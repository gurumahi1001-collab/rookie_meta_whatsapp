import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const STATUS_VALUES = ["planned", "in_progress", "on_hold", "completed", "closed"];
const SCOPE_TYPES = ["inScope", "outOfScope"];

const scopeItemSchema = new Schema({
    type: { type: String, enum: SCOPE_TYPES, required: true },
    text: { type: String, required: true, trim: true, maxlength: 3000 },
    completed: { type: Boolean, default: false },
}, { _id: true, timestamps: true, strict: "throw" });

const deliverableSchema = new Schema({
    name: { type: String, required: true, trim: true, maxlength: 500 },
    dueDate: { type: Date, default: null },
    completed: { type: Boolean, default: false },
}, { _id: true, timestamps: true, strict: "throw" });

const phaseSchema = new Schema({
    name: { type: String, required: true, trim: true, maxlength: 250 },
    description: { type: String, trim: true, maxlength: 2000, default: "" },
    estimatedHours: { type: Number, min: 0, default: 0 },
    order: { type: Number, min: 0, default: 0 },
}, { _id: true, timestamps: true, strict: "throw" });

const projectSchema = new Schema({
    name: { type: String, required: true, trim: true, maxlength: 255, index: true },
    location: { type: String, trim: true, maxlength: 500, default: "" },
    client: { type: String, trim: true, maxlength: 255, default: "" },
    description: { type: String, trim: true, maxlength: 5000, default: "" },
    contractor: { type: String, trim: true, maxlength: 255, default: "" },
    surveyRef: { type: String, trim: true, maxlength: 255, default: "" },

    vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", default: null, index: true },
    vendorName: { type: String, trim: true, maxlength: 255, default: "" },
    managerId: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
    managerName: { type: String, trim: true, maxlength: 180, default: "" },
    managerEmail: { type: String, trim: true, lowercase: true, maxlength: 255, default: "" },

    projectValue: { type: Number, min: 0, default: 0 },
    budget: { type: Number, min: 0, default: 0 },
    currency: { type: String, trim: true, uppercase: true, maxlength: 10, default: "USD" },
    startDate: { type: Date, default: null },
    endDate: { type: Date, default: null },
    status: { type: String, enum: STATUS_VALUES, default: "planned", index: true },
    progressPercentage: { type: Number, min: 0, max: 100, default: 0 },
    version: { type: String, trim: true, maxlength: 120, default: "" },
    versionDate: { type: Date, default: null },

    sourceQuotationId: { type: Schema.Types.ObjectId, ref: "Quotation", default: null },
    sourceQuotationNo: { type: String, trim: true, maxlength: 80, default: "" },
    sourceBOQId: { type: Schema.Types.ObjectId, ref: "BOQ", default: null },

    scopeItems: { type: [scopeItemSchema], default: [] },
    deliverables: { type: [deliverableSchema], default: [] },
    phases: { type: [phaseSchema], default: [] },

    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, {
    collection: "projects",
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
});

projectSchema.index({ vendorId: 1, status: 1, updatedAt: -1 });
projectSchema.index({ managerId: 1, status: 1, updatedAt: -1 });
projectSchema.index({ sourceQuotationId: 1 }, { unique: true, sparse: true, name: "projects_source_quotation_unique" });
projectSchema.index({ name: 1, vendorName: 1, updatedAt: -1 });

projectSchema.virtual("id").get(function id() { return String(this._id); });

function dateValue(value) {
    return value ? new Date(value) : null;
}

projectSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        projectName: this.name,
        name: this.name,
        location: this.location || "",
        client: this.client || "",
        description: this.description || "",
        contractor: this.contractor || "",
        surveyRef: this.surveyRef || "",
        vendorId: this.vendorId ? String(this.vendorId) : null,
        vendorName: this.vendorName || "",
        managerId: this.managerId ? String(this.managerId) : null,
        managerName: this.managerName || "",
        managerEmail: this.managerEmail || "",
        projectValue: Number(this.projectValue || 0),
        budget: Number(this.budget || 0),
        currency: this.currency || "USD",
        startDate: dateValue(this.startDate),
        endDate: dateValue(this.endDate),
        status: this.status,
        progress: Number(this.progressPercentage || 0),
        progressPercentage: Number(this.progressPercentage || 0),
        version: this.version || "",
        versionDate: dateValue(this.versionDate),
        sourceQuotationId: this.sourceQuotationId ? String(this.sourceQuotationId) : null,
        sourceQuotationNo: this.sourceQuotationNo || "",
        sourceBOQId: this.sourceBOQId ? String(this.sourceBOQId) : null,
        scopeItems: (this.scopeItems || []).map((item) => ({
            id: String(item._id),
            type: item.type,
            text: item.text,
            completed: Boolean(item.completed),
        })),
        deliverables: (this.deliverables || []).map((item) => ({
            id: String(item._id),
            projectId: String(this._id),
            name: item.name,
            dueDate: dateValue(item.dueDate),
            completed: Boolean(item.completed),
        })),
        phases: (this.phases || []).map((phase) => ({
            id: String(phase._id),
            name: phase.name,
            description: phase.description || "",
            estimatedHours: Number(phase.estimatedHours || 0),
            order: Number(phase.order || 0),
        })),
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

projectSchema.set("toJSON", { virtuals: true });

const Project = models.Project || model("Project", projectSchema);
export default Project;
export { projectSchema, STATUS_VALUES as PROJECT_STATUS_VALUES };
