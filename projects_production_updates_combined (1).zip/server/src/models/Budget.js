import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const budgetLineSchema = new Schema({
    boqLineId: { type: Schema.Types.ObjectId, default: null },
    description: { type: String, trim: true, maxlength: 2000, default: "" },
    unit: { type: String, trim: true, maxlength: 100, default: "Unit" },
    quantity: { type: Number, min: 0, default: 0 },
    allocatedAmount: { type: Number, min: 0, default: 0 },
    utilizedAmount: { type: Number, min: 0, default: 0 },
    remainingAmount: { type: Number, min: 0, default: 0 },
}, { _id: true, strict: "throw" });

const budgetSchema = new Schema({
    projectId: { type: Schema.Types.ObjectId, ref: "Project", unique: true, required: true, index: true },
    totalAllocation: { type: Number, min: 0, default: 0 },
    utilized: { type: Number, min: 0, default: 0 },
    remaining: { type: Number, min: 0, default: 0 },
    thresholdWarning: { type: Number, min: 0, max: 100, default: 80 },
    thresholdCritical: { type: Number, min: 0, max: 100, default: 100 },
    lines: { type: [budgetLineSchema], default: [] },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, {
    collection: "budgets",
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
});

budgetSchema.index({ projectId: 1 }, { unique: true, name: "budgets_project_unique" });
budgetSchema.virtual("id").get(function id() { return String(this._id); });

budgetSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        projectId: String(this.projectId),
        totalAllocation: Number(this.totalAllocation || 0),
        utilized: Number(this.utilized || 0),
        remaining: Number(this.remaining || 0),
        thresholdWarning: Number(this.thresholdWarning || 80),
        thresholdCritical: Number(this.thresholdCritical || 100),
        utilizationPercentage: this.totalAllocation > 0 ? Math.min(100, (Number(this.utilized || 0) / Number(this.totalAllocation || 1)) * 100) : 0,
        lines: (this.lines || []).map((line) => ({
            id: String(line._id),
            boqLineId: line.boqLineId ? String(line.boqLineId) : null,
            description: line.description || "",
            unit: line.unit || "Unit",
            quantity: Number(line.quantity || 0),
            allocatedAmount: Number(line.allocatedAmount || 0),
            utilizedAmount: Number(line.utilizedAmount || 0),
            remainingAmount: Number(line.remainingAmount || 0),
        })),
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

budgetSchema.set("toJSON", { virtuals: true });
const Budget = models.Budget || model("Budget", budgetSchema);
export default Budget;
export { budgetSchema };
