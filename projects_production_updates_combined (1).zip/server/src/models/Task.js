import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const taskStatusValues = ["pending", "inprogress", "onhold", "completed"];
const priorityValues = ["low", "medium", "high", "urgent"];

const assignedStaffSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: "User", default: null },
    name: { type: String, required: true, trim: true, maxlength: 180 },
    rate: { type: Number, min: 0, default: 0 },
    hours: { type: Number, min: 0, default: 0 },
    amount: { type: Number, min: 0, default: 0 },
}, { _id: false, strict: "throw" });

const workLogSchema = new Schema({
    startedAt: { type: Date, required: true },
    stoppedAt: { type: Date, required: true },
    duration: { type: Number, min: 0, default: 0 },
}, { _id: true, strict: "throw" });

const materialSchema = new Schema({
    name: { type: String, required: true, trim: true, maxlength: 500 },
    unitCost: { type: Number, min: 0, default: 0 },
    quantity: { type: Number, min: 0, default: 0 },
}, { _id: true, strict: "throw" });

const otherExpenseSchema = new Schema({
    name: { type: String, required: true, trim: true, maxlength: 500 },
    amount: { type: Number, min: 0, default: 0 },
    description: { type: String, trim: true, maxlength: 1000, default: "" },
}, { _id: true, strict: "throw" });

const commentSchema = new Schema({
    type: { type: String, enum: ["update", "question", "image"], default: "update" },
    text: { type: String, required: true, trim: true, maxlength: 5000 },
    image: { type: String, trim: true, maxlength: 2000, default: null },
    authorId: { type: Schema.Types.ObjectId, ref: "User", default: null },
    authorName: { type: String, trim: true, maxlength: 180, default: "" },
    createdAt: { type: Date, default: Date.now },
}, { _id: true, strict: "throw" });

const attachmentSchema = new Schema({
    name: { type: String, trim: true, maxlength: 500, required: true },
    url: { type: String, trim: true, maxlength: 2000, required: true },
    mimeType: { type: String, trim: true, maxlength: 160, default: "application/octet-stream" },
    size: { type: Number, min: 0, default: 0 },
    createdAt: { type: Date, default: Date.now },
}, { _id: true, strict: "throw" });

const taskSchema = new Schema({
    projectId: { type: Schema.Types.ObjectId, ref: "Project", required: true, index: true },
    phaseId: { type: Schema.Types.ObjectId, default: null },
    phaseName: { type: String, trim: true, maxlength: 250, default: "" },

    title: { type: String, required: true, trim: true, maxlength: 255 },
    description: { type: String, trim: true, maxlength: 5000, default: "" },
    ownerIds: { type: [Schema.Types.ObjectId], ref: "User", default: [] },
    ownerNames: { type: [String], default: [] },
    assignedStaff: { type: [assignedStaffSchema], default: [] },

    startDate: { type: Date, default: null },
    dueDate: { type: Date, default: null, index: true },
    priority: { type: String, enum: priorityValues, default: "medium" },
    status: { type: String, enum: taskStatusValues, default: "pending", index: true },
    progressPercentage: { type: Number, min: 0, max: 100, default: 0 },

    estimatedHours: { type: Number, min: 0, default: 0 },
    actualHours: { type: Number, min: 0, default: 0 },
    hourlyRate: { type: Number, min: 0, default: 0 },
    materialCost: { type: Number, min: 0, default: 0 },
    otherExpenses: { type: Number, min: 0, default: 0 },

    timerStartedAt: { type: Date, default: null },
    totalWorkedSeconds: { type: Number, min: 0, default: 0 },
    isTimerRunning: { type: Boolean, default: false },
    workLogs: { type: [workLogSchema], default: [] },
    materials: { type: [materialSchema], default: [] },
    otherExpensesBreakdown: { type: [otherExpenseSchema], default: [] },
    comments: { type: [commentSchema], default: [] },
    attachments: { type: [attachmentSchema], default: [] },

    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, {
    collection: "tasks",
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
});

taskSchema.index({ projectId: 1, phaseId: 1, status: 1, dueDate: 1 });
taskSchema.index({ ownerIds: 1, status: 1, dueDate: 1 });
taskSchema.virtual("id").get(function id() { return String(this._id); });

taskSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        projectId: String(this.projectId),
        phaseId: this.phaseId ? String(this.phaseId) : null,
        phaseName: this.phaseName || "",
        title: this.title,
        name: this.title,
        description: this.description || "",
        ownerIds: (this.ownerIds || []).map(String),
        ownerNames: this.ownerNames || [],
        assignedStaff: (this.assignedStaff || []).map((staff) => ({
            userId: staff.userId ? String(staff.userId) : null,
            name: staff.name,
            rate: Number(staff.rate || 0),
            hours: Number(staff.hours || 0),
            amount: Number(staff.amount || 0),
        })),
        startDate: this.startDate || null,
        dueDate: this.dueDate || null,
        priority: String(this.priority || "medium").replace(/^./, (c) => c.toUpperCase()),
        status: this.status === "inprogress" ? "In Progress" : this.status === "onhold" ? "On Hold" : this.status === "completed" ? "Completed" : "Pending",
        progress: Number(this.progressPercentage || 0),
        estimatedHours: Number(this.estimatedHours || 0),
        actualHours: Number(this.actualHours || 0),
        hourlyRate: Number(this.hourlyRate || 0),
        materialCost: Number(this.materialCost || 0),
        otherExpenses: Number(this.otherExpenses || 0),
        timerStartedAt: this.timerStartedAt || null,
        totalWorkedSeconds: Number(this.totalWorkedSeconds || 0),
        isTimerRunning: Boolean(this.isTimerRunning),
        workLogs: (this.workLogs || []).map((log) => ({ id: String(log._id), startedAt: log.startedAt, stoppedAt: log.stoppedAt, duration: Number(log.duration || 0) })),
        materials: (this.materials || []).map((item) => ({ id: String(item._id), name: item.name, unitCost: Number(item.unitCost || 0), quantity: Number(item.quantity || 0) })),
        otherExpensesBreakdown: (this.otherExpensesBreakdown || []).map((item) => ({ id: String(item._id), name: item.name, amount: Number(item.amount || 0), description: item.description || "" })),
        comments: (this.comments || []).map((item) => ({ id: String(item._id), type: item.type, text: item.text, image: item.image || null, createdAt: item.createdAt, authorName: item.authorName || "" })),
        attachments: (this.attachments || []).map((item) => ({ id: String(item._id), name: item.name, url: item.url, mimeType: item.mimeType, size: Number(item.size || 0), createdAt: item.createdAt })),
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

taskSchema.set("toJSON", { virtuals: true });
const Task = models.Task || model("Task", taskSchema);
export default Task;
export { taskSchema };
