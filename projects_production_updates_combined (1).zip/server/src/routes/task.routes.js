import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";
import * as controller from "../controllers/task/taskController.js";

const router = Router();
router.use(authenticate);
router.get("/", authorize({ module: "task", action: "view", realms: ["admin", "internal", "vendor"] }), controller.list);
router.get("/:taskId", authorize({ module: "task", action: "view", realms: ["admin", "internal", "vendor"] }), controller.get);
router.post("/", authorize({ module: "task", action: "add", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.create);
router.patch("/:taskId", authorize({ module: "task", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.update);
router.delete("/:taskId", authorize({ module: "task", action: "delete", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.remove);
export default router;
