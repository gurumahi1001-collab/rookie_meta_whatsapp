import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";
import * as controller from "../controllers/budget/budgetController.js";

const router = Router();
router.use(authenticate);
router.get("/project/:projectId", authorize({ module: "budget", action: "view", realms: ["admin", "internal", "vendor"] }), controller.get);
router.get("/", authorize({ module: "budget", action: "view", realms: ["admin", "internal", "vendor"] }), controller.list);
router.post("/project/:projectId", authorize({ module: "budget", action: "add", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.create);
router.patch("/project/:projectId", authorize({ module: "budget", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.update);
router.delete("/project/:projectId", authorize({ module: "budget", action: "delete", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.remove);
export default router;
