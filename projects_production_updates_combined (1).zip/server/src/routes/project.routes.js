import { Router } from "express";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";
import * as controller from "../controllers/project/projectController.js";

const router = Router();
router.use(authenticate);

router.get("/", authorize({ module: "project", action: "view", realms: ["admin", "internal", "vendor"] }), controller.list);
router.get("/:projectId", authorize({ module: "project", action: "view", realms: ["admin", "internal", "vendor"] }), controller.get);
router.post("/from-quotation/:quotationId", authorize({ module: "project", action: "add", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.createFromQuotation);
router.post("/", authorize({ module: "project", action: "add", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.create);
router.patch("/:projectId/status", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.updateStatus);
router.patch("/:projectId", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.update);
router.delete("/:projectId", authorize({ module: "project", action: "delete", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.remove);

router.post("/:projectId/phases", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.addPhase);
router.post("/:projectId/scope", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.addScope);
router.patch("/:projectId/scope/:scopeId", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.updateScope);
router.delete("/:projectId/scope/:scopeId", authorize({ module: "project", action: "delete", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.deleteScope);
router.post("/:projectId/deliverables", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.addDeliverable);
router.patch("/:projectId/deliverables/:deliverableId", authorize({ module: "project", action: "edit", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.updateDeliverable);
router.delete("/:projectId/deliverables/:deliverableId", authorize({ module: "project", action: "delete", realms: ["admin", "internal"], allowSuperAdmin: true }), controller.deleteDeliverable);

export default router;
