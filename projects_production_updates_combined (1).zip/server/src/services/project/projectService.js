import mongoose from "mongoose";
import Project from "../../models/Project.js";
import Task from "../../models/Task.js";
import Budget from "../../models/Budget.js";
import Vendor from "../../models/Vendor.js";
import User from "../../models/User.js";
import Quotation from "../../models/Quotation.js";
import BOQ from "../../models/BOQ.js";
import auditService from "../audit/auditService.js";

const INTERNAL_TYPES = ["admin", "internal"];
const PROJECT_STATUSES = ["planned", "in_progress", "on_hold", "completed", "closed"];
const STATUS_TO_UI = { planned: "Planned", in_progress: "In Progress", on_hold: "On Hold", completed: "Completed", closed: "Closed" };
const UI_TO_STATUS = { Planned: "planned", "In Progress": "in_progress", "On Hold": "on_hold", Completed: "completed", Closed: "closed" };

export class ProjectServiceError extends Error {
    constructor(message, { code = "PROJECT_ERROR", statusCode = 400, details = undefined } = {}) {
        super(message);
        this.name = "ProjectServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
    }
}

function text(value) { return typeof value === "string" ? value.trim() : ""; }
function num(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function bool(value, fallback = false) { return typeof value === "boolean" ? value : fallback; }
function actorId(actor) { return actor?.userId && mongoose.isValidObjectId(actor.userId) ? new mongoose.Types.ObjectId(actor.userId) : null; }
function oid(value, field = "id") { if (!mongoose.isValidObjectId(value)) throw new ProjectServiceError(`Invalid ${field}.`, { code: `INVALID_${field.replace(/\s+/g, "_").toUpperCase()}`, statusCode: 422 }); return new mongoose.Types.ObjectId(value); }
function dateValue(value, field = "date") { if (value === undefined || value === null || value === "") return null; const d = value instanceof Date ? new Date(value.getTime()) : new Date(value); if (Number.isNaN(d.getTime())) throw new ProjectServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 }); return d; }
function internal(actor) { return INTERNAL_TYPES.includes(String(actor?.userType || "").toLowerCase()); }
function vendor(actor) { return String(actor?.userType || "").toLowerCase() === "vendor"; }
function status(value) { const raw = text(value); if (!raw) return undefined; const normalized = UI_TO_STATUS[raw] || raw.toLowerCase().replace(/\s+/g, "_"); if (!PROJECT_STATUSES.includes(normalized)) throw new ProjectServiceError("Invalid project status.", { code: "INVALID_PROJECT_STATUS", statusCode: 422 }); return normalized; }
function serializeProject(project) { return project?.toSafeJSON ? project.toSafeJSON() : project; }

async function audit(action, project, actor, request, metadata = {}, changes = null) {
    try {
        await auditService.recordAudit({
            action,
            module: "project",
            title: `Project ${action.replace(/_/g, " ")}`,
            description: project?.name || "",
            actor: actor?.actor || actor || null,
            request,
            entityType: "project",
            entityId: project?._id ? String(project._id) : "",
            entityName: project?.name || "",
            vendorId: project?.vendorId || actor?.vendorId || null,
            metadata,
            changes,
        });
    } catch (error) {
        console.error("[projectService] audit write failed", error);
    }
}

function projectManagerScoped(actor) {
    const role = text(actor?.role).toLowerCase().replace(/[-\s]+/g, "_");
    return ["project_manager", "projectmanager", "pm"].includes(role);
}

function canViewProjectRecord(project, actor) {
    if (!project || !actor) return false;
    if (vendor(actor)) return Boolean(actor.vendorId && project.vendorId && String(actor.vendorId) === String(project.vendorId));
    if (projectManagerScoped(actor)) return Boolean(actor.userId && project.managerId && String(actor.userId) === String(project.managerId));
    return internal(actor);
}

function canEditProjectRecord(project, actor) {
    return internal(actor) && Boolean(project);
}

function normalizeStaffNames(value) {
    if (Array.isArray(value)) return [...new Set(value.map((v) => text(typeof v === "object" ? v?.name : v)).filter(Boolean))];
    return text(value).split(",").map((v) => v.trim()).filter(Boolean);
}

async function resolveVendor(vendorId, vendorName) {
    let row = null;
    if (vendorId) row = await Vendor.findById(oid(vendorId, "vendorId"));
    else if (vendorName) row = await Vendor.findOne({ companyName: vendorName });
    if (!row) throw new ProjectServiceError("Approved vendor was not found.", { code: "VENDOR_NOT_FOUND", statusCode: 404 });
    if (row.accountStatus && row.accountStatus !== "APPROVED") throw new ProjectServiceError("Only approved vendors can be assigned to a project.", { code: "VENDOR_NOT_APPROVED", statusCode: 422 });
    return row;
}

async function resolveManager(managerId, managerName) {
    if (managerId) {
        if (!mongoose.isValidObjectId(managerId)) throw new ProjectServiceError("Invalid manager ID.", { code: "INVALID_MANAGER_ID", statusCode: 422 });
        const row = await User.findOne({ _id: managerId, status: "active", userType: { $in: INTERNAL_TYPES } }).select("displayName email");
        if (!row) throw new ProjectServiceError("Project manager was not found.", { code: "MANAGER_NOT_FOUND", statusCode: 404 });
        return row;
    }
    if (!managerName) return null;
    const row = await User.findOne({ displayName: managerName, status: "active", userType: { $in: INTERNAL_TYPES } }).select("displayName email");
    if (!row) throw new ProjectServiceError("Project manager was not found.", { code: "MANAGER_NOT_FOUND", statusCode: 404 });
    return row;
}

async function createBudgetForProject(project, boq = null, actor = null) {
    const existing = await Budget.findOne({ projectId: project._id });
    if (existing) return existing;

    const sourceLines = Array.isArray(boq?.lines) ? boq.lines : [];
    const lines = sourceLines.map((line) => ({
        boqLineId: line._id || null,
        description: text(line.description),
        unit: text(line.unit) || "Unit",
        quantity: num(line.quantity),
        allocatedAmount: num(line.lineTotal, num(line.quantity) * num(line.rate)),
        utilizedAmount: 0,
        remainingAmount: num(line.lineTotal, num(line.quantity) * num(line.rate)),
    }));
    const totalAllocation = num(boq?.grandTotal, num(project.budget));
    const budget = new Budget({
        projectId: project._id,
        totalAllocation,
        utilized: 0,
        remaining: totalAllocation,
        thresholdWarning: 80,
        thresholdCritical: 100,
        lines,
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    await budget.save();
    return budget;
}

async function buildProjectFromQuotation(quotation, { actor = null, request = null } = {}) {
    if (!quotation || text(quotation.status) !== "Awarded") return null;
    if (!quotation.award?.vendorId && !quotation.vendorId) return null;
    const sourceQuotationId = quotation._id;
    const existing = await Project.findOne({ sourceQuotationId }).catch(() => null);
    if (existing) return existing;

    let boq = null;
    if (quotation.boqId && mongoose.isValidObjectId(quotation.boqId)) boq = await BOQ.findById(quotation.boqId).catch(() => null);
    const selectedVendorId = quotation.award?.vendorId || quotation.vendorId;
    const selectedVendorName = quotation.award?.vendorName || quotation.vendorName;
    const manager = null;
    const project = new Project({
        name: text(quotation.projectTitle) || `Project ${quotation.quotationNo}`,
        location: text(quotation.projectSiteLocation),
        client: text(quotation.clientName),
        description: text(quotation.scopeSummary),
        contractor: selectedVendorName,
        surveyRef: text(quotation.siteSurveyReference),
        vendorId: selectedVendorId,
        vendorName: selectedVendorName,
        managerId: manager?.id || null,
        managerName: manager?.displayName || "",
        managerEmail: manager?.email || "",
        projectValue: num(quotation.grandTotal),
        budget: num(boq?.grandTotal, num(quotation.grandTotal)),
        currency: text(quotation.currency) || "USD",
        startDate: null,
        endDate: null,
        status: "planned",
        progressPercentage: 0,
        version: `v${num(quotation.revision, 1) || 1}.0`,
        versionDate: quotation.quotationDate || new Date(),
        sourceQuotationId,
        sourceQuotationNo: text(quotation.quotationNo),
        sourceBOQId: boq?._id || quotation.boqId || null,
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    try {
        await project.save();
    } catch (error) {
        if (error?.code === 11000) return Project.findOne({ sourceQuotationId });
        throw error;
    }
    await createBudgetForProject(project, boq, actor);
    await audit("created_from_award", project, actor, request, { quotationId: String(sourceQuotationId), quotationNo: quotation.quotationNo, boqId: boq?._id ? String(boq._id) : null });
    return project;
}

export async function syncAwardedProjects({ actor = null, request = null } = {}) {
    const awarded = await Quotation.find({ status: "Awarded" }).sort({ updatedAt: 1, _id: 1 }).limit(500);
    const result = [];
    for (const quotation of awarded) {
        const project = await buildProjectFromQuotation(quotation, { actor, request });
        if (project) result.push(project);
    }
    return result;
}

export async function listProjects({ actor, page = 1, limit = 50, search = "", status: statusFilter = "" } = {}) {
    if (!internal(actor) && !vendor(actor)) throw new ProjectServiceError("Project access is not available for this account.", { code: "PROJECT_ACCESS_FORBIDDEN", statusCode: 403 });
    await syncAwardedProjects({ actor: null });

    const p = Math.max(1, parseInt(String(page), 10) || 1);
    const l = Math.min(200, Math.max(1, parseInt(String(limit), 10) || 50));
    const filter = {};
    if (vendor(actor)) filter.vendorId = oid(actor.vendorId, "vendorId");
    else if (projectManagerScoped(actor)) filter.managerId = oid(actor.userId, "userId");
    if (text(statusFilter)) filter.status = status(statusFilter);
    if (text(search)) {
        const escaped = text(search).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const regex = new RegExp(escaped, "i");
        filter.$or = [{ name: regex }, { vendorName: regex }, { location: regex }, { managerName: regex }, { sourceQuotationNo: regex }];
    }
    const [rows, total] = await Promise.all([
        Project.find(filter).sort({ updatedAt: -1, _id: -1 }).skip((p - 1) * l).limit(l),
        Project.countDocuments(filter),
    ]);
    return { data: rows.map(serializeProject), pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) } };
}

export async function getProject(id, { actor } = {}) {
    const project = await Project.findById(oid(id, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canViewProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to view this project.", { code: "PROJECT_ACCESS_FORBIDDEN", statusCode: 403 });

    const [tasks, budget, users] = await Promise.all([
        Task.find({ projectId: project._id }).sort({ phaseId: 1, createdAt: 1, _id: 1 }),
        Budget.findOne({ projectId: project._id }),
        User.find({ userType: { $in: INTERNAL_TYPES }, status: "active" }).select("displayName").sort({ displayName: 1 }).lean(),
    ]);
    const quotation = project.sourceQuotationId ? await Quotation.findById(project.sourceQuotationId).lean().catch(() => null) : null;
    const paymentSchedule = (quotation?.paymentSchedule || []).map((item) => ({ id: String(item._id), name: item.name, amount: num(item.amount), type: item.type || "custom", dueDate: item.dueDate || null, status: "Pending" }));

    return {
        project: serializeProject(project),
        phases: (project.phases || []).sort((a, b) => num(a.order) - num(b.order)).map((phase) => ({ id: String(phase._id), name: phase.name, description: phase.description || "", estimatedHours: num(phase.estimatedHours), order: num(phase.order) })),
        tasks: tasks.map((task) => task.toSafeJSON()),
        scopeItems: (project.scopeItems || []).map((item) => ({ id: String(item._id), type: item.type, text: item.text, completed: Boolean(item.completed) })),
        deliverables: (project.deliverables || []).map((item) => ({ id: String(item._id), projectId: String(project._id), name: item.name, dueDate: item.dueDate || null, completed: Boolean(item.completed) })),
        budget: budget?.toSafeJSON ? budget.toSafeJSON() : { id: null, projectId: String(project._id), totalAllocation: num(project.budget), utilized: 0, remaining: num(project.budget), thresholdWarning: 80, thresholdCritical: 100, lines: [] },
        paymentSchedule,
        teamMembers: users.map((user) => user.displayName).filter(Boolean),
    };
}

export async function createProjectFromQuotation(quotationId, { actor, request = null } = {}) {
    if (!internal(actor)) throw new ProjectServiceError("Only internal users can create projects.", { code: "PROJECT_CREATE_FORBIDDEN", statusCode: 403 });
    const quotation = await Quotation.findById(oid(quotationId, "quotationId"));
    if (!quotation) throw new ProjectServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    if (quotation.status !== "Awarded") throw new ProjectServiceError("Only awarded quotations can create projects.", { code: "QUOTATION_NOT_AWARDED", statusCode: 409 });
    const project = await buildProjectFromQuotation(quotation, { actor, request });
    if (!project) throw new ProjectServiceError("Unable to create project from the awarded quotation.", { code: "PROJECT_CREATE_FAILED", statusCode: 500 });
    return getProject(project._id, { actor });
}

export async function updateProject(id, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(id, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit this project.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });

    const before = { name: project.name, location: project.location, vendorId: project.vendorId ? String(project.vendorId) : null, managerId: project.managerId ? String(project.managerId) : null, endDate: project.endDate, status: project.status, progressPercentage: project.progressPercentage };
    if (payload.projectName !== undefined || payload.name !== undefined) project.name = text(payload.projectName ?? payload.name) || project.name;
    if (payload.location !== undefined) project.location = text(payload.location);
    if (payload.description !== undefined) project.description = text(payload.description);
    if (payload.client !== undefined) project.client = text(payload.client);
    if (payload.endDate !== undefined) project.endDate = dateValue(payload.endDate, "endDate");
    if (payload.startDate !== undefined) project.startDate = dateValue(payload.startDate, "startDate");
    if (payload.projectValue !== undefined) project.projectValue = Math.max(0, num(payload.projectValue));
    if (payload.budget !== undefined) project.budget = Math.max(0, num(payload.budget));
    if (payload.vendorId !== undefined || payload.vendorName !== undefined) {
        const v = await resolveVendor(payload.vendorId, text(payload.vendorName));
        project.vendorId = v._id; project.vendorName = v.companyName; project.contractor = v.companyName;
    }
    if (payload.managerId !== undefined || payload.managerName !== undefined) {
        const manager = await resolveManager(payload.managerId, text(payload.managerName));
        project.managerId = manager?._id || null;
        project.managerName = manager?.displayName || "";
        project.managerEmail = manager?.email || "";
    }
    if (payload.status !== undefined) project.status = status(payload.status) || project.status;
    if (payload.progress !== undefined || payload.progressPercentage !== undefined) project.progressPercentage = Math.max(0, Math.min(100, num(payload.progress ?? payload.progressPercentage)));
    if (project.startDate && project.endDate && project.endDate < project.startDate) throw new ProjectServiceError("Project end date cannot be before the start date.", { code: "PROJECT_DATE_RANGE_INVALID", statusCode: 422 });
    project.updatedBy = actorId(actor);
    await project.save();
    if (payload.budget !== undefined) await Budget.findOneAndUpdate({ projectId: project._id }, { $set: { totalAllocation: project.budget, remaining: Math.max(0, project.budget - num((await Budget.findOne({ projectId: project._id }))?.utilized)) }, $setOnInsert: { projectId: project._id, thresholdWarning: 80, thresholdCritical: 100 } }, { new: true, upsert: true });
    const after = { name: project.name, location: project.location, vendorId: project.vendorId ? String(project.vendorId) : null, managerId: project.managerId ? String(project.managerId) : null, endDate: project.endDate, status: project.status, progressPercentage: project.progressPercentage };
    await audit("updated", project, actor, request, {}, { before, after });
    return serializeProject(project);
}

export async function removeProject(id, { actor, request = null } = {}) {
    const project = await Project.findById(oid(id, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!internal(actor)) throw new ProjectServiceError("Only internal users can delete projects.", { code: "PROJECT_DELETE_FORBIDDEN", statusCode: 403 });
    if (["completed", "closed"].includes(project.status)) throw new ProjectServiceError("Completed or closed projects cannot be deleted.", { code: "PROJECT_DELETE_FORBIDDEN", statusCode: 409 });
    await Promise.all([Task.deleteMany({ projectId: project._id }), Budget.deleteOne({ projectId: project._id }), Project.deleteOne({ _id: project._id })]);
    await audit("deleted", project, actor, request);
    return { id: String(project._id), projectName: project.name };
}

export async function addPhase(projectId, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to add project phases.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const name = text(payload.name); if (!name) throw new ProjectServiceError("Phase name is required.", { code: "PHASE_NAME_REQUIRED", statusCode: 422 });
    const phase = { name, description: text(payload.description), estimatedHours: Math.max(0, num(payload.estimatedHours)), order: project.phases.length };
    project.phases.push(phase); project.updatedBy = actorId(actor); await project.save();
    const created = project.phases[project.phases.length - 1];
    await audit("phase_added", project, actor, request, { phaseId: String(created._id), phaseName: name });
    return { id: String(created._id), name: created.name, description: created.description, estimatedHours: num(created.estimatedHours), order: num(created.order) };
}

export async function addScopeItem(projectId, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit project scope.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const type = text(payload.type); if (!SCOPE_TYPES.includes(type)) throw new ProjectServiceError("Invalid scope type.", { code: "INVALID_SCOPE_TYPE", statusCode: 422 });
    const scopeText = text(payload.text); if (!scopeText) throw new ProjectServiceError("Scope text is required.", { code: "SCOPE_TEXT_REQUIRED", statusCode: 422 });
    project.scopeItems.push({ type, text: scopeText, completed: bool(payload.completed) }); project.updatedBy = actorId(actor); await project.save();
    const item = project.scopeItems[project.scopeItems.length - 1];
    await audit("scope_added", project, actor, request, { scopeId: String(item._id), type });
    return { id: String(item._id), type: item.type, text: item.text, completed: Boolean(item.completed) };
}

export async function updateScopeItem(projectId, scopeId, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit project scope.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const item = project.scopeItems.id(oid(scopeId, "scopeId")); if (!item) throw new ProjectServiceError("Scope item was not found.", { code: "SCOPE_ITEM_NOT_FOUND", statusCode: 404 });
    if (payload.text !== undefined) item.text = text(payload.text) || item.text;
    if (payload.type !== undefined) { const t = text(payload.type); if (!SCOPE_TYPES.includes(t)) throw new ProjectServiceError("Invalid scope type.", { code: "INVALID_SCOPE_TYPE", statusCode: 422 }); item.type = t; }
    if (payload.completed !== undefined) item.completed = bool(payload.completed);
    project.updatedBy = actorId(actor); await project.save();
    await audit("scope_updated", project, actor, request, { scopeId: String(item._id) });
    return { id: String(item._id), type: item.type, text: item.text, completed: Boolean(item.completed) };
}

export async function deleteScopeItem(projectId, scopeId, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit project scope.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const item = project.scopeItems.id(oid(scopeId, "scopeId")); if (!item) throw new ProjectServiceError("Scope item was not found.", { code: "SCOPE_ITEM_NOT_FOUND", statusCode: 404 });
    item.deleteOne(); project.updatedBy = actorId(actor); await project.save(); await audit("scope_deleted", project, actor, request, { scopeId }); return { id: scopeId };
}

export async function addDeliverable(projectId, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit deliverables.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const name = text(payload.name); if (!name) throw new ProjectServiceError("Deliverable name is required.", { code: "DELIVERABLE_NAME_REQUIRED", statusCode: 422 });
    const dueDate = dateValue(payload.dueDate, "dueDate");
    project.deliverables.push({ name, dueDate, completed: bool(payload.completed) }); project.updatedBy = actorId(actor); await project.save();
    const item = project.deliverables[project.deliverables.length - 1]; await audit("deliverable_added", project, actor, request, { deliverableId: String(item._id) });
    return { id: String(item._id), projectId: String(project._id), name: item.name, dueDate: item.dueDate, completed: Boolean(item.completed) };
}

export async function updateDeliverable(projectId, deliverableId, payload, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit deliverables.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const item = project.deliverables.id(oid(deliverableId, "deliverableId")); if (!item) throw new ProjectServiceError("Deliverable was not found.", { code: "DELIVERABLE_NOT_FOUND", statusCode: 404 });
    if (payload.name !== undefined) item.name = text(payload.name) || item.name;
    if (payload.dueDate !== undefined) item.dueDate = dateValue(payload.dueDate, "dueDate");
    if (payload.completed !== undefined) item.completed = bool(payload.completed);
    project.updatedBy = actorId(actor); await project.save(); await audit("deliverable_updated", project, actor, request, { deliverableId: String(item._id) });
    return { id: String(item._id), projectId: String(project._id), name: item.name, dueDate: item.dueDate, completed: Boolean(item.completed) };
}

export async function deleteDeliverable(projectId, deliverableId, { actor, request = null } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) throw new ProjectServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!canEditProjectRecord(project, actor)) throw new ProjectServiceError("You are not authorized to edit deliverables.", { code: "PROJECT_EDIT_FORBIDDEN", statusCode: 403 });
    const item = project.deliverables.id(oid(deliverableId, "deliverableId")); if (!item) throw new ProjectServiceError("Deliverable was not found.", { code: "DELIVERABLE_NOT_FOUND", statusCode: 404 });
    item.deleteOne(); project.updatedBy = actorId(actor); await project.save(); await audit("deliverable_deleted", project, actor, request, { deliverableId }); return { id: deliverableId };
}

export function uiStatus(statusValue) { return STATUS_TO_UI[statusValue] || STATUS_TO_UI.planned; }
export function toProjectStatus(value) { return status(value); }
