import mongoose from "mongoose";
import Task from "../../models/Task.js";
import Project from "../../models/Project.js";
import User from "../../models/User.js";
import auditService from "../audit/auditService.js";

const INTERNAL_TYPES = ["admin", "internal"];
const PRIORITIES = ["low", "medium", "high", "urgent"];
const STATUSES = ["pending", "inprogress", "onhold", "completed"];

export class TaskServiceError extends Error {
    constructor(message, { code = "TASK_ERROR", statusCode = 400, details = undefined } = {}) { super(message); this.name = "TaskServiceError"; this.code = code; this.statusCode = statusCode; this.details = details; }
}
function text(v) { return typeof v === "string" ? v.trim() : ""; }
function num(v, d = 0) { const n = Number(v); return Number.isFinite(n) ? n : d; }
function oid(v, field = "id") { if (!mongoose.isValidObjectId(v)) throw new TaskServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 }); return new mongoose.Types.ObjectId(v); }
function dt(v, field) { if (v === undefined || v === null || v === "") return null; const d = new Date(v); if (Number.isNaN(d.getTime())) throw new TaskServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 }); return d; }
function internal(a) { return INTERNAL_TYPES.includes(String(a?.userType || "").toLowerCase()); }
function vendor(a) { return String(a?.userType || "").toLowerCase() === "vendor"; }
function actorId(a) { return a?.userId && mongoose.isValidObjectId(a.userId) ? new mongoose.Types.ObjectId(a.userId) : null; }
function normalizeStatus(v) { const s = text(v).toLowerCase().replace(/\s+/g, ""); const map = { "pending": "pending", "inprogress": "inprogress", "in_progress": "inprogress", "onhold": "onhold", "on_hold": "onhold", "completed": "completed", "due_date": "pending" }; const out = map[s] || map[text(v).toLowerCase().replace(/\s+/g, "_")]; if (!out || !STATUSES.includes(out)) throw new TaskServiceError("Invalid task status.", { code: "INVALID_TASK_STATUS", statusCode: 422 }); return out; }
function normalizePriority(v) { const p = text(v).toLowerCase(); if (!PRIORITIES.includes(p)) throw new TaskServiceError("Invalid task priority.", { code: "INVALID_TASK_PRIORITY", statusCode: 422 }); return p; }
function serialize(task) { return task?.toSafeJSON ? task.toSafeJSON() : task; }
async function audit(action, task, actor, request, metadata = {}) { try { await auditService.recordAudit({ action, module: "task", title: `Task ${action.replace(/_/g, " ")}`, description: task?.title || "", actor: actor?.actor || actor || null, request, entityType: "task", entityId: task?._id ? String(task._id) : "", entityName: task?.title || "", vendorId: actor?.vendorId || null, metadata }); } catch (e) { console.error("[taskService] audit write failed", e); } }
async function getProject(projectId) { const p = await Project.findById(oid(projectId, "projectId")); if (!p) throw new TaskServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 }); return p; }
function canView(project, actor) { if (internal(actor)) { const role = text(actor?.role).toLowerCase().replace(/[-\s]+/g, "_"); if (["project_manager", "projectmanager", "pm"].includes(role)) return String(project.managerId || "") === String(actor.userId || ""); return true; } return vendor(actor) && actor.vendorId && project.vendorId && String(actor.vendorId) === String(project.vendorId); }
async function assignedStaff(value, fallbackRate, fallbackHours) {
    const names = Array.isArray(value) ? value : text(value).split(",").map((x) => x.trim()).filter(Boolean);
    const unique = [...new Set(names.map((x) => typeof x === "object" ? text(x.name) : text(x)).filter(Boolean))];
    if (!unique.length) return { ownerIds: [], ownerNames: [], staff: [] };
    const users = await User.find({ displayName: { $in: unique }, status: "active" }).select("_id displayName hourlyRate").lean();
    const byName = new Map(users.map((u) => [u.displayName, u]));
    return {
        ownerIds: unique.map((n) => byName.get(n)?._id).filter(Boolean),
        ownerNames: unique,
        staff: unique.map((name) => {
            const supplied = Array.isArray(value) ? value.find((v) => typeof v === "object" && text(v.name) === name) : null;
            const rate = Math.max(0, num(supplied?.rate, num(byName.get(name)?.hourlyRate, fallbackRate)));
            const hours = Math.max(0, num(supplied?.hours, fallbackHours));
            return { userId: byName.get(name)?._id || null, name, rate, hours, amount: Math.max(0, num(supplied?.amount, rate * hours)) };
        }),
    };
}
function normalizeArray(value, mapper) { return Array.isArray(value) ? value.map(mapper).filter(Boolean) : undefined; }

export async function listTasks({ actor, projectId, page = 1, limit = 200 } = {}) {
    if (!projectId) throw new TaskServiceError("Project ID is required.", { code: "PROJECT_ID_REQUIRED", statusCode: 422 });
    const project = await getProject(projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to view these tasks.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const p = Math.max(1, parseInt(String(page), 10) || 1); const l = Math.min(500, Math.max(1, parseInt(String(limit), 10) || 200));
    const [rows, total] = await Promise.all([Task.find({ projectId: project._id }).sort({ createdAt: 1, _id: 1 }).skip((p - 1) * l).limit(l), Task.countDocuments({ projectId: project._id})]);
    return { data: rows.map(serialize), pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) } };
}

export async function getTask(id, { actor } = {}) {
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await getProject(task.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to view this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 }); return serialize(task);
}

export async function createTask(payload, { actor, request = null } = {}) {
    if (!internal(actor)) throw new TaskServiceError("Only internal users can create project tasks.", { code: "TASK_CREATE_FORBIDDEN", statusCode: 403 });
    const project = await getProject(payload.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to add tasks to this project.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const title = text(payload.title ?? payload.name); if (!title) throw new TaskServiceError("Task title is required.", { code: "TASK_TITLE_REQUIRED", statusCode: 422 });
    const phaseId = payload.phaseId && mongoose.isValidObjectId(payload.phaseId) ? new mongoose.Types.ObjectId(payload.phaseId) : null;
    const phase = phaseId ? project.phases.id(phaseId) : null;
    const assigned = await assignedStaff(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff, num(payload.hourlyRate), num(payload.estimatedHours));
    const status = normalizeStatus(payload.status ?? "pending");
    const progress = Math.max(0, Math.min(100, num(payload.progress ?? 0)));
    const task = new Task({
        projectId: project._id,
        phaseId: phase?._id || null,
        phaseName: phase?.name || text(payload.phaseName),
        title,
        description: text(payload.description),
        ownerIds: assigned.ownerIds,
        ownerNames: assigned.ownerNames,
        assignedStaff: assigned.staff,
        startDate: dt(payload.startDate, "startDate"),
        dueDate: dt(payload.dueDate, "dueDate"),
        priority: normalizePriority(payload.priority ?? "medium"),
        status,
        progressPercentage: progress,
        estimatedHours: Math.max(0, num(payload.estimatedHours)),
        actualHours: Math.max(0, num(payload.actualHours ?? (num(payload.totalWorkedSeconds) / 3600))),
        hourlyRate: Math.max(0, num(payload.hourlyRate)),
        materialCost: Math.max(0, num(payload.materialCost)),
        otherExpenses: Math.max(0, num(payload.otherExpenses)),
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    await task.save(); await recalculateProjectProgress(project._id); await audit("created", task, actor, request, { projectId: String(project._id) }); return serialize(task);
}

export async function updateTask(id, payload, { actor, request = null } = {}) {
    if (!internal(actor)) throw new TaskServiceError("Only internal users can update project tasks.", { code: "TASK_EDIT_FORBIDDEN", statusCode: 403 });
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await getProject(task.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to update this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const before = { title: task.title, status: task.status, progress: task.progressPercentage, assignedStaff: task.assignedStaff, estimatedHours: task.estimatedHours, actualHours: task.actualHours, materialCost: task.materialCost, otherExpenses: task.otherExpenses };
    if (payload.title !== undefined || payload.name !== undefined) task.title = text(payload.title ?? payload.name) || task.title;
    if (payload.description !== undefined) task.description = text(payload.description);
    if (payload.phaseId !== undefined) { task.phaseId = payload.phaseId && mongoose.isValidObjectId(payload.phaseId) ? new mongoose.Types.ObjectId(payload.phaseId) : null; const phase = task.phaseId ? project.phases.id(task.phaseId) : null; task.phaseName = phase?.name || text(payload.phaseName); }
    if (payload.startDate !== undefined) task.startDate = dt(payload.startDate, "startDate");
    if (payload.dueDate !== undefined) task.dueDate = dt(payload.dueDate, "dueDate");
    if (payload.priority !== undefined) task.priority = normalizePriority(payload.priority);
    if (payload.status !== undefined) task.status = normalizeStatus(payload.status);
    if (payload.progress !== undefined || payload.progressPercentage !== undefined) task.progressPercentage = Math.max(0, Math.min(100, num(payload.progress ?? payload.progressPercentage)));
    if (payload.estimatedHours !== undefined) task.estimatedHours = Math.max(0, num(payload.estimatedHours));
    if (payload.actualHours !== undefined) task.actualHours = Math.max(0, num(payload.actualHours));
    if (payload.hourlyRate !== undefined) task.hourlyRate = Math.max(0, num(payload.hourlyRate));
    if (payload.materialCost !== undefined) task.materialCost = Math.max(0, num(payload.materialCost));
    if (payload.otherExpenses !== undefined) task.otherExpenses = Math.max(0, num(payload.otherExpenses));
    if (payload.totalWorkedSeconds !== undefined) task.totalWorkedSeconds = Math.max(0, num(payload.totalWorkedSeconds));
    if (payload.timerStartedAt !== undefined) task.timerStartedAt = dt(payload.timerStartedAt, "timerStartedAt");
    if (payload.isTimerRunning !== undefined) task.isTimerRunning = Boolean(payload.isTimerRunning);
    if (payload.assignedStaff !== undefined || payload.Assignstaff !== undefined || payload.assignStaff !== undefined) {
        const assigned = await assignedStaff(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff, task.hourlyRate, task.estimatedHours); task.ownerIds = assigned.ownerIds; task.ownerNames = assigned.ownerNames; task.assignedStaff = assigned.staff;
    }
    const workLogs = normalizeArray(payload.workLogs, (log) => ({ startedAt: dt(log?.startedAt, "workLog.startedAt"), stoppedAt: dt(log?.stoppedAt, "workLog.stoppedAt"), duration: Math.max(0, num(log?.duration)) }));
    if (workLogs) task.workLogs = workLogs;
    const materials = normalizeArray(payload.materials, (item) => ({ name: text(item?.name), unitCost: Math.max(0, num(item?.unitCost)), quantity: Math.max(0, num(item?.quantity)) }));
    if (materials) task.materials = materials;
    const expenses = normalizeArray(payload.otherExpensesBreakdown, (item) => ({ name: text(item?.name), amount: Math.max(0, num(item?.amount)), description: text(item?.description) }));
    if (expenses) task.otherExpensesBreakdown = expenses;
    const commentsRaw = normalizeArray(payload.comments, (item) => ({ type: ["update", "question", "image"].includes(item?.type) ? item.type : "update", text: text(item?.text), image: item?.image ? text(item.image) : null, authorId: item?.authorId && mongoose.isValidObjectId(item.authorId) ? new mongoose.Types.ObjectId(item.authorId) : actorId(actor), authorName: text(item?.authorName) || text(actor?.displayName), createdAt: dt(item?.createdAt, "comment.createdAt") || new Date() }));
    if (commentsRaw) task.comments = commentsRaw.filter((item) => item.text);
    const attachments = normalizeArray(payload.attachments, (item) => {
        const name = text(item?.name);
        const url = text(item?.url);
        if (!name || !url) return null;
        return { name, url, mimeType: text(item?.mimeType) || "application/octet-stream", size: Math.max(0, num(item?.size)), createdAt: dt(item?.createdAt, "attachment.createdAt") || new Date() };
    });
    if (attachments) task.attachments = attachments;
    const materialsTotal = task.materials.reduce((s, item) => s + num(item.unitCost) * num(item.quantity), 0);
    if (payload.materials !== undefined) task.materialCost = materialsTotal;
    const expenseTotal = task.otherExpensesBreakdown.reduce((s, item) => s + num(item.amount), 0);
    if (payload.otherExpensesBreakdown !== undefined) task.otherExpenses = expenseTotal;
    if (payload.totalWorkedSeconds !== undefined || payload.workLogs !== undefined) {
        task.actualHours = Math.max(0, num(task.totalWorkedSeconds) / 3600);
    }
    task.updatedBy = actorId(actor); await task.save(); await recalculateProjectProgress(project._id);
    const after = { title: task.title, status: task.status, progress: task.progressPercentage, assignedStaff: task.assignedStaff, estimatedHours: task.estimatedHours, actualHours: task.actualHours, materialCost: task.materialCost, otherExpenses: task.otherExpenses };
    await audit("updated", task, actor, request, { projectId: String(project._id) }, { before, after }); return serialize(task);
}

export async function deleteTask(id, { actor, request = null } = {}) {
    if (!internal(actor)) throw new TaskServiceError("Only internal users can delete project tasks.", { code: "TASK_DELETE_FORBIDDEN", statusCode: 403 });
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await getProject(task.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to delete this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    await Task.deleteOne({ _id: task._id }); await recalculateProjectProgress(project._id); await audit("deleted", task, actor, request, { projectId: String(project._id) }); return { id: String(task._id) };
}

export async function recalculateProjectProgress(projectId) {
    const project = await Project.findById(projectId); if (!project) return null;
    const tasks = await Task.find({ projectId }).select("progressPercentage");
    const progress = tasks.length ? tasks.reduce((s, t) => s + num(t.progressPercentage), 0) / tasks.length : 0;
    project.progressPercentage = Math.max(0, Math.min(100, Math.round(progress * 100) / 100));
    if (tasks.length && tasks.every((t) => t.status === "completed")) project.status = "completed";
    await project.save(); return project;
}

export async function updateProgress(id, payload, options = {}) { return updateTask(id, payload, options); }
