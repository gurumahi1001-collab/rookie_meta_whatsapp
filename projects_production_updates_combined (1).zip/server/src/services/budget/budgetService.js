import mongoose from "mongoose";
import Budget from "../../models/Budget.js";
import Project from "../../models/Project.js";

const INTERNAL_TYPES = ["admin", "internal"];
function oid(v, field = "id") { if (!mongoose.isValidObjectId(v)) { const error = new Error(`Invalid ${field}.`); error.code = `INVALID_${field.toUpperCase()}`; error.statusCode = 422; throw error; } return new mongoose.Types.ObjectId(v); }
function num(v, d = 0) { const n = Number(v); return Number.isFinite(n) ? n : d; }
function internal(a) { return INTERNAL_TYPES.includes(String(a?.userType || "").toLowerCase()); }
function vendor(a) { return String(a?.userType || "").toLowerCase() === "vendor"; }
function canView(project, actor) { if (!project) return false; if (vendor(actor)) return actor.vendorId && project.vendorId && String(actor.vendorId) === String(project.vendorId); return internal(actor); }
function serialize(x) { return x?.toSafeJSON ? x.toSafeJSON() : x; }

export async function getBudget(projectId, { actor } = {}) {
    const project = await Project.findById(oid(projectId, "projectId"));
    if (!project) { const e = new Error("Project was not found."); e.code = "PROJECT_NOT_FOUND"; e.statusCode = 404; throw e; }
    if (!canView(project, actor)) { const e = new Error("You are not authorized to view this budget."); e.code = "BUDGET_ACCESS_FORBIDDEN"; e.statusCode = 403; throw e; }
    const budget = await Budget.findOne({ projectId: project._id });
    if (budget) return serialize(budget);
    return { id: null, projectId: String(project._id), totalAllocation: num(project.budget), utilized: 0, remaining: num(project.budget), thresholdWarning: 80, thresholdCritical: 100, utilizationPercentage: 0, lines: [] };
}

export async function ensureBudget(projectId, { actor } = {}) {
    if (!internal(actor)) { const e = new Error("Only internal users can manage project budgets."); e.code = "BUDGET_FORBIDDEN"; e.statusCode = 403; throw e; }
    const project = await Project.findById(oid(projectId, "projectId")); if (!project) { const e = new Error("Project was not found."); e.code = "PROJECT_NOT_FOUND"; e.statusCode = 404; throw e; }
    let budget = await Budget.findOne({ projectId: project._id });
    if (!budget) budget = new Budget({ projectId: project._id, totalAllocation: num(project.budget), utilized: 0, remaining: num(project.budget), thresholdWarning: 80, thresholdCritical: 100, lines: [] });
    budget.totalAllocation = num(project.budget); budget.remaining = Math.max(0, budget.totalAllocation - num(budget.utilized)); budget.updatedBy = actor?.userId && mongoose.isValidObjectId(actor.userId) ? new mongoose.Types.ObjectId(actor.userId) : null; await budget.save(); return serialize(budget);
}
