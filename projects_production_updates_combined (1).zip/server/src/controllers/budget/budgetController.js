import * as service from "../../services/budget/budgetService.js";
export async function list(req, res, next) { try { const projectId = req.query.projectId || req.params.projectId; return res.json({ success: true, data: await service.getBudget(projectId, { actor: req.user }) }); } catch (e) { next(e); } }
export async function get(req, res, next) { try { return res.json({ success: true, data: await service.getBudget(req.params.projectId, { actor: req.user }) }); } catch (e) { next(e); } }
export async function create(req, res, next) { try { return res.status(201).json({ success: true, data: await service.ensureBudget(req.params.projectId || req.body?.projectId, { actor: req.user }) }); } catch (e) { next(e); } }
export async function update(req, res, next) { try { return res.json({ success: true, data: await service.ensureBudget(req.params.projectId, { actor: req.user }) }); } catch (e) { next(e); } }
export async function remove(req, res, next) { next(Object.assign(new Error("Project budgets cannot be deleted independently."), { statusCode: 409, code: "BUDGET_IMMUTABLE" })); }
