import { updateProject } from "../../services/project/projectService.js";

export async function update(req, res, next) {
    try {
        const data = await updateProject(req.params.projectId, { progress: req.body?.progress ?? req.body?.progressPercentage }, { actor: req.user, request: req });
        return res.json({ success: true, data });
    } catch (error) { next(error); }
}
export async function list(req, res, next) { try { return res.json({ success: true, data: [] }); } catch (e) { next(e); } }
export async function get(req, res, next) { return update(req, res, next); }
export async function create(req, res, next) { return update(req, res, next); }
export async function remove(req, res, next) { next(Object.assign(new Error("Project progress records cannot be deleted."), { statusCode: 409, code: "PROJECT_PROGRESS_IMMUTABLE" })); }
