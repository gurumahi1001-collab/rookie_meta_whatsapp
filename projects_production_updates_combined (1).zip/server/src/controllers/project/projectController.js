import * as service from "../../services/project/projectService.js";

function send(res, data, status = 200) { return res.status(status).json({ success: true, data }); }

export async function list(req, res, next) { try { return send(res, await service.listProjects({ actor: req.user, page: req.query.page, limit: req.query.limit, search: req.query.search, status: req.query.status })); } catch (e) { next(e); } }
export async function get(req, res, next) { try { return send(res, await service.getProject(req.params.projectId, { actor: req.user })); } catch (e) { next(e); } }
export async function create(req, res, next) { try { const result = await service.createProjectFromQuotation(req.body?.quotationId || req.body?.sourceQuotationId, { actor: req.user, request: req }); return send(res, result, 201); } catch (e) { next(e); } }
export async function createFromQuotation(req, res, next) { try { const result = await service.createProjectFromQuotation(req.params.quotationId, { actor: req.user, request: req }); return send(res, result, 201); } catch (e) { next(e); } }
export async function update(req, res, next) { try { return send(res, await service.updateProject(req.params.projectId, req.body || {}, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function remove(req, res, next) { try { return send(res, await service.removeProject(req.params.projectId, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function updateStatus(req, res, next) { try { return send(res, await service.updateProject(req.params.projectId, { status: req.body?.status }, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function addPhase(req, res, next) { try { return send(res, await service.addPhase(req.params.projectId, req.body || {}, { actor: req.user, request: req }), 201); } catch (e) { next(e); } }
export async function addScope(req, res, next) { try { return send(res, await service.addScopeItem(req.params.projectId, req.body || {}, { actor: req.user, request: req }), 201); } catch (e) { next(e); } }
export async function updateScope(req, res, next) { try { return send(res, await service.updateScopeItem(req.params.projectId, req.params.scopeId, req.body || {}, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function deleteScope(req, res, next) { try { return send(res, await service.deleteScopeItem(req.params.projectId, req.params.scopeId, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function addDeliverable(req, res, next) { try { return send(res, await service.addDeliverable(req.params.projectId, req.body || {}, { actor: req.user, request: req }), 201); } catch (e) { next(e); } }
export async function updateDeliverable(req, res, next) { try { return send(res, await service.updateDeliverable(req.params.projectId, req.params.deliverableId, req.body || {}, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function deleteDeliverable(req, res, next) { try { return send(res, await service.deleteDeliverable(req.params.projectId, req.params.deliverableId, { actor: req.user, request: req })); } catch (e) { next(e); } }
