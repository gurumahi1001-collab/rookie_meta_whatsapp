import * as service from "../../services/task/taskService.js";
function send(res, data, status = 200) { return res.status(status).json({ success: true, data }); }
export async function list(req, res, next) { try { return send(res, await service.listTasks({ actor: req.user, projectId: req.query.projectId, page: req.query.page, limit: req.query.limit })); } catch (e) { next(e); } }
export async function get(req, res, next) { try { return send(res, await service.getTask(req.params.taskId, { actor: req.user })); } catch (e) { next(e); } }
export async function create(req, res, next) { try { return send(res, await service.createTask(req.body || {}, { actor: req.user, request: req }), 201); } catch (e) { next(e); } }
export async function update(req, res, next) { try { return send(res, await service.updateTask(req.params.taskId, req.body || {}, { actor: req.user, request: req })); } catch (e) { next(e); } }
export async function remove(req, res, next) { try { return send(res, await service.deleteTask(req.params.taskId, { actor: req.user, request: req })); } catch (e) { next(e); } }
