import mongoose from "mongoose";
import BOQ from "../../models/BOQ.js";
import Quotation from "../../models/Quotation.js";
import Vendor from "../../models/Vendor.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";
import auditService from "../audit/auditService.js";

export class BOQServiceError extends Error {
    constructor(message, { code = "BOQ_ERROR", statusCode = 400, details } = {}) { super(message); this.name="BOQServiceError"; this.code=code; this.statusCode=statusCode; this.details=details; }
}
function text(v){return typeof v==="string"?v.trim():"";} function num(v,d=0){const n=Number(v);return Number.isFinite(n)?n:d;}
function oid(v,name="id"){if(!v)return null;if(!mongoose.isValidObjectId(v))throw new BOQServiceError(`Invalid ${name}.`,{code:`INVALID_${String(name).toUpperCase()}`,statusCode:422});return new mongoose.Types.ObjectId(v);}
function dt(v){if(v==null||text(v)==="")return null;const d=new Date(v);if(Number.isNaN(d.getTime()))throw new BOQServiceError("Invalid date value.",{code:"INVALID_DATE",statusCode:422});return d;}
function internal(actor){return ["admin","internal"].includes(String(actor?.userType||"").toLowerCase());}
function actorId(a){return a?.userId&&mongoose.isValidObjectId(a.userId)?new mongoose.Types.ObjectId(a.userId):null;}
function serialize(x){return x?.toSafeJSON?x.toSafeJSON():x;}
async function nextNumber(key,prefix){const row=await MasterRateSequence.findOneAndUpdate({_id:key},{$inc:{value:1}},{new:true,upsert:true,setDefaultsOnInsert:true}).lean();const n=num(row?.value);if(!Number.isInteger(n)||n<1)throw new BOQServiceError("Unable to generate BOQ reference.",{code:"BOQ_REFERENCE_GENERATION_FAILED",statusCode:500});return `${prefix}-${new Date().getFullYear()}-${String(n).padStart(3,"0")}`;}
function normalizeLine(input){const qty=num(input?.quantity);const rate=num(input?.rate??input?.standardRate);if(qty<=0)throw new BOQServiceError("Quantity must be greater than zero.",{code:"INVALID_QUANTITY",statusCode:422});if(rate<0)throw new BOQServiceError("Rate cannot be negative.",{code:"INVALID_RATE",statusCode:422});return {marketRateItemId:oid(input?.marketRateItemId??input?.masterRateItemId,"marketRateItemId"),module:text(input?.module),categoryType:text(input?.categoryType),category:text(input?.category),description:text(input?.description),unit:text(input?.unit)||"Unit",quantity:qty,rate,lineTotal:qty*rate,isCustom:Boolean(input?.isCustom)};}
function totals(lines){const subtotal=(lines||[]).reduce((s,x)=>s+num(x.lineTotal,num(x.quantity)*num(x.rate)),0);return {subtotal,contingency:subtotal*0.1,grandTotal:subtotal*1.1};}
async function audit(action,doc,actor,request,metadata={}){try{await auditService.recordAudit({action,module:"boq",title:`BOQ ${action.replace(/_/g," ")}`,description:doc?.boqNo||doc?.projectName||"",actor:actor?.actor||actor,request,entityType:"boq",entityId:String(doc?._id||""),entityName:doc?.boqNo||doc?.projectName||"",metadata});}catch(e){console.error("[boqService] audit write failed",e);}}

export async function listBOQs({page=1,limit=50,search="",status=""}={}){const p=Math.max(1,parseInt(String(page),10)||1),l=Math.min(200,Math.max(1,parseInt(String(limit),10)||50));const f={};if(status)f.status=text(status);if(text(search)){const r=new RegExp(text(search).replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"i");f.$or=[{boqNo:r},{projectName:r}];}const [rows,total]=await Promise.all([BOQ.find(f).sort({updatedAt:-1,_id:-1}).skip((p-1)*l).limit(l),BOQ.countDocuments(f)]);return{data:rows.map(serialize),pagination:{page:p,limit:l,total,totalPages:Math.ceil(total/l)}};}
export async function getBOQ(id){const row=await BOQ.findById(oid(id,"boqId"));if(!row)throw new BOQServiceError("BOQ was not found.",{code:"BOQ_NOT_FOUND",statusCode:404});const quotations=await Quotation.find({boqId:row._id}).sort({grandTotal:1,vendorName:1});return{...serialize(row),quotations:quotations.map(serialize)};}

export async function saveBOQ(payload,{actor,request=null,submit=false}={}){
    if(!internal(actor))throw new BOQServiceError("Only internal users can manage project BOQs.",{code:"BOQ_FORBIDDEN",statusCode:403});
    const vendorsRaw=Array.isArray(payload?.vendorIds)?payload.vendorIds:Array.isArray(payload?.vendors)?payload.vendors.map(v=>typeof v==="object"?v.value:v):[];
    const vendorIds=vendorsRaw.filter(Boolean).map(v=>oid(v,"vendorId"));
    const uniqueIds=[...new Map(vendorIds.map(v=>[String(v),v])).values()];
    let vendorDocs=[];
    if(uniqueIds.length){vendorDocs=await Vendor.find({_id:{$in:uniqueIds},status:"APPROVED"}).lean();if(vendorDocs.length!==uniqueIds.length)throw new BOQServiceError("Only approved vendors can be assigned to a BOQ.",{code:"VENDOR_ASSIGNMENT_INVALID",statusCode:422});}
    const templateId=oid(payload?.formTemplateId,"formTemplateId");
    let template=null;if(templateId){template=await SurveyTemplate.findOne({_id:templateId,status:{ $ne:"archived" }}).lean();if(!template)throw new BOQServiceError("Survey form template was not found.",{code:"SURVEY_TEMPLATE_NOT_FOUND",statusCode:404});}
    const lines=Array.isArray(payload?.lines)?payload.lines.map(normalizeLine):[];
    const manual=Array.isArray(payload?.manualAdditions)?payload.manualAdditions.map(normalizeLine):[];
    const schedule=Array.isArray(payload?.paymentSchedule)?payload.paymentSchedule.map(x=>({name:text(x?.name)||"Installment",amount:Math.max(0,num(x?.amount)),type:x?.type||"custom",dueDate:dt(x?.dueDate)})):[];
    const t=totals([...lines,...manual]);
    let row=null;const id=payload?.id?oid(payload.id,"boqId"):null;
    if(id)row=await BOQ.findById(id);
    if(id&&!row)throw new BOQServiceError("BOQ was not found.",{code:"BOQ_NOT_FOUND",statusCode:404});
    const status=submit?"Generated Quotation":(text(payload?.status)||row?.status||"Draft");
    if(row){
        if(["Awarded","Converted to Project"].includes(row.status))throw new BOQServiceError("Awarded or converted BOQs cannot be edited.",{code:"BOQ_NOT_EDITABLE",statusCode:409});
        row.projectName=text(payload?.projectName);row.projectSiteLocation=text(payload?.projectSiteLocation??payload?.projectLocation);row.siteSurveyReference=text(payload?.siteSurveyReference);row.projectValue=Math.max(0,num(payload?.projectValue));row.currency=text(payload?.currency)||row.currency;row.validityDays=Math.max(0,num(payload?.validityDays,row.validityDays||30));row.responseDueDate=dt(payload?.responseDueDate??payload?.dueDate);row.formTemplateId=template?template._id:null;row.formTemplateName=template?.name||text(payload?.formTemplateName);row.lines=lines;row.manualAdditions=manual;row.paymentSchedule=schedule;row.assignedVendors=vendorDocs.map(v=>({vendorId:v._id,vendorName:v.companyName||v.name||v.vendorName||"Vendor",vendorEmail:v.email||v.primaryEmail||""}));row.subtotal=t.subtotal;row.contingency=t.contingency;row.grandTotal=t.grandTotal;row.status=status;row.updatedBy=actorId(actor);row.revision=num(row.revision,1)+1;
    } else {
        row=new BOQ({boqNo:text(payload?.boqNo)||await nextNumber("boq","BOQ"),projectName:text(payload?.projectName),projectSiteLocation:text(payload?.projectSiteLocation??payload?.projectLocation),siteSurveyReference:text(payload?.siteSurveyReference),projectValue:Math.max(0,num(payload?.projectValue)),currency:text(payload?.currency)||"USD",validityDays:Math.max(0,num(payload?.validityDays,30)),responseDueDate:dt(payload?.responseDueDate??payload?.dueDate),formTemplateId:template?template._id:null,formTemplateName:template?.name||text(payload?.formTemplateName),lines,manualAdditions:manual,paymentSchedule:schedule,assignedVendors:vendorDocs.map(v=>({vendorId:v._id,vendorName:v.companyName||v.name||v.vendorName||"Vendor",vendorEmail:v.email||v.primaryEmail||""})),subtotal:t.subtotal,contingency:t.contingency,grandTotal:t.grandTotal,status,createdBy:actorId(actor),updatedBy:actorId(actor)});
    }
    if(!row.projectName)throw new BOQServiceError("Project name is required.",{code:"PROJECT_NAME_REQUIRED",statusCode:422});
    if(submit&&row.lines.length===0)throw new BOQServiceError("Add at least one BOQ line before generating quotation forms.",{code:"BOQ_LINES_REQUIRED",statusCode:422});
    if(submit&&row.assignedVendors.length===0)throw new BOQServiceError("Assign at least one approved vendor before generating quotation forms.",{code:"VENDORS_REQUIRED",statusCode:422});
    await row.save();
    if(submit){
        for(const vendor of row.assignedVendors){
            const existing=await Quotation.findOne({boqId:row._id,vendorId:vendor.vendorId});
            if(existing){
                if(["Draft","Form Issued","Form Rejected"].includes(existing.status)){
                    existing.projectTitle=row.projectName;existing.projectSiteLocation=row.projectSiteLocation;existing.siteSurveyReference=row.siteSurveyReference;existing.dueDate=row.responseDueDate;existing.validityDays=row.validityDays;existing.formTemplateId=row.formTemplateId;existing.formTemplateName=row.formTemplateName;existing.lines=row.lines.map(l=>({boqLineId:l._id,masterRateItemId:l.marketRateItemId,module:l.module,categoryType:l.categoryType,category:l.category,description:l.description,unit:l.unit,quantity:l.quantity,masterRate:l.rate,vendorRate:0,lineTotal:0,isCustom:l.isCustom}));existing.paymentSchedule=row.paymentSchedule;existing.status="Form Issued";existing.updatedBy=actorId(actor);existing.workflowHistory.push({action:"form_reissued",status:"Form Issued",actorUserId:actorId(actor),actorType:actor?.userType||"internal"});await existing.save();
                }
            } else {
                const no=await nextNumber("quotation","QT");
                const quotation=new Quotation({quotationNo:no,boqId:row._id,vendorId:vendor.vendorId,vendorName:vendor.vendorName,vendorEmail:vendor.vendorEmail,projectTitle:row.projectName,projectSiteLocation:row.projectSiteLocation,siteSurveyReference:row.siteSurveyReference,formTemplateId:row.formTemplateId,formTemplateName:row.formTemplateName,currency:row.currency,dueDate:row.responseDueDate,validityDays:row.validityDays,status:"Form Issued",lines:row.lines.map(l=>({boqLineId:l._id,masterRateItemId:l.marketRateItemId,module:l.module,categoryType:l.categoryType,category:l.category,description:l.description,unit:l.unit,quantity:l.quantity,masterRate:l.rate,vendorRate:0,lineTotal:0,isCustom:l.isCustom})),manualAdditions:row.manualAdditions,paymentSchedule:row.paymentSchedule,subtotal:0,grandTotal:0,createdBy:actorId(actor),updatedBy:actorId(actor),workflowHistory:[{action:"form_issued",status:"Form Issued",actorUserId:actorId(actor),actorType:actor?.userType||"internal"}]});await quotation.save();
            }
        }
        await audit("quotation_forms_generated",row,actor,request,{vendorCount:row.assignedVendors.length});
    }
    return getBOQ(row._id);
}

export async function removeBOQ(id,{actor,request=null}={}){if(!internal(actor))throw new BOQServiceError("Only internal users can delete BOQs.",{code:"BOQ_DELETE_FORBIDDEN",statusCode:403});const row=await BOQ.findById(oid(id,"boqId"));if(!row)throw new BOQServiceError("BOQ was not found.",{code:"BOQ_NOT_FOUND",statusCode:404});if(["Awarded","Converted to Project"].includes(row.status))throw new BOQServiceError("Awarded or converted BOQs cannot be deleted.",{code:"BOQ_DELETE_FORBIDDEN",statusCode:409});await Quotation.deleteMany({boqId:row._id,status:{ $in:["Draft","Form Issued","Form Rejected"] }});await BOQ.deleteOne({_id:row._id});await audit("deleted",row,actor,request);return{ id:String(row._id),boqNo:row.boqNo };}

export async function awardBOQ(id,{vendorId,remarks},{actor,request=null}={}){
    if(!internal(actor))throw new BOQServiceError("Only internal users can award a BOQ.",{code:"BOQ_AWARD_FORBIDDEN",statusCode:403});
    const row=await BOQ.findById(oid(id,"boqId"));if(!row)throw new BOQServiceError("BOQ was not found.",{code:"BOQ_NOT_FOUND",statusCode:404});
    if(!["Pending Approval","Generated Quotation"].includes(row.status))throw new BOQServiceError("This BOQ is not ready for award.",{code:"BOQ_AWARD_INVALID_STATE",statusCode:409});
    const selected=oid(vendorId,"vendorId");if(!selected)throw new BOQServiceError("Vendor selection is required.",{code:"VENDOR_ID_REQUIRED",statusCode:422});if(!text(remarks))throw new BOQServiceError("Award remarks are required.",{code:"AWARD_REMARKS_REQUIRED",statusCode:422});
    const quotation=await Quotation.findOne({boqId:row._id,vendorId:selected});if(!quotation)throw new BOQServiceError("Selected vendor quotation was not found.",{code:"QUOTATION_NOT_FOUND",statusCode:404});
    if(!["Submitted","Form Approved","Awarded"].includes(quotation.status))throw new BOQServiceError("Selected vendor must have an approved/submitted quotation before award.",{code:"VENDOR_QUOTATION_NOT_READY",statusCode:409});
    const now=new Date();
    row.status="Awarded";row.awardedVendorId=selected;row.awardedVendorName=quotation.vendorName;row.awardRemarks=text(remarks);row.awardedQuotationId=quotation._id;row.awardedAt=now;row.awardedBy=actorId(actor);row.updatedBy=actorId(actor);row.revision=num(row.revision,1)+1;await row.save();
    await Quotation.updateMany({boqId:row._id,_id:{ $ne:quotation._id }},{$set:{status:"Not Awarded",updatedBy:actorId(actor)}});
    quotation.status="Awarded";quotation.award={vendorId:selected,vendorName:quotation.vendorName,remarks:text(remarks),awardedAt:now,awardedBy:actorId(actor)};quotation.updatedBy=actorId(actor);quotation.workflowHistory.push({action:"awarded",status:"Awarded",actorUserId:actorId(actor),actorType:actor?.userType||"internal",remarks:text(remarks)});await quotation.save();
    await audit("awarded",row,actor,request,{vendorId:String(selected),quotationId:String(quotation._id),remarks:text(remarks)});
    return getBOQ(row._id);
}
