import mongoose from "mongoose";
import Quotation, { QUOTATION_STATUSES } from "../../models/Quotation.js";
import BOQ from "../../models/BOQ.js";
import Vendor from "../../models/Vendor.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";
import SurveyResponse from "../../models/SurveyResponse.js";
import MasterRateItem from "../../models/MarketRateItem.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";
import auditService from "../audit/auditService.js";

export class QuotationServiceError extends Error {
    constructor(message, { code = "QUOTATION_ERROR", statusCode = 400, details } = {}) {
        super(message);
        this.name = "QuotationServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
    }
}

function text(value) { return typeof value === "string" ? value.trim() : ""; }
function oid(value, name = "id") {
    if (!value) return null;
    if (!mongoose.isValidObjectId(value)) {
        throw new QuotationServiceError(`Invalid ${name}.`, { code: `INVALID_${String(name).toUpperCase()}`, statusCode: 422 });
    }
    return new mongoose.Types.ObjectId(value);
}
function number(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}
function date(value) {
    if (value == null || text(value) === "") return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) throw new QuotationServiceError("Invalid date value.", { code: "INVALID_DATE", statusCode: 422 });
    return d;
}
function actorId(actor) { return actor?.userId && mongoose.isValidObjectId(actor.userId) ? new mongoose.Types.ObjectId(actor.userId) : null; }
function actorVendorId(actor) { return actor?.vendorId && mongoose.isValidObjectId(actor.vendorId) ? new mongoose.Types.ObjectId(actor.vendorId) : null; }
function isVendor(actor) { return String(actor?.userType || "").toLowerCase() === "vendor"; }
function isInternal(actor) { return ["admin", "internal"].includes(String(actor?.userType || "").toLowerCase()); }

async function nextNumber(key, prefix) {
    const row = await MasterRateSequence.findOneAndUpdate(
        { _id: key },
        { $inc: { value: 1 } },
        { new: true, upsert: true, setDefaultsOnInsert: true },
    ).lean();
    const value = number(row?.value, 0);
    if (!Number.isInteger(value) || value < 1) throw new QuotationServiceError("Unable to generate a business reference.", { code: "REFERENCE_GENERATION_FAILED", statusCode: 500 });
    return `${prefix}-${new Date().getFullYear()}-${String(value).padStart(3, "0")}`;
}

function serialize(doc) { return doc?.toSafeJSON ? doc.toSafeJSON() : doc?.toJSON ? doc.toJSON() : doc; }

function normalizeLine(input, { allowVendorRate = false } = {}) {
    const quantity = number(input?.quantity, 0);
    if (quantity <= 0) throw new QuotationServiceError("Quantity must be greater than zero.", { code: "INVALID_QUANTITY", statusCode: 422 });
    const masterRate = number(input?.masterRate ?? input?.rate, 0);
    const vendorRate = allowVendorRate ? number(input?.vendorRate ?? input?.salesPrice ?? input?.rate, 0) : 0;
    if (masterRate < 0 || vendorRate < 0) throw new QuotationServiceError("Rates cannot be negative.", { code: "INVALID_RATE", statusCode: 422 });
    return {
        boqLineId: oid(input?.boqLineId, "boqLineId"),
        masterRateItemId: oid(input?.masterRateItemId ?? input?.marketRateItemId, "masterRateItemId"),
        module: text(input?.module),
        categoryType: text(input?.categoryType),
        category: text(input?.category),
        description: text(input?.description),
        unit: text(input?.unit) || "Unit",
        quantity,
        masterRate,
        vendorRate,
        lineTotal: quantity * (allowVendorRate ? vendorRate : masterRate),
        isCustom: Boolean(input?.isCustom),
    };
}

function recompute(quotation) {
    const subtotal = (quotation.lines || []).reduce((sum, line) => sum + number(line.vendorRate || 0) * number(line.quantity || 0), 0);
    quotation.subtotal = subtotal;
    quotation.grandTotal = subtotal + number(quotation.taxTotal) + number(quotation.otherCharges);
    return quotation;
}

async function ensureVendor(vendorId) {
    const vendor = await Vendor.findOne({ _id: vendorId, status: "APPROVED" }).lean();
    if (!vendor) throw new QuotationServiceError("Only approved vendors can receive quotations.", { code: "VENDOR_NOT_APPROVED", statusCode: 422 });
    return vendor;
}

function assertVendorScope(quotation, actor) {
    if (isVendor(actor)) {
        const vendorId = actorVendorId(actor);
        if (!vendorId || String(quotation.vendorId) !== String(vendorId)) {
            throw new QuotationServiceError("You can only access quotations assigned to your vendor account.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
        }
    }
}

async function audit(action, quotation, actor, request, metadata = {}, changes = null) {
    try {
        await auditService.recordAudit({
            action,
            module: "quotation",
            title: `Quotation ${action.replace(/_/g, " ")}`,
            description: quotation?.quotationNo || "",
            actor: actor?.actor || actor || null,
            request,
            entityType: "quotation",
            entityId: String(quotation?._id || quotation?.id || ""),
            entityName: quotation?.quotationNo || quotation?.projectTitle || "",
            vendorId: quotation?.vendorId || null,
            metadata,
            changes,
        });
    } catch (error) {
        console.error("[quotationService] audit write failed", error);
    }
}

export async function listQuotations({ actor, page = 1, limit = 50, search = "", status = "", vendorId = "" } = {}) {
    const safePage = Math.max(1, Number.parseInt(String(page), 10) || 1);
    const safeLimit = Math.min(200, Math.max(1, Number.parseInt(String(limit), 10) || 50));
    const filter = {};
    if (isVendor(actor)) filter.vendorId = actorVendorId(actor);
    else if (vendorId) filter.vendorId = oid(vendorId, "vendorId");
    if (status && QUOTATION_STATUSES.includes(status)) filter.status = status;
    const term = text(search);
    if (term) {
        const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
        filter.$or = [{ quotationNo: regex }, { vendorName: regex }, { projectTitle: regex }, { clientName: regex }];
    }
    const [rows, total] = await Promise.all([
        Quotation.find(filter).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit),
        Quotation.countDocuments(filter),
    ]);
    return { data: rows.map(serialize), pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) } };
}

export async function getQuotation(id, { actor } = {}) {
    const row = await Quotation.findById(oid(id, "quotationId"));
    if (!row) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(row, actor);
    return serialize(row);
}

export async function createQuotation(payload, { actor, request = null } = {}) {
    if (!isInternal(actor) && !isVendor(actor)) throw new QuotationServiceError("Authenticated account cannot create quotations.", { code: "QUOTATION_CREATE_FORBIDDEN", statusCode: 403 });
    const vendorId = oid(payload?.vendorId ?? actor?.vendorId, "vendorId");
    if (!vendorId) throw new QuotationServiceError("Vendor is required.", { code: "VENDOR_ID_REQUIRED", statusCode: 422 });
    if (isVendor(actor) && String(vendorId) !== String(actorVendorId(actor))) throw new QuotationServiceError("Vendor scope is invalid.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
    const vendor = await ensureVendor(vendorId);
    const quotationNo = text(payload?.quotationNo) || await nextNumber("quotation", "QT");
    const lines = Array.isArray(payload?.lines) ? payload.lines.map((line) => normalizeLine(line, { allowVendorRate: Boolean(payload?.vendorEntry) })) : [];
    const q = new Quotation({
        quotationNo,
        boqId: oid(payload?.boqId, "boqId"),
        vendorId,
        vendorName: vendor.companyName || vendor.name || vendor.vendorName || "Vendor",
        vendorEmail: vendor.email || vendor.primaryEmail || "",
        projectTitle: text(payload?.projectTitle),
        projectSiteLocation: text(payload?.projectSiteLocation ?? payload?.projectLocation),
        clientName: text(payload?.clientName),
        siteSurveyReference: text(payload?.siteSurveyReference),
        category: text(payload?.category),
        formTemplateId: oid(payload?.formTemplateId, "formTemplateId"),
        formTemplateName: text(payload?.formTemplateName ?? payload?.formTemplate),
        currency: text(payload?.currency) || "USD",
        quotationDate: date(payload?.quotationDate) || new Date(),
        dueDate: date(payload?.dueDate ?? payload?.responseDueDate),
        validUntil: date(payload?.validUntil),
        validityDays: payload?.validityDays == null ? null : number(payload.validityDays),
        scopeSummary: text(payload?.scopeSummary),
        terms: text(payload?.terms),
        status: text(payload?.status) || "Draft",
        lines,
        manualAdditions: Array.isArray(payload?.manualAdditions) ? payload.manualAdditions.map((line) => normalizeLine(line, { allowVendorRate: Boolean(payload?.vendorEntry) })) : [],
        paymentSchedule: Array.isArray(payload?.paymentSchedule) ? payload.paymentSchedule.map((item) => ({ name: text(item?.name) || "Installment", amount: Math.max(0, number(item?.amount)), type: item?.type || "custom", dueDate: date(item?.dueDate) })) : [],
        taxTotal: Math.max(0, number(payload?.taxTotal)),
        otherCharges: Math.max(0, number(payload?.otherCharges)),
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    recompute(q);
    q.workflowHistory.push({ action: "created", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "system" });
    await q.save();
    await audit("created", q, actor, request);
    return serialize(q);
}

export async function updateQuotation(id, payload, { actor, request = null } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);

    const previousStatus = q.status;
    if (isVendor(actor) && !["Form Approved", "Form Rejected", "Draft"].includes(q.status)) {
        throw new QuotationServiceError("This quotation is not editable from the vendor portal.", { code: "QUOTATION_NOT_EDITABLE", statusCode: 409 });
    }

    if (payload?.projectTitle !== undefined) q.projectTitle = text(payload.projectTitle);
    if (payload?.projectSiteLocation !== undefined || payload?.projectLocation !== undefined) q.projectSiteLocation = text(payload.projectSiteLocation ?? payload.projectLocation);
    if (payload?.scopeSummary !== undefined) q.scopeSummary = text(payload.scopeSummary);
    if (payload?.terms !== undefined) q.terms = text(payload.terms);
    if (payload?.validityDays !== undefined) q.validityDays = number(payload.validityDays, q.validityDays || 0);
    if (payload?.validUntil !== undefined) q.validUntil = date(payload.validUntil);
    if (payload?.currency !== undefined) q.currency = text(payload.currency) || q.currency;
    if (payload?.taxTotal !== undefined) q.taxTotal = Math.max(0, number(payload.taxTotal));
    if (payload?.otherCharges !== undefined) q.otherCharges = Math.max(0, number(payload.otherCharges));
    if (Array.isArray(payload?.lines)) q.lines = payload.lines.map((line) => normalizeLine(line, { allowVendorRate: isVendor(actor) || payload?.vendorEntry === true }));
    if (Array.isArray(payload?.manualAdditions)) q.manualAdditions = payload.manualAdditions.map((line) => normalizeLine(line, { allowVendorRate: isVendor(actor) || payload?.vendorEntry === true }));
    if (Array.isArray(payload?.paymentSchedule)) q.paymentSchedule = payload.paymentSchedule.map((item) => ({ name: text(item?.name) || "Installment", amount: Math.max(0, number(item?.amount)), type: item?.type || "custom", dueDate: date(item?.dueDate) }));

    if (payload?.status) {
        const requested = String(payload.status).trim();
        if (!QUOTATION_STATUSES.includes(requested)) throw new QuotationServiceError("Invalid quotation status.", { code: "INVALID_QUOTATION_STATUS", statusCode: 422 });
        if (isVendor(actor)) {
            if (!["Draft", "Submitted"].includes(requested)) {
                throw new QuotationServiceError("Vendors can only save a quotation as Draft or submit it for approval.", { code: "VENDOR_STATUS_CHANGE_FORBIDDEN", statusCode: 403 });
            }
            if (requested === "Submitted") {
                if (!["Form Approved", "Draft", "Form Rejected"].includes(q.status)) throw new QuotationServiceError("Survey approval is required before quotation submission.", { code: "SURVEY_APPROVAL_REQUIRED", statusCode: 409 });
                if (!Array.isArray(q.lines) || q.lines.length === 0) throw new QuotationServiceError("Add at least one BOQ line before submitting the quotation.", { code: "QUOTATION_LINES_REQUIRED", statusCode: 422 });
            }
        }
        q.status = requested;
    }

    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    recompute(q);
    q.workflowHistory.push({ action: q.status === "Submitted" ? "submitted" : "updated", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "system", remarks: text(payload?.remarks) });
    await q.save();
    if (q.boqId && q.status === "Submitted") {
        await BOQ.findByIdAndUpdate(
            q.boqId,
            { $set: { status: "Pending Approval", updatedBy: actorId(actor) } },
        );
    }
    await audit(q.status === "Submitted" ? "submitted" : "updated", q, actor, request, {}, { beforeStatus: previousStatus, afterStatus: q.status });
    return serialize(q);
}

export async function deleteQuotation(id, { actor, request = null } = {}) {
    if (!isInternal(actor)) throw new QuotationServiceError("Only internal users can delete quotations.", { code: "QUOTATION_DELETE_FORBIDDEN", statusCode: 403 });
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    await Quotation.deleteOne({ _id: q._id });
    await audit("deleted", q, actor, request);
    return { id: String(q._id), quotationNo: q.quotationNo };
}

export async function submitSurvey(id, payload, { actor, request = null } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    if (isInternal(actor)) throw new QuotationServiceError("Internal users cannot submit the vendor survey.", { code: "SURVEY_SUBMIT_FORBIDDEN", statusCode: 403 });
    if (!["Form Issued", "Form Rejected"].includes(q.status)) throw new QuotationServiceError("This survey is not open for submission.", { code: "SURVEY_NOT_OPEN", statusCode: 409 });
    const templateId = q.formTemplateId || oid(payload?.templateId, "templateId");
    if (!templateId) throw new QuotationServiceError("Survey template is required.", { code: "SURVEY_TEMPLATE_REQUIRED", statusCode: 422 });
    const template = await SurveyTemplate.findOne({ _id: templateId, status: { $ne: "archived" } }).lean();
    if (!template) throw new QuotationServiceError("Survey template was not found.", { code: "SURVEY_TEMPLATE_NOT_FOUND", statusCode: 404 });
    const response = payload?.response && typeof payload.response === "object" && !Array.isArray(payload.response) ? payload.response : {};
    let surveyResponse = q.survey.responseId ? await SurveyResponse.findById(q.survey.responseId) : null;
    if (!surveyResponse) {
        surveyResponse = new SurveyResponse({ templateId, projectId: null, respondentId: actorId(actor), response, status: "submitted", revision: 1, surveyDate: date(payload?.surveyDate), submittedAt: new Date(), createdBy: actorId(actor), updatedBy: actorId(actor) });
    } else {
        surveyResponse.response = response;
        surveyResponse.status = "submitted";
        surveyResponse.submittedAt = new Date();
        surveyResponse.updatedBy = actorId(actor);
        surveyResponse.revision = number(surveyResponse.revision, 1) + 1;
    }
    await surveyResponse.save();
    q.formTemplateId = template._id;
    q.formTemplateName = template.name;
    q.survey = { ...(q.survey?.toObject?.() || q.survey || {}), templateId: template._id, responseId: surveyResponse._id, status: "submitted", response, revision: surveyResponse.revision, submittedAt: surveyResponse.submittedAt, rejectedAt: null, rejectedBy: null, rejectionReason: "" };
    q.status = "Form Submitted";
    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    q.workflowHistory.push({ action: "survey_submitted", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "vendor" });
    await q.save();
    await audit("survey_submitted", q, actor, request, { surveyResponseId: String(surveyResponse._id) });
    return serialize(q);
}

export async function reviewSurvey(id, { decision, remarks = "" }, { actor, request = null } = {}) {
    if (!isInternal(actor)) throw new QuotationServiceError("Only internal users can review vendor surveys.", { code: "SURVEY_REVIEW_FORBIDDEN", statusCode: 403 });
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    if (q.status !== "Form Submitted") throw new QuotationServiceError("Only submitted surveys can be approved or rejected.", { code: "SURVEY_REVIEW_INVALID_STATE", statusCode: 409 });
    const normalized = String(decision || "").trim().toLowerCase();
    if (!['approve', 'reject'].includes(normalized)) throw new QuotationServiceError("Survey decision must be approve or reject.", { code: "INVALID_SURVEY_DECISION", statusCode: 422 });
    if (normalized === "reject" && !text(remarks)) throw new QuotationServiceError("Rejection remarks are required.", { code: "SURVEY_REJECTION_REMARKS_REQUIRED", statusCode: 422 });

    const now = new Date();
    q.status = normalized === "approve" ? "Form Approved" : "Form Rejected";
    q.survey.status = normalized === "approve" ? "approved" : "rejected";
    q.survey.approvedAt = normalized === "approve" ? now : null;
    q.survey.approvedBy = normalized === "approve" ? actorId(actor) : null;
    q.survey.rejectedAt = normalized === "reject" ? now : null;
    q.survey.rejectedBy = normalized === "reject" ? actorId(actor) : null;
    q.survey.rejectionReason = normalized === "reject" ? text(remarks) : "";
    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    q.workflowHistory.push({ action: normalized === "approve" ? "survey_approved" : "survey_rejected", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "internal", remarks: text(remarks) });
    await q.save();

    if (q.survey.responseId) {
        await SurveyResponse.findByIdAndUpdate(q.survey.responseId, normalized === "approve"
            ? { $set: { status: "approved", reviewedAt: now, reviewedBy: actorId(actor), updatedBy: actorId(actor) } }
            : { $set: { status: "rejected", rejectedAt: now, rejectedBy: actorId(actor), rejectionReason: text(remarks), updatedBy: actorId(actor) } },
        );
    }
    await audit(normalized === "approve" ? "survey_approved" : "survey_rejected", q, actor, request, { remarks: text(remarks) });
    return serialize(q);
}

export async function getQuotationSurvey(id, { actor } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    let response = q.survey?.response || {};
    if (q.survey?.responseId) {
        const row = await SurveyResponse.findById(q.survey.responseId).lean();
        if (row?.response) response = row.response;
    }
    const template = q.formTemplateId ? await SurveyTemplate.findById(q.formTemplateId).lean() : null;
    return { quotation: serialize(q), template: template ? { id: String(template._id), name: template.name, schema: template.schema, status: template.status, version: template.version } : null, response };
}

export async function buildQuotationComparison(id, { actor } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    const ids = (q.lines || []).map((line) => line.masterRateItemId).filter(Boolean);
    const rates = ids.length ? await MasterRateItem.find({ _id: { $in: ids } }).lean() : [];
    const map = new Map(rates.map((rate) => [String(rate._id), rate]));
    return (q.lines || []).map((line) => {
        const master = map.get(String(line.masterRateItemId));
        const benchmark = number(master?.standardRate ?? line.masterRate, 0);
        const vendorRate = number(line.vendorRate, 0);
        const variance = benchmark > 0 ? ((vendorRate - benchmark) / benchmark) * 100 : 0;
        return { ...line.toObject?.() || line, masterRate: benchmark, vendorRate, variance };
    });
}
