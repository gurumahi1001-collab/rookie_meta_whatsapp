import { Router } from "express";
import * as controller from "../controllers/boq/boqController.js";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";

const router=Router();
router.use(authenticate);
const view=authorize({module:"boq",action:"view",realms:["admin","internal"],userTypes:["admin","internal"]});
const add=authorize({module:"boq",action:"add",realms:["admin","internal"],userTypes:["admin","internal"]});
const edit=authorize({module:"boq",action:"edit",realms:["admin","internal"],userTypes:["admin","internal"]});
const del=authorize({module:"boq",action:"delete",realms:["admin","internal"],userTypes:["admin","internal"]});
const award=authorize({module:"commercial",action:"edit",realms:["admin","internal"],userTypes:["admin","internal"]});
router.get("/",view,controller.list);router.get("/:id",view,controller.get);router.post("/",add,controller.create);router.patch("/:id",edit,controller.update);router.delete("/:id",del,controller.remove);router.post("/:id/award",award,controller.award);
export default router;
