import { Router } from "express";
import * as controller from "../controllers/quotation/quotationController.js";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";

const router = Router();
router.use(authenticate);

const internalView = authorize({ module: "quotation", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const internalAdd = authorize({ module: "quotation", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const internalEdit = authorize({ module: "quotation", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const internalDelete = authorize({ module: "quotation", action: "delete", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const vendorView = authorize({ module: "quotation", action: "view", realms: ["vendor"], userTypes: ["vendor"] });
const vendorEdit = authorize({ module: "quotation", action: "edit", realms: ["vendor"], userTypes: ["vendor"] });

router.get("/", (req, res, next) => {
    if (["vendor"].includes(req.user?.userType)) return vendorView(req,res,next);
    return internalView(req,res,next);
}, controller.list);

router.get("/:id", (req,res,next) => {
    if (req.user?.userType === "vendor") return vendorView(req,res,next);
    return internalView(req,res,next);
}, controller.get);
router.get("/:id/survey", (req,res,next) => {
    if (req.user?.userType === "vendor") return vendorView(req,res,next);
    return internalView(req,res,next);
}, controller.survey);
router.get("/:id/comparison", internalView, controller.comparison);

router.post("/", internalAdd, controller.create);
router.patch("/:id", (req,res,next) => {
    if (req.user?.userType === "vendor") return vendorEdit(req,res,next);
    return internalEdit(req,res,next);
}, controller.update);
router.delete("/:id", internalDelete, controller.remove);
router.post("/:id/survey/submit", vendorEdit, controller.surveySubmit);
router.post("/:id/survey/review", internalEdit, controller.surveyReview);

export default router;
