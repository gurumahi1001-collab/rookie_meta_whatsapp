import {
    listQuotations,
    getQuotation,
    createQuotation,
    updateQuotation,
    deleteQuotation,
    submitSurvey,
    reviewSurvey,
    getQuotationSurvey,
    buildQuotationComparison,
    QuotationServiceError,
} from "../../services/quotation/quotationService.js";

function actor(req) {
    return req?.user ? {
        userId: req.user.id,
        userType: req.user.userType,
        roleId: req.user.roleId,
        vendorId: req.user.vendorId,
        actor: req.user,
    } : {};
}
function body(req) { return req?.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {}; }
function errorResponse(res, error) {
    if (error instanceof QuotationServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}) });
    if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Quotation validation failed.", code: "QUOTATION_VALIDATION_FAILED", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([k,v]) => [k, v?.message || "Invalid value."])) });
    if (error?.code === 11000) return res.status(409).json({ success: false, message: "A quotation with the same reference or vendor assignment already exists.", code: "QUOTATION_DUPLICATE" });
    console.error("[quotationController]", error);
    return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the quotation.", code: "INTERNAL_SERVER_ERROR" });
}
function request(req) { return { ipAddress: req?.ip, headers: req?.headers, get: req?.get?.bind(req) }; }

export async function list(req, res) { try { const result = await listQuotations({ actor: actor(req), ...req.query }); return res.json({ success: true, ...result }); } catch (e) { return errorResponse(res,e); } }
export async function get(req,res) { try { return res.json({ success:true, data:await getQuotation(req.params.id,{actor:actor(req)}) }); } catch(e){return errorResponse(res,e);} }
export async function create(req,res) { try { return res.status(201).json({success:true,message:"Quotation created successfully.",data:await createQuotation(body(req),{actor:actor(req),request:request(req)})}); } catch(e){return errorResponse(res,e);} }
export async function update(req,res) { try { return res.json({success:true,message:"Quotation updated successfully.",data:await updateQuotation(req.params.id,body(req),{actor:actor(req),request:request(req)})}); } catch(e){return errorResponse(res,e);} }
export async function remove(req,res) { try { return res.json({success:true,message:"Quotation deleted successfully.",data:await deleteQuotation(req.params.id,{actor:actor(req),request:request(req)})}); } catch(e){return errorResponse(res,e);} }
export async function surveySubmit(req,res) { try { return res.json({success:true,message:"Survey submitted for approval.",data:await submitSurvey(req.params.id,body(req),{actor:actor(req),request:request(req)})}); } catch(e){return errorResponse(res,e);} }
export async function surveyReview(req,res) { try { const b=body(req); return res.json({success:true,message:`Survey ${String(b.decision||"").toLowerCase()==="approve"?"approved":"rejected"} successfully.`,data:await reviewSurvey(req.params.id,{decision:b.decision,remarks:b.remarks},{actor:actor(req),request:request(req)})}); } catch(e){return errorResponse(res,e);} }
export async function survey(req,res) { try { return res.json({success:true,data:await getQuotationSurvey(req.params.id,{actor:actor(req)})}); } catch(e){return errorResponse(res,e);} }
export async function comparison(req,res) { try { return res.json({success:true,data:await buildQuotationComparison(req.params.id,{actor:actor(req)})}); } catch(e){return errorResponse(res,e);} }

export default { list,get,create,update,remove,surveySubmit,surveyReview,survey,comparison };
