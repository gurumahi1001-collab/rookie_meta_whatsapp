import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const QUOTATION_STATUSES = Object.freeze([
    "Draft",
    "Form Issued",
    "Form Submitted",
    "Form Approved",
    "Form Rejected",
    "Submitted",
    "Awarded",
    "Rejected",
    "Not Awarded",
    "Not Responded",
]);

const quotationLineSchema = new Schema(
    {
        boqLineId: { type: Schema.Types.ObjectId, default: null },
        masterRateItemId: { type: Schema.Types.ObjectId, ref: "MarketRateItem", default: null },
        module: { type: String, trim: true, default: "" },
        categoryType: { type: String, trim: true, default: "" },
        category: { type: String, trim: true, default: "" },
        description: { type: String, required: true, trim: true, maxlength: 2000 },
        unit: { type: String, required: true, trim: true, maxlength: 100 },
        quantity: { type: Number, required: true, min: 0 },
        masterRate: { type: Number, default: 0, min: 0 },
        vendorRate: { type: Number, default: 0, min: 0 },
        lineTotal: { type: Number, default: 0, min: 0 },
        isCustom: { type: Boolean, default: false },
    },
    { _id: true, strict: "throw" },
);

const paymentInstallmentSchema = new Schema(
    {
        name: { type: String, trim: true, required: true, maxlength: 200 },
        amount: { type: Number, min: 0, required: true },
        type: { type: String, enum: ["advance", "balance", "custom"], default: "custom" },
        dueDate: { type: Date, default: null },
    },
    { _id: true, strict: "throw" },
);

const workflowEntrySchema = new Schema(
    {
        action: { type: String, required: true, trim: true, maxlength: 120 },
        status: { type: String, trim: true, maxlength: 80 },
        actorUserId: { type: Schema.Types.ObjectId, ref: "User", default: null },
        actorType: { type: String, trim: true, default: "system" },
        remarks: { type: String, trim: true, maxlength: 2000, default: "" },
        occurredAt: { type: Date, default: Date.now },
    },
    { _id: true, strict: "throw" },
);

const surveyStateSchema = new Schema(
    {
        templateId: { type: Schema.Types.ObjectId, ref: "SurveyTemplate", default: null },
        responseId: { type: Schema.Types.ObjectId, ref: "SurveyResponse", default: null },
        status: {
            type: String,
            enum: ["not_started", "draft", "submitted", "approved", "rejected"],
            default: "not_started",
        },
        response: { type: Schema.Types.Mixed, default: () => ({}) },
        revision: { type: Number, min: 1, default: 1 },
        submittedAt: { type: Date, default: null },
        approvedAt: { type: Date, default: null },
        rejectedAt: { type: Date, default: null },
        approvedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        rejectedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        rejectionReason: { type: String, trim: true, maxlength: 2000, default: "" },
    },
    { _id: false, strict: "throw" },
);

const quotationSchema = new Schema(
    {
        quotationNo: { type: String, required: true, unique: true, index: true, trim: true, uppercase: true, maxlength: 80 },
        boqId: { type: Schema.Types.ObjectId, ref: "BOQ", default: null, index: true },
        vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true, index: true },
        vendorName: { type: String, required: true, trim: true, maxlength: 255 },
        vendorEmail: { type: String, trim: true, lowercase: true, maxlength: 255, default: "" },
        projectTitle: { type: String, required: true, trim: true, maxlength: 255 },
        projectSiteLocation: { type: String, trim: true, maxlength: 500, default: "" },
        clientName: { type: String, trim: true, maxlength: 255, default: "" },
        siteSurveyReference: { type: String, trim: true, maxlength: 120, default: "" },
        category: { type: String, trim: true, maxlength: 150, default: "" },
        formTemplateId: { type: Schema.Types.ObjectId, ref: "SurveyTemplate", default: null },
        formTemplateName: { type: String, trim: true, maxlength: 255, default: "" },
        currency: { type: String, required: true, trim: true, uppercase: true, maxlength: 10, default: "USD" },
        quotationDate: { type: Date, default: Date.now },
        dueDate: { type: Date, default: null, index: true },
        validUntil: { type: Date, default: null },
        validityDays: { type: Number, min: 0, default: null },
        scopeSummary: { type: String, trim: true, maxlength: 5000, default: "" },
        terms: { type: String, trim: true, maxlength: 10000, default: "" },
        status: { type: String, enum: QUOTATION_STATUSES, default: "Draft", index: true },
        subtotal: { type: Number, min: 0, default: 0 },
        taxTotal: { type: Number, min: 0, default: 0 },
        otherCharges: { type: Number, min: 0, default: 0 },
        grandTotal: { type: Number, min: 0, default: 0, index: true },
        margin: { type: Number, default: 0 },
        lines: { type: [quotationLineSchema], default: [] },
        manualAdditions: { type: [quotationLineSchema], default: [] },
        paymentSchedule: { type: [paymentInstallmentSchema], default: [] },
        survey: { type: surveyStateSchema, default: () => ({}) },
        award: {
            vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", default: null },
            vendorName: { type: String, trim: true, default: "" },
            remarks: { type: String, trim: true, maxlength: 3000, default: "" },
            awardedAt: { type: Date, default: null },
            awardedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        },
        workflowHistory: { type: [workflowEntrySchema], default: [] },
        masterRateComparison: { type: Schema.Types.Mixed, default: () => ({}) },
        revision: { type: Number, min: 1, default: 1 },
        createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    {
        collection: "quotations",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

quotationSchema.index({ boqId: 1, vendorId: 1 }, { unique: true, name: "quotations_boq_vendor_unique" });
quotationSchema.index({ vendorId: 1, status: 1, updatedAt: -1 }, { name: "quotations_vendor_status_updated" });
quotationSchema.index({ status: 1, updatedAt: -1 }, { name: "quotations_status_updated" });
quotationSchema.index({ projectTitle: 1, vendorName: 1, status: 1 }, { name: "quotations_project_vendor_status" });

quotationSchema.pre("validate", function normalizeQuotation() {
    this.quotationNo = String(this.quotationNo || "").trim().toUpperCase();
    this.currency = String(this.currency || "USD").trim().toUpperCase();
    this.vendorName = String(this.vendorName || "").trim();
    this.projectTitle = String(this.projectTitle || "").trim();
    this.status = String(this.status || "Draft").trim();
    this.subtotal = Number(this.subtotal || 0);
    this.taxTotal = Number(this.taxTotal || 0);
    this.otherCharges = Number(this.otherCharges || 0);
    this.grandTotal = Number(this.grandTotal || 0);
    this.revision = Math.max(1, Number(this.revision || 1));
});

quotationSchema.virtual("id").get(function id() { return String(this._id); });

quotationSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        quotationNo: this.quotationNo,
        boqId: this.boqId ? String(this.boqId) : null,
        vendor: this.vendorId ? String(this.vendorId) : null,
        vendorId: this.vendorId ? String(this.vendorId) : null,
        vendorName: this.vendorName,
        vendorEmail: this.vendorEmail,
        projectTitle: this.projectTitle,
        projectSiteLocation: this.projectSiteLocation,
        projectLocation: this.projectSiteLocation,
        clientName: this.clientName,
        siteSurveyReference: this.siteSurveyReference,
        category: this.category,
        formTemplateId: this.formTemplateId ? String(this.formTemplateId) : null,
        formTemplate: this.formTemplateName,
        currency: this.currency,
        quotationDate: this.quotationDate,
        date: this.dueDate || this.quotationDate,
        dueDate: this.dueDate,
        validUntil: this.validUntil,
        validityDays: this.validityDays,
        scopeSummary: this.scopeSummary,
        terms: this.terms,
        status: this.status,
        subtotal: this.subtotal,
        taxTotal: this.taxTotal,
        otherCharges: this.otherCharges,
        grandTotal: this.grandTotal,
        margin: this.margin,
        lines: this.lines || [],
        manualAdditions: this.manualAdditions || [],
        paymentSchedule: this.paymentSchedule || [],
        survey: this.survey || null,
        award: this.award || null,
        awardedVendor: this.award?.vendorName || "",
        workflowHistory: this.workflowHistory || [],
        masterRateComparison: this.masterRateComparison || {},
        revision: this.revision,
        createdBy: this.createdBy ? String(this.createdBy) : null,
        updatedBy: this.updatedBy ? String(this.updatedBy) : null,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
        items: Array.isArray(this.lines) ? this.lines.length : 0,
    };
};

quotationSchema.set("toJSON", { virtuals: true });

const Quotation = models.Quotation || model("Quotation", quotationSchema);
export default Quotation;
export { quotationSchema };
