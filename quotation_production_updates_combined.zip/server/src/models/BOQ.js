import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const BOQ_STATUSES = Object.freeze([
    "Draft",
    "Generated Quotation",
    "Pending Approval",
    "Awarded",
    "Converted to Project",
    "Rejected",
]);

const boqLineSchema = new Schema(
    {
        marketRateItemId: { type: Schema.Types.ObjectId, ref: "MarketRateItem", default: null },
        module: { type: String, trim: true, default: "" },
        categoryType: { type: String, trim: true, default: "" },
        category: { type: String, trim: true, default: "" },
        description: { type: String, trim: true, required: true, maxlength: 2000 },
        unit: { type: String, trim: true, required: true, maxlength: 100 },
        quantity: { type: Number, min: 0, required: true },
        rate: { type: Number, min: 0, required: true },
        lineTotal: { type: Number, min: 0, required: true },
        isCustom: { type: Boolean, default: false },
    },
    { _id: true, strict: "throw" },
);

const vendorSnapshotSchema = new Schema(
    {
        vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true },
        vendorName: { type: String, required: true, trim: true },
        vendorEmail: { type: String, trim: true, lowercase: true, default: "" },
    },
    { _id: false, strict: "throw" },
);

const paymentInstallmentSchema = new Schema(
    {
        name: { type: String, required: true, trim: true },
        amount: { type: Number, min: 0, required: true },
        type: { type: String, enum: ["advance", "balance", "custom"], default: "custom" },
        dueDate: { type: Date, default: null },
    },
    { _id: true, strict: "throw" },
);

const boqSchema = new Schema(
    {
        boqNo: { type: String, required: true, unique: true, trim: true, uppercase: true, index: true },
        projectName: { type: String, required: true, trim: true, maxlength: 255, index: true },
        projectSiteLocation: { type: String, trim: true, maxlength: 500, default: "" },
        siteSurveyReference: { type: String, trim: true, maxlength: 120, default: "" },
        projectValue: { type: Number, min: 0, default: 0 },
        currency: { type: String, trim: true, uppercase: true, maxlength: 10, default: "USD" },
        validityDays: { type: Number, min: 0, default: 30 },
        responseDueDate: { type: Date, default: null, index: true },
        formTemplateId: { type: Schema.Types.ObjectId, ref: "SurveyTemplate", default: null },
        formTemplateName: { type: String, trim: true, maxlength: 255, default: "" },
        lines: { type: [boqLineSchema], default: [] },
        manualAdditions: { type: [boqLineSchema], default: [] },
        paymentSchedule: { type: [paymentInstallmentSchema], default: [] },
        assignedVendors: { type: [vendorSnapshotSchema], default: [] },
        subtotal: { type: Number, min: 0, default: 0 },
        contingency: { type: Number, min: 0, default: 0 },
        grandTotal: { type: Number, min: 0, default: 0 },
        status: { type: String, enum: BOQ_STATUSES, default: "Draft", index: true },
        awardedVendorId: { type: Schema.Types.ObjectId, ref: "Vendor", default: null },
        awardedVendorName: { type: String, trim: true, default: "" },
        awardRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
        awardedQuotationId: { type: Schema.Types.ObjectId, ref: "Quotation", default: null },
        awardedAt: { type: Date, default: null },
        awardedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        revision: { type: Number, min: 1, default: 1 },
        createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    {
        collection: "boqs",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

boqSchema.index({ projectName: 1, status: 1, updatedAt: -1 }, { name: "boqs_project_status_updated" });
boqSchema.index({ status: 1, updatedAt: -1 }, { name: "boqs_status_updated" });

boqSchema.pre("validate", function normalizeBOQ() {
    this.projectName = String(this.projectName || "").trim();
    this.currency = String(this.currency || "USD").trim().toUpperCase();
    this.subtotal = Number(this.subtotal || 0);
    this.contingency = Number(this.contingency || 0);
    this.grandTotal = Number(this.grandTotal || 0);
    this.projectValue = Number(this.projectValue || 0);
    this.revision = Math.max(1, Number(this.revision || 1));
});

boqSchema.virtual("id").get(function id() { return String(this._id); });

boqSchema.methods.toSafeJSON = function toSafeJSON() {
    const vendors = (this.assignedVendors || []).map((vendor) => ({
        id: vendor.vendorId ? String(vendor.vendorId) : null,
        vendorId: vendor.vendorId ? String(vendor.vendorId) : null,
        name: vendor.vendorName,
        email: vendor.vendorEmail,
    }));

    return {
        id: String(this._id),
        boqNo: this.boqNo,
        quotationNo: this.boqNo,
        projectName: this.projectName,
        projectTitle: this.projectName,
        projectSiteLocation: this.projectSiteLocation,
        projectLocation: this.projectSiteLocation,
        siteSurveyReference: this.siteSurveyReference,
        projectValue: this.projectValue,
        currency: this.currency,
        validityDays: this.validityDays,
        dueDate: this.responseDueDate,
        responseDueDate: this.responseDueDate,
        formTemplateId: this.formTemplateId ? String(this.formTemplateId) : null,
        formTemplate: this.formTemplateName,
        lines: this.lines || [],
        manualAdditions: this.manualAdditions || [],
        paymentSchedule: this.paymentSchedule || [],
        vendors,
        assignedVendors: vendors,
        subtotal: this.subtotal,
        contingency: this.contingency,
        grandTotal: this.grandTotal,
        status: this.status,
        awardedVendorId: this.awardedVendorId ? String(this.awardedVendorId) : null,
        awardedVendorName: this.awardedVendorName,
        awardedVendor: this.awardedVendorName,
        awardRemarks: this.awardRemarks,
        awardedQuotationId: this.awardedQuotationId ? String(this.awardedQuotationId) : null,
        awardedAt: this.awardedAt,
        awardedBy: this.awardedBy ? String(this.awardedBy) : null,
        revision: this.revision,
        createdBy: this.createdBy ? String(this.createdBy) : null,
        updatedBy: this.updatedBy ? String(this.updatedBy) : null,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
        items: Array.isArray(this.lines) ? this.lines.length : 0,
    };
};

boqSchema.set("toJSON", { virtuals: true });

const BOQ = models.BOQ || model("BOQ", boqSchema);
export default BOQ;
export { boqSchema };
