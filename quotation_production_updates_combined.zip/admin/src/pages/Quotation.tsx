import { useEffect, useMemo, useState } from "react";

import type { Quotation } from "../types/quotation";
import { listQuotations, toQuotationView } from "../api/quotationApi";

import QuotationTabs, { QuotationTab } from "../components/quotations/QuotationTabs";
import QuotationDashboard from "../components/quotations/QuotationDashboard";
import BidsAndProposals from "../components/quotations/Bids&Proposal";
import ProjectBOQEstimator from "../components/quotations/ProjectBOQ";
import QuotationHeader from "../components/quotations/QuotationHeader";
import NewQuotation from "../components/quotations/NewQuotation";
import QuotationDetails from "../components/quotations/QuotationDetails";
import ProjectBOQList from "../components/quotations/ProjectBOQ_list";

type QuotationView = "list" | "new-quotation" | "project-boq" | "quotation-details";

const Quotations = () => {
    const [activeTab, setActiveTab] = useState<QuotationTab>("bids");
    const [showProjectBOQ, setShowProjectBOQ] = useState(false);
    const [currentView, setCurrentView] = useState<QuotationView>("list");
    const [quotationList, setQuotationList] = useState<Quotation[]>([]);
    const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);

    const loadQuotations = async () => {
        try {
            const response = await listQuotations({ page: 1, limit: 200, sortBy: "updatedAt", sortOrder: "desc" });
            setQuotationList((response.data || []).map(toQuotationView) as Quotation[]);
        } catch (error) {
            console.error("Failed to load quotations", error);
        }
    };

    useEffect(() => {
        void loadQuotations();
    }, []);

    const handleViewQuotation = (quotation: Quotation) => {
        setSelectedQuotation(quotation);
        setCurrentView("quotation-details");
    };

    const handleStatusChange = (quotationId: Quotation["id"], status: Quotation["status"]) => {
        setQuotationList((previous) => previous.map((quotation) => quotation.id === quotationId ? { ...quotation, status } : quotation));
        setSelectedQuotation((previous) => previous?.id === quotationId ? { ...previous, status } : previous);
    };

    const stats = useMemo(() => {
        const pending = quotationList.filter((q) => q.status === "Form Submitted" || q.status === "Submitted").length;
        const approved = quotationList.filter((q) => q.status === "Form Approved" || q.status === "Awarded").length;
        const approvedValue = quotationList.filter((q) => q.status === "Awarded").reduce((total, q) => total + Number(q.grandTotal || 0), 0);
        return { total: quotationList.length, pending, approved, approvedValue };
    }, [quotationList]);

    if (currentView === "quotation-details" && selectedQuotation) {
        return (
            <div className="min-h-screen">
                <QuotationDetails
                    quotation={selectedQuotation}
                    onBack={() => {
                        setSelectedQuotation(null);
                        setCurrentView("list");
                        void loadQuotations();
                    }}
                    onStatusChange={handleStatusChange}
                />
            </div>
        );
    }

    if (currentView === "new-quotation") {
        return (
            <div className="min-h-screen">
                <NewQuotation onBack={() => setCurrentView("list")} onOpenMasterRate={() => setCurrentView("project-boq")} />
            </div>
        );
    }

    if (currentView === "project-boq") {
        return (
            <div className="min-h-screen">
                <ProjectBOQEstimator onBack={() => setCurrentView("new-quotation")} />
            </div>
        );
    }

    return (
        <div className="min-h-screen">
            <QuotationHeader
                showNewQuotation={activeTab === "bids"}
                showBoqActions={activeTab === "boq" && showProjectBOQ}
                showAddBOQ={activeTab === "boq" && showProjectBOQ}
                onExportEstimate={() => console.log("Export Estimate")}
                onGenerateQuotation={() => setCurrentView("new-quotation")}
            />

            <div className="mb-6">
                <QuotationTabs activeTab={activeTab} onChange={setActiveTab} />
            </div>

            {activeTab === "bids" && (
                <>
                    <QuotationDashboard total={stats.total} pending={stats.pending} approved={stats.approved} approvedValue={stats.approvedValue} />
                    <BidsAndProposals quotations={quotationList} onView={handleViewQuotation} />
                </>
            )}

            {activeTab === "boq" && (
                <>
                    {!showProjectBOQ ? (
                        <ProjectBOQList onAddBOQ={() => setShowProjectBOQ(true)} />
                    ) : (
                        <ProjectBOQEstimator showBackButton onBack={() => setShowProjectBOQ(false)} />
                    )}
                </>
            )}
        </div>
    );
};

export default Quotations;
