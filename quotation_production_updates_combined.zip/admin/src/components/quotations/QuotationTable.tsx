import {
    ClipboardText,
    EyeIcon,
    PencilIcon,
    TrashIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { deleteQuotation, toQuotationView, listQuotations } from "../../api/quotationApi";

import type { Quotation, QuotationStatus } from "../../types/quotation";
import DataTable, {
    DataTableColumn,
} from "../DataTable";

interface QuotationTableProps {
    quotations?: Quotation[];
    onView?: (quotation: Quotation) => void;
}

const getVendorName = (quotation: Quotation): string => {
    return quotation.vendorName || (Array.isArray(quotation.vendor) ? quotation.vendor.join(", ") : String(quotation.vendor || "Vendor"));
};

const statusClasses: Record<QuotationStatus, string> = {
    "Form Issued": "bg-blue-50 text-blue-700",
    "Form Submitted": "bg-amber-50 text-amber-700",
    "Form Approved": "bg-emerald-50 text-emerald-700",
    "Form Rejected": "bg-red-50 text-red-700",

    Issued: "bg-blue-50 text-blue-700",
    Draft: "bg-slate-100 text-slate-600",
    Submitted: "bg-amber-50 text-amber-700",
    Awarded: "bg-emerald-50 text-emerald-700",
    "Not Responded": "bg-red-100 text-red-600",
    Rejected: "bg-red-50 text-red-700",
};


const QuotationTable = ({ 
    quotations: quotationsProp,
    onView,
}: QuotationTableProps) => {
    const navigate = useNavigate();

    const [quotations, setQuotations] = useState<Quotation[]>(quotationsProp || []);
    const [hoveredQuotationId, setHoveredQuotationId] = useState<string | null>(null);

    useEffect(() => {
        if (quotationsProp) {
            setQuotations(quotationsProp);
            return;
        }
        let mounted = true;
        void (async () => {
            try {
                const response = await listQuotations({ page: 1, limit: 200, sortBy: "updatedAt", sortOrder: "desc" });
                if (mounted) setQuotations((response.data || []).map(toQuotationView) as Quotation[]);
            } catch (error) {
                console.error("Failed to load quotations", error);
            } finally {
            }
        })();
        return () => { mounted = false; };
    }, [quotationsProp]);

    const handleDeleteQuotation = async (id: string) => {
        if (!confirm("Are you sure you want to delete this quotation?")) return;
        try {
            await deleteQuotation(id);
            setQuotations((previous) => previous.filter((quotation) => quotation.id !== id));
            setHoveredQuotationId(null);
        } catch (error: any) {
            console.error("Error deleting quotation:", error);
            alert(error?.response?.data?.message || "Failed to delete quotation.");
        }
    };

    const handleEditQuotation = (quotation: Quotation) => {
        navigate("/quotation/edit_quotation", {
            state: {
                quotationId: quotation.id,
                editQuotation: quotation,
            },
        });
    };

    const handleView = (quotation: Quotation) => {
        if (onView) {
            onView(quotation);
            return;
        }

        navigate("/quotation/quotationdetails", {
            state: {
                quotation,
            },
        });
    };

    const columns: DataTableColumn<Quotation>[] = [
        {
            key: "quotationNo",
            label: "Quotation",
            width: "120px",
            sortable: true,
            align: "left",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs font-bold text-slate-800 group-hover:text-red-600">
                    {quotation.quotationNo}
                </span>
            ),
        },
        {
            key: "vendor",
            label: "Vendor",
            width: "190px",
            sortable: true,
            align: "left",
            render: (quotation) => {
                const vendorName = getVendorName(quotation);

                return (
                    <span
                        title={vendorName}
                        className="block truncate text-xs font-medium text-slate-700"
                    >
                        {vendorName}
                    </span>
                );
            },
        },
        {
            key: "projectTitle",
            label: "Project Title",
            width: "240px",
            sortable: true,
            align: "left",
            render: (quotation) => (
                <span
                    title={quotation.projectTitle}
                    className="block truncate text-xs font-semibold text-slate-800"
                >
                    {quotation.projectTitle}
                </span>
            ),
        },
        {
            key: "date",
            label: "Due Date",
            width: "110px",
            sortable: true,
            align: "center",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs text-slate-600">
                    {quotation.date}
                </span>
            ),
        },
        {
            key: "grandTotal",
            label: "Grand Total",
            width: "145px",
            sortable: true,
            align: "right",
            render: (quotation) => (
                <span className="block whitespace-nowrap text-xs font-bold text-slate-800">
                    {quotation.currency}{" "}
                    {Number(quotation.grandTotal).toLocaleString(
                        "en-US",
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                        }
                    )}
                </span>
            ),
        },

        {
            key: "status",
            label: "Status",
            width: "135px",
            sortable: true,
            align: "center",
            render: (quotation) => (
                <span
                    className={`inline-flex min-w-[90px] items-center justify-center whitespace-nowrap rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClasses[quotation.status]}`}
                >
                    {quotation.status}
                </span>
            ),
        },
        {
            key: "action",
            label: "Action",
            width: "150px",
            align: "center",
            render: (quotation) => {
                const canEdit =
                    quotation.status === "Draft" || quotation.status === "Form Approved";

                const isHovered =
                    hoveredQuotationId === quotation.id;

                return (
                    <div
                        className="flex min-h-8 items-center justify-center gap-1"
                        onMouseEnter={() =>
                            setHoveredQuotationId(quotation.id)
                        }
                        onMouseLeave={() =>
                            setHoveredQuotationId(null) 
                        }
                    >
                        <div
                            className={`flex items-center justify-center gap-1 transition-opacity duration-150 `}
                        >
                            {canEdit && (
                                <button
                                    type="button"
                                    onClick={() =>
                                        handleEditQuotation(quotation)
                                    }
                                    title="Edit quotation"
                                    aria-label="Edit quotation"
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-blue-600 transition-colors hover:bg-blue-50 hover:text-blue-700"
                                >
                                    <PencilIcon
                                        size={16}
                                        weight="duotone"
                                    />
                                </button>
                            )}

                            {["Form Issued", "Form Submitted", "Form Rejected"].includes(quotation.status) && (
                                <button
                                    type="button"
                                    onClick={(event) => {
                                        event.stopPropagation();

                                        const params = new URLSearchParams({ quotationId: quotation.id });
                                        if ((quotation as any).formTemplateId) {
                                            params.set("templateId", String((quotation as any).formTemplateId));
                                        }
                                        navigate(`/quotation/survey-form?${params.toString()}`, {
                                            state: {
                                                quotationId: quotation.id,
                                                quotation: quotation,
                                            },
                                        });
                                    }}
                                    title="Open survey form"
                                    aria-label="Open survey form"
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-emerald-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"
                                >
                                    <ClipboardText
                                        size={16}
                                        weight="duotone"
                                    />
                                </button>
                            )}


                            <button
                                type="button"
                                onClick={() =>
                                    handleView(quotation)
                                }
                                title="Review quotation"
                                aria-label="Review quotation"
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-600 transition-colors hover:bg-red-50 hover:text-red-700"
                            >
                                <EyeIcon
                                    size={18}
                                    weight="duotone"
                                />
                            </button>

                            <button
                                type="button"
                                onClick={() =>
                                    handleDeleteQuotation(
                                        quotation.id
                                    )
                                }
                                title="Delete quotation"
                                aria-label="Delete quotation"
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-500 transition-colors hover:bg-red-50 hover:text-red-600"
                            >
                                <TrashIcon
                                    size={16}
                                    weight="duotone"
                                />
                            </button>
                        </div>
                    </div>
                );
            },
        },
    ];

    return (
        <DataTable<Quotation>
            columns={columns}
            data={quotations}
            rowKey={(quotation) => quotation.id}
            emptyMessage="No quotations found."
            className="rounded-2xl"
        />
    );
};

export default QuotationTable;
