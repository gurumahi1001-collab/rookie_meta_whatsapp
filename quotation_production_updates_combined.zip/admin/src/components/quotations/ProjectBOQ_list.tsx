import { useEffect, useState } from "react";
import {
    EyeIcon,
    PencilSimpleIcon,
    TrashIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import DataTable, { DataTableColumn } from "../DataTable";
import QuotationHeader from "./QuotationHeader";
import QuotationTabs from "./QuotationTabs";
import { ProjectBOQQuotation } from "../../data/quotations";
import ViewQuotationDrawer from "../../offcanvas/quotation/ViewQuotationDrawer";
import { deleteBOQ, getBOQ, listBOQs, toBOQView } from "../../api/quotationApi";

interface ProjectBOQListProps {
    onAddBOQ: () => void;
    onView?: (quotation: ProjectBOQQuotation) => void;
    onEdit?: (quotation: ProjectBOQQuotation) => void;
    activeTab?: "bids" | "boq";
    onTabChange?: (tab: "bids" | "boq") => void;
    onExportEstimate?: () => void;
    onGenerateQuotation?: () => void;
    showBoqActions?: boolean;
}

const ProjectBOQList = ({
    onAddBOQ,
    onView,
    onEdit,
    activeTab = "boq",
    onTabChange,
    onExportEstimate,
    onGenerateQuotation,
    showBoqActions = true,
}: ProjectBOQListProps) => {
    const navigate = useNavigate();
    const [rows, setRows] = useState<ProjectBOQQuotation[]>([]);
    const [selectedQuotation, setSelectedQuotation] = useState<any>(null);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [showVendors, setShowVendors] = useState(false);
    const [selectedVendors, setSelectedVendors] = useState<string[]>([]);

    const loadRows = async () => {
        try {
            const response = await listBOQs({ page: 1, limit: 200, sortBy: "updatedAt", sortOrder: "desc" });
            setRows((response.data || []).map(toBOQView) as ProjectBOQQuotation[]);
        } catch (error) {
            console.error("Failed to load project BOQs", error);
        }
    };

    useEffect(() => { void loadRows(); }, []);

    const handleViewQuotation = async (quotation: ProjectBOQQuotation) => {
        try {
            const detail = await getBOQ(quotation.id);
            setSelectedQuotation(toBOQView(detail));
        } catch (error) {
            console.error("Failed to load BOQ detail", error);
            setSelectedQuotation(quotation);
        }
        setIsDrawerOpen(true);
        onView?.(quotation);
    };

    const handleEditQuotation = (quotation: ProjectBOQQuotation) => {
        if (onEdit) {
            onEdit(quotation);
            return;
        }
        navigate("/quotation/project_boq/edit-boq", { state: { boqId: quotation.id, boq: quotation } });
    };

    const handleDeleteQuotation = async (quotation: ProjectBOQQuotation) => {
        if (!confirm(`Are you sure you want to delete ${quotation.quotationNo || "this BOQ"}?`)) return;
        try {
            await deleteBOQ(quotation.id);
            setRows((current) => current.filter((row) => row.id !== quotation.id));
            setIsDrawerOpen(false);
        } catch (error: any) {
            console.error("Failed to delete BOQ", error);
            alert(error?.response?.data?.message || "Failed to delete BOQ.");
        }
    };

    const formatDate = (value: any) => value ? new Date(value).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "-";
    const formatCurrency = (value: number) => Number(value || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const statusClass = (status: string) => {
        switch (status) {
            case "Generated Quotation": return "bg-blue-50 text-blue-600";
            case "Pending Approval": return "bg-amber-100 text-amber-600";
            case "Awarded": return "bg-emerald-50 text-emerald-600";
            case "Converted to Project": return "bg-purple-50 text-purple-600";
            default: return "bg-slate-100 text-slate-600";
        }
    };

    const columns: DataTableColumn<ProjectBOQQuotation>[] = [
        { key: "quotationNo", label: "Quotation No", width: "140px", sortable: true, render: (q) => <span className="text-xs font-bold text-slate-800">{q.quotationNo}</span> },
        { key: "projectTitle", label: "Project", width: "240px", sortable: true, render: (q) => <span className="block truncate text-xs font-medium text-slate-700">{q.projectTitle}</span> },
        {
            key: "vendor", label: "Vendors", width: "260px", render: (q) => (
                <div className="flex flex-wrap gap-1.5">
                    {(q.vendor || []).slice(0, 3).map((vendor, index) => <span key={`${vendor}-${index}`} className="max-w-[110px] truncate rounded-md bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-600">{vendor}</span>)}
                    {(q.vendor || []).length > 3 && <button type="button" onClick={() => { setSelectedVendors(q.vendor); setShowVendors(true); }} className="rounded-md bg-slate-100 px-2 py-1 text-[10px] font-bold text-slate-500">+{q.vendor.length - 3}</button>}
                </div>
            )
        },
        { key: "date", label: "Due Date", width: "120px", sortable: true, align: "center", render: (q) => <span className="whitespace-nowrap text-xs text-slate-600">{formatDate(q.date)}</span> },
        { key: "projectValue", label: "Project Value", width: "145px", align: "right", sortable: true, render: (q) => <span className="whitespace-nowrap text-xs font-bold text-slate-800">{q.currency} {formatCurrency(q.projectValue)}</span> },
        { key: "grandTotal", label: "Grand Total", width: "145px", align: "right", sortable: true, render: (q) => <span className="whitespace-nowrap text-xs font-bold text-slate-800">{q.currency} {formatCurrency(q.grandTotal)}</span> },
        { key: "items", label: "Items", width: "70px", align: "center", sortable: true, render: (q) => <span className="text-xs font-semibold text-slate-700">{q.items}</span> },
        { key: "status", label: "Status", width: "150px", align: "center", sortable: true, render: (q) => <span className={`inline-flex rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClass(q.status)}`}>{q.status}</span> },
        {
            key: "actions", label: "Actions", width: "120px", align: "center", render: (q) => (
                <div className="flex items-center justify-center gap-1">
                    <button type="button" onClick={() => void handleViewQuotation(q)} title="View quotation" className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-slate-50 hover:text-slate-700"><EyeIcon size={14} weight="bold" /></button>
                    {q.status !== "Awarded" && q.status !== "Converted to Project" && <button type="button" onClick={() => handleEditQuotation(q)} title="Edit quotation" className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-amber-50 hover:text-amber-600"><PencilSimpleIcon size={14} weight="bold" /></button>}
                    {q.status !== "Awarded" && q.status !== "Converted to Project" && <button type="button" onClick={() => void handleDeleteQuotation(q)} title="Delete quotation" className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-red-50 hover:text-red-600"><TrashIcon size={14} weight="bold" /></button>}
                </div>
            )
        },
    ];

    return (
        <>
            <div className="space-y-5">
                <div className="space-y-4">
                    <QuotationHeader showNewQuotation={activeTab === "bids"} showAddBOQ={activeTab === "boq"} showBoqActions={showBoqActions} onExportEstimate={onExportEstimate} onGenerateQuotation={onGenerateQuotation || onAddBOQ} />
                    <div className="flex w-full items-center">
                        <QuotationTabs activeTab={activeTab} onChange={(tab) => { onTabChange?.(tab); navigate(tab === "bids" ? "/quotation" : "/quotation/project_boq"); }} />
                    </div>
                </div>
                <section className="rounded-2xl shadow-sm">
                    <div className="px-0 py-4"><h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">Recent Quotations</h3><p className="mt-1 text-[10px] text-slate-400">View and manage project BOQ quotations</p></div>
                    <div className="rounded-2xl p-0"><DataTable columns={columns} data={rows} rowKey={(q) => q.id} emptyMessage="No project BOQ quotations found." /></div>
                </section>
            </div>

            <ViewQuotationDrawer isOpen={isDrawerOpen} quotation={selectedQuotation} onClose={() => setIsDrawerOpen(false)} onEdit={handleEditQuotation} onGenerateQuotation={onGenerateQuotation} onAwarded={loadRows} />

            {showVendors && (
                <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
                    <div className="w-full max-w-md overflow-hidden rounded-xl bg-white shadow-2xl">
                        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4"><div><h3 className="text-sm font-bold text-slate-900">Vendors</h3><p className="mt-0.5 text-[10px] text-slate-500">All vendors associated with this quotation</p></div><button type="button" onClick={() => setShowVendors(false)} className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"><XIcon size={16} weight="bold" /></button></div>
                        <div className="max-h-[350px] overflow-y-auto p-5"><div className="space-y-2">{selectedVendors.map((vendor, index) => <div key={`${vendor}-${index}`} className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2.5"><div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-blue-50 text-[11px] font-bold text-blue-600">{index + 1}</div><span className="text-xs font-semibold text-slate-700">{vendor}</span></div>)}</div></div>
                        <div className="flex justify-end border-t border-slate-200 bg-slate-50 px-5 py-3"><button type="button" onClick={() => setShowVendors(false)} className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-[10px] font-bold text-slate-600 transition hover:bg-slate-100">Close</button></div>
                    </div>
                </div>
            )}
        </>
    );
};

export default ProjectBOQList;
