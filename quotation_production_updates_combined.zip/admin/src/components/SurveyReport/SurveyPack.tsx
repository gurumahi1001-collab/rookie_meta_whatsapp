import React, { useEffect, useState } from "react";
import {
  MapPin,
  ClipboardText,
  Buildings,
  WifiHigh,
  House,
  Warning,
  ShieldCheck,
  Camera,
  FileText,
  Printer,
  FloppyDisk,
  ArrowCounterClockwise,
  NavigationArrow,
  Toolbox,
  HardHat,
  Gauge,
  RoadHorizon,
  Signpost,
  User,
  CalendarBlank,
  Cloud,
  Phone,
  Ruler,
  PenNib,
  ArrowLeft,
  XCircle,
  CheckCircle,
} from "@phosphor-icons/react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { getSurveyTemplate } from "../../api/surveyApi";
import { getQuotationSurvey, reviewQuotationSurvey } from "../../api/quotationApi";
import type { SurveyField, SurveyModule } from "./SurveyStorage";

type CheckStatus = "Pass" | "Fail" | "";
type Readiness = "Ready" | "Missing / Defective" | "";
type Severity = "P1 Critical" | "P2 Urgent" | "P3 Routine" | "";

interface ProjectDetails {
  leadContractor: string;
  surveyDate: string;
  weather: string;
  parish: string;
  vehicle: string;
  crewLead: string;
  technician2: string;
}

interface FacilityCheck {
  item: string;
  status: CheckStatus;
  observation: string;
  action: boolean;
}

interface OdfRow {
  rack: string;
  port: string;
  fiber: string;
  core: string;
  power: string;
  connector: string;
  code: string;
}

interface PoleRecord {
  poleGps: string;
  poleType: string;
  fiberSpan: string;
  cableCondition: string;
  enclosureId: string;
  clearance: string[];
}

interface NapStation {
  terminalId: string;
  pole: string;
  physical: string;
  seal: string;
  splitter: string;
  used: string;
  free: string;
  inputPower: string;
  outputPower: string;
  gland: string;
  reference: string;
}

interface Defect {
  location: string;
  severity: Severity;
  description: string;
  action: string;
  materials: string;
  crew: string;
  code: string;
  evidence: string;
}

interface ChecklistItem {
  item: string;
  readiness: Readiness;
  notes: string;
}

const inputClass =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:focus:border-red-400 dark:focus:ring-red-900";

const textareaClass =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:focus:border-red-400 dark:focus:ring-red-900 resize-y";

const selectClass =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:border-slate-700 dark:bg-slate-900 dark:text-white";

const checkboxClass =
  "h-4 w-4 rounded border-slate-300 text-red-600 focus:ring-red-500";

const initialProject: ProjectDetails = {
  leadContractor: "",
  surveyDate: "",
  weather: "",
  parish: "",
  vehicle: "",
  crewLead: "",
  technician2: "",
};

const createFacilityChecks = (): FacilityCheck[] => [
  { item: "CO Facility Access & Security", status: "", observation: "", action: false },
  { item: "Rack Space Availability (OLT/ODF)", status: "", observation: "", action: false },

];

const createOdfRows = (): OdfRow[] => [
  { rack: "ODF-01", port: "", fiber: "", core: "", power: "", connector: "", code: "A1-PP-01" },
  { rack: "ODF-01", port: "", fiber: "", core: "", power: "", connector: "", code: "A1-PP-01" },

];

const createPoleRecords = (): PoleRecord[] =>
  Array.from({ length: 4 }, () => ({
    poleGps: "",
    poleType: "",
    fiberSpan: "",
    cableCondition: "",
    enclosureId: "",
    clearance: [],
  }));

const createNapStations = (): NapStation[] =>
  Array.from({ length: 3 }, () => ({
    terminalId: "",
    pole: "",
    physical: "",
    seal: "",
    splitter: "",
    used: "",
    free: "",
    inputPower: "",
    outputPower: "",
    gland: "",
    reference: "",
  }));

const createDefects = (): Defect[] => [
  {
    location: "",
    severity: "",
    description: "",
    action: "",
    materials: "",
    crew: "2-Man OSP",
    code: "E2-RPR-SPN / E3-MAN-TRK",
    evidence: "",
  },
  {
    location: "",
    severity: "",
    description: "",
    action: "",
    materials: "",
    crew: "Splicer + Tech",
    code: "E1-FLT-VIS / C1-NAP-TERM",
    evidence: "",
  },
  {
    location: "",
    severity: "",
    description: "",
    action: "",
    materials: "",
    crew: "Line Crew",
    code: "E6-EMG-RSTR / B3-CLOS-OSP",
    evidence: "",
  },
];

const createChecklist = (items: string[]): ChecklistItem[] =>
  items.map((item) => ({ item, readiness: "", notes: "" }));

const SectionHeader = ({
  zone,
  title,
  description,
  icon: Icon,
}: {
  zone: string;
  title: string;
  description: string;
  icon: React.ElementType;
}) => (
  <div className="flex items-start gap-4 border-b border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-900/70">
    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white shadow-sm">
      <Icon size={20} weight="duotone" />
    </div>

    <div className="min-w-0">
      <div className="mb-1 text-[10px] font-black uppercase tracking-widest text-red-600">
        {zone}
      </div>

      <h2 className="text-sm font-black text-slate-900 dark:text-white md:text-base">
        {title}
      </h2>

      <p className="mt-1 text-[11px] leading-4 text-slate-500 dark:text-slate-400">
        {description}
      </p>
    </div>
  </div>
);

const FieldLabel = ({
  children,
  required = false,
}: {
  children: React.ReactNode;
  required?: boolean;
}) => (
  <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wide text-slate-600 dark:text-slate-400">
    {children}
    {required && <span className="ml-1 text-red-500">*</span>}
  </label>
);

const Card = ({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div
    className={`overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-950 ${className}`}
  >
    {children}
  </div>
);

const SmallBadge = ({
  children,
  type = "default",
}: {
  children: React.ReactNode;
  type?: "default" | "blue" | "green" | "amber" | "red";
}) => {
  const classes = {
    default: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    blue: "bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300",
    green: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300",
    amber: "bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300",
    red: "bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-300",
  };

  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-wide ${classes[type]}`}
    >
      {children}
    </span>
  );
};

const Checkbox = ({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
}) => (
  <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className={checkboxClass}
    />
    <span>{label}</span>
  </label>
);


const toDateInputValue = (value: unknown): string => {
  if (!value) return "";
  const raw = String(value);
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? raw.slice(0, 10) : parsed.toISOString().slice(0, 10);
};

const normalizePacketArray = <T,>(value: unknown, fallback: () => T[]): T[] =>
  Array.isArray(value) && value.length > 0 ? value as T[] : fallback();

type DynamicSurveyValue = string | number | string[];

type DynamicCanvasItem = {
  moduleId: string;
  repeatCount: number;
  allowFieldAdd: boolean;
};

const dynamicModuleIcon = (code: string) => {
  switch (String(code || "").trim().toUpperCase()) {
    case "MOD-01":
      return Buildings;
    case "MOD-02":
      return WifiHigh;
    case "MOD-03":
      return NavigationArrow;
    case "MOD-04":
      return House;
    case "MOD-05":
      return Warning;
    case "MOD-06":
      return HardHat;
    default:
      return ClipboardText;
  }
};

const normalizeDynamicModule = (value: unknown): SurveyModule | null => {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return null;
  }

  const record = value as Record<string, unknown>;
  const id = String(record.id ?? "").trim();
  const code = String(record.code ?? "").trim();
  const name = String(record.name ?? "").trim();

  if (!id || !code || !name) {
    return null;
  }

  const sections: SurveyModule["sections"] = [];

  if (Array.isArray(record.sections)) {
    for (const sectionValue of record.sections) {
      if (!sectionValue || typeof sectionValue !== "object" || Array.isArray(sectionValue)) {
        continue;
      }

      const section = sectionValue as Record<string, unknown>;
      const fieldGroups: NonNullable<SurveyModule["sections"]>[number]["fieldGroups"] = [];

      if (Array.isArray(section.fieldGroups)) {
        for (const groupValue of section.fieldGroups) {
          if (!groupValue || typeof groupValue !== "object" || Array.isArray(groupValue)) {
            continue;
          }

          const group = groupValue as Record<string, unknown>;
          const fields: NonNullable<typeof fieldGroups>[number]["fields"] = [];

          if (Array.isArray(group.fields)) {
            for (const fieldValue of group.fields) {
              if (!fieldValue || typeof fieldValue !== "object" || Array.isArray(fieldValue)) {
                continue;
              }

              const field = fieldValue as Record<string, unknown>;
              const fieldType = String(field.type ?? "text");
              const allowedTypes = [
                "text",
                "number",
                "radio",
                "select",
                "textarea",
                "checkbox_group",
              ];
              const options = Array.isArray(field.options)
                ? field.options
                    .filter(
                      (option) =>
                        Boolean(option) &&
                        typeof option === "object" &&
                        !Array.isArray(option),
                    )
                    .map((option) => {
                      const item = option as Record<string, unknown>;
                      return {
                        id: String(item.id ?? "").trim(),
                        label: String(item.label ?? item.value ?? "").trim(),
                        value: String(item.value ?? item.label ?? "").trim(),
                      };
                    })
                : [];

              fields.push({
                id: String(field.id ?? `${id}-field-${fields.length + 1}`).trim(),
                name: String(field.name ?? field.id ?? "field").trim(),
                label: String(field.label ?? field.name ?? "Field").trim(),
                type: (allowedTypes.includes(fieldType)
                  ? fieldType
                  : "text") as SurveyField["type"],
                required: Boolean(field.required),
                placeholder: String(field.placeholder ?? "").trim(),
                helpText: String(field.helpText ?? "").trim(),
                unit: String(field.unit ?? "").trim(),
                options,
              });
            }
          }

          fieldGroups.push({
            id: String(group.id ?? `${id}-group-${fieldGroups.length + 1}`).trim(),
            title: String(group.title ?? "Assessment").trim(),
            fields,
          });
        }
      }

      sections.push({
        id: String(section.id ?? `${id}-section-${sections.length + 1}`).trim(),
        title: String(section.title ?? "Survey Checks").trim(),
        number: String(section.number ?? "").trim(),
        fieldGroups,
      });
    }
  }

  return {
    id,
    code,
    zone: String(record.zone ?? "").trim(),
    name,
    description: String(record.description ?? "").trim(),
    fields: Math.max(0, Number(record.fields) || 0),
    repeatable: Boolean(record.repeatable),
    unitLabel: String(record.unitLabel ?? "").trim(),
    hasConditional: Boolean(record.hasConditional),
    sections,
    templateNames: Array.isArray(record.templateNames)
      ? record.templateNames.map((item) => String(item).trim()).filter(Boolean)
      : [],
    icon: dynamicModuleIcon(code),
  };
};

function DynamicSurveyField({
  field,
  fieldKey,
  value,
  onChange,
}: {
  field: SurveyField;
  fieldKey: string;
  value: DynamicSurveyValue;
  onChange: (value: DynamicSurveyValue) => void;
}) {
  if (field.type === "radio") {
    return (
      <div className="space-y-2">
        <label className="block text-[10px] font-black uppercase tracking-wide text-slate-700 dark:text-slate-300">
          {field.label}
          {field.required ? <span className="ml-1 text-red-600">*</span> : null}
        </label>
        <div className="flex flex-wrap gap-4">
          {(field.options || []).map((option) => (
            <label
              key={`${field.id}-${option.id || option.value}`}
              className="inline-flex cursor-pointer items-center gap-2 text-xs text-slate-700 dark:text-slate-300"
            >
              <input
                type="radio"
                name={fieldKey}
                value={option.value}
                checked={String(value) === option.value}
                onChange={() => onChange(option.value)}
                className="h-4 w-4 border-slate-300 text-red-600 focus:ring-red-500"
              />
              <span>{option.label}</span>
            </label>
          ))}
        </div>
      </div>
    );
  }

  if (field.type === "checkbox_group") {
    const selected = Array.isArray(value) ? value : [];
    return (
      <div className="space-y-2">
        <label className="block text-[10px] font-black uppercase tracking-wide text-slate-700 dark:text-slate-300">
          {field.label}
          {field.required ? <span className="ml-1 text-red-600">*</span> : null}
        </label>
        <div className="flex flex-wrap gap-4">
          {(field.options || []).map((option) => (
            <label
              key={`${field.id}-${option.id || option.value}`}
              className="inline-flex cursor-pointer items-center gap-2 text-xs text-slate-700 dark:text-slate-300"
            >
              <input
                type="checkbox"
                checked={selected.includes(option.value)}
                onChange={(event) =>
                  onChange(
                    event.target.checked
                      ? Array.from(new Set([...selected, option.value]))
                      : selected.filter((item) => item !== option.value),
                  )
                }
                className={checkboxClass}
              />
              <span>{option.label}</span>
            </label>
          ))}
        </div>
      </div>
    );
  }

  if (field.type === "select") {
    return (
      <div className="space-y-2">
        <label className="block text-[10px] font-black uppercase tracking-wide text-slate-700 dark:text-slate-300">
          {field.label}
          {field.required ? <span className="ml-1 text-red-600">*</span> : null}
        </label>
        <select
          value={typeof value === "string" ? value : ""}
          onChange={(event) => onChange(event.target.value)}
          className={selectClass}
        >
          <option value="">Select an option</option>
          {(field.options || []).map((option) => (
            <option key={`${field.id}-${option.id || option.value}`} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    );
  }

  if (field.type === "textarea") {
    return (
      <div className="space-y-2">
        <label className="block text-[10px] font-black uppercase tracking-wide text-slate-700 dark:text-slate-300">
          {field.label}
          {field.required ? <span className="ml-1 text-red-600">*</span> : null}
        </label>
        <textarea
          value={typeof value === "string" ? value : String(value ?? "")}
          onChange={(event) => onChange(event.target.value)}
          className={`${textareaClass} min-h-[88px]`}
          placeholder={field.placeholder || undefined}
        />
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <label className="block text-[10px] font-black uppercase tracking-wide text-slate-700 dark:text-slate-300">
        {field.label}
        {field.required ? <span className="ml-1 text-red-600">*</span> : null}
      </label>
      <div className="relative">
        <input
          type={field.type === "number" ? "number" : "text"}
          value={typeof value === "number" ? value : String(value ?? "")}
          onChange={(event) => onChange(event.target.value)}
          className={inputClass}
          placeholder={field.placeholder || undefined}
        />
        {field.unit ? (
          <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-[10px] font-semibold text-slate-400">
            {field.unit}
          </span>
        ) : null}
      </div>
      {field.helpText ? (
        <p className="text-[10px] leading-4 text-slate-500 dark:text-slate-400">
          {field.helpText}
        </p>
      ) : null}
    </div>
  );
}

function DynamicSurveyModules({
  modules,
  canvas,
  values,
  onChange,
}: {
  modules: SurveyModule[];
  canvas: DynamicCanvasItem[];
  values: Record<string, DynamicSurveyValue>;
  onChange: (fieldId: string, value: DynamicSurveyValue) => void;
}) {
  if (canvas.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-white px-5 py-10 text-center text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-950">
        No survey modules are configured in this template.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
      {canvas.map((item, index) => {
        const module = modules.find((entry) => entry.id === item.moduleId);
        if (!module) return null;

        const Icon = dynamicModuleIcon(module.code);
        const sections = Array.isArray(module.sections) ? module.sections : [];
        const repeatCount = module.repeatable ? Math.max(1, item.repeatCount) : 1;

        return (
          <Card className="print-card" key={`${module.id}-${index}`}>
            <SectionHeader
              zone={`Module ${index + 1} • ${module.zone || "Survey"}`}
              title={module.name}
              description={module.description || "Configured survey module."}
              icon={Icon}
            />

            <div className="p-4">
              {sections.length === 0 ? (
                <div className="rounded-lg border border-dashed border-slate-300 px-4 py-8 text-center text-xs text-slate-500 dark:border-slate-700">
                  This module has no configured fields.
                </div>
              ) : (
                <div className="space-y-5">
                  {Array.from({ length: repeatCount }, (_, repeatIndex) => (
                    <div
                      key={`${module.id}-repeat-${repeatIndex}`}
                      className={module.repeatable ? "rounded-xl border border-slate-200 bg-slate-50/50 p-3 dark:border-slate-700 dark:bg-slate-900/30" : ""}
                    >
                      {module.repeatable ? (
                        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                          <div className="text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">
                            {module.unitLabel || "Record"} {repeatIndex + 1}
                          </div>
                          <span className="text-[9px] font-semibold text-slate-400">
                            {repeatIndex + 1} of {repeatCount}
                          </span>
                        </div>
                      ) : null}

                      <div className="space-y-5">
                        {sections.map((section, sectionIndex) => (
                          <section key={`${module.id}-${repeatIndex}-${section.id || sectionIndex}`}>
                            <div className="mb-3 flex items-center gap-2">
                              <span className="inline-flex h-5 min-w-5 items-center justify-center rounded bg-slate-100 px-1 text-[9px] font-black text-slate-500 dark:bg-slate-800 dark:text-slate-300">
                                {section.number || `${index + 1}.${sectionIndex + 1}`}
                              </span>
                              <h3 className="text-xs font-black uppercase tracking-wide text-slate-800 dark:text-slate-100">
                                {section.title}
                              </h3>
                            </div>

                            <div className="space-y-4">
                              {(section.fieldGroups || []).map((group, groupIndex) => (
                                <div
                                  key={`${module.id}-${repeatIndex}-${group.id || groupIndex}`}
                                  className="rounded-lg border border-slate-200 p-4 dark:border-slate-700"
                                >
                                  <div className="mb-4 text-[11px] font-black uppercase tracking-wide text-slate-600 dark:text-slate-300">
                                    {group.title}
                                  </div>

                                  <div className="space-y-4">
                                    {(group.fields || []).map((field) => {
                                      const fieldKey = module.repeatable
                                        ? `${field.id}__${repeatIndex}`
                                        : field.id;
                                      const initialValue =
                                        values[fieldKey] ??
                                        (repeatIndex === 0 ? values[field.id] : undefined) ??
                                        "";

                                      return (
                                        <DynamicSurveyField
                                          key={fieldKey}
                                          field={field}
                                          fieldKey={fieldKey}
                                          value={initialValue}
                                          onChange={(value) => onChange(fieldKey, value)}
                                        />
                                      );
                                    })}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </section>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}

export default function SeiretsuFieldSurveyPacket() {
  const [project, setProject] = useState<ProjectDetails>(initialProject);
  const [facilityChecks, setFacilityChecks] = useState<FacilityCheck[]>(createFacilityChecks);
  const [odfRows, setOdfRows] = useState<OdfRow[]>(createOdfRows);
  const [routeName, setRouteName] = useState("");
  const [startDemarcation, setStartDemarcation] = useState("");
  const [endDemarcation, setEndDemarcation] = useState("");
  const [poleRecords, setPoleRecords] = useState<PoleRecord[]>(createPoleRecords);
  const [routePhotos, setRoutePhotos] = useState("");
  const [routeConstraints, setRouteConstraints] = useState("");
  const [napStations, setNapStations] = useState<NapStation[]>(createNapStations);
  const [premises, setPremises] = useState({
    address: "",
    customer: "",
    phone: "",
    dropMethod: "",
    napId: "",
    dropLength: "",
    roadCrossing: "",
    roadClearance: "",
    demarcationHardware: "",
    wallSubstrate: "",
    demarcationBox: "",
    internalRouting: "",
    outlet: "",
    routerLocation: "",
    sketch: "",
    photos: "",
    authorization: "",
  });
  const [defects, setDefects] = useState<Defect[]>(createDefects);
  const [safetyChecklist, setSafetyChecklist] = useState<ChecklistItem[]>(
    createChecklist([
      "High-visibility safety vests",
      "Hard hats",

    ]),
  );
  const [opticalChecklist, setOpticalChecklist] = useState<ChecklistItem[]>(
    createChecklist([
      "Calibrated Optical Power Meter (OPM)",
      "Visual Fault Locator (VFL / Red Laser)",

    ]),
  );
  const [surveyChecklist, setSurveyChecklist] = useState<ChecklistItem[]>(
    createChecklist([
      "Laser rangefinder / measuring wheel",
      "GPS unit or geotagging mobile tablet",
      "Telescopic measuring stick (pole height / clearance)",
      "Heavy-duty clipboard & water-resistant pens",
    ]),
  );
  const [toolsChecklist, setToolsChecklist] = useState<ChecklistItem[]>(
    createChecklist([
      "28-ft fiberglass extension ladder",
      "216B can wrench / security keys for NAPs / pedestals",
      "Flashlights / headlamps",
      "Cable ties, labels and marker tags",
    ]),
  );
  const [signOff, setSignOff] = useState({
    leadSurveyor: "",
    leadDate: "",
    reviewer: "",
    reviewerDate: "",
  });

  const updateProject = (key: keyof ProjectDetails, value: string) => {
    setProject((prev) => ({ ...prev, [key]: value }));
  };

  const updateFacility = (index: number, key: keyof FacilityCheck, value: string | boolean) => {
    setFacilityChecks((prev) =>
      prev.map((item, i) => (i === index ? { ...item, [key]: value } : item)),
    );
  };

  const updateOdf = (index: number, key: keyof OdfRow, value: string) => {
    setOdfRows((prev) =>
      prev.map((row, i) => (i === index ? { ...row, [key]: value } : row)),
    );
  };

  const updatePole = (index: number, key: keyof PoleRecord, value: string | string[]) => {
    setPoleRecords((prev) =>
      prev.map((record, i) => (i === index ? { ...record, [key]: value } : record)),
    );
  };

  const updateNap = (index: number, key: keyof NapStation, value: string) => {
    setNapStations((prev) =>
      prev.map((station, i) => (i === index ? { ...station, [key]: value } : station)),
    );
  };

  const updateDefect = (index: number, key: keyof Defect, value: string) => {
    setDefects((prev) =>
      prev.map((defect, i) => (i === index ? { ...defect, [key]: value } : defect)),
    );
  };

  const updateChecklist = (
    setter: React.Dispatch<React.SetStateAction<ChecklistItem[]>>,
    index: number,
    key: keyof ChecklistItem,
    value: string,
  ) => {
    setter((prev) =>
      prev.map((item, i) => (i === index ? { ...item, [key]: value } : item)),
    );
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSave = () => {
    const packet = {
      project,
      facilityChecks,
      odfRows,
      route: {
        routeName,
        startDemarcation,
        endDemarcation,
        poleRecords,
        routePhotos,
        routeConstraints,
      },
      napStations,
      premises,
      defects,
      safetyChecklist,
      opticalChecklist,
      surveyChecklist,
      toolsChecklist,
      signOff,
      dynamicFieldValues,
    };

    console.log("SEIRETSU SURVEY PACKET", packet);
    window.alert("Survey packet data prepared successfully.");
    setTimeout(() => {
      navigate("/quotation");
    }, 1000);
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset the complete survey packet?")) {
      setProject(initialProject);
      setFacilityChecks(createFacilityChecks());
      setOdfRows(createOdfRows());
      setRouteName("");
      setStartDemarcation("");
      setEndDemarcation("");
      setPoleRecords(createPoleRecords());
      setRoutePhotos("");
      setRouteConstraints("");
      setNapStations(createNapStations());
      setPremises({
        address: "",
        customer: "",
        phone: "",
        dropMethod: "",
        napId: "",
        dropLength: "",
        roadCrossing: "",
        roadClearance: "",
        demarcationHardware: "",
        wallSubstrate: "",
        demarcationBox: "",
        internalRouting: "",
        outlet: "",
        routerLocation: "",
        sketch: "",
        photos: "",
        authorization: "",
      });
      setDefects(createDefects());
      setSafetyChecklist(
        createChecklist([
          "High-visibility safety vests",
          "Hard hats",
          "Safety glasses",
          "Traffic cones & warning signs",
          "Insulated gloves",
        ]),
      );
      setOpticalChecklist(
        createChecklist([
          "Calibrated Optical Power Meter (OPM)",
          "Visual Fault Locator (VFL / Red Laser)",
          "OTDR unit with launch cable",
          "Fiber scope / connector inspection probe",
        ]),
      );
      setSurveyChecklist(
        createChecklist([
          "Laser rangefinder / measuring wheel",
          "GPS unit or geotagging mobile tablet",
          "Telescopic measuring stick (pole height / clearance)",
          "Heavy-duty clipboard & water-resistant pens",
        ]),
      );
      setToolsChecklist(
        createChecklist([
          "28-ft fiberglass extension ladder",
          "216B can wrench / security keys for NAPs / pedestals",
          "Flashlights / headlamps",
          "Cable ties, labels and marker tags",
        ]),
      );
      setSignOff({
        leadSurveyor: "",
        leadDate: "",
        reviewer: "",
        reviewerDate: "",
      });
    }
  };
const navigate = useNavigate();
const [searchParams] = useSearchParams();
const routeParams = useParams<{ id?: string; templateId?: string }>();

const openedFromSurveyList =
    searchParams.get("from") === "survey_report";
const isQuotationSurveyForm =
    window.location.pathname === "/quotation/survey-form";
const quotationId = String(searchParams.get("quotationId") || "").trim() || null;
const templateId = String(
    searchParams.get("templateId") || routeParams.templateId || routeParams.id || "",
).trim() || null;
const [templateName, setTemplateName] = useState("Survey Template");
const [templateLoading, setTemplateLoading] = useState(false);
const [templateModules, setTemplateModules] = useState<SurveyModule[]>([]);
const [templateCanvas, setTemplateCanvas] = useState<DynamicCanvasItem[]>([]);
const [dynamicFieldValues, setDynamicFieldValues] = useState<Record<string, DynamicSurveyValue>>({});
const [templateError, setTemplateError] = useState("");
const [quotationStatus, setQuotationStatus] = useState("");
const [quotationLoading, setQuotationLoading] = useState(false);
const [quotationReviewing, setQuotationReviewing] = useState(false);

const applySavedQuotationSurvey = (savedResponse: any) => {
    const packet = savedResponse && typeof savedResponse === "object" ? savedResponse : {};
    const savedProject = packet.project && typeof packet.project === "object" ? packet.project : {};

    setProject({
      ...initialProject,
      leadContractor: String(savedProject.leadContractor ?? ""),
      surveyDate: toDateInputValue(savedProject.surveyDate),
      weather: String(savedProject.weather ?? ""),
      parish: String(savedProject.parish ?? ""),
      vehicle: String(savedProject.vehicle ?? ""),
      crewLead: String(savedProject.crewLead ?? ""),
      technician2: String(savedProject.technician2 ?? ""),
    });
    setFacilityChecks(normalizePacketArray(packet.facilityChecks, createFacilityChecks));
    setOdfRows(normalizePacketArray(packet.odfRows, createOdfRows));

    const route = packet.route && typeof packet.route === "object" ? packet.route : {};
    setRouteName(String(route.routeName ?? ""));
    setStartDemarcation(String(route.startDemarcation ?? ""));
    setEndDemarcation(String(route.endDemarcation ?? ""));
    setPoleRecords(normalizePacketArray(route.poleRecords, createPoleRecords));
    setRoutePhotos(String(route.routePhotos ?? ""));
    setRouteConstraints(String(route.routeConstraints ?? ""));

    setNapStations(normalizePacketArray(packet.napStations, createNapStations));

    const savedPremises = packet.premises && typeof packet.premises === "object" ? packet.premises : {};
    setPremises((previous) => ({
      ...previous,
      ...savedPremises,
    }));

    setDefects(normalizePacketArray(packet.defects, createDefects));
    setSafetyChecklist(normalizePacketArray(packet.safetyChecklist, () => createChecklist([
      "High-visibility safety vests",
      "Hard hats",
      "Safety glasses",
      "Traffic cones & warning signs",
      "Insulated gloves",
    ])));
    setOpticalChecklist(normalizePacketArray(packet.opticalChecklist, () => createChecklist([
      "Calibrated Optical Power Meter (OPM)",
      "Visual Fault Locator (VFL / Red Laser)",
      "OTDR unit with launch cable",
      "Fiber scope / connector inspection probe",
    ])));
    setSurveyChecklist(normalizePacketArray(packet.surveyChecklist, () => createChecklist([
      "Laser rangefinder / measuring wheel",
      "GPS unit or geotagging mobile tablet",
      "Telescopic measuring stick (pole height / clearance)",
      "Heavy-duty clipboard & water-resistant pens",
    ])));
    setToolsChecklist(normalizePacketArray(packet.toolsChecklist, () => createChecklist([
      "28-ft fiberglass extension ladder",
      "216B can wrench / security keys for NAPs / pedestals",
      "Flashlights / headlamps",
      "Cable ties, labels and marker tags",
    ])));

    const savedSignOff = packet.signOff && typeof packet.signOff === "object" ? packet.signOff : {};
    setSignOff((previous) => ({
      ...previous,
      ...savedSignOff,
      leadDate: toDateInputValue(savedSignOff.leadDate),
      reviewerDate: toDateInputValue(savedSignOff.reviewerDate),
    }));

    const savedDynamic = packet.dynamicFieldValues;
    setDynamicFieldValues(
      savedDynamic && typeof savedDynamic === "object" && !Array.isArray(savedDynamic)
        ? savedDynamic as Record<string, DynamicSurveyValue>
        : {},
    );
};

useEffect(() => {
    if (!isQuotationSurveyForm || !quotationId) {
      setQuotationStatus("");
      return;
    }

    let active = true;
    setQuotationLoading(true);
    setTemplateError("");

    void getQuotationSurvey(quotationId)
      .then((result) => {
        if (!active) return;
        const quotation = result?.quotation || {};
        setQuotationStatus(String(quotation.status || ""));

        if (result?.template) {
          setTemplateName(String(result.template.name || "Survey Template"));
          const schema = result.template.schema && typeof result.template.schema === "object" && !Array.isArray(result.template.schema)
            ? result.template.schema as Record<string, any>
            : {};
          const rawModules = Array.isArray(schema.modules) ? schema.modules : [];
          const normalizedModules = rawModules
            .map(normalizeDynamicModule)
            .filter((module): module is SurveyModule => Boolean(module));
          const rawCanvas = Array.isArray(schema.canvas) ? schema.canvas : [];
          const normalizedCanvas: DynamicCanvasItem[] = rawCanvas
            .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === "object" && !Array.isArray(item))
            .map((item) => ({
              moduleId: String(item.moduleId ?? "").trim(),
              repeatCount: Math.max(1, Number(item.repeatCount) || 1),
              allowFieldAdd: Boolean(item.allowFieldAdd),
            }))
            .filter((item) => item.moduleId);
          const moduleIds = new Set(normalizedModules.map((module) => module.id));
          setTemplateModules(normalizedModules);
          setTemplateCanvas(normalizedCanvas.filter((item) => moduleIds.has(item.moduleId)));
        }

        applySavedQuotationSurvey(result?.response);
      })
      .catch((error: any) => {
        if (!active) return;
        setQuotationStatus("");
        setTemplateError(error?.response?.data?.message || error?.message || "Unable to load quotation survey.");
      })
      .finally(() => {
        if (active) setQuotationLoading(false);
      });

    return () => {
      active = false;
    };
  }, [isQuotationSurveyForm, quotationId]);

const handleQuotationSurveyReview = async (decision: "approve" | "reject") => {
    if (!quotationId || quotationReviewing) return;

    let remarks = "";
    if (decision === "reject") {
      const entered = window.prompt("Enter rejection remarks:");
      if (entered === null) return;
      remarks = entered.trim();
      if (!remarks) {
        window.alert("Rejection remarks are required.");
        return;
      }
    }

    try {
      setQuotationReviewing(true);
      const result = await reviewQuotationSurvey(quotationId, decision, remarks);
      setQuotationStatus(String(result?.status || (decision === "approve" ? "Form Approved" : "Form Rejected")));
      window.alert(decision === "approve" ? "Survey form approved successfully." : "Survey form rejected successfully.");
      navigate("/quotation");
    } catch (error: any) {
      window.alert(error?.response?.data?.message || error?.message || "Unable to review the survey form.");
    } finally {
      setQuotationReviewing(false);
    }
};

useEffect(() => {
    if (!templateId || !/^[a-f\d]{24}$/i.test(templateId)) {
      setTemplateName("Survey Template");
      setTemplateModules([]);
      setTemplateCanvas([]);
      setDynamicFieldValues({});
      setTemplateError("");
      return;
    }

    let active = true;
    const controller = new AbortController();
    setTemplateLoading(true);
    setTemplateError("");

    void getSurveyTemplate(templateId, controller.signal)
      .then((template) => {
        if (!active || controller.signal.aborted) return;

        const schema =
          template.schema &&
          typeof template.schema === "object" &&
          !Array.isArray(template.schema)
            ? template.schema
            : {};

        const rawModules = Array.isArray(schema.modules) ? schema.modules : [];
        const normalizedModules = rawModules
          .map(normalizeDynamicModule)
          .filter((module): module is SurveyModule => Boolean(module));

        const rawCanvas = Array.isArray(schema.canvas) ? schema.canvas : [];
        const normalizedCanvas: DynamicCanvasItem[] = rawCanvas
          .filter(
            (item): item is Record<string, unknown> =>
              Boolean(item) && typeof item === "object" && !Array.isArray(item),
          )
          .map((item) => ({
            moduleId: String(item.moduleId ?? "").trim(),
            repeatCount: Math.max(1, Number(item.repeatCount) || 1),
            allowFieldAdd: Boolean(item.allowFieldAdd),
          }))
          .filter((item) => item.moduleId);

        const moduleIds = new Set(normalizedModules.map((module) => module.id));
        const usableCanvas = normalizedCanvas.filter((item) => moduleIds.has(item.moduleId));

        const storedValues =
          schema.formValues &&
          typeof schema.formValues === "object" &&
          !Array.isArray(schema.formValues)
            ? schema.formValues
            : {};

        setTemplateName(String(template.name || "Survey Template"));
        setTemplateModules(normalizedModules);
        setTemplateCanvas(usableCanvas);
        setDynamicFieldValues(storedValues as Record<string, DynamicSurveyValue>);
      })
      .catch((error: unknown) => {
        if (!active) return;
        const value = error as { name?: string; code?: string; message?: string } | null;
        if (
          value?.name === "CanceledError" ||
          value?.code === "ERR_CANCELED" ||
          value?.name === "AbortError"
        ) {
          return;
        }

        setTemplateModules([]);
        setTemplateCanvas([]);
        setDynamicFieldValues({});
        setTemplateError(value?.message || "Unable to load the selected survey template.");
      })
      .finally(() => {
        if (active) setTemplateLoading(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [templateId]);

  const updateDynamicFieldValue = (fieldId: string, value: DynamicSurveyValue) => {
    setDynamicFieldValues((previous) => ({
      ...previous,
      [fieldId]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 dark:bg-slate-950 dark:text-slate-100">
     
    
      <div className="print-hidden top-0 z-50 border-b border-slate-200 bg-white/95 shadow-sm backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
        <div className="mx-auto flex max-w-[1700px] items-center justify-between gap-3 px-4 py-3 lg:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <button
                type="button"
               onClick={() =>
                    navigate(
                        openedFromSurveyList
                            ? "/survey_report"
                            : "/quotation"
                    )
                }
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-600 transition-colors hover:bg-slate-100 hover:text-red-600 dark:text-slate-300 dark:hover:bg-slate-800"
                title="Back to Quotation"
                aria-label="Back to Quotation"
            >
                <ArrowLeft size={20} weight="bold" />
            </button>

            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white">
                <ClipboardText size={22} weight="duotone" />
            </div>

            <div className="min-w-0">
                <div className="flex min-w-0 items-center gap-2">
                  <p className="truncate text-sm font-black text-slate-900 dark:text-white">
                      {templateLoading || quotationLoading ? "Loading survey template…" : templateName}
                  </p>
                  {isQuotationSurveyForm && quotationStatus ? (
                    <span className={`inline-flex shrink-0 items-center rounded-full px-2.5 py-1 text-[9px] font-bold ${
                      quotationStatus === "Form Approved" ? "bg-emerald-50 text-emerald-700" :
                      quotationStatus === "Form Rejected" ? "bg-red-50 text-red-700" :
                      "bg-amber-50 text-amber-700"
                    }`}>
                      {quotationStatus}
                    </span>
                  ) : null}
                </div>
                <p className="truncate text-[10px] font-semibold uppercase tracking-widest text-slate-500">
                    Field Engineering Survey Packet
                </p>
            </div>
        </div>

          <div className="flex shrink-0 items-center gap-2">
            {/* <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
            >
              <ArrowCounterClockwise size={16} />
              <span className="hidden sm:inline">Reset</span>
            </button> */}

           {isQuotationSurveyForm && quotationId && quotationStatus === "Form Submitted" ? (
              <>
                <button
                  type="button"
                  onClick={() => void handleQuotationSurveyReview("reject")}
                  disabled={quotationReviewing}
                  className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <XCircle size={16} weight="bold" />
                  <span className="hidden sm:inline">Reject</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleQuotationSurveyReview("approve")}
                  disabled={quotationReviewing}
                  className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-2 text-xs font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <CheckCircle size={16} weight="bold" />
                  <span className="hidden sm:inline">Approve</span>
                </button>
              </>
            ) : null}

            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900"
            >
              <Printer size={16} />
              <span className="hidden sm:inline">Print</span>
            </button>
          </div>
        </div>
      </div>

      <main className="print-page mx-auto w-full max-w-[1700px] px-0 py-4 sm:px-5 lg:px-0">
        <Card className="print-card mb-4">
          <div className="relative overflow-hidden bg-slate-800 px-5 py-5 text-white md:px-6">
            <div className="absolute right-0 top-0 h-40 w-40 rounded-full bg-red-400/10 blur-3xl" />

            <div className="relative flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
              <div>
                <div className="mb-1 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-red-200">
                  <WifiHigh size={16} weight="bold" />
                  Seiretsu FTTH Network
                </div>

                <h1 className="text-xl font-black tracking-tight md:text-2xl">
                  FIELD ENGINEERING SURVEY PACKET
                </h1>

                <p className="mt-1 max-w-3xl text-xs font-medium text-red-100">
                  {templateLoading ? "Loading survey template…" : `${templateName} Field Survey Packet`}
                </p>
              </div>

              <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
                <div className="text-[10px] font-black uppercase tracking-widest text-red-200">
                  Controlled Field Form
                </div>
                <div className="mt-1 text-sm font-bold">{templateName}</div>
                <div className="mt-1 flex items-center gap-2 text-[11px] text-red-100">
                  <CalendarBlank size={13} />
                  Survey Date:
                 <span className="font-bold">
                      {project.surveyDate
                          ? new Date(project.surveyDate).toLocaleDateString("en-GB")
                          : "—"}
                  </span>
              </div>
              </div>  
            </div>
          </div>

          <div className="p-4 md:p-5">
            <div className="mb-3 flex items-center gap-2">
              <Buildings size={16} className="text-red-600" weight="duotone" />
              <h2 className="text-xs font-black uppercase tracking-widest text-slate-900 dark:text-white">
                Project Control
              </h2>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <FieldLabel>Lead Contractor</FieldLabel>
                <input
                  value={project.leadContractor}
                  onChange={(e) => updateProject("leadContractor", e.target.value)}
                  className={inputClass}
                  placeholder="Lead contractor"
                />
              </div>

              <div>
                <FieldLabel>Survey Date</FieldLabel>
                <input
                  type="date"
                  value={project.surveyDate}
                  onChange={(e) => updateProject("surveyDate", e.target.value)}
                  className={inputClass}
                />
              </div>

              <div>
                <FieldLabel>Weather / Conditions</FieldLabel>
                <input
                  value={project.weather}
                  onChange={(e) => updateProject("weather", e.target.value)}
                  className={inputClass}
                  placeholder="Sunny / Rain / Cloudy"
                />
              </div>

              <div>
                <FieldLabel>Parish / Service Area</FieldLabel>
                <input
                  value={project.parish}
                  onChange={(e) => updateProject("parish", e.target.value)}
                  className={inputClass}
                  placeholder="Parish / service area"
                />
              </div>

              <div>
                <FieldLabel>Vehicle & Plate #</FieldLabel>
                <input
                  value={project.vehicle}
                  onChange={(e) => updateProject("vehicle", e.target.value)}
                  className={inputClass}
                  placeholder="Vehicle / plate"
                />
              </div>

              <div>
                <FieldLabel>Survey Crew Lead</FieldLabel>
                <input
                  value={project.crewLead}
                  onChange={(e) => updateProject("crewLead", e.target.value)}
                  className={inputClass}
                  placeholder="Crew lead name"
                />
              </div>

              <div className="sm:col-span-2">
                <FieldLabel>Field Technician 2</FieldLabel>
                <input
                  value={project.technician2}
                  onChange={(e) => updateProject("technician2", e.target.value)}
                  className={inputClass}
                  placeholder="Technician name"
                />
              </div>
            </div>
          </div>
        </Card>

        {templateId ? (
          templateError ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              {templateError}
            </div>
          ) : templateLoading ? (
            <div className="rounded-xl border border-slate-200 bg-white px-4 py-10 text-center text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-950">
              Loading saved survey template…
            </div>
          ) : (
            <DynamicSurveyModules
              modules={templateModules}
              canvas={templateCanvas}
              values={dynamicFieldValues}
              onChange={updateDynamicFieldValue}
            />
          )
        ) : (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="space-y-4">
            <Card className="print-card">
              
              <SectionHeader
                zone="Module 1 • Zone A"
                title="Central Office & Headend Assessment"
                description="Core transmission point, OLT landing, ODF racks and cable-vault egress."
                icon={Buildings}
                
              />

              <div className="p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Cloud size={16} className="text-red-600" weight="duotone" />
                  <h3 className="text-xs font-black">
                    1.1 General Facility & Environmental Checks
                  </h3>
                </div>

                <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
                  <table className="w-full min-w-[700px] text-left">
                    <thead className="bg-slate-50 dark:bg-slate-900">
                      <tr>
                        <th className="px-3 py-2 text-[9px] font-black uppercase tracking-wider">
                          Assessment Item
                        </th>
                        <th className="px-3 py-2 text-[9px] font-black uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-3 py-2 text-[9px] font-black uppercase tracking-wider">
                          Observations / Measurements
                        </th>
                        <th className="px-3 py-2 text-[9px] font-black uppercase tracking-wider">
                          Action
                        </th>
                      </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                      {facilityChecks.map((check, index) => (
                        <tr key={check.item}>
                          <td className="px-3 py-2 text-[11px] font-bold">
                            {check.item}
                          </td>

                          <td className="px-3 py-2">
                            <div className="flex gap-2">
                              <label className="flex items-center gap-1 text-[11px]">
                                <input
                                  type="radio"
                                  name={`facility-${index}`}
                                  checked={check.status === "Pass"}
                                  onChange={() => updateFacility(index, "status", "Pass")}
                                  className="text-emerald-600"
                                />
                                Pass
                              </label>

                              <label className="flex items-center gap-1 text-[11px]">
                                <input
                                  type="radio"
                                  name={`facility-${index}`}
                                  checked={check.status === "Fail"}
                                  onChange={() => updateFacility(index, "status", "Fail")}
                                  className="text-red-600"
                                />
                                Fail
                              </label>
                            </div>
                          </td>

                          <td className="px-3 py-2">
                            <input
                              value={check.observation}
                              onChange={(e) =>
                                updateFacility(index, "observation", e.target.value)
                              }
                              className={inputClass}
                              placeholder="Observation"
                            />
                          </td>

                          <td className="px-3 py-2">
                            <Checkbox
                              checked={check.action}
                              onChange={(value) => updateFacility(index, "action", value)}
                              label="Required"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mb-2 mt-5 flex items-center gap-2">
                  <h3 className="text-xs font-black">
                    1.2 ODF Termination & Optical Verification Log
                  </h3>
                </div>

                <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
                  <table className="w-full min-w-[700px] text-left">
                    <thead className="bg-slate-50 dark:bg-slate-900">
                      <tr>
                        {["Rack / ODF", "Tray / Port", "Fiber ID / Color", "Core", "Power (dBm)", "Connector", "Code"].map(
                          (header) => (
                            <th
                              key={header}
                              className="px-2 py-2 text-[9px] font-black uppercase tracking-wider"
                            >
                              {header}
                            </th>
                          ),
                        )}
                      </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                      {odfRows.map((row, index) => (
                        <tr key={`${row.rack}-${index}`}>
                          <td className="px-2 py-2">
                            <span className="text-[11px] font-black">{row.rack}</span>
                          </td>

                          <td className="px-2 py-2">
                            <input
                              value={row.port}
                              onChange={(e) => updateOdf(index, "port", e.target.value)}
                              className={inputClass}
                              placeholder="Port"
                            />
                          </td>

                          <td className="px-2 py-2">
                            <input
                              value={row.fiber}
                              onChange={(e) => updateOdf(index, "fiber", e.target.value)}
                              className={inputClass}
                              placeholder="Fiber"
                            />
                          </td>

                          <td className="px-2 py-2">
                            <input
                              value={row.core}
                              onChange={(e) => updateOdf(index, "core", e.target.value)}
                              className={inputClass}
                              placeholder="Core"
                            />
                          </td>

                          <td className="px-2 py-2">
                            <input
                              value={row.power}
                              onChange={(e) => updateOdf(index, "power", e.target.value)}
                              className={inputClass}
                              placeholder="dBm"
                            />
                          </td>

                          <td className="px-2 py-2">
                            <select
                              value={row.connector}
                              onChange={(e) => updateOdf(index, "connector", e.target.value)}
                              className={selectClass}
                            >
                              <option value="">Select</option>
                              <option value="SC/APC">SC/APC</option>
                              <option value="LC/UPC">LC/UPC</option>
                            </select>
                          </td>

                          <td className="px-2 py-2">
                            <SmallBadge type="blue">{row.code}</SmallBadge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div>
                    <FieldLabel>OTDR Trace / File IDs</FieldLabel>
                    <input className={inputClass} placeholder="OTDR trace / file IDs" />
                  </div>

                  <div>
                    <FieldLabel>Photo IDs</FieldLabel>
                    <input className={inputClass} placeholder="Photo IDs" />
                  </div>

                  <div className="md:col-span-2">
                    <FieldLabel>Additional CO Notes</FieldLabel>
                    <textarea
                      className={textareaClass}
                      rows={2}
                      placeholder="Additional CO notes"
                    />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="print-card">
              <SectionHeader
                zone="Module 2 • Zone B"
                title="OSP Route & Pole Survey Log"
                description="Use while driving or walking feeder and distribution corridors."
                icon={RoadHorizon}
              />

              <div className="p-4">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  <div>
                    <FieldLabel>Route Name / Feeder Trunk</FieldLabel>
                    <input
                      value={routeName}
                      onChange={(e) => setRouteName(e.target.value)}
                      className={inputClass}
                    />
                  </div>

                  <div>
                    <FieldLabel>Start Demarcation</FieldLabel>
                    <input
                      value={startDemarcation}
                      onChange={(e) => setStartDemarcation(e.target.value)}
                      className={inputClass}
                    />
                  </div>

                  <div>
                    <FieldLabel>End Demarcation</FieldLabel>
                    <input
                      value={endDemarcation}
                      onChange={(e) => setEndDemarcation(e.target.value)}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  {poleRecords.map((record, index) => (
                    <div
                      key={index}
                      className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700"
                    >
                      <div className="flex items-center justify-between bg-slate-50 px-3 py-2 dark:bg-slate-900">
                        <div className="flex items-center gap-2">
                          <Signpost size={16} className="text-red-600" weight="duotone" />
                          <h3 className="text-[10px] font-black uppercase tracking-widest">
                            Pole / Structure {index + 1}
                          </h3>
                        </div>

                        <SmallBadge type="red">B{index + 1}</SmallBadge>
                      </div>

                      <div className="grid grid-cols-1 gap-3 p-3 md:grid-cols-2 lg:grid-cols-3">
                        <div>
                          <FieldLabel>Pole # / GPS</FieldLabel>
                          <input
                            value={record.poleGps}
                            onChange={(e) => updatePole(index, "poleGps", e.target.value)}
                            className={inputClass}
                            placeholder="P-______ / GPS"
                          />
                        </div>

                        <div>
                          <FieldLabel>Pole Type</FieldLabel>
                          <select
                            value={record.poleType}
                            onChange={(e) => updatePole(index, "poleType", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select pole type</option>
                            <option value="JPS Wood">JPS Wood</option>
                            <option value="Concrete">Concrete</option>
                            <option value="Other">Other</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Fiber Span</FieldLabel>
                          <div className="relative">
                            <Ruler size={15} className="absolute left-3 top-3 text-slate-400" />
                            <input
                              value={record.fiberSpan}
                              onChange={(e) => updatePole(index, "fiberSpan", e.target.value)}
                              className={`${inputClass} pl-9`}
                              placeholder="______ m"
                            />
                          </div>
                        </div>

                        <div>
                          <FieldLabel>Cable Condition</FieldLabel>
                          <select
                            value={record.cableCondition}
                            onChange={(e) => updatePole(index, "cableCondition", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select condition</option>
                            <option value="Good">Good</option>
                            <option value="Sagging">Sagging</option>
                            <option value="Lashing broken">Lashing broken</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Enclosure</FieldLabel>
                          <input
                            value={record.enclosureId}
                            onChange={(e) => updatePole(index, "enclosureId", e.target.value)}
                            className={inputClass}
                            placeholder="FOSC Dome ID"
                          />
                        </div>

                        <div>
                          <FieldLabel>Clearance / Hazards</FieldLabel>
                          <div className="space-y-1 pt-1">
                            <Checkbox
                              checked={record.clearance.includes("Low clearance")}
                              onChange={(checked) => {
                                const values = checked
                                  ? [...record.clearance, "Low clearance"]
                                  : record.clearance.filter((x) => x !== "Low clearance");
                                updatePole(index, "clearance", values);
                              }}
                              label="Low clearance"
                            />

                            <Checkbox
                              checked={record.clearance.includes("Tree overgrowth")}
                              onChange={(checked) => {
                                const values = checked
                                  ? [...record.clearance, "Tree overgrowth"]
                                  : record.clearance.filter((x) => x !== "Tree overgrowth");
                                updatePole(index, "clearance", values);
                              }}
                              label="Tree overgrowth"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-2 border-t border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-900/40 md:grid-cols-2">
                        <div>
                          <FieldLabel>Applicable Codes</FieldLabel>
                          <div className="flex flex-wrap gap-1.5">
                            <SmallBadge type="blue">B1-CAB-FEED</SmallBadge>
                            <SmallBadge type="blue">B2-HARD-POLE</SmallBadge>
                          </div>
                        </div>

                        <div>
                          <FieldLabel>Closure Codes</FieldLabel>
                          <div className="flex flex-wrap gap-1.5">
                            <SmallBadge type="default">B3-CLOS-OSP</SmallBadge>
                            <SmallBadge type="default">B4-CLOS-PREP</SmallBadge>
                            <SmallBadge type="default">B5-SPF-FUS</SmallBadge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div>
                    <FieldLabel>Photo / Video IDs</FieldLabel>
                    <input
                      value={routePhotos}
                      onChange={(e) => setRoutePhotos(e.target.value)}
                      className={inputClass}
                    />
                  </div>

                  <div>
                    <FieldLabel>Access, Traffic or Utility Constraints</FieldLabel>
                    <textarea
                      value={routeConstraints}
                      onChange={(e) => setRouteConstraints(e.target.value)}
                      className={textareaClass}
                      rows={2}
                    />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="print-card">
              <SectionHeader
                zone="Module 3 • Zone C"
                title="Network Access Point Inspection"
                description="Complete one station block for each NAP / FDB inspected."
                icon={WifiHigh}
              />

              <div className="p-4">
                <div className="space-y-3">
                  {napStations.map((station, index) => (
                    <div
                      key={index}
                      className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700"
                    >
                      <div className="flex items-center justify-between bg-slate-50 px-3 py-2 dark:bg-slate-900">
                        <div className="flex items-center gap-2">
                          <MapPin size={16} className="text-red-600" weight="duotone" />
                          <h3 className="text-[10px] font-black uppercase tracking-widest">
                            NAP Station {index + 1}
                          </h3>
                        </div>

                        <SmallBadge type="blue">C{index + 1}</SmallBadge>
                      </div>

                      <div className="grid grid-cols-1 gap-3 p-3 md:grid-cols-2 lg:grid-cols-3">
                        <div>
                          <FieldLabel>NAP Terminal ID / Tag</FieldLabel>
                          <input
                            value={station.terminalId}
                            onChange={(e) => updateNap(index, "terminalId", e.target.value)}
                            className={inputClass}
                            placeholder="NAP-________-________"
                          />
                        </div>

                        <div>
                          <FieldLabel>Pole / Structure #</FieldLabel>
                          <input
                            value={station.pole}
                            onChange={(e) => updateNap(index, "pole", e.target.value)}
                            className={inputClass}
                            placeholder="Pole"
                          />
                        </div>

                        <div>
                          <FieldLabel>Enclosure Physical Condition</FieldLabel>
                          <select
                            value={station.physical}
                            onChange={(e) => updateNap(index, "physical", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select</option>
                            <option value="Intact">Intact</option>
                            <option value="Damaged">Damaged</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Weather Seal / Grommet Quality</FieldLabel>
                          <select
                            value={station.seal}
                            onChange={(e) => updateNap(index, "seal", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select</option>
                            <option value="Weather-tight">Weather-tight</option>
                            <option value="Leaking">Leaking</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Splitter Ratio Installed</FieldLabel>
                          <select
                            value={station.splitter}
                            onChange={(e) => updateNap(index, "splitter", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select</option>
                            <option value="1:8">1:8</option>
                            <option value="1:16">1:16</option>
                            <option value="1:32">1:32</option>
                          </select>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <FieldLabel>Used</FieldLabel>
                            <input
                              value={station.used}
                              onChange={(e) => updateNap(index, "used", e.target.value)}
                              className={inputClass}
                              placeholder="Used"
                            />
                          </div>

                          <div>
                            <FieldLabel>Free</FieldLabel>
                            <input
                              value={station.free}
                              onChange={(e) => updateNap(index, "free", e.target.value)}
                              className={inputClass}
                              placeholder="Free"
                            />
                          </div>
                        </div>

                        <div>
                          <FieldLabel>Optical Input Power (1310/1490 nm)</FieldLabel>
                          <input
                            value={station.inputPower}
                            onChange={(e) => updateNap(index, "inputPower", e.target.value)}
                            className={inputClass}
                            placeholder="________________ dBm"
                          />
                        </div>

                        <div>
                          <FieldLabel>Average Output Port Power</FieldLabel>
                          <input
                            value={station.outputPower}
                            onChange={(e) => updateNap(index, "outputPower", e.target.value)}
                            className={inputClass}
                            placeholder="________________ dBm"
                          />
                        </div>

                        <div>
                          <FieldLabel>Drop Cable Gland Space</FieldLabel>
                          <select
                            value={station.gland}
                            onChange={(e) => updateNap(index, "gland", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select</option>
                            <option value="Available">Available</option>
                            <option value="Congested">Congested</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Associated Service Code</FieldLabel>
                          <div className="flex flex-wrap gap-1.5 pt-1">
                            <SmallBadge type="blue">C1-NAP-TERM</SmallBadge>
                            <SmallBadge type="blue">C2-SPL1-X</SmallBadge>
                          </div>
                        </div>

                        <div>
                          <FieldLabel>Photo / Test Reference</FieldLabel>
                          <input
                            value={station.reference}
                            onChange={(e) => updateNap(index, "reference", e.target.value)}
                            className={inputClass}
                            placeholder="Reference"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className="print-card">
              <SectionHeader
                zone="Module 4 • Zone D"
                title="Residential Drop & Premises Assessment"
                description="Document the proposed drop route, demarcation, internal path and customer equipment location."
                icon={House}
              />

              <div className="p-4">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div className="md:col-span-2">
                    <FieldLabel>Premises / Address</FieldLabel>
                    <input
                      value={premises.address}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, address: e.target.value }))
                      }
                      className={inputClass}
                    />
                  </div>

                  <div>
                    <FieldLabel>Customer / Contact Name</FieldLabel>
                    <div className="relative">
                      <User size={15} className="absolute left-3 top-3 text-slate-400" />
                      <input
                        value={premises.customer}
                        onChange={(e) =>
                          setPremises((p) => ({ ...p, customer: e.target.value }))
                        }
                        className={`${inputClass} pl-9`}
                      />
                    </div>
                  </div>

                  <div>
                    <FieldLabel>Phone</FieldLabel>
                    <div className="relative">
                      <Phone size={15} className="absolute left-3 top-3 text-slate-400" />
                      <input
                        value={premises.phone}
                        onChange={(e) =>
                          setPremises((p) => ({ ...p, phone: e.target.value }))
                        }
                        className={`${inputClass} pl-9`}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                  <div>
                    <FieldLabel>Drop Method</FieldLabel>
                    <select
                      value={premises.dropMethod}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, dropMethod: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Aerial Span">Aerial Span</option>
                      <option value="Underground Conduit">Underground Conduit</option>
                      <option value="Direct Buried">Direct Buried</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Serving NAP ID / Estimated Drop Length</FieldLabel>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        value={premises.napId}
                        onChange={(e) =>
                          setPremises((p) => ({ ...p, napId: e.target.value }))
                        }
                        className={inputClass}
                        placeholder="NAP ID"
                      />
                      <input
                        value={premises.dropLength}
                        onChange={(e) =>
                          setPremises((p) => ({ ...p, dropLength: e.target.value }))
                        }
                        className={inputClass}
                        placeholder="Metres"
                      />
                    </div>
                  </div>

                  <div>
                    <FieldLabel>Road Crossing Required</FieldLabel>
                    <select
                      value={premises.roadCrossing}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, roadCrossing: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Clearance</FieldLabel>
                    <input
                      value={premises.roadClearance}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, roadClearance: e.target.value }))
                      }
                      className={inputClass}
                      placeholder="______ ft"
                    />
                  </div>

                  <div>
                    <FieldLabel>Pole Demarcation Hardware</FieldLabel>
                    <select
                      value={premises.demarcationHardware}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, demarcationHardware: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="J-Hook">J-Hook</option>
                      <option value="P-Clamp">P-Clamp</option>
                      <option value="Span Clamp">Span Clamp</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Wall Entry Substrate</FieldLabel>
                    <select
                      value={premises.wallSubstrate}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, wallSubstrate: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Concrete Block / Render">Concrete Block / Render</option>
                      <option value="Wood">Wood</option>
                      <option value="Drywall / Siding">Drywall / Siding</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Demarcation Box Location</FieldLabel>
                    <select
                      value={premises.demarcationBox}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, demarcationBox: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="External Wall Box">External Wall Box</option>
                      <option value="Internal Optical Wall Plate">
                        Internal Optical Wall Plate
                      </option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Internal Routing Complexity</FieldLabel>
                    <select
                      value={premises.internalRouting}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, internalRouting: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Standard (<10 m)">Standard (&lt;10 m)</option>
                      <option value="Extended Microduct">Extended Microduct</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Power Outlet Proximity to ONT</FieldLabel>
                    <select
                      value={premises.outlet}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, outlet: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Adjacent (<1 m)">Adjacent (&lt;1 m)</option>
                      <option value="Extension Required">Extension Required</option>
                    </select>
                  </div>

                  <div>
                    <FieldLabel>Target Router Location</FieldLabel>
                    <select
                      value={premises.routerLocation}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, routerLocation: e.target.value }))
                      }
                      className={selectClass}
                    >
                      <option value="">Select</option>
                      <option value="Living Room">Living Room</option>
                      <option value="Central Hallway">Central Hallway</option>
                      <option value="Home Office">Home Office</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="mb-2 flex items-center gap-2">
                    <NavigationArrow size={16} className="text-red-600" weight="duotone" />
                    <h3 className="text-xs font-black">Route Sketch / Installation Notes</h3>
                  </div>

                  <p className="mb-2 text-[11px] text-slate-500">
                    Sketch cable path, entry point, demarcation, ONT/router location, crossings and access constraints.
                  </p>

                  <textarea
                    value={premises.sketch}
                    onChange={(e) =>
                      setPremises((p) => ({ ...p, sketch: e.target.value }))
                    }
                    className={`${textareaClass} min-h-[120px]`}
                    placeholder="Sketch / installation notes..."
                  />
                </div>

                <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div>
                    <FieldLabel>Photo IDs</FieldLabel>
                    <div className="relative">
                      <Camera size={15} className="absolute left-3 top-3 text-slate-400" />
                      <input
                        value={premises.photos}
                        onChange={(e) =>
                          setPremises((p) => ({ ...p, photos: e.target.value }))
                        }
                        className={`${inputClass} pl-9`}
                      />
                    </div>
                  </div>

                  <div>
                    <FieldLabel>Authorization / Special Instructions</FieldLabel>
                    <input
                      value={premises.authorization}
                      onChange={(e) =>
                        setPremises((p) => ({ ...p, authorization: e.target.value }))
                      }
                      className={inputClass}
                    />
                  </div>
                </div>
              </div>
            </Card>

            <Card className="print-card">
              <SectionHeader
                zone="Module 5 • Zone E"
                title="OSP Remedial Work Order & Defect Punch-List"
                description="Prioritize defects and define the recommended corrective work, materials and crew."
                icon={Warning}
              />

              <div className="p-4">
                <div className="space-y-3">
                  {defects.map((defect, index) => (
                    <div
                      key={index}
                      className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700"
                    >
                      <div className="flex items-center justify-between bg-slate-50 px-3 py-2 dark:bg-slate-900">
                        <div className="flex items-center gap-2">
                          <Warning size={16} className="text-amber-600" weight="duotone" />
                          <h3 className="text-[10px] font-black uppercase tracking-widest">
                            Defect {String(index + 1).padStart(2, "0")}
                          </h3>
                        </div>

                        {defect.severity && (
                          <SmallBadge
                            type={
                              defect.severity === "P1 Critical"
                                ? "red"
                                : defect.severity === "P2 Urgent"
                                  ? "amber"
                                  : "blue"
                            }
                          >
                            {defect.severity}
                          </SmallBadge>
                        )}
                      </div>

                      <div className="grid grid-cols-1 gap-3 p-3 md:grid-cols-2 lg:grid-cols-3">
                        <div>
                          <FieldLabel>Location / Pole ID</FieldLabel>
                          <input
                            value={defect.location}
                            onChange={(e) => updateDefect(index, "location", e.target.value)}
                            className={inputClass}
                            placeholder="Pole #"
                          />
                        </div>

                        <div>
                          <FieldLabel>Severity</FieldLabel>
                          <select
                            value={defect.severity}
                            onChange={(e) => updateDefect(index, "severity", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select severity</option>
                            <option value="P1 Critical">P1 Critical</option>
                            <option value="P2 Urgent">P2 Urgent</option>
                            <option value="P3 Routine">P3 Routine</option>
                          </select>
                        </div>

                        <div>
                          <FieldLabel>Recommended Remedial Action</FieldLabel>
                          <select
                            value={defect.action}
                            onChange={(e) => updateDefect(index, "action", e.target.value)}
                            className={selectClass}
                          >
                            <option value="">Select action</option>
                            {index === 0 && (
                              <>
                                <option value="Re-lash cable">Re-lash cable</option>
                                <option value="Re-splice fiber">Re-splice fiber</option>
                                <option value="Other">Other</option>
                              </>
                            )}
                            {index === 1 && (
                              <>
                                <option value="Replace NAP box">Replace NAP box</option>
                                <option value="Tree clearing">Tree clearing</option>
                                <option value="Other">Other</option>
                              </>
                            )}
                            {index === 2 && (
                              <>
                                <option value="Re-tension drop">Re-tension drop</option>
                                <option value="Replace closure">Replace closure</option>
                                <option value="Other">Other</option>
                              </>
                            )}
                          </select>
                        </div>

                        <div className="md:col-span-2">
                          <FieldLabel>Defect Description</FieldLabel>
                          <textarea
                            value={defect.description}
                            onChange={(e) => updateDefect(index, "description", e.target.value)}
                            className={textareaClass}
                            rows={2}
                          />
                        </div>

                        <div>
                          <FieldLabel>Required Materials</FieldLabel>
                          <input
                            value={defect.materials}
                            onChange={(e) => updateDefect(index, "materials", e.target.value)}
                            className={inputClass}
                          />
                        </div>

                        <div>
                          <FieldLabel>Required Crew</FieldLabel>
                          <input
                            value={defect.crew}
                            onChange={(e) => updateDefect(index, "crew", e.target.value)}
                            className={inputClass}
                          />
                        </div>

                        <div>
                          <FieldLabel>Relevant Billable Code</FieldLabel>
                          <input
                            value={defect.code}
                            onChange={(e) => updateDefect(index, "code", e.target.value)}
                            className={inputClass}
                          />
                        </div>

                        <div className="md:col-span-2 lg:col-span-3">
                          <FieldLabel>Photo / Evidence Reference</FieldLabel>
                          <input
                            value={defect.evidence}
                            onChange={(e) => updateDefect(index, "evidence", e.target.value)}
                            className={inputClass}
                            placeholder="Photo / evidence reference"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            <Card className="print-card">
              <SectionHeader
                zone="Module 6"
                title="Pre-Survey Tool & PPE Checklist"
                description="Verify required safety, test and access equipment before deployment."
                icon={ShieldCheck}
              />

              <div className="space-y-5 p-4">
                <ChecklistSection
                  title="Safety / PPE"
                  icon={HardHat}
                  items={safetyChecklist}
                  setter={setSafetyChecklist}
                  updateChecklist={updateChecklist}
                />

                <ChecklistSection
                  title="Optical Test Equipment"
                  icon={Gauge}
                  items={opticalChecklist}
                  setter={setOpticalChecklist}
                  updateChecklist={updateChecklist}
                />

                <ChecklistSection
                  title="Field Measurement & Survey Gear"
                  icon={Ruler}
                  items={surveyChecklist}
                  setter={setSurveyChecklist}
                  updateChecklist={updateChecklist}
                />

                <ChecklistSection
                  title="Access & Hand Tools"
                  icon={Toolbox}
                  items={toolsChecklist}
                  setter={setToolsChecklist}
                  updateChecklist={updateChecklist}
                />
              </div>
            </Card>


          </div>
        </div>
        )}

        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="space-y-4">
            <Card className="print-card">
              <div className="border-b border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-900">
                <div className="flex items-center gap-2">
                  <PenNib size={17} className="text-red-600" weight="duotone" />
                  <h2 className="text-xs font-black uppercase tracking-widest">
                    Survey Sign-Off
                  </h2>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 p-4 md:grid-cols-2">
                <div className="rounded-xl border border-slate-200 p-3 dark:border-slate-700">
                  <div className="mb-3 flex items-center gap-2">
                    <User size={16} className="text-red-600" />
                    <h3 className="text-[10px] font-black uppercase tracking-widest">
                      Lead Surveyor
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <FieldLabel>Name / Signature</FieldLabel>
                      <input
                        value={signOff.leadSurveyor}
                        onChange={(e) =>
                          setSignOff((p) => ({ ...p, leadSurveyor: e.target.value }))
                        }
                        className={inputClass}
                      />
                    </div>

                    <div>
                      <FieldLabel>Date</FieldLabel>
                      <input
                        type="date"
                        value={signOff.leadDate}
                        onChange={(e) =>
                          setSignOff((p) => ({ ...p, leadDate: e.target.value }))
                        }
                        className={inputClass}
                      />
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 p-3 dark:border-slate-700">
                  <div className="mb-3 flex items-center gap-2">
                    <ShieldCheck size={16} className="text-red-600" />
                    <h3 className="text-[10px] font-black uppercase tracking-widest">
                      Seiretsu Operations Reviewer
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <FieldLabel>Name / Signature</FieldLabel>
                      <input
                        value={signOff.reviewer}
                        onChange={(e) =>
                          setSignOff((p) => ({ ...p, reviewer: e.target.value }))
                        }
                        className={inputClass}
                      />
                    </div>

                    <div>
                      <FieldLabel>Date</FieldLabel>
                      <input
                        type="date"
                        value={signOff.reviewerDate}
                        onChange={(e) =>
                          setSignOff((p) => ({ ...p, reviewerDate: e.target.value }))
                        }
                        className={inputClass}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <Card className="print-card mt-4 mb-5">
          <div className="p-4">
            <div className="grid gap-4 lg:grid-cols-[1fr_1.5fr]">
              <div>
                <div className="mb-2 flex items-center gap-2">
                  <FileText size={16} className="text-red-600" />
                  <h2 className="text-xs font-black uppercase tracking-widest">
                    Packet Use
                  </h2>
                </div>

                <p className="text-[11px] leading-5 text-slate-600 dark:text-slate-400">
                  Complete applicable modules in the field. Record measurements, asset IDs,
                  defects, photographs and test references clearly. Mark non-applicable
                  items <strong>"N/A"</strong>.
                </p>
              </div>

              <div>
                <div className="mb-2 text-[10px] font-black uppercase tracking-widest text-slate-500">
                  Module Map
                </div>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {templateId
                    ? templateCanvas.map((item, index) => {
                        const module = templateModules.find((entry) => entry.id === item.moduleId);
                        if (!module) return null;

                        const coverage =
                          module.description?.trim() ||
                          `${module.fields || 0} configured field${module.fields === 1 ? "" : "s"}`;
                        const repeatLabel =
                          module.repeatable && item.repeatCount > 1
                            ? ` • ${item.repeatCount} ${module.unitLabel || "records"}`
                            : "";

                        return (
                          <div
                            key={`${item.moduleId}-map-${index}`}
                            className="flex gap-2 rounded-lg border border-slate-200 p-2 dark:border-slate-700"
                          >
                            <SmallBadge type="blue">{String.fromCharCode(65 + index)}</SmallBadge>
                            <div className="min-w-0">
                              <div className="text-[11px] font-black">
                                {module.name}
                                {repeatLabel ? (
                                  <span className="font-semibold text-slate-500">{repeatLabel}</span>
                                ) : null}
                              </div>
                              <div className="mt-0.5 text-[10px] leading-4 text-slate-500">
                                {coverage}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    : [
                        [
                          "A",
                          "Central Office / Headend",
                          "Core transmission point, OLT landing, ODF racks, cable vault egress",
                        ],
                        ["B", "Outside Plant Route & Poles", "Feeder and distribution corridors"],
                        [
                          "C",
                          "Network Access Point (NAP / FDB)",
                          "Terminal condition, capacity, splitter and optical readings",
                        ],
                        [
                          "D",
                          "Residential Drop & Premises",
                          "Drop route, demarcation, internal routing and ONT location",
                        ],
                        [
                          "E",
                          "Remedial Work & Defects",
                          "Prioritized punch-list and required corrective work",
                        ],
                      ].map(([zone, module, coverage]) => (
                        <div
                          key={zone}
                          className="flex gap-2 rounded-lg border border-slate-200 p-2 dark:border-slate-700"
                        >
                          <SmallBadge type="blue">{zone}</SmallBadge>
                          <div>
                            <div className="text-[11px] font-black">{module}</div>
                            <div className="mt-0.5 text-[10px] leading-4 text-slate-500">
                              {coverage}
                            </div>
                          </div>
                        </div>
                      ))}
                </div>

                <div className="mt-2 rounded-lg bg-slate-50 p-2 text-[10px] text-slate-500 dark:bg-slate-900 dark:text-slate-400">
                  {templateId
                    ? "Module map reflects the modules and repeat counts saved in this survey template."
                    : "Survey packet reference: Seiretsu field-services scope of work and associated billable activity code framework."}
                </div>
              </div>
            </div>
          </div>
        </Card>

        <div className="print-card mb-5 rounded-xl border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-slate-950">
          <div className="flex flex-col justify-between gap-2 text-[11px] text-slate-500 sm:flex-row sm:items-center">
            <div className="font-semibold">Controlled Field Form</div>

            <div>
              Survey Date:{" "}
              <span className="font-bold text-slate-700 dark:text-slate-300">
                {project.surveyDate || "________________"}
              </span>
            </div>

            <div className="font-black">Seiretsu Jamaica Ltd.</div>
          </div>
        </div>
      </main>
    </div>
  );
}

function ChecklistSection({
  title,
  icon: Icon,
  items,
  setter,
  updateChecklist,
}: {
  title: string;
  icon: React.ElementType;
  items: ChecklistItem[];
  setter: React.Dispatch<React.SetStateAction<ChecklistItem[]>>;
  updateChecklist: (
    setter: React.Dispatch<React.SetStateAction<ChecklistItem[]>>,
    index: number,
    key: keyof ChecklistItem,
    value: string,
  ) => void;
}) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2">
        <Icon size={16} className="text-red-600" weight="duotone" />
        <h3 className="text-xs font-black">{title}</h3>
      </div>

      <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
        <table className="w-full min-w-[600px] text-left">
          <thead className="bg-slate-50 dark:bg-slate-900">
            <tr>
              <th className="px-3 py-2 text-[9px] font-black uppercase tracking-widest">
                Item
              </th>
              <th className="px-3 py-2 text-[9px] font-black uppercase tracking-widest">
                Readiness
              </th>
              <th className="px-3 py-2 text-[9px] font-black uppercase tracking-widest">
                Notes
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
            {items.map((item, index) => (
              <tr key={item.item}>
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2 text-[11px] font-bold">
                    <input type="checkbox" className={checkboxClass} />
                    {item.item}
                  </div>
                </td>

                <td className="px-3 py-2">
                  <select
                    value={item.readiness}
                    onChange={(e) =>
                      updateChecklist(setter, index, "readiness", e.target.value)
                    }
                    className={selectClass}
                  >
                    <option value="">Select readiness</option>
                    <option value="Ready">Ready</option>
                    <option value="Missing / Defective">Missing / Defective</option>
                  </select>
                </td>

                <td className="px-3 py-2">
                  <input
                    value={item.notes}
                    onChange={(e) =>
                      updateChecklist(setter, index, "notes", e.target.value)
                    }
                    className={inputClass}
                    placeholder="Notes"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}