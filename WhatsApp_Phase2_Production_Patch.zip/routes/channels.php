<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});


// Private realtime channel for WhatsApp Management. Match the page/API admin allow-list.
Broadcast::channel('whatsapp-management.chat', function ($user) {
    $allowed = array_map('strval', (array) config('whatsapp.admin_user_ids', []));
    $userId = (string) ($user->user_id ?? $user->id ?? '');
    return $userId !== '' && !empty($allowed) && in_array($userId, $allowed, true);
});
