@extends('layouts/layoutMaster')

<title>Elysium Academy&#174;| Manage Lead</title>

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'

])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
<style>
    table thead th{
        padding: 5px !important;
    }
    table tbody tr td{
        padding: 5px !important;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data=$helper->get_staff_data($user_id);
        $document_send_count = $helper->general_setting_data()->max_document_send_limit ?? 7;
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
    @endphp
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Lead  @if (isset($staffName))<span class="badge bg-warning rounded"> {{ $staffName }}</span> @endif</h5>
        <div class="row">
            <div class="col-xl-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Sales Management</a>
                    </li>
                </ol>
            </nav>
            </div>
            <div class="col-xl-7">
                <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
                    @if(isset($Lead_status_list))
                        @foreach ($Lead_status_list as $ls_list)
                          <div class="d-flex align-items-center px-1 py-1">
                            <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: {{ $ls_list->lead_bg_color }} !important;"> </label>
                            <label class="fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $ls_list->lead_status_name }}">{{ $ls_list->lead_status_name }}</label>
                          </div>
                        @endforeach
                   @endif
                   <div class="d-flex align-items-center px-1 py-1">
                            <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: lightpink !important;"> </label>
                            <label class="fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Followup Pending">Followup Pending</label>
                          </div>
                </div>
            </div>
            <div class="col-xl-1">
              <div class="d-flex justify-content-end align-items-center flex-wrap">

                <!-- Dropdown Trigger -->
                <div class="dropdown">
                  <button class="btn btn-primary btn-sm p-1" type="button" id="emojiDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="border-radius: 10px;">
                   <i class="mdi mdi-emoticon-happy-outline fs-4"></i>
                 </button>


                  <!-- Dropdown Menu -->
                  <ul class="dropdown-menu p-3" aria-labelledby="emojiDropdown" style="width: 200px; ">

                    <li class="dropdown-header text-center fs-6 fw-bold text-black pb-2 border-bottom">
                      Potential Type
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-kiss-outline fs-2 me-2" style="width: 30px; height: 30px; color: #6c1fe0"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="top" title="Premium Potential">Premium Potential</label>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-cool-outline fs-2 me-2" style="width: 30px; height: 30px; color: #18aa0e"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="down" title="High Potential">High Potential</label>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-outline fs-2 me-2" style="width: 30px; height: 30px; color: #e17a19"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="down" title="Good Potential">Good Potential</label>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-happy-outline fs-2 me-2" style="width: 30px; height: 30px; color: #e0bc0b"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="down" title="Medium Potential">Medium Potential</label>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-devil-outline fs-2 me-2" style="width: 30px; height: 30px; color: #d41616"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="down" title="Critical Potential">Critical Potential</label>
                    </li>

                    <li class="d-flex align-items-center mb-2">
                      <i class="mdi mdi-emoticon-dead-outline fs-2 me-2" style="width: 30px; height: 30px; color: #000000"></i>
                      <label class="tooltip-hover fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="down" title="Low Potential">Low Potential</label>
                    </li>

                    <!-- Add more emojis here -->
                  </ul>
                </div>
              </div>
            </div>
       </div>
    </div>
    <div class="card-body px-4 py-2">
        <div class="row mt-2">
            <div class="col-xl-12 mb-2">
                <div class="nav-align-top mb-2">
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item mb-2">
                        @if(auth()->user()->hasPermission('Sales Management',
                                                    'Raw Lead', 'Manage Lead'))
                          <a href="{{url('/sales/raw_lead')}}" class="nav-link text-capitalize ">
                            <span>
                            <img src="{{asset('assets/eapl_images/manage_lead/rawlead.png')}}" class="image-input-wrapper w-25px h-25px me-2" />
                            </span>Raw Lead
                          </a>
                        @endif
                          <!--<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">-->
                          <!--      <a href=""   class="dropdown-item" >-->
                          <!--          <span class="me-1">-->
                          <!--              <img src="{{asset('assets/eapl_images/manage_lead/lead.png')}}" class="image-input-wrapper w-25px h-25px" />-->
                          <!--          </span> Fresh Lead-->
                          <!--      </a>-->
                          <!--      <a href="javascript:;" type="button" class="dropdown-item" >-->
                          <!--          <span class="">-->
                          <!--              <img src="{{asset('assets/eapl_images/manage_lead/feature_lead.png')}}" class="image-input-wrapper w-25px h-25px" />-->
                          <!--          </span> Future Lead-->
                          <!--      </a>-->
                          <!-- </div>-->
                        </li>

                        <li class="nav-item mb-2">
                        @if(auth()->user()->hasPermission('Sales Management',
                                                    'Lead Bank', 'Manage Lead'))
                          <a href="{{url('/lead_bank_list')}}" class="nav-link text-capitalize "  type="button" >
                            <span>
                            <img src="{{asset('assets/eapl_images/manage_lead/lead_bank.png')}}" class="image-input-wrapper w-25px h-25px me-2" />
                            </span>Lead Bank @if($leadbankCount > 0)<span
                                class="badge rounded fs-8 text-white bg-success ms-2">{{ sprintf('%02d',
                                $leadbankCount) }}</span>@endif

                          </a>
                        @endif
                        </li>
                        <li class="nav-item mb-2 me-2">
                          <a href="{{url('/sales/manage_lead')}}" type="button" class="nav-link text-capitalize bg-success" >
                              <span class="me-1">
                                <img src="{{asset('assets/eapl_images/manage_lead/lead.png')}}" class="image-input-wrapper w-25px h-25px" />
                            </span> Lead @if($leadOriginalCount>0)<span class="badge bg-info ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf("%02d",$leadOriginalCount) }}</span>@endif</a>
                      </li>
                      <li class="nav-item mb-2">
                        @if(auth()->user()->hasPermission('Sales Management',
                                                    'Spam Lead', 'Manage Lead'))
                            <a href="{{url('/sales/manage_lead/spam_lead')}}" type="button" class="nav-link text-capitalize ">
                            <span class="me-1">
                                <img src="{{asset('assets/eapl_images/manage_lead/spam.png')}}" class="image-input-wrapper w-25px h-25px" />
                            </span>
                             Spam Lead @if($not_verified_spam_count>0)<span class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d',$not_verified_spam_count) }}</span>@endif</a>
                        @endif
                      </li>
                      <li class="nav-item mb-2">
                       @if(auth()->user()->hasPermission('Sales Management',
                                                    'Dead lead', 'Manage Lead'))
                        <a href="{{url('/sales/manage_lead/drop_lead')}}"  type="button"  class="nav-link text-capitalize ">
                        <span class="me-1">
                            <img src="{{asset('assets/eapl_images/manage_lead/dead_lead.ico')}}" class="image-input-wrapper w-25px h-25px" />
                        </span>
                          Dead Lead @if($not_verified_drop_count>0)<span class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d',$not_verified_drop_count) }}</span>@endif</a>
                        @endif
                      </li>
                       <li class="nav-item mb-2">
                        @if(auth()->user()->hasPermission('Sales Management','Internal Calls', 'Manage Lead'))
                            <a href="{{url('/sales/internal_calls')}}" type="button" class="nav-link text-capitalize">
                            <span class="me-1">
                                <img src="{{asset('assets/eapl_images/manage_lead/internal_call.png')}}" class="image-input-wrapper w-25px h-25px" />
                            </span> Internal Calls</a>
                        @endif
                        </li>
                        @if(auth()->user()->hasPermission('Sales Management','Lead Wallet', 'Manage Lead'))
                        <li class="nav-item mb-2 ms-2">
                            <a href="{{url('/sales/lead_wallet')}}" type="button" class="nav-link text-capitalize">
                                <span class="me-1">
                                <img src="{{asset('assets/eapl_images/manage_lead/wallet_lead.png')}}" class="image-input-wrapper w-25px h-25px" /> Lead Wallet
                                @if($walletCount > 0)
                                    <span class="badge rounded fs-8 text-white bg-success ms-2">{{ sprintf('%02d',$walletCount) }}</span>
                                @endif
                            </a>
                        </li>
                        @endif
                        <li class="nav-item mb-2">
                        @if(auth()->user()->hasPermission('Sales Management','Today Followup', 'Manage Lead'))
                            <a href="{{url('/sales/today_followup')}}" type="button"
                                class="nav-link text-capitalize" style="background: #fcff66;">
                                <span class="me-1">
                                <img src="{{asset('assets/eapl_images/manage_lead/followup.png')}}" class="image-input-wrapper w-25px h-25px" />
                                </span> Today Followup @if($totalFollowup > 0)<span class="badge rounded fs-8 text-white bg-success ms-2">{{ sprintf('%02d', $totalFollowup) }}</span>@endif</a>
                        @endif
                        </li>

                    </ul>
                </div>
            </div>

            <div class="col-xl-12">
                <div class="card-body pt-0">
                    <div class="lead_tbox" >
                        <div class="row">
                            <div class="col-lg-10 d-flex flex-wrap align-items-center mb-2 gap-2">
                                <!-- <div class="row"> -->
                                <a href="#" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                                    <div class="fw-semibold fs-6 text-black text-center">Total Leads</div>
                                    <!--<div class="fw-semibold fs-6 text-black text-center">-->
                                    <!--    <label class="fs-8">Upto</label>-->
                                    <!--    <label>(<?php echo date("M-Y"); ?>)</label>-->
                                    <!--</div>-->
                                    <div>
                                        <img src="{{ asset('assets/eapl_images/group_connection_new.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: 70;">
                                    </div>
                                    <div class="d-block">
                                        <div class="d-block badge bg-primary rounded fw-bold fs-6"> {{  $leadOriginalCount }} </div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Month Leads">
                                    <div class="fw-semibold fs-6 text-black text-center">Leads (<?php echo date("M"); ?>)</div>
                                    <!--<div class="fw-semibold fs-6 text-black text-center"></div>-->
                                    <div>

                                          <img src="{{ asset('assets/eapl_images/Calender_new.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 90px; height: 70;">
                                    </div>
                                    <div class="d-block">
                                        <div class="d-block badge bg-primary rounded fw-bold fs-6">{{  $currentMonthLeadCount }}</div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Conversion Rate">
                                    <div class="fw-semibold fs-6 text-black text-center">Total ACR</div>
                                    <!--<div class="fw-semibold fs-6 text-black text-center">(upto <?php echo date("M"); ?>)</div>-->
                                    <div>
                                          <img src="{{ asset('assets/eapl_images/Analytics.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 100px; height: 65;">
                                    </div>
                                    <div class="d-block mt-1">
                                        <div class="d-block badge bg-primary rounded fw-bold fs-6">{{  $percentageover}}</div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Month Conversion">
                                    <div class="fw-semibold fs-6 text-black text-center">Conversion (<?php echo date("M"); ?>)</div>
                                    <!--<div class="fw-semibold fs-6 text-black text-center">(<?php echo date("M"); ?>)</div>-->
                                    <div>
                                     <img src="{{ asset('assets/eapl_images/Conversion_rate.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: auto;">
                                    </div>
                                    <div class="d-block">
                                        <div class="d-block badge bg-primary rounded fw-bold fs-6">{{  $percentagecurrentmonth  }}</div>
                                    </div>
                                </a>
                                    @if ($follwup_count > 0)
                                       <a href="javascript:;" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Followup Count" onclick="pending_followup_func()">
                                            <div class="fw-semibold fs-6 text-black text-center">Followup</div>
                                            <div>
                                                 @if ($follwup_count > 5)
                                                    <img src="{{ asset('assets/eapl_images/Enraged_Emoji.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: auto;">
                                                @else
                                                    <img src="{{ asset('assets/eapl_images/Emoji_Angry.gif') }}" alt="emoji" class="rounded ms-2 align-middle" style="max-width: 70px; height: auto;">
                                                @endif
                                            </div>
                                            <div class="d-block">
                                                 @if ($follwup_count > 5)
                                                 <div class="d-block badge bg-danger rounded fw-bold fs-6">{{ $follwup_count }}</div>
                                                 @else
                                                   <div class="d-block badge bg-primary rounded fw-bold fs-6">{{ $follwup_count }}</div>
                                                 @endif
                                            </div>
                                        </a>
                                         <form id="pending_followup_form" method="POST" action="/lead_filter"> @csrf <input type="hidden" name="pending_followUp_fill" value="1"></form>
                                         <form id="walkin_func_form" method="POST" action="/lead_filter"> @csrf <input type="hidden" name="walkin_fill" value="1"></form>
                                    @endif
                                    @if ($walkInCount > 0)
                                        <a href="javascript:;" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Walk-IN" onclick="walkin_func()">
                                            <div class="fw-semibold fs-6 text-black text-center">Walk-IN</div>
                                            <div>
                                                    <img src="{{ asset('assets/eapl_images/walk-in-appointment.gif') }}" alt="emoji" style="max-width: 70px; height: auto;">

                                            </div>
                                            <div class="d-block">
                                                <div class="d-block badge rounded fw-bold fs-6" style="background: #6c8ad3;">{{ sprintf("%02d",$walkInCount) }}</div>
                                            </div>
                                        </a>
                                    @endif
                                <!-- </div> -->
                            </div>
                            <div class="col-lg-2 d-flex justify-content-end align-items-center flex-wrap">
                                <!-- <div class="align-items-center"> -->
                                <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" title="Print" onclick="printTable()">-->
                                <!--    <span><i class="mdi mdi-printer"></i></span>-->
                                <!--</a>-->
                                @if(auth()->user()->hasPermission('Sales Management', 'Export', 'Manage Lead'))
                                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" data-bs-toggle="modal" data-bs-target="" title="Export" id="export_excel">
                                    <span class=""><i class="mdi mdi-calendar-export-outline"></i></span>
                                </a>
                                @endif
                               <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_import_old" title="Export" id="import_old_lead">-->
                               <!--     <span class=""><i class="mdi mdi-calendar-star"></i></span>-->
                               <!-- </a>-->
                                <!--************FilterButton*****************-->
                                @if(auth()->user()->hasPermission('Sales Management', 'Filter', 'Manage Lead'))
                                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2"
                                    id="lead_filter" title="Filter">
                                    <i class="mdi mdi-filter-outline text-center"></i>
                                </a>

                                @endif

                                <!--@if(auth()->user()->hasPermission('Sales Management', 'Quick Lead', 'Manage Lead'))-->
                                <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_add_quick_lead">-->
                                <!--    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Quick Lead-->
                                <!--</a>-->
                                <!--@endif-->
                                <!-- </div> -->
                        </div>
                        </div>
                        <div class="lead_filter" style="display: none;">
                            <form id="filter_form" method="POST" action="/lead_filter">
                                @csrf
                                <div class="row py-1">
                                  <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                  <input type="hidden" name="filter_on" value="1">
                                  <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                  <!--<div class="col-lg-3 mb-2">-->
                                  <!--  <label class="text-dark mb-1 fs-6 fw-semibold">Lead - Name / Phone / Email Id</label>-->
                                  <!--  <input type="text" class="form-control" id="lead_fill" name="lead_fill" placeholder="Enter Lead - Name/ Mob. No/ Email Id" value="{{ $lead_fill ?? '' }}"/>-->
                                  <!--</div>-->
                                  <div class="col-lg-3 mb-2">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Course</label>
                                    <select id="course_fill" name="course_fill" class="select3 form-select" >
                                        <option value="">Select Course</option>
                                        @if (isset($lead))
                                        @foreach ($lead as $course_ty_fill)
                                        <option value="{{ $course_ty_fill->sno }}" @if($course_ty_fill->sno==
                                            $course_fill)
                                            selected @endif>{{ $course_ty_fill->course_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                  </div>
                                  <div class="col-lg-3 mb-2">
                                      <label class="text-dark mb-1 fs-6 fw-semibold">Potential Type</label>
                                      <select id="potential_type_fill" name="potential_type_fill"
                                          class="select3 form-select">
                                          <option value="">Select Potential Type</option>
                                          @if (isset($PotentialType))
                                          @foreach ($PotentialType as $course_ty_fill)
                                          <option value="{{ $course_ty_fill->sno }}" @if($course_ty_fill->sno==
                                              $potential_type_fill)
                                              selected @endif>{{ $course_ty_fill->potential_type_name }}</option>
                                          @endforeach
                                          @endif
                                      </select>
                                  </div>
                                  <div class="col-lg-3 mb-2">
                                      <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source</label>
                                      <select id="lead_source_fill" name="lead_source_fill"
                                          class="select3 form-select">
                                          <option value="">Select Lead Source</option>
                                          @if (isset($CourseCategory))
                                          @foreach ($CourseCategory as $course_ty_fill)
                                          <option value="{{ $course_ty_fill->sno }}" @if($course_ty_fill->sno==
                                              $lead_source_fill)
                                              selected @endif>{{ $course_ty_fill->lead_source_name }}</option>
                                          @endforeach
                                          @endif
                                      </select>
                                  </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                                        <select id="lead_status_fill" name="lead_status_fill"
                                            class="select3 form-select">
                                            <option value="">Select Status</option>
                                            <option value="0" @if($lead_status_fill==0) selected @endif>Active</option>
                                            <option value="1" @if($lead_status_fill==1) selected @endif>Inactive</option>
                                            <option value="4" @if($lead_status_fill==4) selected @endif>Customer</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales Person</label>
                                        <select id="staff_fill" name="staff_fill"
                                            class="select3 form-select">
                                            <option value="">Select Sales Person</option>
                                            @if (isset($staff_filter_list))
                                            @foreach ($staff_filter_list as $staff_li)
                                            <option value="{{ $staff_li->sno }}" @if($staff_li->sno==
                                                $staff_fill)
                                                selected @endif>{{ $staff_li->nick_name }} - {{ $staff_li->staff_name }}</option>
                                            @endforeach
                                            @endif
                                            <option value="0">Old Staff</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                        <select class="select3 form-select" name="dt_fill_issue_rpt"
                                            id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                            <option value="all" @if($date_filter =="all") selected @endif>All</option>
                                            <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                                            <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                                            <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                                            <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                                            />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                                            />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled
                                            />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_this_month_dt_fill"
                                                placeholder="Select Date" class="form-control this_month_dt_fill"
                                                value="<?php echo date("M-Y"); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" placeholder="Select Date" readonly name="from_date_fillter_textbox"  class="form-control common_date_class"
                                            value="<?php echo date(" d-M-Y"); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text"  placeholder="Select Date"
                                                class="form-control common_date_class" readonly name="to_date_fillter_textbox"  value="<?php echo date(" d-M-Y"); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Financial Year</label>
                                        @php
                                            $get_fin_yr = $helper->get_fin_yr();
                                            // Array of month names
                                            $months = [
                                                1 => 'January',
                                                2 => 'February',
                                                3 => 'March',
                                                4 => 'April',
                                                5 => 'May',
                                                6 => 'June',
                                                7 => 'July',
                                                8 => 'August',
                                                9 => 'September',
                                                10 => 'October',
                                                11 => 'November',
                                                12 => 'December',
                                            ];
                                        @endphp
                                        <select class="select3 form-select" name="fin_yr_fill" id="fin_yr_fill">
                                            <option value="">Select Financial Year</option>
                                            @foreach ($get_fin_yr as $dp_list)
                                                <option value="{{ $dp_list->sno }}" @if($fin_yr_fill == $dp_list->sno) selected @endif>
                                                    {{ $dp_list->financial_year_name }} (
                                                    @php
                                                        $monthsArray = json_decode($dp_list->financial_month, true);
                                                    @endphp
                                                    @if (is_array($monthsArray))
                                                        {{ implode(', ', array_map(fn($m) => $months[$m] ?? 'N/A', $monthsArray)) }}
                                                    @else
                                                        {{ 'N/A' }}
                                                    @endif)
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end mb-2">
                                    <a href="{{ url('/sales/manage_lead') }}" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
                                    </a>
                                    <button type="submit"
                                        class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                                </div>
                            </form>
                        </div>
                        @if (
                            !empty($lead->firstWhere('sno', $course_fill)->course_name) ||
                            !empty($PotentialType->firstWhere('sno', $potential_type_fill)->potential_type_name) ||
                            !empty($CourseCategory->firstWhere('sno', $lead_source_fill)->lead_source_name) ||
                            !empty($staff_filter_list->firstWhere('sno', $staff_fill)->nick_name) ||
                            !empty($date_filter)
                        )
                        <div class="lead_filter_show mb-4">
                            <div class="card shadow-sm">
                                <div class="card-header bg-primary text-white p-2">
                                    <h5 class="mb-0 text-white">Filtered Results</h5>
                                </div>
                                <div class="card-body p-2">
                                    <div class="row gy-3">
                                        @if (!empty($lead->firstWhere('sno', $course_fill)->course_name))
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-book-open-page-variant fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Course:</span>
                                                    <span class="text-danger">{{ $lead->firstWhere('sno', $course_fill)->course_name }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                        @if (!empty($PotentialType->firstWhere('sno', $potential_type_fill)->potential_type_name))
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-chart-line fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Potential Type:</span>
                                                    <span class="text-danger">{{ $PotentialType->firstWhere('sno', $potential_type_fill)->potential_type_name }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                        @if (!empty($CourseCategory->firstWhere('sno', $lead_source_fill)->lead_source_name))
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-source-branch fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Lead Source:</span>
                                                    <span class="text-danger">{{ $CourseCategory->firstWhere('sno', $lead_source_fill)->lead_source_name }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                        @if (!empty($staff_filter_list->firstWhere('sno', $staff_fill)->nick_name))
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-account fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Sales Person:</span>
                                                    <span class="text-danger">{{ $staff_filter_list->firstWhere('sno', $staff_fill)->nick_name }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                        @if ($date_filter)
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-calendar-range fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Date Range:</span>
                                                    @if ($date_filter === 'today')
                                                        <span class="text-danger">{{ date("d-M-Y") }}</span>
                                                    @elseif ($date_filter === 'week')
                                                        @php
                                                            $today = date('l');
                                                            $weekFromDate = $today == "Sunday" ? date('d-M-Y', strtotime("sunday 0 week")) : date('d-M-Y', strtotime("sunday -1 week"));
                                                            $weekToDate = $today == "Sunday" ? date('d-M-Y', strtotime("saturday 1 week")) : date('d-M-Y', strtotime("saturday 0 week"));
                                                        @endphp
                                                        <span class="text-danger">{{ $weekFromDate }} - {{ $weekToDate }}</span>
                                                    @elseif ($date_filter === 'monthly')
                                                        <span class="text-danger">{{ date('01-M-Y') }} - {{ date('t-M-Y') }}</span>
                                                    @elseif ($date_filter === 'custom_date')
                                                        <span class="text-danger">
                                                            {{ $from_date_filter ? date('d-M-Y', strtotime($from_date_filter)) : 'Not Selected' }} -
                                                            {{ $to_date_filter ? date('d-M-Y', strtotime($to_date_filter)) : 'Not Selected' }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        @endif

                                        @if (!empty($selectedMonthsText))
                                        <div class="col-lg-4">
                                            <div class="d-flex align-items-center">
                                                <i class="mdi mdi-calendar-text fs-4 text-primary me-2"></i>
                                                <div>
                                                    <span class="fw-bold text-dark">Financial Year:</span>
                                                    <span class="text-danger">{{ $selectedMonthsText }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif

                    <div class="d-flex justify-content-between align-items-center">
                      <div class="mb-4">
                          @php $perpage_count = $perpage ? $perpage : 25; @endphp
                          <div>
                              <span>Show</span>
                              <br>
                              <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                  <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                  </option>
                                @php endforeach; @endphp
                              </select>
                          </div>
                      </div>
                       <div class="ms-auto">
                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_bulk_convert_sales_person"   id="bulkConversionBtn" style="display: none">
                              <button type="button" class="btn btn-primary me-2 mb-2">Bulk Transfer</button>
                            </a>
                            @if($user_data->role_id != 11)
                           <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_add_spam">
                                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Spam
                            </a>
                            @endif
                            @if(auth()->user()->hasPermission('Sales Management', 'Add Lead', 'Manage Lead'))
                                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead">
                                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Lead
                                </a>
                            @endif
                        </div>
                      <div class="mb-4">
                        <form id="search_form" method="POST" action="/lead_filter">
                          @csrf
                        <div class="d-flex align-items-center gap-2">
                          <div class="mb-1">
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                            <input
                              type="text"
                              class="form-control"
                              id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                              placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                            />
                          </div>
                          <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        </div>
                        </form>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <input type="hidden" id="view_edit_id" />
                              <form id="bulk_request_pay_form" method="POST">
                              @csrf
                              <input type="hidden" name="bulk_assign_staff_id" id="bulk_assign_staff_id">
                             <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                       @if(in_array(auth()->user()->role_id, [1,9,12,18,28,41]))
                                        <th data-sortable="false"  class="min-w-50px">
                                            <input class="form-check-input me-1" type="checkbox" name="all" id="bulk_checkall" onchange="showConversionBtn()">
                                            <!--<span class="fs-7">All</span>-->
                                        </th>
                                        @endif
                                        <th data-sortable="true"  class="min-w-125px">Lead</th>
                                        <th data-sortable="false" class="min-w-100px">Mobile / L.F.D</th>
                                        <th data-sortable="false" class="min-w-80px">Calls</th>
                                        <th data-sortable="false" class="min-w-80px">Sales Person </th>
                                        <th data-sortable="false" class="min-w-100px">Potential Type</th>
                                        <th data-sortable="false" class="min-w-120px">Status</th>
                                        <th data-sortable="false" class="min-w-80px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    @if (count($leads) > 0)
                                    @foreach ($leads as $i=> $category)

                                     <tr class="{{ ($category->just_dial_id > 0 && $category->lead_status_id == 1) ? 'highlight-row' : '' }}"  style="background-color:

                                        @if($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)lightpink;@elseif($category->status != 4 && $category->is_hot_lead == 1)#6fd1fb;@else{{ $category->lead_bg_color }} {{-- Use the existing color otherwise --}}
                                        @endif;">

                                        @if(in_array(auth()->user()->role_id, [1,9,12,18,28,41]))
                                            <td>
                                                @php
                                                    $encryptLeadId = $helper->encrypt_decrypt($category->sno, 'encrypt');
                                                @endphp
                                                @if(in_array(auth()->user()->role_id, [1,9,41]))
                                                    <input class="form-check-input bulk_chk 1" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}"  data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                @elseif(auth()->user()->hasPermission('Sales Management', 'Checkbox', 'Manage Lead'))
                                                    <input class="form-check-input bulk_chk 1" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}"  data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                @else
                                                    @if($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                        @if($category->lead_status_id == 3)
                                                            @if(intval($hot_lead_days <= $category->formattedDayDifference))
                                                            <input class="form-check-input bulk_chk 1" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}"  data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                            @endif
                                                        @elseif($category->status == 0)
                                                            @if($category->lead_status_id != 3)
                                                                <input class="form-check-input bulk_chk 2" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}" data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                            @endif
                                                        @endif
                                                    @endif
                                                @endif
                                            </td>
                                        @endif
                                        
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <!-- <div class="d-flex align-items-center">
                                                <!-- Star -->
                                                @if($category->is_hot_lead == 2)
                                                    <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Hot Lead Star" class="me-1">
                                                        <img src="{{ asset('assets/eapl_images/Star_animate.gif') }}" alt="Hot Lead Star" class="w-50px h-50px">
                                                    </div>
                                                @endif

                                                <!-- Name and Registered Date -->
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex align-items-center mb-0">
                                                        @if($category->lead_appointment_status == 1)
                                                            <i class="animation-blink mdi mdi-phone-clock text-danger fs-4 me-1" title="Appointment"></i>
                                                        @endif

                                                        <span class="fs-7 me-1">{{ $category->lead_name }}</span>

                                                        @if($category->lead_gender == 1)
                                                            <i class="mdi mdi-face-man text-info me-1"></i>
                                                        @elseif($category->lead_gender == 2)
                                                            <i class="mdi mdi-face-woman text-danger me-1"></i>
                                                        @endif

                                                        @if($category->lead_dob == date('Y-m-d'))
                                                            <i class="mdi mdi-cake-variant-outline animation-blink text-primary fs-4"></i>
                                                        @endif
                                                    </div>

                                                    <div class="fs-8 text-primary">
                                                        <span>{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) : '' }}</span>
                                                    </div>
                                                </div>
                                            </div>





                                        </td>
                                        <td>
                                            <div class="d-flex align-items-start justify-content-start ">
                                                <div>
                                                    @if($category->status != 7)
                                                    <label>
                                                       @php
                                                            $call_chk = isset($category->inter_calls) ? $category->inter_calls : 0;
                                                            $countryCode = $call_chk == 0 ? '+91' : '+' . $category->inter_calls;

                                                            $roleId = auth()->user()->role_id;
                                                            $mobileNumber = $category->status == 1 ? 'XXXXXXXXXX' : $helper::maskMobileNumber(
                                                                $category->lead_mobile,
                                                                $roleId,
                                                                [27, 28, 29, 30, 31, 32] // Replace with the role IDs that should have masking
                                                            );
                                                        @endphp

                                                        {{ $countryCode }} {{ $mobileNumber }}

                                                    </label>
                                                    @endif
                                                    @if($category->status == 7)
                                                    <label title="Mobile No">{{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}</label>
                                                    @endif
                                                    <br>
                                                    @if ($category->lead_status_id == 1 && $category->lead_score == null && ($category->lead_condition == 1 || $category->lead_condition == 2 && $category->status != 1))
                                                        <span class="blink new-label fs-8 mt-4" style="margin-left: 5px;">New!</span>
                                                    @endif
                                                    @if(is_null($category->appointment_date))
                                                        @else
                                                        <div class="d-block text-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Follow Up Date">
                                                            {{ date($common_date_format, strtotime($category->appointment_date)) }}
                                                        </div>
                                                    @endif

                                                </div>
                                                <div>
                                                    <span>
                                                        @php
                                                            $phoneVerifyContent = json_decode($category->phone_verify_content, true);
                                                        @endphp
                                                        @if ($category->phone_verify_status==1)
                                                            <a href="javascript:;" class="btn btn-icon btn-sm" onclick="phoneVerifyDetails('{{ $category->lead_name }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:76%!important">
                                                                    <rect id="Layer_1" width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                                    <g id="Layer_2">
                                                                        <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                                                        <path fill="#39ba77" d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z"></path>
                                                                        <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                                                    </g>
                                                                </svg>
                                                            </a>
                                                        @elseif ($category->phone_verify_status==2)
                                                            <a href="javascript:;" class="btn btn-icon btn-sm" onclick="phoneVerifyDetails('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:76%!important">
                                                                    <rect id="Layer_1" width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                                    <g id="Layer_2">
                                                                        <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                                                        <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                        <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                                                    </g>
                                                                </svg>
                                                            </a>
                                                        @endif
                                                    </span>
                                                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_transfer" onclick="leadTransfer('{{ $category->sno }}', '{{ $category->lead_name }}', '{{ $category->lead_mobile }}', '{{ $category->lead_source_name }}', '{{ $category->registered_date }}')">
                                                        <span class="badge bg-info rounded fs-8 fw-semibold text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Life Time" >
                                                            {{ $category->formattedDifference ?? '0 day' }}
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                         <td>

                                            <span>

                                                <button type="button" class="fs-8 bg-label-secondary rounded position-relative text-nowrap d-inline-block border-0 px-2 py-1"  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <!--<label class=" image-input image-input-circle"  >-->
                                                     <img src="{{asset('assets/eapl_images/call_tracker.png')}}" class="image-input-wrapper w-25px h-25px " />
                                                       <span class="badge rounded-pill bg-primary fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Outgoing"  style="top: -10px !important; left: 25px !important;">
                                                            {{ $category->outgoing_count }}
                                                        </span>
                                                    <!--</label>-->
                                                </button>

                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <div>
                                                        <a href="javascript:;" onclick="openCallHistoryModal('{{ $category->sno }}','Incoming','{{ $category->lead_name }}','{{ $category->lead_mobile }}')" class="dropdown-item d-flex gap-1" data-bs-toggle="modal" data-bs-target="#kt_modal_call_lead_history" >
                                                            <span >
                                                                <div class="bg-label-secondary rounded image-input image-input-circle px-1 py-1" style="background-color: #0a0a0ac7 !important;">
                                                                <img src="{{asset('assets/eapl_images/incoming.png')}}" class="image-input-wrapper w-15px h-15px" />
                                                                </div>
                                                            </span>
                                                            <span style="background-color:#FFBF66" class="badge text-black fw-bold badge-pill animate__animated animate__pulse animate__infinite">{{ $category->incoming_count }}</span> Incoming
                                                        </a>
                                                    </div>
                                                    <div>
                                                        <a href="javascript:;" class="dropdown-item d-flex gap-1" data-bs-toggle="modal" data-bs-target="#kt_modal_call_lead_history" onclick="openCallHistoryModal('{{ $category->sno }}','Outgoing','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">
                                                            <span>
                                                                <div class="bg-label-secondary rounded image-input image-input-circle px-1 py-1" style="background-color: #0a0a0ac7 !important;">
                                                                <img src="{{asset('assets/eapl_images/outgoing.png')}}" class="image-input-wrapper w-15px h-15px" />
                                                                </div>
                                                            </span><span style="background-color:#7594E8" class="badge text-black fw-bold badge-pill animate__animated animate__pulse animate__infinite">{{ $category->outgoing_count }}</span> Outgoing </a>
                                                    </div>
                                                    <div>
                                                        <a href="javascript:;" class="dropdown-item d-flex gap-1" data-bs-toggle="modal" data-bs-target="#kt_modal_call_lead_history" onclick="openCallHistoryModal('{{ $category->sno }}','Dialed','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">
                                                            <span>
                                                                <div class="bg-label-secondary rounded image-input image-input-circle px-1 py-1" style="background-color: #71eba8 !important;">
                                                                    <img src="{{asset('assets/eapl_images/outgoing.png')}}" class="image-input-wrapper w-15px h-15px" />
                                                                </div>
                                                            </span>
                                                            <span  style="background-color:#71eba8" class="badge text-black fw-bold badge-pill animate__animated animate__pulse animate__infinite">{{ $category->dialed_count }}</span> Dialed </a>
                                                    </div>
                                                    <div>
                                                        <a href="javascript:;" class="dropdown-item d-flex gap-1" data-bs-toggle="modal" data-bs-target="#kt_modal_call_lead_history" onclick="openCallHistoryModal('{{ $category->sno }}','Missed & Rejected','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">
                                                            <span>
                                                                <div class="bg-label-secondary rounded image-input image-input-circle px-1 py-1" style="background-color: #0a0a0ac7 !important;">
                                                                    <img src="{{asset('assets/eapl_images/miss_rej.png')}}" class="image-input-wrapper w-15px h-15px" />
                                                                </div>
                                                            </span><span  style="background-color:#FFA500" class="badge text-black fw-bold badge-pill animate__animated animate__pulse animate__infinite">{{ $category->missed_reject_count }}</span> Missed & Rejected </a>
                                                    </div>
                                                    <!--<div>-->
                                                    <!--    <a href="javascript:;" class="dropdown-item d-flex gap-1" data-bs-toggle="modal" data-bs-target="#kt_modal_call_lead" onclick="openSummaryModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->incoming_count }}','{{ $category->outgoing_count }}','{{ $category->dialed_count }}','{{ $category->missed_reject_count }}')"><span><div class="bg-label-secondary rounded image-input image-input-circle px-1 py-1" style="background-color: #0a0a0ac7 !important;">-->
                                                    <!--            <img src="{{asset('assets/eapl_images/call_summary.png')}}" class="image-input-wrapper w-15px h-15px" />-->
                                                    <!--        </div></span>Summary</a>-->
                                                    <!--</div>-->
                                                </div>
                                            </span>

                                        </td>
                                        <td>
                                            @if($category->status == 8)
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="EAPL">EAPL</label>
                                            @else
                                                <label data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->nick_name ?? 'Old Staff' }}">
                                                    {{ $category->staff_name ?? 'Old Staff' }}
                                                </label>
                                            @endif

                                            <div class="d-block">
                                                <!--@if(($category->just_dial_id > 0 || $category->cloud_call_id > 0 || $category->call_tracker_id > 0 || $category->website_id > 0) )-->

                                                <!--    <label class="badge bg-warning text-primary rounded fw-bold fs-8 -->
                                                <!--        @if($category->just_dial_id > 0 || $category->cloud_call_id > 0 || $category->call_tracker_id > 0 || $category->website_id > 0 && $category->lead_status_id == 1) -->
                                                <!--            blink source-label-->
                                                <!--        @endif" -->
                                                <!--        data-bs-toggle="tooltip" -->
                                                <!--        data-bs-placement="bottom" -->
                                                <!--        title="Lead Source">-->
                                                <!--        {{ $category->lead_source_name }}-->
                                                <!--    </label>-->

                                                <!--@else-->
                                                <!--<label class="badge bg-warning text-primary rounded fw-bold fs-8 "-->
                                                <!--    data-bs-toggle="tooltip" -->
                                                <!--    data-bs-placement="bottom" -->
                                                <!--    title="Lead Source">-->
                                                <!--    {{ $category->lead_source_name ??'-' }}-->
                                                <!--</label>-->
                                                <!--@endif-->
                                                 @php
                                                  $isUrbanPro = strtolower($category->lead_source_name) === 'urbanpro';
                                                 @endphp
                                                @if($category->just_dial_id > 0)
                                                <label class="badge bg-white text-primary rounded fw-bold fs-6 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                  <span class="jd-blue">Just</span><span class="jd-orange">dial</span>
                                                </label>
                                                @elseif($category->cloud_call_id > 0)
                                                <label class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                    <i class="fas fa-cloud cc-icon"></i><span class="cc-purple">Cloud</span><span class="cc-purple">Call</span>
                                                </label>
                                                @elseif($category->call_tracker_id > 0)
                                                <label class="badge ct-orange text-white rounded fw-bold  blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                    <!--<span class="ct-black">Call</span>-->
                                                    <!--<span class="badge ct-orange">-->
                                                        Tra<i class="mdi mdi-phone-in-talk ct-icon"></i>cker
                                                    <!--</span>-->
                                                </label>
                                                @elseif($category->urban_pro_id > 0 || $isUrbanPro)
                                                <label
                                                  class="badge {{ $isUrbanPro ? 'text-white' : 'bg-warning text-primary' }} rounded fw-bold fs-8"
                                                  data-bs-toggle="tooltip"
                                                  data-bs-placement="bottom"
                                                  title="Lead Source"
                                                  style="{{ $isUrbanPro ? 'background: linear-gradient(178deg, #00c7a6, #0081f2);' : '' }}"
                                              >
                                                  {{ $category->lead_source_name }}
                                              </label>

                                                @elseif($category->website_id > 0)
                                                <label class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                  <span class="text-primary">Web</span><span class="text-primary">Site</span>
                                                </label>
                                                 @elseif($category->sulekha_id > 0)
                                                <label class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                    <img src="{{asset('assets/eapl_images/sulekha_logo.png')}}" class="image-input-wrapper w-70px h-25px" />
                                                </label>
                                                @else
                                                    @if($category->lead_source_id == 21)
                                                        <span class="qr-badge d-inline-flex align-items-center gap-1 fs-7" data-bs-toggle="tooltip"  data-bs-placement="bottom" title="Lead Source">
                                                            <i class="mdi mdi-qrcode-scan fs-7"></i>{{ $category->lead_source_name ?? '-' }}
                                                        </span>
                                                    @elseif($category->lead_source_id == 22)
                                                    @php
                                                        $event_name = $helper->get_event_name_data($category->lead_event_id)->event_name ?? '';
                                                    @endphp
                                                        <!--<span class="qr-badge2 d-inline-flex align-items-center gap-1 fs-7" data-bs-toggle="tooltip"  data-bs-placement="bottom" title="Event Name : {{$event_name}}">-->
                                                        <!--    <i class="mdi mdi-calendar-outline fs-7"></i>{{ $category->lead_source_name ?? '-' }}-->
                                                        <!--</span>-->
                                                         <label
                                                          class="badge rounded fw-bold fs-8"
                                                          data-bs-toggle="tooltip"
                                                          data-bs-placement="bottom"
                                                          title="Event Name : {{$event_name}}"
                                                          style="{{ $event_name ? 'background: linear-gradient(#FFE67C);color: #295F2D;' : '' }}"
                                                      >
                                                          {{ $category->lead_source_name }}
                                                      </label>
                                                    @else
                                                        <label class="badge bg-warning text-primary rounded fw-bold fs-8"
                                                               data-bs-toggle="tooltip"
                                                               data-bs-placement="bottom"
                                                               title="Lead Source">
                                                            {{ $category->lead_source_name ?? '-' }}
                                                        </label>
                                                    @endif
                                              @endif

                                            </div>
                                        </td>

                                        <td>
                                            <div class="d-flex">
                                                <div class="mb-0 me-2">
                                                    <label>
                                                        <span>
                                                            <i class="mdi {{ $category->emoji ?? '-' }} fs-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Potential Type" style="color: {{ $category->emoji_color }}"></i>
                                                        </span>
                                                    </label>
                                                </div>
                                                <div class="avatar avatar-sm me-2">
                                                    @if($category->total_app_score > 0)
                                                    <span class="position-relative avatar-initial avatar-initial rounded bg-label-success fs-5 border p-1 d-inline-block" style="min-width: 35px; text-align: center;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="lead score">{{ $category->total_app_score }}
                                                        {{-- @if ($category->total_appointments > 0)
                                                            @if($category->appointment_status == 4)
                                                                <span class="badge rounded-pill bg-success position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                                @elseif($category->appointment_status == 1)
                                                                <span class="badge rounded-pill bg-danger position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                            @endif

                                                        @endif --}}
                                                    </span>
                                                    @elseif($category->total_app_score < 0)
                                                    <span class="avatar-initial rounded bg-label-danger fs-5 border p-1 d-inline-block" style="min-width: 35px; text-align: center;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="lead score">{{ $category->total_app_score }}
                                                        {{-- @if ($category->total_appointments > 0)
                                                            @if($category->appointment_status == 4)
                                                                <span class="badge rounded-pill bg-success position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                                @elseif($category->appointment_status == 1)
                                                                <span class="badge rounded-pill bg-danger position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                            @endif

                                                        @endif --}}
                                                    </span>
                                                    @else
                                                    <span class="position-relative avatar-initial rounded bg-label-info fs-5 border p-1 d-inline-block" style="min-width: 35px; text-align: center;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="lead score">
                                                        {{ $category->total_app_score }}
                                                        {{-- @if ($category->total_appointments > 0)
                                                            @if($category->appointment_status == 4)
                                                                <span class="badge rounded-pill bg-success position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                                @else
                                                                <span class="badge rounded-pill bg-danger position-absolute fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending" style="top: -8px; right: -8px;">
                                                                    {{ $category->total_appointments }}
                                                                </span>
                                                            @endif

                                                        @endif --}}
                                                    </span>


                                                    @endif
                                                </div>
                                            </div>
                                        </td>
                                        <td>

                                            @if( $category->status == 0)
                                            <a href="javascript:;" class="badge bg-info text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Active
                                            </a>
                                            @elseif( $category->status == 1)
                                            <a href="javascript:;" class="badge bg-warning text-white rounded fw-bold fs-8 mb-2 " id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                In Active
                                            </a>
                                            @elseif( $category->status == 4)
                                            <a href="javascript:;" class="badge bg-success text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Customer
                                            </a>
                                             @elseif( $category->status == 10)
                                            <a href="javascript:;" class="badge bg-success text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Old Customer
                                            </a>
                                            @elseif($category->status == 5 && ($category->drop_verified == 0 || $category->drop_tl_verified == 0) )
                                            <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead Awaiting </a>
                                            @elseif($category->status == 5 && $category->drop_verified == 1 && in_array(auth()->user()->role_id, [12,18,20,21]))
                                            <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead </a>
                                            @elseif($category->status == 5 && $category->drop_verified == 1 && !in_array(auth()->user()->role_id, [12,18,20,21]))
                                            <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead Awaiting </a>
                                            @elseif( $category->status == 7 && ($category->spam_verified == 0 || $category->spam_tl_verified == 0) )
                                            <a href="javascript:;" class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Spam Awaiting </a>
                                            @elseif($category->status == 7 && $category->spam_verified == 1 && in_array(auth()->user()->role_id, [12,18,20,21]))
                                            <a href="javascript:;" class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Spam </a>
                                            @elseif($category->status == 7 && $category->spam_verified == 1 && !in_array(auth()->user()->role_id, [12,18,20,21]))
                                            <a href="javascript:;" class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Spam Awaiting </a>

                                            @elseif( $category->status == 8)
                                            <a href="javascript:;" class="badge bg-warning text-primary rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                OLD
                                            </a>
                                            @endif

                                            @php
                                                 $hot_lead_followup = $helper->getFollowupCount($category->sno)
                                            @endphp


                                            @if( $category->status == 0)
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <!--{{$user_data->role_id}}-->
                                                @if($user_data->role_id != 11 && $user_data->role_id != 12)
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_inactivate" onclick="inactiveModal('{{ $category->sno }}','{{ $category->lead_name }}')">Inactivate</a>
                                                @endif
                                                @if($hot_lead_followup >= 2)
                                                @if($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)
                                                    <a href="javascript:;" class="dropdown-item d-none" data-bs-toggle="modal" data-bs-target="#kt_modal_hot_lead" onclick="hotLeadModal('{{ $category->sno }}','{{ $category->lead_name }}')">Hot Lead</a>
                                                @elseif($category->lead_status_id != 3)
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_hot_lead" onclick="hotLeadModal('{{ $category->sno }}','{{ $category->lead_name }}')">Hot Lead</a>
                                                @endif
                                                @endif

                                                @if($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                   @if($category->dead_not_closed == 1)
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_drop_list" onclick="dropModalList('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')">Dead Lead</a>
 
                                                @else
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_drop" onclick="dropModal('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')">Dead Lead</a>
                                                @endif
                                                 @if($category->dead_not_closed == 1)
                                               <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_spam_list" onclick="spamModalList('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->created_by }}')">Spam Lead</a>
 
                                                @else
                                               <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_spam" onclick="spamModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->created_by }}')">Spam Lead</a>
                                                @endif
                                                
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_potential" onclick="PotentialModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">Potential Baseket</a>
                                                
                                                @elseif($category->appointment_status != 4)
                                                    <label  class="text-danger fs-8 fw-bold dropdown-item">Pending Follow-up</label>
                                                @elseif($category->lead_appointment_status == 1)
                                                    <label class="dropdown-item" class="text-danger fs-8 fw-bold dropdown-item">Pending Appointment</label>
                                                @endif

                                            </div>
                                            @elseif( $category->status == 1)
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_activate"onclick="activeModal('{{ $category->sno }}','{{ $category->lead_name }}')">Activate</a>
                                            </div>
                                            @elseif( $category->status == 4)

                                            @endif
                                          @if($category->status !== 1 && $category->status !== 7  && $category->status !== 5)
                                            {{-- Follow Up Icon Start--}}
                                            @if( $category->appointment_status == 1   && $category->status !== 4 && $category->status !== 10 ||  $category->appointment_status == 5)
                                            <span class="badge bg-danger fs-8  position-relative text-nowrap d-inline-block px-2 py-1"   data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead_schedule" onclick="openResheduleModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">F
                                                @if($category->appointment_status == 4)
                                                <span class="badge rounded-pill bg-success fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed"  style="top: -13px !important; left: 15px !important;">
                                                    {{ $category->total_appointments }}
                                                </span>
                                                @else
                                                <span class="badge rounded-pill bg-danger fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending"  style="top: -13px !important; left: 15px !important;">
                                                    {{ $category->total_appointments }}
                                                </span>
                                                @endif
                                            </span>
                                            @elseif( $category->appointment_status == 4  && $category->status !== 4 && $category->status !== 10)
                                            @if( $category->not_closed == 1 && auth()->user()->branch_id == 6)
                                                <button type="button" class="badge bg-danger fs-8  position-relative text-nowrap d-inline-block border-0 px-2 py-1"  data-bs-toggle="modal" data-bs-target="#kt_modal_not_closed" onclick="openNotClosedModal('{{ $category->created_by }}')">F
                                                    @if($category->appointment_status == 4)
                                                    <span class="badge rounded-pill bg-success fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed"  style="top: -13px !important; left: 15px !important;">
                                                        {{ $category->total_appointments }}
                                                    </span>
                                                    @else
                                                    <span class="badge rounded-pill bg-danger fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending"  style="top: -13px !important; left: 15px !important;">
                                                        {{ $category->total_appointments }}
                                                    </span>
                                                    @endif
                                                </button>
                                                @else
                                                <button type="button" class="badge bg-danger fs-8  position-relative text-nowrap d-inline-block border-0 px-2 py-1"  data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead_schedule_again" onclick="openResheduleModalAgain('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">F
                                                    @if($category->appointment_status == 4)
                                                    <span class="badge rounded-pill bg-success fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Completed"  style="top: -13px !important; left: 15px !important;">
                                                        {{ $category->total_appointments }}
                                                    </span>
                                                    @else
                                                    <span class="badge rounded-pill bg-danger fs-8 position-absolute" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Followup Pending"  style="top: -13px !important; left: 15px !important;">
                                                        {{ $category->total_appointments }}
                                                    </span>
                                                    @endif
                                                </button>
                                                @endif
                                            @elseif( $category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                            @if( $category->not_closed == 1 && auth()->user()->branch_id == 6)
                                                <button type="button" class="animation-blink badge bg-danger fs-8  position-relative text-nowrap d-inline-block border-0"  data-bs-toggle="modal" data-bs-target="#kt_modal_not_closed" onclick="openNotClosedModal('{{ $category->created_by }}')">F</button>
                                             @else
                                               <button type="button" class="animation-blink badge bg-danger fs-8  position-relative text-nowrap d-inline-block border-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Not yet Followed"  data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead" onclick="AppointmentSchedule('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">F</button>
                                            @endif
                                            @elseif( $category->status == 5)
                                            @endif
                                            {{-- Follow Up Icon End--}}

                                            {{-- Checklist Icon Start --}}
                                            @if($category->lead_condition != 1)
                                            @if($category->status != 4 && $category->status !== 10)

                                            @if( $category->lead_score == null && $category->status !== 5)
                                                <button type="button" class="animation-blink badge bg-info fs-8 ms-2 border-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Checklist Not Yet Completed" data-bs-toggle="modal" data-bs-target="#kt_modal_check_list" onclick="openChecklistModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">C</button>
                                            @else
                                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Checklist Completed"  data-bs-toggle="modal" data-bs-target="#kt_modal_check_list_view" onclick="openChecklistviewModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}','{{ $category->lead_answer }}')">
                                                    <i class='mdi mdi-playlist-check fs-3 text-dark ms-2'></i>
                                                </a>
                                            @endif
                                            @endif
                                            @endif
                                            {{-- Checklist Icon End --}}

                                            @if($category->status != 4)
                                            @if ($category->lead_condition == 1)
                                                <a href="javascript:;" class="animation-blink badge bg-success fs-8 ms-2 border-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Partially Completed" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead" onclick="partialEditModal('{{ $category->sno }}')">P</a>
                                            @elseif($category->lead_condition < 1)
                                                <a href="javascript:;" class="badge bg-success fs-8 ms-2 border-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Partially Completed" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead" onclick="partialEditModal('{{ $category->sno }}')">P</a>
                                            @endif
                                            @endif
                                             @endif
                                        </td>
                                        <td>
                                            @if($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                <span class="d-flex align-items-center text-end">
                                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                    </a>

                                                    <div class="dropdown-menu dropdown-menu-end">
                                                    {{-- @if(auth()->user()->hasPermission('Sales Management', 'Followup', 'Manage Lead')) --}}
                                                        {{-- @if( $category->appointment_status == 1 && $category->status !== 4 )
                                                        
                                                        <div>
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead_schedule" onclick="openResheduleModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">Follow Up
                                                                <span class="badge rounded-pill bg-primary text-end">{{ $category->total_appointments }}</span>
                                                            </a>
                                                        </div>
                                                        
                                                        @elseif( $category->appointment_status == 4 && $category->status !== 4 )
                                                       
                                                        <div>
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead_schedule_again" onclick="openResheduleModalAgain('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">Follow Up
                                                                <span class="badge rounded-pill bg-primary text-end">{{ $category->total_appointments }}</span>
                                                            </a>
                                                        </div>
                                                       
                                                        @elseif( $category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_follow_up_lead" onclick="AppointmentSchedule('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">Follow Up</a>
                                                        @elseif( $category->status == 5)
                                                        @endif --}}
                                                        {{-- @endif --}}
                                                        {{-- @if(auth()->user()->hasPermission('Sales Management', 'Check List', 'Manage Lead')) --}}
                                                            {{-- @if( $category->lead_score == null && $category->status !== 5)
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_check_list" onclick="openChecklistModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">Check List</a> --}}
                                                            @if(auth()->user()->hasPermission('Sales Management', 'Message', 'Manage Lead'))
                                                                @if( $category->status !== 4 && $category->status !== 5 && $category->status !== 10)
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_to_cus" onclick="ConvertCustomer('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')" style="background-color: #c2fbb6 !important;">
                                                                        <span> <i class="mdi mdi-account-sync-outline fs-3 text-black me-1"></i>Customer</span>
                                                                    </a>
                                                                @endif
                                                            {{-- <a href="javascript:;" class="dropdown-item" >Check List
                                                                <span class="badge badge-center rounded-pill bg-primary"><i class='mdi mdi-check'></i></span>
                                                            </a> --}}
                                                            @endif
                                                        {{-- @endif --}}
                                                        <div>
                                                        @if(auth()->user()->hasPermission('Sales Management', 'View', 'Manage Lead'))
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_lead" onclick="populateViewModal('{{ $category->sno }}')"><span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View Lead</span></a></a>
                                                        @endif
                                                        </div>
                                                        @if($category->status !== 4 && $category->status !== 10)
                                                             @if( $category->lead_appointment_status != 1)
                                                             @if(auth()->user()->hasPermission('Sales Management', 'Followup', 'Manage Lead'))
                                                                  <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_appointment" onclick="lead_appointment_func('{{ $category->sno }}','{{ $category->lead_name }}')"><span> <i class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i>Appointment </span></a></a>
                                                              @endif
                                                            @endif
                                                            @if(auth()->user()->role_id==9 || auth()->user()->role_id==18 )
                                                            <!--<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_status_lead" onclick="populateStatusModal('{{ $category->sno }}')"> <span> <i class="mdi mdi-account-check-outline fs-3 text-black me-1"></i>Status Change</span></a>-->

                                                            @php
                                                            $id = $category->sno;
                                                            $encryptedAdd_Course = $helper->encrypt_decrypt($id, 'encrypt');
                                                            $customer_add_course = url('/customer/old_customer_add/' . $encryptedAdd_Course);
                                                            @endphp

                                                            <a href="{{$customer_add_course}}" class="dropdown-item" style="background: #fcff66;" > <span> <i class="mdi mdi-account-sync-outline fs-3 text-black me-1"></i>Old Customer</span></a>


                                                            @endif
                                                            @if($user_data->role_id == 9)
                                                             <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_covert_branch" onclick="convertBranchModal('{{ $category->sno }}','{{$category->lead_name}}')"> <span> <i class="mdi mdi-city-switch fs-3 text-black me-1"></i>Convert Branch</span></a>
                                                             @endif

                                                            @if($login_branch_data->branch_type==1)
                                                             
                                                                 @if($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                                     <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_internal_call_lead" onclick="internalCalls('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_id }}')">
                                                                         <span><i class="mdi mdi-call-split fs-3 text-black me-1"></i>Internal Calls</span>
                                                                     </a>
                                                               @endif
                                                             @endif
                                                            @if(auth()->user()->hasPermission('Sales Management','Lead Wallet', 'Manage Lead'))
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_wallet" onclick="leadWallet('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')">
                                                                <span><i class="mdi mdi-wallet fs-3 text-black me-1"></i>Lead Wallet</span>
                                                            </a>
                                                            @endif
                                                            {{-- @if(auth()->user()->hasPermission('Sales Management', 'Edit', 'Manage Lead'))
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead"onclick="populateEditModal('{{ $category->sno }}')">Edit</a>
                                                            @endif --}}

                                                            @if($document_send_count > $category->document_send_count)
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_syllabus_document_send" onclick="sendSyllabusMessage('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')">
                                                                <span> <i class="mdi mdi-chat-processing-outline fs-3 text-black me-1"></i>Send Syllabus</span>
                                                            </a>
                                                             @endif


                                                            @if(auth()->user()->hasPermission('Sales Management', 'Intern', 'Manage Lead'))
                                                              <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_to_intern" onclick="ConvertIntern('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')" style="background-color: #b6f1fb !important;">
                                                                  <span> <i class="mdi mdi-account-arrow-right-outline fs-3 text-black me-1"></i>Intern</span>
                                                              </a>
                                                            @endif
                                                            <!--@if(auth()->user()->hasPermission('Sales Management', 'Delete', 'Manage Lead'))-->
                                                            <!--    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_lead" onclick="confirmDelete('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_id }}')"><span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Unlist</span>-->
                                                            <!--    </a>-->
                                                            <!--@endif-->
                                                        @endif
                                                        
                                                            @if(auth()->user()->role_id == 9)
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_chat" onclick="LeadMessage('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}')"><span> <i class="mdi mdi-chat-processing-outline fs-3 text-black me-1"></i>Message</span></a>
                                                            @endif
                                                       

                                                    </div>
                                                   @if (auth()->user()->hasPermission('Sales Management', 'Call Summary', 'Manage Lead'))
                                                    @if($category->outgoing_count == $category->total_appointments && $category->status != 4)
                                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_succ_sum" onclick="successSummary('{{$category->lead_name }}', '{{ $category->lead_mobile}}','The number of outgoing calls matches the follow-ups', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                     <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:76%!important">
                                                        <rect id="Layer_1" width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                        <g id="Layer_2">
                                                          <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                                          <path fill="#39ba77" d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                  c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                  c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                  c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                  c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z"></path>
                                                          <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                  c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                  c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                                        </g>
                                                      </svg>
                                                    </a>
                                                    @elseif($category->outgoing_count == $category->total_appointments || $category->total_appointments >= 5 && $category->status != 4)
                                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_succ_sum" onclick="successSummary('{{$category->lead_name }}', '{{ $category->lead_mobile}}','Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed!', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:76%!important">
                                                           <rect id="Layer_1" width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                           <g id="Layer_2">
                                                             <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                                             <path fill="#39ba77" d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                     c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                     c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                     c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                     c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z"></path>
                                                             <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                     c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                     c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                                           </g>
                                                         </svg>
                                                    </a>
                                                    {{-- Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed! --}}
                                                    @elseif($category->outgoing_count != $category->total_appointments && $category->status != 4)
                                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_fail_sum" onclick="failSummary('{{$category->lead_name }}', '{{ $category->lead_mobile}}', 'Outgoing calls and follow-ups are mismatched. Please review the call and follow-up details', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                        {{-- data-bs-toggle="modal" data-bs-target="#kt_modal_lead_wallet" onclick="leadWallet('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')"> --}}
                                                        <svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 500 500" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:76%!important">
                                                            <rect id="Layer_1" width="500" height="500" fill="#fff0f0" display="none"></rect>
                                                            <g id="Layer_2">
                                                                <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                                                <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                        l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                        c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                        c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                        c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                        c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                        C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                                            </g>
                                                        </svg>
                                                    </a>
                                                    @endif
                                                    @php
                                                        $currentDate = \Carbon\Carbon::now();
                                                        $registeredDate = \Carbon\Carbon::parse($category->registered_date);
                                                        $diffInDays = $registeredDate->diffInDays($currentDate);

                                                        $expectedOutgoingCount = 0;
                                                        if ($diffInDays >= 15) {
                                                            $expectedOutgoingCount = 5;
                                                        } elseif ($diffInDays >= 7) {
                                                            $expectedOutgoingCount = 4;
                                                        } elseif ($diffInDays >= 3) {
                                                            $expectedOutgoingCount = 3;
                                                        } elseif ($diffInDays >= 2) {
                                                            $expectedOutgoingCount = 2;
                                                        } elseif ($diffInDays >= 1) {
                                                            $expectedOutgoingCount = 1;
                                                        }
                                                    @endphp
                                                    @if($category->outgoing_count != $expectedOutgoingCount && $category->status != 4)
                                                        <a href="javascript:;" class="btn btn-icon btn-sm animate__animated animate__pulse animate__infinite" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_danger_sum" onclick="dangerSummary('{{$category->lead_name }}', '{{ $category->lead_mobile}}','{{$diffInDays}}', '{{ $category->outgoing_count }}', '{{ $expectedOutgoingCount}}', '{{ $category->total_appointments }}')">
                                                            {{-- Insert your SVG or button content here --}}
                                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33.5 31.25" id="ExclamationSign" style="width:76%!important">
                                                                <defs>
                                                                    <linearGradient id="a" x1="27.59" x2="8.53" y1="6.27" y2="33.97" gradientUnits="userSpaceOnUse">
                                                                        <stop offset="0" stop-color="#ff8383"></stop>
                                                                        <stop offset="1" stop-color="#fa1818"></stop>
                                                                    </linearGradient>
                                                                </defs>
                                                                <g fill="#ef1818">
                                                                    <path fill="url(#a)" d="m16.75,31.25c-7.48,0-11.22,0-13.38-1.57C1.49,28.31.27,26.2.03,23.88c-.28-2.66,1.59-5.9,5.33-12.37C9.1,5.04,10.97,1.8,13.41.71c2.13-.95,4.56-.95,6.69,0,2.44,1.09,4.31,4.33,8.05,10.8,3.74,6.48,5.61,9.71,5.33,12.37-.25,2.32-1.46,4.42-3.35,5.79-2.16,1.57-5.9,1.57-13.38,1.57Z"></path>
                                                                    <line x1="16.75" x2="16.75" y1="8.22" y2="18.09" fill="none" stroke="#ffffff" stroke-linecap="round" stroke-width="3"></line>
                                                                    <path fill="#ffffff" d="m18.4,23.02c0,.91-.74,1.64-1.64,1.64s-1.64-.74-1.64-1.64.74-1.64,1.64-1.64,1.64.74,1.64,1.64Z"></path>
                                                                </g>
                                                            </svg>
                                                        </a>
                                                    @endif

                                                </span>
                                            @endif
                                             @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            </form>
                        </div>
                        <div class="mt-4">
                        {{ $leads->appends(request()->except(['page', '_token']))->links() }}

                         </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Lead syllabus document send-->
     <div class="modal fade" id="kt_modal_syllabus_document_send" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Send Syllabus Document</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" id="lead_id_document" name="lead_id">
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_document">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_document">-</label>
                            </div>
                        </div>
                        <!-- Basic -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course Type<span class="text-danger">*</span></label>
                            <select id="course_type_id_msg" name="course_type_id_msg" class="select3 form-select" onchange="course_type_change_func(this.value)">
                                <option value="">Select Course Type</option>
                            </select>
                            <div class="text-danger" id="course_type_id_msg_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
                            <select id="course_id_msg" name="course_id_msg" class="select3 form-select">
                                <option value="">Select Course</option>
                            </select>
                            <div class="text-danger" id="course_id_msg_err"></div>
                        </div>

                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="sendDocumentBtn" onclick="sendSyllabus_func()" class="btn btn-primary">Send Syllabus</button>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead syllabus document send-->



    <!--begin::Modal -Lead Wallet-->
    <div class="modal fade" id="kt_modal_lead_wallet" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure
                    Want To Convert Lead to Lead Wallet?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 wallet_name"></label>
                </div>
                <form id="leadWallet_form" method="POST" action="{{ url('/lead_wallet_status') }}">
                    @csrf
                    {{-- <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_internal_select" name="reason_internal_select"
                            class="select3 form-select" onchange="toggleInputField_internal(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_internal) && count($reasonList_internal) > 0)
                            @foreach ($reasonList_internal as $i_reason)
                            <option value="{{ $i_reason->reason_name }}"
                                data-comments-check="{{ $i_reason->comments_check }}">
                                {{ $i_reason->reason_name }}
                                @endforeach
                                @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_internal_select_err"></div>
                        <div class="mt-4" id="internal_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_reason_text"
                                id="internal_reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="internal_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_comments_text"
                                id="internal_comments_text" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="internal_reason_text_err"></div>
                        <div class="text-danger" id="internal_comments_text_err"></div>
                    </div> --}}
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_wallet" id="lead_id_wallet">
                    <input type="hidden" name="staff_id_wallet" id="staff_id_wallet">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Wallet-->

     <!--begin::Modal - Convert bulk staff-->
      <div class="modal fade" id="kt_modal_bulk_convert_sales_person" tabindex="-1" aria-hidden="true"   data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                    <h3 class="my-4 text-center  fw-bold ">Bulk Transfer</h3>
                    <div class="container" id="swal2-html-container" style="display: block;">
                      <div class="mb-4 fw-bold fs-6">
                        <span id="bulk_convert_message"></span>
                      </div>
                      <div class="row d-flex justify-content-center mb-4">
                        <div class="col-lg-8">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Convert Staff<span class="text-danger">*</span></label>
                          <select id="bulk_assign_staff_conver" name="bulk_assign_staff_conver" class="select3 form-select">
                          </select>
                          <div class="text-danger" id="bulk_assign_staff_conver_err"></div>
                        </div>
                      </div>
                    <div class="text-center">
                      <button type="button" id="bulk_convert_btn" class="btn btn-danger me-3" onclick="bulk_request_pay();">
                        Convert</button>
                      <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                    </div>

                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
       </div>
    <!--end::Modal - Convert bulk staff-->
    <!--begin::Modal - Lead Call history-->
    <div class="modal fade" id="kt_modal_call_lead_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black" id="call_status_name">Call History</h3>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px px-2">Communicator</th>
                                        <th class="min-w-80px px-1">Call Date</th>
                                        <th class="min-w-100px px-1">Start Time</th>
                                        <th class="min-w-100px px-1">End Time</th>
                                        <th class="min-w-100px px-1">Duration</th>
                                        <th class="min-w-125px px-1">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="call-history-data" class="text-gray-600 fw-semibold fs-7">
                                    <!-- Data will be loaded here dynamically -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Call History-->

          <!--begin::Modal - Lead Call Summmary-->
          <div class="modal fade" id="kt_modal_call_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-md">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Call Summary <span id="call_summary_name" class="badge bg-info text-white fs-7 fw-bold"> </span></h3>
                        </div>
                        <div class="row">
                            <div class="col-4 mb-3">
                                 <div class="fs-6 fw-semibold">Incoming Call</div>
                                 <div id="incoming_count_summary"></div>
                            </div>
                            <div class="col-4 mb-3">
                                <div class="fs-6 fw-semibold">Outgoing Call</div>
                                <div id="outgoing_count_summary"></div>
                            </div>
                            <div class="col-4 mb-3">
                                <div class="fs-6 fw-semibold">Dialed Call</div>
                                <div id="dialed_count_summary"></div>
                            </div>
                            <div class="col-4 mb-3">
                                <div class="fs-6 fw-semibold">missed & Rejected Call </div>
                                <div id="missed_reject_count_summary"></div>
                            </div>
                            <div class="col-4 mb-3">
                                <div class="fs-6 fw-semibold">Average Outgoing Call Ratio</div>
                                <div id="aocr_count_summary"></div>
                            </div>
                            <div class="col-4 mb-3">
                                <div class="fs-6 fw-semibold">Average Missed Call Ratio</div>
                                <div id="amcr_count_summary"></div>
                            </div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Lead Call Summmary-->

      <!--begin::Modal - Lead Status -->
      <div class="modal fade" id="kt_modal_status_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Status Updation</h3>
                    </div>
                    <form id="changeStatusForm">
                        <div class="row mt-4">
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Status<span class="text-danger">*</span></label>
                                <select id="status_id" name="status" class="select3 form-select">
                                    <option value="">Select Status</option>
                                    <option value="4" selected>Customer</option>
                                </select>
                                <input type="hidden" class="form-control" name="lead_id"
                                    id="lead_status_id" />
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Status Updations</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
      <!--end::Modal - Lead Status-->

    <!--begin::Modal - Add Lead Appointment-->
    <div class="modal fade" id="kt_modal_add_lead_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Appointment - <span id="search_lead_name" class="badge bg-info text-end fs-6 text-white fw-semibold rounded"></span></span> </h3>
                    </div>
                    <form id="addLeadAppointmentForm" action="{{ route('lead_appointment_add') }}" method="POST" autocomplete="off">
                      @csrf
                      <div class="form-repeater_ld_appmt_add">
                          <div data-repeater-list="group-a_led_question">
                              <div data-repeater-item>
                                  <div class="row mt-4">
                                      <div class="col-lg-11">
                                          <div class="row">
                                            <input type="hidden" name="lead_id_add" id="lead_id_add">
                                              <div class="col-lg-4 mb-3">
                                                  <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Category<span class="text-danger">*</span></label>
                                                  <select id="appt_catg_add" class="select3 form-select" name="appt_catg_add">
                                                      <option value="">Select Appointment Category</option>
                                                      <option value="Walk-in">Walk-in</option>
                                                      <option value="Online">Online</option>
                                                      <option value="Offline">Offline</option>
                                                      <option value="Video">Video</option>
                                                      <option value="Payment">Payment</option>
                                                      <option value="Registration">Registration</option>
                                                  </select>
                                                  <div class="text-danger" id="appt_catg_add_err"></div>
                                              </div>
                                              <div class="col-lg-4 mb-3">
                                                  <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Date<span class="text-danger">*</span></label>
                                                  <input type="text" class="form-control" placeholder="Select Appointment Date" id="ld_appt_dt_add" name="ld_appt_dt_add"/>
                                                  <div class="text-danger" id="ld_appt_dt_add_err"></div>
                                              </div>
                                              @if($user_data)
                                              @if($user_data->role_id == 11)
                                              <input type="hidden" id="assg_dept_add" name="assg_dept_add" value="{{ $user_data->department_id }}">
                                              <input type="hidden" id="assg_dept_add_err">

                                              <input type="hidden" id="assg_staff_add" name="assg_staff_add" value="{{ $user_data->sno }}">
                                              <input type="hidden" id="assg_staff_add_err" >

                                              @else
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Department <span class="text-danger">*</span></label>
                                                    <select id="assg_dept_add" name="assg_dept_add" class="select3 form-select" onchange="depat_staff_func(this.value)">
                                                    </select>
                                                    <div class="text-danger" id="assg_dept_add_err"></div>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span class="text-danger">*</span></label>
                                                    <select id="assg_staff_add" name="assg_staff_add" class="select3 form-select">
                                                      <option value="">select Staff</option>
                                                    </select>
                                                    <div class="text-danger" id="assg_staff_add_err"></div>
                                                </div>
                                              @endif
                                              @endif
                                              <div class="col-lg-4 mb-3">
                                                  <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Reason<span class="text-danger">*</span></label>
                                                  <textarea class="form-control" rows="1" id="appt_reason_add" name="appt_reason_add" placeholder="Enter Appointment Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                                                  <div class="text-danger" id="appt_reason_add_err"></div>
                                              </div>
                                          </div>
                                      </div>
                                      {{-- <div class="col-lg-1">
                                          <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 ld_appmt_add_del" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete" id="ld_appmt_add_del" style="display: none !important;">
                                              <i class="mdi mdi-delete fs-4"></i>
                                          </a>
                                      </div> --}}
                                  </div>
                                  {{-- <hr class="my-1"> --}}
                              </div>
                          </div>
                      </div>
                      {{-- <div class="mb-1 mt-1">
                          <button class="btn btn-primary ld_appmt_add" data-bs-toggle="tooltip" data-bs-placement="top" title="Add" data-repeater-create id="ld_appmt_add">
                              <i class="mdi mdi-plus me-1"></i>
                          </button>
                      </div> --}}
                      <div class="d-flex justify-content-end align-items-center mt-4">
                          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                          <button type="button" id="addSubmit" onclick="addLeadvalidateForm()" class="btn btn-primary">Create Appointment</button>
                      </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
  <!--end::Modal - Add Lead Appointment-->

    <!--begin::Modal - Import Lead-->
    <div class="modal fade" id="kt_modal_lead_import" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Lead</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Lead Import</label>
                            <a download="Lead Data" target="_blank" class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="leadImportForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf <!-- Include CSRF token for security -->
                        <div class="row">
                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>
                                <select id="lead_type_import" name="lead_type_id"  class="select3 form-select" data-placeholder="Select Lead Type">
                                    <option value="">Select Lead Type</option>
                                </select>
                            </div>
                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                                <select id="lead_source_import" name="lead_source_id" class="select3 form-select">
                                    <option value="">Select Lead Source</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 mb-1">
                             <input name="file_import" type="file" accept=".xls" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Import</button>
                            </div>
                        </div>

                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Lead-->
    <div class="modal fade" id="kt_modal_phone_verify" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Phone Verification Details</h3>
                    </div>
                    <div class="modal-body" id="phone_verify_modal_content">
                        <!-- Phone verification details will be dynamically inserted here -->
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
    </div>

    <!--begin::Modal - Success Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_succ_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="succ_lead_name"></label>
                            [<label id="succ_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                           <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_succ_call_count"></span>
                           </label>
                           <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_succ_count"></span>
                           </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_succ_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Success Lead Call Summmary-->

    <!--begin::Modal - Fail Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_fail_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="fail_lead_name"></label>
                            [<label id="fail_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                           <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_fail_call_count"></span>
                           </label>
                           <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_fail_count"></span>
                           </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_fail_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Fail Lead Call Summmary-->

    <!--begin::Modal - Danger Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_danger_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary</h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="danger_lead_name"></label>
                            [<label id="danger_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_danger_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_danger_count"></span>
                            </label>
                        </div>
                        <!-- Properly aligned section -->
                        <div class="text-center mt-4">
                            <label class="fw-bold fs-5 text-primary bg-warning px-2" id="danger_lead_msg"></label>
                            <table class="table table-borderless text-primary fw-semibold fs-5 mx-auto" style="width: auto;">
                                <tbody>
                                    <tr>
                                        <td class="text-end pe-3">Days since registration:</td>
                                        <td class="text-start"><label id="lead_danger_days"></label> days</td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Expected Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_expected"></label></td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Actual Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_call_count_actual"></label></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Danger Lead Call Summmary-->

    <!--begin::Modal - Import old Lead-->
    <div class="modal fade" id="kt_modal_lead_import_old" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Lead Old</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Lead Import</label>
                            <a download="Lead Data" target="_blank" class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="leadImportOldForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf <!-- Include CSRF token for security -->
                        <div class="row">
                            <div class="col-lg-6 mb-1">
                             <input name="file_import" type="file" accept=".xls" required />
                            </div>
                        </div>
                        <div class="row">
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <div class="position-relative">
                                    <button type="submit" class="btn btn-primary" id="importButton">
                                        Import
                                    </button>
                                    <div id="importLoader" class="import-loader d-none">
                                        <div class="spinner-border text-light" role="status"></div>
                                        <span class="ms-2">Importing...</span>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import old Lead-->

    <!--begin::Modal - Convert Branch -->
    <div class="modal fade" id="kt_modal_lead_transfer" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer Log </h3>
                    </div>
                        <div class="row mt-4">
                            <input type="hidden" id="lead_id_transfer" name="lead_id_transfer">
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Lead Name</label>
                                    <span class="col-1">:</span>
                                    <label class="col-6 text-dark fs-6 fw-semibold" id="lead_name_transfer"></label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Mobile No</label>
                                    <span class="col-1">:</span>
                                    <label class="col-6 text-dark fs-6 fw-semibold" id="lead_mobile_transfer"></label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Lead Source</label>
                                    <span class="col-1">:</span>
                                    <label class="col-6 text-dark fs-6 fw-semibold" id="lead_src_transfer"></label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-5 text-dark fs-6 fw-semibold">Registered Date</label>
                                    <span class="col-1">:</span>
                                    <label class="col-6 text-dark fs-6 fw-semibold" id="lead_reg_date_transfer"></label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3" >
                                <table
                                    class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-100px">Staff</th>
                                            <th class="min-w-100px">Transfered From</th>
                                            <th class="min-w-150px">End Date</th>
                                            <th class="min-w-50px">Duration</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-semibold fs-7" id="transfer_log_div">
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Branch -->

   <!--begin::Modal - Add Lead-->
    <div class="modal fade" id="kt_modal_add_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl" id="addModal">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Lead</h3>
                    </div>
                    <form id="leadAddForm" action="{{ route('add_lead') }}" method="POST" novalidate autocomplete="off">
                        @csrf

                        <div class="row" >
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_name_create" name="lead_name" placeholder="Enter Lead Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                                <div class="text-danger" id="lead_name_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio1" value="1"  checked/>
                                    <label class="form-check-label" for="inlineRadio1">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio2" value="2" />
                                    <label class="form-check-label" for="inlineRadio2">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio3" value="3" />
                                    <label class="form-check-label" for="inlineRadio3">Others</label>
                                </div>
                                <div class="text-danger" id="lead_gender_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id=""   name="lead_dob" readonly placeholder="Select Date" class=" common_date_class form-control" />

                                </div>
                                <div class="text-danger" id="lead_dob_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <button class="btn btn-outline-primary dropdown-toggle waves-effect" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="countryDropdownButton" name="countryDropdownButton">Phn Code</button>
                                    <ul class="dropdown-menu" id="countryDropdownMenu" name="countryDropdownMenu" style="max-height: 250px; overflow-y: auto; position: relative;">
                                        <li>
                                            <input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;">
                                        </li>
                                    </ul>
                                    <input type="text" class="form-control" id="lead_mobile_create" name="lead_mobile_create" maxlength="12" placeholder="Enter Mobile Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                                    <input type="hidden" id="country_code_name" name="country_code_name" value=""/>
                                </div>
                                <div class="text-danger" id="lead_mobile_create_err"></div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="border rounded-3 p-3" style="background:#f8fbfa;border-color:#dce9e5!important">
                                    <div class="d-flex align-items-center gap-2 mb-2">
                                        <i class="mdi mdi-whatsapp text-success fs-4"></i>
                                        <strong class="text-dark">WhatsApp consent (optional)</strong>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" value="1" id="wa_utility_opt_in" name="wa_utility_opt_in">
                                        <label class="form-check-label" for="wa_utility_opt_in">The person explicitly agreed to receive enquiry, appointment and service updates from this business through WhatsApp.</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" value="1" id="wa_marketing_opt_in" name="wa_marketing_opt_in">
                                        <label class="form-check-label" for="wa_marketing_opt_in">The person explicitly agreed to receive course offers, promotions and other marketing messages through WhatsApp.</label>
                                    </div>
                                    <small class="text-muted d-block">Leave unchecked unless the person has clearly agreed. The selected consent category and form submission evidence are recorded in the consent registry before the welcome automation is queued. Creating a lead alone does not opt the person in.</small>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                                <input type="text" class="form-control me-2" maxlength="12"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" id="lead_alternate_create"   name="lead_alternate_mobile" placeholder="Enter Alternate Mobile Number" />
                                <div class="text-danger" id="lead_alternate_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
                                <select id="lead_marital_create"   name="lead_marital_status" class="select3 form-select">
                                    <option value="">Select Marital Status</option>
                                    <option value="1">Married</option>
                                    <option value="2">Un Married</option>
                                </select>
                                <div class="text-danger" id="lead_marital_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email ID</label>
                                <input type="text" class="form-control" id="lead_email_create"   name="lead_email_id" placeholder="Enter E-Mail ID" oninput=" this.value = this.value.toLowerCase();" />
                                <div id="lead_email_create_err" class="text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country</label>
                                <select id="countryId" name="country" class="select3 form-select">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="text-danger" id="lead_country_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State</label>
                                <select  id="stateId" name="state" class="select3 form-select">
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="lead_state_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City</label>
                                <select  id="cityId" name="city" class="select3 form-select">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="lead_city_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street</label>
                                <input type="text" id="address"  name="address" class="form-control me-2" placeholder="Enter Area / Street" />
                                <div class="text-danger" id="lead_country_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type</label>
                                <select id="lead_type_create" name="lead_type_id"  class="select3 form-select" data-placeholder="Select Lead Type">
                                    <option value="">Select Lead Type</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                                <select id="lead_source_create" name="lead_source_id" class="select3 form-select">
                                    <option value="">Select Lead Source</option>
                                </select>
                                <div class="text-danger" id="lead_source_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Comments</label>
                                <textarea class="form-control" rows="1" id="" name="lead_comments" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Course<span class="text-danger">*</span></label>
                                <select id="lead_course_create" name="course_id[]"  class="select3 form-select" multiple  data-placeholder="Select Course">

                                </select>
                                <div class="text-danger" id="lead_course_create_err"></div>
                            </div>
                            <div class="row mt-4">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Lead Knowledge Tag</label>
                              <div class="form-floating form-floating-outline">
                                  <input id="lead_KnowledgeTag" name="lead_KnowledgeTag" class="form-control h-auto" placeholder="Select Knowledge Tags" value="">
                              </div>
                              <div class="text-danger" id="lead_KnowledgeTag_err"></div>
                          </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_lead_add" onclick="AddvalidateForm()">Create Lead</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Lead-->

    <!--begin::Modal - Edit Lead-->
    <div class="modal fade" id="kt_modal_edit_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl" id="editModal">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Lead</h3>
                    </div>
                    <form id="leadEditForm" action="{{ route('lead_update') }}" method="POST" novalidate autocomplete="off">
                        @csrf
                        <input type="hidden" id="lead_id_edit" name="lead_id">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_name_edit" name="lead_name" placeholder="Enter Lead Name"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                                <div class="text-danger" id="lead_name_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio1edit" value="1" checked />
                                    <label class="form-check-label" for="inlineRadio1edit">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio2edit" value="2"  />
                                    <label class="form-check-label" for="inlineRadio2edit">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio3edit" value="3" />
                                    <label class="form-check-label" for="inlineRadio3edit">Others</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_dob_up" name="lead_dob" placeholder="Select Date" class="form-control"  />
                                </div>
                                <div class="text-danger" id="lead_dob_up_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Registered Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_reg_date_up"  name="lead_reg_date_up" readonly placeholder="Select Date" class="form-control common_date_class" />

                                </div>
                                <div class="text-danger" id="lead_reg_date_up_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <button class="btn btn-outline-primary dropdown-toggle waves-effect" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="countryDropdownButton_edit" name="countryDropdownButton">IN - +91</button>
                                    <ul class="dropdown-menu" id="countryDropdownMenu_edit" name="countryDropdownMenu" style="max-height: 250px; overflow-y: auto; position: relative;">
                                        <li>
                                            <input type="text" id="countrySearch_edit" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;">
                                        </li>
                                    </ul>
                                    <input type="text" class="form-control" id="lead_mobile_edit" name="lead_mobile" maxlength="12" placeholder="Enter Mobile Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                                    <input type="hidden" id="country_code_name_edit" name="country_code_name_edit" value="91">
                                </div>
                                <div class="text-danger" id="lead_mobile_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                                <input type="text" class="form-control me-2" id="lead_alternate_edit" placeholder="Enter Alternate Mobile Number" name="lead_alternate_mobile" maxlength="12"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
                                <select id="lead_marital_edit" name="lead_marital_status" class="select3 form-select trigerchange">
                                    <option value="">Select Marital Status</option>
                                    <option value="1">Married</option>
                                    <option value="2">Un Married</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email ID</label>
                                <input type="text" class="form-control" name="lead_email_id" id="lead_email_edit" placeholder="Enter E-Mail ID" oninput=" this.value = this.value.toLowerCase();" />
                                <div class="text-danger" id="lead_email_edit_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country</label>
                                <select id="country_id_edit" name="country_edit" class="select3 form-select trigerchange">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="text-danger" id="country_id_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State</label>
                                <select id="state_edit" name="state_edit" class="select3 form-select trigerchange">
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="state_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City</label>
                                <select id="city_edit" name="city_edit" class="select3 form-select trigerchange">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="city_edit_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street</label>
                                <input type="text" class="form-control me-2" id="lead_address_edit" name="address" placeholder="Enter Area / Street" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type</label>
                                <select id="lead_type_edit" name="lead_type_id_edit" class="select3 form-select trigerchange">


                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span class="text-danger">*</span></label>
                                <select id="lead_source_edit" name="lead_source_id_edit" class="select3 form-select trigerchange">

                                </select>
                                <div class="text-danger" id="lead_source_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Comments</label>
                                <textarea class="form-control" rows="1" id="comments_edit"  name="lead_comments"
                                placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Course Name<span class="text-danger">*</span></label>
                                <select id="lead_course_edit" name="course_id_edit[]" class="select3 form-select trigerchange" multiple>


                                </select>
                                <div class="text-danger" id="lead_course_edit_err"></div>
                            </div>
                            <div class="row mt-4">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Lead Knowledge Tag</label>
                              <div class="form-floating form-floating-outline">
                                  <input id="lead_Knowledge_edit_tag" name="lead_Knowledge_edit_tag" class="form-control h-auto" placeholder="Select Knowledge Tags" value="">
                              </div>
                              <div class="text-danger" id="lead_Knowledge_edit_tag_err"></div>
                          </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_lead_edit" onclick="EditvalidateForm()">Update Lead</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit Lead-->

    <!--begin::Modal - View Lead-->
    <div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-6">
                        <h3 class="text-center text-black">View Lead -
                            <label id="lead_source_view_h" class="me-4 badge bg-warning text-black rounded fw-bold fs-4"></label>
                        </h3>
                    </div>
                    <form>
                    <div class="row">
                        <div class="col-lg-6 text-black fs-5 fw-bold"><u>Basic Information</u></div>
                        <div class="col-lg-6 d-flex align-items-end justify-content-end">
                            <div class="row">
                                <div class="col-lg-9">
                                    <label id="lead_id_view" class="badge bg-info text-end fs-6 text-white fw-semibold rounded"></label>
                                </div>
                                <div class="col-lg-3" style="display: none;" id="edit_icon">
 @if(auth()->user()->hasPermission('Sales Management', 'Edit', 'Manage Lead'))
                                    <a href="javascript:;"  class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead"onclick="populateEditModal()"><i class="mdi mdi-square-edit-outline fs-3 text-black" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Edit"></i></a>
                                        @endif
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Created Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_created" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_name_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Gender</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_gender_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Date of Birth</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_dob_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_email_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Mobile Number</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_mobile_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Alternate Number</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_alternate_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Marital Status</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_marital_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Country</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_country_view" class="col-7 text-black fs-6 fw-bold">India</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">State</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_state_view" class="col-7 text-black fs-6 fw-bold">Tamil Nadu</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">City</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_city_view" class="col-7 text-black fs-6 fw-bold">Madurai</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Area / street</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_address_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold"><u>Lead Information</u></div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Lead Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_type_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_source_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Course</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_course_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Potential Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_potential_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-black fs-7 fw-semibold">Comments</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                            </div>
                            <div class="row mb-4">
                                <label id="lead_comments_view" class="col-12 text-black fs-6 fw-bold">&emsp;</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="row mb-4">
                            <label class="col-4 text-black fs-7 fw-semibold">Lead Knowledge Tag</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="lead_tag_view" class="col-7 text-black fs-6 fw-bold"></label>
                          </div>
                        </div>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Lead-->

    <!--begin::Modal - Delete Lead-->
    <div class="modal fade" id="kt_modal_delete_lead" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="delete_message"></span></div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-danger me-3"onclick="deleteCourseCategory()">Yes, delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Lead-->

    <!--begin::Modal - Followup Lead-->
    <div class="modal fade" id="kt_modal_follow_up_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Schedule</h3>
                    </div>
                    <form action="{{ route('add_appointment') }}" method="POST"  onsubmit="return FollowupvalidateForm()" novalidate autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                                <div>
                                   <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_app">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div >
                                  <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_app">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Date<span class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_apt_sch" name="appointment_date" placeholder="Select Date" class="form-control"  />
                                </div>
                                <div class="text-danger" id="apt_date_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Time<span class="text-danger">*</span></label>
                                <input type="text" id="apt_time_followp" class="form-control common_time_class" name="appointment_time"  placeholder="HH:MM"  />
                                <div class="text-danger" id="apt_time_err"></div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="schedule_button">Schedule</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Followup Lead-->
    <!--begin::Modal - Customer HotLead-->
     <div class="modal fade" id="kt_modal_hot_lead" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Hot Lead?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer HotLead-->
    <!--begin::Modal - Followup Lead Schedule-->
     <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                                <div>
                                   <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_reop">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div >
                                  <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_reop">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="app_date" placeholder="Select Date" class="form-control"  disabled />
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Time</label>
                                <input type="text" class="form-control " placeholder="HH:MM" id="app_time"  disabled />
                            </div>
                            <div class="col-lg-12 mb-3 d-flex justify-content-end">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Reshcedule Count</label> <span class="badge bg-danger" id="followup_reschedule_rep_count"></span>
                            </div>

                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span class="text-danger">*</span></label>
                               <div class="form-check form-check-inline" id="prog_yes" onclick="yes_func();">
                                  <input class="form-check-input" type="radio" name="progressed" id="progressed_yes" value="1">
                                  <label class="form-check-label" for="progressed_yes">Yes</label>
                              </div>
 
                              <div class="form-check form-check-inline" id="prog_no" onclick="no_func();">
                                  <input class="form-check-input" type="radio" name="progressed" id="progressed_no" value="2">
                                  <label class="form-check-label" for="progressed_no">No</label>
                              </div>
                            </div>
                            <div class="col-lg-12 mb-3" id="message" name="message" style="display: none !important;">
                                <div class="row">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold d-block">Conversation Message<span class="text-danger">*</span></label>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="app_score" onclick="onlyOne(this)" value="1" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Positive</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="app_score" onclick="onlyOne(this)" value="-1" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Negative</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="app_score" onclick="onlyOne(this)" value="0"/>
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Neutral</label>
                                        </div>
                                    </div>
                                    <!--<div class="col-lg-6 mb-3">-->
                                    <!--    <label class="text-danger mb-1 fs-6 fw-semibold d-block">Highly Interested Lead</label>-->
                                    <!--    <div class="form-check form-check-inline">-->
                                    <!--        <input class="form-check-input" type="checkbox" name="hot_lead" id="hot_lead" />-->
                                    <!--        <label class="text-dark mb-1 fs-6 fw-semibold">Hot Lead</label>-->
                                    <!--    </div>-->

                                    <!--</div>-->
                                    <div class="col-lg-12 mb-3">
                                        <textarea class="form-control" rows="3" id="convo_message" placeholder="Enter Conversation Message" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="mb-3" id="reason" name="reason" style="display: none !important;">-->
                            <!--    <div class="col-lg-12 mb-3">-->
                            <!--        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>-->
                            <!--        <textarea class="form-control" rows="3" id="app_reason" placeholder="Enter Reason"></textarea>-->
                            <!--    </div>-->
                            <!--    <div class="row mb-3">-->
                            <!--        <div class="col-lg-6 mb-3">-->
                            <!--            <label class="text-dark mb-1 fs-6 fw-semibold">Re-Followup Date</label>-->
                            <!--            <div class="input-group input-group-merge">-->
                            <!--                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>-->
                            <!--                <input type="text" id="re_app_date" placeholder="Select Date" class="form-control" name="appointment_date" />-->
                            <!--            </div>-->
                            <!--        </div>-->
                            <!--        <div class="col-lg-6 mb-3">-->
                            <!--            <label class="text-dark mb-1 fs-6 fw-semibold">Re-Followup Time</label>-->
                            <!--            <input type="text" class="form-control common_time_class " placeholder="HH:MM" id="re_app_time" name="appointment_time" />-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--</div>-->
                             <div class="mb-3" id="reason" name="reason" style="display: none !important;">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                                    {{-- <select id="app_reason" name="app_reason" class="select3 form-select">

                                    </select> --}}
                                    <select id="app_reason" name="app_reason" class="select3 form-select"
                                    onchange="toggleInputField_followup(this.value)">
                                    <option value="">Select Reason</option>
                                      @if (isset($followupReasonList))
                                      @foreach ($followupReasonList as $s_reason)
                                      <option value="{{ $s_reason->reason_name }}"
                                          data-comments-check-followup="{{ $s_reason->comments_check }}">
                                          {{ $s_reason->reason_name }}
                                      </option>
                                      @endforeach
                                      @endif
                                      <option value="1">Others</option>
                                </select>
                                <div class="text-danger" id="app_reason_select_err"></div>
                                <div class="mt-4" id="followup_reason_div" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="followup_reason_text" id="followup_reason_text"
                                        value="" placeholder="Enter Reason">
                                </div>
                                {{-- <div class="mt-4" id="followup_comments_div" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="followup_comments_text"
                                        id="followup_comments_text" value="" placeholder="Enter Comments">
                                </div> --}}
                                <div class="text-danger" id="followup_reason_text_err"></div>
                                {{-- <div class="text-danger" id="followup_comments_text_err"></div> --}}

                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Re-Appointment Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date" class="form-control" name="appointment_date" />
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Re-Appointment Time</label>
                                        <input type="text" class="form-control common_time_class_new " placeholder="HH:MM" id="re_app_time" name="appointment_time" />
                                    </div>
                                    <div class="col-lg-12 mb-3 d-flex justify-content-end">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Reshcedule Count</label> <span class="badge bg-danger" id="followup_reschedule_count"></span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <div class="accordion mb-2" id="accordionExample">
                                    <div class="accordion-item active">
                                        <h2 class="accordion-header" id="headingOne">
                                            <button type="button" class="accordion-button fw-bold" data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="false" aria-controls="accordionOne" role="tabpanel">
                                                Follow Up History<span class="ms-2 badge bg-info text-white rounded fw-bold fs- " id="app_count">
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="accordionOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1" >
                                                            <thead>
                                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-80px">Date</th>
                                                                    <th class="min-w-50px">Time</th>
                                                                    <th class="min-w-80px">Followed BY</th>
                                                                    <th class="min-w-80px">Reason</th>
                                                                    <!-- <th class="min-w-80px">ReSchedule</th> -->
                                                                    <th class="min-w-50px">Score</th>
                                                                    <th class="min-w-80px">Conversation</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="historicalLeadIdsTableBody" class="text-black fw-semibold fs-7">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="accordion" id="accordionExample2">
                                  <div class="accordion-item active">
                                      <h2 class="accordion-header" id="headingTwo">
                                          <button type="button" class="accordion-button fw-bold" data-bs-toggle="collapse" data-bs-target="#accordionTwo" aria-expanded="false" aria-controls="accordionTwo" role="tabpanel">
                                              Appointment History<span class="ms-2 badge bg-info text-white rounded fw-bold fs- " id="apptmnt_count">
                                              </span>
                                          </button>
                                      </h2>
                                      <div id="accordionTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample2">
                                          <div class="accordion-body">
                                              <div class="row">
                                                  <div class="col-lg-12">
                                                      <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1" >
                                                          <thead>
                                                              <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                  <th class="min-w-50px">S.No</th>
                                                                  <th class="min-w-100px">Date / Time</th>
                                                                  <th class="min-w-50px">Category</th>
                                                                  <th class="min-w-80px">Status</th>
                                                                  <th class="min-w-80px">Conversation</th>
                                                                  <th class="min-w-80px">Reason</th>
                                                              </tr>
                                                          </thead>
                                                          <tbody id="appointmentLeadIdsTableBody" class="text-black fw-semibold fs-7">

                                                          </tbody>
                                                      </table>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="rescheduleBtn">Submit Report</button>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Followup Lead Schedule-->
    <!--begin::Modal - Add Spam-->
    <div class="modal fade" id="kt_modal_add_spam" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md" id="addSpamModal">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Create Spam</h3>
                </div>
                <form id="spamAddForm" action="{{ route('add_spam') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                            <input type="text" class="form-control" id="lead_name_spam" name="lead_name_spam"
                                placeholder="Enter Lead Name"
                                oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="lead_mobile_spam" maxlength="12"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                name="lead_mobile_spam" placeholder="Enter Mobile Number" />
                            <div class="text-danger" id="lead_mobile_spam_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            {{-- {{ $reasonList }} --}}
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span class="text-danger">*</span></label>
                            <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleAddSpam(this.value)">
                                <option value="">Select Reason</option>
                                @if (isset($reasonList) && count($reasonList) > 0)
                                @foreach ($reasonList as $reason_spam)
                                <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                                    {{ $reason_spam->reason_name }}
                                </option>
                                @endforeach
                                @endif
                                <option value="1">Others</option>
                            </select>
                            <div class="text-danger" id="reason_select_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                            <div class="text-danger" id="reason_text_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                            <div class="text-danger" id="spam_comments_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="submit_spam_add"
                            onclick="spamAddvalidateForm()">Create Spam</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

    <!--begin::Modal - Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule_again"  tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false" >
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">New Followup</h3>
                    </div>
                    <form action="{{ route('add_appointment') }}" method="POST"  autocomplete="off" id="follow_submit">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id_again">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                                <div>
                                   <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_app_again">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div >
                                  <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_app_again">-</label>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="app_date_again" name="appointment_date" placeholder="Select Date " class="form-control cus_date_doj"   />
                                </div>
                                   <div class="text-danger" id="follow_time_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Followup Time</label>
                                <input type="text" class="form-control common_time_class_new" placeholder="HH:MM" id="app_time_again" name="appointment_time" />
                            </div>
                            <div class="col-lg-12 mb-3 d-flex justify-content-end">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Reshcedule Count  </label> <span class="badge bg-danger" id="followup_reschedule_count_again">0</span>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <div class="accordion mb-2" id="accordionExample">
                                    <div class="accordion-item active">
                                        <h2 class="accordion-header" id="headingOne">
                                            <button type="button" class="accordion-button fw-bold" data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="false" aria-controls="accordionOne" role="tabpanel">
                                                Follow Up History<span class="ms-2 badge bg-info text-white rounded fw-bold fs- " id="app_count_again">
                                                </span>
                                            </button>
                                        </h2>
                                        <div id="accordionOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1" >
                                                            <thead>
                                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-80px">Date</th>
                                                                    <th class="min-w-50px">Time</th>
                                                                    <th class="min-w-80px">Followed BY</th>
                                                                    <th class="min-w-80px">Reason</th>
                                                                    <!-- <th class="min-w-80px">ReSchedule</th> -->
                                                                    <th class="min-w-50px">Score</th>
                                                                    <th class="min-w-80px">Conversation</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody id="historicalLeadIdsTableBodyAgain" class="text-black fw-semibold fs-7">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="accordion" id="accordionExample2">
                                  <div class="accordion-item active">
                                      <h2 class="accordion-header" id="headingTwo">
                                          <button type="button" class="accordion-button fw-bold" data-bs-toggle="collapse" data-bs-target="#accordionTwo" aria-expanded="false" aria-controls="accordionTwo" role="tabpanel">
                                              Appointment History<span class="ms-2 badge bg-info text-white rounded fw-bold fs- " id="apptmnt_count_again">
                                              </span>
                                          </button>
                                      </h2>
                                      <div id="accordionTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample2">
                                          <div class="accordion-body">
                                              <div class="row">
                                                  <div class="col-lg-12">
                                                      <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1" >
                                                          <thead>
                                                              <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                                  <th class="min-w-50px">S.No</th>
                                                                  <th class="min-w-100px">Date / Time</th>
                                                                  <th class="min-w-50px">Category</th>
                                                                  <th class="min-w-80px">Status</th>
                                                                  <th class="min-w-80px">Conversation</th>
                                                                  <th class="min-w-80px">Reason</th>
                                                              </tr>
                                                          </thead>
                                                          <tbody id="appointmentLeadIdsTableBodyAgain" class="text-black fw-semibold fs-7">

                                                          </tbody>
                                                      </table>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="sche_button">Submit Report</button>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Followup Lead Schedule-->

    <!--begin::Modal - Transfer Lead to Customer-->
    <div class="modal fade" id="kt_modal_lead_to_cus" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead To Customer</h3>
                    </div>
                    <form method="POST" action="{{ route('convert_customer') }}" autocomplete="off">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="lead_id" id="lead_id_cus" value="">
                            <div class="col-lg-12 mt-4">
                                <h5 class="text-dark mb-1 fw-semibold">Are You Sure Want To Convert Lead To Customer?</h5>
                                <div class="text-center">
                                    <label class="fw-bold fs-5 text-danger" id="lead-name" ></label>
                                    <span class="fw-bold fs-5 text-danger" id="lead-mobile">[]</span>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                {{-- <a id="lead-convert-link" type="submit" href="#" class="btn btn-primary me-3"  onclick="submitConvertForm()">
                                    Yes
                                </a> --}}
                                {{-- <a  href="/sales/customer/customer_add/" class="btn btn-primary me-3">
                                    Yes
                                </a> --}}

                                <button type="submit" class="btn btn-primary me-3" >Yes</button>
                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Transfer Lead to Customer-->

     <!--begin::Modal - Convert Branch -->
     <div class="modal fade" id="kt_modal_covert_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
      <!--begin::Modal dialog-->
      <div class="modal-dialog modal-md">
          <!--begin::Modal content-->
          <div class="modal-content rounded">
              <!--begin::Modal header-->
              <div class="modal-header justify-content-end border-0 pb-0">
                  <!--begin::Close-->
                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                      <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                      <span class="svg-icon svg-icon-1">
                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                          </svg>
                      </span>
                      <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
              </div>
              <!--end::Modal header-->
              <!--begin::Modal body-->
              <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                  <!--begin::Heading-->
                  <div class="mb-4 text-center">
                      <h3 class="text-center mb-4 text-black">Convert Branch </h3>
                       <h5>Lead - [ <span id="covert_lead_name" class="text-success"></span> ] </h5>
                  </div>
                  <form id="convertBranchForm">
                      <div class="row mt-4">
                          <div class="col-lg-12 mb-3">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                              <select id="convert_branch_id" name="convert_branch" class="select3 form-select" onchange="convert_staff_func(this.value)">
                                  <option value="">Select Branch</option>
                                  @php
                                    $get_branch_franchise_list=$helper->get_branch_franchise_list();

                                  @endphp
                                   @if ($get_branch_franchise_list)
                                   @php
                                       $branches = $get_branch_franchise_list->filter(fn($item) => $item['branch_type'] == 1 && $item['sno'] != $login_branch_data->sno);
                                       $franchises = $get_branch_franchise_list->filter(fn($item) => $item['branch_type'] == 2 && $item['sno'] != $login_branch_data->sno);
                                   @endphp

                                   @if ($branches->count())
                                       <optgroup label="Branches">
                                           @foreach ($branches as $branch)
                                               <option value="{{ $branch['sno'] }}" >
                                                   {{ $branch['branch_name'] }}
                                               </option>
                                           @endforeach
                                       </optgroup>
                                   @endif
                                   @if ($franchises->count())
                                       <optgroup label="Franchises">
                                           @foreach ($franchises as $franchise)
                                               <option value="{{ $franchise['sno'] }}" >
                                                   {{ $franchise['franchise_name'] }}
                                               </option>
                                           @endforeach
                                       </optgroup>
                                   @endif
                               @endif
                              </select>
                              <input type="hidden" class="form-control" name="covert_lead_id"
                                  id="covert_lead_id" />
                                  <div class="text-danger" id="convert_branch_id_err"></div>

                          </div>
                          <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                            <select id="convert_staff_id" name="convert_staff" class="select3 form-select">
                                <option value="">Select Staff</option>
                            </select>
                            <div class="text-danger" id="convert_staff_id_err"></div>

                        </div>
                          <div class="d-flex justify-content-center align-items-center mt-4">
                              <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                              <button type="submit" class="btn btn-primary">Convert Branch</button>
                          </div>
                      </div>
                  </form>
              </div>
              <!--end::Modal body-->
          </div>
          <!--end::Modal content-->
      </div>
      <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Branch -->
  
     <!--begin::Modal -Lead Drop List-->
    <div class="modal fade" id="kt_modal_lead_drop_list" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
 
        <div class="modal-dialog modal-md">
 
            <div class="modal-content rounded">
 
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title fw-bold text-danger">
                        Dead Lead Process
                    </h5>
 
                    <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                    </button>
                </div>
 
                <!-- Modal Body -->
                <div class="modal-body">
 
                    <div class="text-center mb-3">
                        <div class="swal2-icon swal2-warning swal2-icon-show" style="display:inline-flex;">
                            <div class="swal2-icon-content">!</div>
                        </div>
                    </div>
 
                    <div class="text-center mb-3">
                        <p class="text-dark fw-semibold">
                            These dead leads are <span class="text-danger fs-4">still not approved by the Business Head</span>.
                            Only after approval you can move this lead to Dead.
                        </p>
                    </div>
 
                    <div class="text-center mb-3">
                        <label class="text-info fw-bold fs-5 lead-name"></label>
                    </div>
 
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mb-0">
 
                            <thead class="table bg-primary text-white text-center">
                                <tr>
                                    <th>Lead ID</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                </tr>
                            </thead>
 
                            <tbody id="deadLeadTableBody">
                                <!-- AJAX rows will load here -->
                            </tbody>
 
                        </table>
                    </div>
 
                </div>
 
            </div>
 
        </div>
    </div>
    <!--end::Modal - Lead Drop List-->
   <!--begin::Modal -Lead spam List-->
    <div class="modal fade" id="kt_modal_lead_spam_list" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
 
        <div class="modal-dialog modal-md">
 
            <div class="modal-content rounded">
 
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title fw-bold text-danger">
                        Spam Lead Process
                    </h5>
 
                    <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                    </button>
                </div>
 
                <!-- Modal Body -->
                <div class="modal-body">
 
                    <div class="text-center mb-3">
                        <div class="swal2-icon swal2-warning swal2-icon-show" style="display:inline-flex;">
                            <div class="swal2-icon-content">!</div>
                        </div>
                    </div>
 
                    <div class="text-center mb-3">
                        <p class="text-dark fw-semibold">
                            These spam leads are <span class="text-danger fs-4">still not approved by the Business Head</span>.
                            Only after approval you can move this lead to Spam.
                        </p>
                    </div>
 
                    <div class="text-center mb-3">
                        <label class="text-info fw-bold fs-5 lead-name"></label>
                    </div>
 
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mb-0">
 
                            <thead class="table bg-primary text-white text-center">
                                <tr>
                                    <th>Lead ID</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                </tr>
                            </thead>
 
                            <tbody id="spamLeadTableBody">
                                <!-- AJAX rows will load here -->
                            </tbody>
 
                        </table>
                    </div>
 
                </div>
 
            </div>
 
        </div>
    </div>
    <!--end::Modal - Lead spam List-->
    
  <!--begin::Modal - Transfer Lead to Customer-->
    <div class="modal fade" id="kt_modal_lead_to_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead To Intern</h3>
                    </div>
                    <form method="POST" action="{{ route('convert_intern') }}" autocomplete="off">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="lead_id" id="lead_id_intern" value="">
                            <div class="col-lg-12 mt-4">
                                <h5 class="text-dark mb-1 fw-semibold">Are You Sure Want To Convert Lead To Intern?</h5>
                                <div class="text-center">
                                    <label class="fw-bold fs-5 text-danger" id="lead-name_intern" ></label>
                                    <span class="fw-bold fs-5 text-danger" id="lead-mobile_intern">[]</span>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                <button type="submit" class="btn btn-primary me-3" >Yes</button>
                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Transfer Lead to Customer-->
    
    <!--begin::Modal -Lead Drop-->
    <div class="modal fade" id="kt_modal_lead_drop" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Change Status to Dead Lead?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="drop_reason_form" method="POST" action="{{ url('/submit_drop_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <input type="hidden" name="staff_id_drop" id="staff_id_drop">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_edit" name="reason_edit" class="select3 form-select"
                            onchange="toggleInputField(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_drop) && count($reasonList_drop) > 0)
                            @foreach ($reasonList_drop as $d_reason)
                            <option value="{{ $d_reason->reason_name }}"
                                data-comments-check="{{ $d_reason->comments_check }}">
                                {{ $d_reason->reason_name }}
                                @endforeach
                                @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_edit_select_err"></div>
                        <div class="mt-4" id="drop_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="drop_reason_text" id="drop_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="reason_edit_err"></div>
                        <div class="mt-4" id="drop_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="drop_comments_text" id="drop_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="drop_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_drop" id="lead_id_drop">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Drop-->


    <!--begin::Modal - Lead potential-->
    <div class="modal fade" id="kt_modal_lead_potential" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Move Lead to Potential Baseket ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="potential_reason_form" method="POST" action="{{ url('/submit_potential_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <input type="hidden" name="staff_id_potential" id="staff_id_potential">

                        <select id="potential_reason_edit" name="potential_reason_edit" class="select3 form-select"
                            onchange="toggleInputField_potential(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_potential) && count($reasonList_potential) > 0)
                            @foreach ($reasonList_potential as $p_reason)
                            <option value="{{ $p_reason->reason_name }}" data-comments-check-potential="{{ $p_reason->comments_check }}">
                                {{ $p_reason->reason_name }}
                            </option>
                            @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="potential_reason_edit_select_err"></div>
                        <div class="mt-4" id="potential_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="potential_reason_text" id="potential_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                <div class="text-danger" id="reason_edit_err"></div>
                        </div>
                        <div class="mt-4" id="potential_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="potential_comments_text" id="potential_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="potential_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_potential" id="lead_id_potential">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
    </div>
    <!--end::Modal - Lead potential-->

    <!--begin::Modal -activate Lead-->
    <div class="modal fade" id="kt_modal_lead_activate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Activate?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="updateStatusForm" action="{{ route('lead_status') }}" method="POST"
                    >
                    @csrf
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    {{-- <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a> --}}
                 <button type="submit" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - activate Lead-->

    <!--begin::Modal - Customer Inactivate-->
    <div class="modal fade" id="kt_modal_lead_inactivate" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Inactivate?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/sales/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer Inactivate-->

     <!--begin::Modal - Customer Spam-->
    <div class="modal fade" id="kt_modal_lead_spam" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Change Status to Spam?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="drop_reason_form" method="POST" action="{{ url('/submit_spam_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="spam_reason_edit" name="spam_reason_edit" class="select3 form-select"
                            onchange="toggleInputField_spam(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList) && count($reasonList) > 0)
                            @foreach ($reasonList as $s_reason)
                            <option value="{{ $s_reason->reason_name }}"
                                data-comments-check="{{ $s_reason->comments_check }}">
                                {{ $s_reason->reason_name }}
                            </option>
                            @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="spam_reason_edit_select_err"></div>
                        <div class="mt-4" id="spam_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_reason_text" id="spam_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="spam_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_comments_text" id="spam_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="spam_reason_edit_err"></div>
                        <div class="text-danger" id="spam_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_spam" id="lead_id_spam">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer Spam-->
    
    <!--begin::Modal -Lead internal_call-->
    <div class="modal fade" id="kt_modal_internal_call_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Convert to Internal Calls?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 internal_name"></label>
                </div>
                <form id="internal_reason_form" method="POST" action="{{ url('/submit_internal_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_internal_select" name="reason_internal_select" class="select3 form-select"
                            onchange="toggleInputField_internal(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_internal) && count($reasonList_internal) > 0)
                            @foreach ($reasonList_internal as $i_reason)
                            <option value="{{ $i_reason->reason_name }}"
                                data-comments-check="{{ $i_reason->comments_check }}">
                                {{ $i_reason->reason_name }}
                                @endforeach
                                @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_internal_select_err"></div>
                        <div class="mt-4" id="internal_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_reason_text"
                                id="internal_reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="internal_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_comments_text"
                                id="internal_comments_text" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[^a-zA-Z0-9\s@\-$/]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="internal_reason_text_err"></div>
                        <div class="text-danger" id="internal_comments_text_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_internal" id="lead_id_internal">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead internal_call-->

    <!--begin::Modal - Lead Check List-->
    <div class="modal fade" id="kt_modal_check_list" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Check List</h3>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                            <div>
                               <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_chli">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div >
                              <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_chli">-</label>
                            </div>
                        </div>
                    </div>
                    <form action="{{ route('lead_checklist') }}" method="post" id="leadChecklistForm" onsubmit="return validateDynamicForm()">
                      @csrf
                      <input type="hidden" name="lead_id" id="lead_id_checklist">
                      <input type="hidden" name="lead_score" id="lead_score">
                      <input type="hidden" name="answers" id="answers">
                      <div class="row mt-2 scroll-y max-h-400px" id="form-container"></div>
                      <div class="d-flex justify-content-end align-items-center mt-4">
                          <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                          <button type="submit" class="btn btn-primary">Verify Check List</button>
                      </div>
                  </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Check List-->

    <!--begin::Modal - Lead Check List-->
      <div class="modal fade" id="kt_modal_check_list_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
          <!--begin::Modal dialog-->
          <div class="modal-dialog modal-lg">
              <!--begin::Modal content-->
              <div class="modal-content rounded">
                  <!--begin::Modal header-->
                  <div class="modal-header justify-content-end border-0 pb-0">
                      <!--begin::Close-->
                      <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                          <span class="svg-icon svg-icon-1">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                  <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                              </svg>
                          </span>
                          <!--end::Svg Icon-->
                      </div>
                      <!--end::Close-->
                  </div>
                  <!--end::Modal header-->
                  <!--begin::Modal body-->
                  <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                      <div class="mb-4 text-center">
                          <h3 class="text-center mb-4 text-black">Check List View</h3>
                      </div>
                      <div class="row mt-4">
                          <div class="col-lg-6 mb-3">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                              <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_chli_view">-</label>
                              </div>
                          </div>
                          <div class="col-lg-6 mb-3">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                              <div >
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_chli_view">-</label>
                              </div>
                          </div>
                      </div>
                      <div id="check_list_view_div" class="row mt-2 scroll-y max-h-400px">

                      </div>
                  </div>
                  <!--end::Modal body-->
              </div>
              <!--end::Modal content-->
          </div>
          <!--end::Modal dialog-->
      </div>
    <!--end::Modal - Lead Check List-->

    <!--begin::Modal - Lead Chat-->
     <div class="modal fade" id="kt_modal_lead_chat" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Message</h3>
                </div>
                <div class="row">
                    <input type="hidden" id="lead_id_message" name="lead_id">
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                        <div>
                            <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_message">-</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>
                        <div>
                            <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_message">-</label>
                        </div>
                    </div>
                    <!-- Basic -->
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">SMS Template</label>
                        <select id="type" name="type" class="select3 form-select">
                            <option value="">Select SMS Template</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Email Template</label>
                        <select id="email_template_id" name="email_template_id" class="select3 form-select">
                            <option value="">Select Email Template</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label for="whatsapp_template_id" class="text-dark mb-1 fs-6 fw-semibold">Whatsapp Template</label>
                        <select id="whatsapp_template_id" name="template_id" class="select3 form-select">
                            <option value="">Select Whatsapp Template</option>
                        </select>

                    </div>
                </div>
                <!-- <div class="row"> -->
                <div class="col-lg-12 mb-3 d-flex flex-wrap align-items-center grid gap-5">
                    <a href="#" class="mb-3" id="whatsapp" name="whatsapp" onclick="whatsapp_func();">
                        <label class="btn btn-icon btn-sm" title="Whatsapp">
                            <span>
                                <i class="mdi mdi-whatsapp text-success fs-2"></i>
                            </span>
                        </label>
                    </a>
                    <a href="#" class="mb-3" id="whatsapp_on" name="whatsapp_on" style="display: none !important;" onclick="whatsapp_func1();">
                        <label class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" title="Whatsapp">
                            <i class="mdi mdi-whatsapp text-success fs-2"></i>
                            <span class="position-absolute top-0 start-100 translate-middle">
                                <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                            </span>
                        </label>
                    </a>

                    <a href="#" class="mb-3" id="email" name="email" onclick="email_func();">
                        <label class="btn btn-icon btn-sm" title="Email">
                            <i class="mdi mdi-email-outline text-danger fs-2"></i>
                        </label>
                    </a>
                    <a href="#" class="mb-3" id="email_on" name="email_on" style="display: none !important;" onclick="email_func1();">
                        <label href="#" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" title="Email">
                            <i class="mdi mdi-email-outline text-danger fs-2"></i>
                            <span class="position-absolute top-0 start-100 translate-middle">
                                <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                            </span>
                        </label>
                    </a>

                    <div class="mb-3" id="linked" name="linked" onclick="linked_func();">
                        <a href="#" class="btn btn-icon btn-sm" title="Follow Up">
                            <i class="mdi mdi-message-alert-outline text-primary fs-2"></i>
                        </a>
                    </div>
                    <div class="mb-3" id="linked_on" name="linked_on" style="display: none !important;" onclick="linked_func1();">
                        <a href="#" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative" title="Follow Up">
                            <i class="mdi mdi-message-alert-outline text-primary fs-2"></i>
                            <span class="position-absolute top-0 start-100 translate-middle">
                                <i class="mdi mdi-check-circle ms-1 mt-1 fs-4"></i>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="sendMessageBtn" class="btn btn-primary">Send Message</button>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
   <!--end::Modal - Lead Chat-->

    <!--begin::Modal - Convert Raw Lead-->
     <div class="modal fade" id="kt_modal_convert_raw_to_lead" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="convert_message"></span></div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal" onclick="convert_to_lead()">Yes,
                        Convert!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Raw Lead-->

    <!-- start Bootstrap Modal for showing messages -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Import Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modalMessageContent" class="alert" role="alert">
                        <!-- Dynamic content will be injected here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="closeModalButton" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end Bootstrap Modal for showing messages -->

     <!-- start Bootstrap old Modal for showing messages -->

     <div class="modal fade" id="messageModalold" tabindex="-1" aria-labelledby="messageModaloldLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModaloldLabel">Import Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modalMessageOldContent" class="alert" role="alert">
                        <!-- Dynamic content will be injected here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="closeModaloldButton" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- end Bootstrap old Modal for showing messages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <!-- Not Closed Followup Modal -->
   <div class="modal fade" id="kt_modal_not_closed" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
 
            <div class="modal-header">
                <h5 class="modal-title text-danger">
                    Pending Followups
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
 
            <div class="modal-body">
                <div class="alert alert-danger fs-4 fw-bold">
                    These are the unclosed followups. Please complete them first before creating a new followup.
                </div>
 
                <div id="notClosedContent">
                    <!-- AJAX Data Will Load Here -->
                </div>
            </div>
 
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                    Close
                </button>
                <a href="/sales/manage_lead_follow_up/un_follow"  class="btn btn-primary">
                    UnFollowup Page
                </a>
            </div>
 
        </div>
    </div>
</div>
 
<style>
  .custom-scroll-table {
    max-height: 350px; /* adjust height as needed */
    overflow-y: auto;
    border: 1px solid #dee2e6;
  }
 
  .custom-scroll-table thead th {
      position: sticky;
      top: 0;
      background: #39484f; /* same as your header */
      color: #fff;
      z-index: 2;
  }
</style>

<script>
  function openNotClosedModal(created_by) {
 
      $('#notClosedContent').html('<div class="text-center p-5">Loading...</div>');
 
      $.ajax({
          url: "{{ route('get_not_closed_followups') }}",
          type: "POST",
          data: {
              created_by: created_by,
              _token: "{{ csrf_token() }}"
          },
          success: function(response) {
 
              let html = '';
 
              if(response.count > 0) {
 
                  html += `
                      <div class="mb-3 fw-bold text-danger">
                          Total Pending:<label class="mb-3 fw-bold badge bg-label-danger fs-5" >${response.count}</label>
                      </div>
 
                      <div class="custom-scroll-table">
                        <table class="table table-bordered table-row-gray-300 align-middle mb-0">
                              <thead class="bg-light-danger">
                                  <tr class="fw-bold text-dark bg-primary">
                                      <th>Lead Name</th>
                                      <th>Mobile</th>
                                      <th>Appointment Date</th>
                                  </tr>
                              </thead>
                              <tbody>
                  `;
 
                  response.data.forEach(function(item){
                      html += `
                          <tr>
                              <td>${item.lead_name ?? '-'}</td>
                              <td>${item.lead_mobile ?? '-'}</td>
                              <td class="text-danger fw-bold">
                                  ${item.appointment_date}
                              </td>
                          </tr>
                      `;
                  });
 
                  html += `
                              </tbody>
                          </table>
                      </div>
                  `;
 
              } else {
 
                  html = `
                      <div class="alert alert-success text-center">
                          No Pending Followups
                      </div>
                  `;
              }
 
              $('#notClosedContent').html(html);
          },
          error: function() {
              $('#notClosedContent').html(
                  '<div class="alert alert-danger">Something went wrong.</div>'
              );
          }
      });
  }
</script>

    <style>


       .highlight-row {
            position: relative;
            width: 200px;
            height: 50px;
            overflow: hidden;

        }
        .qr-badge {
          background: linear-gradient(135deg, #e0f7fa, #b2ebf2);
          color: #006064;
          padding: 2px 6px;
          border: 2px dashed #0097a7;
          border-radius: 8px;
          font-weight: 600;
          font-size: 0.85rem;
          box-shadow: 0 2px 6px rgba(0,0,0,0.1);
          transition: all 0.3s ease-in-out;
        }

        .qr-badge i {
          color: #006064;
        }
        .qr-badge2 {
            background: linear-gradient(135deg, #e0f7fa, #717fbf);
            color: #cd11ab;
            padding: 2px 12px;
            /* border: 2px dashed #0097a7; */
            border-radius: 8px;
            font-weight: 600;
            /* font-size: 0.85rem; */
            /* box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); */
            /* transition: all 0.3s ease-in-out;*/
        }
        .qr-badge2 i {
          color: #cd11ab;
        }
       .source-label {
        position: relative; /* Ensure the label is positioned relative for absolute positioning of ::before */
        display: inline-block;
        }



        .source-label::before {
            content: '🌟';
            font-family: "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif;
            position: absolute;
            top: -12px; /* Move it further up */
            left: 90%; /* Center it horizontally */
            transform: translateX(-50%); /* Adjust horizontal alignment */
            font-size: 1rem;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }


         .jd-blue {
       color: #1976d2; /* Justdial Blue */
        font-weight: bold;
    }

    .jd-orange {
        color: #f16522; /* Justdial Orange */
        font-weight: bold;
    }
    .jd-blue, .jd-orange {
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
    }
    .cc-purple {
    color: #5c2d91; /* CloudCall Purple */
    font-weight: bold;
    }

    .cc-orange {
        color: #f58220; /* CloudCall Orange */
        font-weight: bold;
    }

    /* Cloud Icon Styling */
    .cc-icon {
        color: #5c2d91; /* Matching CloudCall Purple */
        margin-right: 5px;
    }


    .ct-black {
      color: #000000; /* Call in Black */
      font-weight: bold;
    }

    .ct-orange {
        background-color: #f16522; /* Justdial Orange */
        color: #ffffff; /* White text inside */
        /*font-weight: bold;*/
        padding: 2px 6px;
        border-radius: 4px;
    }

    /* Call Icon Styling */
    .ct-icon {
        color: #000000; /* Black Call Icon */
        font-size: 14px;
        margin-left: 3px;
    }


    /* Loading Dots */
    .loading-dots {
        display: flex;
        gap: 8px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    /* Individual Balls */
    .loading-dots span {
        width: 15px;
        height: 15px;
        background-color: rgb(32, 32, 34);
        border-radius: 50%;
        opacity: 0;
        animation: fadeInOut 1.5s infinite ease-in-out;
    }

    /* Add More Balls with Delay */
    .loading-dots span:nth-child(1) { animation-delay: 0s; }
    .loading-dots span:nth-child(2) { animation-delay: 0.2s; }
    .loading-dots span:nth-child(3) { animation-delay: 0.4s; }
    .loading-dots span:nth-child(4) { animation-delay: 0.6s; }
    .loading-dots span:nth-child(5) { animation-delay: 0.8s; }
    .loading-dots span:nth-child(6) { animation-delay: 1s; }

    /* Animation */
    @keyframes fadeInOut {
        0%, 100% {
            opacity: 0;
            transform: scale(0.8);
        }
        50% {
            opacity: 1;
            transform: scale(1);
        }
    }


        /* Stylish Fade Effect Box */
        .fade-effect {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #dbdd47, #ccce43);
            color: rgb(255, 255, 255);
            font-weight: bold;
            font-size: 18px;
            text-align: center;
            line-height: 60px;
            border-radius: 10px;
            text-shadow: 0 0 5px rgba(137, 92, 219, 0.5),
                         0 0 10px rgba(137, 92, 219, 0.5),
                         0 0 20px rgba(137, 92, 219, 0.5); /* Intense Neon Glow */
            box-shadow: 0 0 15px rgba(137, 92, 219, 0.5),
                    0 0 25px rgba(16, 168, 185, 0.8),
                    0 0 35px rgba(137, 92, 219, 0.5); /* Red & Black Glow */
            letter-spacing: 2px;
            opacity: 0; /* Initially hidden */
            transition: all 0.5s ease-in-out;
            animation: shimmer 3s infinite alternate, runText 12s linear infinite, fadeEffect 3s infinite alternate;
        }

        /* Hover Glow Effect */
        .fade-effect:hover {
          box-shadow: 0 0 15px rgba(135, 0, 0, 0.7),
                    0 0 25px rgba(25, 10, 5, 0.8),
                    0 0 35px rgba(135, 0, 0, 0.6); /* Red & Black Glow */
            transform: scale(1.05); /* Slight Zoom */
        }

        /* Running Text Animation */
        @keyframes runText {
            from {
                left: 100%;
            }
            to {
                left: -100%;
            }
        }

        /* Fade Effect Animation */
        @keyframes fadeEffect {
            0% {
                opacity: 0.3;
            }
            100% {
                opacity: 1;
            }
        }
        @keyframes shimmer {
            0% {
                background-position: -200%;
            }
            100% {
                background-position: 200%;
            }
        }

        /* Blinking text animation */
        .blink {
            /*animation: blinker 1.5s linear infinite;*/
            /* font-weight: bold; */
            color: white; /* White text for better contrast */
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9; /* Soft pink color */
            padding: 0px 8px;
            border-radius: 12px; /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
            font-size: 0.3rem; /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }

        /* Adding a cute icon or star effect */
        .new-label::before {
             content: '✨';
            font-family: "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif;
            position: absolute;
            top: -8px;
            right: -10px; /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }


        /* Bounce animation for cute effect */
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-8px);
            }
            60% {
                transform: translateY(-4px);
            }
        }
    </style>
    <style>
        #modalMessageContent {
            font-size: 1.2rem; /* Make font larger */
            padding: 10px; /* Add padding */
            border-radius: 5px; /* Rounded corners */
        }

        /* Example styles for success, warning, and error */
        .text-successs {
            background-color: #d4edda;
            color: #155724;
        }
        .text-dangers {
            background-color: #f8d7da;
            color: #721c24;
        }
        .text-warnings {
            background-color: #fff3cd;
            color: #856404;
        }

    </style>
      <style>
         #modalMessageOldContent {
            font-size: 1.2rem; /* Make font larger */
            padding: 10px; /* Add padding */
            border-radius: 5px; /* Rounded corners */
        }
        .import-loader {
            display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;
            inset: 0;
            background: rgba(137, 92, 219, 0.5); /* Semi-transparent overlay */
            color: white;
            z-index: 1050; /* Ensure it appears above everything else */
            border-radius: 0.25rem;
        }

        .spinner-border {
            width: 1.5rem;
            height: 1.5rem;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    <style>


        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>

    <style>
        .dataTables_scroll3 {
            position: relative;
            overflow: auto;
            max-height: 400px;
            /*the maximum height you want to achieve*/
            width: 100%;
        }

        .dataTables_scroll3 thead {

            position: -webkit-sticky;
            position: sticky;
            top: 0;
            background-color: #fff;
            z-index: 2;
        }
    </style>
    <script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('follow_submit');
    const dateInput = document.getElementById('app_date_again');
    const errorDiv = document.getElementById('follow_time_err');

    form.addEventListener('submit', function (e) {
        const dateValue = dateInput.value.trim();

        if (!dateValue) {
            e.preventDefault(); // Stop form submission
            errorDiv.textContent = 'Please select a date for the appointment.';
            dateInput.classList.add('is-invalid'); // Highlight the input
        } else {
            errorDiv.textContent = '';
            dateInput.classList.remove('is-invalid');
            $('#sche_button').prop('disabled', true); // Optional, if using jQuery
        }
    });
});
</script>
    <script>
	$(".list_page_scroll3").DataTable({
		// "ordering": false,
		"aaSorting": [],
		// "pagingType": 'simple_numbers',
		"pagingType": "full_numbers",
		"sorting": false,
		"paging": false,
		// "info": false,
		// "buttons": [
		//             'copy', 'csv', 'excel', 'pdf', 'print'
		//         ],
		"language": {
			"lengthMenu": "Show _MENU_",
		},
		// "pageLength": 5,
		"dom": "<'row'" +
			// "<'col-sm-6 d-flex align-items-center justify-conten-start my-3'l>" +
			//   "<'col-sm-12 d-flex align-items-center justify-content-end my-3'f>" +
			">" +

			"<'table-responsive'tr>" +

			"<'row'" +
// 			"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
			// "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
			">"
	});
	$('.list_page_scroll3').wrap('<div class="dataTables_scroll3" />');
</script>

<script>


    $(document).ready(function () {
        function fadeInOutEffect() {
            console.log("Fade In Start:", new Date().toLocaleTimeString());

            $(".fade-effect").fadeTo(1000, 1, function () {
                console.log("Fade In Complete:", new Date().toLocaleTimeString());

                setTimeout(function () {
                    console.log("Fade Out Start:", new Date().toLocaleTimeString());

                    $(".fade-effect").fadeTo(1000, 0, function () {
                        console.log("Fade Out Complete:", new Date().toLocaleTimeString());
                        fadeInOutEffect(); // Restart the loop
                    });

                }, 500); // Delay before fading out
            });
        }

        fadeInOutEffect(); // Start the animation loop
    });

function openCallHistoryModal(leadId,status,name='',mobile='') {
    // var call_lead=1248;

    // var call_lead_status="Outgoing";
    let Heading = '';
        if(status== 'Incoming'){
            Heading = `${name} [ <span class="text-info">${mobile}</span> ] ${status} Call History`;
        }else if(status== 'Outgoing'){
            Heading = `${name} [ <span class="text-info">${mobile}</span> ] ${status} Call History`;
        }else if( status=='Dialed'){
            Heading = `${name} [ <span class="text-info">${mobile}</span> ] ${status} Call History`;
        }else if(status== 'Missed & Rejected'){
            Heading = `${name} [ <span class="text-info">${mobile}</span> ] ${status} Call History `;
        }

        $('#call_status_name').html(Heading);


    // $('#call_status_name').html(status);

    $.ajax({
        url: "{{ route('get_call_history') }}",
        type: "GET",
        data: { lead_id: leadId ,
            status:status
        },
        beforeSend: function () {
            $('#call-history-data').html('<tr><td colspan="6" class="text-center">Loading...</td></tr>');
        },
        success: function (response) {

            let rows = '';
            if (response.calls.length > 0) {
                response.calls.forEach(call => {
                    let bgColor = " ";
                    let img = "outgoing.png";
                    let statusText = " ";
                    let statusColor = " ";

                    switch(call.call_status) {
                        case 0:
                            bgColor = " ";
                            img = "outgoing.png";
                            statusText = "Outgoing Call";
                            statusColor = "#7594E8";
                            break;
                        case 1:
                            bgColor = " ";
                            img = "incoming.png";
                            statusText = "Incoming Call";
                            statusColor = "#FFBF66";
                            break;
                        case 2:
                            bgColor = "#ffcf9f";
                            img = "missed.png";
                            statusText = "Missed Call";
                            statusColor = "#FFA500";
                            break;
                        case 3:
                            bgColor = "#FF7979";
                            img = "rejected.png";
                            statusText = "Missed Call";
                            statusColor = "#FF7979";
                            break;
                        default:
                            bgColor = " ";
                            img = "outgoing.png";
                            statusText = "Dialed Call";
                            statusColor = "#7594E8";
                            break;
                    }

                    rows += `
                        <tr style="background: ${bgColor}">
                            <td class="px-1">
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px border border-gray-400 bg-primary rounded px-1 py-1 me-2">
                                        <img src="{{asset('assets/eapl_images/')}}/${img}" alt="Communicator" class="w-20px h-20px" />
                                    </div>
                                    <div>
                                        <label class="fs-7 me-1">${call.staff_name}</label>
                                        <div class="d-block text-primary fs-8" title="Mobile No">${call.staff_phone_no}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-1">${call.call_start_date}</td>
                            <td class="px-1">
                                <label class="text-info fs-7 fw-semibold">${call.call_start_time}</label>
                            </td>
                            <td class="px-1">
                                <label class="text-danger fs-7 fw-semibold">${call.call_end_time ? call.call_end_time : '-'}</label>
                            </td>
                            <td class="px-1">
                                <label class="badge bg-warning text-black fs-7 fw-bold">${call.call_duration ? call.call_duration : '-'}</label>
                            </td>
                            <td class="px-1">
                                <label class="badge rounded text-white fs-7 fw-semibold" style="background-color: ${statusColor}">${statusText}</label>
                            </td>
                        </tr>`;
                });
            } else {
                rows = '<tr><td colspan="6" class="text-center">No call history found</td></tr>';
            }

            $('#call-history-data').html(rows);
        }
    });
}

</script>

<script>

    function openSummaryModal(categoryId,name,incoming,outgoing,dialed,missed_rejected) {
        $('#call_summary_name').html(name)
        $('#incoming_count_summary').html(incoming)
        $('#outgoing_count_summary').html(outgoing)
        $('#dialed_count_summary').html(dialed)
        $('#missed_reject_count_summary').html(missed_rejected)

    }
</script>
    <script>
        $('#bulk_checkall').change(function () {
            $('.bulk_chk').prop('checked',this.checked);
        });

        $('.bulk_chk').change(function () {
        if ($('.bulk_chk:checked').length == $('.bulk_chk').length){
          $('#bulk_checkall').prop('checked',true);
        }
        else {
          $('#bulk_checkall').prop('checked',false);
        }
        });
        // function bulk_request_pay() {
        //   if ($('.bulk_chk:checked').length>0){
        //     $('#bulk_request_pay_form').attr('action', "{{ route('bulk_raw_lead') }}");
        //     $("#bulk_request_pay_form").submit();
        //     e.preventDefault();
        //   }else{
        //     Swal.fire({
        //         title: 'Error!',
        //         text:  'Please Check Any one of the checkbox...',
        //         icon:  'error',
        //         customClass: {
        //                     confirmButton: 'btn btn-primary waves-effect waves-light'
        //         },
        //         buttonsStyling: false
        //     });
        //   }
        // }
    </script>
    <script>
      // Move the changestatus function outside of $(document).ready()
      function changestatus(id, status) {
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

          fetch(`/lead_status_change/${id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': csrfToken
              },
              body: JSON.stringify({
                  status: status
              }),
          })
          .then(response => response.json())  // Ensure you parse the JSON response
          .then(data => {
              if (data.status === 200) {
                  toastr.success('Status Updated successfully!');
                  console.log('Data: ', data);
                  const encryptedValue = data.encryptedValue;  // Get the encrypted value from the response

                  if (encryptedValue) {
                      window.location.href = `/customer/old_customer_add/${encryptedValue}`; // Redirect with the encrypted value
                  } else {
                      toastr.error('Encrypted value is missing!');
                  }
              } else {
                  toastr.error('Status Failed to update!');
              }
          })
          .catch(error => {
              console.error('Error updating category:', error);
              toastr.error('An error occurred: ' + error.message);
          });
      }

      $(document).ready(function() {
        // Now this function is already defined, so we can safely add the event listener
        document.getElementById('changeStatusForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const id = document.getElementById('lead_status_id').value;
            const status = document.getElementById('status_id').value;

            changestatus(id, status); // This will now work as changestatus is defined
        });
      });
    </script>
    <script>
    	$(".list_page_1").DataTable({
    		"ordering": false,
    		"aaSorting": [],
    		// "pagingType": 'simple_numbers',

    		"sorting": false,
    		"paging": false,
    		// "info": false,
    		// "buttons": [
    		//             'copy', 'csv', 'excel', 'pdf', 'print'
    		//         ],
    		"language": {
    			"lengthMenu": "Show _MENU_",
    		},
    		// "pageLength": 5,
    		"dom": "<'row'" +
    			// "<'col-sm-6 d-flex align-items-center justify-conten-start my-3'l>" +
    			//   "<'col-sm-12 d-flex align-items-center justify-content-end my-3'f>" +
    			">" +

    			"<'table-responsive'tr>" +

    			"<'row'" +
    			// "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
    			// "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
    			">"
    	});
    	$('.list_page_1').wrap('<div class="dataTables_scroll3" />');
    </script>



    <script>
      $(document).ready(function() {
          // Basic
          //------------------------------------------------------
          const course_KnowledgeTagEl = document.querySelector('#lead_KnowledgeTag');
          let whitelist = [];
          // Fetch data using $.ajax (jQuery)
          $.ajax({
              url: "{{ route('knowledge_tag') }}",
              type: 'GET',
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      response.data.forEach(function(tags) {
                          whitelist.push(tags.knowledge_tag_name); // Populate whitelist array
                      });

                      initializeTagify(); // Call Tagify initialization after data fetch
                  }
              },
              error: function(error) {
                  console.error('Error fetching knowledge tags:', error);
              }
          });

          function initializeTagify() {
              // Inline initialization of Tagify
              let KnowledgeTag = new Tagify(course_KnowledgeTagEl, {
                  whitelist: whitelist,
                  maxTags: 500, // allows to select max items
                  dropdown: {
                      maxItems: 1000, // display max items
                      classname: 'tags-inline', // Custom inline class
                      enabled: 0,
                      closeOnSelect: true
                  }
              });

              // Ensure the z-index is set correctly after initialization
              KnowledgeTag.DOM.dropdown.style.zIndex = '9999';
          }
      });
  </script>
  <script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#lead_week_st_dt_fill').val(firstday);
            $('#lead_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>
    <script>
    //raw lead to lead Conversion
     function confirmConvertRawtoLead(id, name) {
        console.log(id, name);
        document.querySelector('#kt_modal_convert_raw_to_lead .btn-danger').setAttribute(
            'data-id', id);
        $('#convert_message').html("Are you sure you want to Convert <br>  <b class='text-danger'>" + name +
            "</b> Raw Lead ?");
    }

      function convert_to_lead() {
        var categoryId = document.querySelector('#kt_modal_convert_raw_to_lead .btn-danger').getAttribute('data-id');
        console.log(categoryId);

        fetch('/convert_raw_to_lead/' + categoryId, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message);

                // Pass the returned lead ID to the populateEditModal function
                if (data.data && data.data.lead_id) {
                    $('#view_edit_id').val(data.data.lead_id);
                    populateEditModal();

                    // Show the edit modal
                    $('#kt_modal_edit_lead').modal('show');
                }
            } else {
                console.error(data.error_msg);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }

    function printTable() {
            // Hide the rest of the page
            let filterForm = document.querySelector('.lead_filter');
            let buttons = document.querySelector('.btn-group');

            if (filterForm) filterForm.style.display = 'none'; // Hide filter form
            if (buttons) buttons.style.display = 'none'; // Hide other buttons

            // Clone the table so it can be printed alone
            let printContent = document.querySelector('.list_page').outerHTML;

            let printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Print Lead Data</title>');
            printWindow.document.write('</head><body>');
            printWindow.document.write('<h2>Filtered Lead Data</h2>');
            printWindow.document.write(printContent);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();

            // Restore hidden elements after printing
            if (filterForm) filterForm.style.display = 'block'; // Show filter form
            if (buttons) buttons.style.display = 'block'; // Show other buttons
        }

    </script>
   <script>
            // Add event listener for input blur event
            $('#lead_mobile_create').on('blur', function() {
                const mobileNumber = $(this).val();
                if (mobileNumber.length >= 5 && mobileNumber.length <= 12)  { // Ensure it's a 10-digit number
                    $.ajax({
                        url: '{{ route("checkMobileExists") }}', // Route to check mobile in backend
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        data: JSON.stringify({
                            mobile: mobileNumber
                        }),
                        success: function(response) {
                            if (response.exists) {
                                $('#lead_mobile_create_err').text('This mobile number is already registered.');
                            } else {
                                $('#lead_mobile_create_err').text(''); // Clear any error messages
                            }
                        },
                        error: function() {
                            $('#lead_mobile_create_err').text('Error checking mobile number.');
                        }
                    });
                } else {
                    $('#lead_mobile_create_err').text('Please enter a valid mobile number.');
                }
            });
        </script>
<script>
    // Check if 'filter_on' session variable is set and trigger click event
        $(document).ready(function() {
            @if ($filter_on ?? '')
                // $('.lead_tbox').slideToggle('fast');
                $('.lead_filter').slideToggle('fast');

                // });
            @endif
        });

        // Toggle branch filter section
        $('#lead_filter').click(function() {
            $('.lead_filter').slideToggle('slow');
        });

        document.getElementById('filter_form').onsubmit = function() {
            this.querySelector('button[type="submit"]').disabled = true;
        };
</script>

<script>


    document.getElementById('leadImportForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        const form = event.target;
        const formData = new FormData(form);

        fetch('{{ route("lead_import") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
            },
            body: formData
        })
        .then(response => response.json()) // assuming the backend returns a JSON response
        .then(data => {
            // Handle success or error response
            let modalMessage = '';
            if (data.status === 'success') {
                modalMessage = `<span class="text-success">${data.message}</span>`;
            } else if (data.status === 'partial_success') {  // Handle partial success
                modalMessage = `<span class="text-warnings">${data.message}<br>${data.error_msg.join(', ')}</span>`; // Join error messages
            } else if (data.status === 'error') {  // Make sure to define error handling on the backend
                modalMessage = `<span class="text-dangers">${data.error_msg}</span>`;
            }

            // Set the modal message content
            document.getElementById('modalMessageContent').innerHTML = modalMessage;

            // Close the import modal in case of error as well
            var importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
            if (importModal) {
                importModal.hide();
            }
            // Show the message modal
            var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
            messageModal.show();

            // Reload the page after a short delay
            // setTimeout(() => {
            //     location.reload();
            // }, 8000); // 2-second delay to allow the user to read the message
        })
        .catch(error => {
            // Handle any errors
            console.error('Error:', error);
            document.getElementById('modalMessageContent').innerHTML = '<span class="text-danger">An error occurred while importing leads.</span>';

            // Close the import modal in case of error as well
            var importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
            if (importModal) {
                importModal.hide();
            }

            // Show the error message in the message modal
            var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
            messageModal.show();

            // Reload the page after a short delay
            // setTimeout(() => {
            //     location.reload();
            // }, 8000); // 2-second delay to allow the user to read the error message
        });
    });
    // Reload the page when the close button is clicked
    document.getElementById('closeModalButton').addEventListener('click', function() {
        location.reload(); // Reload the page when the close button is clicked
    });
</script>
{{-- old lead import --}}
<script>

    document.getElementById('leadImportOldForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        const form = event.target;
        const formData = new FormData(form);

        // Show the loader
        const importButton = document.getElementById('importButton');
        const importLoader = document.getElementById('importLoader');
        importButton.disabled = true; // Disable button to prevent multiple clicks
        importLoader.classList.remove('d-none'); // Show loader

        fetch('{{ route("lead_import_old") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
            },
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                // Hide the loader
                importLoader.classList.add('d-none');
                importButton.disabled = false;

                // Handle success or error response
                let modalMessage = '';
                if (data.status === 'success') {
                    modalMessage = `<span class="text-success">${data.message}</span>`;
                } else if (data.status === 'partial_success') {
                    modalMessage = `<span class="text-warning">${data.message}<br>${data.error_msg.join(', ')}</span>`;
                } else if (data.status === 'error') {
                    modalMessage = `<span class="text-danger">${data.error_msg}</span>`;
                }

                document.getElementById('modalMessageOldContent').innerHTML = modalMessage;

                const importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
                if (importModal) {
                    importModal.hide();
                }

                const messageModalold = new bootstrap.Modal(document.getElementById('messageModalold'));
                messageModalold.show();
            })
            .catch(error => {
                // Hide the loader
                importLoader.classList.add('d-none');
                importButton.disabled = false;

                console.error('Error:', error);
                document.getElementById('modalMessageOldContent').innerHTML = '<span class="text-danger">An error occurred while importing leads.</span>';

                const importModal = bootstrap.Modal.getInstance(document.getElementById('kt_modal_lead_import'));
                if (importModal) {
                    importModal.hide();
                }

                const messageModalold = new bootstrap.Modal(document.getElementById('messageModalold'));
                messageModalold.show();
            });
    });

    // // Reload the page when the close button is clicked
    document.getElementById('closeModaloldButton').addEventListener('click', function() {
        location.reload(); // Reload the page when the close button is clicked
    });

</script>
  <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector("form#leadDropzone").addEventListener("submit", function(e) {
                e.preventDefault();
                e.stopPropagation();

                let formData = new FormData(this);
                formData.append("_token", document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

                fetch("{{ route('lead_import') }}", {
                    method: "POST",
                    body: formData,
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message); // Display success message
                        // setTimeout(() => {
                        //     window.location.reload(); // Refresh page to show success message
                        // }, 1500);
                    } else {
                        // Handle error response
                        if (data.status === 401 || data.status === 400) {
                            if (data.error_msg) {
                                toastr.error(data.error_msg.join("<br>")); // Join and display validation errors
                            } else {
                                toastr.error(data.message); // General error message
                            }
                        } else {
                            toastr.error("An unexpected error occurred.");
                        }
                    }
                })
                .catch(error => {
                    toastr.error("An error occurred while processing the request: " + error.message);
                });
            });
        });
    </script>

    <script>
        $('#lead_slow_mo').click(function() {
            $('.lead_tbox').slideToggle('slow');
        });
    </script>



    <script>
        // Display Toastr messages
        @if(Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
        @endif
    </script>
    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
      function AddvalidateForm() {
          var err = 0;

          // Validate knowledge Name
          var lead_name_create = document.getElementById("lead_name_create").value.trim();
          if (lead_name_create === "") {
              document.getElementById('lead_name_create_err').innerHTML = 'Lead Name is required...!';
              err++;
          } else {
              document.getElementById('lead_name_create_err').innerHTML = '';
          }

          // Validate Gender
          // var lead_gender = document.querySelector('input[name="lead_gender"]:checked');
          // if (!lead_gender) {
          //     document.getElementById('lead_gender_create_err').innerHTML = 'Gender is required...!';
          //     err++;
          // } else {
          //     document.getElementById('lead_gender_create_err').innerHTML = '';
          // }
          // Validate Gender
        //   var lead_dob = document.getElementById("lead_dob").value.trim();
        //   if (!lead_dob) {
        //       document.getElementById('lead_dob_create_err').innerHTML = 'Date of Birth is required...!';
        //       err++;
        //   } else {
        //       document.getElementById('lead_dob_create_err').innerHTML = '';
        //   }

        var countryDropdownMenu_valid = $('#country_code_name');

        if(countryDropdownMenu_valid == 'IN - +91'){
            var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();
            var mobilePattern = /^\d{12}$/;

            if (lead_mobile_create === "") {
                document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                err++;
            } else if (!mobilePattern.test(lead_mobile_create)) {
                document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number must be 10 digits...!';
                err++;
            } else {
                document.getElementById('lead_mobile_create_err').innerHTML = '';
            }
        }else{
            if (lead_mobile_create === "") {
                document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                err++;
            }else {
                document.getElementById('lead_mobile_create_err').innerHTML = '';
            }
        }

        var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();

        if (lead_mobile_create === "") {
            document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
            err++;
        } else {
            document.getElementById('lead_mobile_create_err').innerHTML = '';
        }




          var lead_email_create = document.getElementById("lead_email_create").value.trim();
          if (lead_email_create === "") {
              // document.getElementById('lead_email_id_err').innerHTML = 'Email is required...!';
              // document.getElementById('lead_email_create').classList.add('error_msg');
              // err++;
          } else {
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
            if (filter.test(lead_email_create)) {
              document.getElementById('lead_email_create_err').innerHTML = '';

            } else {
              document.getElementById('lead_email_create_err').innerHTML = 'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
              err++;

            }
          }

        //   var countryId = document.getElementById("countryId").value.trim();
        //   if (countryId === "") {
        //       document.getElementById('lead_country_create_err').innerHTML = 'Country is required...!';

        //       err++;
        //   } else {

        //       document.getElementById('lead_country_create_err').innerHTML = '';
        //   }
        //   var stateId = document.getElementById("stateId").value.trim();
        //   if (stateId === "") {
        //       document.getElementById('lead_state_create_err').innerHTML = 'State is required...!';

        //       err++;
        //   } else {

        //       document.getElementById('lead_state_create_err').innerHTML = '';
        //   }
        //   var cityId = document.getElementById("cityId").value.trim();
        //   if (cityId === "") {
        //       document.getElementById('lead_city_create_err').innerHTML = 'City is required...!';

        //       err++;
        //   } else {

        //       document.getElementById('lead_city_create_err').innerHTML = '';
        //   }

          // Validate knowledge Name
          var lead_source_create = document.getElementById("lead_source_create").value.trim();
          if (lead_source_create === "") {
              document.getElementById('lead_source_create_err').innerHTML = 'Lead Source is required...!';

              err++;
          } else {

              document.getElementById('lead_source_create_err').innerHTML = '';
          }
          // Validate knowledge Name
          var lead_course_create = document.getElementById("lead_course_create").value.trim();
          if (lead_course_create === "") {
              document.getElementById('lead_course_create_err').innerHTML = 'Course is required...!';

              err++;
          } else {

              document.getElementById('lead_course_create_err').innerHTML = '';
          }
        //   var lead_KnowledgeTag = document.getElementById("lead_KnowledgeTag").value.trim();
        //   if (lead_KnowledgeTag === "") {
        //       document.getElementById('lead_KnowledgeTag_err').innerHTML = 'Lead Knowledge Tag is required...!';

        //       err++;
        //   } else {

        //       document.getElementById('lead_KnowledgeTag_err').innerHTML = '';
        //   }


        if (err === 0) {
            $('#leadAddForm').submit();
            $('#submit_lead_add').prop('disabled', true);
        } else {
                $('#submit_lead_add').prop('disabled', false);
        }
      }
  </script>

<script>
    function EditvalidateForm() {
        var err = 0;

        // Validate knowledge Name
        var lead_name_edit = document.getElementById("lead_name_edit").value.trim();
        if (lead_name_edit === "") {
            document.getElementById('lead_name_edit_err').innerHTML = 'Lead Name is required...!';
            err++;
        } else {
            document.getElementById('lead_name_edit_err').innerHTML = '';
        }

        // Validate Gender
        // var lead_dob_up = document.getElementById("lead_dob_up").value.trim();
        // if (!lead_dob_up) {
        //     document.getElementById('lead_dob_up_err').innerHTML = 'Date of Birth is required...!';
        //     err++;
        // } else {
        //     document.getElementById('lead_dob_up_err').innerHTML = '';
        // }

        var countryDropdownMenu = $('#country_code_name_edit');

        if(countryDropdownMenu == 'IN - +91'){
            var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();
            var mobilePattern = /^\d{12}$/;
            
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';

                err++;
            } else if (!mobilePattern.test(lead_mobile_edit)) {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number must be 10 digits...!';

                err++;
            } else {

                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }else{
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';
                err++;
            }else {
                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }

         var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();

            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';

                err++;
            } else {

                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }


        var lead_email_edit = document.getElementById("lead_email_edit").value.trim();
          if (lead_email_edit === "") {
              // document.getElementById('lead_email_id_err').innerHTML = 'Email is required...!';
              // document.getElementById('lead_email_edit').classList.add('error_msg');
              // err++;
          } else {
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
            if (filter.test(lead_email_edit)) {
              document.getElementById('lead_email_edit_err').innerHTML = '';
            } else {
              document.getElementById('lead_email_edit_err').innerHTML = 'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
              err++;

            }
          }

        // var country_id_edit = document.getElementById("country_id_edit").value.trim();
        // if (country_id_edit === "") {
        //     document.getElementById('country_id_edit_err').innerHTML = 'Country is required...!';
        //     err++;
        // } else {
        //     document.getElementById('country_id_edit_err').innerHTML = '';
        // }

        // var state_edit = document.getElementById("state_edit").value.trim();
        // if (state_edit === "") {
        //     document.getElementById('state_edit_err').innerHTML = 'State is required...!';

        //     err++;
        // } else {

        //     document.getElementById('state_edit_err').innerHTML = '';
        // }
        // var city_edit = document.getElementById("city_edit").value.trim();
        // if (city_edit === "") {
        //     document.getElementById('city_edit_err').innerHTML = 'City is required...!';

        //     err++;
        // } else {

        //     document.getElementById('city_edit_err').innerHTML = '';
        // }

        // Validate knowledge Name
        var lead_source_edit = document.getElementById("lead_source_edit").value.trim();
        if (lead_source_edit === "") {
            document.getElementById('lead_source_edit_err').innerHTML = 'Lead Source is required...!';

            err++;
        } else {

            document.getElementById('lead_source_edit_err').innerHTML = '';
        }

        // Validate knowledge Name
        var lead_course_edit = document.getElementById("lead_course_edit").value.trim();
        if (lead_course_edit === "") {
            document.getElementById('lead_course_edit_err').innerHTML = 'Course is required...!';

            err++;
        } else {

            document.getElementById('lead_course_edit_err').innerHTML = '';
        }
        // var lead_Knowledge_edit_tag = document.getElementById("lead_Knowledge_edit_tag").value.trim();
        // if (lead_Knowledge_edit_tag === "") {
        //     document.getElementById('lead_Knowledge_edit_tag_err').innerHTML = 'Lead Knowledge Tag is required...!';

        //     err++;
        // } else {

        //     document.getElementById('lead_Knowledge_edit_tag_err').innerHTML = '';
        // }


        if (err === 0) {
            $('#leadEditForm').submit();
            $('#submit_lead_edit').prop('disabled', true);
        } else {
            $('#submit_lead_edit').prop('disabled', false);
        }
    }
</script>

    <script>
        function FollowupvalidateForm() {
            var err = 0;

            // Validate knowledge Name
            var lead_apt_sch = document.getElementById("lead_apt_sch").value.trim();
            if (lead_apt_sch === "") {
                document.getElementById('apt_date_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('lead_apt_sch').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('lead_apt_sch').classList.remove('error_msg');
                document.getElementById('apt_date_err').innerHTML = '';
            }
                // Validate knowledge Name
            var apt_time_followp = document.getElementById("apt_time_followp").value.trim();
            if (apt_time_followp === "") {
                document.getElementById('apt_time_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('apt_time_followp').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('apt_time_followp').classList.remove('error_msg');
                document.getElementById('apt_time_err').innerHTML = '';
            }
             if(err==0){
                $('#schedule_button').prop('disabled',true);
            }
            return err === 0;
        }

        // Add event listeners to clear error messages on input
        document.getElementById('lead_apt_sch').addEventListener('input', function() {
            document.getElementById('apt_date_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
        // Add event listeners to clear error messages on input
        document.getElementById('apt_time_followp').addEventListener('input', function() {
            document.getElementById('apt_time_err').innerHTML = '';
            this.classList.remove('error_msg');
        });

    </script>
    <script>

        $(document).ready(function() {

            $.ajax({
                url: "{{ route('lead_source') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('select[name="lead_source_id"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Lead source</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno)
                                .text(level.lead_source_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
        });

        $(document).ready(function() {

            $.ajax({
                url: "{{ route('lead_type') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('select[name="lead_type_id"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Lead source</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno)
                                .text(level.lead_type_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
        });
        </script>
        <script>

        $(document).ready(function() {
            $.ajax({
                url: "{{ route('course') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('select[name="course_id[]"]');
                        selectDropdown.empty().append('<option value="">Select Lead Course</option>');

                        response.data.forEach(function(level) {
                            selectDropdown.append(
                                $('<option></option>')
                                    .attr('value', level.sno)
                                    .text(level.course_type_name + ' - ' + level.course_name)
                            );
                        });
                    }
                },
            });
        });
      </script>

      <script>


        function AppointmentSchedule(leadId,name,phone) {
            $('#lead_id').val(leadId); // Set the lead ID in the hidden input field
            $('#lead_name_app').html(name);
            $('#lead_phone_app').html(phone);
            $('#kt_modal_follow_up_lead').modal('show'); // Show the modal
        }
        function openChecklistModal(leadId,name,phone) {
            $('#lead_id_checklist').val(leadId); // Set the lead ID in the hidden input field
            $('#lead_name_chli').html(name);
            $('#lead_phone_chli').html(phone);
            $('#kt_modal_check_list').modal('show'); // Show the modal
        }
        function openChecklistviewModal(leadId, name, phone, lead_answer) {
          // Set the lead name and phone in the modal
          $('#lead_name_chli_view').html(name);
          $('#lead_phone_chli_view').html(phone);

          // Clear previous content
          $('#check_list_view_div').html('');

          // Check if lead_answer is a JSON string, and parse it if necessary
          if (typeof lead_answer === 'string') {
              try {
                  lead_answer = JSON.parse(lead_answer);
              } catch (e) {
                  console.error('Error parsing lead_answer:', e);
                  return; // Exit if parsing fails
              }
          }

          // Check if lead_answer is an array
          if (Array.isArray(lead_answer)) {
              // Iterate through the lead_answer array and create rows for each question-answer pair
              var sno = 1;
              lead_answer.forEach(item => {
                  let rowDiv = `
                      <div class="row mb-2">
                          <div class="col-lg-12">
                              <label class="text-dark mb-1 fs-6 fw-semibold">${sno}. ${item.question}</label>
                              <div class="border p-2">${item.answer}</div>
                          </div>
                      </div>
                  `;
                  $('#check_list_view_div').append(rowDiv); // Append the row to the checklist view
                  sno++;
              });
          } else {
            //   console.error('lead_answer is not an array:', lead_answer);
          }

          // Show the modal
          $('#kt_modal_check_list_view').modal('show');
      }



        $(document).ready(function() {
            // Any additional setup if needed
        });

        </script>
    <script>
      function populateViewModal(categoryId) {
        fetch(`/lead_view/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data;
                    console.log(lead);

                    // Function to format date to '10-Jun-2024'
                    function formatDate(dateString) {
                        if (!dateString) return '-'; // Handle null or undefined dates
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }

                    $('#lead_id_view').html(lead.lead_id || '-');
                    $('#lead_created').html(formatDate(lead.created_at));
                    $('#lead_name_view').html(lead.lead_name || '-');
                    $('#lead_mobile_view').html(lead.lead_mobile || '-');
                    $('#lead_alternate_view').html(lead.lead_alternate_mobile || '-');
                    $('#lead_email_view').html(lead.lead_email_id || '-');

                    const gender = lead.lead_gender === 1 ? 'Male' : (lead.lead_gender === 2 ? 'Female' : 'Other');
                    $('#lead_gender_view').html(gender);

                    $('#lead_dob_view').html(formatDate(lead.lead_dob));

                    const maritalStatus = lead.lead_marital_status === 1 ? 'Married' : (lead.lead_marital_status === 2 ? 'Unmarried' : '-');
                    $('#lead_marital_view').html(maritalStatus);

                    $('#lead_country_view').html(lead.country_name || '-');
                    $('#lead_state_view').html(lead.state_name || '-');
                    $('#lead_city_view').html(lead.city_name || '-');
                    $('#lead_address_view').html(lead.address || '-');
                    $('#lead_course_view').html(lead.course_names || '-');
                    $('#lead_type_view').html(lead.lead_type_name || '-');
                    $('#lead_source_view_h').html(lead.lead_source_name || '-');
                    $('#lead_source_view').html(lead.lead_source_name || '-');
                    $('#lead_comments_view').html(lead.lead_comments || '-');
                    $('#lead_potential_view').html(lead.potential_type_name || '-');
                    $('#view_edit_id').val(lead.sno || '');

                    if(lead.status == 4) {
                        $('#edit_icon').hide();
                    } else {
                        $('#edit_icon').show();
                    }

                    // Assuming lead.lead_knowledge_tags is your JSON array or string
                    let tagsString = '-';
                    if (lead.lead_knowledge_tags) {
                        const tagsArray = Array.isArray(lead.lead_knowledge_tags) ? lead.lead_knowledge_tags : JSON.parse(lead.lead_knowledge_tags);
                        tagsString = tagsArray.map(tag => tag.value).join(', ');
                    }
                    $('#lead_tag_view').html(tagsString);

                } else {
                    console.error('Error fetching category:', data.message);
                    // Optionally, show an alert or update the UI to reflect the error.
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
                // Optionally, show an alert or update the UI to reflect the error.
            });
      }


    </script>
    <script>
      $(document).ready(function() {
        $.ajax({
            url: "{{ route('lead_question') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    let questions = response.data;
                    let formContainer = $('#form-container');

                    questions.forEach(question => {
                      let questionLabel = `<label class="text-primary mb-1 fs-6 fw-semibold">${question.lead_question_name} <span class="text-danger">*</span></label>`;
                      let errorDiv = `<div class="text-danger" id="question_${question.sno}_err"></div>`;
                      formContainer.append(`<div class="col-lg-12 mt-2">${questionLabel}</div>`);

                      if (question.lead_question_type === 'radio_button') {
                          let options = JSON.parse(question.lead_question_option);
                          options.forEach(option => {
                              let radioButton = `
                                  <div class="form-check form-check-inline">
                                      <input type="hidden" name="chk_li_question[]" value="${question.lead_question_name}">
                                      <input class="form-check-input" type="radio" name="question_${question.sno}" value="${option.value}" data-score="${option.score}" data-question="${question.lead_question_name}"/>
                                      <label class="form-check-label text-dark mb-1 fs-6 fw-semibold">${option.value}</label>
                                  </div>
                              `;
                              formContainer.append(`<div class="col-lg-4 mt-2">${radioButton}</div>`);
                          });
                      } else if (question.lead_question_type === 'checkbox') {
                          let options = JSON.parse(question.lead_question_option);
                          options.forEach(option => {
                              let checkbox = `
                                  <div class="form-check form-check-inline">
                                      <input type="hidden" name="chk_li_question[]" value="${question.lead_question_name}">
                                      <input class="form-check-input" type="checkbox" name="question_${question.sno}[]" value="${option.value}" data-score="${option.score}" data-question="${question.lead_question_name}"/>
                                      <label class="form-check-label text-dark mb-1 fs-6 fw-semibold">${option.value}</label>
                                  </div>
                              `;
                              formContainer.append(`<div class="col-lg-4 mt-2">${checkbox}</div>`);
                          });
                      } else if (question.lead_question_type === 'list_box') {
                          let options = JSON.parse(question.lead_question_option);
                          let selectOptions = '';
                          options.forEach(option => {
                              selectOptions += `<option value="${option.value}" data-score="${option.score}" data-question="${question.lead_question_name}">${option.value}</option>`;
                          });
                          let listBox = `
                              <div class="col-lg-4 mt-2">
                                  <input type="hidden" name="chk_li_question[]" value="${question.lead_question_name}">
                                  <select name="question_${question.sno}" class="select3 form-select">
                                      ${selectOptions}
                                  </select>
                              </div>
                          `;
                          formContainer.append(listBox);
                      } else if (question.lead_question_type === 'text_field') {
                          let textField = `
                              <div class="col-lg-12 mt-2">
                                  <input type="hidden" name="chk_li_question[]" value="${question.lead_question_name}">
                                  <textarea name="question_${question.sno}" class="form-control" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                              </div>
                          `;
                          formContainer.append(textField);
                      }

                      formContainer.append(errorDiv);
                      formContainer.append(`<input type="hidden" name="question_ids[]" value="${question.sno}">`);
                  });

                  // Update scores and answers on change events
                  $('#leadChecklistForm input[type="radio"], #leadChecklistForm input[type="checkbox"], #leadChecklistForm select').on('change', function() {
                      updateScores();
                  });
                  $('#leadChecklistForm textarea').on('keyup', function() {
                      updateScores();
                  });

                  function updateScores() {
                      let totalScore = 0;
                      let questionAnswerPairs = [];

                      // Iterate over checked/selected inputs inside the form
                      $('#leadChecklistForm input[type="radio"]:checked, #leadChecklistForm input[type="checkbox"]:checked, #leadChecklistForm select option:selected').each(function() {
                          // Get the selected value
                          let answer = $(this).val();
                          // Get the score associated with the selected option
                          let score = parseInt($(this).data('score') || 0);

                          // Get the question name directly from the data attribute
                          let questionName = $(this).data('question');

                          totalScore += score;  // Add the score to total

                          // Store both question and answer in the array
                          questionAnswerPairs.push({
                              question: questionName,  // Store the question
                              answer: answer           // Store the answer
                          });
                      });

                      // Include textarea values in question-answer pairs
                      $('#leadChecklistForm textarea').each(function() {
                          let textareaValue = $(this).val().trim();  // Get the textarea value

                          if (textareaValue) {
                              // Get the question name using the closest hidden input
                              let questionName = $(this).closest('.col-lg-12').find('input[name="chk_li_question[]"]').val();

                              // Store the textarea question and value in the array
                              questionAnswerPairs.push({
                                  question: questionName,  // Store the question
                                  answer: textareaValue    // Store the answer (textarea)
                              });
                          }
                      });

                      // Update hidden fields with the total score and question-answer array
                      $('#lead_score').val(totalScore);
                      $('#answers').val(JSON.stringify(questionAnswerPairs));  // Store the question-answer pairs as JSON

                      console.log('Final Question-Answer Pairs:', questionAnswerPairs);
                  }




                }
            },
            error: function(error) {
                console.error('Error fetching lead question:', error);
            }
        });
        // Function to clear error message
        function clearErrorMessage(name) {
            let errorDiv = $(`#${name}_err`);
            errorDiv.html('');
        }
        // Function to validate the form
        function validateDynamicForm() {
            let err = 0;

            // Clear previous error messages and styles
            $('#form-container .error_msg').removeClass('error_msg');
            $('.error-message').html('');

            // Loop through each input element in the #form-container
            $('#form-container').find('input[type="radio"], input[type="checkbox"], select, textarea').each(function() {
                let $this = $(this);
                let name = $this.attr('name');
                let type = $this.attr('type');
                let errorDiv = $(`#${name}_err`);

                // Check for radio and checkbox inputs
                if (type === 'radio' || type === 'checkbox') {
                    if ($(`input[name="${name}"]:checked`).length === 0) {
                        errorDiv.html('This field is required.');
                        $this.addClass('error_msg');
                        err++;
                    } else {
                        $this.removeClass('error_msg');
                        errorDiv.html('');
                    }
                }
                // Check for select elements
                else if ($this.is('select')) {
                    if ($this.val() === '') {
                        errorDiv.html('This field is required.');
                        $this.addClass('error_msg');
                        err++;
                    } else {
                        $this.removeClass('error_msg');
                        errorDiv.html('');
                    }
                }
                // Check for textarea elements
                else if ($this.is('textarea')) {
                    if ($this.val().trim() === '') {
                        errorDiv.html('This field is required.');
                        $this.addClass('error_msg');
                        err++;
                    } else {
                        $this.removeClass('error_msg');
                        errorDiv.html('');
                    }
                }
            });

            return err === 0;
        }
        // Attach the validateDynamicForm function to your form's submit event
        $('#leadChecklistForm').on('submit', function(event) {
            if (!validateDynamicForm()) {
                event.preventDefault(); // Prevent form submission if validation fails
            }
        });
      });



    </script>
  {{-- lead sourse dropdown --}}
    <script>

        function populateDropdowns() {
            $.ajax({
                url: "{{ route('lead_source') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched lead sources
                        var selectDropdown = $('select[name="lead_source_id_edit"]');
                        selectDropdown.empty();
                        selectDropdown.append('<option value="">Select Lead source</option>');
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.lead_source_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching lead sources:', error);
                }
            });

            $.ajax({
                url: "{{ route('lead_type') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched lead types
                        var selectDropdown = $('select[name="lead_type_id_edit"]');
                        selectDropdown.empty();
                        selectDropdown.append('<option value="">Select Lead type</option>');
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.lead_type_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching lead types:', error);
                }
            });
            $.ajax({
                url: "{{ route('course') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched courses
                        var selectDropdown = $('select[name="course_id_edit[]"]');
                        selectDropdown.empty();
                        // selectDropdown.append('<option value="">Select Course</option>');
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.course_type_name+' - '+level.course_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching courses:', error);
                }
            });


        }

        $(document).ready(function() {
            populateDropdowns();
        });

    </script>

<script>

    let reshedule_id;

    function openResheduleModal(categoryId,name,mobile) {
        $('#lead_name_reop').html(name);
        $('#lead_phone_reop').html(mobile);
        reshedule_id = categoryId;
        // Function to format date to '10-Jun-2024'
                  function formatDate(dateString) {
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }
                    function formatTime(timeString) {
                        const date = new Date(`1970-01-01T${timeString}Z`);
                        let hours = date.getUTCHours();
                        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                        const ampm = hours >= 12 ? 'PM' : 'AM';
                        hours = hours % 12;
                        hours = hours ? hours : 12; // the hour '0' should be '12'
                        return `${hours}:${minutes} ${ampm}`;
                    }
        fetch(`/edit_appointment/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;



                    document.getElementById('app_date').value = formatDate(lead.appointment_date);
                    document.getElementById('app_time').value = lead.appointment_time;
                     $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                     $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                     $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                    // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                   console.log('Appointment Count:', data.data.appointmentCount);
                    $('#app_count').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('historicalLeadIdsTableBody');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            const row = `<tr>
    <td>
        <div class="mb-0 align-items-center">
            <label>
                <span class="fs-7 me-2">${index + 1}</span>
            </label>
        </div>
    </td>
    <td>
        <div class="d-block badge rounded bg-success text-black fs-7">${formatDate(category.appointment_date)}</div>
    </td>
    <td>
        <div class="d-block badge rounded bg-danger text-white fs-7">${formatTime(category.appointment_time)}</div>
    </td>
    <td>${category.staff_name}</td>
    <td>
        <div class="text-black fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom"
             title="${category.reason ?? '-'}">
            ${category.reason ?? '-'}
        </div>
    </td>
    <td>
        <label title="Score">
            ${
                category.app_score === 1
                    ? `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`
                    : category.app_score === -1
                    ? `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`
                    : category.app_score === 0
                    ? `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`
                    : `<span>-</span>`
            }
        </label>
    </td>
    <td>
        <div class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
             title="${category.convo_message ?? '-'}">
            ${category.convo_message ?? '-'}
        </div>
    </td>
</tr>`;

                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        <td colspan="6" class="text-center">No data available</td>
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }


                } else {
                    console.error('Error fetching category:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });

        fetch(`/appointment_history/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                  console.log(data)
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;

                    $('#apptmnt_count').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('appointmentLeadIdsTableBody');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];

                if(category.app_score === 1){
                    var score =  `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                }else if(category.app_score === -1){
                   var score = `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                }
                else if(category.app_score === 0){
                   var score = `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                }else{
                    var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                }



                            const row = `<tr>
    <td>
        <div class="mb-0 align-items-center">
            <label>
                <span class="fs-7 me-2">${index + 1}</span>
            </label>
        </div>
    </td>
    <td>
        <div class="d-block badge rounded bg-success text-black fs-7">${formatDate(category.appointment_date)}</div>
    </td>
    <td>
        <div class="d-block badge rounded bg-danger text-white fs-7">${formatTime(category.appointment_time)}</div>
    </td>
    <td>${category.staff_name}</td>
    <td>
        <div class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
             title="${category.reason ?? '-'}">
            ${category.reason ?? '-'}
        </div>
    </td>
    <td>
        <label title="Score">
            ${score}
        </label>
    </td>
    <td>
        <div class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
             title="${category.convo_message ?? '-'}">
            ${category.convo_message ?? '-'}
        </div>
    </td>
</tr>`;

                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        <td colspan="6" class="text-center">No data available</td>
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }

                } else {
                    console.error('Error fetching category:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });


    }


    // function updateReshedule() {
    //     const resheduleid = reshedule_id;
    //     const progressed = document.querySelector('input[name="progressed"]:checked').value;

    //     // Initialize variables
    //     let app_score = null;
    //     let convo_message = null;
    //     let hot_lead = null;
    //     let reason = null;
    //     let appointment_date = null;
    //     let appointment_time = null;

    //     if(progressed == 1){
    //         app_score = document.querySelector('input[name="app_score"]:checked').value;
    //         convo_message = document.getElementById('convo_message').value;
    //         hot_lead = document.getElementById('hot_lead').value;
    //     } else {
    //         reason = document.getElementById('app_reason').value;
    //         appointment_date = document.getElementById('re_app_date').value;
    //         appointment_time = document.getElementById('re_app_time').value;
    //         // appointment_date = document.querySelector('input[name="appointment_date"]').value;
    //         // appointment_time = document.querySelector('input[name="appointment_time"]').value;
    //     }

    //     if(document.getElementById('hot_lead').checked){
    //       hot_lead=1;
    //     }else{
    //       hot_lead=0;
    //     }


    //     const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');


    //     fetch(`/appointment_update/${resheduleid}`, {
    //             method: 'post',
    //             headers: {
    //                 'Content-Type': 'application/json',
    //                 'X-CSRF-TOKEN': csrfToken
    //             },
    //             body: JSON.stringify({
    //                 progressed: progressed,
    //                 app_score: app_score,
    //                 convo_message: convo_message,
    //                 hot_lead: hot_lead,
    //                 reason: reason,
    //                 appointment_date: appointment_date,
    //                 appointment_time: appointment_time,
    //             }),
    //         })

    //         .then(data => {
    //             if (data.status === 200) {
    //                 toastr.success('Appointment Updated successfully!');
    //                 location.reload();
    //             } else {
    //                 toastr.error('Appointment Failed to update!');
    //             }
    //         })
    //         .catch(error => {
    //             console.error('Error updating category:', error);

    //         });
    // }


    function updateReshedule() {
        const resheduleid = reshedule_id;
        const progressed = document.querySelector('input[name="progressed"]:checked').value;

        // Initialize variables
        let app_score = null;
        let convo_message = null;
        let hot_lead = null;
        let reason = null;
        let appointment_date = null;
        let appointment_time = null;
        var err=0;

        if(progressed == 1){
            app_score = document.querySelector('input[name="app_score"]:checked').value;
            convo_message = document.getElementById('convo_message').value;
            // hot_lead = document.getElementById('hot_lead').value;
        } else {
            reason = document.getElementById('app_reason').value;
            other_reason = document.getElementById('followup_reason_text').value;
              if(reason==1){
                if(other_reason == ""){
                    $('#followup_comments_text_err').text('Other Reason is Required');
                    err++;
                }else{
                  reason=other_reason;
                }
              }
            appointment_date = document.getElementById('re_app_date').value;
            appointment_time = document.getElementById('re_app_time').value;
            // appointment_date = document.querySelector('input[name="appointment_date"]').value;
            // appointment_time = document.querySelector('input[name="appointment_time"]').value;
        }


        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        // if(document.getElementById('hot_lead').checked){
        //   hot_lead=1;
        // }else{
        //   hot_lead=0;
        // }

      if(err==0){
          $('#rescheduleBtn').prop('disabled', true);
        fetch(`/appointment_update/${resheduleid}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                    progressed: progressed,
                    app_score: app_score,
                    convo_message: convo_message,
                    // hot_lead: hot_lead,
                    reason: reason,
                    appointment_date: appointment_date,
                    appointment_time: appointment_time,
                }),
            })

            .then(data => {
                if (data.status === 200) {
                    toastr.success('Appointment Updated successfully!');
                    location.reload();
                } else {
                    toastr.error('Appointment Failed to update!');
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);

        });
      }else{
        $('#rescheduleBtn').prop('disabled', false);
      }
    }

    // new appointment
    let resheduleagain_id;

    function openResheduleModalAgain(categoryId,name,mobile) {
         $('#lead_name_app_again').html(name);
        $('#lead_phone_app_again').html(mobile);
        resheduleagain_id = categoryId;
        // Function to format date to '10-Jun-2024'
        function formatDate(dateString) {
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }
                    function formatTime(timeString) {
                        const date = new Date(`1970-01-01T${timeString}Z`);
                        let hours = date.getUTCHours();
                        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                        const ampm = hours >= 12 ? 'PM' : 'AM';
                        hours = hours % 12;
                        hours = hours ? hours : 12; // the hour '0' should be '12'
                        return `${hours}:${minutes} ${ampm}`;
                    }
          fetch(`/edit_appointment/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;
                    document.getElementById('lead_id_again').value = lead.lead_id;
                    $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                    $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                      $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                    // document.getElementById('lead_id_again').value = formatDate(lead.lead_id);
                    // document.getElementById('app_time_again').value = lead.appointment_time;
                    // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                    console.log('Appointment Count:', data.data.appointmentCount);
                    $('#app_count_again').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            if(category.app_score === 1){
                                var score =  `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }else if(category.app_score === -1){
                               var score = `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }
                            else if(category.app_score === 0){
                               var score = `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }else{
                                var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                            }
                            const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-block badge rounded bg-success text-black fs-7">${formatDate(category.appointment_date)}</div>
                                </td>
                                <td>
                                    <div class="d-block badge rounded bg-danger text-white fs-7">${formatTime(category.appointment_time)}</div>
                                </td>
                                <td>${category.staff_name}</td>
                                <td>
                                    <div class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${category.reason ?? '-'}">${category.reason ?? '-'}</div>
                                </td>
                                <td>
                                    <label title="Score">
                                        ${score}
                                    </label>
                                </td>
                                <td>
                                    <div class=" text-black fw-bold fs-8 text-truncate max-w-100px" id="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}</div>
                                </td>
                            </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        <td colspan="6" class="text-center">No data available</td>
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }

                     $('[data-bs-toggle="tooltip"]').tooltip();


                } else {
                    console.error('Error fetching category:', data.message);
                }
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                console.error('Error fetching category:', error);
          });

          fetch(`/appointment_history/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                  console.log(data)
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;

                    $('#apptmnt_count_again').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('appointmentLeadIdsTableBodyAgain');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            const row = `<tr>
                                <td>${index + 1}</td>
                                <td>
                                    <label>${formatDate(category.previous_appointment_date == null? category.appointment_date : category.previous_appointment_date)}</label>
                                    <div class="d-block text-primary fs-8" title="Last Follow Up Date">${formatTime((category.previous_appointment_time == null? category.appointment_time : category.previous_appointment_time))}</div>
                                </td>
                                <td>
                                    <label class="text-truncate max-w-100px" title="${category.appointment_category}">${category.appointment_category !== null ? category.appointment_category : '-'}</label>
                                </td>
                                <td>
                                    <label title="Score">
                                        ${category.appointment_status == 2 ? `<span class="text-success fw-bold fs-6 text-center">Completed</span>` :
                                        category.appointment_status == 3 ? `<span class="text-danger fw-bold fs-6 text-center">Cancelled</span>` :
                                        category.appointment_status == 1 ? `<span class="text-info fw-bold fs-6 text-center">Not Yet Started</span>` :
                                        '<span>-</span>'}
                                    </label>
                                </td>
                                  <td>
                                    ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):'-' )}
                                </td>
                                <td>
                                    <label class="text-truncate max-w-100px" title="${category.appointment_reason}">
                                    ${category.appointment_reason !== null ? category.appointment_reason : '-'}</label>
                                    </td>
                            </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        <td colspan="6" class="text-center">No data available</td>
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }

                } else {
                    console.error('Error fetching category:', data.message);
                }
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });
    }
    let status_id;


        function openStatusModal(categoryId) {
            status_id = categoryId;
            fetch(`/lead_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data;
                        console.log(lead);

                        // document.getElementById('status_id').value = lead.status;
                        const statusSelect = document.getElementById('status_id');
                        statusSelect.value = lead.status;

                        // Optionally trigger a change event if needed
                        const event = new Event('change');
                        statusSelect.dispatchEvent(event);
                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });
        }

        function leadstatusupdate(statusId, status) {

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/hot_lead_status_update/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }


        function updatestatus(statusId, status) {
            // const statusId = status_id;
            // const status = document.getElementById('status_id').value;


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/status_update/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        // alert(data.status);
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        // toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }


        function inactiveModal(id, leadName) {
            $('#kt_modal_lead_inactivate').modal('show');
            $('#kt_modal_lead_inactivate .lead-name').text(leadName);
            $('#kt_modal_lead_inactivate .btn-primary').off('click').on('click', function() {
                updatestatus(id, 1); // Assuming status 1 is Inactive
                $('#kt_modal_lead_inactivate').modal('hide');
            });
        }
          //hot lead modal
        function hotLeadModal(id, leadName) {
            $('#kt_modal_hot_lead').modal('show');
            $('#kt_modal_hot_lead .lead-name').text(leadName);
            $('#kt_modal_hot_lead .btn-primary').off('click').on('click', function() {
              leadstatusupdate(id, 3); // Assuming status 1 is Inactive
                $('#kt_modal_hot_lead').modal('hide');
            });
        }

        function dropModal(id, leadName,staffId) {
            $('#kt_modal_lead_drop').modal('show');
            $('#kt_modal_lead_drop .lead-name').text(leadName);
            $('#staff_id_drop').val(staffId);

            $('#lead_id_drop').val(id);

            $('#kt_modal_lead_drop .btn-primary').off('click').on('click', function() {
                const reason = $('#reason_edit').val();
                const otherReason = $('#drop_reason_text').val();
                const comments = $('#drop_comments_text').val();

                if (!reason) {
                    $('#reason_edit_select_err').text('Reason is Required');
                    return false;
                }else {
                    $('#reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
                    $('#drop_comments_edit_err').text('Comments are required');
                    return false;
                }else {
                    $('#drop_comments_edit_err').text('');
                }

                if (reason == '1' && !otherReason.trim()) {
                    $('#reason_edit_err').text('Other Reason is required');
                    return false;
                }else {
                    $('#reason_edit_err').text('');
                }
            });
        }

        function PotentialModal(id, leadName,staffId) {
            $('#kt_modal_lead_potential').modal('show');
            $('#kt_modal_lead_potential .lead-name').text(leadName);
            $('#staff_id_potential').val(staffId);

            $('#lead_id_potential').val(id);

            $('#kt_modal_lead_potential .btn-primary').off('click').on('click', function() {
                const potential_reason = $('#potential_reason_edit').val();
                // alert(potential_reason)
                const otherReason = $('#potential_reason_text').val();
                const comments = $('#potential_comments_text').val();

                if (!potential_reason) {
                    $('#potential_reason_edit_select_err').text('Reason is Required');
                    return false;
                }else {
                    $('#potential_reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#potential_reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
                    $('#potential_comments_edit_err').text('Comments are required');
                    return false;
                }else {
                    $('#potential_comments_edit_err').text('');
                }

                if (potential_reason == '1' && !otherReason.trim()) {
                    $('#potential_reason_edit_err').text('Other Reason is required');
                    return false;
                }else {
                    $('#potential_reason_edit_err').text('');
                }
            });
        }

    function spamModal(id, leadName) {
        $('#kt_modal_lead_spam').modal('show');
        $('#kt_modal_lead_spam .lead-name').text(leadName);

        $('#lead_id_spam').val(id);

        $('#kt_modal_lead_spam .btn-primary').off('click').on('click', function() {
            // Validate the reason selection
            const reason = $('#spam_reason_edit').val();
            const otherReason = $('#spam_reason_text').val();
            const comments = $('#spam_comments_text').val();

            if (!reason) {
                $('#spam_reason_edit_select_err').text('Reason is Required');
                return false;
            }else {
                $('#spam_reason_edit_select_err').text('');
            }
            // Check if the selected reason's comments_check is 1 before validating comments
            const selectedReasonOption = $('#spam_reason_edit option:selected');
            const commentsCheck = selectedReasonOption.data('comments-check');

            if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
                $('#spam_comments_edit_err').text('Comments are required');
                return false;
            }else {
                $('#spam_comments_edit_err').text('');
            }

            if (reason == '1' && !otherReason.trim()) {
                $('#spam_reason_edit_err').text('Other Reason is required');
                return false;
            }else {
                $('#spam_reason_edit_err').text('');
            }
        });
    }

        function activeModal(id, leadName) {
            $('#kt_modal_lead_activate').modal('show');
            $('#kt_modal_lead_activate .lead-name').text(leadName);
            $('#kt_modal_lead_activate .btn-primary').off('click').on('click', function() {
                updatestatus(id, 0); // Assuming status 0 is Active
                $('#kt_modal_lead_activate').modal('hide');
            });
        }


    document.getElementById('updateStatusForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const statusId = document.getElementById('status_id').value;
        const status = document.getElementById('status_id').value;
        updatestatus(statusId, status);
        leadstatusupdate(statusId, status);
    });


    function confirmDelete(id, name, ids) {
            document.querySelector('#kt_modal_delete_lead .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('Are you sure you want to delete <br> <b>[' + ids + '] ' + name + '</b> Lead ?');
        }

    function deleteCourseCategory() {

        var categoryId = document.querySelector('#kt_modal_delete_lead .btn-danger').getAttribute('data-id');

        fetch('/lead_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Lead Deleted successfully!');
                    location.reload();

                } else {

                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }


    function ConvertCustomer(id, leadName, mobile) {
        document.getElementById('lead_id_cus').value = id;
        document.getElementById('lead-name').innerText = leadName;
        document.getElementById('lead-mobile').innerText = `[${mobile}]`;

        // Set the href attribute of the anchor tag
        // document.getElementById('lead-convert-link').href = `/sales/customer/customer_add/${id}`;
    }
    function submitConvertForm() {
        document.querySelector('form').submit();
    }

     function LeadMessage(leadId, name, mobile) {
        $('#lead_name_message').html(name);
        $('#lead_phone_message').html(mobile);
        $('#lead_id_message').val(leadId); // Set the lead ID in the hidden input field
        $('#kt_modal_lead_chat').modal('show'); // Show the modal
    }
    $('#sendMessageBtn').on('click', function(e) {
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const lead_id = $('#lead_id_message').val();
        const messageContent = $('#message_content').val();
        const messageType = $('#type').val(); // Assuming you have id="type" on your select element
        const whatsapp_temp_id = $('#whatsapp_template_id').val();
        const email_template_id = $('#email_template_id').val();
        $.ajax({
            url: '/lead_message',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            }, // Replace with your backend URL
            method: 'POST',
            data: JSON.stringify({
                lead_id: lead_id,
                message: messageContent,
                type: messageType,
                whatsapp_temp_id: whatsapp_temp_id,
                email_template_id: email_template_id,
                whatsapp: whatsappChecked,
                email: emailChecked,
                sms: linkedChecked
            }),
            success: function(response) {
                if (response.status === 200) {
                    toastr.success(response.message);
                    location.reload(); // Reload the page to update the UI
                } else {
                    toastr.error(response.message || 'Failed to send the message.');
                }
            },
            error: function(xhr, status, error) {
                const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                toastr.error(errorMsg);
            }
        });
    });
        // whatsapp template dropdown
        document.addEventListener('DOMContentLoaded', function() {
            fetch('{{ route('whatsapp_templates') }}')
                .then(response => response.json())
                .then(data => {
                    let select = document.getElementById('whatsapp_template_id');
                    select.innerHTML = ''; // Clear existing options
                     data.data.forEach(template => {
                        let option = document.createElement('option');
                        // if(template.name !="hello_world"){
                          option.value = template.name;
                          option.textContent = template.name;
                          select.appendChild(option);
                        // }

                    });
                })
                .catch(() => {
                    document.getElementById('template').innerHTML = '<option>Error loading templates</option>';
                });


        });
        </script>


<script>
          function lead_appointment_func(id,name){
             $('#search_lead_name').text(name);
             $('#lead_id_add').val(id);
             $.ajax({
                url: "{{ route('department') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="assg_dept_add"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                        response.data.forEach(function(dept) {
                            selectDropdown.append($('<option></option>').attr('value', dept
                                    .sno)
                                .text(dept.department_name));
                        });
                    }
                },
                error: function(error) {
                  selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                    // console.error('Error fetching course Brand:', error);
                }
            });

          }
    </script>
    {{-- lead appointment --}}
      <script>
        function addLeadvalidateForm() {
              var err = 0;

              $('#addSubmit').prop('disabled', true);
              // Validate Lead Name
              var ld_name_add = document.getElementById("lead_id_add").value.trim();
              if (ld_name_add === "") {
                  document.getElementById('appt_reason_add_err').innerHTML = 'Lead Name is required...!';
                  document.getElementById('lead_id_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('lead_id_add').classList.remove('error_msg');
                  document.getElementById('appt_reason_add_err').innerHTML = '';
              }
            // Validate appointment category
              var appt_catg_add = document.getElementById("appt_catg_add").value.trim();
              if (appt_catg_add === "") {
                  document.getElementById('appt_catg_add_err').innerHTML = 'Appointment Category is required...!';
                  document.getElementById('appt_catg_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('appt_catg_add').classList.remove('error_msg');
                  document.getElementById('appt_catg_add_err').innerHTML = '';
              }

              // Validate Appointment date
              var ld_appt_dt_add = document.getElementById("ld_appt_dt_add").value.trim();
              if (ld_appt_dt_add === "") {
                  document.getElementById('ld_appt_dt_add_err').innerHTML = 'Appointment Date is required...!';
                  document.getElementById('ld_appt_dt_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('ld_appt_dt_add').classList.remove('error_msg');
                  document.getElementById('ld_appt_dt_add_err').innerHTML = '';
              }

              // Validate Reason message
              var appt_reason_add = document.getElementById("appt_reason_add").value.trim();
              if (appt_reason_add === "") {
                  document.getElementById('appt_reason_add_err').innerHTML = 'Reason is required...!';
                  document.getElementById('appt_reason_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('appt_reason_add').classList.remove('error_msg');
                  document.getElementById('appt_reason_add_err').innerHTML = '';
              }

              // Validate Staff
              var assg_dept_add = document.getElementById("assg_dept_add").value.trim();
              if (assg_dept_add === "") {
                  document.getElementById('assg_dept_add_err').innerHTML = 'Department is required...!';
                  document.getElementById('assg_dept_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('assg_staff_add').classList.remove('error_msg');
                  document.getElementById('assg_dept_add_err').innerHTML = '';
              }

              var assg_staff_add = document.getElementById("assg_staff_add").value.trim();
              if (assg_staff_add === "") {
                  document.getElementById('assg_staff_add_err').innerHTML = 'Staff is required...!';
                  document.getElementById('assg_staff_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('assg_staff_add').classList.remove('error_msg');
                  document.getElementById('assg_staff_add_err').innerHTML = '';
              }

              if(err==0){
                  $('#addLeadAppointmentForm').submit();
              }else{
                  $('#addSubmit').prop('disabled', false);
              }

        }
      </script>


 <script>
      function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#filter_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#filter_form').submit();
        }
      }
    </script>

<script>
    function onlyOne(checkbox) {
        var checkboxes = document.getElementsByName('app_score')
        checkboxes.forEach((item) => {
            if (item !== checkbox) item.checked = false
        })
    }
</script>
<script>
    // Function to export table data to Excel
      function exportToExcel(filters) {
        $.ajax({
            url: '/lead/export-excel'
            , type: 'GET'
            , data: filters, // Pass filters as query parameters
            success: function(response) {
                window.location.href = '/lead/export-excel?' + $.param(filters); // Trigger file download
            }
            , error: function(xhr, status, error) {
                console.error('Error exporting to Excel:', error);
            }
        });
    }
    $('#export_excel').on('click', function(e) {
        e.preventDefault();
        let filters = {
            course_fill: $('#course_fill').val()
            , potential_type_fill: $('#potential_type_fill').val()
            , lead_source_fill: $('#lead_source_fill').val()
            , lead_status_fill: $('#lead_status_fill').val()
            , staff_fill: $('#staff_fill').val()
            , date_filter: $('#dt_fill_issue_rpt').val()
            , from_date_fillter_textbox: $('#from_date_fillter_textbox').val()
            , to_date_fillter_textbox: $('#to_date_fillter_textbox').val()
        };
        exportToExcel(filters);
         setTimeout(function() {
  console.log('This message will appear after 2 seconds');
  location.reload();
}, 2000); // 2000 milliseconds = 2 seconds
    });
    // Check if 'filter_on' session variable is set and trigger click event
    // $(document).ready(function() {
    //     @if($filter_on ?? '')
    //     $('.lead_filter').slideToggle('slow');
    //     // });
    //     @endif
    // });

    // // Toggle branch filter section
    // $('#lead_filter').click(function() {
    //     $('.lead_filter').slideToggle('slow');
    // });


    function sampleToExcel() {
        // Replace with your server endpoint for exporting to Excel
        let url = '/lead/sample-excel';

        // Example AJAX call to trigger export
        $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
                // Handle success, such as downloading the file
                window.location.href = url; // Redirect to download link
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error('Error exporting to Excel:', error);
            }
        });
    }

    // Event listener for Excel export button
    $('#sample_excel').on('click', function(e) {
        // e.preventDefault();
        sampleToExcel();

          setTimeout(function() {
  console.log('This message will appear after 2 seconds');
  location.reload();
}, 2000); // 2000 milliseconds = 2 seconds
    });
    // Similarly, add event listeners for CSV and PDF exports
    // Example: $('#export_csv').on('click', function(e) { ... });
    // Example: $('#export_pdf').on('click', function(e) { ... });

</script>
<script>
    document.getElementById('updateResheduleForm').addEventListener('submit', function(event) {
        event.preventDefault();
        // if (FollvalidateForm()) {
            updateReshedule();
        // }
    });
</script>
<script>
 $(document).ready(function() {
     $.ajax({
            url: "{{ route('country') }}", // Assuming this is your server-side route to fetch countries
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdownMenu = $('#countryDropdownMenu');
                    countryDropdownMenu.empty();
                    console.log(response.data);

                    // Add the search input to the dropdown menu
                    countryDropdownMenu.append('<li><input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');

                    // Loop through the countries and add them to the dropdown
                    response.data.forEach(function(country) {
                        countryDropdownMenu.append(
                            $('<li></li>').append(
                                $('<a></a>')
                                    .addClass('dropdown-item waves-effect')
                                    .attr('href', 'javascript:void(0);')
                                    .data('id', country.id)
                                    .data('phonecode', country.phonecode)
                                    .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                            )
                        );
                    });

                    // Pre-select country based on the initial selection (if any)
                    var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                    var initialPhoneCode = '';
                    if (selectedCountryId) {
                        var selectedCountry = response.data.find(function(country) {
                            return country.id === selectedCountryId;
                        });
                        if (selectedCountry) {
                            $('#countryDropdownButton').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode); // Set the initial country/phone code
                            initialPhoneCode = selectedCountry.phonecode;
                            $('#lead_mobile_create').attr('maxlength', 12);
                            $('#country_code_name').val(initialPhoneCode);
                        }
                    }

                    $('#countrySearch').on('input', function() {
                        var searchValue = $(this).val().toLowerCase();
                        $('#countryDropdownMenu li a').each(function() {
                            var countryText = $(this).text().toLowerCase();
                            if (countryText.indexOf(searchValue) === -1) {
                                $(this).parent().hide(); // Hide countries that don't match the search term
                            } else {
                                $(this).parent().show(); // Show countries that match
                            }
                        });
                    });
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });

        // Handle country selection from the dropdown
        $(document).on('click', '.dropdown-item', function() {
            var countryId = $(this).data('id');
            var phoneCode = $(this).data('phonecode');
            var countryName = $(this).text();

            $('#countryDropdownButton').text(countryName);
            $('#country_code_name').val(phoneCode);

            // Handle max length if needed based on country
            var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
            if (countryId === selectedCountryId) {
                $('#lead_mobile_create').attr('maxlength', 12);  // Set max length for a specific country
            } else {
                $('#lead_mobile_create').removeAttr('maxlength'); // Remove max length if country changes
            }
        });
});
    $(document).ready(function() {
        var selectedCountryId = null;
        var selectedStateId = null;
        var selectedCityId = null;


        // Fetch and populate countries for Add
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change

                    $('select[name="country"]').val({{ $login_branch_data->country_id ?? 0 }}).change();
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });

        // Event listener for country change for Add
        $('select[name="country"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state"]');
            var cityDropdown = $('select[name="city"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country for Add
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change

                            $('select[name="state"]').val({{ $login_branch_data->state_id ?? 0}}).change();
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change for Add
        $('select[name="state"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country"]').val();
            var cityDropdown = $('select[name="city"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country for Add
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                            });
                            cityDropdown.val(selectedCityId); // Set the selected city
                            $('select[name="city"]').val('{{ $login_branch_data->city_id ?? 0}}').change();
                        }

                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });

        // Fetch and populate countries for Edit
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country_edit"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });


        // Event listener for country change for Edit
        $('select[name="country_edit"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state_edit"]');
            var cityDropdown = $('select[name="city_edit"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country for Edit
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change for Edit
        $('select[name="state_edit"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country_edit"]').val();
            var cityDropdown = $('select[name="city_edit"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country for Edit
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                            });
                            cityDropdown.val(selectedCityId); // Set the selected city
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });
    });
</script>
<script>
    function toggleInputField(value) {
        var dropReasonDiv = document.getElementById('drop_reason_div');
        var dropReasonText = document.getElementById('drop_reason_text');
        var dropCommentsDiv = document.getElementById('drop_comments_div');
        var selectedOption = document.querySelector('#reason_edit option:nth-child(' + (document.getElementById('reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            dropReasonDiv.style.display = 'block';
            dropReasonText.setAttribute('required', 'required');
        } else {
            dropReasonDiv.style.display = 'none';
            dropReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            dropCommentsDiv.style.display = 'block';
        } else {
            dropCommentsDiv.style.display = 'none';
        }
    }
    function toggleInputField_potential(value) {
        var potentialReasonDiv = document.getElementById('potential_reason_div');
        var potentialReasonText = document.getElementById('potential_reason_text');
        var potentialCommentsDiv = document.getElementById('potential_comments_div');
        var selectedOption = document.querySelector('#potential_reason_edit option:nth-child(' + (document.getElementById('potential_reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-potential') : null;

        if (value == '1') {
            potentialReasonDiv.style.display = 'block';
            potentialReasonText.setAttribute('required', 'required');
        } else {
            potentialReasonDiv.style.display = 'none';
            potentialReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            potentialCommentsDiv.style.display = 'block';
        } else {
            potentialCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>
    function toggleAddSpam(value) {
        var ReasonDiv = document.getElementById('reason_div');
        var ReasonText = document.getElementById('reason_text');
        var CommentsDiv = document.getElementById('comments_div');
        var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            ReasonDiv.style.display = 'block';
            ReasonText.setAttribute('required', 'required');
        } else {
            ReasonDiv.style.display = 'none';
            ReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            CommentsDiv.style.display = 'block';
        } else {
            CommentsDiv.style.display = 'none';
        }
    }
</script>

<script>
    function toggleInputField_internal(value) {
        var internalReasonDiv = document.getElementById('internal_reason_div');
        var internalReasonText = document.getElementById('internal_reason_text');
        var internalCommentsDiv = document.getElementById('internal_comments_div');
        var selectedOption = document.querySelector('#reason_internal_select option:nth-child(' + (document.getElementById('reason_internal_select').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            internalReasonDiv.style.display = 'block';
            internalReasonText.setAttribute('required', 'required');
        } else {
            internalReasonDiv.style.display = 'none';
            internalReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            internalCommentsDiv.style.display = 'block';
        } else {
            internalCommentsDiv.style.display = 'none';
        }
    }
</script>

<script>
    function toggleInputField_spam(value) {
        var spamReasonDiv = document.getElementById('spam_reason_div');
        var spamReasonText = document.getElementById('spam_reason_text');
        var spamCommentsDiv = document.getElementById('spam_comments_div');
        var selectedOption = document.querySelector('#spam_reason_edit option:nth-child(' + (document.getElementById('spam_reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            spamReasonDiv.style.display = 'block';
            spamReasonText.setAttribute('required', 'required');
        } else {
            spamReasonDiv.style.display = 'none';
            spamReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            spamCommentsDiv.style.display = 'block';
        } else {
            spamCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>
    // Populate the edit modal with lead data, including setting the country code
    function populateEditModal() {
        var categoryId = $('#view_edit_id').val();
        fetch(`/lead_edit/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data;

                    // Populate input fields
                    $('#lead_id_edit').val(lead.sno);
                    $('#lead_name_edit').val(lead.lead_name);
                    $('#lead_mobile_edit').val(lead.lead_mobile);
                    $('#lead_alternate_edit').val(lead.lead_alternate_mobile);
                    $('#lead_email_edit').val(lead.lead_email_id);
                    $('#lead_dob_up').val(lead.lead_dob);
                    $('#lead_reg_date_up').val(lead.registered_date);
                    $('#lead_address_edit').val(lead.address);
                    $('#lead_comments_edit').val(lead.lead_comments);
                    $('#lead_type_edit').val(lead.lead_type_id).trigger('change');
                    $('#lead_marital_edit').val(lead.lead_marital_status).trigger('change');
                    $('#lead_source_edit').val(lead.lead_source_id).trigger('change');
                    $('#lead_Knowledge_edit_tag').val(lead.lead_knowledge_tags); // Assuming this is correct

                    // Initialize country code dropdown and selection
                    const selectedCountryId = lead.country || {{ $login_branch_data->country_id ?? 0 }};
                    const selectedStateId = lead.state || {{ $login_branch_data->state_id ?? 0 }};
                    const selectedCityId = lead.city || '{{ $login_branch_data->city_id ?? 0 }}';

                    // Fetch and populate countries for Edit
                    $.ajax({
                        url: "{{ route('country') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                const countryDropdown = $('#country_id_edit');
                                countryDropdown.empty().append('<option value="">Select Country</option>');
                                response.data.forEach(function(country) {
                                    countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                                });
                                countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change

                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state') }}",
                                    type: "GET",
                                    data: { country_id: selectedCountryId },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            const stateDropdown = $('#state_edit');
                                            stateDropdown.empty().append('<option value="">Select State</option>');
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                            });
                                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change

                                            // Fetch and populate cities based on selected state
                                            $.ajax({
                                                url: "{{ route('city') }}",
                                                type: "GET",
                                                data: { country_id: selectedCountryId, state_id: selectedStateId },
                                                success: function(response) {
                                                    if (response.status === 200 && response.data) {
                                                        const cityDropdown = $('#city_edit');
                                                        cityDropdown.empty().append('<option value="">Select City</option>');
                                                        response.data.forEach(function(city) {
                                                            cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                                                        });
                                                        cityDropdown.val(selectedCityId); // Set the selected city
                                                    }
                                                },
                                                error: function(error) {
                                                    console.error('Error fetching cities:', error);
                                                }
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });

                    var country_code = $('#country_code_name_edit').val();

                    $.ajax({
                        url: "{{ route('country') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var countryDropdownMenu = $('#countryDropdownMenu_edit');
                                countryDropdownMenu.empty();
                                console.log(response.data);

                                // Add the search input to the dropdown menu
                                countryDropdownMenu.append('<li><input type="text" id="countrySearch_edit" name="countrySearch_edit" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');

                                // Loop through the countries and add them to the dropdown
                                response.data.forEach(function(country) {
                                    countryDropdownMenu.append(
                                        $('<li></li>').append(
                                            $('<a></a>')
                                                .addClass('dropdown-item waves-effect')
                                                .attr('href', 'javascript:void(0);')
                                                .data('id', country.id)
                                                .data('phonecode', country.phonecode)
                                                .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                        )
                                    );
                                });

                                // Pre-select country based on the initial selection (if any)
                                var selectedCountryId = country_code;
                                if(country_code == 0){
                                  country_code = 91;
                                }
                                $('#countryDropdownButton_edit').text('+' + country_code);
                                $('#country_code_name_edit').val(country_code);

                                if (selectedCountryId) {
                                    // Find the country matching the phone code
                                    var selectedCountry = response.data.find(function(country) {
                                        return country.phonecode === selectedCountryId;  // Match based on the phone code
                                    });

                                    if (selectedCountry) {
                                        // Set the initial country/phone code in the dropdown button
                                        $('#countryDropdownButton_edit').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode);
                                        $('#country_code_name_edit').val(selectedCountry.phonecode); // Ensure the hidden input gets updated as well
                                        $('#lead_mobile_edit').attr('maxlength', 10); // Set maxlength based on country
                                    }
                                }

                                // Search functionality
                                $('#countrySearch_edit').on('input', function() {
                                    var searchValue = $(this).val().toLowerCase();
                                    $('#countryDropdownMenu_edit li a').each(function() {
                                        var countryText = $(this).text().toLowerCase();
                                        if (countryText.indexOf(searchValue) === -1) {
                                            $(this).parent().hide(); // Hide countries that don't match the search term
                                        } else {
                                            $(this).parent().show(); // Show countries that match
                                        }
                                    });
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });
                    $('#countryDropdownButton_edit').text('+' +country_code);

                    $('#countryDropdownMenu_edit').on('click', '.dropdown-item', function() {
                        var countryId = $(this).data('id');
                        var phoneCode = $(this).data('phonecode');
                        var countryName = $(this).text();

                        // Update dropdown button text with selected country
                        $('#countryDropdownButton_edit').text(countryName);
                        // Update the country code hidden input
                        $('#country_code_name_edit').val(phoneCode);

                        // Handle max length if needed based on country
                        var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                        if (countryId === selectedCountryId) {
                            $('#lead_mobile_edit').attr('maxlength', 10);  // Set max length for a specific country
                        } else {
                            $('#lead_mobile_edit').removeAttr('maxlength'); // Remove max length if country changes
                        }
                    });


                    // Gender radio button selection
                    $('input[name="lead_gender_edit"]').prop('checked', false); // Uncheck all
                    if (lead.lead_gender === 1) {
                        $('#inlineRadio1edit').prop('checked', true);
                    } else if (lead.lead_gender === 2) {
                        $('#inlineRadio2edit').prop('checked', true);
                    } else {
                        $('#inlineRadio3edit').prop('checked', true);
                    }

                    $(document).ready(function() {
                        // Basic
                        //------------------------------------------------------
                        const course_KnowledgeTagEl = document.querySelector('#lead_Knowledge_edit_tag');
                        let whitelist = [];
                        // Fetch data using $.ajax (jQuery)
                        $.ajax({
                            url: "{{ route('knowledge_tag') }}",
                            type: 'GET',
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    response.data.forEach(function(tags) {
                                        whitelist.push(tags.knowledge_tag_name); // Populate whitelist array
                                    });

                                    initializeTagify(); // Call Tagify initialization after data fetch
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching knowledge tags:', error);
                            }
                        });

                        function initializeTagify() {
                            // Inline initialization of Tagify
                            let KnowledgeTag = new Tagify(course_KnowledgeTagEl, {
                                whitelist: whitelist,
                                maxTags: 500, // allows to select max items
                                dropdown: {
                                    maxItems: 1000, // display max items
                                    classname: 'tags-inline', // Custom inline class
                                    enabled: 0,
                                    closeOnSelect: true
                                }
                            });

                            // Ensure the z-index is set correctly after initialization
                            KnowledgeTag.DOM.dropdown.style.zIndex = '9999';
                        }

                    });

                    $('#lead_course_edit').val(lead.course_id).trigger('change');
                    // Populate marital status dropdown
                    $('#lead_marital_edit, #lead_course_edit, #lead_type_edit, #lead_source_edit, .trigerchange').trigger('change');
                } else {
                    console.error('Error fetching lead data:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching lead data:', error);
            });
}

    // Function to handle the modal popup for editing a lead
    function partialEditModal(categoryId) {
        $('#view_edit_id').val(categoryId);
        populateEditModal();
        $('#kt_modal_edit_lead').modal('show');
}
</script>




    <script>
       $(document).ready(function() {
          $.ajax({
              url: "{{ route('email_template_list') }}",
              type: "GET",
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      // Populate the select dropdown with fetched course categories
                      var selectDropdown = $('select[name="email_template_id"]');
                      selectDropdown.empty();
                      selectDropdown.append($(
                          '<option value="">Select Email Template</option>'));
                      response.data.forEach(function(level) {
                          selectDropdown.append($('<option></option>').attr('value', level.sno)
                              .text(level.email_name));
                      });
                  }
              },
              error: function(error) {
                  console.error('Error fetching course categories:', error);
              }
          });
        });
        function insta_func() {
            var insta = document.getElementById("insta");
            var insta_on = document.getElementById("insta_on");

            if (insta.click) {
                insta_on.style.display = "block";
                insta.style.display = "none";

            } else {
                insta_on.style.display = "none";
                insta.style.display = "block";
            }
        }
    </script>

    <script>
        function insta_func1() {
            var insta = document.getElementById("insta");
            var insta_on = document.getElementById("insta_on");

            if (insta_on.click) {
                insta.style.display = "block";
                insta_on.style.display = "none";

            } else {
                insta.style.display = "none";
                insta_on.style.display = "block";
            }
        }
    </script>
    <script>
        function pinin_func() {
            var pinin = document.getElementById("pinin");
            var pinin_on = document.getElementById("pinin_on");

            if (pinin.click) {
                pinin_on.style.display = "block";
                pinin.style.display = "none";

            } else {
                pinin_on.style.display = "none";
                pinin.style.display = "block";
            }
        }
    </script>

    <script>
        function pinin_func1() {
            var pinin = document.getElementById("pinin");
            var pinin_on = document.getElementById("pinin_on");

            if (pinin_on.click) {
                pinin.style.display = "block";
                pinin_on.style.display = "none";

            } else {
                pinin.style.display = "none";
                pinin_on.style.display = "block";
            }
        }
    </script>
    
      <script>
function yes_func() {
 
    document.getElementById("progressed_yes").checked = true;
 
    var message = document.getElementById("message");
    var reason = document.getElementById("reason");
 
    message.style.display = "block";
    reason.style.display = "none";
}
</script>
 
<script>
function no_func() {
 
    document.getElementById("progressed_no").checked = true;
 
    var message = document.getElementById("message");
    var reason = document.getElementById("reason");
 
    reason.style.display = "block";
    message.style.display = "none";
}
</script>
    
   <script>
    let whatsappChecked = 0;
    let emailChecked = 0;
    let linkedChecked = 0;

    function whatsapp_func() {
        whatsappChecked = 1; // Set to 1 when selected
        $('#whatsapp').hide();
        $('#whatsapp_on').show();
    }

    function whatsapp_func1() {
        whatsappChecked = 0; // Set to 0 when deselected
        $('#whatsapp_on').hide();
        $('#whatsapp').show();
    }

    function email_func() {
        emailChecked = 1; // Set to 1 when selected
        $('#email').hide();
        $('#email_on').show();
    }

    function email_func1() {
        emailChecked = 0; // Set to 0 when deselected
        $('#email_on').hide();
        $('#email').show();
    }

    function linked_func() {
        linkedChecked = 1; // Set to 1 when selected
        $('#linked').hide();
        $('#linked_on').show();
    }

    function linked_func1() {
        linkedChecked = 0; // Set to 0 when deselected
        $('#linked_on').hide();
        $('#linked').show();
    }


   </script>


     <script>
        function populateStatusModal(id){
          $('#lead_status_id').val(id)
        }
      </script>
     <script>
      $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
    </script>
    {{-- department dropdown ajax --}}
     <script>
       function depat_staff_func(dept_id) {
          if (dept_id) {
              $.ajax({
                  url: "{{ route('dept_staff') }}",
                  type: "GET",
                  data: {
                      dept_id: dept_id
                  },
                  success: function(response) {
                      if (response.status === 200 && response.data) {
                          var selectDropdown = $('#assg_staff_add');
                          selectDropdown.empty();
                          selectDropdown.append(
                              '<option value="">Select Staff</option>');
                          response.data.forEach(function(staff) {
                              var option = $('<option></option>')
                                  .attr('value', staff
                                      .sno)
                                  .text(staff.staff_name + " - "+staff.position_name);
                              selectDropdown.append(option);
                          });
                      }
                  },
                  error: function(error) {
                      console.error('Error fetching Staff:', error);
                  }
              });
          } else {
              $('#assg_staff_add').empty().append(
                  '<option value="">Select Staff</option>');
          }
      }
    </script>
    {{-- covert branch for lead --}}
    <script>
      $(document).ready(function() {
        // Now this function is already defined, so we can safely add the event listener
        document.getElementById('convertBranchForm').addEventListener('submit', function(event) {
            event.preventDefault();
            $('#convert_staff_id_err').text("");
            $('#convert_branch_id_err').text("");
            const id = document.getElementById('covert_lead_id').value;
            const convert_branch_id = document.getElementById('convert_branch_id').value;
            const convert_staff_id = document.getElementById('convert_staff_id').value;
            var err=0;
            if(convert_branch_id ==""){
                $('#convert_branch_id_err').text("Branch is Required..!");
                err++;
              } if(convert_staff_id==""){
                $('#convert_staff_id_err').text("Staff is Required..!");
                err++;
              }
              if(err>0){
                return false;
              }else{
                convertBranch(id, convert_branch_id,convert_staff_id);
                return true;
              }
        });
      });

      function convertBranch(id, convert_branch_id,convert_staff_id) {
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

          fetch(`/lead_convert_branch/${id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': csrfToken
              },
              body: JSON.stringify({
                convert_branch_id: convert_branch_id,
                  convert_staff_id: convert_staff_id
              }),
          })
          .then(response => response.json())  // Ensure you parse the JSON response
          .then(data => {
              if (data.status === 200) {
                  toastr.success('Branch Converted successfully!');
                  location.reload();
              } else {
                  toastr.error('Branch Failed to Convert!');
              }
          })
          .catch(error => {
              console.error('Error updating category:', error);
              toastr.error('An error occurred: ' + error.message);
          });
      }
    </script>
    {{-- branch staff dropdown --}}
    <script>
       function convert_staff_func(branch_id) {
          if (branch_id) {
              $.ajax({
                  url: "{{ route('branch_staff') }}",
                  type: "GET",
                  data: {
                      branch_id: branch_id
                  },
                  success: function(response) {
                      if (response.status === 200 && response.data) {
    var selectDropdown = $('#convert_staff_id');
    selectDropdown.empty().append('<option value="">Select Staff</option>');

    response.data.forEach(function(staff) {
        // Capitalize the first letter of each word in staff_name and position_name
        var name_option = staff.staff_name.split(' ').map(function(word) {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }).join(' ') + " - " + staff.position_name.split(' ').map(function(word) {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }).join(' ');

        var option = $('<option></option>')
            .attr('value', staff.sno)
            .text(name_option);

        selectDropdown.append(option);
    });
}
                  },
                  error: function(error) {
                      console.error('Error fetching Staff:', error);
                  }
              });
          } else {
              $('#convert_staff_id').empty().append(
                  '<option value="">Select Staff</option>');
          }
      }
    </script>
          <script>
        function convertBranchModal(id,name){
          $('#covert_lead_id').val(id);
           $('#covert_lead_name').text(name);
        }

         function ConvertIntern(id, leadName, mobile) {
            document.getElementById('lead_id_intern').value = id;
            document.getElementById('lead-name_intern').innerText = leadName;
            document.getElementById('lead-mobile_intern').innerText = `[${mobile}]`;
        }
      </script>

<script>
    function spamAddvalidateForm() {
        var err = 0;

        // Get mobile number and validate
        var lead_mobile_spam = document.getElementById("lead_mobile_spam").value.trim();
        var mobilePattern = /^\d{5,12}$/; // Regular expression to match exactly 10 digits

        if (lead_mobile_spam === "") {
            document.getElementById('lead_mobile_spam_err').innerHTML = 'Mobile number is required...!';
            err++;
        } else if (!mobilePattern.test(lead_mobile_spam)) {
            document.getElementById('lead_mobile_spam_err').innerHTML = 'Mobile number must be 10 digits...!';
            err++;
        } else {
            document.getElementById('lead_mobile_spam_err').innerHTML = '';
        }

       // Get other fields and validate
        var spam_reason = document.getElementById("spam_reason");
        var reason_text = document.getElementById("reason_text");
        var spam_comments = document.getElementById("spam_comments");

        // Clear error messages for reason and comments
        document.getElementById('reason_text_err').innerHTML = '';
        document.getElementById('spam_comments_err').innerHTML = '';

        // Check if spam reason is provided
        if (!spam_reason || spam_reason.value === "") {
            // alert('reason valid');
            document.getElementById('reason_select_err').innerHTML = 'Reason is required...!';
            err++;
        } else if (spam_reason.value === "1") {
            // alert('other reason valid');
            if (!reason_text || reason_text.value.trim() === "") {
                document.getElementById('reason_text_err').innerHTML = 'Other reason is required...!';
                err++;
            }
        }

        // Check if the selected reason's comments_check is 1 before validating comments
        var selectedReasonOption = spam_reason.options[spam_reason.selectedIndex];
        var commentsCheck = selectedReasonOption ? selectedReasonOption.getAttribute('data-comments-check') : null;

        if (commentsCheck == "1" && (!spam_comments || spam_comments.value.trim() === "")) {
            // alert('comments valid');
            document.getElementById('spam_comments_err').innerHTML = 'Comments are required...!';
            err++;
        }

        // If no errors, submit the form
        if (err === 0) {
            $('#spamAddForm').submit();
            $('#submit_spam_add').prop('disabled', true);
        } else {
            $('#submit_spam_add').prop('disabled', false);
        }
    }
</script>
<script>
    function internalCalls(id, leadName) {
        $('#kt_modal_internal_call_lead').modal('show');
        $('#kt_modal_internal_call_lead .internal_name').text(leadName);

        $('#lead_id_internal').val(id);

        $('#kt_modal_internal_call_lead .btn-primary').off('click').on('click', function() {
            // Validate the reason selection
            const reason = $('#reason_internal_select').val();
            const otherReason = $('#internal_reason_text').val();
            const comments = $('#internal_comments_text').val();

            if (!reason) {
                $('#reason_internal_select_err').text('Reason is Required');
                return false;
            }else {
                $('#reason_internal_select_err').text('');
            }
            // Check if the selected reason's comments_check is 1 before validating comments
            const selectedReasonOption = $('#reason_internal_select option:selected');
            const commentsCheck = selectedReasonOption.data('comments-check');

            if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
                $('#internal_comments_text_err').text('Comments are required');
                return false;
            }else {
                $('#internal_comments_text_err').text('');
            }

            if (reason == '1' && !otherReason.trim()) {
                $('#internal_reason_text_err').text('Other Reason is required');
                return false;
            }else {
                $('#internal_reason_text_err').text('');
            }
        });
    }
</script>
{{-- bulk conversion --}}
    <script>
      $('#bulk_checkall').change(function () {
          $('.bulk_chk').prop('checked',this.checked);
      });

      $('.bulk_chk').change(function () {
      if ($('.bulk_chk:checked').length == $('.bulk_chk').length){
        $('#bulk_checkall').prop('checked',true);
      }
      else {
        $('#bulk_checkall').prop('checked',false);
      }
      });
      // function bulk_lead_sourx
      // function bulk_lead_sourx
      function bulk_request_pay() {
        $('#bulk_convert_btn').prop('disabled', true);

        var bulk_assign_staff_conver = $('#bulk_assign_staff_conver').val();
        $('#bulk_assign_staff_id').val(bulk_assign_staff_conver);
        // alert(bulk_assign_staff_conver);

        var bulk_assign_staff_hidden = $('#bulk_assign_staff_id').val();

        if ($('.bulk_chk:checked').length > 0) {
            if (bulk_assign_staff_hidden == "") {
                $('#bulk_convert_btn').prop('disabled', false);
                document.getElementById('bulk_assign_staff_conver_err').innerHTML = 'Staff is required...!';
            } else {
                $('#bulk_convert_btn').prop('disabled', true);

                var createdByData = [];
                $('.bulk_chk:checked').each(function () {
                    var createdBy = $(this).data('created-by');
                    createdByData.push(createdBy);
                });

                // Create hidden input fields for each `created_by` value
                createdByData.forEach(function (createdBy, index) {
                    var input = $('<input>').attr({
                        type: 'hidden',
                        name: 'created_by[' + index + ']', // You can use the index for unique names
                        value: createdBy
                    });
                    $('#bulk_request_pay_form').append(input);
                });

                // Submit the form
                $('#bulk_request_pay_form').attr('action', "{{ route('bulk_sales_staff_convert') }}");
                $("#bulk_request_pay_form").submit();
            }
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'Please Check Any one of the checkbox...',
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            $('#kt_modal_bulk_convert_sales_person').modal('hide');
        }

        $('#bulk_convert_btn').prop('disabled', false);
    }
    </script>
    <script>
     // bulk assign staff
     $.ajax({
                  url: "{{ route('sales_staff') }}",
                  type: "GET",
                  success: function(response) {
                      if (response.status === 200 && response.data) {
                        let select = document.getElementById('bulk_assign_staff_conver');
                        select.innerHTML = ''; // Clear existing options
                        // Add the empty option
                        let defaultOption = document.createElement('option');
                        defaultOption.value = '';
                        defaultOption.textContent = 'Select Convert Staff';
                        select.appendChild(defaultOption);
                      response.data.forEach(staff => {

                        let option = document.createElement('option');
                        option.value = staff.sno;
                        var staffName = (staff.staff_name + "-" + staff.position_name).charAt(0).toUpperCase() +(staff.staff_name + "-" + staff.position_name).slice(1).toLowerCase();
                        option.textContent = staffName;
                        select.appendChild(option);
                    });
                      } else {
                          let select = document.getElementById('bulk_assign_staff_conver');
                          select.innerHTML = ''; // Clear existing options
                          // Add the empty option
                          let defaultOption = document.createElement('option');
                          defaultOption.value = '';
                          defaultOption.textContent = 'Select Convert Staff';
                          select.appendChild(defaultOption);
                      }
                  }

            });
    </script>
    <script>
  function toggleInputField_followup(value) {
      var followupReasonDiv = document.getElementById('followup_reason_div');
      var followupReasonText = document.getElementById('followup_reason_text');
      // var followupCommentsDiv = document.getElementById('followup_comments_div');
      var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById('app_reason').selectedIndex + 1) + ')');
      // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

      if (value == '1') {
          followupReasonDiv.style.display = 'block';
          followupReasonText.setAttribute('required', 'required');
      } else {
          followupReasonDiv.style.display = 'none';
          followupReasonText.removeAttribute('required');
      }

      // if (commentsCheck == '1') {
      //     followupCommentsDiv.style.display = 'block';
      // } else {
      //     followupCommentsDiv.style.display = 'none';
      // }
  }
</script>
    {{-- show bulk conversion button --}}
  <script>
      function showConversionBtn() {
          var bulkCheckAll = document.getElementById('bulk_checkall');

          if(bulkCheckAll.checked){
            $('#bulkConversionBtn').show();
          }else {
            $('#bulkConversionBtn').hide();
          }

      }

      function singleShowConversionBtn() {
        var checkboxes = document.querySelectorAll('.bulk_chk');
        var isAnyChecked = false;
        checkboxes.forEach(function(checkbox) {
            if (checkbox.checked) {
                isAnyChecked = true;
            }
        });

        if(isAnyChecked) {
            $('#bulkConversionBtn').show();
          } else {
            $('#bulkConversionBtn').hide();
          }
      }

  </script>
   <script>
        function leadWallet(id, leadName, staff_id) {
            $('#kt_modal_lead_wallet').modal('show');
            $('#kt_modal_lead_wallet .wallet_name').text(leadName);
            $('#lead_id_wallet').val(id);
            $('#staff_id_wallet').val(staff_id);
            $('#kt_modal_lead_wallet .btn-primary').off('click').on('click', function() {
                $('#kt_modal_lead_wallet').modal('hide');
            });
        }
    </script>
    <script>
       function formatDateTransfer(dateString) {
            let date = new Date(dateString);
            let day = String(date.getDate()).padStart(2, '0');
            let monthIndex = date.getMonth();
            let year = date.getFullYear();

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex];

            return `${day}-${month}-${year}`;
        }


        function leadTransfer(id, name, mobile_no, lead_src, reg_date = '') {
            $('#lead_id_transfer').val(id);
            $('#lead_name_transfer').html(name);
            $('#lead_mobile_transfer').html(mobile_no);
            $('#lead_src_transfer').html(lead_src);
            if(reg_date != ''){
                $('#lead_reg_date_transfer').html(formatDateTransfer(reg_date));
            } else {
                $('#lead_reg_date_transfer').html('-');
            }


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/lead_transfer/${id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify({})
            })
            .then(response => response.json())
            .then(data => {
                console.log('Data', data);

                if (data && data.data && Array.isArray(data.data)) {
                    const transferLogDiv = document.getElementById('transfer_log_div');
                    transferLogDiv.innerHTML = '';

                     // Lead List
                    const transferredFromMapping = {
                        0:  'Direct Lead',
                        1:  'Bulk Raw Lead - Lead',
                        2:  'Lead - Spam Lead',
                        3:  'Lead - Drop Lead',
                        4:  'Raw Lead - Lead',
                        5:  'Bulk Raw Lead - Lead',
                        6:  'Bank Raw Lead - Lead',
                        7:  'Bulk Bank Raw Lead - Lead',
                        8:  'Cloud Call - Lead',
                        9:  'Cloud Call - Spam Lead',
                        10: 'Call Tracker - Lead',
                        11: 'Call Tracker - Spam Lead',
                        12: 'Justdial - Lead',
                        13: 'Website - Lead ',
                        14: 'Spam Lead - Lead',
                        15: 'Dead Lead - Lead',
                        16: 'Lead - Potential Lead',
                        17: 'Potential Lead - Lead'
                    };

                    data.data.forEach(item => {
                        // let staffName =  item.end_date ? item.current_staff_name : item.change_staff_name;
                        let staffName =  item.current_staff_name;

                        // Map transferred_from to human-readable text
                        let transferredFromText = transferredFromMapping[item.transferred_from] || '-'; // Default to '-' if value is not found

                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${staffName || ''}</td>
                            <td>${transferredFromText}</td>
                            <td>${item.end_date ? formatDateTransfer(item.end_date) : '-'}</td>
                            <td>${item.days_difference || ''}</td>
                        `;
                        transferLogDiv.appendChild(row);
                    });
                } else {
                     // If no transfer data is available, display a message
                    const transferLogDiv = document.getElementById('transfer_log_div');
                    transferLogDiv.innerHTML = '<tr><td></td><td colspan="4">There is no transfer of staff for the lead</td><td></td><td></td></tr>';
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);
                toastr.error('An error occurred: ' + error.message);
            });
        }
    </script>
    <script>
        function successSummary(name, mobile, message, count, call_count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("succ_lead_name").innerText = name;
            document.getElementById("succ_lead_mobile").innerText = mobile;
            document.getElementById("lead_succ_msg").innerText = message;
            document.getElementById("lead_succ_count").innerHTML = formattedCount;
            document.getElementById("lead_succ_call_count").innerHTML = formattedCallCount;
        }

        function failSummary(name, mobile, message, count, call_count) {

            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("fail_lead_name").innerText = name;
            document.getElementById("fail_lead_mobile").innerText = mobile;
            document.getElementById("lead_fail_msg").innerText = message;
            document.getElementById("lead_fail_count").innerHTML = formattedCount;
            document.getElementById("lead_fail_call_count").innerHTML = formattedCallCount;
        }

        function dangerSummary(name, mobile, daysDiff, expectedCount, outgoingCount, count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedOutgoingCount = outgoingCount.toString().padStart(2, '0');
            let formattedExpectedCount = expectedCount.toString().padStart(2, '0');
            let message = `Outgoing calls are mismatched!`;

            document.getElementById("danger_lead_name").innerText = name;
            document.getElementById("danger_lead_mobile").innerText = mobile;
            document.getElementById("lead_danger_days").innerText = daysDiff;
            document.getElementById("danger_lead_msg").innerText = message;
            document.getElementById("lead_danger_expected").innerText =  formattedOutgoingCount;
            document.getElementById("lead_danger_call_count").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_call_count_actual").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_count").innerHTML = formattedCount;
        }

    </script>

    <script>
    $('#addSlotForm').submit(function (event) {
        event.preventDefault();
        var form = $(this);
        var phoneNumber = $('#lead_mobile_add').val();
        var countryCode = $('#country_sort_name_add').val();

        $.ajax({
            url: form.attr('action'),
            method: form.attr('method'),
            data: form.serialize(),
            success: function(response) {
                if (response.valid) {

                    $('#valid_detail_div').show();

                    $('#Message').text(response.message).removeClass('text-danger').addClass('text-success').css('text-align', 'center');

                    $('#location').text(response.location);
                    $('#carrier').text(response.carrier);
                } else {

                    $('#valid_detail_div').show();

                    $('#Message').text(response.message).removeClass('text-success').addClass('text-danger').css('text-align', 'center');
                    $('#location').text('-');
                    $('#carrier').text('-');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    });
</script>
<!-- syllabus document message -->
 <script>

    function sendSyllabusMessage(leadId, name, mobile) {
        $('#lead_name_document').html(name);
        $('#lead_phone_document').html(mobile);
        $('#lead_id_document').val(leadId); // Set the lead ID in the hidden input field
        $('#kt_modal_syllabus_document_send').modal('show'); // Show the modal
    }

    function sendSyllabus_func(){
        $('#sendDocumentbtn').prop('disabled', true);
        var err=0;

        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const lead_id = $('#lead_id_document').val();
        const course_id_msg = $('#course_id_msg').val();
        const course_type_id_msg = $('#course_type_id_msg').val();

        if (course_type_id_msg === " ") {
            document.getElementById('course_type_id_msg_err').innerHTML = 'Course Type is required...!';
            document.getElementById('course_type_id_msg').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('course_type_id_msg').classList.remove('error_msg');
            document.getElementById('course_type_id_msg_err').innerHTML = '';
        }

        if (course_id_msg === " ") {
            document.getElementById('course_id_msg_err').innerHTML = 'Course is required...!';
            document.getElementById('course_id_msg').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('course_id_msg').classList.remove('error_msg');
            document.getElementById('course_id_msg_err').innerHTML = '';
        }


        if(err==0){
            $('#sendDocumentbtn').prop('disabled', true);
            $.ajax({
                url: '/syllabus_message',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    lead_id: lead_id,
                    course_id: course_id_msg,

                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        console.log(response)
                        $('#sendDocumentbtn').prop('disabled', true);
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                        $('#sendDocumentbtn').prop('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                    $('#sendDocumentbtn').prop('disabled', false);
                }
            });

        }else{
            $('#sendDocumentbtn').prop('disabled', false);
            return false;
        }


    }

    $.ajax({
        url: "{{ route('course_type') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                var selectDropdown = $('#course_type_id_msg');
                selectDropdown.empty().append('<option value="">Select Course Type</option>');
                response.data.forEach(function(level) {
                    selectDropdown.append($('<option></option>').attr('value', level.sno).text(level.course_type_name));
                });
            } else {
                console.error('Error fetching course types:', response);
            }
        },
        error: function(error) {
            console.error('Error fetching course types:', error);
        }
    });

    function course_type_change_func(value){
            var courseTypeId = value;

            if (courseTypeId) {
                $.ajax({
                    url: "{{ route('get_course') }}",
                    type: "GET",
                    data: { course_type_id: courseTypeId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var selectDropdown = $('#course_id_msg');
                            selectDropdown.empty().append('<option value="">Select Course</option>');
                            response.data.forEach(function(course) {
                                selectDropdown.append($('<option></option>').attr('value', course.sno).text(course.course_name).data('course_name', course.course_name));
                            });
                        } else {
                            console.error('Error fetching courses:', response);
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching courses:', error);
                    }
                });
            } else {
                $('#course_id_msg').empty().append('<option value="">Select Course</option>');
            }
    }
 </script>

 <script>
    function phoneVerifyDetails(leadName, leadMobile, validStatus, carrier, lineType, location) {
        let statusMessage = validStatus ? "<span class='text-success'>Valid Number</span>" : "<span class='text-danger'>IN-Valid Number</span>";

        // Construct the message
        let message = `<div class="row">`;
        message += `
            <div class="col-lg-5">Lead Name</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6"><strong>${leadName}</strong></div>`;

        message += `
            <div class="col-lg-5">Lead Mobile</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6 fs-4"><strong>${leadMobile}</strong></div>`;

        message += `
            <div class="col-lg-5">Status</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6"><strong>${statusMessage}</strong></div>`;

        if (carrier) message += `
            <div class="col-lg-5">Carrier</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6"><strong>${carrier}</strong></div>`;

        if (lineType) message += `
            <div class="col-lg-5">Line Type</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6 fs-6"><strong>${lineType}</strong></div>`;

        if (location) message += `
            <div class="col-lg-5">Location</div>
            <div class="col-lg-1">:</div>
            <div class="col-lg-6"><strong>${location}</strong></div>`;

        message += `</div>`;

        // Set content in the modal
        document.getElementById("phone_verify_modal_content").innerHTML = message;

        // Show modal
        var phoneVerifyModal = new bootstrap.Modal(document.getElementById("kt_modal_phone_verify"));
        phoneVerifyModal.show();
    }

function dropModalList(id, leadName, staffId) {
 
            $('#kt_modal_lead_drop_list').modal('show');
 
            $('#staff_id_drop_list').val(staffId);
            $('#lead_id_drop_list').val(id);
 
            $('.lead-name').text(leadName);
 
            $('#deadLeadTableBody').html('');
 
            $.ajax({
                url: '/lead/getNotClosedDead',
                type: 'GET',
                data: { lead_id: id, created_by: staffId },
                dataType: 'json',
 
                success: function(res) {
 
                    if(res.data && res.data.length > 0){
 
                        let rows = '';
 
                        res.data.forEach(function(lead){
 
                            rows += `
                                <tr>
                                    <td class="fw-bold">${lead.lead_id}</td>
                                    <td>${lead.lead_name}</td>
                                    <td class="text-primary fw-bold">${lead.lead_mobile}</td>
                                </tr>
                            `;
 
                        });
 
                        $('#deadLeadTableBody').html(rows);
 
                    }else{
 
                        $('#deadLeadTableBody').html(`
                            <tr>
                                <td colspan="3" class="text-center text-danger">
                                    No Pending Dead Leads
                                </td>
                            </tr>
                        `);
 
                    }
 
                },
 
                error:function(){
 
                    $('#deadLeadTableBody').html(`
                        <tr>
                            <td colspan="3" class="text-center text-danger">
                                Error loading data
                            </td>
                        </tr>
                    `);
 
                }
 
            });
 
        }
        function spamModalList(id, leadName, staffId) {
 
            $('#kt_modal_lead_spam_list').modal('show');
 
            $('#staff_id_spam_list').val(staffId);
            $('#lead_id_spam_list').val(id);
 
            $('.lead-name').text(leadName);
 
            $('#spamLeadTableBody').html('');
 
            $.ajax({
                url: '/lead/getNotClosedSpam',
                type: 'GET',
                data: { lead_id: id, created_by: staffId },
                dataType: 'json',
 
                success: function(res) {
 
                    if(res.data && res.data.length > 0){
 
                        let rows = '';
 
                        res.data.forEach(function(lead){
 
                            rows += `
                                <tr>
                                    <td class="fw-bold">${lead.lead_id}</td>
                                    <td>${lead.lead_name}</td>
                                    <td class="text-primary fw-bold">${lead.lead_mobile}</td>
                                </tr>
                            `;
 
                        });
 
                        $('#spamLeadTableBody').html(rows);
 
                    }else{
 
                        $('#spamLeadTableBody').html(`
                            <tr>
                                <td colspan="3" class="text-center text-danger">
                                    No Pending Spam Leads
                                </td>
                            </tr>
                        `);
 
                    }
 
                },
 
                error:function(){
 
                    $('#spamLeadTableBody').html(`
                        <tr>
                            <td colspan="3" class="text-center text-danger">
                                Error loading data
                            </td>
                        </tr>
                    `);
 
                }
 
            });
 
        }
        
 </script>
 <script>
    function pending_followup_func(){
         $('#pending_followup_form').submit();
    }
     $(document).ready(function() {
$(".common_time_class_new").flatpickr({
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            defaultHour: new Date().getHours(),
            defaultMinute: new Date().getMinutes()
        });
});
 </script>

 <script>
    function walkin_func(){
         $('#walkin_func_form').submit();
    }
 </script>



@endsection
