@extends('layouts.contentNavbarLayout')

@section('title', 'WhatsApp Management')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id;
$user_data=$helper->get_staff_data($user_id);
@endphp



@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">

<div class="wa-app" id="waApp" data-section="{{ $section }}" data-kind="{{ $kind }}" data-default-branch="{{ $defaultBranchId }}"
     data-pusher-key="{{ config('broadcasting.connections.pusher.key', '4ca039940ceb505e4104') }}"
     data-pusher-cluster="{{ config('broadcasting.connections.pusher.options.cluster', 'ap2') }}"
     data-broadcast-auth="{{ url('/broadcasting/auth') }}">
  <aside class="wa-sidebar">

    <div class="wa-brand">
      <span class="wa-brand-mark"><span class="mdi mdi-whatsapp"></span></span>
      <div>
        <strong>WhatsApp</strong>
        <small>WhatsApp Management</small>
      </div>
    </div>

    <div class="wa-side-scroll">
      <a class="wa-nav {{ $section === 'dashboard' ? 'active' : '' }}" href="{{ url('/wa-management') }}">
        <span>▦</span> Overview
      </a>

      <div class="wa-nav-group-label">MESSAGING</div>
      <div class="wa-nav-parent">Chats</div>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'lead' ? 'active' : '' }}" data-wa-feature="lead_chat" href="{{ url('/wa-management/chats/lead') }}">Lead chat</a>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'customer' ? 'active' : '' }}" data-wa-feature="customer_chat" href="{{ url('/wa-management/chats/customer') }}">Customer chat</a>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'common' ? 'active' : '' }}" data-wa-feature="common_chat" href="{{ url('/wa-management/chats/common') }}">Common chat</a>
      <a class="wa-subnav {{ $section === 'groups' ? 'active' : '' }}" data-wa-feature="custom_group_chat" href="{{ url('/wa-management/groups') }}">Custom audiences</a>
      <a class="wa-subnav {{ $section === 'broadcast' ? 'active' : '' }}" data-wa-feature="broadcast_channel" href="{{ url('/wa-management/broadcast') }}">Broadcast manager</a>
      <a class="wa-nav {{ $section === 'templates' ? 'active' : '' }}" href="{{ url('/wa-management/templates') }}">
        <span>▤</span> Templates
      </a>
      <a class="wa-nav {{ $section === 'automation' ? 'active' : '' }}" href="{{ url('/wa-management/automation') }}">
        <span>⤷</span> Automation rules
      </a>
      <a class="wa-nav {{ $section === 'campaigns' ? 'active' : '' }}" data-wa-feature="bulk_campaigns" href="{{ url('/wa-management/campaigns') }}">
        <span>➤</span> Bulk campaigns
      </a>
      <a class="wa-nav {{ $section === 'logs' ? 'active' : '' }}" href="{{ url('/wa-management/logs') }}">
        <span>≡</span> Message logs
      </a>

      <div class="wa-nav-group-label">CONTROL</div>
      <a class="wa-nav {{ $section === 'consent' ? 'active' : '' }}" href="{{ url('/wa-management/consent') }}">
        <span>✓</span> Consent registry
      </a>
      <a class="wa-nav {{ $section === 'setup' ? 'active' : '' }}" href="{{ url('/wa-management/setup') }}">
        <span>⚙</span> API & menu setup
      </a>
      <a class="wa-nav {{ $section === 'calling' ? 'active' : '' }}" data-wa-feature="calling" href="{{ url('/wa-management/calling') }}">
        <span>☎</span> Calling capability
      </a>
    </div>

    <div class="wa-side-foot">
      <span class="wa-status-dot"></span> Outbox-first messaging
      <br>
      <small>Shared ERP profile • branch-scoped CRM</small>
    </div>

  </aside>
  
  <main class="wa-main">
    <header class="wa-topbar">
      <div>
        <!-- <div class="wa-eyebrow">ERP / WHATSAPP</div> -->
        <div class="wa-top-title">{{ ucfirst(str_replace('_', ' ', $section === 'chat' ? $kind . ' chat' : $section)) }}</div>
      </div>
      <div class="wa-top-actions">
        <span id="waBranchControl">
          <label for="waBranchId">CRM branch</label>
          <input id="waBranchId" type="number" min="1" value="{{ $defaultBranchId }}" class="wa-branch-input">
        </span>
        <span id="waGlobalState" class="wa-state-pill">Checking status…</span>
        <button type="button" id="waGlobalKill" class="wa-btn wa-btn-danger">Pause all sending</button>
      </div>
    </header>
    <div class="wa-body">
      @include('content.whatsapp_management.pages.' . $section)
    </div>
    <div id="waToast" class="wa-toast" role="status" aria-live="polite">

    </div>
  </main>

</div>

<style>
  .wa-app{
    display:flex;
    min-height:calc(100vh - 120px);
    margin:-.5rem 0 0;
    background:#f5f7f9;
    border:1px solid #e4e9ef;
    border-radius:16px;
    overflow:hidden;
    color:#1c2b33;
    font-family:inherit;
    --wa-green:#0b806c;
    --wa-green-dark:#075e54;
    --wa-soft:#e8f5ef;
    --wa-line:#e4e9ed;
    --wa-muted:#71818a;
  }
  .wa-sidebar{
    width:242px;
    flex:0 0 242px;
    background:#fff;
    border-right:1px solid var(--wa-line);
    display:flex;
    flex-direction:column;
  }
  .wa-brand{
    display:flex;
    align-items:center;
    gap:11px;
    padding:23px 19px 21px;
    border-bottom:1px solid #f0f2f3;
  }
  .wa-brand-mark{
    width:38px;
    height:38px;
    border-radius:13px;
    background:var(--wa-green);
    color:#fff;
    display:grid;
    place-items:center;
    font-size:12px;
    font-weight:800;
    letter-spacing:.04em;
  }
  .wa-brand strong{
    display:block;
    font-size:15px;
    color:#192f36;
  }
  .wa-brand small{
    display:block;
    color:#809096;
    font-size:10px;
    margin-top:2px;
    letter-spacing:.06em;
  }
  .wa-side-scroll{
    padding:13px 11px;
    flex:1;
    overflow:auto;
  }
  .wa-nav,.wa-subnav{
    display:flex;
    align-items:center;
    gap:11px;
    color:#506169;
    text-decoration:none!important;
    border-radius:9px;
    padding:10px 12px;
    margin:2px 0;
    font-size:12px;
    font-weight:600;
    transition:.15s;
  }
  .wa-nav span{
    width:17px;
    text-align:center;
    font-size:16px;
    color:#789096;
  }
  .wa-nav:hover,.wa-subnav:hover{
    background:#f4f8f7;
    color:var(--wa-green-dark);
  }
  .wa-nav.active,.wa-subnav.active{
    background:#e8f6ef;
    color:#087b63;
  }
  .wa-nav.active span{
    color:#087b63;
  }
  .wa-nav-group-label{
    color:#9aabad;
    font-size:9px;
    letter-spacing:.14em;
    font-weight:800;
    margin:22px 12px 8px;
  }
  .wa-nav-parent{
    padding:8px 12px 2px;
    font-size:11px;
    font-weight:800;
    color:#77868b;
  }
  .wa-subnav{
    margin-left:12px;
    padding:9px 10px;
    font-size:11px;
    border-left:2px solid #e8eeee;
    border-radius:0 8px 8px 0;
  }
  .wa-side-foot{
    padding:14px 17px;
    border-top:1px solid var(--wa-line);
    font-size:10px;
    line-height:1.8;
    color:#53676b;
  }
  .wa-status-dot{
    display:inline-block;
    width:7px;
    height:7px;
    background:#1da875;
    border-radius:50%;
    margin-right:6px;
  }
  .wa-side-foot small{
    color:#96a2a5;
  }
  .wa-main{
    min-width:0;
    flex:1;
    display:flex;
    flex-direction:column;
  }
  .wa-topbar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
    background:#fff;
    border-bottom:1px solid var(--wa-line);
    padding:15px 22px;
  }
  .wa-eyebrow{
    font-size:9px;
    letter-spacing:.15em;
    color:#9aa8ac;
    font-weight:800;
    margin-bottom:4px;
  }
  .wa-top-title{
    font-size:18px;
    font-weight:800;
    color:#1f343b;
  }
  .wa-top-actions{
    display:flex;
    align-items:center;
    gap:9px;
    flex-wrap:wrap;
  }
  .wa-top-actions label{
    font-size:10px;
    color:#728389;
    font-weight:700;
  }
  .wa-branch-input{
    width:78px!important;
    min-width:0!important;
    padding:7px 8px!important;
    border:1px solid #dbe4e6!important;
    border-radius:8px!important;
    font-size:12px!important;
  }
  .wa-state-pill{
    font-size:10px;
    padding:7px 10px;
    border-radius:99px;
    background:#f1f5f5;
    color:#5b6d71;
    font-weight:800;
  }
  .wa-state-pill.paused{
    background:#fff0e8;
    color:#a8471a;
  }
  .wa-btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    padding:9px 13px;
    border-radius:9px;
    border:1px solid #d9e2e4;
    background:#fff;
    color:#41575d;
    font-size:11px;
    font-weight:800;
    cursor:pointer;
    line-height:1.2;
  }
  .wa-btn:hover{
    filter:brightness(.98);
  }
  .wa-btn-primary{
    background:var(--wa-green);
    border-color:var(--wa-green);
    color:#fff;
  }
  .wa-btn-soft{
    background:#eef8f3;
    border-color:#d4eee2;
    color:#06765e;
  }

  .wa-btn-danger{
    background:#fff5f0;
    border-color:#ffdcca;
    color:#a84522;
  }

  .wa-btn:disabled{
    opacity:.4;
    cursor:not-allowed;
  }

  .wa-body{
    padding:22px;
    flex:1;
    min-width:0;
  }

  .wa-page-head{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:15px;
    margin-bottom:18px;
  }

  .wa-page-head h2{
    font-size:17px;
    font-weight:800;
    margin:0 0 5px;
    color:#243940;
  }

  .wa-page-head p{
    font-size:11px;
    color:#7e8e93;
    margin:0;
    max-width:740px;
  }

  .wa-card{
    background:#fff;
    border:1px solid #e6ebed;
    border-radius:13px;
    padding:18px;
    margin-bottom:15px;
    box-shadow:0 2px 8px rgba(18,48,55,.025);
  }

  .wa-card-title{
    font-size:12px;
    font-weight:800;
    color:#2e454c;
    margin-bottom:13px;
  }

  .wa-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:13px;
  }

  .wa-grid-2{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:14px;
  }

  .wa-stat{
    background:#fff;
    border:1px solid #e5ebed;
    border-radius:13px;
    padding:16px;
    min-width:0;
  }

  .wa-stat-label{
    color:#809096;
    font-size:10px;
    font-weight:700;
    margin-bottom:9px;
  }

  .wa-stat-value{
    font-size:24px;
    font-weight:800;
    color:#20363e;
  }

  .wa-stat-note{
    font-size:10px;
    color:#98a4a7;
    margin-top:5px;
  }
  .wa-field{
    margin-bottom:13px;
  }

  .wa-field label{
    display:block;
    font-size:10px;
    font-weight:800;
    color:#62757a;
    margin-bottom:6px;
  }

  .wa-field input,
  .wa-field select,
  .wa-field textarea,
  .wa-search{
    width:100%;
    border:1px solid #dfe7e9;
    border-radius:8px;
    padding:10px 11px;
    font:inherit;
    font-size:11px;
    color:#253e45;
    background:#fff;
  }

  .wa-field textarea{
    min-height:90px;
    resize:vertical;
  }

  .wa-field small{
    display:block;
    color:#8d9a9e;
    font-size:9px;
    margin-top:5px;
    line-height:1.6;
  }

  .wa-row{
    display:flex;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
  }

  .wa-table-wrap{
    width:100%;
    overflow:auto;
  }

  .wa-table{
    width:100%;
    border-collapse:collapse;
    font-size:11px;
  }

  .wa-table th{
    text-align:left;
    background:#f7f9fa;
    color:#819197;
    font-size:9px;
    text-transform:uppercase;
    letter-spacing:.05em;
    padding:11px 10px;
    white-space:nowrap;
  }

  .wa-table td{
    padding:11px 10px;
    border-bottom:1px solid #eff2f3;
    color:#53676d;
    vertical-align:middle;
  }

  .wa-table td strong{
    color:#273e45;
  }

  .wa-muted{
    color:#89979b;
  }

  .wa-badge{
    display:inline-block;
    padding:4px 7px;
    border-radius:99px;
    font-size:9px;
    font-weight:800;
    background:#eef2f3;
    color:#62757a;
  }

  .wa-badge.ok{
    background:#e7f7ee;
    color:#087753;
  }

  .wa-badge.warn{
    background:#fff4de;
    color:#a56700;
  }

  .wa-badge.bad{
    background:#ffeded;
    color:#b42318;
  }

  .wa-empty{
    padding:27px;
    text-align:center;
    color:#90a0a4;
    font-size:11px;
  }

  .wa-inline-note{
    border:1px solid #ddeae5;
    background:#f5fbf8;
    border-radius:9px;
    padding:12px 14px;
    color:#527168;
    font-size:10px;
    line-height:1.7;
  }

  .wa-inline-warning{
    border-color:#f3dfc9;
    background:#fff9f2;
    color:#91673a;
  }

  .wa-toggle{
    display:flex;
    align-items:center;
    gap:8px;
    font-size:11px;
    color:#52696e;
  }

  .wa-toggle input{
    accent-color:var(--wa-green);
  }

  .wa-toast{
    position:fixed;
    bottom:22px;
    right:24px;
    z-index:99999;
    display:none;
    max-width:440px;
    background:#193b3d;
    color:#fff;
    padding:13px 17px;
    border-radius:10px;
    font-size:11px;
    box-shadow:0 10px 30px #1233;
  }

  .wa-chat-shell{
    display:grid;
    grid-template-columns:minmax(230px,31%) minmax(0,1fr);
    height:min(690px,calc(100vh - 225px));
    min-height:480px;
    border:1px solid #e1e8ea;
    border-radius:13px;
    overflow:hidden;
    background:#fff;
  }

  .wa-chat-left{
    border-right:1px solid var(--wa-line);
    display:flex;
    flex-direction:column;
    min-width:0;
  }

  .wa-chat-listhead{
    padding:14px;
    border-bottom:1px solid #edf0f1;
  }

  .wa-chat-contact-list{
    overflow:auto;
    flex:1;
  }

  .wa-chat-contact{
    display:flex;
    gap:10px;
    align-items:center;
    padding:13px;
    border-bottom:1px solid #f0f2f3;
    cursor:pointer;
  }

  .wa-chat-contact:hover,
  .wa-chat-contact.selected{
    background:#f1f8f5;
  }

  .wa-avatar{
    width:36px;
    height:36px;
    flex:0 0 36px;
    display:grid;
    place-items:center;
    border-radius:50%;
    background:#dfeee7;
    color:#087b63;
    font-weight:800;
    font-size:12px;
  }

  .wa-contact-meta{
    min-width:0;
    flex:1;
  }

  .wa-contact-meta strong{
    display:block;
    color:#2b4249;
    font-size:11px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }

  .wa-contact-meta small{
    display:block;
    color:#8b999d;
    font-size:9px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    margin-top:4px;
  }

  .wa-chat-window{
    display:flex;
    flex-direction:column;
    min-width:0;
    background:#f4f7f7;
  }

  .wa-chat-window-head{
    padding:13px 16px;
    background:#fff;
    border-bottom:1px solid #e6edef;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:10px;
  }
  .wa-chat-window-head strong{
    display:block;
    color:#2d444a;
    font-size:12px;
  }
  .wa-chat-window-head small{
    color:#7e9094;
    font-size:9px;
  }

  .wa-message-list{
    padding:18px;
    overflow:auto;
    flex:1;
    background-color:#f5f8f7;
    background-image:radial-gradient(#e1e9e5 .7px,transparent .7px);
    background-size:14px 14px;
  }

  .wa-message-row{
    display:flex;
    margin:8px 0;
  }

  .wa-message-row.outbound{
    justify-content:flex-end;
  }

  .wa-message-bubble{
    max-width:min(75%,520px);
    background:#fff;
    border:1px solid #e6ece8;
    border-radius:11px 11px 11px 3px;
    padding:9px 11px;
    color:#3f565c;
    font-size:11px;
    line-height:1.6;
    white-space:pre-wrap;
    overflow-wrap:anywhere;
    box-shadow:0 1px 2px #1931;
  }

  .wa-message-row.outbound .wa-message-bubble{
    background:#dff5e7;
    border-color:#d5eee0;
    border-radius:11px 11px 3px 11px;
  }

  .wa-message-status{
    display:block;
    text-align:right;
    font-size:8px;
    color:#8fa19b;
    margin-top:3px;
  }
  .wa-chat-compose{
    padding:12px;
    background:#fff;
    border-top:1px solid #e1e9e7;
    display:flex;
    gap:8px;
    align-items:flex-end;
  }

  .wa-chat-compose textarea{
    flex:1;
    min-height:39px;
    max-height:120px;
    border:1px solid #dfe8e5;
    border-radius:10px;
    padding:10px 12px;
    font-size:11px;
    resize:vertical;
  }

  .wa-window-closed{
    padding:9px 14px;
    background:#fff2dc;
    color:#855e24;
    font-size:10px;
    border-top:1px solid #f2e3c8;
  }

  .wa-feature-disabled{
    padding:28px;
    background:#fff;
    border:1px dashed #d9e2e3;
    border-radius:13px;
    text-align:center;
    color:#75878c;
    font-size:12px;
  }

  .wa-check-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:12px;
  }
  .wa-check-card{
    border:1px solid #e5ebed;
    border-radius:9px;
    padding:12px;
  }

  .wa-check-card strong{
    font-size:11px;
    color:#43585e;
    display:block;
    margin-bottom:5px;
  }

  .wa-check-card small{
    font-size:9px;
    color:#8a999e;
    display:block;
    line-height:1.6;
  }

  .wa-code{
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    background:#f5f7f8;
    border-radius:5px;
    padding:2px 5px;
    font-size:10px;
    color:#475e65;
  }

  @media(max-width:1150px){
    .wa-sidebar{
      width:200px;
      flex-basis:200px;
    }

    .wa-grid{
      grid-template-columns:repeat(2,minmax(0,1fr));
    }
    .wa-topbar{
      align-items:flex-start;
      flex-direction:column;
    }
    .wa-top-actions{
      width:100%;
    }

  }
  @media(max-width:760px){
    .wa-app{
      display:block;
      overflow:visible;
    }
    .wa-sidebar{
      width:100%;
      border-right:0;
      border-bottom:1px solid var(--wa-line);
    }
    .wa-brand{
      padding:14px;
    }
    .wa-side-scroll{
      display:flex;
      flex-wrap:wrap;
      padding:8px;
    }
    .wa-nav,.wa-subnav{
      margin:3px;
      padding:8px 10px;
    }
    .wa-nav-group-label,.wa-nav-parent,.wa-side-foot{
      display:none;
    }
    .wa-subnav{
      border-left:0;
      margin-left:0;
    }
    .wa-body{
      padding:12px;
    }
    .wa-chat-shell{
      grid-template-columns:1fr;
      height:auto;
      min-height:600px;
    }
    .wa-chat-left{
      max-height:240px;
    }
    .wa-chat-window{
      min-height:430px;
    }
    .wa-grid-2,.wa-check-grid{
      grid-template-columns:1fr;
    }
    .wa-page-head{
      flex-direction:column;
    }
    .wa-topbar{
      padding:13px;
    }
    .wa-chat-window-head{
      align-items:flex-start;
    }
    .wa-message-bubble{
      max-width:92%;
    }
  }
</style>



<script>
function initializeWhatsAppCore() {
  'use strict';

  var $ = window.jQuery;

  var root = document.getElementById('waApp');

  window.WA = window.WA || {};

  window.WA.branch = function () {
    return parseInt(
      $('#waBranchId').val() || root.dataset.defaultBranch || '1',
      10
    );
  };

  window.WA.url = function (path) {
    return `/wa-management/api${path}`;
  };

  // Fetch-backed request helper. Keep the existing done/fail/always interface
  // so the page's current event handlers do not need to change.
  window.WA.request = function (url, options) {
    var callbacks = {
      done: [],
      fail: [],
      always: []
    };
    var state = 'pending';
    var settledValue;
    var request;

    function invoke(callbackList, value) {
      callbackList.slice().forEach(function (callback) {
        callback(value);
      });
    }

    request = {
      done: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state === 'resolved') {
          callback(settledValue);
        } else if (state === 'pending') {
          callbacks.done.push(callback);
        }

        return request;
      },
      fail: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state === 'rejected') {
          callback(settledValue);
        } else if (state === 'pending') {
          callbacks.fail.push(callback);
        }

        return request;
      },
      always: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state !== 'pending') {
          callback(settledValue);
        } else {
          callbacks.always.push(callback);
        }

        return request;
      }
    };

    Promise.resolve()
      .then(function () {
        return fetch(url, options);
      })
      .then(async function (response) {
        var responseData = null;

        if (response.status !== 204) {
          try {
            responseData = await response.json();
          } catch (error) {
            if (response.ok) {
              throw error;
            }
          }
        }

        if (!response.ok) {
          var requestError = new Error(
            (responseData && responseData.message) ||
              `Request failed with status ${response.status}.`
          );

          requestError.responseJSON = responseData;
          requestError.status = response.status;
          throw requestError;
        }

        return responseData;
      })
      .then(
        function (responseData) {
          state = 'resolved';
          settledValue = responseData;
          invoke(callbacks.done, responseData);
          invoke(callbacks.always, responseData);
        },
        function (error) {
          state = 'rejected';
          settledValue = error;
          invoke(callbacks.fail, error);
          invoke(callbacks.always, error);
        }
      );

    return request;
  };

  window.WA.api = function (path, method, data) {
    data = data || {};

    var requestMethod = (method || 'GET').toUpperCase();

    if (requestMethod !== 'GET') {
      data._token =
        $('meta[name="csrf-token"]').attr('content') ||
        $('input[name="_token"]').val();
    }

    if (typeof data.branch_id === 'undefined') {
      data.branch_id = window.WA.branch();
    }

    var requestUrl = window.WA.url(path);
    var requestOptions = {
      method: requestMethod,
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') || ''
      }
    };

    if (requestMethod === 'GET') {
      var queryString = new URLSearchParams(data).toString();

      if (queryString) {
        requestUrl = `${requestUrl}${requestUrl.indexOf('?') === -1 ? '?' : '&'}${queryString}`;
      }
    } else {
      requestOptions.headers['Content-Type'] =
        'application/x-www-form-urlencoded; charset=UTF-8';
      requestOptions.body = new URLSearchParams(data).toString();
    }

    return window.WA.request(requestUrl, requestOptions);
  };

  window.WA.esc = function (value) {
    return $('<div>').text(value == null ? '' : String(value)).html();
  };

  window.WA.toast = function (message, bad) {
    var element = $('#waToast');

    element
      .stop(true, true)
      .text(message || 'Done')
      .css('background', bad ? '#812c25' : '#193b3d')
      .fadeIn(120);

    setTimeout(function () {
      element.fadeOut(250);
    }, 4200);
  };

  window.WA.status = function (status) {
    status = status || {};

    $('#waGlobalState')
      .text(
        status.global_kill_switch
          ? 'All sending paused'
          : status.profile_enabled
            ? 'Sending enabled'
            : 'Shared profile paused'
      )
      .toggleClass(
        'paused',
        !!status.global_kill_switch || !status.profile_enabled
      );

    $('#waGlobalKill')
      .text(
        status.global_kill_switch
          ? 'Resume global sending'
          : 'Pause all sending'
      )
      .toggleClass('wa-btn-danger', !status.global_kill_switch)
      .toggleClass('wa-btn-soft', !!status.global_kill_switch)
      .data('enabled', !status.global_kill_switch);
  };

  function refreshHeader() {
    window.WA.api('/overview', 'GET', {})
      .done(function (response) {
        if (response && response.ok) {
          window.WA.status(response.data);
        }
      })
      .fail(function () {
        $('#waGlobalState').text('Status unavailable');
      });
  }

  if (
    !(
      root.dataset.section === 'chat' &&
      ['lead', 'customer'].indexOf(root.dataset.kind) >= 0
    )
  ) {
    $('#waBranchControl').hide();
  }

  $('#waBranchId').on('change', function () {
    var url = new URL(window.location.href);

    url.searchParams.set('branch_id', window.WA.branch());
    window.location.href = url.toString();
  });

  $('#waGlobalKill').on('click', function () {
    var button = $(this);

    button.prop('disabled', true);

    window.WA.api('/kill-switch', 'POST', {
      enabled: button.data('enabled')
    })
      .done(function (response) {
        window.WA.toast(response.message);
        refreshHeader();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Unable to change global switch.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  window.WA.api('/features', 'GET', {})
    .done(function (response) {
      if (!response || !response.data) {
        return;
      }

      Object.keys(response.data.features || {}).forEach(function (key) {
        if (!response.data.features[key]) {
          $(`[data-wa-feature="${key}"]`).hide();
        }
      });
    });

  refreshHeader();
}

initializeWhatsAppCore();
</script>

<!-- Pusher Channels client used by the WhatsApp private realtime channel. -->
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>

<!-- chat -->
<script>
function initializeWhatsAppChat() {
  'use strict';

  var $ = window.jQuery;

  var kind = @json($kind);
  var selected = null;
  var open = false;
  var allContacts = [];

  var emojiGroups = {
    'Smileys': ['😀','😃','😄','😁','😆','😅','😂','🤣','🥲','☺️','😊','😇','🙂','🙃','😉','😌','😍','🥰','😘','😗','😙','😚','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🫢','🫣','🤫','🤔','🫡','🤐','🤨','😐','😑','😶','🫥','😏','😒','🙄','😬','🤥','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🥵','🥶','🥴','😵','🤯','🥳','🥸','😎','🤓','🧐','😕','🫤','😟','🙁','☹️','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','🤖'],
    'People & gestures': ['👋','🤚','🖐️','✋','🖖','🫱','🫲','🫳','🫴','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','👈','👉','👆','👇','☝️','🫵','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁️','👅','👄','💋'],
    'Hearts & symbols': ['❤️','🧡','💛','💚','💙','🩵','💜','🖤','🩶','🤍','🤎','💔','❤️‍🔥','❤️‍🩹','💕','💞','💓','💗','💖','💘','💝','💟','❣️','💌','💤','💢','💥','💫','💦','💨','🕳️','💬','🗨️','🗯️','💭','🔥','✨','⭐','🌟','💯','✅','☑️','❌','❎','⚠️','🚫','🔔','🔕','🎵','🎶'],
    'Nature': ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐻‍❄️','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🙈','🙉','🙊','🐔','🐧','🐦','🐤','🦆','🦉','🦇','🐺','🐗','🐴','🦄','🐝','🪱','🦋','🐌','🐞','🐜','🪲','🕷️','🦂','🐢','🐍','🦎','🐙','🦑','🦐','🦀','🐠','🐟','🐬','🐳','🦈','🐊','🐅','🐆','🦓','🦍','🦧','🐘','🦛','🦒','🦘','🐄','🐎','🐑','🐐','🦌','🐕','🐈','🐓','🦃','🦚','🦜','🦢','🦩','🌵','🌲','🌳','🌴','🌱','🌿','☘️','🍀','🍁','🍂','🍃','🌷','🌹','🌻','🌼','🌸','💐','🌎','🌈','☀️','🌤️','⛅','🌧️','⛈️','❄️','☃️','🌊'],
    'Food & drink': ['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒','🍑','🥭','🍍','🥥','🥝','🍅','🍆','🥑','🥦','🥬','🥒','🌶️','🫑','🌽','🥕','🫒','🧄','🧅','🥔','🍠','🥐','🥯','🍞','🥖','🥨','🧀','🥚','🍳','🧈','🥞','🧇','🥓','🥩','🍗','🍖','🌭','🍔','🍟','🍕','🫓','🥪','🥙','🧆','🌮','🌯','🫔','🥗','🥘','🍲','🍛','🍜','🍝','🍣','🍱','🥟','🍤','🍙','🍚','🍘','🍥','🥠','🍢','🍡','🍧','🍨','🍦','🥧','🧁','🍰','🎂','🍮','🍭','🍬','🍫','🍿','🍩','🍪','☕','🫖','🍵','🥤','🧋','🧃','🥛','🍺','🍻','🥂','🍷','🥃','🍸','🍹'],
    'Travel & places': ['🚗','🚕','🚙','🚌','🚎','🏎️','🚓','🚑','🚒','🚐','🛻','🚚','🚛','🚜','🛵','🏍️','🚲','🛴','🚏','🛣️','🛤️','⛽','🚨','🚥','🚦','✈️','🛫','🛬','🛩️','🚁','🚀','🛸','🚢','⛵','🚤','🛥️','🛟','⚓','🗺️','🗽','🗼','🏰','🏯','🏟️','🎡','🎢','🎠','⛲','⛱️','🏖️','🏝️','🏜️','🌋','⛰️','🏔️','🗻','🏕️','🏠','🏡','🏢','🏬','🏥','🏦','🏨','🏫','🏭','🏛️','⛪','🕌','🛕','🕍','⛩️','🕋','🌆','🌇','🌃','🌉','🌌'],
    'Activities & objects': ['⚽','🏀','🏈','⚾','🥎','🎾','🏐','🏉','🥏','🎱','🪀','🏓','🏸','🏒','🏑','🥍','🏏','🪃','🥅','⛳','🪁','🏹','🎣','🤿','🥊','🥋','🎽','🛹','🛼','🛷','⛸️','🥌','🎿','⛷️','🏂','🏋️','🤼','🤸','⛹️','🤺','🏇','🧘','🏄','🏊','🚣','🧗','🚵','🚴','🎪','🎭','🎨','🎬','🎤','🎧','🎼','🎹','🥁','🪘','🎷','🎺','🪗','🎸','🪕','🎻','🎲','♟️','🎯','🎳','🎮','🕹️','🎰','🧩','🪄','🎁','🎈','🎉','🎊','🎀','🏆','🥇','🥈','🥉','🏅','🎖️','📱','💻','⌨️','🖥️','🖨️','🖱️','🕹️','💽','💾','💿','📷','📸','📹','🎥','📞','☎️','📟','📠','🔋','🪫','🔌','💡','🔦','🕯️','🧯','🛢️','💸','💵','💳','🧾','💎','🔧','🔨','⚙️','🧰','🪛','🪜','🔒','🔑','🗝️','🚪','🪑','🛏️','🛋️','🚿','🛁','🧴','🧻','🧼','🪥','🧹','🧺','🧸','🪅','📚','📖','📝','✏️','🖊️','📎','📌','📍','✂️','📁','📂','🗂️','📅','🗓️','📆','⏰','⌚','⏳','⌛','📦','📫','📮','📧','✉️','📨','📩','📤','📥']
  };
  var emojiSearchIndex = Object.keys(emojiGroups).reduce(function (all, group) {
    emojiGroups[group].forEach(function (emoji) { all.push({ group: group, emoji: emoji }); });
    return all;
  }, []);

  var esc = function (value) {
    return $('<div>').text(value == null ? '' : String(value)).html();
  };

  function contactHtml(contact) {
    var phone = contact.phone_e164 || '';
    var name = contact.display_name || phone;
    var preview = contact.last_message_preview || 'Open conversation';
    var isSelected = selected && selected.phone_e164 === phone;
    var sessionLabel = contact.session_open ? ' · 24h open' : '';

    return `
      <div
        class="wa-chat-contact ${isSelected ? 'selected' : ''}"
        data-phone="${esc(phone)}"
        data-name="${esc(name)}"
      >
        <div class="wa-avatar">${esc((name.trim().charAt(0) || '?').toUpperCase())}</div>
        <div class="wa-contact-meta">
          <strong>${esc(name)}</strong>
          <small>${esc(preview)}</small>
          <small>${esc(phone)}${sessionLabel}</small>
        </div>
      </div>
    `;
  }

  function renderContacts(items) {
    allContacts = items || [];

    $('#waChatCount').text(`${allContacts.length} contacts`);
    $('#waChatContacts').html(
      allContacts.length
        ? allContacts.map(contactHtml).join('')
        : '<div class="wa-empty">No contacts found. Search the branch contacts or add a new number from Common Chat.</div>'
    );
  }

  function loadContacts() {
    window.WA.api('/conversations', 'GET', {
      kind: kind,
      q: $('#waChatSearch').val() || ''
    })
      .done(function (response) {
        renderContacts((response.data || {}).conversations || []);
      })
      .fail(function (xhr) {
        $('#waChatContacts').html(
          '<div class="wa-empty">Unable to load contacts.</div>'
        );
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Conversation list failed.',
          true
        );
      });
  }

  function messageMedia(message) {
    if (!message.media_id) {
      return '';
    }

    var url = `/wa-management/api/media/${encodeURIComponent(message.id)}?kind=${encodeURIComponent(kind)}&branch_id=${encodeURIComponent(window.WA.branch())}`;
    var type = (message.message_type || '').toLowerCase();
    var filename = esc(message.media_filename || 'Open attachment');

    if (type === 'image' || type === 'sticker') {
      return `
        <a href="${url}" target="_blank" rel="noopener noreferrer">
          <img
            class="wa-message-media"
            src="${url}"
            loading="lazy"
            alt="WhatsApp image"
          >
        </a>
      `;
    }

    if (type === 'video') {
      return `
        <video
          class="wa-message-media video"
          controls
          preload="metadata"
          src="${url}"
        ></video>
      `;
    }

    if (type === 'audio') {
      return `
        <audio
          class="wa-message-media audio"
          controls
          preload="none"
          src="${url}"
        ></audio>
      `;
    }

    return `
      <a
        class="wa-message-file"
        href="${url}"
        target="_blank"
        rel="noopener noreferrer"
      >
        📄 ${filename} · Open attachment
      </a>
    `;
  }

  function messageHtml(message) {
    var isOutbound = message.direction === 'outbound';
    var messageId = message.meta_message_id || '';
    var media = messageMedia(message);
    var body = message.body || '';

    if (media && /^\[(Image|Video|Audio|Document|Sticker) received\]$/i.test(body)) {
      body = '';
    }

    var bodyHtml = body ? `<div>${esc(body)}</div>` : '';
    var reactionHtml = messageId.indexOf('wamid.') === 0
      ? `
          <div class="wa-message-actions">
            <button
              class="wa-reaction-button"
              data-mid="${esc(messageId)}"
              title="React"
            >
              ☺ React
            </button>
          </div>
        `
      : '';

    return `
      <div
        class="wa-message-row ${isOutbound ? 'outbound' : 'inbound'}"
        data-id="${Number(message.id || 0)}"
      >
        <div class="wa-message-bubble">
          ${media}
          ${bodyHtml}
          <span class="wa-message-status">
            ${esc(message.status || '')} · ${esc(message.created_at || message.sent_at || '')}
          </span>
          ${reactionHtml}
        </div>
      </div>
    `;
  }

  function renderMessages(data) {
    var rows = data.messages || [];

    open = !!data.session_open;

    if (!selected) {
      return;
    }

    $('#waChatHeading').text(
      (data.contact && data.contact.display_name) ||
        selected.display_name ||
        selected.phone_e164
    );
    $('#waChatSubheading').text(
      `${selected.phone_e164} · ${open ? '24-hour service window open' : '24-hour service window closed'}`
    );

    var queryString = `?to=${encodeURIComponent(selected.phone_e164)}&kind=${encodeURIComponent(kind)}&branch_id=${encodeURIComponent(window.WA.branch())}`;

    $('#waChatTemplateLink, #waTopTemplateLink').attr(
      'href',
      `/wa-management/templates${queryString}`
    );

    $('#waWindowWarning')
      .toggle(!open)
      .text(
        open
          ? ''
          : [
              'The customer-service window is closed. Send an approved template to start/reopen the conversation;',
              'media, text, reactions and interactive sends are blocked until the recipient messages again.'
            ].join(' ')
      );

    // Keep the composer on screen at all times. Enforce Meta's 24-hour rule by
    // disabling free-form controls only when the service window is actually closed.
    $('#waChatComposer').css({ display: 'flex', visibility: 'visible' });
    $('#waComposerPolicy').text(open
      ? 'Customer-service window open · You can send free-form text, media, location, contact cards and supported interactive messages.'
      : 'Customer-service window closed · Free-form text and media are unavailable. Use an approved template to initiate/restart the conversation.');
    $('#waChatText, #waChatSend, #waAttachButton, #waLocationButton, #waContactCardButton, #waInteractiveButton, #waFlowToggle').prop('disabled', !open);
    $('#waEmojiToggle').prop('disabled', !open);
    $('#waChatText').attr('placeholder', open ? 'Type a message' : 'Use an approved template while the 24-hour window is closed');

    $('#waMessageList').html(
      rows.length
        ? rows.map(messageHtml).join('')
        : '<div class="wa-empty">No history stored yet. Start from an approved template or wait for the contact to message your WhatsApp number.</div>'
    );

    var messageList = $('#waMessageList')[0];
    messageList.scrollTop = messageList.scrollHeight;

    var hasUnreadInbound = rows.some(function (message) {
      return (
        message.direction === 'inbound' &&
        message.status === 'received' &&
        message.meta_message_id
      );
    });

    if (hasUnreadInbound) {
      window.WA.api(
        `/conversations/${encodeURIComponent(selected.phone_e164)}/read`,
        'POST',
        { kind: kind }
      ).done(function () {
        window.setTimeout(function () {
          window.WA.api(
            `/conversations/${encodeURIComponent(selected.phone_e164)}/messages`,
            'GET',
            { kind: kind }
          ).done(function (response) {
            if (selected && response.data) {
              renderMessages(response.data);
            }
          });
        }, 300);
      });
    }
  }

  function openChat(phone, name, contactId) {
    var selectedPhone = String(phone || '').trim();
    if (!selectedPhone) return Promise.reject(new Error('Contact phone number is missing.'));

    selected = {
      phone_e164: selectedPhone,
      display_name: name || selectedPhone,
      contact_id: contactId || null
    };
    open = false;
    renderContacts(allContacts);
    $('#waChatHeading').text(selected.display_name);
    $('#waChatSubheading').text(`${selected.phone_e164} · loading conversation…`);
    $('#waMessageList').html('<div class="wa-empty">Loading messages…</div>');
    $('#waChatComposer').css({ display: 'flex', visibility: 'visible' });
    $('#waChatText').prop('disabled', true).val('');
    $('#waChatSend, #waAttachButton, #waLocationButton, #waContactCardButton, #waInteractiveButton, #waFlowToggle, #waEmojiToggle').prop('disabled', true);
    $('#waComposerPolicy').text('Loading the conversation and checking the 24-hour customer-service window…');

    var chatUrl = `/wa-management/api/conversations/${encodeURIComponent(selectedPhone)}/messages?kind=${encodeURIComponent(kind)}&branch_id=${encodeURIComponent(window.WA.branch())}&_=${Date.now()}`;
    return fetch(chatUrl, {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      }
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (payload) {
        if (!response.ok || payload.ok === false) {
          var error = new Error(payload.message || `Conversation request failed (${response.status}).`);
          error.responseJSON = payload;
          throw error;
        }
        return payload;
      });
    }).then(function (payload) {
      renderMessages(payload.data || payload || {});
      if (open) $('#waChatText').trigger('focus');
      return payload;
    }).catch(function (error) {
      $('#waMessageList').html('<div class="wa-empty">Conversation could not be opened. Refresh the contact list and try again.</div>');
      $('#waComposerPolicy').text('Conversation unavailable. Check your session, branch access and WhatsApp configuration.');
      window.WA.toast((error.responseJSON && error.responseJSON.message) || error.message || 'Conversation failed.', true);
      return null;
    });
  }

  // Existing click handlers and external code may still call openContact(contact).
  function openContact(contact) {
    return openChat(contact.phone_e164, contact.display_name || contact.phone_e164, contact.contact_id || null);
  }
  window.openWhatsAppChat = openChat;

  $('#waChatContacts').on('click', '.wa-chat-contact', function () {
    openContact({
      phone_e164: $(this).data('phone'),
      display_name: $(this).data('name')
    });
  });

  function refreshCurrent() {
    loadContacts();

    if (selected) {
      window.WA.api(
        `/conversations/${encodeURIComponent(selected.phone_e164)}/messages`,
        'GET',
        { kind: kind }
      ).done(function (response) {
        if (selected && response && response.data) {
          renderMessages(response.data);
        }
      });
    }
  }

  $('#waChatSearch').on('keydown', function (event) {
    if (event.key === 'Enter') {
      loadContacts();
    }
  });

  $('#waChatRefresh').on('click', refreshCurrent);

  $('#waChatSend').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var text = $.trim($('#waChatText').val());

    if (!text) {
      return;
    }

    var button = $(this);
    button.prop('disabled', true);
    var csrfToken = $('meta[name="csrf-token"]').attr('content') || '';
    var sendUrl = `/wa-management/api/send/text`;

    fetch(sendUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': csrfToken
      },
      body: new URLSearchParams({
        to: selected.phone_e164,
        text: text,
        kind: kind,
        branch_id: String(window.WA.branch()),
        _token: csrfToken
      })
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (payload) {
        if (!response.ok || payload.ok === false) {
          var error = new Error(payload.message || `Message request failed (${response.status}).`);
          error.responseJSON = payload;
          throw error;
        }
        return payload;
      });
    }).then(function () {
      $('#waChatText').val('');
      window.WA.toast('Message queued. Delivery status will update from Meta webhooks.');
      refreshCurrent();
    }).catch(function (error) {
      window.WA.toast((error.responseJSON && error.responseJSON.message) || error.message || 'Message blocked. Check the service window and opt-out status.', true);
    }).finally(function () {
      button.prop('disabled', !open);
    });
  });

  $('#waChatText').on('keydown', function (event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      $('#waChatSend').click();
    }
  });

  $('#waNewContactToggle').on('click', function () {
    $('#waNewContactForm').slideToggle(120);
  });

  $('#waNewContactCancel').on('click', function () {
    $('#waNewContactForm').slideUp(120);
  });

  $('#waNewContactSave').on('click', function () {
    var name = $.trim($('#waNewContactName').val());
    var phone = $.trim($('#waNewContactPhone').val());

    if (!phone) {
      window.WA.toast('Enter an international phone number.', true);
      return;
    }

    var button = $(this);
    button.prop('disabled', true);

    window.WA.api('/contacts/create', 'POST', {
      phone: phone,
      display_name: name,
      kind: 'common'
    })
      .done(function (response) {
        var contact = (response.data || {}).contact || {};

        if (kind !== 'common') {
          var url = `/wa-management/chats/common?new_contact=${encodeURIComponent(contact.phone_e164 || phone)}&display_name=${encodeURIComponent(contact.display_name || name)}`;
          window.location.href = url;
          return;
        }

        $('#waNewContactName, #waNewContactPhone').val('');
        $('#waNewContactForm').slideUp(120);
        $('#waChatSearch').val('');
        loadContacts();

        selected = {
          phone_e164: contact.phone_e164 || phone,
          display_name: contact.display_name || name || phone
        };

        window.setTimeout(function () {
          openContact(selected);
        }, 250);

        window.WA.toast(response.message || 'Contact saved.');
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Contact could not be saved.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  function renderEmojiPicker(filterText) {
    var query = String(filterText || '').toLowerCase();
    var rows = emojiSearchIndex.filter(function (item) {
      return !query || item.emoji.indexOf(query) !== -1 || item.group.toLowerCase().indexOf(query) !== -1;
    });
    var html = '';
    var lastGroup = '';
    rows.forEach(function (item) {
      if (item.group !== lastGroup) {
        lastGroup = item.group;
        html += `<div class="wa-emoji-category">${esc(lastGroup)}</div>`;
      }
      html += `<button type="button" class="wa-emoji" data-emoji="${esc(item.emoji)}" title="${esc(lastGroup)}">${item.emoji}</button>`;
    });
    $('#waEmojiList').html(html || '<div class="wa-empty">No emoji found.</div>');
  }
  renderEmojiPicker('');
  $('#waEmojiSearch').on('input', function () { renderEmojiPicker(this.value); });
  $('#waEmojiToggle').on('click', function () {
    if (!open) return;
    $('#waEmojiTray').slideToggle(100);
    $('#waEmojiSearch').val('');
    renderEmojiPicker('');
  });

  $('#waEmojiTray').on('click', '.wa-emoji', function () {
    var textarea = $('#waChatText')[0];
    var emoji = $(this).data('emoji');

    if (!textarea) {
      return;
    }

    var start = textarea.selectionStart || textarea.value.length;
    var end = textarea.selectionEnd || start;

    textarea.value = `${textarea.value.substring(0, start)}${emoji}${textarea.value.substring(end)}`;

    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
  });

  $('#waMessageList').on('click', '.wa-reaction-button', function () {
    if (!selected || !open) {
      return;
    }

    var emoji = window.prompt(
      'Enter one emoji to react with, e.g. 👍 or ❤️',
      '👍'
    );

    if (!emoji) {
      return;
    }

    window.WA.api('/send/reaction', 'POST', {
      to: selected.phone_e164,
      target_message_id: $(this).data('mid'),
      emoji: emoji,
      kind: kind
    })
      .done(function () {
        window.WA.toast('Reaction queued.');
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Reaction failed.',
          true
        );
      });
  });

  $('#waAttachButton').on('click', function () {
    if (!selected || !open) {
      window.WA.toast(
        'Attachments can be sent only inside the 24-hour service window.',
        true
      );
      return;
    }

    $('#waChatMedia').trigger('click');
  });

  $('#waChatMedia').on('change', function () {
    var file = this.files && this.files[0];

    if (!file) {
      return;
    }

    $('#waSelectedFileLabel').text(
      `${file.name} · ${Math.ceil(file.size / 1024)} KB`
    );
    $('#waMediaCaptionRow').show();
  });

  $('#waCancelMedia').on('click', function () {
    $('#waChatMedia').val('');
    $('#waMediaCaption').val('');
    $('#waSelectedFileLabel').text('');
    $('#waMediaCaptionRow').hide();
  });

  $('#waSendMedia').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var file = $('#waChatMedia')[0].files[0];

    if (!file) {
      return;
    }

    var form = new FormData();
    form.append('media', file);
    form.append('to', selected.phone_e164);
    form.append('kind', kind);
    form.append('caption', $('#waMediaCaption').val());
    form.append('_token', $('meta[name="csrf-token"]').attr('content') || '');
    form.append('branch_id', window.WA.branch());

    var button = $(this);
    button.prop('disabled', true).text('Uploading…');

    window.WA.request('/wa-management/api/send/media', {
      method: 'POST',
      credentials: 'same-origin',
      body: form,
      headers: {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') || ''
      }
    })
      .done(function () {
        window.WA.toast('Attachment queued.');
        $('#waCancelMedia').click();
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Attachment blocked or upload failed.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false).text('Send attachment');
      });
  });

  $('#waLocationButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    if (!navigator.geolocation) {
      window.WA.toast(
        'This browser does not provide location sharing.',
        true
      );
      return;
    }

    if (!window.confirm('Share your current device location with this contact?')) {
      return;
    }

    var button = $(this);
    button.prop('disabled', true);

    navigator.geolocation.getCurrentPosition(
      function (position) {
        window.WA.api('/send/location', 'POST', {
          to: selected.phone_e164,
          kind: kind,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        })
          .done(function () {
            window.WA.toast('Location queued.');
            refreshCurrent();
          })
          .fail(function (xhr) {
            window.WA.toast(
              (xhr.responseJSON && xhr.responseJSON.message) ||
                'Location could not be sent.',
              true
            );
          })
          .always(function () {
            button.prop('disabled', false);
          });
      },
      function () {
        button.prop('disabled', false);
        window.WA.toast(
          'Location access was denied or unavailable.',
          true
        );
      },
      {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });

  $('#waContactCardButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var name = window.prompt('Contact display name:', '');

    if (name === null || !name.trim()) {
      return;
    }

    var phone = window.prompt(
      'Contact phone in international format:',
      '+91'
    );

    if (phone === null || !phone.trim()) {
      return;
    }

    window.WA.api('/send/contact', 'POST', {
      to: selected.phone_e164,
      kind: kind,
      contact_name: name,
      contact_phone: phone
    })
      .done(function () {
        window.WA.toast('Contact card queued.');
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Contact card could not be sent.',
          true
        );
      });
  });

  $('#waInteractiveButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var body = window.prompt('Interactive message body text:', 'Choose an option');

    if (body === null || !body.trim()) {
      return;
    }

    var title = window.prompt('Reply button label (max 20 characters):', 'Yes');

    if (title === null || !title.trim()) {
      return;
    }

    title = title.substring(0, 20);

    var interactive = {
      type: 'button',
      body: {
        text: body.substring(0, 1024)
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: `choice_${Date.now()}`,
              title: title
            }
          }
        ]
      }
    };

    window.WA.api('/send/interactive', 'POST', {
      to: selected.phone_e164,
      kind: kind,
      interactive_json: JSON.stringify(interactive)
    })
      .done(function () {
        window.WA.toast('Interactive message queued.');
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Interactive message failed.',
          true
        );
      });
  });

  $('#waFlowToggle').on('click', function () {
    if (!selected || !open) {
      return;
    }

    $('#waFlowPanel').slideToggle(100);
  });

  $('#waCloseFlow').on('click', function () {
    $('#waFlowPanel').slideUp(100);
  });

  $('#waSendFlow').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var data = $.trim($('#waFlowData').val() || '{}');

    try {
      JSON.parse(data);
    } catch (error) {
      window.WA.toast('Initial Flow data must be valid JSON.', true);
      return;
    }

    var payload = {
      to: selected.phone_e164,
      kind: kind,
      flow_id: $('#waFlowId').val(),
      flow_token: $('#waFlowToken').val() || `eapl_${Date.now()}`,
      flow_cta: $('#waFlowCta').val(),
      body: $('#waFlowBody').val(),
      flow_action: 'navigate',
      flow_action_payload: data
    };

    window.WA.api('/send/flow', 'POST', payload)
      .done(function () {
        window.WA.toast('Flow message queued.');
        $('#waFlowPanel').slideUp(100);
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Flow could not be sent. Check published Flow ID and account support.',
          true
        );
      });
  });

  // Keep branch scoping for Lead/Customer CRM lists. API configuration,
  // templates, rules, and message history remain shared.
  var searchParams = new URLSearchParams(window.location.search);
  var newContact = searchParams.get('new_contact');
  var newName = searchParams.get('display_name');

  loadContacts();

  // Realtime chat updates use a private Laravel-authorized Pusher channel.
  // The legacy public `chat` channel remains available to the old ERP chat pages.
  function connectWhatsAppPusher() {
    var chatRoot = document.getElementById('waApp');
    if (!chatRoot || !window.Pusher || !chatRoot.dataset.pusherKey) return;
    try {
      var csrf = $('meta[name="csrf-token"]').attr('content') || '';
      var pusher = new Pusher(chatRoot.dataset.pusherKey, {
        cluster: chatRoot.dataset.pusherCluster || 'ap2',
        forceTLS: true,
        authEndpoint: chatRoot.dataset.broadcastAuth || '/broadcasting/auth',
        auth: { headers: { 'X-CSRF-TOKEN': csrf, 'X-Requested-With': 'XMLHttpRequest' } }
      });
      var channel = pusher.subscribe('private-whatsapp-management.chat');
      channel.bind('message.updated', function (eventPayload) {
        loadContacts();
        var incoming = eventPayload && eventPayload.message ? eventPayload.message : null;
        if (selected && incoming && incoming.phone_e164 === selected.phone_e164) {
          refreshCurrent();
        }
      });
      channel.bind('pusher:subscription_error', function () {
        console.warn('WhatsApp private Pusher channel could not be authorized. Check broadcasting/auth and WhatsApp admin_user_ids.');
      });
      window.WA.whatsappPusher = pusher;
    } catch (error) {
      console.warn('WhatsApp Pusher initialization failed.', error);
    }
  }
  connectWhatsAppPusher();

  if (newContact) {
    $('#waChatSearch').val(newContact);

    window.setTimeout(function () {
      openContact({
        phone_e164: newContact,
        display_name: newName || newContact
      });
    }, 350);
  }
}

initializeWhatsAppChat();
</script>

<!-- Shared Meta template-schema helpers: used by single send, Automation Rules and Bulk Campaigns. -->
<script>
function initializeWhatsAppTemplateSchemaHelpers() {
  'use strict';
  window.WA = window.WA || {};

  function schemaComponents(template) {
    if (!template) return [];
    if (Array.isArray(template.components)) return template.components;
    if (typeof template.components_json === 'string') {
      try { var parsed = JSON.parse(template.components_json); if (Array.isArray(parsed)) return parsed; } catch (e) {}
    }
    return [];
  }
  function tokens(text) {
      var result = [];
      var re = /\{\{\s*([A-Za-z_][A-Za-z0-9_]*|\d+)\s*\}\}/g;
      var match;

      while ((match = re.exec(String(text || ''))) !== null) {
          result.push(match[1]);
      }

      return result;
  }

  function named(template) { 
    return String((template && template.parameter_format) || 'POSITIONAL').toUpperCase() === 'NAMED'; 
  }
  
  function firstArray(value) { return Array.isArray(value) && Array.isArray(value[0]) ? value[0] : (Array.isArray(value) ? value : []); }
  function bodyExample(component, token, index, isNamed) {
    var ex = component.example || {};
    if (isNamed && Array.isArray(ex.body_text_named_params)) {
      var found = ex.body_text_named_params.find(function (item) { return String(item.param_name) === String(token); });
      if (found && found.example !== undefined) return `SAMPLE_${String(found.example)}`;
    }
    var values = firstArray(ex.body_text);
    if (values[index] !== undefined) return `SAMPLE_${String(values[index])}`;
    return isNamed ? `SAMPLE_${token}` : `SAMPLE_BODY_${index + 1}`;
  }
  function headerExample(component, token, index, isNamed) {
    var ex = component.example || {};
    if (isNamed && Array.isArray(ex.header_text_named_params)) {
      var found = ex.header_text_named_params.find(function (item) { return String(item.param_name) === String(token); });
      if (found && found.example !== undefined) return `SAMPLE_${String(found.example)}`;
    }
    var values = Array.isArray(ex.header_text) ? ex.header_text : [];
    if (values[index] !== undefined) return `SAMPLE_${String(values[index])}`;
    return isNamed ? `SAMPLE_${token}` : `SAMPLE_HEADER_${index + 1}`;
  }
  function textParameter(value, token, isNamed) {
    var parameter = { type: 'text', text: String(value) };
    if (isNamed && token) parameter.parameter_name = String(token);
    return parameter;
  }
  function mediaPlaceholder(format) {
    if (format === 'IMAGE') return { type: 'image', image: { link: 'https://example.com/REPLACE_WITH_PUBLIC_IMAGE.jpg' } };
    if (format === 'VIDEO') return { type: 'video', video: { link: 'https://example.com/REPLACE_WITH_PUBLIC_VIDEO.mp4' } };
    if (format === 'DOCUMENT') return { type: 'document', document: { link: 'https://example.com/REPLACE_WITH_PUBLIC_DOCUMENT.pdf', filename: 'REPLACE_WITH_REAL_FILENAME.pdf' } };
    return null;
  }
  function findTemplate(list, id) {
    return (Array.isArray(list) ? list : []).find(function (item) { return String(item.id) === String(id); }) || null;
  }
  function buildSampleComponents(template) {
    var components = schemaComponents(template), result = [], isNamed = named(template);
    components.forEach(function (component) {
      var type = String(component.type || '').toUpperCase();
      if (type === 'HEADER') {
        var format = String(component.format || '').toUpperCase();
        if (format === 'TEXT') {
          var ht = tokens(component.text || '');
          if (ht.length) {
            result.push({ type: 'header', parameters: ht.map(function (token, index) { return textParameter(headerExample(component, token, index, isNamed), token, isNamed); }) });
          }
        } else {
          var media = mediaPlaceholder(format);
          if (media) result.push({ type: 'header', parameters: [media] });
        }
      } else if (type === 'BODY') {
        var bt = tokens(component.text || '');
        if (bt.length) {
          result.push({ type: 'body', parameters: bt.map(function (token, index) { return textParameter(bodyExample(component, token, index, isNamed), token, isNamed); }) });
        }
      } else if (type === 'BUTTONS' && Array.isArray(component.buttons)) {
        component.buttons.forEach(function (button, index) {
          var buttonType = String(button.type || '').toUpperCase();
          if (buttonType === 'URL') {
            var urlTokens = tokens(button.url || '');
            if (urlTokens.length) {
              result.push({
                type: 'button', sub_type: 'url', index: index,
                parameters: urlTokens.map(function (token, pIndex) {
                  var example = Array.isArray(button.example) ? button.example[pIndex] : undefined;
                  return textParameter(example === undefined ? `SAMPLE_BUTTON_${index + 1}_${pIndex + 1}` : `SAMPLE_${String(example)}`, token, isNamed);
                })
              });
            }
          } else if (buttonType === 'COPY_CODE') {
            result.push({ type: 'button', sub_type: 'copy_code', index: index, parameters: [{ type: 'coupon_code', coupon_code: 'REPLACE_WITH_REAL_CODE' }] });
          }
          // QUICK_REPLY, PHONE_NUMBER, FLOW, OTP and fixed URL buttons carry no customer-supplied send parameter here.
        });
      }
    });
    return result;
  }
  function buildParameterMap(template) {
    var components = schemaComponents(template), result = [], isNamed = named(template);
    components.forEach(function (component) {
      var type = String(component.type || '').toUpperCase();
      if (type === 'HEADER') {
        var format = String(component.format || '').toUpperCase();
        if (format === 'TEXT') {
          var hTokens = tokens(component.text || '');
          if (hTokens.length) result.push({ type: 'header', parameters: hTokens.map(function (token, index) {
            var p = { type: 'text', source: isNamed ? token : `header_${index + 1}` };
            if (isNamed) p.parameter_name = token;
            return p;
          }) });
        } else if (['IMAGE', 'VIDEO', 'DOCUMENT'].indexOf(format) >= 0) {
          var mediaKind = format.toLowerCase();
          var mediaParam = { type: mediaKind, source: `header_${mediaKind}` };
          if (mediaKind === 'document') mediaParam.filename_source = 'header_filename';
          result.push({ type: 'header', parameters: [mediaParam] });
        }
      } else if (type === 'BODY') {
        var bTokens = tokens(component.text || '');
        if (bTokens.length) result.push({ type: 'body', parameters: bTokens.map(function (token, index) {
          var p = { type: 'text', source: isNamed ? token : `body_${index + 1}` };
          if (isNamed) p.parameter_name = token;
          return p;
        }) });
      } else if (type === 'BUTTONS' && Array.isArray(component.buttons)) {
        component.buttons.forEach(function (button, index) {
          var buttonType = String(button.type || '').toUpperCase();
          if (buttonType === 'URL') {
            var bTokens = tokens(button.url || '');
            if (bTokens.length) result.push({ type: 'button', sub_type: 'url', index: index, parameters: bTokens.map(function (token, pIndex) {
              var p = { type: 'text', source: isNamed ? token : `button_${index}_${pIndex + 1}` };
              if (isNamed) p.parameter_name = token;
              return p;
            }) });
          } else if (buttonType === 'COPY_CODE') {
            result.push({ type: 'button', sub_type: 'copy_code', index: index, parameters: [{ type: 'coupon_code', source: 'coupon_code' }] });
          }
        });
      }
    });
    return result;
  }
  function hasSampleMarkers(json) {
    return /example\.com\/REPLACE_WITH_|REPLACE_WITH_REAL_|SAMPLE_(?:BODY|HEADER|BUTTON|[A-Za-z_])/.test(String(json || ''));
  }
  window.WA.templateSchemaComponents = schemaComponents;
  window.WA.findTemplateById = findTemplate;
  window.WA.buildTemplateSampleComponents = buildSampleComponents;
  window.WA.buildTemplateParameterMap = buildParameterMap;
  window.WA.hasTemplateSampleMarkers = hasSampleMarkers;
  window.WA.populateTemplateComponents = function (target, warning, template) {
    if (!template) { window.jQuery(target).val('[]'); window.jQuery(warning).hide().text(''); return; }
    var sample = buildSampleComponents(template);
    window.jQuery(target).val(JSON.stringify(sample, null, 2));
    if (sample.length && hasSampleMarkers(JSON.stringify(sample))) {
      window.jQuery(warning).show().text('Generated from Meta schema using dummy values. Replace every SAMPLE_/REPLACE_WITH_ value and example.com URL before sending. Fixed components need no parameters.');
    } else if (sample.length) {
      window.jQuery(warning).show().text('Generated from the selected Meta template schema. Verify examples and dynamic button values before sending.');
    } else {
      window.jQuery(warning).hide().text('');
    }
  };
}

initializeWhatsAppTemplateSchemaHelpers();
</script>

<!-- templates -->
<script>
function initializeWhatsAppTemplates() {
  'use strict';

  var $ = window.jQuery;

  var all = [];

  function load() {
    window.WA.api('/templates', 'GET', {})
      .done(function (response) {
        all = (response.data || {}).templates || [];
        render();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Templates unavailable.',
          true
        );
      });
  }

  function render() {
    var query = ($.trim($('#waTemplateSearch').val() || '')).toLowerCase();
    var rows = all.filter(function (template) {
      return (
        `${template.name} ${template.language} ${template.category}`
          .toLowerCase()
          .indexOf(query) >= 0
      );
    });

    $('#waTemplateRows').html(
      rows.length
        ? rows.map(function (template) {
            var isApproved = template.approval_status === 'APPROVED';
            var isEnabled = !!template.is_enabled;
            var statusClass = isApproved ? 'ok' : 'bad';
            var disabledAttribute = isApproved ? '' : 'disabled';
            var checkedAttribute = isEnabled ? 'checked' : '';

            return `
              <tr>
                <td>
                  <strong>${window.WA.esc(template.name)}</strong><br>
                  <small class="wa-muted">ID ${window.WA.esc(template.id)}</small>
                </td>
                <td>${window.WA.esc(template.language)}</td>
                <td>${window.WA.esc(template.category)}</td>
                <td>
                  <span class="wa-badge ${statusClass}">
                    ${window.WA.esc(template.approval_status)}
                  </span>
                </td>
                <td>
                  <label class="wa-toggle">
                    <input
                      type="checkbox"
                      class="waTemplateEnable"
                      data-id="${window.WA.esc(template.id)}"
                      ${checkedAttribute}
                      ${disabledAttribute}
                    >
                    Enabled
                  </label>
                </td>
                <td>${window.WA.esc(template.last_synced_at || '—')}</td>
              </tr>
            `;
          }).join('')
        : '<tr><td colspan="6" class="wa-empty">No templates. Sync after API setup, or change the search.</td></tr>'
    );

    var approvedTemplates = all.filter(function (template) {
      return template.approval_status === 'APPROVED' && template.is_enabled;
    });

    $('#waSendTemplate').html(`
      <option value="">Choose approved template</option>
      ${approvedTemplates.map(function (template) {
        return `
          <option
            value="${window.WA.esc(template.id)}"
            data-template-name="${window.WA.esc(template.name)}"
            data-language="${window.WA.esc(template.language)}"
          >
            ${window.WA.esc(template.name)} · ${window.WA.esc(template.language)}
          </option>
        `;
      }).join('')}
    `);
  }

  $('#waTemplateSearch').on('input', render);

  $('#waSyncTemplates').on('click', function () {
    var button = $(this);

    button.prop('disabled', true).text('Syncing…');

    window.WA.api('/templates/sync', 'POST', {})
      .done(function (response) {
        window.WA.toast(response.message || 'Template sync complete.');
        load();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Template sync failed.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false).text('↻ Sync from Meta');
      });
  });

  $('#waTemplateRows').on('change', '.waTemplateEnable', function () {
    var element = $(this);

    window.WA.api('/templates/toggle', 'POST', {
      id: element.data('id'),
      enabled: element.is(':checked') ? 1 : 0
    })
      .done(function (response) {
        window.WA.toast(response.message || 'Template status saved.');
        load();
      })
      .fail(function (xhr) {
        element.prop('checked', !element.is(':checked'));
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Could not update template.',
          true
        );
      });
  });

  window.jQuery(document).on('change', '#waSendTemplate', function () {
    var option = $(this).find(':selected');
    var language = option.data('language') || 'en';
    var template = window.WA.findTemplateById(all, $(this).val());
    $('#waSendLanguage')
      .html(`<option value="${window.WA.esc(language)}">${window.WA.esc(language)}</option>`)
      .val(language);
    window.WA.populateTemplateComponents('#waSendComponents', '#waSendSampleWarning', template);
  });

  $('#waSendTemplateButton').on('click', function () {
    var button = $(this);
    var components = $.trim($('#waSendComponents').val() || '[]');

    var parsedComponents;
    try {
      parsedComponents = JSON.parse(components);
      if (!Array.isArray(parsedComponents)) throw new Error('Components must be an array.');
    } catch (error) {
      window.WA.toast('Components field must be a valid JSON array.', true);
      return;
    }
    if (window.WA.hasTemplateSampleMarkers(components)) {
      window.WA.toast('Replace all generated sample values and example.com media links before sending.', true);
      return;
    }

    var recipient = $('#waSendTo').val();
    var selectedOption = $('#waSendTemplate').find(':selected');
    var templateName = selectedOption.data('template-name');

    if (!recipient || !templateName) {
      window.WA.toast('Recipient and template are required.', true);
      return;
    }

    button.prop('disabled', true);

    window.WA.api('/send/template', 'POST', {
      to: recipient,
      template_name: templateName,
      language: $('#waSendLanguage').val(),
      components: components,
      source_type: 'admin_manual'
    })
      .done(function (response) {
        var outboxId = response.id || (response.data || {}).id || '—';
        var status = response.status || 'queued';

        $('#waSingleSendStatus').text(
          `Outbox ID ${outboxId} · ${status}`
        );
        window.WA.toast(
          'Accepted into outbox. Delivery receipts update asynchronously.'
        );
      })
      .fail(function (xhr) {
        var message =
          (xhr.responseJSON && xhr.responseJSON.message) ||
          'Template blocked. Check consent/profile/status.';

        $('#waSingleSendStatus').text(message);
        window.WA.toast(message, true);
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  load();
}

initializeWhatsAppTemplates();
</script>

<!-- setup  -->
 <script>
function initializeWhatsAppSetup() {
    'use strict';

    var $ = window.jQuery;

    var profile = null;
    var featureLabels = {
        lead_chat: [
            'Lead chat',
            'Uses the configured lead table and branch scoping.'
        ],
        customer_chat: [
            'Customer chat',
            'Optional; enable only when this ERP has the customer module.'
        ],
        common_chat: [
            'Common chat',
            'General one-to-one conversation list.'
        ],
        custom_group_chat: [
            'Custom audiences',
            'ERP saved recipient lists; not native WhatsApp groups.'
        ],
        broadcast_channel: [
            'Broadcast manager',
            'Paced template campaigns; not WhatsApp Channels publishing.'
        ],
        bulk_campaigns: [
            'Bulk campaigns',
            'Allows paced template campaigns with per-recipient consent checks.'
        ],
        calling: [
            'Calling capability',
            'Requires separate Meta calling eligibility, permissions and call flow implementation.'
        ]
    };

    function loadFeatures() {
        window.WA.api('/features', 'GET', {})
            .done(function (response) {
                var features = (response.data || {}).features || {};

                $('#waFeatureList').html(Object.keys(featureLabels).map(function (key) {
                    var label = featureLabels[key];

                    return `
                        <label class="wa-check-card">
                            <span class="wa-toggle">
                                <input
                                    type="checkbox"
                                    class="waFeature"
                                    data-key="${WA.esc(key)}"
                                    ${features[key] ? 'checked' : ''}
                                >
                                <strong>${WA.esc(label[0])}</strong>
                            </span>
                            <small>${WA.esc(label[1])}</small>
                        </label>
                    `;
                }).join(''));
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Feature settings unavailable.',
                    true
                );
            });
    }

    function loadProfile() {
        window.WA.api('/config', 'GET', {})
            .done(function (response) {
                profile = response.data || {};

                $('#waWabaId').val(profile.waba_id || '');
                $('#waPhoneNumberId').val(profile.phone_number_id || '');
                $('#waGraphVersion').val(profile.graph_api_version || 'v26.0');
                $('#waSendInterval').val(profile.min_send_interval_seconds || 10);
                $('#waProfileEnabled').prop('checked', !!profile.is_enabled);
                $('#waToggleProfile')
                    .text(profile.is_enabled ? 'Pause shared sends' : 'Resume shared sends')
                    .data('enabled', !profile.is_enabled);

                $('#waProfileStatus').html(`
                    <div class="wa-inline-note">
                        ${profile.configured ? 'Shared profile exists' : 'No shared profile saved yet'}
                        · Token: ${profile.token_saved ? 'encrypted token present' : 'not saved'}
                        · Sending: ${profile.is_enabled ? 'enabled' : 'paused'}
                    </div>
                `);
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not load profile.',
                    true
                );
            });

        loadFeatures();
    }

    $('#waSetupReload').on('click', loadProfile);

    $('#waSaveConfig').on('click', function () {
        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/config', 'POST', {
            waba_id: $('#waWabaId').val(),
            phone_number_id: $('#waPhoneNumberId').val(),
            graph_api_version: $('#waGraphVersion').val(),
            access_token: $('#waAccessToken').val(),
            is_enabled: $('#waProfileEnabled').is(':checked') ? 1 : 0,
            min_send_interval_seconds: $('#waSendInterval').val()
        })
            .done(function () {
                $('#waAccessToken').val('');
                WA.toast('Profile saved.');
                loadProfile();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Profile save failed.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waTestConfig').on('click', function () {
        var button = $(this);
        button.prop('disabled', true).text('Testing…');

        window.WA.api('/config/test', 'POST', {})
            .done(function (response) {
                var message = response.message || 'Connection success';
                $('#waProfileStatus').html(`
                    <div class="wa-inline-note">${WA.esc(message)}</div>
                `);
                WA.toast(message);
            })
            .fail(function (error) {
                var response = error.responseJSON || {};
                var message = response.message || 'Connection failed';

                $('#waProfileStatus').html(`
                    <div class="wa-inline-note wa-inline-warning">${WA.esc(message)}</div>
                `);
                WA.toast(response.message || 'Test failed.', true);
            })
            .always(function () {
                button.prop('disabled', false).text('Test credentials');
            });
    });

    $('#waToggleProfile').on('click', function () {
        var button = $(this);

        window.WA.api('/config/toggle', 'POST', {
            enabled: button.data('enabled')
        })
            .done(function (response) {
                WA.toast(response.message || 'Shared ERP setting updated.');
                loadProfile();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not update profile.',
                    true
                );
            });
    });

    $('#waSaveFeatures').on('click', function () {
        var payload = {};

        // Match jQuery's nested form encoding for the shared Fetch-backed WA.api helper.
        $('.waFeature').each(function () {
            var key = $(this).data('key');
            payload[`features[${key}]`] = $(this).is(':checked');
        });

        window.WA.api('/features', 'POST', payload)
            .done(function () {
                WA.toast('Feature switches saved. Reload to apply sidebar visibility.');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save menu switches.',
                    true
                );
            });
    });

    loadProfile();
}

initializeWhatsAppSetup();
</script>

<!-- Automation Rules -->
 <script>
function initializeWhatsAppAutomationRules() {
    'use strict';

    var $ = window.jQuery;

    var templates = [];
    var rules = [];

    function loadTemplates() {
        window.WA.api('/templates', 'GET', {})
            .done(function (response) {
                templates = ((response.data || {}).templates || []).filter(function (template) {
                    return template.approval_status === 'APPROVED' && template.is_enabled;
                });

                $('#waWorkflowTemplate').html(`
                    <option value="">Select template</option>
                    ${templates.map(function (template) {
                        return `
                            <option value="${WA.esc(template.id)}" data-template-name="${WA.esc(template.name)}" data-lang="${WA.esc(template.language)}">
                                ${WA.esc(template.name)} · ${WA.esc(template.language)}
                            </option>
                        `;
                    }).join('')}
                `);
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Templates unavailable for workflow rules.',
                    true
                );
            });
    }

    function renderRules() {
        $('#waRuleRows').html(rules.length
            ? rules.map(function (rule) {
                return `
                    <tr>
                        <td>
                            <strong>${WA.esc(rule.event_key)}</strong><br>
                            <small class="wa-muted">${WA.esc(rule.notes || '')}</small>
                        </td>
                        <td>${WA.esc(rule.template_name || '')}</td>
                        <td>${WA.esc(rule.language || '')}</td>
                        <td>
                            <span class="wa-badge ${rule.is_enabled ? 'ok' : 'warn'}">
                                ${rule.is_enabled ? 'Enabled' : 'Disabled'}
                            </span>
                        </td>
                        <td>
                            <button
                                type="button"
                                class="wa-btn waRuleToggle"
                                data-id="${WA.esc(rule.id)}"
                                data-enabled="${rule.is_enabled ? 0 : 1}"
                            >
                                ${rule.is_enabled ? 'Disable' : 'Enable'}
                            </button>
                            <button type="button" class="wa-btn waRuleEdit" data-id="${WA.esc(rule.id)}">
                                Edit
                            </button>
                        </td>
                    </tr>
                `;
            }).join('')
            : '<tr><td colspan="5" class="wa-empty">No workflow rules configured yet.</td></tr>'
        );
    }

    function loadRules() {
        window.WA.api('/workflow-rules', 'GET', {})
            .done(function (response) {
                rules = (response.data || {}).rules || [];
                renderRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Rules unavailable.',
                    true
                );
            });
    }

    $('#waWorkflowTemplate').on('change', function () {
        var option = $(this).find(':selected');
        var language = option.data('lang') || 'en';
        var template = window.WA.findTemplateById(templates, $(this).val());
        $('#waWorkflowLanguage')
            .html(`<option value="${WA.esc(language)}">${WA.esc(language)}</option>`)
            .val(language);
        if (template) {
            $('#waParameterMap').val(JSON.stringify(window.WA.buildTemplateParameterMap(template), null, 2));
            $('#waParameterMapHint').show().text('Generated from Meta schema. Check source names against your event variables. Header media uses header_image/header_video/header_document; text fields use names like body_1 or named placeholders.');
        } else {
            $('#waParameterMap').val('[]');
            $('#waParameterMapHint').hide().text('');
        }
    });

    $('#waSaveRule').on('click', function () {
        var mappingJson = $.trim($('#waParameterMap').val() || '[]');

        try {
            var mapping = JSON.parse(mappingJson);
            if (!Array.isArray(mapping)) {
                throw new Error('Parameter mapping must be an array.');
            }
        } catch (error) {
            WA.toast('Parameter mapping must be a JSON array.', true);
            return;
        }

        var payload = {
            event_key: $.trim($('#waEventKey').val()),
            template_name: $('#waWorkflowTemplate').find(':selected').data('template-name'),
            language: $('#waWorkflowLanguage').val(),
            parameter_map_json: mappingJson,
            notes: $('#waRuleNotes').val(),
            is_enabled: $('#waRuleEnabled').is(':checked') ? 1 : 0
        };

        if (!payload.event_key || !payload.template_name) {
            WA.toast('Event key and template are required.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/workflow-rules', 'POST', payload)
            .done(function (response) {
                WA.toast(response.message || 'Rule saved.');
                loadRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save workflow.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waRuleRows').on('click', '.waRuleToggle', function () {
        var button = $(this);

        window.WA.api('/workflow-rules/toggle', 'POST', {
            id: button.data('id'),
            enabled: button.data('enabled')
        })
            .done(function () {
                loadRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Update failed.',
                    true
                );
            });
    });

    $('#waRuleRows').on('click', '.waRuleEdit', function () {
        var ruleId = Number($(this).data('id'));
        var rule = rules.find(function (item) {
            return Number(item.id) === ruleId;
        });

        if (!rule) {
            return;
        }

        $('#waEventKey').val(rule.event_key);
        var matchingTemplate = templates.find(function (item) {
            return item.name === rule.template_name && item.language === rule.language;
        });
        $('#waWorkflowTemplate').val(matchingTemplate ? matchingTemplate.id : '');
        if (matchingTemplate) {
            $('#waWorkflowLanguage').html(`<option value="${WA.esc(matchingTemplate.language)}">${WA.esc(matchingTemplate.language)}</option>`).val(matchingTemplate.language);
            $('#waParameterMapHint').show().text('Loaded the saved rule. The mapping is preserved below; use the selected template schema as a reference.');
        } else {
            $('#waParameterMapHint').hide().text('');
        }
        $('#waParameterMap').val(rule.parameter_map_json || (matchingTemplate ? JSON.stringify(WA.buildTemplateParameterMap(matchingTemplate), null, 2) : '[]'));
        $('#waRuleNotes').val(rule.notes || '');
        $('#waRuleEnabled').prop('checked', !!rule.is_enabled);
    });

    $('#waWorkflowRefresh').on('click', function () {
        loadRules();
        loadTemplates();
    });

    $('#waResetRule').on('click', function () {
        $('#waEventKey, #waRuleNotes').val('');
        $('#waParameterMap').val('[]');
        $('#waParameterMapHint').hide().text('');
        $('#waWorkflowTemplate').val('');
        $('#waRuleEnabled').prop('checked', true);
    });

    loadTemplates();
    loadRules();
}

initializeWhatsAppAutomationRules();
</script>

<!-- Broadcast Script -->
 <script>
function initializeWhatsAppBroadcast() {
    'use strict';

    var $ = window.jQuery;

    window.WA.api('/campaigns', 'GET', {})
        .done(function (response) {
            var campaigns = (response.data || {}).campaigns || [];

            $('#waBroadcastRows').html(campaigns.length
                ? campaigns.map(function (campaign) {
                    return `
                        <tr>
                            <td>${WA.esc(campaign.name || '')}</td>
                            <td>${WA.esc(campaign.template_name || '')}</td>
                            <td>${WA.esc(campaign.state || '')}</td>
                            <td>${Number(campaign.total_recipients || 0)}</td>
                            <td>${Number(campaign.queued_count || 0)}</td>
                            <td>${Number(campaign.blocked_count || 0)}</td>
                        </tr>
                    `;
                }).join('')
                : '<tr><td colspan="6" class="wa-empty">No campaigns yet.</td></tr>'
            );
        })
        .fail(function (error) {
            $('#waBroadcastRows').html(
                '<tr><td colspan="6" class="wa-empty">Unable to load campaigns.</td></tr>'
            );
            WA.toast(
                error.responseJSON && error.responseJSON.message ||
                'Campaign list unavailable.',
                true
            );
        });
}

initializeWhatsAppBroadcast();
</script>

<!-- campaigns -->
 <script>
function initializeWhatsAppCampaigns() {
    'use strict';

    var $ = window.jQuery;

    var campaignTemplates = [];

    function loadTemplates() {
        window.WA.api('/templates', 'GET', {})
            .done(function (response) {
                campaignTemplates = ((response.data || {}).templates || []).filter(function (template) {
                    return template.approval_status === 'APPROVED' && template.is_enabled;
                });

                $('#waCampaignTemplate').html(`
                    <option value="">Select template</option>
                    ${campaignTemplates.map(function (template) {
                        return `
                            <option value="${WA.esc(template.id)}" data-template-name="${WA.esc(template.name)}" data-lang="${WA.esc(template.language)}">
                                ${WA.esc(template.name)} · ${WA.esc(template.language)}
                            </option>
                        `;
                    }).join('')}
                `);
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Templates unavailable for campaigns.',
                    true
                );
            });
    }

    function loadAudiences() {
        window.WA.api('/audiences', 'GET', {})
            .done(function (response) {
                var audiences = (response.data || {}).audiences || [];

                $('#waCampaignAudience').html(`
                    <option value="">Manual numbers only</option>
                    ${audiences.map(function (audience) {
                        return `
                            <option value="${Number(audience.id)}">
                                ${WA.esc(audience.name)} · #${Number(audience.id)}
                            </option>
                        `;
                    }).join('')}
                `);
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audiences unavailable for campaigns.',
                    true
                );
            });
    }

    function loadCampaigns() {
        window.WA.api('/campaigns', 'GET', {})
            .done(function (response) {
                var campaigns = (response.data || {}).campaigns || [];

                $('#waCampaignRows').html(campaigns.length
                    ? campaigns.map(function (campaign) {
                        var stateClass = campaign.state === 'queued'
                            ? 'ok'
                            : (campaign.state === 'blocked' ? 'bad' : 'warn');

                        return `
                            <tr>
                                <td><strong>${WA.esc(campaign.name || '')}</strong></td>
                                <td>${WA.esc(campaign.template_name || '')}</td>
                                <td>
                                    <span class="wa-badge ${stateClass}">
                                        ${WA.esc(campaign.state || '')}
                                    </span>
                                </td>
                                <td>${Number(campaign.queued_count || 0)}</td>
                                <td>${Number(campaign.blocked_count || 0)}</td>
                                <td>${WA.esc(campaign.created_at || '')}</td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="6" class="wa-empty">No campaigns have been created.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Campaign list unavailable.',
                    true
                );
            });
    }

    $('#waCampaignTemplate').on('change', function () {
        var option = $(this).find(':selected');
        var language = option.data('lang') || 'en';
        var template = window.WA.findTemplateById(campaignTemplates, $(this).val());
        $('#waCampaignLanguage')
            .html(`<option value="${WA.esc(language)}">${WA.esc(language)}</option>`)
            .val(language);
        window.WA.populateTemplateComponents('#waCampaignComponents', '#waCampaignSampleWarning', template);
    });

    $('#waCampaignSend').on('click', function () {
        var componentsJson = $.trim($('#waCampaignComponents').val() || '[]');
        var audienceId = $('#waCampaignAudience').val();
        var recipients = $.trim($('#waCampaignRecipients').val());
        var campaignName = $('#waCampaignName').val();
        var selectedTemplateOption = $('#waCampaignTemplate').find(':selected');
        var templateName = selectedTemplateOption.data('template-name');

        try {
            if (!Array.isArray(JSON.parse(componentsJson))) {
                throw new Error('Components must be a JSON array.');
            }
        } catch (error) {
            WA.toast('Components must be a JSON array.', true);
            return;
        }
        if (window.WA.hasTemplateSampleMarkers(componentsJson)) {
            WA.toast('Replace every generated sample value and example.com media link before queueing this campaign.', true);
            return;
        }

        if (!campaignName || !templateName || (!audienceId && !recipients)) {
            WA.toast(
                'Campaign name, approved template, and either a saved audience or manual recipients are required.',
                true
            );
            return;
        }

        if (!window.confirm(
            'Queue this campaign? Each recipient will be checked for an enabled template, opt-in and global pause status.'
        )) {
            return;
        }

        var button = $(this);
        button.prop('disabled', true).text('Validating & queuing…');

        window.WA.api('/send/bulk', 'POST', {
            name: campaignName,
            template_name: templateName,
            language: $('#waCampaignLanguage').val(),
            components: componentsJson,
            recipients: recipients,
            audience_id: audienceId || ''
        })
            .done(function (response) {
                var data = response.data || {};

                $('#waCampaignResult').html(`
                    <div class="wa-inline-note">
                        <strong>Campaign #${WA.esc(data.campaign_id || '—')}</strong><br>
                        Total: ${Number(data.total || 0)} ·
                        Queued: ${Number(data.queued || 0)} ·
                        Blocked: ${Number(data.blocked || 0)}<br>
                        See Message Logs for delivery statuses and block reasons.
                    </div>
                `);

                WA.toast(response.message || 'Campaign processed.');
                loadCampaigns();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Campaign could not be queued.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false).text('Validate and queue campaign');
            });
    });

    loadTemplates();
    loadAudiences();
    loadCampaigns();
}

initializeWhatsAppCampaigns();
</script>

<!-- constent -->
 <script>
function initializeWhatsAppConsent() {
    'use strict';

    var $ = window.jQuery;

    $('#waSaveConsent').on('click', function () {
        var button = $(this);
        var payload = {
            phone: $('#waConsentPhone').val(),
            category: $('#waConsentCategory').val(),
            consent_status: $('#waConsentStatus').val(),
            source: $('#waConsentSource').val(),
            evidence_ref: $('#waConsentEvidence').val()
        };

        if (!payload.phone || !payload.evidence_ref) {
            WA.toast('Phone and evidence reference are required.', true);
            return;
        }

        button.prop('disabled', true);

        WA.api('/consent', 'POST', payload)
            .done(function (response) {
                WA.toast(response.message || 'Consent saved.');
                $('#waConsentEvidence').val('');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save consent.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });
}

initializeWhatsAppConsent();
</script>

<!-- dasboard -->
 <script>
function initializeWhatsAppDashboard() {
    'use strict';

    var $ = window.jQuery;

    var months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;

    for (var month = 1; month <= 12; month++) {
        $('#waAnalyticsMonth').append(`
            <option value="${month}" ${month === currentMonth ? 'selected' : ''}>
                ${months[month - 1]}
            </option>
        `);
    }

    for (var year = currentYear - 3; year <= currentYear + 1; year++) {
        $('#waAnalyticsYear').append(`
            <option value="${year}" ${year === currentYear ? 'selected' : ''}>
                ${year}
            </option>
        `);
    }

    function formatNumber(value) {
        return Number(value || 0).toLocaleString();
    }

    function loadAnalytics() {
      console.log("ewhgwjh")
        var period = $('#waAnalyticsPeriod').val();

        $('#waAnalyticsMonth').prop('disabled', period === 'year');

        window.WA.api('/analytics', 'GET', {
            period: period,
            month: $('#waAnalyticsMonth').val(),
            year: $('#waAnalyticsYear').val()
        })
            .done(function (response) {
                var data = response.data || {};
                var counts = data.counts || {};
                var total = Object.keys(counts).reduce(function (sum, key) {
                    return sum + Number(counts[key] || 0);
                }, 0);
                var sent = Number(counts.sent || 0) +
                    Number(counts.delivered || 0) +
                    Number(counts.read || 0);
                var statistics = [
                    ['Sent / accepted', sent, 'Meta accepted this month'],
                    ['Delivered', counts.delivered || 0, 'Confirmed delivery receipts'],
                    ['Read', counts.read || 0, 'Confirmed read receipts'],
                    [
                        'Failed / blocked',
                        Number(counts.failed || 0) + Number(counts.blocked || 0),
                        'Inspect errors and consent blocks'
                    ]
                ];

                $('#waStats').html(statistics.map(function (item) {
                    return `
                        <div class="wa-stat">
                            <div class="wa-stat-label">${item[0]}</div>
                            <div class="wa-stat-value">${formatNumber(item[1])}</div>
                            <div class="wa-stat-note">${item[2]}</div>
                        </div>
                    `;
                }).join(''));

                var statusKeys = Object.keys(counts).sort();
                $('#waStatusRows').html(statusKeys.length
                    ? statusKeys.map(function (key) {
                        var statusClass = ['delivered', 'read'].indexOf(key) >= 0
                            ? 'ok'
                            : (['failed', 'blocked'].indexOf(key) >= 0 ? 'bad' : 'warn');
                        var share = (100 * Number(counts[key] || 0) / (total || 1)).toFixed(1);

                        return `
                            <tr>
                                <td><span class="wa-badge ${statusClass}">${WA.esc(key)}</span></td>
                                <td>${formatNumber(counts[key])}</td>
                                <td>${share}%</td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="3" class="wa-empty">No messages in this period.</td></tr>'
                );

                var monthlyRows = Array.from({ length: 12 }, function () {
                    return {};
                });

                (data.by_month || []).forEach(function (item) {
                    if (item.month_num >= 1 && item.month_num <= 12) {
                        monthlyRows[item.month_num - 1][item.status] = item.total;
                    }
                });

                $('#waMonthlyRows').html(monthlyRows.map(function (row, index) {
                    return `
                        <tr>
                            <td>${months[index]}</td>
                            <td>${formatNumber(row.queued || 0)}</td>
                            <td>${formatNumber(row.sent || 0)}</td>
                            <td>${formatNumber(row.delivered || 0)}</td>
                            <td>${formatNumber(row.read || 0)}</td>
                            <td>${formatNumber(row.failed || 0)}</td>
                        </tr>
                    `;
                }).join(''));
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Analytics unavailable.',
                    true
                );
            });

        window.WA.api('/overview', 'GET', {})
            .done(function (response) {
                var data = response.data || {};

                $('#waProfileSummary').html(`
                    <strong>Branch profile:</strong> ${data.profile_configured ? 'API profile configured' : 'Not configured'}<br>
                    <strong>Sending:</strong> ${data.profile_enabled ? 'Enabled' : 'Paused'}<br>
                    <strong>Approved templates:</strong> ${formatNumber(data.templates_approved)} / ${formatNumber(data.templates_total)}<br>
                    <strong>Global pause:</strong> ${data.global_kill_switch ? 'ON' : 'OFF'}
                `);

                $('#waTotalsSummary').html(`
                    <strong>Campaigns this month:</strong> ${formatNumber(data.campaigns_month)}<br>
                    <strong>Month starts:</strong> ${WA.esc(new Date().toLocaleDateString())}<br>
                    <small>Configure template approval, explicit consent and a durable queue before production activation.</small>
                `);
            });
    }

    $('#waAnalyticsRefresh,#waAnalyticsPeriod,  #waAnalyticsMonth, #waAnalyticsYear')
        .on('change click', loadAnalytics);
    
 

    loadAnalytics();
}

initializeWhatsAppDashboard();
</script>

<!-- Groups -->
 <script>
function initializeWhatsAppAudiences() {
    'use strict';

    var $ = window.jQuery;

    function loadAudiences() {
        window.WA.api('/audiences', 'GET', {})
            .done(function (response) {
                var audiences = (response.data || {}).audiences || [];

                $('#waAudienceSelect').html(`
                    <option value="">Select audience</option>
                    ${audiences.map(function (audience) {
                        return `
                            <option value="${WA.esc(audience.id)}">
                                ${WA.esc(audience.name)}
                            </option>
                        `;
                    }).join('')}
                `);

                $('#waAudienceRows').html(audiences.length
                    ? audiences.map(function (audience) {
                        return `
                            <tr>
                                <td>
                                    <strong>${WA.esc(audience.name)}</strong><br>
                                    <small>#${WA.esc(audience.id)}</small>
                                </td>
                                <td>${WA.esc(audience.description || '')}</td>
                                <td>${WA.esc(audience.created_at || '')}</td>
                                <td>
                                    <button type="button" class="wa-btn waAudienceChoose" data-id="${WA.esc(audience.id)}">
                                        Select
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="4" class="wa-empty">No audiences created.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audiences unavailable.',
                    true
                );
            });
    }

    $('#waCreateAudience').on('click', function () {
        var name = $.trim($('#waAudienceName').val());
        var description = $('#waAudienceDescription').val();

        if (!name) {
            WA.toast('Audience name is required.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/audiences', 'POST', {
            name: name,
            description: description
        })
            .done(function (response) {
                WA.toast(response.message || 'Audience created.');
                $('#waAudienceName, #waAudienceDescription').val('');
                loadAudiences();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audience creation failed.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waAudienceRows').on('click', '.waAudienceChoose', function () {
        $('#waAudienceSelect').val($(this).data('id'));
    });

    $('#waAddMembers').on('click', function () {
        var audienceId = $('#waAudienceSelect').val();
        var recipients = $.trim($('#waAudiencePhones').val());

        if (!audienceId || !recipients) {
            WA.toast('Select an audience and enter recipient numbers.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/audiences/members', 'POST', {
            audience_id: audienceId,
            recipients: recipients
        })
            .done(function (response) {
                var savedCount = (response.data || {}).members_saved || 0;
                WA.toast(`${response.message || 'Members saved.'} Saved: ${savedCount}`);
                $('#waAudiencePhones').val('');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save recipients.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    loadAudiences();
}

initializeWhatsAppAudiences();
</script>

<!-- logs -->
 <script>
function initializeWhatsAppLogs() {
    'use strict';

    var $ = window.jQuery;

    var page = 1;
    var lastPage = 1;
    var months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;

    months.forEach(function (monthName, index) {
        var monthNumber = index + 1;
        $('#waLogMonth').append(`
            <option value="${monthNumber}" ${monthNumber === currentMonth ? 'selected' : ''}>
                ${monthName}
            </option>
        `);
    });

    for (var year = currentYear - 4; year <= currentYear + 1; year++) {
        $('#waLogYear').append(`
            <option value="${year}" ${year === currentYear ? 'selected' : ''}>
                ${year}
            </option>
        `);
    }

    function loadLogs() {
        var period = $('#waLogPeriod').val();
        $('#waLogMonth').prop('disabled', period === 'year');

        window.WA.api('/outbox', 'GET', {
            period: period,
            month: $('#waLogMonth').val(),
            year: $('#waLogYear').val(),
            status: $('#waLogStatus').val(),
            q: $('#waLogSearch').val(),
            page: page
        })
            .done(function (response) {
                var data = response.data || {};
                lastPage = data.last_page || 1;

                $('#waLogCount').text(
                    `${Number(data.total || 0).toLocaleString()} messages matching this filter`
                );
                $('#waLogPageLabel').text(`Page ${data.page || 1} of ${lastPage}`);
                $('#waLogPrev').prop('disabled', page <= 1);
                $('#waLogNext').prop('disabled', page >= lastPage);

                var rows = data.rows || [];
                $('#waLogRows').html(rows.length
                    ? rows.map(function (row) {
                        var statusClass = ['delivered', 'read', 'sent'].indexOf(row.status) >= 0
                            ? 'ok'
                            : (['failed', 'blocked'].indexOf(row.status) >= 0 ? 'bad' : 'warn');
                        var campaignHtml = row.campaign_id
                            ? `<br><small>Campaign #${WA.esc(row.campaign_id)}</small>`
                            : '';
                        var errorHtml = row.error_message
                            ? `<br><small>${WA.esc(row.error_message)}</small>`
                            : '';

                        return `
                            <tr>
                                <td>
                                    ${WA.esc(row.created_at || '')}<br>
                                    <small class="wa-muted">#${WA.esc(row.id)}</small>
                                </td>
                                <td><strong>${WA.esc(row.phone_e164 || '')}</strong></td>
                                <td>
                                    ${WA.esc(row.template_name || row.message_type || '')}<br>
                                    <small class="wa-muted">${WA.esc(row.language || '')}</small>
                                </td>
                                <td>
                                    ${WA.esc(row.workflow_event_key || row.source_type || '')}
                                    ${campaignHtml}
                                </td>
                                <td><span class="wa-badge ${statusClass}">${WA.esc(row.status || '')}</span></td>
                                <td>${WA.esc(row.error_code || '')}${errorHtml}</td>
                                <td>
                                    <small>
                                        Sent: ${WA.esc(row.sent_at || '—')}<br>
                                        Delivered: ${WA.esc(row.delivered_at || '—')}<br>
                                        Read: ${WA.esc(row.read_at || '—')}<br>
                                        Failed: ${WA.esc(row.failed_at || '—')}
                                    </small>
                                </td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="7" class="wa-empty">No outbox records in this period.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Log query failed.',
                    true
                );
            });
    }

    $('#waLogApply, #waLogRefresh').on('click', function () {
        page = 1;
        loadLogs();
    });

    $('#waLogPrev').on('click', function () {
        if (page > 1) {
            page--;
            loadLogs();
        }
    });

    $('#waLogNext').on('click', function () {
        if (page < lastPage) {
            page++;
            loadLogs();
        }
    });

    $('#waLogPeriod, #waLogMonth, #waLogYear, #waLogStatus').on('change', function () {
        page = 1;
        loadLogs();
    });

    $('#waLogSearch').on('keydown', function (event) {
        if (event.key === 'Enter') {
            page = 1;
            loadLogs();
        }
    });

    loadLogs();
}

initializeWhatsAppLogs();
</script>
@endsection
