<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use InvalidArgumentException;
use Throwable;

/**
 * Reusable business-event adapter. The event key selects its approved Meta template and mapping
 * in WhatsApp Management; callers pass business data, never a Graph API payload.
 */
class WhatsAppWorkflowDispatcher
{
    private function normalizeRecipient(string $phone): string
    {
        $phone = trim($phone);
        $hadPlus = isset($phone[0]) && $phone[0] === '+';
        $digits = preg_replace('/\D+/', '', $phone);
        $country = preg_replace('/\D+/', '', (string) config('whatsapp.default_country_code', '91'));
        if (!$digits) throw new InvalidArgumentException('WhatsApp recipient number is empty.');
        if (!$hadPlus && strlen($digits) === 10) $digits = $country . $digits;
        elseif (!$hadPlus && strlen($digits) === 11 && isset($digits[0]) && $digits[0] === '0') $digits = $country . substr($digits, 1);
        if (strlen($digits) < 8 || strlen($digits) > 15 || $digits[0] === '0') {
            throw new InvalidArgumentException('Recipient must be an international WhatsApp phone number.');
        }
        return '+' . $digits;
    }

    public function queue(
        string $eventKey,
        string $recipient,
        array $variables,
        string $sourceType,
        int $sourceId,
        ?int $actorId = null,
        ?string $idempotencyKey = null,
        ?array $consentEvidence = null
    ): array {
        try {
            $phone = $this->normalizeRecipient($recipient);

            // Consent is registered only when the originating workflow supplies a real,
            // affirmative opt-in captured from the recipient. A CRM record alone is not consent.
            if ($consentEvidence !== null) {
                if (($consentEvidence['accepted'] ?? false) !== true) {
                    return ['ok' => false, 'status' => 'blocked', 'reason' => 'Consent evidence must confirm an explicit affirmative opt-in.'];
                }
                $categories = array_values(array_unique(array_filter(array_map(
                    static function ($value) { return strtolower(trim((string) $value)); },
                    (array) ($consentEvidence['categories'] ?? [])
                ))));
                $source = trim((string) ($consentEvidence['source'] ?? ''));
                $evidenceRef = trim((string) ($consentEvidence['evidence_ref'] ?? ''));
                if ($categories && ($source === '' || $evidenceRef === '')) {
                    return ['ok' => false, 'status' => 'blocked', 'reason' => 'Consent categories were supplied without auditable opt-in evidence.'];
                }
                foreach ($categories as $category) {
                    if (!in_array($category, ['utility', 'marketing', 'authentication', 'all'], true)) {
                        return ['ok' => false, 'status' => 'blocked', 'reason' => 'Unsupported WhatsApp consent category.'];
                    }
                    $consentResult = app(WhatsAppManagerService::class)->recordConsent([
                        'phone' => $phone,
                        'category' => $category,
                        'consent_status' => 'opted_in',
                        'source' => $source,
                        'evidence_ref' => $evidenceRef,
                        'created_by' => $actorId,
                    ]);
                    if (empty($consentResult['ok'])) {
                        Log::warning('WhatsApp workflow consent could not be registered; message not queued.', [
                            'event_key' => $eventKey,
                            'source_type' => $sourceType,
                            'source_id' => $sourceId,
                            'category' => $category,
                        ]);
                        return ['ok' => false, 'status' => 'blocked', 'reason' => $consentResult['message'] ?? 'Consent registration failed.'];
                    }
                }
            }

            $result = app(WhatsAppManagerService::class)->queueWorkflow([
                'branch_id' => 0,
                'event_key' => $eventKey,
                'to' => $phone,
                'variables' => $variables,
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'created_by' => $actorId,
                'idempotency_key' => $idempotencyKey ?: ($eventKey . ':' . $sourceId . ':' . Str::uuid()),
            ]);
            if (empty($result['ok'])) {
                Log::notice('WhatsApp workflow was not queued; source ERP operation remains successful.', [
                    'event_key' => $eventKey,
                    'source_type' => $sourceType,
                    'source_id' => $sourceId,
                    'outbox_id' => $result['id'] ?? null,
                    'queue_status' => $result['status'] ?? 'blocked',
                    'reason' => $result['reason'] ?? 'not_queued',
                ]);
            }
            return $result;
        } catch (Throwable $exception) {
            Log::error('WhatsApp workflow adapter failed; ERP source operation must remain successful.', [
                'event_key' => $eventKey,
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'exception' => class_basename($exception),
            ]);
            return ['ok' => false, 'status' => 'error', 'reason' => 'WhatsApp workflow adapter failed.'];
        }
    }
}
