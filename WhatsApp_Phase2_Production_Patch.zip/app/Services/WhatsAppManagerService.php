<?php

namespace App\Services;

use App\Jobs\ProcessWhatsAppOutboxJob;
use App\Support\WhatsAppTables;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/** Central WhatsApp Cloud API gateway for the ERP. Keep controllers out of HTTP/API details. */
class WhatsAppManagerService
{
    public function normalizePhone(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            throw new \InvalidArgumentException('Recipient phone number is required.');
        }
        // Accept E.164 (+919876543210) or international digits (919876543210), not an ambiguous local number.
        $hadPlus = isset($value[0]) && $value[0] === '+';
        $digits = preg_replace('/\D+/', '', $value);
        if (!$digits || strlen($digits) < 8 || strlen($digits) > 15 || $digits[0] === '0' || (!$hadPlus && strlen($digits) === 10)) {
            throw new \InvalidArgumentException('Use an international WhatsApp number, e.g. +919876543210. Do not enter a local 10-digit number without country code.');
        }
        return '+' . $digits;
    }

    private function phoneDigits(string $phone): string
    {
        return preg_replace('/\D+/', '', $phone);
    }

    /** One ERP-wide Meta profile. The argument remains for source compatibility with older controllers. */
    public function settingsForBranch(int $branchId = 0): ?object
    {
        return DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('branch_id', 0)->first();
    }

    /** Alias fields used only while legacy controllers are being migrated away from inline URL/token plumbing. */
    public function legacyCompatibilityProfile(): object
    {
        $row = $this->settingsForBranch(0);
        $profile = new \stdClass();
        $profile->branch_id = 0;
        $profile->phone_number_id = $row->phone_number_id ?? '';
        $profile->phonenumber_id = $row->phone_number_id ?? '';
        $profile->waba_id = $row->waba_id ?? '';
        // Legacy helper methods are replaced by the queue bridge; never return the plaintext token here.
        $profile->access_tokken = '';
        $profile->access_token = '';
        $profile->access_token_encrypted = $row->access_token_encrypted ?? null;
        $profile->graph_api_version = $row->graph_api_version ?? config('whatsapp.api_version', 'v26.0');
        return $profile;
    }

    private function globalKillSwitchOn(): bool
    {
        return (bool) DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('branch_id', 0)->value('kill_switch');
    }

    private function tokenForSettings(?object $settings): ?string
    {
        if (!$settings || empty($settings->access_token_encrypted)) {
            return null;
        }
        try {
            return Crypt::decryptString($settings->access_token_encrypted);
        } catch (Throwable $e) {
            Log::error('WhatsApp access token could not be decrypted; rotate/re-save the token.', [
                'branch_id' => $settings->branch_id ?? null,
            ]);
            return null;
        }
    }

    /** Access token for internal media proxy/API calls; never return this value to browser responses. */
    public function accessTokenForSettings(?object $settings): ?string
    {
        return $this->tokenForSettings($settings);
    }

    public function getAccessTokenForPhoneNumber(?string $phoneNumberId): ?string
    {
        if (!$phoneNumberId) {
            return null;
        }
        // Inbound webhook/media processing must continue even when an admin pauses outbound sends.
        $settings = DB::table(WhatsAppTables::name('whatsapp_automation_settings'))
            ->where('phone_number_id', $phoneNumberId)
            ->first();
        return $this->tokenForSettings($settings);
    }

    public function testConnection(int $branchId = 0): array
    {
        $settings = $this->settingsForBranch(0);
        $token = $this->tokenForSettings($settings);
        if (!$settings || !$token || empty($settings->waba_id)) {
            return ['ok' => false, 'message' => 'Configure the WABA ID, phone number ID, and access token first.'];
        }
        try {
            $url = $this->graphBase($settings) . '/' . rawurlencode($settings->waba_id) . '/message_templates';
            $response = Http::withToken($token)->acceptJson()->timeout(20)->get($url, ['limit' => 1]);
            if ($response->successful()) {
                return ['ok' => true, 'message' => 'Meta accepted the credentials and the WABA template endpoint responded.'];
            }
            $json = $response->json();
            return ['ok' => false, 'message' => $json['error']['message'] ?? 'Meta API returned HTTP ' . $response->status(), 'error_code' => $json['error']['code'] ?? null];
        } catch (Throwable $e) {
            Log::warning('WhatsApp connection test failed', ['branch_id' => $branchId, 'exception' => class_basename($e)]);
            return ['ok' => false, 'message' => 'Connection failed. Check application logs and outbound HTTPS connectivity.'];
        }
    }

    private function graphBase(object $settings): string
    {
        $version = trim((string) ($settings->graph_api_version ?: config('whatsapp.api_version', 'v26.0')));
        $version = ltrim($version, '/');
        if (!preg_match('/^v\d+\.0$/', $version)) {
            throw new \InvalidArgumentException('Graph API version must look like v26.0.');
        }
        return 'https://graph.facebook.com/' . $version;
    }

    public function syncTemplates(int $branchId = 0): array
    {
        $branchId = 0; // Template registry is common to the ERP-wide WABA.
        $settings = $this->settingsForBranch(0);
        $token = $this->tokenForSettings($settings);
        if (!$settings || !$token || empty($settings->waba_id)) {
            return ['ok' => false, 'message' => 'Configure a valid WhatsApp API profile before syncing templates.'];
        }

        $base = $this->graphBase($settings) . '/' . rawurlencode($settings->waba_id) . '/message_templates';
        $url = $base;
        $params = ['limit' => 100];
        $count = 0;
        $pages = 0;
        try {
            // Guard against unexpectedly large/unbounded pagination responses.
            while ($url && $pages < (int) config('whatsapp.max_template_sync_pages', 20)) {
                if (parse_url($url, PHP_URL_HOST) !== 'graph.facebook.com') {
                    return ['ok' => false, 'message' => 'Meta template paging returned an unexpected host; sync stopped.'];
                }
                $response = Http::withToken($token)->acceptJson()->timeout(25)->get($url, $params);
                if (!$response->successful()) {
                    $json = $response->json();
                    return ['ok' => false, 'message' => $json['error']['message'] ?? 'Meta returned HTTP ' . $response->status(), 'error_code' => $json['error']['code'] ?? null];
                }
                $json = $response->json();
                foreach (($json['data'] ?? []) as $template) {
                    if (empty($template['name']) || empty($template['language'])) {
                        continue;
                    }
                    $name = (string) $template['name'];
                    $language = (string) $template['language'];
                    $key = sha1($name . '|' . $language);
                    $existing = DB::table(WhatsAppTables::name('whatsapp_template_registry'))
                        ->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)->where('template_key', $key)->first();
                    $values = [
                        'branch_id' => $branchId,
                        'waba_id' => (string) $settings->waba_id,
                        'meta_template_id' => isset($template['id']) ? (string) $template['id'] : null,
                        'template_key' => $key,
                        'name' => $name,
                        'language' => $language,
                        'category' => strtoupper((string) ($template['category'] ?? 'UNKNOWN')),
                        'approval_status' => strtoupper((string) ($template['status'] ?? 'UNKNOWN')),
                        'components_json' => json_encode($template['components'] ?? [], JSON_UNESCAPED_UNICODE),
                        'raw_json' => json_encode($template, JSON_UNESCAPED_UNICODE),
                        'last_synced_at' => now(),
                        'updated_at' => now(),
                    ];
                    if ($existing) {
                        DB::table(WhatsAppTables::name('whatsapp_template_registry'))->where('id', $existing->id)->update($values);
                    } else {
                        $values['is_enabled'] = 0; // Explicit admin review before a synced template can be used.
                        $values['created_at'] = now();
                        DB::table(WhatsAppTables::name('whatsapp_template_registry'))->insert($values);
                    }
                    $count++;
                }
                $pages++;
                $url = $json['paging']['next'] ?? null;
                $params = []; // Paging URL already contains its cursor/limit.
            }
            return ['ok' => true, 'message' => 'Template sync complete. Review approval statuses and enable only templates intended for production.', 'count' => $count, 'pages' => $pages];
        } catch (Throwable $e) {
            Log::error('WhatsApp template sync failed', ['branch_id' => $branchId, 'exception' => class_basename($e)]);
            return ['ok' => false, 'message' => 'Template sync failed. Check application logs.' ,'ERR'=>$e->getMessage()];
        }
    }

    /** Resolve a business event through an admin-managed branch rule, not a controller template literal. */
    public function queueWorkflow(array $input): array
    {
        $branchId = 0; // Business-event rules are shared ERP-wide.
        $eventKey = trim((string) ($input['event_key'] ?? ''));
        if (!preg_match('/^[a-z][a-z0-9_.-]{1,99}$/', $eventKey)) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'A valid workflow event key is required.'];
        }

        $input['branch_id'] = 0;
        $input['workflow_event_key'] = $eventKey;
        $rule = DB::table(WhatsAppTables::name('whatsapp_workflow_rules'))
            ->where('branch_id', 0)->where('event_key', $eventKey)->where('is_enabled', 1)->first();
        if (!$rule) {
            // Reuse the outbox policy path so missing/disabled workflow mappings are visible in Message logs.
            $input['template_name'] = '__workflow_not_configured__';
            $input['language'] = 'en_US';
            $input['components'] = [];
            $input['force_block_reason'] = 'No enabled WhatsApp workflow rule exists for event: ' . $eventKey;
            return $this->queueTemplate($input);
        }

        $expectedTemplate = trim((string) ($input['expected_template_name'] ?? ''));
        if ($expectedTemplate !== '' && !hash_equals((string) $rule->template_name, $expectedTemplate)) {
            // Prevent a manually selected template from silently resolving to another template's workflow.
            $input['template_name'] = $expectedTemplate;
            $input['language'] = $rule->language;
            $input['components'] = [];
            $input['force_block_reason'] = 'Selected template does not match the branch workflow mapping. Review Automation rules.';
            return $this->queueTemplate($input);
        }
        $input['template_name'] = $rule->template_name;
        $input['language'] = $rule->language;
        if (!empty($input['require_parameter_map'])) {
            $legacyMap = json_decode((string) ($rule->parameter_map_json ?? ''), true);
            if (!is_array($legacyMap) || count($legacyMap) === 0) {
                $input['components'] = [];
                $input['force_block_reason'] = 'This legacy send needs a non-empty admin parameter map. Configure the Automation rule before enabling it.';
                return $this->queueTemplate($input);
            }
        }
        // A rule may resolve template parameters from event variables using an admin-managed map.
        // Explicit prebuilt components remain supported for legacy integrations while they migrate.
        if (!empty($input['variables']) && !empty($rule->parameter_map_json)) {
            try {
                $mapping = json_decode((string) $rule->parameter_map_json, true, 32, JSON_THROW_ON_ERROR);
                $input['components'] = $this->resolveParameterMap(is_array($mapping) ? $mapping : [], (array) $input['variables']);
            } catch (\Throwable $e) {
                $input['components'] = [];
                $input['force_block_reason'] = 'The WhatsApp workflow parameter map is invalid; review it in Automation rules.';
            }
        }
        return $this->queueTemplate($input);
    }

    /**
     * Map an event-variable dictionary to Meta's components array.
     * Mapping format: [{"type":"body","parameters":[{"type":"text","source":"lead_name"}]}, ...]
     * Supported source-backed types: text, image, document, video, currency, date_time and coupon_code.
     */
    private function resolveParameterMap(array $mapping, array $variables): array
    {
        if (!$mapping) return [];
        if (count($mapping) > 10) throw new \InvalidArgumentException('Too many mapped template components.');
        $components = [];
        foreach ($mapping as $component) {
            if (!is_array($component) || empty($component['type'])) throw new \InvalidArgumentException('Each mapped component needs a type.');
            $type = strtolower((string) $component['type']);
            if (!in_array($type, ['header', 'body', 'button'], true)) throw new \InvalidArgumentException('Unsupported component type.');
            $target = ['type' => $type];
            if ($type === 'button') {
                $target['sub_type'] = (string) ($component['sub_type'] ?? 'url');
                $target['index'] = (int) ($component['index'] ?? 0);
            }
            $parameters = $component['parameters'] ?? [];
            if (!is_array($parameters) || count($parameters) > 20) throw new \InvalidArgumentException('Invalid mapped parameters.');
            $target['parameters'] = [];
            foreach ($parameters as $parameter) {
                if (!is_array($parameter)) throw new \InvalidArgumentException('Invalid mapped parameter.');
                $kind = strtolower((string) ($parameter['type'] ?? 'text'));
                $source = (string) ($parameter['source'] ?? '');
                if (!in_array($kind, ['text', 'image', 'document', 'video', 'currency', 'date_time', 'coupon_code'], true)) {
                    throw new \InvalidArgumentException('Unsupported mapped parameter type.');
                }
                if ($source !== '') {
                    if (!array_key_exists($source, $variables) || $variables[$source] === null || $variables[$source] === '') {
                        throw new \InvalidArgumentException('Missing event variable: ' . $source);
                    }
                    $value = $variables[$source];
                } elseif (array_key_exists('value', $parameter)) {
                    $value = $parameter['value'];
                } else {
                    throw new \InvalidArgumentException('Each mapped parameter needs source or value.');
                }
                if ($kind === 'text') {
                    $textParameter = ['type' => 'text', 'text' => (string) $value];
                    if (!empty($parameter['parameter_name'])) {
                        $parameterName = (string) $parameter['parameter_name'];
                        if (!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,79}$/', $parameterName)) {
                            throw new \InvalidArgumentException('Invalid named-template parameter name.');
                        }
                        $textParameter['parameter_name'] = $parameterName;
                    }
                    $target['parameters'][] = $textParameter;
                } elseif (in_array($kind, ['image', 'document', 'video'], true)) {
                    if (!filter_var((string) $value, FILTER_VALIDATE_URL) || !in_array(strtolower((string) parse_url((string) $value, PHP_URL_SCHEME)), ['https'], true)) {
                        throw new \InvalidArgumentException('Media parameters must use public HTTPS URLs.');
                    }
                    $media = ['link' => (string) $value];
                    if ($kind === 'document' && !empty($parameter['filename_source']) && !empty($variables[$parameter['filename_source']])) {
                        $media['filename'] = (string) $variables[$parameter['filename_source']];
                    }
                    $target['parameters'][] = ['type' => $kind, $kind => $media];
                } elseif ($kind === 'coupon_code') {
                    $target['parameters'][] = ['type' => 'coupon_code', 'coupon_code' => (string) $value];
                } elseif ($kind === 'currency') {
                    if (!is_array($value)) throw new \InvalidArgumentException('Currency value must be an object/array.');
                    $target['parameters'][] = ['type' => 'currency', 'currency' => $value];
                } else {
                    if (!is_array($value)) throw new \InvalidArgumentException('Date-time value must be an object/array.');
                    $target['parameters'][] = ['type' => 'date_time', 'date_time' => $value];
                }
            }
            if ($target['parameters']) $components[] = $target;
        }
        return $components;
    }

    public function queueTemplate(array $input): array
    {
        $branchId = 0; // Every outbound operation uses the shared ERP/WABA profile and global outbox.
        $templateName = trim((string) ($input['template_name'] ?? ''));
        $language = trim((string) ($input['language'] ?? 'en_US'));
        $sourceType = substr(trim((string) ($input['source_type'] ?? 'admin_manual')), 0, 80);
        $sourceId = isset($input['source_id']) ? (int) $input['source_id'] : null;
        $actorId = isset($input['created_by']) ? (int) $input['created_by'] : null;
        $components = $input['components'] ?? [];
        $idempotencyKey = substr((string) ($input['idempotency_key'] ?? Str::uuid()), 0, 191);
        $delaySeconds = max(0, min(3600, (int) ($input['delay_seconds'] ?? 0)));
        $campaignId = isset($input['campaign_id']) ? (int) $input['campaign_id'] : null;
        $workflowEventKey = isset($input['workflow_event_key']) ? substr((string) $input['workflow_event_key'], 0, 100) : null;

        try {
            $phone = $this->normalizePhone((string) ($input['to'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => $e->getMessage()];
        }
        if ($templateName === '' || !is_array($components)) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'Template name and component array are required.'];
        }

        $settings = $this->settingsForBranch(0);
        $template = $settings ? DB::table(WhatsAppTables::name('whatsapp_template_registry'))
            ->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)
            ->where('name', $templateName)->where('language', $language)->first() : null;
        $reason = trim((string) ($input['force_block_reason'] ?? '')) ?: null;
        if (!$reason) {
            if ($this->globalKillSwitchOn()) {
                $reason = 'Global WhatsApp kill switch is ON.';
            } elseif (!$settings || !(int) $settings->is_enabled) {
                $reason = 'WhatsApp API profile is missing or disabled for this branch.';
            } elseif (!$template) {
                $reason = 'Template is not synced for this WABA/language.';
            } elseif (strtoupper((string) $template->approval_status) !== 'APPROVED') {
                $reason = 'Meta template status is not APPROVED.';
            } elseif (!(int) $template->is_enabled) {
                $reason = 'Template is disabled in ERP settings.';
            } elseif (!$this->hasConsent(0, $phone, $this->consentCategory($template->category))) {
                $reason = 'No current, matching WhatsApp opt-in evidence. Record/import consent before initiating a template message.';
            }
        }

        $existing = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) {
            return ['ok' => in_array($existing->status, ['queued', 'processing', 'sent', 'delivered', 'read'], true), 'id' => $existing->id, 'status' => $existing->status, 'reason' => $existing->error_message, 'duplicate_request' => true];
        }

        $status = $reason ? 'blocked' : 'queued';
        $scheduledAt = null;
        $outboxId = null;
        DB::transaction(function () use (&$outboxId, &$scheduledAt, $branchId, $settings, $phone, $templateName, $language, $components, $sourceType, $sourceId, $actorId, $idempotencyKey, $reason, $status, $delaySeconds, $campaignId, $workflowEventKey) {
            // Serialise schedule assignment per branch to spread automatic/bulk sends instead of spiking traffic.
            $lockedSettings = $settings ? DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('id', $settings->id)->lockForUpdate()->first() : null;
            if (!$reason && (!$lockedSettings || !(int) $lockedSettings->is_enabled || $this->globalKillSwitchOn())) {
                $actualStatus = 'blocked';
                $actualReason = 'WhatsApp sending was disabled while this message was being queued.';
            } else {
                $actualStatus = $status;
                $actualReason = $reason;
            }
            if ($actualStatus === 'queued') {
                $base = now()->addSeconds($delaySeconds);
                if ($lockedSettings && !empty($lockedSettings->next_send_at)) {
                    $next = \Carbon\Carbon::parse($lockedSettings->next_send_at);
                    if ($next->greaterThan($base)) {
                        $base = $next;
                    }
                }
                $scheduledAt = $base;
                $interval = max(1, min(300, (int) ($lockedSettings->min_send_interval_seconds ?? 10)));
                DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('id', $lockedSettings->id)->update([
                    'next_send_at' => $base->copy()->addSeconds($interval),
                    'updated_at' => now(),
                ]);
            }
            $outboxId = DB::table(WhatsAppTables::name('whatsapp_outbox'))->insertGetId([
                'branch_id' => $branchId,
                'phone_e164' => $phone,
                'message_type' => 'template',
                'template_name' => $templateName,
                'language' => $language,
                'template_category' => $this->consentCategoryFromInput($branchId, $templateName, $language),
                'components_json' => json_encode($components, JSON_UNESCAPED_UNICODE),
                'text_body' => null,
                'source_type' => $sourceType,
                'workflow_event_key' => $workflowEventKey,
                'campaign_id' => $campaignId,
                'source_id' => $sourceId,
                'created_by' => $actorId,
                'idempotency_key' => $idempotencyKey,
                'status' => $actualStatus,
                'scheduled_at' => $scheduledAt,
                'error_code' => $actualReason ? 'POLICY_GUARD' : null,
                'error_message' => $actualReason,
                'attempts' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });

        if ($status === 'queued' && $scheduledAt && !$reason) {
            ProcessWhatsAppOutboxJob::dispatch($outboxId)->delay($scheduledAt);
            return ['ok' => true, 'id' => $outboxId, 'status' => 'queued', 'scheduled_at' => $scheduledAt->toDateTimeString()];
        }
        $row = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->first();
        return ['ok' => false, 'id' => $outboxId, 'status' => $row->status ?? 'blocked', 'reason' => $row->error_message ?? $reason];
    }

    private function consentCategory(string $templateCategory): string
    {
        $category = strtoupper($templateCategory);
        if (in_array($category, ['AUTHENTICATION', 'UTILITY', 'MARKETING'], true)) {
            return strtolower($category);
        }
        return 'all';
    }

    private function consentCategoryFromInput(int $branchId, string $name, string $language): string
    {
        $settings = $this->settingsForBranch($branchId);
        if (!$settings) return 'unknown';
        $template = DB::table(WhatsAppTables::name('whatsapp_template_registry'))->where('branch_id', $branchId)->where('waba_id', $settings->waba_id)->where('name', $name)->where('language', $language)->first();
        return $template ? $this->consentCategory($template->category) : 'unknown';
    }

    private function hasConsent(int $branchId, string $phone, string $category): bool
    {
        $all = DB::table(WhatsAppTables::name('whatsapp_consents'))->where('branch_id', $branchId)->where('phone_e164', $phone)->where('category', 'all')->first();
        $exact = $category === 'all' ? $all : DB::table(WhatsAppTables::name('whatsapp_consents'))->where('branch_id', $branchId)
            ->where('phone_e164', $phone)->where('category', $category)->first();

        // STOP creates an all-category opt-out. A later, explicitly evidenced opt-in for a
        // specific category may re-enable only that category; older category opt-ins must not
        // override a newer STOP. The dispatcher writes opted_in_at when that new evidence arrives.
        if ($all && $all->consent_status === 'opted_out') {
            if ($category !== 'all' && $exact && $exact->consent_status === 'opted_in' && !empty($exact->opted_in_at)
                && !empty($all->opted_out_at) && \Carbon\Carbon::parse($exact->opted_in_at)->greaterThan(\Carbon\Carbon::parse($all->opted_out_at))) {
                return true;
            }
            return false;
        }
        if ($exact && $exact->consent_status !== 'opted_in') return false;
        if ($exact && $exact->consent_status === 'opted_in' && !empty($exact->opted_in_at)) return true;
        return $all && $all->consent_status === 'opted_in' && !empty($all->opted_in_at);
    }

    private function isOptedOut(int $branchId, string $phone): bool
    {
        $all = DB::table(WhatsAppTables::name('whatsapp_consents'))->where('branch_id', $branchId)->where('phone_e164', $phone)->where('category', 'all')->first();
        return $all && $all->consent_status === 'opted_out';
    }

    public function queueText(array $input): array
    {
        $branchId = 0; // Chat session is WABA-wide. Lead/customer branch filtering belongs to the CRM contact list.
        try {
            $phone = $this->normalizePhone((string) ($input['to'] ?? ''));
        } catch (\InvalidArgumentException $e) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => $e->getMessage()];
        }
        $text = trim((string) ($input['text'] ?? ''));
        if ($text === '' || mb_strlen($text) > 4096) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'Text (1–4096 characters) is required.'];
        }
        $settings = $this->settingsForBranch(0);
        $session = DB::table(WhatsAppTables::name('whatsapp_sessions'))->where('branch_id', $branchId)->where('phone_e164', $phone)->first();
        $active = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        $reason = null;
        if ($this->globalKillSwitchOn()) $reason = 'Global WhatsApp kill switch is ON.';
        elseif (!$settings || !(int) $settings->is_enabled) $reason = 'WhatsApp API profile is missing or disabled for this branch.';
        elseif (!$active) $reason = 'The 24-hour customer service window is closed. Send an approved template instead.';
        elseif ($this->isOptedOut($branchId, $phone)) $reason = 'This recipient has opted out. Respect the opt-out request.';

        $idempotencyKey = substr((string) ($input['idempotency_key'] ?? Str::uuid()), 0, 191);
        $existing = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) return ['ok' => in_array($existing->status, ['queued', 'processing', 'sent', 'delivered', 'read'], true), 'id' => $existing->id, 'status' => $existing->status, 'reason' => $existing->error_message, 'duplicate_request' => true];

        $outboxId = DB::table(WhatsAppTables::name('whatsapp_outbox'))->insertGetId([
            'branch_id' => $branchId, 'phone_e164' => $phone, 'message_type' => 'text', 'template_name' => null,
            'language' => null, 'template_category' => null, 'components_json' => null, 'text_body' => $text,
            'source_type' => substr((string) ($input['source_type'] ?? 'agent_chat'), 0, 80), 'source_id' => null,
            'created_by' => isset($input['created_by']) ? (int) $input['created_by'] : null, 'idempotency_key' => $idempotencyKey,
            'status' => $reason ? 'blocked' : 'queued', 'scheduled_at' => $reason ? null : now(),
            'error_code' => $reason ? 'POLICY_GUARD' : null, 'error_message' => $reason, 'attempts' => 0,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        if ($reason) return ['ok' => false, 'id' => $outboxId, 'status' => 'blocked', 'reason' => $reason];
        ProcessWhatsAppOutboxJob::dispatch($outboxId);
        return ['ok' => true, 'id' => $outboxId, 'status' => 'queued'];
    }

    /** Queue a non-template Cloud API payload (media, location, reaction, interactive or Flow). */
    public function queueCloudMessage(array $input): array
    {
        $type = strtolower(trim((string) ($input['message_type'] ?? '')));
        $allowed = ['image', 'video', 'audio', 'document', 'sticker', 'location', 'contacts', 'reaction', 'interactive'];
        if (!in_array($type, $allowed, true)) return ['ok' => false, 'status' => 'blocked', 'reason' => 'Unsupported Cloud API message type.'];
        try { $phone = $this->normalizePhone((string) ($input['to'] ?? '')); }
        catch (\InvalidArgumentException $e) { return ['ok' => false, 'status' => 'blocked', 'reason' => $e->getMessage()]; }
        $settings = $this->settingsForBranch(0);
        $session = DB::table(WhatsAppTables::name('whatsapp_sessions'))->where('branch_id', 0)->where('phone_e164', $phone)->first();
        $windowOpen = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        $reason = null;
        if ($this->globalKillSwitchOn()) $reason = 'Global WhatsApp kill switch is ON.';
        elseif (!$settings || !(int) $settings->is_enabled || empty($settings->phone_number_id)) $reason = 'Shared ERP WhatsApp profile is missing or disabled.';
        elseif (!$windowOpen) $reason = 'The 24-hour customer-service window is closed. Use an approved template to initiate/reopen the conversation.';
        elseif ($this->isOptedOut(0, $phone)) $reason = 'Recipient has opted out.';

        $payload = $input['payload'] ?? [];
        if (!is_array($payload)) return ['ok' => false, 'status' => 'blocked', 'reason' => 'Message payload must be a JSON object.'];
        $mediaPath = isset($input['media_path']) ? trim((string) $input['media_path']) : null;
        if (in_array($type, ['image','video','audio','document','sticker'], true) && !$mediaPath) {
            return ['ok' => false, 'status' => 'blocked', 'reason' => 'Media attachment path is missing.'];
        }
        $idempotencyKey = substr((string) ($input['idempotency_key'] ?? Str::uuid()), 0, 191);
        $existing = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('idempotency_key', $idempotencyKey)->first();
        if ($existing) return ['ok' => in_array($existing->status, ['queued','processing','sent','delivered','read'], true), 'id' => $existing->id, 'status' => $existing->status, 'duplicate_request' => true, 'reason' => $existing->error_message];
        $id = DB::table(WhatsAppTables::name('whatsapp_outbox'))->insertGetId([
            'branch_id' => 0, 'phone_e164' => $phone, 'message_type' => $type, 'template_name' => null, 'language' => null,
            'template_category' => 'service', 'components_json' => null, 'payload_json' => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'text_body' => isset($input['text_body']) ? mb_substr((string) $input['text_body'], 0, 4096) : null,
            'media_path' => $mediaPath, 'media_filename' => isset($input['media_filename']) ? mb_substr((string) $input['media_filename'], 0, 255) : null,
            'media_mime_type' => isset($input['media_mime_type']) ? mb_substr((string) $input['media_mime_type'], 0, 100) : null,
            'media_caption' => isset($input['media_caption']) ? mb_substr((string) $input['media_caption'], 0, 1024) : null,
            'uploaded_media_id' => null, 'source_type' => substr((string) ($input['source_type'] ?? ('chat_' . $type)), 0, 80),
            'workflow_event_key' => null, 'campaign_id' => null, 'source_id' => null, 'created_by' => $input['created_by'] ?? null,
            'idempotency_key' => $idempotencyKey, 'status' => $reason ? 'blocked' : 'queued', 'scheduled_at' => $reason ? null : now(),
            'error_code' => $reason ? 'POLICY_GUARD' : null, 'error_message' => $reason, 'attempts' => 0,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        if ($reason) return ['ok' => false, 'id' => $id, 'status' => 'blocked', 'reason' => $reason];
        ProcessWhatsAppOutboxJob::dispatch($id);
        return ['ok' => true, 'id' => $id, 'status' => 'queued'];
    }

    public function processOutbox(int $outboxId): void
    {
        $row = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->first();
        if (!$row || !in_array($row->status, ['queued'], true)) return; // protects against duplicate jobs
        if (!empty($row->scheduled_at) && \Carbon\Carbon::parse($row->scheduled_at)->isFuture()) {
            ProcessWhatsAppOutboxJob::dispatch($outboxId)->delay(\Carbon\Carbon::parse($row->scheduled_at));
            return;
        }
        $claimed = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->where('status', 'queued')->update([
            'status' => 'processing', 'attempts' => DB::raw('attempts + 1'), 'updated_at' => now(),
        ]);
        if (!$claimed) return;
        $row = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->first();
        $settings = $this->settingsForBranch((int) $row->branch_id);
        if ($this->globalKillSwitchOn() || !$settings || !(int) $settings->is_enabled) {
            $this->failOutbox($outboxId, 'SENDING_DISABLED', 'WhatsApp sending is currently disabled.');
            return;
        }
        $token = $this->tokenForSettings($settings);
        if (!$token || empty($settings->phone_number_id)) {
            $this->failOutbox($outboxId, 'CONFIG_MISSING', 'Missing/decryption-failed API token or phone number ID.');
            return;
        }

        if ($row->message_type === 'template') {
            if (!empty($row->workflow_event_key)) {
                $rule = DB::table(WhatsAppTables::name('whatsapp_workflow_rules'))
                    ->where('branch_id', 0)
                    ->where('event_key', $row->workflow_event_key)
                    ->where('is_enabled', 1)->first();
                if (!$rule || $rule->template_name !== $row->template_name || $rule->language !== $row->language) {
                    $this->failOutbox($outboxId, 'WORKFLOW_DISABLED', 'Workflow rule was disabled or changed after the message was queued.');
                    return;
                }
            }
            $template = DB::table(WhatsAppTables::name('whatsapp_template_registry'))
                ->where('branch_id', 0)->where('waba_id', $settings->waba_id)
                ->where('name', $row->template_name)->where('language', $row->language)->first();
            if (!$template || strtoupper($template->approval_status) !== 'APPROVED' || !(int) $template->is_enabled) {
                $this->failOutbox($outboxId, 'TEMPLATE_UNAVAILABLE', 'Template is not approved and enabled at send time.');
                return;
            }
            if (!$this->hasConsent(0, $row->phone_e164, $this->consentCategory($template->category))) {
                $this->failOutbox($outboxId, 'CONSENT_MISSING', 'Recipient consent is missing, revoked, or no longer matches the template category.');
                return;
            }
            $templateData = ['name' => $row->template_name, 'language' => ['code' => $row->language ?: 'en_US']];
            $components = $row->components_json ? json_decode($row->components_json, true) : [];
            if (is_array($components) && count($components)) $templateData['components'] = $components;
            $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164), 'type' => 'template', 'template' => $templateData];
        } elseif ($row->message_type === 'text') {
            $session = DB::table(WhatsAppTables::name('whatsapp_sessions'))->where('branch_id', $row->branch_id)->where('phone_e164', $row->phone_e164)->first();
            $active = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
            if (!$active) {
                $this->failOutbox($outboxId, 'WINDOW_CLOSED', 'The 24-hour customer service window is closed. Use an approved template.');
                return;
            }
            if ($this->isOptedOut(0, $row->phone_e164)) {
                $this->failOutbox($outboxId, 'RECIPIENT_OPTOUT', 'Recipient has opted out.');
                return;
            }
            $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164), 'type' => 'text', 'text' => ['preview_url' => false, 'body' => $row->text_body]];
        } elseif (in_array($row->message_type, ['image', 'video', 'audio', 'document', 'sticker'], true)) {
            if (empty($row->media_path)) { $this->failOutbox($outboxId, 'MEDIA_MISSING', 'Queued media file is missing.'); return; }
            $path = \Illuminate\Support\Facades\Storage::disk('local')->path($row->media_path);
            if (!is_file($path) || !is_readable($path)) { $this->failOutbox($outboxId, 'MEDIA_FILE_MISSING', 'Queued media file is no longer available to the worker.'); return; }
            $mediaId = (string) ($row->uploaded_media_id ?? '');
            if ($mediaId === '') {
                $stream = fopen($path, 'r');
                try {
                    $upload = Http::withToken($token)->timeout(60)->attach('file', $stream, (string) ($row->media_filename ?: basename($path)), ['Content-Type' => (string) ($row->media_mime_type ?: 'application/octet-stream')])
                        ->post($this->graphBase($settings) . '/' . rawurlencode($settings->phone_number_id) . '/media', ['messaging_product' => 'whatsapp']);
                } finally { if (is_resource($stream)) fclose($stream); }
                $uploadJson = $upload->json();
                if (!$upload->successful() || empty($uploadJson['id'])) {
                    $error = $uploadJson['error'] ?? [];
                    $this->failOutbox($outboxId, (string) ($error['code'] ?? ('MEDIA_HTTP_' . $upload->status())), (string) ($error['message'] ?? 'Meta media upload failed.'), null, $uploadJson);
                    return;
                }
                $mediaId = (string) $uploadJson['id'];
                DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->update(['uploaded_media_id' => $mediaId, 'updated_at' => now()]);
            }
            $mediaObject = ['id' => $mediaId];
            if (!empty($row->media_caption) && in_array($row->message_type, ['image','video','document'], true)) $mediaObject['caption'] = (string) $row->media_caption;
            if ($row->message_type === 'document' && !empty($row->media_filename)) $mediaObject['filename'] = (string) $row->media_filename;
            $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164), 'type' => $row->message_type, $row->message_type => $mediaObject];
        } elseif (in_array($row->message_type, ['location', 'contacts', 'reaction', 'interactive'], true)) {
            $storedPayload = $row->payload_json ? json_decode($row->payload_json, true) : [];
            if (!is_array($storedPayload) || empty($storedPayload['type'])) { $this->failOutbox($outboxId, 'INVALID_MESSAGE_PAYLOAD', 'Interactive/location/reaction payload is invalid.'); return; }
            $payload = array_merge(['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $this->phoneDigits($row->phone_e164)], $storedPayload);
        } else {
            $this->failOutbox($outboxId, 'UNSUPPORTED_MESSAGE_TYPE', 'Unsupported message type.');
            return;
        }

        try {
            $url = $this->graphBase($settings) . '/' . rawurlencode($settings->phone_number_id) . '/messages';
            // Do not automatically retry a POST after an ambiguous timeout; it might already have been accepted by Meta.
            $response = Http::withToken($token)->acceptJson()->asJson()->timeout(25)->post($url, $payload);
            $json = $response->json();
            $messageId = $json['messages'][0]['id'] ?? null;
            if ($response->successful() && $messageId) {
                DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->update([
                    'status' => 'sent', 'meta_message_id' => $messageId,
                    'request_json' => json_encode($payload, JSON_UNESCAPED_UNICODE),
                    'response_json' => json_encode($json, JSON_UNESCAPED_UNICODE),
                    'sent_at' => now(), 'error_code' => null, 'error_message' => null, 'updated_at' => now(),
                ]);
                $this->writeLegacyChatMessage($row, $messageId);
                return;
            }
            $error = $json['error'] ?? [];
            $this->failOutbox($outboxId, (string) ($error['code'] ?? ('HTTP_' . $response->status())), (string) ($error['message'] ?? 'Meta did not accept this message.'), $payload, $json);
        } catch (\Illuminate\Http\Client\ConnectionException $e) {
            // Unknown delivery state is safer than retrying automatically and risking duplicate notifications.
            DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $outboxId)->update([
                'status' => 'unknown', 'error_code' => 'NETWORK_RESULT_UNKNOWN',
                'error_message' => 'Network timeout/error; delivery state is unknown. Check webhook/Meta status before retrying.',
                'request_json' => json_encode($payload, JSON_UNESCAPED_UNICODE), 'updated_at' => now(),
            ]);
            Log::warning('WhatsApp send result is ambiguous; automatic retry suppressed.', ['outbox_id' => $outboxId]);
        } catch (Throwable $e) {
            $this->failOutbox($outboxId, 'UNEXPECTED_EXCEPTION', 'Unexpected send failure. Check server logs.', $payload ?? null, null);
            Log::error('WhatsApp send exception', ['outbox_id' => $outboxId, 'exception' => class_basename($e)]);
        }
    }

    private function failOutbox(int $id, string $code, string $message, ?array $request = null, ?array $response = null): void
    {
        DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('id', $id)->update([
            'status' => 'failed', 'error_code' => substr($code, 0, 100), 'error_message' => mb_substr($message, 0, 2000),
            'request_json' => $request ? json_encode($request, JSON_UNESCAPED_UNICODE) : null,
            'response_json' => $response ? json_encode($response, JSON_UNESCAPED_UNICODE) : null,
            'failed_at' => now(), 'updated_at' => now(),
        ]);
    }

    private function writeLegacyChatMessage(object $outbox, string $messageId): void
    {
        try {
            app(\App\Services\WhatsAppConversationService::class)->storeOutbound($outbox, $messageId);
        } catch (Throwable $e) {
            // An accepted API send must never be turned into a failure because chat mirroring failed.
            Log::warning('WhatsApp send succeeded but conversation persistence failed.', ['outbox_id' => $outbox->id ?? null]);
        }
    }

    public function recordInboundSession(string $phone, ?string $timestamp, ?string $phoneNumberId, ?string $messageText, ?string $messageId): bool
    {
        $digits = $this->phoneDigits($phone);
        if (strlen($digits) < 8 || strlen($digits) > 15) return false;
        $normalized = '+' . $digits;
        $settings = $phoneNumberId ? DB::table(WhatsAppTables::name('whatsapp_automation_settings'))->where('phone_number_id', $phoneNumberId)->first() : null;
        if (!$settings) {
            Log::warning('Inbound WhatsApp message did not match a configured phone-number profile.');
            return false;
        }
        $branchId = 0;
        $dateTime = $timestamp ? \Carbon\Carbon::createFromTimestamp((int) $timestamp, config('app.timezone', 'UTC')) : now();
        $sessionQuery = DB::table(WhatsAppTables::name('whatsapp_sessions'))->where('branch_id', $branchId)->where('phone_e164', $normalized);
        $session = $sessionQuery->first();
        if (!$session) {
            DB::table(WhatsAppTables::name('whatsapp_sessions'))->insert([
                'branch_id' => $branchId, 'phone_e164' => $normalized,
                'last_inbound_at' => $dateTime, 'last_inbound_meta_message_id' => $messageId,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        } else {
            // Duplicate/out-of-order webhooks must not move the 24-hour window backwards.
            $sessionUpdate = ['updated_at' => now()];
            if (empty($session->last_inbound_at) || $dateTime->greaterThan(\Carbon\Carbon::parse($session->last_inbound_at))) {
                $sessionUpdate['last_inbound_at'] = $dateTime;
                $sessionUpdate['last_inbound_meta_message_id'] = $messageId;
            }
            $sessionQuery->update($sessionUpdate);
        }
        $upper = strtoupper(trim((string) $messageText));
        if (in_array($upper, ['STOP', 'STOP ALL', 'UNSUBSCRIBE', 'CANCEL', 'END', 'QUIT'], true)) {
            DB::table(WhatsAppTables::name('whatsapp_consents'))->updateOrInsert(
                ['branch_id' => $branchId, 'phone_e164' => $normalized, 'category' => 'all'],
                ['consent_status' => 'opted_out', 'source' => 'inbound_whatsapp', 'evidence_ref' => $messageId,
                    'opted_out_at' => $dateTime, 'opted_in_at' => null, 'updated_at' => now(), 'created_at' => now()]
            );
        }
        return true;
    }

    public function updateOutboxStatus(string $messageId, string $status, ?array $error = null): void
    {
        $allowed = ['sent', 'delivered', 'read', 'failed'];
        if (!in_array($status, $allowed, true)) return;
        $current = DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('meta_message_id', $messageId)->first(['id', 'status']);
        if (!$current) return;
        if (in_array($current->status, ['read', 'failed'], true)) return;
        $rank = ['queued' => 0, 'processing' => 1, 'unknown' => 1, 'sent' => 2, 'delivered' => 3, 'read' => 4, 'failed' => 5];
        if ($status !== 'failed' && ($rank[$status] ?? 0) < ($rank[$current->status] ?? 0)) return;
        $data = ['status' => $status, 'updated_at' => now()];
        if ($status === 'delivered') $data['delivered_at'] = now();
        if ($status === 'read') $data['read_at'] = now();
        if ($status === 'failed') {
            $data['failed_at'] = now();
            $data['error_code'] = isset($error['code']) ? (string) $error['code'] : 'WEBHOOK_FAILED';
            $data['error_message'] = isset($error['message']) ? mb_substr((string) $error['message'], 0, 2000) : 'Meta webhook reported a failure.';
        }
        DB::table(WhatsAppTables::name('whatsapp_outbox'))->where('meta_message_id', $messageId)->update($data);
        try { app(\App\Services\WhatsAppConversationService::class)->updateStatusByMetaId($messageId, $status, $error); } catch (Throwable $e) { Log::warning('Could not mirror WhatsApp delivery status.', ['message_id_hash' => sha1($messageId)]); }
    }

    /** Mark an inbound customer message as read using the Cloud API, without exposing credentials. */
    public function markAsRead(string $messageId): array
    {
        if (!preg_match('/^wamid\./', $messageId)) return ['ok' => false, 'message' => 'Invalid Meta message ID.'];
        $settings = $this->settingsForBranch(0);
        $token = $this->tokenForSettings($settings);
        if (!$settings || !$token || empty($settings->phone_number_id)) return ['ok' => false, 'message' => 'Shared WhatsApp API profile is not configured.'];
        try {
            $payload = ['messaging_product' => 'whatsapp', 'status' => 'read', 'message_id' => $messageId];
            $response = Http::withToken($token)->acceptJson()->asJson()->timeout(15)->post($this->graphBase($settings) . '/' . rawurlencode($settings->phone_number_id) . '/messages', $payload);
            if (!$response->successful()) return ['ok' => false, 'message' => 'Meta did not accept the read receipt.'];
            DB::table(WhatsAppTables::name('whatsapp_messages'))->where('branch_id', 0)->where('meta_message_id', $messageId)->where('direction', 'inbound')->update(['status' => 'read', 'read_at' => now(), 'updated_at' => now()]);
            return ['ok' => true];
        } catch (Throwable $e) {
            Log::notice('WhatsApp read receipt failed.', ['message_id_hash' => sha1($messageId), 'exception' => class_basename($e)]);
            return ['ok' => false, 'message' => 'Read receipt failed; the conversation itself remains available.'];
        }
    }

    public function recordConsent(array $input): array
    {
        $branchId = 0; // Consent is associated with the recipient and shared WABA, not an ERP branch.
        $category = strtolower(trim((string) ($input['category'] ?? '')));
        $source = trim((string) ($input['source'] ?? ''));
        $evidence = trim((string) ($input['evidence_ref'] ?? ''));
        $consentStatus = ($input['consent_status'] ?? 'opted_in') === 'opted_out' ? 'opted_out' : 'opted_in';
        try { $phone = $this->normalizePhone((string) ($input['phone'] ?? '')); }
        catch (\InvalidArgumentException $e) { return ['ok' => false, 'message' => $e->getMessage()]; }
        if (!in_array($category, ['all', 'marketing', 'utility', 'authentication'], true) || $source === '' || $evidence === '') {
            return ['ok' => false, 'message' => 'Supported category, consent source and evidence reference are required. Never record consent without real recipient evidence.'];
        }
        $table = WhatsAppTables::name('whatsapp_consents');
        $key = ['branch_id' => $branchId, 'phone_e164' => $phone, 'category' => $category];
        $existing = DB::table($table)->where($key)->first(['id', 'created_at']);
        $now = now();
        $values = [
            'consent_status' => $consentStatus,
            'source' => substr($source, 0, 100),
            'evidence_ref' => mb_substr($evidence, 0, 1000),
            'opted_in_at' => $consentStatus === 'opted_in' ? $now : null,
            'opted_out_at' => $consentStatus === 'opted_out' ? $now : null,
            'created_by' => isset($input['created_by']) ? (int) $input['created_by'] : null,
            'updated_by' => isset($input['created_by']) ? (int) $input['created_by'] : null,
            'updated_at' => $now,
        ];
        if ($existing) {
            DB::table($table)->where('id', $existing->id)->update($values);
        } else {
            DB::table($table)->insert(array_merge($key, $values, ['created_at' => $now]));
        }
        return ['ok' => true, 'message' => 'Consent record saved with evidence reference.'];
    }
}
