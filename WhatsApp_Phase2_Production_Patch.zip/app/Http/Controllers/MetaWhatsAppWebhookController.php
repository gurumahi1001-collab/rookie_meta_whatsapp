<?php

namespace App\Http\Controllers;

use App\Services\WhatsAppConversationService;
use App\Services\WhatsAppManagerService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/** Public Meta callback. GET verifies the callback; POST verifies HMAC before processing. */
class MetaWhatsAppWebhookController extends Controller
{
    public function handle(Request $request, WhatsAppManagerService $manager, WhatsAppConversationService $conversations)
    {
        if ($request->isMethod('GET')) {
            $query = $request->query();
            $mode = (string) ($query['hub.mode'] ?? $query['hub_mode'] ?? '');
            $token = (string) ($query['hub.verify_token'] ?? $query['hub_verify_token'] ?? '');
            $challenge = (string) ($query['hub.challenge'] ?? $query['hub_challenge'] ?? '');
            $verifyToken = (string) config('whatsapp.verify_token', '');
            if ($mode === 'subscribe' && $verifyToken !== '' && $token !== '' && hash_equals($verifyToken, $token)) {
                return response($challenge, 200)->header('Content-Type', 'text/plain');
            }
            Log::warning('Meta WhatsApp webhook verification rejected.');
            return response()->json(['error' => 'Verification failed'], 403);
        }

        if (!$request->isMethod('POST')) return response()->json(['error' => 'Method not allowed'], 405);

        $appSecret = (string) config('whatsapp.app_secret', '');
        if ($appSecret === '') {
            Log::critical('META_APP_SECRET is missing; refusing unsigned WhatsApp webhook POSTs.');
            return response()->json(['error' => 'Webhook signature validation is not configured'], 503);
        }
        $signature = (string) $request->header('X-Hub-Signature-256', '');
        $expected = 'sha256=' . hash_hmac('sha256', $request->getContent(), $appSecret);
        if ($signature === '' || !hash_equals($expected, $signature)) {
            Log::warning('Meta WhatsApp webhook signature rejected.');
            return response()->json(['error' => 'Invalid signature'], 401);
        }

        $payload = json_decode($request->getContent(), true);
        if (!is_array($payload) || empty($payload['entry']) || !is_array($payload['entry'])) {
            return response()->json(['error' => 'Invalid webhook payload'], 400);
        }

        try {
            foreach ($payload['entry'] as $entry) {
                foreach (($entry['changes'] ?? []) as $change) {
                    if (($change['field'] ?? 'messages') !== 'messages') continue;
                    $value = $change['value'] ?? [];
                    $phoneNumberId = (string) ($value['metadata']['phone_number_id'] ?? '');

                    foreach (($value['statuses'] ?? []) as $status) {
                        $messageId = (string) ($status['id'] ?? '');
                        $statusType = strtolower((string) ($status['status'] ?? ''));
                        if ($messageId !== '' && in_array($statusType, ['sent', 'delivered', 'read', 'failed'], true)) {
                            $error = $status['errors'][0] ?? null;
                            $manager->updateOutboxStatus($messageId, $statusType, is_array($error) ? $error : null);
                        }
                    }

                    $profiles = [];
                    foreach (($value['contacts'] ?? []) as $profile) {
                        $waId = preg_replace('/\D+/', '', (string) ($profile['wa_id'] ?? ''));
                        if ($waId !== '') $profiles[$waId] = (string) ($profile['profile']['name'] ?? '');
                    }

                    foreach (($value['messages'] ?? []) as $message) {
                        $from = preg_replace('/\D+/', '', (string) ($message['from'] ?? ''));
                        $messageId = (string) ($message['id'] ?? '');
                        if ($from === '' || $messageId === '' || $phoneNumberId === '') continue;
                        $phone = '+' . $from;
                        $type = strtolower((string) ($message['type'] ?? 'unknown'));
                        $text = null;
                        if ($type === 'text') $text = (string) ($message['text']['body'] ?? '');
                        elseif ($type === 'button') $text = (string) ($message['button']['text'] ?? '');
                        elseif ($type === 'interactive') $text = (string) ($message['interactive']['button_reply']['title'] ?? $message['interactive']['list_reply']['title'] ?? '');
                        $timestamp = isset($message['timestamp']) ? (string) $message['timestamp'] : null;

                        // Record the inbound timestamp first so the 24-hour session is open by the time
                        // the UI loads; STOP/UNSUBSCRIBE creates a hard all-category opt-out.
                        $sessionRecorded = $manager->recordInboundSession($phone, $timestamp, $phoneNumberId, $text, $messageId);
                        if (!$sessionRecorded) continue; // Do not persist traffic for an unconfigured WABA phone number.
                        $messageDateTime = $timestamp
                            ? \Carbon\Carbon::createFromTimestamp((int) $timestamp, config('app.timezone', 'UTC'))->toDateTimeString()
                            : now()->toDateTimeString();
                        $conversations->storeInbound(0, $phone, $profiles[$from] ?? null, $message, $messageDateTime);
                    }
                }
            }
        } catch (Throwable $exception) {
            Log::error('Meta WhatsApp webhook processing failed.', ['exception' => class_basename($exception)]);
            return response()->json(['error' => 'Webhook processing failed; Meta may retry this event.'], 500);
        }

        return response()->json(['received' => true], 200);
    }
}
