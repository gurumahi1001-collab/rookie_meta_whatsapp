# WhatsApp Management Phase 2 — deployment notes

## What this patch fixes

1. **Consent-aware automation:** `WhatsAppWorkflowDispatcher::queue()` now accepts an optional consent evidence object. It registers only the categories for which the originating form submitted an affirmative opt-in, then queues the workflow. It does not infer permission from a saved lead, an existing CRM phone field, message history, or a successful appointment save.
2. **Lead create:** the standard Add Lead form now has separate, unchecked Utility and Marketing consent checkboxes. The evidence reference includes the newly saved lead ID, accepted categories, server timestamp, user ID and one-way hashes of IP/user-agent. The record is written before `lead.created` queues.
3. **Quick Add:** existing consent is reused by the same automation key; Quick Add does not manufacture consent because its UI has no recipient opt-in control.
4. **Appointment create:** the retired hard-coded Graph API template in `ManageLeadAppointment::Add()` was removed. It uses the `appointment.created` Automation Rule and the shared sender. It is queued only if a valid consent record already covers the category of the mapped approved template; actual delivery is confirmed later by Meta webhook status.
5. **Chat composer:** the composer remains visible after a contact is selected. Outside the 24-hour window, only free-form send controls are disabled; the approved-template link remains usable.
6. **Emoji picker:** searchable, categorized emoji list instead of the original 38-symbol list.
7. **Pusher:** new real-time event uses `private-whatsapp-management.chat` and Laravel channel authorization. The legacy `NewMessage` public `chat` event is left intact so the old ERP chat pages are not silently broken by this patch.
8. **Inbound webhook:** `MetaWhatsAppWebhookController` was absent even though `routes/web.php` referenced it. This patch adds the class, verifies the Meta GET challenge and POST HMAC signature, handles inbound messages/status callbacks, opens the 24-hour session, records STOP opt-outs and writes messages into the new conversation tables.
9. **Media upload:** controller limits are type-specific: images 5 MB, audio/video 16 MB, documents up to 100 MB, and sticker upload 500 KB. Your PHP/nginx upload limits must be configured accordingly. This patch still relies on Meta rejecting any codec/container it does not support.

## Important consent rule

Do not auto-create `opted_in` consent merely because the ERP has a phone number. Meta's current Business Messaging Policy requires permission before business-initiated conversations and requires an approved template outside the 24-hour customer-service window. The new lead form checkboxes are unchecked by default and are separate by category. The standard Add Lead controller now passes the submitted categories and server-side audit evidence into the dispatcher before queueing. If the contact did not actually agree, leave them unchecked; the automation will be logged as blocked by the existing policy guard. Quick Add does not display consent controls and therefore can only reuse a consent record already on file. A person's STOP / UNSUBSCRIBE opt-out blocks sends. A subsequent explicit opt-in can re-enable only the category the person accepted; a previous, older category opt-in cannot override a later STOP.

## Automation Rules to create/confirm

In WhatsApp Management → Automation Rules, configure and enable these event keys with the correct Meta-approved template name/language/category and parameter map:

- `lead.created`
- `appointment.created`

The mapping for `appointment.created` can use these variables:

`greet_msg`, `customer_name`, `app_date`, `app_time`, `app_location`, `contact1_no`, `branch_name`, `contact_no`, `contact_email`, `header_image`, `coupon_code`, `header_1`, `body_1` … `body_9`, `button_0_1`, `button_1_1`, `appointment_id`, `appointment_number`, `lead_id`.

For lead automation, variables include:

`greet_msg`, `customer_name`, `web_link`, `branch_name`, `contact_no`, `contact_email`, `header_image`, `coupon_code`, `header_1`, `body_1` … `body_6`, `button_0_1`, `lead_id`, `lead_mobile`, `lead_email`.

The exact map must match your synced Meta template schema. Keep Utility templates mapped to Utility consent; Marketing templates require Marketing consent. No message is reported as delivered merely because it entered the queue.

## Reusable controller example

```php
$consentEvidence = null;
if ($request->boolean('whatsapp_utility_opt_in')) {
    $consentEvidence = [
        'accepted' => true,
        'categories' => ['utility'],
        'source' => 'appointment_form_checkbox',
        'evidence_ref' => json_encode([
            'appointment_id' => $appointment->sno,
            'accepted' => true,
            'accepted_at' => now('UTC')->toIso8601String(),
            'actor_id' => auth()->user()->user_id,
        ]),
    ];
}

$result = app(\App\Services\WhatsAppWorkflowDispatcher::class)->queue(
    'appointment.created',
    '+919876543210',              // Normalize from the contact's stored country code.
    ['customer_name' => $contact->name],
    'appointment.created',
    (int) $appointment->sno,
    (int) auth()->user()->user_id,
    'appointment.created:' . $appointment->sno,
    $consentEvidence             // Null unless this operation captured a real opt-in.
);
```

For a workflow that reuses previously recorded consent (for example an appointment against an already-consented lead), pass `null` as the final argument. `WhatsAppManagerService` still validates the stored consent at queue time and again in the background worker before it calls Meta.

## Pusher configuration

The frontend uses the same Pusher Channels JS pattern as the old `whatsapp_chat` view, but the new management chat subscribes to a private channel. The Pusher client script is loaded before the chat initializer so the channel can subscribe on first page load. Your existing `config/broadcasting.php` should have its Pusher connection configured with the matching app key, secret and cluster (`ap2` in the legacy view). Do not put the Pusher secret in Blade or JavaScript.

Add/confirm this in `config/whatsapp.php` (merge into the existing file; do not replace unrelated config):

```php
return [
    // keep all existing WhatsApp settings
    'admin_user_ids' => array_filter(array_map('trim', explode(',', env('WHATSAPP_ADMIN_USER_IDS', '')))),
    'verify_token' => env('WHATSAPP_VERIFY_TOKEN'),
    'app_secret' => env('META_APP_SECRET'),
];
```

Set environment values:

```dotenv
WHATSAPP_VERIFY_TOKEN=use-a-long-random-webhook-verification-token
META_APP_SECRET=your-meta-app-secret
WHATSAPP_ADMIN_USER_IDS=18,24
```

Use your actual authorized admin user IDs. The example IDs above are placeholders. Existing Phase 1 `config('whatsapp.table_prefix')` and `config('whatsapp.crm')` values must remain unchanged. If broadcasting is not configured for Pusher, the chat continues to work with AJAX refresh but real-time updates will not arrive.

## Media and PHP upload settings

The controller now accepts files up to 100 MB only for document media. Ensure `upload_max_filesize` and `post_max_size` in PHP-FPM/php.ini are at least `105M`, and nginx `client_max_body_size` is at least `105m`. Do not increase these values on a shared server without reviewing general upload/security controls. Cloud API media limits: image 5 MB; audio/video 16 MB; document 100 MB. The sticker ceiling depends on static/animated WebP requirements; current UI is not a full sticker editor.

## Deployment order (staging first)

1. Back up the live application and database.
2. Copy the included files to the exact relative paths in your Laravel project; do not replace the full ERP source tree with this overlay.
3. Merge `routes/channels.php` and `routes/web.php`; verify there is only one active public `/test_webhook` route and one `/webhook_whatsapp` route. Both point to `MetaWhatsAppWebhookController::handle` and are excluded from CSRF through the existing `VerifyCsrfToken::$except` entries.
4. Merge the shown keys into your existing `config/whatsapp.php`; never overwrite the rest of your WhatsApp config. Run `php artisan config:clear` then `php artisan config:cache`.
5. Confirm `BroadcastServiceProvider` is registered and `routes/channels.php` is loaded. Confirm `broadcasting.default=pusher` and a matching server-side Pusher key/secret/cluster.
6. Add/confirm Automation Rules keys `lead.created` and `appointment.created`. Sync templates from Meta, check APPROVED status, inspect category, enable only intentional templates, then test with a consenting internal test recipient.
7. Verify queue worker is running the `whatsapp` queue (`php artisan queue:work --queue=whatsapp,default --tries=1`). Existing process manager/supervisor must keep it alive.
8. Set PHP/nginx upload limits if you need documents up to the supported maximum.
9. Test Meta webhook GET verification and POST signature via Meta's dashboard, then send test inbound text, STOP, delivered, read and failed status callbacks.
10. Verify contact click, composer state inside/outside 24h, text, image, video, audio, document, location, contact card, emoji, Pusher live update, and approved-template fallback. Finally test the global kill switch.

## No SQL migration required for this patch

The supplied `eapl (1).sql` already contains `za_whatsapp_consents`, `za_whatsapp_contacts`, `za_whatsapp_messages`, `za_whatsapp_sessions`, `za_whatsapp_outbox` and the supporting WhatsApp tables used by this patch. No table/column change is introduced. Keep your existing table-prefix resolver; this project uses `za_` in the supplied dump. No database-wide prefix replace is performed.

## Known scope / limitations

- This implements Cloud API-supported chat functions already represented by the Phase 1 backend: text (inside 24h), image/video/audio/document media, location, contact cards, reactions, interactive messages and Flows (depending on Meta account/API eligibility and payload schema).
- It does not make Cloud API identical to the consumer WhatsApp Web app. Native WhatsApp group messaging, Channels publishing, consumer-app calls, voice/video calling, message edit/delete for everyone, and all Web-only behaviours must not be simulated as if they were Cloud API features. Your current Custom Audiences are ERP recipient lists, not WhatsApp native groups.
- Browser location sending requires HTTPS and the user to grant geolocation permission.
- Media support still depends on Meta's accepted MIME/container/codec. PHP, proxy, worker and storage limits also apply.
- This is a source overlay, not a live production certification. No full Laravel project/bootstrap, `composer.lock`, production `.env`, live DB connection, Pusher credentials or Meta test account was supplied; therefore no live request, queue run, webhook signature, browser visual test or Meta delivery receipt can be certified here.
