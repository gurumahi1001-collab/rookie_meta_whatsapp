<?php
// Merge these keys into the EXISTING config/whatsapp.php; do not overwrite the file.
return [
    'admin_user_ids' => array_filter(array_map('trim', explode(',', env('WHATSAPP_ADMIN_USER_IDS', '')))),
    'verify_token' => env('WHATSAPP_VERIFY_TOKEN'),
    'app_secret' => env('META_APP_SECRET'),
];
