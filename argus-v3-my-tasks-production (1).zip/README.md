# ARGUS V3 — Cumulative Production Baseline

Completed Core Admin modules through My Tasks:
- Survey Report / Survey Templates
- User Management
- Master Rate Schedule
- BOQ
- RFQ
- Quotation
- Projects
- Invoices
- My Tasks

## My Tasks scope
- MongoDB/Mongoose task persistence
- Dynamic task list and Kanban loading
- Server-generated task references (`TSK-YYYY-#####`)
- Active internal/admin staff validation
- Active/open project validation and project phase validation
- Draft-like task creation with editable lifecycle (`Pending`, `In Progress`, `On Hold`, `Due Date`, `Completed`)
- Server-side date, priority, status and progress validation
- Persistent assignees, timers, work logs, materials, expenses and task conversation metadata
- Safe deletion rules for active/completed work
- Task RBAC (`task:view/add/edit/delete`)
- Existing My Tasks UI and List/Kanban presentation preserved

## Vendor baseline
The vendor panel is included as the current baseline. Vendor-side implementation follows after the remaining Core Admin sequence is completed.
