import React from "react";
import { createBrowserRouter } from "react-router-dom";
import BlankLayout from "../components/Layouts/BlankLayout";
import DefaultLayout from "../components/Layouts/DefaultLayout";
import ProtectedRoute from "../auth/ProtectedRoute";
import { routes } from "./routes";

const finalRoutes = routes.map((route: any) => {
    const element =
        route.layout === "blank" ? (
            route.element
        ) : (
            <ProtectedRoute
                allowedUserTypes={
                    Array.isArray(route.auth)
                        ? route.auth
                        : [route.auth || "admin"]
                }
            >
                {route.element}
            </ProtectedRoute>
        );

    return {
        ...route,
        element:
            route.layout === "blank" ? (
                <BlankLayout>{element}</BlankLayout>
            ) : (
                <DefaultLayout>{element}</DefaultLayout>
            ),
    };
});

const router = createBrowserRouter(finalRoutes);

export default router;
