export type BOQStatus = "draft" | "locked";

export interface BOQVendor {
    vendorId: string;
    id: string;
    name: string;
}

export interface BOQLineRecord {
    id: string;
    rateItemId?: string | null;
    rateCode?: string;
    customItemFlag?: boolean;
    categoryType: string;
    category: string;
    module: string;
    description: string;
    unit: string;
    quantity: number;
    rate: number;
    lineTotal: number;
    sortOrder: number;
}

export interface BOQRecord {
    id: string;
    title: string;
    reference: string;
    boqDate: string;
    responseDueDate: string;
    projectSiteLocation: string;
    projectValue: number;
    currency: string;
    siteSurveyReference: string;
    formTemplate: {
        templateId?: string | null;
        name: string;
    };
    vendors: BOQVendor[];
    subtotal: number;
    contingencyPercentage: number;
    contingencyAmount: number;
    grandTotal: number;
    itemCount: number;
    status: BOQStatus;
    lockedAt?: string | null;
    lockedBy?: string | null;
    createdBy?: string | null;
    updatedBy?: string | null;
    createdAt?: string | null;
    updatedAt?: string | null;
    lines?: BOQLineRecord[];
}

export interface BOQPayload {
    reference?: string;
    title: string;
    boqDate?: string;
    responseDueDate?: string;
    projectSiteLocation?: string;
    projectValue?: number;
    currency?: string;
    siteSurveyReference?: string;
    formTemplateId?: string | null;
    formTemplateName?: string;
    vendors?: Array<{ vendorId: string; name?: string }>;
    lines: Array<{
        rateItemId?: string | null;
        rateCode?: string;
        customItemFlag?: boolean;
        categoryType?: string;
        category?: string;
        module?: string;
        description: string;
        unit: string;
        quantity: number;
        rate: number;
        sortOrder?: number;
    }>;
}
