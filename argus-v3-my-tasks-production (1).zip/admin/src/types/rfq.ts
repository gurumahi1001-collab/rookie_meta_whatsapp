export type RFQStatus = "draft" | "sent" | "closed" | "cancelled";
export type RFQVendorStatus = "pending" | "invited" | "submitted" | "declined";

export interface RFQVendor {
  id: string;
  name: string;
  email: string;
  contactName: string;
  inviteStatus: RFQVendorStatus;
  invitedAt?: string | null;
  respondedAt?: string | null;
}

export interface RFQRecord {
  id: string;
  reference: string;
  title: string;
  description: string;
  boq: { id: string; reference: string; title: string };
  surveyTemplate: { id: string; name: string; version: number };
  issueDate: string;
  responseDueDate: string;
  currency: string;
  vendors: RFQVendor[];
  terms: string;
  internalNotes: string;
  status: RFQStatus;
  sentAt?: string | null;
  closedAt?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface RFQPayload {
  title: string;
  description?: string;
  boqId: string;
  surveyTemplateId?: string;
  issueDate: string;
  responseDueDate: string;
  currency: string;
  vendorIds: string[];
  terms?: string;
  internalNotes?: string;
  reference?: string;
}
