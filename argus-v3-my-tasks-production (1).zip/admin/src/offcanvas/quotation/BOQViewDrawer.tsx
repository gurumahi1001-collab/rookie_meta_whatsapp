import { XIcon, PencilSimpleIcon, LockSimpleIcon, FileTextIcon } from "@phosphor-icons/react";
import type { BOQRecord } from "../../types/boq";

interface BOQViewDrawerProps {
    isOpen: boolean;
    boq: BOQRecord | null;
    onClose: () => void;
    onEdit?: () => void;
}

function formatCurrency(value: number, currency: string) {
    return `${currency} ${Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    })}`;
}

export default function BOQViewDrawer({ isOpen, boq, onClose, onEdit }: BOQViewDrawerProps) {
    if (!isOpen || !boq) return null;

    return (
        <div className="fixed inset-0 z-[9998] flex justify-end bg-slate-950/30 backdrop-blur-[1px]">
            <button type="button" aria-label="Close BOQ drawer" onClick={onClose} className="absolute inset-0 cursor-default" />
            <aside className="relative z-10 flex h-full w-full max-w-3xl flex-col bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                    <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50 text-red-600">
                            <FileTextIcon size={18} weight="duotone" />
                        </div>
                        <div>
                            <div className="flex items-center gap-2">
                                <h2 className="text-sm font-bold text-slate-900">{boq.reference}</h2>
                                <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${boq.status === "locked" ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-600"}`}>
                                    {boq.status === "locked" ? "Locked" : "Draft"}
                                </span>
                            </div>
                            <p className="mt-0.5 text-[10px] text-slate-400">{boq.title}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-1">
                        {onEdit && boq.status === "draft" && (
                            <button type="button" onClick={onEdit} className="flex h-8 items-center gap-1.5 rounded-md border border-amber-200 bg-amber-50 px-3 text-[10px] font-bold text-amber-700 hover:bg-amber-100">
                                <PencilSimpleIcon size={13} weight="bold" /> Edit
                            </button>
                        )}
                        <button type="button" onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-700">
                            <XIcon size={16} weight="bold" />
                        </button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-5">
                    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                        {[
                            ["Project Value", formatCurrency(boq.projectValue, boq.currency)],
                            ["BOQ Total", formatCurrency(boq.grandTotal, boq.currency)],
                            ["Line Items", String(boq.itemCount)],
                            ["Due Date", boq.responseDueDate || "-"],
                        ].map(([label, value]) => (
                            <div key={label} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                                <p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">{label}</p>
                                <p className="mt-1 text-xs font-bold text-slate-900">{value}</p>
                            </div>
                        ))}
                    </div>

                    <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div className="rounded-xl border border-slate-200 p-4">
                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Project Details</p>
                            <dl className="mt-3 space-y-2.5 text-[11px]">
                                <div className="flex justify-between gap-3"><dt className="text-slate-400">Site</dt><dd className="text-right font-semibold text-slate-700">{boq.projectSiteLocation || "-"}</dd></div>
                                <div className="flex justify-between gap-3"><dt className="text-slate-400">Survey Ref</dt><dd className="text-right font-semibold text-slate-700">{boq.siteSurveyReference || "-"}</dd></div>
                                <div className="flex justify-between gap-3"><dt className="text-slate-400">Form Template</dt><dd className="text-right font-semibold text-slate-700">{boq.formTemplate?.name || "-"}</dd></div>
                                <div className="flex justify-between gap-3"><dt className="text-slate-400">Contingency</dt><dd className="text-right font-semibold text-slate-700">{boq.contingencyPercentage}% ({formatCurrency(boq.contingencyAmount, boq.currency)})</dd></div>
                            </dl>
                        </div>
                        <div className="rounded-xl border border-slate-200 p-4">
                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Assigned Vendors</p>
                            <div className="mt-3 space-y-2">
                                {boq.vendors.length ? boq.vendors.map((vendor) => (
                                    <div key={vendor.vendorId} className="rounded-lg bg-slate-50 px-3 py-2 text-[10px] font-semibold text-slate-700">{vendor.name}</div>
                                )) : <p className="text-[10px] text-slate-400">No vendors assigned.</p>}
                            </div>
                        </div>
                    </div>

                    <div className="mt-5 overflow-hidden rounded-xl border border-slate-200">
                        <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">BOQ Lines</p>
                                    <p className="mt-0.5 text-[10px] text-slate-500">Saved line-item snapshot used for the BOQ total.</p>
                                </div>
                                {boq.status === "locked" && <LockSimpleIcon size={14} className="text-emerald-500" />}
                            </div>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full min-w-[780px] border-collapse">
                                <thead>
                                    <tr className="border-b border-slate-200 bg-white">
                                        {['#', 'Module', 'Category', 'Description', 'Unit', 'Qty', 'Rate', 'Total'].map((label) => <th key={label} className="px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">{label}</th>)}
                                    </tr>
                                </thead>
                                <tbody>
                                    {(boq.lines || []).map((line, index) => (
                                        <tr key={line.id} className="border-b border-slate-100 last:border-b-0">
                                            <td className="px-3 py-2 text-[9px] text-slate-400">{index + 1}</td>
                                            <td className="px-3 py-2 text-[10px] font-semibold text-slate-700">{line.module || "-"}</td>
                                            <td className="px-3 py-2 text-[10px] text-slate-600">{line.category || "-"}</td>
                                            <td className="px-3 py-2 text-[10px] text-slate-700">{line.description}</td>
                                            <td className="px-3 py-2 text-[10px] text-slate-600">{line.unit}</td>
                                            <td className="px-3 py-2 text-[10px] font-semibold text-slate-700">{line.quantity}</td>
                                            <td className="px-3 py-2 text-[10px] font-semibold text-slate-700">{formatCurrency(line.rate, boq.currency)}</td>
                                            <td className="px-3 py-2 text-[10px] font-bold text-slate-900">{formatCurrency(line.lineTotal, boq.currency)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
    );
}
