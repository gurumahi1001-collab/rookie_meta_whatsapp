import { useEffect, useMemo, useState } from "react";
import {
    MagnifyingGlassIcon,
    PlusIcon,
} from "@phosphor-icons/react";
import Select, { MultiValue } from "react-select";

import OffCanvas from "../../components/OffCanvas";
import { RateItem } from "../../types/rateSchedule";
import api from "../../api/axios";

interface BrowseAddRateProps {
    isOpen: boolean;
    onClose: () => void;
    onAddRates: (rateItems: RateItem[]) => void;
}

interface ModuleOption {
    code: string;
    module: string;
    description: string;
}

interface CategoryOption {
    value: string;
    label: string;
}

const BrowseAddRate = ({
    isOpen,
    onClose,
    onAddRates,
}: BrowseAddRateProps) => {
    const [search, setSearch] = useState("");
    const [selectedCategories, setSelectedCategories] = useState<CategoryOption[]>([]);
    const [selectedRateIds, setSelectedRateIds] = useState<string[]>([]);
    const [activeRates, setActiveRates] = useState<RateItem[]>([]);
    const [loading, setLoading] = useState(false);
    const [loadError, setLoadError] = useState("");

    useEffect(() => {
        if (!isOpen) return;
        let cancelled = false;

        const loadActiveRates = async () => {
            setLoading(true);
            setLoadError("");
            try {
                const response = await api.get<{
                    success?: boolean;
                    message?: string;
                    data?: RateItem[];
                }>("/master-rates/active");

                if (response.data?.success === false) {
                    throw new Error(response.data.message || "Unable to load active master rates.");
                }

                const rows = Array.isArray(response.data?.data)
                    ? response.data.data.filter((rate) => rate && String(rate.code || "").trim())
                    : [];

                if (!cancelled) {
                    setActiveRates(rows);
                    setSelectedRateIds([]);
                }
            } catch (error) {
                if (!cancelled) {
                    setActiveRates([]);
                    setSelectedRateIds([]);
                    setLoadError(
                        (error as { response?: { data?: { message?: string } }; message?: string })?.response?.data?.message
                            || (error as { message?: string })?.message
                            || "Unable to load active master rates.",
                    );
                }
            } finally {
                if (!cancelled) setLoading(false);
            }
        };

        void loadActiveRates();
        return () => { cancelled = true; };
    }, [isOpen]);

    const categoryOptions = useMemo<CategoryOption[]>(() => {
        const values = Array.from(new Set(
            activeRates
                .map((rate) => String(rate.category || "").trim())
                .filter(Boolean),
        ));
        return values.map((value) => ({ value, label: value }));
    }, [activeRates]);

    const filteredModules = useMemo<ModuleOption[]>(() => {
        const searchValue = search.trim().toLowerCase();
        const selectedCategoryValues = selectedCategories.map((category) => category.value);

        return activeRates
            .map((rate) => ({
                rate,
                code: String(rate.code || "").trim(),
                module: String(rate.module || "").trim() || String(rate.subcategory || "").trim() || "-",
                description: String(rate.description || "").trim() || "-",
            }))
            .filter(({ rate, code, module, description }) => {
                if (!code) return false;
                const matchesCategory =
                    selectedCategoryValues.length === 0
                    || selectedCategoryValues.includes(String(rate.category || ""));
                const searchable = [
                    code,
                    module,
                    description,
                    String(rate.category || ""),
                    String(rate.categoryType || ""),
                    String(rate.unit || ""),
                ].join(" ").toLowerCase();
                return matchesCategory && (!searchValue || searchable.includes(searchValue));
            })
            .map(({ code, module, description }) => ({ code, module, description }));
    }, [activeRates, search, selectedCategories]);

    const toggleRate = (rateId: string) => {
        setSelectedRateIds((current) =>
            current.includes(rateId)
                ? current.filter((id) => id !== rateId)
                : [...current, rateId],
        );
    };

    const toggleSelectAll = () => {
        const visibleIds = filteredModules.map((item) => item.code);
        if (!visibleIds.length) return;
        const allSelected = visibleIds.every((id) => selectedRateIds.includes(id));
        setSelectedRateIds((current) =>
            allSelected
                ? current.filter((id) => !visibleIds.includes(id))
                : [...new Set([...current, ...visibleIds])],
        );
    };

    const handleAddRates = () => {
        if (!selectedRateIds.length) return;

        const selectedRates = selectedRateIds
            .map((rateId) => activeRates.find((rate) => String(rate.code) === rateId))
            .filter((rate): rate is RateItem => Boolean(rate))
            .map((rate) => ({
                ...rate,
                module: String(rate.module || "").trim() || String(rate.subcategory || "").trim() || "",
                description: String(rate.description || "").trim(),
            }));

        if (!selectedRates.length) return;
        onAddRates(selectedRates);
        setSelectedRateIds([]);
        setSearch("");
        setSelectedCategories([]);
        onClose();
    };

    const clearSelection = () => setSelectedRateIds([]);
    const resetFilters = () => {
        setSearch("");
        setSelectedCategories([]);
    };

    const allVisibleSelected =
        filteredModules.length > 0 &&
        filteredModules.every((item) => selectedRateIds.includes(item.code));

        return (
            <OffCanvas
                isOpen={isOpen}
                onClose={onClose}
                title="Select Master Rate Item"
                subtitle="Browse and add items from the master rate schedule"
                widthClass="max-w-xl"
                footer={
                    <div className="flex items-center justify-between gap-4">
                        <div className="min-w-0">
                            <p className="text-[10px] font-semibold text-slate-500">
                                {selectedRateIds.length}{" "}
                                {selectedRateIds.length === 1
                                    ? "item"
                                    : "items"}{" "}
                                selected
                            </p>

                            <p className="mt-0.5 text-[9px] text-slate-400">
                                Select one or more master rate items.
                            </p>
                        </div>

                        <div className="flex shrink-0 items-center gap-2">
                            <button
                                type="button"
                                onClick={onClose}
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                disabled={
                                    selectedRateIds.length === 0
                                }
                                onClick={handleAddRates}
                                className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                            >
                                <PlusIcon
                                    size={14}
                                    weight="bold"
                                />
                                Add Selected Rates
                            </button>
                        </div>
                    </div>
                }
            >
                <div className="space-y-5">
                    <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                        <div className="space-y-4">
                            <div>
                                <p className="mb-2 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                    Search
                                </p>

                                <div className="relative">
                                    <MagnifyingGlassIcon
                                        size={16}
                                        className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                                    />

                                    <input
                                        type="text"
                                        value={search}
                                        onChange={(e) =>
                                            setSearch(
                                                e.target.value
                                            )
                                        }
                                        placeholder="Search modules or descriptions..."
                                        className="h-10 w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                    />
                                </div>
                            </div>

                            <div>
                                <div className="mb-2 flex items-center justify-between">
                                    <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                        Category
                                    </p>

                                    {selectedCategories.length > 0 && (
                                        <button
                                            type="button"
                                            onClick={() =>
                                                setSelectedCategories(
                                                    []
                                                )
                                            }
                                            className="text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                                        >
                                            Clear
                                        </button>
                                    )}
                                </div>

                                <Select<CategoryOption, true>
                                    isMulti
                                    options={categoryOptions}
                                    value={selectedCategories}
                                    onChange={(
                                        options: MultiValue<CategoryOption>
                                    ) => {
                                        setSelectedCategories(
                                            [...options]
                                        );
                                    }}
                                    placeholder="Select categories..."
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    isSearchable
                                    styles={{
                                        control: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            minHeight: "40px",
                                            borderRadius: "8px",
                                            borderColor:
                                                state.isFocused
                                                    ? "#f87171"
                                                    : "#e2e8f0",
                                            boxShadow:
                                                state.isFocused
                                                    ? "0 0 0 2px rgba(254, 226, 226, 1)"
                                                    : "none",
                                            backgroundColor:
                                                "#ffffff",
                                            "&:hover": {
                                                borderColor:
                                                    "#f87171",
                                            },
                                        }),

                                        valueContainer: (
                                            base
                                        ) => ({
                                            ...base,
                                            padding: "2px 8px",
                                        }),

                                        input: (base) => ({
                                            ...base,
                                            fontSize: "12px",
                                            color: "#334155",
                                        }),

                                        placeholder: (
                                            base
                                        ) => ({
                                            ...base,
                                            fontSize: "12px",
                                            color: "#94a3b8",
                                        }),

                                        multiValue: (
                                            base
                                        ) => ({
                                            ...base,
                                            backgroundColor:
                                                "#fef2f2",
                                            borderRadius: "6px",
                                        }),

                                        multiValueLabel: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#b91c1c",
                                            fontSize: "10px",
                                            fontWeight: 600,
                                            padding: "3px 6px",
                                        }),

                                        multiValueRemove: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#b91c1c",
                                            borderRadius:
                                                "0 6px 6px 0",
                                            ":hover": {
                                                backgroundColor:
                                                    "#fee2e2",
                                                color: "#991b1b",
                                            },
                                        }),

                                        menu: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                            borderRadius: "8px",
                                            overflow: "hidden",
                                        }),

                                        option: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            fontSize: "11px",
                                            padding: "9px 12px",
                                            backgroundColor:
                                                state.isSelected
                                                    ? "#fee2e2"
                                                    : state.isFocused
                                                    ? "#f8fafc"
                                                    : "#ffffff",
                                            color:
                                                state.isSelected
                                                    ? "#b91c1c"
                                                    : "#334155",
                                            cursor: "pointer",
                                        }),

                                        indicatorSeparator: (
                                            base
                                        ) => ({
                                            ...base,
                                            backgroundColor:
                                                "#e2e8f0",
                                        }),

                                        dropdownIndicator: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            color:
                                                state.isFocused
                                                    ? "#dc2626"
                                                    : "#94a3b8",
                                            ":hover": {
                                                color: "#dc2626",
                                            },
                                        }),

                                        clearIndicator: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#94a3b8",
                                            ":hover": {
                                                color: "#dc2626",
                                            },
                                        }),
                                    }}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                        <div className="grid grid-cols-[40px_180px_minmax(0,1fr)] items-center border-b border-slate-200 bg-slate-50 px-4 py-3">
                            <div className="flex items-center">
                                <input
                                    type="checkbox"
                                    checked={allVisibleSelected}
                                    onChange={toggleSelectAll}
                                    className="h-3.5 w-3.5 accent-red-600"
                                />
                            </div>

                            <div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                Module
                            </div>

                            <div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                Description
                            </div>
                        </div>

                        {loading ? (
                            <div className="px-6 py-16 text-center">
                                <p className="text-xs font-semibold text-slate-500">Loading active master rates...</p>
                            </div>
                        ) : loadError ? (
                            <div className="px-6 py-16 text-center">
                                <p className="text-xs font-semibold text-red-600">{loadError}</p>
                                <p className="mt-1 text-[10px] text-slate-400">Check the master rate service and try again.</p>
                            </div>
                        ) : filteredModules.length === 0 ? (
                            <div className="px-6 py-16 text-center">
                                <p className="text-xs font-semibold text-slate-500">
                                    No master rate items found.
                                </p>

                                <p className="mt-1 text-[10px] text-slate-400">
                                    Try changing your search or category filters.
                                </p>

                                <button
                                    type="button"
                                    onClick={resetFilters}
                                    className="mt-3 text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                                >
                                    Reset Filters
                                </button>
                            </div>
                        ) : (
                            <div>
                                {filteredModules.map(
                                    (item) => {
                                        const selected =
                                            selectedRateIds.includes(
                                                item.code
                                            );

                                        const rate = activeRates.find(
                                            (rateItem) => String(rateItem.code) === item.code
                                        );

                                        return (
                                            <div
                                                key={item.code}
                                                onClick={() =>
                                                    toggleRate(
                                                        item.code
                                                    )
                                                }
                                                className={`grid cursor-pointer grid-cols-[40px_180px_minmax(0,1fr)] items-center border-b border-slate-100 px-4 py-3 transition last:border-b-0 ${
                                                    selected
                                                        ? "bg-red-50/60"
                                                        : "hover:bg-slate-50"
                                                }`}
                                            >
                                                <div className="flex items-center">
                                                    <input
                                                        type="checkbox"
                                                        checked={
                                                            selected
                                                        }
                                                        onChange={() =>
                                                            toggleRate(
                                                                item.code
                                                            )
                                                        }
                                                        onClick={(
                                                            e
                                                        ) =>
                                                            e.stopPropagation()
                                                        }
                                                        className="h-3.5 w-3.5 accent-red-600"
                                                    />
                                                </div>

                                                <div className="min-w-0 pr-4">
                                                    <span className="inline-flex max-w-full truncate rounded-md bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-600">
                                                        {
                                                            item.module
                                                        }
                                                    </span>
                                                </div>

                                                <div className="min-w-0">
                                                    <p className="text-[11px] font-medium leading-5 text-slate-700">
                                                        {
                                                            item.description
                                                        }
                                                    </p>

                                                    {rate && (
                                                        <div className="mt-1 flex items-center gap-2">
                                                            <span className="text-[9px] text-slate-400">
                                                                {
                                                                    rate.code
                                                                }
                                                            </span>

                                                            <span className="text-[9px] text-slate-300">
                                                                •
                                                            </span>

                                                            <span className="text-[9px] text-slate-400">
                                                                {
                                                                    rate.unit
                                                                }
                                                            </span>

                                                            <span className="text-[9px] text-slate-300">
                                                                •
                                                            </span>

                                                            <span className="text-[9px] font-semibold text-slate-500">
                                                                J${" "}
                                                                {Number(
                                                                    rate.standardRate ??
                                                                        rate.rate ??
                                                                        0
                                                                ).toLocaleString(
                                                                    "en-US",
                                                                    {
                                                                        minimumFractionDigits: 2,
                                                                        maximumFractionDigits: 2,
                                                                    }
                                                                )}
                                                            </span>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    }
                                )}
                            </div>
                        )}
                    </div>

                    <div className="flex items-center justify-between">
                        <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                            {filteredModules.length}{" "}
                            {filteredModules.length === 1
                                ? "module"
                                : "modules"}{" "}
                            available
                        </p>

                        {selectedRateIds.length > 0 && (
                            <button
                                type="button"
                                onClick={clearSelection}
                                className="text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                            >
                                Clear Selection
                            </button>
                        )}
                    </div>
                </div>
            </OffCanvas>
        );
    };

    export default BrowseAddRate;
