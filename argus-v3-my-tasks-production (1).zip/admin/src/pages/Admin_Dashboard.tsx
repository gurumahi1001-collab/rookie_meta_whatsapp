import Summary from "../components/admin_dashboard/summary";

const Dashboard = () => {
    return <Summary />;
};

export default Dashboard;
