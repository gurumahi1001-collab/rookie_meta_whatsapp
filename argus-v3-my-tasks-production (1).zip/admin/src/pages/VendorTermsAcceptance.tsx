import { useEffect, useRef, useState } from "react";
import { CheckIcon, EraserIcon, FileTextIcon } from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../auth/AuthProvider";
import logo from "../assets/img/logo.png";
// import { useAuth } from "../auth/AuthProvider";

interface TermsData {
    id: string;
    title: string;
    content: string;
    updatedAt?: string | null;
}

export default function VendorTermsAcceptance() {
    const navigate = useNavigate();
    const { reloadSession, signOut } = useAuth();
    // const { signOut } = useAuth();
    const canvasRef = useRef<HTMLCanvasElement | null>(null);

    const [terms, setTerms] = useState<TermsData | null>(null);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [accepted, setAccepted] = useState(false);
    const [signerName, setSignerName] = useState("");
    const [hasSignature, setHasSignature] = useState(false);
    const [drawing, setDrawing] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        let mounted = true;

        const load = async () => {
            setLoading(true);
            setError("");

            try {
                const response = await api.get("/vendor-portal/terms");

                if (
                    response.data?.success !== true ||
                    !response.data?.data
                ) {
                    throw new Error(
                        response.data?.message ||
                            "Unable to load Telecom Terms & Conditions.",
                    );
                }

                if (mounted) {
                    setTerms(response.data.data);
                }
            } catch (requestError: any) {
                if (mounted) {
                    setError(
                        requestError?.response?.data?.message ||
                            requestError?.message ||
                            "Unable to load Telecom Terms & Conditions.",
                    );
                }
            } finally {
                if (mounted) {
                    setLoading(false);
                }
            }
        };

        void load();

        return () => {
            mounted = false;
        };
    }, []);

    const coordinates = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>,
    ) => {
        const canvas = canvasRef.current;
        if (!canvas) return { x: 0, y: 0 };

        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;

        if ("touches" in event) {
            const touch = event.touches[0];
            return {
                x: (touch.clientX - rect.left) * scaleX,
                y: (touch.clientY - rect.top) * scaleY,
            };
        }

        return {
            x: (event.clientX - rect.left) * scaleX,
            y: (event.clientY - rect.top) * scaleY,
        };
    };

    const startDrawing = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>,
    ) => {
        event.preventDefault();
        const canvas = canvasRef.current;
        const context = canvas?.getContext("2d");
        if (!canvas || !context) return;

        const { x, y } = coordinates(event);
        context.beginPath();
        context.moveTo(x, y);
        context.lineWidth = 2;
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = "#0f172a";
        setDrawing(true);
    };

    const draw = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>,
    ) => {
        if (!drawing) return;
        event.preventDefault();

        const canvas = canvasRef.current;
        const context = canvas?.getContext("2d");
        if (!canvas || !context) return;

        const { x, y } = coordinates(event);
        context.lineTo(x, y);
        context.stroke();
        setHasSignature(true);
    };

    const clearSignature = () => {
        const canvas = canvasRef.current;
        const context = canvas?.getContext("2d");
        if (!canvas || !context) return;

        context.clearRect(0, 0, canvas.width, canvas.height);
        setHasSignature(false);
    };

    const submit = async () => {
        setError("");

        if (!accepted) {
            setError("Please accept the Telecom Terms & Conditions.");
            return;
        }

        if (!signerName.trim()) {
            setError("Signer name is required.");
            return;
        }

        if (!hasSignature) {
            setError("Please provide your electronic signature.");
            return;
        }

        const signature = canvasRef.current?.toDataURL("image/png");
        if (!signature) {
            setError("Unable to capture your electronic signature.");
            return;
        }

        setSubmitting(true);

        try {
            const response = await api.post("/vendor-portal/terms/accept", {
                signerName: signerName.trim(),
                signature,
            });

            if (response.data?.success !== true) {
                throw new Error(
                    response.data?.message ||
                        "Unable to record Terms & Conditions acceptance.",
                );
            }

            const sessionLoaded = await reloadSession();
            if (!sessionLoaded) {
                throw new Error("Unable to refresh the vendor session after accepting the Terms & Conditions.");
            }

            navigate("/vendor_dashboard", { replace: true });
        } catch (requestError: any) {
            setError(
                requestError?.response?.data?.message ||
                    requestError?.message ||
                    "Unable to complete Terms & Conditions acceptance.",
            );
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#F5F7FA] px-4 py-8 sm:px-6">
            <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-4xl flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
                <div className="flex items-center gap-3 border-b border-slate-200 px-6 py-5">
                    <img src={logo} alt="Argus" className="h-10 w-auto" />
                    <div>
                        <div className="text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-400">
                            Vendor Portal
                        </div>
                        <h1 className="mt-1 text-xl font-bold text-[#0F1E3D]">
                            Telecom Terms &amp; Conditions
                        </h1>
                    </div>
                </div>

                <div className="min-h-0 flex-1 overflow-y-auto px-6 py-6">
                    {loading ? (
                        <div className="flex min-h-[300px] items-center justify-center text-sm text-slate-500">
                            Loading Terms &amp; Conditions…
                        </div>
                    ) : error && !terms ? (
                        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                            {error}
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {error && (
                                <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                                    {error}
                                </div>
                            )}

                            <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
                                <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                                    <FileTextIcon size={18} />
                                    {terms?.title || "Telecom Terms & Conditions"}
                                </div>
                                {terms?.updatedAt && (
                                    <p className="mt-1 text-xs text-slate-500">
                                        Current version updated{" "}
                                        {new Date(terms.updatedAt).toLocaleString()}
                                    </p>
                                )}
                            </div>

                            <div
                                className="prose prose-sm max-w-none rounded-xl border border-slate-200 bg-white p-5 text-slate-700"
                                dangerouslySetInnerHTML={{
                                    __html: terms?.content || "",
                                }}
                            />

                            <label className="flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
                                <input
                                    type="checkbox"
                                    checked={accepted}
                                    onChange={(event) =>
                                        setAccepted(event.target.checked)
                                    }
                                    className="mt-1 h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600"
                                />
                                <span className="text-sm leading-6 text-slate-700">
                                    I have read, understood, and agree to the current Telecom Terms &amp; Conditions.
                                </span>
                            </label>

                            <div>
                                <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                                    Signer Name
                                </label>
                                <input
                                    value={signerName}
                                    onChange={(event) =>
                                        setSignerName(event.target.value)
                                    }
                                    placeholder="Enter your full name"
                                    className="w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm text-slate-700 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                                />
                            </div>

                            <div>
                                <div className="mb-1.5 flex items-center justify-between gap-2">
                                    <label className="text-sm font-semibold text-slate-700">
                                        Electronic Signature
                                    </label>

                                    <button
                                        type="button"
                                        onClick={clearSignature}
                                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition hover:text-slate-800"
                                    >
                                        <EraserIcon size={15} />
                                        Clear
                                    </button>
                                </div>

                                <canvas
                                    ref={canvasRef}
                                    width={1200}
                                    height={220}
                                    className="h-44 w-full touch-none rounded-xl border border-dashed border-slate-300 bg-white"
                                    onMouseDown={startDrawing}
                                    onMouseMove={draw}
                                    onMouseUp={() => setDrawing(false)}
                                    onMouseLeave={() => setDrawing(false)}
                                    onTouchStart={startDrawing}
                                    onTouchMove={draw}
                                    onTouchEnd={() => setDrawing(false)}
                                />
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex items-center justify-end gap-3 border-t border-slate-200 px-6 py-4">
                    <button
                        type="button"
                        onClick={() => void signOut()}
                        className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                    >
                        Decline
                    </button>

                    <button
                        type="button"
                        onClick={submit}
                        disabled={
                            loading ||
                            submitting ||
                            !accepted ||
                            !signerName.trim() ||
                            !hasSignature
                        }
                        className="inline-flex items-center gap-2 rounded-xl bg-[#123A8F] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#0F2F73] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <CheckIcon size={17} />
                        {submitting ? "Saving…" : "Accept & Continue"}
                    </button>
                </div>
            </div>
        </div>
    );
}
