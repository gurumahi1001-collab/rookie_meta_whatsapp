import React, {
    useCallback,
    useEffect,
    useRef,
    useState,
} from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
    BuildingsIcon,
    CheckCircleIcon,
    FloppyDiskBackIcon,
    InfoIcon,
    UploadSimpleIcon,
    XCircleIcon,
} from "@phosphor-icons/react";

import Field from "../../components/Field";
import Button from "../../components/Button";
import { getInputClass } from "../../utils/inputCls";
import api from "../../api/axios";

/*
|--------------------------------------------------------------------------
| Types
|--------------------------------------------------------------------------
*/

interface CompanyFileMetadata {
    originalName?: string;
    storageKey?: string;
    relativePath?: string;
    mimeType?: string;
    extension?: string;
    size?: number;
    checksum?: string;
    uploadedAt?: string;
    uploadedBy?: string;
}

interface CompanyProfile {
    legalName?: string;
    taxId?: string;
    contactEmail?: string;
    supportPhone?: string;
    headquartersAddress?: string;
    companyName?: string;
    taxNumber?: string;
    email?: string;
    phone?: string;
    address?: string;
    logo?: CompanyFileMetadata | null;
    favicon?: CompanyFileMetadata | null;
    active?: boolean;
}

interface CompanyFormValues {
    companyName: string;
    taxNumber: string;
    email: string;
    phone: string;
    address: string;
}

interface UploadState {
    file: File | null;
    previewUrl: string | null;
    uploading: boolean;
    removing: boolean;
    error: string | null;
}

interface ToastState {
    type: "success" | "error" | "warning" | null;
    message: string;
}

/* Constants */

const API_BASE = String(api.defaults.baseURL || "").replace(/\/+$/, "");
const COMPANY_INITIALIZE_ENDPOINT = "/settings/company";
const COMPANY_LOGO_ENDPOINT = "/settings/company/logo";
const COMPANY_FAVICON_ENDPOINT = "/settings/company/favicon";
const COMPANY_LOGO_DOWNLOAD_ENDPOINT = "/settings/company/logo/download";
const COMPANY_FAVICON_DOWNLOAD_ENDPOINT = "/settings/company/favicon/download";

const ACCEPTED_LOGO_TYPES = [
    "image/png",
    "image/jpeg",
    "image/webp",
];

const ACCEPTED_FAVICON_TYPES = [
    "image/png",
    "image/x-icon",
    "image/vnd.microsoft.icon",
    "image/svg+xml",
];

const MAX_LOGO_SIZE = 5 * 1024 * 1024;
const MAX_FAVICON_SIZE = 2 * 1024 * 1024;

const INITIAL_FORM: CompanyFormValues = {
    companyName: "",
    taxNumber: "",
    email: "",
    phone: "",
    address: "",
};

/* Validation */

const companySchema = Yup.object({
    companyName: Yup.string()
        .trim()
        .max(200,"Company legal name cannot exceed 200 characters",)
        .required("Legal Company Name is required"),

    taxNumber: Yup.string()
        .trim()
        .max(100, "Tax/VAT number cannot exceed 100 characters",)
        .required("Tax/VAT number is required"),

    email: Yup.string()
        .trim()
        .email("Enter a valid email address")
        .max(255,"Email cannot exceed 255 characters",)
        .required("Email is required"),

    phone: Yup.string()
        .trim()
        .max(50, "Phone number cannot exceed 50 characters",)
        .nullable(),

    address: Yup.string()
        .trim()
        .max(1000, "Address cannot exceed 1000 characters",)
        .required("Headquarters Address is required"),
});

/* Helpers */

/**
 * Extract the actual payload from common API response formats.
 *
 * Supports:
 *   { success: true, data: {...} }
 *   { status: 200, data: {...} }
 *   { data: {...} }
 */
function extractPayload<T = unknown>(
    response: any,
): T {
    const payload = response?.data;

    if (
        payload &&
        typeof payload === "object" &&
        Object.prototype.hasOwnProperty.call(
            payload,
            "data",
        )
    ) {
        return payload.data as T;
    }

    return payload as T;
}

function extractCompanyProfile(
    response: any,
): CompanyProfile | null {
    const payload =
        extractPayload<any>(
            response,
        );

    if (
        payload &&
        typeof payload === "object" &&
        Object.prototype.hasOwnProperty.call(
            payload,
            "company",
        )
    ) {
        return (
            payload.company ||
            null
        );
    }

    return payload || null;
}

function extractErrorMessage(
    error: any,
    fallback: string,
): string {
    return (
        error?.response?.data?.message ||
        error?.response?.data?.error?.message ||
        error?.message ||
        fallback
    );
}

function getCompanyField(
    profile: CompanyProfile | null,
    primaryKey: keyof CompanyProfile,
    fallbackKey?: keyof CompanyProfile,
): string {
    const primary = profile?.[primaryKey];
    const fallback = fallbackKey
        ? profile?.[fallbackKey]
        : undefined;

    return String(
        primary ??
            fallback ??
            "",
    );
}

function formatFileSize(size?: number): string {
    const bytes = Number(size || 0);

    if (!bytes) {
        return "-";
    }

    if (bytes < 1024) {
        return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
        return `${(bytes / 1024).toFixed(1)} KB`;
    }

    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileExtension(fileName?: string): string {
    if (!fileName) {
        return "";
    }

    const parts = fileName.split(".");

    if (parts.length < 2) {
        return "";
    }

    return parts.pop()?.toUpperCase() || "";
}

/**
 * Build a protected URL.
 *
 * IMPORTANT:
 * We never use the storageKey/relativePath returned by the backend
 * as a public filesystem URL.
 */
function buildProtectedAssetUrl(
    endpoint: string,
): string {
    if (!API_BASE) {
        return endpoint;
    }

    return `${API_BASE}${endpoint}`;
}

/**
 * The browser cannot attach the Axios Bearer token to a normal
 * <img src=""> request. Therefore protected image endpoints are
 * fetched through Axios as Blob data and converted to object URLs.
 */
function revokeObjectUrl(
    objectUrl: string | null,
): void {
    if (
        objectUrl &&
        objectUrl.startsWith("blob:")
    ) {
        URL.revokeObjectURL(objectUrl);
    }
}

async function fetchProtectedImage(
    endpoint: string,
): Promise<string> {
    const response = await api.get(
        endpoint,
        {
            responseType: "blob",
        },
    );

    const blob = response.data;

    if (!(blob instanceof Blob)) {
        throw new Error(
            "The server returned an invalid image.",
        );
    }

    return URL.createObjectURL(blob);
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function CompanyInformation() {
    /*
    |--------------------------------------------------------------------------
    | General State
    |--------------------------------------------------------------------------
    */

    const [profile, setProfile] =
        useState<CompanyProfile | null>(
            null,
        );

    const [loading, setLoading] =
        useState(true);

    const [saving, setSaving] =
        useState(false);

    const [pageError, setPageError] =
        useState<string | null>(null);

    const [toast, setToast] =
        useState<ToastState>({
            type: null,
            message: "",
        });

    const [hasLoadedOnce, setHasLoadedOnce] =
        useState(false);

    /*
    |--------------------------------------------------------------------------
    | File States
    |--------------------------------------------------------------------------
    */

    const [logoState, setLogoState] =
        useState<UploadState>({
            file: null,
            previewUrl: null,
            uploading: false,
            removing: false,
            error: null,
        });

    const [faviconState, setFaviconState] =
        useState<UploadState>({
            file: null,
            previewUrl: null,
            uploading: false,
            removing: false,
            error: null,
        });

    const [logoFileInputKey, setLogoFileInputKey] =
        useState(0);

    const [faviconFileInputKey, setFaviconFileInputKey] =
        useState(0);

    const logoObjectUrlRef =
        useRef<string | null>(null);

    const faviconObjectUrlRef =
        useRef<string | null>(null);

    /*
    |--------------------------------------------------------------------------
    | Formik
    |--------------------------------------------------------------------------
    */

    const formik = useFormik<CompanyFormValues>({
        initialValues: INITIAL_FORM,
        validationSchema: companySchema,
        enableReinitialize: true,

        onSubmit: async ( values,) => {
            await handleSaveProfile(
                values,
            );
        },
    });

    const {
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        handleSubmit,
    } = formik;

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        if (!toast.message) {
            return;
        }

        const timer = window.setTimeout(
            () => {
                setToast({
                    type: null,
                    message: "",
                });
            },
            4000,
        );

        return () => {
            window.clearTimeout(timer);
        };
    }, [toast]);

    const showToast = useCallback(
        (
            type:
                | "success"
                | "error"
                | "warning",
            message: string,
        ) => {
            setToast({
                type,
                message,
            });
        },
        [],
    );

    /*
    |--------------------------------------------------------------------------
    | Load Company Profile
    |--------------------------------------------------------------------------
    */

    const loadCompanyProfile =
        useCallback(
            async (
                showLoader = true,
            ) => {
                if (showLoader) {
                    setLoading(true);
                }

                setPageError(null);

                try {
                    const response =
                        await api.get("/settings/company",);

                    const normalizedProfile =
                        extractCompanyProfile(
                            response,
                        );

                    setProfile(
                        normalizedProfile,
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Keep one source of truth:
                    | Formik gets all company fields from backend.
                    |--------------------------------------------------------------------------
                    */

                    formik.setValues(
                        {
                            companyName:
                                getCompanyField(
                                    normalizedProfile,
                                    "companyName",
                                    "legalName",
                                ),

                            taxNumber:
                                getCompanyField(
                                    normalizedProfile,
                                    "taxNumber",
                                    "taxId",
                                ),

                            email:
                                getCompanyField(
                                    normalizedProfile,
                                    "email",
                                    "contactEmail",
                                ),

                            phone:
                                getCompanyField(
                                    normalizedProfile,
                                    "phone",
                                    "supportPhone",
                                ),

                            address:
                                getCompanyField(
                                    normalizedProfile,
                                    "address",
                                    "headquartersAddress",
                                ),
                        },
                        false,
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Existing asset preview.
                    |
                    | We fetch through Axios because the endpoint is protected.
                    |--------------------------------------------------------------------------
                    */

                    if (
                        normalizedProfile?.logo
                            ?.storageKey ||
                        normalizedProfile?.logo
                            ?.originalName
                    ) {
                        await refreshLogoPreview();
                    } else {
                        cleanupLogoPreview();

                        setLogoState(
                            (prev) => ({
                                ...prev,
                                previewUrl:
                                    null,
                            }),
                        );
                    }

                    if (
                        normalizedProfile?.favicon
                            ?.storageKey ||
                        normalizedProfile?.favicon
                            ?.originalName
                    ) {
                        await refreshFaviconPreview();
                    } else {
                        cleanupFaviconPreview();

                        setFaviconState(
                            (prev) => ({
                                ...prev,
                                previewUrl:
                                    null,
                            }),
                        );
                    }

                    setHasLoadedOnce(
                        true,
                    );
                } catch (error) {
                    const message =
                        extractErrorMessage(
                            error,
                            "Unable to load company information.",
                        );

                    setPageError(message);

                    if (
                        !hasLoadedOnce
                    ) {
                        showToast(
                            "error",
                            message,
                        );
                    }
                } finally {
                    if (showLoader) {
                        setLoading(false);
                    }
                }
            },
            // Intentionally stable.
            // Formik methods and callbacks used here are stable enough for this screen.
            // eslint-disable-next-line react-hooks/exhaustive-deps
            [hasLoadedOnce, showToast],
        );

    /*
    |--------------------------------------------------------------------------
    | Asset Preview Cleanup
    |--------------------------------------------------------------------------
    */

    const cleanupLogoPreview =
        useCallback(() => {
            revokeObjectUrl(
                logoObjectUrlRef.current,
            );

            logoObjectUrlRef.current =
                null;
        }, []);

    const cleanupFaviconPreview =
        useCallback(() => {
            revokeObjectUrl(
                faviconObjectUrlRef.current,
            );

            faviconObjectUrlRef.current =
                null;
        }, []);

    /*
    |--------------------------------------------------------------------------
    | Refresh Protected Previews
    |--------------------------------------------------------------------------
    */

    const refreshLogoPreview =
        useCallback(async () => {
            try {
                const objectUrl =
                    await fetchProtectedImage(
                        COMPANY_LOGO_ENDPOINT,
                    );

                revokeObjectUrl(
                    logoObjectUrlRef.current,
                );

                logoObjectUrlRef.current =
                    objectUrl;

                setLogoState(
                    (prev) => ({
                        ...prev,
                        previewUrl:
                            objectUrl,
                        error: null,
                    }),
                );
            } catch (error) {
                cleanupLogoPreview();

                setLogoState(
                    (prev) => ({
                        ...prev,
                        previewUrl: null,
                        error:
                            extractErrorMessage(
                                error,
                                "Unable to load company logo.",
                            ),
                    }),
                );
            }
        }, [
            cleanupLogoPreview,
        ]);

    const refreshFaviconPreview =
        useCallback(async () => {
            try {
                const objectUrl =
                    await fetchProtectedImage(
                        COMPANY_FAVICON_ENDPOINT,
                    );

                revokeObjectUrl(
                    faviconObjectUrlRef.current,
                );

                faviconObjectUrlRef.current =
                    objectUrl;

                setFaviconState(
                    (prev) => ({
                        ...prev,
                        previewUrl:
                            objectUrl,
                        error: null,
                    }),
                );
            } catch (error) {
                cleanupFaviconPreview();

                setFaviconState(
                    (prev) => ({
                        ...prev,
                        previewUrl: null,
                        error:
                            extractErrorMessage(
                                error,
                                "Unable to load company favicon.",
                            ),
                    }),
                );
            }
        }, [
            cleanupFaviconPreview,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Initial Load
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        void loadCompanyProfile(
            true,
        );

        return () => {
            cleanupLogoPreview();
            cleanupFaviconPreview();
        };
    }, [
        loadCompanyProfile,
        cleanupLogoPreview,
        cleanupFaviconPreview,
    ]);

    /*
    |--------------------------------------------------------------------------
    | Save Company Profile
    |--------------------------------------------------------------------------
    */

    async function handleSaveProfile(
        formValues: CompanyFormValues,
    ) {
        setSaving(true);
        setPageError(null);

        try {
            const profilePayload = {
                companyName:
                    formValues.companyName.trim(),

                taxNumber:
                    formValues.taxNumber.trim(),

                email:
                    formValues.email.trim(),

                phone:
                    formValues.phone.trim(),

                address:
                    formValues.address.trim(),
            };

            const response =
                profile
                    ? await api.patch(
                          COMPANY_INITIALIZE_ENDPOINT,
                          profilePayload,
                      )
                    : await api.post(
                          COMPANY_INITIALIZE_ENDPOINT,
                          profilePayload,
                      );

            const data =
                extractCompanyProfile(
                    response,
                );

            if (data) {
                setProfile(
                    data,
                );

                /*
                |--------------------------------------------------------------------------
                | Keep the response synchronized with the form.
                |--------------------------------------------------------------------------
                */

                formik.setValues(
                    {
                        companyName:
                            getCompanyField(
                                data,
                                "companyName",
                                "legalName",
                            ),

                        taxNumber:
                            getCompanyField(
                                data,
                                "taxNumber",
                                "taxId",
                            ),

                        email:
                            getCompanyField(
                                data,
                                "email",
                                "contactEmail",
                            ),

                        phone:
                            getCompanyField(
                                data,
                                "phone",
                                "supportPhone",
                            ),

                        address:
                            getCompanyField(
                                data,
                                "address",
                                "headquartersAddress",
                            ),
                    },
                    false,
                );
            }

            if (logoState.file) {
                await uploadLogo(
                    logoState.file,
                );
            }

            if (faviconState.file) {
                await uploadFavicon(
                    faviconState.file,
                );
            }

            showToast(
                "success",
                profile
                    ? "Company profile saved successfully."
                    : "Company profile initialized successfully.",
            );
        } catch (error) {
            const message =
                extractErrorMessage(
                    error,
                    "Unable to save company information.",
                );

            setPageError(message);

            showToast(
                "error",
                message,
            );
        } finally {
            setSaving(false);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | File Validation
    |--------------------------------------------------------------------------
    */

    function validateSelectedFile(
        file: File,
        allowedTypes: string[],
        maxSize: number,
        label: string,
    ): string | null {
        if (!allowedTypes.includes(file.type)) {
            return `${label} must be one of the supported image formats.`;
        }

        if (file.size <= 0) {
            return `The selected ${label.toLowerCase()} is empty.`;
        }

        if (file.size > maxSize) {
            return `${label} must be smaller than ${formatFileSize(
                maxSize,
            )}.`;
        }

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | Logo Selection
    |--------------------------------------------------------------------------
    */

    async function handleLogoSelect(
        event: React.ChangeEvent<HTMLInputElement>,
    ) {
        const file =
            event.target.files?.[0];

        if (!file) {
            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Clear native input so selecting the same file again
        | still triggers onChange.
        |--------------------------------------------------------------------------
        */

        event.target.value = "";

        const validationError =
            validateSelectedFile(
                file,
                ACCEPTED_LOGO_TYPES,
                MAX_LOGO_SIZE,
                "Company logo",
            );

        if (validationError) {
            setLogoState(
                (prev) => ({
                    ...prev,
                    error:
                        validationError,
                }),
            );

            showToast(
                "error",
                validationError,
            );

            return;
        }

        const previewUrl =
            URL.createObjectURL(
                file,
            );

        revokeObjectUrl(
            logoObjectUrlRef.current,
        );

        logoObjectUrlRef.current =
            previewUrl;

        setLogoState(
            {
                file,
                previewUrl,
                uploading: false,
                removing: false,
                error: null,
            },
        );

        /*
        |--------------------------------------------------------------------------
        | Upload immediately.
        |
        | This means the image is already persisted when the user
        | presses Save Profile. The Save button itself handles only
        | the profile fields.
        |--------------------------------------------------------------------------
        */

        if (profile) {
            await uploadLogo(
                file,
            );
        } else {
            showToast(
                "warning",
                "Complete Company Information and click Save Profile to initialize the company before uploading the logo.",
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Favicon Selection
    |--------------------------------------------------------------------------
    */

    async function handleFaviconSelect(
        event: React.ChangeEvent<HTMLInputElement>,
    ) {
        const file =
            event.target.files?.[0];

        if (!file) {
            return;
        }

        event.target.value = "";

        const validationError =
            validateSelectedFile(
                file,
                ACCEPTED_FAVICON_TYPES,
                MAX_FAVICON_SIZE,
                "Company favicon",
            );

        if (validationError) {
            setFaviconState(
                (prev) => ({
                    ...prev,
                    error:
                        validationError,
                }),
            );

            showToast(
                "error",
                validationError,
            );

            return;
        }

        const previewUrl =
            URL.createObjectURL(
                file,
            );

        revokeObjectUrl(
            faviconObjectUrlRef.current,
        );

        faviconObjectUrlRef.current =
            previewUrl;

        setFaviconState(
            {
                file,
                previewUrl,
                uploading: false,
                removing: false,
                error: null,
            },
        );

        if (profile) {
            await uploadFavicon(
                file,
            );
        } else {
            showToast(
                "warning",
                "Complete Company Information and click Save Profile to initialize the company before uploading the favicon.",
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Logo Upload
    |--------------------------------------------------------------------------
    */

    async function uploadLogo(
        file: File,
    ) {
        setLogoState(
            (prev) => ({
                ...prev,
                uploading: true,
                removing: false,
                error: null,
            }),
        );

        const formData =
            new FormData();

        formData.append(
            "logo",
            file,
        );

        try {
            const response =
                await api.post(
                    COMPANY_LOGO_ENDPOINT,
                    formData,
                );

            const data =
                extractPayload<CompanyProfile>(
                    response,
                );

            if (
                data &&
                typeof data ===
                    "object"
            ) {
                setProfile(
                    (prev) => ({
                        ...(prev || {}),
                        ...data,
                        logo:
                            data.logo ??
                            prev?.logo ??
                            null,
                    }),
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Re-fetch protected asset so the preview is based on
            | the persisted server-side file rather than just the
            | browser-selected local file.
            |--------------------------------------------------------------------------
            */

            await refreshLogoPreview();

            setLogoState(
                (prev) => ({
                    ...prev,
                    file: null,
                    uploading: false,
                    error: null,
                }),
            );

            setLogoFileInputKey(
                (value) =>
                    value + 1,
            );

            showToast(
                "success",
                "Company logo uploaded successfully.",
            );
        } catch (error) {
            const message =
                extractErrorMessage(
                    error,
                    "Unable to upload company logo.",
                );

            setLogoState(
                (prev) => ({
                    ...prev,
                    uploading: false,
                    error: message,
                }),
            );

            showToast(
                "error",
                message,
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Favicon Upload
    |--------------------------------------------------------------------------
    */

    async function uploadFavicon(
        file: File,
    ) {
        setFaviconState(
            (prev) => ({
                ...prev,
                uploading: true,
                removing: false,
                error: null,
            }),
        );

        const formData =
            new FormData();

        formData.append(
            "favicon",
            file,
        );

        try {
            const response =
                await api.post(
                    COMPANY_FAVICON_ENDPOINT,
                    formData,
                );

            const data =
                extractPayload<CompanyProfile>(
                    response,
                );

            if (
                data &&
                typeof data ===
                    "object"
            ) {
                setProfile(
                    (prev) => ({
                        ...(prev || {}),
                        ...data,
                        favicon:
                            data.favicon ??
                            prev?.favicon ??
                            null,
                    }),
                );
            }

            await refreshFaviconPreview();

            setFaviconState(
                (prev) => ({
                    ...prev,
                    file: null,
                    uploading: false,
                    error: null,
                }),
            );

            setFaviconFileInputKey(
                (value) =>
                    value + 1,
            );

            showToast(
                "success",
                "Company favicon uploaded successfully.",
            );
        } catch (error) {
            const message =
                extractErrorMessage(
                    error,
                    "Unable to upload company favicon.",
                );

            setFaviconState(
                (prev) => ({
                    ...prev,
                    uploading: false,
                    error: message,
                }),
            );

            showToast(
                "error",
                message,
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Logo Remove
    |--------------------------------------------------------------------------
    */

    async function handleRemoveLogo() {
        setLogoState(
            (prev) => ({
                ...prev,
                removing: true,
                error: null,
            }),
        );

        try {
            await api.delete(
                COMPANY_LOGO_ENDPOINT,
            );

            cleanupLogoPreview();

            setProfile(
                (prev) => ({
                    ...(prev || {}),
                    logo: null,
                }),
            );

            setLogoState({
                file: null,
                previewUrl: null,
                uploading: false,
                removing: false,
                error: null,
            });

            setLogoFileInputKey(
                (value) =>
                    value + 1,
            );

            showToast(
                "success",
                "Company logo removed successfully.",
            );
        } catch (error) {
            const message =
                extractErrorMessage(
                    error,
                    "Unable to remove company logo.",
                );

            setLogoState(
                (prev) => ({
                    ...prev,
                    removing: false,
                    error: message,
                }),
            );

            showToast(
                "error",
                message,
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Favicon Remove
    |--------------------------------------------------------------------------
    */

    async function handleRemoveFavicon() {
        setFaviconState(
            (prev) => ({
                ...prev,
                removing: true,
                error: null,
            }),
        );

        try {
            await api.delete(
                COMPANY_FAVICON_ENDPOINT,
            );

            cleanupFaviconPreview();

            setProfile(
                (prev) => ({
                    ...(prev || {}),
                    favicon: null,
                }),
            );

            setFaviconState({
                file: null,
                previewUrl: null,
                uploading: false,
                removing: false,
                error: null,
            });

            setFaviconFileInputKey(
                (value) =>
                    value + 1,
            );

            showToast(
                "success",
                "Company favicon removed successfully.",
            );
        } catch (error) {
            const message =
                extractErrorMessage(
                    error,
                    "Unable to remove company favicon.",
                );

            setFaviconState(
                (prev) => ({
                    ...prev,
                    removing: false,
                    error: message,
                }),
            );

            showToast(
                "error",
                message,
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Download Protected Asset
    |--------------------------------------------------------------------------
    */

    async function downloadProtectedAsset(
        endpoint: string,
        fallbackName: string,
    ) {
        try {
            const response =
                await api.get(
                    endpoint,
                    {
                        responseType:
                            "blob",
                    },
                );

            const blob =
                response.data;

            if (!(blob instanceof Blob)) {
                throw new Error(
                    "Invalid file returned by server.",
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Try to use filename from Content-Disposition.
            |--------------------------------------------------------------------------
            */

            let fileName =
                fallbackName;

            const disposition =
                response.headers[
                    "content-disposition"
                ];

            if (
                typeof disposition ===
                "string"
            ) {
                const match =
                    disposition.match(
                        /filename="?([^"]+)"?/i,
                    );

                if (match?.[1]) {
                    fileName =
                        match[1];
                }
            }

            const objectUrl =
                URL.createObjectURL(
                    blob,
                );

            const anchor =
                document.createElement(
                    "a",
                );

            anchor.href =
                objectUrl;

            anchor.download =
                fileName;

            document.body.appendChild(
                anchor,
            );

            anchor.click();

            anchor.remove();

            window.setTimeout(
                () => {
                    URL.revokeObjectURL(
                        objectUrl,
                    );
                },
                1000,
            );
        } catch (error) {
            showToast(
                "error",
                extractErrorMessage(
                    error,
                    "Unable to download file.",
                ),
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Page Refresh
    |--------------------------------------------------------------------------
    */

    async function handleRefresh() {
        await loadCompanyProfile(
            true,
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Loading Skeleton
    |--------------------------------------------------------------------------
    */

    if (loading) {
        return (
            <div className="animate-pulse">
                <div className="border-b border-slate-100 pb-6">
                    <div className="flex items-start gap-4">
                        <div className="h-8 w-8 rounded-lg bg-slate-200" />

                        <div className="space-y-2">
                            <div className="h-5 w-48 rounded bg-slate-200" />
                            <div className="h-3 w-72 rounded bg-slate-100" />
                        </div>
                    </div>

                    <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
                        <div className="h-36 rounded-2xl bg-slate-100" />
                        <div className="h-36 rounded-2xl bg-slate-100" />
                    </div>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div className="h-20 rounded-xl bg-slate-100" />
                    <div className="h-20 rounded-xl bg-slate-100" />
                    <div className="h-20 rounded-xl bg-slate-100" />
                    <div className="h-20 rounded-xl bg-slate-100" />
                    <div className="h-28 rounded-xl bg-slate-100 sm:col-span-2" />
                </div>
            </div>
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Main UI
    |--------------------------------------------------------------------------
    */

    return (
        <div>
            {/* ---------------------------------------------------------------- */}
            {/* Toast                                                             */}
            {/* ---------------------------------------------------------------- */}

            {toast.message ? (
                <div className="fixed right-4 top-4 z-[100] w-[calc(100vw-2rem)] max-w-sm">
                    <div
                        className={[
                            "rounded-xl border px-4 py-3 shadow-lg backdrop-blur",
                            toast.type ===
                            "success"
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : toast.type ===
                                  "warning"
                                ? "border-amber-200 bg-amber-50 text-amber-700"
                                : "border-red-200 bg-red-50 text-red-700",
                        ].join(" ")}
                    >
                        <div className="flex items-start gap-3">
                            {toast.type ===
                            "success" ? (
                                <CheckCircleIcon
                                    size={20}
                                    weight="fill"
                                    className="mt-0.5 shrink-0"
                                />
                            ) : toast.type ===
                              "warning" ? (
                                <InfoIcon
                                    size={20}
                                    weight="fill"
                                    className="mt-0.5 shrink-0"
                                />
                            ) : (
                                <XCircleIcon
                                    size={20}
                                    weight="fill"
                                    className="mt-0.5 shrink-0"
                                />
                            )}

                            <p className="text-sm font-medium">
                                {
                                    toast.message
                                }
                            </p>
                        </div>
                    </div>
                </div>
            ) : null}

            {/* ---------------------------------------------------------------- */}
            {/* Header                                                            */}
            {/* ---------------------------------------------------------------- */}

            <div className="border-b border-slate-100 pb-6">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex items-start gap-4">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                            <BuildingsIcon
                                size={21}
                                weight="duotone"
                            />
                        </div>

                        <div>
                            <div className="flex flex-wrap items-center gap-2">
                                <h2 className="text-lg font-bold text-slate-900">
                                    Company Information
                                </h2>

                                {profile ? (
                                    <span
                                        className={[
                                            "inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold",
                                            profile.active ===
                                            false
                                                ? "bg-slate-100 text-slate-600"
                                                : "bg-emerald-50 text-emerald-700",
                                        ].join(
                                            " ",
                                        )}
                                    >
                                        <span
                                            className={[
                                                "mr-1.5 h-1.5 w-1.5 rounded-full",
                                                profile.active ===
                                                false
                                                    ? "bg-slate-400"
                                                    : "bg-emerald-500",
                                            ].join(
                                                " ",
                                            )}
                                        />

                                        {profile.active ===
                                        false
                                            ? "Inactive"
                                            : "Active"}
                                    </span>
                                ) : null}
                            </div>

                            <p className="mt-1 max-w-2xl text-sm text-slate-500">
                                Manage the primary company identity,
                                contact information and brand assets used
                                throughout ARGUS.
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={
                            handleRefresh
                        }
                        disabled={
                            loading ||
                            saving
                        }
                        className="inline-flex w-fit items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <span
                            className={
                                loading
                                    ? "h-3.5 w-3.5 animate-spin rounded-full border-2 border-slate-300 border-t-red-500"
                                    : ""
                            }
                        >
                            {!loading ? "↻" : ""}
                        </span>

                        Refresh
                    </button>
                </div>

                {/* ---------------------------------------------------------------- */}
                {/* Page Error                                                       */}
                {/* ---------------------------------------------------------------- */}

                {pageError ? (
                    <div className="mt-5 flex items-start gap-3 rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-700">
                        <XCircleIcon
                            size={20}
                            weight="fill"
                            className="mt-0.5 shrink-0"
                        />

                        <div className="flex-1">
                            <p className="font-semibold">
                                Unable to complete request
                            </p>

                            <p className="mt-0.5 text-xs leading-5 text-red-600">
                                {pageError}
                            </p>
                        </div>
                    </div>
                ) : null}

                {/* ---------------------------------------------------------------- */}
                {/* Brand Assets - legacy UI, production functionality preserved */}
                {/* ---------------------------------------------------------------- */}

                <div className="mt-6 grid grid-cols-1 gap-8 md:grid-cols-2">
                    {/* Company Logo */}
                    <div className="flex items-start gap-4">
                        <div className="shrink-0">
                            <label
                                htmlFor={`company-logo-upload-${logoFileInputKey}`}
                                className="flex h-24 w-24 cursor-pointer items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-50 transition hover:border-red-200 hover:bg-red-50"
                            >
                                {logoState.previewUrl ? (
                                    <img
                                        src={logoState.previewUrl}
                                        alt="Company Logo"
                                        className="h-full w-full object-contain p-2"
                                    />
                                ) : (
                                    <div className="flex flex-col items-center justify-center text-center text-slate-400">
                                        <UploadSimpleIcon size={24} />
                                        <span className="mt-1 text-[10px] font-semibold uppercase tracking-wide">
                                            Upload
                                        </span>
                                    </div>
                                )}
                            </label>

                            <input
                                id={`company-logo-upload-${logoFileInputKey}`}
                                type="file"
                                accept={ACCEPTED_LOGO_TYPES.join(",")}
                                className="hidden"
                                disabled={saving || logoState.uploading || logoState.removing}
                                onChange={handleLogoSelect}
                            />
                        </div>

                        <div className="min-w-0 pt-1">
                            <h3 className="text-sm font-semibold text-slate-800">
                                Company Logo
                            </h3>

                            <p className="mt-1 text-xs text-slate-500">
                                Upload your company logo
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                PNG, JPG or WEBP
                            </p>

                            {profile?.logo?.originalName ? (
                                <p className="mt-2 max-w-[220px] truncate text-[11px] text-slate-400">
                                    {profile.logo.originalName}
                                </p>
                            ) : null}

                            {logoState.error ? (
                                <p className="mt-2 text-xs text-red-600">
                                    {logoState.error}
                                </p>
                            ) : null}

                            {profile?.logo ? (
                                <div className="mt-2 flex items-center gap-3">
                                    {/* <button
                                        type="button"
                                        onClick={() =>
                                            void downloadProtectedAsset(
                                                COMPANY_LOGO_DOWNLOAD_ENDPOINT,
                                                profile.logo?.originalName || "company-logo",
                                            )
                                        }
                                        disabled={saving || logoState.uploading || logoState.removing}
                                        className="text-xs font-semibold text-slate-500 hover:text-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
                                    >
                                        Download
                                    </button>  */}

                                    <button
                                        type="button"
                                        onClick={handleRemoveLogo}
                                        disabled={saving || logoState.uploading || logoState.removing}
                                        className="text-xs font-semibold text-red-500 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
                                    >
                                        {logoState.removing ? "Removing..." : "Remove"}
                                    </button>
                                </div>
                            ) : null}

                            {logoState.uploading ? (
                                <p className="mt-2 text-xs font-medium text-red-500">
                                    Uploading...
                                </p>
                            ) : null}
                        </div>
                    </div>

                    {/* Favicon */}
                    <div className="flex items-start gap-4">
                        <div className="shrink-0">
                            <label
                                htmlFor={`company-favicon-upload-${faviconFileInputKey}`}
                                className="flex h-24 w-24 cursor-pointer items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-50 transition hover:border-red-200 hover:bg-red-50"
                            >
                                {faviconState.previewUrl ? (
                                    <img
                                        src={faviconState.previewUrl}
                                        alt="Favicon"
                                        className="h-full w-full object-contain p-2"
                                    />
                                ) : (
                                    <div className="flex flex-col items-center justify-center text-center text-slate-400">
                                        <UploadSimpleIcon size={24} />
                                        <span className="mt-1 text-[10px] font-semibold uppercase tracking-wide">
                                            Upload
                                        </span>
                                    </div>
                                )}
                            </label>

                            <input
                                id={`company-favicon-upload-${faviconFileInputKey}`}
                                type="file"
                                accept={ACCEPTED_FAVICON_TYPES.join(",")}
                                className="hidden"
                                disabled={saving || faviconState.uploading || faviconState.removing}
                                onChange={handleFaviconSelect}
                            />
                        </div>

                        <div className="min-w-0 pt-1">
                            <h3 className="text-sm font-semibold text-slate-800">
                                Favicon
                            </h3>

                            <p className="mt-1 text-xs text-slate-500">
                                Upload your application favicon
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                PNG, ICO or SVG
                            </p>

                            {profile?.favicon?.originalName ? (
                                <p className="mt-2 max-w-[220px] truncate text-[11px] text-slate-400">
                                    {profile.favicon.originalName}
                                </p>
                            ) : null}

                            {faviconState.error ? (
                                <p className="mt-2 text-xs text-red-600">
                                    {faviconState.error}
                                </p>
                            ) : null}

                            {profile?.favicon ? (
                                <div className="mt-2 flex items-center gap-3">
                                    {/* <button
                                        type="button"
                                        onClick={() =>
                                            void downloadProtectedAsset(
                                                COMPANY_FAVICON_DOWNLOAD_ENDPOINT,
                                                profile.favicon?.originalName || "company-favicon",
                                            )
                                        }
                                        disabled={saving || faviconState.uploading || faviconState.removing}
                                        className="text-xs font-semibold text-slate-500 hover:text-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
                                    >
                                        Download
                                    </button> */}

                                    <button
                                        type="button"
                                        onClick={handleRemoveFavicon}
                                        disabled={saving || faviconState.uploading || faviconState.removing}
                                        className="text-xs font-semibold text-red-500 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-50"
                                    >
                                        {faviconState.removing ? "Removing..." : "Remove"}
                                    </button>
                                </div>
                            ) : null}

                            {faviconState.uploading ? (
                                <p className="mt-2 text-xs font-medium text-red-500">
                                    Uploading...
                                </p>
                            ) : null}
                        </div>
                    </div>
                </div>
            </div>

            {/* ------------------------------------------------------------------ */}
            {/* Form                                                                */}
            {/* ------------------------------------------------------------------ */}

            <form
                onSubmit={
                    handleSubmit
                }
                noValidate
            >
                <div className="mt-6">
                    <div className="mb-4">
                        <h3 className="text-sm font-semibold text-slate-900">
                            Company Profile
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            Keep the legal and contact information up to
                            date for procurement, projects, invoices and
                            other company-facing workflows.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-x-6 gap-y-5 sm:grid-cols-2">
                        <Field
                            required
                            label="Company Legal Name"
                            name="companyName"
                            value={
                                values.companyName
                            }
                            onChange={
                                handleChange
                            }
                            onBlur={
                                handleBlur
                            }
                            error={
                                errors.companyName
                            }
                            touched={
                                touched.companyName
                            }
                            placeholder="ABC Technologies"
                            disabled={
                                saving
                            }
                            className={getInputClass(
                                {
                                    touched:
                                        touched.companyName,
                                    error:
                                        errors.companyName,
                                },
                            )}
                        />

                        <Field
                            required
                            label="Tax ID / VAT Number"
                            name="taxNumber"
                            value={
                                values.taxNumber
                            }
                            onChange={
                                handleChange
                            }
                            onBlur={
                                handleBlur
                            }
                            error={
                                errors.taxNumber
                            }
                            touched={
                                touched.taxNumber
                            }
                            placeholder="VAT-123456789"
                            disabled={
                                saving
                            }
                            className={getInputClass(
                                {
                                    touched:
                                        touched.taxNumber,
                                    error:
                                        errors.taxNumber,
                                },
                            )}
                        />

                        <Field
                            required
                            label="Primary Contact Email"
                            type="email"
                            name="email"
                            value={
                                values.email
                            }
                            onChange={
                                handleChange
                            }
                            onBlur={
                                handleBlur
                            }
                            error={
                                errors.email
                            }
                            touched={
                                touched.email
                            }
                            placeholder="operations@company.com"
                            disabled={
                                saving
                            }
                            className={getInputClass(
                                {
                                    touched:
                                        touched.email,
                                    error:
                                        errors.email,
                                },
                            )}
                        />

                        <Field
                            label="Support Phone"
                            type="tel"
                            name="phone"
                            value={
                                values.phone
                            }
                            onChange={
                                handleChange
                            }
                            onBlur={
                                handleBlur
                            }
                            error={
                                errors.phone
                            }
                            touched={
                                touched.phone
                            }
                            placeholder="+91 98765 43210"
                            disabled={
                                saving
                            }
                            className={getInputClass(
                                {
                                    touched:
                                        touched.phone,
                                    error:
                                        errors.phone,
                                },
                            )}
                        />

                        <div className="sm:col-span-2">
                            <Field
                                required
                                label="Headquarters Address"
                                type="textarea"
                                rows={4}
                                name="address"
                                value={
                                    values.address
                                }
                                onChange={
                                    handleChange
                                }
                                onBlur={
                                    handleBlur
                                }
                                error={
                                    errors.address
                                }
                                touched={
                                    touched.address
                                }
                                placeholder="123 Main Street, City, State, Country"
                                disabled={
                                    saving
                                }
                                className={`${getInputClass(
                                    {
                                        touched:
                                            touched.address,
                                        error:
                                            errors.address,
                                    },
                                )} resize-none`}
                            />
                        </div>
                    </div>
                </div>

                {/* ---------------------------------------------------------------- */}
                {/* Footer                                                           */}
                {/* ---------------------------------------------------------------- */}

                <div className="mt-8 flex flex-col gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:items-center sm:justify-end">
                    {/* <div className="flex items-start gap-2 text-xs text-slate-400">
                        <InfoIcon
                            size={15}
                            className="mt-0.5 shrink-0"
                        />

                        <span>
                            Changes to the company profile are protected
                            by backend authentication and permissions.
                        </span>
                    </div> */}

                    <Button
                        type="submit"
                        disabled={
                            saving
                        }
                    >
                        {saving ? (
                            <>
                                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                                Saving...
                            </>
                        ) : (
                            <>
                                <FloppyDiskBackIcon
                                    size={16}
                                />
                                Save Profile
                            </>
                        )}
                    </Button>
                </div>
            </form>

            {/* ------------------------------------------------------------------ */}
            {/* Existing File Information                                           */}
            {/* ------------------------------------------------------------------ */}

            {/* {(profile?.logo ||
                profile?.favicon) && (
                <div className="mt-8 rounded-2xl border border-slate-200 bg-slate-50/70 p-4">
                    <div className="mb-3">
                        <h3 className="text-sm font-semibold text-slate-900">
                            Stored Asset Details
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            Server-side metadata for the currently
                            configured brand assets.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        {profile.logo ? (
                            <div className="rounded-xl border border-slate-200 bg-white p-3">
                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-xs font-semibold text-slate-700">
                                        Logo
                                    </span>

                                    <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500">
                                        {getFileExtension(
                                            profile.logo
                                                .originalName,
                                        ) ||
                                            "IMAGE"}
                                    </span>
                                </div>

                                <p className="mt-2 truncate text-xs text-slate-500">
                                    {
                                        profile.logo
                                            .originalName
                                    }
                                </p>

                                <p className="mt-1 text-[11px] text-slate-400">
                                    {formatFileSize(
                                        profile.logo
                                            .size,
                                    )}
                                </p>
                            </div>
                        ) : null}

                        {profile.favicon ? (
                            <div className="rounded-xl border border-slate-200 bg-white p-3">
                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-xs font-semibold text-slate-700">
                                        Favicon
                                    </span>

                                    <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500">
                                        {getFileExtension(
                                            profile
                                                .favicon
                                                .originalName,
                                        ) ||
                                            "ICON"}
                                    </span>
                                </div>

                                <p className="mt-2 truncate text-xs text-slate-500">
                                    {
                                        profile
                                            .favicon
                                            .originalName
                                    }
                                </p>

                                <p className="mt-1 text-[11px] text-slate-400">
                                    {formatFileSize(
                                        profile
                                            .favicon
                                            .size,
                                    )}
                                </p>
                            </div>
                        ) : null}
                    </div>
                </div>
            )} */}
        </div>
    );
}