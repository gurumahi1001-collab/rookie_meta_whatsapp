import { useCallback, useEffect, useMemo, useState } from "react";

import type { Quotation } from "../types/quotation";
import QuotationTabs, { QuotationTab } from "../components/quotations/QuotationTabs";
import QuotationDashboard from "../components/quotations/QuotationDashboard";
import BidsAndProposals from "../components/quotations/Bids&Proposal";
import ProjectBOQEstimator from "../components/quotations/ProjectBOQ";
import QuotationHeader from "../components/quotations/QuotationHeader";
import NewQuotation from "../components/quotations/NewQuotation";
import QuotationDetails from "../components/quotations/QuotationDetails";
import ProjectBOQList from "../components/quotations/ProjectBOQ_list";
import {
    deleteQuotation,
    getQuotation,
    listQuotations,
} from "../api/quotationApi";

const errorMessage = (error: unknown, fallback: string) => {
    const value = error as { response?: { data?: { message?: string } }; message?: string };
    return value.response?.data?.message || value.message || fallback;
};

const Quotations = () => {
    const [activeTab, setActiveTab] = useState<QuotationTab>("bids");
    const [showProjectBOQ, setShowProjectBOQ] = useState(false);
    const [currentView, setCurrentView] = useState<"list" | "new-quotation" | "project-boq" | "quotation-details">("list");
    const [quotationList, setQuotationList] = useState<Quotation[]>([]);
    const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const loadQuotations = useCallback(async () => {
        try {
            setLoading(true);
            setError("");
            const result = await listQuotations({ page: 1, limit: 250 });
            setQuotationList(result.data);
        } catch (loadError) {
            setError(errorMessage(loadError, "Unable to load quotations."));
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        void loadQuotations();
    }, [loadQuotations]);

    const stats = useMemo(() => {
        const draft = quotationList.filter((q) => q.statusCode === "draft" || q.status === "Draft").length;
        const submitted = quotationList.filter((q) => q.statusCode === "submitted" || q.status === "Submitted").length;
        const awarded = quotationList.filter((q) => q.statusCode === "awarded" || q.status === "Awarded").length;
        const approvedValue = quotationList
            .filter((q) => q.statusCode === "awarded" || q.status === "Awarded" || q.statusCode === "approved" || q.status === "Form Approved")
            .reduce((total, quotation) => total + Number(quotation.grandTotal || 0), 0);
        return { total: quotationList.length, draft, submitted, awarded, approvedValue };
    }, [quotationList]);

    const handleViewQuotation = useCallback(async (quotation: Quotation) => {
        try {
            setError("");
            setSelectedQuotation(await getQuotation(quotation.id));
            setCurrentView("quotation-details");
        } catch (viewError) {
            setError(errorMessage(viewError, "Unable to load quotation details."));
        }
    }, []);

    const handleStatusChange = useCallback(async (quotationId: string) => {
        try {
            setError("");
            const updated = await getQuotation(quotationId);
            setQuotationList((current) => current.map((row) => row.id === updated.id ? updated : row));
            setSelectedQuotation(updated);
        } catch (statusError) {
            setError(errorMessage(statusError, "Unable to refresh quotation status."));
        }
    }, []);

    const handleDelete = useCallback(async (quotation: Quotation) => {
        if (!window.confirm(`Delete ${quotation.quotationNo}? This cannot be undone.`)) return;
        try {
            setError("");
            await deleteQuotation(quotation.id);
            setQuotationList((current) => current.filter((row) => row.id !== quotation.id));
        } catch (deleteError) {
            setError(errorMessage(deleteError, "Unable to delete quotation."));
        }
    }, []);

    if (currentView === "quotation-details" && selectedQuotation) {
        return (
            <div className="min-h-screen">
                <QuotationDetails
                    quotation={selectedQuotation}
                    onBack={() => {
                        setSelectedQuotation(null);
                        setCurrentView("list");
                    }}
                    onStatusChange={handleStatusChange}
                />
            </div>
        );
    }

    if (currentView === "new-quotation") {
        return (
            <div className="min-h-screen">
                <NewQuotation
                    onBack={() => {
                        setCurrentView("list");
                        void loadQuotations();
                    }}
                    onOpenMasterRate={() => setCurrentView("project-boq")}
                />
            </div>
        );
    }

    if (currentView === "project-boq") {
        return (
            <div className="min-h-screen">
                <ProjectBOQEstimator onBack={() => setCurrentView("new-quotation")} />
            </div>
        );
    }

    return (
        <div className="min-h-screen">
            <QuotationHeader
                showNewQuotation={activeTab === "bids"}
                showBoqActions={activeTab === "boq" && showProjectBOQ}
                showAddBOQ={activeTab === "boq" && showProjectBOQ}
                onExportEstimate={() => window.print()}
                onGenerateQuotation={() => setCurrentView("new-quotation")}
            />

            {error && (
                <div className="mb-4 flex items-center justify-between rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-xs text-red-700">
                    <span>{error}</span>
                    <button type="button" className="font-semibold" onClick={() => setError("")}>Dismiss</button>
                </div>
            )}

            <div className="mb-6">
                <QuotationTabs activeTab={activeTab} onChange={setActiveTab} />
            </div>

            {activeTab === "bids" && (
                <>
                    <QuotationDashboard
                        total={stats.total}
                        pending={stats.submitted}
                        approved={stats.awarded}
                        approvedValue={stats.approvedValue}
                    />
                    {loading ? (
                        <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500 shadow-sm">Loading quotations…</div>
                    ) : (
                        <BidsAndProposals quotations={quotationList} onView={handleViewQuotation} onDelete={handleDelete} />
                    )}
                </>
            )}

            {activeTab === "boq" && (
                <>
                    {!showProjectBOQ ? (
                        <ProjectBOQList onAddBOQ={() => setShowProjectBOQ(true)} />
                    ) : (
                        <ProjectBOQEstimator showBackButton onBack={() => setShowProjectBOQ(false)} />
                    )}
                </>
            )}
        </div>
    );
};

export default Quotations;
