import {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";

import {
    ClockCounterClockwiseIcon,
    DownloadSimpleIcon,
    PlusIcon,
    TrashIcon,
    UploadSimpleIcon,
    WarningCircleIcon,
    CheckCircleIcon,
    XCircleIcon,
    SpinnerGapIcon,
    PenNibIcon,
    ArrowClockwiseIcon,
} from "@phosphor-icons/react";

import Button from "../components/Button";

import DataTable, {
    DataTableColumn,
} from "../components/DataTable";

import ToggleSwitch from "../components/ToggleSwitch";

import ConfirmDialog from "../components/ConfirmModal";

import RateFilters from "../features/master_rate_schedule/RateFilters";

import RateFormOffCanvas from "../offcanvas/master_rate_schedule/RateFormOffcanvas";

import RateHistoryOffCanvas from "../offcanvas/master_rate_schedule/RateHistoryOffcanvas";

import {
    exportRatesToCsv,
    parseRatesCsvFile,
} from "../features/master_rate_schedule/csvUtils";

import {
    RateItem,
    RateFormValues,
    emptyRateForm,
} from "../types/rateSchedule";

import {
    fmtJmd,
    todayIso,
} from "../data/seedRateSchedule";

import api from "../api/axios";

/*
|--------------------------------------------------------------------------
| API
|--------------------------------------------------------------------------
*/

const MASTER_RATE_ENDPOINT =
    "/master-rates";

/*
|--------------------------------------------------------------------------
| Response Types
|--------------------------------------------------------------------------
*/

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    code?: string;
    data?: T;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

/*
|--------------------------------------------------------------------------
| History
|--------------------------------------------------------------------------
*/

interface RateHistoryApiItem {
    rate: number;
    effectiveDate: string;
    updatedAt: string;
    updatedBy: string;
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    const axiosError =
        error as {
            response?: {
                data?: {
                    message?: string;
                    error?: string;
                };
            };
            message?: string;
        };

    return (
        axiosError?.response?.data
            ?.message ||
        axiosError?.response?.data
            ?.error ||
        axiosError?.message ||
        fallback
    );
}

function assertApiSuccess(
    response: {
        data?: ApiResponse<unknown>;
    },
    fallback: string,
): void {
    if (response?.data?.success === false) {
        throw new Error(
            response.data.message || fallback,
        );
    }
}

function normalizeStatus(
    value: unknown,
):
    | "active"
    | "inactive" {
    return String(
        value ?? "active",
    ).toLowerCase() ===
        "inactive"
        ? "inactive"
        : "active";
}

function normalizeHistoryItem(
    value: unknown,
): RateHistoryApiItem | null {
    if (
        !value ||
        typeof value !==
            "object"
    ) {
        return null;
    }

    const source =
        value as Record<
            string,
            unknown
        >;

    return {
        rate:
            Number(
                source.rate ??
                    0,
            ),

        effectiveDate:
            String(
                source.effectiveDate ??
                    "",
            ),

        updatedAt:
            String(
                source.updatedAt ??
                    "",
            ),

        updatedBy:
            String(
                source.updatedBy ??
                    "",
            ),
    };
}

function normalizeRateItem(
    value: unknown,
): RateItem | null {
    if (
        !value ||
        typeof value !==
            "object"
    ) {
        return null;
    }

    const source =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            source.id ??
                source._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    const standardRate =
        Number(
            source.standardRate ??
                source.rate ??
                0,
        );

    const historySource =
        Array.isArray(
            source.history,
        )
            ? source.history
            : [];

    const history =
        historySource
            .map(
                normalizeHistoryItem,
            )
            .filter(
                (
                    item,
                ): item is RateHistoryApiItem =>
                    item !== null,
            );

    return {
        id,

        code:
            String(
                source.code ??
                    "",
            ),

        /*
         * The current frontend RateItem contract contains `rate`
         * separately from `standardRate`.
         */
        rate:
            Number(
                source.rate ??
                    standardRate,
            ),

        categoryType:
            String(
                source.categoryType ??
                    "",
            ),

        category:
            String(
                source.category ??
                    "",
            ),

        subcategory:
            String(
                source.subcategory ??
                    "",
            ),

        module:
            String(
                source.module ??
                    "",
            ),

        description:
            String(
                source.description ??
                    "",
            ),

        unit:
            String(
                source.unit ??
                    "",
            ),

        standardRate,

        effectiveDate:
            String(
                source.effectiveDate ??
                    "",
            ),

        status:
            normalizeStatus(
                source.status,
            ),

        history,
    };
}

function extractRateItems(
    response: ApiResponse<
        unknown[]
    >,
): RateItem[] {
    const source =
        Array.isArray(
            response?.data,
        )
            ? response.data
            : [];

    return source
        .map(
            normalizeRateItem,
        )
        .filter(
            (
                item,
            ): item is RateItem =>
                item !== null,
        );
}

function buildFormFromRate(
    row: RateItem,
): RateFormValues {
    return {
        code:
            row.code,

        category:
            row.category,

        categorytype:
            row.categoryType,

        description:
            row.description,

        unit:
            row.unit,

        standardRate:
            String(
                row.standardRate,
            ),

        effectiveDate:
            row.effectiveDate,

        status:
            row.status,

        subcategory:
            row.subcategory,
    };
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function MasterRateSchedule() {
    const [
        data,
        setData,
    ] = useState<RateItem[]>([]);

    const [
        loading,
        setLoading,
    ] = useState(true);

    const [
        refreshing,
        setRefreshing,
    ] = useState(false);

    const [
        actionError,
        setActionError,
    ] = useState("");

    const [
        search,
        setSearch,
    ] = useState("");

    const [
        categoryFilter,
        setCategoryFilter,
    ] = useState("all");

    const [
        formOpen,
        setFormOpen,
    ] = useState(false);

    const [
        editingId,
        setEditingId,
    ] = useState<string | null>(
        null,
    );

    const [
        form,
        setForm,
    ] = useState<RateFormValues>(
        emptyRateForm(
            todayIso(),
        ),
    );

    const [
        historyRow,
        setHistoryRow,
    ] = useState<RateItem | null>(
        null,
    );

    const [
        historyLoading,
        setHistoryLoading,
    ] = useState(false);

    const [
        historyError,
        setHistoryError,
    ] = useState("");

    const [
        deleteTarget,
        setDeleteTarget,
    ] = useState<RateItem | null>(
        null,
    );

    const [
        deleting,
        setDeleting,
    ] = useState(false);

    const [
        saving,
        setSaving,
    ] = useState(false);

    const [
        togglingId,
        setTogglingId,
    ] =
        useState<string | null>(
            null,
        );

    const [
        toast,
        setToast,
    ] = useState<{
        type:
            | "success"
            | "error";
        message: string;
    }>({
        type: "success",
        message: "",
    });

    const importInputRef =
        useRef<HTMLInputElement>(
            null,
        );

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    const showToast =
        useCallback(
            (
                type:
                    | "success"
                    | "error",
                message: string,
            ) => {
                setToast({
                    type,
                    message,
                });

                window.setTimeout(
                    () => {
                        setToast(
                            (
                                previous,
                            ) =>
                                previous.message ===
                                message
                                    ? {
                                          type:
                                              "success",
                                          message:
                                              "",
                                      }
                                    : previous,
                        );
                    },
                    3500,
                );
            },
            [],
        );

    /*
    |--------------------------------------------------------------------------
    | Load Rates
    |--------------------------------------------------------------------------
    */

    const loadRates =
        useCallback(
            async (
                showSpinner = true,
            ) => {
                if (
                    showSpinner
                ) {
                    setLoading(
                        true,
                    );
                } else {
                    setRefreshing(
                        true,
                    );
                }

                setActionError(
                    "",
                );

                try {
                    const response =
                        await api.get<
                            ApiResponse<
                                unknown[]
                            >
                        >(
                            MASTER_RATE_ENDPOINT,
                            {
                                params: {
                                    page: 1,
                                    limit: 100,
                                    search:
                                        search.trim(),
                                    category:
                                        categoryFilter ===
                                        "all"
                                            ? ""
                                            : categoryFilter,
                                    sort: "updatedAt",
                                    sortOrder:
                                        "desc",
                                },
                            },
                        );

                    assertApiSuccess(
                        response,
                        "Unable to load master rates.",
                    );

                    setData(
                        extractRateItems(
                            response.data,
                        ),
                    );
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            "Unable to load master rates.",
                        );

                    setActionError(
                        message,
                    );

                    showToast(
                        "error",
                        message,
                    );
                } finally {
                    setLoading(
                        false,
                    );

                    setRefreshing(
                        false,
                    );
                }
            },
            [
                categoryFilter,
                search,
                showToast,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Initial / Filter Load
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        const timer =
            window.setTimeout(
                () => {
                    void loadRates(
                        true,
                    );
                },
                search.trim()
                    ? 300
                    : 0,
            );

        return () =>
            window.clearTimeout(
                timer,
            );
    }, [
        categoryFilter,
        loadRates,
        search,
    ]);

    /*
    |--------------------------------------------------------------------------
    | Client Filter
    |--------------------------------------------------------------------------
    |
    | The backend is already filtering. This second pass protects the
    | existing UI if the backend returns a broader dataset.
    |
    |--------------------------------------------------------------------------
    */

    const filtered =
        useMemo(() => {
            const q =
                search
                    .trim()
                    .toLowerCase();

            return data.filter(
                (row) => {
                    const matchesCategory =
                        categoryFilter ===
                            "all" ||
                        row.category
                            .trim()
                            .toLowerCase() ===
                            categoryFilter
                                .trim()
                                .toLowerCase();

                    const matchesSearch =
                        q ===
                            "" ||
                        row.code
                            .toLowerCase()
                            .includes(
                                q,
                            ) ||
                        row.description
                            .toLowerCase()
                            .includes(
                                q,
                            ) ||
                        row.subcategory
                            .toLowerCase()
                            .includes(
                                q,
                            );

                    return (
                        matchesCategory &&
                        matchesSearch
                    );
                },
            );
        }, [
            categoryFilter,
            data,
            search,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Add
    |--------------------------------------------------------------------------
    */

    function openAdd() {
        setEditingId(
            null,
        );

        setForm(
            emptyRateForm(
                todayIso(),
            ),
        );

        setActionError(
            "",
        );

        setFormOpen(
            true,
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Edit
    |--------------------------------------------------------------------------
    */

    function openEdit(
        row: RateItem,
    ) {
        setEditingId(
            row.id,
        );

        setForm(
            buildFormFromRate(
                row,
            ),
        );

        setActionError(
            "",
        );

        setFormOpen(
            true,
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Close Form
    |--------------------------------------------------------------------------
    */

    function closeForm() {
        if (saving) {
            return;
        }

        setFormOpen(
            false,
        );

        setEditingId(
            null,
        );

        setForm(
            emptyRateForm(
                todayIso(),
            ),
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Validate Form
    |--------------------------------------------------------------------------
    */

    const validateForm =
        useCallback(() => {
            if (
                !form.category.trim()
            ) {
                showToast(
                    "error",
                    "Category is required.",
                );

                return false;
            }

            if (
                !form.subcategory.trim()
            ) {
                showToast(
                    "error",
                    "Module is required.",
                );

                return false;
            }

            if (
                !form.description.trim()
            ) {
                showToast(
                    "error",
                    "Description is required.",
                );

                return false;
            }

            if (
                !form.unit.trim()
            ) {
                showToast(
                    "error",
                    "Unit of measure is required.",
                );

                return false;
            }

            const rate =
                Number(
                    form.standardRate,
                );

            if (
                !Number.isFinite(
                    rate,
                ) ||
                rate < 0
            ) {
                showToast(
                    "error",
                    "Standard rate must be a valid non-negative number.",
                );

                return false;
            }

            if (
                !form.effectiveDate
            ) {
                showToast(
                    "error",
                    "Effective date is required.",
                );

                return false;
            }

            return true;
        }, [
            form,
            showToast,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Save
    |--------------------------------------------------------------------------
    */

    const saveForm =
        useCallback(
            async () => {
                if (
                    saving ||
                    !validateForm()
                ) {
                    return;
                }

                setSaving(
                    true,
                );

                setActionError(
                    "",
                );

                const payload = {
                    category:
                        form.category.trim(),

                    categoryType:
                        form.categorytype.trim(),

                    subcategory:
                        form.subcategory.trim(),

                    description:
                        form.description.trim(),

                    unit:
                        form.unit.trim(),

                    standardRate:
                        Number(
                            form.standardRate,
                        ),

                    effectiveDate:
                        form.effectiveDate,

                    status:
                        form.status,
                };

                try {
                    if (
                        editingId
                    ) {
                        const response =
                            await api.patch<
                                ApiResponse<unknown>
                            >(
                                `${MASTER_RATE_ENDPOINT}/${encodeURIComponent(
                                    editingId,
                                )}`,
                                payload,
                            );

                        const updated =
                            normalizeRateItem(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            updated
                        ) {
                            setData(
                                (
                                    previous,
                                ) =>
                                    previous.map(
                                        (
                                            row,
                                        ) =>
                                            row.id ===
                                            updated.id
                                                ? updated
                                                : row,
                                    ),
                            );
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Master rate updated successfully.",
                        );
                    } else {
                        const response =
                            await api.post<
                                ApiResponse<unknown>
                            >(
                                MASTER_RATE_ENDPOINT,
                                payload,
                            );

                        const created =
                            normalizeRateItem(
                                response
                                    .data
                                    ?.data,
                            );

                        if (created) {
                            setData((previous) => [
                                created,
                                ...previous.filter(
                                    (row) => row.id !== created.id,
                                ),
                            ]);
                        } else {
                            await loadRates(false);
                        }

                        showToast(
                            "success",
                            response
                                .data
                                ?.message ||
                                "Master rate created successfully.",
                        );
                    }

                    closeForm();
                } catch (error) {
                    const message =
                        getErrorMessage(
                            error,
                            editingId
                                ? "Unable to update master rate."
                                : "Unable to create master rate.",
                        );

                    setActionError(
                        message,
                    );

                    showToast(
                        "error",
                        message,
                    );
                } finally {
                    setSaving(
                        false,
                    );
                }
            },
            [
                closeForm,
                editingId,
                form,
                loadRates,
                saving,
                showToast,
                validateForm,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Status Toggle
    |--------------------------------------------------------------------------
    */

    const toggleStatus =
        useCallback(
            async (
                row: RateItem,
            ) => {
                if (
                    togglingId ===
                    row.id
                ) {
                    return;
                }

                const nextStatus =
                    row.status ===
                    "active"
                        ? "inactive"
                        : "active";

                const previousStatus =
                    row.status;

                /*
                 * Optimistic update.
                 */
                setData(
                    (
                        previous,
                    ) =>
                        previous.map(
                            (item) =>
                                item.id ===
                                row.id
                                    ? {
                                          ...item,
                                          status:
                                              nextStatus,
                                      }
                                    : item,
                        ),
                );

                setTogglingId(
                    row.id,
                );

                try {
                    const response =
                        await api.patch<
                            ApiResponse<unknown>
                        >(
                            `${MASTER_RATE_ENDPOINT}/${encodeURIComponent(
                                row.id,
                            )}/status`,
                            {
                                status:
                                    nextStatus,
                            },
                        );

                    const updated =
                        normalizeRateItem(
                            response
                                .data
                                ?.data,
                        );

                    if (
                        updated
                    ) {
                        setData(
                            (
                                previous,
                            ) =>
                                previous.map(
                                    (
                                        item,
                                    ) =>
                                        item.id ===
                                        updated.id
                                            ? updated
                                            : item,
                                ),
                        );
                    }

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            (nextStatus ===
                            "active"
                                ? "Master rate enabled successfully."
                                : "Master rate disabled successfully."),
                    );
                } catch (error) {
                    /*
                     * Rollback.
                     */
                    setData(
                        (
                            previous,
                        ) =>
                            previous.map(
                                (
                                    item,
                                ) =>
                                    item.id ===
                                    row.id
                                        ? {
                                              ...item,
                                              status:
                                                  previousStatus,
                                          }
                                        : item,
                            ),
                    );

                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to update master rate status.",
                        ),
                    );
                } finally {
                    setTogglingId(
                        null,
                    );
                }
            },
            [
                showToast,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | History
    |--------------------------------------------------------------------------
    */

    const openHistory =
        useCallback(
            async (
                row: RateItem,
            ) => {
                /*
                 * Open immediately using whatever history is already
                 * present in the list response.
                 */
                setHistoryRow(
                    row,
                );

                setHistoryError(
                    "",
                );

                setHistoryLoading(
                    true,
                );

                try {
                    const response =
                        await api.get<
                            ApiResponse<
                                RateHistoryApiItem[]
                            >
                        >(
                            `${MASTER_RATE_ENDPOINT}/${encodeURIComponent(
                                row.id,
                            )}/history`,
                        );

                    if (
                        response
                            .data
                            ?.success ===
                        false
                    ) {
                        throw new Error(
                            response
                                .data
                                ?.message ||
                                "Unable to load rate history.",
                        );
                    }

                    const history =
                        Array.isArray(
                            response
                                .data
                                ?.data,
                        )
                            ? response.data.data
                                  .map(
                                      normalizeHistoryItem,
                                  )
                                  .filter(
                                      (
                                          item,
                                      ): item is RateHistoryApiItem =>
                                          item !==
                                          null,
                                  )
                            : [];

                    setHistoryRow(
                        (
                            previous,
                        ) => {
                            if (
                                !previous ||
                                previous.id !==
                                    row.id
                            ) {
                                return previous;
                            }

                            return {
                                ...previous,
                                history,
                            };
                        },
                    );
                } catch (error) {
                    setHistoryError(
                        getErrorMessage(
                            error,
                            "Unable to load rate history.",
                        ),
                    );

                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to load rate history.",
                        ),
                    );
                } finally {
                    setHistoryLoading(
                        false,
                    );
                }
            },
            [showToast],
        );

    /*
    |--------------------------------------------------------------------------
    | Delete
    |--------------------------------------------------------------------------
    */

    const confirmDelete =
        useCallback(
            async () => {
                if (
                    !deleteTarget ||
                    deleting
                ) {
                    return;
                }

                setDeleting(
                    true,
                );

                try {
                    const response =
                        await api.delete<
                            ApiResponse<unknown>
                        >(
                            `${MASTER_RATE_ENDPOINT}/${encodeURIComponent(
                                deleteTarget.id,
                            )}`,
                        );

                    setData(
                        (
                            previous,
                        ) =>
                            previous.filter(
                                (
                                    row,
                                ) =>
                                    row.id !==
                                    deleteTarget.id,
                            ),
                    );

                    setDeleteTarget(
                        null,
                    );

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            "Master rate deleted successfully.",
                    );
                } catch (error) {
                    showToast(
                        "error",
                        getErrorMessage(
                            error,
                            "Unable to delete master rate.",
                        ),
                    );
                } finally {
                    setDeleting(
                        false,
                    );
                }
            },
            [
                deleteTarget,
                deleting,
                showToast,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Import
    |--------------------------------------------------------------------------
    |
    | The existing frontend CSV utility remains available as a local
    | validation/fallback parser. The actual persistence is now sent
    | to the backend import endpoint.
    |
    |--------------------------------------------------------------------------
    */

    async function handleImportFile(
        event: React.ChangeEvent<HTMLInputElement>,
    ) {
        const file =
            event.target.files?.[0];

        if (!file) {
            return;
        }

        event.target.value = "";

        if (
            !file.name
                .toLowerCase()
                .endsWith(
                    ".csv",
                )
        ) {
            showToast(
                "error",
                "Please select a CSV file.",
            );

            return;
        }

        try {
            setSaving(
                true,
            );

            setActionError(
                "",
            );

            /*
             * First parse locally so malformed CSVs fail early.
             */
            await parseRatesCsvFile(
                file,
            );

            const formData =
                new FormData();

            formData.append(
                "file",
                file,
                file.name,
            );

            const response =
                await api.post<
                    ApiResponse<unknown>
                >(
                    `${MASTER_RATE_ENDPOINT}/import`,
                    formData,
                );

            await loadRates(
                false,
            );

            const summary =
                (
                    response
                        .data
                        ?.data as {
                        summary?: {
                            created?: number;
                            updated?: number;
                            unchanged?: number;
                        };
                    }
                )?.summary;

            const summaryText =
                summary
                    ? ` Created: ${
                          summary.created ??
                          0
                      }, updated: ${
                          summary.updated ??
                          0
                      }, unchanged: ${
                          summary.unchanged ??
                          0
                      }.`
                    : "";

            showToast(
                "success",
                `${
                    response
                        .data
                        ?.message ||
                    "Master rates imported successfully."
                }${summaryText}`,
            );
        } catch (error) {
            showToast(
                "error",
                getErrorMessage(
                    error,
                    "Unable to import master rates.",
                ),
            );
        } finally {
            setSaving(
                false,
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Export
    |--------------------------------------------------------------------------
    */

    const handleExport =
        useCallback(async () => {
            try {
                /*
                 * Server-side CSV export is the production path.
                 */
                const response =
                    await api.get(
                        `${MASTER_RATE_ENDPOINT}/export`,
                        {
                            params: {
                                search:
                                    search.trim(),

                                category:
                                    categoryFilter ===
                                    "all"
                                        ? ""
                                        : categoryFilter,
                            },

                            responseType:
                                "blob",
                        },
                    );

                const blob =
                    response.data;

                const url =
                    window.URL.createObjectURL(
                        blob,
                    );

                const anchor =
                    document.createElement(
                        "a",
                    );

                anchor.href =
                    url;

                anchor.download =
                    "master-rate-schedule.csv";

                document.body.appendChild(
                    anchor,
                );

                anchor.click();

                anchor.remove();

                window.URL.revokeObjectURL(
                    url,
                );
            } catch (error) {
                /*
                 * Keep existing CSV helper as a safe fallback if the
                 * backend export endpoint is unavailable.
                 */
                try {
                    exportRatesToCsv(
                        filtered,
                    );

                    showToast(
                        "success",
                        "Master rates exported successfully.",
                    );
                } catch (fallbackError) {
                    showToast(
                        "error",
                        getErrorMessage(
                            fallbackError,
                            getErrorMessage(
                                error,
                                "Unable to export master rates.",
                            ),
                        ),
                    );
                }
            }
        }, [
            categoryFilter,
            filtered,
            search,
            showToast,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Columns
    |--------------------------------------------------------------------------
    */

    const columns =
        useMemo<
            DataTableColumn<RateItem>[]
        >(
            () => [
                {
                    key: "subcategory",

                    label:
                        "Module",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex flex-col gap-1">
                                <span className="text-xs font-semibold uppercase tracking-wide text-slate-900">
                                    {
                                        row.subcategory
                                    }
                                </span>
                            </div>
                        ),
                },

                {
                    key: "category",

                    label:
                        "Category",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex flex-col gap-1">
                                <span className="text-xs font-semibold uppercase tracking-wide text-slate-900">
                                    {
                                        row.category
                                    }
                                </span>

                                <span className="w-fit rounded bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-bold text-slate-500">
                                    {
                                        row.code
                                    }
                                </span>
                            </div>
                        ),
                },

                {
                    key: "categoryType",

                    label:
                        "Category Type",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <span className="text-xs font-semibold uppercase tracking-wide text-slate-900">
                                {
                                    row.categoryType
                                }
                            </span>
                        ),
                },

                {
                    key: "description",

                    label:
                        "Description",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <span className="text-xs leading-5 text-slate-500">
                                {
                                    row.description
                                }
                            </span>
                        ),
                },

                {
                    key: "unit",

                    label:
                        "Unit",

                    width:
                        "3%",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <span className="text-xs font-semibold text-slate-700">
                                {
                                    row.unit
                                }
                            </span>
                        ),
                },

                {
                    key: "standardRate",

                    label:
                        "Standard Rate",

                    align:
                        "center",

                    sortable:
                        true,

                    render:
                        (
                            row,
                        ) => (
                            <span className="font-bold text-slate-900">
                                {fmtJmd(
                                    row.standardRate,
                                )}
                            </span>
                        ),
                },

                {
                    key: "effectiveDate",

                    label:
                        "Effective Date",

                    sortable:
                        true,

                    width:
                        "9%",

                    render:
                        (
                            row,
                        ) => (
                            <span className="text-xs text-slate-600">
                                {
                                    row.effectiveDate
                                }
                            </span>
                        ),
                },

                {
                    key: "status",

                    label:
                        "Status",

                    align:
                        "center",

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex justify-center">
                                <ToggleSwitch
                                    checked={
                                        row.status ===
                                        "active"
                                    }
                                    onChange={() =>
                                        void toggleStatus(
                                            row,
                                        )
                                    }
                                    disabled={
                                        togglingId ===
                                        row.id
                                    }
                                    srLabel={`Toggle status for ${row.code}`}
                                />
                            </div>
                        ),
                },

                {
                    key: "action",

                    label:
                        "Actions",

                    align:
                        "center",

                    render:
                        (
                            row,
                        ) => (
                            <div className="flex items-center justify-center gap-2">
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() =>
                                        void openHistory(
                                            row,
                                        )
                                    }
                                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                                    title="View rate history"
                                    disabled={
                                        historyLoading &&
                                        historyRow?.id ===
                                            row.id
                                    }
                                >
                                    {historyLoading &&
                                    historyRow?.id ===
                                        row.id ? (
                                        <SpinnerGapIcon
                                            size={
                                                16
                                            }
                                            className="animate-spin"
                                        />
                                    ) : (
                                        <ClockCounterClockwiseIcon
                                            size={
                                                16
                                            }
                                        />
                                    )}
                                </Button>

                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() =>
                                        openEdit(
                                            row,
                                        )
                                    }
                                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                                    title="Edit rate"
                                    disabled={
                                        saving ||
                                        deleting
                                    }
                                >
                                    <PenNibIcon
                                        size={
                                            16
                                        }
                                    />
                                </Button>

                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() =>
                                        setDeleteTarget(
                                            row,
                                        )
                                    }
                                    className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                                    title="Delete rate"
                                    disabled={
                                        deleting
                                    }
                                >
                                    <TrashIcon
                                        size={
                                            16
                                        }
                                    />
                                </Button>
                            </div>
                        ),
                },
            ],
            [
                deleting,
                historyLoading,
                historyRow?.id,
                openHistory,
                saving,
                toggleStatus,
                togglingId,
            ],
        );

    /*
    |--------------------------------------------------------------------------
    | Render
    |--------------------------------------------------------------------------
    */

    return (
        <>
            {/* ==============================================================
             * Header
             * ============================================================== */}

            <div className="mb-6 flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        Master Rate
                        Schedule
                    </h1>

                    {refreshing && (
                        <p className="mt-1 flex items-center gap-1.5 text-[11px] font-medium text-slate-400">
                            <SpinnerGapIcon
                                size={
                                    12
                                }
                                className="animate-spin"
                            />
                            Updating
                            rates...
                        </p>
                    )}
                </div>

                <div className="flex flex-wrap items-center gap-3">
                    <input
                        ref={
                            importInputRef
                        }
                        type="file"
                        accept=".csv,text/csv"
                        className="hidden"
                        onChange={
                            handleImportFile
                        }
                    />

                    <Button
                        variant="outline"
                        onClick={() =>
                            void loadRates(false)
                        }
                        disabled={
                            loading ||
                            saving ||
                            refreshing
                        }
                        title="Refresh master rates"
                    >
                        <ArrowClockwiseIcon
                            size={16}
                            className={refreshing ? "animate-spin" : ""}
                        />
                        Refresh
                    </Button>

                    <Button
                        variant="outline"
                        onClick={() =>
                            importInputRef.current?.click()
                        }
                        disabled={
                            saving ||
                            loading
                        }
                    >
                        <UploadSimpleIcon
                            size={
                                16
                            }
                        />

                        Bulk Import
                    </Button>

                    <Button
                        variant="outline"
                        onClick={() =>
                            void handleExport()
                        }
                        disabled={
                            loading ||
                            saving ||
                            filtered.length ===
                                0
                        }
                    >
                        <DownloadSimpleIcon
                            size={
                                16
                            }
                        />

                        Export CSV
                    </Button>

                    <Button
                        onClick={
                            openAdd
                        }
                        disabled={
                            loading ||
                            saving
                        }
                    >
                        <PlusIcon
                            size={
                                16
                            }
                        />

                        Add New Rate
                    </Button>
                </div>
            </div>

            {/* ==============================================================
             * Toast
             * ============================================================== */}

            {toast.message && (
                <div
                    className={`mb-4 flex items-start gap-3 rounded-xl border px-4 py-3 ${
                        toast.type ===
                        "success"
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : "border-red-200 bg-red-50 text-red-700"
                    }`}
                    role="status"
                    aria-live="polite"
                >
                    {toast.type ===
                    "success" ? (
                        <CheckCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    ) : (
                        <XCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0"
                        />
                    )}

                    <span className="text-xs font-semibold">
                        {
                            toast.message
                        }
                    </span>
                </div>
            )}

            {/* ==============================================================
             * Error
             * ============================================================== */}

            {actionError && (
                <div className="mb-4 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
                    <WarningCircleIcon
                        size={
                            18
                        }
                        weight="duotone"
                        className="mt-0.5 shrink-0 text-red-600"
                    />

                    <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-red-700">
                            Unable to
                            complete
                            the
                            request
                        </p>

                        <p className="mt-1 text-xs leading-5 text-red-600">
                            {
                                actionError
                            }
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            setActionError(
                                "",
                            )
                        }
                        className="shrink-0 text-red-400 hover:text-red-700"
                        aria-label="Dismiss error"
                    >
                        <XCircleIcon
                            size={
                                18
                            }
                        />
                    </button>
                </div>
            )}

            {/* ==============================================================
             * Filters
             * ============================================================== */}

            <RateFilters
                search={
                    search
                }
                onSearchChange={
                    setSearch
                }
                category={
                    categoryFilter
                }
                onCategoryChange={
                    setCategoryFilter
                }
                resultCount={
                    filtered.length
                }
            />

            {/* ==============================================================
             * Table
             * ============================================================== */}

            {loading ? (
                <div className="flex min-h-[320px] items-center justify-center rounded-xl border border-slate-200 bg-white">
                    <div className="flex flex-col items-center gap-3">
                        <SpinnerGapIcon
                            size={
                                28
                            }
                            className="animate-spin text-red-600"
                            weight="bold"
                        />

                        <p className="text-xs font-semibold text-slate-500">
                            Loading
                            master
                            rates...
                        </p>
                    </div>
                </div>
            ) : (
                <DataTable<RateItem>
                    columns={
                        columns
                    }
                    data={
                        filtered
                    }
                    rowKey={(
                        row,
                    ) =>
                        row.id
                    }
                    emptyMessage="No rates match your filters."
                />
            )}

            {/* ==============================================================
             * Add / Edit Offcanvas
             * ============================================================== */}

            <RateFormOffCanvas
                isOpen={
                    formOpen
                }
                isEditing={
                    !!editingId
                }
                form={
                    form
                }
                onChange={
                    setForm
                }
                onClose={
                    closeForm
                }
                onSave={() =>
                    void saveForm()
                }
            />

            {/* ==============================================================
             * History Offcanvas
             * ============================================================== */}

            <RateHistoryOffCanvas
                row={
                    historyRow
                }
                onClose={() => {
                    setHistoryRow(
                        null,
                    );

                    setHistoryError(
                        "",
                    );
                    setHistoryLoading(
                        false,
                    );
                }}
                loading={
                    historyLoading
                }
                error={
                    historyError
                }
            />

            {/* ==============================================================
             * Delete Confirmation
             * ============================================================== */}

            <ConfirmDialog
                open={
                    !!deleteTarget
                }
                title="Delete rate?"
                message={
                    deleteTarget
                        ? `"${deleteTarget.description}" (${deleteTarget.code}) will be removed from the schedule. This can't be undone.`
                        : ""
                }
                onCancel={() => {
                    if (
                        deleting
                    ) {
                        return;
                    }

                    setDeleteTarget(
                        null,
                    );
                }}
                onConfirm={() =>
                    void confirmDelete()
                }
            />
        </>
    );
}