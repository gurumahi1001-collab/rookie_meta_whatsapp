import SurveyList from "../components/SurveyReport/SurveyList";

const SurveyTemplate = () => <SurveyList />;

export default SurveyTemplate;
