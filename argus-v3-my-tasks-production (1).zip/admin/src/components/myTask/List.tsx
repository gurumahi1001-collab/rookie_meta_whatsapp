import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import IconNotes from '../../components/Icon/IconNotes';

import Kanban from './Kanban';
import { CaretDownIcon, KanbanIcon, ListIcon, Pencil, Plus, X } from '@phosphor-icons/react';
import Edit, { Task, } from '../../offcanvas/mytask/edit';
import IconSearch from '../Icon/IconSearch';
import IconRefresh from '../Icon/IconRefresh';
import { Trash } from '@phosphor-icons/react/dist/ssr';
import { createTask, deleteTask, listTaskAssignees, listTaskProjects, listTasks, updateTask } from '../../api/taskApi';
import type { TaskAssigneeOption, TaskProjectOption } from '../../api/taskApi';

export type TaskStatus =
    | 'Pending'
    | 'In Progress'
    | 'On Hold'
    | 'Due Date'
    | 'Completed';

export type TaskPriority =
    | 'Low'
    | 'Medium'
    | 'High'
    | 'Urgent';

const List = () => {
    const [view, setView] = useState<'list' | 'kanban'>('list');
    const [tasks, setTasks] = useState<Task[]>([]);
    const [teamMembers, setTeamMembers] = useState<TaskAssigneeOption[]>([]);
    const [projects, setProjects] = useState<TaskProjectOption[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState<'All' | TaskStatus>('All');
    const [priorityFilter, setPriorityFilter] = useState<'All' | TaskPriority>('All');
    const [showModal, setShowModal] = useState(false);
    const [editingTask, setEditingTask] = useState<Task | null>(null);
    const [showTaskDrawer, setShowTaskDrawer] = useState(false);
    const [selectedTask, setSelectedTask] = useState<Task | null>(null);
    const [isEditTaskOpen, setIsEditTaskOpen] = useState(false);
    const [userFilter, setUserFilter] = useState<string>('All');
    const [expandedStaffTaskId, setExpandedStaffTaskId] = useState<string | number | null>(null);

    // Form state uses plain string names for the staff picker
    const [form, setForm] = useState<Omit<Task, 'id' | 'Assignstaff'> & { Assignstaff: string[] }>({
        title: '',
        description: '',
        project: '',
        Assignstaff: [],
        phase: '',
        startDate: '',
        dueDate: '',
        priority: 'Medium',
        status: 'Pending',
        progress: 0,
    });

    const loadReferenceData = async () => {
        const [assignees, projectRows] = await Promise.all([listTaskAssignees(), listTaskProjects()]);
        setTeamMembers(assignees);
        setProjects(projectRows);
    };

    const loadTasks = async () => {
        setLoading(true);
        try {
            const result = await listTasks({ limit: 250 });
            setTasks(result.data);
        } catch (error) {
            alert(error instanceof Error ? error.message : 'Unable to load tasks.');
            setTasks([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        Promise.all([loadReferenceData(), loadTasks()]).catch((error) => {
            alert(error instanceof Error ? error.message : 'Unable to load task data.');
        });
    }, []);

    const projectPhases = useMemo(() => {
        const project = projects.find((item) => item.name === form.project);
        return project?.phases || [];
    }, [projects, form.project]);

    const filteredTasks = useMemo(() => {
        return tasks.filter((task) => {
            const searchText = search.trim().toLowerCase();

            const matchesSearch =
                task.title.toLowerCase().includes(searchText) ||
                task.description.toLowerCase().includes(searchText) ||
                task.project.toLowerCase().includes(searchText) ||
                task.phase.toLowerCase().includes(searchText) ||
                task.Assignstaff.some((staff) =>
                    staff.name.toLowerCase().includes(searchText)
                );

            const matchesStatus =
                statusFilter === 'All' || task.status === statusFilter;

            const matchesPriority =
                priorityFilter === 'All' || task.priority === priorityFilter;

            const matchesUser =
                userFilter === 'All' ||
                task.Assignstaff.some((staff) => staff.name === userFilter);

            return matchesSearch && matchesStatus && matchesPriority && matchesUser;
        });
    }, [tasks, search, statusFilter, priorityFilter, userFilter]);

    const totalTasks = tasks.length;
    const pendingTasks = tasks.filter((task) => task.status === 'Pending').length;
    const inProgressTasks = tasks.filter((task) => task.status === 'In Progress').length;
    const onHoldTasks = tasks.filter((task) => task.status === 'On Hold').length;
    const dueDateTasks = tasks.filter((task) => task.status === 'Due Date').length;
    const completedTasks = tasks.filter((task) => task.status === 'Completed').length;

    const openAddModal = () => {
        setEditingTask(null);
        setForm({
            title: '',
            description: '',
            project: '',
            Assignstaff: [],
            phase: '',
            startDate: '',
            dueDate: '',
            priority: 'Medium',
            status: 'Pending',
            progress: 0,
        });
        setShowModal(true);
    };

    const openEditModal = (task: Task) => {
        setEditingTask(task);
        setForm({
            title: task.title,
            description: task.description,
            project: task.project,
            Assignstaff: (task.Assignstaff || []).map((s) => s.id || s.userId || s.name),
            phase: task.phase || '',
            startDate: task.startDate,
            dueDate: task.dueDate,
            priority: task.priority,
            status: task.status,
            progress: task.progress,
        });
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setEditingTask(null);
    };

    const openTaskDrawer = (task: Task) => {
        setSelectedTask(task);
        setShowTaskDrawer(true);
    };

    const closeTaskDrawer = () => {
        setShowTaskDrawer(false);
        setSelectedTask(null);
    };

    const persistTask = async (updatedTask: Task) => {
        try {
            const saved = await updateTask(String(updatedTask.id), {
                title: updatedTask.title,
                description: updatedTask.description,
                projectId: updatedTask.projectId,
                phase: updatedTask.phase,
                Assignstaff: (updatedTask.Assignstaff || []).map((staff) => staff.id || staff.userId || staff.name),
                startDate: updatedTask.startDate,
                dueDate: updatedTask.dueDate,
                priority: updatedTask.priority,
                status: updatedTask.status,
                progress: updatedTask.progress,
                estimatedHours: updatedTask.estimatedHours,
                timerStartedAt: updatedTask.timerStartedAt,
                totalWorkedSeconds: updatedTask.totalWorkedSeconds,
                workLogs: updatedTask.workLogs || [],
                materials: updatedTask.materials || [],
                otherExpenses: updatedTask.otherExpenses || [],
                conversations: (updatedTask.conversations || []).map((item) => ({ id: String(item.id), type: item.type, text: item.text, createdAt: item.createdAt, imageStorageKey: item.imageStorageKey || '' })),
            });
            setTasks((current) => current.map((task) => String(task.id) === String(saved.id) ? saved : task));
            setSelectedTask(saved);
            return saved;
        } catch (error) {
            alert(error instanceof Error ? error.message : 'Unable to update task.');
            return null;
        }
    };

    const updateTaskLocal = (updatedTask: Task) => { void persistTask(updatedTask); };
    const handleUpdateTaskFromDrawer = (updatedTask: Task) => { void persistTask(updatedTask); };

    const handleSaveTask = async () => {
        if (!form.title.trim() || !form.description.trim() || !form.project.trim() || form.Assignstaff.length === 0 || !form.phase.trim() || !form.startDate || !form.dueDate) {
            alert('Please fill all required fields.');
            return;
        }

        if (new Date(form.dueDate) < new Date(form.startDate)) {
            alert('Due date cannot be earlier than start date.');
            return;
        }

        const project = projects.find((item) => item.name === form.project);
        if (!project) { alert('Please select a valid project.'); return; }
        const payload = {
            title: form.title, description: form.description, projectId: project.id, project: project.name, Assignstaff: form.Assignstaff,
            phase: form.phase, startDate: form.startDate, dueDate: form.dueDate, priority: form.priority, status: form.status, progress: form.progress,
            estimatedHours: form.estimatedHours || 0,
        };
        try {
            const saved = editingTask ? await updateTask(String(editingTask.id), payload) : await createTask(payload);
            setTasks((current) => editingTask ? current.map((task) => String(task.id) === String(saved.id) ? saved : task) : [saved, ...current]);
            setSelectedTask(saved);
            closeModal();
        } catch (error) {
            alert(error instanceof Error ? error.message : 'Unable to save task.');
        }

    };

    const handleDelete = async (id: string | number) => {
        if (!window.confirm('Are you sure you want to delete this task?')) return;
        try { await deleteTask(String(id)); setTasks((current) => current.filter((task) => String(task.id) !== String(id))); if (selectedTask && String(selectedTask.id) === String(id)) closeTaskDrawer(); if (String(expandedStaffTaskId) === String(id)) setExpandedStaffTaskId(null); }
        catch (error) { alert(error instanceof Error ? error.message : 'Unable to delete task.'); }
    };

    const handleRefresh = async () => {
        setSearch(''); setStatusFilter('All'); setPriorityFilter('All'); setUserFilter('All'); setExpandedStaffTaskId(null); await loadTasks();
    };

    const priorityClass = (priority: TaskPriority) => {
        switch (priority) {
            case 'Urgent': return 'bg-red-100 text-red-700';
            case 'High': return 'bg-orange-100 text-orange-700';
            case 'Medium': return 'bg-yellow-100 text-yellow-700';
            default: return 'bg-green-100 text-green-700';
        }
    };

    const statusClass = (status: TaskStatus) => {
        switch (status) {
            case 'Completed': return 'bg-green-100 text-green-700';
            case 'In Progress': return 'bg-blue-100 text-blue-700';
            case 'On Hold': return 'bg-orange-100 text-orange-700';
            case 'Due Date': return 'bg-red-100 text-red-700';
            default: return 'bg-slate-100 text-slate-700';
        }
    };

    const phaseClass = (phase: string) => {
        switch (phase) {
            case 'Planning': return 'bg-purple-100 text-purple-700';
            case 'Pre-Sales': return 'bg-indigo-100 text-indigo-700';
            case 'Estimation': return 'bg-cyan-100 text-cyan-700';
            case 'Procurement': return 'bg-yellow-100 text-yellow-700';
            case 'Execution': return 'bg-blue-100 text-blue-700';
            case 'Billing': return 'bg-green-100 text-green-700';
            case 'Closing': return 'bg-slate-100 text-slate-700';
            default: return 'bg-slate-100 text-slate-700';
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">My Tasks</h1>
                    <p className="mt-1 text-sm text-slate-500">
                        Create, manage and track your project tasks
                    </p>
                </div>

                <div className="flex items-center gap-3">
                    <div className="flex items-center rounded-lg border border-slate-200 bg-white p-1 shadow-sm">
                        <button
                            type="button"
                            onClick={() => setView('list')}
                            title="List View"
                            className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition ${
                                view === 'list'
                                    ? 'bg-primary text-white'
                                    : 'text-slate-600 hover:bg-slate-100'
                            }`}
                        >
                            <ListIcon size={18} />
                            <span className="hidden sm:inline">List</span>
                        </button>

                        <button
                            type="button"
                            onClick={() => setView('kanban')}
                            title="Kanban View"
                            className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition ${
                                view === 'kanban'
                                    ? 'bg-primary text-white'
                                    : 'text-slate-600 hover:bg-slate-100'
                            }`}
                        >
                            <KanbanIcon size={18} />
                            <span className="hidden sm:inline">Kanban</span>
                        </button>
                    </div>

                    <button
                        type="button"
                        onClick={openAddModal}
                        className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-white shadow-sm hover:opacity-90"
                    >
                        <Plus size={18} />
                        Create New Task
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-6">
                <DashboardCard title="Total Tasks" value={totalTasks} />
                <DashboardCard title="Pending" value={pendingTasks} />
                <DashboardCard title="In Progress" value={inProgressTasks} />
                <DashboardCard title="On Hold" value={onHoldTasks} />
                <DashboardCard title="Due Date" value={dueDateTasks} />
                <DashboardCard title="Completed" value={completedTasks} />
            </div>

            {loading ? (
                <div className="rounded-xl border border-slate-200 bg-white px-6 py-16 text-center text-sm text-slate-500 shadow-sm">Loading tasks...</div>
            ) : view === 'list' && (
                <>
                    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                        <div className="flex flex-col gap-3 xl:flex-row">
                            <div className="relative flex-1">
                                <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                <input
                                    type="text"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                    placeholder="Search tasks, projects, phases or team members..."
                                    className="w-full rounded-lg border border-slate-200 py-2.5 pl-10 pr-4 text-sm outline-none focus:border-primary"
                                />
                            </div>

                            <select
                                value={userFilter}
                                onChange={(e) => setUserFilter(e.target.value)}
                                className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary"
                            >
                                <option value="All">All Users</option>
                                {teamMembers.map((member) => (
                                    <option key={member.id} value={member.name}>{member.name}</option>
                                ))}
                            </select>

                            <select
                                value={statusFilter}
                                onChange={(e) =>
                                    setStatusFilter(e.target.value as 'All' | TaskStatus)
                                }
                                className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary"
                            >
                                <option value="All">All Status</option>
                                <option value="Pending">Pending</option>
                                <option value="In Progress">In Progress</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Due Date">Due Date</option>
                                <option value="Completed">Completed</option>
                            </select>

                            <select
                                value={priorityFilter}
                                onChange={(e) =>
                                    setPriorityFilter(e.target.value as 'All' | TaskPriority)
                                }
                                className="rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary"
                            >
                                <option value="All">All Priority</option>
                                <option value="Urgent">Urgent</option>
                                <option value="High">High</option>
                                <option value="Medium">Medium</option>
                                <option value="Low">Low</option>
                            </select>

                            <button
                                type="button"
                                onClick={handleRefresh}
                                className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50"
                            >
                                <IconRefresh />
                                Refresh
                            </button>
                        </div>
                    </div>

                    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                        <div className="overflow-x-auto">
                            <table className="w-full min-w-[1150px] text-left">
                                <thead className="bg-slate-50">
                                    <tr className="border-b border-slate-200">
                                        <th className="whitespace-nowrap px-5 py-4 text-xs font-semibold uppercase text-slate-500">Task</th>
                                        <th className="whitespace-nowrap px-5 py-4 text-xs font-semibold uppercase text-slate-500">Project</th>
                                        <th className="whitespace-nowrap px-5 py-4 text-xs font-semibold uppercase text-slate-500">Assign Staff</th>
                                        <th className="min-w-[125px] whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase text-slate-500">Start Date</th>
                                        <th className="min-w-[125px] whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase text-slate-500">Due Date</th>
                                        <th className="whitespace-nowrap px-5 py-4 text-xs font-semibold uppercase text-slate-500">Priority</th>
                                        <th className="whitespace-nowrap px-5 py-4 text-xs font-semibold uppercase text-slate-500">Progress</th>
                                        <th className="min-w-[130px] whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase text-slate-500">Status</th>
                                        <th className="whitespace-nowrap px-5 py-4 text-center text-xs font-semibold uppercase text-slate-500">Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {filteredTasks.length === 0 ? (
                                        <tr>
                                            <td colSpan={9} className="px-5 py-12 text-center text-sm text-slate-500">
                                                No tasks found.
                                            </td>
                                        </tr>
                                    ) : (
                                        filteredTasks.map((task) => {
                                            const staff = task.Assignstaff || [];
                                            const firstStaff = staff[0]?.name || 'Not assigned';
                                            const remainingStaff = staff.slice(1).map((s) => s.name);
                                            const isStaffExpanded = expandedStaffTaskId === task.id;

                                            return (
                                                <tr key={task.id} className="border-b border-slate-100 hover:bg-slate-50">
                                                    <td className="px-5 py-4">
                                                        <div className="whitespace-nowrap font-semibold text-slate-800">{task.title}</div>
                                                        <div className="mt-1 max-w-xs truncate text-xs text-slate-500">{task.description}</div>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <button
                                                            type="button"
                                                            onClick={() => openTaskDrawer(task)}
                                                            className="w-full text-left"
                                                        >
                                                            <div className="whitespace-nowrap text-sm font-semibold text-slate-700 hover:text-primary">{task.project}</div>
                                                            <div className="mt-1 whitespace-nowrap text-xs text-slate-500">{task.phase}</div>
                                                        </button>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <div className="relative flex min-w-[190px] items-center gap-2">
                                                            <span className="max-w-[145px] truncate whitespace-nowrap text-sm font-medium text-slate-600">{firstStaff}</span>

                                                            {remainingStaff.length > 0 && (
                                                                <div className="relative">
                                                                    <button
                                                                        type="button"
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            setExpandedStaffTaskId(isStaffExpanded ? null : task.id);
                                                                        }}
                                                                        className="flex items-center gap-1 rounded-md bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
                                                                        title="View assigned staff"
                                                                    >
                                                                        <span>+{remainingStaff.length}</span>
                                                                        <CaretDownIcon
                                                                            size={14}
                                                                            className={`transition-transform ${isStaffExpanded ? 'rotate-180' : ''}`}
                                                                        />
                                                                    </button>

                                                                    {isStaffExpanded && (
                                                                        <div
                                                                            onClick={(e) => e.stopPropagation()}
                                                                            className="absolute left-0 top-full z-50 mt-2 min-w-[190px] rounded-lg border border-slate-200 bg-white p-2 shadow-lg"
                                                                        >
                                                                            <div className="mb-1 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                                                                Assigned Staff
                                                                            </div>
                                                                            {remainingStaff.map((member) => (
                                                                                <div key={member} className="rounded-md px-2 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50">
                                                                                    {member}
                                                                                </div>
                                                                            ))}
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </td>

                                                    <td className="min-w-[125px] whitespace-nowrap px-4 py-3 text-sm text-slate-600">{formatDate(task.startDate)}</td>
                                                    <td className="min-w-[125px] whitespace-nowrap px-4 py-3 text-sm text-slate-600">{formatDate(task.dueDate)}</td>

                                                    <td className="px-5 py-4">
                                                        <span className={`inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold ${priorityClass(task.priority)}`}>
                                                            {task.priority}
                                                        </span>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <div className="w-28">
                                                            <div className="mb-1 flex justify-between text-xs">
                                                                <span className="whitespace-nowrap text-slate-500">Progress</span>
                                                                <span className="whitespace-nowrap font-semibold text-slate-700">{task.progress}%</span>
                                                            </div>
                                                            <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                                                                <div
                                                                    className="h-full rounded-full bg-primary"
                                                                    style={{
                                                                        width: `${Math.min(100, Math.max(0, task.progress))}%`,
                                                                    }}
                                                                />
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td className="min-w-[130px] whitespace-nowrap px-4 py-3">
                                                        <span className={`inline-flex items-center justify-center whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold ${statusClass(task.status)}`}>
                                                            {task.status}
                                                        </span>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <div className="flex items-center justify-center gap-2">
                                                            <button
                                                                type="button"
                                                                onClick={() => openEditModal(task)}
                                                                className="rounded-lg p-2 text-blue-600 hover:bg-blue-50"
                                                                title="Edit"
                                                            >
                                                                <Pencil size={17} />
                                                            </button>

                                                            <button
                                                                type="button"
                                                                onClick={() => handleDelete(task.id)}
                                                                className="rounded-lg p-2 text-red-600 hover:bg-red-50"
                                                                title="Delete"
                                                            >
                                                                <Trash size={17} />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </>
            )}

            {view === 'kanban' && (
                <Kanban
                    tasks={tasks}
                    onUpdateTask={updateTaskLocal}
                    onEditTask={openEditModal}
                    onDeleteTask={handleDelete}
                    onOpenTask={openTaskDrawer}
                />
            )}

            {showModal &&
                createPortal(
                    <div
                        className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60 p-4"
                        onMouseDown={(e) => {
                            if (e.target === e.currentTarget) closeModal();
                        }}
                    >
                        <div
                            className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white shadow-2xl"
                            onMouseDown={(e) => e.stopPropagation()}
                        >
                            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-200 bg-white px-6 py-5">
                                <div>
                                    <h2 className="text-xl font-bold text-slate-800">
                                        {editingTask ? 'Edit Task' : 'Add Task'}
                                    </h2>
                                    <p className="mt-1 text-sm text-slate-500">
                                        Add task details and track its progress.
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={closeModal}
                                    className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                                    aria-label="Close"
                                >
                                    <X size={20} />
                                </button>
                            </div>

                            <div className="grid grid-cols-1 gap-5 p-6 md:grid-cols-2">
                                <div className="md:col-span-2">
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Task Title *</label>
                                    <input
                                        type="text"
                                        value={form.title}
                                        onChange={(e) => setForm({ ...form, title: e.target.value })}
                                        placeholder="Enter task title"
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    />
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Project *</label>
                                    <select
                                        value={form.project}
                                        onChange={(e) => setForm({ ...form, project: e.target.value })}
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    >
                                        <option value="">Select Project</option>
                                        {projects.map((project) => (
                                            <option key={project.id} value={project.name}>{project.name}</option>
                                        ))}
                                    </select>
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Phase *</label>
                                    <select
                                        value={form.phase}
                                        onChange={(e) => setForm({ ...form, phase: e.target.value })}
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    >
                                        <option value="">Select Phase</option>
                                        {projectPhases.map((phase) => (
                                            <option key={phase} value={phase}>{phase}</option>
                                        ))}
                                    </select>
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Assign Staff *</label>
                                    <select
                                        value={form.Assignstaff[0] || ''}
                                        onChange={(e) =>
                                            setForm({
                                                ...form,
                                                Assignstaff: e.target.value ? [e.target.value] : [],
                                            })
                                        }
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    >
                                        <option value="">Select Staff</option>
                                        {teamMembers.map((member) => (
                                            <option key={member.id} value={member.id}>{member.name}</option>
                                        ))}
                                    </select>
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Start Date *</label>
                                    <input
                                        type="date"
                                        value={form.startDate}
                                        onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    />
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Due Date *</label>
                                    <input
                                        type="date"
                                        value={form.dueDate}
                                        min={form.startDate}
                                        onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    />
                                </div>

                                <div>
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Priority *</label>
                                    <select
                                        value={form.priority}
                                        onChange={(e) =>
                                            setForm({ ...form, priority: e.target.value as TaskPriority })
                                        }
                                        className="w-full rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    >
                                        <option value="Low">Low</option>
                                        <option value="Medium">Medium</option>
                                        <option value="High">High</option>
                                        <option value="Urgent">Urgent</option>
                                    </select>
                                </div>

                                <div className="md:col-span-2">
                                    <label className="mb-2 block text-sm font-medium text-slate-700">Description *</label>
                                    <textarea
                                        rows={4}
                                        value={form.description}
                                        onChange={(e) => setForm({ ...form, description: e.target.value })}
                                        placeholder="Enter task description"
                                        className="w-full resize-none rounded-lg border border-slate-200 px-4 py-2.5 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                    />
                                </div>
                            </div>

                            <div className="flex justify-end gap-3 border-t border-slate-200 bg-white px-6 py-4">
                                <button
                                    type="button"
                                    onClick={closeModal}
                                    className="rounded-lg border border-slate-200 px-5 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
                                >
                                    Cancel
                                </button>

                                <button
                                    type="button"
                                    onClick={handleSaveTask}
                                    className="rounded-lg bg-primary px-5 py-2.5 text-sm font-medium text-white hover:opacity-90"
                                >
                                    {editingTask ? 'Update Task' : 'Add Task'}
                                </button>
                            </div>
                        </div>
                    </div>,
                    document.body
                )}

            {showTaskDrawer && selectedTask && (
                <Edit
                    task={selectedTask}
                    onClose={() => {
                        setIsEditTaskOpen(false);
                        setSelectedTask(null);
                    }}
                    onUpdateTask={handleUpdateTaskFromDrawer}
                    teamMembers={teamMembers.map((member) => member.name)}
                />
            )}
        </div>
    );
};

interface DashboardCardProps {
    title: string;
    value: number;
}

const DashboardCard = ({ title, value }: DashboardCardProps) => {
    return (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-slate-500">{title}</p>
                    <h3 className="mt-2 text-2xl font-bold text-slate-800">{value}</h3>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <IconNotes className="h-6 w-6 text-primary" duotone={true} />
                </div>
            </div>
        </div>
    );
};

const formatDate = (date: string) => {
    if (!date) return '-';
    return new Date(`${date}T00:00:00`).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    });
};

export default List;