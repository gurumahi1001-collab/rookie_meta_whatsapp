import {
    DownloadSimpleIcon,
    FileTextIcon,
    FloppyDiskIcon,
    PlusIcon,
} from "@phosphor-icons/react";
import {
    useLocation,
    useNavigate,
} from "react-router-dom";
import Button from "../Button";
import { BOQItemm } from "../../types/projectBOQ";

interface QuotationHeaderProps {
    onNewQuotation?: () => void;
    showNewQuotation: boolean;
    showAddBOQ?: boolean;
    showBoqActions?: boolean;
    onExportEstimate?: () => void;
    onGenerateQuotation?: () => void;
    onSaveDraft?: () => void;
    isSaving?: boolean;
    boqData?: BOQItemm[];
    // Full export data
    exportData?: {
        projectName: string;
        projectSiteLocation: string;
        vendors: string;
        siteSurveyReference: string;
        date: string;
        boqItems: BOQItemm[];
        subtotal: number;
        contingency: number;
        grandTotal: number;
        paymentInstallments: Array<{
            name: string;
            amount: number;
            type: string;
            dueDate: string;
        }>;
        totalInstallmentAmount: number;
        remainingBalance: number;
    };
}

export default function QuotationHeader({
    onNewQuotation,
    showNewQuotation,
    showAddBOQ = false,
    showBoqActions = false,
    onExportEstimate,
    onGenerateQuotation,
    onSaveDraft,
    isSaving = false,
    exportData,
}: QuotationHeaderProps) {
    const navigate = useNavigate();
    const location = useLocation();

    const handleExport = () => {
        if (onExportEstimate) {
            onExportEstimate();
            return;
        }

        // If no onExportEstimate prop, use the data passed
        if (exportData) {
            // Import and use the export function
            import('../../utils/exportBOQToExcel').then(({ exportFullBOQData }) => {
                exportFullBOQData(exportData);
            });
        } else {
            alert("No data available to export");
        }
    };

    const handleNewQuotation = () => {
        if (onNewQuotation) {
            onNewQuotation();
            return;
        }

        navigate("/quotation/new_quotation");
    };

    const handleSaveDraft = () => {
        onSaveDraft?.();
    };

    // Only show these buttons on Add BOQ page
    const isAddBOQPage =
        location.pathname === "/quotation/project_boq/add-boq";

    const isEditBOQPage =
        location.pathname === "/quotation/project_boq/edit-boq" ||
        location.pathname.startsWith("/quotation/project_boq/edit-boq/");


    return (
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            {/* TITLE */}
            <div>
                <h1 className="text-2xl font-bold text-slate-900">
                    Quotations
                </h1>

                <p className="mt-1 text-sm text-slate-500">
                    Manage bids, proposals and project quotations.
                </p>
            </div>

            {/* ACTIONS */}
            <div className="flex flex-wrap items-center gap-2">

                {/* ADD BOQ */}
                {showAddBOQ && (
                    <button
                        type="button"
                        onClick={() =>
                            navigate(
                                "/quotation/project_boq/add-boq"
                            )
                        }
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                    >
                        <PlusIcon
                            size={16}
                            weight="bold"
                        />
                        Add BOQ 
                    </button>
                )}

                {/* EXPORT + GENERATE */}
                {(isAddBOQPage || isEditBOQPage) && (
                    <div className="flex shrink-0 items-center gap-2">
                        {onSaveDraft && (
                            <Button
                                variant="outline"
                                onClick={handleSaveDraft}
                                disabled={isSaving}
                                className="border-amber-300 text-amber-700 hover:bg-amber-50 hover:text-amber-800"
                            >
                                <FloppyDiskIcon size={16} />
                                {isSaving ? "Saving..." : "Save as Draft"}
                            </Button>
                        )}

                        <Button 
                            variant="outline"
                            onClick={handleExport}
                        >
                            <DownloadSimpleIcon size={16} />
                            Export Estimate
                        </Button>

                        <button
                            type="button"
                            onClick={onGenerateQuotation}
                            disabled={!onGenerateQuotation}
                            className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700"
                        >
                            <FileTextIcon
                                size={16}
                                weight="bold"
                            />
                            Generate Quotation
                        </button>
                    </div>
                )}

                {/* {location.pathname === "/quotation/project_boq/add-boq" && (
                    <Button
                        variant="outline"
                        onClick={handleSaveDraft}
                        className="border-amber-300 text-amber-700 hover:bg-amber-50 hover:text-amber-800"
                    >
                        <FloppyDiskIcon size={16} />
                        Save as Draft
                    </Button>
                )} */}
            </div>
        </div>
    );
}
