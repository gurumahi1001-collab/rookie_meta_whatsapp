import { useMemo, useState } from "react";

import type { Quotation } from "../../types/quotation";

import QuotationFilters from "./QuotationFilters";
import QuotationTable from "./QuotationTable";
import QuotationCard from "./QuotationCards";

interface BidsAndProposalsProps {
    quotations: Quotation[];
    onView: (quotation: Quotation) => void;
    onDelete?: (quotation: Quotation) => void;
}

const BidsAndProposals = ({
    quotations,
    onView,
    onDelete,
}: BidsAndProposalsProps) => {
    const [query, setQuery] = useState("");
    const [vendor, setVendor] = useState("All Vendors");
    const [status, setStatus] = useState("");
    const [view, setView] = useState<"list" | "card">("list");

    const vendors = useMemo(() => {
        const uniqueVendors = Array.from(
            new Set(
                quotations.map(
                    (quotation) => quotation.vendor
                )
            )
        );

        return [
            "All Vendors",
            ...uniqueVendors,
        ];
    }, [quotations]);

    const filteredQuotations = useMemo(() => {
        const searchValue = query
            .trim()
            .toLowerCase();

        return quotations.filter((quotation) => {
            const matchesSearch =
                !searchValue ||
                quotation.quotationNo
                    .toLowerCase()
                    .includes(searchValue) ||
                quotation.vendor
                    .toLowerCase()
                    .includes(searchValue) ||
                quotation.projectTitle
                    .toLowerCase()
                    .includes(searchValue) ||
                quotation.clientName
                    .toLowerCase()
                    .includes(searchValue);

            const matchesVendor =
                vendor === "All Vendors" ||
                quotation.vendor === vendor;

            const matchesStatus =
                status === "" ||
                quotation.status === status;

            return (
                matchesSearch &&
                matchesVendor &&
                matchesStatus
            );
        });
    }, [
        quotations,
        query,
        vendor,
        status,
    ]);

    return (
        <div>
            <QuotationFilters
                query={query}
                setQuery={setQuery}
                vendor={vendor}
                setVendor={setVendor}
                status={status}
                setStatus={setStatus}
                view={view}
                setView={setView}
                vendors={vendors}
            />

            {view === "list" ? (
                <QuotationTable
                    quotations={filteredQuotations}
                    onView={onView}
                    onDelete={onDelete}
                />
            ) : (
                <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
                    {filteredQuotations.map(
                        (quotation) => (
                            <QuotationCard
                                key={quotation.id}
                                quotation={quotation}
                                onView={onView}
                            />
                        )
                    )}

                    {filteredQuotations.length === 0 && (
                        <div className="col-span-full rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                            <p className="text-sm font-medium text-slate-500">
                                No quotations found
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Try changing your search or filter criteria.
                            </p>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default BidsAndProposals;