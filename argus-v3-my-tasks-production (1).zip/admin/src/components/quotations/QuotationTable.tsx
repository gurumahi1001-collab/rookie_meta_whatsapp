import { ClipboardText, EyeIcon, PencilIcon, TrashIcon } from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import type { Quotation, QuotationStatus } from "../../types/quotation";
import DataTable, { DataTableColumn } from "../DataTable";

interface QuotationTableProps {
    quotations?: Quotation[];
    onView?: (quotation: Quotation) => void;
    onDelete?: (quotation: Quotation) => void;
}

const statusClasses: Record<QuotationStatus, string> = {
    "Form Issued": "bg-blue-50 text-blue-700",
    "Form Submitted": "bg-amber-50 text-amber-700",
    "Form Approved": "bg-emerald-50 text-emerald-700",
    "Form Rejected": "bg-red-50 text-red-700",
    Issued: "bg-blue-50 text-blue-700",
    Draft: "bg-slate-100 text-slate-600",
    Submitted: "bg-amber-50 text-amber-700",
    Awarded: "bg-emerald-50 text-emerald-700",
    "Not Responded": "bg-red-100 text-red-600",
    Rejected: "bg-red-50 text-red-700",
};

const QuotationTable = ({ quotations = [], onView, onDelete }: QuotationTableProps) => {
    const navigate = useNavigate();
    const [hoveredQuotationId, setHoveredQuotationId] = useState<string | null>(null);

    const handleEditQuotation = (quotation: Quotation) => {
        navigate("/quotation/edit_quotation", { state: { quotationId: quotation.id, editQuotation: quotation } });
    };

    const handleView = (quotation: Quotation) => {
        if (onView) onView(quotation);
        else navigate("/quotation/quotationdetails", { state: { quotation } });
    };

    const columns: DataTableColumn<Quotation>[] = [
        {
            key: "quotationNo",
            label: "Quotation",
            width: "120px",
            sortable: true,
            render: (quotation) => <span className="block whitespace-nowrap text-xs font-bold text-slate-800 group-hover:text-red-600">{quotation.quotationNo}</span>,
        },
        {
            key: "vendorName",
            label: "Vendor",
            width: "190px",
            sortable: true,
            render: (quotation) => <span title={quotation.vendorName} className="block truncate text-xs font-medium text-slate-700">{quotation.vendorName || "Unknown Vendor"}</span>,
        },
        {
            key: "projectTitle",
            label: "Project Title",
            width: "240px",
            sortable: true,
            render: (quotation) => <span title={quotation.projectTitle} className="block truncate text-xs font-semibold text-slate-800">{quotation.projectTitle || "-"}</span>,
        },
        {
            key: "date",
            label: "Due Date",
            width: "110px",
            sortable: true,
            align: "center",
            render: (quotation) => <span className="block whitespace-nowrap text-xs text-slate-600">{quotation.validUntil || "-"}</span>,
        },
        {
            key: "grandTotal",
            label: "Grand Total",
            width: "145px",
            sortable: true,
            align: "right",
            render: (quotation) => <span className="block whitespace-nowrap text-xs font-bold text-slate-800">{quotation.currency} {Number(quotation.grandTotal || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>,
        },
        {
            key: "status",
            label: "Status",
            width: "135px",
            sortable: true,
            align: "center",
            render: (quotation) => <span className={`inline-flex min-w-[90px] items-center justify-center whitespace-nowrap rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClasses[quotation.status] || "bg-slate-100 text-slate-600"}`}>{quotation.status}</span>,
        },
        {
            key: "action",
            label: "Action",
            width: "170px",
            align: "center",
            render: (quotation) => {
                const isHovered = hoveredQuotationId === quotation.id;
                const editable = quotation.statusCode === "draft" || quotation.status === "Draft";
                const deletable = editable || quotation.statusCode === "rejected" || quotation.status === "Rejected";
                return (
                    <div className="flex min-h-8 items-center justify-center gap-1" onMouseEnter={() => setHoveredQuotationId(quotation.id)} onMouseLeave={() => setHoveredQuotationId(null)}>
                        <div className={`flex items-center justify-center gap-1 transition-opacity duration-150 ${isHovered ? "opacity-100" : "pointer-events-none opacity-0"}`}>
                            {editable && <button type="button" onClick={() => handleEditQuotation(quotation)} title="Edit quotation" aria-label="Edit quotation" className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-blue-600 transition-colors hover:bg-blue-50 hover:text-blue-700"><PencilIcon size={16} weight="duotone" /></button>}
                            {(quotation.status === "Form Issued" || quotation.statusCode === "issued") && <button type="button" onClick={() => navigate("/quotation/survey-form", { state: { quotationId: quotation.id, quotation } })} title="Open survey form" aria-label="Open survey form" className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-emerald-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700"><ClipboardText size={16} weight="duotone" /></button>}
                            <button type="button" onClick={() => handleView(quotation)} title="Review quotation" aria-label="Review quotation" className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-600 transition-colors hover:bg-red-50 hover:text-red-700"><EyeIcon size={18} weight="duotone" /></button>
                            {deletable && onDelete && <button type="button" onClick={() => onDelete(quotation)} title="Delete quotation" aria-label="Delete quotation" className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-red-500 transition-colors hover:bg-red-50 hover:text-red-700"><TrashIcon size={16} weight="duotone" /></button>}
                        </div>
                    </div>
                );
            },
        },
    ];

    return quotations.length ? <DataTable columns={columns} data={quotations} /> : <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm"><p className="text-sm font-medium text-slate-500">No quotations found</p><p className="mt-1 text-xs text-slate-400">Create a quotation or change the current filter criteria.</p></div>;
};

export default QuotationTable;
