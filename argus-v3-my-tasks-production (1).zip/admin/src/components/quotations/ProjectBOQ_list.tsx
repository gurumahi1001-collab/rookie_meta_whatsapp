import { useCallback, useEffect, useState } from "react";
import {
    ArrowClockwiseIcon,
    EyeIcon,
    LockSimpleIcon,
    PencilSimpleIcon,
    TrashIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import DataTable, { DataTableColumn } from "../DataTable";
import ConfirmDialog from "../ConfirmModal";
import QuotationHeader from "./QuotationHeader";
import QuotationTabs from "./QuotationTabs";
import BOQViewDrawer from "../../offcanvas/quotation/BOQViewDrawer";

import api from "../../api/axios";
import { deleteBOQ, getBOQ, listBOQs, lockBOQ } from "../../api/boqApi";
import type { BOQRecord, BOQStatus } from "../../types/boq";

interface ProjectBOQListProps {
    onAddBOQ: () => void;
    onView?: (boq: BOQRecord) => void;
    onEdit?: (boq: BOQRecord) => void;
    activeTab?: "bids" | "boq";
    onTabChange?: (tab: "bids" | "boq") => void;
    onExportEstimate?: () => void;
    onGenerateQuotation?: () => void;
    showBoqActions?: boolean;
}

interface VendorOption {
    id: string;
    name: string;
}

function getErrorMessage(error: unknown, fallback: string) {
    const value = error as {
        response?: { data?: { message?: string } };
        message?: string;
    };
    return value?.response?.data?.message || value?.message || fallback;
}

function formatCurrency(value: number) {
    return Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
}

function formatDate(value?: string | null) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    }).format(date);
}

function statusClass(status: BOQStatus) {
    return status === "locked"
        ? "bg-emerald-50 text-emerald-600"
        : "bg-slate-100 text-slate-600";
}

const ProjectBOQList = ({
    onAddBOQ,
    onView,
    activeTab = "boq",
    onTabChange,
    onExportEstimate,
    onGenerateQuotation,
    showBoqActions = true,
}: ProjectBOQListProps) => {
    const navigate = useNavigate();
    const [boqs, setBoqs] = useState<BOQRecord[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [refreshing, setRefreshing] = useState(false);
    const [selectedBOQ, setSelectedBOQ] = useState<BOQRecord | null>(null);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [deleteTarget, setDeleteTarget] = useState<BOQRecord | null>(null);
    const [lockTarget, setLockTarget] = useState<BOQRecord | null>(null);
    const [actionLoading, setActionLoading] = useState(false);

    const loadBOQs = useCallback(async (silent = false) => {
        try {
            if (silent) setRefreshing(true);
            else setLoading(true);
            setError("");
            const result = await listBOQs({ page: 1, limit: 250 });
            setBoqs(result.data);
        } catch (loadError) {
            setError(getErrorMessage(loadError, "Unable to load BOQs."));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    }, []);

    useEffect(() => {
        void loadBOQs();
    }, [loadBOQs]);

    const handleView = async (boq: BOQRecord) => {
        try {
            setError("");
            const detail = await getBOQ(boq.id);
            setSelectedBOQ(detail);
            setIsViewOpen(true);
            onView?.(detail);
        } catch (viewError) {
            setError(getErrorMessage(viewError, "Unable to load the BOQ details."));
        }
    };

    const handleEdit = (boq: BOQRecord) => {
        if (boq.status !== "draft") return;
        navigate(`/quotation/project_boq/edit-boq/${encodeURIComponent(boq.id)}`, {
            state: { boq },
        });
    };

    const handleDelete = async () => {
        if (!deleteTarget) return;
        try {
            setActionLoading(true);
            await deleteBOQ(deleteTarget.id);
            setBoqs((current) => current.filter((row) => row.id !== deleteTarget.id));
            setDeleteTarget(null);
        } catch (deleteError) {
            setError(getErrorMessage(deleteError, "Unable to delete the BOQ."));
        } finally {
            setActionLoading(false);
        }
    };

    const handleLock = async () => {
        if (!lockTarget) return;
        try {
            setActionLoading(true);
            const updated = await lockBOQ(lockTarget.id);
            setBoqs((current) => current.map((row) => (row.id === updated.id ? updated : row)));
            setLockTarget(null);
        } catch (lockError) {
            setError(getErrorMessage(lockError, "Unable to lock the BOQ."));
        } finally {
            setActionLoading(false);
        }
    };

    const columns: DataTableColumn<BOQRecord>[] = [
        {
            key: "reference",
            label: "BOQ No",
            width: "120px",
            sortable: true,
            render: (boq) => (
                <span className="text-[12px] font-bold text-slate-800 whitespace-nowrap">
                    {boq.reference || "-"}
                </span>
            ),
        },
        {
            key: "title",
            label: "Project",
            width: "210px",
            sortable: true,
            render: (boq) => (
                <span className="block max-w-[210px] truncate text-[12px] font-semibold text-slate-700" title={boq.title}>
                    {boq.title}
                </span>
            ),
        },
        {
            key: "vendors",
            label: "Vendors",
            width: "190px",
            sortable: false,
            render: (boq) => {
                const visible = boq.vendors.slice(0, 3);
                const remaining = Math.max(0, boq.vendors.length - 3);
                return (
                    <div className="flex max-w-[190px] flex-wrap items-center gap-1">
                        {visible.map((vendor: VendorOption, index) => (
                            <span
                                key={`${vendor.id}-${index}`}
                                className="max-w-[100px] truncate rounded-md bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600"
                                title={vendor.name}
                            >
                                {vendor.name}
                            </span>
                        ))}
                        {remaining > 0 && (
                            <span className="rounded-md bg-blue-50 px-1.5 py-0.5 text-[9px] font-bold text-blue-600">
                                +{remaining}
                            </span>
                        )}
                        {boq.vendors.length === 0 && (
                            <span className="text-[10px] text-slate-400">Not assigned</span>
                        )}
                    </div>
                );
            },
        },
        {
            key: "responseDueDate",
            label: "Due Date",
            width: "110px",
            sortable: true,
            render: (boq) => (
                <span className="whitespace-nowrap text-[12px] font-medium text-slate-600">
                    {formatDate(boq.responseDueDate)}
                </span>
            ),
        },
        {
            key: "projectValue",
            label: "Project Value",
            width: "125px",
            align: "center",
            sortable: true,
            render: (boq) => (
                <span className="whitespace-nowrap text-[11px] font-semibold text-slate-900">
                    {boq.currency} {formatCurrency(boq.projectValue)}
                </span>
            ),
        },
        {
            key: "grandTotal",
            label: "Grand Total",
            width: "125px",
            align: "center",
            sortable: true,
            render: (boq) => (
                <span className="whitespace-nowrap text-[11px] font-bold text-slate-900">
                    {boq.currency} {formatCurrency(boq.grandTotal)}
                </span>
            ),
        },
        {
            key: "itemCount",
            label: "Items",
            width: "65px",
            align: "center",
            sortable: true,
            render: (boq) => (
                <span className="text-[12px] font-semibold text-slate-700">{boq.itemCount}</span>
            ),
        },
        {
            key: "status",
            label: "Status",
            width: "95px",
            align: "center",
            sortable: true,
            render: (boq) => (
                <span className={`inline-flex rounded-full px-2 py-1 text-[9px] font-bold ${statusClass(boq.status)}`}>
                    {boq.status === "locked" ? "Locked" : "Draft"}
                </span>
            ),
        },
        {
            key: "actions",
            label: "Actions",
            width: "145px",
            align: "center",
            sortable: false,
            render: (boq) => (
                <div className="flex items-center justify-center gap-0.5 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                    <button
                        type="button"
                        onClick={() => void handleView(boq)}
                        title="View BOQ"
                        className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
                    >
                        <EyeIcon size={14} weight="bold" />
                    </button>

                    {boq.status === "draft" && (
                        <button
                            type="button"
                            onClick={() => handleEdit(boq)}
                            title="Edit BOQ"
                            className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-amber-50 hover:text-amber-600"
                        >
                            <PencilSimpleIcon size={14} weight="bold" />
                        </button>
                    )}

                    {boq.status === "draft" && (
                        <button
                            type="button"
                            onClick={() => setLockTarget(boq)}
                            title="Lock BOQ"
                            className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-emerald-50 hover:text-emerald-600"
                        >
                            <LockSimpleIcon size={14} weight="bold" />
                        </button>
                    )}

                    {boq.status === "draft" && (
                        <button
                            type="button"
                            onClick={() => setDeleteTarget(boq)}
                            title="Delete BOQ"
                            className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                        >
                            <TrashIcon size={14} weight="bold" />
                        </button>
                    )}
                </div>
            ),
        },
    ];

    return (
        <>
            <div className="space-y-5">
                <div className="space-y-4">
                    <QuotationHeader
                        showNewQuotation={activeTab === "bids"}
                        showAddBOQ={activeTab === "boq"}
                        showBoqActions={showBoqActions}
                        onExportEstimate={onExportEstimate}
                        onGenerateQuotation={onGenerateQuotation}
                    />

                    <div className="flex w-full items-center">
                        <QuotationTabs
                            activeTab={activeTab}
                            onChange={(tab) => {
                                onTabChange?.(tab);
                                navigate(tab === "bids" ? "/quotation" : "/quotation/project_boq");
                            }}
                        />
                    </div>
                </div>

                {error && (
                    <div className="flex items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
                        <p className="text-xs font-semibold text-red-700">{error}</p>
                        <button
                            type="button"
                            onClick={() => setError("")}
                            className="text-red-400 transition hover:text-red-600"
                        >
                            <XIcon size={15} weight="bold" />
                        </button>
                    </div>
                )}

                <section className="rounded-2xl shadow-sm">
                    <div className="flex items-center justify-between px-0 py-4">
                        <div>
                            <h3 className="text-xs font-bold uppercase tracking-wide text-slate-900">Recent BOQs</h3>
                            <p className="mt-1 text-[10px] text-slate-400">View and manage project bills of quantities</p>
                        </div>

                        <button
                            type="button"
                            onClick={() => void loadBOQs(true)}
                            disabled={refreshing}
                            title="Refresh BOQs"
                            className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-400 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
                        >
                            <ArrowClockwiseIcon size={14} weight="bold" className={refreshing ? "animate-spin" : ""} />
                        </button>
                    </div>

                    <div className="rounded-2xl p-0">
                        <DataTable
                            columns={columns}
                            data={boqs}
                            rowKey={(boq) => boq.id}
                            emptyMessage={loading ? "Loading BOQs..." : "No project BOQs found."}
                        />
                    </div>
                </section>
            </div>

            <BOQViewDrawer
                isOpen={isViewOpen}
                boq={selectedBOQ}
                onClose={() => setIsViewOpen(false)}
                onEdit={selectedBOQ?.status === "draft" ? () => handleEdit(selectedBOQ) : undefined}
            />

            <ConfirmDialog
                open={Boolean(deleteTarget)}
                title="Delete BOQ"
                message={deleteTarget ? `Delete ${deleteTarget.reference}? This action cannot be undone.` : "Delete this BOQ?"}
                confirmText="Delete BOQ"
                onConfirm={() => void handleDelete()}
                onCancel={() => (actionLoading ? undefined : setDeleteTarget(null))}
                loading={actionLoading}
            />

            <ConfirmDialog
                open={Boolean(lockTarget)}
                title="Lock BOQ"
                message={lockTarget ? `Lock ${lockTarget.reference}? Locked BOQs cannot be edited or deleted.` : "Lock this BOQ?"}
                confirmText="Lock BOQ"
                onConfirm={() => void handleLock()}
                onCancel={() => (actionLoading ? undefined : setLockTarget(null))}
                loading={actionLoading}
            />
        </>
    );
};

export default ProjectBOQList;
