import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
    Eye,
    MagnifyingGlass,
    PencilSimple,
    Plus,
    ArrowClockwise,
    CaretDown,
    Trash,
    CaretLeft,
    CaretRight,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import DataTable, { DataTableColumn } from "../DataTable";
import {
    deleteSurveyTemplate,
    listSurveyTemplates,
    updateSurveyTemplateStatus,
    SurveyTemplateRecord,
} from "../../api/surveyApi";
import { useAuth } from "../../auth/AuthProvider";
import { hasPermission } from "../../auth/permissionUtils";

export type SurveyTemplate = {
    id: string;
    name: string;
    description: string;
    status: "Active" | "Draft" | "Archived";
    modules: string[];
    version?: number;
    updatedAt?: string | null;
};

function normalizeStatus(
    status: SurveyTemplateRecord["status"],
): SurveyTemplate["status"] {
    switch (String(status || "draft").toLowerCase()) {
        case "active":
            return "Active";
        case "archived":
            return "Archived";
        default:
            return "Draft";
    }
}

function normalizeModules(record: SurveyTemplateRecord): string[] {
    if (Array.isArray(record.moduleCodes)) {
        return record.moduleCodes
            .map((code) => String(code).trim())
            .filter(Boolean);
    }

    const modules = record.schema?.modules;
    if (!Array.isArray(modules)) {
        return [];
    }

    return modules
        .map((module) => {
            if (!module || typeof module !== "object") {
                return "";
            }

            return String((module as { code?: unknown }).code ?? "").trim();
        })
        .filter(Boolean);
}

function mapApiTemplate(record: SurveyTemplateRecord): SurveyTemplate {
    return {
        id: String(record.id),
        name: String(record.name || "Untitled Survey"),
        description: String(record.description || ""),
        status: normalizeStatus(record.status),
        modules: normalizeModules(record),
        version: Number(record.version || 1),
        updatedAt: record.updatedAt ?? null,
    };
}

function isAbortError(error: unknown): boolean {
    const value = error as { name?: string; code?: string } | null;
    return (
        value?.name === "CanceledError" ||
        value?.name === "AbortError" ||
        value?.code === "ERR_CANCELED"
    );
}

function formatDate(value?: string | null): string {
    if (!value) return "—";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "—";

    return new Intl.DateTimeFormat(undefined, {
        dateStyle: "medium",
    }).format(date);
}

function isObjectId(value: string): boolean {
    return /^[a-f\d]{24}$/i.test(value);
}

export default function SurveyList() {
    const navigate = useNavigate();
    const { user, role, permissions } = useAuth();

    const [templates, setTemplates] = useState<SurveyTemplate[]>([]);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [total, setTotal] = useState(0);
    const [search, setSearch] = useState("");
    const [status, setStatus] = useState<"all" | "draft" | "active" | "archived">("all");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const [statusUpdatingId, setStatusUpdatingId] = useState<string | null>(null);
    const requestRef = useRef<AbortController | null>(null);
    const requestSequence = useRef(0);
    const pageSize = 25;

    const userType = String(user?.userType || "").toLowerCase();
    const canUseSurveyReport = userType === "admin" || userType === "internal";
    const ownerRole = role?.ownerRole === true;
    const canView = ownerRole || hasPermission(permissions, "survey_report", "view");
    const canAdd = ownerRole || hasPermission(permissions, "survey_report", "add");
    const canEdit = ownerRole || hasPermission(permissions, "survey_report", "edit");
    const canDelete = ownerRole || hasPermission(permissions, "survey_report", "delete");

    const loadTemplates = useCallback(async (targetPage: number, signal?: AbortSignal) => {
        const sequence = ++requestSequence.current;
        setLoading(true);
        setError("");

        try {
            const result = await listSurveyTemplates({
                page: targetPage,
                limit: pageSize,
                search: search.trim(),
                status,
                signal,
            });

            if (sequence !== requestSequence.current || signal?.aborted) {
                return;
            }

            const nextPage = Math.max(1, Number(result.pagination.page || targetPage));
            const nextPages = Math.max(1, Number(result.pagination.pages || 1));

            setTemplates(result.data.map(mapApiTemplate));
            setPage(nextPage);
            setTotalPages(nextPages);
            setTotal(Math.max(0, Number(result.pagination.total || 0)));
        } catch (requestError) {
            if (isAbortError(requestError) || signal?.aborted) {
                return;
            }

            if (sequence === requestSequence.current) {
                setTemplates([]);
                setTotal(0);
                setTotalPages(1);
                setError(
                    requestError instanceof Error
                        ? requestError.message
                        : "Unable to load survey templates.",
                );
            }
        } finally {
            if (sequence === requestSequence.current) {
                setLoading(false);
            }
        }
    }, [search, status]);

    useEffect(() => {
        requestRef.current?.abort();
        const controller = new AbortController();
        requestRef.current = controller;

        const timer = window.setTimeout(() => {
            void loadTemplates(page, controller.signal);
        }, 250);

        return () => {
            window.clearTimeout(timer);
            controller.abort();
        };
    }, [page, loadTemplates]);

    useEffect(() => {
        if (notice) {
            const timer = window.setTimeout(() => setNotice(""), 3500);
            return () => window.clearTimeout(timer);
        }

        return undefined;
    }, [notice]);

    const stats = useMemo(() => {
        const active = templates.filter((template) => template.status === "Active").length;
        const drafts = templates.filter((template) => template.status === "Draft").length;

        return { active, drafts };
    }, [templates]);

    const handleStatusChange = (value: typeof status) => {
        setPage(1);
        setStatus(value);
    };

    const handleTemplateStatusChange = async (
        template: SurveyTemplate,
        nextStatus: "draft" | "active" | "archived",
    ) => {
        if (!canEdit || !isObjectId(template.id) || statusUpdatingId === template.id) {
            return;
        }

        const currentStatus = template.status.toLowerCase() as "draft" | "active" | "archived";
        if (currentStatus === nextStatus) {
            return;
        }

        if (nextStatus === "archived") {
            const confirmed = window.confirm(
                `Archive the survey template "${template.name}"? It will remain stored and can be restored later.`,
            );
            if (!confirmed) return;
        }

        setStatusUpdatingId(template.id);
        setError("");
        setNotice("");

        try {
            const saved = await updateSurveyTemplateStatus(template.id, nextStatus);
            const savedStatus = normalizeStatus(saved.status);

            setTemplates((current) =>
                current
                    .map((item) =>
                        item.id === template.id
                            ? { ...item, status: savedStatus, updatedAt: saved.updatedAt ?? item.updatedAt }
                            : item,
                    )
                    .filter((item) =>
                        status === "all" || item.status.toLowerCase() === status,
                    ),
            );

            setTotal((current) =>
                status === "all" ? current : Math.max(0, current - 1),
            );
            setNotice(
                savedStatus === "Archived"
                    ? `"${template.name}" was archived.`
                    : `"${template.name}" is now ${savedStatus.toLowerCase()}.`,
            );

            if (status !== "all") {
                void loadTemplates(page);
            }
        } catch (requestError) {
            if (isAbortError(requestError)) return;
            setError(
                requestError instanceof Error
                    ? requestError.message
                    : "Unable to change the survey template status.",
            );
        } finally {
            setStatusUpdatingId(null);
        }
    };

    const handleDelete = async (template: SurveyTemplate) => {
        if (!canDelete || !isObjectId(template.id)) {
            return;
        }

        const confirmed = window.confirm(
            `Archive the survey template "${template.name}"? Archived templates remain stored but are removed from normal active use.`,
        );

        if (!confirmed) {
            return;
        }

        requestRef.current?.abort();
        const controller = new AbortController();
        requestRef.current = controller;

        setError("");
        setNotice("");

        try {
            await deleteSurveyTemplate(template.id, controller.signal);
            setNotice(`"${template.name}" was archived.`);

            const nextPage = page > 1 && templates.length === 1 ? page - 1 : page;
            setPage(nextPage);
        } catch (requestError) {
            if (isAbortError(requestError)) return;

            setError(
                requestError instanceof Error
                    ? requestError.message
                    : "Unable to archive the survey template.",
            );
        }
    };

    const handleRefresh = () => {
        requestRef.current?.abort();
        const controller = new AbortController();
        requestRef.current = controller;
        void loadTemplates(page, controller.signal);
    };

    const columns: DataTableColumn<SurveyTemplate>[] = [
        {
            key: "name",
            label: "Template",
            sortable: true,
            width: "26%",
            render: (row) => (
                <div className="min-w-0">
                    <div className="truncate font-medium text-slate-900">{row.name}</div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-400">
                        <span>{row.modules.length} module{row.modules.length === 1 ? "" : "s"}</span>
                        {row.version ? <span>v{row.version}</span> : null}
                    </div>
                </div>
            ),
        },
        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "38%",
            render: (row) => (
                <div className="max-w-2xl truncate text-xs text-slate-500" title={row.description}>
                    {row.description || "No description"}
                </div>
            ),
        },
        {
            key: "status",
            label: "Status",
            sortable: true,
            width: "14%",
            render: (row) => {
                const styles: Record<SurveyTemplate["status"], string> = {
                    Active: "border-emerald-200 bg-emerald-50 text-emerald-700",
                    Draft: "border-amber-200 bg-amber-50 text-amber-700",
                    Archived: "border-slate-200 bg-slate-100 text-slate-500",
                };

                return (
                    <div className="flex items-center">
                        {canEdit && isObjectId(row.id) ? (
                            <div className={`inline-flex items-center rounded-full border ${styles[row.status]} ${statusUpdatingId === row.id ? "opacity-60" : ""}`}>
                                <span className="ml-2 h-1.5 w-1.5 rounded-full bg-current" />
                                <select
                                    value={row.status.toLowerCase()}
                                    disabled={statusUpdatingId === row.id}
                                    onChange={(event) =>
                                        void handleTemplateStatusChange(
                                            row,
                                            event.target.value as "draft" | "active" | "archived",
                                        )
                                    }
                                    onClick={(event) => event.stopPropagation()}
                                    className="appearance-none border-0 bg-transparent px-2 py-1 text-[10px] font-semibold text-current outline-none focus:ring-0 disabled:cursor-not-allowed"
                                    aria-label={`Change status for ${row.name}`}
                                    title="Change template status"
                                >
                                    <option value="active">Active</option>
                                    <option value="draft">Draft</option>
                                    <option value="archived">Archived</option>
                                </select>
                                <CaretDown size={10} className="mr-2 shrink-0 text-current" />
                            </div>
                        ) : (
                            <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[10px] font-semibold ${styles[row.status]}`}>
                                <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-current" />
                                {row.status}
                            </span>
                        )}
                    </div>
                );
            },
        },
        {
            key: "updatedAt",
            label: "Updated",
            sortable: true,
            width: "14%",
            render: (row) => (
                <span className="text-xs text-slate-500">{formatDate(row.updatedAt)}</span>
            ),
        },
        {
            key: "actions",
            label: "Actions",
            width: "8%",
            render: (row) => (
                <div className="flex items-center justify-end gap-1.5">
                    <button
                        type="button"
                        onClick={(event) => {
                            event.stopPropagation();
                            navigate(
                                `/survey_report/view_form?templateId=${encodeURIComponent(row.id)}&from=survey_report`,
                            );
                        }}
                        title="Open survey form"
                        aria-label={`Open ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-sky-600 transition hover:bg-sky-50"
                    >
                        <Eye size={14} />
                    </button>

                    {canEdit && isObjectId(row.id) ? (
                        <button
                            type="button"
                            onClick={(event) => {
                                event.stopPropagation();
                                navigate(
                                    `/survey_report/create_template?editId=${encodeURIComponent(row.id)}`,
                                );
                            }}
                            title="Edit template"
                            aria-label={`Edit ${row.name}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-slate-600 transition hover:bg-slate-50"
                        >
                            <PencilSimple size={14} />
                        </button>
                    ) : null}

                    {canDelete && isObjectId(row.id) && row.status !== "Archived" ? (
                        <button
                            type="button"
                            onClick={(event) => {
                                event.stopPropagation();
                                void handleDelete(row);
                            }}
                            title="Archive template"
                            aria-label={`Archive ${row.name}`}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white text-red-600 transition hover:bg-red-50"
                        >
                            <Trash size={14} />
                        </button>
                    ) : null}
                </div>
            ),
        },
    ];

    if (!canUseSurveyReport || !canView) {
        return (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-800">
                You do not have permission to view Survey Report.
            </div>
        );
    }

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div>
                    <h1 className="text-base font-semibold text-slate-900">Survey Report</h1>
                    <p className="mt-1 text-xs leading-relaxed text-slate-500">
                        Create and manage the survey templates used for field inspections and survey packets.
                    </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <button
                        type="button"
                        onClick={handleRefresh}
                        disabled={loading}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        <ArrowClockwise size={14} className={loading ? "animate-spin" : ""} />
                        Refresh
                    </button>

                    {canAdd ? (
                        <button
                            type="button"
                            onClick={() => navigate("/survey_report/create_template")}
                            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
                        >
                            <Plus size={15} weight="bold" />
                            Add Template
                        </button>
                    ) : null}
                </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Templates on page</div>
                    <div className="mt-1 text-xl font-semibold text-slate-900">{templates.length}</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Active on page</div>
                    <div className="mt-1 text-xl font-semibold text-emerald-700">{stats.active}</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm col-span-2 sm:col-span-1">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Total records</div>
                    <div className="mt-1 text-xl font-semibold text-slate-900">{total}</div>
                </div>
            </div>

            {notice ? (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    {notice}
                </div>
            ) : null}

            {error ? (
                <div className="flex flex-col gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 sm:flex-row sm:items-center sm:justify-between">
                    <span>{error}</span>
                    <button
                        type="button"
                        onClick={handleRefresh}
                        className="inline-flex w-fit items-center gap-1.5 rounded-lg border border-red-200 bg-white px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100"
                    >
                        <ArrowClockwise size={13} /> Retry
                    </button>
                </div>
            ) : null}

            <div className="flex flex-col gap-2 rounded-xl border border-slate-200 bg-white p-3 shadow-sm md:flex-row md:items-center md:justify-between">
                <div className="relative min-w-0 flex-1 md:max-w-xl">
                    <MagnifyingGlass className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
                    <input
                        type="search"
                        value={search}
                        onChange={(event) => {
                            setSearch(event.target.value);
                            setPage(1);
                        }}
                        placeholder="Search by template name, description or module code…"
                        maxLength={120}
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2.5 pl-9 pr-3 text-xs text-slate-800 outline-none transition focus:border-red-300 focus:bg-white focus:ring-2 focus:ring-red-500/10"
                    />
                </div>

                <select
                    value={status}
                    onChange={(event) => handleStatusChange(event.target.value as typeof status)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-medium text-slate-700 outline-none focus:border-red-300 focus:ring-2 focus:ring-red-500/10"
                >
                    <option value="all">All statuses</option>
                    <option value="active">Active</option>
                    <option value="draft">Draft</option>
                    <option value="archived">Archived</option>
                </select>
            </div>

            <div className="relative">
                {loading ? (
                    <div className="pointer-events-none absolute inset-0 z-10 rounded-lg bg-white/55 backdrop-blur-[1px]">
                        <div className="flex h-full items-center justify-center">
                            <div className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 shadow-sm">
                                Loading survey templates…
                            </div>
                        </div>
                    </div>
                ) : null}

                <DataTable<SurveyTemplate>
                    columns={columns}
                    data={templates}
                    rowKey={(row) => String(row.id)}
                    emptyMessage={
                        error
                            ? "Unable to load survey templates."
                            : search.trim() || status !== "all"
                                ? "No survey templates match the selected filters."
                                : "No survey templates have been created yet."
                    }
                    minWidth="1000px"
                    footer={
                        <div className="flex flex-col gap-2 border-t border-slate-100 bg-white px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between">
                            <div className="text-[10px] text-slate-500">
                                Page {page} of {totalPages} · {total} record{total === 1 ? "" : "s"}
                            </div>
                            <div className="flex items-center gap-1.5">
                                <button
                                    type="button"
                                    disabled={loading || page <= 1}
                                    onClick={() => setPage((current) => Math.max(1, current - 1))}
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40"
                                    aria-label="Previous page"
                                >
                                    <CaretLeft size={14} />
                                </button>
                                <button
                                    type="button"
                                    disabled={loading || page >= totalPages}
                                    onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
                                    className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 disabled:cursor-not-allowed disabled:opacity-40"
                                    aria-label="Next page"
                                >
                                    <CaretRight size={14} />
                                </button>
                            </div>
                        </div>
                    }
                />
            </div>
        </div>
    );
}
