import type { ElementType } from "react";
import type { SurveyTemplate } from "./SurveyList";

export type SurveyFieldOption = {
    id: string;
    label: string;
    value: string;
};

export type SurveyFieldType =
    | "text"
    | "number"
    | "radio"
    | "select"
    | "textarea"
    | "checkbox_group";

export type SurveyField = {
    id: string;
    name: string;
    label: string;
    type: SurveyFieldType;
    required: boolean;
    placeholder?: string;
    helpText?: string;
    unit?: string;
    options?: SurveyFieldOption[];
};

export type SurveyFieldGroup = {
    id: string;
    title: string;
    fields: SurveyField[];
};

export type SurveySection = {
    id: string;
    title: string;
    number?: string;
    fieldGroups: SurveyFieldGroup[];
};

export type StoredSurveyModule = {
    id: string;
    code: string;
    zone: string;
    name: string;
    description?: string;
    fields: number;
    repeatable: boolean;
    unitLabel?: string;
    hasConditional?: boolean;
    sections?: SurveySection[];
    templateNames?: string[];
};

export type StoredSurveyTemplate = SurveyTemplate & {
    moduleId?: string;
};

/**
 * Browser storage is a client-side recovery/cache layer only.
 * The server remains the source of truth once the survey API is connected.
 */
const STORAGE_VERSION = 2;
const TEMPLATE_STORAGE_KEY = "survey_templates";
const MODULE_STORAGE_KEY = "survey_modules";
const VERSION_STORAGE_KEY = "survey_storage_version";

const isBrowser = (): boolean =>
    typeof window !== "undefined" &&
    typeof window.localStorage !== "undefined";

const canUseStorage = (): boolean => {
    if (!isBrowser()) {
        return false;
    }

    try {
        const probeKey = "__argus_survey_storage_probe__";
        window.localStorage.setItem(probeKey, "1");
        window.localStorage.removeItem(probeKey);
        return true;
    } catch {
        return false;
    }
};

const readJson = <T,>(
    key: string,
    fallback: T,
): T => {
    if (!canUseStorage()) {
        return fallback;
    }

    try {
        const raw = window.localStorage.getItem(key);

        if (!raw) {
            return fallback;
        }

        const parsed: unknown = JSON.parse(raw);

        return parsed as T;
    } catch {
        return fallback;
    }
};

const writeJson = <T,>(
    key: string,
    value: T,
): boolean => {
    if (!canUseStorage()) {
        return false;
    }

    try {
        window.localStorage.setItem(
            key,
            JSON.stringify(value),
        );

        return true;
    } catch {
        return false;
    }
};

const normalizeId = (value: unknown): string =>
    String(value ?? "").trim();

const normalizeText = (value: unknown): string =>
    String(value ?? "").trim();

const normalizeBoolean = (
    value: unknown,
    fallback = false,
): boolean => {
    if (typeof value === "boolean") {
        return value;
    }

    if (value === "true" || value === 1 || value === "1") {
        return true;
    }

    if (value === "false" || value === 0 || value === "0") {
        return false;
    }

    return fallback;
};

const normalizeFieldOption = (
    option: Partial<SurveyFieldOption> | null | undefined,
): SurveyFieldOption => ({
    id: normalizeId(option?.id),
    label: normalizeText(option?.label),
    value: normalizeText(option?.value),
});

const normalizeField = (
    field: Partial<SurveyField> | null | undefined,
): SurveyField => ({
    id: normalizeId(field?.id),
    name: normalizeText(field?.name),
    label: normalizeText(field?.label),
    type: (
        [
            "text",
            "number",
            "radio",
            "select",
            "textarea",
            "checkbox_group",
        ].includes(String(field?.type))
            ? field?.type
            : "text"
    ) as SurveyFieldType,
    required: normalizeBoolean(field?.required),
    placeholder: normalizeText(field?.placeholder),
    helpText: normalizeText(field?.helpText),
    unit: normalizeText(field?.unit),
    options: Array.isArray(field?.options)
        ? (field?.options ?? []).map(normalizeFieldOption)
        : [],
});

const normalizeFieldGroup = (
    group: Partial<SurveyFieldGroup> | null | undefined,
): SurveyFieldGroup => ({
    id: normalizeId(group?.id),
    title: normalizeText(group?.title),
    fields: Array.isArray(group?.fields)
        ? (group?.fields ?? []).map(normalizeField)
        : [],
});

const normalizeSection = (
    section: Partial<SurveySection> | null | undefined,
): SurveySection => ({
    id: normalizeId(section?.id),
    title: normalizeText(section?.title),
    number: normalizeText(section?.number),
    fieldGroups: Array.isArray(section?.fieldGroups)
        ? (section?.fieldGroups ?? []).map(normalizeFieldGroup)
        : [],
});

const normalizeModule = (
    module: Partial<StoredSurveyModule> | null | undefined,
): StoredSurveyModule => ({
    id: normalizeId(module?.id),
    code: normalizeText(module?.code),
    zone: normalizeText(module?.zone),
    name: normalizeText(module?.name),
    description: normalizeText(module?.description),
    fields: Math.max(0, Number(module?.fields) || 0),
    repeatable: normalizeBoolean(module?.repeatable),
    unitLabel: normalizeText(module?.unitLabel),
    hasConditional: normalizeBoolean(module?.hasConditional),
    sections: Array.isArray(module?.sections)
        ? (module?.sections ?? []).map(normalizeSection)
        : [],
    templateNames: Array.isArray(module?.templateNames)
        ? Array.from(
              new Set(
                  (module?.templateNames ?? [])
                      .map(normalizeText)
                      .filter(Boolean),
              ),
          )
        : [],
});

const normalizeTemplate = (
    template: Partial<SurveyTemplate> | null | undefined,
): SurveyTemplate => ({
    id: template?.id as SurveyTemplate["id"],
    name: normalizeText(template?.name),
    description: normalizeText(template?.description),
    status:
        template?.status === "Active" ||
        template?.status === "Archived"
            ? template.status
            : "Draft",
    modules: Array.isArray(template?.modules)
        ? (template?.modules ?? [])
              .map(normalizeText)
              .filter(Boolean)
        : [],
});

const ensureStorageVersion = (): void => {
    if (!canUseStorage()) {
        return;
    }

    try {
        const storedVersion = Number(
            window.localStorage.getItem(
                VERSION_STORAGE_KEY,
            ),
        );

        if (!Number.isFinite(storedVersion) || storedVersion < STORAGE_VERSION) {
            window.localStorage.setItem(
                VERSION_STORAGE_KEY,
                String(STORAGE_VERSION),
            );
        }
    } catch {
        // Storage failures are intentionally non-fatal.
    }
};

export const getStoredTemplates = (): SurveyTemplate[] => {
    ensureStorageVersion();

    const data = readJson<unknown[]>(
        TEMPLATE_STORAGE_KEY,
        [],
    );

    if (!Array.isArray(data)) {
        return [];
    }

    return data
        .filter(
            (template): template is Partial<SurveyTemplate> =>
                Boolean(template) &&
                typeof template === "object",
        )
        .map(normalizeTemplate);
};

export const saveStoredTemplates = (
    templates: SurveyTemplate[],
): boolean => {
    ensureStorageVersion();

    return writeJson(
        TEMPLATE_STORAGE_KEY,
        templates.map(normalizeTemplate),
    );
};

export const getStoredModules = (): StoredSurveyModule[] => {
    ensureStorageVersion();

    const data = readJson<unknown[]>(
        MODULE_STORAGE_KEY,
        [],
    );

    if (!Array.isArray(data)) {
        return [];
    }

    return data
        .filter(
            (module): module is Partial<StoredSurveyModule> =>
                Boolean(module) &&
                typeof module === "object",
        )
        .map(normalizeModule);
};

export const saveStoredModules = (
    modules: StoredSurveyModule[],
): boolean => {
    ensureStorageVersion();

    return writeJson(
        MODULE_STORAGE_KEY,
        modules.map(normalizeModule),
    );
};

const sameText = (
    left: unknown,
    right: unknown,
): boolean =>
    normalizeText(left).toLowerCase() ===
    normalizeText(right).toLowerCase();

export const findModuleForTemplate = (
    template: SurveyTemplate,
): StoredSurveyModule | undefined => {
    const modules = getStoredModules();

    const byTemplateName = modules.find(
        (module) =>
            sameText(module.name, template.name) ||
            module.templateNames?.some((name) =>
                sameText(name, template.name),
            ),
    );

    if (byTemplateName) {
        return byTemplateName;
    }

    const moduleId = (
        template as SurveyTemplate & {
            moduleId?: unknown;
        }
    ).moduleId;

    if (moduleId) {
        return modules.find(
            (module) =>
                sameText(module.id, moduleId),
        );
    }

    return undefined;
};

export const updateStoredModule = (
    updatedModule: StoredSurveyModule,
): boolean => {
    const normalizedModule =
        normalizeModule(updatedModule);

    if (!normalizedModule.id) {
        return false;
    }

    const modules = getStoredModules();
    let updated = false;

    const nextModules = modules.map((module) => {
        if (!sameText(module.id, normalizedModule.id)) {
            return module;
        }

        updated = true;
        return normalizedModule;
    });

    if (!updated) {
        return false;
    }

    return saveStoredModules(nextModules);
};

export const addStoredModule = (
    module: StoredSurveyModule,
): boolean => {
    const normalizedModule =
        normalizeModule(module);

    if (!normalizedModule.id) {
        return false;
    }

    const modules = getStoredModules();
    const existingIndex = modules.findIndex(
        (item) =>
            sameText(item.id, normalizedModule.id),
    );

    if (existingIndex >= 0) {
        const nextModules = [...modules];
        nextModules[existingIndex] = normalizedModule;
        return saveStoredModules(nextModules);
    }

    return saveStoredModules([
        ...modules,
        normalizedModule,
    ]);
};

export const removeStoredModule = (
    moduleId: string,
): boolean => {
    const normalizedId = normalizeId(moduleId);

    if (!normalizedId) {
        return false;
    }

    const modules = getStoredModules();
    const nextModules = modules.filter(
        (module) =>
            !sameText(module.id, normalizedId),
    );

    if (nextModules.length === modules.length) {
        return false;
    }

    return saveStoredModules(nextModules);
};

/**
 * Keep the public module shape used by the current builder while allowing
 * icon assignment to remain a presentation concern.
 */
export type SurveyModule = StoredSurveyModule & {
    icon: ElementType;
};
