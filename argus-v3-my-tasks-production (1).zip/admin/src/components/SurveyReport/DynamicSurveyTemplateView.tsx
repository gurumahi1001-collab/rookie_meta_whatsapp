import { useMemo, useState } from "react";
import IconSafari from "../Icon/IconSafari";

import {
    ArrowLeft,
    Buildings,
    ClipboardText,
    CalendarBlank,
    CaretDown,
    CaretRight,
    FloppyDisk,
    HardHat,
    ListChecks,
    MapPin,
    Printer,
    Radio,
} from "@phosphor-icons/react";

import type { SurveyTemplateRecord } from "../../api/surveyApi";

type JsonObject = Record<string, unknown>;
type DynamicValue = string | number | string[];

type CanvasItem = {
    moduleId?: string;
    moduleCode?: string;
    id?: string;
    code?: string;
    repeatCount?: number;
};

type DynamicField = {
    id: string;
    name?: string;
    label: string;
    type?: string;
    required?: boolean;
    placeholder?: string;
    helpText?: string;
    unit?: string;
    options?: Array<{
        id?: string;
        label?: string;
        value?: string;
    }>;
};

type DynamicFieldGroup = {
    id?: string;
    title?: string;
    fields?: DynamicField[];
};

type DynamicSection = {
    id?: string;
    title?: string;
    fieldGroups?: DynamicFieldGroup[];
};

type DynamicModule = {
    id?: string;
    code?: string;
    zone?: string;
    name?: string;
    description?: string;
    fields?: number;
    repeatable?: boolean;
    unitLabel?: string;
    sections?: DynamicSection[];
};

function asObject(value: unknown): JsonObject | null {
    return value && typeof value === "object" && !Array.isArray(value)
        ? (value as JsonObject)
        : null;
}

function asString(value: unknown): string {
    return String(value ?? "").trim();
}

function normalizeModule(value: unknown): DynamicModule | null {
    const raw = asObject(value);
    if (!raw) return null;

    const sections = Array.isArray(raw.sections)
        ? raw.sections.map((section) => {
              const item = asObject(section);
              return item
                  ? ({
                        ...item,
                        fieldGroups: Array.isArray(item.fieldGroups)
                            ? item.fieldGroups
                                  .map((group) => {
                                      const groupValue = asObject(group);
                                      return groupValue
                                          ? ({
                                                ...groupValue,
                                                fields: Array.isArray(groupValue.fields)
                                                    ? groupValue.fields
                                                          .map((field) => asObject(field))
                                                          .filter((field): field is JsonObject => Boolean(field))
                                                    : [],
                                            } as DynamicFieldGroup)
                                          : null;
                                  })
                                  .filter((group): group is DynamicFieldGroup => Boolean(group))
                            : [],
                    } as DynamicSection)
                  : null;
          })
              .filter((section): section is DynamicSection => Boolean(section))
        : [];

    return {
        ...raw,
        id: asString(raw.id),
        code: asString(raw.code),
        zone: asString(raw.zone) || "SURVEY",
        name: asString(raw.name) || "Untitled Module",
        description: asString(raw.description),
        fields: Math.max(0, Number(raw.fields) || 0),
        repeatable: Boolean(raw.repeatable),
        unitLabel: asString(raw.unitLabel),
        sections,
    } as DynamicModule;
}

function normalizeCanvas(value: unknown): CanvasItem[] {
    return Array.isArray(value)
        ? value
              .map((item) => asObject(item))
              .filter((item): item is JsonObject => Boolean(item))
              .map((item) => ({
                  ...item,
                  moduleId: asString(item.moduleId ?? item.id),
                  moduleCode: asString(item.moduleCode ?? item.code),
                  repeatCount: Math.max(1, Number(item.repeatCount) || 1),
              }))
        : [];
}

function getIcon(code?: string) {
    switch (String(code || "").toUpperCase()) {
        case "MOD-02":
            return Radio;
        case "MOD-03":
            return IconSafari;
        case "MOD-04":
            return MapPin;
        case "MOD-05":
            return ListChecks;
        case "MOD-06":
            return HardHat;
        case "MOD-01":
        default:
            return Buildings;
    }
}

function normalizeInitialValues(value: unknown): Record<string, DynamicValue> {
    const raw = asObject(value);
    if (!raw) return {};

    const result: Record<string, DynamicValue> = {};

    for (const [key, current] of Object.entries(raw)) {
        if (Array.isArray(current)) {
            result[key] = current.map((item) => String(item));
        } else if (typeof current === "number") {
            result[key] = current;
        } else if (typeof current === "string") {
            result[key] = current;
        }
    }

    return result;
}

function inputValue(value: DynamicValue | undefined): string | number {
    return value ?? "";
}

function DynamicFieldRenderer({
    field,
    value,
    onChange,
    inputName,
}: {
    field: DynamicField;
    value?: DynamicValue;
    onChange: (value: DynamicValue) => void;
    inputName?: string;
}) {
    const fieldType = asString(field.type).toLowerCase();
    const options = Array.isArray(field.options) ? field.options : [];
    const commonClass =
        "w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition focus:border-red-400 focus:ring-2 focus:ring-red-500/10";

    switch (fieldType) {
        case "number":
            return (
                <div className="flex items-center gap-2">
                    <input
                        type="number"
                        value={inputValue(value)}
                        onChange={(event) => onChange(event.target.value)}
                        placeholder={field.placeholder || "Enter value"}
                        className={commonClass}
                    />
                    {field.unit ? (
                        <span className="shrink-0 text-xs font-semibold text-slate-500">
                            {field.unit}
                        </span>
                    ) : null}
                </div>
            );

        case "radio":
            return (
                <div className="flex flex-wrap gap-3">
                    {options.map((option, index) => {
                        const optionValue = asString(option.value) || asString(option.label);
                        const optionLabel = asString(option.label) || optionValue;
                        const optionId = `${field.id}-${option.id || optionValue || index}`;
                        return (
                            <label
                                key={optionId}
                                className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 transition hover:border-slate-300 hover:bg-white"
                            >
                                <input
                                    type="radio"
                                    name={inputName || field.id}
                                    value={optionValue}
                                    checked={value === optionValue}
                                    onChange={() => onChange(optionValue)}
                                    className="h-4 w-4 border-slate-300 text-red-600 focus:ring-red-500"
                                />
                                {optionLabel}
                            </label>
                        );
                    })}
                </div>
            );

        case "select":
            return (
                <select
                    value={typeof value === "string" ? value : ""}
                    onChange={(event) => onChange(event.target.value)}
                    className={commonClass}
                >
                    <option value="">Select...</option>
                    {options.map((option, index) => {
                        const optionValue = asString(option.value) || asString(option.label);
                        return (
                            <option
                                key={`${field.id}-${option.id || optionValue || index}`}
                                value={optionValue}
                            >
                                {asString(option.label) || optionValue}
                            </option>
                        );
                    })}
                </select>
            );

        case "checkbox_group": {
            const selected = Array.isArray(value) ? value : [];
            return (
                <div className="grid gap-2 sm:grid-cols-2">
                    {options.map((option, index) => {
                        const optionValue = asString(option.value) || asString(option.label);
                        const optionLabel = asString(option.label) || optionValue;
                        const checked = selected.includes(optionValue);
                        return (
                            <label
                                key={`${field.id}-${option.id || optionValue || index}`}
                                className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
                            >
                                <input
                                    type="checkbox"
                                    checked={checked}
                                    onChange={(event) => {
                                        const next = event.target.checked
                                            ? Array.from(new Set([...selected, optionValue]))
                                            : selected.filter((item) => item !== optionValue);
                                        onChange(next);
                                    }}
                                    className="h-4 w-4 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                />
                                {optionLabel}
                            </label>
                        );
                    })}
                </div>
            );
        }

        case "textarea":
            return (
                <textarea
                    rows={4}
                    value={typeof value === "string" ? value : ""}
                    onChange={(event) => onChange(event.target.value)}
                    placeholder={field.placeholder || "Enter notes"}
                    className={commonClass}
                />
            );

        case "text":
        default:
            return (
                <input
                    type="text"
                    value={inputValue(value)}
                    onChange={(event) => onChange(event.target.value)}
                    placeholder={field.placeholder || "Enter value"}
                    className={commonClass}
                />
            );
    }
}

export default function DynamicSurveyTemplateView({
    template,
    onBack,
}: {
    template: SurveyTemplateRecord;
    onBack: () => void;
}) {
    const schema = asObject(template.schema) || {};
    const modules = useMemo(
        () =>
            (Array.isArray(schema.modules) ? schema.modules : [])
                .map(normalizeModule)
                .filter((module): module is DynamicModule => Boolean(module)),
        [schema.modules],
    );

    const canvas = useMemo(() => normalizeCanvas(schema.canvas), [schema.canvas]);
    const selectedFields = useMemo(
        () =>
            Array.isArray(schema.selectedFields)
                ? new Set(schema.selectedFields.map((value) => asString(value)).filter(Boolean))
                : new Set<string>(),
        [schema.selectedFields],
    );

    const initialValues = useMemo(() => normalizeInitialValues(schema.formValues), [schema.formValues]);
    const [values, setValues] = useState<Record<string, DynamicValue>>(initialValues);
    const [expanded, setExpanded] = useState<string | null>(null);

    const orderedModules = useMemo(() => {
        const byId = new Map(modules.map((module) => [asString(module.id), module]));
        const byCode = new Map(modules.map((module) => [asString(module.code).toLowerCase(), module]));

        const items = canvas.length
            ? canvas
                  .map((item) => {
                      const module =
                          byId.get(asString(item.moduleId)) ||
                          byCode.get(asString(item.moduleCode).toLowerCase());
                      return module
                          ? {
                                module,
                                repeatCount: Math.max(1, Number(item.repeatCount) || 1),
                            }
                          : null;
                  })
                  .filter(
                      (item): item is { module: DynamicModule; repeatCount: number } =>
                          Boolean(item),
                  )
            : modules.map((module) => ({
                  module,
                  repeatCount: module.repeatable ? 1 : 1,
              }));

        return items;
    }, [canvas, modules]);

    const visibleFieldCount = useMemo(() =>
        orderedModules.reduce(
            (count, item) => {
                const moduleFieldCount = (item.module.sections || []).reduce(
                    (sectionCount, section) =>
                        sectionCount +
                        (section.fieldGroups || []).reduce(
                            (groupCount, group) =>
                                groupCount +
                                (group.fields || []).filter(
                                    (field) =>
                                        selectedFields.size === 0 ||
                                        selectedFields.has(asString(field.id)),
                                ).length,
                            0,
                        ),
                    0,
                );

                return count + moduleFieldCount * item.repeatCount;
            },
            0,
        ),
    [orderedModules, selectedFields]);

    const handlePrint = () => {
        window.print();
    };

    const updateField = (key: string, value: DynamicValue) => {
        setValues((current) => ({ ...current, [key]: value }));
    };

    return (
        <div className="min-h-screen bg-slate-100 text-slate-800 dark:bg-slate-950 dark:text-slate-100">
            <div className="print-hidden sticky top-0 z-40 border-b border-slate-200 bg-white/95 shadow-sm backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
                <div className="mx-auto flex max-w-[1700px] items-center justify-between gap-3 px-4 py-3 lg:px-6">
                    <div className="flex min-w-0 items-center gap-3">
                        <button
                            type="button"
                            onClick={onBack}
                            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-600 transition hover:bg-slate-100 hover:text-red-600 dark:text-slate-300 dark:hover:bg-slate-800"
                            aria-label="Back to Survey Report"
                            title="Back to Survey Report"
                        >
                            <ArrowLeft size={18} weight="bold" />
                        </button>
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white">
                            <ClipboardText size={21} weight="duotone" />
                        </div>
                        <div className="min-w-0">
                            <p className="truncate text-sm font-black text-slate-900 dark:text-white">
                                {asString(template.name) || "Survey Template"}
                            </p>
                            <p className="truncate text-[10px] font-semibold uppercase tracking-widest text-slate-500">
                                Survey Template Preview
                            </p>
                        </div>
                    </div>

                    <button
                        type="button"
                        onClick={handlePrint}
                        className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-900"
                    >
                        <Printer size={16} />
                        <span className="hidden sm:inline">Print</span>
                    </button>
                </div>
            </div>

            <main className="mx-auto w-full max-w-[1700px] px-3 py-4 sm:px-5 lg:px-6">
                <section className="mb-4 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="relative overflow-hidden bg-slate-800 px-5 py-5 text-white md:px-6">
                        <div className="absolute right-0 top-0 h-40 w-40 rounded-full bg-red-400/10 blur-3xl" />
                        <div className="relative flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
                            <div>
                                <div className="mb-1 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-red-200">
                                    <FloppyDisk size={14} weight="bold" />
                                    Saved Survey Definition
                                </div>
                                <h1 className="text-xl font-black tracking-tight md:text-2xl">
                                    {asString(template.name) || "Untitled Survey Template"}
                                </h1>
                                <p className="mt-1 max-w-3xl text-xs font-medium text-red-100">
                                    {asString(template.description) || "No template description provided."}
                                </p>
                            </div>

                            <div className="rounded-xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur">
                                <div className="text-[10px] font-black uppercase tracking-widest text-red-200">
                                    Template Status
                                </div>
                                <div className="mt-1 flex items-center gap-2 text-sm font-bold">
                                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                                    {asString(template.status).toUpperCase() || "DRAFT"}
                                </div>
                                <div className="mt-2 text-[11px] text-red-100">
                                    {orderedModules.length} module{orderedModules.length === 1 ? "" : "s"} · {visibleFieldCount} field{visibleFieldCount === 1 ? "" : "s"}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">
                        <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Version</div>
                            <div className="mt-0.5 text-sm font-semibold text-slate-800">v{Number(template.version || 1)}</div>
                        </div>
                        <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Vendor Category</div>
                            <div className="mt-0.5 text-sm font-semibold text-slate-800">
                                {asString(schema.vendorCategory) || "Not specified"}
                            </div>
                        </div>
                        <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 sm:col-span-2 lg:col-span-1">
                            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Updated</div>
                            <div className="mt-0.5 flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                                <CalendarBlank size={14} className="text-slate-400" />
                                {template.updatedAt ? new Date(template.updatedAt).toLocaleDateString() : "—"}
                            </div>
                        </div>
                    </div>
                </section>

                {orderedModules.length === 0 ? (
                    <section className="rounded-xl border border-amber-200 bg-amber-50 p-6 text-sm text-amber-800">
                        This saved template does not contain any configured modules or fields yet.
                    </section>
                ) : (
                    <div className="space-y-4">
                        {orderedModules.map(({ module, repeatCount }, moduleIndex) => {
                            const ModuleIcon = getIcon(module.code);
                            const moduleKey = `${asString(module.id) || asString(module.code) || moduleIndex}`;
                            const isOpen = expanded === null ? moduleIndex === 0 : expanded === moduleKey;

                            return (
                                <section
                                    key={`${moduleKey}-${moduleIndex}`}
                                    className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"
                                >
                                    <button
                                        type="button"
                                        onClick={() => setExpanded(isOpen ? null : moduleKey)}
                                        className="flex w-full items-center justify-between gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:bg-white"
                                    >
                                        <div className="flex min-w-0 items-center gap-3">
                                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                                <ModuleIcon size={18} weight="duotone" />
                                            </div>
                                            <div className="min-w-0">
                                                <div className="flex flex-wrap items-center gap-2">
                                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                                                        {asString(module.zone) || "SURVEY"}
                                                    </span>
                                                    {module.code ? (
                                                        <span className="rounded-full border border-slate-200 bg-white px-2 py-0.5 text-[9px] font-bold text-slate-500">
                                                            {module.code}
                                                        </span>
                                                    ) : null}
                                                </div>
                                                <h2 className="mt-0.5 truncate text-sm font-bold text-slate-900">
                                                    {module.name}
                                                </h2>
                                                {module.description ? (
                                                    <p className="mt-0.5 truncate text-xs text-slate-500">{module.description}</p>
                                                ) : null}
                                            </div>
                                        </div>
                                        <div className="flex shrink-0 items-center gap-2 text-slate-400">
                                            {repeatCount > 1 ? (
                                                <span className="hidden rounded-full bg-white px-2 py-1 text-[10px] font-semibold text-slate-500 sm:inline-flex">
                                                    {repeatCount}× {module.unitLabel || "records"}
                                                </span>
                                            ) : null}
                                            {isOpen ? <CaretDown size={16} /> : <CaretRight size={16} />}
                                        </div>
                                    </button>

                                    {isOpen ? (
                                        <div className="space-y-5 p-4">
                                            {Array.from({ length: repeatCount }, (_, repeatIndex) => (
                                                <div
                                                    key={`${moduleKey}-repeat-${repeatIndex}`}
                                                    className={repeatCount > 1 ? "rounded-xl border border-slate-200 p-4" : ""}
                                                >
                                                    {repeatCount > 1 ? (
                                                        <div className="mb-4 flex items-center justify-between gap-2">
                                                            <h3 className="text-xs font-black uppercase tracking-widest text-slate-700">
                                                                {module.unitLabel || "Record"} {repeatIndex + 1}
                                                            </h3>
                                                            <span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-500">
                                                                {repeatIndex + 1} / {repeatCount}
                                                            </span>
                                                        </div>
                                                    ) : null}

                                                    {module.sections && module.sections.length > 0 ? (
                                                        <div className="space-y-5">
                                                            {module.sections.map((section, sectionIndex) => {
                                                                const groups = section.fieldGroups || [];
                                                                return (
                                                                    <div key={`${moduleKey}-${section.id || sectionIndex}`}>
                                                                        <div className="mb-3 flex items-center gap-2">
                                                                            <span className="h-6 w-6 rounded-full bg-red-50 text-center text-[10px] font-black leading-6 text-red-600">
                                                                                {sectionIndex + 1}
                                                                            </span>
                                                                            <h3 className="text-xs font-black uppercase tracking-widest text-slate-700">
                                                                                {asString(section.title) || "Section"}
                                                                            </h3>
                                                                        </div>

                                                                        <div className="space-y-3">
                                                                            {groups.map((group, groupIndex) => {
                                                                                const fields = (group.fields || []).filter(
                                                                                    (field) =>
                                                                                        selectedFields.size === 0 ||
                                                                                        selectedFields.has(asString(field.id)),
                                                                                );

                                                                                if (fields.length === 0) return null;

                                                                                return (
                                                                                    <div
                                                                                        key={`${moduleKey}-${group.id || groupIndex}`}
                                                                                        className="rounded-lg border border-slate-200 p-4"
                                                                                    >
                                                                                        {group.title ? (
                                                                                            <div className="mb-4 text-sm font-semibold text-slate-900">
                                                                                                {group.title}
                                                                                            </div>
                                                                                        ) : null}

                                                                                        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                                                                                            {fields.map((field, fieldIndex) => {
                                                                                                const valueKey = `${moduleKey}::${repeatIndex}::${asString(field.id) || fieldIndex}`;
                                                                                                return (
                                                                                                    <div
                                                                                                        key={valueKey}
                                                                                                        className={asString(field.type).toLowerCase() === "textarea" || asString(field.type).toLowerCase() === "checkbox_group" || asString(field.type).toLowerCase() === "radio" ? "lg:col-span-2" : ""}
                                                                                                    >
                                                                                                        <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                                                                            {asString(field.label) || "Untitled Field"}
                                                                                                            {field.required ? <span className="ml-1 text-red-500">*</span> : null}
                                                                                                        </label>
                                                                                                        {field.helpText ? (
                                                                                                            <p className="mb-2 text-[11px] leading-relaxed text-slate-400">{field.helpText}</p>
                                                                                                        ) : null}
                                                                                                        <DynamicFieldRenderer
                                                                                                            field={field}
                                                                                                            value={values[valueKey] ?? values[asString(field.id)]}
                                                                                                            inputName={valueKey}
                                                                                                            onChange={(nextValue) => updateField(valueKey, nextValue)}
                                                                                                        />
                                                                                                    </div>
                                                                                                );
                                                                                            })}
                                                                                        </div>
                                                                                    </div>
                                                                                );
                                                                            })}
                                                                        </div>
                                                                    </div>
                                                                );
                                                            })}
                                                        </div>
                                                    ) : (
                                                        <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4 text-xs text-slate-500">
                                                            This module has no field sections configured.
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    ) : null}
                                </section>
                            );
                        })}
                    </div>
                )}
            </main>
        </div>
    );
}
