import React, { useEffect, useMemo, useState } from "react";
import Select, { StylesConfig } from "react-select";
import {
  HardHat,
  MapPin,
  Buildings,
  ListChecks,
  CaretDown,
  CaretRight,
  Plus,
  Minus,
  Check,
  FloppyDisk,
  Radio,
  Warning,
  ArrowsClockwise,
  ArrowLeft,

} from "@phosphor-icons/react";
import IconSafari from "../Icon/IconSafari";
import AddModule from "../../offcanvas/surveyform/addmodule";
import type { SurveyTemplate } from "./SurveyList";
import { useNavigate, useSearchParams } from "react-router-dom";
import api, { getApiErrorMessage } from "../../api/axios";
import {
    SurveyModule,
    SurveyField,
    SurveyFieldGroup,
    SurveyFieldOption,
    SurveySection,
} from "./SurveyStorage";
import { FieldOption, FieldRendererProps, FieldType, FormValue } from "../../types/survey";
import {
    createSurveyTemplate,
    getSurveyTemplate,
    listSurveyTemplates,
    updateSurveyTemplate,
    SurveyTemplateRecord,
} from "../../api/surveyApi";

export const INITIAL_MODULES: SurveyModule[] = [
    {
        id: "mod1",
        code: "MOD-01",
        zone: "CO",
        name: "Central Office / Headend Check",
        icon: Buildings,
        fields: 14,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH OSP Network Survey",
            "FTTH Network & Drop Survey",
        ],

        sections: [
            {
                id: "mod1-sec1",
                title: "General Facility & Environmental Checks",

                fieldGroups: [
                    {
                        id: "co-access-security",
                        title: "CO Facility Access & Security",

                        fields: [
                            {
                                id: "co-access-status",
                                name: "status",
                                label: "Status",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Pass",
                                        value: "pass",
                                        id: "",
                                    },
                                    {
                                        label: "Fail",
                                        value: "fail",
                                        id: "",
                                    },
                                ],
                            },
                            {
                                id: "co-access-security-method",
                                name: "securityMethod",
                                label: "Keypad / padlock / security guard",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Yes",
                                        value: "yes",
                                        id: "",
                                    },
                                    {
                                        label: "No",
                                        value: "no",
                                        id: "",
                                    },
                                ],
                            },
                        ],
                    },
                    {
                        id: "rack-space-availability",
                        title: "Rack Space Availability (OLT/ODF)",

                        fields: [
                            {
                                id: "rack-space-status",
                                name: "rackSpaceStatus",
                                label: "Status",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Pass",
                                        value: "pass",
                                        id: "",
                                    },
                                    {
                                        label: "Fail",
                                        value: "fail",
                                        id: "",
                                    },
                                ],
                            },
                            {
                                id: "usable-rack-units",
                                name: "usableRackUnits",
                                label: "Usable rack units",
                                type: "number",
                                required: true,
                                unit: "RU",
                            },
                            {
                                id: "rack-space-action",
                                name: "rackSpaceAction",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        label: "Yes",
                                        value: "yes",
                                        id: "",
                                    },
                                    {
                                        label: "No",
                                        value: "no",
                                        id: "",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod2",
        code: "MOD-02",
        zone: "OSP",
        name: "OSP Pole / Structure Survey",
        icon: Radio,
        fields: 22,
        repeatable: true,
        unitLabel: "Pole / Structure Record",
        templateNames: [
          
            "FTTH OSP Network Survey",
            
        ],

        sections: [
            {
                id: "mod2-sec1",
                title: "Pole / Structure Identification",
                fieldGroups: [
                    {
                        id: "osp-structure-identification",
                        title: "Structure Identification",
                        fields: [
                            {
                                id: "osp-structure-id",
                                name: "structureId",
                                label: "Structure / Pole ID",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "osp-structure-type",
                                name: "structureType",
                                label: "Structure Type",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Wooden Pole",
                                        value: "wooden_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Concrete Pole",
                                        value: "concrete_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Steel Pole",
                                        value: "steel_pole",
                                    },
                                    {
                                        id: "",
                                        label: "Other",
                                        value: "other",
                                    },
                                ],
                            },
                            {
                                id: "osp-location-reference",
                                name: "locationReference",
                                label: "Location / Landmark",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "osp-gps-latitude",
                                name: "gpsLatitude",
                                label: "GPS Latitude",
                                type: "number",
                                required: true,
                            },
                            {
                                id: "osp-gps-longitude",
                                name: "gpsLongitude",
                                label: "GPS Longitude",
                                type: "number",
                                required: true,
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec2",
                title: "Pole Condition & Structural Assessment",
                fieldGroups: [
                    {
                        id: "osp-pole-condition",
                        title: "Pole Condition",
                        fields: [
                            {
                                id: "osp-pole-condition-status",
                                name: "poleConditionStatus",
                                label: "Overall Pole Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Pass",
                                        value: "pass",
                                    },
                                    {
                                        id: "",
                                        label: "Fail",
                                        value: "fail",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-damage",
                                name: "poleDamage",
                                label: "Visible Damage",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "None",
                                        value: "none",
                                    },
                                    {
                                        id: "",
                                        label: "Minor",
                                        value: "minor",
                                    },
                                    {
                                        id: "",
                                        label: "Major",
                                        value: "major",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-tilt",
                                name: "poleTilt",
                                label: "Pole Tilt / Lean",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Acceptable",
                                        value: "acceptable",
                                    },
                                    {
                                        id: "",
                                        label: "Requires Attention",
                                        value: "requires_attention",
                                    },
                                ],
                            },
                            {
                                id: "osp-pole-height",
                                name: "poleHeight",
                                label: "Approximate Pole Height",
                                type: "number",
                                required: true,
                                unit: "m",
                            },
                            {
                                id: "osp-foundation-condition",
                                name: "foundationCondition",
                                label: "Foundation / Ground Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Needs Repair",
                                        value: "needs_repair",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec3",
                title: "Cable & Attachment Assessment",
                fieldGroups: [
                    {
                        id: "osp-cable-attachments",
                        title: "Cable / Hardware Attachments",
                        fields: [
                            {
                                id: "osp-existing-cables",
                                name: "existingCables",
                                label: "Existing Cable Attachments",
                                type: "number",
                                required: true,
                            },
                            {
                                id: "osp-cable-clearance",
                                name: "cableClearance",
                                label: "Cable Clearance",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Compliant",
                                        value: "compliant",
                                    },
                                    {
                                        id: "",
                                        label: "Non-compliant",
                                        value: "non_compliant",
                                    },
                                ],
                            },
                            {
                                id: "osp-hardware-condition",
                                name: "hardwareCondition",
                                label: "Attachment Hardware Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Damaged",
                                        value: "damaged",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "osp-new-attachment-required",
                                name: "newAttachmentRequired",
                                label: "New Attachment Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod2-sec4",
                title: "Safety & Survey Notes",
                fieldGroups: [
                    {
                        id: "osp-safety-notes",
                        title: "Safety & Action Required",
                        fields: [
                            {
                                id: "osp-safety-status",
                                name: "safetyStatus",
                                label: "Safety Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Safe",
                                        value: "safe",
                                    },
                                    {
                                        id: "",
                                        label: "Unsafe",
                                        value: "unsafe",
                                    },
                                ],
                            },
                            {
                                id: "osp-action-required",
                                name: "actionRequired",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                            {
                                id: "osp-survey-notes",
                                name: "surveyNotes",
                                label: "Survey Notes",
                                type: "textarea",
                                required: false,
                                placeholder: "Enter additional observations...",
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod3",
        code: "MOD-03",
        zone: "NAP",
        name: "NAP Station Inspection",
        icon: IconSafari,
        fields: 18,
        repeatable: true,
        unitLabel: "NAP Station",
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH OSP Network Survey",
            "FTTH Network & Drop Survey",
        ],

        sections: [
            {
                id: "mod3-sec1",
                title: "NAP Station Identification",
                fieldGroups: [
                    {
                        id: "nap-station-identification",
                        title: "Station Details",
                        fields: [
                            {
                                id: "nap-station-id",
                                name: "stationId",
                                label: "NAP Station ID",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "nap-station-type",
                                name: "stationType",
                                label: "NAP Type",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Wall Mounted",
                                        value: "wall_mounted",
                                    },
                                    {
                                        id: "",
                                        label: "Pole Mounted",
                                        value: "pole_mounted",
                                    },
                                    {
                                        id: "",
                                        label: "Cabinet",
                                        value: "cabinet",
                                    },
                                ],
                            },
                            {
                                id: "nap-location",
                                name: "location",
                                label: "Location / Landmark",
                                type: "text",
                                required: true,
                            },
                            {
                                id: "nap-port-count",
                                name: "portCount",
                                label: "Total Port Count",
                                type: "number",
                                required: true,
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec2",
                title: "NAP Enclosure Condition",
                fieldGroups: [
                    {
                        id: "nap-enclosure-condition",
                        title: "Enclosure & Physical Condition",
                        fields: [
                            {
                                id: "nap-enclosure-status",
                                name: "enclosureStatus",
                                label: "Enclosure Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Pass",
                                        value: "pass",
                                    },
                                    {
                                        id: "",
                                        label: "Fail",
                                        value: "fail",
                                    },
                                ],
                            },
                            {
                                id: "nap-door-condition",
                                name: "doorCondition",
                                label: "Door / Cover Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Damaged",
                                        value: "damaged",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "nap-lock-condition",
                                name: "lockCondition",
                                label: "Lock / Security Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Secure",
                                        value: "secure",
                                    },
                                    {
                                        id: "",
                                        label: "Not Secure",
                                        value: "not_secure",
                                    },
                                ],
                            },
                            {
                                id: "nap-water-ingress",
                                name: "waterIngress",
                                label: "Water / Moisture Ingress",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec3",
                title: "Fiber & Port Inspection",
                fieldGroups: [
                    {
                        id: "nap-fiber-port-inspection",
                        title: "Fiber / Port Condition",
                        fields: [
                            {
                                id: "nap-port-status",
                                name: "portStatus",
                                label: "Port Availability",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Available",
                                        value: "available",
                                    },
                                    {
                                        id: "",
                                        label: "Occupied",
                                        value: "occupied",
                                    },
                                    {
                                        id: "",
                                        label: "Faulty",
                                        value: "faulty",
                                    },
                                ],
                            },
                            {
                                id: "nap-splice-condition",
                                name: "spliceCondition",
                                label: "Splice / Fiber Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Good",
                                        value: "good",
                                    },
                                    {
                                        id: "",
                                        label: "Needs Attention",
                                        value: "needs_attention",
                                    },
                                ],
                            },
                            {
                                id: "nap-labeling-status",
                                name: "labelingStatus",
                                label: "Fiber Labeling",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Correct",
                                        value: "correct",
                                    },
                                    {
                                        id: "",
                                        label: "Incorrect",
                                        value: "incorrect",
                                    },
                                    {
                                        id: "",
                                        label: "Missing",
                                        value: "missing",
                                    },
                                ],
                            },
                            {
                                id: "nap-slack-storage",
                                name: "slackStorage",
                                label: "Slack Fiber Storage",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Adequate",
                                        value: "adequate",
                                    },
                                    {
                                        id: "",
                                        label: "Inadequate",
                                        value: "inadequate",
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },

            {
                id: "mod3-sec4",
                title: "NAP Safety & Actions",
                fieldGroups: [
                    {
                        id: "nap-safety-actions",
                        title: "Safety & Action Required",
                        fields: [
                            {
                                id: "nap-safety-status",
                                name: "safetyStatus",
                                label: "Safety Condition",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Safe",
                                        value: "safe",
                                    },
                                    {
                                        id: "",
                                        label: "Unsafe",
                                        value: "unsafe",
                                    },
                                ],
                            },
                            {
                                id: "nap-action-required",
                                name: "actionRequired",
                                label: "Action Required",
                                type: "radio",
                                required: true,
                                options: [
                                    {
                                        id: "",
                                        label: "Yes",
                                        value: "yes",
                                    },
                                    {
                                        id: "",
                                        label: "No",
                                        value: "no",
                                    },
                                ],
                            },
                            {
                                id: "nap-inspection-notes",
                                name: "inspectionNotes",
                                label: "Inspection Notes",
                                type: "textarea",
                                required: false,
                                placeholder: "Enter additional observations...",
                            },
                        ],
                    },
                ],
            },
        ],
    },

    {
        id: "mod4",
        code: "MOD-04",
        zone: "DROP",
        name: "Residential Drop & Premises",
        icon: MapPin,
        fields: 16,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
            "FTTH Network & Drop Survey",
        ],
    },

    {
        id: "mod5",
        code: "MOD-05",
        zone: "QC",
        name: "Defect / Punch-list",
        icon: ListChecks,
        fields: 9,
        repeatable: true,
        unitLabel: "Defect",
        hasConditional: true,
        templateNames: [
            "Full FTTH Field Survey",
        ],
    },

    {
        id: "mod6",
        code: "MOD-06",
        zone: "SAFETY",
        name: "PPE & Tool Checklist",
        icon: HardHat,
        fields: 12,
        repeatable: false,
        templateNames: [
            "Full FTTH Field Survey",
        ],
    },
];


const ZONE_COLOR: Record<string, string> = {
  CO: "text-[#4FB6A8] border-[#4FB6A8]/40 bg-[#4FB6A8]/10",
  OSP: "text-[#E8A33D] border-[#E8A33D]/40 bg-[#E8A33D]/10",
  NAP: "text-[#7FA8D9] border-[#7FA8D9]/40 bg-[#7FA8D9]/10",
  DROP: "text-[#C48FD9] border-[#C48FD9]/40 bg-[#C48FD9]/10",
  QC: "text-[#D6614A] border-[#D6614A]/40 bg-[#D6614A]/10",
  SAFETY: "text-[#E8D23D] border-[#E8D23D]/40 bg-[#E8D23D]/10",
};



type CanvasItem = {
  moduleId: string;
  repeatCount: number;
  allowFieldAdd: boolean;
};

type SurveyReportProps = {
    open: boolean;
    onClose: () => void;
    template?: SurveyTemplate | null;
};

async function fetchVendorCategories(signal?: AbortSignal): Promise<{ value: string; label: string }[]> {
    const response = await api.get("/vendors/categories", {
        params: { page: 1, limit: 200, status: true },
        signal,
    });

    if (response.data?.success === false) {
        throw new Error(response.data?.message || "Unable to load vendor categories.");
    }

    const responseData = response.data?.data;
    const rawItems = Array.isArray(responseData)
        ? responseData
        : responseData && typeof responseData === "object" && Array.isArray(responseData.data)
            ? responseData.data
            : Array.isArray(response.data?.items)
                ? response.data.items
                : [];

    return rawItems
        .map((item: any) => ({
            value: String(item?.id ?? item?._id ?? item?.value ?? "").trim(),
            label: String(item?.name ?? item?.label ?? "").trim(),
        }))
        .filter((item: { value: string; label: string }) => item.value && item.label);
}

export default function SurveyReport() {
const [canvas, setCanvas] = useState<CanvasItem[]>([
    { moduleId: "mod2", repeatCount: 4, allowFieldAdd: true },
    { moduleId: "mod3", repeatCount: 3, allowFieldAdd: true },
    { moduleId: "mod5", repeatCount: 3, allowFieldAdd: true },
    { moduleId: "mod6", repeatCount: 1, allowFieldAdd: false },
]);

    const [expanded, setExpanded] = useState<string | null>("mod5");
    const [formValues, setFormValues] = useState<Record<string, FormValue>>({});
    const [label, setLabel] = useState("");
    const [type, setType] = useState<FieldType>("text");
    const [required, setRequired] = useState(false);
    const [unit, setUnit] = useState("");
    const [options, setOptions] = useState<FieldOption[]>([]);

    const [selectedFields, setSelectedFields] = useState<string[]>([]);

    

const getModuleIcon = (
    module: Partial<SurveyModule>
): React.ElementType => {
    switch (module.code) {
        case "MOD-01":
            return Buildings;
        case "MOD-02":
            return Radio;
        case "MOD-03":
            return IconSafari;
        case "MOD-04":
            return MapPin;
        case "MOD-05":
            return ListChecks;
        case "MOD-06":
            return HardHat;
        default:
            return Buildings;
    }
};
const [modules, setModules] = useState<SurveyModule[]>(INITIAL_MODULES);

    // fetching existing data starts
    const [addModuleOpen, setAddModuleOpen] = useState(false);
    const [searchParams] = useSearchParams();
    const editId = searchParams.get("editId");
    const [editingModule, setEditingModule] = useState<SurveyModule | null>(null);
    const [loadedTemplate, setLoadedTemplate] = useState<SurveyTemplate | null>(null);
    const [selectedTemplateSchemaCanvas, setSelectedTemplateSchemaCanvas] = useState<unknown[]>([]);
    const [templateLoading, setTemplateLoading] = useState(false);
    const [templateSaving, setTemplateSaving] = useState(false);
    const [templateError, setTemplateError] = useState("");
    const [templateName, setTemplateName] = useState("");
    const [templateDescription, setTemplateDescription] = useState("");
    const [templateStatus, setTemplateStatus] = useState<"draft" | "active" | "archived">("active");
    const [vendorCategory, setVendorCategory] = useState("");
    const [vendorCategoryOptions, setVendorCategoryOptions] = useState<
        { value: string; label: string }[]
    >([]);
    const [vendorCategoriesLoading, setVendorCategoriesLoading] = useState(false);

    const selectedVendorCategoryOption = useMemo(() => {
        if (!vendorCategory) {
            return null;
        }

        return (
            vendorCategoryOptions.find(
                (option) => option.value === vendorCategory,
            ) || {
                value: vendorCategory,
                label: vendorCategory,
            }
        );
    }, [vendorCategory, vendorCategoryOptions]);

    const vendorCategoryStyles: StylesConfig<{ value: string; label: string }, false> = useMemo(
        () => ({
            control: (base) => ({
                ...base,
                minHeight: "41px",
                borderColor: "#cbd5e1",
                borderRadius: "8px",
                boxShadow: "none",
                fontSize: "14px",
                "&:hover": { borderColor: "#cbd5e1" },
            }),
            valueContainer: (base) => ({ ...base, padding: "2px 10px" }),
            placeholder: (base) => ({ ...base, color: "#94a3b8" }),
            singleValue: (base) => ({ ...base, color: "#334155" }),
            indicatorSeparator: (base) => ({ ...base, backgroundColor: "#cbd5e1", marginTop: "8px", marginBottom: "8px" }),
            dropdownIndicator: (base) => ({ ...base, color: "#94a3b8", padding: "0 10px" }),
            menu: (base) => ({ ...base, zIndex: 40, fontSize: "14px", borderRadius: "8px", overflow: "hidden" }),
            option: (base, state) => ({
                ...base,
                backgroundColor: state.isSelected ? "#ef4444" : state.isFocused ? "#fef2f2" : "#ffffff",
                color: state.isSelected ? "#ffffff" : "#334155",
                cursor: "pointer",
            }),
        }),
        [],
    );

    const selectedTemplate = useMemo<SurveyTemplate | null>(() => loadedTemplate, [loadedTemplate]);

useEffect(() => {
    let active = true;
    const controller = new AbortController();

    const loadVendorCategories = async () => {
        setVendorCategoriesLoading(true);

        try {
            const response = await fetchVendorCategories(controller.signal);

            if (!active || controller.signal.aborted) {
                return;
            }

            setVendorCategoryOptions(response);
        } catch (error: any) {
            if (error?.name === "AbortError" || error?.name === "CanceledError" || error?.code === "ERR_CANCELED") {
                return;
            }

            // The template editor remains usable when a user does not have
            // vendor-settings read access. A legacy stored value is rendered
            // through selectedVendorCategoryOption below instead of being lost.
            if (active) {
                setVendorCategoryOptions([]);
            }
        } finally {
            if (active) {
                setVendorCategoriesLoading(false);
            }
        }
    };

    void loadVendorCategories();

    return () => {
        active = false;
        controller.abort();
    };
}, []);


useEffect(() => {
    let active = true;
    const controller = new AbortController();

    const loadSavedModuleDefinitions = async () => {
        try {
            const result = await listSurveyTemplates({
                page: 1,
                limit: 100,
                status: "all",
                signal: controller.signal,
            });

            if (!active || controller.signal.aborted) {
                return;
            }

            const savedModules = result.data.flatMap((record) =>
                Array.isArray(record.schema?.modules)
                    ? record.schema.modules
                          .filter((module): module is Record<string, unknown> =>
                              Boolean(module) && typeof module === "object" && !Array.isArray(module),
                          )
                          .map((module) => ({
                              ...module,
                              id: String(module.id ?? "").trim(),
                              code: String(module.code ?? "").trim(),
                              name: String(module.name ?? "").trim(),
                              icon: getModuleIcon(module),
                          }))
                    : [],
            );

            setModules((current) => {
                const merged = new Map(
                    current.map((module) => [module.id, module]),
                );
                const codes = new Map(
                    current.map((module) => [module.code.toLowerCase(), module.id]),
                );

                for (const raw of savedModules) {
                    if (!raw.id || !raw.code || !raw.name) continue;
                    const existingId = codes.get(raw.code.toLowerCase());
                    if (existingId && existingId !== raw.id) continue;
                    const existing = merged.get(raw.id);
                    const module = {
                        ...(existing || {}),
                        ...raw,
                        icon: getModuleIcon(raw),
                    } as SurveyModule;
                    merged.set(module.id, module);
                    codes.set(module.code.toLowerCase(), module.id);
                }

                return Array.from(merged.values());
            });
        } catch (error: any) {
            if (error?.name === "CanceledError" || error?.code === "ERR_CANCELED" || error?.name === "AbortError") {
                return;
            }
        }
    };

    void loadSavedModuleDefinitions();

    return () => {
        active = false;
        controller.abort();
    };
}, []);

useEffect(() => {
    if (!vendorCategory || vendorCategoryOptions.length === 0) {
        return;
    }

    const current = vendorCategoryOptions.find(
        (option) =>
            option.value === vendorCategory ||
            option.label.trim().toLowerCase() === vendorCategory.trim().toLowerCase(),
    );

    if (current && current.value !== vendorCategory) {
        setVendorCategory(current.value);
    }
}, [vendorCategory, vendorCategoryOptions]);

useEffect(() => {
    let active = true;
    const controller = new AbortController();

    const loadTemplate = async () => {
        if (!editId) {
            setLoadedTemplate(null);
            setSelectedTemplateSchemaCanvas([]);
            setTemplateError("");
            setTemplateLoading(false);
            return;
        }

        if (!/^[a-f\d]{24}$/i.test(String(editId))) {
            setLoadedTemplate(null);
            setTemplateError("This survey template link is no longer valid. Please open an existing template from the Survey Report list.");
            setTemplateLoading(false);
            return;
        }

        setTemplateLoading(true);
        setTemplateError("");

        try {
            const record: SurveyTemplateRecord = await getSurveyTemplate(
                editId,
                controller.signal,
            );

            if (!active) {
                return;
            }

            const schemaModules = Array.isArray(record.schema?.modules)
                ? record.schema.modules
                      .filter((module): module is Record<string, unknown> =>
                          Boolean(module) && typeof module === "object" && !Array.isArray(module),
                      )
                      .map((module) => ({
                          ...module,
                          id: String(module.id ?? crypto.randomUUID()),
                          code: String(module.code ?? "").trim(),
                          zone: String(module.zone ?? "CO").trim(),
                          name: String(module.name ?? "Untitled Module").trim(),
                          description: String(module.description ?? "").trim(),
                          fields: Math.max(0, Number(module.fields) || 0),
                          repeatable: Boolean(module.repeatable),
                          unitLabel: String(module.unitLabel ?? "").trim(),
                          hasConditional: Boolean(module.hasConditional),
                          sections: Array.isArray(module.sections) ? module.sections : [],
                          templateNames: Array.isArray(module.templateNames) ? module.templateNames : [],
                          icon: getModuleIcon(module),
                      })) as SurveyModule[]
                : [];

            const fallbackCodes = Array.isArray(record.moduleCodes)
                ? record.moduleCodes.map((code) => String(code).trim()).filter(Boolean)
                : [];

            setModules((current) => {
                const byId = new Map(current.map((module) => [module.id, module]));
                const byCode = new Map(current.map((module) => [module.code.toLowerCase(), module]));

                for (const apiModule of schemaModules) {
                    const existing = byId.get(apiModule.id) || byCode.get(apiModule.code.toLowerCase());
                    byId.set(apiModule.id, {
                        ...(existing || {}),
                        ...apiModule,
                        icon: getModuleIcon(apiModule),
                    } as SurveyModule);
                    byCode.set(apiModule.code.toLowerCase(), byId.get(apiModule.id)!);
                }

                return Array.from(byId.values());
            });

            const modulesFromApi =
                fallbackCodes.length > 0
                    ? fallbackCodes
                    : schemaModules
                          .map((module) => String(module.code).trim())
                          .filter(Boolean);

            setLoadedTemplate({
                id: String(record.id),
                name: String(record.name || "Untitled Survey"),
                description: String(record.description || ""),
                status:
                    String(record.status || "draft").toLowerCase() === "active"
                        ? "Active"
                        : String(record.status || "draft").toLowerCase() === "archived"
                            ? "Archived"
                            : "Draft",
                modules: modulesFromApi,
                version: Number(record.version || 1),
                updatedAt: record.updatedAt ?? null,
            });

            const storedVendorCategory = record.schema?.vendorCategory;
            setVendorCategory(
                typeof storedVendorCategory === "string" ? storedVendorCategory.trim() : "",
            );

            const storedFormValues = record.schema?.formValues;
            setFormValues(
                storedFormValues && typeof storedFormValues === "object" && !Array.isArray(storedFormValues)
                    ? storedFormValues as Record<string, FormValue>
                    : {},
            );

            setSelectedTemplateSchemaCanvas(
                Array.isArray(record.schema?.canvas) ? record.schema.canvas : [],
            );

            const storedSelectedFields = record.schema?.selectedFields;
            setSelectedFields(
                Array.isArray(storedSelectedFields)
                    ? storedSelectedFields.map((fieldId) => String(fieldId).trim()).filter(Boolean)
                    : [],
            );
        } catch (error: any) {
            if (error?.name === "CanceledError" || error?.code === "ERR_CANCELED" || error?.name === "AbortError") {
                return;
            }

            if (active) {
                setLoadedTemplate(null);
                setTemplateError(
                    getApiErrorMessage(
                        error,
                        "Unable to load the survey template.",
                    ),
                );
            }
        } finally {
            if (active) {
                setTemplateLoading(false);
            }
        }
    };

    void loadTemplate();

    return () => {
        active = false;
        controller.abort();
    };
}, [editId]);

useEffect(() => {
    if (!editId) {
        setTemplateName("");
        setTemplateDescription("");
        setTemplateStatus("active");
        setVendorCategory("");
        setFormValues({});
        setSelectedFields([]);
        setSelectedTemplateSchemaCanvas([]);
        return;
    }

    if (!selectedTemplate) {
        return;
    }

    setTemplateName(selectedTemplate.name);
    setTemplateDescription(selectedTemplate.description);
    const normalizedStatus = String(selectedTemplate.status || "Draft").toLowerCase();
    setTemplateStatus(
        normalizedStatus === "active"
            ? "active"
            : normalizedStatus === "archived"
                ? "archived"
                : "draft",
    );
}, [editId, selectedTemplate]);

useEffect(() => {
    if (!selectedTemplate || modules.length === 0) {
        return;
    }

    // The server schema is authoritative when editing an existing template.
    // Preserve its repeat counts and ordering instead of rebuilding them from
    // hardcoded defaults.
    const rawCanvas = selectedTemplateSchemaCanvas;
    const byCode = new Map(modules.map((module) => [module.code.toLowerCase(), module]));
    const byId = new Map(modules.map((module) => [module.id, module]));

    const nextCanvas: CanvasItem[] = (
        Array.isArray(rawCanvas) && rawCanvas.length > 0
            ? rawCanvas
                  .map((item) => {
                      if (!item || typeof item !== "object") return null;
                      const raw = item as Record<string, unknown>;
                      const rawId = String(raw.moduleId ?? raw.id ?? "").trim();
                      const rawCode = String(raw.moduleCode ?? raw.code ?? "").trim().toLowerCase();
                      const module = byId.get(rawId) || byCode.get(rawCode);
                      if (!module) return null;
                      return {
                          moduleId: module.id,
                          repeatCount: Math.max(1, Number(raw.repeatCount) || 1),
                          allowFieldAdd: Boolean(raw.allowFieldAdd) && Boolean(module.repeatable),
                      };
                  })
                  .filter((item): item is CanvasItem => item !== null)
            : selectedTemplate.modules
                  .map((moduleCode) => {
                      const module = byCode.get(String(moduleCode).toLowerCase());
                      if (!module) return null;
                      return {
                          moduleId: module.id,
                          repeatCount: module.repeatable ? 1 : 1,
                          allowFieldAdd: !!module.repeatable,
                      };
                  })
                  .filter((item): item is CanvasItem => item !== null)
    );

    setCanvas(nextCanvas);

    if (nextCanvas.length > 0) {
        setExpanded(nextCanvas[0].moduleId);
    }
}, [selectedTemplate, modules, selectedTemplateSchemaCanvas]);



    // Fetching existing data ends

const getAllFieldIds = () => {
    return canvas.flatMap((item) => {
        const module = modules.find(
            (mod) => mod.id === item.moduleId
        );

        if (!module) {
            return [];
        }

        return (
            module.sections?.flatMap((section) =>
                section.fieldGroups?.flatMap((group) =>
                    group.fields?.map((field) => field.id) ?? []
                ) ?? []
            ) ?? []
        );
    });
};

const handleSelectAllFields = () => {
    const allFieldIds = getAllFieldIds();

    if (selectedFields.length === allFieldIds.length) {
        setSelectedFields([]);
    } else {
        setSelectedFields(allFieldIds);
    }
};

//   const handleAddField = () => {
//     const newField: SurveyField = {
//         id: crypto.randomUUID(),
//         name: label
//             .toLowerCase()
//             .replace(/\s+/g, "_"),
//         label,
//         type,
//         required,
//         unit: type === "number" ? unit : undefined,
//         options:
//             type === "radio" || type === "select"
//                 ? options
//                 : undefined,
//     };

//     onAddField(newField);
// };

const handleCreateModule = (newModule: SurveyModule) => {
    const duplicate = modules.some(
        (module) =>
            module.code.trim().toLowerCase() ===
            newModule.code.trim().toLowerCase(),
    );

    if (duplicate) {
        setTemplateError("A module with this code already exists.");
        return;
    }

    setModules((current) => [
        ...current,
        { ...newModule, icon: getModuleIcon(newModule) },
    ]);

    setCanvas((current) => [
        ...current,
        {
            moduleId: newModule.id,
            repeatCount: newModule.repeatable ? 1 : 1,
            allowFieldAdd: !!newModule.repeatable,
        },
    ]);

    setEditingModule(null);
    setAddModuleOpen(false);
};

const handleUpdateModule = (updatedModule: SurveyModule) => {
    const duplicate = modules.some(
        (module) =>
            module.id !== updatedModule.id &&
            module.code.trim().toLowerCase() ===
                updatedModule.code.trim().toLowerCase(),
    );

    if (duplicate) {
        setTemplateError("A module with this code already exists.");
        return;
    }

    setModules((current) =>
        current.map((module) =>
            module.id === updatedModule.id
                ? { ...updatedModule, icon: getModuleIcon(updatedModule) }
                : module,
        ),
    );

    setCanvas((current) =>
        current.map((item) =>
            item.moduleId === updatedModule.id ? { ...item } : item,
        ),
    );

    setEditingModule(null);
    setAddModuleOpen(false);
};
    
  const [otherChecked, setOtherChecked] = useState(true);
  const [savedFlash, setSavedFlash] = useState(false);



  const inCanvas = (id: string) =>
    canvas.some((item) => item.moduleId === id);

  const toggleModule = (id: string) => {
    setCanvas((prev) => {
      if (prev.some((item) => item.moduleId === id)) {
        return prev.filter((item) => item.moduleId !== id);
      }

      const module = modules.find((item) => item.id === id);

      if (!module) return prev;

      return [
        ...prev,
        {
          moduleId: id,
          repeatCount: 1,
          allowFieldAdd: !!module.repeatable,
        },
      ];
    });

    setExpanded(id);
  };

  const setRepeat = (id: string, delta: number) => {
    setCanvas((prev) =>
      prev.map((item) =>
        item.moduleId === id
          ? {
              ...item,
              repeatCount: Math.max(1, item.repeatCount + delta),
            }
          : item
      )
    );
  };

  const totalFields = canvas.reduce((total, item) => {
    const module = modules.find(
        (mod) => mod.id === item.moduleId
    );

    return total + (module?.fields ?? 0);
}, 0);

  const toggleAllowAdd = (id: string) => {
    setCanvas((prev) =>
      prev.map((item) =>
        item.moduleId === id
          ? { ...item, allowFieldAdd: !item.allowFieldAdd }
          : item
      )
    );
  };

//   const totalFields = useMemo(
//     () =>
//       canvas.reduce((sum, item) => {
//         const module = modules.find((mod) => mod.id === item.moduleId);
//         return sum + (module?.fields || 0) * item.repeatCount;
//       }, 0),
//     [canvas]
//   );
 

function FieldRenderer({
    field,
    value,
    onChange,
}: FieldRendererProps) {
    switch (field.type) {
        case "text":
            return (
                <input
                    type="text"
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                />
            );

        case "number":
            return (
                <div className="flex items-center gap-2">
                    <input
                        type="number"
                        value={value ?? ""}
                        onChange={(e) =>
                            onChange(field.id, e.target.value)
                        }
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                    />

                    {field.unit && (
                        <span className="text-xs text-slate-500">
                            {field.unit}
                        </span>
                    )}
                </div>
            );

        case "radio":
            return (
                <div className="flex flex-wrap gap-4">
                    {field.options?.map((option) => (
                        <label
                            key={option.value}
                            className="flex cursor-pointer items-center gap-2 text-sm text-slate-600"
                        >
                            <input
                                type="radio"
                                name={field.id}
                                value={option.value}
                                checked={value === option.value}
                                onChange={() =>
                                    onChange(
                                        field.id,
                                        option.value
                                    )
                                }
                            />

                            {option.label}
                        </label>
                    ))}
                </div>
            );

        case "select":
            return (
                <select
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-amber-400"
                >
                    <option value="">
                        Select...
                    </option>

                    {field.options?.map((option) => (
                        <option
                            key={option.value}
                            value={option.value}
                        >
                            {option.label}
                        </option>
                    ))}
                </select>
            );

        case "textarea":
            return (
                <textarea
                    value={value ?? ""}
                    onChange={(e) =>
                        onChange(field.id, e.target.value)
                    }
                    rows={4}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400"
                />
            );

        default:
            return null;
    }
}

const handleSaveTemplate = async (statusOverride?: "draft" | "active" | "archived") => {
    if (templateSaving) {
        return;
    }

    if (editId && !selectedTemplate) {
        setTemplateError(
            "The selected survey template could not be loaded. Return to Survey Report and open the template again.",
        );
        return;
    }

    const modulePayload = modules
        .map(({ icon, ...module }) => ({
            ...module,
        }))
        .filter((module) =>
            canvas.some((item) => item.moduleId === module.id)
        );

    const normalizedTemplateName = templateName.trim();
    const normalizedDescription = templateDescription.trim();

    if (!normalizedTemplateName) {
        setTemplateError("Survey template name is required.");
        return;
    }

    if (normalizedTemplateName.length > 255) {
        setTemplateError("Survey template name must be 255 characters or fewer.");
        return;
    }

    if (normalizedDescription.length > 2000) {
        setTemplateError("Survey template description must be 2000 characters or fewer.");
        return;
    }

    const existingId = selectedTemplate?.id ?? null;
    const effectiveStatus = statusOverride ?? templateStatus;

    const payload = {
        name: normalizedTemplateName,
        description: normalizedDescription,
        status: effectiveStatus,
        schema: {
            version: Number(selectedTemplate?.version || 1),
            modules: modulePayload,
            canvas,
            vendorCategory,
            formValues,
            selectedFields,
        },
    };

    setTemplateSaving(true);
    setTemplateError("");

    try {
        const normalizedExistingId = String(existingId ?? "").trim();
        const saved = /^[a-f\d]{24}$/i.test(normalizedExistingId)
            ? await updateSurveyTemplate(
                normalizedExistingId,
                payload,
            )
            : await createSurveyTemplate(payload);

        if (!saved?.id) {
            throw new Error("The server returned an invalid survey template response.");
        }

        setLoadedTemplate({
            id: String(saved.id),
            name: String(saved.name || templateName),
            description: String(saved.description || payload.description),
            status:
                String(saved.status || payload.status).toLowerCase() === "active"
                    ? "Active"
                    : String(saved.status || payload.status).toLowerCase() === "archived"
                        ? "Archived"
                        : "Draft",
            modules: Array.isArray(saved.moduleCodes)
                ? saved.moduleCodes.map((code) => String(code).trim()).filter(Boolean)
                : modulePayload.map((module) => String(module.code)),
            version: Number(saved.version || 1),
            updatedAt: saved.updatedAt ?? null,
        });

        setSavedFlash(true);
        window.setTimeout(() => {
            navigate("/survey_report");
        }, 700);
    } catch (error: any) {
        if (error?.name === "CanceledError" || error?.code === "ERR_CANCELED") {
            return;
        }

        const recovery = {
            ...payload,
            recoverySavedAt: new Date().toISOString(),
        };

        try {
            localStorage.setItem(
                `survey_template_recovery_${String(existingId ?? "new")}`,
                JSON.stringify(recovery),
            );
        } catch {
            // Recovery storage is best-effort and must not mask the API error.
        }

        const message = getApiErrorMessage(
            error,
            "Unable to save the survey template. Your local recovery copy has been preserved."
        );
        setTemplateError(message);
        window.alert(message);
    } finally {
        setTemplateSaving(false);
    }
};
const handleFieldChange = (
    fieldId: string,
    value: string | number
) => {
    setFormValues((prev) => ({
        ...prev,
        [fieldId]: value,
    }));
};

const navigate = useNavigate();
return (
 <div className="min-h-screen w-full bg-slate-50 font-['IBM_Plex_Sans',sans-serif] text-slate-900">
    <div className="p-3 sm:p-4 md:p-3">
        <div className="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-3">
                <button
                    type="button"
                    onClick={() => navigate("/survey_report")}
                    className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900"
                    aria-label="Back to survey templates"
                    title="Back to survey templates"
                >
                    <ArrowLeft size={18} weight="bold" />
                </button>

                <div className="min-w-0">
                    <h1 className="text-2xl font-bold text-slate-900">
                        Create Survey Template
                    </h1>
                    <p className="mt-1 max-w-3xl text-sm leading-relaxed text-slate-500">
                        Configure your survey template and vendor categories
                    </p>
                    {(templateLoading || templateError) && (
                        <p
                            className={`mt-2 text-xs ${
                                templateError ? "text-amber-600" : "text-slate-400"
                            }`}
                            role={templateError ? "alert" : undefined}
                        >
                            {templateLoading ? "Loading survey template..." : templateError}
                        </p>
                    )}
                </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <div className="text-xs text-slate-500 sm:text-right">
                    {canvas.length} modules selected · {totalFields} fields assembled
                </div>

                <div className="flex items-center gap-2">
                    <button
                        type="button"
                        onClick={() => void handleSaveTemplate("draft")}
                        disabled={templateSaving || templateLoading}
                        className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        <FloppyDisk size={15} />
                        Save as Draft
                    </button>

                    <button
                        type="button"
                        onClick={() => void handleSaveTemplate()}
                        disabled={templateSaving || templateLoading}
                        className="inline-flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        <FloppyDisk size={15} />
                        {templateSaving ? "Saving..." : savedFlash ? "Template saved" : "Save template"}
                    </button>
                </div>
            </div>
        </div>

        <div className="mb-5 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-5">
                <h2 className="text-sm font-semibold text-slate-900">
                    Template Details
                </h2>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">
                    Enter the basic information for this survey template.
                </p>
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                <div className="lg:col-span-4">
                    <label
                        htmlFor="survey-template-name"
                        className="mb-1.5 block text-xs font-medium text-slate-700"
                    >
                        Template Name
                    </label>
                    <input
                        id="survey-template-name"
                        type="text"
                        value={templateName}
                        onChange={(event) => {
                            setTemplateName(event.target.value);
                            if (templateError) setTemplateError("");
                        }}
                        maxLength={255}
                        placeholder="e.g. FTTH Standard Survey"
                        autoComplete="off"
                        disabled={templateSaving || templateLoading}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                    />
                </div>

                <div className="lg:col-span-4">
                    <label
                        htmlFor="survey-template-description"
                        className="mb-1.5 block text-xs font-medium text-slate-700"
                    >
                        Description
                    </label>
                    <input
                        id="survey-template-description"
                        type="text"
                        value={templateDescription}
                        onChange={(event) => {
                            setTemplateDescription(event.target.value);
                            if (templateError) setTemplateError("");
                        }}
                        maxLength={2000}
                        placeholder="e.g. Standard survey configuration for urban FTTH deployment"
                        disabled={templateSaving || templateLoading}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                    />
                </div>

                <div className="lg:col-span-4">
                    <label
                        htmlFor="survey-vendor-category"
                        className="mb-1.5 block text-xs font-medium text-slate-700"
                    >
                        Vendor Category
                    </label>
                    <Select
                        inputId="survey-vendor-category"
                        options={vendorCategoryOptions}
                        value={selectedVendorCategoryOption}
                        onChange={(option) => {
                            setVendorCategory(option?.value ?? "");
                            if (templateError) setTemplateError("");
                        }}
                        placeholder="Select Vendors"
                        isClearable
                        isSearchable={false}
                        isDisabled={templateSaving || templateLoading || vendorCategoriesLoading}
                        styles={vendorCategoryStyles}
                    />
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
            <aside className="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white lg:col-span-3">
                <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-4 py-4">
                    <div className="min-w-0">
                        <h2 className="text-sm font-semibold text-slate-900">
                            Module Library
                        </h2>

                        <p className="mt-1 text-xs leading-relaxed text-slate-500">
                            Select modules to add them to the assembled survey
                            template.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() => { setEditingModule(null); setAddModuleOpen(true); }}
                        title="Add Module"
                        aria-label="Add Module"
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-600 text-white transition hover:bg-red-700"
                    >
                        <Plus size={16} weight="bold" />
                    </button>
                </div>


                <div className="space-y-2 p-3">
                    {modules.map((module) => {
                        const Icon = module.icon;
                        const active = inCanvas(module.id);

                        return (
                            <button
                                key={module.id}
                                type="button"
                                onClick={() => toggleModule(module.id)}
                                className={`w-full rounded-lg border p-3 text-left transition-colors ${
                                    active
                                        ? "border-amber-300 bg-amber-50"
                                        : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                                }`}
                            >
                                <div className="flex items-start gap-2.5">
                                    <div
                                        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${ZONE_COLOR[module.zone]}`}
                                    >
                                        <Icon size={15} />
                                    </div> 

                                    <div className="min-w-0 flex-1">
                                        <div className="flex flex-wrap items-center gap-2">
                                            <span className="font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                                {module.code}
                                            </span>

                                            {module.repeatable && (
                                                <span className="inline-flex items-center gap-1 text-[10px] text-slate-400">
                                                    <ArrowsClockwise size={10} />
                                                    repeatable
                                                </span>
                                            )}
                                        </div>

                                        <div className="mt-0.5 text-[13px] font-medium leading-snug text-slate-900">
                                            {module.name}
                                        </div>

                                        <div className="mt-1 text-[11px] text-slate-500">
                                            {module.fields} fields
                                            {module.hasConditional &&
                                                " · conditional logic"}
                                        </div>
                                    </div>

                                    <div
                                        className={`mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                                            active
                                                ? "border-amber-500 text-amber-600"
                                                : "border-slate-300"
                                        }`}
                                    >
                                        {active && <Check size={11} />}
                                    </div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </aside>

            <main className="min-w-0 overflow-hidden rounded-lg border border-slate-200 bg-white lg:col-span-9">
               <div className="border-b border-slate-200 px-4 py-4">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 className="text-sm font-semibold text-slate-900">
                Assembled Template
            </h2>

            <p className="mt-1 text-xs leading-relaxed text-slate-500">
                Configure the selected modules and their repeat counts.
            </p>
        </div>

        <button
            type="button"
            onClick={handleSelectAllFields}
            className="w-fit rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
        >
            {selectedFields.length === getAllFieldIds().length &&
            getAllFieldIds().length > 0
                ? "Deselect All"
                : "Select All"}
        </button>
    </div>
</div>


                <div className="space-y-3 p-4 sm:p-5">
                    {canvas.length === 0 && (
                        <div className="rounded-lg border border-dashed border-slate-300 py-12 text-center text-sm text-slate-500">
                            No modules selected.
                        </div>
                    )}

                    {canvas.map((item, index) => {
                        const module = modules.find(
                            (mod) => mod.id === item.moduleId
                        );

                        if (!module) return null;

                        const Icon = module.icon;
                        const isOpen = expanded === module.id;

                        return (
                            <div
                                key={module.id}
                                className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm"
                            >
                                <button
                                    type="button"
                                    onClick={() =>
                                        setExpanded(
                                            isOpen ? null : module.id
                                        )
                                    }
                                    className={`flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left transition-colors hover:bg-slate-50 ${
                                        isOpen
                                            ? "border-b border-slate-200"
                                            : ""
                                    }`}
                                >
                                   <div className="flex min-w-0 items-center gap-3">
                                        <span className="w-5 shrink-0 text-center font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                            {String(index + 1).padStart(2, "0")}
                                        </span>
                                        <div
                                            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border ${ZONE_COLOR[module.zone]}`}
                                        >
                                            <Icon size={15} />
                                        </div>

                                        <div className="min-w-0 flex-1">
                                            <div className="truncate text-sm font-medium text-slate-900">
                                                {module.name}
                                            </div>

                                            <div className="mt-0.5 font-['IBM_Plex_Mono',monospace] text-[10px] text-slate-400">
                                                {module.code}

                                                {module.repeatable &&
                                                    ` · ${item.repeatCount}× ${module.unitLabel}`}
                                            </div>
                                        </div>
                                    </div>
                                    

                                    {isOpen ? (
                                        <CaretDown
                                            size={16}
                                            className="shrink-0 text-slate-400"
                                        />
                                    ) : (
                                        <CaretRight
                                            size={16}
                                            className="shrink-0 text-slate-400"
                                        />
                                    )}
                                </button>

                               {isOpen && (
                                    
                            <div className="space-y-5 px-4 pb-4 pt-4">
                                {module.sections?.map((section) => {
                                    const sectionFieldIds =
                                        section.fieldGroups?.flatMap(
                                            (group) =>
                                                group.fields?.map((field) => field.id) ?? []
                                        ) ?? [];

                                    const allSectionFieldsSelected =
                                        sectionFieldIds.length > 0 &&
                                        sectionFieldIds.every((id) =>
                                            selectedFields.includes(id)
                                        );

                                    const handleSectionSelect = () => {
                                        setSelectedFields((prev) => {
                                            if (allSectionFieldsSelected) {
                                                return prev.filter(
                                                    (id) => !sectionFieldIds.includes(id)
                                                );
                                            }

                                            return Array.from(
                                                new Set([...prev, ...sectionFieldIds])
                                            );
                                        });
                                    };

                                    return (
                                        <div key={section.id}>
                                            <div className="mb-3 flex flex-wrap items-center gap-2">
                                                <input
                                                    type="checkbox"
                                                    checked={allSectionFieldsSelected}
                                                    onChange={handleSectionSelect}
                                                    className="h-4 w-4 shrink-0 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                                />

                                                <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                                                    {section.title}
                                                </h3>

                                                
                                            </div>

                                            <div className="space-y-4">
                                                {section.fieldGroups?.map((group) => (
                                                    <div
                                                        key={group.id}
                                                        className="rounded-lg border border-slate-200 p-4"
                                                    >
                                                        <div className="mb-4 text-sm font-medium text-slate-900">
                                                            {group.title}
                                                        </div>

                                                        <div className="space-y-4">
                                                            {group.fields?.map((field) => (
                                                                <div
                                                                    key={field.id}
                                                                    className="flex items-start gap-3"
                                                                >
                                                                    <input
                                                                        type="checkbox"
                                                                        checked={selectedFields.includes(
                                                                            field.id
                                                                        )}
                                                                        onChange={(event) => {
                                                                            setSelectedFields(
                                                                                (prev) =>
                                                                                    event.target
                                                                                        .checked
                                                                                        ? [
                                                                                            ...prev,
                                                                                            field.id,
                                                                                        ]
                                                                                        : prev.filter(
                                                                                            (
                                                                                                id
                                                                                            ) =>
                                                                                                id !==
                                                                                                field.id
                                                                                        )
                                                                            );
                                                                        }}
                                                                        className="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 text-red-600 focus:ring-red-500"
                                                                    />

                                                                    <div className="min-w-0 flex-1">
                                                                        <label className="mb-2 block text-xs font-medium text-slate-700">
                                                                            {field.label}

                                                                            {field.required && (
                                                                                <span className="ml-1 text-red-500">
                                                                                    *
                                                                                </span>
                                                                            )}
                                                                        </label>

                                                                        <FieldRenderer
                                                                            field={field}
                                                                            value={
                                                                                formValues[
                                                                                    field.id
                                                                                ]
                                                                            }
                                                                            onChange={
                                                                                handleFieldChange
                                                                            }
                                                                        />
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>


                                )}

                            </div>
                        );
                    })}
                </div>
            </main>

        </div>
    </div>
<AddModule
    open={addModuleOpen}
    onClose={() => {
        setAddModuleOpen(false);
        setEditingModule(null);
    }}
    onCreate={handleCreateModule}
    onUpdate={handleUpdateModule}
    editingModule={editingModule}
    templateName=""
    modules={modules}
/>
</div>
);
}