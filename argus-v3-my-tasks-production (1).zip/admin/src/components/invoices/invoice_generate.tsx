import {
    ArrowLeftIcon,
    CheckCircleIcon,
    CheckIcon,
    FileTextIcon,
    PencilSimpleIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import DataTable, { DataTableColumn } from "../DataTable";
import { BOQRow } from "../quotations/NewQuotation";
import Select from "react-select";
import { getQuotation } from "../../api/quotationApi";
import { createInvoice, submitInvoice, uploadInvoiceDocument } from "../../api/invoiceApi";

// ============================================================
// TYPES
// ============================================================
interface ApprovedQuotation {
    id: string;
    quotationNo: string;
    projectTitle: string;
    vendor: string;
    contractValue: number;
    currency: string;
    status: string;
}

interface InvoiceGenerateLocationState {
    quotation?: ApprovedQuotation;
}

interface MilestoneOption {
    value: string;
    label: string;
    percentage: number;
}

interface Installment {
    id: number;
    name: string;
    amount: number;
    date: string;
}

type ModuleItem = {
    id: number;
    name: string;
    rate: number;
};

type InstallmentData = {
    id: number;
    name: string;
    days: number;
    netTotalAmount: number;
    moduleItems: ModuleItem[];
};

// ============================================================
// COMPONENT
// ============================================================
const InvoiceGenerate = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const state = location.state as InvoiceGenerateLocationState | null;
    const queryQuotationId = new URLSearchParams(location.search).get("quotationId");
    const requestedQuotationId = state?.quotation?.id || queryQuotationId;
    const [quotationDetails, setQuotationDetails] = useState<any | null>(null);
    const [loadingQuotation, setLoadingQuotation] = useState(true);
    const [loadError, setLoadError] = useState("");
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        let cancelled = false;
        const load = async () => {
            if (!requestedQuotationId) { setLoadingQuotation(false); return; }
            setLoadingQuotation(true); setLoadError("");
            try {
                const data = await getQuotation(requestedQuotationId);
                if (!cancelled) setQuotationDetails(data);
            } catch (e: any) {
                if (!cancelled) setLoadError(e?.message || "Unable to load the selected quotation.");
            } finally { if (!cancelled) setLoadingQuotation(false); }
        };
        void load();
        return () => { cancelled = true; };
    }, [requestedQuotationId]);

    const quotation = quotationDetails || state?.quotation || null;
    const currencyOptions = Array.from(new Set([quotationDetails?.currency, "JMD", "USD"].filter(Boolean))).map((value) => ({ value, label: value }));

    // ----- Invoice Config State -----
    const [invoiceNumber] = useState("Generated on save");
    const [currency, setCurrency] = useState("JMD");
    const [dueDate, setDueDate] = useState(() => new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
    const [siteReference, setSiteReference] = useState("");
    const [tax, setTax] = useState(0);
    const [invoiceDocument, setInvoiceDocument] = useState<File | null>(null);

    // ----- Milestone / Modules -----
    const [selectedMilestone, setSelectedMilestone] = useState("");
    const [selectedModules, setSelectedModules] = useState<string[]>([]);
    const [billPercentage, setBillPercentage] = useState(100);

    // ----- Installment Selection State -----
    const [selectedInstallments, setSelectedInstallments] = useState<number[]>([]);
    const [remarks, setRemarks] = useState("");

    // Existing payment editor UI is kept intact, but starts empty because payment history is server-owned.
    const [installments, setInstallments] = useState<Installment[]>([]);
    const totalPaid = installments.reduce((sum, installment) => sum + installment.amount, 0);

    // Dynamic quotation-derived data. The old module-level seed constants remain only for backwards compatibility; these values are authoritative.
    const boqRows = useMemo<BOQRow[]>(() => (quotationDetails?.lines || []).map((line: any, index: number) => ({
        id: index + 1,
        section: index + 1,
        module: line.module || line.category || "General",
        category: line.category || "General",
        description: line.description,
        quantity: Number(line.quantity || 0),
        uom: line.unit || "Unit",
        materialCost: Number(line.materialCost || 0),
        serviceCost: Number(line.serviceCost || 0),
        salesPrice: Number(line.quotedRate || 0),
        gct: Number(line.taxRate || 0),
        totalInstallments: 0, pendingInstallments: 0, invoicesGenerated: 0, invoicesPaid: 0, balanceAmount: 0,
    })), [quotationDetails]);

    const INSTALLMENTS = useMemo<InstallmentData[]>(() => (quotationDetails?.paymentSchedule?.installments || []).map((item: any, index: number) => ({
        id: index + 1,
        name: item.installmentName || `Installment ${index + 1}`,
        days: Array.isArray(item.days) ? Number(item.days[0] || 0) : Number(item.days || 0),
        netTotalAmount: Number(item.amount || 0),
        moduleItems: (Array.isArray(item.modules) ? item.modules : []).map((name: string, moduleIndex: number) => ({
            id: index * 100 + moduleIndex + 1, name, rate: boqRows.filter((row) => row.module === name).reduce((sum, row) => sum + row.quantity * row.salesPrice, 0),
        })),
    })), [quotationDetails, boqRows]);

    const milestoneOptions = useMemo<MilestoneOption[]>(() => INSTALLMENTS.map((item) => ({ value: String(item.id), label: item.name, percentage: 100 })), [INSTALLMENTS]);
    const moduleOptions = useMemo(() => Array.from(new Set(boqRows.map((row) => row.module))).filter(Boolean).map((value) => ({ value, label: value })), [boqRows]);
    const verificationTasks = useMemo(() => boqRows.map((row, index) => ({ id: index + 1, name: row.description, description: row.category, estimatedHours: 0, status: "Pending", progress: 0, priority: "Medium" })), [boqRows]);

    useEffect(() => {
        if (!quotationDetails) return;
        setCurrency(quotationDetails.currency || "JMD");
        setSiteReference(quotationDetails.projectLocation || "");
        const total = Number(quotationDetails.subtotal || quotationDetails.grandTotal || 0);
        const taxTotal = Number(quotationDetails.taxTotal || 0);
        setTax(total > 0 ? Number(((taxTotal / total) * 100).toFixed(2)) : 0);
        const today = new Date(); const todayText = today.toISOString().slice(0, 10);
        const validUntil = (quotationDetails.validUntil || "").slice(0, 10);
        setDueDate(validUntil && validUntil >= todayText ? validUntil : new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
    }, [quotationDetails]);

    useEffect(() => {
        if (!INSTALLMENTS.length) { setSelectedInstallments([]); setSelectedMilestone(""); setSelectedModules([]); return; }
        setSelectedInstallments((prev) => prev.length ? prev.filter((id) => INSTALLMENTS.some((item) => item.id === id)) : [INSTALLMENTS[0].id]);
        setSelectedMilestone((prev) => prev || String(INSTALLMENTS[0].id));
        setSelectedModules((prev) => prev.length ? prev : (INSTALLMENTS[0].moduleItems.map((item) => item.name)));
    }, [INSTALLMENTS]);

    const netTotalAmount = Number(quotationDetails?.grandTotal ?? state?.quotation?.contractValue ?? 0);
    const calculatedInvoiceAmount = INSTALLMENTS.filter((installment) => selectedInstallments.includes(installment.id)).reduce((total, installment) => total + installment.netTotalAmount, 0) * (billPercentage / 100);
    const [invoiceAmount, setInvoiceAmount] = useState<number>(0);
    useEffect(() => { setInvoiceAmount(Number(calculatedInvoiceAmount.toFixed(2))); }, [calculatedInvoiceAmount]);
    const remainingAmount = Math.max(0, netTotalAmount - totalPaid);

    // ----- Add Installment (legacy modal) -----
    const [isAddingInstallment, setIsAddingInstallment] = useState(false);
    const [newInstallment, setNewInstallment] = useState({
        name: "",
        amount: "",
        date: "",
    });

    const [isEditingPayment, setIsEditingPayment] = useState(false);
    const [currentPayment, setCurrentPayment] = useState("42500");
    const [currentPaymentDate, setCurrentPaymentDate] = useState("");

    // ============================================================
    // MEMOS
    // ============================================================
    const selectedModuleRows = useMemo(() => {
        return boqRows.filter((row) => selectedModules.includes(row.module));
    }, [selectedModules]);

    const selectedMilestoneData = useMemo(() => milestoneOptions.find((milestone) => milestone.value === selectedMilestone), [milestoneOptions, selectedMilestone]);

    const contractValue = quotation?.contractValue ?? 0;

    const totalValueToGenerate = invoiceAmount;

    const moduleTotal = useMemo(() => {
        return selectedModuleRows.reduce(
            (total, row) => total + row.quantity * row.salesPrice,
            0
        );
    }, [selectedModuleRows]);

    // ============================================================
    // HELPERS
    // ============================================================
    const formatCurrency = (value: number) =>
        value.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });

    const handleDocumentUpload = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        if (file) setInvoiceDocument(file);
    };

    const handleCancel = () => {
        navigate("/invoices", {
            state: { activeTab: "approvedQuotes" },
        });
    };

    // ----- Installment toggle -----
    const handleInstallmentChange = (installmentId: number) => {
        setSelectedInstallments((prev) => {
            if (prev.includes(installmentId)) {
                return prev.filter((id) => id !== installmentId);
            }

            return [...prev, installmentId];
        });
    };


    // ============================================================
    // SAVE / SUBMIT
    // ============================================================
    const buildInvoicePayload = () => ({
        quotationId: quotation?.id,
        currency,
        invoiceDate: new Date().toISOString(),
        dueDate,
        siteReference,
        milestoneName: selectedMilestoneData?.label || "",
        milestoneModules: selectedModuleRows.map((row) => ({ name: row.module, rate: Number(row.salesPrice || 0) })),
        selectedInstallmentIds: selectedInstallments.map(String),
        billPercentage,
        taxRate: tax,
        remarks,
    });

    const handleSaveDraft = async () => {
        if (!quotation?.id || saving) return;
        setSaving(true);
        try {
            const created = await createInvoice(buildInvoicePayload());
            if (invoiceDocument) await uploadInvoiceDocument(created.id, invoiceDocument);
            navigate("/invoices", { state: { invoiceCreated: true } });
        } catch (e: any) {
            setLoadError(e?.message || "Unable to save invoice draft.");
        } finally { setSaving(false); }
    };

    const handleSubmitInvoice = async () => {
        if (!quotation?.id || saving) return;
        setSaving(true);
        try {
            const created = await createInvoice(buildInvoicePayload());
            if (invoiceDocument) await uploadInvoiceDocument(created.id, invoiceDocument);
            await submitInvoice(created.id);
            navigate("/invoices", { state: { invoiceSubmitted: true } });
        } catch (e: any) {
            setLoadError(e?.message || "Unable to submit invoice.");
        } finally { setSaving(false); }
    };

    // ============================================================
    // EARLY RETURN: No Quotation
    // ============================================================
    if (loadingQuotation) {
        return <div className="flex min-h-[500px] items-center justify-center bg-slate-50"><p className="text-sm font-semibold text-slate-500">Loading quotation...</p></div>;
    }
    if (loadError && !quotation) {
        return <div className="flex min-h-[500px] items-center justify-center bg-slate-50"><div className="text-center"><p className="text-sm font-semibold text-red-600">{loadError}</p><button type="button" onClick={handleCancel} className="mt-3 text-xs font-semibold text-slate-500 hover:text-red-600">Back to Invoice List</button></div></div>;
    }
    if (!quotation) {
        return (
            <div className="flex min-h-[500px] items-center justify-center bg-slate-50">
                <div className="text-center">
                    <p className="text-sm font-semibold text-slate-700">
                        No quotation selected.
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                        Please select an approved quotation before generating an
                        invoice.
                    </p>
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition-colors hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>
                </div>
            </div>
        );
    }

    // ============================================================
    // DATATABLE COLUMNS
    // ============================================================




    const installmentColumns: DataTableColumn<Installment>[] = [
        {
            key: "name",
            label: "Installment",
            width: "40%",
            sortable: true,
            render: (installment) => (
                <div>
                    <p className="text-xs font-bold text-slate-800">
                        {installment.name}
                    </p>
                    <p className="mt-0.5 text-[9px] text-slate-400">
                        Installment {installment.id}
                    </p>
                </div>
            ),
        },
        {
            key: "amount",
            label: "Amount",
            width: "25%",
            sortable: true,
            render: (installment) => (
                <span className="text-xs font-bold text-slate-700">
                    $
                    {installment.amount.toLocaleString("en-US", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                    })}
                </span>
            ),
        },
        {
            key: "date",
            label: "Payment Date",
            width: "35%",
            sortable: true,
            render: (installment) => (
                <span className="text-xs font-medium text-slate-600">
                    {new Date(installment.date).toLocaleDateString("en-US", {
                        month: "short",
                        day: "2-digit",
                        year: "numeric",
                    })}
                </span>
            ),
        },
    ];

    // ============================================================
    // RENDER
    // ============================================================
    return (
        <div className="min-h-screen bg-slate-50">
            <div className="mx-auto px-2 py-3">
                {/* ================= HEADER ================= */}
                <div className="mb-6">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>

                    <h1 className="text-xl font-bold text-slate-900">
                        Invoice Configuration
                    </h1>

                    {loadError && <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">{loadError}</div>}

                    <p className="mt-1 text-xs text-slate-500">
                        Generating invoice for{" "}
                        <span className="font-semibold text-slate-700">
                            {quotation.projectTitle}
                        </span>{" "}
                        ({quotation.quotationNo})
                    </p>
                </div>

                {/* ================= INVOICE CONFIG ================= */}
                <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    {/* Header */}
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Invoice Configuration
                        </h2>
                    </div>

                    {/* Form */}
                    <div className="grid grid-cols-1 gap-x-5 gap-y-5 p-6 md:grid-cols-3">

                        {/* Invoice Number */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Number
                            </label>

                            <input
                                type="text"
                                value={invoiceNumber}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Vendor */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Vendor
                            </label>

                            <input
                                type="text"
                                value={quotation.vendorName || quotation.vendor || ""}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Currency */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Currency
                            </label>

                            <Select
                                value={
                                    currencyOptions.find(
                                        (option) => option.value === currency
                                    ) ?? null
                                }
                                onChange={(option) =>
                                    setCurrency(option?.value ?? "JMD")
                                }
                                options={currencyOptions}
                                isSearchable={false}
                                className="text-sm"
                                classNamePrefix="currency-select"
                                styles={{
                                    control: (base, state) => ({
                                        ...base,
                                        minHeight: "42px",
                                        height: "42px",
                                        borderRadius: "8px",
                                        borderColor: state.isFocused
                                            ? "#fca5a5"
                                            : "#e2e8f0",
                                        backgroundColor: state.isFocused
                                            ? "#ffffff"
                                            : "#f8fafc",
                                        boxShadow: "none",
                                        "&:hover": {
                                            borderColor: "#fca5a5",
                                        },
                                    }),
                                    valueContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                        padding: "0 12px",
                                    }),
                                    indicatorsContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                    }),
                                    singleValue: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                    }),
                                    placeholder: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#94a3b8",
                                    }),
                                    option: (base, state) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                        backgroundColor: state.isSelected
                                            ? "#fee2e2"
                                            : state.isFocused
                                                ? "#fef2f2"
                                                : "#ffffff",
                                        cursor: "pointer",
                                    }),
                                    menu: (base) => ({
                                        ...base,
                                        zIndex: 50,
                                    }),
                                }}
                            />
                        </div>

                        {/* Due Date */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Due Date
                            </label>

                            <input
                                type="date"
                                value={dueDate}
                                onChange={(event) =>
                                    setDueDate(event.target.value)
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Site Reference */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Site Reference
                            </label>

                            <input
                                type="text"
                                value={siteReference}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>


                        {/* Invoice Amount */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Amount
                            </label>

                            <div className="relative">
                                <span className="absolute left-3 top-1/2 z-10 -translate-y-1/2 text-xs font-semibold text-slate-400">
                                    {currency}
                                </span>

                                <input
                                    type="number"
                                    value={invoiceAmount}
                                    readOnly
                                    placeholder="Calculated from selected installments"
                                    className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-12 pr-3 text-sm font-semibold text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                />
                            </div>
                        </div>

                        {/* Tax */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Tax (%)
                            </label>

                            <input
                                type="number"
                                min={0}
                                max={100}
                                value={tax}
                                onChange={(event) =>
                                    setTax(Number(event.target.value))
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Supporting Document */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Supporting Document
                            </label>

                            <input
                                type="file"
                                onChange={handleDocumentUpload}
                                className="block h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-red-50 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-red-600"
                            />

                            {invoiceDocument && (
                                <p className="mt-2 text-[10px] font-medium text-emerald-600">
                                    Selected: {invoiceDocument.name}
                                </p>
                            )}
                        </div>

                        {/* Remarks */}
                        <div className="min-w-0">
                            <label
                                htmlFor="remarks"
                                className="mb-1.5 block text-xs font-semibold text-slate-700"
                            >
                                Remarks
                            </label>

                            <textarea
                                id="remarks"
                                rows={3}
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                                placeholder="Enter remarks..."
                                className="w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 outline-none transition focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>


                    </div>
                </section>


                {/* ================= MILESTONE ALLOCATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Overall Milestone Allocation
                        </h2>
                        <p className="mt-1 text-xs text-slate-500">
                            Select the project phase, module, and percentage of
                            the approved contract value to invoice.
                        </p>
                    </div>



                    {/* ============================================================
                        INSTALLMENT ITEMS
                    ============================================================ */}
                    <div className="border-t border-slate-200">
                        <div className="border-b border-slate-100 px-6 py-4">
                            <h2 className="text-sm font-bold text-slate-800">
                                Installment Items
                            </h2>
                            <p className="mt-1 text-xs text-slate-500">
                                The first installment has already been paid.
                                Select an installment to view its details.
                            </p>
                        </div>

                        <div className="p-6">
                            {/* Installment List Table */}
                            <div className="overflow-hidden rounded-lg border border-slate-200">
                                {/* Header */}
                                <div className="grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 bg-slate-50 px-4 py-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                    <div></div>
                                    <div>Installment Name</div>
                                    <div>Days</div>
                                    <div>Total Amount</div>
                                    <div>Action</div>
                                    <div>Module Items</div>
                                </div>

                                {/* Rows */}
                                {INSTALLMENTS.map((installment, index) => {
                                    const isFirstInstallment = index === 0;
                                    const isChecked =
                                        isFirstInstallment ||
                                        selectedInstallments.includes(
                                            installment.id
                                        );

                                    return (
                                        <div
                                            key={installment.id}
                                            className={`grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 border-t border-slate-100 px-4 py-4 transition-colors ${isChecked
                                                ? "bg-primary/5"
                                                : "bg-white hover:bg-slate-50"
                                                }`}
                                        >
                                            {/* Checkbox */}
                                            <div>
                                                <input
                                                    type="checkbox"
                                                    checked={isChecked}
                                                    disabled={isFirstInstallment}
                                                    onChange={() => {
                                                        if (
                                                            !isFirstInstallment
                                                        ) {
                                                            handleInstallmentChange(
                                                                installment.id
                                                            );
                                                        }
                                                    }}
                                                    className={`h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary ${isFirstInstallment
                                                        ? "cursor-not-allowed opacity-60"
                                                        : "cursor-pointer"
                                                        }`}
                                                />
                                            </div>

                                            {/* Name */}
                                            <div>
                                                <p className="text-sm font-semibold text-slate-800">
                                                    {installment.name}
                                                </p>
                                                {isFirstInstallment && (
                                                    <span className="mt-1 inline-flex rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-semibold text-green-700">
                                                        Mandatory
                                                    </span>
                                                )}
                                            </div>

                                            {/* Days */}
                                            <div className="text-sm text-slate-600">
                                                {installment.days} Days
                                            </div>

                                            {/* Net Total */}
                                            <div className="text-sm font-bold text-red-600">
                                                USD{" "}
                                                {formatCurrency(
                                                    installment.netTotalAmount
                                                )}
                                            </div>

                                            {/* Action */}
                                            <div>
                                                {isFirstInstallment ? (
                                                    <span className="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                                                        Selected
                                                    </span>
                                                ) : (
                                                    <span
                                                        className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${isChecked
                                                            ? "bg-primary/10 text-primary"
                                                            : "bg-slate-100 text-slate-500"
                                                            }`}
                                                    >
                                                        {isChecked
                                                            ? "Selected"
                                                            : "Pending"}
                                                    </span>
                                                )}
                                            </div>

                                            {/* Module Items */}
                                            <div className="flex flex-wrap gap-2">
                                                {installment.moduleItems.map(
                                                    (item) => (
                                                        <span
                                                            key={item.id}
                                                            className="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600"
                                                        >
                                                            {item.name}
                                                        </span>
                                                    )
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {/* ============================================================
                                SELECTED INSTALLMENTS (SEPARATE)
                            ============================================================ */}
                            {selectedInstallments.length > 0 && (
                                <div className="mt-6">
                                    <div className="mb-4">
                                        <h3 className="text-sm font-bold text-slate-800">
                                            Selected Installments
                                        </h3>
                                        <p className="mt-1 text-xs text-slate-500">
                                            Details of the selected installments
                                            are displayed separately below.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        {INSTALLMENTS.filter((installment) =>
                                            selectedInstallments.includes(
                                                installment.id
                                            )
                                        ).map((installment) => (
                                            <div
                                                key={installment.id}
                                                className="overflow-hidden rounded-lg border border-slate-200 bg-white"
                                            >
                                                {/* Header */}
                                                <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-5 py-4">
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <h4 className="text-sm font-bold text-slate-800">
                                                                {
                                                                    installment.name
                                                                }
                                                            </h4>
                                                            <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-primary">
                                                                Selected
                                                            </span>
                                                        </div>
                                                        <p className="mt-1 text-xs text-slate-500">
                                                            {installment.days}{" "}
                                                            Days
                                                        </p>
                                                    </div>

                                                    <div className="text-right">
                                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                                            Total
                                                        </p>
                                                        <p className="text-sm font-bold text-red-600">
                                                            USD{" "}
                                                            {formatCurrency(
                                                                installment.netTotalAmount
                                                            )}
                                                        </p>
                                                    </div>
                                                </div>

                                                {/* Module Items */}
                                                <div className="p-5">
                                                    <h5 className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                                        Module Items
                                                    </h5>

                                                    <div className="overflow-hidden rounded-lg border border-slate-200">
                                                        {installment.moduleItems.map(
                                                            (item) => (
                                                                <div
                                                                    key={item.id}
                                                                    className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-b-0"
                                                                >
                                                                    <div>
                                                                        <p className="text-sm font-medium text-slate-700">
                                                                            {
                                                                                item.name
                                                                            }
                                                                        </p>
                                                                        <p className="mt-0.5 text-xs text-slate-400">
                                                                            Module
                                                                            Item
                                                                        </p>
                                                                    </div>
                                                                    <div className="text-sm font-bold text-slate-700">
                                                                        USD{" "}
                                                                        {formatCurrency(
                                                                            item.rate
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            )
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                {/* ================= TASKS VERIFICATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
                        <div>
                            <h2 className="text-sm font-bold text-slate-800">
                                Tasks Verification
                            </h2>
                            <p className="mt-0.5 text-[11px] text-slate-500">
                                Review task progress and completion status.
                            </p>
                        </div>
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-bold text-emerald-700">
                            <CheckCircleIcon size={11} weight="fill" />
                            Verified
                        </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        {verificationTasks.map((task) => {
                            const isCompleted = task.status === "Completed";

                            return (
                                <div
                                    key={task.id}
                                    className="flex items-center gap-3 px-5 py-3 transition hover:bg-slate-50"
                                >
                                    {/* Status Icon */}
                                    <div
                                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${isCompleted
                                            ? "bg-emerald-500 text-white"
                                            : "border border-slate-300 bg-white"
                                            }`}
                                    >
                                        {isCompleted && (
                                            <CheckIcon size={12} weight="bold" />
                                        )}
                                    </div>

                                    {/* Info */}
                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                            <h3
                                                className={`truncate text-xs font-semibold ${isCompleted
                                                    ? "text-slate-400 line-through"
                                                    : "text-slate-700"
                                                    }`}
                                            >
                                                {task.name}
                                            </h3>
                                            <span
                                                className={`shrink-0 rounded px-1.5 py-0.5 text-[8px] font-bold ${task.priority === "Urgent"
                                                    ? "bg-red-50 text-red-600"
                                                    : task.priority === "High"
                                                        ? "bg-orange-50 text-orange-600"
                                                        : task.priority ===
                                                            "Medium"
                                                            ? "bg-amber-50 text-amber-600"
                                                            : "bg-slate-100 text-slate-500"
                                                    }`}
                                            >
                                                {task.priority}
                                            </span>
                                        </div>

                                        {/* Progress Bar */}
                                        <div className="mt-1.5 flex items-center gap-2">
                                            <div className="h-1 flex-1 overflow-hidden rounded-full bg-slate-100">
                                                <div
                                                    className={`h-full rounded-full ${isCompleted
                                                        ? "bg-emerald-500"
                                                        : task.status ===
                                                            "In Progress"
                                                            ? "bg-blue-500"
                                                            : task.status ===
                                                                "On Hold"
                                                                ? "bg-amber-500"
                                                                : "bg-slate-300"
                                                        }`}
                                                    style={{
                                                        width: `${task.progress}%`,
                                                    }}
                                                />
                                            </div>
                                            <span className="w-7 text-right text-[9px] font-bold text-slate-500">
                                                {task.progress}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Status Badge */}
                                    <span
                                        className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-semibold ${task.status === "Completed"
                                            ? "bg-emerald-50 text-emerald-700"
                                            : task.status === "In Progress"
                                                ? "bg-blue-50 text-blue-700"
                                                : task.status === "On Hold"
                                                    ? "bg-amber-50 text-amber-700"
                                                    : task.status === "Due Date"
                                                        ? "bg-red-50 text-red-700"
                                                        : "bg-slate-100 text-slate-600"
                                            }`}
                                    >
                                        {task.status}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </section>



                {/* ================= ACTIONS ================= */}
                <div className="mt-6 flex flex-col-reverse gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-end">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="inline-flex h-10 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        onClick={handleSaveDraft} disabled={saving}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Save as Draft
                    </button>

                    <button
                        type="button"
                        onClick={handleSubmitInvoice} disabled={saving}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-600 px-5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Generate Invoice
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InvoiceGenerate;