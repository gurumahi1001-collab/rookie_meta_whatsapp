import { Outlet } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { listProjects, getProject, updateProject as apiUpdateProject, createProject as apiCreateProject, deleteProject as apiDeleteProject } from "../../api/projectApi";

export interface Project {
    id: string;
    reference?: string;
    projectName: string;
    location: string;
    description?: string;
    vendorName: string;
    vendorId?: string;
    currency?: string;
    managerName: string;
    managerEmail: string;
    startDate: string;
    endDate: string;
    projectValue: number;
    budget: number;
    surveyRef: string;
    version: string;
    versionDate?: string;
    status:
    | "Planned"
    | "In Progress"
    | "On Hold"
    | "Completed"
    | "Closed";
    progress: number;
}

export interface Deliverable {
    id: string;
    projectId: string;
    name: string;
    dueDate: string;
    completed: boolean;
}
export interface ActivityLog {
    id: string;
    projectId: string;
    entity: "DELIVERABLE";
    entityId: string;
    action: "ADD" | "MODIFY" | "DELETE";
    description: string;
    createdAt: string;
}
export const PROJECT_DATA: Project[] = [
    {
        id: "PRJ-001",
        projectName: "Al Noor Commercial Tower",
        location: "Dubai, UAE",
        vendorName: "Seiretsu JA Ltd",
        managerName: "Sarah Johnson",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 485000,
        budget: 520000,
        status: "Planned",
        progress: 75,
        surveyRef: "Seiretsu FTTx 5.31.26",
        version: "v1.0 — July 19, 2026"
    },
    {
        id: "PRJ-002",
        projectName: "Kingston Office Renovation",
        location: "Kingston, Jamaica",
        vendorName: "Flow Jamaica",
        managerName: "Michael Brown",
        managerEmail: "michael_brown@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 275000,
        budget: 300000,
        status: "In Progress",
        progress: 52,
        surveyRef: "Flow Jamaica FTTx 5.31.26",
        version: "v1.0 — July 25, 2026"
    },
    {
        id: "PRJ-003",
        projectName: "Metro Network Expansion",
        location: "Montego Bay, Jamaica",
        vendorName: "Digicel Metro Networks",
        managerName: "David Wilson",
        managerEmail: "david_wilson@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 350000,
        budget: 375000,
        status: "On Hold",
        progress: 35,
        surveyRef: "Digicel Metro FTTx 5.26.26",
        version: "v1.0 — July 29, 2026"
    },
    {
        id: "PRJ-004",
        projectName: "Regional Operations Center",
        location: "Miami, USA",
        vendorName: "Global Tech Solutions",
        managerName: "Emily Davis",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 620000,
        budget: 650000,
        status: "Completed",
        progress: 100,
        surveyRef: "Global Tech FTTx 3.26.26",
        version: "v1.0 — July 03, 2026"
    },
    {
        id: "PRJ-005",
        projectName: "Regional Operations Center",
        location: "Miami, USA",
        vendorName: "City Council - Kingston & St. Andrew Corporation",
        managerName: "Emily Davis",
        managerEmail: "sarah.j@projectflow.com",
        startDate: "18 Aug 2026",
        endDate: "30 Jun 2027",
        projectValue: 620000,
        budget: 650000,
        status: "Closed",
        progress: 100,
        surveyRef: "Digicel Metro FTTx 3.24.26",
        version: "v1.0 — July 19, 2026"
    },
];


export interface ProjectsContextType {
    projects: Project[];
    loading: boolean;
    error: string | null;
    refreshProjects: (params?: { search?: string; status?: Project["status"] }) => Promise<void>;
    loadProject: (projectId: string) => Promise<Project | null>;
    updateProject: (projectId: string, updates: Partial<Project> & Record<string, unknown>) => Promise<Project | null>;
    createProject: (payload: Record<string, unknown>) => Promise<Project | null>;
    deleteProject: (projectId: string) => Promise<void>;
    activityLogs: ActivityLog[];
    addActivityLog: (activity: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => Promise<void>;
}

function formatDate(value: string | Date | null | undefined) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return date.toLocaleDateString("en-US", { day: "2-digit", month: "short", year: "numeric" });
}

function toProjectStatus(value: unknown): Project["status"] {
    switch (String(value || "planned").toLowerCase()) {
        case "in_progress": return "In Progress";
        case "on_hold": return "On Hold";
        case "completed": return "Completed";
        case "closed": return "Closed";
        default: return "Planned";
    }
}

function toProject(value: any): Project {
    return {
        id: String(value?.id ?? ""),
        reference: value?.reference || "",
        projectName: value?.projectName || value?.name || "",
        location: value?.location || "",
        description: value?.description || "",
        vendorName: value?.vendorName || value?.vendor?.name || "",
        vendorId: value?.vendorId || value?.vendor?.vendorId || "",
        managerName: value?.managerName || value?.manager?.name || "",
        managerEmail: value?.managerEmail || value?.manager?.email || "",
        startDate: formatDate(value?.startDate),
        endDate: formatDate(value?.endDate),
        projectValue: Number(value?.projectValue || 0),
        budget: Number(value?.budget || 0),
        status: toProjectStatus(value?.status),
        progress: Number(value?.progress || 0),
        surveyRef: value?.surveyRef || "",
        version: value?.version || "",
        versionDate: formatDate(value?.versionDate),
    };
}

export default function Projects() {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

    const refreshProjects = useCallback(async (params: { search?: string; status?: Project["status"] } = {}) => {
        setLoading(true);
        setError(null);
        try {
            const response = await listProjects({ search: params.search, status: params.status ? ({ Planned: "planned", "In Progress": "in_progress", "On Hold": "on_hold", Completed: "completed", Closed: "closed" } as any)[params.status] : undefined, limit: 250 });
            setProjects(response.data.map(toProject));
        } catch (err: any) {
            setError(err?.message || "Unable to load projects.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { void refreshProjects(); }, [refreshProjects]);

    const loadProject = useCallback(async (projectId: string) => {
        try {
            const detail = await getProject(projectId);
            setProjects((current) => {
                const normalized = { ...toProject(detail), __detail: detail } as Project & { __detail: any };
                const exists = current.some((item) => item.id === normalized.id);
                return exists ? current.map((item) => item.id === normalized.id ? normalized : item) : [...current, normalized];
            });
            setActivityLogs((detail.activityLogs || []).map((item: any) => ({ ...item, id: String(item.id), projectId, createdAt: item.createdAt })));
            return detail as any;
        } catch (err: any) {
            setError(err?.message || "Unable to load the project.");
            return null;
        }
    }, []);

    const updateProject = useCallback(async (projectId: string, updates: Partial<Project> & Record<string, unknown>) => {
        setError(null);
        try {
            const payload: Record<string, unknown> = { ...updates };
            if ("status" in updates) payload.status = ({ Planned: "planned", "In Progress": "in_progress", "On Hold": "on_hold", Completed: "completed", Closed: "closed" } as any)[updates.status as string] || updates.status;
            const result = await apiUpdateProject(projectId, payload);
            setProjects((current) => current.map((item) => item.id === projectId ? toProject(result) : item));
            setActivityLogs((result.activityLogs || []).map((item: any) => ({ ...item, id: String(item.id), projectId, createdAt: item.createdAt })));
            return result as any;
        } catch (err: any) {
            setError(err?.message || "Unable to update the project.");
            return null;
        }
    }, []);

    const createProject = useCallback(async (payload: Record<string, unknown>) => {
        setError(null);
        try {
            const result = await apiCreateProject(payload);
            setProjects((current) => [toProject(result), ...current]);
            return result as any;
        } catch (err: any) {
            setError(err?.message || "Unable to create the project.");
            return null;
        }
    }, []);

    const deleteProject = useCallback(async (projectId: string) => {
        setError(null);
        await apiDeleteProject(projectId);
        setProjects((current) => current.filter((item) => item.id !== projectId));
        setActivityLogs((current) => current.filter((item) => item.projectId !== projectId));
    }, []);

    const addActivityLog = useCallback(async ({ projectId, entity, entityId, action, description }: {
        projectId: string;
        entity: "DELIVERABLE";
        entityId: string;
        action: "ADD" | "MODIFY" | "DELETE";
        description: string;
    }) => {
        try {
            const result = await addProjectActivityLog(projectId, { entity, entityId, action, description });
            setActivityLogs((result.activityLogs || []).map((item: any) => ({ ...item, id: String(item.id), projectId, createdAt: item.createdAt })));
        } catch (err: any) {
            setError(err?.message || "Unable to record project activity.");
        }
    }, [updateProject]);

    return <Outlet context={{ projects, loading, error, refreshProjects, loadProject, updateProject, createProject, deleteProject, activityLogs, addActivityLog }} />;
}
