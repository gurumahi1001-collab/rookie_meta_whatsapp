import api from "./axios";

export type InvoiceStatus = "draft" | "submitted" | "approved" | "rejected" | "paid" | "overdue";

export interface InvoiceRecord {
  id: string;
  invoiceNo: string;
  reference: string;
  vendor: string;
  vendorId: string;
  vendorEmail: string;
  vendorBank?: { bankName: string; branch: string; accountHolderName: string; accountNumber: string; ifscCode: string; swiftCode: string } | null;
  project: string;
  projectId: string;
  quotationId: string;
  quotationNo: string;
  amount: number;
  currency: string;
  dueDate: string;
  invoiceDate: string;
  status: InvoiceStatus;
  statusLabel: string;
  rejectionRemarks: string;
  milestoneName: string;
  milestoneModules: Array<{ name: string; rate: number }>;
  installmentAmount: number;
  taxRate: number;
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
  contractValue: number;
  siteReference: string;
  billPercentage: number;
  selectedInstallments: Array<{ id: string; name: string; amount: number; dueDate?: string | null; modules?: Array<{ name: string; rate: number }> }>;
  remarks: string;
  invoiceDocument?: { originalName: string; storageKey: string; mimeType: string; size: number; checksum?: string; uploadedAt?: string } | null;
  payment?: { amount: number; transactionRefId: string; paymentDate?: string | null; notes: string } | null;
  workflowHistory: Array<{ status: InvoiceStatus; comment: string; performedBy?: string; performedAt: string }>;
  createdAt?: string;
  updatedAt?: string;
}

export interface EligibleQuotation {
  id: string;
  quotationNo: string;
  projectTitle: string;
  vendor: string;
  vendorEmail: string;
  contractValue: number;
  currency: string;
  status: string;
  totalInstallments: number;
  pendingInstallments: number;
  invoicesGenerated: number;
  invoicesPaid: number;
  balanceAmount: number;
  remarks: string;
}

interface Envelope<T = unknown> {
  success?: boolean;
  message?: string;
  data?: T;
  pagination?: { page: number; limit: number; total: number; totalPages: number };
}

function ensure<T>(response: { data?: Envelope<T> }, fallback: string): T {
  if (response.data?.success === false) throw new Error(response.data.message || fallback);
  if (response.data?.data === undefined) throw new Error(fallback);
  return response.data.data as T;
}

export async function listInvoices(params: { search?: string; status?: InvoiceStatus; page?: number; limit?: number } = {}) {
  const response = await api.get<Envelope<InvoiceRecord[]>>("/invoices", {
    params: { search: params.search?.trim() || undefined, status: params.status || undefined, page: Math.max(1, Number(params.page) || 1), limit: Math.min(250, Math.max(1, Number(params.limit) || 25)) },
  });
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to load invoices.");
  return { data: Array.isArray(response.data?.data) ? response.data.data : [], pagination: response.data?.pagination };
}

export async function getInvoice(id: string) {
  return ensure(await api.get<Envelope<InvoiceRecord>>(`/invoices/${encodeURIComponent(id.trim())}`), "Unable to load invoice.");
}

export async function listEligibleQuotations() {
  return ensure(await api.get<Envelope<EligibleQuotation[]>>("/invoices/eligible-quotations"), "Unable to load approved quotations.");
}

export async function createInvoice(payload: Record<string, unknown>) {
  return ensure(await api.post<Envelope<InvoiceRecord>>("/invoices", payload), "Unable to create invoice.");
}

export async function updateInvoice(id: string, payload: Record<string, unknown>) {
  return ensure(await api.patch<Envelope<InvoiceRecord>>(`/invoices/${encodeURIComponent(id.trim())}`, payload), "Unable to update invoice.");
}

async function workflow(id: string, action: "submit" | "approve" | "reject", comment = "") {
  return ensure(await api.post<Envelope<InvoiceRecord>>(`/invoices/${encodeURIComponent(id.trim())}/${action}`, { comment }), `Unable to ${action} invoice.`);
}
export const submitInvoice = (id: string, comment = "") => workflow(id, "submit", comment);
export const approveInvoice = (id: string, comment = "") => workflow(id, "approve", comment);
export const rejectInvoice = (id: string, comment = "") => workflow(id, "reject", comment);

export async function markInvoicePaid(id: string, payload: { amount: number; transactionRefId: string; paymentDate: string; notes?: string }) {
  return ensure(await api.post<Envelope<InvoiceRecord>>(`/invoices/${encodeURIComponent(id.trim())}/mark-paid`, payload), "Unable to record payment.");
}

export async function uploadInvoiceDocument(id: string, file: File) {
  const form = new FormData();
  form.append("invoiceAttachment", file);
  return ensure(await api.post<Envelope<InvoiceRecord>>(`/invoices/${encodeURIComponent(id.trim())}/document`, form, { headers: { "Content-Type": "multipart/form-data" } }), "Unable to upload invoice document.");
}

export async function deleteInvoice(id: string) {
  const response = await api.delete<Envelope<unknown>>(`/invoices/${encodeURIComponent(id.trim())}`);
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to delete invoice.");
}
