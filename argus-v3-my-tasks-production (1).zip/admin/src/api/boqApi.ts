import api from "./axios";
import type { BOQPayload, BOQRecord, BOQStatus } from "../types/boq";

interface ApiEnvelope<T = unknown> {
    success?: boolean;
    message?: string;
    code?: string;
    data?: T;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

function normalizeId(value: unknown): string {
    return String(value ?? "").trim();
}

function assertSuccess<T>(response: { data?: ApiEnvelope<T> }, fallback: string): void {
    if (response.data?.success === false) {
        throw new Error(response.data.message || fallback);
    }
}

export async function listBOQs(params: {
    search?: string;
    status?: BOQStatus;
    page?: number;
    limit?: number;
} = {}) {
    const response = await api.get<ApiEnvelope<BOQRecord[]>>("/boqs", {
        params: {
            search: params.search?.trim() || undefined,
            status: params.status || undefined,
            page: Math.max(1, Number(params.page) || 1),
            limit: Math.min(250, Math.max(1, Number(params.limit) || 250)),
        },
    });
    assertSuccess(response, "Unable to load BOQs.");
    return {
        data: Array.isArray(response.data?.data) ? response.data.data : [],
        pagination: response.data?.pagination,
    };
}

export async function getBOQ(id: string): Promise<BOQRecord> {
    const normalizedId = normalizeId(id);
    if (!normalizedId) throw new Error("BOQ ID is required.");
    const response = await api.get<ApiEnvelope<BOQRecord>>(`/boqs/${encodeURIComponent(normalizedId)}`);
    assertSuccess(response, "Unable to load the BOQ.");
    if (!response.data?.data) throw new Error("BOQ record was not returned by the server.");
    return response.data.data;
}

export async function createBOQ(payload: BOQPayload): Promise<BOQRecord> {
    const response = await api.post<ApiEnvelope<BOQRecord>>("/boqs", payload);
    assertSuccess(response, "Unable to create the BOQ.");
    if (!response.data?.data) throw new Error("BOQ record was not returned by the server.");
    return response.data.data;
}

export async function updateBOQ(id: string, payload: BOQPayload): Promise<BOQRecord> {
    const normalizedId = normalizeId(id);
    if (!normalizedId) throw new Error("BOQ ID is required.");
    const response = await api.patch<ApiEnvelope<BOQRecord>>(`/boqs/${encodeURIComponent(normalizedId)}`, payload);
    assertSuccess(response, "Unable to update the BOQ.");
    if (!response.data?.data) throw new Error("BOQ record was not returned by the server.");
    return response.data.data;
}

export async function lockBOQ(id: string): Promise<BOQRecord> {
    const normalizedId = normalizeId(id);
    if (!normalizedId) throw new Error("BOQ ID is required.");
    const response = await api.patch<ApiEnvelope<BOQRecord>>(`/boqs/${encodeURIComponent(normalizedId)}/lock`);
    assertSuccess(response, "Unable to lock the BOQ.");
    if (!response.data?.data) throw new Error("Locked BOQ record was not returned by the server.");
    return response.data.data;
}

export async function deleteBOQ(id: string): Promise<void> {
    const normalizedId = normalizeId(id);
    if (!normalizedId) throw new Error("BOQ ID is required.");
    const response = await api.delete<ApiEnvelope<unknown>>(`/boqs/${encodeURIComponent(normalizedId)}`);
    assertSuccess(response, "Unable to delete the BOQ.");
}
