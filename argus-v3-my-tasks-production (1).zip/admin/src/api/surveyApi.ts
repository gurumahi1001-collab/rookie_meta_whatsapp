import api from "./axios";

/*
 * ARGUS Survey API client
 *
 * UI components should use this module instead of constructing survey
 * endpoints directly. The existing Axios instance remains the single place
 * for authentication, refresh-token handling, request IDs, and base URL
 * configuration.
 */

export type SurveyStatus =
    | "draft"
    | "active"
    | "archived";

export type SurveyResponseStatus =
    | "draft"
    | "submitted"
    | "reviewed"
    | "approved"
    | "rejected"
    | "archived";

export type SurveyReportStatus =
    | "draft"
    | "generated"
    | "final"
    | "archived"
    | "failed";

export type SurveyTemplateRecord = {
    id: string;
    name: string;
    description?: string;
    schema?: Record<string, unknown>;
    moduleCodes?: string[];
    moduleCount?: number;
    status?: SurveyStatus;
    version?: number;
    createdBy?: string | null;
    updatedBy?: string | null;
    createdAt?: string | null;
    updatedAt?: string | null;
    archivedAt?: string | null;
};

export type SurveyResponseRecord = {
    id: string;
    templateId?: string | null;
    projectId?: string | null;
    vendorId?: string | null;
    respondentId?: string | null;
    status?: SurveyResponseStatus;
    revision?: number;
    data?: Record<string, unknown>;
    metadata?: Record<string, unknown>;
    submittedAt?: string | null;
    reviewedAt?: string | null;
    approvedAt?: string | null;
    createdAt?: string | null;
    updatedAt?: string | null;
};

export type SurveyReportRecord = {
    id: string;
    reportNumber?: string;
    templateId?: string | null;
    responseId?: string | null;
    projectId?: string | null;
    vendorId?: string | null;
    status?: SurveyReportStatus;
    version?: number;
    summary?: Record<string, unknown>;
    data?: Record<string, unknown>;
    createdAt?: string | null;
    updatedAt?: string | null;
};

export type Pagination = {
    page: number;
    limit: number;
    total: number;
    pages: number;
};

export type ListResult<T> = {
    data: T[];
    pagination: Pagination;
    summary?: Record<string, number>;
};

type ApiEnvelope<T> = {
    success?: boolean;
    message?: string;
    data?: T;
    pagination?: Partial<Pagination>;
    summary?: Record<string, number>;
    requestId?: string;
};

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;

function normalizeId(value: unknown): string {
    return String(value ?? "").trim();
}

function normalizePagination(
    pagination?: Partial<Pagination>,
): Pagination {
    const page = Math.max(
        1,
        Number(pagination?.page) || DEFAULT_PAGE,
    );

    const limit = Math.min(
        MAX_LIMIT,
        Math.max(
            1,
            Number(pagination?.limit) || DEFAULT_LIMIT,
        ),
    );

    const total = Math.max(
        0,
        Number(pagination?.total) || 0,
    );

    const calculatedPages = Math.max(
        1,
        Math.ceil(total / limit),
    );

    const pages = Math.max(
        1,
        Number(pagination?.pages) || calculatedPages,
    );

    return { page, limit, total, pages };
}


function assertApiSuccess<T>(
    response: { data?: ApiEnvelope<T> },
    fallbackMessage: string,
): void {
    const envelope = response.data;

    if (envelope?.success === false) {
        throw new Error(envelope.message || fallbackMessage);
    }
}

function unwrapList<T>(
    response: { data?: ApiEnvelope<T[] | { data?: T[] }> },
): ListResult<T> {
    const envelope = response.data || {};
    const raw = envelope.data;
    const nestedList =
        raw &&
        typeof raw === "object" &&
        !Array.isArray(raw) &&
        "data" in raw
            ? raw.data
            : undefined;

    const list = Array.isArray(raw)
        ? raw
        : Array.isArray(nestedList)
            ? nestedList
            : [];

    return {
        data: list,
        pagination: normalizePagination(
            envelope.pagination,
        ),
        summary: envelope.summary,
    };
}

function unwrapItem<T>(
    response: { data?: ApiEnvelope<T | { data?: T }> },
): T {
    const envelope = response.data || {};
    const value = envelope.data;

    if (
        value &&
        typeof value === "object" &&
        "data" in value &&
        value.data !== undefined
    ) {
        return value.data as T;
    }

    return value as T;
}

function withId<T extends { id?: unknown; _id?: unknown }>(
    value: T,
): T & { id: string } {
    return {
        ...value,
        id: normalizeId(value.id || value._id),
    };
}

function withTemplateId(
    value: SurveyTemplateRecord,
): SurveyTemplateRecord {
    return withId(value);
}

function withResponseId(
    value: SurveyResponseRecord,
): SurveyResponseRecord {
    return withId(value);
}

function withReportId(
    value: SurveyReportRecord,
): SurveyReportRecord {
    return withId(value);
}

function requireId(
    id: string,
    resource: string,
): string {
    const normalized = normalizeId(id);

    if (!normalized) {
        throw new Error(`${resource} ID is required.`);
    }

    return encodeURIComponent(normalized);
}

function sanitizeParams(
    params: Record<string, unknown>,
): Record<string, unknown> {
    return Object.fromEntries(
        Object.entries(params).filter(([, value]) => {
            if (value === undefined || value === null) {
                return false;
            }

            if (typeof value === "string") {
                return value.trim().length > 0;
            }

            return true;
        }),
    );
}

/* -------------------------------------------------------------------------- */
/* Templates                                                                  */
/* -------------------------------------------------------------------------- */

export async function listSurveyTemplates(
    params: {
        page?: number;
        limit?: number;
        search?: string;
        status?: SurveyStatus | "all";
        moduleCode?: string;
        signal?: AbortSignal;
    } = {},
): Promise<ListResult<SurveyTemplateRecord>> {
    const response = await api.get<
        ApiEnvelope<SurveyTemplateRecord[] | { data?: SurveyTemplateRecord[] }>
    >(
        "/surveys/templates",
        {
            params: sanitizeParams({
                page: Math.max(1, params.page || DEFAULT_PAGE),
                limit: Math.min(MAX_LIMIT, Math.max(1, params.limit || DEFAULT_LIMIT)),
                search: params.search,
                status: params.status === "all" ? undefined : params.status,
                moduleCode: params.moduleCode,
            }),
            signal: params.signal,
        },
    );

    assertApiSuccess(response, "Unable to load survey templates.");
    const result = unwrapList<SurveyTemplateRecord>(response);

    return {
        ...result,
        data: result.data.map(withTemplateId),
    };
}

export async function getSurveyTemplate(
    id: string,
    signal?: AbortSignal,
): Promise<SurveyTemplateRecord> {
    const response = await api.get<
        ApiEnvelope<SurveyTemplateRecord>
    >(
        `/surveys/templates/${requireId(id, "Survey template")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to load the survey template.");

    return withTemplateId(
        unwrapItem(response),
    );
}

export async function createSurveyTemplate(
    payload: Partial<SurveyTemplateRecord>,
    signal?: AbortSignal,
): Promise<SurveyTemplateRecord> {
    const response = await api.post<
        ApiEnvelope<SurveyTemplateRecord>
    >(
        "/surveys/templates",
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to create the survey template.");

    return withTemplateId(
        unwrapItem(response),
    );
}

export async function updateSurveyTemplateStatus(
    id: string,
    status: SurveyStatus,
    signal?: AbortSignal,
): Promise<SurveyTemplateRecord> {
    return updateSurveyTemplate(
        id,
        { status },
        signal,
    );
}

export async function updateSurveyTemplate(
    id: string,
    payload: Partial<SurveyTemplateRecord>,
    signal?: AbortSignal,
): Promise<SurveyTemplateRecord> {
    const response = await api.patch<
        ApiEnvelope<SurveyTemplateRecord>
    >(
        `/surveys/templates/${requireId(id, "Survey template")}`,
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to update the survey template.");

    return withTemplateId(
        unwrapItem(response),
    );
}

export async function deleteSurveyTemplate(
    id: string,
    signal?: AbortSignal,
): Promise<void> {
    const response = await api.delete<ApiEnvelope<unknown>>(
        `/surveys/templates/${requireId(id, "Survey template")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to delete the survey template.");
}

/* -------------------------------------------------------------------------- */
/* Responses                                                                  */
/* -------------------------------------------------------------------------- */

export async function listSurveyResponses(
    params: {
        page?: number;
        limit?: number;
        search?: string;
        templateId?: string;
        projectId?: string;
        vendorId?: string;
        respondentId?: string;
        status?: SurveyResponseStatus | "all";
        fromDate?: string;
        toDate?: string;
        signal?: AbortSignal;
    } = {},
): Promise<ListResult<SurveyResponseRecord>> {
    const response = await api.get<
        ApiEnvelope<SurveyResponseRecord[] | { data?: SurveyResponseRecord[] }>
    >(
        "/surveys/responses",
        {
            params: sanitizeParams({
                page: Math.max(1, params.page || DEFAULT_PAGE),
                limit: Math.min(MAX_LIMIT, Math.max(1, params.limit || DEFAULT_LIMIT)),
                search: params.search,
                templateId: params.templateId,
                projectId: params.projectId,
                vendorId: params.vendorId,
                respondentId: params.respondentId,
                status: params.status === "all" ? undefined : params.status,
                fromDate: params.fromDate,
                toDate: params.toDate,
            }),
            signal: params.signal,
        },
    );

    assertApiSuccess(response, "Unable to load survey responses.");
    const result = unwrapList<SurveyResponseRecord>(response);

    return {
        ...result,
        data: result.data.map(withResponseId),
    };
}

export async function getSurveyResponse(
    id: string,
    signal?: AbortSignal,
): Promise<SurveyResponseRecord> {
    const response = await api.get<
        ApiEnvelope<SurveyResponseRecord>
    >(
        `/surveys/responses/${requireId(id, "Survey response")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to load the survey response.");

    return withResponseId(
        unwrapItem<SurveyResponseRecord>(response),
    );
}

export async function createSurveyResponse(
    payload: Partial<SurveyResponseRecord>,
    signal?: AbortSignal,
): Promise<SurveyResponseRecord> {
    const response = await api.post<
        ApiEnvelope<SurveyResponseRecord>
    >(
        "/surveys/responses",
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to create the survey response.");

    return withResponseId(
        unwrapItem<SurveyResponseRecord>(response),
    );
}

export async function updateSurveyResponse(
    id: string,
    payload: Partial<SurveyResponseRecord> & {
        revision?: number;
    },
    signal?: AbortSignal,
): Promise<SurveyResponseRecord> {
    const response = await api.patch<
        ApiEnvelope<SurveyResponseRecord>
    >(
        `/surveys/responses/${requireId(id, "Survey response")}`,
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to update the survey response.");

    return withResponseId(
        unwrapItem<SurveyResponseRecord>(response),
    );
}

export async function deleteSurveyResponse(
    id: string,
    signal?: AbortSignal,
): Promise<void> {
    const response = await api.delete<ApiEnvelope<unknown>>(
        `/surveys/responses/${requireId(id, "Survey response")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to delete the survey response.");
}

/* -------------------------------------------------------------------------- */
/* Reports                                                                    */
/* -------------------------------------------------------------------------- */

export async function listSurveyReports(
    params: {
        page?: number;
        limit?: number;
        search?: string;
        templateId?: string;
        responseId?: string;
        projectId?: string;
        vendorId?: string;
        status?: SurveyReportStatus | "all";
        fromDate?: string;
        toDate?: string;
        signal?: AbortSignal;
    } = {},
): Promise<ListResult<SurveyReportRecord>> {
    const response = await api.get<
        ApiEnvelope<SurveyReportRecord[] | { data?: SurveyReportRecord[] }>
    >(
        "/surveys/reports",
        {
            params: sanitizeParams({
                page: Math.max(1, params.page || DEFAULT_PAGE),
                limit: Math.min(MAX_LIMIT, Math.max(1, params.limit || DEFAULT_LIMIT)),
                search: params.search,
                templateId: params.templateId,
                responseId: params.responseId,
                projectId: params.projectId,
                vendorId: params.vendorId,
                status: params.status === "all" ? undefined : params.status,
                fromDate: params.fromDate,
                toDate: params.toDate,
            }),
            signal: params.signal,
        },
    );

    assertApiSuccess(response, "Unable to load survey reports.");
    const result = unwrapList<SurveyReportRecord>(response);

    return {
        ...result,
        data: result.data.map(withReportId),
    };
}

export async function getSurveyReport(
    id: string,
    signal?: AbortSignal,
): Promise<SurveyReportRecord> {
    const response = await api.get<
        ApiEnvelope<SurveyReportRecord>
    >(
        `/surveys/reports/${requireId(id, "Survey report")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to load the survey report.");

    return withReportId(
        unwrapItem<SurveyReportRecord>(response),
    );
}

export async function createSurveyReport(
    payload: Partial<SurveyReportRecord>,
    signal?: AbortSignal,
): Promise<SurveyReportRecord> {
    const response = await api.post<
        ApiEnvelope<SurveyReportRecord>
    >(
        "/surveys/reports",
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to create the survey report.");

    return withReportId(
        unwrapItem<SurveyReportRecord>(response),
    );
}

export async function updateSurveyReport(
    id: string,
    payload: Partial<SurveyReportRecord> & {
        version?: number;
    },
    signal?: AbortSignal,
): Promise<SurveyReportRecord> {
    const response = await api.patch<
        ApiEnvelope<SurveyReportRecord>
    >(
        `/surveys/reports/${requireId(id, "Survey report")}`,
        payload,
        { signal },
    );

    assertApiSuccess(response, "Unable to update the survey report.");

    return withReportId(
        unwrapItem<SurveyReportRecord>(response),
    );
}

export async function deleteSurveyReport(
    id: string,
    signal?: AbortSignal,
): Promise<void> {
    const response = await api.delete<ApiEnvelope<unknown>>(
        `/surveys/reports/${requireId(id, "Survey report")}`,
        { signal },
    );

    assertApiSuccess(response, "Unable to delete the survey report.");
}

export default {
    listSurveyTemplates,
    getSurveyTemplate,
    createSurveyTemplate,
    updateSurveyTemplate,
    updateSurveyTemplateStatus,
    deleteSurveyTemplate,
    listSurveyResponses,
    getSurveyResponse,
    createSurveyResponse,
    updateSurveyResponse,
    deleteSurveyResponse,
    listSurveyReports,
    getSurveyReport,
    createSurveyReport,
    updateSurveyReport,
    deleteSurveyReport,
};
