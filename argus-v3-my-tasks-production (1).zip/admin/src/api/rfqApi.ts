import api from "./axios";
import type { RFQPayload, RFQRecord, RFQStatus } from "../types/rfq";

interface Envelope<T = unknown> { success?: boolean; message?: string; data?: T; pagination?: { page: number; limit: number; total: number; totalPages: number } }
const ensure = <T>(response: { data?: Envelope<T> }, fallback: string): T => { if (response.data?.success === false) throw new Error(response.data.message || fallback); if (!response.data?.data) throw new Error(fallback); return response.data.data; };

export async function listRFQs(params: { search?: string; status?: RFQStatus; page?: number; limit?: number } = {}) {
  const response = await api.get<Envelope<RFQRecord[]>>("/rfqs", { params: { search: params.search?.trim() || undefined, status: params.status || undefined, page: Math.max(1, Number(params.page) || 1), limit: Math.min(250, Math.max(1, Number(params.limit) || 25)) } });
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to load RFQs.");
  return { data: Array.isArray(response.data?.data) ? response.data.data : [], pagination: response.data?.pagination };
}
export async function getRFQ(id: string): Promise<RFQRecord> { const value = id.trim(); if (!value) throw new Error("RFQ ID is required."); return ensure(await api.get<Envelope<RFQRecord>>(`/rfqs/${encodeURIComponent(value)}`), "Unable to load the RFQ."); }
export async function createRFQ(payload: RFQPayload): Promise<RFQRecord> { return ensure(await api.post<Envelope<RFQRecord>>("/rfqs", payload), "Unable to create the RFQ."); }
export async function updateRFQ(id: string, payload: RFQPayload): Promise<RFQRecord> { return ensure(await api.patch<Envelope<RFQRecord>>(`/rfqs/${encodeURIComponent(id.trim())}`, payload), "Unable to update the RFQ."); }
export async function sendRFQ(id: string): Promise<RFQRecord> { return ensure(await api.post<Envelope<RFQRecord>>(`/rfqs/${encodeURIComponent(id.trim())}/send`), "Unable to send the RFQ."); }
export async function closeRFQ(id: string): Promise<RFQRecord> { return ensure(await api.post<Envelope<RFQRecord>>(`/rfqs/${encodeURIComponent(id.trim())}/close`), "Unable to close the RFQ."); }
export async function deleteRFQ(id: string): Promise<void> { const response = await api.delete<Envelope<unknown>>(`/rfqs/${encodeURIComponent(id.trim())}`); if (response.data?.success === false) throw new Error(response.data.message || "Unable to delete the RFQ."); }
