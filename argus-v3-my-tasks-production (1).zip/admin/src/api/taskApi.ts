import api from './axios';
import type { Task } from '../offcanvas/mytask/edit';

export type TaskStatusValue = 'Pending' | 'In Progress' | 'On Hold' | 'Due Date' | 'Completed';
export type TaskPriorityValue = 'Low' | 'Medium' | 'High' | 'Urgent';

export interface TaskAssigneeOption { id: string; name: string; email: string; hourlyRate: number; }
export interface TaskProjectOption { id: string; reference: string; name: string; status: string; phases: string[]; }
interface Envelope<T = unknown> { success?: boolean; message?: string; data?: T; pagination?: { page:number; limit:number; total:number; totalPages:number }; }

function ensure<T>(response: { data?: Envelope<T> }, fallback: string): T {
  if (response.data?.success === false) throw new Error(response.data.message || fallback);
  if (response.data?.data === undefined) throw new Error(fallback);
  return response.data.data as T;
}

export async function listTasks(params: { search?: string; status?: TaskStatusValue; priority?: TaskPriorityValue; page?: number; limit?: number } = {}) {
  const response = await api.get<Envelope<Task[]>>('/tasks', { params: {
    search: params.search?.trim() || undefined,
    status: params.status || undefined,
    priority: params.priority || undefined,
    page: Math.max(1, Number(params.page) || 1),
    limit: Math.min(250, Math.max(1, Number(params.limit) || 100)),
  }});
  if (response.data?.success === false) throw new Error(response.data.message || 'Unable to load tasks.');
  return { data: Array.isArray(response.data?.data) ? response.data!.data! : [], pagination: response.data?.pagination };
}
export async function getTask(id: string): Promise<Task> { return ensure<Task>(await api.get<Envelope<Task>>(`/tasks/${encodeURIComponent(id.trim())}`), 'Unable to load task.'); }
export async function listTaskAssignees() { return ensure(await api.get<Envelope<TaskAssigneeOption[]>>('/tasks/assignees'), 'Unable to load staff.'); }
export async function listTaskProjects() { return ensure(await api.get<Envelope<TaskProjectOption[]>>('/tasks/projects'), 'Unable to load projects.'); }
export async function createTask(payload: Record<string, unknown>): Promise<Task> { return ensure<Task>(await api.post<Envelope<Task>>('/tasks', payload), 'Unable to create task.'); }
export async function updateTask(id: string, payload: Record<string, unknown>): Promise<Task> { return ensure<Task>(await api.patch<Envelope<Task>>(`/tasks/${encodeURIComponent(id.trim())}`, payload), 'Unable to update task.'); }
export async function deleteTask(id: string) { const r = await api.delete<Envelope<unknown>>(`/tasks/${encodeURIComponent(id.trim())}`); if (r.data?.success === false) throw new Error(r.data.message || 'Unable to delete task.'); }
