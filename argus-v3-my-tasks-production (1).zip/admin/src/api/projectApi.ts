import api from "./axios";

export type ProjectStatus = "planned" | "in_progress" | "on_hold" | "completed" | "closed";

export interface ProjectListRecord {
    id: string;
    reference: string;
    projectName: string;
    location: string;
    vendorName: string;
    vendorId: string;
    managerName: string;
    managerEmail: string;
    managerId: string;
    startDate: string | null;
    endDate: string | null;
    projectValue: number;
    budget: number;
    status: ProjectStatus;
    progress: number;
    currency: string;
    surveyRef: string;
    version: string;
    versionDate: string | null;
    createdAt?: string;
    updatedAt?: string;
}

export interface ProjectDetailRecord extends ProjectListRecord {
    name: string;
    description: string;
    sourceQuotationId: string;
    surveyTemplateId: string;
    inScopeItems: Array<{ id: string; text: string; completed?: boolean }>;
    outOfScopeItems: Array<{ id: string; text: string; completed?: boolean }>;
    phases: any[];
    deliverables: Array<{ id: string; name: string; dueDate: string; completed: boolean }>;
    installments: any[];
    activityLogs: Array<{ id: string; projectId?: string; entity: string; entityId: string; action: "ADD" | "MODIFY" | "DELETE"; description: string; createdAt: string; createdBy?: string }>;
}

interface Envelope<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
    pagination?: { page: number; limit: number; total: number; totalPages: number };
}

function ensure<T>(response: { data?: Envelope<T> }, fallback: string): T {
    if (response.data?.success === false) throw new Error(response.data.message || fallback);
    if (response.data?.data === undefined) throw new Error(fallback);
    return response.data.data as T;
}

export async function listProjects(params: { search?: string; status?: ProjectStatus; page?: number; limit?: number } = {}) {
    const response = await api.get<Envelope<ProjectListRecord[]>>("/projects", {
        params: {
            search: params.search?.trim() || undefined,
            status: params.status || undefined,
            page: Math.max(1, Number(params.page) || 1),
            limit: Math.min(250, Math.max(1, Number(params.limit) || 50)),
        },
    });
    if (response.data?.success === false) throw new Error(response.data.message || "Unable to load projects.");
    return { data: Array.isArray(response.data?.data) ? response.data.data : [], pagination: response.data?.pagination };
}


export async function listProjectAssignees(): Promise<Array<{ id: string; name: string; email: string }>> {
    return ensure(await api.get<Envelope<Array<{ id: string; name: string; email: string }>>>("/projects/assignees"), "Unable to load project assignees.");
}

export async function getProject(id: string): Promise<ProjectDetailRecord> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    return ensure(await api.get<Envelope<ProjectDetailRecord>>(`/projects/${encodeURIComponent(value)}`), "Unable to load the project.");
}

export async function createProject(payload: Record<string, unknown>): Promise<ProjectDetailRecord> {
    return ensure(await api.post<Envelope<ProjectDetailRecord>>("/projects", payload), "Unable to create the project.");
}

export async function updateProject(id: string, payload: Record<string, unknown>): Promise<ProjectDetailRecord> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    return ensure(await api.patch<Envelope<ProjectDetailRecord>>(`/projects/${encodeURIComponent(value)}`, payload), "Unable to update the project.");
}

export async function deleteProject(id: string): Promise<void> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    const response = await api.delete<Envelope<unknown>>(`/projects/${encodeURIComponent(value)}`);
    if (response.data?.success === false) throw new Error(response.data.message || "Unable to delete the project.");
}

export interface ProjectProgressRecord {
    projectId: string;
    reference: string;
    projectName: string;
    status: string;
    progress: number;
    taskCount: number;
    completedTaskCount: number;
    phaseCount: number;
    totalEstimatedHours: number;
    totalActualHours: number;
    projectValue: number;
    budget: number;
    startDate?: string | null;
    endDate?: string | null;
    phases: Array<{
        id: string;
        name: string;
        progress: number;
        taskCount: number;
        completedTaskCount: number;
    }>;
}

export async function getProjectProgress(id: string): Promise<ProjectProgressRecord> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    return ensure(await api.get<Envelope<ProjectProgressRecord>>(`/projects/${encodeURIComponent(value)}/progress`), "Unable to load project progress.");
}

export async function updateProjectProgress(id: string, payload: Record<string, unknown>): Promise<ProjectDetailRecord> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    return ensure(await api.patch<Envelope<ProjectDetailRecord>>(`/projects/${encodeURIComponent(value)}/progress`, payload), "Unable to update project progress.");
}

export async function addProjectActivityLog(id: string, payload: {
    entity: string;
    entityId: string;
    action: "ADD" | "MODIFY" | "DELETE";
    description: string;
}): Promise<ProjectDetailRecord> {
    const value = id.trim();
    if (!value) throw new Error("Project ID is required.");
    return ensure(await api.post<Envelope<ProjectDetailRecord>>(`/projects/${encodeURIComponent(value)}/activity`, payload), "Unable to record project activity.");
}
