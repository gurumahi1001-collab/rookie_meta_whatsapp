import api from "./axios";
import type { Quotation, QuotationPayload, QuotationStatus } from "../types/quotation";

interface Envelope<T = unknown> {
  success?: boolean;
  message?: string;
  data?: T;
  pagination?: { page: number; limit: number; total: number; totalPages: number };
}

function ensure<T>(response: { data?: Envelope<T> }, fallback: string): T {
  if (response.data?.success === false) throw new Error(response.data.message || fallback);
  if (!response.data?.data) throw new Error(fallback);
  return response.data.data;
}

export async function listQuotations(params: { search?: string; statusCode?: string; vendorId?: string; rfqId?: string; page?: number; limit?: number } = {}) {
  const response = await api.get<Envelope<Quotation[]>>("/quotations", {
    params: {
      search: params.search?.trim() || undefined,
      status: params.statusCode || undefined,
      vendorId: params.vendorId || undefined,
      rfqId: params.rfqId || undefined,
      page: Math.max(1, Number(params.page) || 1),
      limit: Math.min(250, Math.max(1, Number(params.limit) || 25)),
    },
  });
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to load quotations.");
  return { data: Array.isArray(response.data?.data) ? response.data.data : [], pagination: response.data?.pagination };
}

export async function getQuotation(id: string) {
  const value = id.trim();
  if (!value) throw new Error("Quotation ID is required.");
  return ensure(await api.get<Envelope<Quotation>>(`/quotations/${encodeURIComponent(value)}`), "Unable to load the quotation.");
}

export async function createQuotation(payload: QuotationPayload) {
  return ensure(await api.post<Envelope<Quotation>>("/quotations", payload), "Unable to create the quotation.");
}

export async function updateQuotation(id: string, payload: QuotationPayload) {
  return ensure(await api.patch<Envelope<Quotation>>(`/quotations/${encodeURIComponent(id.trim())}`, payload), "Unable to update the quotation.");
}

export async function submitQuotation(id: string, comment = "") {
  return ensure(await api.post<Envelope<Quotation>>(`/quotations/${encodeURIComponent(id.trim())}/submit`, { comment }), "Unable to submit the quotation.");
}

export async function approveQuotation(id: string, comment = "") {
  return ensure(await api.post<Envelope<Quotation>>(`/quotations/${encodeURIComponent(id.trim())}/approve`, { comment }), "Unable to approve the quotation.");
}

export async function rejectQuotation(id: string, comment: string) {
  return ensure(await api.post<Envelope<Quotation>>(`/quotations/${encodeURIComponent(id.trim())}/reject`, { comment }), "Unable to reject the quotation.");
}

export async function awardQuotation(id: string, comment = "") {
  return ensure(await api.post<Envelope<Quotation>>(`/quotations/${encodeURIComponent(id.trim())}/award`, { comment }), "Unable to award the quotation.");
}

export async function deleteQuotation(id: string) {
  const response = await api.delete<Envelope<unknown>>(`/quotations/${encodeURIComponent(id.trim())}`);
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to delete the quotation.");
}

export async function listApprovedVendors() {
  const response = await api.get<Envelope<any[]>>("/vendors", { params: { page: 1, limit: 250, status: "APPROVED" } });
  if (response.data?.success === false) throw new Error(response.data.message || "Unable to load approved vendors.");
  return Array.isArray(response.data?.data) ? response.data.data : [];
}
