import React, {
    createContext,
    PropsWithChildren,
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useState,
} from "react";
import api from "../api/axios";

export interface AuthUser {
    id: string;
    email: string;
    displayName?: string | null;
    profileImage?: {
        mimeType?: string | null;
        extension?: string | null;
        size?: number | null;
        uploadedAt?: string | null;
    } | null;
    userType?: string | null;
    roleId?: string | null;
    vendorId?: string | null;
    status?: string | null;
    vendorPortalOnboarding?: {
        requiresTermsAcceptance?: boolean;
        termsAcceptedAt?: string | null;
        invitationSentAt?: string | null;
    } | null;
}

export interface AuthRole {
    id: string;
    key: string;
    name: string;
    system?: boolean;
    ownerRole?: boolean;
}

export type AuthPermissions =
    | unknown[]
    | Record<string, unknown>;

interface AuthContextValue {
    user: AuthUser | null;
    role: AuthRole | null;
    permissions: AuthPermissions;
    loading: boolean;
    isAuthenticated: boolean;

    signInAdmin: (
        email: string,
        password: string,
        rememberMe?: boolean,
    ) => Promise<void>;

    signOut: () => Promise<void>;

    reloadSession: () => Promise<boolean>;
}

const AuthContext =
    createContext<AuthContextValue | undefined>(
        undefined,
    );

function getErrorMessage(
    error: any,
): string {
    return (
        error?.response?.data?.message ||
        error?.message ||
        "Authentication failed. Please try again."
    );
}

function readAuthPayload(
    response: any,
) {
    const data =
        response?.data?.data ??
        response?.data ??
        {};

    return {
        user: data.user ?? null,
        role: data.role ?? null,
        permissions:
            data.permissions ?? [],
    };
}

export function AuthProvider({
    children,
}: PropsWithChildren) {
    const [user, setUser] =
        useState<AuthUser | null>(null);

    const [role, setRole] =
        useState<AuthRole | null>(null);

    const [permissions, setPermissions] =
        useState<AuthPermissions>([]);

    const [loading, setLoading] =
        useState(true);

    const applySession =
        useCallback((payload: any) => {
            const normalized =
                readAuthPayload(
                    payload,
                );

            setUser(
                normalized.user,
            );

            setRole(
                normalized.role,
            );

            setPermissions(
                normalized.permissions,
            );
        }, []);

    const clearSession =
        useCallback(() => {
            setUser(null);
            setRole(null);
            setPermissions([]);
        }, []);

    const reloadSession =
        useCallback(
            async (): Promise<boolean> => {
                try {
                    const response =
                        await api.get(
                            "/auth/me",
                        );

                    applySession(
                        response,
                    );

                    return true;
                } catch {
                    clearSession();
                    return false;
                }
            },
            [
                applySession,
                clearSession,
            ],
        );

    useEffect(() => {
        let mounted = true;

        const bootstrap =
            async () => {
                try {
                    const response =
                        await api.get(
                            "/auth/me",
                        );

                    if (mounted) {
                        applySession(
                            response,
                        );
                    }
                } catch {
                    if (mounted) {
                        clearSession();
                    }
                } finally {
                    if (mounted) {
                        setLoading(
                            false,
                        );
                    }
                }
            };

        void bootstrap();

        return () => {
            mounted = false;
        };
    }, [
        applySession,
        clearSession,
    ]);

    const signInAdmin =
        useCallback(
            async (
                email: string,
                password: string,
                rememberMe = false,
            ) => {
                try {
                    const response =
                        await api.post(
                            "/auth/admin/login",
                            {
                                email:
                                    email.trim(),
                                password,
                                rememberMe:
                                    rememberMe === true,
                            },
                        );

                    applySession(
                        response,
                    );
                } catch (error) {
                    throw new Error(
                        getErrorMessage(
                            error,
                        ),
                    );
                }
            },
            [applySession],
        );

    const signOut =
        useCallback(
            async () => {
                try {
                    await api.post(
                        "/auth/logout",
                    );
                } finally {
                    clearSession();

                    if (
                        typeof window !==
                        "undefined"
                    ) {
                        window.location.assign(
                            "/",
                        );
                    }
                }
            },
            [clearSession],
        );

    const value =
        useMemo<AuthContextValue>(
            () => ({
                user,
                role,
                permissions,
                loading,
                isAuthenticated:
                    Boolean(user),
                signInAdmin,
                signOut,
                reloadSession,
            }),
            [
                user,
                role,
                permissions,
                loading,
                signInAdmin,
                signOut,
                reloadSession,
            ],
        );

    return (
        <AuthContext.Provider
            value={value}
        >
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth(): AuthContextValue {
    const context =
        useContext(AuthContext);

    if (!context) {
        throw new Error(
            "useAuth must be used inside <AuthProvider />.",
        );
    }

    return context;
}