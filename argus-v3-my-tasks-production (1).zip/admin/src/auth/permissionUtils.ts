export type PermissionAction = "view" | "add" | "edit" | "delete" | "all";

function isEnabled(value: unknown): boolean {
    return value === true || value === 1 || String(value).toLowerCase() === "true";
}

function normalizePermission(value: unknown): Record<string, boolean> {
    if (!value || typeof value !== "object") {
        return {};
    }

    const source = value as Record<string, unknown>;
    const all = isEnabled(source.all);

    return {
        view: all || isEnabled(source.view),
        add: all || isEnabled(source.add),
        edit: all || isEnabled(source.edit),
        delete: all || isEnabled(source.delete),
        all,
    };
}

export function hasPermission(
    permissions: unknown,
    module: string,
    action: PermissionAction = "view",
): boolean {
    const key = String(module || "").trim().toLowerCase();

    if (!key) {
        return false;
    }

    if (Array.isArray(permissions)) {
        for (const entry of permissions) {
            if (!entry || typeof entry !== "object") {
                continue;
            }

            const row = entry as Record<string, unknown>;
            const candidate = String(
                row.key ?? row.moduleKey ?? row.module ?? row.permission ?? "",
            )
                .trim()
                .toLowerCase();

            if (candidate !== key) {
                continue;
            }

            return normalizePermission(row.actions ?? row.permissions ?? row).all ||
                normalizePermission(row.actions ?? row.permissions ?? row)[action] === true;
        }

        return false;
    }

    if (permissions && typeof permissions === "object") {
        const map = permissions as Record<string, unknown>;
        const value = map[key] ?? map[module];
        const normalized = normalizePermission(value);

        return normalized.all || normalized[action] === true;
    }

    return false;
}
