import crypto from "node:crypto";
import mongoose from "mongoose";
import Project, {
    PROJECT_STATUSES,
    PROJECT_TASK_PRIORITIES,
    PROJECT_TASK_STATUSES,
} from "../../models/Project.js";
import Vendor from "../../models/Vendor.js";
import User from "../../models/User.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";
import Quotation from "../../models/Quotation.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";

export class ProjectServiceError extends Error {
    constructor(message, { code = "PROJECT_ERROR", statusCode = 400, details } = {}) {
        super(message);
        this.name = "ProjectServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, ProjectServiceError);
    }
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 250;
const text = (value) => String(value ?? "").trim();
const safeId = (value) => value ? String(value) : "";
const asObjectId = (value, field = "Project ID") => {
    const normalized = text(value);
    if (!mongoose.isValidObjectId(normalized)) {
        throw new ProjectServiceError(`Invalid ${field}.`, {
            code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`,
            statusCode: 400,
        });
    }
    return new mongoose.Types.ObjectId(normalized);
};
const asUserId = (value) => {
    const normalized = text(value);
    return normalized ? asObjectId(normalized, "user ID") : null;
};
const escapeRegex = (value) => text(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const normalizePage = (value) => {
    const parsed = Number.parseInt(String(value ?? ""), 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_PAGE;
};
const normalizeLimit = (value) => {
    const parsed = Number.parseInt(String(value ?? ""), 10);
    if (!Number.isFinite(parsed) || parsed < 1) return DEFAULT_LIMIT;
    return Math.min(MAX_LIMIT, parsed);
};

function parseDate(value, field, { optional = true } = {}) {
    if (value === undefined || value === null || value === "") return optional ? null : (() => { throw new ProjectServiceError(`${field} is required.`, { code: `${field.toUpperCase().replace(/\s+/g, "_")}_REQUIRED`, statusCode: 422 }); })();
    const date = /^\d{4}-\d{2}-\d{2}$/.test(String(value)) ? new Date(`${value}T00:00:00.000Z`) : new Date(value);
    if (Number.isNaN(date.getTime())) throw new ProjectServiceError(`${field} is invalid.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
    return date;
}

function number(value, field, { min = 0, max = Number.POSITIVE_INFINITY, fallback = 0 } = {}) {
    if (value === undefined || value === null || value === "") return fallback;
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
        throw new ProjectServiceError(`${field} must be between ${min} and ${max === Number.POSITIVE_INFINITY ? "infinity" : max}.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
    }
    return parsed;
}

function statusFor(value, fallback = "planned") {
    const normalized = text(value).toLowerCase().replace(/\s+/g, "_");
    if (!normalized) return fallback;
    if (!PROJECT_STATUSES.includes(normalized)) {
        throw new ProjectServiceError(`Invalid project status.`, { code: "INVALID_PROJECT_STATUS", statusCode: 422, details: { allowed: PROJECT_STATUSES } });
    }
    return normalized;
}

function normalizePriority(value) {
    const normalized = text(value).toLowerCase().replace(/\s+/g, "_");
    return PROJECT_TASK_PRIORITIES.includes(normalized) ? normalized : "medium";
}

function normalizeTaskStatus(value) {
    const normalized = text(value).toLowerCase().replace(/\s+/g, "");
    if (normalized === "in_progress") return "inprogress";
    if (normalized === "on_hold") return "onhold";
    if (PROJECT_TASK_STATUSES.includes(normalized)) return normalized;
    return "pending";
}

function normalizeStaff(list) {
    return Array.isArray(list) ? list.map((item) => ({
        name: text(item?.name),
        rate: number(item?.rate, "staff rate"),
        hours: number(item?.hours, "staff hours"),
        amount: number(item?.amount, "staff amount"),
    })).filter((item) => item.name) : [];
}

function normalizeTask(input, index = 0) {
    const name = text(input?.name || input?.title);
    if (!name) throw new ProjectServiceError(`Task ${index + 1}: task name is required.`, { code: "PROJECT_TASK_NAME_REQUIRED", statusCode: 422 });
    const staff = normalizeStaff(input?.Assignstaff || input?.assignStaff);
    const estimatedHours = number(input?.estimatedHours, "estimated hours");
    const actualHours = number(input?.actualHours, "actual hours");
    const hourlyRate = number(input?.hourlyRate ?? input?.rate, "hourly rate");
    return {
        id: text(input?.id) || crypto.randomUUID(),
        title: name,
        name,
        description: text(input?.description),
        phase: text(input?.phase),
        assignedTo: text(input?.assignedTo || input?.assignStaff || staff.map((staffMember) => staffMember.name).join(", ")),
        assignStaff: text(input?.assignStaff || input?.assignedTo || staff.map((staffMember) => staffMember.name).join(", ")),
        Assignstaff: staff,
        startDate: text(input?.startDate),
        endDate: text(input?.endDate || input?.dueDate),
        dueDate: text(input?.dueDate || input?.endDate),
        priority: normalizePriority(input?.priority),
        status: normalizeTaskStatus(input?.status),
        progress: number(input?.progress, "task progress", { min: 0, max: 100 }),
        estimatedHours,
        actualHours,
        hourlyRate,
        materialCost: number(input?.materialCost, "material cost"),
        otherExpenses: number(input?.otherExpenses, "other expenses"),
    };
}

function normalizePhase(input, index = 0) {
    const phaseName = text(input?.name) || `Phase ${index + 1}`;
    const tasks = Array.isArray(input?.tasks) ? input.tasks.map((task, taskIndex) => normalizeTask(task, taskIndex)) : [];
    return {
        id: text(input?.id) || crypto.randomUUID(),
        name: phaseName,
        description: text(input?.description),
        estimatedHours: number(input?.estimatedHours, "phase estimated hours"),
        tasks,
    };
}

function normalizeScopeItems(items) {
    if (!Array.isArray(items)) return [];
    return items.map((item) => ({ id: text(item?.id) || crypto.randomUUID(), text: text(item?.text), completed: Boolean(item?.completed) })).filter((item) => item.text);
}

function normalizeDeliverables(items) {
    if (!Array.isArray(items)) return [];
    return items.map((item) => ({ id: text(item?.id) || crypto.randomUUID(), name: text(item?.name), dueDate: text(item?.dueDate), completed: Boolean(item?.completed) })).filter((item) => item.name);
}

function normalizeInstallments(items) {
    if (!Array.isArray(items)) return [];
    return items.map((item, index) => ({
        id: item?.id ?? index + 1,
        name: text(item?.name) || `Installment ${index + 1}`,
        days: number(item?.days, "installment days"),
        dueDate: text(item?.dueDate),
        netTotalAmount: number(item?.netTotalAmount, "installment amount"),
        status: item?.status === "Paid" ? "Paid" : "Pending",
        moduleItems: Array.isArray(item?.moduleItems) ? item.moduleItems.map((moduleItem, moduleIndex) => ({ id: moduleItem?.id ?? moduleIndex + 1, name: text(moduleItem?.name) || `Item ${moduleIndex + 1}`, rate: number(moduleItem?.rate, "module rate") })) : [],
    }));
}

function normalizeActivityLogs(items) {
    if (!Array.isArray(items)) return [];
    return items.slice(-500).map((item) => ({
        id: text(item?.id) || crypto.randomUUID(),
        entity: text(item?.entity) || "PROJECT",
        entityId: text(item?.entityId),
        action: ["ADD", "MODIFY", "DELETE"].includes(item?.action) ? item.action : "MODIFY",
        description: text(item?.description) || "Project updated.",
        createdAt: parseDate(item?.createdAt, "Activity createdAt") || new Date(),
        createdBy: item?.createdBy && mongoose.isValidObjectId(String(item.createdBy)) ? new mongoose.Types.ObjectId(String(item.createdBy)) : null,
    }));
}

function toList(row) {
    return {
        id: safeId(row._id),
        reference: row.reference,
        projectName: row.projectName,
        location: row.location || "",
        vendorName: row.vendor?.name || "",
        vendorId: safeId(row.vendor?.vendorId),
        managerName: row.manager?.name || "",
        managerEmail: row.manager?.email || "",
        managerId: safeId(row.manager?.userId),
        startDate: row.startDate,
        endDate: row.endDate,
        projectValue: Number(row.projectValue || 0),
        budget: Number(row.budget || 0),
        status: row.status,
        progress: Number(row.progress || 0),
        currency: row.currency || "USD",
        surveyRef: row.surveyRef || "",
        version: row.version || "",
        versionDate: row.versionDate,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
    };
}

function toDetail(row) {
    return {
        ...toList(row),
        name: row.name || row.projectName,
        description: row.description || "",
        sourceQuotationId: safeId(row.sourceQuotationId),
        surveyTemplateId: safeId(row.surveyTemplateId),
        inScopeItems: row.inScopeItems || [],
        outOfScopeItems: row.outOfScopeItems || [],
        phases: row.phases || [],
        deliverables: row.deliverables || [],
        installments: row.installments || [],
        activityLogs: (row.activityLogs || []).map((item) => ({ ...item, createdBy: safeId(item.createdBy) })),
    };
}

async function nextReference() {
    const sequence = await MasterRateSequence.findOneAndUpdate(
        { _id: "project" },
        { $inc: { value: 1 } },
        { upsert: true, new: true, setDefaultsOnInsert: true },
    ).lean();
    const value = Number(sequence?.value || 0);
    if (!Number.isInteger(value) || value < 1) throw new ProjectServiceError("Unable to generate project reference.", { code: "PROJECT_REFERENCE_GENERATION_FAILED", statusCode: 500 });
    return `PRJ-${new Date().getFullYear()}-${String(value).padStart(5, "0")}`;
}

async function resolveRelations(payload, existing = null) {
    let vendorId = Object.prototype.hasOwnProperty.call(payload, "vendorId") ? text(payload.vendorId) : safeId(existing?.vendor?.vendorId);
    let managerId = Object.prototype.hasOwnProperty.call(payload, "managerId") ? text(payload.managerId) : safeId(existing?.manager?.userId);

    if (Object.prototype.hasOwnProperty.call(payload, "vendorName") && text(payload.vendorName) && text(payload.vendorName) !== text(existing?.vendor?.name)) {
        vendorId = "";
    }
    if (Object.prototype.hasOwnProperty.call(payload, "managerName") && text(payload.managerName) && text(payload.managerName) !== text(existing?.manager?.name)) {
        managerId = "";
    }

    if (!vendorId && Object.prototype.hasOwnProperty.call(payload, "vendorName") && text(payload.vendorName)) {
        const vendorByName = await Vendor.findOne({ companyName: text(payload.vendorName), accountStatus: "APPROVED" }).select("_id").lean();
        if (!vendorByName) throw new ProjectServiceError("Selected vendor is not approved or available.", { code: "PROJECT_VENDOR_UNAVAILABLE", statusCode: 422 });
        vendorId = String(vendorByName._id);
    }

    if (!managerId && Object.prototype.hasOwnProperty.call(payload, "managerName") && text(payload.managerName)) {
        const managerByName = await User.findOne({ displayName: text(payload.managerName), status: "active" }).select("_id").lean();
        if (!managerByName) throw new ProjectServiceError("Selected project manager is not active or available.", { code: "PROJECT_MANAGER_UNAVAILABLE", statusCode: 422 });
        managerId = String(managerByName._id);
    }
    const surveyTemplateId = Object.prototype.hasOwnProperty.call(payload, "surveyTemplateId") ? text(payload.surveyTemplateId) : safeId(existing?.surveyTemplateId);
    const sourceQuotationId = Object.prototype.hasOwnProperty.call(payload, "sourceQuotationId") ? text(payload.sourceQuotationId) : safeId(existing?.sourceQuotationId);

    let vendor = { vendorId: existing?.vendor?.vendorId || null, name: existing?.vendor?.name || "" };
    if (vendorId) {
        if (!mongoose.isValidObjectId(vendorId)) throw new ProjectServiceError("Invalid vendor ID.", { code: "INVALID_VENDOR_ID", statusCode: 422 });
        const row = await Vendor.findOne({ _id: new mongoose.Types.ObjectId(vendorId), accountStatus: "APPROVED" }).select("_id companyName").lean();
        if (!row) throw new ProjectServiceError("Selected vendor is not approved or available.", { code: "PROJECT_VENDOR_UNAVAILABLE", statusCode: 422 });
        vendor = { vendorId: row._id, name: row.companyName };
    }

    let manager = { userId: existing?.manager?.userId || null, name: existing?.manager?.name || "", email: existing?.manager?.email || "" };
    if (managerId) {
        if (!mongoose.isValidObjectId(managerId)) throw new ProjectServiceError("Invalid manager ID.", { code: "INVALID_MANAGER_ID", statusCode: 422 });
        const row = await User.findOne({ _id: new mongoose.Types.ObjectId(managerId), status: { $in: ["active", "ACTIVE"] } }).select("_id displayName email").lean();
        if (!row) throw new ProjectServiceError("Selected project manager is not active or available.", { code: "PROJECT_MANAGER_UNAVAILABLE", statusCode: 422 });
        manager = { userId: row._id, name: row.displayName || row.email || "", email: row.email || "" };
    }

    if (surveyTemplateId) {
        if (!mongoose.isValidObjectId(surveyTemplateId)) throw new ProjectServiceError("Invalid survey template ID.", { code: "INVALID_SURVEY_TEMPLATE_ID", statusCode: 422 });
        const row = await SurveyTemplate.findOne({ _id: new mongoose.Types.ObjectId(surveyTemplateId), status: "active" }).select("_id name").lean();
        if (!row) throw new ProjectServiceError("Selected survey template is inactive or unavailable.", { code: "PROJECT_SURVEY_TEMPLATE_UNAVAILABLE", statusCode: 422 });
    }

    if (sourceQuotationId) {
        if (!mongoose.isValidObjectId(sourceQuotationId)) throw new ProjectServiceError("Invalid quotation ID.", { code: "INVALID_SOURCE_QUOTATION_ID", statusCode: 422 });
        const row = await Quotation.findById(new mongoose.Types.ObjectId(sourceQuotationId)).select("_id status vendor projectTitle").lean();
        if (!row) throw new ProjectServiceError("Source quotation not found.", { code: "SOURCE_QUOTATION_NOT_FOUND", statusCode: 404 });
        if (!["approved", "awarded"].includes(row.status)) throw new ProjectServiceError("A project can only be created from an approved or awarded quotation.", { code: "SOURCE_QUOTATION_NOT_READY", statusCode: 422 });
    }

    return { vendor, manager, surveyTemplateId: surveyTemplateId ? new mongoose.Types.ObjectId(surveyTemplateId) : null, sourceQuotationId: sourceQuotationId ? new mongoose.Types.ObjectId(sourceQuotationId) : null };
}

function calculateProgress(project) {
    const tasks = (project.phases || []).flatMap((phase) => phase.tasks || []);
    if (!tasks.length) return Number(project.progress || 0);
    const total = tasks.reduce((sum, task) => sum + Number(task.progress || 0), 0);
    return Number(Math.min(100, Math.max(0, total / tasks.length)).toFixed(2));
}

export async function listProjects({ search, status, page, limit } = {}) {
    const normalizedPage = normalizePage(page);
    const normalizedLimit = normalizeLimit(limit);
    const filter = {};
    const statusValue = text(status);
    if (statusValue) filter.status = statusFor(statusValue);
    const searchValue = text(search);
    if (searchValue) {
        const regex = new RegExp(escapeRegex(searchValue), "i");
        filter.$or = [
            { reference: regex },
            { projectName: regex },
            { "vendor.name": regex },
            { "manager.name": regex },
            { location: regex },
        ];
    }
    const [rows, total] = await Promise.all([
        Project.find(filter).select("reference projectName location vendor manager startDate endDate projectValue budget status progress currency surveyRef version versionDate createdAt updatedAt").sort({ updatedAt: -1 }).skip((normalizedPage - 1) * normalizedLimit).limit(normalizedLimit).lean(),
        Project.countDocuments(filter),
    ]);
    return {
        data: rows.map(toList),
        pagination: { page: normalizedPage, limit: normalizedLimit, total, totalPages: Math.max(1, Math.ceil(total / normalizedLimit)) },
    };
}

export async function getProject(id) {
    const row = await Project.findById(asObjectId(id)).lean();
    if (!row) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    return toDetail(row);
}

export async function createProject({ payload, userId } = {}) {
    const source = payload || {};
    const projectName = text(source.projectName || source.name);
    if (projectName.length < 2) throw new ProjectServiceError("Project name is required.", { code: "PROJECT_NAME_REQUIRED", statusCode: 422 });
    const startDate = parseDate(source.startDate, "Start date", { optional: false });
    const endDate = parseDate(source.endDate, "End date", { optional: true });
    if (startDate && endDate && endDate < startDate) throw new ProjectServiceError("End date must be on or after the start date.", { code: "PROJECT_INVALID_DATE_RANGE", statusCode: 422 });
    const relation = await resolveRelations(source);
    const actor = asUserId(userId);
    const reference = text(source.reference) || await nextReference();
    const row = await Project.create({
        reference,
        projectName,
        name: projectName,
        description: text(source.description),
        location: text(source.location),
        currency: text(source.currency || "USD").toUpperCase(),
        vendor: relation.vendor,
        manager: relation.manager,
        startDate,
        endDate,
        projectValue: number(source.projectValue, "project value"),
        budget: number(source.budget, "budget"),
        surveyRef: text(source.surveyRef),
        surveyTemplateId: relation.surveyTemplateId,
        sourceQuotationId: relation.sourceQuotationId,
        version: text(source.version) || "v1.0",
        versionDate: parseDate(source.versionDate, "Version date", { optional: true }) || new Date(),
        status: statusFor(source.status, "planned"),
        progress: number(source.progress, "progress", { min: 0, max: 100 }),
        inScopeItems: normalizeScopeItems(source.inScopeItems),
        outOfScopeItems: normalizeScopeItems(source.outOfScopeItems),
        phases: Array.isArray(source.phases) ? source.phases.map(normalizePhase) : [],
        deliverables: normalizeDeliverables(source.deliverables),
        installments: normalizeInstallments(source.installments),
        activityLogs: [{ id: crypto.randomUUID(), entity: "PROJECT", entityId: reference, action: "ADD", description: "Project created.", createdAt: new Date(), createdBy: actor }],
        createdBy: actor,
        updatedBy: actor,
    });
    row.progress = calculateProgress(row);
    await row.save();
    return toDetail(row.toObject());
}

export async function updateProject({ id, payload, userId } = {}) {
    const objectId = asObjectId(id);
    const row = await Project.findById(objectId);
    if (!row) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    const source = payload || {};
    if (Object.prototype.hasOwnProperty.call(source, "projectName") || Object.prototype.hasOwnProperty.call(source, "name")) {
        const nextName = text(source.projectName || source.name);
        if (nextName.length < 2) throw new ProjectServiceError("Project name is required.", { code: "PROJECT_NAME_REQUIRED", statusCode: 422 });
        row.projectName = nextName; row.name = nextName;
    }
    const relationKeys = ["vendorId", "managerId", "surveyTemplateId", "sourceQuotationId"];
    if (relationKeys.some((key) => Object.prototype.hasOwnProperty.call(source, key))) {
        const relation = await resolveRelations(source, row);
        row.vendor = relation.vendor;
        row.manager = relation.manager;
        row.surveyTemplateId = relation.surveyTemplateId;
        row.sourceQuotationId = relation.sourceQuotationId;
    }
    const scalarMap = {
        description: (v) => text(v), location: (v) => text(v), currency: (v) => text(v || "USD").toUpperCase(), surveyRef: (v) => text(v), version: (v) => text(v),
        projectValue: (v) => number(v, "project value"), budget: (v) => number(v, "budget"), progress: (v) => number(v, "progress", { min: 0, max: 100 }),
        startDate: (v) => parseDate(v, "Start date", { optional: true }), endDate: (v) => parseDate(v, "End date", { optional: true }), versionDate: (v) => parseDate(v, "Version date", { optional: true }),
        status: (v) => statusFor(v, row.status),
    };
    for (const [key, transform] of Object.entries(scalarMap)) if (Object.prototype.hasOwnProperty.call(source, key)) row[key] = transform(source[key]);
    if (row.startDate && row.endDate && row.endDate < row.startDate) throw new ProjectServiceError("End date must be on or after the start date.", { code: "PROJECT_INVALID_DATE_RANGE", statusCode: 422 });
    if (Array.isArray(source.inScopeItems)) row.inScopeItems = normalizeScopeItems(source.inScopeItems);
    if (Array.isArray(source.outOfScopeItems)) row.outOfScopeItems = normalizeScopeItems(source.outOfScopeItems);
    if (Array.isArray(source.phases)) row.phases = source.phases.map(normalizePhase);
    if (Array.isArray(source.deliverables)) row.deliverables = normalizeDeliverables(source.deliverables);
    if (Array.isArray(source.installments)) row.installments = normalizeInstallments(source.installments);
    row.progress = calculateProgress(row);
    row.updatedBy = asUserId(userId);
    await row.save();
    return toDetail(row.toObject());
}

export async function addProjectActivityLog({ id, activity, userId } = {}) {
    const row = await Project.findById(asObjectId(id));
    if (!row) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    const source = activity || {};
    const entity = text(source.entity) || "PROJECT";
    const action = text(source.action).toUpperCase();
    const description = text(source.description);
    const entityId = text(source.entityId);
    if (!("ADD" === action || "MODIFY" === action || "DELETE" === action)) {
        throw new ProjectServiceError("Invalid project activity action.", { code: "INVALID_PROJECT_ACTIVITY_ACTION", statusCode: 422 });
    }
    if (!description) throw new ProjectServiceError("Project activity description is required.", { code: "PROJECT_ACTIVITY_DESCRIPTION_REQUIRED", statusCode: 422 });
    if (!entityId) throw new ProjectServiceError("Project activity entity ID is required.", { code: "PROJECT_ACTIVITY_ENTITY_REQUIRED", statusCode: 422 });

    row.activityLogs = [...(row.activityLogs || []), {
        id: crypto.randomUUID(),
        entity,
        entityId,
        action,
        description,
        createdAt: new Date(),
        createdBy: asUserId(userId),
    }].slice(-500);
    row.updatedBy = asUserId(userId);
    await row.save();
    return toDetail(row.toObject());
}

export async function getProjectProgress(id) {
    const row = await Project.findById(asObjectId(id)).select("reference projectName status progress phases budget projectValue startDate endDate").lean();
    if (!row) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });

    const phases = Array.isArray(row.phases) ? row.phases : [];
    const tasks = phases.flatMap((phase) => Array.isArray(phase.tasks) ? phase.tasks : []);
    const completedTasks = tasks.filter((task) => task.status === "completed" || Number(task.progress || 0) >= 100).length;
    const totalEstimatedHours = tasks.reduce((sum, task) => sum + Number(task.estimatedHours || 0), 0);
    const totalActualHours = tasks.reduce((sum, task) => sum + Number(task.actualHours || 0), 0);
    const phaseSummaries = phases.map((phase) => {
        const phaseTasks = Array.isArray(phase.tasks) ? phase.tasks : [];
        const phaseProgress = phaseTasks.length
            ? Number((phaseTasks.reduce((sum, task) => sum + Number(task.progress || 0), 0) / phaseTasks.length).toFixed(2))
            : 0;
        return {
            id: String(phase.id),
            name: phase.name,
            progress: phaseProgress,
            taskCount: phaseTasks.length,
            completedTaskCount: phaseTasks.filter((task) => task.status === "completed" || Number(task.progress || 0) >= 100).length,
        };
    });

    return {
        projectId: String(row._id),
        reference: row.reference,
        projectName: row.projectName,
        status: row.status,
        progress: Number(row.progress || 0),
        taskCount: tasks.length,
        completedTaskCount: completedTasks,
        phaseCount: phases.length,
        totalEstimatedHours,
        totalActualHours,
        projectValue: Number(row.projectValue || 0),
        budget: Number(row.budget || 0),
        startDate: row.startDate,
        endDate: row.endDate,
        phases: phaseSummaries,
    };
}

export async function updateProjectProgress({ id, payload, userId } = {}) {
    const source = payload || {};
    const project = await Project.findById(asObjectId(id));
    if (!project) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });

    const hasTaskPayload = Object.prototype.hasOwnProperty.call(source, "phases");
    if (hasTaskPayload) {
        const phases = Array.isArray(source.phases) ? source.phases : [];
        project.phases = phases.map(normalizePhase);
    } else if (Object.prototype.hasOwnProperty.call(source, "progress")) {
        project.progress = number(source.progress, "progress", { min: 0, max: 100 });
    } else {
        throw new ProjectServiceError("Progress or phases are required.", { code: "PROJECT_PROGRESS_REQUIRED", statusCode: 422 });
    }

    project.progress = calculateProgress(project);
    project.updatedBy = asUserId(userId);
    await project.save();
    return toDetail(project.toObject());
}

export async function deleteProject(id) {
    const row = await Project.findById(asObjectId(id));
    if (!row) throw new ProjectServiceError("Project not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (!["planned", "on_hold"].includes(row.status)) throw new ProjectServiceError("Only planned or on-hold projects can be deleted.", { code: "PROJECT_NOT_DELETABLE", statusCode: 409 });
    if ((row.phases || []).some((phase) => (phase.tasks || []).length)) throw new ProjectServiceError("Projects with tasks cannot be deleted.", { code: "PROJECT_HAS_TASKS", statusCode: 409 });
    await Project.deleteOne({ _id: row._id });
    return { id: safeId(row._id), reference: row.reference, deleted: true };
}


export async function listProjectAssignees() {
    const rows = await User.find({ status: "active", userType: { $in: ["admin", "internal"] } })
        .select("_id displayName email")
        .sort({ displayName: 1, email: 1 })
        .limit(250)
        .lean();
    return rows.map((row) => ({ id: safeId(row._id), name: row.displayName || row.email || "", email: row.email || "" })).filter((row) => row.name);
}

export default { listProjects, getProject, getProjectProgress, addProjectActivityLog, createProject, updateProject, updateProjectProgress, deleteProject, listProjectAssignees };
