import crypto from "node:crypto";
import mongoose from "mongoose";
import RFQ, { RFQ_STATUSES } from "../../models/RFQ.js";
import RFQVendor from "../../models/RFQVendor.js";
import BOQ from "../../models/BOQ.js";
import Vendor from "../../models/Vendor.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";

export class RFQServiceError extends Error {
  constructor(message, { code = "RFQ_ERROR", statusCode = 400, details } = {}) {
    super(message); this.name = "RFQServiceError"; this.code = code; this.statusCode = statusCode; this.details = details;
    Error.captureStackTrace?.(this, RFQServiceError);
  }
}

const text = (value) => String(value ?? "").trim();
const toObjectId = (value, field = "ID") => {
  const normalized = text(value);
  if (!mongoose.isValidObjectId(normalized)) throw new RFQServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 400 });
  return new mongoose.Types.ObjectId(normalized);
};
const parseDate = (value, field, required = true) => {
  if (!value && !required) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new RFQServiceError(`${field} is invalid.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
  return date;
};
const actorId = (value) => value ? toObjectId(value, "user ID") : null;
const escapeRegex = (value) => text(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function safeId(value) { return value ? String(value) : ""; }
function plain(row) {
  return {
    id: safeId(row._id), reference: row.reference, title: row.title, description: row.description || "",
    boq: { id: safeId(row.boq?.boqId), reference: row.boq?.reference || "", title: row.boq?.title || "" },
    surveyTemplate: { id: safeId(row.surveyTemplate?.templateId), name: row.surveyTemplate?.name || "", version: row.surveyTemplate?.version || 1 },
    issueDate: row.issueDate, responseDueDate: row.responseDueDate, currency: row.currency,
    vendors: (row.vendors || []).map(v => ({ id: safeId(v.vendorId), name: v.name, email: v.email || "", contactName: v.contactName || "", inviteStatus: v.inviteStatus, invitedAt: v.invitedAt, respondedAt: v.respondedAt })),
    terms: row.terms || "", internalNotes: row.internalNotes || "", status: row.status,
    sentAt: row.sentAt, closedAt: row.closedAt, createdAt: row.createdAt, updatedAt: row.updatedAt,
  };
}

async function nextReference() {
  const sequence = await MasterRateSequence.findOneAndUpdate({ _id: "rfq" }, { $inc: { value: 1 } }, { upsert: true, new: true, setDefaultsOnInsert: true }).lean();
  const value = Number(sequence?.value || 0);
  if (!Number.isInteger(value) || value < 1) throw new RFQServiceError("Unable to generate RFQ reference.", { code: "RFQ_REFERENCE_GENERATION_FAILED", statusCode: 500 });
  return `RFQ-${new Date().getFullYear()}-${String(value).padStart(5, "0")}`;
}

async function resolvePayload(payload, { existing = null, partial = false } = {}) {
  const source = payload || {};
  const get = (key, fallback = "") => Object.prototype.hasOwnProperty.call(source, key) ? source[key] : (partial ? fallback : "");
  const boqId = get("boqId", existing?.boq?.boqId || "");
  const due = get("responseDueDate", existing?.responseDueDate || "");
  const issue = get("issueDate", existing?.issueDate || new Date());
  const vendorIds = Array.isArray(get("vendorIds", existing?.vendors?.map(v => String(v.vendorId)) || [])) ? get("vendorIds", existing?.vendors?.map(v => String(v.vendorId)) || []) : [];

  const boq = await BOQ.findOne({ _id: toObjectId(boqId, "BOQ ID"), status: "locked" }).select("_id reference title currency responseDueDate").lean();
  if (!boq) throw new RFQServiceError("RFQ can only be created from a locked BOQ.", { code: "BOQ_NOT_READY_FOR_RFQ", statusCode: 422 });

  const ids = [...new Set(vendorIds.map(String).filter(Boolean))];
  if (!ids.length) throw new RFQServiceError("At least one approved vendor is required.", { code: "RFQ_VENDOR_REQUIRED", statusCode: 422 });
  if (ids.some(id => !mongoose.isValidObjectId(id))) throw new RFQServiceError("One or more vendor IDs are invalid.", { code: "INVALID_RFQ_VENDOR_ID", statusCode: 422 });
  const vendors = await Vendor.find({ _id: { $in: ids.map(id => new mongoose.Types.ObjectId(id)) }, accountStatus: "APPROVED" }).select("_id companyName contact currency").lean();
  if (vendors.length !== ids.length) throw new RFQServiceError("One or more selected vendors are not approved or unavailable.", { code: "RFQ_VENDOR_UNAVAILABLE", statusCode: 422 });

  let survey = { templateId: null, name: "", version: 1 };
  const surveyTemplateId = text(get("surveyTemplateId", existing?.surveyTemplate?.templateId || ""));
  if (surveyTemplateId) {
    const template = await SurveyTemplate.findOne({ _id: toObjectId(surveyTemplateId, "Survey template ID"), status: "active" }).select("_id name version").lean();
    if (!template) throw new RFQServiceError("Selected survey template is inactive or unavailable.", { code: "RFQ_SURVEY_TEMPLATE_UNAVAILABLE", statusCode: 422 });
    survey = { templateId: template._id, name: template.name, version: Number(template.version || 1) };
  }

  const responseDueDate = parseDate(due, "Response due date");
  const issueDate = parseDate(issue, "Issue date");
  if (responseDueDate <= issueDate) throw new RFQServiceError("Response due date must be after the issue date.", { code: "RFQ_INVALID_DUE_DATE", statusCode: 422 });

  return {
    title: text(get("title", existing?.title || "")), description: text(get("description", existing?.description || "")),
    issueDate, responseDueDate, currency: text(get("currency", existing?.currency || boq.currency || "JMD")).toUpperCase(),
    boq: { boqId: boq._id, reference: boq.reference, title: boq.title },
    surveyTemplate: survey, terms: text(get("terms", existing?.terms || "")), internalNotes: text(get("internalNotes", existing?.internalNotes || "")),
    vendors: vendors.map(v => ({ vendorId: v._id, name: v.companyName, email: v.contact?.email || "", contactName: v.contact?.name || "", inviteStatus: existing?.vendors?.find(e => String(e.vendorId) === String(v._id))?.inviteStatus || "pending", invitedAt: existing?.vendors?.find(e => String(e.vendorId) === String(v._id))?.invitedAt || null, respondedAt: existing?.vendors?.find(e => String(e.vendorId) === String(v._id))?.respondedAt || null })),
  };
}

export async function listRFQs({ search = "", status, page = 1, limit = 25 } = {}) {
  const safePage = Math.max(1, Number(page) || 1), safeLimit = Math.min(250, Math.max(1, Number(limit) || 25));
  const query = {};
  if (status) { if (!RFQ_STATUSES.includes(text(status).toLowerCase())) throw new RFQServiceError("Invalid RFQ status.", { code: "INVALID_RFQ_STATUS", statusCode: 422 }); query.status = text(status).toLowerCase(); }
  const q = text(search); if (q) query.$or = [{ reference: new RegExp(escapeRegex(q), "i") }, { title: new RegExp(escapeRegex(q), "i") }, { "boq.reference": new RegExp(escapeRegex(q), "i") }];
  const [rows, total] = await Promise.all([RFQ.find(query).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit).lean(), RFQ.countDocuments(query)]);
  return { data: rows.map(plain), pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) } };
}

export async function getRFQ(id) {
  const row = await RFQ.findById(toObjectId(id, "RFQ ID")).lean();
  if (!row) throw new RFQServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  return plain(row);
}

export async function createRFQ({ payload, userId }) {
  const normalized = await resolvePayload(payload);
  if (!normalized.title) throw new RFQServiceError("RFQ title is required.", { code: "RFQ_TITLE_REQUIRED", statusCode: 422 });
  const reference = text(payload?.reference).toUpperCase() || await nextReference();
  try {
    const row = await RFQ.create({ ...normalized, reference, status: "draft", createdBy: actorId(userId), updatedBy: actorId(userId) });
    return plain(row);
  } catch (error) {
    if (error?.code === 11000) throw new RFQServiceError("An RFQ with this reference already exists.", { code: "RFQ_REFERENCE_DUPLICATE", statusCode: 409 });
    throw error;
  }
}

export async function updateRFQ({ id, payload, userId }) {
  const row = await RFQ.findById(toObjectId(id, "RFQ ID"));
  if (!row) throw new RFQServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  if (row.status !== "draft") throw new RFQServiceError("Only draft RFQs can be edited.", { code: "RFQ_NOT_EDITABLE", statusCode: 409 });
  const normalized = await resolvePayload(payload, { existing: row.toObject(), partial: true });
  if (!normalized.title) throw new RFQServiceError("RFQ title is required.", { code: "RFQ_TITLE_REQUIRED", statusCode: 422 });
  Object.assign(row, normalized, { updatedBy: actorId(userId) });
  await row.save(); return plain(row);
}

export async function sendRFQ({ id, userId }) {
  const row = await RFQ.findById(toObjectId(id, "RFQ ID"));
  if (!row) throw new RFQServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  if (!["draft", "sent"].includes(row.status)) throw new RFQServiceError("This RFQ cannot be sent in its current status.", { code: "RFQ_NOT_SENDABLE", statusCode: 409 });
  if (!row.vendors.length) throw new RFQServiceError("At least one vendor is required before sending an RFQ.", { code: "RFQ_VENDOR_REQUIRED", statusCode: 422 });
  const invitedAt = new Date();
  row.vendors.forEach(v => { if (v.inviteStatus === "pending" || v.inviteStatus === "declined") { v.inviteStatus = "invited"; v.invitedAt = invitedAt; } });
  row.status = "sent"; row.sentAt = invitedAt; row.updatedBy = actorId(userId);
  await row.save();
  await RFQVendor.bulkWrite(row.vendors.map(v => ({ updateOne: { filter: { rfqId: row._id, vendorId: v.vendorId }, update: { $set: { rfqId: row._id, vendorId: v.vendorId, vendorName: v.name, email: v.email, status: v.inviteStatus, invitedAt: v.invitedAt } }, upsert: true } })));
  return plain(row);
}

export async function closeRFQ({ id, userId }) {
  const row = await RFQ.findById(toObjectId(id, "RFQ ID"));
  if (!row) throw new RFQServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  if (row.status !== "sent") throw new RFQServiceError("Only sent RFQs can be closed.", { code: "RFQ_NOT_CLOSABLE", statusCode: 409 });
  row.status = "closed"; row.closedAt = new Date(); row.updatedBy = actorId(userId); await row.save(); return plain(row);
}

export async function deleteRFQ({ id, userId }) {
  const row = await RFQ.findById(toObjectId(id, "RFQ ID"));
  if (!row) throw new RFQServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  if (row.status !== "draft") throw new RFQServiceError("Only draft RFQs can be deleted.", { code: "RFQ_NOT_DELETABLE", statusCode: 409 });
  await Promise.all([RFQ.deleteOne({ _id: row._id }), RFQVendor.deleteMany({ rfqId: row._id })]);
  return { id: String(row._id), deleted: true };
}

export default { listRFQs, getRFQ, createRFQ, updateRFQ, sendRFQ, closeRFQ, deleteRFQ };
