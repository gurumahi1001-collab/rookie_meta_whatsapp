// src/services/user/vendorUserManagementService.js

import mongoose from "mongoose";

import User from "../../models/User.js";
import Vendor from "../../models/Vendor.js";
import Role from "../../models/Role.js";
import RolePermission from "../../models/RolePermission.js";
import userManagementService, {
    UserManagementServiceError,
} from "./userManagementService.js";
import auditService from "../audit/auditService.js";


/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class VendorUserManagementServiceError extends Error {
    constructor(
        message,
        {
            code = "VENDOR_USER_MANAGEMENT_ERROR",
            statusCode = 400,
            details = null,
        } = {},
    ) {
        super(message);
        this.name = "VendorUserManagementServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, VendorUserManagementServiceError);
    }
}


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

const text = (value) => String(value ?? "").trim();

function objectId(value, field = "id") {
    const normalized = text(value);

    if (!mongoose.isValidObjectId(normalized)) {
        throw new VendorUserManagementServiceError(
            `Invalid ${field}.`,
            {
                code: "INVALID_IDENTIFIER",
                statusCode: 422,
                details: { field },
            },
        );
    }

    return new mongoose.Types.ObjectId(normalized);
}

function stringId(value) {
    return value ? String(value) : "";
}

function vendorSchemaSupportsScope() {
    return Boolean(Role.schema?.path?.("vendorId"));
}

async function resolveApprovedVendor(vendorId) {
    const _id = objectId(vendorId, "vendorId");

    const vendor = await Vendor.findById(_id)
        .select("_id companyName company_name email accountStatus status")
        .lean();

    if (!vendor) {
        throw new VendorUserManagementServiceError(
            "Vendor was not found.",
            {
                code: "VENDOR_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    const status = String(vendor.accountStatus ?? vendor.status ?? "")
        .trim()
        .toUpperCase();

    if (status !== "APPROVED") {
        throw new VendorUserManagementServiceError(
            "Only an approved vendor can manage vendor users.",
            {
                code: "VENDOR_NOT_APPROVED",
                statusCode: 409,
                details: { vendorStatus: status || null },
            },
        );
    }

    return vendor;
}

async function assertManagedUser(userId, vendorId) {
    const _id = objectId(userId, "userId");
    const _vendorId = objectId(vendorId, "vendorId");

    const user = await User.findOne({
        _id,
        userType: "vendor",
        vendorId: _vendorId,
    }).select("_id email displayName userType roleId vendorId status profileImage");

    if (!user) {
        throw new VendorUserManagementServiceError(
            "Vendor user was not found.",
            {
                code: "USER_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return user;
}

function roleAllowsVendor(role) {
    if (!role || role.active === false) {
        return false;
    }

    const allowedUserTypes = Array.isArray(role.allowedUserTypes)
        ? role.allowedUserTypes.map((value) => String(value).toLowerCase())
        : [];

    const realm = String(role.realm ?? "").toLowerCase();

    return (
        realm === "vendor" ||
        realm === "both" ||
        allowedUserTypes.includes("vendor")
    ) && (
        !allowedUserTypes.length ||
        allowedUserTypes.includes("vendor")
    );
}

async function resolveAssignableRole(roleId, vendorId) {
    const _vendorId = objectId(vendorId, "vendorId");
    const normalizedRoleId = text(roleId);

    if (!normalizedRoleId) {
        throw new VendorUserManagementServiceError(
            "Role is required.",
            {
                code: "ROLE_REQUIRED",
                statusCode: 422,
            },
        );
    }

    let role = null;

    if (mongoose.isValidObjectId(normalizedRoleId)) {
        role = await Role.findById(
            new mongoose.Types.ObjectId(normalizedRoleId),
        ).lean();
    } else {
        const key = normalizedRoleId
            .toLowerCase()
            .replace(/\s+/g, "_")
            .replace(/[^a-z0-9_.-]/g, "");

        if (key) {
            role = await Role.findOne({
                $or: [{ key }, { code: key }],
            }).lean();
        }
    }

    if (!role || !roleAllowsVendor(role)) {
        throw new VendorUserManagementServiceError(
            "The selected role is not available for vendor users.",
            {
                code: "ROLE_NOT_VENDOR_COMPATIBLE",
                statusCode: 422,
            },
        );
    }

    if (vendorSchemaSupportsScope()) {
        const roleVendorId = role.vendorId ? String(role.vendorId) : null;

        if (role.system) {
            return role;
        }

        if (!roleVendorId || roleVendorId !== String(_vendorId)) {
            throw new VendorUserManagementServiceError(
                "The selected role does not belong to this vendor.",
                {
                    code: "ROLE_VENDOR_SCOPE_VIOLATION",
                    statusCode: 403,
                },
            );
        }

        return role;
    }

    // Legacy Role schema fallback: only protected vendor system roles are
    // safe to expose until vendorId exists on the Role schema.
    if (!role.system) {
        throw new VendorUserManagementServiceError(
            "Vendor-specific custom roles are unavailable until vendor role scope is configured.",
            {
                code: "VENDOR_ROLE_SCOPE_NOT_CONFIGURED",
                statusCode: 409,
            },
        );
    }

    return role;
}

async function assertNoPrivilegeEscalation({
    actorUserId,
    targetRoleId,
}) {
    const actorId = objectId(actorUserId, "actorUserId");
    const roleId = objectId(targetRoleId, "roleId");

    const actor = await User.findById(actorId)
        .select("_id userType roleId vendorId")
        .lean();

    if (!actor || actor.userType !== "vendor") {
        throw new VendorUserManagementServiceError(
            "The current account cannot manage vendor users.",
            {
                code: "ACTOR_NOT_VENDOR",
                statusCode: 403,
            },
        );
    }

    const actorAssignments = await RolePermission.find({
        roleId: actor.roleId,
        active: true,
    })
        .select("permissionId actions")
        .lean();

    const targetAssignments = await RolePermission.find({
        roleId,
        active: true,
    })
        .select("permissionId actions")
        .lean();

    const actorMap = new Map(
        actorAssignments.map((assignment) => [
            String(assignment.permissionId),
            {
                view: assignment.actions?.view === true,
                add: assignment.actions?.add === true,
                edit: assignment.actions?.edit === true,
                delete: assignment.actions?.delete === true,
            },
        ]),
    );

    const escalation = [];

    for (const assignment of targetAssignments) {
        const permissionId = String(assignment.permissionId);
        const actorActions = actorMap.get(permissionId) ?? {
            view: false,
            add: false,
            edit: false,
            delete: false,
        };

        const targetActions = {
            view: assignment.actions?.view === true,
            add: assignment.actions?.add === true,
            edit: assignment.actions?.edit === true,
            delete: assignment.actions?.delete === true,
        };

        for (const action of ["view", "add", "edit", "delete"]) {
            if (targetActions[action] && !actorActions[action]) {
                escalation.push({ permissionId, action });
            }
        }
    }

    if (escalation.length) {
        throw new VendorUserManagementServiceError(
            "You cannot assign a role with permissions greater than your own.",
            {
                code: "ROLE_PRIVILEGE_ESCALATION",
                statusCode: 403,
                details: { permissions: escalation.slice(0, 50) },
            },
        );
    }
}

function mapBaseError(error) {
    if (error instanceof VendorUserManagementServiceError) {
        return error;
    }

    if (error instanceof UserManagementServiceError) {
        return new VendorUserManagementServiceError(
            error.message,
            {
                code: error.code,
                statusCode: error.statusCode,
                details: error.details,
            },
        );
    }

    return error;
}

async function writeAudit({
    action,
    title,
    description,
    actor,
    request,
    vendorId,
    entityId,
    entityName,
    metadata = {},
    changes = null,
}) {
    try {
        await auditService.recordAudit({
            action,
            module: "user_management",
            title,
            description,
            actor,
            request,
            vendorId,
            entityType: "user",
            entityId,
            entityName,
            metadata,
            changes,
        });
    } catch (error) {
        // Do not roll back an already-successful user mutation because a
        // separate audit write failed. Keep the failure visible to operators.
        console.error("[VendorUserManagementService] audit write failed", error);
    }
}


/* -------------------------------------------------------------------------- */
/* Public vendor-scoped operations                                            */
/* -------------------------------------------------------------------------- */

export async function listAssignableRoles({ vendorId } = {}) {
    await resolveApprovedVendor(vendorId);

    const query = {
        active: true,
        $or: [
            { realm: "vendor" },
            { realm: "both" },
            { allowedUserTypes: "vendor" },
        ],
    };

    if (vendorSchemaSupportsScope()) {
        query.$and = [
            {
                $or: [
                    { system: true },
                    { vendorId: objectId(vendorId, "vendorId") },
                ],
            },
        ];
    }

    const roles = await Role.find(query)
        .sort({ system: -1, sortOrder: 1, name: 1 })
        .lean();

    return roles.filter(roleAllowsVendor).map((role) => ({
        id: String(role._id),
        key: role.key,
        code: role.code ?? role.key,
        name: role.name,
        description: role.description ?? "",
        active: role.active !== false,
        system: role.system === true,
        ownerRole: role.ownerRole === true,
        realm: role.realm,
        allowedUserTypes: role.allowedUserTypes ?? [],
    }));
}

export async function listUsers({
    vendorId,
    actorUserId,
    search = "",
    roleId = "",
    status = "",
    page = 1,
    limit = 25,
} = {}) {
    const vendor = await resolveApprovedVendor(vendorId);
    objectId(actorUserId, "actorUserId");

    const result = await userManagementService.listUsers({
        search,
        roleId,
        status,
        userType: "vendor",
        vendorId: String(vendor._id),
        page,
        limit,
    });

    return result;
}

export async function getUser({ vendorId, userId, actorUserId } = {}) {
    await resolveApprovedVendor(vendorId);
    objectId(actorUserId, "actorUserId");
    await assertManagedUser(userId, vendorId);

    try {
        return await userManagementService.getUser(userId);
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function createUser({
    vendorId,
    actorUserId,
    email,
    displayName,
    password,
    hourlyRate = null,
    roleId,
    status = "active",
    request = null,
} = {}) {
    const vendor = await resolveApprovedVendor(vendorId);
    const role = await resolveAssignableRole(roleId, vendorId);
    await assertNoPrivilegeEscalation({
        actorUserId,
        targetRoleId: role._id,
    });

    try {
        const user = await userManagementService.createUser({
            email,
            displayName,
            password,
            hourlyRate,
            userType: "vendor",
            roleId: role._id,
            vendorId: String(vendor._id),
            status,
            createdBy: actorUserId,
        });

        await writeAudit({
            action: "create",
            title: "Vendor user created",
            description: `Vendor user ${user.displayName || user.email} was created.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: user.id,
            entityName: user.displayName || user.email,
            metadata: {
                roleId: String(role._id),
                role: role.name,
                status: user.status,
            },
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function updateUser({
    vendorId,
    actorUserId,
    userId,
    email,
    displayName,
    password,
    hourlyRate,
    roleId,
    status,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    let resolvedRoleId = existing.roleId;
    let resolvedRole = null;

    if (roleId !== undefined) {
        resolvedRole = await resolveAssignableRole(roleId, vendorId);
        await assertNoPrivilegeEscalation({
            actorUserId,
            targetRoleId: resolvedRole._id,
        });
        resolvedRoleId = resolvedRole._id;
    } else {
        await assertNoPrivilegeEscalation({
            actorUserId,
            targetRoleId: existing.roleId,
        });
    }

    try {
        const user = await userManagementService.updateUser({
            userId,
            email,
            displayName,
            hourlyRate,
            password,
            userType: "vendor",
            roleId: resolvedRoleId,
            vendorId: String(vendorId),
            status,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "update",
            title: "Vendor user updated",
            description: `Vendor user ${user.displayName || user.email} was updated.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: user.id,
            entityName: user.displayName || user.email,
            metadata: {
                roleChanged: roleId !== undefined,
                statusChanged: status !== undefined,
            },
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function activateUser({
    vendorId,
    actorUserId,
    userId,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    try {
        const user = await userManagementService.activateUser({
            userId,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "activate",
            title: "Vendor user activated",
            description: `Vendor user ${user.displayName || user.email} was activated.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function deactivateUser({
    vendorId,
    actorUserId,
    userId,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    try {
        const user = await userManagementService.deactivateUser({
            userId,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "deactivate",
            title: "Vendor user deactivated",
            description: `Vendor user ${user.displayName || user.email} was deactivated.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function resetPassword({
    vendorId,
    actorUserId,
    userId,
    password,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    try {
        const result = await userManagementService.resetPassword({
            userId,
            password,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "password_reset",
            title: "Vendor user password reset",
            description: `Password reset for vendor user ${existing.displayName || existing.email}.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
            metadata: { passwordChanged: true },
        });

        return result;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function assignRole({
    vendorId,
    actorUserId,
    userId,
    roleId,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);
    const role = await resolveAssignableRole(roleId, vendorId);

    await assertNoPrivilegeEscalation({
        actorUserId,
        targetRoleId: role._id,
    });

    try {
        const user = await userManagementService.assignRole({
            userId,
            roleId: role._id,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "role_assign",
            title: "Vendor user role changed",
            description: `Role for vendor user ${existing.displayName || existing.email} was changed.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
            metadata: {
                previousRoleId: String(existing.roleId),
                roleId: String(role._id),
                role: role.name,
            },
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function checkEmailAvailability({
    vendorId,
    email,
    excludeUserId = null,
} = {}) {
    await resolveApprovedVendor(vendorId);

    try {
        return await userManagementService.checkEmailAvailability({
            email,
            excludeUserId,
        });
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function bulkUpdateStatus({
    vendorId,
    actorUserId,
    userIds = [],
    status,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const normalizedIds = Array.isArray(userIds) ? userIds : [];

    if (!normalizedIds.length) {
        throw new VendorUserManagementServiceError(
            "At least one vendor user must be selected.",
            {
                code: "USER_IDS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    for (const userId of normalizedIds) {
        await assertManagedUser(userId, vendorId);
    }

    // The base service performs the actual bulk update after the complete
    // vendor-scope validation above, so cross-vendor IDs cannot be modified.
    try {
        const result = await userManagementService.bulkUpdateStatus({
            userIds: normalizedIds,
            status,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "bulk_status",
            title: "Vendor user statuses updated",
            description: `${result.modified} vendor user account(s) were updated.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            metadata: {
                requestedCount: normalizedIds.length,
                modified: result.modified,
                status: result.status,
            },
        });

        return result;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function updateProfileImage({
    vendorId,
    actorUserId,
    userId,
    file,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    try {
        const user = await userManagementService.updateProfileImage({
            userId,
            file,
            uploadedBy: actorUserId,
        });

        await writeAudit({
            action: "profile_image_update",
            title: "Vendor user profile image updated",
            description: `Profile image updated for vendor user ${existing.displayName || existing.email}.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function removeProfileImage({
    vendorId,
    actorUserId,
    userId,
    request = null,
} = {}) {
    await resolveApprovedVendor(vendorId);
    const existing = await assertManagedUser(userId, vendorId);

    try {
        const user = await userManagementService.removeProfileImage({
            userId,
            updatedBy: actorUserId,
        });

        await writeAudit({
            action: "profile_image_remove",
            title: "Vendor user profile image removed",
            description: `Profile image removed for vendor user ${existing.displayName || existing.email}.`,
            actor: request?.user ?? { id: actorUserId, userType: "vendor" },
            request,
            vendorId,
            entityId: String(existing._id),
            entityName: existing.displayName || existing.email,
        });

        return user;
    } catch (error) {
        throw mapBaseError(error);
    }
}

export async function getProfileImageFile({ vendorId, userId } = {}) {
    await resolveApprovedVendor(vendorId);
    await assertManagedUser(userId, vendorId);

    try {
        return await userManagementService.getProfileImageFile(userId);
    } catch (error) {
        throw mapBaseError(error);
    }
}


/* -------------------------------------------------------------------------- */
/* Default service                                                            */
/* -------------------------------------------------------------------------- */

const vendorUserManagementService = Object.freeze({
    listAssignableRoles,
    listUsers,
    getUser,
    createUser,
    updateUser,
    activateUser,
    deactivateUser,
    resetPassword,
    assignRole,
    checkEmailAvailability,
    bulkUpdateStatus,
    updateProfileImage,
    removeProfileImage,
    getProfileImageFile,
});

export default vendorUserManagementService;
