import mongoose from "mongoose";
import Invoice, { INVOICE_STATUSES } from "../../models/Invoice.js";
import Quotation from "../../models/Quotation.js";
import Vendor from "../../models/Vendor.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";
import Project from "../../models/Project.js";
import { sanitizeOriginalName, sanitizeStorageFilename, saveBuffer } from "../storage/storageService.js";

export class InvoiceServiceError extends Error {
  constructor(message, { code = "INVOICE_ERROR", statusCode = 400, details } = {}) {
    super(message); this.name = "InvoiceServiceError"; this.code = code; this.statusCode = statusCode; this.details = details;
    Error.captureStackTrace?.(this, InvoiceServiceError);
  }
}

const text = (v) => String(v ?? "").trim();
const oid = (v, field) => {
  const value = text(v);
  if (!mongoose.isValidObjectId(value)) throw new InvoiceServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 400 });
  return new mongoose.Types.ObjectId(value);
};
const num = (v, field, { min = 0, max = Number.POSITIVE_INFINITY, fallback = 0 } = {}) => {
  if (v === undefined || v === null || v === "") return fallback;
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) throw new InvoiceServiceError(`${field} is invalid.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
  return n;
};
const date = (v, field, required = true) => {
  if ((v === undefined || v === null || v === "") && !required) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) throw new InvoiceServiceError(`${field} is invalid.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
  return d;
};
const actorId = (v) => v && mongoose.isValidObjectId(String(v)) ? new mongoose.Types.ObjectId(String(v)) : null;
const escapeRegex = (v) => text(v).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function fmtDate(v) { return v ? new Date(v).toISOString().slice(0, 10) : ""; }
function statusLabel(v) { return String(v || "draft").replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()); }
function refOf(row) { return row ? String(row._id) : ""; }
function sumInstallments(items) { return items.reduce((s, item) => s + Number(item.amount || 0), 0); }

function toPublic(row) {
  const plain = row.toObject ? row.toObject() : row;
  const overdue = !["paid", "rejected"].includes(plain.status) && plain.dueDate && new Date(plain.dueDate) < new Date();
  return {
    id: refOf(plain),
    invoiceNo: plain.reference,
    reference: plain.reference,
    vendor: plain.vendor?.name || "",
    vendorId: refOf(plain.vendor?.id),
    vendorEmail: plain.vendor?.email || "",
    vendorBank: plain.vendorBank || null,
    project: plain.project?.name || "",
    projectId: refOf(plain.project?.id),
    quotationId: refOf(plain.quotation?.id),
    quotationNo: plain.quotation?.reference || "",
    amount: Number(plain.totalAmount || 0),
    currency: plain.currency,
    dueDate: fmtDate(plain.dueDate),
    invoiceDate: fmtDate(plain.invoiceDate),
    status: overdue ? "overdue" : plain.status,
    statusLabel: overdue ? "Overdue" : statusLabel(plain.status),
    rejectionRemarks: plain.rejectionRemarks || "",
    milestoneName: plain.milestoneName || "",
    milestoneModules: plain.milestoneModules || [],
    installmentAmount: Number(plain.subtotal || 0),
    taxRate: Number(plain.taxRate || 0) / 100,
    subtotal: Number(plain.subtotal || 0),
    taxAmount: Number(plain.taxAmount || 0),
    totalAmount: Number(plain.totalAmount || 0),
    contractValue: Number(plain.contractValue || 0),
    siteReference: plain.siteReference || "",
    billPercentage: Number(plain.billPercentage || 100),
    selectedInstallments: plain.selectedInstallments || [],
    remarks: plain.remarks || "",
    invoiceDocument: plain.invoiceDocument || null,
    payment: plain.payment || null,
    workflowHistory: (plain.workflowHistory || []).map((entry) => ({ ...entry, performedBy: refOf(entry.performedBy) })),
    createdAt: plain.createdAt,
    updatedAt: plain.updatedAt,
  };
}

async function nextReference() {
  const seq = await MasterRateSequence.findOneAndUpdate({ _id: "invoice" }, { $inc: { value: 1 } }, { upsert: true, new: true, setDefaultsOnInsert: true }).lean();
  const value = Number(seq?.value || 0);
  if (!Number.isInteger(value) || value < 1) throw new InvoiceServiceError("Unable to generate invoice reference.", { code: "INVOICE_REFERENCE_GENERATION_FAILED", statusCode: 500 });
  return `INV-${new Date().getFullYear()}-${String(value).padStart(5, "0")}`;
}

async function resolveQuotation(quotationId) {
  const id = oid(quotationId, "quotation ID");
  const quotation = await Quotation.findById(id).lean();
  if (!quotation) throw new InvoiceServiceError("Quotation not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
  if (!["approved", "awarded"].includes(quotation.status)) throw new InvoiceServiceError("Invoice can only be generated from an approved or awarded quotation.", { code: "QUOTATION_NOT_READY_FOR_INVOICE", statusCode: 422 });
  return quotation;
}

function snapshotQuotation(q) {
  return { id: q._id, reference: q.reference, name: q.projectTitle || q.reference, email: "" };
}

function normalizeInstallments(quotation, selectedIds) {
  const source = quotation.paymentSchedule?.installments || [];
  const ids = Array.isArray(selectedIds) ? [...new Set(selectedIds.map(String))] : [];
  const chosen = source.filter((item, index) => ids.length ? ids.includes(String(item.id || index + 1)) : index === 0).map((item, index) => ({
    id: String(item.id || index + 1),
    name: text(item.installmentName) || `Installment ${index + 1}`,
    amount: num(item.amount, "installment amount"),
    dueDate: null,
    modules: Array.isArray(item.modules) ? item.modules.map((name) => ({ name: text(name), rate: 0 })).filter((m) => m.name) : [],
  }));
  return chosen;
}

async function buildPayload(payload, { existing = null, userId, partial = false } = {}) {
  const quotationId = text(payload?.quotationId || existing?.quotation?.id);
  const quotation = await resolveQuotation(quotationId);
  const vendor = quotation.vendor?.vendorId ? await Vendor.findById(quotation.vendor.vendorId).select("companyName contact bankInformation").lean() : null;
  const project = await Project.findOne({ sourceQuotationId: quotation._id }).select("_id reference projectName name location").lean();
  const selectedInstallments = normalizeInstallments(quotation, payload?.selectedInstallmentIds ?? existing?.selectedInstallments?.map((i) => i.id));
  const billPercentage = num(payload?.billPercentage ?? existing?.billPercentage, "Bill percentage", { min: 0.01, max: 100, fallback: 100 });
  const subtotal = Number((sumInstallments(selectedInstallments) * billPercentage / 100).toFixed(2));
  const taxRate = num(payload?.taxRate ?? existing?.taxRate, "Tax rate", { min: 0, max: 100, fallback: 0 });
  const taxAmount = Number((subtotal * taxRate / 100).toFixed(2));
  const totalAmount = Number((subtotal + taxAmount).toFixed(2));
  const billingMatch = { "quotation.id": quotation._id, status: { $in: ["draft", "submitted", "approved", "paid"] } };
  if (existing?._id) billingMatch._id = { $ne: existing._id };
  const billedRows = await Invoice.aggregate([{ $match: billingMatch }, { $group: { _id: null, total: { $sum: "$totalAmount" } } }]);
  const alreadyBilled = Number(billedRows[0]?.total || 0);
  if (totalAmount > Math.max(0, Number(quotation.grandTotal || 0) - alreadyBilled) + 0.01) {
    throw new InvoiceServiceError("This invoice exceeds the remaining quotation balance.", { code: "INVOICE_EXCEEDS_QUOTATION_BALANCE", statusCode: 422, details: { contractValue: Number(quotation.grandTotal || 0), alreadyBilled, remainingBalance: Math.max(0, Number(quotation.grandTotal || 0) - alreadyBilled), requestedTotal: totalAmount } });
  }
  const dueDate = date(payload?.dueDate ?? existing?.dueDate, "Due date");
  const invoiceDate = date(payload?.invoiceDate ?? existing?.invoiceDate ?? new Date(), "Invoice date");
  if (dueDate < invoiceDate) throw new InvoiceServiceError("Due date cannot be before invoice date.", { code: "INVALID_INVOICE_DUE_DATE", statusCode: 422 });
  if (!selectedInstallments.length && !partial) throw new InvoiceServiceError("At least one quotation installment is required.", { code: "INVOICE_INSTALLMENT_REQUIRED", statusCode: 422 });
  return {
    quotation: snapshotQuotation(quotation),
    vendor: { id: quotation.vendor?.vendorId || null, name: quotation.vendor?.name || vendor?.companyName || "", email: quotation.vendor?.email || vendor?.contact?.email || "" },
    vendorBank: {
      bankName: vendor?.bankInformation?.bankName || "",
      branch: vendor?.bankInformation?.branch || "",
      accountHolderName: vendor?.bankInformation?.accountHolderName || "",
      accountNumber: vendor?.bankInformation?.accountNumber || "",
      ifscCode: vendor?.bankInformation?.ifscCode || "",
      swiftCode: vendor?.bankInformation?.swiftCode || "",
    },
    project: { id: project?._id || null, reference: project?.reference || quotation.reference, name: project?.projectName || project?.name || quotation.projectTitle || "", email: "" },
    currency: text(payload?.currency || existing?.currency || quotation.currency).toUpperCase(),
    invoiceDate, dueDate,
    siteReference: text(payload?.siteReference ?? existing?.siteReference),
    milestoneName: text(payload?.milestoneName ?? existing?.milestoneName),
    milestoneModules: Array.isArray(payload?.milestoneModules) ? payload.milestoneModules.map((m) => ({ name: text(m?.name), rate: num(m?.rate, "module rate") })).filter((m) => m.name) : (existing?.milestoneModules || []),
    selectedInstallments,
    billPercentage,
    contractValue: Number(quotation.grandTotal || 0),
    subtotal, taxRate, taxAmount, totalAmount,
    remarks: text(payload?.remarks ?? existing?.remarks),
  };
}

export async function listInvoices({ search = "", status, page = 1, limit = 25 } = {}) {
  const safePage = Math.max(1, Number(page) || 1); const safeLimit = Math.min(250, Math.max(1, Number(limit) || 25));
  const query = {};
  const normalizedStatus = text(status).toLowerCase();
  if (normalizedStatus) {
    if (![...INVOICE_STATUSES, "overdue"].includes(normalizedStatus)) throw new InvoiceServiceError("Invalid invoice status.", { code: "INVALID_INVOICE_STATUS", statusCode: 422 });
    if (normalizedStatus === "overdue") { query.status = { $in: ["draft", "submitted", "approved"] }; query.dueDate = { $lt: new Date() }; }
    else query.status = normalizedStatus;
  }
  const q = text(search); if (q) query.$or = [{ reference: new RegExp(escapeRegex(q), "i") }, { "vendor.name": new RegExp(escapeRegex(q), "i") }, { "project.name": new RegExp(escapeRegex(q), "i") }, { "quotation.reference": new RegExp(escapeRegex(q), "i") }];
  const rows = await Invoice.find(query).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit).lean();
  const total = await Invoice.countDocuments(query);
  return { data: rows.map(toPublic), pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) } };
}

export async function getInvoice(id) {
  const row = await Invoice.findById(oid(id, "invoice ID")).lean();
  if (!row) throw new InvoiceServiceError("Invoice not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
  return toPublic(row);
}

export async function listInvoiceEligibleQuotations() {
  const quotations = await Quotation.find({ status: { $in: ["approved", "awarded"] } }).sort({ updatedAt: -1 }).lean();
  const ids = quotations.map((q) => q._id);
  const invoiceRows = await Invoice.find({ "quotation.id": { $in: ids } }).select("quotation.id status totalAmount selectedInstallments.id").lean();
  const grouped = new Map();
  for (const row of invoiceRows) { const key = String(row.quotation?.id); const x = grouped.get(key) || { generated: 0, paid: 0, billed: 0, installmentIds: new Set() }; if (row.status !== "rejected") { x.generated += 1; x.billed += Number(row.totalAmount || 0); (row.selectedInstallments || []).forEach((item) => x.installmentIds.add(String(item.id))); } if (row.status === "paid") x.paid += 1; grouped.set(key, x); }
  return quotations.map((q) => {
    const g = grouped.get(String(q._id)) || { generated: 0, paid: 0, billed: 0 };
    const installments = q.paymentSchedule?.installments || [];
    const contractValue = Number(q.grandTotal || 0); const balance = Math.max(0, contractValue - g.billed);
    const pendingInstallments = Math.max(0, installments.filter((item, index) => !g.installmentIds?.has(String(item.id || index + 1))).length);
    return { id: String(q._id), quotationNo: q.reference, projectTitle: q.projectTitle, vendor: q.vendor?.name || "", vendorEmail: q.vendor?.email || "", contractValue, currency: q.currency, status: q.status, totalInstallments: installments.length, pendingInstallments, invoicesGenerated: g.generated, invoicesPaid: g.paid, balanceAmount: balance, remarks: q.status === "approved" ? "Approved quotation" : "Awarded quotation" };
  });
}

export async function createInvoice({ payload, userId }) {
  const normalized = await buildPayload(payload, { userId });
  let reference = text(payload?.reference).toUpperCase();
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      if (!reference) reference = await nextReference();
      const row = await Invoice.create({ ...normalized, reference, status: "draft", createdBy: actorId(userId), updatedBy: actorId(userId), workflowHistory: [{ status: "draft", comment: "Invoice created.", performedBy: actorId(userId) }] });
      return toPublic(row);
    } catch (e) {
      if (e?.code !== 11000 || text(payload?.reference)) throw e;
      reference = "";
    }
  }
  throw new InvoiceServiceError("Unable to generate a unique invoice reference.", { code: "INVOICE_REFERENCE_COLLISION", statusCode: 409 });
}

export async function updateInvoice({ id, payload, userId }) {
  const row = await Invoice.findById(oid(id, "invoice ID"));
  if (!row) throw new InvoiceServiceError("Invoice not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
  if (!["draft", "rejected"].includes(row.status)) throw new InvoiceServiceError("Only draft or rejected invoices can be edited.", { code: "INVOICE_NOT_EDITABLE", statusCode: 409 });
  const normalized = await buildPayload(payload, { existing: row.toObject(), userId, partial: false });
  Object.assign(row, normalized, { status: "draft", rejectionRemarks: "", updatedBy: actorId(userId) });
  row.workflowHistory.push({ status: "draft", comment: "Invoice updated and returned to draft.", performedBy: actorId(userId) });
  await row.save(); return toPublic(row);
}

async function transition(id, from, to, { userId, comment = "" } = {}) {
  const oidValue = oid(id, "invoice ID");
  const row = await Invoice.findOneAndUpdate({ _id: oidValue, status: from }, { $set: { status: to, updatedBy: actorId(userId), ...(to === "rejected" ? { rejectionRemarks: text(comment) } : {}) }, $push: { workflowHistory: { status: to, comment: text(comment), performedBy: actorId(userId), performedAt: new Date() } } }, { new: true }).lean();
  if (!row) {
    const current = await Invoice.findById(oidValue).select("status").lean();
    if (!current) throw new InvoiceServiceError("Invoice not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
    throw new InvoiceServiceError(`Invoice cannot move from ${statusLabel(current.status)} to ${statusLabel(to)}.`, { code: "INVOICE_INVALID_TRANSITION", statusCode: 409, details: { currentStatus: current.status, targetStatus: to } });
  }
  return toPublic(row);
}

export const submitInvoice = ({ id, userId, comment }) => transition(id, "draft", "submitted", { userId, comment: comment || "Invoice submitted for approval." });
export const approveInvoice = ({ id, userId, comment }) => transition(id, "submitted", "approved", { userId, comment: comment || "Invoice approved." });
export const rejectInvoice = ({ id, userId, comment }) => transition(id, "submitted", "rejected", { userId, comment: comment || "Invoice rejected." });

export async function markInvoicePaid({ id, payload, userId, files = [] }) {
  const invoiceId = oid(id, "invoice ID");
  const amount = num(payload?.amount, "Payment amount", { min: 0.01 });
  const transactionRefId = text(payload?.transactionRefId);
  if (!transactionRefId) throw new InvoiceServiceError("Transaction reference is required.", { code: "PAYMENT_TRANSACTION_REQUIRED", statusCode: 422 });
  const paymentDate = date(payload?.paymentDate, "Payment date");
  const current = await Invoice.findOne({ _id: invoiceId, status: "approved" }).select("totalAmount").lean();
  if (!current) throw new InvoiceServiceError("Only approved invoices can be marked as paid.", { code: "INVOICE_PAYMENT_NOT_ALLOWED", statusCode: 409 });
  if (Math.abs(amount - Number(current.totalAmount || 0)) > 0.01) throw new InvoiceServiceError("Payment amount must equal the full invoice total. Partial payments are managed through the Payments module.", { code: "PAYMENT_MUST_MATCH_INVOICE_TOTAL", statusCode: 422 });

  const documents = [];
  for (const file of Array.isArray(files) ? files.slice(0, 10) : []) {
    if (!file?.buffer?.length) continue;
    const originalName = sanitizeOriginalName(file.originalname || "payment-proof");
    const filename = `${cryptoSafePrefix(id)}-payment-${Date.now()}-${sanitizeStorageFilename(originalName)}`;
    const stored = await saveBuffer({ buffer: file.buffer, context: "invoices", filename, overwrite: false });
    documents.push({ originalName, storageKey: stored.storageKey, mimeType: file.mimetype, size: file.size || stored.size, checksum: stored.checksum, uploadedAt: new Date(), uploadedBy: actorId(userId) });
  }
  if (!documents.length) throw new InvoiceServiceError("At least one payment proof document is required.", { code: "PAYMENT_PROOF_REQUIRED", statusCode: 422 });

  const row = await Invoice.findOneAndUpdate({ _id: invoiceId, status: "approved" }, { $set: { status: "paid", updatedBy: actorId(userId), payment: { amount, transactionRefId, paymentDate, notes: text(payload?.notes), documents, recordedBy: actorId(userId), recordedAt: new Date() } }, $push: { workflowHistory: { status: "paid", comment: `Payment recorded. ${transactionRefId}`, performedBy: actorId(userId), performedAt: new Date() } } }, { new: true }).lean();
  if (!row) throw new InvoiceServiceError("Invoice status changed before payment could be recorded.", { code: "INVOICE_CONCURRENT_UPDATE", statusCode: 409 });
  return toPublic(row);
}

export async function attachInvoiceDocument({ id, file, userId }) {
  if (!file?.buffer?.length) throw new InvoiceServiceError("Invoice document is required.", { code: "INVOICE_DOCUMENT_REQUIRED", statusCode: 422 });
  const allowed = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp"]);
  if (!allowed.has(String(file.mimetype || "").toLowerCase())) throw new InvoiceServiceError("Only PDF or image invoice documents are allowed.", { code: "INVOICE_DOCUMENT_TYPE_NOT_ALLOWED", statusCode: 422 });
  const invoice = await Invoice.findOne({ _id: oid(id, "invoice ID"), status: { $in: ["draft", "rejected"] } }).select("_id").lean();
  if (!invoice) throw new InvoiceServiceError("Invoice document can only be attached to a draft or rejected invoice.", { code: "INVOICE_DOCUMENT_NOT_ALLOWED", statusCode: 409 });
  const originalName = sanitizeOriginalName(file.originalname || "invoice-upload");
  const filename = `${cryptoSafePrefix(id)}-${Date.now()}-${sanitizeStorageFilename(originalName)}`;
  const stored = await saveBuffer({ buffer: file.buffer, context: "invoices", filename, overwrite: false });
  const document = { originalName, storageKey: stored.storageKey, mimeType: file.mimetype, size: file.size || stored.size, checksum: stored.checksum, uploadedAt: new Date(), uploadedBy: actorId(userId) };
  const row = await Invoice.findOneAndUpdate({ _id: invoice._id, status: { $in: ["draft", "rejected"] } }, { $set: { invoiceDocument: document, updatedBy: actorId(userId) } }, { new: true }).lean();
  if (!row) throw new InvoiceServiceError("Invoice changed before document attachment completed.", { code: "INVOICE_CONCURRENT_UPDATE", statusCode: 409 });
  return toPublic(row);
}
function cryptoSafePrefix(id) { return text(id).replace(/[^a-zA-Z0-9_-]/g, "").slice(-24) || "invoice"; }

export async function deleteInvoice({ id }) {
  const row = await Invoice.findById(oid(id, "invoice ID"));
  if (!row) throw new InvoiceServiceError("Invoice not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
  if (!["draft", "rejected"].includes(row.status)) throw new InvoiceServiceError("Only draft or rejected invoices can be deleted.", { code: "INVOICE_NOT_DELETABLE", statusCode: 409 });
  await Invoice.deleteOne({ _id: row._id });
  return { id: String(row._id), deleted: true };
}

export default { listInvoices, getInvoice, listInvoiceEligibleQuotations, createInvoice, updateInvoice, submitInvoice, approveInvoice, rejectInvoice, markInvoicePaid, attachInvoiceDocument, deleteInvoice };
