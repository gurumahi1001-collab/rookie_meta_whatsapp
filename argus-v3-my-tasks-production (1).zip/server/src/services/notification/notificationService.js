import mongoose from "mongoose";
import Notification from "../../models/Notification.js";
import Role from "../../models/Role.js";
import User from "../../models/User.js";

export class NotificationServiceError extends Error {
    constructor(message, { code = "NOTIFICATION_ERROR", statusCode = 400, details = null } = {}) {
        super(message);
        this.name = "NotificationServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, NotificationServiceError);
    }
}

function objectId(id, field = "id") {
    const value = String(id ?? "").trim();
    if (!mongoose.Types.ObjectId.isValid(value)) {
        throw new NotificationServiceError(`Invalid ${field}.`, {
            code: "INVALID_IDENTIFIER",
            statusCode: 400,
            details: { field },
        });
    }
    return new mongoose.Types.ObjectId(value);
}

export async function createNotification({
    recipientId,
    eventType,
    title,
    message,
    payload = null,
}) {
    const row = await Notification.create({
        recipientId: objectId(recipientId, "recipientId"),
        eventType: String(eventType || "").trim(),
        title: String(title || "").trim(),
        message: String(message || "").trim(),
        payload,
    });

    return row.toSafeJSON();
}

export async function notifyWorkspaceOwners({
    eventType,
    title,
    message,
    payload = null,
    excludeUserId = null,
}) {
    const ownerRoles = await Role.find({
        ownerRole: true,
        active: true,
    }).select("_id").lean();

    const roleIds = ownerRoles.map((role) => role._id);
    if (!roleIds.length) return [];

    const query = {
        roleId: { $in: roleIds },
        userType: { $in: ["admin", "internal"] },
        status: "active",
    };

    if (excludeUserId && mongoose.Types.ObjectId.isValid(String(excludeUserId))) {
        query._id = { $ne: objectId(excludeUserId, "excludeUserId") };
    }

    const owners = await User.find(query).select("_id").lean();

    if (!owners.length) return [];

    const rows = await Notification.insertMany(
        owners.map((owner) => ({
            recipientId: owner._id,
            eventType,
            title,
            message,
            payload,
        })),
    );

    return rows.map((row) => row.toSafeJSON());
}

export async function listNotifications({ recipientId, unreadOnly = false, limit = 20 } = {}) {
    const safeLimit = Math.min(100, Math.max(1, Number(limit) || 20));
    const query = { recipientId: objectId(recipientId, "recipientId") };

    if (unreadOnly) query.readAt = null;

    const [rows, unreadCount] = await Promise.all([
        Notification.find(query)
            .sort({ createdAt: -1, _id: -1 })
            .limit(safeLimit),
        Notification.countDocuments({
            recipientId: query.recipientId,
            readAt: null,
        }),
    ]);

    return {
        data: rows.map((row) => row.toSafeJSON()),
        unreadCount,
    };
}

export async function markNotificationRead({ id, recipientId }) {
    const row = await Notification.findOneAndUpdate(
        {
            _id: objectId(id),
            recipientId: objectId(recipientId, "recipientId"),
        },
        {
            $set: { readAt: new Date() },
        },
        { new: true },
    );

    if (!row) {
        throw new NotificationServiceError("Notification not found.", {
            code: "NOTIFICATION_NOT_FOUND",
            statusCode: 404,
        });
    }

    return row.toSafeJSON();
}

export async function markAllNotificationsRead({ recipientId }) {
    const result = await Notification.updateMany(
        {
            recipientId: objectId(recipientId, "recipientId"),
            readAt: null,
        },
        {
            $set: { readAt: new Date() },
        },
    );

    return {
        modifiedCount: Number(result.modifiedCount || 0),
    };
}
