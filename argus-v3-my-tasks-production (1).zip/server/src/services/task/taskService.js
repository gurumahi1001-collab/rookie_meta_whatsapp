import crypto from "node:crypto";
import mongoose from "mongoose";
import Task, { TASK_PRIORITIES, TASK_STATUSES } from "../../models/Task.js";
import Project from "../../models/Project.js";
import User from "../../models/User.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";

export class TaskServiceError extends Error {
    constructor(message, { code = "TASK_ERROR", statusCode = 400, details } = {}) { super(message); this.name = "TaskServiceError"; this.code = code; this.statusCode = statusCode; this.details = details; }
}

const text = (v) => String(v ?? "").trim();
const idOf = (v) => text(v);
function objectId(v) { if (!mongoose.isValidObjectId(v)) throw new TaskServiceError("Invalid task identifier.", { code: "INVALID_TASK_ID", statusCode: 400 }); return new mongoose.Types.ObjectId(String(v)); }
function userId(v) { return v && mongoose.isValidObjectId(v) ? new mongoose.Types.ObjectId(String(v)) : null; }
function num(v, name, { min = 0, max = Number.POSITIVE_INFINITY } = {}) { const n = Number(v ?? 0); if (!Number.isFinite(n) || n < min || n > max) throw new TaskServiceError(`Invalid ${name}.`, { code: `INVALID_${name.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 }); return n; }
function date(v, name, required = true) { if (!v && !required) return null; const d = new Date(v); if (Number.isNaN(d.getTime())) throw new TaskServiceError(`Invalid ${name}.`, { code: `INVALID_${name.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 }); return d; }
function status(v, fallback = "pending") { const raw = text(v).toLowerCase().replace(/\s+/g, "_"); const map = { "in_progress":"in_progress", "inprogress":"in_progress", "on_hold":"on_hold", "onhold":"on_hold", "due_date":"due_date", pending:"pending", completed:"completed" }; const value = map[raw] || fallback; if (!TASK_STATUSES.includes(value)) throw new TaskServiceError("Invalid task status.", { code: "INVALID_TASK_STATUS", statusCode: 422, details: { allowed: TASK_STATUSES } }); return value; }
function priority(v, fallback = "medium") { const raw = text(v).toLowerCase(); const value = TASK_PRIORITIES.includes(raw) ? raw : fallback; if (!TASK_PRIORITIES.includes(value)) throw new TaskServiceError("Invalid task priority.", { code: "INVALID_TASK_PRIORITY", statusCode: 422 }); return value; }

async function nextReference() {
    const year = new Date().getFullYear();
    const key = `task:${year}`;
    const row = await MasterRateSequence.findOneAndUpdate({ _id: key }, { $inc: { value: 1 } }, { new: true, upsert: true, setDefaultsOnInsert: true });
    return `TSK-${year}-${String(row.value).padStart(5, "0")}`;
}

async function resolveProject(projectId) {
    if (!projectId || !mongoose.isValidObjectId(projectId)) throw new TaskServiceError("A valid project is required.", { code: "TASK_PROJECT_REQUIRED", statusCode: 422 });
    const project = await Project.findById(projectId).select("_id reference projectName status phases").lean();
    if (!project) throw new TaskServiceError("Project not found.", { code: "TASK_PROJECT_NOT_FOUND", statusCode: 404 });
    if (["completed", "closed"].includes(project.status)) throw new TaskServiceError("Tasks cannot be created for completed or closed projects.", { code: "TASK_PROJECT_CLOSED", statusCode: 409 });
    const phases = Array.isArray(project.phases) ? project.phases.map((p) => p.name).filter(Boolean) : [];
    return { project, phases };
}
async function resolveStaff(ids) {
    const clean = [...new Set((Array.isArray(ids) ? ids : []).map(idOf).filter(Boolean))];
    if (!clean.length) throw new TaskServiceError("At least one active staff member is required.", { code: "TASK_STAFF_REQUIRED", statusCode: 422 });
    if (clean.some((id) => !mongoose.isValidObjectId(id))) throw new TaskServiceError("One or more staff identifiers are invalid.", { code: "INVALID_TASK_STAFF_ID", statusCode: 422 });
    const rows = await User.find({ _id: { $in: clean }, status: "active", userType: { $in: ["admin", "internal"] } }).select("_id displayName email hourlyRate status userType").lean();
    const byId = new Map(rows.map((r) => [String(r._id), r]));
    if (rows.length !== clean.length) throw new TaskServiceError("One or more selected staff members are not active internal users.", { code: "TASK_STAFF_NOT_ACTIVE", statusCode: 422 });
    return clean.map((id) => { const r = byId.get(id); return { userId: r._id, name: r.displayName || r.email, email: r.email || "", rate: Number(r.hourlyRate || 0), hours: 0, amount: 0 }; });
}
function normalizeNested(source) {
    const workLogs = Array.isArray(source.workLogs) ? source.workLogs.slice(-500).map((x) => ({ id: text(x.id) || crypto.randomUUID(), startedAt: date(x.startedAt, "work log start"), stoppedAt: date(x.stoppedAt, "work log stop"), duration: num(x.duration, "work log duration") })) : [];
    const materials = Array.isArray(source.materials) ? source.materials.slice(-500).map((x) => ({ id: text(x.id) || crypto.randomUUID(), name: text(x.name), unitCost: num(x.unitCost, "material unit cost"), quantity: num(x.quantity, "material quantity") })).filter((x) => x.name) : [];
    const otherExpenses = Array.isArray(source.otherExpenses) ? source.otherExpenses.slice(-500).map((x) => ({ id: text(x.id) || crypto.randomUUID(), name: text(x.name), amount: num(x.amount, "expense amount"), description: text(x.description) })).filter((x) => x.name) : [];
    const conversations = Array.isArray(source.conversations) ? source.conversations.slice(-500).map((x) => ({ id: text(x.id) || crypto.randomUUID(), type: ["update", "question", "image"].includes(x.type) ? x.type : "update", text: text(x.text), imageStorageKey: text(x.imageStorageKey), createdAt: date(x.createdAt, "conversation createdAt", false) || new Date() })).filter((x) => x.text || x.imageStorageKey) : [];
    return { workLogs, materials, otherExpenses, conversations };
}
function toRecord(row) {
    const mapStatus = { pending:"Pending", in_progress:"In Progress", on_hold:"On Hold", due_date:"Due Date", completed:"Completed" };
    const mapPriority = { low:"Low", medium:"Medium", high:"High", urgent:"Urgent" };
    return {
        id: String(row._id), reference: row.reference, title: row.title, name: row.title, description: row.description || "",
        projectId: String(row.project.projectId), project: row.project.name, projectReference: row.project.reference || "", phase: row.phase || "",
        Assignstaff: (row.assignStaff || []).map((s) => ({ id: String(s.userId), name: s.name, email: s.email || "", rate: Number(s.rate || 0), hours: Number(s.hours || 0), amount: Number(s.amount || 0) })),
        startDate: row.startDate ? new Date(row.startDate).toISOString().slice(0,10) : "", dueDate: row.dueDate ? new Date(row.dueDate).toISOString().slice(0,10) : "",
        priority: mapPriority[row.priority] || "Medium", status: mapStatus[row.status] || "Pending", progress: Number(row.progress || 0), estimatedHours: Number(row.estimatedHours || 0),
        timerStartedAt: row.timerStartedAt ? new Date(row.timerStartedAt).toISOString() : null, totalWorkedSeconds: Number(row.totalWorkedSeconds || 0), isTimerRunning: Boolean(row.timerStartedAt),
        workLogs: (row.workLogs || []).map((x) => ({ id: x.id, startedAt: new Date(x.startedAt).toISOString(), stoppedAt: new Date(x.stoppedAt).toISOString(), duration: Number(x.duration || 0) })),
        materials: row.materials || [], otherExpenses: row.otherExpenses || [], conversations: (row.conversations || []).map((x) => ({ ...x, createdAt: new Date(x.createdAt).toISOString(), id: x.id, imageStorageKey: x.imageStorageKey || "" })),
        createdAt: row.createdAt, updatedAt: row.updatedAt,
    };
}

function payloadStaffIds(source) { const list = Array.isArray(source.Assignstaff) ? source.Assignstaff : (Array.isArray(source.assignStaff) ? source.assignStaff : []); return list.map((x) => typeof x === "string" ? x : x?.id || x?.userId).filter(Boolean); }

export async function listTasks({ search, status: statusFilter, priority: priorityFilter, assigneeId, projectId, page = 1, limit = 50 } = {}) {
    const p = Math.max(1, Number(page) || 1), l = Math.min(250, Math.max(1, Number(limit) || 50));
    const query = {};
    const q = text(search); if (q) query.$or = [{ title: { $regex: q, $options: "i" } }, { reference: { $regex: q, $options: "i" } }, { description: { $regex: q, $options: "i" } }, { "project.name": { $regex: q, $options: "i" } }, { phase: { $regex: q, $options: "i" } }, { "assignStaff.name": { $regex: q, $options: "i" } }];
    if (statusFilter) query.status = status(statusFilter);
    if (priorityFilter) query.priority = priority(priorityFilter);
    if (assigneeId && mongoose.isValidObjectId(assigneeId)) query["assignStaff.userId"] = new mongoose.Types.ObjectId(assigneeId);
    if (projectId && mongoose.isValidObjectId(projectId)) query["project.projectId"] = new mongoose.Types.ObjectId(projectId);
    const [rows, total] = await Promise.all([Task.find(query).sort({ dueDate: 1, createdAt: -1 }).skip((p-1)*l).limit(l).lean(), Task.countDocuments(query)]);
    return { data: rows.map(toRecord), pagination: { page:p, limit:l, total, totalPages: Math.ceil(total/l) } };
}
export async function getTask(id) { const row = await Task.findById(objectId(id)).lean(); if (!row) throw new TaskServiceError("Task not found.",{code:"TASK_NOT_FOUND",statusCode:404}); return toRecord(row); }
export async function listTaskAssignees() { const rows = await User.find({ status:"active", userType:{ $in:["admin","internal"] } }).select("_id displayName email hourlyRate").sort({displayName:1,email:1}).limit(500).lean(); return rows.map(r=>({id:String(r._id),name:r.displayName||r.email,email:r.email||"",hourlyRate:Number(r.hourlyRate||0)})).filter(r=>r.name); }
export async function listTaskProjects() { const rows = await Project.find({ status:{ $nin:["completed","closed"] } }).select("_id reference projectName phases status").sort({projectName:1}).limit(500).lean(); return rows.map(r=>({id:String(r._id),reference:r.reference,name:r.projectName,status:r.status,phases:(r.phases||[]).map(p=>p.name).filter(Boolean)})); }

export async function createTask({ payload, actorId }) {
    const source = payload || {}; const title=text(source.title||source.name), description=text(source.description); if(title.length<2) throw new TaskServiceError("Task title is required.",{code:"TASK_TITLE_REQUIRED",statusCode:422}); if(!description) throw new TaskServiceError("Task description is required.",{code:"TASK_DESCRIPTION_REQUIRED",statusCode:422});
    const startDate=date(source.startDate,"start date"), dueDate=date(source.dueDate,"due date"); if(dueDate<startDate) throw new TaskServiceError("Due date cannot be earlier than start date.",{code:"TASK_INVALID_DATE_RANGE",statusCode:422});
    const {project, phases}=await resolveProject(source.projectId); const phase=text(source.phase); if(phase && phases.length && !phases.includes(phase)) throw new TaskServiceError("Selected phase does not belong to the selected project.",{code:"TASK_PHASE_INVALID",statusCode:422});
    const staff=await resolveStaff(payloadStaffIds(source)); const progress=num(source.progress,"progress",{min:0,max:100}); const nested=normalizeNested(source); const task=await Task.create({reference: await nextReference(),title,description,project:{projectId:project._id,reference:project.reference,name:project.projectName},phase,assignStaff:staff,startDate,dueDate,priority:priority(source.priority),status:status(source.status),progress: status(source.status)==="completed"?100:progress,estimatedHours:num(source.estimatedHours,"estimated hours"),...nested,createdBy:userId(actorId),updatedBy:userId(actorId)}); return toRecord(task.toObject());
}
export async function updateTask({ id, payload, actorId }) {
    const row=await Task.findById(objectId(id)); if(!row) throw new TaskServiceError("Task not found.",{code:"TASK_NOT_FOUND",statusCode:404}); const source=payload||{};
    if(Object.prototype.hasOwnProperty.call(source,"title")||Object.prototype.hasOwnProperty.call(source,"name")){const title=text(source.title||source.name);if(title.length<2)throw new TaskServiceError("Task title is required.",{code:"TASK_TITLE_REQUIRED",statusCode:422});row.title=title;}
    if(Object.prototype.hasOwnProperty.call(source,"description")) row.description=text(source.description);
    if(Object.prototype.hasOwnProperty.call(source,"projectId")){const {project}=await resolveProject(source.projectId);row.project={projectId:project._id,reference:project.reference,name:project.projectName};}
    if(Object.prototype.hasOwnProperty.call(source,"phase")){const phase=text(source.phase); const phaseProject=await Project.findById(row.project.projectId).select("phases").lean(); const phases=Array.isArray(phaseProject?.phases)?phaseProject.phases.map(p=>p.name):[]; if(phase&&phases.length&&!phases.includes(phase))throw new TaskServiceError("Selected phase does not belong to the selected project.",{code:"TASK_PHASE_INVALID",statusCode:422}); row.phase=phase;}
    if(Object.prototype.hasOwnProperty.call(source,"startDate"))row.startDate=date(source.startDate,"start date"); if(Object.prototype.hasOwnProperty.call(source,"dueDate"))row.dueDate=date(source.dueDate,"due date"); if(row.dueDate<row.startDate)throw new TaskServiceError("Due date cannot be earlier than start date.",{code:"TASK_INVALID_DATE_RANGE",statusCode:422});
    if(Object.prototype.hasOwnProperty.call(source,"priority"))row.priority=priority(source.priority,row.priority); if(Object.prototype.hasOwnProperty.call(source,"status"))row.status=status(source.status,row.status); if(row.status==="completed")row.progress=100; else if(Object.prototype.hasOwnProperty.call(source,"progress"))row.progress=num(source.progress,"progress",{min:0,max:100});
    if(Object.prototype.hasOwnProperty.call(source,"estimatedHours"))row.estimatedHours=num(source.estimatedHours,"estimated hours");
    if(Object.prototype.hasOwnProperty.call(source,"Assignstaff")||Object.prototype.hasOwnProperty.call(source,"assignStaff")) row.assignStaff=await resolveStaff(payloadStaffIds(source));
    const nested=normalizeNested(source); for(const key of ["workLogs","materials","otherExpenses","conversations"]) if(Object.prototype.hasOwnProperty.call(source,key)) row[key]=nested[key];
    if(Object.prototype.hasOwnProperty.call(source,"timerStartedAt")) row.timerStartedAt=source.timerStartedAt?date(source.timerStartedAt,"timer start"):null; if(Object.prototype.hasOwnProperty.call(source,"totalWorkedSeconds"))row.totalWorkedSeconds=num(source.totalWorkedSeconds,"worked seconds"); row.updatedBy=userId(actorId); await row.save(); return toRecord(row.toObject());
}
export async function deleteTask(id){const row=await Task.findById(objectId(id));if(!row)throw new TaskServiceError("Task not found.",{code:"TASK_NOT_FOUND",statusCode:404});if(["in_progress","completed"].includes(row.status))throw new TaskServiceError("In-progress or completed tasks cannot be deleted.",{code:"TASK_NOT_DELETABLE",statusCode:409});await Task.deleteOne({_id:row._id});return{id:String(row._id),reference:row.reference,deleted:true};}
export default { listTasks,getTask,listTaskAssignees,listTaskProjects,createTask,updateTask,deleteTask };
