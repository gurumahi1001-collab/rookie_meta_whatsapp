import crypto from "node:crypto";
import { mailer, emailConfig } from "../../config/email.js";
import env from "../../config/env.js";

export class EmailServiceError extends Error {
    constructor(message, { code = "EMAIL_ERROR", statusCode = 503, details = null } = {}) {
        super(message);
        this.name = "EmailServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, EmailServiceError);
    }
}

function text(value) {
    return String(value ?? "").trim();
}

function escapeHtml(value) {
    return text(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#39;");
}

function vendorPortalUrl() {
    const base = String(env?.cors?.vendorFrontendUrl || "").replace(/\/+$/, "");
    return base ? `${base}/vendor-login` : "/vendor-login";
}

export function generateTemporaryPassword(length = 16) {
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*";
    const bytes = crypto.randomBytes(length);
    let output = "";
    for (let i = 0; i < length; i += 1) {
        output += alphabet[bytes[i] % alphabet.length];
    }
    return output;
}

export async function sendVendorInvitation({
    to,
    vendorName,
    displayName,
    email,
    password = "",
    isTemporaryPassword = true,
    isResend = false,
}) {
    const recipient = text(to).toLowerCase();

    if (!recipient) {
        throw new EmailServiceError("Vendor invitation recipient email is required.", {
            code: "EMAIL_RECIPIENT_REQUIRED",
            statusCode: 422,
        });
    }

    if (!emailConfig.enabled || !mailer) {
        throw new EmailServiceError(
            "Email delivery is not configured. Configure SMTP before sending vendor invitations.",
            {
                code: "EMAIL_NOT_CONFIGURED",
                statusCode: 503,
            },
        );
    }

    const normalizedPassword = text(password);

    if (!normalizedPassword) {
        throw new EmailServiceError(
            "A vendor invitation password is required before an invitation can be sent.",
            {
                code: "EMAIL_PASSWORD_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const safeVendor = escapeHtml(vendorName || "Vendor");
    const safeName = escapeHtml(displayName || "Vendor Admin");
    const safeEmail = escapeHtml(email || recipient);
    const safePassword = escapeHtml(normalizedPassword);
    const passwordLabel = isTemporaryPassword ? "Temporary password" : "Password";
    const passwordLine = `${passwordLabel}: ${normalizedPassword}`;
    const safePasswordLine =
        `<p style="margin:0"><strong>${escapeHtml(passwordLabel)}:</strong> ${safePassword}</p>`;
    const loginUrl = vendorPortalUrl();

    const subject = isResend
        ? `ARGUS Vendor Portal access — password updated — ${vendorName || "Vendor"}`
        : `ARGUS Vendor Portal invitation — ${vendorName || "Vendor"}`;

    const accountMessage = isResend
        ? `Your vendor portal access for ${vendorName || "your company"} has been resent. A new permanent portal password has been issued below because the existing password is stored securely and cannot be recovered as plaintext.`
        : `Your vendor portal account for ${vendorName || "your company"} has been approved.`;

    const passwordNotice = isTemporaryPassword
        ? "Use this temporary password for your first sign-in and follow the portal's password-change policy."
        : isResend
            ? "This password is permanent until you change it from Vendor User Management."
            : "This password is the permanent vendor portal password.";

    const textBody = [
        `Hello ${displayName || "Vendor Admin"},`,
        "",
        accountMessage,
        "",
        `Sign in: ${loginUrl}`,
        `Email: ${email || recipient}`,
        passwordLine,
        passwordNotice,
        "",
        "On your first login, you must review and accept the current Telecom Terms & Conditions before accessing the vendor portal.",
        "",
        "Please keep this invitation confidential.",
    ].join("\n");

    const htmlBody = `
        <div style="font-family:Arial,Helvetica,sans-serif;line-height:1.6;color:#1e293b">
            <h2 style="margin:0 0 16px">ARGUS Vendor Portal Invitation</h2>
            <p>Hello <strong>${safeName}</strong>,</p>
            <p>${escapeHtml(accountMessage)}</p>
            <div style="margin:20px 0;padding:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px">
                <p style="margin:0 0 8px"><strong>Sign in:</strong> <a href="${loginUrl}">${loginUrl}</a></p>
                <p style="margin:0 0 8px"><strong>Email:</strong> ${safeEmail}</p>
                ${safePasswordLine}
                <p style="margin:8px 0 0;color:#475569;font-size:13px">${escapeHtml(passwordNotice)}</p>
            </div>
            <p>On your first login, you must review and accept the current Telecom Terms &amp; Conditions before accessing the vendor portal.</p>
            <p style="font-size:12px;color:#64748b">Please keep this invitation confidential.</p>
        </div>
    `;

    const result = await mailer.sendMail({
        from: {
            name: emailConfig.from.name,
            address: emailConfig.from.email,
        },
        to: recipient,
        subject,
        text: textBody,
        html: htmlBody,
    });

    return {
        messageId: result.messageId || null,
        accepted: Array.isArray(result.accepted) ? result.accepted : [],
        rejected: Array.isArray(result.rejected) ? result.rejected : [],
    };
}
