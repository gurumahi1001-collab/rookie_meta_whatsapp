import mongoose from "mongoose";

import BOQ, { BOQ_STATUSES } from "../../models/BOQ.js";
import BOQLine from "../../models/BOQLine.js";
import MarketRateItem from "../../models/MarketRateItem.js";
import Vendor from "../../models/Vendor.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 250;
const CONTINGENCY_PERCENTAGE = 10;

export class BOQServiceError extends Error {
    constructor(message, { code = "BOQ_ERROR", statusCode = 400, details } = {}) {
        super(message);
        this.name = "BOQServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, BOQServiceError);
    }
}

const text = (value) => String(value ?? "").trim();

function idOf(value, fieldName = "BOQ ID") {
    const normalized = text(value);
    if (!mongoose.isValidObjectId(normalized)) {
        throw new BOQServiceError(`Invalid ${fieldName}.`, {
            code: `INVALID_${fieldName.toUpperCase().replace(/\s+/g, "_")}`,
            statusCode: 400,
        });
    }
    return new mongoose.Types.ObjectId(normalized);
}

function userIdOf(value, fieldName = "user ID") {
    const normalized = text(value);
    if (!normalized) return null;
    return idOf(normalized, fieldName);
}

function normalizePage(value) {
    const parsed = Number.parseInt(String(value ?? ""), 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_PAGE;
}

function normalizeLimit(value) {
    const parsed = Number.parseInt(String(value ?? ""), 10);
    if (!Number.isFinite(parsed) || parsed < 1) return DEFAULT_LIMIT;
    return Math.min(MAX_LIMIT, parsed);
}

function escapeRegex(value) {
    return text(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function parseNumber(value, fieldName, { min = 0, max = Number.POSITIVE_INFINITY, optional = false } = {}) {
    if (optional && (value === undefined || value === null || value === "")) return null;
    const number = Number(value);
    if (!Number.isFinite(number) || number < min || number > max) {
        throw new BOQServiceError(
            `${fieldName} must be a valid number between ${min} and ${max === Number.POSITIVE_INFINITY ? "infinity" : max}.`,
            {
                code: `INVALID_${fieldName.toUpperCase().replace(/\s+/g, "_")}`,
                statusCode: 422,
                details: { field: fieldName },
            },
        );
    }
    return number;
}

function parseDate(value, fieldName, { optional = false } = {}) {
    if (optional && (value === undefined || value === null || value === "")) return null;
    const raw = text(value);
    if (!raw) {
        if (optional) return null;
        throw new BOQServiceError(`${fieldName} is required.`, {
            code: `${fieldName.toUpperCase().replace(/\s+/g, "_")}_REQUIRED`,
            statusCode: 422,
        });
    }

    const date = /^\d{4}-\d{2}-\d{2}$/.test(raw)
        ? new Date(`${raw}T00:00:00.000Z`)
        : new Date(raw);

    if (Number.isNaN(date.getTime())) {
        throw new BOQServiceError(`${fieldName} is invalid.`, {
            code: `INVALID_${fieldName.toUpperCase().replace(/\s+/g, "_")}`,
            statusCode: 422,
            details: { field: fieldName },
        });
    }
    return date;
}

function formatDateOnly(value) {
    if (!value) return "";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "" : date.toISOString().slice(0, 10);
}

function calculateTotals(lines) {
    const subtotal = lines.reduce(
        (total, line) => total + Number(line.quantity) * Number(line.rate),
        0,
    );
    const contingencyAmount = subtotal * (CONTINGENCY_PERCENTAGE / 100);
    return {
        subtotal: Number(subtotal.toFixed(2)),
        contingencyPercentage: CONTINGENCY_PERCENTAGE,
        contingencyAmount: Number(contingencyAmount.toFixed(2)),
        grandTotal: Number((subtotal + contingencyAmount).toFixed(2)),
        itemCount: lines.length,
    };
}

function normalizeLine(input, index) {
    const description = text(input?.description);
    const unit = text(input?.unit);
    if (!description) {
        throw new BOQServiceError("BOQ line description is required.", {
            code: "BOQ_LINE_DESCRIPTION_REQUIRED",
            statusCode: 422,
            details: { index },
        });
    }
    if (!unit) {
        throw new BOQServiceError("BOQ line unit is required.", {
            code: "BOQ_LINE_UNIT_REQUIRED",
            statusCode: 422,
            details: { index },
        });
    }

    const quantity = parseNumber(input?.quantity, "quantity", { min: 0.0001 });
    const rate = parseNumber(input?.rate, "rate", { min: 0 });
    const rateItemId = text(input?.rateItemId);

    return {
        rateItemId: rateItemId ? idOf(rateItemId, "rate item ID") : null,
        rateCode: text(input?.rateCode).toUpperCase(),
        customItemFlag: Boolean(input?.customItemFlag) || !rateItemId,
        categoryType: text(input?.categoryType),
        category: text(input?.category),
        module: text(input?.module),
        description,
        unit,
        quantity,
        rate,
        lineTotal: Number((quantity * rate).toFixed(2)),
        sortOrder: Number.isFinite(Number(input?.sortOrder)) ? Number(input.sortOrder) : index,
    };
}

function normalizeVendorInput(vendors) {
    if (!Array.isArray(vendors)) return [];

    const deduped = new Map();
    for (const vendor of vendors) {
        const vendorId = typeof vendor === "string" ? vendor : vendor?.vendorId || vendor?.id;
        const normalizedId = text(vendorId);
        if (!normalizedId) continue;
        deduped.set(normalizedId, {
            vendorId: normalizedId,
            name: text(vendor?.name),
        });
    }

    for (const entry of deduped.values()) {
        if (!mongoose.isValidObjectId(entry.vendorId)) {
            throw new BOQServiceError("One or more vendor identifiers are invalid.", {
                code: "INVALID_BOQ_VENDOR_ID",
                statusCode: 422,
            });
        }
    }

    return [...deduped.values()];
}

async function validateReferences(lines, vendors, formTemplateId) {
    const rateIds = [
        ...new Set(
            lines
                .filter((line) => line.rateItemId)
                .map((line) => String(line.rateItemId)),
        ),
    ];

    if (rateIds.length) {
        const activeRates = await MarketRateItem.find({
            _id: {
                $in: rateIds.map((value) => new mongoose.Types.ObjectId(value)),
            },
            status: "active",
        })
            .select("_id code categoryType category subcategory module description unit standardRate rate")
            .lean();

        const activeSet = new Set(activeRates.map((row) => String(row._id)));
        const missing = rateIds.filter((value) => !activeSet.has(value));
        if (missing.length) {
            throw new BOQServiceError(
                "One or more selected master rates are inactive or unavailable.",
                {
                    code: "BOQ_RATE_ITEM_UNAVAILABLE",
                    statusCode: 422,
                    details: { rateItemIds: missing },
                },
            );
        }
    }

    const vendorIds = [...new Set(vendors.map((vendor) => String(vendor.vendorId)))];
    const approvedMap = new Map();

    if (vendorIds.length) {
        const approvedVendors = await Vendor.find({
            _id: {
                $in: vendorIds.map((value) => new mongoose.Types.ObjectId(value)),
            },
            accountStatus: "APPROVED",
        })
            .select("_id companyName")
            .lean();

        for (const row of approvedVendors) {
            approvedMap.set(String(row._id), row);
        }

        const missing = vendorIds.filter((value) => !approvedMap.has(value));
        if (missing.length) {
            throw new BOQServiceError(
                "One or more selected vendors are not approved or unavailable.",
                {
                    code: "BOQ_VENDOR_UNAVAILABLE",
                    statusCode: 422,
                    details: { vendorIds: missing },
                },
            );
        }
    }

    if (formTemplateId) {
        const template = await SurveyTemplate.findOne({
            _id: formTemplateId,
            status: "active",
        })
            .select("_id name")
            .lean();

        if (!template) {
            throw new BOQServiceError("Selected form template is inactive or unavailable.", {
                code: "BOQ_FORM_TEMPLATE_UNAVAILABLE",
                statusCode: 422,
                details: { field: "formTemplateId" },
            });
        }
    }

    return approvedMap;
}

function normalizePayload(payload) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
        throw new BOQServiceError("BOQ payload must be a JSON object.", {
            code: "INVALID_BOQ_PAYLOAD",
            statusCode: 400,
        });
    }

    const title = text(payload.title || payload.projectName);
    if (!title) {
        throw new BOQServiceError("BOQ title is required.", {
            code: "BOQ_TITLE_REQUIRED",
            statusCode: 422,
            details: { field: "title" },
        });
    }

    const lineInputs = Array.isArray(payload.lines) ? payload.lines : [];
    const lines = lineInputs.map(normalizeLine);
    const vendors = normalizeVendorInput(payload.vendors);
    const formTemplateId = text(
        payload.formTemplateId ?? payload.formTemplate?.templateId,
    );

    if (formTemplateId && !mongoose.isValidObjectId(formTemplateId)) {
        throw new BOQServiceError("Invalid form template ID.", {
            code: "INVALID_BOQ_FORM_TEMPLATE_ID",
            statusCode: 422,
            details: { field: "formTemplateId" },
        });
    }

    return {
        title,
        reference: text(payload.reference).toUpperCase(),
        boqDate:
            parseDate(payload.boqDate, "BOQ date", { optional: true }) || new Date(),
        responseDueDate: parseDate(payload.responseDueDate, "Response due date", {
            optional: true,
        }),
        projectSiteLocation: text(payload.projectSiteLocation),
        projectValue: parseNumber(payload.projectValue ?? 0, "project value", {
            min: 0,
        }),
        currency: text(payload.currency || "JMD").toUpperCase(),
        siteSurveyReference: text(payload.siteSurveyReference),
        formTemplateId: formTemplateId || null,
        formTemplateName: text(
            payload.formTemplateName ?? payload.formTemplate?.name,
        ),
        vendors,
        lines,
        ...calculateTotals(lines),
    };
}

function dateBefore(left, right) {
    return Boolean(left && right && new Date(left).getTime() < new Date(right).getTime());
}

async function runWithBestAvailablePersistence(work) {
    const topologyType = mongoose.connection.client?.topology?.description?.type;
    const transactionsSupported = Boolean(topologyType && topologyType !== "Single");
    if (!transactionsSupported) return work(null);

    const session = await mongoose.startSession();
    try {
        let result;
        await session.withTransaction(async () => {
            result = await work(session);
        });
        return result;
    } finally {
        await session.endSession();
    }
}

function buildVendorSnapshot(vendors, vendorMap) {
    return vendors.map((vendor) => ({
        vendorId: new mongoose.Types.ObjectId(vendor.vendorId),
        name: vendorMap.get(vendor.vendorId)?.companyName || vendor.name || vendor.vendorId,
    }));
}

async function resolveReference() {
    const year = new Date().getFullYear();
    const prefix = `BOQ-${year}-`;
    const latest = await BOQ.findOne({
        reference: new RegExp(`^${escapeRegex(prefix)}\\d{6}$`, "i"),
    })
        .sort({ reference: -1 })
        .select("reference")
        .lean();
    const current = latest ? Number(String(latest.reference).slice(-6)) : 0;
    return `${prefix}${String(current + 1).padStart(6, "0")}`;
}

function serializeLine(row) {
    return {
        id: String(row?._id || ""),
        rateItemId: row?.rateItemId ? String(row.rateItemId) : null,
        rateCode: row?.rateCode || "",
        customItemFlag: Boolean(row?.customItemFlag),
        categoryType: row?.categoryType || "",
        category: row?.category || "",
        module: row?.module || "",
        description: row?.description || "",
        unit: row?.unit || "",
        quantity: Number(row?.quantity || 0),
        rate: Number(row?.rate || 0),
        lineTotal: Number(row?.lineTotal || 0),
        sortOrder: Number(row?.sortOrder || 0),
    };
}

function serialize(row, lines = []) {
    return {
        id: String(row?._id || ""),
        title: row?.title || "",
        reference: row?.reference || "",
        boqDate: formatDateOnly(row?.boqDate),
        responseDueDate: formatDateOnly(row?.responseDueDate),
        projectSiteLocation: row?.projectSiteLocation || "",
        projectValue: Number(row?.projectValue || 0),
        currency: row?.currency || "JMD",
        siteSurveyReference: row?.siteSurveyReference || "",
        formTemplate: {
            templateId: row?.formTemplate?.templateId
                ? String(row.formTemplate.templateId)
                : null,
            name: row?.formTemplate?.name || "",
        },
        vendors: Array.isArray(row?.vendors)
            ? row.vendors.map((vendor) => ({
                  vendorId: String(vendor.vendorId),
                  id: String(vendor.vendorId),
                  name: vendor.name || "",
              }))
            : [],
        subtotal: Number(row?.subtotal || 0),
        contingencyPercentage: Number(
            row?.contingencyPercentage ?? CONTINGENCY_PERCENTAGE,
        ),
        contingencyAmount: Number(row?.contingencyAmount || 0),
        grandTotal: Number(row?.grandTotal || 0),
        itemCount: Number(row?.itemCount || 0),
        status: row?.status || "draft",
        lockedAt: row?.lockedAt ? new Date(row.lockedAt).toISOString() : null,
        lockedBy: row?.lockedBy ? String(row.lockedBy) : null,
        createdBy: row?.createdBy ? String(row.createdBy) : null,
        updatedBy: row?.updatedBy ? String(row.updatedBy) : null,
        createdAt: row?.createdAt ? new Date(row.createdAt).toISOString() : null,
        updatedAt: row?.updatedAt ? new Date(row.updatedAt).toISOString() : null,
        ...(lines ? { lines: lines.map(serializeLine).sort((a, b) => a.sortOrder - b.sortOrder) } : {}),
    };
}

async function getLinesForBOQ(boqId, { session } = {}) {
    const query = BOQLine.find({ boqId }).sort({ sortOrder: 1, _id: 1 });
    if (session) query.session(session);
    return query.lean();
}

export async function listBOQs({ search = "", status = "", page = 1, limit = DEFAULT_LIMIT } = {}) {
    const normalizedPage = normalizePage(page);
    const normalizedLimit = normalizeLimit(limit);
    const filter = {};
    const normalizedSearch = text(search);

    if (normalizedSearch) {
        const regex = new RegExp(escapeRegex(normalizedSearch), "i");
        filter.$or = [
            { title: regex },
            { reference: regex },
            { projectSiteLocation: regex },
            { siteSurveyReference: regex },
            { "vendors.name": regex },
        ];
    }

    if (text(status)) {
        const normalizedStatus = text(status).toLowerCase();
        if (!BOQ_STATUSES.includes(normalizedStatus)) {
            throw new BOQServiceError("Invalid BOQ status.", {
                code: "INVALID_BOQ_STATUS",
                statusCode: 422,
            });
        }
        filter.status = normalizedStatus;
    }

    const skip = (normalizedPage - 1) * normalizedLimit;
    const [rows, total] = await Promise.all([
        BOQ.find(filter)
            .sort({ updatedAt: -1, _id: -1 })
            .skip(skip)
            .limit(normalizedLimit)
            .lean(),
        BOQ.countDocuments(filter),
    ]);

    return {
        data: rows.map((row) => serialize(row)),
        pagination: {
            page: normalizedPage,
            limit: normalizedLimit,
            total,
            totalPages: Math.ceil(total / normalizedLimit),
        },
    };
}

export async function getBOQ(id, { includeLines = true } = {}) {
    const row = await BOQ.findById(idOf(id));
    if (!row) {
        throw new BOQServiceError("BOQ not found.", {
            code: "BOQ_NOT_FOUND",
            statusCode: 404,
        });
    }
    const lines = includeLines ? await getLinesForBOQ(row._id) : null;
    return serialize(row, lines);
}

async function createOnce({ data, actorId, reference }) {
    const vendorMap = await validateReferences(
        data.lines,
        data.vendors,
        data.formTemplateId ? new mongoose.Types.ObjectId(data.formTemplateId) : null,
    );

    let formTemplateName = data.formTemplateName;
    if (data.formTemplateId) {
        const template = await SurveyTemplate.findById(data.formTemplateId)
            .select("name")
            .lean();
        formTemplateName = template?.name || formTemplateName;
    }

    const snapshotVendors = buildVendorSnapshot(data.vendors, vendorMap);

    return runWithBestAvailablePersistence(async (session) => {
        const createOptions = session ? { session } : undefined;
        const [boq] = await BOQ.create(
            [
                {
                    title: data.title,
                    reference,
                    boqDate: data.boqDate,
                    responseDueDate: data.responseDueDate,
                    projectSiteLocation: data.projectSiteLocation,
                    projectValue: data.projectValue,
                    currency: data.currency,
                    siteSurveyReference: data.siteSurveyReference,
                    formTemplate: {
                        templateId: data.formTemplateId
                            ? new mongoose.Types.ObjectId(data.formTemplateId)
                            : null,
                        name: formTemplateName,
                    },
                    vendors: snapshotVendors,
                    subtotal: data.subtotal,
                    contingencyPercentage: data.contingencyPercentage,
                    contingencyAmount: data.contingencyAmount,
                    grandTotal: data.grandTotal,
                    itemCount: data.itemCount,
                    status: "draft",
                    createdBy: actorId,
                    updatedBy: actorId,
                },
            ],
            createOptions,
        );

        if (data.lines.length) {
            await BOQLine.insertMany(
                data.lines.map((line) => ({ ...line, boqId: boq._id })),
                session ? { session } : undefined,
            );
        }

        return serialize(
            boq,
            await getLinesForBOQ(boq._id, { session }),
        );
    });
}

export async function createBOQ({ payload, userId }) {
    const data = normalizePayload(payload);
    if (dateBefore(data.responseDueDate, data.boqDate)) {
        throw new BOQServiceError("Response due date cannot be before the BOQ date.", {
            code: "INVALID_BOQ_DUE_DATE",
            statusCode: 422,
        });
    }

    const actorId = userIdOf(userId, "createdBy");
    let reference = data.reference || await resolveReference();

    for (let attempt = 0; attempt < 3; attempt += 1) {
        try {
            return await createOnce({ data, actorId, reference });
        } catch (error) {
            if (error?.code !== 11000 || attempt >= 2 || data.reference) throw error;
            reference = await resolveReference();
        }
    }

    throw new BOQServiceError("Unable to create the BOQ.", {
        code: "BOQ_CREATE_FAILED",
        statusCode: 500,
    });
}

export async function updateBOQ({ id, payload, userId }) {
    const boqId = idOf(id);
    const existing = await BOQ.findById(boqId);
    if (!existing) {
        throw new BOQServiceError("BOQ not found.", {
            code: "BOQ_NOT_FOUND",
            statusCode: 404,
        });
    }
    if (existing.status !== "draft") {
        throw new BOQServiceError("Locked BOQs cannot be edited.", {
            code: "BOQ_LOCKED",
            statusCode: 409,
        });
    }

    const data = normalizePayload({ ...payload, reference: existing.reference });
    if (dateBefore(data.responseDueDate, data.boqDate)) {
        throw new BOQServiceError("Response due date cannot be before the BOQ date.", {
            code: "INVALID_BOQ_DUE_DATE",
            statusCode: 422,
        });
    }

    const actorId = userIdOf(userId, "updatedBy");
    const vendorMap = await validateReferences(
        data.lines,
        data.vendors,
        data.formTemplateId ? new mongoose.Types.ObjectId(data.formTemplateId) : null,
    );

    let formTemplateName = data.formTemplateName;
    if (data.formTemplateId) {
        const template = await SurveyTemplate.findById(data.formTemplateId)
            .select("name")
            .lean();
        formTemplateName = template?.name || formTemplateName;
    }

    const updated = await runWithBestAvailablePersistence(async (session) => {
        const options = session ? { session } : undefined;
        existing.title = data.title;
        existing.boqDate = data.boqDate;
        existing.responseDueDate = data.responseDueDate;
        existing.projectSiteLocation = data.projectSiteLocation;
        existing.projectValue = data.projectValue;
        existing.currency = data.currency;
        existing.siteSurveyReference = data.siteSurveyReference;
        existing.formTemplate = {
            templateId: data.formTemplateId
                ? new mongoose.Types.ObjectId(data.formTemplateId)
                : null,
            name: formTemplateName,
        };
        existing.vendors = buildVendorSnapshot(data.vendors, vendorMap);
        existing.subtotal = data.subtotal;
        existing.contingencyPercentage = data.contingencyPercentage;
        existing.contingencyAmount = data.contingencyAmount;
        existing.grandTotal = data.grandTotal;
        existing.itemCount = data.itemCount;
        existing.updatedBy = actorId;
        await existing.save(options);

        await BOQLine.deleteMany({ boqId }, options);
        if (data.lines.length) {
            await BOQLine.insertMany(
                data.lines.map((line) => ({ ...line, boqId })),
                options,
            );
        }

        return serialize(existing, await getLinesForBOQ(boqId, { session }));
    });

    return updated;
}

export async function lockBOQ({ id, userId }) {
    const boqId = idOf(id);
    const actorId = userIdOf(userId, "lockedBy");
    const row = await BOQ.findById(boqId);
    if (!row) {
        throw new BOQServiceError("BOQ not found.", {
            code: "BOQ_NOT_FOUND",
            statusCode: 404,
        });
    }
    if (row.status === "locked") {
        return serialize(row, await getLinesForBOQ(row._id));
    }

    const lines = await getLinesForBOQ(row._id);
    if (!lines.length) {
        throw new BOQServiceError("Add at least one BOQ line before locking the BOQ.", {
            code: "BOQ_ITEMS_REQUIRED",
            statusCode: 422,
        });
    }

    row.status = "locked";
    row.lockedAt = new Date();
    row.lockedBy = actorId;
    row.updatedBy = actorId;
    await row.save();
    return serialize(row, lines);
}

export async function deleteBOQ(id, { userId } = {}) {
    const boqId = idOf(id);
    const row = await BOQ.findById(boqId);
    if (!row) {
        throw new BOQServiceError("BOQ not found.", {
            code: "BOQ_NOT_FOUND",
            statusCode: 404,
        });
    }
    if (row.status !== "draft") {
        throw new BOQServiceError("Locked BOQs cannot be deleted.", {
            code: "BOQ_LOCKED",
            statusCode: 409,
        });
    }

    await BOQLine.deleteMany({ boqId });
    await BOQ.findByIdAndDelete(boqId);
    return { id: String(boqId) };
}

export default {
    listBOQs,
    getBOQ,
    createBOQ,
    updateBOQ,
    lockBOQ,
    deleteBOQ,
};
