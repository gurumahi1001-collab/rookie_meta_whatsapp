import mongoose from "mongoose";
import { getDatabaseConnection } from "../../config/database.js";

/**
 * ARGUS Survey Report service.
 *
 * MongoDB is the authoritative runtime database. The legacy SQL migration in
 * this repository is retained for historical reference only and is not used
 * by this service.
 */
export const serviceName = "surveyReportService";

const COLLECTIONS = Object.freeze({
    reports: "survey_reports",
    responses: "survey_responses",
    templates: "survey_templates",
});

const SORT_FIELDS = Object.freeze({
    createdAt: "createdAt",
    updatedAt: "updatedAt",
    generatedAt: "generatedAt",
    reportNumber: "reportNumber",
    status: "status",
});

const REPORT_STATUSES = Object.freeze([
    "draft",
    "generated",
    "final",
    "archived",
    "failed",
]);

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;
const MAX_REPORT_DATA_BYTES = 8 * 1024 * 1024;

let indexesPromise = null;

export class SurveyReportServiceError extends Error {
    constructor(message, { code = "SURVEY_REPORT_ERROR", statusCode = 400, details = null } = {}) {
        super(message);
        this.name = "SurveyReportServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, SurveyReportServiceError);
    }
}

function getConnection() {
    const connection = getDatabaseConnection();
    if (!connection || connection.readyState !== 1) {
        throw new SurveyReportServiceError("MongoDB is not connected.", {
            code: "DATABASE_NOT_CONNECTED",
            statusCode: 503,
        });
    }
    return connection;
}

function getCollection(name) {
    return getConnection().collection(name);
}

function asObjectId(value, fieldName) {
    if (value === undefined || value === null || value === "") {
        return null;
    }

    if (value instanceof mongoose.Types.ObjectId) {
        return value;
    }

    const normalized = String(value).trim();
    if (!mongoose.isValidObjectId(normalized)) {
        throw new SurveyReportServiceError(`Invalid ${fieldName}.`, {
            code: "INVALID_SURVEY_REPORT_ID",
            statusCode: 422,
            details: { field: fieldName },
        });
    }

    return new mongoose.Types.ObjectId(normalized);
}

function normalizePage(value) {
    const page = Number.parseInt(String(value ?? DEFAULT_PAGE), 10);
    return Number.isFinite(page) && page > 0 ? page : DEFAULT_PAGE;
}

function normalizeLimit(value) {
    const limit = Number.parseInt(String(value ?? DEFAULT_LIMIT), 10);
    if (!Number.isFinite(limit) || limit <= 0) return DEFAULT_LIMIT;
    return Math.min(limit, MAX_LIMIT);
}

function normalizeString(value, maxLength = 500) {
    if (value === undefined || value === null) return "";
    return String(value).trim().slice(0, maxLength);
}

function normalizeStatus(value) {
    const status = normalizeString(value, 30).toLowerCase();
    if (!status) return "";
    if (!REPORT_STATUSES.includes(status)) {
        throw new SurveyReportServiceError("Invalid survey report status.", {
            code: "INVALID_REPORT_STATUS",
            statusCode: 422,
            details: { allowed: REPORT_STATUSES },
        });
    }
    return status;
}

function normalizeDate(value, fieldName) {
    if (!value) return null;
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) {
        throw new SurveyReportServiceError(`Invalid ${fieldName}.`, {
            code: "INVALID_REPORT_DATE",
            statusCode: 422,
            details: { field: fieldName },
        });
    }
    return date;
}

function escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function plainClone(value) {
    if (value === undefined) return undefined;
    return JSON.parse(JSON.stringify(value));
}

function assertPayloadSize(value) {
    const bytes = Buffer.byteLength(JSON.stringify(value ?? {}), "utf8");
    if (bytes > MAX_REPORT_DATA_BYTES) {
        throw new SurveyReportServiceError("Survey report data is too large.", {
            code: "REPORT_DATA_TOO_LARGE",
            statusCode: 413,
            details: { maxBytes: MAX_REPORT_DATA_BYTES },
        });
    }
}

function normalizeActorId(actorId) {
    return asObjectId(actorId, "actorId");
}

function safeValue(value) {
    if (value === null || value === undefined) return "";
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return value;
    }
    return value;
}

function flattenValues(value, output = []) {
    if (Array.isArray(value)) {
        value.forEach((item) => flattenValues(item, output));
        return output;
    }

    if (value && typeof value === "object") {
        Object.values(value).forEach((item) => flattenValues(item, output));
        return output;
    }

    if (value !== null && value !== undefined) {
        output.push(value);
    }

    return output;
}

function buildSummary(responseDocument) {
    const response = responseDocument?.response ?? responseDocument?.data ?? {};
    const flat = flattenValues(response);
    const normalized = flat.map((item) => String(item).trim().toLowerCase());

    const countOf = (values) => normalized.filter((item) => values.includes(item)).length;

    const passCount = countOf(["pass", "passed", "ok", "ready", "yes"]);
    const failCount = countOf(["fail", "failed", "defective", "no", "missing / defective"]);
    const warningCount = countOf(["warning", "urgent", "p2 urgent", "p3 routine"]);

    const totalChecks = passCount + failCount;
    const completionPercentage = totalChecks > 0
        ? Math.round((passCount / totalChecks) * 10000) / 100
        : null;

    return {
        totalChecks,
        passCount,
        failCount,
        warningCount,
        completionPercentage,
        responseStatus: normalizeString(responseDocument?.status, 40).toLowerCase() || null,
    };
}

function serializeReport(document) {
    if (!document) return null;
    const result = { ...document };
    if (result._id) result.id = String(result._id);
    ["_id", "__v"].forEach((key) => delete result[key]);
    ["templateId", "responseId", "projectId", "vendorId", "generatedBy", "updatedBy", "archivedBy"].forEach((key) => {
        if (result[key]) result[key] = String(result[key]);
    });
    return result;
}

async function ensureIndexes() {
    if (indexesPromise) return indexesPromise;

    const reports = getCollection(COLLECTIONS.reports);
    const responses = getCollection(COLLECTIONS.responses);

    indexesPromise = Promise.all([
        reports.createIndex({ reportNumber: 1 }, { unique: true, name: "survey_reports_report_number_uq" }),
        reports.createIndex({ status: 1, createdAt: -1 }, { name: "survey_reports_status_created" }),
        reports.createIndex({ templateId: 1, createdAt: -1 }, { name: "survey_reports_template_created" }),
        reports.createIndex({ responseId: 1 }, { sparse: true, name: "survey_reports_response" }),
        reports.createIndex({ projectId: 1, createdAt: -1 }, { sparse: true, name: "survey_reports_project_created" }),
        reports.createIndex({ generatedBy: 1, createdAt: -1 }, { sparse: true, name: "survey_reports_generated_by" }),
        reports.createIndex({ "summary.failCount": -1, createdAt: -1 }, { name: "survey_reports_fail_count" }),
        responses.createIndex({ templateId: 1, createdAt: -1 }, { sparse: true, name: "survey_responses_template_created" }),
        responses.createIndex({ projectId: 1, createdAt: -1 }, { sparse: true, name: "survey_responses_project_created" }),
        responses.createIndex({ respondentId: 1, createdAt: -1 }, { sparse: true, name: "survey_responses_respondent_created" }),
    ]).catch((error) => {
        indexesPromise = null;
        throw error;
    });

    return indexesPromise;
}

function buildReportFilter(filters = {}) {
    const query = {};

    const status = normalizeStatus(filters.status);
    if (status) query.status = status;

    const templateId = asObjectId(filters.templateId, "templateId");
    if (templateId) query.templateId = templateId;

    const responseId = asObjectId(filters.responseId, "responseId");
    if (responseId) query.responseId = responseId;

    const projectId = asObjectId(filters.projectId, "projectId");
    if (projectId) query.projectId = projectId;

    const vendorId = asObjectId(filters.vendorId, "vendorId");
    if (vendorId) query.vendorId = vendorId;

    const generatedBy = asObjectId(filters.generatedBy, "generatedBy");
    if (generatedBy) query.generatedBy = generatedBy;

    const search = normalizeString(filters.search, 120);
    if (search) {
        const regex = new RegExp(escapeRegex(search), "i");
        query.$or = [
            { reportNumber: regex },
            { title: regex },
            { "metadata.projectName": regex },
            { "metadata.vendorName": regex },
        ];
    }

    const from = normalizeDate(filters.from, "from");
    const to = normalizeDate(filters.to, "to");
    if (from || to) {
        query.createdAt = {};
        if (from) query.createdAt.$gte = from;
        if (to) query.createdAt.$lte = to;
    }

    if (filters.includeArchived !== true) {
        query.status = query.status || { $ne: "archived" };
    }

    return query;
}

function createReportNumber(now = new Date()) {
    const datePart = now.toISOString().slice(0, 10).replace(/-/g, "");
    const randomPart = Math.random().toString(36).slice(2, 8).toUpperCase();
    return `SR-${datePart}-${randomPart}`;
}

async function createUniqueReportNumber() {
    const reports = getCollection(COLLECTIONS.reports);
    for (let attempt = 0; attempt < 5; attempt += 1) {
        const reportNumber = createReportNumber();
        const exists = await reports.findOne({ reportNumber }, { projection: { _id: 1 } });
        if (!exists) return reportNumber;
    }
    throw new SurveyReportServiceError("Unable to allocate a unique survey report number.", {
        code: "REPORT_NUMBER_ALLOCATION_FAILED",
        statusCode: 503,
    });
}

async function loadResponseContext(responseId) {
    if (!responseId) return null;
    const responses = getCollection(COLLECTIONS.responses);
    const response = await responses.findOne({ _id: responseId });
    if (!response) {
        throw new SurveyReportServiceError("Survey response not found.", {
            code: "SURVEY_RESPONSE_NOT_FOUND",
            statusCode: 404,
        });
    }
    return response;
}

async function loadTemplateContext(templateId) {
    if (!templateId) return null;
    const templates = getCollection(COLLECTIONS.templates);
    const template = await templates.findOne({ _id: templateId });
    if (!template) {
        throw new SurveyReportServiceError("Survey template not found.", {
            code: "SURVEY_TEMPLATE_NOT_FOUND",
            statusCode: 404,
        });
    }
    return template;
}

export async function list(options = {}) {
    await ensureIndexes();

    const page = normalizePage(options.page);
    const limit = normalizeLimit(options.limit);
    const skip = (page - 1) * limit;
    const sortField = SORT_FIELDS[options.sort] || SORT_FIELDS.createdAt;
    const sortDirection = String(options.sortOrder).toLowerCase() === "asc" ? 1 : -1;
    const query = buildReportFilter(options);

    const reports = getCollection(COLLECTIONS.reports);
    const [items, total] = await Promise.all([
        reports.find(query).sort({ [sortField]: sortDirection }).skip(skip).limit(limit).toArray(),
        reports.countDocuments(query),
    ]);

    const pages = Math.max(1, Math.ceil(total / limit));

    return {
        data: items.map(serializeReport),
        pagination: {
            page,
            limit,
            total,
            pages,
            hasNextPage: page < pages,
            hasPreviousPage: page > 1,
        },
        filters: {
            search: normalizeString(options.search, 120),
            status: normalizeStatus(options.status) || "",
            templateId: options.templateId ? String(options.templateId) : "",
            responseId: options.responseId ? String(options.responseId) : "",
            projectId: options.projectId ? String(options.projectId) : "",
            vendorId: options.vendorId ? String(options.vendorId) : "",
            from: options.from || "",
            to: options.to || "",
        },
    };
}

export async function getById(id) {
    await ensureIndexes();
    const objectId = asObjectId(id, "reportId");
    const report = await getCollection(COLLECTIONS.reports).findOne({ _id: objectId });
    if (!report) {
        throw new SurveyReportServiceError("Survey report not found.", {
            code: "SURVEY_REPORT_NOT_FOUND",
            statusCode: 404,
        });
    }
    return serializeReport(report);
}

export async function create(payload = {}, actorId = null) {
    await ensureIndexes();

    const generatedBy = normalizeActorId(actorId || payload.generatedBy);
    const responseId = asObjectId(payload.responseId, "responseId");
    const templateId = asObjectId(payload.templateId, "templateId");
    const projectId = asObjectId(payload.projectId, "projectId");
    const vendorId = asObjectId(payload.vendorId, "vendorId");

    const responseContext = await loadResponseContext(responseId);
    const resolvedTemplateId = templateId || responseContext?.templateId || null;
    const templateContext = await loadTemplateContext(resolvedTemplateId);

    const reportData = payload.reportData !== undefined
        ? plainClone(payload.reportData)
        : responseContext
            ? plainClone(responseContext.response ?? responseContext.data ?? {})
            : {};

    assertPayloadSize(reportData);

    if (!resolvedTemplateId && !reportData) {
        throw new SurveyReportServiceError("A survey template or report data is required.", {
            code: "SURVEY_REPORT_SOURCE_REQUIRED",
            statusCode: 422,
        });
    }

    const now = new Date();
    const reportNumber = await createUniqueReportNumber();
    const summary = payload.summary && typeof payload.summary === "object"
        ? plainClone(payload.summary)
        : buildSummary(responseContext);

    const document = {
        reportNumber,
        title: normalizeString(payload.title, 255) || templateContext?.name || "Survey Report",
        reportType: normalizeString(payload.reportType, 80) || "survey",
        status: normalizeStatus(payload.status) || "generated",
        templateId: resolvedTemplateId,
        responseId,
        projectId: projectId || responseContext?.projectId || null,
        vendorId: vendorId || responseContext?.vendorId || null,
        generatedBy,
        generatedAt: now,
        updatedBy: generatedBy,
        version: 1,
        summary,
        filters: payload.filters && typeof payload.filters === "object" ? plainClone(payload.filters) : {},
        metadata: payload.metadata && typeof payload.metadata === "object" ? plainClone(payload.metadata) : {},
        reportData,
        attachments: Array.isArray(payload.attachments)
            ? payload.attachments.slice(0, 100).map((item) => plainClone(item))
            : [],
        error: null,
        archivedAt: null,
        archivedBy: null,
        createdAt: now,
        updatedAt: now,
    };

    const result = await getCollection(COLLECTIONS.reports).insertOne(document);
    return serializeReport({ ...document, _id: result.insertedId });
}

export async function update(id, payload = {}, actorId = null) {
    await ensureIndexes();

    const reportId = asObjectId(id, "reportId");
    const expectedVersion = payload.version === undefined || payload.version === null
        ? null
        : Number.parseInt(String(payload.version), 10);

    if (expectedVersion !== null && (!Number.isInteger(expectedVersion) || expectedVersion < 1)) {
        throw new SurveyReportServiceError("Invalid report version.", {
            code: "INVALID_REPORT_VERSION",
            statusCode: 422,
        });
    }

    const actor = normalizeActorId(actorId || payload.updatedBy);
    const existing = await getCollection(COLLECTIONS.reports).findOne({ _id: reportId });

    if (!existing) {
        throw new SurveyReportServiceError("Survey report not found.", {
            code: "SURVEY_REPORT_NOT_FOUND",
            statusCode: 404,
        });
    }

    if (existing.status === "archived") {
        throw new SurveyReportServiceError("Archived survey reports cannot be edited.", {
            code: "REPORT_ARCHIVED",
            statusCode: 409,
        });
    }

    const set = {};
    const editableFields = [
        "title",
        "reportType",
        "summary",
        "filters",
        "metadata",
        "reportData",
        "attachments",
        "error",
    ];

    editableFields.forEach((field) => {
        if (payload[field] !== undefined) {
            set[field] = plainClone(payload[field]);
        }
    });

    if (payload.status !== undefined) set.status = normalizeStatus(payload.status);
    if (payload.generatedAt !== undefined) set.generatedAt = normalizeDate(payload.generatedAt, "generatedAt");
    if (payload.projectId !== undefined) set.projectId = asObjectId(payload.projectId, "projectId");
    if (payload.vendorId !== undefined) set.vendorId = asObjectId(payload.vendorId, "vendorId");
    if (payload.templateId !== undefined) set.templateId = asObjectId(payload.templateId, "templateId");
    if (payload.responseId !== undefined) set.responseId = asObjectId(payload.responseId, "responseId");

    if (set.reportData !== undefined) assertPayloadSize(set.reportData);

    if (set.status === "archived") {
        set.archivedAt = new Date();
        set.archivedBy = actor;
    }

    set.updatedBy = actor;
    set.updatedAt = new Date();
    set.version = Number(existing.version || 1) + 1;

    const filter = { _id: reportId };
    if (expectedVersion !== null) filter.version = expectedVersion;

    const result = await getCollection(COLLECTIONS.reports).findOneAndUpdate(
        filter,
        { $set: set },
        { returnDocument: "after" },
    );

    if (!result) {
        if (expectedVersion !== null) {
            throw new SurveyReportServiceError("Survey report was changed by another user. Reload before saving again.", {
                code: "REPORT_VERSION_CONFLICT",
                statusCode: 409,
                details: { expectedVersion },
            });
        }

        throw new SurveyReportServiceError("Unable to update survey report.", {
            code: "REPORT_UPDATE_FAILED",
            statusCode: 409,
        });
    }

    return serializeReport(result);
}

export async function remove(id, actorId = null) {
    await ensureIndexes();

    const reportId = asObjectId(id, "reportId");
    const actor = normalizeActorId(actorId);
    const now = new Date();

    const result = await getCollection(COLLECTIONS.reports).findOneAndUpdate(
        { _id: reportId, status: { $ne: "archived" } },
        {
            $set: {
                status: "archived",
                archivedAt: now,
                archivedBy: actor,
                updatedBy: actor,
                updatedAt: now,
            },
            $inc: {
                version: 1,
            },
        },
        { returnDocument: "after" },
    );

    if (!result) {
        const existing = await getCollection(COLLECTIONS.reports).findOne({ _id: reportId }, { projection: { status: 1 } });
        if (!existing) {
            throw new SurveyReportServiceError("Survey report not found.", {
                code: "SURVEY_REPORT_NOT_FOUND",
                statusCode: 404,
            });
        }
        throw new SurveyReportServiceError("Survey report is already archived.", {
            code: "REPORT_ALREADY_ARCHIVED",
            statusCode: 409,
        });
    }

    return serializeReport(result);
}

export async function restore(id, actorId = null) {
    await ensureIndexes();

    const reportId = asObjectId(id, "reportId");
    const actor = normalizeActorId(actorId);
    const existing = await getCollection(COLLECTIONS.reports).findOne({ _id: reportId });

    if (!existing) {
        throw new SurveyReportServiceError("Survey report not found.", {
            code: "SURVEY_REPORT_NOT_FOUND",
            statusCode: 404,
        });
    }

    if (existing.status !== "archived") return serializeReport(existing);

    const now = new Date();
    const result = await getCollection(COLLECTIONS.reports).findOneAndUpdate(
        { _id: reportId, status: "archived" },
        {
            $set: {
                status: "generated",
                archivedAt: null,
                archivedBy: null,
                updatedBy: actor,
                updatedAt: now,
                version: Number(existing.version || 1) + 1,
            },
        },
        { returnDocument: "after" },
    );

    if (!result) {
        throw new SurveyReportServiceError("Unable to restore survey report.", {
            code: "REPORT_RESTORE_FAILED",
            statusCode: 409,
        });
    }

    return serializeReport(result);
}

export async function summary(filters = {}) {
    await ensureIndexes();
    const query = buildReportFilter(filters);
    delete query.status;
    if (filters.includeArchived !== true) query.status = { $ne: "archived" };

    const reports = getCollection(COLLECTIONS.reports);
    const rows = await reports.aggregate([
        { $match: query },
        {
            $group: {
                _id: null,
                total: { $sum: 1 },
                draft: { $sum: { $cond: [{ $eq: ["$status", "draft"] }, 1, 0] } },
                generated: { $sum: { $cond: [{ $eq: ["$status", "generated"] }, 1, 0] } },
                final: { $sum: { $cond: [{ $eq: ["$status", "final"] }, 1, 0] } },
                failed: { $sum: { $cond: [{ $eq: ["$status", "failed"] }, 1, 0] } },
                archived: { $sum: { $cond: [{ $eq: ["$status", "archived"] }, 1, 0] } },
                passedChecks: { $sum: { $ifNull: ["$summary.passCount", 0] } },
                failedChecks: { $sum: { $ifNull: ["$summary.failCount", 0] } },
                warningChecks: { $sum: { $ifNull: ["$summary.warningCount", 0] } },
            },
        },
        { $project: { _id: 0 } },
    ]).toArray();

    return rows[0] || {
        total: 0,
        draft: 0,
        generated: 0,
        final: 0,
        failed: 0,
        archived: 0,
        passedChecks: 0,
        failedChecks: 0,
        warningChecks: 0,
    };
}

export async function getExportRows(filters = {}) {
    await ensureIndexes();
    const query = buildReportFilter(filters);
    const projection = {
        _id: 1,
        reportNumber: 1,
        title: 1,
        reportType: 1,
        status: 1,
        templateId: 1,
        responseId: 1,
        projectId: 1,
        vendorId: 1,
        generatedAt: 1,
        createdAt: 1,
        updatedAt: 1,
        "summary.totalChecks": 1,
        "summary.passCount": 1,
        "summary.failCount": 1,
        "summary.warningCount": 1,
        "summary.completionPercentage": 1,
    };

    const reports = getCollection(COLLECTIONS.reports);
    const rows = await reports.find(query).project(projection).sort({ createdAt: -1 }).limit(5000).toArray();

    return rows.map((row) => {
        const serialized = serializeReport(row);
        return {
            id: serialized.id,
            reportNumber: serialized.reportNumber || "",
            title: serialized.title || "",
            reportType: serialized.reportType || "",
            status: serialized.status || "",
            templateId: serialized.templateId || "",
            responseId: serialized.responseId || "",
            projectId: serialized.projectId || "",
            vendorId: serialized.vendorId || "",
            generatedAt: serialized.generatedAt || "",
            createdAt: serialized.createdAt || "",
            updatedAt: serialized.updatedAt || "",
            totalChecks: Number(serialized.summary?.totalChecks || 0),
            passCount: Number(serialized.summary?.passCount || 0),
            failCount: Number(serialized.summary?.failCount || 0),
            warningCount: Number(serialized.summary?.warningCount || 0),
            completionPercentage: serialized.summary?.completionPercentage ?? "",
        };
    });
}
