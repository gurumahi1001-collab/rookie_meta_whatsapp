import mongoose from "mongoose";

import SurveyTemplate from "../../models/SurveyTemplate.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;
const MAX_SEARCH_LENGTH = 120;
const MAX_SCHEMA_BYTES = 2 * 1024 * 1024;
const MAX_MODULES = 100;
const MAX_MODULE_FIELDS = 10000;

const TEMPLATE_STATUSES = Object.freeze([
    "draft",
    "active",
    "archived",
]);

/* -------------------------------------------------------------------------- */
/* Errors                                                                     */
/* -------------------------------------------------------------------------- */

export class SurveyTemplateServiceError extends Error {
    constructor(
        message,
        {
            code = "SURVEY_TEMPLATE_ERROR",
            statusCode = 400,
            details = null,
        } = {},
    ) {
        super(message);

        this.name =
            "SurveyTemplateServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;

        Error.captureStackTrace?.(
            this,
            SurveyTemplateServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Normalization helpers                                                      */
/* -------------------------------------------------------------------------- */

function normalizeString(value) {
    return typeof value === "string"
        ? value.trim()
        : "";
}

function normalizeKey(value) {
    return normalizeString(value)
        .toLowerCase()
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_.-]/g, "_")
        .replace(/_+/g, "_")
        .replace(/^[_-]+|[_-]+$/g, "");
}

function escapeRegex(value) {
    return value.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
    );
}

function normalizeSearch(value) {
    return normalizeString(value)
        .slice(0, MAX_SEARCH_LENGTH);
}

function parsePage(value) {
    const page = Number.parseInt(
        String(value ?? ""),
        10,
    );

    return Number.isFinite(page) && page > 0
        ? page
        : DEFAULT_PAGE;
}

function parseLimit(value) {
    const limit = Number.parseInt(
        String(value ?? ""),
        10,
    );

    if (!Number.isFinite(limit) || limit <= 0) {
        return DEFAULT_LIMIT;
    }

    return Math.min(limit, MAX_LIMIT);
}

function normalizeStatus(value) {
    const status = normalizeString(value)
        .toLowerCase();

    if (!status) {
        return undefined;
    }

    if (!TEMPLATE_STATUSES.includes(status)) {
        throw new SurveyTemplateServiceError(
            "Invalid survey template status.",
            {
                code: "INVALID_SURVEY_TEMPLATE_STATUS",
                statusCode: 422,
                details: {
                    field: "status",
                    allowed: TEMPLATE_STATUSES,
                },
            },
        );
    }

    return status;
}

function toObjectId(
    value,
    fieldName,
) {
    if (
        !value ||
        !mongoose.isValidObjectId(value)
    ) {
        throw new SurveyTemplateServiceError(
            `Invalid ${fieldName}.`,
            {
                code: "INVALID_OBJECT_ID",
                statusCode: 422,
                details: {
                    field: fieldName,
                },
            },
        );
    }

    return new mongoose.Types.ObjectId(value);
}

function resolveActorId(actor) {
    const value =
        actor?.id ??
        actor?.userId ??
        actor?._id ??
        null;

    return value && mongoose.isValidObjectId(value)
        ? new mongoose.Types.ObjectId(value)
        : null;
}

function cloneJsonValue(value) {
    if (value === undefined) {
        return {};
    }

    try {
        return JSON.parse(
            JSON.stringify(value),
        );
    } catch {
        throw new SurveyTemplateServiceError(
            "Survey template schema must contain JSON-compatible values.",
            {
                code: "INVALID_SURVEY_TEMPLATE_SCHEMA",
                statusCode: 422,
                details: {
                    field: "schema",
                },
            },
        );
    }
}

function removeUnsafeKeys(value) {
    if (Array.isArray(value)) {
        return value.map(removeUnsafeKeys);
    }

    if (
        value === null ||
        typeof value !== "object"
    ) {
        return value;
    }

    const result = {};

    for (const [key, child] of Object.entries(value)) {
        if (
            key === "__proto__" ||
            key === "constructor" ||
            key === "prototype"
        ) {
            continue;
        }

        result[key] = removeUnsafeKeys(child);
    }

    return result;
}

function normalizeModules(schemaValue) {
    const schema = cloneJsonValue(
        removeUnsafeKeys(schemaValue),
    );

    if (
        !schema ||
        typeof schema !== "object" ||
        Array.isArray(schema)
    ) {
        throw new SurveyTemplateServiceError(
            "Survey template schema must be an object.",
            {
                code: "INVALID_SURVEY_TEMPLATE_SCHEMA",
                statusCode: 422,
                details: {
                    field: "schema",
                },
            },
        );
    }

    const modules = Array.isArray(schema.modules)
        ? schema.modules
        : [];

    if (modules.length > MAX_MODULES) {
        throw new SurveyTemplateServiceError(
            `A survey template cannot contain more than ${MAX_MODULES} modules.`,
            {
                code: "SURVEY_TEMPLATE_MODULE_LIMIT_EXCEEDED",
                statusCode: 422,
                details: {
                    field: "schema.modules",
                    max: MAX_MODULES,
                },
            },
        );
    }

    let fieldCount = 0;

    for (const module of modules) {
        if (
            !module ||
            typeof module !== "object" ||
            Array.isArray(module)
        ) {
            throw new SurveyTemplateServiceError(
                "Each survey module must be an object.",
                {
                    code: "INVALID_SURVEY_MODULE",
                    statusCode: 422,
                    details: {
                        field: "schema.modules",
                    },
                },
            );
        }

        const explicitFields = Number(module.fields);

        if (
            Number.isFinite(explicitFields) &&
            explicitFields >= 0
        ) {
            fieldCount += Math.floor(explicitFields);
        }

        if (
            Array.isArray(module.sections)
        ) {
            for (const section of module.sections) {
                if (!section || typeof section !== "object") {
                    continue;
                }

                if (!Array.isArray(section.fieldGroups)) {
                    continue;
                }

                for (const group of section.fieldGroups) {
                    if (!group || typeof group !== "object") {
                        continue;
                    }

                    if (Array.isArray(group.fields)) {
                        fieldCount += group.fields.length;
                    }

                    if (fieldCount > MAX_MODULE_FIELDS) {
                        break;
                    }
                }

                if (fieldCount > MAX_MODULE_FIELDS) {
                    break;
                }
            }
        }

        if (fieldCount > MAX_MODULE_FIELDS) {
            break;
        }
    }

    if (fieldCount > MAX_MODULE_FIELDS) {
        throw new SurveyTemplateServiceError(
            `A survey template cannot contain more than ${MAX_MODULE_FIELDS} fields.`,
            {
                code: "SURVEY_TEMPLATE_FIELD_LIMIT_EXCEEDED",
                statusCode: 422,
                details: {
                    field: "schema.modules",
                    max: MAX_MODULE_FIELDS,
                },
            },
        );
    }

    const version = Number(schema.version);

    schema.version =
        Number.isFinite(version) && version >= 1
            ? Math.floor(version)
            : 1;
    schema.modules = modules;

    const serialized = JSON.stringify(schema);

    if (
        Buffer.byteLength(serialized, "utf8") >
        MAX_SCHEMA_BYTES
    ) {
        throw new SurveyTemplateServiceError(
            "Survey template schema is too large.",
            {
                code: "SURVEY_TEMPLATE_SCHEMA_TOO_LARGE",
                statusCode: 422,
                details: {
                    field: "schema",
                    maxBytes: MAX_SCHEMA_BYTES,
                },
            },
        );
    }

    return {
        schema,
        fieldCount,
    };
}

function getModuleCodes(modules) {
    return Array.from(
        new Set(
            modules
                .map((module) =>
                    normalizeString(module?.code).slice(0, 80),
                )
                .filter(Boolean),
        ),
    );
}

function normalizeMetadata(value) {
    if (
        value === undefined ||
        value === null
    ) {
        return {};
    }

    if (
        typeof value !== "object" ||
        Array.isArray(value)
    ) {
        throw new SurveyTemplateServiceError(
            "Survey template metadata must be an object.",
            {
                code: "INVALID_SURVEY_TEMPLATE_METADATA",
                statusCode: 422,
                details: {
                    field: "metadata",
                },
            },
        );
    }

    return removeUnsafeKeys(
        cloneJsonValue(value),
    );
}

function buildNameFilter(name) {
    const normalized = normalizeString(name);

    if (!normalized) {
        return null;
    }

    return {
        name: {
            $regex: `^${escapeRegex(normalized)}$`,
            $options: "i",
        },
        status: {
            $ne: "archived",
        },
    };
}

function serializeTemplate(template) {
    if (!template) {
        return null;
    }

    const source =
        typeof template.toSafeJSON === "function"
            ? template.toSafeJSON()
            : template;

    return {
        id: String(source.id ?? source._id),
        name: normalizeString(source.name),
        description: normalizeString(source.description),
        schema: source.schema ?? {
            version: 1,
            modules: [],
        },
        moduleCodes: Array.isArray(source.moduleCodes)
            ? source.moduleCodes
            : [],
        moduleCount: Number(source.moduleCount || 0),
        fieldCount: Number(source.fieldCount || 0),
        status: normalizeString(source.status).toLowerCase() || "draft",
        version: Number(source.version || 1),
        metadata: source.metadata ?? {},
        createdBy: source.createdBy
            ? String(source.createdBy)
            : null,
        updatedBy: source.updatedBy
            ? String(source.updatedBy)
            : null,
        archivedAt: source.archivedAt ?? null,
        archivedBy: source.archivedBy
            ? String(source.archivedBy)
            : null,
        createdAt: source.createdAt ?? null,
        updatedAt: source.updatedAt ?? null,
    };
}

function normalizeTemplateInput(payload = {}) {
    if (
        !payload ||
        typeof payload !== "object" ||
        Array.isArray(payload)
    ) {
        throw new SurveyTemplateServiceError(
            "Survey template payload must be an object.",
            {
                code: "INVALID_SURVEY_TEMPLATE_PAYLOAD",
                statusCode: 422,
            },
        );
    }

    const name = normalizeString(payload.name);

    if (!name) {
        throw new SurveyTemplateServiceError(
            "Survey template name is required.",
            {
                code: "SURVEY_TEMPLATE_NAME_REQUIRED",
                statusCode: 422,
                details: {
                    field: "name",
                },
            },
        );
    }

    if (name.length < 2 || name.length > 255) {
        throw new SurveyTemplateServiceError(
            "Survey template name must contain 2 to 255 characters.",
            {
                code: "INVALID_SURVEY_TEMPLATE_NAME",
                statusCode: 422,
                details: {
                    field: "name",
                },
            },
        );
    }

    const description = normalizeString(
        payload.description,
    ).slice(0, 2000);

    const normalizedSchema = normalizeModules(
        payload.schema ?? {
            version: 1,
            modules: [],
        },
    );

    const status = normalizeStatus(
        payload.status,
    ) ?? "draft";

    return {
        name,
        description,
        schema: normalizedSchema.schema,
        moduleCodes: getModuleCodes(
            normalizedSchema.schema.modules,
        ),
        moduleCount:
            normalizedSchema.schema.modules.length,
        fieldCount:
            normalizedSchema.fieldCount,
        status,
        version:
            normalizedSchema.schema.version,
        metadata:
            normalizeMetadata(payload.metadata),
    };
}

/* -------------------------------------------------------------------------- */
/* List filters                                                               */
/* -------------------------------------------------------------------------- */

function buildListFilter(options = {}) {
    const filter = {};

    const search = normalizeSearch(
        options.search,
    );

    if (search) {
        const escaped = escapeRegex(search);

        filter.$or = [
            {
                name: {
                    $regex: escaped,
                    $options: "i",
                },
            },
            {
                description: {
                    $regex: escaped,
                    $options: "i",
                },
            },
            {
                moduleCodes: {
                    $regex: escaped,
                    $options: "i",
                },
            },
        ];
    }

    const status = normalizeStatus(
        options.status,
    );

    if (status) {
        filter.status = status;
    }

    if (options.moduleCode) {
        const moduleCode = normalizeString(
            options.moduleCode,
        ).slice(0, 80);

        if (moduleCode) {
            filter.moduleCodes = moduleCode;
        }
    }

    if (options.createdBy) {
        filter.createdBy = toObjectId(
            options.createdBy,
            "createdBy",
        );
    }

    return filter;
}

/* -------------------------------------------------------------------------- */
/* Public service operations                                                  */
/* -------------------------------------------------------------------------- */

export async function listTemplates(
    options = {},
) {
    const page = parsePage(options.page);
    const limit = parseLimit(options.limit);
    const skip = (page - 1) * limit;
    const filter = buildListFilter(options);

    const [items, total] = await Promise.all([
        SurveyTemplate.find(filter)
            .sort({
                status: 1,
                updatedAt: -1,
                _id: -1,
            })
            .skip(skip)
            .limit(limit)
            .lean(),
        SurveyTemplate.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(
        total / limit,
    );

    return {
        data: items.map(serializeTemplate),
        pagination: {
            page,
            limit,
            total,
            pages: totalPages,
            hasNextPage:
                page < totalPages,
            hasPreviousPage:
                page > 1,
        },
        filters: {
            search: normalizeSearch(options.search),
            status:
                normalizeStatus(options.status) ?? null,
            moduleCode:
                normalizeString(options.moduleCode) || null,
            createdBy:
                options.createdBy
                    ? String(options.createdBy)
                    : null,
        },
    };
}

export async function getTemplate(
    templateId,
) {
    const _id = toObjectId(
        templateId,
        "survey template id",
    );

    const template =
        await SurveyTemplate.findById(
            _id,
        );

    if (!template) {
        throw new SurveyTemplateServiceError(
            "Survey template not found.",
            {
                code: "SURVEY_TEMPLATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeTemplate(template);
}

export async function getActiveTemplates() {
    const templates =
        await SurveyTemplate.find({
            status: "active",
        })
            .sort({
                name: 1,
                _id: 1,
            })
            .lean();

    return templates.map(serializeTemplate);
}

export async function createTemplate(
    payload,
    {
        actor = null,
    } = {},
) {
    const input = normalizeTemplateInput(
        payload,
    );

    const duplicate =
        buildNameFilter(input.name);

    if (duplicate) {
        const existing =
            await SurveyTemplate.exists(
                duplicate,
            );

        if (existing) {
            throw new SurveyTemplateServiceError(
                "A survey template with this name already exists.",
                {
                    code: "SURVEY_TEMPLATE_NAME_EXISTS",
                    statusCode: 409,
                    details: {
                        field: "name",
                    },
                },
            );
        }
    }

    const actorId =
        resolveActorId(actor);

    const template =
        await SurveyTemplate.create({
            ...input,
            createdBy: actorId,
            updatedBy: actorId,
            archivedAt:
                input.status === "archived"
                    ? new Date()
                    : null,
            archivedBy: null,
        });

    return serializeTemplate(template);
}

export async function updateTemplate(
    templateId,
    payload,
    {
        actor = null,
    } = {},
) {
    const _id = toObjectId(
        templateId,
        "survey template id",
    );

    const existing =
        await SurveyTemplate.findById(
            _id,
        );

    if (!existing) {
        throw new SurveyTemplateServiceError(
            "Survey template not found.",
            {
                code: "SURVEY_TEMPLATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    const input = normalizeTemplateInput(
        {
            ...payload,
            name:
                payload?.name ??
                existing.name,
            description:
                payload?.description ??
                existing.description,
            schema:
                payload?.schema ??
                existing.schema,
            status:
                payload?.status ??
                existing.status,
            metadata:
                payload?.metadata ??
                existing.metadata,
        },
    );

    const duplicate =
        buildNameFilter(input.name);

    if (duplicate) {
        duplicate._id = {
            $ne: existing._id,
        };

        const duplicateRecord =
            await SurveyTemplate.exists(
                duplicate,
            );

        if (duplicateRecord) {
            throw new SurveyTemplateServiceError(
                "A survey template with this name already exists.",
                {
                    code: "SURVEY_TEMPLATE_NAME_EXISTS",
                    statusCode: 409,
                    details: {
                        field: "name",
                    },
                },
            );
        }
    }

    if (
        existing.status === "archived" &&
        input.status !== "archived"
    ) {
        existing.archivedAt = null;
        existing.archivedBy = null;
    }

    if (input.status === "archived") {
        existing.archivedAt =
            existing.archivedAt ||
            new Date();
        existing.archivedBy =
            resolveActorId(actor);
    }

    existing.name = input.name;
    existing.description = input.description;
    existing.schema = input.schema;
    existing.moduleCodes = input.moduleCodes;
    existing.moduleCount = input.moduleCount;
    existing.fieldCount = input.fieldCount;
    existing.status = input.status;
    existing.version = input.version;
    existing.metadata = input.metadata;
    existing.updatedBy =
        resolveActorId(actor);

    await existing.save();

    return serializeTemplate(existing);
}

/**
 * DELETE is intentionally implemented as an archive operation.
 *
 * The admin UI can keep its existing delete action while preserving the
 * survey definition and historical references. A future retention workflow
 * may permanently remove data outside this normal application path.
 */
export async function removeTemplate(
    templateId,
    {
        actor = null,
    } = {},
) {
    const _id = toObjectId(
        templateId,
        "survey template id",
    );

    const template =
        await SurveyTemplate.findById(
            _id,
        );

    if (!template) {
        throw new SurveyTemplateServiceError(
            "Survey template not found.",
            {
                code: "SURVEY_TEMPLATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    if (template.status !== "archived") {
        template.status = "archived";
        template.archivedAt = new Date();
        template.archivedBy =
            resolveActorId(actor);
        template.updatedBy =
            resolveActorId(actor);

        await template.save();
    }

    return serializeTemplate(template);
}

export async function restoreTemplate(
    templateId,
    {
        actor = null,
        activate = false,
    } = {},
) {
    const _id = toObjectId(
        templateId,
        "survey template id",
    );

    const template =
        await SurveyTemplate.findById(
            _id,
        );

    if (!template) {
        throw new SurveyTemplateServiceError(
            "Survey template not found.",
            {
                code: "SURVEY_TEMPLATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    template.status =
        activate ? "active" : "draft";
    template.archivedAt = null;
    template.archivedBy = null;
    template.updatedBy =
        resolveActorId(actor);

    await template.save();

    return serializeTemplate(template);
}

/* -------------------------------------------------------------------------- */
/* Service object                                                             */
/* -------------------------------------------------------------------------- */

const surveyTemplateService = {
    serviceName: "surveyTemplateService",
    listTemplates,
    list: listTemplates,
    getTemplate,
    get: getTemplate,
    getActiveTemplates,
    createTemplate,
    create: createTemplate,
    updateTemplate,
    update: updateTemplate,
    removeTemplate,
    remove: removeTemplate,
    restoreTemplate,
};

export default surveyTemplateService;
