import mongoose from "mongoose";

import SurveyResponse from "../../models/SurveyResponse.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";

export class SurveyResponseServiceError extends Error {
    constructor(
        message,
        { code = "SURVEY_RESPONSE_ERROR", statusCode = 400, details } = {},
    ) {
        super(message);
        this.name = "SurveyResponseServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, SurveyResponseServiceError);
    }
}

const RESPONSE_MAX_BYTES = 5 * 1024 * 1024;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 250;

const ALLOWED_STATUSES = new Set([
    "draft",
    "submitted",
    "reviewed",
    "approved",
    "rejected",
    "archived",
]);

const SORT_FIELDS = new Set([
    "createdAt",
    "updatedAt",
    "surveyDate",
    "submittedAt",
    "revision",
    "status",
]);

const STATUS_TRANSITIONS = Object.freeze({
    draft: new Set(["draft", "submitted", "archived"]),
    submitted: new Set(["submitted", "reviewed", "rejected", "archived"]),
    reviewed: new Set(["reviewed", "approved", "rejected", "archived"]),
    approved: new Set(["approved", "archived"]),
    rejected: new Set(["rejected", "draft", "submitted", "archived"]),
    archived: new Set(["archived"]),
});

const text = (value) => String(value ?? "").trim();

function objectId(value, fieldName) {
    const raw = text(value);

    if (!raw) {
        return null;
    }

    if (!mongoose.Types.ObjectId.isValid(raw)) {
        throw new SurveyResponseServiceError(
            `Invalid ${fieldName} identifier.`,
            {
                code: `INVALID_${fieldName.toUpperCase()}_ID`,
                statusCode: 400,
                details: { field: fieldName },
            },
        );
    }

    return new mongoose.Types.ObjectId(raw);
}

function normalizeStatus(value, { allowEmpty = true } = {}) {
    const status = text(value).toLowerCase();

    if (!status && allowEmpty) {
        return null;
    }

    if (!ALLOWED_STATUSES.has(status)) {
        throw new SurveyResponseServiceError("Invalid survey response status.", {
            code: "INVALID_SURVEY_RESPONSE_STATUS",
            statusCode: 422,
            details: {
                allowed: [...ALLOWED_STATUSES],
            },
        });
    }

    return status;
}

function normalizePagination(page, limit) {
    const safePage = Math.max(1, Number.parseInt(String(page || 1), 10) || 1);
    const safeLimit = Math.min(
        MAX_LIMIT,
        Math.max(1, Number.parseInt(String(limit || DEFAULT_LIMIT), 10) || DEFAULT_LIMIT),
    );

    return {
        page: safePage,
        limit: safeLimit,
        skip: (safePage - 1) * safeLimit,
    };
}

function normalizeDate(value, fieldName) {
    if (value == null || text(value) === "") {
        return null;
    }

    const date = value instanceof Date ? new Date(value.getTime()) : new Date(value);

    if (Number.isNaN(date.getTime())) {
        throw new SurveyResponseServiceError(`Invalid ${fieldName}.`, {
            code: `INVALID_${fieldName.toUpperCase()}`,
            statusCode: 422,
            details: { field: fieldName },
        });
    }

    return date;
}

function normalizeDateEnd(value, fieldName) {
    const date = normalizeDate(value, fieldName);
    if (!date) return null;

    /* When a date-only value is supplied, include the whole calendar day. */
    if (/^\d{4}-\d{2}-\d{2}$/.test(text(value))) {
        date.setHours(23, 59, 59, 999);
    }

    return date;
}

function clonePlain(value) {
    if (value == null) return value;

    try {
        return JSON.parse(JSON.stringify(value));
    } catch {
        throw new SurveyResponseServiceError(
            "Survey response payload contains unsupported values.",
            {
                code: "INVALID_SURVEY_RESPONSE_PAYLOAD",
                statusCode: 422,
            },
        );
    }
}

function validateSafeObject(value, path = "response", seen = new WeakSet()) {
    if (value == null) return;

    if (typeof value === "function" || typeof value === "symbol" || typeof value === "bigint") {
        throw new SurveyResponseServiceError(
            "Survey response contains an unsupported value.",
            {
                code: "UNSUPPORTED_SURVEY_RESPONSE_VALUE",
                statusCode: 422,
                details: { path },
            },
        );
    }

    if (typeof value !== "object") return;

    if (seen.has(value)) {
        throw new SurveyResponseServiceError(
            "Survey response contains a circular reference.",
            {
                code: "CIRCULAR_SURVEY_RESPONSE",
                statusCode: 422,
                details: { path },
            },
        );
    }

    seen.add(value);

    if (Array.isArray(value)) {
        value.forEach((item, index) =>
            validateSafeObject(item, `${path}[${index}]`, seen),
        );
    } else {
        for (const [key, child] of Object.entries(value)) {
            if (
                key === "__proto__" ||
                key === "prototype" ||
                key === "constructor" ||
                key.startsWith("$") ||
                key.includes(".")
            ) {
                throw new SurveyResponseServiceError(
                    "Survey response contains an invalid field name.",
                    {
                        code: "INVALID_SURVEY_RESPONSE_FIELD",
                        statusCode: 422,
                        details: { path: `${path}.${key}` },
                    },
                );
            }

            validateSafeObject(child, `${path}.${key}`, seen);
        }
    }

    seen.delete(value);
}

function normalizeResponsePayload(payload) {
    let response = payload;

    if (response && typeof response === "object" && !Array.isArray(response)) {
        if (Object.prototype.hasOwnProperty.call(response, "response")) {
            response = response.response;
        } else if (Object.prototype.hasOwnProperty.call(response, "answers")) {
            response = response.answers;
        } else if (Object.prototype.hasOwnProperty.call(response, "data")) {
            response = response.data;
        }
    }

    if (
        response == null ||
        typeof response !== "object" ||
        Array.isArray(response)
    ) {
        throw new SurveyResponseServiceError(
            "Survey response must be a JSON object.",
            {
                code: "SURVEY_RESPONSE_OBJECT_REQUIRED",
                statusCode: 422,
            },
        );
    }

    validateSafeObject(response);

    const normalized = clonePlain(response);
    const bytes = Buffer.byteLength(JSON.stringify(normalized), "utf8");

    if (bytes > RESPONSE_MAX_BYTES) {
        throw new SurveyResponseServiceError(
            "Survey response payload exceeds the maximum allowed size.",
            {
                code: "SURVEY_RESPONSE_TOO_LARGE",
                statusCode: 413,
                details: {
                    maxBytes: RESPONSE_MAX_BYTES,
                    actualBytes: bytes,
                },
            },
        );
    }

    return normalized;
}

function normalizeSort(sortBy, sortOrder) {
    const field = text(sortBy) || "updatedAt";
    const safeField = SORT_FIELDS.has(field) ? field : "updatedAt";
    const direction = text(sortOrder).toLowerCase() === "asc" ? 1 : -1;

    return { [safeField]: direction };
}

function plainResponse(row) {
    if (!row) return null;

    const json = typeof row.toSafeJSON === "function"
        ? row.toSafeJSON()
        : row.toObject
            ? row.toObject({ virtuals: true })
            : row;

    return {
        ...json,
        id: String(json.id || json._id || row._id || ""),
        templateId: json.templateId ? String(json.templateId) : null,
        projectId: json.projectId ? String(json.projectId) : null,
        respondentId: json.respondentId ? String(json.respondentId) : null,
        reviewedBy: json.reviewedBy ? String(json.reviewedBy) : null,
        rejectedBy: json.rejectedBy ? String(json.rejectedBy) : null,
        createdBy: json.createdBy ? String(json.createdBy) : null,
        updatedBy: json.updatedBy ? String(json.updatedBy) : null,
    };
}

function normalizePersistenceError(error) {
    if (error instanceof SurveyResponseServiceError) {
        return error;
    }

    if (error?.name === "ValidationError") {
        return new SurveyResponseServiceError("Survey response validation failed.", {
            code: "SURVEY_RESPONSE_VALIDATION_FAILED",
            statusCode: 422,
            details: {
                fields: Object.fromEntries(
                    Object.entries(error.errors || {}).map(([field, fieldError]) => [
                        field,
                        fieldError?.message || "Invalid value.",
                    ]),
                ),
            },
        });
    }

    if (error?.name === "CastError") {
        return new SurveyResponseServiceError("Invalid survey response value.", {
            code: "INVALID_SURVEY_RESPONSE_VALUE",
            statusCode: 422,
            details: { field: error.path || undefined },
        });
    }

    if (error?.code === 11000) {
        return new SurveyResponseServiceError(
            "A survey response with the same unique reference already exists.",
            {
                code: "DUPLICATE_SURVEY_RESPONSE",
                statusCode: 409,
                details: {
                    fields: error.keyPattern ? Object.keys(error.keyPattern) : [],
                },
            },
        );
    }

    return error;
}

async function ensureTemplateExists(templateId, { includeArchived = true } = {}) {
    const id = objectId(templateId, "template");
    if (!id) {
        throw new SurveyResponseServiceError("Survey template ID is required.", {
            code: "SURVEY_TEMPLATE_ID_REQUIRED",
            statusCode: 422,
        });
    }

    const filter = { _id: id };
    if (!includeArchived) {
        filter.status = { $ne: "archived" };
    }

    const template = await SurveyTemplate.findOne(filter).lean();

    if (!template) {
        throw new SurveyResponseServiceError("Survey template was not found.", {
            code: "SURVEY_TEMPLATE_NOT_FOUND",
            statusCode: 404,
        });
    }

    return template;
}

function assertTransition(currentStatus, nextStatus) {
    if (!nextStatus || currentStatus === nextStatus) return;

    if (!STATUS_TRANSITIONS[currentStatus]?.has(nextStatus)) {
        throw new SurveyResponseServiceError(
            `Survey response cannot change from ${currentStatus} to ${nextStatus}.`,
            {
                code: "INVALID_SURVEY_RESPONSE_STATUS_TRANSITION",
                statusCode: 409,
                details: { currentStatus, nextStatus },
            },
        );
    }
}

function parseExpectedRevision(value) {
    if (value == null || text(value) === "") return null;

    const revision = Number.parseInt(String(value), 10);
    if (!Number.isInteger(revision) || revision < 1) {
        throw new SurveyResponseServiceError("Expected revision must be a positive integer.", {
            code: "INVALID_EXPECTED_REVISION",
            statusCode: 422,
        });
    }

    return revision;
}

function buildFilter(filters = {}) {
    const query = {};

    const templateId = objectId(filters.templateId, "template");
    const projectId = objectId(filters.projectId, "project");
    const respondentId = objectId(filters.respondentId, "respondent");

    if (templateId) query.templateId = templateId;
    if (projectId) query.projectId = projectId;
    if (respondentId) query.respondentId = respondentId;

    const status = normalizeStatus(filters.status);
    if (status) query.status = status;

    const surveyDateFrom = normalizeDate(filters.surveyDateFrom, "surveyDateFrom");
    const surveyDateTo = normalizeDateEnd(filters.surveyDateTo, "surveyDateTo");

    if (surveyDateFrom || surveyDateTo) {
        query.surveyDate = {};
        if (surveyDateFrom) query.surveyDate.$gte = surveyDateFrom;
        if (surveyDateTo) query.surveyDate.$lte = surveyDateTo;
    }

    const submittedFrom = normalizeDate(filters.submittedFrom, "submittedFrom");
    const submittedTo = normalizeDateEnd(filters.submittedTo, "submittedTo");

    if (submittedFrom || submittedTo) {
        query.submittedAt = {};
        if (submittedFrom) query.submittedAt.$gte = submittedFrom;
        if (submittedTo) query.submittedAt.$lte = submittedTo;
    }

    if (filters.includeArchived !== true) {
        if (query.status) {
            if (query.status === "archived") {
                return query;
            }
        } else {
            query.status = { $ne: "archived" };
        }
    }

    return query;
}

export async function listSurveyResponses(filters = {}) {
    const { page, limit, skip } = normalizePagination(filters.page, filters.limit);
    const filter = buildFilter(filters);
    const sort = normalizeSort(filters.sortBy, filters.sortOrder);

    try {
        const [rows, total] = await Promise.all([
            SurveyResponse.find(filter)
                .sort(sort)
                .skip(skip)
                .limit(limit)
                .lean(),
            SurveyResponse.countDocuments(filter),
        ]);

        return {
            data: rows.map(plainResponse),
            pagination: {
                page,
                limit,
                total,
                pages: total === 0 ? 0 : Math.ceil(total / limit),
            },
        };
    } catch (error) {
        throw normalizePersistenceError(error);
    }
}

export async function getSurveyResponse(id) {
    const responseId = objectId(id, "response");

    if (!responseId) {
        throw new SurveyResponseServiceError("Survey response ID is required.", {
            code: "SURVEY_RESPONSE_ID_REQUIRED",
            statusCode: 422,
        });
    }

    try {
        const row = await SurveyResponse.findById(responseId).lean();

        if (!row) {
            throw new SurveyResponseServiceError("Survey response was not found.", {
                code: "SURVEY_RESPONSE_NOT_FOUND",
                statusCode: 404,
            });
        }

        return plainResponse(row);
    } catch (error) {
        throw normalizePersistenceError(error);
    }
}

export async function createSurveyResponse(payload = {}, context = {}) {
    const templateId = payload.templateId ?? payload.template_id;
    const template = await ensureTemplateExists(templateId, { includeArchived: false });

    const projectId = objectId(
        payload.projectId ?? payload.project_id,
        "project",
    );
    const respondentId = objectId(
        payload.respondentId ?? payload.respondent_id ?? context.userId,
        "respondent",
    );
    const createdBy = objectId(context.userId ?? payload.createdBy ?? payload.created_by, "createdBy");

    const status = normalizeStatus(payload.status) || "draft";
    const surveyDate = normalizeDate(payload.surveyDate ?? payload.survey_date, "surveyDate");
    const response = normalizeResponsePayload(payload.response ?? payload.answers ?? payload.data ?? payload);

    const created = new SurveyResponse({
        templateId: template._id,
        projectId,
        respondentId,
        response,
        status,
        revision: 1,
        surveyDate,
        createdBy,
        updatedBy: createdBy,
        submittedAt: status === "submitted" ? new Date() : null,
    });

    try {
        await created.validate();
        await created.save();
        return plainResponse(created);
    } catch (error) {
        throw normalizePersistenceError(error);
    }
}

export async function updateSurveyResponse(id, payload = {}, context = {}) {
    const responseId = objectId(id, "response");

    if (!responseId) {
        throw new SurveyResponseServiceError("Survey response ID is required.", {
            code: "SURVEY_RESPONSE_ID_REQUIRED",
            statusCode: 422,
        });
    }

    const existing = await SurveyResponse.findById(responseId);

    if (!existing) {
        throw new SurveyResponseServiceError("Survey response was not found.", {
            code: "SURVEY_RESPONSE_NOT_FOUND",
            statusCode: 404,
        });
    }

    const expectedRevision = parseExpectedRevision(
        payload.expectedRevision ?? payload.revision,
    );

    if (
        expectedRevision != null &&
        Number(existing.revision || 1) !== expectedRevision
    ) {
        throw new SurveyResponseServiceError(
            "Survey response was changed by another user. Reload the latest version before saving.",
            {
                code: "SURVEY_RESPONSE_REVISION_CONFLICT",
                statusCode: 409,
                details: {
                    expectedRevision,
                    currentRevision: Number(existing.revision || 1),
                },
            },
        );
    }

    if (payload.templateId || payload.template_id) {
        const template = await ensureTemplateExists(
            payload.templateId ?? payload.template_id,
            { includeArchived: false },
        );
        existing.templateId = template._id;
    }

    if (Object.prototype.hasOwnProperty.call(payload, "projectId") ||
        Object.prototype.hasOwnProperty.call(payload, "project_id")) {
        existing.projectId = objectId(
            payload.projectId ?? payload.project_id,
            "project",
        );
    }

    if (Object.prototype.hasOwnProperty.call(payload, "respondentId") ||
        Object.prototype.hasOwnProperty.call(payload, "respondent_id")) {
        existing.respondentId = objectId(
            payload.respondentId ?? payload.respondent_id,
            "respondent",
        );
    }

    if (
        Object.prototype.hasOwnProperty.call(payload, "response") ||
        Object.prototype.hasOwnProperty.call(payload, "answers") ||
        Object.prototype.hasOwnProperty.call(payload, "data")
    ) {
        existing.response = normalizeResponsePayload(
            payload.response ?? payload.answers ?? payload.data,
        );
    }

    if (
        Object.prototype.hasOwnProperty.call(payload, "surveyDate") ||
        Object.prototype.hasOwnProperty.call(payload, "survey_date")
    ) {
        existing.surveyDate = normalizeDate(
            payload.surveyDate ?? payload.survey_date,
            "surveyDate",
        );
    }

    const nextStatus = normalizeStatus(payload.status);
    if (nextStatus) {
        assertTransition(existing.status, nextStatus);
        existing.status = nextStatus;
    }

    const actorId = objectId(context.userId ?? payload.updatedBy ?? payload.updated_by, "updatedBy");
    existing.updatedBy = actorId;
    existing.revision = Number(existing.revision || 1) + 1;

    if (existing.status === "submitted" && !existing.submittedAt) {
        existing.submittedAt = new Date();
    }

    if (existing.status === "rejected") {
        existing.rejectionReason = text(
            payload.rejectionReason ?? payload.rejection_reason ?? existing.rejectionReason,
        );
        existing.rejectedAt = existing.rejectedAt || new Date();
        existing.rejectedBy = actorId || existing.rejectedBy || null;
    } else if (nextStatus && nextStatus !== "rejected") {
        existing.rejectionReason = "";
        existing.rejectedAt = null;
        existing.rejectedBy = null;
    }

    if (existing.status === "reviewed") {
        existing.reviewedAt = existing.reviewedAt || new Date();
        existing.reviewedBy = actorId || existing.reviewedBy || null;
    }

    try {
        await existing.validate();
        await existing.save();
        return plainResponse(existing);
    } catch (error) {
        throw normalizePersistenceError(error);
    }
}

export async function archiveSurveyResponse(id, context = {}) {
    const responseId = objectId(id, "response");

    if (!responseId) {
        throw new SurveyResponseServiceError("Survey response ID is required.", {
            code: "SURVEY_RESPONSE_ID_REQUIRED",
            statusCode: 422,
        });
    }

    const existing = await SurveyResponse.findById(responseId);
    if (!existing) {
        throw new SurveyResponseServiceError("Survey response was not found.", {
            code: "SURVEY_RESPONSE_NOT_FOUND",
            statusCode: 404,
        });
    }

    if (existing.status === "archived") {
        return plainResponse(existing);
    }

    existing.status = "archived";
    existing.revision = Number(existing.revision || 1) + 1;
    existing.updatedBy = objectId(context.userId, "updatedBy");

    try {
        await existing.save();
        return plainResponse(existing);
    } catch (error) {
        throw normalizePersistenceError(error);
    }
}

export async function deleteSurveyResponse(id, context = {}) {
    return archiveSurveyResponse(id, context);
}

export const list = listSurveyResponses;
export const get = getSurveyResponse;
export const create = createSurveyResponse;
export const update = updateSurveyResponse;
export const remove = deleteSurveyResponse;

export default {
    listSurveyResponses,
    getSurveyResponse,
    createSurveyResponse,
    updateSurveyResponse,
    archiveSurveyResponse,
    deleteSurveyResponse,
};
