import mongoose from "mongoose";
import Quotation, { QUOTATION_STATUSES } from "../../models/Quotation.js";
import RFQ from "../../models/RFQ.js";
import Vendor from "../../models/Vendor.js";

const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 250;
const TAX_RATE = 15;
const OTHER_CHARGES_DEFAULT = 1500;

export class QuotationServiceError extends Error {
  constructor(message, { code = "QUOTATION_ERROR", statusCode = 400, details } = {}) {
    super(message);
    this.name = "QuotationServiceError";
    this.code = code;
    this.statusCode = statusCode;
    this.details = details;
    Error.captureStackTrace?.(this, QuotationServiceError);
  }
}

const text = (value) => String(value ?? "").trim();
const normalizeEmail = (value) => text(value).toLowerCase();
const escapeRegex = (value) => text(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function objectId(value, field = "ID") {
  const valueText = text(value);
  if (!mongoose.isValidObjectId(valueText)) {
    throw new QuotationServiceError(`Invalid ${field}.`, { code: `INVALID_${field.replace(/\s+/g, "_").toUpperCase()}`, statusCode: 400 });
  }
  return new mongoose.Types.ObjectId(valueText);
}

function pageValue(value) {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
}

function limitValue(value) {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) && parsed > 0 ? Math.min(parsed, MAX_LIMIT) : DEFAULT_LIMIT;
}

function dateValue(value, field, { optional = false } = {}) {
  if ((value === undefined || value === null || value === "") && optional) return null;
  const raw = text(value);
  if (!raw) throw new QuotationServiceError(`${field} is required.`, { code: `${field.toUpperCase().replace(/\s+/g, "_")}_REQUIRED`, statusCode: 422 });
  const date = /^\d{4}-\d{2}-\d{2}$/.test(raw) ? new Date(`${raw}T00:00:00.000Z`) : new Date(raw);
  if (Number.isNaN(date.getTime())) throw new QuotationServiceError(`${field} is invalid.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
  return date;
}

function numberValue(value, field, { min = 0, optional = false } = {}) {
  if ((value === undefined || value === null || value === "") && optional) return 0;
  const number = Number(value);
  if (!Number.isFinite(number) || number < min) throw new QuotationServiceError(`${field} must be a valid number greater than or equal to ${min}.`, { code: `INVALID_${field.toUpperCase().replace(/\s+/g, "_")}`, statusCode: 422 });
  return number;
}

function actorId(value) {
  const valueText = text(value);
  return valueText && mongoose.isValidObjectId(valueText) ? new mongoose.Types.ObjectId(valueText) : null;
}

function statusLabel(status) {
  return ({
    draft: "Draft",
    issued: "Issued",
    submitted: "Submitted",
    approved: "Form Approved",
    rejected: "Rejected",
    awarded: "Awarded",
    not_responded: "Not Responded",
  })[status] || status;
}

function serialize(row) {
  const value = typeof row.toObject === "function" ? row.toObject() : row;
  return {
    id: String(value._id),
    quotationNo: value.reference,
    vendor: value.vendor?.vendorId ? String(value.vendor.vendorId) : "",
    vendorName: value.vendor?.name || "",
    vendorEmail: value.vendor?.email || "",
    projectTitle: value.projectTitle,
    projectLocation: value.projectLocation || "",
    date: value.quotationDate?.toISOString?.().slice(0, 10) || "",
    grandTotal: Number(value.grandTotal || 0),
    currency: value.currency,
    margin: Number(value.margin || 0),
    status: statusLabel(value.status),
    statusCode: value.status,
    category: value.category || "General",
    items: Array.isArray(value.lines) ? value.lines.length : 0,
    progress: value.status === "awarded" ? 100 : value.status === "submitted" || value.status === "approved" ? 50 : 0,
    validUntil: value.validUntil?.toISOString?.().slice(0, 10) || "",
    createdDate: value.createdAt?.toISOString?.().slice(0, 10) || "",
    clientName: value.clientName || "",
    formTemplate: value.formTemplate || "",
    scopeSummary: value.scopeSummary || "",
    terms: value.terms || "",
    rfq: value.rfq?.rfqId ? { id: String(value.rfq.rfqId), reference: value.rfq.reference || "" } : null,
    lines: Array.isArray(value.lines) ? value.lines.map((line) => ({
      id: String(line._id),
      boqLineId: line.boqLineId ? String(line.boqLineId) : null,
      module: line.module || "",
      category: line.category || "",
      description: line.description,
      unit: line.unit,
      quantity: Number(line.quantity || 0),
      materialCost: Number(line.materialCost || 0),
      serviceCost: Number(line.serviceCost || 0),
      quotedRate: Number(line.quotedRate || 0),
      taxRate: Number(line.taxRate || 0),
      lineSubtotal: Number(line.lineSubtotal || 0),
      lineTax: Number(line.lineTax || 0),
      lineTotal: Number(line.lineTotal || 0),
      sortOrder: Number(line.sortOrder || 0),
    })) : [],
    paymentSchedule: value.paymentSchedule || { installments: [] },
    subtotal: Number(value.subtotal || 0),
    taxTotal: Number(value.taxTotal || 0),
    otherCharges: Number(value.otherCharges || 0),
    workflowHistory: Array.isArray(value.workflowHistory) ? value.workflowHistory.map((entry) => ({
      status: statusLabel(entry.status),
      statusCode: entry.status,
      comment: entry.comment || "",
      performedAt: entry.performedAt,
      performedBy: entry.performedBy ? String(entry.performedBy) : null,
    })) : [],
    submittedAt: value.submittedAt,
    approvedAt: value.approvedAt,
    rejectedAt: value.rejectedAt,
    awardedAt: value.awardedAt,
    createdAt: value.createdAt,
    updatedAt: value.updatedAt,
  };
}

async function nextReference() {
  const year = new Date().getUTCFullYear();
  const pattern = new RegExp(`^QT-${year}-(\\d+)$`, "i");
  const rows = await Quotation.find({ reference: new RegExp(`^QT-${year}-`, "i") }).select("reference").lean();
  let max = 0;
  for (const row of rows) {
    const match = pattern.exec(row.reference || "");
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `QT-${year}-${String(max + 1).padStart(3, "0")}`;
}

function normalizeLines(lines) {
  if (!Array.isArray(lines) || !lines.length) {
    throw new QuotationServiceError("At least one quotation line is required.", { code: "QUOTATION_LINES_REQUIRED", statusCode: 422 });
  }
  return lines.map((input, index) => {
    const description = text(input?.description);
    const unit = text(input?.unit || input?.uom);
    if (!description) throw new QuotationServiceError(`Line ${index + 1}: description is required.`, { code: "QUOTATION_LINE_DESCRIPTION_REQUIRED", statusCode: 422 });
    if (!unit) throw new QuotationServiceError(`Line ${index + 1}: unit is required.`, { code: "QUOTATION_LINE_UNIT_REQUIRED", statusCode: 422 });
    const quantity = numberValue(input?.quantity, `Line ${index + 1} quantity`, { min: 0.0001 });
    const quotedRate = numberValue(input?.quotedRate ?? input?.salesPrice ?? input?.unitPrice, `Line ${index + 1} quoted rate`, { min: 0 });
    const materialCost = numberValue(input?.materialCost, `Line ${index + 1} material cost`, { min: 0, optional: true });
    const serviceCost = numberValue(input?.serviceCost, `Line ${index + 1} service cost`, { min: 0, optional: true });
    const taxRate = numberValue(input?.taxRate ?? input?.gct, `Line ${index + 1} tax rate`, { min: 0, optional: true });
    const lineSubtotal = Number((quantity * quotedRate).toFixed(2));
    const lineTax = Number((lineSubtotal * (taxRate / 100)).toFixed(2));
    const lineTotal = Number((lineSubtotal + lineTax).toFixed(2));
    return {
      boqLineId: text(input?.boqLineId) ? objectId(input.boqLineId, "BOQ line ID") : null,
      rateItemId: text(input?.rateItemId) ? objectId(input.rateItemId, "rate item ID") : null,
      module: text(input?.module),
      category: text(input?.category),
      description,
      unit,
      quantity,
      materialCost,
      serviceCost,
      quotedRate,
      taxRate,
      lineSubtotal,
      lineTax,
      lineTotal,
      sortOrder: Number.isFinite(Number(input?.sortOrder)) ? Number(input.sortOrder) : index,
    };
  });
}

async function resolveVendor(vendorId) {
  const vendor = await Vendor.findOne({ _id: objectId(vendorId, "vendor ID"), accountStatus: "APPROVED" }).lean();
  if (!vendor) throw new QuotationServiceError("Only an approved vendor can receive a quotation.", { code: "APPROVED_VENDOR_REQUIRED", statusCode: 422 });
  return {
    vendorId: vendor._id,
    name: vendor.companyName,
    email: normalizeEmail(vendor.contact?.email),
    contactName: text(vendor.contact?.name),
  };
}

async function resolveRFQ(rfqId, vendorId) {
  if (!text(rfqId)) return null;
  const rfq = await RFQ.findById(objectId(rfqId, "RFQ ID")).lean();
  if (!rfq) throw new QuotationServiceError("RFQ not found.", { code: "RFQ_NOT_FOUND", statusCode: 404 });
  if (rfq.status !== "sent" && rfq.status !== "closed") throw new QuotationServiceError("Quotation can only be linked to a sent or closed RFQ.", { code: "RFQ_NOT_QUOTABLE", statusCode: 409 });
  const invited = Array.isArray(rfq.vendors) && rfq.vendors.some((vendor) => String(vendor.vendorId) === String(vendorId) && ["invited", "submitted"].includes(vendor.inviteStatus));
  if (!invited) throw new QuotationServiceError("The selected vendor is not an invited vendor for this RFQ.", { code: "RFQ_VENDOR_NOT_INVITED", statusCode: 422 });
  return { rfqId: rfq._id, reference: rfq.reference };
}

function buildTotals(lines, otherCharges = OTHER_CHARGES_DEFAULT) {
  const subtotal = Number(lines.reduce((sum, line) => sum + line.lineSubtotal, 0).toFixed(2));
  const taxTotal = Number(lines.reduce((sum, line) => sum + line.lineTax, 0).toFixed(2));
  const charges = Number(numberValue(otherCharges, "Other charges", { min: 0, optional: true }).toFixed(2));
  return { subtotal, taxTotal, otherCharges: charges, grandTotal: Number((subtotal + taxTotal + charges).toFixed(2)) };
}

async function normalizePayload(payload, { existing } = {}) {
  const vendorId = text(payload?.vendorId) || existing?.vendor?.vendorId;
  if (!vendorId) throw new QuotationServiceError("Vendor is required.", { code: "VENDOR_REQUIRED", statusCode: 422 });
  const vendor = await resolveVendor(vendorId);
  const rfq = await resolveRFQ(payload?.rfqId ?? existing?.rfq?.rfqId, vendor.vendorId);
  const lines = payload?.lines !== undefined ? normalizeLines(payload.lines) : existing?.lines || [];
  if (!lines.length) throw new QuotationServiceError("At least one quotation line is required.", { code: "QUOTATION_LINES_REQUIRED", statusCode: 422 });
  const quotationDate = payload?.quotationDate !== undefined ? dateValue(payload.quotationDate, "Quotation date") : existing?.quotationDate || new Date();
  const validUntil = payload?.validUntil !== undefined ? dateValue(payload.validUntil, "Valid until") : existing?.validUntil;
  if (!validUntil || validUntil < quotationDate) throw new QuotationServiceError("Valid until date cannot be earlier than the quotation date.", { code: "INVALID_VALID_UNTIL", statusCode: 422 });
  const currency = text(payload?.currency ?? existing?.currency ?? "USD").toUpperCase();
  if (!currency || currency.length > 12) throw new QuotationServiceError("Currency is required and must be 12 characters or fewer.", { code: "INVALID_CURRENCY", statusCode: 422 });
  const totals = buildTotals(lines, payload?.otherCharges ?? existing?.otherCharges ?? OTHER_CHARGES_DEFAULT);
  const baseCost = lines.reduce((sum, line) => sum + (line.materialCost + line.serviceCost) * line.quantity, 0);
  const margin = totals.grandTotal > 0 ? Number((((totals.grandTotal - baseCost) / totals.grandTotal) * 100).toFixed(2)) : 0;
  return {
    vendor,
    rfq,
    projectTitle: text(payload?.projectTitle ?? existing?.projectTitle),
    projectLocation: text(payload?.projectLocation ?? existing?.projectLocation),
    clientName: text(payload?.clientName ?? existing?.clientName ?? vendor.name),
    currency,
    quotationDate,
    validUntil,
    scopeSummary: text(payload?.scopeSummary ?? existing?.scopeSummary),
    terms: text(payload?.terms ?? existing?.terms),
    formTemplate: text(payload?.formTemplate ?? existing?.formTemplate),
    category: text(payload?.category ?? existing?.category ?? lines[0]?.category ?? "General") || "General",
    lines,
    paymentSchedule: payload?.paymentSchedule !== undefined ? { installments: Array.isArray(payload.paymentSchedule?.installments) ? payload.paymentSchedule.installments.map((x) => ({ id: text(x?.id), installmentName: text(x?.installmentName || x?.name), modules: Array.isArray(x?.modules) ? x.modules.map(text) : [], amount: numberValue(x?.amount, "Payment installment amount", { min: 0, optional: true }), days: Array.isArray(x?.days) ? x.days.map((d) => Number(d)).filter(Number.isFinite) : [] })) : [] } : (existing?.paymentSchedule || { installments: [] }),
    ...totals,
    margin,
  };
}

export async function listQuotations({ search = "", status = "", vendorId = "", rfqId = "", page = 1, limit = DEFAULT_LIMIT } = {}) {
  const safePage = pageValue(page);
  const safeLimit = limitValue(limit);
  const query = {};
  if (text(status)) {
    if (!QUOTATION_STATUSES.includes(text(status).toLowerCase())) throw new QuotationServiceError("Invalid quotation status filter.", { code: "INVALID_QUOTATION_STATUS", statusCode: 422 });
    query.status = text(status).toLowerCase();
  }
  if (text(vendorId)) query["vendor.vendorId"] = objectId(vendorId, "vendor ID");
  if (text(rfqId)) query["rfq.rfqId"] = objectId(rfqId, "RFQ ID");
  const normalizedSearch = text(search);
  if (normalizedSearch) {
    const regex = new RegExp(escapeRegex(normalizedSearch), "i");
    query.$or = [{ reference: regex }, { projectTitle: regex }, { "vendor.name": regex }, { clientName: regex }];
  }
  const skip = (safePage - 1) * safeLimit;
  const [rows, total] = await Promise.all([
    Quotation.find(query).sort({ updatedAt: -1, _id: -1 }).skip(skip).limit(safeLimit).lean(),
    Quotation.countDocuments(query),
  ]);
  return { data: rows.map(serialize), pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) } };
}

export async function getQuotation(id) {
  const row = await Quotation.findById(objectId(id, "quotation ID")).lean();
  if (!row) throw new QuotationServiceError("Quotation not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
  return serialize(row);
}

export async function createQuotation({ payload, userId }) {
  const normalized = await normalizePayload(payload);
  if (!normalized.projectTitle) throw new QuotationServiceError("Project title is required.", { code: "PROJECT_TITLE_REQUIRED", statusCode: 422 });
  const explicitReference = text(payload?.reference).toUpperCase();
  const actor = actorId(userId);

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const reference = explicitReference || await nextReference();
    try {
      const row = await Quotation.create({ ...normalized, reference, status: "draft", createdBy: actor, updatedBy: actor, workflowHistory: [{ status: "draft", comment: "Quotation draft created.", performedBy: actor, performedAt: new Date() }] });
      return serialize(row);
    } catch (error) {
      if (error?.code === 11000 && !explicitReference) continue;
      if (error?.code === 11000) throw new QuotationServiceError("A quotation with the same reference already exists.", { code: "QUOTATION_REFERENCE_DUPLICATE", statusCode: 409 });
      throw error;
    }
  }

  throw new QuotationServiceError("Unable to generate a unique quotation reference. Please try again.", { code: "QUOTATION_REFERENCE_GENERATION_FAILED", statusCode: 409 });
}

export async function updateQuotation({ id, payload, userId }) {
  const row = await Quotation.findById(objectId(id, "quotation ID"));
  if (!row) throw new QuotationServiceError("Quotation not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
  if (row.status !== "draft") throw new QuotationServiceError("Only draft quotations can be edited.", { code: "QUOTATION_NOT_EDITABLE", statusCode: 409 });
  const normalized = await normalizePayload(payload, { existing: row.toObject() });
  if (!normalized.projectTitle) throw new QuotationServiceError("Project title is required.", { code: "PROJECT_TITLE_REQUIRED", statusCode: 422 });
  Object.assign(row, normalized, { updatedBy: actorId(userId) });
  await row.save();
  return serialize(row);
}

async function transition({ id, userId, status, comment, allowedFrom, timestampField }) {
  const quotationId = objectId(id, "quotation ID");
  const actor = actorId(userId);
  const now = new Date();
  const updated = await Quotation.findOneAndUpdate(
    { _id: quotationId, status: { $in: allowedFrom } },
    {
      $set: { status, [timestampField]: now, updatedBy: actor },
      $push: { workflowHistory: { status, comment: text(comment), performedBy: actor, performedAt: now } },
    },
    { new: true, runValidators: true },
  );

  if (updated) return serialize(updated);

  const existing = await Quotation.findById(quotationId).select("status").lean();
  if (!existing) throw new QuotationServiceError("Quotation not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
  throw new QuotationServiceError(`Quotation cannot move to ${statusLabel(status)} from its current status.`, { code: "INVALID_QUOTATION_TRANSITION", statusCode: 409 });
}

export async function submitQuotation({ id, userId, comment }) {
  return transition({ id, userId, status: "submitted", comment: comment || "Quotation submitted for approval.", allowedFrom: ["draft"], timestampField: "submittedAt" });
}

export async function approveQuotation({ id, userId, comment }) {
  return transition({ id, userId, status: "approved", comment: comment || "Quotation approved.", allowedFrom: ["submitted"], timestampField: "approvedAt" });
}

export async function rejectQuotation({ id, userId, comment }) {
  const cleanComment = text(comment);
  if (!cleanComment) throw new QuotationServiceError("A rejection reason is required.", { code: "REJECTION_REASON_REQUIRED", statusCode: 422 });
  return transition({ id, userId, status: "rejected", comment: cleanComment, allowedFrom: ["submitted"], timestampField: "rejectedAt" });
}

export async function awardQuotation({ id, userId, comment }) {
  return transition({ id, userId, status: "awarded", comment: comment || "Quotation awarded.", allowedFrom: ["approved"], timestampField: "awardedAt" });
}

export async function deleteQuotation({ id }) {
  const row = await Quotation.findById(objectId(id, "quotation ID"));
  if (!row) throw new QuotationServiceError("Quotation not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
  if (row.status !== "draft" && row.status !== "rejected") throw new QuotationServiceError("Only draft or rejected quotations can be deleted.", { code: "QUOTATION_NOT_DELETABLE", statusCode: 409 });
  await Quotation.deleteOne({ _id: row._id });
  return { id: String(row._id), deleted: true };
}

export default { listQuotations, getQuotation, createQuotation, updateQuotation, submitQuotation, approveQuotation, rejectQuotation, awardQuotation, deleteQuotation };
