// src/services/masterRate/rateService.js

import mongoose from "mongoose";

import MarketRateItem from "../../models/MarketRateItem.js";
import RateHistory from "../../models/RateHistory.js";
import RateCategory from "../../models/RateCategory.js";
import Unit from "../../models/Unit.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;

const RATE_STATUS = Object.freeze([
    "active",
    "inactive",
]);

const SORT_FIELDS = Object.freeze({
    code: "code",
    categoryType: "categoryType",
    category: "category",
    subcategory: "subcategory",
    unit: "unit",
    standardRate: "standardRate",
    effectiveDate: "effectiveDate",
    status: "status",
    createdAt: "createdAt",
    updatedAt: "updatedAt",
});

/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class RateServiceError extends Error {
    constructor(
        message,
        {
            code = "RATE_SERVICE_ERROR",
            statusCode = 400,
            details = undefined,
            cause = undefined,
        } = {},
    ) {
        super(message);

        this.name = "RateServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;

        if (cause) {
            this.cause = cause;
        }

        Error.captureStackTrace?.(
            this,
            RateServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeString(value) {
    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value).trim();
}

function normalizeOptionalString(value) {
    const normalized = normalizeString(value);

    return normalized || null;
}

function normalizeStatus(value) {
    const normalized = normalizeString(value).toLowerCase();

    if (!normalized) {
        return "active";
    }

    if (
        normalized === "active" ||
        normalized === "inactive"
    ) {
        return normalized;
    }

    throw new RateServiceError(
        "Invalid rate status.",
        {
            code: "INVALID_RATE_STATUS",
            statusCode: 422,
            details: {
                allowed: RATE_STATUS,
            },
        },
    );
}

function normalizeNumber(
    value,
    fieldName,
) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        throw new RateServiceError(
            `${fieldName} is required.`,
            {
                code: `${fieldName
                    .toUpperCase()
                    .replace(/\s+/g, "_")}_REQUIRED`,
                statusCode: 422,
            },
        );
    }

    const numberValue = Number(value);

    if (
        !Number.isFinite(
            numberValue,
        )
    ) {
        throw new RateServiceError(
            `${fieldName} must be a valid number.`,
            {
                code: "INVALID_RATE_NUMBER",
                statusCode: 422,
                details: {
                    field: fieldName,
                },
            },
        );
    }

    if (numberValue < 0) {
        throw new RateServiceError(
            `${fieldName} cannot be negative.`,
            {
                code: "NEGATIVE_RATE_VALUE",
                statusCode: 422,
                details: {
                    field: fieldName,
                },
            },
        );
    }

    return numberValue;
}

function normalizePage(value) {
    const page = Number.parseInt(
        String(value ?? ""),
        10,
    );

    if (
        !Number.isFinite(page) ||
        page < 1
    ) {
        return DEFAULT_PAGE;
    }

    return page;
}

function normalizeLimit(value) {
    const limit = Number.parseInt(
        String(value ?? ""),
        10,
    );

    if (
        !Number.isFinite(limit) ||
        limit < 1
    ) {
        return DEFAULT_LIMIT;
    }

    return Math.min(
        MAX_LIMIT,
        limit,
    );
}

function normalizeSort(value) {
    const normalized =
        normalizeString(value);

    return (
        SORT_FIELDS[normalized] ||
        "updatedAt"
    );
}

function normalizeSortDirection(value) {
    return normalizeString(value).toLowerCase() ===
        "desc"
        ? -1
        : 1;
}

function ensureObjectId(id) {
    const normalized = normalizeString(id);

    if (
        !mongoose.Types.ObjectId.isValid(
            normalized,
        )
    ) {
        throw new RateServiceError(
            "Invalid master rate ID.",
            {
                code: "INVALID_MASTER_RATE_ID",
                statusCode: 400,
            },
        );
    }

    return new mongoose.Types.ObjectId(
        normalized,
    );
}

function escapeRegex(value) {
    return value.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
    );
}

function parseDateOnly(value) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        throw new RateServiceError(
            "Effective date is required.",
            {
                code: "EFFECTIVE_DATE_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        typeof value === "string"
    ) {
        const match =
            value.trim().match(
                /^(\d{4})-(\d{2})-(\d{2})$/,
            );

        if (!match) {
            throw new RateServiceError(
                "Effective date must use YYYY-MM-DD format.",
                {
                    code:
                        "INVALID_EFFECTIVE_DATE",
                    statusCode: 422,
                },
            );
        }

        const year =
            Number(match[1]);

        const month =
            Number(match[2]);

        const day =
            Number(match[3]);

        const date =
            new Date(
                year,
                month - 1,
                day,
                0,
                0,
                0,
                0,
            );

        if (
            date.getFullYear() !==
                year ||
            date.getMonth() !==
                month - 1 ||
            date.getDate() !==
                day
        ) {
            throw new RateServiceError(
                "Effective date is invalid.",
                {
                    code:
                        "INVALID_EFFECTIVE_DATE",
                    statusCode: 422,
                },
            );
        }

        return date;
    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime(),
        )
    ) {
        throw new RateServiceError(
            "Effective date is invalid.",
            {
                code:
                    "INVALID_EFFECTIVE_DATE",
                statusCode: 422,
            },
        );
    }

    date.setHours(
        0,
        0,
        0,
        0,
    );

    return date;
}

function formatDateOnly(value) {
    if (!value) {
        return "";
    }

    const date =
        value instanceof Date
            ? value
            : new Date(value);

    if (
        Number.isNaN(
            date.getTime(),
        )
    ) {
        return "";
    }

    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1,
        ).padStart(
            2,
            "0",
        );

    const day =
        String(
            date.getDate(),
        ).padStart(
            2,
            "0",
        );

    return `${year}-${month}-${day}`;
}

function getUserId(user) {
    return (
        user?.id ||
        user?._id ||
        user?.userId ||
        null
    );
}

function getUserName(user) {
    return (
        user?.displayName ||
        user?.name ||
        user?.email ||
        ""
    );
}

/* -------------------------------------------------------------------------- */
/* Serialization                                                              */
/* -------------------------------------------------------------------------- */

function serializeHistoryItem(item) {
    if (!item) {
        return null;
    }

    return {
        rate: Number(
            item.rate ?? 0,
        ),

        effectiveDate:
            formatDateOnly(
                item.effectiveDate,
            ),

        updatedAt:
            item.updatedAt
                ? new Date(
                      item.updatedAt,
                  ).toISOString()
                : "",

        updatedBy:
            item.updatedByName ||
            (
                item.updatedBy
                    ? item.updatedBy.toString()
                    : ""
            ),
    };
}

function serializeRate(document) {
    if (!document) {
        return null;
    }

    if (
        typeof document.toSafeJSON ===
        "function"
    ) {
        return document.toSafeJSON();
    }

    const data =
        typeof document.toObject ===
        "function"
            ? document.toObject({
                  depopulate: true,
              })
            : document;

    const history =
        Array.isArray(
            data.history,
        )
            ? data.history
                  .slice()
                  .sort(
                      (a, b) =>
                          new Date(
                              b.effectiveDate,
                          ).getTime() -
                          new Date(
                              a.effectiveDate,
                          ).getTime(),
                  )
                  .map(
                      serializeHistoryItem,
                  )
            : [];

    return {
        id:
            data._id?.toString(),

        code:
            data.code || "",

        /*
         * Preserve frontend contract.
         */
        rate:
            Number(
                data.rate ??
                    data.standardRate ??
                    0,
            ),

        categoryType:
            data.categoryType || "",

        category:
            data.category || "",

        subcategory:
            data.subcategory || "",

        module:
            data.module || "",

        description:
            data.description || "",

        unit:
            data.unit || "",

        standardRate:
            Number(
                data.standardRate ??
                    data.rate ??
                    0,
            ),

        effectiveDate:
            formatDateOnly(
                data.effectiveDate,
            ),

        status:
            data.status ===
            "inactive"
                ? "inactive"
                : "active",

        history,

        createdAt:
            data.createdAt ||
            null,

        updatedAt:
            data.updatedAt ||
            null,
    };
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

function validatePayload(
    payload,
    {
        partial = false,
        allowCode = true,
        requireCode = !partial,
        requireCategoryType = !partial,
    } = {},
) {
    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(payload)
    ) {
        throw new RateServiceError(
            "Master rate payload must be an object.",
            {
                code:
                    "INVALID_MASTER_RATE_PAYLOAD",
                statusCode: 400,
            },
        );
    }

    const data = {};

    const hasCode = Object.prototype.hasOwnProperty.call(
        payload,
        "code",
    );

    if (
        allowCode &&
        (hasCode || requireCode)
    ) {
        const code =
            normalizeString(
                payload.code,
            ).toUpperCase();

        if (!code) {
            if (requireCode) {
                throw new RateServiceError(
                    "Rate code is required.",
                    {
                        code:
                            "RATE_CODE_REQUIRED",
                        statusCode: 422,
                    },
                );
            }
        } else if (code.length > 50) {
            throw new RateServiceError(
                "Rate code cannot exceed 50 characters.",
                {
                    code:
                        "INVALID_RATE_CODE",
                    statusCode: 422,
                },
            );
        } else {
            data.code = code;
        }
    } else if (hasCode && !allowCode) {
        throw new RateServiceError(
            "Rate code is generated by the system and cannot be changed manually.",
            {
                code: "RATE_CODE_MANAGED_BY_SYSTEM",
                statusCode: 422,
            },
        );
    }

    const hasCategoryType =
        Object.prototype.hasOwnProperty.call(
            payload,
            "categoryType",
        ) ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "categorytype",
        );

    if (
        hasCategoryType ||
        requireCategoryType
    ) {
        const categoryType =
            normalizeString(
                payload.categoryType ??
                    payload.categorytype,
            );

        if (!categoryType) {
            if (requireCategoryType) {
                throw new RateServiceError(
                    "Category type is required.",
                    {
                        code:
                            "CATEGORY_TYPE_REQUIRED",
                        statusCode: 422,
                    },
                );
            }
        }

        if (
            categoryType.length >
            150
        ) {
            throw new RateServiceError(
                "Category type cannot exceed 150 characters.",
                {
                    code:
                        "INVALID_CATEGORY_TYPE",
                    statusCode: 422,
                },
            );
        }

        data.categoryType =
            categoryType;
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "category",
        )
    ) {
        const category =
            normalizeString(
                payload.category,
            );

        if (!category) {
            throw new RateServiceError(
                "Category is required.",
                {
                    code:
                        "CATEGORY_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        if (
            category.length >
            150
        ) {
            throw new RateServiceError(
                "Category cannot exceed 150 characters.",
                {
                    code:
                        "INVALID_CATEGORY",
                    statusCode: 422,
                },
            );
        }

        data.category =
            category;
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "subcategory",
        )
    ) {
        const subcategory =
            normalizeString(
                payload.subcategory,
            );

        if (!subcategory) {
            throw new RateServiceError(
                "Subcategory is required.",
                {
                    code:
                        "SUBCATEGORY_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        if (
            subcategory.length >
            150
        ) {
            throw new RateServiceError(
                "Subcategory cannot exceed 150 characters.",
                {
                    code:
                        "INVALID_SUBCATEGORY",
                    statusCode: 422,
                },
            );
        }

        data.subcategory =
            subcategory;
    }

    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "module",
        )
    ) {
        data.module =
            normalizeOptionalString(
                payload.module,
            ) || "";
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "description",
        )
    ) {
        const description =
            normalizeString(
                payload.description,
            );

        if (!description) {
            throw new RateServiceError(
                "Description is required.",
                {
                    code:
                        "DESCRIPTION_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        if (
            description.length >
            2000
        ) {
            throw new RateServiceError(
                "Description cannot exceed 2000 characters.",
                {
                    code:
                        "INVALID_DESCRIPTION",
                    statusCode: 422,
                },
            );
        }

        data.description =
            description;
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "unit",
        )
    ) {
        const unit =
            normalizeString(
                payload.unit,
            );

        if (!unit) {
            throw new RateServiceError(
                "Unit is required.",
                {
                    code:
                        "UNIT_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        if (
            unit.length > 100
        ) {
            throw new RateServiceError(
                "Unit cannot exceed 100 characters.",
                {
                    code:
                        "INVALID_UNIT",
                    statusCode: 422,
                },
            );
        }

        data.unit = unit;
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "standardRate",
        )
    ) {
        data.standardRate =
            normalizeNumber(
                payload.standardRate,
                "standardRate",
            );

        /*
         * Keep the existing frontend `rate` property synchronized.
         */
        data.rate =
            data.standardRate;
    }

    if (
        !partial ||
        Object.prototype.hasOwnProperty.call(
            payload,
            "effectiveDate",
        )
    ) {
        data.effectiveDate =
            parseDateOnly(
                payload.effectiveDate,
            );
    }

    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "status",
        )
    ) {
        data.status =
            normalizeStatus(
                payload.status,
            );
    }

    return data;
}

/* -------------------------------------------------------------------------- */
/* Persistence Helpers                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Normalize authenticated user ids before storing them in ObjectId fields.
 * The service is the final persistence boundary, so callers cannot
 * accidentally persist arbitrary strings as audit identities.
 */
function normalizeUserId(
    userId,
    fieldName = "updatedBy",
) {
    const normalized =
        normalizeString(
            userId,
        );

    if (!normalized) {
        return null;
    }

    if (
        !mongoose.Types.ObjectId.isValid(
            normalized,
        )
    ) {
        throw new RateServiceError(
            `Invalid ${fieldName} user identifier.`,
            {
                code:
                    "INVALID_AUDIT_USER_ID",
                statusCode: 400,
                details: {
                    field:
                        fieldName,
                },
            },
        );
    }

    return new mongoose.Types.ObjectId(
        normalized,
    );
}

/**
 * Normalize persistence errors emitted by Mongoose.
 *
 * Duplicate-code handling is kept separate from validation errors so the
 * frontend receives a deterministic response for every common write case.
 */
function normalizePersistenceError(
    error,
) {
    if (
        error instanceof
        RateServiceError
    ) {
        return error;
    }

    if (
        error?.code === 11000
    ) {
        const duplicateField =
            error?.keyPattern?.code
                ? "code"
                : Object.keys(
                      error?.keyPattern ||
                          {},
                  )[0] ||
                  "code";

        return new RateServiceError(
            "A master rate with this code already exists.",
            {
                code:
                    "MASTER_RATE_CODE_DUPLICATE",
                statusCode: 409,
                details: {
                    field:
                        duplicateField,
                },
                cause:
                    error,
            },
        );
    }

    if (
        error?.name ===
        "ValidationError"
    ) {
        return new RateServiceError(
            "Master rate validation failed.",
            {
                code:
                    "MASTER_RATE_VALIDATION_FAILED",
                statusCode: 422,
                details: {
                    fields:
                        Object.fromEntries(
                            Object.entries(
                                error.errors ||
                                    {},
                            ).map(
                                ([
                                    field,
                                    fieldError,
                                ]) => [
                                    field,
                                    fieldError?.message ||
                                        "Invalid value.",
                                ],
                            ),
                        ),
                },
                cause:
                    error,
            },
        );
    }

    if (
        error?.name ===
            "CastError" &&
        error?.kind ===
            "ObjectId"
    ) {
        return new RateServiceError(
            "Invalid master rate identifier.",
            {
                code:
                    "INVALID_MASTER_RATE_ID",
                statusCode: 400,
                details: {
                    field:
                        error.path ||
                        undefined,
                },
                cause:
                    error,
            },
        );
    }

    return error;
}

/* -------------------------------------------------------------------------- */
/* Category Resolution                                                       */
/* -------------------------------------------------------------------------- */

async function resolveCategoryHierarchy(
    data,
    {
        requireActive = true,
    } = {},
) {
    const category = normalizeString(
        data.category,
    );

    if (!category) {
        return data;
    }

    const suppliedType = normalizeString(
        data.categoryType,
    );

    const filter = {
        category: new RegExp(
            `^${escapeRegex(category)}$`,
            "i",
        ),
        ...(requireActive ? { status: true } : {}),
    };

    if (suppliedType) {
        filter.categoryType = new RegExp(
            `^${escapeRegex(suppliedType)}$`,
            "i",
        );
    }

    const matches = await RateCategory.find(filter)
        .select("categoryType category status")
        .sort({ sortOrder: 1, categoryType: 1, category: 1 })
        .lean();

    if (matches.length === 0) {
        throw new RateServiceError(
            suppliedType
                ? "The selected category and category type do not match an active master rate category."
                : "The selected category is not available in the active master rate categories.",
            {
                code: "RATE_CATEGORY_NOT_AVAILABLE",
                statusCode: 422,
                details: {
                    category,
                    ...(suppliedType
                        ? { categoryType: suppliedType }
                        : {}),
                },
            },
        );
    }

    if (!suppliedType && matches.length > 1) {
        throw new RateServiceError(
            "The selected category is ambiguous because it exists under multiple category types. Please select a category from the master category list.",
            {
                code: "AMBIGUOUS_RATE_CATEGORY",
                statusCode: 422,
                details: {
                    category,
                    categoryTypes: matches.map(
                        (item) => item.categoryType,
                    ),
                },
            },
        );
    }

    return {
        ...data,
        category: matches[0].category,
        categoryType: matches[0].categoryType,
    };
}

async function resolveUnitName(
    value,
    {
        requireActive = true,
    } = {},
) {
    const unit = normalizeString(value);

    if (!unit) {
        throw new RateServiceError(
            "Unit is required.",
            {
                code: "UNIT_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const document = await Unit.findOne({
        name: new RegExp(
            `^${escapeRegex(unit)}$`,
            "i",
        ),
        ...(requireActive ? { status: true } : {}),
    })
        .select("name status")
        .lean();

    if (!document) {
        throw new RateServiceError(
            requireActive
                ? "The selected unit is not available in the active units master."
                : "The selected unit does not exist in the units master.",
            {
                code: "RATE_UNIT_NOT_AVAILABLE",
                statusCode: 422,
                details: {
                    unit,
                },
            },
        );
    }

    return document.name;
}

/* -------------------------------------------------------------------------- */
/* Managed Rate Code                                                          */
/* -------------------------------------------------------------------------- */

async function generateRateCode() {
    for (let attempt = 0; attempt < 10; attempt += 1) {
        const sequence = await MasterRateSequence.findOneAndUpdate(
            { _id: "master_rate" },
            { $inc: { value: 1 } },
            {
                new: true,
                upsert: true,
                setDefaultsOnInsert: true,
            },
        ).lean();

        const value = Number(sequence?.value);

        if (!Number.isInteger(value) || value < 1) {
            throw new RateServiceError(
                "Unable to generate a master rate code.",
                {
                    code: "RATE_CODE_GENERATION_FAILED",
                    statusCode: 500,
                },
            );
        }

        const code = `MR-${String(value).padStart(6, "0")}`;

        const existing = await MarketRateItem.findOne({ code })
            .select("_id")
            .lean();

        if (!existing) {
            return code;
        }
    }

    throw new RateServiceError(
        "Unable to generate a unique master rate code.",
        {
            code: "RATE_CODE_GENERATION_FAILED",
            statusCode: 500,
        },
    );
}

/* -------------------------------------------------------------------------- */
/* Duplicate Code                                                             */
/* -------------------------------------------------------------------------- */

async function ensureUniqueCode(
    code,
    {
        excludeId = null,
    } = {},
) {
    const filter = {
        code:
            normalizeString(
                code,
            ).toUpperCase(),
    };

    if (excludeId) {
        filter._id = {
            $ne: excludeId,
        };
    }

    const existing =
        await MarketRateItem.findOne(
            filter,
        )
            .select("_id code")
            .lean();

    if (existing) {
        throw new RateServiceError(
            "A master rate with this code already exists.",
            {
                code:
                    "MASTER_RATE_CODE_DUPLICATE",
                statusCode: 409,
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* History Synchronization                                                    */
/* -------------------------------------------------------------------------- */

function sortHistory(history) {
    return history.sort(
        (a, b) =>
            new Date(
                b.effectiveDate,
            ).getTime() -
            new Date(
                a.effectiveDate,
            ).getTime(),
    );
}

async function createHistoryRecord(
    {
        marketRateItemId,
        rate,
        effectiveDate,
        userId,
        userName,
        changeReason = "",
    },
    {
        session = null,
    } = {},
) {
    const document = {
        marketRateItemId,

        rate,

        effectiveDate,

        updatedBy:
            userId || null,

        updatedByName:
            userName || "",

        changeReason,
    };

    if (session) {
        const created =
            await RateHistory.create(
                [document],
                {
                    session,
                },
            );

        return created[0];
    }

    return RateHistory.create(
        document,
    );
}

function pushEmbeddedHistory(
    document,
    {
        rate,
        effectiveDate,
        userId,
        userName,
    },
) {
    if (
        !Array.isArray(
            document.history,
        )
    ) {
        document.history = [];
    }

    document.history.push({
        rate,

        effectiveDate,

        updatedAt:
            new Date(),

        updatedBy:
            userId || null,

        updatedByName:
            userName || "",
    });

    /*
     * Keep newest effective date first in the embedded array.
     */
    document.history =
        sortHistory(
            document.history,
        );
}

/* -------------------------------------------------------------------------- */
/* LIST                                                                       */
/* -------------------------------------------------------------------------- */

export async function listRates(
    {
        page = DEFAULT_PAGE,
        limit = DEFAULT_LIMIT,
        search = "",
        categoryType = "",
        category = "",
        subcategory = "",
        unit = "",
        status = "",
        effectiveDate = "",
        sort = "updatedAt",
        sortOrder = "desc",
    } = {},
) {
    const normalizedPage =
        normalizePage(page);

    const normalizedLimit =
        normalizeLimit(limit);

    const filter = {};

    const normalizedSearch =
        normalizeString(
            search,
        );

    if (normalizedSearch) {
        const regex =
            new RegExp(
                escapeRegex(
                    normalizedSearch,
                ),
                "i",
            );

        filter.$or = [
            {
                code: regex,
            },
            {
                categoryType:
                    regex,
            },
            {
                category: regex,
            },
            {
                subcategory:
                    regex,
            },
            {
                module: regex,
            },
            {
                description:
                    regex,
            },
            {
                unit: regex,
            },
        ];
    }

    if (
        normalizeString(
            categoryType,
        )
    ) {
        filter.categoryType =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        categoryType,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            category,
        )
    ) {
        filter.category =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        category,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            subcategory,
        )
    ) {
        filter.subcategory =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        subcategory,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(unit)
    ) {
        filter.unit =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        unit,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(status)
    ) {
        filter.status =
            normalizeStatus(
                status,
            );
    }

    if (
        normalizeString(
            effectiveDate,
        )
    ) {
        const date =
            parseDateOnly(
                effectiveDate,
            );

        const nextDay =
            new Date(date);

        nextDay.setDate(
            nextDay.getDate() +
                1,
        );

        filter.effectiveDate = {
            $gte: date,
            $lt: nextDay,
        };
    }

    const skip =
        (normalizedPage - 1) *
        normalizedLimit;

    const sortField =
        normalizeSort(sort);

    const direction =
        normalizeSortDirection(
            sortOrder,
        );

    const sortSpec = {
        [sortField]:
            direction,

        code: 1,
    };

    const [
        documents,
        total,
    ] = await Promise.all([
        MarketRateItem.find(
            filter,
        )
            .sort(sortSpec)
            .skip(skip)
            .limit(
                normalizedLimit,
            ),

        MarketRateItem.countDocuments(
            filter,
        ),
    ]);

    const items =
        documents.map(
            serializeRate,
        );

    return {
        items,

        data:
            items,

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            totalPages:
                total === 0
                    ? 0
                    : Math.ceil(
                          total /
                              normalizedLimit,
                      ),
        },

        filters: {
            search:
                normalizedSearch,

            categoryType:
                normalizeString(
                    categoryType,
                ),

            category:
                normalizeString(
                    category,
                ),

            subcategory:
                normalizeString(
                    subcategory,
                ),

            unit:
                normalizeString(
                    unit,
                ),

            status:
                normalizeString(
                    status,
                ) || null,

            effectiveDate:
                normalizeString(
                    effectiveDate,
                ) || null,
        },

        sort: {
            field:
                sortField,

            order:
                direction === -1
                    ? "desc"
                    : "asc",
        },
    };
}

/* -------------------------------------------------------------------------- */
/* GET                                                                        */
/* -------------------------------------------------------------------------- */

export async function getRate(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await MarketRateItem.findById(
            objectId,
        );

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeRate(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* HISTORY                                                                    */
/* -------------------------------------------------------------------------- */

export async function getRateHistory(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await MarketRateItem.findById(
            objectId,
        ).select(
            "_id code history",
        );

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * Separate history collection is authoritative for persisted
     * history reads. Embedded history is retained for frontend
     * compatibility and resilience.
     */
    const historyRecords =
        await RateHistory.find({
            marketRateItemId:
                objectId,
        }).sort({
            effectiveDate:
                -1,

            createdAt:
                -1,
        });

    if (
        historyRecords.length >
        0
    ) {
        return {
            rateId:
                objectId.toString(),

            code:
                document.code,

            history:
                historyRecords.map(
                    serializeHistoryItem,
                ),
        };
    }

    const embedded =
        Array.isArray(
            document.history,
        )
            ? sortHistory(
                  document.history.slice(),
              ).map(
                  serializeHistoryItem,
              )
            : [];

    return {
        rateId:
            objectId.toString(),

        code:
            document.code,

        history:
            embedded,
    };
}

/* -------------------------------------------------------------------------- */
/* CREATE                                                                     */
/* -------------------------------------------------------------------------- */

export async function createRate(
    payload,
    {
        user = null,
        userId = null,
        session = null,
        changeReason = "",
    } = {},
) {
    let data =
        validatePayload(
            payload,
            {
                partial: false,
                allowCode: false,
                requireCode: false,
                requireCategoryType: false,
            },
        );

    data = await resolveCategoryHierarchy(
        data,
        { requireActive: true },
    );

    data.unit = await resolveUnitName(
        data.unit,
        { requireActive: true },
    );

    data.code = await generateRateCode();

    /*
     * Prefer explicit userId, otherwise derive it from user.
     */
    const actorId =
        normalizeUserId(
            userId ||
                getUserId(user),
            "createdBy",
        );

    const actorName =
        getUserName(user);

    const document =
        new MarketRateItem({
            ...data,

            status:
                data.status ||
                "active",

            history: [],

            createdBy:
                actorId || null,

            updatedBy:
                actorId || null,
        });

    /*
     * Create the first history snapshot.
     *
     * A new rate must immediately have a history entry so the
     * existing RateHistoryOffcanvas can work from day one.
     */
    pushEmbeddedHistory(
        document,
        {
            rate:
                data.standardRate,

            effectiveDate:
                data.effectiveDate,

            userId:
                actorId,

            userName:
                actorName,
        },
    );

    try {
        if (session) {
            await document.save({
                session,
                validateModifiedOnly:
                    true,
            });

            await createHistoryRecord(
                {
                    marketRateItemId:
                        document._id,

                    rate:
                        data.standardRate,

                    effectiveDate:
                        data.effectiveDate,

                    userId:
                        actorId,

                    userName:
                        actorName,

                    changeReason:
                        changeReason ||
                        "Initial master rate.",
                },
                {
                    session,
                },
            );
        } else {
            await document.save();

            await createHistoryRecord({
                marketRateItemId:
                    document._id,

                rate:
                    data.standardRate,

                effectiveDate:
                    data.effectiveDate,

                userId:
                    actorId,

                userName:
                    actorName,

                changeReason:
                    changeReason ||
                    "Initial master rate.",
            });
        }

        return serializeRate(
            document,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* UPDATE                                                                     */
/* -------------------------------------------------------------------------- */

export async function updateRate(
    id,
    payload,
    {
        user = null,
        userId = null,
        session = null,
        changeReason = "",
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await MarketRateItem.findById(
            objectId,
        ).session(
            session || null,
        );

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    const beforeRate =
        Number(
            document.standardRate,
        );

    const beforeEffectiveDate =
        formatDateOnly(
            document.effectiveDate,
        );

    let data =
        validatePayload(
            payload,
            {
                partial: true,
                allowCode: false,
                requireCode: false,
            },
        );

    if (
        Object.prototype.hasOwnProperty.call(
            data,
            "category",
        ) ||
        Object.prototype.hasOwnProperty.call(
            data,
            "categoryType",
        )
    ) {
        const nextCategory =
            normalizeString(
                data.category ??
                    document.category,
            );

        const nextCategoryType =
            normalizeString(
                data.categoryType ??
                    document.categoryType,
            );

        const sameCategory =
            nextCategory.toLowerCase() ===
                String(document.category || "")
                    .trim()
                    .toLowerCase() &&
            nextCategoryType.toLowerCase() ===
                String(document.categoryType || "")
                    .trim()
                    .toLowerCase();

        data = await resolveCategoryHierarchy(
            {
                ...data,
                category: nextCategory,
                categoryType: nextCategoryType,
            },
            { requireActive: !sameCategory },
        ).then((hierarchy) => ({
            ...data,
            category: hierarchy.category,
            categoryType: hierarchy.categoryType,
        }));
    }

    if (
        Object.prototype.hasOwnProperty.call(
            data,
            "unit",
        )
    ) {
        const sameUnit =
            normalizeString(data.unit).toLowerCase() ===
            String(document.unit || "")
                .trim()
                .toLowerCase();

        data.unit = await resolveUnitName(
            data.unit,
            { requireActive: !sameUnit },
        );
    }

    const actorId =
        normalizeUserId(
            userId ||
                getUserId(user),
            "updatedBy",
        );

    const actorName =
        getUserName(user);

    /*
     * Determine whether this update changes the actual rate or
     * its business-effective date.
     */
    const rateChanged =
        Object.prototype.hasOwnProperty.call(
            data,
            "standardRate",
        ) &&
        Number(
            data.standardRate,
        ) !== beforeRate;

    const effectiveDateChanged =
        Object.prototype.hasOwnProperty.call(
            data,
            "effectiveDate",
        ) &&
        formatDateOnly(
            data.effectiveDate,
        ) !== beforeEffectiveDate;

    /*
     * Apply ordinary fields.
     */
    Object.assign(
        document,
        data,
    );

    if (actorId) {
        document.updatedBy =
            actorId;
    }

    /*
     * If standardRate is supplied, keep legacy rate field synchronized.
     */
    if (
        Object.prototype.hasOwnProperty.call(
            data,
            "standardRate",
        )
    ) {
        document.rate =
            data.standardRate;
    }

    /*
     * Only write a new history record when the rate/effective date
     * actually changes.
     */
    const shouldCreateHistory =
        rateChanged ||
        effectiveDateChanged;

    if (
        shouldCreateHistory
    ) {
        pushEmbeddedHistory(
            document,
            {
                rate:
                    Number(
                        document.standardRate,
                    ),

                effectiveDate:
                    document.effectiveDate,

                userId:
                    actorId,

                userName:
                    actorName,
            },
        );
    }

    try {
        if (session) {
            await document.save({
                session,
                validateModifiedOnly:
                    true,
            });
        } else {
            await document.save({
                validateModifiedOnly:
                    true,
            });
        }

        if (
            shouldCreateHistory
        ) {
            await createHistoryRecord(
                {
                    marketRateItemId:
                        document._id,

                    rate:
                        Number(
                            document.standardRate,
                        ),

                    effectiveDate:
                        document.effectiveDate,

                    userId:
                        actorId,

                    userName:
                        actorName,

                    changeReason:
                        changeReason ||
                        (
                            rateChanged
                                ? "Master rate updated."
                                : "Rate effective date updated."
                        ),
                },
                session
                    ? {
                          session,
                      }
                    : {},
            );
        }

        return serializeRate(
            document,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* STATUS                                                                     */
/* -------------------------------------------------------------------------- */

export async function setRateStatus(
    id,
    status,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const normalizedStatus =
        normalizeStatus(
            status,
        );

    const update = {
        status:
            normalizedStatus,
    };

    if (normalizedStatus === "active") {
        const current =
            await MarketRateItem.findById(
                objectId,
            )
                .select("_id category categoryType unit status")
                .lean();

        if (!current) {
            throw new RateServiceError(
                "Master rate not found.",
                {
                    code: "MASTER_RATE_NOT_FOUND",
                    statusCode: 404,
                },
            );
        }

        await resolveCategoryHierarchy(
            {
                category: current.category,
                categoryType: current.categoryType,
            },
            { requireActive: true },
        );

        await resolveUnitName(
            current.unit,
            { requireActive: true },
        );
    }

    const auditUserId =
        normalizeUserId(
            userId,
            "updatedBy",
        );

    if (auditUserId) {
        update.updatedBy =
            auditUserId;
    }

    let document;

    try {
        document =
            await MarketRateItem.findByIdAndUpdate(
                objectId,
                {
                    $set:
                        update,
                },
                {
                    new: true,
                    runValidators:
                        true,
                },
            );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeRate(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* DELETE                                                                     */
/* -------------------------------------------------------------------------- */

export async function deleteRate(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await MarketRateItem.findById(
            objectId,
        );

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * Keep historical records instead of deleting them.
     *
     * The Master Rate itself is removed from the active master table,
     * while RateHistory remains available for audit purposes.
     */
    try {
        await MarketRateItem.deleteOne({
            _id: objectId,
        });
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    return {
        id:
            objectId.toString(),

        code:
            document.code,

        deleted: true,
    };
}

/* -------------------------------------------------------------------------- */
/* BULK STATUS                                                                */
/* -------------------------------------------------------------------------- */

export async function bulkUpdateStatus(
    ids,
    status,
    {
        userId = null,
    } = {},
) {
    if (
        !Array.isArray(ids) ||
        ids.length === 0
    ) {
        throw new RateServiceError(
            "At least one master rate ID is required.",
            {
                code:
                    "MASTER_RATE_IDS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const uniqueIdMap = new Map();
    ids.forEach((id) => {
        const objectId = ensureObjectId(id);
        uniqueIdMap.set(objectId.toString(), objectId);
    });
    const objectIds = [
        ...uniqueIdMap.values(),
    ];

    const normalizedStatus =
        normalizeStatus(
            status,
        );

    const update = {
        status:
            normalizedStatus,
    };

    if (normalizedStatus === "active") {
        const [activeCategories, activeUnits] =
            await Promise.all([
                RateCategory.find({ status: true })
                    .select("categoryType category")
                    .lean(),
                Unit.find({ status: true })
                    .select("name")
                    .lean(),
            ]);

        const categoryKeys = new Set(
            activeCategories.map(
                (item) =>
                    `${String(item.categoryType || "").trim().toLowerCase()}\u0000${String(item.category || "").trim().toLowerCase()}`,
            ),
        );

        const unitNames = new Set(
            activeUnits.map(
                (item) =>
                    String(item.name || "")
                        .trim()
                        .toLowerCase(),
            ),
        );

        const currentRates =
            await MarketRateItem.find({
                _id: {
                    $in: objectIds,
                },
            })
                .select("_id category categoryType unit")
                .lean();

        for (const current of currentRates) {
            const categoryKey =
                `${String(current.categoryType || "").trim().toLowerCase()}\u0000${String(current.category || "").trim().toLowerCase()}`;

            if (!categoryKeys.has(categoryKey)) {
                throw new RateServiceError(
                    `Master rate ${current._id.toString()} cannot be activated because its category is inactive or unavailable.`,
                    {
                        code: "RATE_CATEGORY_NOT_ACTIVE",
                        statusCode: 409,
                    },
                );
            }

            if (
                !unitNames.has(
                    String(current.unit || "")
                        .trim()
                        .toLowerCase(),
                )
            ) {
                throw new RateServiceError(
                    `Master rate ${current._id.toString()} cannot be activated because its unit is inactive or unavailable.`,
                    {
                        code: "RATE_UNIT_NOT_ACTIVE",
                        statusCode: 409,
                    },
                );
            }
        }

        if (currentRates.length !== objectIds.length) {
            throw new RateServiceError(
                "One or more master rates were not found.",
                {
                    code: "MASTER_RATE_NOT_FOUND",
                    statusCode: 404,
                },
            );
        }
    }

    const auditUserId =
        normalizeUserId(
            userId,
            "updatedBy",
        );

    if (auditUserId) {
        update.updatedBy =
            auditUserId;
    }

    let result;

    try {
        result =
        await MarketRateItem.updateMany(
            {
                _id: {
                    $in: objectIds,
                },
            },
            {
                $set:
                    update,
            },
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    return {
        matched:
            result.matchedCount ??
            result.n ??
            0,

        modified:
            result.modifiedCount ??
            result.nModified ??
            0,

        status:
            normalizedStatus,
    };
}

/* -------------------------------------------------------------------------- */
/* ACTIVE                                                                      */
/* -------------------------------------------------------------------------- */

export async function listActiveRates(
    {
        categoryType = "",
        category = "",
    } = {},
) {
    const filter = {
        status: "active",
    };

    if (
        normalizeString(
            categoryType,
        )
    ) {
        filter.categoryType =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        categoryType,
                    ),
                )}$`,
                "i",
            );
    }

    if (
        normalizeString(
            category,
        )
    ) {
        filter.category =
            new RegExp(
                `^${escapeRegex(
                    normalizeString(
                        category,
                    ),
                )}$`,
                "i",
            );
    }

    const documents =
        await MarketRateItem.find(
            filter,
        ).sort({
            categoryType: 1,
            category: 1,
            subcategory: 1,
            code: 1,
        });

    return documents.map(
        serializeRate,
    );
}

/* -------------------------------------------------------------------------- */
/* Lookup                                                                     */
/* -------------------------------------------------------------------------- */

export async function getRateByCode(
    code,
) {
    const normalizedCode =
        normalizeString(
            code,
        ).toUpperCase();

    if (!normalizedCode) {
        throw new RateServiceError(
            "Rate code is required.",
            {
                code:
                    "RATE_CODE_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const document =
        await MarketRateItem.findOne({
            code:
                normalizedCode,
        });

    if (!document) {
        throw new RateServiceError(
            "Master rate not found.",
            {
                code:
                    "MASTER_RATE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeRate(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* Service Object                                                             */
/* -------------------------------------------------------------------------- */

const rateService = {
    list:
        listRates,

    get:
        getRate,

    getHistory:
        getRateHistory,

    getByCode:
        getRateByCode,

    create:
        createRate,

    update:
        updateRate,

    setStatus:
        setRateStatus,

    delete:
        deleteRate,

    bulkUpdateStatus,

    listActive:
        listActiveRates,
};

export default rateService;