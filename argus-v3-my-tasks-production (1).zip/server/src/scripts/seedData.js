
// src/scripts/seedData.js

import path from "node:path";
import { pathToFileURL } from "node:url";

import bcrypt from "bcrypt";

import env from "../config/env.js";
import {
    connectDatabase,
    disconnectDatabase,
} from "../config/database.js";

import User from "../models/User.js";
import Role from "../models/Role.js";
import Permission from "../models/Permission.js";
import RolePermission from "../models/RolePermission.js";
import BootstrapState from "../models/BootstrapState.js";

/*
|--------------------------------------------------------------------------
| ARGUS MongoDB Seed
|--------------------------------------------------------------------------
|
| Creates the initial authorization foundation:
|
|   Permissions
|       ↓
|   workspace_owner
|       ↓
|   RolePermission
|       ↓
|   Bootstrap User
|
| This script is intentionally idempotent.
|
| Running:
|
|   npm run db:seed
|
| multiple times should not create duplicate roles or permissions.
|
|--------------------------------------------------------------------------
*/

/* -------------------------------------------------------------------------- */
/* Automatic bootstrap seed metadata                                         */
/* -------------------------------------------------------------------------- */

/**
 * The seed is intentionally versioned.
 *
 * - The same version runs only once successfully.
 * - To intentionally introduce a new bootstrap-data change, increment the
 *   version. The database marker is then eligible to run exactly once for
 *   that new version.
 */
const BOOTSTRAP_SEED_KEY = "argus-authorization-bootstrap";
const BOOTSTRAP_SEED_VERSION = 1;
const BOOTSTRAP_SEED_LEASE_MS = 10 * 60 * 1000;

/**
 * Startup auto-seeding can be disabled without adding another required env
 * variable. The default is enabled; only an explicit false disables it.
 */
function isAutomaticSeedEnabled() {
    if (
        process.env.AUTO_SEED_ENABLED === undefined
    ) {
        return true;
    }

    return (
        String(
            process.env.AUTO_SEED_ENABLED,
        )
            .trim()
            .toLowerCase() !== "false"
    );
}

function isDirectExecution() {
    if (!process.argv[1]) {
        return false;
    }

    return (
        pathToFileURL(
            path.resolve(process.argv[1]),
        ).href ===
        import.meta.url
    );
}

/* -------------------------------------------------------------------------- */
/* Bootstrap configuration                                                    */
/* -------------------------------------------------------------------------- */

const BOOTSTRAP_ADMIN_EMAIL =
    String(
        process.env.BOOTSTRAP_ADMIN_EMAIL ||
            "",
    )
        .trim()
        .toLowerCase();

const BOOTSTRAP_ADMIN_PASSWORD =
    String(
        process.env.BOOTSTRAP_ADMIN_PASSWORD ||
            "",
    );

const BOOTSTRAP_ADMIN_NAME =
    String(
        process.env.BOOTSTRAP_ADMIN_NAME ||
            "ARGUS Workspace Owner",
    ).trim();

/* -------------------------------------------------------------------------- */
/* Permission catalog                                                         */
/* -------------------------------------------------------------------------- */

/*
 * Keep the existing ARGUS application permission vocabulary.
 *
 * Additional Settings permissions are included because the Settings
 * module is being built first.
 */
const DEFAULT_PERMISSION_ACTIONS = Object.freeze({
    view: true,
    add: true,
    edit: true,
    delete: true,
});
const PERMISSIONS = [
    {
        key: "dashboard",
        name: "Dashboard",
        category: "core",
        sortOrder: 10,
        description:
            "Application dashboard access.",
    },

    {
        key: "vendor",
        name: "Vendor Management",
        category: "procurement",
        sortOrder: 20,
        description:
            "Vendor management and vendor records.",
    },

    {
        key: "master_rate",
        name: "Master Rate Schedule",
        category: "procurement",
        sortOrder: 30,
        description:
            "Master rate schedules and rate items.",
    },

    {
        key: "boq",
        name: "BOQ",
        category: "procurement",
        sortOrder: 40,
        description:
            "Bill of quantities management.",
    },

    {
        key: "rfq",
        name: "RFQ",
        category: "procurement",
        sortOrder: 50,
        description:
            "Request for quotation management.",
    },

    {
        key: "quotation",
        name: "Quotation",
        category: "procurement",
        sortOrder: 60,
        description:
            "Vendor quotation management.",
    },

    {
        key: "commercial",
        name: "Commercial Comparison & Award",
        category: "procurement",
        sortOrder: 70,
        description:
            "Commercial comparison and award workflows.",
    },

    {
        key: "project",
        name: "Projects",
        category: "project",
        sortOrder: 80,
        description:
            "Project management.",
    },

    {
        key: "task",
        name: "Tasks",
        category: "project",
        sortOrder: 90,
        description:
            "Project task management.",
    },

    {
        key: "budget",
        name: "Budget",
        category: "finance",
        sortOrder: 100,
        description:
            "Project budget management.",
    },

    {
        key: "invoice",
        name: "Invoices",
        category: "finance",
        sortOrder: 110,
        description:
            "Invoice management.",
    },

    {
        key: "payment",
        name: "Payments",
        category: "finance",
        sortOrder: 120,
        description:
            "Payment management.",
    },

    {
        key: "survey_report",
        name: "Survey Report",
        category: "survey",
        sortOrder: 130,
        description:
            "Survey and report management.",
    },

    {
        key: "user_management",
        name: "User Management",
        category: "administration",
        sortOrder: 140,
        description:
            "Internal user administration.",
    },

    {
        key: "roles_permissions",
        name: "Roles & Permissions",
        category: "settings",
        sortOrder: 150,
        description:
            "Role and permission administration.",
    },

    {
        key: "settings",
        name: "Settings",
        category: "settings",
        sortOrder: 160,
        description:
            "Application settings area.",
    },

    {
        key: "company_settings",
        name: "Company Information",
        category: "settings",
        sortOrder: 161,
        description:
            "Company identity, contact information and branding.",
    },

    {
        key: "api_configuration",
        name: "API Configuration",
        category: "settings",
        sortOrder: 162,
        description:
            "External API configuration.",
    },

    {
        key: "vendor_settings",
        name: "Vendor Settings",
        category: "settings",
        sortOrder: 163,
        description:
            "Vendor portal settings.",
    },

    {
        key: "common_settings",
        name: "Common Settings",
        category: "settings",
        sortOrder: 164,
        description:
            "Common application settings.",
    },

    {
        key: "master_rate_settings",
        name: "Master Rate Settings",
        category: "settings",
        sortOrder: 165,
        description:
            "Master-rate-related application settings.",
    },

    {
        key: "audit_log",
        name: "Audit Log",
        category: "administration",
        sortOrder: 170,
        description:
            "Audit history and security events.",
    },
];

/* -------------------------------------------------------------------------- */
/* System role catalog                                                        */
/* -------------------------------------------------------------------------- */

const ROLES = [
    /*
     * Admin accounts authenticate in the "admin" realm while internal
     * accounts authenticate in the "internal" realm. These system roles
     * are explicitly assignable to both user types, so their role realm
     * must be "both".
     */
    {
        key: "workspace_owner",
        name: "Workspace Owner",
        description:
            "Full administrative access to the ARGUS workspace.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: true,
        sortOrder: 10,
    },

    {
        key: "network_admin",
        name: "Network Admin",
        description:
            "Administrative access to assigned internal modules.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 20,
    },

    {
        key: "field_technician",
        name: "Field Technician",
        description:
            "Operational field access based on assigned permissions.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 30,
    },

    {
        key: "billing_manager",
        name: "Billing Manager",
        description:
            "Finance and billing access based on assigned permissions.",
        realm: "both",
        allowedUserTypes: [
            "admin",
            "internal",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 40,
    },

    {
        key: "vendor_admin",
        name: "Vendor Admin",
        description:
            "Vendor portal administration.",
        realm: "vendor",
        allowedUserTypes: [
            "vendor",
        ],
        system: true,
        ownerRole: false,
        sortOrder: 50,
    },
];

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

function validateBootstrapConfiguration() {
    if (
        BOOTSTRAP_ADMIN_PASSWORD &&
        BOOTSTRAP_ADMIN_PASSWORD.length <
            env.auth.passwordMinLength
    ) {
        throw new Error(
            `BOOTSTRAP_ADMIN_PASSWORD must contain at least ${env.auth.passwordMinLength} characters.`,
        );
    }

    if (
        BOOTSTRAP_ADMIN_EMAIL &&
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
            BOOTSTRAP_ADMIN_EMAIL,
        )
    ) {
        throw new Error(
            "BOOTSTRAP_ADMIN_EMAIL must be a valid email address.",
        );
    }

    /*
     * Creating a brand-new bootstrap user without a password would
     * create an unusable account. Refuse instead of generating or
     * shipping a default password.
     */
    if (
        BOOTSTRAP_ADMIN_EMAIL &&
        !BOOTSTRAP_ADMIN_PASSWORD
    ) {
        throw new Error(
            "BOOTSTRAP_ADMIN_PASSWORD is required when BOOTSTRAP_ADMIN_EMAIL is configured.",
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Permission seeding                                                         */
/* -------------------------------------------------------------------------- */

async function seedPermissions() {
    const permissionMap =
        new Map();

    for (
        const definition of PERMISSIONS
    ) {
        const permission =
            await Permission.findOneAndUpdate(
                {
                    key:
                        definition.key,
                },

                {
                    $set: {
                        name:
                            definition.name,

                        description:
                            definition.description,

                        category:
                            definition.category,

                        sortOrder:
                            definition.sortOrder,

                        /*
                         * Permission actions describe the actions that
                         * the module supports.
                         *
                         * RolePermission separately controls which
                         * supported actions are granted to a role.
                         *
                         * IMPORTANT:
                         *
                         * This is intentionally under $set, not only
                         * $setOnInsert, so existing installations are
                         * repaired when the seed is executed again.
                         */
                        actions: {
                            ...DEFAULT_PERMISSION_ACTIONS,
                        },

                        active:
                            true,

                        system:
                            true,
                    },

                    $setOnInsert: {
                        key:
                            definition.key,
                    },
                },

                {
                    upsert:
                        true,

                    new:
                        true,

                    setDefaultsOnInsert:
                        true,
                },
            );

        permissionMap.set(
            permission.key,
            permission,
        );
    }

    return permissionMap;
}
/* -------------------------------------------------------------------------- */
/* Role seeding                                                               */
/* -------------------------------------------------------------------------- */

async function seedRoles() {
    const roleMap =
        new Map();

    for (
        const definition of ROLES
    ) {
        const role =
            await Role.findOneAndUpdate(
                {
                    key:
                        definition.key,
                },

                {
                    $set: {
                        name:
                            definition.name,

                        description:
                            definition.description,

                        realm:
                            definition.realm,

                        allowedUserTypes:
                            definition.allowedUserTypes,

                        system:
                            definition.system,

                        ownerRole:
                            definition.ownerRole,

                        sortOrder:
                            definition.sortOrder,

                        active:
                            true,
                    },

                    $setOnInsert: {
                        key:
                            definition.key,
                    },
                },

                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert:
                        true,
                },
            );

        roleMap.set(
            role.key,
            role,
        );
    }

    return roleMap;
}

/* -------------------------------------------------------------------------- */
/* Workspace owner permissions                                                */
/* -------------------------------------------------------------------------- */

async function seedWorkspaceOwnerPermissions(
    role,
    permissionMap,
) {
    /*
     * Workspace Owner receives all currently registered application
     * permissions with all four actions.
     *
     * Future role customization is done through the Roles & Permissions
     * service/UI.
     */
    for (
        const permission of
            permissionMap.values()
    ) {
        await RolePermission.findOneAndUpdate(
            {
                roleId:
                    role._id,

                permissionId:
                    permission._id,
            },

            {
                $set: {
                    actions: {
                        view:
                            true,

                        add:
                            true,

                        edit:
                            true,

                        delete:
                            true,
                    },

                    active:
                        true,
                },

                $setOnInsert: {
                    roleId:
                        role._id,

                    permissionId:
                        permission._id,
                },
            },

            {
                upsert: true,
                new: true,
                setDefaultsOnInsert:
                    true,
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Vendor Admin permissions                                                   */
/* -------------------------------------------------------------------------- */

async function seedVendorAdminPermissions(
    role,
    permissionMap,
) {
    if (!role) {
        throw new Error(
            "vendor_admin role could not be resolved for permission seeding.",
        );
    }

    /*
     * Keep the vendor-admin permission catalog explicit. This prevents
     * accidentally granting internal/admin-only modules to vendor users.
     *
     * The Vendor Panel currently exposes:
     *   - Dashboard
     *   - Quotations / Bids & Proposals
     *   - Projects
     *   - My Tasks
     *   - User Management
     *   - Roles & Permissions
     */
    const vendorPermissions = {
        dashboard: {
            view: true,
            add: false,
            edit: false,
            delete: false,
        },

        quotation: {
            view: true,
            add: true,
            edit: true,
            delete: false,
        },

        project: {
            view: true,
            add: false,
            edit: false,
            delete: false,
        },

        task: {
            view: true,
            add: true,
            edit: true,
            delete: false,
        },

        user_management: {
            view: true,
            add: true,
            edit: true,
            delete: true,
        },

        roles_permissions: {
            view: true,
            add: true,
            edit: true,
            delete: true,
        },
    };

    for (const [permissionKey, actions] of Object.entries(vendorPermissions)) {
        const permission = permissionMap.get(permissionKey);

        if (!permission) {
            throw new Error(
                `Required vendor permission '${permissionKey}' is missing from the permission catalog.`,
            );
        }

        await RolePermission.findOneAndUpdate(
            {
                roleId: role._id,
                permissionId: permission._id,
            },
            {
                $set: {
                    actions,
                    active: true,
                },
                $setOnInsert: {
                    roleId: role._id,
                    permissionId: permission._id,
                },
            },
            {
                upsert: true,
                new: true,
                setDefaultsOnInsert: true,
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Bootstrap user                                                             */
/* -------------------------------------------------------------------------- */

async function seedBootstrapUser(
    ownerRole,
) {
    if (
        !BOOTSTRAP_ADMIN_EMAIL
    ) {
        console.warn(
            "[SEED] BOOTSTRAP_ADMIN_EMAIL not configured. No bootstrap user was created or assigned.",
        );

        console.warn(
            "[SEED] Add BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD to explicitly grant Workspace Owner access.",
        );

        return null;
    }

    let user =
        await User.findOne({
            email:
                BOOTSTRAP_ADMIN_EMAIL,
        }).select(
            "+passwordHash",
        );

    if (
        user
    ) {
        if (
            ![
                "admin",
                "internal",
            ].includes(
                user.userType,
            )
        ) {
            throw new Error(
                `Bootstrap user ${BOOTSTRAP_ADMIN_EMAIL} is not an admin/internal user.`,
            );
        }

        /*
         * Explicit bootstrap configuration means the operator is
         * intentionally granting ownership to this account.
         */
        user.roleId =
            ownerRole._id;

        user.status =
            "active";

        user.updatedBy =
            user._id;

        /*
         * Do not silently replace an existing password.
         */
        if (
            !user.passwordHash
        ) {
            user.passwordHash =
                await bcrypt.hash(
                    BOOTSTRAP_ADMIN_PASSWORD,
                    env.auth
                        .bcryptSaltRounds,
                );
        }

        await user.save();

        console.info(
            `[SEED] Existing bootstrap user assigned Workspace Owner: ${BOOTSTRAP_ADMIN_EMAIL}`,
        );

        return user;
    }

    /*
     * Creating a new admin is only allowed when both email and password
     * were explicitly supplied through environment variables.
     */
    const passwordHash =
        await bcrypt.hash(
            BOOTSTRAP_ADMIN_PASSWORD,
            env.auth
                .bcryptSaltRounds,
        );

    user =
        await User.create({
            email:
                BOOTSTRAP_ADMIN_EMAIL,

            passwordHash,

            displayName:
                BOOTSTRAP_ADMIN_NAME,

            userType:
                "admin",

            roleId:
                ownerRole._id,

            vendorId:
                null,

            status:
                "active",

            passwordChangedAt:
                new Date(),

            emailVerifiedAt:
                new Date(),
        });

    console.info(
        `[SEED] Bootstrap Workspace Owner created: ${BOOTSTRAP_ADMIN_EMAIL}`,
    );

    return user;
}

/* -------------------------------------------------------------------------- */
/* Existing users without roles                                               */
/* -------------------------------------------------------------------------- */

async function reportUsersWithoutRoles() {
    const count =
        await User.countDocuments({
            roleId: null,
        });

    if (
        count === 0
    ) {
        return;
    }

    console.warn(
        `[SEED] ${count} user(s) currently have no role assigned.`,
    );

    console.warn(
        "[SEED] They will remain unauthorized until a valid role is assigned.",
    );
}

/* -------------------------------------------------------------------------- */
/* Persistent bootstrap marker                                               */
/* -------------------------------------------------------------------------- */

async function claimBootstrapSeed() {
    const now = new Date();
    const leaseUntil = new Date(
        now.getTime() + BOOTSTRAP_SEED_LEASE_MS,
    );

    const existing =
        await BootstrapState.findOne({
            _id: BOOTSTRAP_SEED_KEY,
        }).lean();

    if (
        existing?.status === "completed" &&
        existing.version === BOOTSTRAP_SEED_VERSION
    ) {
        return {
            shouldRun: false,
            state: existing,
        };
    }

    /**
     * Atomically claim the seed slot. A second application process can see
     * the same MongoDB marker and will not execute the seed while the first
     * process owns an active lease.
     *
     * The upsert race is handled below: the unique MongoDB `_id` index guarantees
     * only one marker document exists.
     */
    try {
        const state =
            await BootstrapState.findOneAndUpdate(
                {
                    _id: BOOTSTRAP_SEED_KEY,

                    $or: [
                        {
                            status: {
                                $exists: false,
                            },
                        },
                        {
                            status: "failed",
                        },
                        {
                            status: "running",
                            lockUntil: {
                                $lte: now,
                            },
                        },
                        {
                            status: "completed",
                            version: {
                                $ne: BOOTSTRAP_SEED_VERSION,
                            },
                        },
                    ],
                },

                {
                    $set: {
                        version:
                            BOOTSTRAP_SEED_VERSION,
                        status: "running",
                        startedAt: now,
                        lockUntil: leaseUntil,
                        lastError: null,
                    },

                    $setOnInsert: {
                        _id: BOOTSTRAP_SEED_KEY,
                    },
                },

                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert: true,
                },
            );

        if (!state) {
            return {
                shouldRun: false,
                state: await BootstrapState.findOne({
                    _id: BOOTSTRAP_SEED_KEY,
                }).lean(),
            };
        }

        return {
            shouldRun: true,
            state,
        };
    } catch (error) {
        /**
         * Another process may have won the initial upsert race. In that case
         * MongoDB raises a duplicate-key error, and the existing marker is
         * the source of truth.
         */
        if (error?.code !== 11000) {
            throw error;
        }

        const current =
            await BootstrapState.findOne({
                _id: BOOTSTRAP_SEED_KEY,
            }).lean();

        return {
            shouldRun: false,
            state: current,
        };
    }
}

async function markBootstrapSeedCompleted() {
    await BootstrapState.updateOne(
        {
            _id: BOOTSTRAP_SEED_KEY,
        },
        {
            $set: {
                version: BOOTSTRAP_SEED_VERSION,
                status: "completed",
                completedAt: new Date(),
                lockUntil: null,
                lastError: null,
            },
        },
    );
}

async function markBootstrapSeedFailed(error) {
    await BootstrapState.updateOne(
        {
            _id: BOOTSTRAP_SEED_KEY,
        },
        {
            $set: {
                status: "failed",
                lockUntil: null,
                lastError:
                    error instanceof Error
                        ? error.message.slice(0, 2000)
                        : String(error).slice(0, 2000),
            },
        },
    );
}

/**
 * Run the ARGUS authorization/bootstrap seed once per successful version.
 *
 * This function is reusable from: 
 * - the server startup sequence
 * - `npm run db:seed`
 *
 * It never disconnects MongoDB itself; the application owns its connection
 * lifecycle.
 */
export async function runSeed({ startup = false } = {}) {
    if (
        startup &&
        !isAutomaticSeedEnabled()
    ) {
        console.info(
            "[SEED] Automatic startup seeding is disabled by AUTO_SEED_ENABLED=false.",
        );

        return {
            status: "disabled",
        };
    }

    console.info(
        `[SEED] Checking ARGUS bootstrap seed version ${BOOTSTRAP_SEED_VERSION}...`,
    );

    await connectDatabase();

    const claim =
        await claimBootstrapSeed();

    if (!claim.shouldRun) {
        console.info(
            `[SEED] Bootstrap seed already completed for version ${BOOTSTRAP_SEED_VERSION}; skipping.`,
        );

        return {
            status: "skipped",
            state: claim.state,
        };
    }

    try {
        /*
         * Validate bootstrap credentials only when this seed version is
         * actually going to execute. A normal server restart must not fail
         * because old bootstrap env values were removed after first setup.
         */
        validateBootstrapConfiguration();

        console.info(
            "[SEED] Running first-time ARGUS authorization bootstrap...",
        );

        const permissionMap =
            await seedPermissions();

        console.info(
            `[SEED] Permissions ready: ${permissionMap.size}`,
        );

        const roleMap =
            await seedRoles();

        console.info(
            `[SEED] Roles ready: ${roleMap.size}`,
        );

        const workspaceOwner =
            roleMap.get(
                "workspace_owner",
            );

        if (!workspaceOwner) {
            throw new Error(
                "workspace_owner role could not be created.",
            );
        }

        await seedWorkspaceOwnerPermissions(
            workspaceOwner,
            permissionMap,
        );

        console.info(
            "[SEED] Workspace Owner permissions ready.",
        );

        const vendorAdminRole =
            roleMap.get(
                "vendor_admin",
            );

        if (!vendorAdminRole) {
            throw new Error(
                "vendor_admin role could not be created.",
            );
        }

        await seedVendorAdminPermissions(
            vendorAdminRole,
            permissionMap,
        );

        console.info(
            "[SEED] Vendor Admin permissions ready.",
        );

        await seedBootstrapUser(
            workspaceOwner,
        );

        await reportUsersWithoutRoles();

        await markBootstrapSeedCompleted();

        console.info(
            `[SEED] ARGUS MongoDB authorization bootstrap completed successfully (version ${BOOTSTRAP_SEED_VERSION}).`,
        );

        return {
            status: "completed",
            version: BOOTSTRAP_SEED_VERSION,
        };
    } catch (error) {
        try {
            await markBootstrapSeedFailed(error);
        } catch (markerError) {
            console.error(
                "[SEED] Failed to persist bootstrap failure marker:",
                markerError?.message || markerError,
            );
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* Main                                                                       */
/* -------------------------------------------------------------------------- */

async function main() {
    await runSeed({ startup: false });
}

/* -------------------------------------------------------------------------- */
/* Process                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * `npm run db:seed` continues to work as an explicit/manual operation.
 * Importing this module from `server.js` does not execute it automatically.
 */
if (isDirectExecution()) {
    main()
        .then(
            async () => {
                await disconnectDatabase();

                process.exit(0);
            },
        )
        .catch(
            async (error) => {
                console.error(
                    "[SEED] Failed:",
                    error,
                );

                try {
                    await disconnectDatabase();
                } catch {
                    // Preserve the original seed failure.
                }

                process.exit(1);
            },
        );
}
