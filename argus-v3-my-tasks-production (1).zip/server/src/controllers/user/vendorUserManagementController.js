// src/controllers/user/vendorUserManagementController.js

import fs from "node:fs";

import storageService from "../../services/storage/storageService.js";
import vendorUserManagementService, {
    VendorUserManagementServiceError,
} from "../../services/user/vendorUserManagementService.js";
import {
    getAuthenticatedUserId,
    getAuthenticatedVendorId,
} from "../../middleware/auth.js";


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getQueryValue(value) {
    if (Array.isArray(value)) {
        return value[0];
    }

    return value;
}

function parsePositiveInteger(value, fallback) {
    const parsed = Number.parseInt(String(value ?? ""), 10);

    if (!Number.isFinite(parsed) || parsed <= 0) {
        return fallback;
    }

    return parsed;
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = "Request completed successfully.",
        data = null,
    } = {},
) {
    return res.status(statusCode).json({
        success: true,
        message,
        data,
    });
}

function sendError(res, error, requestId = null) {
    if (error instanceof VendorUserManagementServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
            ...(requestId ? { requestId } : {}),
        });
    }

    if (error?.code === 11000) {
        return res.status(409).json({
            success: false,
            message: "A vendor user with the supplied unique value already exists.",
            code: "DUPLICATE_RECORD",
            ...(requestId ? { requestId } : {}),
        });
    }

    if (error?.name === "ValidationError") {
        const fields = {};

        for (const [field, detail] of Object.entries(error.errors || {})) {
            fields[field] = detail.message;
        }

        return res.status(422).json({
            success: false,
            message: "Validation failed.",
            code: "VALIDATION_ERROR",
            details: { fields },
            ...(requestId ? { requestId } : {}),
        });
    }

    if (error?.name === "CastError") {
        return res.status(422).json({
            success: false,
            message: "One or more supplied identifiers are invalid.",
            code: "INVALID_IDENTIFIER",
            ...(requestId ? { requestId } : {}),
        });
    }

    console.error("[VendorUserManagementController]", {
        requestId,
        error,
    });

    return res.status(500).json({
        success: false,
        message: "Unable to process the vendor user management request.",
        code: "INTERNAL_SERVER_ERROR",
        ...(requestId ? { requestId } : {}),
    });
}

function getContext(req) {
    return {
        vendorId: getAuthenticatedVendorId(req),
        actorUserId: getAuthenticatedUserId(req),
    };
}

/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/users                                                   */
/* -------------------------------------------------------------------------- */

export const list = async (req, res) => {
    try {
        const query = req.query || {};
        const { vendorId, actorUserId } = getContext(req);

        const result = await vendorUserManagementService.listUsers({
            vendorId,
            actorUserId,
            search: getQueryValue(query.search) || "",
            roleId: getQueryValue(query.roleId ?? query.role_id) || "",
            status: getQueryValue(query.status) || "",
            page: parsePositiveInteger(getQueryValue(query.page), 1),
            limit: Math.min(
                100,
                parsePositiveInteger(
                    getQueryValue(query.limit ?? query.perPage ?? query.per_page),
                    25,
                ),
            ),
        });

        return sendSuccess(res, {
            message: "Vendor users loaded successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/users/roles                                             */
/* -------------------------------------------------------------------------- */

export const listAssignableRoles = async (req, res) => {
    try {
        const { vendorId } = getContext(req);

        const roles = await vendorUserManagementService.listAssignableRoles({
            vendorId,
        });

        return sendSuccess(res, {
            message: "Vendor roles loaded successfully.",
            data: roles,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/users/check-email                                       */
/* -------------------------------------------------------------------------- */

export const checkEmail = async (req, res) => {
    try {
        const query = req.query || {};
        const { vendorId } = getContext(req);

        const email = getQueryValue(query.email);
        const excludeUserId =
            getQueryValue(query.excludeUserId ?? query.exclude_user_id) || null;

        const result = await vendorUserManagementService.checkEmailAvailability({
            vendorId,
            email,
            excludeUserId,
        });

        return sendSuccess(res, {
            message: "Email availability checked successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/users/:id                                               */
/* -------------------------------------------------------------------------- */

export const get = async (req, res) => {
    try {
        const { vendorId, actorUserId } = getContext(req);

        const user = await vendorUserManagementService.getUser({
            vendorId,
            actorUserId,
            userId: req.params?.id,
        });

        return sendSuccess(res, {
            message: "Vendor user loaded successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* POST /vendor-portal/users                                                  */
/* -------------------------------------------------------------------------- */

export const create = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);

        const user = await vendorUserManagementService.createUser({
            vendorId,
            actorUserId,
            email: body.email,
            displayName: body.displayName ?? body.name,
            hourlyRate: body.hourlyRate ?? body.hourlyrate,
            password: body.password,
            roleId: body.roleId ?? body.role_id ?? body.role,
            status: body.status ?? "active",
            request: req,
        });

        return sendSuccess(res, {
            statusCode: 201,
            message: "Vendor user created successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /vendor-portal/users/:id                                             */
/* -------------------------------------------------------------------------- */

export const update = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);

        const user = await vendorUserManagementService.updateUser({
            vendorId,
            actorUserId,
            userId: req.params?.id,
            email: body.email,
            displayName: body.displayName ?? body.name,
            hourlyRate: body.hourlyRate ?? body.hourlyrate,
            password: body.password,
            roleId: body.roleId ?? body.role_id ?? body.role,
            status: body.status,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user updated successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /vendor-portal/users/:id/status                                      */
/* -------------------------------------------------------------------------- */

export const updateStatus = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);
        const status = String(body.status || "").trim().toLowerCase();

        if (status !== "active" && status !== "inactive") {
            return res.status(422).json({
                success: false,
                message: "Status must be active or inactive.",
                code: "INVALID_USER_STATUS",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        const payload = {
            vendorId,
            actorUserId,
            userId: req.params?.id,
            request: req,
        };

        const user =
            status === "active"
                ? await vendorUserManagementService.activateUser(payload)
                : await vendorUserManagementService.deactivateUser(payload);

        return sendSuccess(res, {
            message: `Vendor user ${status === "active" ? "activated" : "deactivated"} successfully.`,
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /vendor-portal/users/:id/password                                    */
/* -------------------------------------------------------------------------- */

export const resetPassword = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);

        const result = await vendorUserManagementService.resetPassword({
            vendorId,
            actorUserId,
            userId: req.params?.id,
            password: body.password ?? body.newPassword ?? body.new_password,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user password reset successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /vendor-portal/users/:id/role                                        */
/* -------------------------------------------------------------------------- */

export const assignRole = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);
        const roleId = body.roleId ?? body.role_id ?? body.role;

        if (!roleId) {
            return res.status(422).json({
                success: false,
                message: "Role is required.",
                code: "ROLE_REQUIRED",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        const user = await vendorUserManagementService.assignRole({
            vendorId,
            actorUserId,
            userId: req.params?.id,
            roleId,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user role assigned successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /vendor-portal/users/bulk-status                                      */
/* -------------------------------------------------------------------------- */

export const bulkUpdateStatus = async (req, res) => {
    try {
        const body = req.body || {};
        const { vendorId, actorUserId } = getContext(req);

        const userIds = body.userIds ?? body.user_ids ?? body.ids ?? [];

        const result = await vendorUserManagementService.bulkUpdateStatus({
            vendorId,
            actorUserId,
            userIds,
            status: body.status,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user statuses updated successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

/* -------------------------------------------------------------------------- */
/* PROFILE IMAGE                                                              */
/* -------------------------------------------------------------------------- */

export const uploadProfileImage = async (req, res) => {
    try {
        const { vendorId, actorUserId } = getContext(req);

        if (!req.file) {
            return res.status(422).json({
                success: false,
                message: "Profile image file is required.",
                code: "PROFILE_IMAGE_REQUIRED",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        const user = await vendorUserManagementService.updateProfileImage({
            vendorId,
            actorUserId,
            userId: req.params?.id,
            file: req.file,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user profile image uploaded successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

export const removeProfileImage = async (req, res) => {
    try {
        const { vendorId, actorUserId } = getContext(req);

        const user = await vendorUserManagementService.removeProfileImage({
            vendorId,
            actorUserId,
            userId: req.params?.id,
            request: req,
        });

        return sendSuccess(res, {
            message: "Vendor user profile image removed successfully.",
            data: user,
        });
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};

export const getProfileImage = async (req, res) => {
    try {
        const { vendorId } = getContext(req);
        const metadata = await vendorUserManagementService.getProfileImageFile({
            vendorId,
            userId: req.params?.id,
        });

        const resolvedPath = storageService.resolveStoragePath(
            metadata.storageKey,
        );

        let stats;
        try {
            stats = await fs.promises.stat(resolvedPath);
        } catch (error) {
            if (error?.code === "ENOENT") {
                return res.status(404).json({
                    success: false,
                    message: "Profile image is not available.",
                    code: "PROFILE_IMAGE_FILE_NOT_FOUND",
                    ...(req.requestId ? { requestId: req.requestId } : {}),
                });
            }

            throw error;
        }

        if (!stats.isFile()) {
            return res.status(404).json({
                success: false,
                message: "Profile image is not available.",
                code: "PROFILE_IMAGE_FILE_NOT_FOUND",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        const etag = `"${stats.size.toString(16)}-${Math.floor(
            stats.mtimeMs,
        ).toString(16)}"`;

        if (req.headers["if-none-match"] === etag) {
            return res.status(304).end();
        }

        res.setHeader(
            "Content-Type",
            metadata.mimeType || "application/octet-stream",
        );
        res.setHeader("Content-Length", stats.size);
        res.setHeader(
            "Cache-Control",
            "private, max-age=3600, must-revalidate",
        );
        res.setHeader("ETag", etag);
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("Cross-Origin-Resource-Policy", "same-site");

        const stream = fs.createReadStream(resolvedPath);

        stream.on("error", (error) => {
            if (!res.headersSent) {
                res.status(500).json({
                    success: false,
                    message: "Unable to read profile image.",
                    code: "PROFILE_IMAGE_READ_FAILED",
                    ...(req.requestId ? { requestId: req.requestId } : {}),
                });
                return;
            }

            res.destroy(error);
        });

        stream.pipe(res);
        return undefined;
    } catch (error) {
        return sendError(res, error, req.requestId);
    }
};


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default {
    list,
    listAssignableRoles,
    get,
    create,
    update,
    updateStatus,
    resetPassword,
    assignRole,
    checkEmail,
    bulkUpdateStatus,
    uploadProfileImage,
    removeProfileImage,
    getProfileImage,
};
