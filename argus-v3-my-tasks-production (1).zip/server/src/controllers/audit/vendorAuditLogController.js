// src/controllers/audit/vendorAuditLogController.js

import mongoose from "mongoose";

import User from "../../models/User.js";
import auditService, {
    AuditServiceError,
} from "../../services/audit/auditService.js";
import {
    getAuthenticatedVendorId,
} from "../../middleware/auth.js";


/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;
const MAX_SEARCH_LENGTH = 120;
const MAX_FILTER_LENGTH = 120;


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function queryValue(value) {
    if (Array.isArray(value)) {
        return value[0];
    }

    return value;
}

function normalizeText(value, maxLength = MAX_FILTER_LENGTH) {
    return String(value ?? "")
        .trim()
        .slice(0, maxLength);
}

function parsePositiveInteger(value, fallback, maximum = Number.MAX_SAFE_INTEGER) {
    const parsed = Number.parseInt(String(value ?? ""), 10);

    if (!Number.isFinite(parsed) || parsed <= 0) {
        return fallback;
    }

    return Math.min(parsed, maximum);
}

function isValidObjectId(value) {
    return Boolean(
        value &&
        mongoose.isValidObjectId(value),
    );
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = "Request completed successfully.",
        data = null,
        meta = null,
    } = {},
) {
    return res.status(statusCode).json({
        success: true,
        message,
        data,
        ...(meta && typeof meta === "object" ? meta : {}),
    });
}

function sendError(res, error, requestId = null) {
    if (error instanceof AuditServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details
                ? { details: error.details }
                : {}),
            ...(requestId ? { requestId } : {}),
        });
    }

    if (error?.name === "ValidationError") {
        const fields = {};

        for (const [field, detail] of Object.entries(error.errors || {})) {
            fields[field] = detail?.message || "Invalid value.";
        }

        return res.status(422).json({
            success: false,
            message: "Validation failed.",
            code: "VALIDATION_ERROR",
            details: { fields },
            ...(requestId ? { requestId } : {}),
        });
    }

    if (error?.name === "CastError") {
        return res.status(422).json({
            success: false,
            message: "One or more supplied identifiers are invalid.",
            code: "INVALID_IDENTIFIER",
            ...(requestId ? { requestId } : {}),
        });
    }

    console.error("[VendorAuditLogController]", {
        requestId,
        error,
    });

    return res.status(500).json({
        success: false,
        message: "Unable to process the vendor audit log request.",
        code: "INTERNAL_SERVER_ERROR",
        ...(requestId ? { requestId } : {}),
    });
}

function getVendorId(req) {
    const vendorId = getAuthenticatedVendorId(req);

    if (!vendorId || !isValidObjectId(vendorId)) {
        const error = new AuditServiceError(
            "The authenticated vendor scope is invalid.",
            {
                code: "INVALID_VENDOR_SCOPE",
                statusCode: 403,
            },
        );

        throw error;
    }

    return String(vendorId);
}

async function assertVendorUser({
    userId,
    vendorId,
}) {
    const normalizedUserId = normalizeText(userId, 64);

    if (!normalizedUserId) {
        return null;
    }

    if (!isValidObjectId(normalizedUserId)) {
        throw new AuditServiceError(
            "Invalid user id.",
            {
                code: "INVALID_USER_ID",
                statusCode: 422,
                details: { field: "actorUserId" },
            },
        );
    }

    const user = await User.findOne({
        _id: new mongoose.Types.ObjectId(normalizedUserId),
        userType: "vendor",
        vendorId: new mongoose.Types.ObjectId(vendorId),
    })
        .select("_id email displayName userType vendorId status")
        .lean();

    if (!user) {
        throw new AuditServiceError(
            "Vendor user was not found.",
            {
                code: "USER_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return user;
}

function buildListOptions(req, vendorId) {
    const query = req.query || {};

    const actorUserId = queryValue(
        query.actorUserId ?? query.userId,
    );

    return {
        page: parsePositiveInteger(
            queryValue(query.page),
            DEFAULT_PAGE,
        ),
        limit: parsePositiveInteger(
            queryValue(query.limit),
            DEFAULT_LIMIT,
            MAX_LIMIT,
        ),
        search: normalizeText(
            queryValue(query.search),
            MAX_SEARCH_LENGTH,
        ),
        action: normalizeText(
            queryValue(query.action),
            MAX_FILTER_LENGTH,
        ),
        module: normalizeText(
            queryValue(query.module),
            MAX_FILTER_LENGTH,
        ),
        actorType: "vendor",
        entityType: normalizeText(
            queryValue(query.entityType),
            MAX_FILTER_LENGTH,
        ),
        entityId: normalizeText(
            queryValue(query.entityId),
            200,
        ),
        actorUserId: normalizeText(
            actorUserId,
            64,
        ) || undefined,
        // IMPORTANT: vendor scope always comes from the authenticated token.
        // Never trust req.query.vendorId for tenant isolation.
        vendorId,
        status: normalizeText(
            queryValue(query.status),
            30,
        ),
        fromDate: queryValue(
            query.fromDate ?? query.startDate,
        ),
        toDate: queryValue(
            query.toDate ?? query.endDate,
        ),
    };
}


/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/audit                                                   */
/* -------------------------------------------------------------------------- */

export async function list(req, res) {
    try {
        const vendorId = getVendorId(req);
        const options = buildListOptions(req, vendorId);

        // User Log is a vendor-user activity surface. When actorUserId is
        // supplied, verify that the selected user belongs to this vendor
        // before reading the audit collection.
        await assertVendorUser({
            userId: options.actorUserId,
            vendorId,
        });

        const result = await auditService.listAuditLogs(options);

        return sendSuccess(res, {
            data: result.items,
            message: "Vendor audit logs retrieved successfully.",
            meta: {
                pagination: result.pagination,
                filters: result.filters,
            },
        });
    } catch (error) {
        return sendError(
            res,
            error,
            req.requestId,
        );
    }
}


/* -------------------------------------------------------------------------- */
/* GET /vendor-portal/audit/:id                                               */
/* -------------------------------------------------------------------------- */

export async function get(req, res) {
    try {
        const vendorId = getVendorId(req);
        const id = normalizeText(req.params?.id, 64);

        if (!id) {
            return res.status(422).json({
                success: false,
                message: "Audit log id is required.",
                code: "AUDIT_ID_REQUIRED",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        if (!isValidObjectId(id)) {
            return res.status(422).json({
                success: false,
                message: "Invalid audit log id.",
                code: "INVALID_AUDIT_ID",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        const data = await auditService.getAuditLogById(id);

        /* ------------------------------------------------------------------ */
        /* Tenant isolation                                                    */
        /* ------------------------------------------------------------------ */

        // Vendor audit details must never be readable merely because the
        // caller knows another tenant's audit record id.
        if (!data?.vendorId || String(data.vendorId) !== String(vendorId)) {
            return res.status(404).json({
                success: false,
                message: "Audit log entry was not found.",
                code: "AUDIT_NOT_FOUND",
                ...(req.requestId ? { requestId: req.requestId } : {}),
            });
        }

        // Prevent a malformed/legacy vendor audit record from being exposed
        // when its actor is not actually a user inside the authenticated
        // vendor tenant.
        if (data.actor?.id) {
            await assertVendorUser({
                userId: data.actor.id,
                vendorId,
            });
        }

        return sendSuccess(res, {
            data,
            message: "Vendor audit log entry retrieved successfully.",
        });
    } catch (error) {
        return sendError(
            res,
            error,
            req.requestId,
        );
    }
}


/* -------------------------------------------------------------------------- */
/* No browser write endpoints                                                 */
/* -------------------------------------------------------------------------- */

export async function create(_req, res) {
    return res.status(405).json({
        success: false,
        message: "Audit events are created internally by application services.",
        code: "AUDIT_WRITE_NOT_ALLOWED",
    });
}

export async function update(_req, res) {
    return res.status(409).json({
        success: false,
        message: "Audit log records are immutable and cannot be updated.",
        code: "AUDIT_IMMUTABLE",
    });
}

export async function remove(_req, res) {
    return res.status(409).json({
        success: false,
        message: "Audit log records are immutable and cannot be deleted.",
        code: "AUDIT_IMMUTABLE",
    });
}


export default {
    list,
    get,
    create,
    update,
    remove,
};
