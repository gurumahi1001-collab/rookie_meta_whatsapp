import { createRFQ, deleteRFQ, getRFQ, listRFQs, RFQServiceError, sendRFQ, updateRFQ, closeRFQ } from "../../services/rfq/rfqService.js";

function actorId(req) { return req.user?.id || req.user?._id || req.user?.userId || null; }
function body(req) { const value = req?.body; if (!value || typeof value !== "object" || Array.isArray(value)) throw new RFQServiceError("Request body must be a JSON object.", { code: "INVALID_REQUEST_BODY", statusCode: 400 }); return value; }
function sendError(res, req, error) {
  if (error instanceof RFQServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}), ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.code === 11000) return res.status(409).json({ success: false, message: "RFQ reference already exists.", code: "RFQ_REFERENCE_DUPLICATE", ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "RFQ validation failed.", code: "RFQ_VALIDATION_FAILED", details: { fields: Object.fromEntries(Object.entries(error.errors || {}).map(([k, v]) => [k, v?.message || "Invalid value."])) }, ...(req.requestId ? { requestId: req.requestId } : {}) });
  console.error("[rfqController]", { message: error?.message, stack: error?.stack, requestId: req.requestId });
  return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the RFQ.", code: "INTERNAL_SERVER_ERROR", ...(req.requestId ? { requestId: req.requestId } : {}) });
}

export async function list(req, res) { try { const result = await listRFQs(req.query || {}); return res.json({ success: true, data: result.data, pagination: result.pagination }); } catch (e) { return sendError(res, req, e); } }
export async function get(req, res) { try { return res.json({ success: true, data: await getRFQ(req.params.id) }); } catch (e) { return sendError(res, req, e); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "RFQ created successfully.", data: await createRFQ({ payload: body(req), userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function update(req, res) { try { return res.json({ success: true, message: "RFQ updated successfully.", data: await updateRFQ({ id: req.params.id, payload: body(req), userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function send(req, res) { try { return res.json({ success: true, message: "RFQ issued and vendor invitation records created.", data: await sendRFQ({ id: req.params.id, userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function close(req, res) { try { return res.json({ success: true, message: "RFQ closed successfully.", data: await closeRFQ({ id: req.params.id, userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function remove(req, res) { try { return res.json({ success: true, message: "RFQ deleted successfully.", data: await deleteRFQ({ id: req.params.id, userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export default { list, get, create, update, send, close, remove };
