// src/controllers/settings/vendorRolesPermissionsController.js

import mongoose from "mongoose";

import rolesPermissionsService, {
    RolesPermissionsServiceError,
} from "../../services/settings/rolesPermissionsService.js";

import Role from "../../models/Role.js";
import Permission from "../../models/Permission.js";

/* -------------------------------------------------------------------------- */
/* Vendor permission boundary                                                 */
/* -------------------------------------------------------------------------- */

/*
 * The vendor panel navigation exposes only these application areas.
 * Keep this allow-list server-side so a vendor cannot grant itself an
 * internal-only permission by posting a different permissionId.
 *
 * Notifications are intentionally absent because notification access is
 * handled by the dedicated vendor notification endpoints and is not a
 * RolePermission permission-key in the current application catalog.
 */
const VENDOR_PERMISSION_KEYS = Object.freeze([
    "dashboard",
    "quotation",
    "project",
    "task",
    "user_management",
    "roles_permissions",
]);

const VENDOR_PERMISSION_KEY_SET =
    new Set(VENDOR_PERMISSION_KEYS);

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getAuthenticatedUserId(req) {
    return (
        req?.user?.id ||
        req?.user?.userId ||
        req?.user?._id ||
        null
    );
}

function getAuthenticatedVendorId(req) {
    return (
        req?.user?.vendorId ||
        null
    );
}

function normalizeString(value) {
    return typeof value === "string"
        ? value.trim()
        : "";
}

function normalizeKey(value) {
    return normalizeString(value)
        .toLowerCase()
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_.-]/g, "_")
        .replace(/_+/g, "_")
        .replace(/^[_-]+|[_-]+$/g, "");
}

function vendorRoleKey(value) {
    const normalized =
        normalizeKey(value);

    if (!normalized) {
        return "";
    }

    return normalized.startsWith("vendor_")
        ? normalized
        : `vendor_${normalized}`;
}

function parseOptionalBoolean(value) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    if (typeof value === "boolean") {
        return value;
    }

    const normalized =
        String(value)
            .trim()
            .toLowerCase();

    if (
        normalized === "true" ||
        normalized === "1"
    ) {
        return true;
    }

    if (
        normalized === "false" ||
        normalized === "0"
    ) {
        return false;
    }

    return undefined;
}

function parsePositiveInteger(
    value,
    fallback,
) {
    const parsed = Number.parseInt(
        String(value ?? ""),
        10,
    );

    if (
        !Number.isFinite(parsed) ||
        parsed <= 0
    ) {
        return fallback;
    }

    return parsed;
}

function assertObjectId(
    value,
    fieldName,
) {
    if (
        !value ||
        !mongoose.isValidObjectId(value)
    ) {
        const error =
            new RolesPermissionsServiceError(
                `Invalid ${fieldName}.`,
                {
                    code: "INVALID_OBJECT_ID",
                    statusCode: 422,
                    details: {
                        field: fieldName,
                    },
                },
            );

        throw error;
    }
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = "Request completed successfully.",
        data = null,
    } = {},
) {
    return res.status(statusCode).json({
        success: true,
        message,
        data,
    });
}

function sendError(res, error) {
    if (
        error instanceof
        RolesPermissionsServiceError
    ) {
        return res
            .status(error.statusCode || 400)
            .json({
                success: false,
                message: error.message,
                code: error.code,
                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    if (error?.code === 11000) {
        const duplicateField =
            Object.keys(
                error.keyPattern || {},
            )[0] || "value";

        return res
            .status(409)
            .json({
                success: false,
                message:
                    `A record with the same ${duplicateField} already exists.`,
                code: "DUPLICATE_RECORD",
            });
    }

    if (
        error?.name === "ValidationError"
    ) {
        const fields = {};

        for (const [
            field,
            detail,
        ] of Object.entries(
            error.errors || {},
        )) {
            fields[field] =
                detail.message;
        }

        return res
            .status(422)
            .json({
                success: false,
                message:
                    "Validation failed.",
                code: "VALIDATION_ERROR",
                details: { fields },
            });
    }

    if (error?.name === "CastError") {
        return res
            .status(422)
            .json({
                success: false,
                message:
                    "One or more supplied identifiers are invalid.",
                code: "INVALID_IDENTIFIER",
            });
    }

    console.error(
        "[VendorRolesPermissionsController]",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,
            message:
                "Unable to process vendor roles and permissions.",
            code: "INTERNAL_SERVER_ERROR",
        });
}

async function findVendorRoleOrThrow(
    roleId,
    vendorId,
) {
    assertObjectId(roleId, "roleId");

    assertObjectId(vendorId, "vendorId");

    const role = await Role.findById(
        roleId,
    );

    if (!role) {
        throw new RolesPermissionsServiceError(
            "Role was not found.",
            {
                code: "ROLE_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    const allowedUserTypes =
        Array.isArray(role.allowedUserTypes)
            ? role.allowedUserTypes
            : [];

    const vendorCompatible =
        (role.realm === "vendor" ||
            role.realm === "both") &&
        (role.allowsUserType
            ? role.allowsUserType("vendor")
            : allowedUserTypes.includes(
                  "vendor",
              ));

    if (!vendorCompatible) {
        throw new RolesPermissionsServiceError(
            "The selected role is not a vendor portal role.",
            {
                code:
                    "ROLE_NOT_VENDOR_COMPATIBLE",
                statusCode: 403,
            },
        );
    }

    const isGlobalSystemVendorRole =
        role.system === true &&
        !role.vendorId;

    const belongsToVendor =
        role.vendorId &&
        String(role.vendorId) ===
            String(vendorId);

    if (!belongsToVendor && !isGlobalSystemVendorRole) {
        throw new RolesPermissionsServiceError(
            "You are not allowed to access this vendor role.",
            {
                code:
                    "ROLE_VENDOR_SCOPE_FORBIDDEN",
                statusCode: 403,
            },
        );
    }

    if (!role.active) {
        throw new RolesPermissionsServiceError(
            "The selected role is inactive.",
            {
                code: "ROLE_INACTIVE",
                statusCode: 409,
            },
        );
    }

    return role;
}

async function getVendorPermissionCatalog() {
    const permissions =
        await Permission.find({
            active: true,
            key: {
                $in:
                    VENDOR_PERMISSION_KEYS,
            },
        })
            .sort({
                sortOrder: 1,
                name: 1,
            })
            .lean();

    return permissions;
}

async function assertVendorPermissionId(
    permissionId,
) {
    assertObjectId(
        permissionId,
        "permissionId",
    );

    const permission =
        await Permission.findOne({
            _id: permissionId,
            active: true,
        }).lean();

    if (!permission) {
        throw new RolesPermissionsServiceError(
            "Permission was not found or is inactive.",
            {
                code: "PERMISSION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    if (
        !VENDOR_PERMISSION_KEY_SET.has(
            permission.key,
        )
    ) {
        throw new RolesPermissionsServiceError(
            "This permission is not available to vendor portal roles.",
            {
                code:
                    "VENDOR_PERMISSION_FORBIDDEN",
                statusCode: 403,
            },
        );
    }

    return permission;
}

function filterMatrixToVendor(
    result,
) {
    if (!result) {
        return result;
    }

    return {
        ...result,
        permissions: Array.isArray(
            result.permissions,
        )
            ? result.permissions.filter(
                  (permission) =>
                      VENDOR_PERMISSION_KEY_SET.has(
                          permission.key,
                      ),
              )
            : [],
    };
}

function validateVendorScope(req) {
    const vendorId =
        getAuthenticatedVendorId(req);

    /*
     * Every vendor role operation must be bound to the vendor identity in
     * the authenticated token. The Role model/service enforce the same
     * tenant boundary, so request payloads can never select another vendor's
     * custom role scope.
     */
    assertObjectId(vendorId, "vendorId");

    return vendorId;
}

/* -------------------------------------------------------------------------- */
/* GET /roles                                                                 */
/* -------------------------------------------------------------------------- */

export const list = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const query = req.query || {};

        const result =
            await rolesPermissionsService.listRoles({
                search:
                    Array.isArray(query.search)
                        ? query.search[0]
                        : query.search || "",

                active:
                    parseOptionalBoolean(
                        Array.isArray(query.active)
                            ? query.active[0]
                            : query.active,
                    ),

                realm: "vendor",
                userType: "vendor",
                vendorId,

                page: parsePositiveInteger(
                    Array.isArray(query.page)
                        ? query.page[0]
                        : query.page,
                    1,
                ),

                limit: Math.min(
                    100,
                    parsePositiveInteger(
                        Array.isArray(query.limit)
                            ? query.limit[0]
                            : query.limit,
                        50,
                    ),
                ),
            });

        return sendSuccess(res, {
            message:
                "Vendor roles loaded successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /roles/permissions                                                     */
/* -------------------------------------------------------------------------- */

export const permissions = async (
    req,
    res,
) => {
    try {
        validateVendorScope(req);

        const query = req.query || {};

        const search =
            Array.isArray(query.search)
                ? query.search[0]
                : normalizeString(
                      query.search,
                  );

        const category =
            Array.isArray(query.category)
                ? query.category[0]
                : normalizeString(
                      query.category,
                  );

        const catalog =
            await getVendorPermissionCatalog();

        const normalizedSearch =
            search.toLowerCase();
        const normalizedCategory =
            category.toLowerCase();

        const data = catalog.filter(
            (permission) => {
                if (
                    normalizedSearch &&
                    ![
                        permission.key,
                        permission.name,
                        permission.description,
                    ].some((value) =>
                        String(value || "")
                            .toLowerCase()
                            .includes(
                                normalizedSearch,
                            ),
                    )
                ) {
                    return false;
                }

                if (
                    normalizedCategory &&
                    String(
                        permission.category ||
                            "",
                    ).toLowerCase() !==
                        normalizedCategory
                ) {
                    return false;
                }

                return true;
            },
        );

        /* Use the existing service serializer for an identical response shape. */
        const serialized =
            await rolesPermissionsService.listPermissions({
                active: true,
            });

        const allowed =
            new Map(
                serialized
                    .filter((item) =>
                        VENDOR_PERMISSION_KEY_SET.has(
                            item.key,
                        ),
                    )
                    .map((item) => [
                        item.key,
                        item,
                    ]),
            );

        const filtered = data
            .map((item) =>
                allowed.get(item.key),
            )
            .filter(Boolean);

        return sendSuccess(res, {
            message:
                "Vendor permissions loaded successfully.",
            data: filtered,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /roles/:roleId                                                         */
/* -------------------------------------------------------------------------- */

export const get = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;

        await findVendorRoleOrThrow(
            roleId,
            vendorId,
        );

        const result =
            await rolesPermissionsService.getRole(
                roleId,
                { vendorId },
            );

        result.permissions =
            result.permissions.filter(
                (permission) =>
                    VENDOR_PERMISSION_KEY_SET.has(
                        permission.key,
                    ),
            );

        return sendSuccess(res, {
            message:
                "Vendor role loaded successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* GET /roles/:roleId/permissions                                            */
/* -------------------------------------------------------------------------- */

export const matrix = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;

        await findVendorRoleOrThrow(
            roleId,
            vendorId,
        );

        const result =
            await rolesPermissionsService.getRolePermissionMatrix(
                roleId,
                { vendorId },
            );

        return sendSuccess(res, {
            message:
                "Vendor role permissions loaded successfully.",
            data: filterMatrixToVendor(
                result,
            ),
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* POST /roles                                                                */
/* -------------------------------------------------------------------------- */

export const create = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const body = req.body || {};
        const userId =
            getAuthenticatedUserId(req);

        const role =
            await rolesPermissionsService.createRole(
                {
                    name: body.name,
                    key: vendorRoleKey(body.key || body.name),
                    description:
                        body.description,
                    realm: "vendor",
                    allowedUserTypes: [
                        "vendor",
                    ],
                    sortOrder:
                        body.sortOrder,
                    createdBy: userId,
                    vendorId,
                },
            );

        return sendSuccess(res, {
            statusCode: 201,
            message:
                "Vendor role created successfully.",
            data: role,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /roles/:roleId                                                       */
/* -------------------------------------------------------------------------- */

export const update = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;
        const body = req.body || {};
        const userId =
            getAuthenticatedUserId(req);

        const role =
            await findVendorRoleOrThrow(
                roleId,
                vendorId,
            );

        const suppliedRealm =
            body.realm !== undefined
                ? "vendor"
                : undefined;

        const suppliedUserTypes =
            body.allowedUserTypes !==
                undefined
                ? ["vendor"]
                : undefined;

        const suppliedKey =
            body.key !== undefined
                ? vendorRoleKey(body.key)
                : undefined;

        const updated =
            await rolesPermissionsService.updateRole(
                {
                    roleId: role._id,
                    name: body.name,
                    key: suppliedKey,
                    description:
                        body.description,
                    realm: suppliedRealm,
                    allowedUserTypes:
                        suppliedUserTypes,
                    sortOrder:
                        body.sortOrder,
                    active: body.active,
                    updatedBy: userId,
                    vendorId,
                },
            );

        return sendSuccess(res, {
            message:
                "Vendor role updated successfully.",
            data: updated,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* DELETE /roles/:roleId                                                      */
/* -------------------------------------------------------------------------- */

export const remove = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;

        await findVendorRoleOrThrow(
            roleId,
            vendorId,
        );

        const result =
            await rolesPermissionsService.deleteRole(
                {
                    roleId,
                    vendorId,
                },
            );

        return sendSuccess(res, {
            message:
                "Vendor role removed successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* PUT /roles/:roleId/permissions                                             */
/* -------------------------------------------------------------------------- */

export const replacePermissions = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;
        const body = req.body || {};
        const assignments =
            body.assignments ??
            body.permissions ??
            [];

        await findVendorRoleOrThrow(
            roleId,
            vendorId,
        );

        if (!Array.isArray(assignments)) {
            throw new RolesPermissionsServiceError(
                "Permission assignments must be an array.",
                {
                    code:
                        "INVALID_PERMISSION_ASSIGNMENTS",
                    statusCode: 422,
                },
            );
        }

        const normalizedAssignments =
            [];

        for (const item of assignments) {
            const permissionId =
                item?.permissionId ||
                item?.id;

            /* Preserve the base service behavior for malformed/empty rows. */
            if (!permissionId) {
                continue;
            }

            await assertVendorPermissionId(
                permissionId,
            );

            normalizedAssignments.push(
                item,
            );
        }

        const userId =
            getAuthenticatedUserId(req);

        const result =
            await rolesPermissionsService.replaceRolePermissions(
                {
                    roleId,
                    assignments:
                        normalizedAssignments,
                    updatedBy: userId,
                    vendorId,
                },
            );

        return sendSuccess(res, {
            message:
                "Vendor role permissions saved successfully.",
            data: filterMatrixToVendor(
                result,
            ),
        });
    } catch (error) {
        return sendError(res, error);
    }
};

/* -------------------------------------------------------------------------- */
/* PATCH /roles/:roleId/permissions/:permissionId                             */
/* -------------------------------------------------------------------------- */

export const updatePermission = async (
    req,
    res,
) => {
    try {
        const vendorId = validateVendorScope(req);

        const roleId =
            req.params?.roleId;
        const permissionId =
            req.params?.permissionId;
        const body = req.body || {};
        const userId =
            getAuthenticatedUserId(req);

        await findVendorRoleOrThrow(
            roleId,
            vendorId,
        );
        await assertVendorPermissionId(
            permissionId,
        );

        const result =
            await rolesPermissionsService.updateRolePermission(
                {
                    roleId,
                    permissionId,
                    actions:
                        body.actions ??
                        body,
                    updatedBy: userId,
                    vendorId,
                },
            );

        return sendSuccess(res, {
            message:
                "Vendor permission updated successfully.",
            data: result,
        });
    } catch (error) {
        return sendError(res, error);
    }
};

export default Object.freeze({
    list,
    permissions,
    get,
    matrix,
    create,
    update,
    remove,
    replacePermissions,
    updatePermission,
});
