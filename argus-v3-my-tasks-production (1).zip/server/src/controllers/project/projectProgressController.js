import projectService, { ProjectServiceError } from "../../services/project/projectService.js";

function actorId(req) {
    return req.user?.id || req.user?._id || req.user?.userId || null;
}

function bodyOf(req) {
    const body = req?.body;
    if (!body || typeof body !== "object" || Array.isArray(body)) {
        throw new ProjectServiceError("Request body must be a JSON object.", {
            code: "INVALID_REQUEST_BODY",
            statusCode: 400,
        });
    }
    return body;
}

function sendError(res, req, error) {
    if (error instanceof ProjectServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    if (error?.name === "CastError") {
        return res.status(400).json({
            success: false,
            message: "Invalid project identifier.",
            code: "INVALID_PROJECT_IDENTIFIER",
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    console.error("[projectProgressController]", {
        message: error?.message,
        code: error?.code,
        stack: error?.stack,
        requestId: req.requestId,
    });
    return res.status(500).json({
        success: false,
        message: "An unexpected error occurred while processing project progress.",
        code: "INTERNAL_SERVER_ERROR",
        ...(req.requestId ? { requestId: req.requestId } : {}),
    });
}

export async function get(req, res) {
    try {
        const data = await projectService.getProjectProgress(req.params?.id);
        return res.json({ success: true, data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function update(req, res) {
    try {
        const data = await projectService.updateProjectProgress({
            id: req.params?.id,
            payload: bodyOf(req),
            userId: actorId(req),
        });
        return res.json({ success: true, message: "Project progress updated successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function activity(req, res) {
    try {
        const data = await projectService.addProjectActivityLog({
            id: req.params?.id,
            activity: bodyOf(req),
            userId: actorId(req),
        });
        return res.status(201).json({ success: true, message: "Project activity recorded successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export default { get, update, activity };
