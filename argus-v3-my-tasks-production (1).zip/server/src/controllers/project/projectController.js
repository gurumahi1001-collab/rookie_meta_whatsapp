import projectService, { ProjectServiceError } from "../../services/project/projectService.js";

function actorId(req) { return req.user?.id || req.user?._id || req.user?.userId || null; }
function bodyOf(req) {
    const body = req?.body;
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new ProjectServiceError("Request body must be a JSON object.", { code: "INVALID_REQUEST_BODY", statusCode: 400 });
    return body;
}
function sendError(res, req, error) {
    if (error instanceof ProjectServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}), ...(req.requestId ? { requestId: req.requestId } : {}) });
    if (error?.code === 11000) return res.status(409).json({ success: false, message: "A project with the same reference already exists.", code: "PROJECT_REFERENCE_DUPLICATE", ...(req.requestId ? { requestId: req.requestId } : {}) });
    if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Project validation failed.", code: "VALIDATION_ERROR", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([field, detail]) => [field, detail?.message || "Invalid value."])), ...(req.requestId ? { requestId: req.requestId } : {}) });
    if (error?.name === "CastError") return res.status(400).json({ success: false, message: "One or more project identifiers are invalid.", code: "INVALID_PROJECT_IDENTIFIER", ...(req.requestId ? { requestId: req.requestId } : {}) });
    console.error("[projectController]", { message: error?.message, code: error?.code, stack: error?.stack, requestId: req.requestId });
    return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the project.", code: "INTERNAL_SERVER_ERROR", ...(req.requestId ? { requestId: req.requestId } : {}) });
}

export async function list(req, res) { try { const result = await projectService.listProjects({ search: req.query?.search, status: req.query?.status, page: req.query?.page, limit: req.query?.limit }); return res.json({ success: true, data: result.data, pagination: result.pagination }); } catch (error) { return sendError(res, req, error); } }
export async function get(req, res) { try { return res.json({ success: true, data: await projectService.getProject(req.params?.id) }); } catch (error) { return sendError(res, req, error); } }
export async function assignees(req, res) { try { return res.json({ success: true, data: await projectService.listProjectAssignees() }); } catch (error) { return sendError(res, req, error); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "Project created successfully.", data: await projectService.createProject({ payload: bodyOf(req), userId: actorId(req) }) }); } catch (error) { return sendError(res, req, error); } }
export async function update(req, res) { try { return res.json({ success: true, message: "Project updated successfully.", data: await projectService.updateProject({ id: req.params?.id, payload: bodyOf(req), userId: actorId(req) }) }); } catch (error) { return sendError(res, req, error); } }
export async function remove(req, res) { try { return res.json({ success: true, message: "Project deleted successfully.", data: await projectService.deleteProject(req.params?.id) }); } catch (error) { return sendError(res, req, error); } }

export default { list, get, assignees, create, update, remove };
