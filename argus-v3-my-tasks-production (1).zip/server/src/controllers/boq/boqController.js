import {
    listBOQs,
    getBOQ,
    createBOQ,
    updateBOQ,
    lockBOQ,
    deleteBOQ,
    BOQServiceError,
} from "../../services/boq/boqService.js";

function actorId(req) {
    return req.user?.id || req.user?._id || req.user?.userId || null;
}

function bodyOf(req) {
    const body = req?.body;
    if (!body || typeof body !== "object" || Array.isArray(body)) {
        throw new BOQServiceError("Request body must be a JSON object.", {
            code: "INVALID_REQUEST_BODY",
            statusCode: 400,
        });
    }
    return body;
}

function sendError(res, req, error) {
    if (error instanceof BOQServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    if (error?.code === 11000) {
        return res.status(409).json({
            success: false,
            message: "A BOQ with the same reference already exists.",
            code: "BOQ_REFERENCE_DUPLICATE",
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    if (error?.name === "ValidationError") {
        return res.status(422).json({
            success: false,
            message: "BOQ validation failed.",
            code: "VALIDATION_ERROR",
            details: {
                fields: Object.fromEntries(
                    Object.entries(error.errors || {}).map(([field, detail]) => [field, detail?.message || "Invalid value."]),
                ),
            },
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    if (error?.name === "CastError") {
        return res.status(422).json({
            success: false,
            message: "One or more supplied BOQ identifiers are invalid.",
            code: "INVALID_BOQ_IDENTIFIER",
            ...(req.requestId ? { requestId: req.requestId } : {}),
        });
    }
    console.error("[boqController]", {
        message: error?.message,
        code: error?.code,
        stack: error?.stack,
        requestId: req.requestId,
    });
    return res.status(500).json({
        success: false,
        message: "An unexpected error occurred while processing the BOQ.",
        code: "INTERNAL_SERVER_ERROR",
        ...(req.requestId ? { requestId: req.requestId } : {}),
    });
}

export async function list(req, res) {
    try {
        const result = await listBOQs({
            search: req.query?.search,
            status: req.query?.status,
            page: req.query?.page,
            limit: req.query?.limit,
        });
        return res.status(200).json({ success: true, data: result.data, pagination: result.pagination });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function get(req, res) {
    try {
        const data = await getBOQ(req.params?.id, { includeLines: true });
        return res.status(200).json({ success: true, data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function create(req, res) {
    try {
        const data = await createBOQ({ payload: bodyOf(req), userId: actorId(req) });
        return res.status(201).json({ success: true, message: "BOQ created successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function update(req, res) {
    try {
        const data = await updateBOQ({ id: req.params?.id, payload: bodyOf(req), userId: actorId(req) });
        return res.status(200).json({ success: true, message: "BOQ updated successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function lock(req, res) {
    try {
        const data = await lockBOQ({ id: req.params?.id, userId: actorId(req) });
        return res.status(200).json({ success: true, message: "BOQ locked successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function remove(req, res) {
    try {
        const data = await deleteBOQ(req.params?.id, { userId: actorId(req) });
        return res.status(200).json({ success: true, message: "BOQ deleted successfully.", data });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export default { list, get, create, update, lock, remove };
