export const list = async (_req, res) => res.status(501).json({ success: false, message: "Quotation document management is scheduled for the document workflow." });
export const get = async (_req, res) => res.status(501).json({ success: false, message: "Quotation document management is scheduled for the document workflow." });
export const create = async (_req, res) => res.status(501).json({ success: false, message: "Quotation document management is scheduled for the document workflow." });
export const update = async (_req, res) => res.status(501).json({ success: false, message: "Quotation document management is scheduled for the document workflow." });
export const remove = async (_req, res) => res.status(501).json({ success: false, message: "Quotation document management is scheduled for the document workflow." });
export default { list, get, create, update, remove };
