import quotationService from "../../services/quotation/quotationService.js";

export const list = async (_req, res) => res.status(501).json({ success: false, message: "Quotation lines are returned through the quotation resource." });
export const get = async (_req, res) => res.status(501).json({ success: false, message: "Quotation lines are returned through the quotation resource." });
export const create = async (_req, res) => res.status(405).json({ success: false, message: "Quotation lines must be changed through the quotation edit workflow." });
export const update = async (_req, res) => res.status(405).json({ success: false, message: "Quotation lines must be changed through the quotation edit workflow." });
export const remove = async (_req, res) => res.status(405).json({ success: false, message: "Quotation lines must be changed through the quotation edit workflow." });
export default { list, get, create, update, remove };
