import quotationService, { QuotationServiceError } from "../../services/quotation/quotationService.js";

function actorId(req) { return req.user?.id || req.user?._id || req.user?.userId || null; }
function bodyOf(req) {
  const body = req?.body;
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new QuotationServiceError("Request body must be a JSON object.", { code: "INVALID_REQUEST_BODY", statusCode: 400 });
  return body;
}
function sendError(res, req, error) {
  if (error instanceof QuotationServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}), ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Quotation validation failed.", code: "VALIDATION_ERROR", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([field, detail]) => [field, detail?.message || "Invalid value."])), ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.name === "CastError") return res.status(400).json({ success: false, message: "One or more quotation identifiers are invalid.", code: "INVALID_QUOTATION_IDENTIFIER", ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.code === 11000) return res.status(409).json({ success: false, message: "A quotation with the same reference already exists.", code: "QUOTATION_REFERENCE_DUPLICATE", ...(req.requestId ? { requestId: req.requestId } : {}) });
  console.error("[quotationController]", { message: error?.message, code: error?.code, stack: error?.stack, requestId: req.requestId });
  return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the quotation.", code: "INTERNAL_SERVER_ERROR", ...(req.requestId ? { requestId: req.requestId } : {}) });
}

export async function list(req, res) { try { const result = await quotationService.listQuotations({ search: req.query?.search, status: req.query?.status, vendorId: req.query?.vendorId, rfqId: req.query?.rfqId, page: req.query?.page, limit: req.query?.limit }); return res.json({ success: true, data: result.data, pagination: result.pagination }); } catch (error) { return sendError(res, req, error); } }
export async function get(req, res) { try { return res.json({ success: true, data: await quotationService.getQuotation(req.params?.id) }); } catch (error) { return sendError(res, req, error); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "Quotation draft created successfully.", data: await quotationService.createQuotation({ payload: bodyOf(req), userId: actorId(req) }) }); } catch (error) { return sendError(res, req, error); } }
export async function update(req, res) { try { return res.json({ success: true, message: "Quotation updated successfully.", data: await quotationService.updateQuotation({ id: req.params?.id, payload: bodyOf(req), userId: actorId(req) }) }); } catch (error) { return sendError(res, req, error); } }
export async function submit(req, res) { try { return res.json({ success: true, message: "Quotation submitted for approval.", data: await quotationService.submitQuotation({ id: req.params?.id, userId: actorId(req), comment: req.body?.comment }) }); } catch (error) { return sendError(res, req, error); } }
export async function approve(req, res) { try { return res.json({ success: true, message: "Quotation approved successfully.", data: await quotationService.approveQuotation({ id: req.params?.id, userId: actorId(req), comment: req.body?.comment }) }); } catch (error) { return sendError(res, req, error); } }
export async function reject(req, res) { try { return res.json({ success: true, message: "Quotation rejected successfully.", data: await quotationService.rejectQuotation({ id: req.params?.id, userId: actorId(req), comment: req.body?.comment }) }); } catch (error) { return sendError(res, req, error); } }
export async function award(req, res) { try { return res.json({ success: true, message: "Quotation awarded successfully.", data: await quotationService.awardQuotation({ id: req.params?.id, userId: actorId(req), comment: req.body?.comment }) }); } catch (error) { return sendError(res, req, error); } }
export async function remove(req, res) { try { return res.json({ success: true, message: "Quotation deleted successfully.", data: await quotationService.deleteQuotation({ id: req.params?.id }) }); } catch (error) { return sendError(res, req, error); } }

export default { list, get, create, update, submit, approve, reject, award, remove };
