import invoiceService, { InvoiceServiceError } from "../../services/invoice/invoiceService.js";

function actorId(req) { return req.user?.id || req.user?._id || req.user?.userId || null; }
function body(req) { const value = req?.body; if (!value || typeof value !== "object" || Array.isArray(value)) throw new InvoiceServiceError("Request body must be a JSON object.", { code: "INVALID_REQUEST_BODY", statusCode: 400 }); return value; }
function sendError(res, req, error) {
  if (error instanceof InvoiceServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}), ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.code === 11000) return res.status(409).json({ success: false, message: "Invoice reference already exists.", code: "INVOICE_REFERENCE_DUPLICATE", ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Invoice validation failed.", code: "INVOICE_VALIDATION_FAILED", details: { fields: Object.fromEntries(Object.entries(error.errors || {}).map(([k, v]) => [k, v?.message || "Invalid value."])) }, ...(req.requestId ? { requestId: req.requestId } : {}) });
  if (error?.name === "CastError") return res.status(400).json({ success: false, message: "One or more invoice identifiers are invalid.", code: "INVALID_INVOICE_IDENTIFIER", ...(req.requestId ? { requestId: req.requestId } : {}) });
  console.error("[invoiceController]", { message: error?.message, code: error?.code, stack: error?.stack, requestId: req.requestId });
  return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the invoice.", code: "INTERNAL_SERVER_ERROR", ...(req.requestId ? { requestId: req.requestId } : {}) });
}

export async function list(req, res) { try { const result = await invoiceService.listInvoices(req.query || {}); return res.json({ success: true, data: result.data, pagination: result.pagination }); } catch (e) { return sendError(res, req, e); } }
export async function eligibleQuotations(_req, res) { try { return res.json({ success: true, data: await invoiceService.listInvoiceEligibleQuotations() }); } catch (e) { return sendError(res, _req, e); } }
export async function get(req, res) { try { return res.json({ success: true, data: await invoiceService.getInvoice(req.params.id) }); } catch (e) { return sendError(res, req, e); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "Invoice created successfully.", data: await invoiceService.createInvoice({ payload: body(req), userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function update(req, res) { try { return res.json({ success: true, message: "Invoice updated successfully.", data: await invoiceService.updateInvoice({ id: req.params.id, payload: body(req), userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function submit(req, res) { try { return res.json({ success: true, message: "Invoice submitted successfully.", data: await invoiceService.submitInvoice({ id: req.params.id, userId: actorId(req), comment: body(req)?.comment }) }); } catch (e) { return sendError(res, req, e); } }
export async function approve(req, res) { try { return res.json({ success: true, message: "Invoice approved successfully.", data: await invoiceService.approveInvoice({ id: req.params.id, userId: actorId(req), comment: body(req)?.comment }) }); } catch (e) { return sendError(res, req, e); } }
export async function reject(req, res) { try { return res.json({ success: true, message: "Invoice rejected successfully.", data: await invoiceService.rejectInvoice({ id: req.params.id, userId: actorId(req), comment: body(req)?.comment }) }); } catch (e) { return sendError(res, req, e); } }
export async function markPaid(req, res) { try { return res.json({ success: true, message: "Payment recorded successfully.", data: await invoiceService.markInvoicePaid({ id: req.params.id, payload: body(req), userId: actorId(req), files: req.files || [] }) }); } catch (e) { return sendError(res, req, e); } }
export async function uploadDocument(req, res) { try { return res.json({ success: true, message: "Invoice document uploaded successfully.", data: await invoiceService.attachInvoiceDocument({ id: req.params.id, file: req.file, userId: actorId(req) }) }); } catch (e) { return sendError(res, req, e); } }
export async function remove(req, res) { try { return res.json({ success: true, message: "Invoice deleted successfully.", data: await invoiceService.deleteInvoice({ id: req.params.id }) }); } catch (e) { return sendError(res, req, e); } }
export default { list, eligibleQuotations, get, create, update, submit, approve, reject, markPaid, uploadDocument, remove };
