// src/controllers/survey/surveyTemplateController.js

import surveyTemplateService, {
    SurveyTemplateServiceError,
} from "../../services/survey/surveyTemplateService.js";

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getAuthenticatedUser(req) {
    return req?.user || null;
}

function getActorId(req) {
    const user = getAuthenticatedUser(req);

    return (
        user?.id ||
        user?.userId ||
        user?._id ||
        null
    );
}

function getRequestId(req) {
    return req?.requestId || req?.id || null;
}

function normalizeQueryValue(value) {
    if (Array.isArray(value)) {
        return value[0];
    }

    return value;
}

function getBody(req) {
    const body = req?.body;

    if (body === undefined || body === null) {
        return {};
    }

    if (
        typeof body !== "object" ||
        Array.isArray(body)
    ) {
        throw new SurveyTemplateServiceError(
            "Request body must be a JSON object.",
            {
                code: "INVALID_REQUEST_BODY",
                statusCode: 400,
            },
        );
    }

    return body;
}

function requireTemplateId(req) {
    const id = String(
        req?.params?.id ?? "",
    ).trim();

    if (!id) {
        throw new SurveyTemplateServiceError(
            "Survey template ID is required.",
            {
                code: "SURVEY_TEMPLATE_ID_REQUIRED",
                statusCode: 400,
            },
        );
    }

    return id;
}

function parseBoolean(value) {
    const normalized = String(
        normalizeQueryValue(value) ?? "",
    )
        .trim()
        .toLowerCase();

    if (!normalized) {
        return undefined;
    }

    if (["true", "1", "yes"].includes(normalized)) {
        return true;
    }

    if (["false", "0", "no"].includes(normalized)) {
        return false;
    }

    return undefined;
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = "Request completed successfully.",
        data = null,
        pagination = undefined,
        filters = undefined,
    } = {},
) {
    const body = {
        success: true,
        message,
        data,
    };

    if (pagination !== undefined) {
        body.pagination = pagination;
    }

    if (filters !== undefined) {
        body.filters = filters;
    }

    return res
        .status(statusCode)
        .json(body);
}

function sendError(res, req, error) {
    if (error instanceof SurveyTemplateServiceError) {
        return res
            .status(error.statusCode || 400)
            .json({
                success: false,
                message: error.message,
                code: error.code,
                ...(error.details
                    ? { details: error.details }
                    : {}),
                ...(getRequestId(req)
                    ? { requestId: getRequestId(req) }
                    : {}),
            });
    }

    if (error?.code === 11000) {
        return res
            .status(409)
            .json({
                success: false,
                message:
                    "A survey template with the supplied unique value already exists.",
                code: "DUPLICATE_SURVEY_TEMPLATE",
                ...(getRequestId(req)
                    ? { requestId: getRequestId(req) }
                    : {}),
            });
    }

    if (error?.name === "ValidationError") {
        const fields = {};

        for (const [field, fieldError] of Object.entries(
            error.errors || {},
        )) {
            fields[field] =
                fieldError?.message || "Invalid value.";
        }

        return res
            .status(422)
            .json({
                success: false,
                message: "Survey template validation failed.",
                code: "VALIDATION_ERROR",
                details: {
                    fields,
                },
                ...(getRequestId(req)
                    ? { requestId: getRequestId(req) }
                    : {}),
            });
    }

    if (error?.name === "CastError") {
        return res
            .status(422)
            .json({
                success: false,
                message:
                    "One or more supplied survey template identifiers are invalid.",
                code: "INVALID_SURVEY_TEMPLATE_IDENTIFIER",
                ...(getRequestId(req)
                    ? { requestId: getRequestId(req) }
                    : {}),
            });
    }

    console.error(
        "[surveyTemplateController] Unexpected error",
        {
            name: error?.name,
            message: error?.message,
            code: error?.code,
            statusCode: error?.statusCode,
            requestId: getRequestId(req),
            stack: error?.stack,
        },
    );

    return res
        .status(500)
        .json({
            success: false,
            message:
                "An unexpected error occurred while processing the survey template.",
            code: "INTERNAL_SERVER_ERROR",
            ...(getRequestId(req)
                ? { requestId: getRequestId(req) }
                : {}),
        });
}

/* -------------------------------------------------------------------------- */
/* Controllers                                                                */
/* -------------------------------------------------------------------------- */

export async function list(req, res) {
    try {
        const result =
            await surveyTemplateService.listTemplates({
                search: normalizeQueryValue(req.query?.search),
                status: normalizeQueryValue(req.query?.status),
                moduleCode: normalizeQueryValue(
                    req.query?.moduleCode,
                ),
                createdBy: normalizeQueryValue(
                    req.query?.createdBy,
                ),
                page: normalizeQueryValue(req.query?.page),
                limit: normalizeQueryValue(req.query?.limit),
            });

        return sendSuccess(res, {
            data: result.data,
            pagination: result.pagination,
            filters: result.filters,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function active(req, res) {
    try {
        const data =
            await surveyTemplateService.getActiveTemplates();

        return sendSuccess(res, {
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function get(req, res) {
    try {
        const data =
            await surveyTemplateService.getTemplate(
                requireTemplateId(req),
            );

        return sendSuccess(res, {
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function create(req, res) {
    try {
        const data =
            await surveyTemplateService.createTemplate(
                getBody(req),
                {
                    actor: getAuthenticatedUser(req),
                },
            );

        return sendSuccess(res, {
            statusCode: 201,
            message:
                "Survey template created successfully.",
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function update(req, res) {
    try {
        const data =
            await surveyTemplateService.updateTemplate(
                requireTemplateId(req),
                getBody(req),
                {
                    actor: getAuthenticatedUser(req),
                },
            );

        return sendSuccess(res, {
            message:
                "Survey template updated successfully.",
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function remove(req, res) {
    try {
        const data =
            await surveyTemplateService.removeTemplate(
                requireTemplateId(req),
                {
                    actor: getAuthenticatedUser(req),
                },
            );

        return sendSuccess(res, {
            message:
                "Survey template archived successfully.",
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

export async function restore(req, res) {
    try {
        const activate =
            parseBoolean(req.query?.activate) === true;

        const data =
            await surveyTemplateService.restoreTemplate(
                requireTemplateId(req),
                {
                    actor: getAuthenticatedUser(req),
                    activate,
                },
            );

        return sendSuccess(res, {
            message:
                activate
                    ? "Survey template restored and activated successfully."
                    : "Survey template restored as a draft successfully.",
            data,
        });
    } catch (error) {
        return sendError(res, req, error);
    }
}

/* -------------------------------------------------------------------------- */
/* Compatibility export                                                      */
/* -------------------------------------------------------------------------- */

export default {
    list,
    active,
    get,
    create,
    update,
    remove,
    restore,
};
