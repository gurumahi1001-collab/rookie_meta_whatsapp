// src/controllers/survey/surveyReportController.js

import {
    SurveyReportServiceError,
    list as listReportsService,
    getById as getByIdService,
    create as createReportService,
    update as updateReportService,
    remove as removeReportService,
} from '../../services/survey/surveyReportService.js';

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function queryValue(value, fallback = '') {
    if (value === undefined || value === null) {
        return fallback;
    }

    if (Array.isArray(value)) {
        return String(value[0] ?? fallback).trim();
    }

    return String(value).trim();
}

function bodyObject(req) {
    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
        return {};
    }

    return req.body;
}

function getActorId(req) {
    return (
        req.user?.id ||
        req.user?._id ||
        req.user?.userId ||
        null
    );
}

function requireActorId(req) {
    const actorId = getActorId(req);

    if (!actorId) {
        throw new SurveyReportServiceError(
            'Authentication is required.',
            {
                code: 'AUTHENTICATION_REQUIRED',
                statusCode: 401,
            },
        );
    }

    return actorId;
}

function requestId(req) {
    return req.requestId || null;
}

function sendSuccess(
    req,
    res,
    {
        statusCode = 200,
        message = 'Request completed successfully.',
        data = null,
        meta = null,
    } = {},
) {
    return res.status(statusCode).json({
        success: true,
        message,
        data,
        ...(meta && typeof meta === 'object' ? meta : {}),
        ...(requestId(req) ? { requestId: requestId(req) } : {}),
    });
}

function sendError(req, res, error) {
    if (error instanceof SurveyReportServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
            ...(requestId(req) ? { requestId: requestId(req) } : {}),
        });
    }

    if (error?.name === 'ValidationError') {
        const fields = {};

        for (const [field, detail] of Object.entries(error.errors || {})) {
            fields[field] = detail?.message || 'Invalid value.';
        }

        return res.status(422).json({
            success: false,
            message: 'Survey report validation failed.',
            code: 'VALIDATION_ERROR',
            details: { fields },
            ...(requestId(req) ? { requestId: requestId(req) } : {}),
        });
    }

    if (error?.name === 'CastError') {
        return res.status(422).json({
            success: false,
            message: 'One or more supplied identifiers are invalid.',
            code: 'INVALID_IDENTIFIER',
            ...(requestId(req) ? { requestId: requestId(req) } : {}),
        });
    }

    if (error?.code === 11000) {
        return res.status(409).json({
            success: false,
            message: 'A survey report with the supplied unique value already exists.',
            code: 'SURVEY_REPORT_DUPLICATE',
            ...(requestId(req) ? { requestId: requestId(req) } : {}),
        });
    }

    console.error('[SurveyReportController]', {
        requestId: requestId(req),
        message: error?.message,
        stack: error?.stack,
    });

    return res.status(500).json({
        success: false,
        message: 'Unable to process the survey report request.',
        code: 'INTERNAL_SERVER_ERROR',
        ...(requestId(req) ? { requestId: requestId(req) } : {}),
    });
}

function buildListOptions(req) {
    return {
        page: queryValue(req.query?.page),
        limit: queryValue(req.query?.limit),
        search: queryValue(req.query?.search),
        sort: queryValue(req.query?.sort),
        sortOrder: queryValue(req.query?.sortOrder),
        status: queryValue(req.query?.status),
        templateId: queryValue(req.query?.templateId),
        responseId: queryValue(req.query?.responseId),
        projectId: queryValue(req.query?.projectId),
        vendorId: queryValue(req.query?.vendorId),
        generatedBy: queryValue(req.query?.generatedBy),
        from: queryValue(
            req.query?.from ?? req.query?.fromDate,
        ),
        to: queryValue(
            req.query?.to ?? req.query?.toDate,
        ),
        includeArchived:
            req.query?.includeArchived === true ||
            ['true', '1'].includes(
                queryValue(req.query?.includeArchived).toLowerCase(),
            ),
    };
}

function requireRouteId(value) {
    const id = queryValue(value);

    if (!id) {
        throw new SurveyReportServiceError(
            'Survey report ID is required.',
            {
                code: 'SURVEY_REPORT_ID_REQUIRED',
                statusCode: 400,
            },
        );
    }

    return id;
}

/* -------------------------------------------------------------------------- */
/* GET /reports                                                               */
/* -------------------------------------------------------------------------- */

export async function listReports(req, res) {
    try {
        const result = await listReportsService(buildListOptions(req));

        return sendSuccess(req, res, {
            data: result.data,
            message: 'Survey reports retrieved successfully.',
            meta: {
                pagination: result.pagination,
                filters: result.filters,
            },
        });
    } catch (error) {
        return sendError(req, res, error);
    }
}

/* -------------------------------------------------------------------------- */
/* GET /reports/:id                                                           */
/* -------------------------------------------------------------------------- */

export async function get(req, res) {
    try {
        const id = requireRouteId(req.params?.id);
        const data = await getByIdService(id);

        return sendSuccess(req, res, {
            data,
            message: 'Survey report retrieved successfully.',
        });
    } catch (error) {
        return sendError(req, res, error);
    }
}

/* -------------------------------------------------------------------------- */
/* POST /reports                                                              */
/* -------------------------------------------------------------------------- */

export async function createReport(req, res) {
    try {
        const actorId = requireActorId(req);
        const payload = bodyObject(req);
        const data = await createReportService(payload, actorId);

        return sendSuccess(req, res, {
            statusCode: 201,
            data,
            message: 'Survey report created successfully.',
        });
    } catch (error) {
        return sendError(req, res, error);
    }
}

/* -------------------------------------------------------------------------- */
/* PATCH /reports/:id                                                         */
/* -------------------------------------------------------------------------- */

export async function updateReport(req, res) {
    try {
        const actorId = requireActorId(req);
        const id = requireRouteId(req.params?.id);
        const payload = bodyObject(req);
        const data = await updateReportService(id, payload, actorId);

        return sendSuccess(req, res, {
            data,
            message: 'Survey report updated successfully.',
        });
    } catch (error) {
        return sendError(req, res, error);
    }
}

/* -------------------------------------------------------------------------- */
/* DELETE /reports/:id                                                        */
/* -------------------------------------------------------------------------- */

export async function removeReport(req, res) {
    try {
        const actorId = requireActorId(req);
        const id = requireRouteId(req.params?.id);
        const data = await removeReportService(id, actorId);

        return sendSuccess(req, res, {
            data,
            message: 'Survey report archived successfully.',
        });
    } catch (error) {
        return sendError(req, res, error);
    }
}

/* -------------------------------------------------------------------------- */
/* Backward-compatible names                                                  */
/* -------------------------------------------------------------------------- */

export const list = listReports;
export const create = createReport;
export const update = updateReport;
export const remove = removeReport;

export default {
    list,
    get,
    create,
    update,
    remove,
};
