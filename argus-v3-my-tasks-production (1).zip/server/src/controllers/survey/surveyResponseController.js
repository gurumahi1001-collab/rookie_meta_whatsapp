// src/controllers/survey/surveyResponseController.js

import {
    listSurveyResponses,
    getSurveyResponse,
    createSurveyResponse,
    updateSurveyResponse,
    deleteSurveyResponse,
    SurveyResponseServiceError,
} from "../../services/survey/surveyResponseService.js";

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function authenticatedUserId(req) {
    return (
        req?.user?.id ||
        req?.user?._id ||
        req?.user?.userId ||
        null
    );
}

function requestBody(req) {
    const body = req?.body;

    if (body == null) {
        return {};
    }

    if (typeof body !== "object" || Array.isArray(body)) {
        throw new SurveyResponseServiceError(
            "Request body must be a JSON object.",
            {
                code: "INVALID_REQUEST_BODY",
                statusCode: 400,
            },
        );
    }

    return body;
}

function queryValue(value) {
    if (Array.isArray(value)) {
        return value[0];
    }

    return value;
}

function queryBoolean(value) {
    const normalized = String(queryValue(value) ?? "")
        .trim()
        .toLowerCase();

    if (!normalized) {
        return undefined;
    }

    if (["true", "1", "yes", "on"].includes(normalized)) {
        return true;
    }

    if (["false", "0", "no", "off"].includes(normalized)) {
        return false;
    }

    return undefined;
}

function requireId(req) {
    const id = String(req?.params?.id ?? "").trim();

    if (!id) {
        throw new SurveyResponseServiceError(
            "Survey response ID is required.",
            {
                code: "SURVEY_RESPONSE_ID_REQUIRED",
                statusCode: 400,
            },
        );
    }

    return id;
}

function responseFilters(req) {
    const query = req?.query || {};

    return {
        page: queryValue(query.page),
        limit: queryValue(query.limit),
        templateId: queryValue(query.templateId ?? query.template_id),
        projectId: queryValue(query.projectId ?? query.project_id),
        respondentId: queryValue(
            query.respondentId ?? query.respondent_id,
        ),
        status: queryValue(query.status),
        surveyDateFrom: queryValue(query.surveyDateFrom),
        surveyDateTo: queryValue(query.surveyDateTo),
        submittedFrom: queryValue(query.submittedFrom),
        submittedTo: queryValue(query.submittedTo),
        sortBy: queryValue(query.sortBy ?? query.sort),
        sortOrder: queryValue(query.sortOrder),
        includeArchived: queryBoolean(query.includeArchived) === true,
    };
}

function sendServiceError(res, error) {
    if (error instanceof SurveyResponseServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details ? { details: error.details } : {}),
        });
    }

    if (error?.name === "ValidationError") {
        const fields = {};

        for (const [field, fieldError] of Object.entries(error.errors || {})) {
            fields[field] = fieldError?.message || "Invalid value.";
        }

        return res.status(422).json({
            success: false,
            message: "Survey response validation failed.",
            code: "SURVEY_RESPONSE_VALIDATION_FAILED",
            fields,
        });
    }

    if (error?.code === 11000) {
        return res.status(409).json({
            success: false,
            message: "A survey response with the same unique reference already exists.",
            code: "DUPLICATE_SURVEY_RESPONSE",
        });
    }

    if (error?.name === "CastError") {
        return res.status(400).json({
            success: false,
            message: "Invalid survey response identifier or value.",
            code: "INVALID_SURVEY_RESPONSE_VALUE",
        });
    }

    console.error("[surveyResponseController]", {
        name: error?.name,
        message: error?.message,
        code: error?.code,
        statusCode: error?.statusCode,
        stack: error?.stack,
    });

    return res.status(500).json({
        success: false,
        message: "An unexpected error occurred while processing the survey response.",
        code: "INTERNAL_SERVER_ERROR",
    });
}

function actorContext(req) {
    return {
        userId: authenticatedUserId(req),
        userType: req?.user?.userType || req?.user?.type || null,
        roleId: req?.user?.roleId || null,
        vendorId: req?.user?.vendorId || null,
    };
}

/* -------------------------------------------------------------------------- */
/* Handlers                                                                   */
/* -------------------------------------------------------------------------- */

export async function list(req, res) {
    try {
        const result = await listSurveyResponses(responseFilters(req));

        return res.status(200).json({
            success: true,
            data: result.data,
            pagination: result.pagination,
        });
    } catch (error) {
        return sendServiceError(res, error);
    }
}

export async function get(req, res) {
    try {
        const data = await getSurveyResponse(requireId(req));

        return res.status(200).json({
            success: true,
            data,
        });
    } catch (error) {
        return sendServiceError(res, error);
    }
}

export async function create(req, res) {
    try {
        const data = await createSurveyResponse(
            requestBody(req),
            actorContext(req),
        );

        return res.status(201).json({
            success: true,
            message: "Survey response created successfully.",
            data,
        });
    } catch (error) {
        return sendServiceError(res, error);
    }
}

export async function update(req, res) {
    try {
        const data = await updateSurveyResponse(
            requireId(req),
            requestBody(req),
            actorContext(req),
        );

        return res.status(200).json({
            success: true,
            message: "Survey response updated successfully.",
            data,
        });
    } catch (error) {
        return sendServiceError(res, error);
    }
}

export async function remove(req, res) {
    try {
        const data = await deleteSurveyResponse(
            requireId(req),
            actorContext(req),
        );

        return res.status(200).json({
            success: true,
            message: "Survey response archived successfully.",
            data,
        });
    } catch (error) {
        return sendServiceError(res, error);
    }
}

export default {
    list,
    get,
    create,
    update,
    remove,
};
