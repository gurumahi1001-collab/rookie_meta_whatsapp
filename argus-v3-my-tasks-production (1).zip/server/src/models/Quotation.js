import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const QUOTATION_STATUSES = Object.freeze([
  "draft",
  "issued",
  "submitted",
  "approved",
  "rejected",
  "awarded",
  "not_responded",
]);

const quotationLineSchema = new Schema(
  {
    boqLineId: { type: Schema.Types.ObjectId, ref: "BOQLine", default: null },
    rateItemId: { type: Schema.Types.ObjectId, ref: "MarketRateItem", default: null },
    module: { type: String, trim: true, maxlength: 160, default: "" },
    category: { type: String, trim: true, maxlength: 160, default: "" },
    description: { type: String, required: true, trim: true, maxlength: 500 },
    unit: { type: String, required: true, trim: true, maxlength: 80 },
    quantity: { type: Number, required: true, min: 0.0001 },
    materialCost: { type: Number, min: 0, default: 0 },
    serviceCost: { type: Number, min: 0, default: 0 },
    quotedRate: { type: Number, required: true, min: 0 },
    taxRate: { type: Number, min: 0, max: 100, default: 15 },
    lineSubtotal: { type: Number, required: true, min: 0 },
    lineTax: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
    sortOrder: { type: Number, default: 0 },
  },
  { _id: true },
);

const paymentInstallmentSchema = new Schema(
  {
    id: { type: String, trim: true, maxlength: 80, default: "" },
    installmentName: { type: String, trim: true, maxlength: 160, default: "" },
    modules: { type: [String], default: [] },
    amount: { type: Number, min: 0, default: 0 },
    days: { type: [Number], default: [] },
  },
  { _id: false },
);

const workflowHistorySchema = new Schema(
  {
    status: { type: String, enum: QUOTATION_STATUSES, required: true },
    comment: { type: String, trim: true, maxlength: 2000, default: "" },
    performedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    performedAt: { type: Date, default: Date.now },
  },
  { _id: false },
);

const vendorSnapshotSchema = new Schema(
  {
    vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true },
    name: { type: String, required: true, trim: true, maxlength: 200 },
    email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
    contactName: { type: String, trim: true, maxlength: 160, default: "" },
  },
  { _id: false },
);

const quotationSchema = new Schema(
  {
    reference: { type: String, required: true, trim: true, uppercase: true, maxlength: 100 },
    rfq: {
      rfqId: { type: Schema.Types.ObjectId, ref: "RFQ", default: null },
      reference: { type: String, trim: true, uppercase: true, maxlength: 100, default: "" },
    },
    vendor: { type: vendorSnapshotSchema, required: true },
    projectTitle: { type: String, required: true, trim: true, maxlength: 255 },
    projectLocation: { type: String, trim: true, maxlength: 500, default: "" },
    clientName: { type: String, trim: true, maxlength: 255, default: "" },
    currency: { type: String, required: true, trim: true, uppercase: true, maxlength: 12 },
    quotationDate: { type: Date, required: true, default: Date.now },
    validUntil: { type: Date, required: true },
    scopeSummary: { type: String, trim: true, maxlength: 5000, default: "" },
    terms: { type: String, trim: true, maxlength: 5000, default: "" },
    formTemplate: { type: String, trim: true, maxlength: 255, default: "" },
    category: { type: String, trim: true, maxlength: 160, default: "General" },
    lines: { type: [quotationLineSchema], default: [] },
    paymentSchedule: { installments: { type: [paymentInstallmentSchema], default: [] } },
    subtotal: { type: Number, required: true, min: 0, default: 0 },
    taxTotal: { type: Number, required: true, min: 0, default: 0 },
    otherCharges: { type: Number, min: 0, default: 0 },
    grandTotal: { type: Number, required: true, min: 0, default: 0 },
    margin: { type: Number, min: -100, max: 100, default: 0 },
    status: { type: String, enum: QUOTATION_STATUSES, default: "draft", index: true },
    submittedAt: { type: Date, default: null },
    approvedAt: { type: Date, default: null },
    rejectedAt: { type: Date, default: null },
    awardedAt: { type: Date, default: null },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    workflowHistory: { type: [workflowHistorySchema], default: [] },
  },
  {
    collection: "quotations",
    timestamps: true,
    strict: "throw",
    minimize: false,
    versionKey: false,
  },
);

quotationSchema.index({ reference: 1 }, { unique: true, name: "quotations_reference_unique" });
quotationSchema.index({ status: 1, updatedAt: -1 });
quotationSchema.index({ "vendor.vendorId": 1, status: 1, updatedAt: -1 });
quotationSchema.index({ "rfq.rfqId": 1, status: 1 });
quotationSchema.index({ projectTitle: 1 });

export default models.Quotation || model("Quotation", quotationSchema);
