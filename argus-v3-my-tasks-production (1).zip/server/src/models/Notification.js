import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const notificationSchema = new Schema(
    {
        recipientId: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: true,
            index: true,
        },
        eventType: {
            type: String,
            required: true,
            trim: true,
            maxlength: 120,
            index: true,
        },
        title: {
            type: String,
            required: true,
            trim: true,
            maxlength: 255,
        },
        message: {
            type: String,
            required: true,
            trim: true,
            maxlength: 2000,
        },
        payload: {
            type: Schema.Types.Mixed,
            default: null,
        },
        readAt: {
            type: Date,
            default: null,
            index: true,
        },
    },
    {
        collection: "notifications",
        timestamps: true,
        strict: "throw",
        versionKey: false,
    },
);

notificationSchema.index({ recipientId: 1, createdAt: -1 });
notificationSchema.index({ recipientId: 1, readAt: 1, createdAt: -1 });

notificationSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        eventType: this.eventType,
        title: this.title,
        message: this.message,
        payload: this.payload,
        readAt: this.readAt,
        createdAt: this.createdAt,
    };
};

export default models.Notification || model("Notification", notificationSchema);
