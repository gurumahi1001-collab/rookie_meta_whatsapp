import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const boqLineSchema = new Schema(
    {
        boqId: {
            type: Schema.Types.ObjectId,
            ref: "BOQ",
            required: true,
            index: true,
        },
        rateItemId: {
            type: Schema.Types.ObjectId,
            ref: "MarketRateItem",
            default: null,
        },
        rateCode: {
            type: String,
            trim: true,
            uppercase: true,
            maxlength: 50,
            default: "",
        },
        customItemFlag: {
            type: Boolean,
            default: false,
        },
        categoryType: {
            type: String,
            trim: true,
            maxlength: 150,
            default: "",
        },
        category: {
            type: String,
            trim: true,
            maxlength: 150,
            default: "",
        },
        module: {
            type: String,
            trim: true,
            maxlength: 150,
            default: "",
        },
        description: {
            type: String,
            required: [true, "BOQ line description is required."],
            trim: true,
            maxlength: 2000,
        },
        unit: {
            type: String,
            required: [true, "BOQ line unit is required."],
            trim: true,
            maxlength: 100,
        },
        quantity: {
            type: Number,
            required: true,
            min: [0, "BOQ quantity cannot be negative."],
        },
        rate: {
            type: Number,
            required: true,
            min: [0, "BOQ rate cannot be negative."],
        },
        lineTotal: {
            type: Number,
            required: true,
            min: 0,
        },
        sortOrder: {
            type: Number,
            min: 0,
            default: 0,
        },
    },
    {
        collection: "boq_lines",
        timestamps: true,
        strict: "throw",
        versionKey: false,
    },
);

boqLineSchema.index({ boqId: 1, sortOrder: 1 });
boqLineSchema.index({ boqId: 1, rateItemId: 1 });

const BOQLine = models.BOQLine || model("BOQLine", boqLineSchema);

export { BOQLine, boqLineSchema };
export default BOQLine;
