import mongoose from "mongoose";

/**
 * Persistent state for one-time/ versioned application bootstrap tasks.
 *
 * The fixed `_id` prevents duplicate marker documents. A lease allows a
 * crashed process to be retried safely after the lock expires.
 */
const bootstrapStateSchema = new mongoose.Schema(
    {
        /**
         * Fixed string identifier for the bootstrap task. Using `_id` gives
         * MongoDB an always-present unique index, even before Mongoose builds
         * any optional application indexes.
         */
        _id: {
            type: String,
            required: true,
            trim: true,
        },

        version: {
            type: Number,
            required: true,
            min: 1,
        },

        status: {
            type: String,
            required: true,
            enum: [
                "running",
                "completed",
                "failed",
            ],
            default: "running",
            index: true,
        },

        startedAt: {
            type: Date,
            default: null,
        },

        completedAt: {
            type: Date,
            default: null,
        },

        lockUntil: {
            type: Date,
            default: null,
            index: true,
        },

        lastError: {
            type: String,
            default: null,
            maxlength: 2000,
        },
    },
    {
        collection: "bootstrap_states",
        timestamps: true,
        versionKey: false,
    },
);

bootstrapStateSchema.index({
    status: 1,
    lockUntil: 1,
});

const BootstrapState =
    mongoose.models.BootstrapState ||
    mongoose.model(
        "BootstrapState",
        bootstrapStateSchema,
    );

export default BootstrapState;
