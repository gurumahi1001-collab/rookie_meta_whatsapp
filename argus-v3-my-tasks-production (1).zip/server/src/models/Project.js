import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const PROJECT_STATUSES = Object.freeze([
    "planned",
    "in_progress",
    "on_hold",
    "completed",
    "closed",
]);

export const PROJECT_TASK_STATUSES = Object.freeze([
    "pending",
    "inprogress",
    "onhold",
    "completed",
]);

export const PROJECT_TASK_PRIORITIES = Object.freeze([
    "low",
    "medium",
    "high",
    "urgent",
]);

const assignedStaffSchema = new Schema(
    {
        name: { type: String, required: true, trim: true, maxlength: 160 },
        rate: { type: Number, min: 0, default: 0 },
        hours: { type: Number, min: 0, default: 0 },
        amount: { type: Number, min: 0, default: 0 },
    },
    { _id: false },
);

const taskSchema = new Schema(
    {
        id: { type: String, required: true, trim: true, maxlength: 100 },
        title: { type: String, required: true, trim: true, maxlength: 255 },
        name: { type: String, trim: true, maxlength: 255, default: "" },
        description: { type: String, trim: true, maxlength: 5000, default: "" },
        phase: { type: String, trim: true, maxlength: 100, default: "" },
        assignedTo: { type: String, trim: true, maxlength: 1000, default: "" },
        assignStaff: { type: String, trim: true, maxlength: 1000, default: "" },
        Assignstaff: { type: [assignedStaffSchema], default: [] },
        startDate: { type: String, trim: true, maxlength: 40, default: "" },
        endDate: { type: String, trim: true, maxlength: 40, default: "" },
        dueDate: { type: String, trim: true, maxlength: 40, default: "" },
        priority: { type: String, enum: PROJECT_TASK_PRIORITIES, default: "medium" },
        status: { type: String, enum: PROJECT_TASK_STATUSES, default: "pending" },
        progress: { type: Number, min: 0, max: 100, default: 0 },
        estimatedHours: { type: Number, min: 0, default: 0 },
        actualHours: { type: Number, min: 0, default: 0 },
        hourlyRate: { type: Number, min: 0, default: 0 },
        materialCost: { type: Number, min: 0, default: 0 },
        otherExpenses: { type: Number, min: 0, default: 0 },
    },
    { _id: false },
);

const phaseSchema = new Schema(
    {
        id: { type: String, required: true, trim: true, maxlength: 100 },
        name: { type: String, required: true, trim: true, maxlength: 255 },
        description: { type: String, trim: true, maxlength: 2000, default: "" },
        estimatedHours: { type: Number, min: 0, default: 0 },
        tasks: { type: [taskSchema], default: [] },
    },
    { _id: false },
);

const scopeItemSchema = new Schema(
    {
        id: { type: String, required: true, trim: true, maxlength: 100 },
        text: { type: String, required: true, trim: true, maxlength: 2000 },
        completed: { type: Boolean, default: false },
    },
    { _id: false },
);

const deliverableSchema = new Schema(
    {
        id: { type: String, required: true, trim: true, maxlength: 100 },
        name: { type: String, required: true, trim: true, maxlength: 255 },
        dueDate: { type: String, trim: true, maxlength: 40, default: "" },
        completed: { type: Boolean, default: false },
    },
    { _id: false },
);

const installmentItemSchema = new Schema(
    {
        id: { type: Schema.Types.Mixed, required: true },
        name: { type: String, required: true, trim: true, maxlength: 255 },
        rate: { type: Number, min: 0, default: 0 },
    },
    { _id: false },
);

const installmentSchema = new Schema(
    {
        id: { type: Schema.Types.Mixed, required: true },
        name: { type: String, required: true, trim: true, maxlength: 255 },
        days: { type: Number, min: 0, default: 0 },
        dueDate: { type: String, trim: true, maxlength: 40, default: "" },
        netTotalAmount: { type: Number, min: 0, default: 0 },
        status: { type: String, enum: ["Paid", "Pending"], default: "Pending" },
        moduleItems: { type: [installmentItemSchema], default: [] },
    },
    { _id: false },
);

const activityLogSchema = new Schema(
    {
        id: { type: String, required: true, trim: true, maxlength: 100 },
        entity: { type: String, required: true, trim: true, maxlength: 80 },
        entityId: { type: String, trim: true, maxlength: 100, default: "" },
        action: { type: String, enum: ["ADD", "MODIFY", "DELETE"], required: true },
        description: { type: String, required: true, trim: true, maxlength: 2000 },
        createdAt: { type: Date, default: Date.now },
        createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    { _id: false },
);

const projectSchema = new Schema(
    {
        reference: {
            type: String,
            required: true,
            trim: true,
            uppercase: true,
            maxlength: 100,
            unique: true,
            index: true,
        },
        projectName: {
            type: String,
            required: [true, "Project name is required."],
            trim: true,
            minlength: 2,
            maxlength: 255,
            index: true,
        },
        name: { type: String, trim: true, maxlength: 255, default: "" },
        description: { type: String, trim: true, maxlength: 10000, default: "" },
        location: { type: String, trim: true, maxlength: 1000, default: "" },
        currency: { type: String, trim: true, uppercase: true, maxlength: 12, default: "USD" },
        vendor: {
            vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", default: null },
            name: { type: String, trim: true, maxlength: 255, default: "" },
        },
        manager: {
            userId: { type: Schema.Types.ObjectId, ref: "User", default: null },
            name: { type: String, trim: true, maxlength: 255, default: "" },
            email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
        },
        startDate: { type: Date, default: null },
        endDate: { type: Date, default: null },
        projectValue: { type: Number, min: 0, default: 0 },
        budget: { type: Number, min: 0, default: 0 },
        surveyRef: { type: String, trim: true, maxlength: 255, default: "" },
        surveyTemplateId: { type: Schema.Types.ObjectId, ref: "SurveyTemplate", default: null },
        sourceQuotationId: { type: Schema.Types.ObjectId, ref: "Quotation", default: null },
        version: { type: String, trim: true, maxlength: 80, default: "v1.0" },
        versionDate: { type: Date, default: null },
        status: { type: String, enum: PROJECT_STATUSES, default: "planned", index: true },
        progress: { type: Number, min: 0, max: 100, default: 0 },
        inScopeItems: { type: [scopeItemSchema], default: [] },
        outOfScopeItems: { type: [scopeItemSchema], default: [] },
        phases: { type: [phaseSchema], default: [] },
        deliverables: { type: [deliverableSchema], default: [] },
        installments: { type: [installmentSchema], default: [] },
        activityLogs: { type: [activityLogSchema], default: [] },
        createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
        updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    {
        collection: "projects",
        timestamps: true,
        strict: "throw",
        minimize: false,
        versionKey: true,
    },
);

projectSchema.index({ status: 1, updatedAt: -1 });
projectSchema.index({ "vendor.vendorId": 1, status: 1 });
projectSchema.index({ "manager.userId": 1, status: 1 });
projectSchema.index({ projectName: 1, status: 1 });

const Project = models.Project || model("Project", projectSchema);

export { Project, projectSchema };
export default Project;
