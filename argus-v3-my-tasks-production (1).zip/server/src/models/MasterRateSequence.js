import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const masterRateSequenceSchema = new Schema(
    {
        _id: {
            type: String,
            required: true,
        },

        value: {
            type: Number,
            required: true,
            min: 0,
            default: 0,
        },
    },
    {
        collection: "master_rate_sequences",
        versionKey: false,
        strict: "throw",
    },
);

const MasterRateSequence =
    models.MasterRateSequence ||
    model(
        "MasterRateSequence",
        masterRateSequenceSchema,
    );

export default MasterRateSequence;
