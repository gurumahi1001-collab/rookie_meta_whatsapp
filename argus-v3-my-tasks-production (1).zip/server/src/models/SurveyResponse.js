import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/**
 * ARGUS Survey Response / Field Survey Packet
 *
 * The survey builder is intentionally schema-driven. The response payload is
 * therefore kept in a Mixed field so adding/removing survey modules does not
 * require a MongoDB migration for every new field.
 *
 * Common query dimensions remain strongly typed and indexed for reporting.
 */
const surveyResponseSchema = new Schema(
    {
        templateId: {
            type: Schema.Types.ObjectId,
            ref: "SurveyTemplate",
            required: true,
            index: true,
        },

        projectId: {
            type: Schema.Types.ObjectId,
            ref: "Project",
            default: null,
            index: true,
        },

        respondentId: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },

        /**
         * Complete dynamic survey packet.
         *
         * This may contain:
         * - project/header details
         * - module/section answers
         * - repeatable rows
         * - checklist results
         * - observations/defects
         * - attachment metadata
         */
        response: {
            type: Schema.Types.Mixed,
            required: true,
            default: () => ({}),
        },

        status: {
            type: String,
            enum: [
                "draft",
                "submitted",
                "reviewed",
                "approved",
                "rejected",
                "archived",
            ],
            default: "draft",
            index: true,
        },

        /**
         * Client-side revision number. Useful when autosave/offline recovery
         * is enabled so an older packet cannot silently overwrite a newer one.
         */
        revision: {
            type: Number,
            default: 1,
            min: 1,
            max: 1000000,
        },

        surveyDate: {
            type: Date,
            default: null,
            index: true,
        },

        submittedAt: {
            type: Date,
            default: null,
            index: true,
        },

        reviewedAt: {
            type: Date,
            default: null,
        },

        reviewedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        rejectedAt: {
            type: Date,
            default: null,
        },

        rejectedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        rejectionReason: {
            type: String,
            trim: true,
            maxlength: 2000,
            default: "",
        },

        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "survey_responses",
        timestamps: true,
        strict: "throw",
        minimize: false,
        versionKey: false,
    },
);

surveyResponseSchema.index(
    {
        templateId: 1,
        projectId: 1,
        status: 1,
        updatedAt: -1,
    },
    {
        name: "survey_responses_template_project_status_updated",
    },
);

surveyResponseSchema.index(
    {
        respondentId: 1,
        status: 1,
        surveyDate: -1,
    },
    {
        name: "survey_responses_respondent_status_date",
    },
);

surveyResponseSchema.index(
    {
        status: 1,
        submittedAt: -1,
    },
    {
        name: "survey_responses_status_submitted",
    },
);

surveyResponseSchema.pre("validate", function normalizeSurveyResponse() {
    if (
        !this.response ||
        typeof this.response !== "object" ||
        Array.isArray(this.response)
    ) {
        this.response = {};
    }

    this.revision = Math.max(
        1,
        Number.parseInt(String(this.revision || 1), 10) || 1,
    );

    if (this.status === "submitted" && !this.submittedAt) {
        this.submittedAt = new Date();
    }

    if (this.status !== "submitted" && this.status !== "reviewed" && this.status !== "approved") {
        this.submittedAt = this.submittedAt || null;
    }

    this.rejectionReason = String(this.rejectionReason || "").trim();
});

surveyResponseSchema.virtual("id").get(function id() {
    return String(this._id);
});

surveyResponseSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        templateId: this.templateId ? String(this.templateId) : null,
        projectId: this.projectId ? String(this.projectId) : null,
        respondentId: this.respondentId ? String(this.respondentId) : null,
        response: this.response || {},
        status: this.status,
        revision: this.revision,
        surveyDate: this.surveyDate,
        submittedAt: this.submittedAt,
        reviewedAt: this.reviewedAt,
        reviewedBy: this.reviewedBy ? String(this.reviewedBy) : null,
        rejectedAt: this.rejectedAt,
        rejectedBy: this.rejectedBy ? String(this.rejectedBy) : null,
        rejectionReason: this.rejectionReason,
        createdBy: this.createdBy ? String(this.createdBy) : null,
        updatedBy: this.updatedBy ? String(this.updatedBy) : null,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

surveyResponseSchema.set("toJSON", {
    virtuals: true,
});

const SurveyResponse =
    models.SurveyResponse ||
    model("SurveyResponse", surveyResponseSchema);

export {
    SurveyResponse,
    surveyResponseSchema,
};

export default SurveyResponse;
