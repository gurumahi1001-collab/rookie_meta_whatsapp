
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Role Schema
|--------------------------------------------------------------------------
|
| A Role defines who the user is.
|
| Permissions are assigned separately through RolePermission.
|
| Example system roles:
|
|   workspace_owner
|   network_admin
|   field_technician
|   billing_manager
|   vendor_admin
|   vendor_user
|
|--------------------------------------------------------------------------
*/

const roleSchema = new Schema(
    {
        /*
         * Stable internal identifier.
         *
         * This is also the identifier placed into the access JWT
         * and consumed by the existing RBAC middleware.
         */
        key: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
            lowercase: true,
            minlength: 1,
            maxlength: 100,
            match: /^[a-z0-9_.-]+$/,
        },

        /*
         * Human-readable name shown in the UI.
         */
        name: {
            type: String,
            required: true,
            trim: true,
            maxlength: 150,
        },

        /*
         * Optional description for administrators.
         */
        description: {
            type: String,
            default: "",
            trim: true,
            maxlength: 1000,
        },

        /*
         * Whether users can currently be assigned this role.
         */
        active: {
            type: Boolean,
            default: true,
            index: true,
        },

        /*
         * System roles are protected platform roles.
         *
         * Examples:
         * workspace_owner
         * vendor_user
         *
         * These should not be deleted through normal UI operations.
         */
        system: {
            type: Boolean,
            default: false,
            index: true,
        },

        /*
         * Marks the bootstrap/application-owner role.
         *
         * Only one role should normally have this enabled.
         */
        ownerRole: {
            type: Boolean,
            default: false,
            index: true,
        },

        /*
         * Determines which authentication realm can use the role.
         *
         * Note: admin and internal are distinct authentication realms.
         * A role assigned to both admin and internal user types must use
         * realm "both"; realm "internal" is for internal users only.
         *
         * internal:
         *   internal users
         *
         * vendor:
         *   vendor users
         *
         * both:
         *   role may be used across supported realms where explicitly
         *   allowed by allowedUserTypes.
         */
        realm: {
            type: String,
            enum: [
                "internal",
                "vendor",
                "both",
            ],
            default: "internal",
            index: true,
        },

        /*
         * User type restrictions.
         *
         * Existing authentication uses:
         *
         *   admin
         *   internal
         *   vendor
         *
         * Keeping this on the role allows authorization rules to
         * remain explicit instead of inferring them from role names.
         */
        allowedUserTypes: {
            type: [
                {
                    type: String,
                    enum: [
                        "admin",
                        "internal",
                        "vendor",
                    ],
                },
            ],
            default: ["internal"],
        },

        /*
         * Vendor tenant scope.
         *
         * - Admin/internal roles keep this as null.
         * - Custom vendor roles are owned by exactly one Vendor document.
         * - System vendor template roles (for example vendor_admin /
         *   vendor_user) may remain global so existing bootstrap data and
         *   authentication role IDs continue to work.
         */
        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            default: null,
            index: true,
        },

        /*
         * UI ordering.
         */
        sortOrder: {
            type: Number,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Vendor scope validation
|--------------------------------------------------------------------------
|
| Vendor roles are tenant-owned unless they are system templates. This lets
| the shared bootstrap roles remain global while preventing custom vendor
| roles from accidentally becoming cross-vendor roles.
|--------------------------------------------------------------------------
*/

roleSchema.pre(
    "validate",
    function validateVendorScope() {
        const isVendorRealm =
            this.realm === "vendor";

        const hasVendorScope =
            Boolean(this.vendorId);

        if (
            isVendorRealm &&
            !this.system &&
            !hasVendorScope
        ) {
            this.invalidate(
                "vendorId",
                "Custom vendor roles must belong to a vendor.",
            );
        }

        if (
            !isVendorRealm &&
            hasVendorScope
        ) {
            this.invalidate(
                "vendorId",
                "Only vendor-realm roles can have a vendor scope.",
            );
        }
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

roleSchema.index({
    active: 1,
    sortOrder: 1,
});

roleSchema.index({
    realm: 1,
    active: 1,
    sortOrder: 1,
});

roleSchema.index({
    vendorId: 1,
    active: 1,
    sortOrder: 1,
});

roleSchema.index({
    vendorId: 1,
    realm: 1,
    active: 1,
    sortOrder: 1,
});

roleSchema.index({
    system: 1,
    active: 1,
});

roleSchema.index({
    ownerRole: 1,
});

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return the role identifier used by authentication/RBAC.
 */
roleSchema.methods.getRBACKey =
    function getRBACKey() {
        return this.key;
    };

/**
 * Determine whether this role can be assigned to a user type.
 */
roleSchema.methods.allowsUserType =
    function allowsUserType(
        userType,
    ) {
        if (
            typeof userType !==
            "string"
        ) {
            return false;
        }

        const normalizedUserType =
            userType
                .trim()
                .toLowerCase();

        return (
            Array.isArray(
                this.allowedUserTypes,
            ) &&
            this.allowedUserTypes.includes(
                normalizedUserType,
            )
        );
    };

/**
 * Determine whether this role belongs to an application realm.
 */
roleSchema.methods.allowsRealm =
    function allowsRealm(
        realm,
    ) {
        if (
            typeof realm !==
            "string"
        ) {
            return false;
        }

        const normalizedRealm =
            realm
                .trim()
                .toLowerCase();

        return (
            this.realm ===
                "both" ||
            this.realm ===
                normalizedRealm
        );
    };

/*
|--------------------------------------------------------------------------
| Vendor Scope Helpers
|--------------------------------------------------------------------------
*/

/**
 * Determine whether this role is a vendor role for a specific vendor.
 *
 * Global system vendor roles remain valid for every vendor; custom vendor
 * roles must match the supplied vendorId exactly.
 */
roleSchema.methods.belongsToVendor =
    function belongsToVendor(
        vendorId,
    ) {
        if (this.realm !== "vendor") {
            return false;
        }

        if (this.system && !this.vendorId) {
            return true;
        }

        if (!vendorId || !this.vendorId) {
            return false;
        }

        return String(this.vendorId) ===
            String(vendorId);
    };

/**
 * Find vendor-compatible active roles.
 *
 * The result includes global system vendor templates plus custom roles
 * belonging to the requested vendor.
 */
roleSchema.statics.findAssignableForVendor =
    function findAssignableForVendor(
        vendorId,
    ) {
        if (
            !vendorId ||
            !mongoose.isValidObjectId(vendorId)
        ) {
            return this.findOne({ _id: null });
        }

        const objectId =
            new mongoose.Types.ObjectId(
                vendorId,
            );

        return this.find({
            active: true,
            realm: "vendor",
            allowedUserTypes: "vendor",
            $or: [
                {
                    system: true,
                    vendorId: null,
                },
                {
                    vendorId: objectId,
                },
            ],
        }).sort({
            sortOrder: 1,
            name: 1,
        });
    };

/*
|--------------------------------------------------------------------------
| Query Helpers
|--------------------------------------------------------------------------
*/

roleSchema.query.activeOnly =
    function activeOnly() {
        return this.where({
            active: true,
        });
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find an active role by its stable key.
 */
roleSchema.statics.findByKey =
    function findByKey(
        key,
    ) {
        if (
            typeof key !==
                "string" ||
            !key.trim()
        ) {
            return null;
        }

        return this.findOne({
            key: key
                .trim()
                .toLowerCase(),

            active: true,
        });
    };

/**
 * Find the bootstrap/application-owner role.
 */
roleSchema.statics.findOwnerRole =
    function findOwnerRole() {
        return this.findOne({
            ownerRole: true,
            active: true,
        });
    };

/**
 * Find all roles available for a user type.
 */
roleSchema.statics.findAssignableForUserType =
    function findAssignableForUserType(
        userType,
    ) {
        if (
            typeof userType !==
            "string"
        ) {
            return this.findOne({
                _id: null,
            });
        }

        const normalizedUserType =
            userType
                .trim()
                .toLowerCase();

        return this.find({
            active: true,
            allowedUserTypes:
                normalizedUserType,
        }).sort({
            sortOrder: 1,
            name: 1,
        });
    };

/**
 * Convert a role document into the minimal authentication payload.
 *
 * This is intentionally limited to identity/authorization metadata.
 */
roleSchema.methods.toAuthContext =
    function toAuthContext() {
        return {
            roleId:
                String(
                    this._id,
                ),

            role:
                this.key,

            realm:
                this.realm,

            ownerRole:
                this.ownerRole === true,

            system:
                this.system === true,
        };
    };

/*
|--------------------------------------------------------------------------
| Mongoose Model
|--------------------------------------------------------------------------
*/

const Role =
    models.Role ||
    model(
        "Role",
        roleSchema,
    );

export default Role;
export { Role };