import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const RFQ_STATUSES = Object.freeze(["draft", "sent", "closed", "cancelled"]);
export const RFQ_VENDOR_STATUSES = Object.freeze(["pending", "invited", "submitted", "declined"]);

const vendorSnapshotSchema = new Schema(
  {
    vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true },
    name: { type: String, required: true, trim: true, maxlength: 200 },
    email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
    contactName: { type: String, trim: true, maxlength: 160, default: "" },
    inviteStatus: { type: String, enum: RFQ_VENDOR_STATUSES, default: "pending" },
    invitedAt: { type: Date, default: null },
    respondedAt: { type: Date, default: null },
  },
  { _id: false },
);

const rfqSchema = new Schema(
  {
    reference: { type: String, required: true, trim: true, uppercase: true, maxlength: 100, index: true },
    title: { type: String, required: true, trim: true, minlength: 2, maxlength: 255, index: true },
    description: { type: String, trim: true, maxlength: 3000, default: "" },
    boq: {
      boqId: { type: Schema.Types.ObjectId, ref: "BOQ", required: true },
      reference: { type: String, trim: true, uppercase: true, maxlength: 100, default: "" },
      title: { type: String, trim: true, maxlength: 255, default: "" },
    },
    surveyTemplate: {
      templateId: { type: Schema.Types.ObjectId, ref: "SurveyTemplate", default: null },
      name: { type: String, trim: true, maxlength: 255, default: "" },
      version: { type: Number, min: 1, default: 1 },
    },
    issueDate: { type: Date, required: true, default: Date.now },
    responseDueDate: { type: Date, required: true },
    currency: { type: String, trim: true, uppercase: true, maxlength: 12, default: "JMD" },
    vendors: { type: [vendorSnapshotSchema], default: [] },
    terms: { type: String, trim: true, maxlength: 5000, default: "" },
    internalNotes: { type: String, trim: true, maxlength: 5000, default: "" },
    status: { type: String, enum: RFQ_STATUSES, default: "draft", index: true },
    sentAt: { type: Date, default: null },
    closedAt: { type: Date, default: null },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  },
  { collection: "rfqs", timestamps: true, strict: "throw", minimize: false, versionKey: false },
);

rfqSchema.index({ reference: 1 }, { unique: true, name: "rfqs_reference_unique" });
rfqSchema.index({ status: 1, updatedAt: -1 });
rfqSchema.index({ "boq.boqId": 1, status: 1 });
rfqSchema.index({ "vendors.vendorId": 1, status: 1 });

export default models.RFQ || model("RFQ", rfqSchema);
