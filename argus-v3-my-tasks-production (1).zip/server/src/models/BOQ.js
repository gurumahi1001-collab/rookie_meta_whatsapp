import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const BOQ_STATUSES = Object.freeze(["draft", "locked"]);

const vendorSnapshotSchema = new Schema(
    {
        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            required: true,
        },
        name: {
            type: String,
            required: true,
            trim: true,
            maxlength: 200,
        },
    },
    { _id: false },
);

const boqSchema = new Schema(
    {
        title: {
            type: String,
            required: [true, "BOQ title is required."],
            trim: true,
            minlength: 2,
            maxlength: 255,
            index: true,
        },
        reference: {
            type: String,
            required: [true, "BOQ reference is required."],
            trim: true,
            uppercase: true,
            maxlength: 100,
            index: true,
        },
        boqDate: {
            type: Date,
            required: true,
            default: Date.now,
        },
        responseDueDate: {
            type: Date,
            default: null,
        },
        projectSiteLocation: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },
        projectValue: {
            type: Number,
            min: 0,
            default: 0,
        },
        currency: {
            type: String,
            trim: true,
            uppercase: true,
            maxlength: 12,
            default: "JMD",
        },
        siteSurveyReference: {
            type: String,
            trim: true,
            maxlength: 120,
            default: "",
        },
        formTemplate: {
            templateId: {
                type: Schema.Types.ObjectId,
                ref: "SurveyTemplate",
                default: null,
            },
            name: {
                type: String,
                trim: true,
                maxlength: 200,
                default: "",
            },
        },
        vendors: {
            type: [vendorSnapshotSchema],
            default: [],
        },
        subtotal: {
            type: Number,
            min: 0,
            default: 0,
        },
        contingencyPercentage: {
            type: Number,
            min: 0,
            max: 100,
            default: 10,
        },
        contingencyAmount: {
            type: Number,
            min: 0,
            default: 0,
        },
        grandTotal: {
            type: Number,
            min: 0,
            default: 0,
        },
        itemCount: {
            type: Number,
            min: 0,
            default: 0,
        },
        status: {
            type: String,
            enum: BOQ_STATUSES,
            default: "draft",
            index: true,
        },
        lockedAt: {
            type: Date,
            default: null,
        },
        lockedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "boqs",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

boqSchema.index(
    { reference: 1 },
    { unique: true, name: "boqs_reference_unique" },
);
boqSchema.index({ status: 1, updatedAt: -1 });
boqSchema.index({ title: 1, status: 1 });

const BOQ = models.BOQ || model("BOQ", boqSchema);

export { BOQ, boqSchema };
export default BOQ;
