import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const INVOICE_STATUSES = Object.freeze([
  "draft",
  "submitted",
  "approved",
  "rejected",
  "paid",
]);

const snapshotSchema = new Schema({
  id: { type: Schema.Types.ObjectId, default: null },
  reference: { type: String, trim: true, uppercase: true, maxlength: 120, default: "" },
  name: { type: String, trim: true, maxlength: 255, default: "" },
  email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
}, { _id: false });

const bankSchema = new Schema({
  bankName: { type: String, trim: true, maxlength: 160, default: "" },
  branch: { type: String, trim: true, maxlength: 160, default: "" },
  accountHolderName: { type: String, trim: true, maxlength: 160, default: "" },
  accountNumber: { type: String, trim: true, maxlength: 80, default: "" },
  ifscCode: { type: String, trim: true, maxlength: 40, default: "" },
  swiftCode: { type: String, trim: true, maxlength: 40, default: "" },
}, { _id: false });

const moduleSchema = new Schema({
  name: { type: String, trim: true, maxlength: 255, required: true },
  rate: { type: Number, min: 0, required: true },
}, { _id: false });

const installmentSchema = new Schema({
  id: { type: String, trim: true, maxlength: 80, required: true },
  name: { type: String, trim: true, maxlength: 255, required: true },
  amount: { type: Number, min: 0, required: true },
  dueDate: { type: Date, default: null },
  modules: { type: [moduleSchema], default: [] },
}, { _id: false });

const documentSchema = new Schema({
  originalName: { type: String, trim: true, maxlength: 255, required: true },
  storageKey: { type: String, trim: true, maxlength: 500, required: true },
  mimeType: { type: String, trim: true, lowercase: true, maxlength: 150, default: "application/octet-stream" },
  size: { type: Number, min: 0, required: true },
  checksum: { type: String, trim: true, maxlength: 128, default: "" },
  uploadedAt: { type: Date, default: Date.now },
  uploadedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { _id: false });

const paymentSchema = new Schema({
  amount: { type: Number, min: 0, default: 0 },
  transactionRefId: { type: String, trim: true, maxlength: 160, default: "" },
  paymentDate: { type: Date, default: null },
  notes: { type: String, trim: true, maxlength: 2000, default: "" },
  documents: { type: [documentSchema], default: [] },
  recordedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  recordedAt: { type: Date, default: null },
}, { _id: false });

const workflowSchema = new Schema({
  status: { type: String, enum: INVOICE_STATUSES, required: true },
  comment: { type: String, trim: true, maxlength: 2000, default: "" },
  performedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  performedAt: { type: Date, default: Date.now },
}, { _id: false });

const invoiceSchema = new Schema({
  reference: { type: String, required: true, trim: true, uppercase: true, maxlength: 100 },
  quotation: { type: snapshotSchema, required: true },
  vendor: { type: snapshotSchema, required: true },
  vendorBank: { type: bankSchema, default: () => ({}) },
  project: { type: snapshotSchema, required: true },
  currency: { type: String, required: true, trim: true, uppercase: true, maxlength: 12 },
  invoiceDate: { type: Date, required: true, default: Date.now },
  dueDate: { type: Date, required: true },
  siteReference: { type: String, trim: true, maxlength: 255, default: "" },
  milestoneName: { type: String, trim: true, maxlength: 255, default: "" },
  milestoneModules: { type: [moduleSchema], default: [] },
  selectedInstallments: { type: [installmentSchema], default: [] },
  billPercentage: { type: Number, min: 0.01, max: 100, default: 100 },
  contractValue: { type: Number, min: 0, required: true, default: 0 },
  subtotal: { type: Number, min: 0, required: true, default: 0 },
  taxRate: { type: Number, min: 0, max: 100, required: true, default: 0 },
  taxAmount: { type: Number, min: 0, required: true, default: 0 },
  totalAmount: { type: Number, min: 0, required: true, default: 0 },
  remarks: { type: String, trim: true, maxlength: 5000, default: "" },
  invoiceDocument: { type: documentSchema, default: null },
  status: { type: String, enum: INVOICE_STATUSES, default: "draft", index: true },
  rejectionRemarks: { type: String, trim: true, maxlength: 2000, default: "" },
  payment: { type: paymentSchema, default: () => ({}) },
  workflowHistory: { type: [workflowSchema], default: [] },
  createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
  updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, {
  collection: "invoices",
  timestamps: true,
  strict: "throw",
  minimize: false,
  versionKey: false,
});

invoiceSchema.index({ reference: 1 }, { unique: true, name: "invoices_reference_unique" });
invoiceSchema.index({ status: 1, updatedAt: -1 });
invoiceSchema.index({ "quotation.id": 1, status: 1, updatedAt: -1 });
invoiceSchema.index({ "vendor.id": 1, status: 1, updatedAt: -1 });
invoiceSchema.index({ "project.id": 1, status: 1, updatedAt: -1 });

export default models.Invoice || model("Invoice", invoiceSchema);
