import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const TASK_STATUSES = Object.freeze(["pending", "in_progress", "on_hold", "due_date", "completed"]);
export const TASK_PRIORITIES = Object.freeze(["low", "medium", "high", "urgent"]);

const staffSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    name: { type: String, required: true, trim: true, maxlength: 180 },
    email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
    rate: { type: Number, min: 0, default: 0 },
    hours: { type: Number, min: 0, default: 0 },
    amount: { type: Number, min: 0, default: 0 },
}, { _id: false });

const workLogSchema = new Schema({
    id: { type: String, required: true, trim: true, maxlength: 100 },
    startedAt: { type: Date, required: true },
    stoppedAt: { type: Date, required: true },
    duration: { type: Number, min: 0, required: true },
}, { _id: false });

const materialSchema = new Schema({
    id: { type: String, required: true, trim: true, maxlength: 100 },
    name: { type: String, required: true, trim: true, maxlength: 255 },
    unitCost: { type: Number, min: 0, required: true },
    quantity: { type: Number, min: 0, required: true },
}, { _id: false });

const expenseSchema = new Schema({
    id: { type: String, required: true, trim: true, maxlength: 100 },
    name: { type: String, required: true, trim: true, maxlength: 255 },
    amount: { type: Number, min: 0, required: true },
    description: { type: String, trim: true, maxlength: 2000, default: "" },
}, { _id: false });

const conversationSchema = new Schema({
    id: { type: String, required: true, trim: true, maxlength: 100 },
    type: { type: String, enum: ["update", "question", "image"], required: true },
    text: { type: String, trim: true, maxlength: 5000, default: "" },
    imageStorageKey: { type: String, trim: true, maxlength: 500, default: "" },
    createdAt: { type: Date, default: Date.now },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { _id: false });

const taskSchema = new Schema({
    reference: { type: String, required: true, unique: true, index: true, trim: true, uppercase: true, maxlength: 100 },
    title: { type: String, required: true, trim: true, minlength: 2, maxlength: 255, index: true },
    description: { type: String, trim: true, maxlength: 5000, default: "" },
    project: {
        projectId: { type: Schema.Types.ObjectId, ref: "Project", required: true },
        reference: { type: String, trim: true, maxlength: 100, default: "" },
        name: { type: String, trim: true, maxlength: 255, required: true },
    },
    phase: { type: String, trim: true, maxlength: 160, default: "" },
    assignStaff: { type: [staffSchema], default: [] },
    startDate: { type: Date, required: true },
    dueDate: { type: Date, required: true },
    priority: { type: String, enum: TASK_PRIORITIES, default: "medium", index: true },
    status: { type: String, enum: TASK_STATUSES, default: "pending", index: true },
    progress: { type: Number, min: 0, max: 100, default: 0 },
    estimatedHours: { type: Number, min: 0, default: 0 },
    timerStartedAt: { type: Date, default: null },
    totalWorkedSeconds: { type: Number, min: 0, default: 0 },
    workLogs: { type: [workLogSchema], default: [] },
    materials: { type: [materialSchema], default: [] },
    otherExpenses: { type: [expenseSchema], default: [] },
    conversations: { type: [conversationSchema], default: [] },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { collection: "tasks", timestamps: true, strict: "throw", minimize: false });

taskSchema.index({ "project.projectId": 1, status: 1, dueDate: 1 });
taskSchema.index({ "assignStaff.userId": 1, status: 1, dueDate: 1 });

const Task = models.Task || model("Task", taskSchema);
export default Task;
