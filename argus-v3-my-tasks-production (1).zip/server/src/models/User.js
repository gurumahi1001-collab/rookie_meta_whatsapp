
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const profileImageSchema = new Schema(
    {
        originalName: { type: String, trim: true, maxlength: 255 },
        storageKey: { type: String, required: true, trim: true, maxlength: 500 },
        relativePath: { type: String, required: true, trim: true, maxlength: 1000 },
        mimeType: { type: String, required: true, trim: true, lowercase: true, maxlength: 150 },
        extension: { type: String, trim: true, lowercase: true, maxlength: 20 },
        size: { type: Number, required: true, min: 0, max: 2097152 },
        checksum: { type: String, trim: true, maxlength: 128 },
        uploadedAt: { type: Date, default: Date.now },
        uploadedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    { _id: false, id: false, versionKey: false },
);

const vendorPortalOnboardingSchema = new Schema(
    {
        requiresTermsAcceptance: { type: Boolean, default: false },
        termsAcceptedAt: { type: Date, default: null },
        termsConditionId: { type: Schema.Types.ObjectId, ref: "TermsCondition", default: null },
        termsSignerName: { type: String, trim: true, maxlength: 180, default: "" },
        termsSignature: { type: String, trim: true, maxlength: 1000000, default: "" },
        invitationSentAt: { type: Date, default: null },
        invitationSentTo: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
        invitationLastError: { type: String, trim: true, maxlength: 2000, default: "" },
    },
    { _id: false, versionKey: false },
);


/*
|--------------------------------------------------------------------------
| User Schema
|--------------------------------------------------------------------------
|
| ARGUS authentication identity.
|
| User
|   ├── Role
|   └── Vendor (vendor users only)
|
| Permission assignments are resolved through:
|
|   Role
|      ↓
|   RolePermission
|      ↓
|   Permission
|
|--------------------------------------------------------------------------
*/

const userSchema = new Schema(
    {
        /*
         * Login identity.
         */
        email: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
            lowercase: true,
            maxlength: 255,
            validate: {
                validator(value) {
                    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                        value,
                    );
                },

                message:
                    "A valid email address is required.",
            },
        },

        /*
         * bcrypt password hash.
         *
         * Never return this field through normal API responses.
         */
        passwordHash: {
            type: String,
            required: true,
            select: false,
        },

        /*
         * Display name shown in the application.
         */
        displayName: {
            type: String,
            default: "",
            trim: true,
            maxlength: 180,
        },

        /*
         * Optional default hourly billing/cost rate for the user.
         * Stored as a number so calculations remain reliable; the UI may
         * submit currency-formatted text such as "$ 25" which is normalized
         * by the user-management service before persistence.
         */
        hourlyRate: {
            type: Number,
            default: null,
            min: 0,
            max: 1000000000,
        },

        /*
         * Optional private profile image. The binary is stored on the
         * configured local filesystem; MongoDB stores only safe metadata.
         */
        profileImage: {
            type: profileImageSchema,
            default: null,
        },

        /*
         * Existing ARGUS authentication supports:
         *
         * admin
         * internal
         * vendor
         */
        userType: {
            type: String,
            required: true,
            enum: [
                "admin",
                "internal",
                "vendor",
            ],
            index: true,
        },

        /*
         * Assigned authorization role.
         */
        roleId: {
            type: Schema.Types.ObjectId,
            ref: "Role",
            required: true,
            index: true,
        },

        /*
         * Vendor scope.
         *
         * Required for vendor users.
         * Must be null for internal/admin users.
         */
        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            default: null,
            index: true,
        },

        /*
         * User account lifecycle.
         */
        status: {
            type: String,
            enum: [
                "active",
                "inactive",
                "locked",
                "pending",
            ],
            default: "active",
            index: true,
        },

        /*
         * Last successful authentication time.
         */
        lastLoginAt: {
            type: Date,
            default: null,
        },

        /*
         * Failed-login protection.
         *
         * The values are server-side security state and are not
         * returned by normal user serializers.
         */
        failedLoginAttempts: {
            type: Number,
            default: 0,
            min: 0,
        },

        lockedUntil: {
            type: Date,
            default: null,
        },

        /*
         * Password lifecycle.
         */
        passwordChangedAt: {
            type: Date,
            default: null,
        },

        /*
         * Optional account verification state.
         */
        emailVerifiedAt: {
            type: Date,
            default: null,
        },

        /*
         * Vendor portal first-login / invitation lifecycle.
         */
        vendorPortalOnboarding: {
            type: vendorPortalOnboardingSchema,
            default: () => ({}),
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
|
| The old SQL contract enforced:
|
| vendor user      -> vendorId required
| admin/internal   -> vendorId null
|
| Keep the same business rule in MongoDB.
|--------------------------------------------------------------------------
*/

userSchema.pre(
    "validate",
    function validateUserScope() {
        const isVendor =
            this.userType === "vendor";

        const isNonVendor =
            this.userType === "admin" ||
            this.userType === "internal";

        if (
            isVendor &&
            !this.vendorId
        ) {
            this.invalidate(
                "vendorId",
                "Vendor users must belong to a vendor.",
            );
        }

        if (
            isNonVendor &&
            this.vendorId
        ) {
            this.invalidate(
                "vendorId",
                "Admin and internal users cannot belong to a vendor.",
            );
        }
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

userSchema.index({
    userType: 1,
    status: 1,
});

userSchema.index({
    roleId: 1,
    status: 1,
});

userSchema.index({
    vendorId: 1,
    status: 1,
});

userSchema.index({
    status: 1,
    lastLoginAt: -1,
});

/*
|--------------------------------------------------------------------------
| Query Helpers
|--------------------------------------------------------------------------
*/

userSchema.query.activeOnly =
    function activeOnly() {
        return this.where({
            status: "active",
        });
    };

/*
|--------------------------------------------------------------------------
| Security Helpers
|--------------------------------------------------------------------------
*/

/**
 * Check whether the account is currently usable.
 */
userSchema.methods.isActive =
    function isActive() {
        return (
            this.status ===
            "active"
        );
    };

/**
 * Check whether the account is currently locked.
 */
userSchema.methods.isLocked =
    function isLocked() {
        if (
            this.status ===
            "locked"
        ) {
            return true;
        }

        if (
            !this.lockedUntil
        ) {
            return false;
        }

        return (
            this.lockedUntil.getTime() >
            Date.now()
        );
    };

/**
 * Clear failed-login state after a successful login.
 */
userSchema.methods.resetLoginFailures =
    function resetLoginFailures() {
        this.failedLoginAttempts = 0;
        this.lockedUntil = null;
    };

/**
 * Record a failed authentication attempt.
 *
 * The actual threshold and lock duration should come from env
 * configuration in the authentication service.
 */
userSchema.methods.recordLoginFailure =
    function recordLoginFailure({
        maxAttempts = 5,
        lockoutMinutes = 15,
    } = {}) {
        this.failedLoginAttempts =
            Number(
                this.failedLoginAttempts ||
                    0,
            ) + 1;

        if (
            this.failedLoginAttempts >=
            maxAttempts
        ) {
            this.status =
                "locked";

            this.lockedUntil =
                new Date(
                    Date.now() +
                        lockoutMinutes *
                            60 *
                            1000,
                );
        }
    };

/**
 * Mark the user as successfully authenticated.
 */
userSchema.methods.recordSuccessfulLogin =
    function recordSuccessfulLogin() {
        this.lastLoginAt =
            new Date();

        this.failedLoginAttempts =
            0;

        this.lockedUntil =
            null;

        /*
         * If the account was temporarily locked and the service
         * explicitly permits login again, return it to active.
         */
        if (
            this.status ===
            "locked"
        ) {
            this.status =
                "active";
        }
    };

/*
|--------------------------------------------------------------------------
| Authentication Context
|--------------------------------------------------------------------------
*/

/**
 * Return the minimal identity context needed for JWT creation.
 */
userSchema.methods.toAuthContext =
    function toAuthContext() {
        return {
            userId:
                String(
                    this._id,
                ),

            userType:
                this.userType,

            roleId:
                this.roleId
                    ? String(
                          this.roleId,
                      )
                    : null,

            vendorId:
                this.vendorId
                    ? String(
                          this.vendorId,
                      )
                    : null,
        };
    };

/*
|--------------------------------------------------------------------------
| Safe API Serialization
|--------------------------------------------------------------------------
|
| Password hashes and login security state are never exposed.
|--------------------------------------------------------------------------
*/

userSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                String(
                    this._id,
                ),

            email:
                this.email,

            displayName:
                this.displayName,

            profileImage:
                this.profileImage
                    ? {
                          originalName:
                              this.profileImage.originalName || null,
                          mimeType:
                              this.profileImage.mimeType || null,
                          extension:
                              this.profileImage.extension || null,
                          size:
                              this.profileImage.size ?? null,
                          checksum:
                              this.profileImage.checksum || null,
                          uploadedAt:
                              this.profileImage.uploadedAt || null,
                      }
                    : null,

            userType:
                this.userType,

            roleId:
                this.roleId
                    ? String(
                          this.roleId,
                      )
                    : null,

            vendorId:
                this.vendorId
                    ? String(
                          this.vendorId,
                      )
                    : null,

            status:
                this.status,

            lastLoginAt:
                this.lastLoginAt,

            emailVerifiedAt:
                this.emailVerifiedAt,

            vendorPortalOnboarding: this.userType === "vendor"
                ? {
                      requiresTermsAcceptance:
                          this.vendorPortalOnboarding?.requiresTermsAcceptance === true,
                      termsAcceptedAt:
                          this.vendorPortalOnboarding?.termsAcceptedAt || null,
                      invitationSentAt:
                          this.vendorPortalOnboarding?.invitationSentAt || null,
                  }
                : null,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find by normalized email.
 */
userSchema.statics.findByEmail =
    function findByEmail(
        email,
        {
            includePasswordHash = false,
        } = {},
    ) {
        if (
            typeof email !==
                "string" ||
            !email.trim()
        ) {
            return null;
        }

        const query =
            this.findOne({
                email: email
                    .trim()
                    .toLowerCase(),
            });

        if (
            includePasswordHash
        ) {
            query.select(
                "+passwordHash",
            );
        }

        return query;
    };

/**
 * Find an active internal/admin user by id.
 */
userSchema.statics.findActiveInternalUser =
    function findActiveInternalUser(
        userId,
    ) {
        return this.findOne({
            _id: userId,

            userType: {
                $in: [
                    "admin",
                    "internal",
                ],
            },

            status: "active",
        });
    };

/**
 * Find an active vendor user by id.
 */
userSchema.statics.findActiveVendorUser =
    function findActiveVendorUser(
        userId,
    ) {
        return this.findOne({
            _id: userId,
            userType: "vendor",
            status: "active",
        });
    };

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const User =
    models.User ||
    model(
        "User",
        userSchema,
    );

export default User;
export { User };