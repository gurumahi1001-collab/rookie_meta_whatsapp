import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const quotationAttachmentSchema = new Schema(
  {
    quotationId: { type: Schema.Types.ObjectId, ref: "Quotation", required: true, index: true },
    originalName: { type: String, required: true, trim: true, maxlength: 255 },
    storedName: { type: String, required: true, trim: true, maxlength: 255 },
    storagePath: { type: String, required: true, trim: true, maxlength: 1000 },
    mimeType: { type: String, trim: true, maxlength: 255, default: "" },
    sizeBytes: { type: Number, required: true, min: 0 },
    uploadedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    uploadedAt: { type: Date, default: Date.now },
  },
  { collection: "quotation_attachments", timestamps: true, strict: "throw", versionKey: false },
);
quotationAttachmentSchema.index({ quotationId: 1, uploadedAt: -1 });
export default models.QuotationAttachment || model("QuotationAttachment", quotationAttachmentSchema);
