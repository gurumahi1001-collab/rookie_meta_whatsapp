import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const quotationLineSchema = new Schema(
  {
    quotationId: { type: Schema.Types.ObjectId, ref: "Quotation", required: true, index: true },
    boqLineId: { type: Schema.Types.ObjectId, ref: "BOQLine", default: null },
    description: { type: String, required: true, trim: true, maxlength: 500 },
    unit: { type: String, required: true, trim: true, maxlength: 80 },
    quantity: { type: Number, required: true, min: 0.0001 },
    quotedRate: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
    sortOrder: { type: Number, default: 0 },
  },
  { collection: "quotation_lines", timestamps: true, strict: "throw", versionKey: false },
);
quotationLineSchema.index({ quotationId: 1, sortOrder: 1 });
export default models.QuotationLine || model("QuotationLine", quotationLineSchema);
