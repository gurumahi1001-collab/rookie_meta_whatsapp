import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

export const SURVEY_TEMPLATE_STATUSES = Object.freeze([
    "draft",
    "active",
    "archived",
]);

const DEFAULT_SCHEMA = Object.freeze({
    version: 1,
    modules: [],
});

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeString(value, maxLength = null) {
    if (typeof value !== "string") {
        return "";
    }

    const normalized = value.trim();

    return maxLength === null
        ? normalized
        : normalized.slice(0, maxLength);
}

function normalizeSchemaDefinition(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        return {
            ...DEFAULT_SCHEMA,
        };
    }

    const modules = Array.isArray(value.modules)
        ? value.modules
        : [];

    const version = Number(value.version);

    return {
        ...value,
        version:
            Number.isFinite(version) && version >= 1
                ? Math.floor(version)
                : 1,
        modules,
    };
}

function getModuleCodes(modules) {
    return Array.from(
        new Set(
            modules
                .map((module) => normalizeString(module?.code, 80))
                .filter(Boolean),
        ),
    );
}

function countModuleFields(modules) {
    return modules.reduce((total, module) => {
        const explicitCount = Number(module?.fields);

        if (Number.isFinite(explicitCount) && explicitCount >= 0) {
            return total + explicitCount;
        }

        return total;
    }, 0);
}

/* -------------------------------------------------------------------------- */
/* Schema                                                                     */
/* -------------------------------------------------------------------------- */

const surveyTemplateSchema = new Schema(
    {
        /* Human-readable template name shown by the existing admin UI. */
        name: {
            type: String,
            required: [
                true,
                "Survey template name is required.",
            ],
            trim: true,
            minlength: 2,
            maxlength: 255,
            index: true,
        },

        /* Optional description shown in the template list. */
        description: {
            type: String,
            trim: true,
            maxlength: 2000,
            default: "",
        },

        /*
         * Complete builder definition.
         *
         * The existing frontend already models survey structure as:
         *
         *   { version, modules: [...] }
         *
         * Keeping this as Mixed allows the field-builder to evolve without a
         * Mongo migration for every new field type.
         */
        schema: {
            type: Schema.Types.Mixed,
            required: true,
            default: () => ({ ...DEFAULT_SCHEMA }),
        },

        /* Cached module codes for fast filtering/reporting. */
        moduleCodes: {
            type: [
                {
                    type: String,
                    trim: true,
                    maxlength: 80,
                },
            ],
            default: [],
        },

        moduleCount: {
            type: Number,
            min: 0,
            max: 1000,
            default: 0,
        },

        fieldCount: {
            type: Number,
            min: 0,
            max: 100000,
            default: 0,
        },

        /* Template lifecycle controlled by the admin workflow. */
        status: {
            type: String,
            enum: {
                values: SURVEY_TEMPLATE_STATUSES,
                message: "Invalid survey template status.",
            },
            default: "draft",
            index: true,
        },

        /* Builder/schema revision. */
        version: {
            type: Number,
            min: 1,
            max: 1000000,
            default: 1,
        },

        /*
         * Vendor defaults and other future builder metadata belong to the
         * template document rather than the client browser.
         */
        metadata: {
            type: Schema.Types.Mixed,
            default: () => ({}),
        },

        /* Audit identity. */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        archivedAt: {
            type: Date,
            default: null,
        },

        archivedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "survey_templates",
        timestamps: true,
        strict: "throw",
        minimize: false,
        versionKey: false,
    },
);

/* -------------------------------------------------------------------------- */
/* Indexes                                                                    */
/* -------------------------------------------------------------------------- */

surveyTemplateSchema.index(
    {
        name: 1,
        status: 1,
    },
    {
        name: "survey_templates_name_status",
    },
);

surveyTemplateSchema.index(
    {
        status: 1,
        updatedAt: -1,
    },
    {
        name: "survey_templates_status_updated",
    },
);

surveyTemplateSchema.index(
    {
        moduleCodes: 1,
        status: 1,
    },
    {
        name: "survey_templates_module_status",
    },
);

surveyTemplateSchema.index(
    {
        createdBy: 1,
        createdAt: -1,
    },
    {
        name: "survey_templates_creator_created",
    },
);

/* -------------------------------------------------------------------------- */
/* Validation / Normalization                                                 */
/* -------------------------------------------------------------------------- */

/*
 * Mongoose 9 supports promise-based middleware. Avoid callback-style
 * `next()` middleware because it can produce `next is not a function` in
 * current Mongoose installations.
 */
surveyTemplateSchema.pre(
    "validate",
    function normalizeSurveyTemplate() {
        this.name = normalizeString(this.name, 255);
        this.description = normalizeString(this.description, 2000);

        const normalizedSchema = normalizeSchemaDefinition(this.schema);
        const modules = normalizedSchema.modules;

        this.schema = normalizedSchema;
        this.moduleCodes = getModuleCodes(modules);
        this.moduleCount = modules.length;
        this.fieldCount = countModuleFields(modules);
        this.version = normalizedSchema.version;

        if (this.status === "archived") {
            if (!this.archivedAt) {
                this.archivedAt = new Date();
            }
        } else {
            this.archivedAt = null;
            this.archivedBy = null;
        }

        if (!this.metadata || typeof this.metadata !== "object") {
            this.metadata = {};
        }
    },
);

/* -------------------------------------------------------------------------- */
/* Instance helpers                                                           */
/* -------------------------------------------------------------------------- */

surveyTemplateSchema.methods.isActive = function isActive() {
    return this.status === "active";
};

surveyTemplateSchema.methods.isDraft = function isDraft() {
    return this.status === "draft";
};

surveyTemplateSchema.methods.isArchived = function isArchived() {
    return this.status === "archived";
};

surveyTemplateSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        name: this.name,
        description: this.description,
        schema: this.schema,
        moduleCodes: this.moduleCodes,
        moduleCount: this.moduleCount,
        fieldCount: this.fieldCount,
        status: this.status,
        version: this.version,
        metadata: this.metadata || {},
        createdBy: this.createdBy ? String(this.createdBy) : null,
        updatedBy: this.updatedBy ? String(this.updatedBy) : null,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
        archivedAt: this.archivedAt,
        archivedBy: this.archivedBy ? String(this.archivedBy) : null,
    };
};

/* -------------------------------------------------------------------------- */
/* Static helpers                                                             */
/* -------------------------------------------------------------------------- */

surveyTemplateSchema.statics.findActive = function findActive() {
    return this.find({
        status: "active",
    }).sort({
        name: 1,
        updatedAt: -1,
    });
};

surveyTemplateSchema.statics.findByIdActive = function findByIdActive(id) {
    return this.findOne({
        _id: id,
        status: "active",
    });
};

/* -------------------------------------------------------------------------- */
/* JSON serialization                                                         */
/* -------------------------------------------------------------------------- */

surveyTemplateSchema.set("toJSON", {
    virtuals: true,
    transform(_doc, ret) {
        if (ret._id) {
            ret.id = String(ret._id);
        }

        delete ret._id;

        return ret;
    },
});

const SurveyTemplate =
    models.SurveyTemplate ||
    model("SurveyTemplate", surveyTemplateSchema);

export {
    SurveyTemplate,
    surveyTemplateSchema,
};

export default SurveyTemplate;
