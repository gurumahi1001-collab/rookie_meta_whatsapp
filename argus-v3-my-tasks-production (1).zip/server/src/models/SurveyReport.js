import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| ARGUS Survey Report
|--------------------------------------------------------------------------
|
| A SurveyReport is the persisted reporting artifact for a survey response.
| The original survey response remains the source of truth; this document
| stores the generated/reporting metadata, denormalized summary information,
| export information, and the audit-friendly lifecycle state.
|
| Binary report files are not stored in MongoDB. The configured local storage
| layer owns report files; Mongo stores only safe metadata and the relative
| storage reference.
|
| This model is intentionally callback-free so it is compatible with the
| current Mongoose 9 runtime used by ARGUS.
|--------------------------------------------------------------------------
*/

const reportFileSchema = new Schema(
    {
        storageKey: {
            type: String,
            trim: true,
            maxlength: 500,
            default: "",
        },

        relativePath: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },

        originalName: {
            type: String,
            trim: true,
            maxlength: 255,
            default: "",
        },

        mimeType: {
            type: String,
            trim: true,
            lowercase: true,
            maxlength: 180,
            default: "",
        },

        extension: {
            type: String,
            trim: true,
            lowercase: true,
            maxlength: 20,
            default: "",
        },

        size: {
            type: Number,
            min: 0,
            max: 524288000,
            default: 0,
        },

        checksum: {
            type: String,
            trim: true,
            maxlength: 128,
            default: "",
        },

        uploadedAt: {
            type: Date,
            default: null,
        },

        uploadedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        _id: false,
        id: false,
        versionKey: false,
    },
);

const reportSummarySchema = new Schema(
    {
        totalModules: {
            type: Number,
            min: 0,
            max: 10000,
            default: 0,
        },

        completedModules: {
            type: Number,
            min: 0,
            max: 10000,
            default: 0,
        },

        totalFields: {
            type: Number,
            min: 0,
            max: 1000000,
            default: 0,
        },

        answeredFields: {
            type: Number,
            min: 0,
            max: 1000000,
            default: 0,
        },

        defects: {
            type: Number,
            min: 0,
            max: 1000000,
            default: 0,
        },

        criticalDefects: {
            type: Number,
            min: 0,
            max: 1000000,
            default: 0,
        },

        completionPercentage: {
            type: Number,
            min: 0,
            max: 100,
            default: 0,
        },

        riskLevel: {
            type: String,
            enum: ["low", "medium", "high", "critical", ""],
            default: "",
        },
    },
    {
        _id: false,
        id: false,
        versionKey: false,
    },
);

const surveyReportSchema = new Schema(
    {
        reportNumber: {
            type: String,
            trim: true,
            uppercase: true,
            maxlength: 80,
            index: true,
            default: "",
        },

        title: {
            type: String,
            required: [true, "Survey report title is required."],
            trim: true,
            minlength: 2,
            maxlength: 255,
        },

        reportType: {
            type: String,
            enum: [
                "survey",
                "survey_summary",
                "survey_detail",
                "survey_compliance",
            ],
            default: "survey",
            index: true,
        },

        status: {
            type: String,
            enum: ["draft", "generated", "final", "archived", "failed"],
            default: "draft",
            index: true,
        },

        format: {
            type: String,
            enum: ["json", "pdf", "xlsx", "csv"],
            default: "json",
            index: true,
        },

        templateId: {
            type: Schema.Types.ObjectId,
            ref: "SurveyTemplate",
            required: true,
            index: true,
        },

        responseId: {
            type: Schema.Types.ObjectId,
            ref: "SurveyResponse",
            required: true,
            index: true,
        },

        projectId: {
            type: Schema.Types.ObjectId,
            ref: "Project",
            default: null,
            index: true,
        },

        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            default: null,
            index: true,
        },

        generatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },

        approvedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        archivedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        version: {
            type: Number,
            min: 1,
            max: 1000000,
            default: 1,
        },

        summary: {
            type: reportSummarySchema,
            default: () => ({}),
        },

        filters: {
            type: Schema.Types.Mixed,
            default: () => ({}),
        },

        reportData: {
            type: Schema.Types.Mixed,
            default: () => ({}),
        },

        file: {
            type: reportFileSchema,
            default: null,
        },

        errorMessage: {
            type: String,
            trim: true,
            maxlength: 2000,
            default: "",
        },

        generatedAt: {
            type: Date,
            default: null,
            index: true,
        },

        approvedAt: {
            type: Date,
            default: null,
        },

        archivedAt: {
            type: Date,
            default: null,
        },

        metadata: {
            type: Schema.Types.Mixed,
            default: () => ({}),
        },
    },
    {
        collection: "survey_reports",
        timestamps: true,
        strict: "throw",
        minimize: false,
        versionKey: false,
    },
);

surveyReportSchema.index(
    { responseId: 1, version: -1 },
    { name: "survey_reports_response_version" },
);

surveyReportSchema.index(
    { templateId: 1, projectId: 1, createdAt: -1 },
    { name: "survey_reports_template_project_created" },
);

surveyReportSchema.index(
    { status: 1, generatedAt: -1 },
    { name: "survey_reports_status_generated" },
);

surveyReportSchema.index(
    { vendorId: 1, status: 1, createdAt: -1 },
    { name: "survey_reports_vendor_status_created" },
);

surveyReportSchema.index(
    { reportNumber: 1 },
    {
        name: "survey_reports_report_number_unique",
        unique: true,
        partialFilterExpression: {
            reportNumber: {
                $type: "string",
                $ne: "",
            },
        },
    },
);

surveyReportSchema.pre("validate", async function normalizeSurveyReport() {
    this.title = String(this.title || "").trim();
    this.reportNumber = String(this.reportNumber || "").trim().toUpperCase();
    this.errorMessage = String(this.errorMessage || "").trim();

    if (this.summary) {
        const completion = Number(this.summary.completionPercentage);
        this.summary.completionPercentage = Number.isFinite(completion)
            ? Math.min(100, Math.max(0, completion))
            : 0;

        const totalModules = Number(this.summary.totalModules) || 0;
        const completedModules = Number(this.summary.completedModules) || 0;
        const totalFields = Number(this.summary.totalFields) || 0;
        const answeredFields = Number(this.summary.answeredFields) || 0;
        const defects = Number(this.summary.defects) || 0;
        const criticalDefects = Number(this.summary.criticalDefects) || 0;

        this.summary.totalModules = Math.max(0, totalModules);
        this.summary.completedModules = Math.min(
            this.summary.totalModules,
            Math.max(0, completedModules),
        );
        this.summary.totalFields = Math.max(0, totalFields);
        this.summary.answeredFields = Math.min(
            this.summary.totalFields,
            Math.max(0, answeredFields),
        );
        this.summary.defects = Math.max(0, defects);
        this.summary.criticalDefects = Math.min(
            this.summary.defects,
            Math.max(0, criticalDefects),
        );
    }

    if (this.status === "generated" && !this.generatedAt) {
        this.generatedAt = new Date();
    }

    if (this.status === "final" && !this.approvedAt) {
        this.approvedAt = new Date();
    }

    if (this.status === "archived" && !this.archivedAt) {
        this.archivedAt = new Date();
    }
});

surveyReportSchema.virtual("id").get(function id() {
    return String(this._id);
});

surveyReportSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        reportNumber: this.reportNumber,
        title: this.title,
        reportType: this.reportType,
        status: this.status,
        format: this.format,
        templateId: this.templateId ? String(this.templateId) : null,
        responseId: this.responseId ? String(this.responseId) : null,
        projectId: this.projectId ? String(this.projectId) : null,
        vendorId: this.vendorId ? String(this.vendorId) : null,
        generatedBy: this.generatedBy ? String(this.generatedBy) : null,
        approvedBy: this.approvedBy ? String(this.approvedBy) : null,
        archivedBy: this.archivedBy ? String(this.archivedBy) : null,
        version: this.version,
        summary: this.summary || {},
        filters: this.filters || {},
        reportData: this.reportData || {},
        file: this.file || null,
        errorMessage: this.errorMessage,
        generatedAt: this.generatedAt,
        approvedAt: this.approvedAt,
        archivedAt: this.archivedAt,
        metadata: this.metadata || {},
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

surveyReportSchema.set("toJSON", {
    virtuals: true,
});

const SurveyReport =
    models.SurveyReport ||
    model("SurveyReport", surveyReportSchema);

export {
    SurveyReport,
    reportFileSchema,
    reportSummarySchema,
    surveyReportSchema,
};

export default SurveyReport;
