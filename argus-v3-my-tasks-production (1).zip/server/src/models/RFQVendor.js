import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const rfqVendorSchema = new Schema(
  {
    rfqId: { type: Schema.Types.ObjectId, ref: "RFQ", required: true, index: true },
    vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true, index: true },
    vendorName: { type: String, required: true, trim: true, maxlength: 200 },
    email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
    status: { type: String, enum: ["pending", "invited", "submitted", "declined"], default: "pending", index: true },
    invitedAt: { type: Date, default: null },
    respondedAt: { type: Date, default: null },
    submittedQuotationId: { type: Schema.Types.ObjectId, ref: "Quotation", default: null },
  },
  { collection: "rfq_vendors", timestamps: true, strict: "throw", versionKey: false },
);

rfqVendorSchema.index({ rfqId: 1, vendorId: 1 }, { unique: true, name: "rfq_vendors_unique" });
rfqVendorSchema.index({ vendorId: 1, status: 1, createdAt: -1 });

export default models.RFQVendor || model("RFQVendor", rfqVendorSchema);
