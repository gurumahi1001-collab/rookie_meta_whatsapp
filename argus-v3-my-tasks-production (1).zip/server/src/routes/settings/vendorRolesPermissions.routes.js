// src/routes/settings/vendorRolesPermissions.routes.js

import { Router } from "express";

import authenticate, {
    requireVendorUser,
} from "../../middleware/auth.js";

import authorize from "../../middleware/rbac.js";
import { requireVendorTermsAcceptedMiddleware } from "../../middleware/vendorTerms.js";

import * as vendorRolesPermissionsController from "../../controllers/settings/vendorRolesPermissionsController.js";


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Common middleware                                                           */
/* -------------------------------------------------------------------------- */

const vendorRolesPermissionView = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    authorize({
        module: "roles_permissions",
        action: "view",
        realms: ["vendor"],
        userTypes: ["vendor"],
        allowSuperAdmin: false,
    }),
];

const vendorRolesPermissionAdd = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    authorize({
        module: "roles_permissions",
        action: "add",
        realms: ["vendor"],
        userTypes: ["vendor"],
        allowSuperAdmin: false,
    }),
];

const vendorRolesPermissionEdit = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    authorize({
        module: "roles_permissions",
        action: "edit",
        realms: ["vendor"],
        userTypes: ["vendor"],
        allowSuperAdmin: false,
    }),
];

const vendorRolesPermissionDelete = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    authorize({
        module: "roles_permissions",
        action: "delete",
        realms: ["vendor"],
        userTypes: ["vendor"],
        allowSuperAdmin: false,
    }),
];


/* -------------------------------------------------------------------------- */
/* Role collection / permission catalog                                      */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/settings/roles
 */
router.get(
    "/roles",
    ...vendorRolesPermissionView,
    vendorRolesPermissionsController.list,
);


/**
 * GET /api/v1/vendor-portal/settings/roles/permissions
 *
 * Keep this route before /roles/:roleId so "permissions" is never treated
 * as a role identifier.
 */
router.get(
    "/roles/permissions",
    ...vendorRolesPermissionView,
    vendorRolesPermissionsController.permissions,
);


/* -------------------------------------------------------------------------- */
/* Role permission matrix                                                     */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/settings/roles/:roleId/permissions
 */
router.get(
    "/roles/:roleId/permissions",
    ...vendorRolesPermissionView,
    vendorRolesPermissionsController.matrix,
);


/**
 * PUT /api/v1/vendor-portal/settings/roles/:roleId/permissions
 */
router.put(
    "/roles/:roleId/permissions",
    ...vendorRolesPermissionEdit,
    vendorRolesPermissionsController.replacePermissions,
);


/**
 * PATCH /api/v1/vendor-portal/settings/roles/:roleId/permissions/:permissionId
 */
router.patch(
    "/roles/:roleId/permissions/:permissionId",
    ...vendorRolesPermissionEdit,
    vendorRolesPermissionsController.updatePermission,
);


/* -------------------------------------------------------------------------- */
/* Role detail / CRUD                                                         */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/settings/roles/:roleId
 */
router.get(
    "/roles/:roleId",
    ...vendorRolesPermissionView,
    vendorRolesPermissionsController.get,
);


/**
 * POST /api/v1/vendor-portal/settings/roles
 */
router.post(
    "/roles",
    ...vendorRolesPermissionAdd,
    vendorRolesPermissionsController.create,
);


/**
 * PATCH /api/v1/vendor-portal/settings/roles/:roleId
 */
router.patch(
    "/roles/:roleId",
    ...vendorRolesPermissionEdit,
    vendorRolesPermissionsController.update,
);


/**
 * DELETE /api/v1/vendor-portal/settings/roles/:roleId
 */
router.delete(
    "/roles/:roleId",
    ...vendorRolesPermissionDelete,
    vendorRolesPermissionsController.remove,
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;
