import { Router } from "express";
import authenticate, { requireInternalUser } from "../middleware/auth.js";
import authorize from "../middleware/rbac.js";
import projectController from "../controllers/project/projectController.js";
import projectProgressController from "../controllers/project/projectProgressController.js";

const router = Router();
router.use(authenticate, requireInternalUser);

const canView = authorize({ module: "project", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canAdd = authorize({ module: "project", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canEdit = authorize({ module: "project", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canDelete = authorize({ module: "project", action: "delete", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });

router.get("/", canView, projectController.list);
router.get("/assignees", canView, projectController.assignees);
router.post("/", canAdd, projectController.create);
router.get("/:id/progress", canView, projectProgressController.get);
router.patch("/:id/progress", canEdit, projectProgressController.update);
router.post("/:id/activity", canEdit, projectProgressController.activity);
router.get("/:id", canView, projectController.get);
router.patch("/:id", canEdit, projectController.update);
router.delete("/:id", canDelete, projectController.remove);

export default router;
