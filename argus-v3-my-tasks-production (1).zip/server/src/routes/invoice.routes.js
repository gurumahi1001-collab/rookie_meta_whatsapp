import { Router } from "express";
import authenticate, { requireInternalUser } from "../middleware/auth.js";
import authorize from "../middleware/rbac.js";
import { upload } from "../middleware/upload.js";
import invoiceController from "../controllers/invoice/invoiceController.js";

const router = Router();
router.use(authenticate, requireInternalUser);

const canView = authorize({ module: "invoice", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canAdd = authorize({ module: "invoice", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canEdit = authorize({ module: "invoice", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canDelete = authorize({ module: "invoice", action: "delete", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });

router.get("/eligible-quotations", canView, invoiceController.eligibleQuotations);
router.get("/", canView, invoiceController.list);
router.post("/", canAdd, invoiceController.create);
router.get("/:id", canView, invoiceController.get);
router.patch("/:id", canEdit, invoiceController.update);
router.post("/:id/submit", canEdit, invoiceController.submit);
router.post("/:id/approve", canEdit, invoiceController.approve);
router.post("/:id/reject", canEdit, invoiceController.reject);
router.post("/:id/mark-paid", canEdit, upload.array("paymentProof", 10), invoiceController.markPaid);
router.post("/:id/document", canEdit, upload.single("invoiceAttachment"), invoiceController.uploadDocument);
router.delete("/:id", canDelete, invoiceController.remove);

export default router;
