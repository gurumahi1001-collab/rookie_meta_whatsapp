// src/routes/index.js

import { Router } from 'express';


/* -------------------------------------------------------------------------- */
/* Route Imports                                                              */
/* -------------------------------------------------------------------------- */

import vendorRoutes from './vendor.routes.js';
import vendorDashboardRoutes from './vendorDashboard.routes.js';
import vendorPortalRoutes from './vendorPortal.routes.js';
import masterRateRoutes from './masterRate.routes.js';
import boqRoutes from './boq.routes.js';
import rfqRoutes from './rfq.routes.js';
import quotationRoutes from './quotation.routes.js';
import commercialRoutes from './commercial.routes.js';
import projectRoutes from './project.routes.js';
import taskRoutes from './task.routes.js';
import budgetRoutes from './budget.routes.js';
import invoiceRoutes from './invoice.routes.js';
import paymentRoutes from './payment.routes.js';
import dashboardRoutes from './dashboard.routes.js';
import reportsRoutes from './reports.routes.js';
import settingsRoutes from './settings.routes.js';
import userRoutes from './user.routes.js';
import auditRoutes from './audit.routes.js';
import surveyRoutes from './survey.routes.js';
import authRoutes from './auth.routes.js';
import notificationRoutes from './notification.routes.js';
import vendorRolesPermissionsRoutes from './settings/vendorRolesPermissions.routes.js';
import vendorUserRoutes from './vendorUser.routes.js';
import vendorAuditLogRoutes from './vendorAuditLog.routes.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router =
  Router();



/* -------------------------------------------------------------------------- */
/* Authentication                                                             */
/* -------------------------------------------------------------------------- */

router.use(
  '/auth',
  authRoutes,
);

/* Notifications for authenticated internal/admin users. */
router.use(
  '/notifications',
  notificationRoutes,
);

/* -------------------------------------------------------------------------- */
/* Core Application Routes                                                    */
/* -------------------------------------------------------------------------- */

router.use(
  '/vendor-portal',
  vendorPortalRoutes,
);

router.use(
  '/vendor-portal',
  vendorDashboardRoutes,
);

/* -------------------------------------------------------------------------- */
/* Vendor Settings                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Vendor Roles & Permissions
 *
 * /api/v1/vendor-portal/settings/roles/*
 *
 * Kept separate from the internal/admin /settings router.
 */
router.use(
  '/vendor-portal/settings',
  vendorRolesPermissionsRoutes,
);

/**
 * Vendor Management
 *
 * /api/vendors/*
 */
router.use(
  '/vendors',
  vendorRoutes,
);


/**
 * Master Rate Management
 *
 * /api/master-rates/*
 */
router.use(
  '/master-rates',
  masterRateRoutes,
);


/**
 * BOQ Management
 *
 * /api/boqs/*
 */
router.use(
  '/boqs',
  boqRoutes,
);


/**
 * RFQ Management
 *
 * /api/rfqs/*
 */
router.use(
  '/rfqs',
  rfqRoutes,
);


/**
 * Quotation Management
 *
 * /api/quotations/*
 */
router.use(
  '/quotations',
  quotationRoutes,
);


/**
 * Commercial Comparison / Approval
 *
 * /api/commercial/*
 */
router.use(
  '/commercial',
  commercialRoutes,
);


/**
 * Project Management
 *
 * /api/projects/*
 */
router.use(
  '/projects',
  projectRoutes,
);


/**
 * Task Management
 *
 * /api/tasks/*
 */
router.use(
  '/tasks',
  taskRoutes,
);


/**
 * Budget Management
 *
 * /api/budgets/*
 */
router.use(
  '/budgets',
  budgetRoutes,
);


/**
 * Invoice Management
 *
 * /api/invoices/*
 */
router.use(
  '/invoices',
  invoiceRoutes,
);


/**
 * Payment Management
 *
 * /api/payments/*
 */
router.use(
  '/payments',
  paymentRoutes,
);


/**
 * Dashboard
 *
 * /api/dashboard/*
 */
router.use(
  '/dashboard',
  dashboardRoutes,
);


/**
 * Reports
 *
 * /api/reports/*
 */
router.use(
  '/reports',
  reportsRoutes,
);


/* -------------------------------------------------------------------------- */
/* Settings                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Settings
 *
 * /api/settings/*
 *
 * Includes:
 *
 * - Company Information
 * - Roles & Permissions
 * - API Configuration
 * - Common Settings
 * - Vendor Settings
 * - Master Rate Settings
 */
router.use(
  '/settings',
  settingsRoutes,
);


/* -------------------------------------------------------------------------- */
/* User Management                                                            */
/* -------------------------------------------------------------------------- */

/**
 * User Management
 *
 * /api/users/*
 */
/* -------------------------------------------------------------------------- */
/* Vendor User Management                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Vendor User Management
 *
 * /api/v1/vendor-portal/users/*
 *
 * Completely separate from the internal/admin /users router.
 */
router.use(
  '/vendor-portal/users',
  vendorUserRoutes,
);

/**
 * Vendor User Activity / Audit Logs
 *
 * /api/v1/vendor-portal/audit/*
 *
 * Kept separate from the internal/admin /audit router. The mounted
 * vendor router enforces vendor authentication, tenant scope, terms,
 * and the existing user_management:view permission.
 */
router.use(
  '/vendor-portal/audit',
  vendorAuditLogRoutes,
);

router.use(
  '/users',
  userRoutes,
);


/* -------------------------------------------------------------------------- */
/* Audit                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Audit Logs
 *
 * /api/audit/*
 */
router.use(
  '/audit',
  auditRoutes,
);


/* -------------------------------------------------------------------------- */
/* Survey                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Survey / Survey Reports
 *
 * /api/surveys/*
 */
router.use(
  '/surveys',
  surveyRoutes,
);


/* -------------------------------------------------------------------------- */
/* API Root Information                                                       */
/* -------------------------------------------------------------------------- */

/**
 * GET /api
 *
 * Lightweight route registry response.
 *
 * This is intentionally public and contains no
 * implementation details or permission information.
 */
router.get(
  '/',
  (_req, res) => {
    res.json({
      success: true,

      service:
        'argus-backend',

      status:
        'ok',

      message:
        'ARGUS API is running.',

      routes: {
        vendors:
          '/vendors',

        masterRates:
          '/master-rates',

        boqs:
          '/boqs',

        rfqs:
          '/rfqs',

        quotations:
          '/quotations',

        commercial:
          '/commercial',

        projects:
          '/projects',

        tasks:
          '/tasks',

        budgets:
          '/budgets',

        invoices:
          '/invoices',

        payments:
          '/payments',

        dashboard:
          '/dashboard',

        reports:
          '/reports',

        settings:
          '/settings',

        users:
          '/users',

        vendorUsers:
          '/vendor-portal/users',

        vendorRolesPermissions:
          '/vendor-portal/settings/roles',

        vendorAudit:
          '/vendor-portal/audit',

        audit:
          '/audit',

        surveys:
          '/surveys',
      },
    });
  },
);

 
/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;