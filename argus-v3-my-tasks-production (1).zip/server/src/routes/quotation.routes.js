import { Router } from "express";
import authenticate, { requireInternalUser } from "../middleware/auth.js";
import authorize from "../middleware/rbac.js";
import quotationController from "../controllers/quotation/quotationController.js";

const router = Router();
router.use(authenticate, requireInternalUser);

const canView = authorize({ module: "quotation", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canAdd = authorize({ module: "quotation", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canEdit = authorize({ module: "quotation", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canDelete = authorize({ module: "quotation", action: "delete", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });

router.get("/", canView, quotationController.list);
router.post("/", canAdd, quotationController.create);
router.get("/:id", canView, quotationController.get);
router.patch("/:id", canEdit, quotationController.update);
router.post("/:id/submit", canEdit, quotationController.submit);
router.post("/:id/approve", canEdit, quotationController.approve);
router.post("/:id/reject", canEdit, quotationController.reject);
router.post("/:id/award", canEdit, quotationController.award);
router.delete("/:id", canDelete, quotationController.remove);

export default router;
