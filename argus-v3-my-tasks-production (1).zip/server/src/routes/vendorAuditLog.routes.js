// src/routes/vendorAuditLog.routes.js

import { Router } from "express";

import authenticate, {
    requireVendorUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";
import {
    requireVendorTermsAcceptedMiddleware,
} from "../middleware/vendorTerms.js";

import vendorAuditLogController from "../controllers/audit/vendorAuditLogController.js";


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Vendor User Activity Log access                                            */
/* -------------------------------------------------------------------------- */

/**
 * The Vendor User Log is part of Vendor User Management.
 *
 * We intentionally use the existing `user_management:view` permission so
 * the Vendor Roles & Permissions matrix does not need an additional module
 * merely for opening a user's activity drawer.
 *
 * Tenant isolation is enforced by the controller/service from the
 * authenticated vendor scope. No vendorId is accepted from the URL/query.
 */
const vendorUserLogViewAccess = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
    authorize({
        module: "user_management",
        action: "view",
        realms: ["vendor"],
        userTypes: ["vendor"],
        allowSuperAdmin: false,
    }),
];


/* -------------------------------------------------------------------------- */
/* LIST VENDOR AUDIT LOGS                                                     */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/audit
 *
 * Query parameters supported by the controller:
 *   page
 *   limit
 *   search
 *   action
 *   module
 *   actorUserId / userId
 *   entityType
 *   entityId
 *   status
 *   fromDate / startDate
 *   toDate / endDate
 *
 * The controller always resolves vendorId from req.user.
 */
router.get(
    "/",
    ...vendorUserLogViewAccess,
    vendorAuditLogController.list,
);


/* -------------------------------------------------------------------------- */
/* GET SINGLE VENDOR AUDIT ENTRY                                              */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/audit/:id
 *
 * The controller verifies that the requested audit record belongs to the
 * authenticated vendor before returning the record. This prevents a user
 * from reading another vendor's activity by guessing an ObjectId.
 */
router.get(
    "/:id",
    ...vendorUserLogViewAccess,
    vendorAuditLogController.get,
);


/* -------------------------------------------------------------------------- */
/* No browser write endpoints                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Audit history is append-only.
 *
 * POST / PUT / PATCH / DELETE are deliberately not exposed. Audit events
 * must be created by trusted backend application services only.
 */


export default router;
