import { Router } from "express";

import authenticate, { requireInternalUser } from "../middleware/auth.js";
import authorize from "../middleware/rbac.js";
import boqController from "../controllers/boq/boqController.js";

const router = Router();

router.use(authenticate);
router.use(requireInternalUser);

const canView = authorize({
    module: "boq",
    action: "view",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canAdd = authorize({
    module: "boq",
    action: "add",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canEdit = authorize({
    module: "boq",
    action: "edit",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canDelete = authorize({
    module: "boq",
    action: "delete",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

router.get("/", canView, boqController.list);
router.post("/", canAdd, boqController.create);
router.get("/:id", canView, boqController.get);
router.patch("/:id", canEdit, boqController.update);
router.patch("/:id/lock", canEdit, boqController.lock);
router.delete("/:id", canDelete, boqController.remove);

export default router;
