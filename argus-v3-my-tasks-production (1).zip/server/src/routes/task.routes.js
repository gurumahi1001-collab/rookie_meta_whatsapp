import { Router } from "express";
import authenticate, { requireInternalUser } from "../middleware/auth.js";
import authorize from "../middleware/rbac.js";
import taskController from "../controllers/task/taskController.js";

const router = Router();
router.use(authenticate, requireInternalUser);
const canView=authorize({module:"task",action:"view",realms:["admin","internal"],userTypes:["admin","internal"]});
const canAdd=authorize({module:"task",action:"add",realms:["admin","internal"],userTypes:["admin","internal"]});
const canEdit=authorize({module:"task",action:"edit",realms:["admin","internal"],userTypes:["admin","internal"]});
const canDelete=authorize({module:"task",action:"delete",realms:["admin","internal"],userTypes:["admin","internal"]});
router.get("/",canView,taskController.list);
router.get("/assignees",canView,taskController.assignees);
router.get("/projects",canView,taskController.projects);
router.post("/",canAdd,taskController.create);
router.get("/:id",canView,taskController.get);
router.patch("/:id",canEdit,taskController.update);
router.delete("/:id",canDelete,taskController.remove);
export default router;
