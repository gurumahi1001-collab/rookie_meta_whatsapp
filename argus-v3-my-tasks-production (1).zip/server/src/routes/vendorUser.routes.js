// src/routes/vendorUser.routes.js

import { Router } from "express";

import authenticate, {
    requireVendorUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";
import { profileImageUpload } from "../middleware/upload.js";
import { requireVendorTermsAcceptedMiddleware } from "../middleware/vendorTerms.js";

import vendorUserManagementController from "../controllers/user/vendorUserManagementController.js";


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Vendor User Management RBAC                                                */
/* -------------------------------------------------------------------------- */

/**
 * Vendor User Management uses the same permission key as the Admin UI,
 * but the middleware additionally restricts access to vendor users.
 *
 * The authenticated vendorId is NEVER taken from query/body data. It is
 * resolved later by the controller/service from the authenticated session.
 */

const canViewUsers = authorize({
    module: "user_management",
    action: "view",
    realms: ["vendor"],
    userTypes: ["vendor"],
});

const canAddUsers = authorize({
    module: "user_management",
    action: "add",
    realms: ["vendor"],
    userTypes: ["vendor"],
});

const canEditUsers = authorize({
    module: "user_management",
    action: "edit",
    realms: ["vendor"],
    userTypes: ["vendor"],
});


/* -------------------------------------------------------------------------- */
/* Common vendor guard                                                        */
/* -------------------------------------------------------------------------- */

const requireVendorManagementAccess = [
    authenticate,
    requireVendorUser,
    requireVendorTermsAcceptedMiddleware,
];


/* -------------------------------------------------------------------------- */
/* LIST USERS                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/users
 *
 * Supported query parameters:
 *   search=
 *   roleId=
 *   status=
 *   page=
 *   limit=
 */
router.get(
    "/",
    ...requireVendorManagementAccess,
    canViewUsers,
    vendorUserManagementController.list,
);


/* -------------------------------------------------------------------------- */
/* ASSIGNABLE ROLES                                                           */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/users/roles
 *
 * Must appear before /:id.
 */
router.get(
    "/roles",
    ...requireVendorManagementAccess,
    canViewUsers,
    vendorUserManagementController.listAssignableRoles,
);


/* -------------------------------------------------------------------------- */
/* CHECK EMAIL                                                                */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/users/check-email?email=...
 *
 * Must appear before /:id.
 */
router.get(
    "/check-email",
    ...requireVendorManagementAccess,
    canViewUsers,
    vendorUserManagementController.checkEmail,
);


/* -------------------------------------------------------------------------- */
/* BULK STATUS                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/vendor-portal/users/bulk-status
 *
 * Must appear before /:id.
 */
router.patch(
    "/bulk-status",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.bulkUpdateStatus,
);


/* -------------------------------------------------------------------------- */
/* CREATE USER                                                                */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/vendor-portal/users
 */
router.post(
    "/",
    ...requireVendorManagementAccess,
    canAddUsers,
    vendorUserManagementController.create,
);


/* -------------------------------------------------------------------------- */
/* PROFILE IMAGE                                                              */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/users/:id/avatar
 */
router.get(
    "/:id/avatar",
    ...requireVendorManagementAccess,
    canViewUsers,
    vendorUserManagementController.getProfileImage,
);

/**
 * POST /api/v1/vendor-portal/users/:id/avatar
 */
router.post(
    "/:id/avatar",
    ...requireVendorManagementAccess,
    canEditUsers,
    profileImageUpload,
    vendorUserManagementController.uploadProfileImage,
);

/**
 * DELETE /api/v1/vendor-portal/users/:id/avatar
 */
router.delete(
    "/:id/avatar",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.removeProfileImage,
);


/* -------------------------------------------------------------------------- */
/* GET USER                                                                   */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/vendor-portal/users/:id
 */
router.get(
    "/:id",
    ...requireVendorManagementAccess,
    canViewUsers,
    vendorUserManagementController.get,
);


/* -------------------------------------------------------------------------- */
/* UPDATE USER                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/vendor-portal/users/:id
 */
router.patch(
    "/:id",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.update,
);


/* -------------------------------------------------------------------------- */
/* UPDATE USER STATUS                                                         */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/vendor-portal/users/:id/status
 */
router.patch(
    "/:id/status",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.updateStatus,
);


/* -------------------------------------------------------------------------- */
/* RESET PASSWORD                                                             */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/vendor-portal/users/:id/password
 */
router.patch(
    "/:id/password",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.resetPassword,
);


/* -------------------------------------------------------------------------- */
/* ASSIGN ROLE                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/vendor-portal/users/:id/role
 */
router.patch(
    "/:id/role",
    ...requireVendorManagementAccess,
    canEditUsers,
    vendorUserManagementController.assignRole,
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;
