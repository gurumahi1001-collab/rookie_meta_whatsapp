import { Router } from "express";

import authenticate, {
    requireInternalUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";

import * as surveyTemplateController from "../controllers/survey/surveyTemplateController.js";
import * as surveyResponseController from "../controllers/survey/surveyResponseController.js";
import * as surveyReportController from "../controllers/survey/surveyReportController.js";

const router = Router();

/* -------------------------------------------------------------------------- */
/* Authentication / scope                                                    */
/* -------------------------------------------------------------------------- */

/*
 * Survey Report is an internal/admin module. Keep authentication and the
 * internal-user guard at router scope so a newly added endpoint cannot
 * accidentally bypass them.
 */
router.use(authenticate);
router.use(requireInternalUser);

/* -------------------------------------------------------------------------- */
/* RBAC                                                                       */
/* -------------------------------------------------------------------------- */

const canViewSurvey = authorize({
    module: "survey_report",
    action: "view",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canAddSurvey = authorize({
    module: "survey_report",
    action: "add",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canEditSurvey = authorize({
    module: "survey_report",
    action: "edit",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

const canDeleteSurvey = authorize({
    module: "survey_report",
    action: "delete",
    realms: ["admin", "internal"],
    userTypes: ["admin", "internal"],
});

/* -------------------------------------------------------------------------- */
/* Survey templates                                                           */
/* -------------------------------------------------------------------------- */

/*
 * Register static collection paths before /:id. This avoids treating
 * "templates" as a MongoDB document id in a future generic route.
 */
router.get(
    "/templates",
    canViewSurvey,
    surveyTemplateController.list,
);

router.post(
    "/templates",
    canAddSurvey,
    surveyTemplateController.create,
);

router.get(
    "/templates/:id",
    canViewSurvey,
    surveyTemplateController.get,
);

router.patch(
    "/templates/:id",
    canEditSurvey,
    surveyTemplateController.update,
);

router.delete(
    "/templates/:id",
    canDeleteSurvey,
    surveyTemplateController.remove,
);

/* -------------------------------------------------------------------------- */
/* Survey responses                                                           */
/* -------------------------------------------------------------------------- */

router.get(
    "/responses",
    canViewSurvey,
    surveyResponseController.list,
);

router.post(
    "/responses",
    canAddSurvey,
    surveyResponseController.create,
);

router.get(
    "/responses/:id",
    canViewSurvey,
    surveyResponseController.get,
);

router.patch(
    "/responses/:id",
    canEditSurvey,
    surveyResponseController.update,
);

router.delete(
    "/responses/:id",
    canDeleteSurvey,
    surveyResponseController.remove,
);

/* -------------------------------------------------------------------------- */
/* Survey reports                                                             */
/* -------------------------------------------------------------------------- */

router.get(
    "/reports",
    canViewSurvey,
    surveyReportController.list,
);

router.post(
    "/reports",
    canAddSurvey,
    surveyReportController.create,
);

router.get(
    "/reports/:id",
    canViewSurvey,
    surveyReportController.get,
);

router.patch(
    "/reports/:id",
    canEditSurvey,
    surveyReportController.update,
);

router.delete(
    "/reports/:id",
    canDeleteSurvey,
    surveyReportController.remove,
);

/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;
