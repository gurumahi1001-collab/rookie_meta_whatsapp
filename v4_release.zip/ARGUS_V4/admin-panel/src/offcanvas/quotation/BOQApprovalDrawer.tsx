import { useEffect, useMemo, useState } from "react";
import { CheckCircleIcon, FileMagnifyingGlassIcon, FloppyDiskIcon, TrophyIcon, XCircleIcon } from "@phosphor-icons/react";
import type { BOQRecord } from "../../types/boq";
import type { BOQApproval } from "../../api/procurementWorkflowApi";
import { awardBOQVendor, checkMasterRate, getBOQApproval, reviewSurvey } from "../../api/procurementWorkflowApi";

type Props = { isOpen: boolean; boq: BOQRecord | null; onClose: () => void; onChanged?: () => void };

const money = (value: number, currency: string) => `${currency} ${Number(value || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const statusClass = (status: string) => {
  if (["approved", "awarded", "submitted"].includes(status)) return "bg-emerald-50 text-emerald-700";
  if (["form_submitted", "draft", "issued"].includes(status)) return "bg-amber-50 text-amber-700";
  if (["rejected", "not_awarded"].includes(status)) return "bg-red-50 text-red-700";
  return "bg-slate-100 text-slate-600";
};

export default function BOQApprovalDrawer({ isOpen, boq, onClose, onChanged }: Props) {
  const [data, setData] = useState<BOQApproval | null>(null);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState("");
  const [message, setMessage] = useState("");
  const [awardId, setAwardId] = useState("");
  const [remarks, setRemarks] = useState("");

  const load = async () => {
    if (!boq) return;
    setLoading(true);
    setMessage("");
    try { setData(await getBOQApproval(boq.id)); } catch (e) { setMessage(e instanceof Error ? e.message : "Unable to load BOQ approval."); }
    finally { setLoading(false); }
  };
  useEffect(() => { if (isOpen && boq) void load(); else { setData(null); setAwardId(""); setRemarks(""); } }, [isOpen, boq?.id]);

  const eligible = data?.eligibleToAward || [];
  const selected = eligible.find((v) => v.quotationId === awardId) || null;
  const canAward = Boolean(data?.canAward && selected);
  const allSurveyReviewable = data?.quotations.filter((q) => q.surveyStatus === "submitted") || [];

  const run = async (id: string, action: () => Promise<unknown>, success: string) => {
    setBusyId(id); setMessage("");
    try { await action(); setMessage(success); await load(); onChanged?.(); }
    catch (e) { setMessage(e instanceof Error ? e.message : "Action failed."); }
    finally { setBusyId(""); }
  };

  const award = async () => {
    if (!boq || !awardId || !remarks.trim()) { setMessage("Select a vendor and enter award remarks."); return; }
    await run("award", () => awardBOQVendor(boq.id, awardId, remarks.trim()), "Vendor awarded. Project creation is complete.");
  };

  if (!isOpen || !boq) return null;
  return <div className="fixed inset-0 z-[9999] flex justify-end bg-slate-950/30 backdrop-blur-[1px]">
    <button type="button" className="absolute inset-0 cursor-default" aria-label="Close BOQ approval" onClick={onClose} />
    <aside className="relative z-10 flex h-full w-full max-w-6xl flex-col bg-white shadow-2xl">
      <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
        <div><div className="flex items-center gap-2"><h2 className="text-sm font-bold text-slate-900">{boq.reference} — BOQ Approval</h2><span className="rounded-full bg-blue-50 px-2 py-0.5 text-[9px] font-bold text-blue-700">{data?.boq.statusLabel || boq.status}</span></div><p className="mt-1 text-[10px] text-slate-400">{boq.title} · vendor survey, quotation and award review</p></div>
        <button type="button" onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-slate-400 hover:bg-slate-100"><XCircleIcon size={18} /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">
        {message && <div className="mb-4 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-xs font-semibold text-blue-700">{message}</div>}
        {loading ? <div className="rounded-xl border border-slate-200 bg-slate-50 p-10 text-center text-xs font-semibold text-slate-500">Loading approval details…</div> : data ? <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
            {[["Vendors", data.counts.selectedVendors], ["Survey Pending", data.counts.surveyPending], ["Quote Issued", data.counts.quoteIssued], ["Submitted", data.counts.submitted], ["Rejected", data.counts.rejected]].map(([label,value]) => <div key={String(label)} className="rounded-xl border border-slate-200 bg-slate-50 p-3"><p className="text-[8px] font-bold uppercase tracking-wide text-slate-400">{label}</p><p className="mt-1 text-sm font-black text-slate-900">{value}</p></div>)}
          </div>
          <section className="mt-5 overflow-hidden rounded-xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3"><div><p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Vendor Responses</p><p className="mt-0.5 text-[10px] text-slate-500">Review the dynamic form first, then verify vendor prices against the Master Rate Schedule.</p></div><FileMagnifyingGlassIcon size={18} className="text-red-500" /></div>
            <div className="overflow-x-auto"><table className="w-full min-w-[1000px]"><thead><tr className="border-b border-slate-200">{["Vendor","Quote","Survey","Master Rate","Vendor Quote","Variance","Actions"].map(h => <th key={h} className="px-3 py-2 text-left text-[8px] font-bold uppercase tracking-wide text-slate-400">{h}</th>)}</tr></thead>
            <tbody>{data.quotations.map((q) => <tr key={q.quotationId} className="border-b border-slate-100 last:border-0">
              <td className="px-3 py-3"><p className="text-[11px] font-bold text-slate-800">{q.vendorName}</p><p className="text-[9px] text-slate-400">{q.quotationNo}</p></td>
              <td className="px-3 py-3"><span className={`rounded-full px-2 py-1 text-[9px] font-bold ${statusClass(q.status)}`}>{q.statusLabel}</span></td>
              <td className="px-3 py-3 text-[10px] font-semibold text-slate-600">{q.surveyStatus ? q.surveyStatus.replace(/_/g," ") : "—"}{q.rejectionReason ? <p className="mt-1 max-w-[180px] text-[9px] text-red-500">{q.rejectionReason}</p> : null}</td>
              <td className="px-3 py-3 text-[10px] font-semibold text-slate-700">{money(q.masterRateTotal,q.currency)}</td>
              <td className="px-3 py-3 text-[10px] font-semibold text-slate-700">{money(q.vendorQuotedTotal,q.currency)}</td>
              <td className={`px-3 py-3 text-[10px] font-bold ${q.variance > 0 ? "text-red-600" : "text-emerald-600"}`}>{money(q.variance,q.currency)}<br/><span className="text-[8px] font-semibold">{q.variancePercentage.toFixed(2)}%</span></td>
              <td className="px-3 py-3"><div className="flex flex-wrap gap-1">
                {q.surveyStatus === "submitted" && <><button type="button" disabled={busyId===q.quotationId} onClick={() => void run(q.quotationId, () => reviewSurvey(q.quotationId,true), "Survey approved. Vendor quotation is now open.")} className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-1.5 text-[9px] font-bold text-white disabled:opacity-50"><CheckCircleIcon size={12}/>Approve</button><button type="button" disabled={busyId===q.quotationId} onClick={() => { const reason=window.prompt("Enter survey rejection reason:"); if (reason?.trim()) void run(q.quotationId, () => reviewSurvey(q.quotationId,false,reason.trim()), "Survey rejected."); }} className="inline-flex items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2 py-1.5 text-[9px] font-bold text-red-700 disabled:opacity-50"><XCircleIcon size={12}/>Reject</button></>}
                {["submitted","approved"].includes(q.status) && <button type="button" disabled={busyId===q.quotationId} onClick={() => void run(q.quotationId, () => checkMasterRate(q.quotationId), "Master Rate comparison saved.")} className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1.5 text-[9px] font-bold text-slate-700 disabled:opacity-50"><FileMagnifyingGlassIcon size={12}/>Check Rate</button>}
              </div></td>
            </tr>)}</tbody></table></div>
          </section>
          <section className="mt-5 rounded-xl border border-slate-200 p-4">
            <div className="flex items-start gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-600"><TrophyIcon size={18}/></div><div><h3 className="text-xs font-black text-slate-900">Vendor Awarding</h3><p className="mt-0.5 text-[10px] text-slate-500">Select one submitted vendor after all selected vendors have reached a final decision.</p></div></div>
            <div className="mt-4 grid gap-3 md:grid-cols-[1fr_1.4fr_auto] md:items-end"><label className="block"><span className="mb-1 block text-[9px] font-bold uppercase tracking-wide text-slate-400">Award Vendor</span><select value={awardId} onChange={e=>setAwardId(e.target.value)} className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700"><option value="">Select vendor…</option>{eligible.map(v=><option key={v.quotationId} value={v.quotationId}>{v.vendorName} — {money(v.vendorQuotedTotal,v.currency)}</option>)}</select></label><label className="block"><span className="mb-1 block text-[9px] font-bold uppercase tracking-wide text-slate-400">Award Remarks</span><input value={remarks} onChange={e=>setRemarks(e.target.value)} placeholder="Reason / award remarks" className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs text-slate-700 outline-none focus:border-red-300" /></label><button type="button" disabled={!canAward || busyId==="award"} onClick={() => void award()} className="inline-flex h-[39px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 text-[10px] font-bold text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"><FloppyDiskIcon size={14}/>Award Vendor</button></div>
            {!data.canAward && <p className="mt-3 text-[9px] font-semibold text-amber-600">Award remains locked until every selected vendor reaches Submitted/Approved, Rejected or Awarded decision state.</p>}
          </section>
        </> : null}
      </div>
    </aside>
  </div>;
}
