import api from "./axios";

interface Envelope<T = unknown> { success?: boolean; message?: string; code?: string; data?: T; }
function ensure<T>(response: { data?: Envelope<T> }, fallback: string): T { if (response.data?.success === false) throw new Error(response.data.message || fallback); if (response.data?.data === undefined) throw new Error(fallback); return response.data.data as T; }

export type BOQApproval = {
  boq: { id: string; reference: string; title: string; status: string; statusLabel: string; currency: string; projectValue: number; subtotal: number; grandTotal: number; vendors: Array<{ vendorId: string; name: string }>; itemCount: number; quotationWorkflow?: Record<string, unknown> | null };
  quotations: Array<{ quotationId: string; quotationNo: string; vendorId: string; vendorName: string; status: string; statusLabel: string; surveyStatus: string | null; surveyStatusLabel?: string; masterRateTotal: number; vendorQuotedTotal: number; variance: number; variancePercentage: number; grandTotal: number; currency: string; rejectionReason: string; award?: { awarded?: boolean; remarks?: string } | null }>;
  counts: Record<string, number>;
  eligibleToAward: Array<{ quotationId: string; quotationNo: string; vendorId: string; vendorName: string; status: string; masterRateTotal: number; vendorQuotedTotal: number; variance: number; variancePercentage: number; grandTotal: number; currency: string }>;
  canAward: boolean;
};

export async function generateQuotationsFromBOQ(boqId: string) { return ensure(await api.post<Envelope>(`/boqs/${encodeURIComponent(boqId)}/generate-quotations`, {}), "Unable to generate quotation forms."); }
export async function getBOQApproval(boqId: string) { return ensure<BOQApproval>(await api.get<Envelope<BOQApproval>>(`/boqs/${encodeURIComponent(boqId)}/approval`), "Unable to load BOQ approval."); }
export async function reviewSurvey(quotationId: string, approve: boolean, reason = "") { return ensure(await api.post<Envelope>(`/quotations/${encodeURIComponent(quotationId)}/survey-review`, { approve, reason }), "Unable to update survey review."); }
export async function checkMasterRate(quotationId: string, notes = "") { return ensure(await api.post<Envelope>(`/quotations/${encodeURIComponent(quotationId)}/master-rate-check`, { notes }), "Unable to check master rate comparison."); }
export async function awardBOQVendor(boqId: string, quotationId: string, remarks: string) { return ensure(await api.post<Envelope>(`/boqs/${encodeURIComponent(boqId)}/award`, { quotationId, remarks }), "Unable to award vendor."); }
