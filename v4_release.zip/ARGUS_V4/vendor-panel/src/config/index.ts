interface Config {
    apiUrl: string;
    storageUrl: string;
    appTitle: string;
    appVersion: string;
    isDevelopment: boolean;
    isProduction: boolean;
}

const runtimeApiFallback =
    import.meta.env.PROD && typeof window !== 'undefined'
        ? `${window.location.origin}/api/v1`
        : 'http://localhost:3000/api/v1';

const config: Config = {
    apiUrl: import.meta.env.VITE_API_URL || runtimeApiFallback,
    storageUrl: import.meta.env.VITE_STORAGE_URL || runtimeApiFallback,
    appTitle: import.meta.env.VITE_APP_TITLE || 'ARGUS',
    appVersion: import.meta.env.VITE_APP_VERSION || '1.0.0',
    isDevelopment: import.meta.env.DEV,
    isProduction: import.meta.env.PROD,
};

export default config;
