import { useState } from 'react';
import BidsAndProposals from '../components/quotations/Bids&Proposal';
import QuotationDashboard from '../components/quotations/QuotationDashboard';
import type { Quotation } from '../types/quotation';

/**
 * Vendor quotation workspace.
 *
 * The shared backend supplied with this project does not currently expose a
 * production vendor quotation-list API. The vendor panel therefore renders
 * the exact admin Bids & Proposals UI with an intentionally empty dataset
 * until that vendor-scoped API is implemented.
 */
export default function VendorBidsProposals() {
    const [selectedQuotation] = useState<Quotation | null>(null);

    return (
        <div className="min-h-screen">
            <div className="mb-6">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">Bids &amp; Proposals</h1>
                <p className="mt-1 text-sm text-slate-500">Vendor quotations, bid submissions and proposal status tracking.</p>
            </div>

            <QuotationDashboard total={0} pending={0} approved={0} approvedValue={0} />

            <BidsAndProposals
                quotations={[]}
                onView={(quotation) => {
                    void quotation;
                    void selectedQuotation;
                }}
            />
        </div>
    );
}
