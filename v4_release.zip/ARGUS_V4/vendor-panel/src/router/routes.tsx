import { Navigate } from "react-router-dom";
import VendorLogin from "../pages/VendorLogin";
import VendorTermsAcceptance from "../pages/VendorTermsAcceptance";
import VendorSummary from "../components/vendor_dashboard/vendor_summary";
import VendorNotifications from "../pages/VendorNotifications";
import { VendorQuotations, VendorProjects, VendorInvoices, VendorTasks } from "../pages/VendorWorkflowPages";
import RolesPermissions from "../pages/Settings/RolesPermissions";
import Users from "../pages/Users";

export const routes = [
    { path: "/", element: <Navigate to="/vendor-login" replace />, layout: "blank" },
    { path: "/vendor-login", element: <VendorLogin />, layout: "blank" },
    {
        path: "/vendor_terms",
        element: <VendorTermsAcceptance />,
        layout: "blank",
        auth: true,
    },
    {
        path: "/vendor_dashboard",
        element: <VendorSummary />,
        layout: "default",
        auth: true,
    },
    {
        path: "/notifications",
        element: <VendorNotifications />,
        layout: "default",
        auth: true,
    },
    {
        path: "/bids-proposals",
        element: <VendorQuotations />,
        layout: "default",
        auth: true,
    },
    {
        path: "/projects",
        element: <VendorProjects />,
        layout: "default",
        auth: true,
    },
    {
        path: "/projects/project_details/:projectId",
        element: <VendorProjects />,
        layout: "default",
        auth: true,
    },
    {
        path: "/invoices",
        element: <VendorInvoices />,
        layout: "default",
        auth: true,
    },
    {
        path: "/tasks",
        element: <VendorTasks />,
        layout: "default",
        auth: true,
    },
    {
        path: "/user_management",
        element: <Users />,
        layout: "default",
        auth: true,
    },
    {
        path: "/settings/roles_permissions",
        element: <RolesPermissions />,
        layout: "default",
        auth: true,
    },
    { path: "*", element: <Navigate to="/vendor_dashboard" replace />, layout: "default", auth: true },
];
