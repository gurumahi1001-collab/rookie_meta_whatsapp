import { createBrowserRouter } from 'react-router-dom';
import BlankLayout from '../components/Layouts/BlankLayout';
import VendorDefaultLayout from '../components/Layouts/VendorDefaultLayout';
import ProtectedRoute from '../auth/ProtectedRoute';
import { routes } from './routes';

const finalRoutes = routes.map((route: any) => {
    const protectedElement = route.auth ? (
        <ProtectedRoute>{route.element}</ProtectedRoute>
    ) : (
        route.element
    );

    const element = route.layout === 'blank' ? (
        <BlankLayout>{protectedElement}</BlankLayout>
    ) : (
        <VendorDefaultLayout>{protectedElement}</VendorDefaultLayout>
    );

    return {
        ...route,
        element,
    };
});

export default createBrowserRouter(finalRoutes);
