# Staff Employee Files & Login Password Patch

This is a focused follow-up patch for the latest Staff View/Edit production patch. It updates the staff View/Edit drawers and the supporting staff API controller/service only. It does not replace the full MVC project.

## Files to replace

- `resources/views/content/admin_hr/emp_staff/permanent_staff.blade.php`
- `resources/views/content/admin_hr/emp_staff/Contractor_staff.blade.php`
- `app/Http/Controllers/emp_staff/StaffDirectoryController.php`
- `app/Services/HR/StaffService.php`

Back up the existing four files, then extract these replacements into the Laravel project root. No route change, database migration, or SQL import is required.

## Employee Files UI

- Replaces the old sample/demo document cards with a responsive two-column card layout based on the supplied reference image: document icon, original filename, category, file size, verification badge, and edit-only remove control.
- Shows the heading **Compliance Folders & Verified Documents**.
- The upload panel appears in Edit mode and has a category dropdown, file selector, and **Upload Document** action. Uploads save immediately through the existing staff update endpoint and local storage.
- Category options are read dynamically from active `ryans_documents` rows (`status = 0`); no hardcoded category fallback is used.
- The supplied SQL dump contains no active document categories (the only sample `ryans_documents` row has `status = 2`). The dropdown will therefore be disabled with an explanation until categories are added or activated in the existing Document Settings screen.
- New uploads are stored as **Pending**. The UI shows **Verified** only when an explicit `verification_status = Verified` value already exists in the staff profile JSON metadata. This patch does not invent verification results or add an approval workflow.
- Existing `ryans_staff_attachment` and `ryans_staff_profile_data.profile_json` storage is reused. Files remain in local `staff/documents` storage. No new database columns are introduced.
- Uploaded files are validated as PDF, JPG/JPEG, PNG, WEBP, DOC or DOCX, with a 10 MB per-file limit. The server validates the selected document ID against an active document-master row.

## Dropdown theme

All literal and dynamically generated dropdowns in both staff Blade pages use the `select3 form-select` theme classes. The Employee Files category list uses the same classes.

## Login password editing

- The View/Edit profile exposes New Password and Confirm New Password only when the staff member has an existing linked row in `users` (`users.user_id = ryans_staff.sno`).
- The current password hash is never returned to the browser.
- Leave both password fields blank to preserve the current password. If either is entered, both are required; the new password must be at least 8 characters and match its confirmation.
- The service hashes a new password with Laravel `Hash::make()` and updates only the existing linked account. It does not create or link login accounts.

## Validation performed

- PHP syntax checks passed for the updated controller and service.
- JavaScript syntax checks passed for both staff Blade files.
- All 21 literal `<select>` elements in each Blade file were checked for both `select3` and `form-select`; dynamic select creation paths were also checked.
- Permanent and contract staff Blade files remain identical except for their existing employment-type constant.
- ZIP integrity is checked after packaging.

The supplied MVC ZIP does not include Composer's `vendor` directory and no live database/browser session is available here. Laravel boot, end-to-end document upload, and real login testing should therefore be completed in staging before production deployment.
