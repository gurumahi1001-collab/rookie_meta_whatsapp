<?php

namespace App\Services\HR;

use App\Models\HR\LeaveEntitlementModel;
use App\Models\HR\LeaveRequestModel;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class LeaveService
{
    public function __construct(
        private StaffService $staffService,
        private LeaveCycleService $leaveCycleService
    ) {}

    public function paginate(string $type, array $filters)
    {
        $query = LeaveRequestModel::query()->from('ryans_leave_requests as l')
            ->join('ryans_staff as s', 's.sno', '=', 'l.staff_id')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->where('l.status', 0);

        $search = trim((string) ($filters['search'] ?? $filters['employee'] ?? ''));
        if ($search !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $search) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)
                ->orWhere('s.staff_id', 'like', $like)->orWhere('s.mobile_no', 'like', $like)
                ->orWhere('l.leave_type', 'like', $like)->orWhere('l.reason', 'like', $like));
        }
        $status = $filters['leave_status'] ?? $filters['status'] ?? null;
        if ($status && $status !== 'ALL') $query->where('l.approval_status', $status);
        $leaveType = trim((string) ($filters['leave_type'] ?? 'ALL'));
        if ($leaveType !== '' && strtoupper($leaveType) !== 'ALL') {
            $query->whereIn('l.leave_type', $this->leaveCycleService->typeAliases($leaveType));
        }
        if (!empty($filters['from_date'])) $query->whereDate('l.to_date', '>=', $filters['from_date']);
        if (!empty($filters['to_date'])) $query->whereDate('l.from_date', '<=', $filters['to_date']);

        $query->orderByDesc('l.created_at')->orderByDesc('l.sno');
        return $query->select([
            'l.sno as id', 'l.staff_id', 'l.leave_type', 'l.from_date', 'l.to_date', 'l.days', 'l.reason',
            'l.approval_status', 'l.review_note', 'l.reviewed_by', 'l.reviewed_at', 'l.created_at', 'l.updated_at',
            's.staff_name', 's.staff_id as staff_code', 's.date_of_joining', 'd.department_name', 'dg.designation',
        ])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();
    }

    public function summary(string $type, array $filters = []): array
    {
        $employment = $this->staffService->employmentValue($type);
        $staffQuery = DB::table('ryans_staff as s');
        $this->staffService->applyCategoryScope($staffQuery, 's', $type);
        $this->staffService->applyNotDeletedScope($staffQuery, 's');
        $staffCount = (int) $staffQuery->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN -1 WHEN s.status = 2 THEN 2 WHEN s.status IN (5,6,7) THEN -3 ELSE -3 END) = 0")->count();

        $base = DB::table('ryans_leave_requests as l')->join('ryans_staff as s', 's.sno', '=', 'l.staff_id')
            ->where('l.status', 0);
        $this->staffService->applyCategoryScope($base, 's', $type);
        $this->staffService->applyNotDeletedScope($base, 's');
        $today = now()->toDateString();
        $onLeaveToday = (clone $base)->where('l.approval_status', 'Approved')->whereDate('l.from_date', '<=', $today)->whereDate('l.to_date', '>=', $today)->distinct('l.staff_id')->count('l.staff_id');
        $pending = (clone $base)->where('l.approval_status', 'Pending')->count();
        $monthStart = now()->startOfMonth()->toDateString();
        $monthEnd = now()->endOfMonth()->toDateString();
        $approved = (clone $base)->where('l.approval_status', 'Approved')
            ->whereRaw('DATE(COALESCE(l.reviewed_at, l.updated_at, l.created_at)) BETWEEN ? AND ?', [$monthStart, $monthEnd])->count();

        return ['staff_count' => $staffCount, 'on_leave_today' => (int) $onLeaveToday, 'pending_count' => (int) $pending, 'approved_this_month' => (int) $approved];
    }

    /** Realtime staff-specific entitlement summary for each employee's active anniversary cycle. */
    public function entitlements(string $type, array $filters)
    {
        $query = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN -1 WHEN s.status = 2 THEN 2 WHEN s.status IN (5,6,7) THEN -3 ELSE -3 END) = 0");
        if (($filters['search'] ?? '') !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)
                ->orWhere('s.staff_id', 'like', $like)->orWhere('d.department_name', 'like', $like)->orWhere('dg.designation', 'like', $like));
        }
        $page = $query->orderBy('s.staff_name')->select([
            's.sno as staff_pk', 's.staff_id as staff_code', 's.staff_name', 's.date_of_joining',
            's.department_id', 'd.department_name', 's.designation_id', 'dg.designation',
        ])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();

        $asOf = $filters['as_of'] ?? now()->toDateString();
        $page->getCollection()->transform(function ($staff) use ($asOf) {
            $cycleResult = $this->leaveCycleService->ensureCycle((int) $staff->staff_pk, 0, $asOf);
            $cycle = $cycleResult['cycle'];
            $cycleRows = collect($cycleResult['entitlements']);
            $map = [
                'Casual' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0],
                'Privilege' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0],
                'Sick' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0],
            ];
            $values = [];
            foreach ($cycleRows as $row) {
                $key = $this->leaveCycleService->balanceKey((string) $row->leave_type);
                if ($key === null) continue;
                $annual = (float) $row->annual_days;
                $carry = (float) ($row->carry_forward_days ?? 0);
                $adjustments = (float) ($row->adjustment_days ?? 0);
                $used = $this->leaveCycleService->usedDays((int) $staff->staff_pk, (string) $row->leave_type, $cycle['start_date'], $cycle['end_date']);
                $entitled = $annual + $carry + $adjustments;
                $map[$key]['entitled'] += $entitled;
                $map[$key]['availed'] += $used;
                $map[$key]['balance'] = max(0, $map[$key]['entitled'] - $map[$key]['availed']);
                if ($key === 'Casual') $values['Casual'] = $annual;
                if ($key === 'Privilege') { $values['Privilege'] = $annual; $values['Paid Leave'] = $annual; $values['Privilege Carry Forward'] = $carry; $values['Privilege Adjustment'] = $adjustments; }
                if ($key === 'Casual') $values['Casual Adjustment'] = $adjustments;
                if ($key === 'Sick') $values['Sick Adjustment'] = $adjustments;
                if ($key === 'Sick') $values['Sick'] = $annual;
            }
            foreach ($map as &$balance) $balance['balance'] = max(0, $balance['entitled'] - $balance['availed']);
            unset($balance);
            $staff->cycle_start_date = $cycle['start_date'];
            $staff->cycle_end_date = $cycle['end_date'];
            $staff->cycle_basis = $cycle['cycle_basis'];
            $staff->leave_balances = $map;
            $staff->leave_entitlement_values = $values;
            $staff->total_entitled = array_sum(array_column($map, 'entitled'));
            $staff->total_availed = array_sum(array_column($map, 'availed'));
            $staff->total_balance = array_sum(array_column($map, 'balance'));
            $staff->balance_health = $staff->total_entitled > 0 ? (int) round(($staff->total_balance / $staff->total_entitled) * 100) : 0;
            return $staff;
        });
        return $page;
    }

    public function createRequest(int $staffId, array $data, ?string $type = null, int $actor = 0): LeaveRequestModel
    {
        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['sno', 'status', 'hr_status', 'date_of_joining']);
        if (!$staff) abort(404, 'Staff profile not found.');
        $this->assertActiveStaff($staffId);
        if ($type !== null) $this->assertCategory($staffId, $type);
        $from = Carbon::parse($data['from_date'])->startOfDay();
        $to = Carbon::parse($data['to_date'])->startOfDay();
        if ($to->lt($from)) throw ValidationException::withMessages(['to_date' => 'The end date must be on or after the start date.']);
        if ($staff->date_of_joining && $from->lt(Carbon::parse($staff->date_of_joining)->startOfDay())) {
            throw ValidationException::withMessages(['from_date' => 'Leave cannot begin before the staff joining date.']);
        }
        $days = $this->leaveCycleService->workingDaysBetween($from->toDateString(), $to->toDateString());
        if ($days <= 0) throw ValidationException::withMessages(['from_date' => 'The selected range contains no working days after weekends and configured holidays.']);
        $leaveType = $this->leaveCycleService->canonicalType(trim((string) $data['leave_type']));
        if (!in_array($leaveType, ['Casual Leave', 'Paid Leave', 'Sick Leave'], true)) {
            throw ValidationException::withMessages(['leave_type' => 'Choose Casual Leave, Paid Leave or Sick Leave.']);
        }

        return DB::transaction(function () use ($staffId, $data, $from, $to, $days, $leaveType, $actor) {
            DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first(['sno']);
            $overlap = LeaveRequestModel::query()->where('staff_id', $staffId)->where('status', 0)
                ->whereIn('approval_status', ['Pending', 'Approved'])
                ->whereDate('from_date', '<=', $to->toDateString())->whereDate('to_date', '>=', $from->toDateString())->lockForUpdate()->exists();
            if ($overlap) throw ValidationException::withMessages(['from_date' => 'This leave overlaps an existing pending or approved request.']);
            $leave = LeaveRequestModel::query()->create([
                'staff_id' => $staffId, 'leave_type' => $leaveType,
                'from_date' => $from->toDateString(), 'to_date' => $to->toDateString(), 'days' => $days,
                'reason' => trim((string) $data['reason']), 'approval_status' => 'Pending', 'status' => 0,
            ]);
            $this->leaveCycleService->logLeaveRequest($staffId, $leaveType, $from->toDateString(), $to->toDateString(), (int) $leave->sno, (float) $days, $actor);
            return $leave;
        }, 3);
    }

    public function review(int $id, string $status, ?string $note, int $actor, ?string $type = null): void
    {
        DB::transaction(function () use ($id, $status, $note, $actor, $type) {
            $leave = LeaveRequestModel::query()->where('sno', $id)->where('status', 0)->lockForUpdate()->first();
            if (!$leave) abort(404, 'Leave request not found.');
            $staff = DB::table('ryans_staff')->where('sno', $leave->staff_id)->lockForUpdate()->first(['sno', 'status', 'hr_status']);
            if (!$staff || (int) ($staff->hr_status ?? match ((int) $staff->status) { 0 => 0, 1, 4 => -1, 2 => 2, 5, 6, 7 => -3, default => -3 }) === 2) abort(404, 'Leave request not found.');
            if ($type !== null) $this->assertCategory((int) $leave->staff_id, $type);
            if ($leave->approval_status !== 'Pending') throw ValidationException::withMessages(['approval_status' => 'Only pending requests can be reviewed.']);

            if ($status === 'Approved') {
                $approvedDays = $this->leaveCycleService->workingDaysBetween((string) $leave->from_date, (string) $leave->to_date);
                if ($approvedDays <= 0) throw ValidationException::withMessages(['approval_status' => 'This request contains no working days under the current holiday calendar.']);
                $this->leaveCycleService->validateLeaveAvailability((int) $leave->staff_id, (string) $leave->leave_type, (string) $leave->from_date, (string) $leave->to_date, $actor);
                // This is part of the same transaction. Attendance conflicts roll the approval back.
                $this->leaveCycleService->synchroniseApprovedLeaveToAttendance((int) $leave->staff_id, (string) $leave->leave_type, (string) $leave->from_date, (string) $leave->to_date, (int) $leave->sno, $actor);
                $leave->days = $approvedDays;
            }

            $leave->approval_status = $status;
            $leave->review_note = $note;
            $leave->reviewed_by = $actor;
            $leave->reviewed_at = now();
            $leave->save();

            if ($status === 'Approved') {
                $this->leaveCycleService->logLeaveApproval((int) $leave->staff_id, (string) $leave->leave_type, (string) $leave->from_date, (string) $leave->to_date, (int) $leave->sno, $actor);
            } else {
                $this->leaveCycleService->logLeaveRejection((int) $leave->staff_id, (string) $leave->leave_type,
                    (string) $leave->from_date, (string) $leave->to_date, (int) $leave->sno, $note, $actor);
            }
        }, 3);
    }

    public function saveEntitlement(string $type, array $data, int $actor): void
    {
        $staffId = (int) $data['staff_id'];
        $employment = $this->staffService->employmentValue($type);
        $this->assertCategory($staffId, $type);
        $leaveType = $this->leaveCycleService->canonicalType((string) $data['leave_type']);
        $this->leaveCycleService->ensureCycle($staffId, $actor, $data['as_of'] ?? null);
        $cycle = $this->leaveCycleService->cycleForStaff($staffId, $data['as_of'] ?? null);
        $this->leaveCycleService->saveAllocation($staffId, $leaveType, (float) $data['annual_days'],
            array_key_exists('carry_forward_days', $data) ? (float) $data['carry_forward_days'] : null, $actor, $cycle);
    }

    public function saveEntitlementsBulk(string $type, int $staffId, array $entitlements, int $actor, ?string $asOf = null): void
    {
        $this->assertCategory($staffId, $type);
        $this->leaveCycleService->saveEntitlementsBulk($type, $staffId, $entitlements, $actor, $asOf);
    }

    public function creditEntitlementForCategory(string $type, string $leaveType, float $days, int $actor): int
    {
        return $this->leaveCycleService->creditEntitlementForCategory($type, $leaveType, $days, $actor);
    }

    /** One transaction for single-category or all-staff batch credits. */
    public function creditEntitlementForGroup(string $group, string $leaveType, float $days, int $actor): int
    {
        $group = strtolower(trim($group));
        if (!in_array($group, ['permanent', 'contract', 'all'], true)) {
            throw ValidationException::withMessages(['staff_group' => 'Choose Permanent, Contract or All staff.']);
        }
        return DB::transaction(function () use ($group, $leaveType, $days, $actor) {
            if ($group === 'all') {
                return $this->leaveCycleService->creditEntitlementForCategory('permanent', $leaveType, $days, $actor)
                    + $this->leaveCycleService->creditEntitlementForCategory('contract', $leaveType, $days, $actor);
            }
            return $this->leaveCycleService->creditEntitlementForCategory($group, $leaveType, $days, $actor);
        }, 3);
    }

    public function policies(string $type)
    {
        return $this->leaveCycleService->policies($this->staffService->employmentValue($type));
    }

    public function savePolicies(string $type, array $items, int $actor): void
    {
        $this->leaveCycleService->savePolicies($this->staffService->employmentValue($type), $items, $actor);
    }

    public function history(string $type, array $filters)
    {
        return $this->leaveCycleService->listHistory($type, $filters);
    }

    private function assertCategory(int $staffId, string $type): void
    {
        $employment = $this->staffService->employmentValue($type);
        $matches = DB::table('ryans_staff as s')->where('s.sno', $staffId)->where(function ($q) use ($employment) {
            $q->where('s.employment_type', $employment)->orWhere(function ($legacy) use ($employment) {
                $legacy->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                    $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                });
            });
        })->exists();
        if (!$matches) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category.']);
    }

    private function assertActiveStaff(int $staffId): void
    {
        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['status', 'hr_status']);
        $status = $staff?->hr_status ?? match ((int) ($staff->status ?? 2)) { 0 => 0, 1, 4 => -1, 2 => 2, 5, 6, 7 => -3, default => -3 };
        if (!$staff || (int) $status !== 0) throw ValidationException::withMessages(['staff_id' => 'Only active staff can apply for leave.']);
    }
}
