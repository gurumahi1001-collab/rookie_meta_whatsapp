<?php

namespace App\Services\HR;

use App\Models\HR\StaffAttendanceModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class AttendanceService
{
    public function __construct(private StaffService $staffService) {}

    /**
     * Daily list feed: return every active staff member for the requested date,
     * even when no attendance row exists yet. The latest active row for that
     * staff/date is joined so the same screen can create or edit attendance.
     */
    public function paginate(string $type, array $filters)
    {
        $date = (string) ($filters['date'] ?? now()->toDateString());
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            throw ValidationException::withMessages(['date' => 'Date must use YYYY-MM-DD format.']);
        }

        $latestAttendance = DB::table('ryans_staff_attendance as latest_a')
            ->selectRaw('MAX(latest_a.sno) as attendance_sno, latest_a.staff_id')
            ->whereDate('latest_a.date', $date)
            ->where('latest_a.status', 0)
            ->groupBy('latest_a.staff_id');

        $query = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id')
            ->leftJoinSub($latestAttendance, 'latest_a', function ($join) {
                $join->on('latest_a.staff_id', '=', 's.sno');
            })
            ->leftJoin('ryans_staff_attendance as a', 'a.sno', '=', 'latest_a.attendance_sno');

        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) = 0");

        if (($filters['search'] ?? '') !== '') {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q
                ->where('s.staff_name', 'like', $term)
                ->orWhere('s.staff_id', 'like', $term)
                ->orWhere('s.mobile_no', 'like', $term)
                ->orWhere('d.department_name', 'like', $term)
                ->orWhere('dg.designation', 'like', $term)
                ->orWhere('a.attendance', 'like', $term));
        }

        if (!empty($filters['department_id'])) {
            // Primary filter path matches StaffService and the staff directory API.
            $query->where('s.department_id', (int) $filters['department_id']);
        } elseif (!empty($filters['department']) && (string) $filters['department'] !== 'ALL') {
            // Backward compatibility for existing integrations that still send a department name.
            $query->where('d.department_name', (string) $filters['department']);
        }

        if (!empty($filters['month']) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', (string) $filters['month'])) {
            // Month filter is retained for callers that explicitly request a
            // historical log; daily list callers pass only `date`.
            $query->whereRaw("DATE_FORMAT(a.date, '%Y-%m') = ?", [$filters['month']]);
        }

        $sortMap = [
            'date' => 'a.date',
            'staff' => 's.staff_name',
            'department' => 'd.department_name',
            'status' => 'a.attendance',
            'in_time' => 'a.in_time',
            'out_time' => 'a.out_time',
        ];
        $sort = (string) ($filters['sort'] ?? 'staff');
        $direction = strtolower((string) ($filters['direction'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';

        return $query->orderBy($sortMap[$sort] ?? $sortMap['staff'], $direction)
            ->orderBy('s.staff_name')
            ->select([
                'a.sno as id',
                'a.date',
                'a.attendance',
                'a.in_time',
                'a.out_time',
                'a.type',
                'a.reason',
                's.sno as staff_pk',
                's.staff_image',
                's.staff_id as staff_code',
                's.staff_name',
                's.mobile_no',
                's.email_id',
                's.basic_salary',
                'd.department_name',
                'dg.designation',
            ])
            ->paginate((int) ($filters['per_page'] ?? 10))
            ->withQueryString();
    }

    /** Summary counts for the four existing daily-list KPI cards. */
    public function dailySummary(string $type, string $date): array
    {
        $latestAttendance = DB::table('ryans_staff_attendance as latest_a')
            ->selectRaw('MAX(latest_a.sno) as attendance_sno, latest_a.staff_id')
            ->whereDate('latest_a.date', $date)
            ->where('latest_a.status', 0)
            ->groupBy('latest_a.staff_id');

        $query = DB::table('ryans_staff as s')
            ->leftJoinSub($latestAttendance, 'latest_a', function ($join) {
                $join->on('latest_a.staff_id', '=', 's.sno');
            })
            ->leftJoin('ryans_staff_attendance as a', 'a.sno', '=', 'latest_a.attendance_sno');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN 1 WHEN s.status = 2 THEN 2 WHEN s.status IN (3,5,6,7) THEN 3 ELSE 3 END) = 0");

        $row = $query->selectRaw("COUNT(*) AS staff_count,\n            SUM(CASE WHEN UPPER(COALESCE(a.attendance, '')) IN ('P','PR','OD','PRESENT','ON DUTY') THEN 1 ELSE 0 END) AS present_count,\n            SUM(CASE WHEN UPPER(COALESCE(a.attendance, '')) IN ('A','ABSENT') THEN 1 ELSE 0 END) AS absent_count,\n            SUM(CASE WHEN UPPER(COALESCE(a.attendance, '')) IN ('L','LEAVE','ON LEAVE') THEN 1 ELSE 0 END) AS leave_count")
            ->first();

        return [
            'staff_count' => (int) ($row->staff_count ?? 0),
            'present_count' => (int) ($row->present_count ?? 0),
            'absent_count' => (int) ($row->absent_count ?? 0),
            'leave_count' => (int) ($row->leave_count ?? 0),
        ];
    }

    /** Monthly matrix feed for the existing table and calendar screens. */
    public function matrix(string $type, array $filters): array
    {
        $month = (string) ($filters['month'] ?? now()->format('Y-m'));
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) {
            throw ValidationException::withMessages(['month' => 'Month must use YYYY-MM format.']);
        }
        $first = $month . '-01';
        $last = date('Y-m-t', strtotime($first));
        $query = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        if (!empty($filters['department_id'])) $query->where('s.department_id', (int) $filters['department_id']);
        if (!empty($filters['department']) && $filters['department'] !== 'ALL') $query->where('d.department_name', (string) $filters['department']);
        if (!empty($filters['search'])) {
            $term = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $term)
                ->orWhere('s.staff_id', 'like', $term)->orWhere('d.department_name', 'like', $term));
        }
        $page = $query->orderBy('s.staff_name')->select([
            's.sno as id', 's.staff_id', 's.staff_name as name', 's.mobile_no',
            's.department_id', 'd.department_name as department', 's.designation_id', 'dg.designation',
        ])->paginate((int) ($filters['per_page'] ?? 50))->withQueryString();
        $ids = $page->getCollection()->pluck('id')->map(fn ($id) => (int) $id)->all();
        $rows = $ids ? DB::table('ryans_staff_attendance')->whereIn('staff_id', $ids)
            ->where('status', 0)->whereBetween('date', [$first, $last])
            ->orderBy('date')->orderBy('sno')->get([
                'sno', 'staff_id', 'date', 'attendance', 'in_time', 'out_time', 'type', 'reason'
            ]) : collect();
        $attendance = [];
        foreach ($rows as $row) {
            $date = (string) $row->date;
            $attendance[(int) $row->staff_id][$date] = [
                'id' => (int) $row->sno, 'attendance' => (string) $row->attendance,
                'in_time' => $row->in_time, 'out_time' => $row->out_time,
                'type' => $row->type, 'reason' => $row->reason,
            ];
        }
        $holidayRows = DB::table('ryans_holiday')->where('status', 0)
            ->whereDate('hol_date', '<=', $last)
            ->whereRaw('COALESCE(hol_end_date, hol_date) >= ?', [$first])
            ->get(['hol_date', 'hol_end_date', 'hol_reason']);
        $holidays = [];
        foreach ($holidayRows as $holiday) {
            $holidayStart = Carbon::parse($holiday->hol_date)->startOfDay();
            $holidayEnd = Carbon::parse($holiday->hol_end_date ?: $holiday->hol_date)->startOfDay();
            if ($holidayEnd->lt($holidayStart)) $holidayEnd = $holidayStart->copy();
            foreach (CarbonPeriod::create($holidayStart, $holidayEnd) as $holidayDate) {
                $key = $holidayDate->toDateString();
                if ($key >= $first && $key <= $last) $holidays[$key] = (string) $holiday->hol_reason;
            }
        }
        return [
            'data' => $page->items(),
            'attendance' => $attendance,
            'holidays' => $holidays,
            'meta' => ['current_page' => $page->currentPage(), 'last_page' => $page->lastPage(), 'per_page' => $page->perPage(), 'total' => $page->total()],
            'month' => $month,
            'days_in_month' => (int) date('t', strtotime($first)),
        ];
    }

    public function saveManual(string $type, array $data, int $actor): void
    {
        $employment = $this->staffService->employmentValue($type);
        $staff = DB::table('ryans_staff as s')->where('s.sno', (int) $data['staff_id'])
            ->where(function ($q) use ($employment) {
                $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                    $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                        $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                    });
                });
            })->first(['s.sno', 's.status', 's.hr_status']);
        if (!$staff || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) === 2) {
            throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category or is deleted.']);
        }

        // Serialize writes by locking the staff row before checking for an existing
        // attendance row. This avoids two simultaneous requests creating duplicates.
        DB::transaction(function () use ($data, $actor, $employment) {
            $lockedStaff = DB::table('ryans_staff')->where('sno', (int) $data['staff_id'])->lockForUpdate()->first();
            if (!$lockedStaff || (int) ($lockedStaff->hr_status ?? $this->legacyStatus((int) $lockedStaff->status)) === 2) {
                throw ValidationException::withMessages(['staff_id' => 'Staff record is no longer available.']);
            }
            $belongs = (int) ($lockedStaff->employment_type ?? 0) === $employment;
            if (!$belongs && $lockedStaff->employment_type === null) {
                $belongs = DB::table('users')->where('user_id', (int) $lockedStaff->sno)->where('staff_type', $employment)->exists();
            }
            if (!$belongs) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category.']);
            $hrStatus = (int) ($lockedStaff->hr_status ?? $this->legacyStatus((int) $lockedStaff->status));
            if (($data['date'] ?? null) === now()->toDateString() && $hrStatus !== 0) {
                throw ValidationException::withMessages(['staff_id' => 'Only active staff can be marked for today.']);
            }

            $attendanceCode = strtoupper((string) $data['attendance']);
            if (!in_array($attendanceCode, ['P', 'PR', 'OD'], true)) {
                $data['in_time'] = null;
                $data['out_time'] = null;
            } elseif (!empty($data['out_time']) && empty($data['in_time'])) {
                throw ValidationException::withMessages(['in_time' => 'Check-in time is required when a check-out time is provided.']);
            }
            $existing = StaffAttendanceModel::query()->where('staff_id', (int) $data['staff_id'])->whereDate('date', $data['date'])->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            $now = now();
            if ($existing) {
                foreach (['attendance', 'in_time', 'out_time', 'type', 'reason'] as $field) if (array_key_exists($field, $data)) $existing->{$field} = $data[$field];
                $existing->updated_by = $actor; $existing->updated_at = $now; $existing->save();
                return;
            }
            StaffAttendanceModel::query()->create([
                'staff_attendance_id' => 'ATT-' . $data['staff_id'] . '-' . str_replace('-', '', $data['date']),
                'date' => $data['date'], 'staff_id' => (int) $data['staff_id'], 'attendance' => $data['attendance'],
                'in_time' => $data['in_time'] ?? null, 'out_time' => $data['out_time'] ?? null,
                'type' => $data['type'] ?? 'Manual', 'reason' => $data['reason'] ?? null,
                'created_by' => $actor, 'updated_by' => $actor, 'status' => 0,
            ]);
        }, 3);
    }

    public function checkIn(
        int $staffId,
        int $employment,
        int $actor,
        ?float $latitude = null,
        ?float $longitude = null,
        ?float $accuracyM = null,
        ?string $deviceId = null,
    ): array {
        return DB::transaction(function () use ($staffId, $employment, $actor, $latitude, $longitude, $accuracyM, $deviceId) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw ValidationException::withMessages(['staff' => 'Active staff profile was not found for this account.']);
            }
            $today = now()->toDateString();
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', $today)->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if ($row && strtoupper((string) $row->attendance) === 'L' && (string) $row->type === 'Leave Management') {
                throw ValidationException::withMessages(['check_in' => 'Approved leave is recorded for today. Contact HR if this attendance needs correction.']);
            }
            if ($row && $row->in_time) throw ValidationException::withMessages(['check_in' => 'You have already checked in today.']);
            if ($row) {
                $row->attendance = 'P';
                $row->in_time = now()->format('H:i:s');
                $row->type = 'Mobile';
                $row->check_in_latitude = $latitude;
                $row->check_in_longitude = $longitude;
                $row->check_in_accuracy_m = $accuracyM;
                $row->check_in_device_id = $deviceId;
                $row->updated_by = $actor;
                $row->updated_at = now();
                $row->save();
            } else {
                $row = StaffAttendanceModel::query()->create([
                    'staff_attendance_id' => 'ATT-' . $staffId . '-' . now()->format('Ymd'),
                    'date' => $today,
                    'staff_id' => $staffId,
                    'attendance' => 'P',
                    'in_time' => now()->format('H:i:s'),
                    'type' => 'Mobile',
                    'reason' => null,
                    'check_in_latitude' => $latitude,
                    'check_in_longitude' => $longitude,
                    'check_in_accuracy_m' => $accuracyM,
                    'check_in_device_id' => $deviceId,
                    'created_by' => $actor,
                    'updated_by' => $actor,
                    'status' => 0,
                ]);
            }
            return [
                'id' => (int) $row->sno,
                'date' => $today,
                'in_time' => $row->in_time,
                'attendance' => $row->attendance,
                'check_in' => ['latitude' => $row->check_in_latitude, 'longitude' => $row->check_in_longitude, 'accuracy_m' => $row->check_in_accuracy_m, 'device_id' => $row->check_in_device_id],
            ];
        }, 3);
    }

    public function checkOut(
        int $staffId,
        int $employment,
        int $actor,
        ?float $latitude = null,
        ?float $longitude = null,
        ?float $accuracyM = null,
        ?string $deviceId = null,
    ): array {
        return DB::transaction(function () use ($staffId, $employment, $actor, $latitude, $longitude, $accuracyM, $deviceId) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first();
            if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment || (int) ($staff->hr_status ?? $this->legacyStatus((int) $staff->status)) !== 0) {
                throw ValidationException::withMessages(['staff' => 'Active staff profile was not found for this account.']);
            }
            $row = StaffAttendanceModel::query()->where('staff_id', $staffId)->whereDate('date', now()->toDateString())->where('status', 0)->lockForUpdate()->orderByDesc('sno')->first();
            if (!$row || !$row->in_time) throw ValidationException::withMessages(['check_out' => 'Check-in is required before check-out.']);
            if ($row->out_time) throw ValidationException::withMessages(['check_out' => 'You have already checked out today.']);
            $row->out_time = now()->format('H:i:s');
            $row->check_out_latitude = $latitude;
            $row->check_out_longitude = $longitude;
            $row->check_out_accuracy_m = $accuracyM;
            $row->check_out_device_id = $deviceId;
            $row->updated_by = $actor;
            $row->updated_at = now();
            $row->save();
            return [
                'id' => (int) $row->sno,
                'date' => (string) $row->date,
                'in_time' => $row->in_time,
                'out_time' => $row->out_time,
                'check_out' => ['latitude' => $row->check_out_latitude, 'longitude' => $row->check_out_longitude, 'accuracy_m' => $row->check_out_accuracy_m, 'device_id' => $row->check_out_device_id],
            ];
        }, 3);
    }

    public function history(int $staffId, string $month, int $perPage = 31)
    {
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $month)) throw ValidationException::withMessages(['month' => 'Month must use YYYY-MM format.']);
        return StaffAttendanceModel::query()->where('staff_id', $staffId)->where('status', 0)->whereRaw("DATE_FORMAT(`date`, '%Y-%m') = ?", [$month])->orderBy('date')->paginate($perPage);
    }

    private function legacyStatus(int $status): int
    {
        return match ($status) { 0 => 0, 1,4 => 1, 2 => 2, 5,6,7 => 3, default => 3 };
    }
}
