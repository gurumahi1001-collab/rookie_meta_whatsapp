<?php

declare(strict_types=1);

namespace App\Helpers;

use InvalidArgumentException;
use LogicException;
use RuntimeException;
use Throwable;

/**
 * Portable password utilities for Laravel or plain PHP projects.
 *
 * Uses PHP's standard adaptive password-hashing API, never a custom hash scheme.
 * Argon2id is preferred when supported; bcrypt is the compatibility fallback.
 * Password hashes are one-way and cannot be reversed to recover a password.
 */
final class PasswordHelper
{
    private const ARGON2ID_MEMORY_COST = 65536; // KiB = 64 MiB
    private const ARGON2ID_TIME_COST = 3;
    private const ARGON2ID_THREADS = 1;
    private const BCRYPT_COST = 12;
    private const BCRYPT_MAX_BYTES = 72;
    private const MAX_PASSWORD_BYTES = 1024;

    private function __construct()
    {
        // Static utility: do not instantiate.
    }

    /**
     * Create a password hash for database storage.
     *
     * The resulting value includes the algorithm, random salt and work parameters.
     * Store it in VARCHAR(255) (or an equivalent sufficiently wide field).
     *
     * @throws InvalidArgumentException If the password violates input limits.
     * @throws RuntimeException If PHP cannot generate a hash.
     */
    public static function hashPassword(string $plainPassword): string
    {
        self::validatePlainPassword($plainPassword);

        $algorithm = self::currentAlgorithm();
        $options = self::optionsFor($algorithm);

        // bcrypt considers only the first 72 bytes. Never silently truncate.
        if ($algorithm === PASSWORD_BCRYPT && strlen($plainPassword) > self::BCRYPT_MAX_BYTES) {
            throw new InvalidArgumentException(
                'This server uses bcrypt, which supports at most 72 password bytes. Enable Argon2id or shorten the password.'
            );
        }

        try {
            $hash = password_hash($plainPassword, $algorithm, $options);
        } catch (Throwable $exception) {
            throw new RuntimeException(
                'Password hashing failed. Check the PHP password-hashing support and server resource limits.',
                0,
                $exception
            );
        }

        if (!is_string($hash) || $hash === '') {
            throw new RuntimeException('Password hashing failed; no hash was generated.');
        }

        return $hash;
    }

    /**
     * Verify a submitted plaintext password against a stored hash.
     * Returns false for empty, oversized, NUL-containing, malformed, or unsupported input.
     */
    public static function verifyPassword(string $plainPassword, string $storedHash): bool
    {
        if (
            $plainPassword === ''
            || $storedHash === ''
            || strlen($plainPassword) > self::MAX_PASSWORD_BYTES
            || strpos($plainPassword, "\0") !== false
        ) {
            return false;
        }

        try {
            $info = password_get_info($storedHash);
            $algorithmName = $info['algoName'] ?? 'unknown';

            if (!is_string($algorithmName) || $algorithmName === '' || $algorithmName === 'unknown') {
                return false;
            }

            // Prevent bcrypt's 72-byte truncation from creating password collisions.
            if ($algorithmName === 'bcrypt' && strlen($plainPassword) > self::BCRYPT_MAX_BYTES) {
                return false;
            }

            return password_verify($plainPassword, $storedHash);
        } catch (Throwable $exception) {
            // Malformed or incompatible stored hashes must never authenticate.
            return false;
        }
    }

    /** Backwards-compatible alias for existing application code. */
    public static function checkPlainAndHashedPassword(string $plainPassword, string $storedHash): bool
    {
        return self::verifyPassword($plainPassword, $storedHash);
    }

    /**
     * True when a verified hash should be upgraded to the configured current
     * algorithm/work parameters. Call after successful verification, then save
     * hashPassword($submittedPassword) to the password column.
     */
    public static function needsRehash(string $storedHash): bool
    {
        if ($storedHash === '') {
            return true;
        }

        try {
            $info = password_get_info($storedHash);
            $algorithmName = $info['algoName'] ?? 'unknown';

            if (!is_string($algorithmName) || $algorithmName === '' || $algorithmName === 'unknown') {
                return true;
            }

            $algorithm = self::currentAlgorithm();
            return password_needs_rehash($storedHash, $algorithm, self::optionsFor($algorithm));
        } catch (Throwable $exception) {
            return true;
        }
    }

    /** Human-readable algorithm selected on this PHP server, useful for deployment checks. */
    public static function algorithmName(): string
    {
        $algorithm = self::currentAlgorithm();

        if (defined('PASSWORD_ARGON2ID') && $algorithm === PASSWORD_ARGON2ID) {
            return 'argon2id';
        }

        return 'bcrypt';
    }

    /**
     * Password hashes are intentionally non-reversible.
     * Use a password reset or issue a new password instead.
     *
     * @throws LogicException Always.
     */
    public static function hashedPasswordToPlainText(string $storedHash): string
    {
        throw new LogicException(
            'A secure password hash cannot be converted to plaintext. Reset the password or issue a new one.'
        );
    }

    /** Select one supported algorithm for new hashes on this server. */
    private static function currentAlgorithm()
    {
        if (
            defined('PASSWORD_ARGON2ID')
            && function_exists('password_algos')
            && in_array('argon2id', password_algos(), true)
        ) {
            return PASSWORD_ARGON2ID;
        }

        return PASSWORD_BCRYPT;
    }

    /** Return options for the explicitly selected algorithm. */
    private static function optionsFor($algorithm): array
    {
        if (defined('PASSWORD_ARGON2ID') && $algorithm === PASSWORD_ARGON2ID) {
            return [
                'memory_cost' => self::ARGON2ID_MEMORY_COST,
                'time_cost' => self::ARGON2ID_TIME_COST,
                'threads' => self::ARGON2ID_THREADS,
            ];
        }

        return ['cost' => self::BCRYPT_COST];
    }

    private static function validatePlainPassword(string $plainPassword): void
    {
        if ($plainPassword === '') {
            throw new InvalidArgumentException('Password cannot be empty.');
        }

        if (strlen($plainPassword) > self::MAX_PASSWORD_BYTES) {
            throw new InvalidArgumentException('Password exceeds the maximum supported length.');
        }

        if (strpos($plainPassword, "\0") !== false) {
            throw new InvalidArgumentException('Password contains an unsupported NUL byte.');
        }
    }
}
