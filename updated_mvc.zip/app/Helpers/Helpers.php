<?php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;
use App\Models\GeneralSettingsModel;
use App\Models\DocumentTypeModel;
use App\Models\DepartmentModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\JobRoleModel;
use App\Models\TimeZoneModel;
use App\Models\CurrencyFormatModel;
use App\Models\UserRolePermissionModel;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class Helpers
{
  public static function appClasses()
  {

    $data = config('custom.custom');


    // default data array
    $DefaultData = [
      'myLayout' => 'vertical',
      'myTheme' => 'theme-default',
      'myStyle' => 'light',
      'myRTLSupport' => true,
      'myRTLMode' => true,
      'hasCustomizer' => true,
      'showDropdownOnHover' => true,
      'displayCustomizer' => true,
      'contentLayout' => 'compact',
      'headerType' => 'fixed',
      'navbarType' => 'fixed',
      'menuFixed' => true,
      'menuCollapsed' => false,
      'footerFixed' => false,
      'menuFlipped' => false,
      // 'menuOffcanvas' => false,
      'customizerControls' => [
        'rtl',
      'style',
      'headerType',
      'contentLayout',
      'layoutCollapsed',
      'showDropdownOnHover',
      'layoutNavbarOptions',
      'themes',
      ],
      //   'defaultLanguage'=>'en',
    ];

    // if any key missing of array from custom.php file it will be merge and set a default value from dataDefault array and store in data variable
    $data = array_merge($DefaultData, $data);

    // All options available in the template
    $allOptions = [
      'myLayout' => ['vertical', 'horizontal', 'blank', 'front'],
      'menuCollapsed' => [true, false],
      'hasCustomizer' => [true, false],
      'showDropdownOnHover' => [true, false],
      'displayCustomizer' => [true, false],
      'contentLayout' => ['compact', 'wide'],
      'headerType' => ['fixed', 'static'],
      'navbarType' => ['fixed', 'static', 'hidden'],
      'myStyle' => ['light', 'dark', 'system'],
      'myTheme' => ['theme-default', 'theme-bordered', 'theme-semi-dark'],
      'myRTLSupport' => [true, false],
      'myRTLMode' => [true, false],
      'menuFixed' => [true, false],
      'footerFixed' => [true, false],
      'menuFlipped' => [true, false],
      // 'menuOffcanvas' => [true, false],
      'customizerControls' => [],
      // 'defaultLanguage'=>array('en'=>'en','fr'=>'fr','de'=>'de','ar'=>'ar'),
    ];

    //if myLayout value empty or not match with default options in custom.php config file then set a default value
    foreach ($allOptions as $key => $value) {
      if (array_key_exists($key, $DefaultData)) {
        if (gettype($DefaultData[$key]) === gettype($data[$key])) {
          // data key should be string
          if (is_string($data[$key])) {
            // data key should not be empty
            if (isset($data[$key]) && $data[$key] !== null) {
              // data key should not be exist inside allOptions array's sub array
              if (!array_key_exists($data[$key], $value)) {
                // ensure that passed value should be match with any of allOptions array value
                $result = array_search($data[$key], $value, 'strict');
                if (empty($result) && $result !== 0) {
                  $data[$key] = $DefaultData[$key];
                }
              }
            } else {
              // if data key not set or
              $data[$key] = $DefaultData[$key];
            }
          }
        } else {
          $data[$key] = $DefaultData[$key];
        }
      }
    }
    $styleVal = $data['myStyle'] == "dark" ? "dark" : "light";
    if(isset($_COOKIE['mode'])){
      if($_COOKIE['mode'] === "system"){
        if(isset($_COOKIE['colorPref'])) {
          $styleVal = Str::lower($_COOKIE['colorPref']);
        }
      }
      else {
        $styleVal = $_COOKIE['mode'];
      }
    }
    isset($_COOKIE['theme']) ? $themeVal = $_COOKIE['theme'] : $themeVal = $data['myTheme'];
    //layout classes
    $layoutClasses = [
      'layout' => $data['myLayout'],
      'theme' => $themeVal,
      'themeOpt' => $data['myTheme'],
      'style' => $styleVal,
      'styleOpt' => $data['myStyle'],
      'rtlSupport' => $data['myRTLSupport'],
      'rtlMode' => $data['myRTLMode'],
      'textDirection' => $data['myRTLMode'],
      'menuCollapsed' => $data['menuCollapsed'],
      'hasCustomizer' => $data['hasCustomizer'],
      'showDropdownOnHover' => $data['showDropdownOnHover'],
      'displayCustomizer' => $data['displayCustomizer'],
      'contentLayout' => $data['contentLayout'],
      'headerType' => $data['headerType'],
      'navbarType' => $data['navbarType'],
      'menuFixed' => $data['menuFixed'],
      'footerFixed' => $data['footerFixed'],
      'menuFlipped' => $data['menuFlipped'],
      'customizerControls' => $data['customizerControls'],
    ];

    // sidebar Collapsed
    if ($layoutClasses['menuCollapsed'] == true) {
      $layoutClasses['menuCollapsed'] = 'layout-menu-collapsed';
    }

    // Header Type
    if ($layoutClasses['headerType'] == 'fixed') {
      $layoutClasses['headerType'] = 'layout-menu-fixed';
    }
    // Navbar Type
    if ($layoutClasses['navbarType'] == 'fixed') {
      $layoutClasses['navbarType'] = 'layout-navbar-fixed';
    } elseif ($layoutClasses['navbarType'] == 'static') {
      $layoutClasses['navbarType'] = '';
    } else {
      $layoutClasses['navbarType'] = 'layout-navbar-hidden';
    }

    // Menu Fixed
    if ($layoutClasses['menuFixed'] == true) {
      $layoutClasses['menuFixed'] = 'layout-menu-fixed';
    }


    // Footer Fixed
    if ($layoutClasses['footerFixed'] == true) {
      $layoutClasses['footerFixed'] = 'layout-footer-fixed';
    }

    // Menu Flipped
    if ($layoutClasses['menuFlipped'] == true) {
      $layoutClasses['menuFlipped'] = 'layout-menu-flipped';
    }

    // Menu Offcanvas
    // if ($layoutClasses['menuOffcanvas'] == true) {
    //   $layoutClasses['menuOffcanvas'] = 'layout-menu-offcanvas';
    // }

    // RTL Supported template
    if ($layoutClasses['rtlSupport'] == true) {
      $layoutClasses['rtlSupport'] = '/rtl';
    }

    // RTL Layout/Mode
    if ($layoutClasses['rtlMode'] == true) {
      $layoutClasses['rtlMode'] = 'rtl';
      $layoutClasses['textDirection'] = 'rtl';
    } else {
      $layoutClasses['rtlMode'] = 'ltr';
      $layoutClasses['textDirection'] = 'ltr';
    }

    // Show DropdownOnHover for Horizontal Menu
    if ($layoutClasses['showDropdownOnHover'] == true) {
      $layoutClasses['showDropdownOnHover'] = true;
    } else {
      $layoutClasses['showDropdownOnHover'] = false;
    }

    // To hide/show display customizer UI, not js
    if ($layoutClasses['displayCustomizer'] == true) {
      $layoutClasses['displayCustomizer'] = true;
    } else {
      $layoutClasses['displayCustomizer'] = false;
    }

    return $layoutClasses;
  }

  public static function updatePageConfig($pageConfigs)
  {
    $demo = 'custom';
    if (isset($pageConfigs)) {
      if (count($pageConfigs) > 0) {
        foreach ($pageConfigs as $config => $val) {
          Config::set('custom.' . $demo . '.' . $config, $val);
        }
      }
    }
  }

  public static function isActiveMenu($menu, $currentRouteName)
    {
        // Direct match
        if (isset($menu->slug)) {
            if (is_array($menu->slug)) {
                foreach ($menu->slug as $slug) {
                    if (str_starts_with($currentRouteName, $slug)) {
                        return true;
                    }
                }
            } else {
                if (str_starts_with($currentRouteName, $menu->slug)) {
                    return true;
                }
            }
        }

        // Recursive check for children
        if (isset($menu->submenu)) {
            foreach ($menu->submenu as $submenu) {
                if (self::isActiveMenu($submenu, $currentRouteName)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static function getMenuJson()
    {
        // Path to the JSON file (you can adjust it)
        $path = resource_path('menu/verticalMenu.json'); // e.g., resources/data/menu.json

        if (file_exists($path)) {
            $json = file_get_contents($path); // read file contents
            $data = json_decode($json, false); // decode JSON as object

            return $data->menu ?? []; // return menu array or empty array
        }

        return []; // fallback if file doesn't exist
    }

    function Logo_pic($pic)
    {
        if ($pic) {
            return url('logos/' . $pic);
        } else {
            return ""; // Return an empty string if no picture is provided
        }
    }

    function Fav_Icon_pic($pic)
    {
        if ($pic) {
            return url('fav_icons/' . $pic);
        } else {
            return ''; // Return an empty string if no picture is provided
        }
    }
    







    //   GET ROLE USRMANAGEMENT
    function get_roles_list()
    {
        // Fetch roles from the UserRoleModel
        $roles = UserRoleModel::where('status', 0)->get();

        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Filter roles to exclude those that are in userRolePermissions
        $filteredRoles = $roles->filter(function ($role) use ($userRolePermissions) {
            return !in_array($role->sno, $userRolePermissions); // Exclude roles with matching role_id
        });

        return $filteredRoles;
    }

   
    // Email Template
    function get_email_template($id = '')
    {
        $result = EmailTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_roles_list_nav($user_id = null)
    {
        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $matchingRoles = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();

        return $matchingRoles;
    }

    // common Date Format
    function general_setting_data()
    {
        $sno = 1;
        $result = GeneralSettingsModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    
    function encrypt_decrypt($string, $action = 'encrypt')
    {
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'RYANSINFRA'; // Change this to your secret key
        $secret_iv = 'ARAFNISNAYRABCDEFEGC46464566@#$%EGC'; // Change this to your secret IV
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } elseif ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        } else {
            $output = false;
        }

        return $output;
    }

    // Get Country Names by ID
    function get_country_data($id = '')
    {
        $result = CountryModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Get State Names by ID
    function get_state_data($id = '')
    {
        $result = StateModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Get City Names by ID
    function get_city_data($id = '')
    {
        $result = CityModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }


    // get Role list
    function get_role_list()
    {
        $result = UserRoleModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // get Role id
    function get_role_id($sno = "")
    {
        $result = UserRoleModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // get Staff by id
    function get_staff_data($id = '')
    {
        $result = StaffModel::where('ryans_staff.sno', $id)
            ->select(
                'ryans_staff.*',
                'ryans_department.department_name',
            )
            ->join('ryans_department', 'ryans_staff.department_id', 'ryans_department.sno')
            ->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Staff list
    function get_staff_list()
    {
        $result = StaffModel::where('status', 0)->orderBy('staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Name imgae user
    function name_image($ins = "A", $gender = 1)
    {
        // Array of all avatar divs
        if ($gender === 1) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-success'>" . $ins . "</span>
            </div>";
        } else if ($gender === 2) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-info'>" . $ins . "</span>
            </div>";
        } else {
            $divs = "<div class='avatar  me-2'>
              <span class='avatar-initial rounded-circle bg-label-warning'>" . $ins . "</span>
            </div>";
        }

        return $divs;
    }

    // Department List
    function get_department_list()
    {
        $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch time zone ID
    function get_time_zone_id($id = '')
    {
        $result = TimeZoneModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch currency format ID
    function get_currency_format_id($id = '')
    {
        $result = CurrencyFormatModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_department_id($id = '')
    {
        $result = DepartmentModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //position
    function get_position_id($id = '')
    {
        $result = JobRoleModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }


    // Document By id
    function get_document_id($id = '')
    {
        $result = DocumentTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    
    public function convertNumberToWords($number)
    {
        $words = [
            '0' => 'Zero',
            '1' => 'One',
            '2' => 'Two',
            '3' => 'Three',
            '4' => 'Four',
            '5' => 'Five',
            '6' => 'Six',
            '7' => 'Seven',
            '8' => 'Eight',
            '9' => 'Nine',
            '10' => 'Ten',
            '11' => 'Eleven',
            '12' => 'Twelve',
            '13' => 'Thirteen',
            '14' => 'Fourteen',
            '15' => 'Fifteen',
            '16' => 'Sixteen',
            '17' => 'Seventeen',
            '18' => 'Eighteen',
            '19' => 'Nineteen',
            '20' => 'Twenty',
            '30' => 'Thirty',
            '40' => 'Forty',
            '50' => 'Fifty',
            '60' => 'Sixty',
            '70' => 'Seventy',
            '80' => 'Eighty',
            '90' => 'Ninety'
        ];

        $suffixes = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];

        // For numbers less than 21, we can directly return the word.
        if ($number < 21) {
            return $words[$number];
        }

        // Handle numbers less than 100
        elseif ($number < 100) {
            $tens = floor($number / 10) * 10;
            $ones = $number % 10;
            return $words[$tens] . ($ones ? ' ' . $words[$ones] : '');
        }

        // Handle numbers less than 1000
        elseif ($number < 1000) {
            $hundreds = floor($number / 100);
            $remainder = $number % 100;
            $wordsString = $words[$hundreds] . ' ' . $suffixes[1];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the thousands range
        elseif ($number < 100000) {
            $thousands = floor($number / 1000);
            $remainder = $number % 1000;
            $wordsString = $this->convertNumberToWords($thousands) . ' ' . $suffixes[2];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the lakhs range
        elseif ($number < 10000000) {
            $lakhs = floor($number / 100000);
            $remainder = $number % 100000;
            $wordsString = $this->convertNumberToWords($lakhs) . ' ' . $suffixes[3];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the crores range
        elseif ($number < 1000000000) {
            $crores = floor($number / 10000000);
            $remainder = $number % 10000000;
            $wordsString = $this->convertNumberToWords($crores) . ' ' . $suffixes[4];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }
    }
    
    function log_json($label, $data)
    {
        \Log::info($label . ' : ' . json_encode($data, JSON_PRETTY_PRINT));
    }

}