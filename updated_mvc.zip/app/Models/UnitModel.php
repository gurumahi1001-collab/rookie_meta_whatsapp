<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class UnitModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_unit';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'unit_name',
        'created_by',
        'updated_by',
        'status',
    ];
}
