<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShiftTimeSettingsModel extends Model
{
    use HasFactory;
    public $table = "ryans_shift_time";
    public $primaryKey = 'sno';

    protected $fillable = [
        'shift_time_name	',
        'shift_start_time',
        'shift_end_time',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
