<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class MaterialTypeModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_material_type';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'material_type',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
