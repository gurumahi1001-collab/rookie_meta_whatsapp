<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class DesignationModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_designation';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'designation',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
