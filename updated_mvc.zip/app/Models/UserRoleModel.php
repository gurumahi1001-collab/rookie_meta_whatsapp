<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Ryan Infra user roles (ryans_user_role).
 *
 * The legacy application uses `sno` as the numeric role key assigned to
 * `users.role_id`; `role_id` is the human-readable role code.
 */
class UserRoleModel extends Model
{
    use HasFactory;

    protected $table = 'ryans_user_role';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'role_id',
        'role_name',
        'map_under',
        'user_role_id',
        'created_by',
        'updated_by',
        'status',
    ];

    protected $casts = [
        'sno' => 'integer',
        'map_under' => 'integer',
        'user_role_id' => 'integer',
        'created_by' => 'integer',
        'updated_by' => 'integer',
        'status' => 'integer',
    ];
}
