<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class BloodGroupModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_blood_group';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'blood_group_name',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
