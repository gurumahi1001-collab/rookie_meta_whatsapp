<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContractorSettingsModel extends Model
{
    use HasFactory;
    public $table = "ryans_contractor_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'contractor_type',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
