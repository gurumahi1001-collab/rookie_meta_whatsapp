<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\HR\StaffModel;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    public function staff()
    {
        return $this->belongsTo(StaffModel::class, 'user_id', 'sno');
    }
    public function roledetails()
     {
         return $this->belongsTo(UserRoleModel::class, 'role_id', 'sno');
     }
      public function rolepermisiion()
     {
         return $this->belongsTo(UserRolePermissionModel::class, 'role_id', 'sno');
     }

    /**
     * Return role permissions as an array regardless of whether the model
     * accessor returns raw JSON or permissions that have already been decoded.
     * This keeps compatibility with existing and legacy permission records.
     */
    private function rolePermissionsAsArray(): ?array
    {
        $rolePermissions = (new UserRolePermissionModel())->getPermissionsByRole($this->role_id);

        if (is_string($rolePermissions)) {
            $rolePermissions = json_decode($rolePermissions, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                \Log::warning('Unable to decode role permissions JSON', [
                    'role_id' => $this->role_id,
                    'json_error' => json_last_error_msg(),
                ]);
                return null;
            }
        } elseif ($rolePermissions instanceof \Illuminate\Contracts\Support\Arrayable) {
            $rolePermissions = $rolePermissions->toArray();
        }

        return is_array($rolePermissions) ? $rolePermissions : null;
    }

    public function hasPermission($menuName, $submenuName = null, $lastmenuName = null, $actionName = null)
    {
        $rolePermissions = $this->rolePermissionsAsArray();

        if (!is_array($rolePermissions)) {
            \Log::info('Role permissions not an array', ['role_id' => $this->role_id]);
            return false;
        }

        foreach ($rolePermissions as $menu) {
            if (($menu['menuName'] ?? null) === $menuName && ($menu['menuChecked'] ?? 0)) {

                // If only menu level check required
                if (!$submenuName) {
                    return true;
                }

                // Check submenu permissions
                foreach ($menu['submenu'] ?? [] as $submenu) {
                    $submenuChecked = $submenu['submenuChecked'] ?? 1;

                    if (($submenu['submenuName'] ?? null) === $submenuName && $submenuChecked) {

                        // If only submenu level check required
                        if (!$lastmenuName) {

                            // If an action is provided directly under the submenu,
                            // check that action instead of automatically allowing it.
                            if ($actionName) {
                                foreach ($submenu['actions'] ?? [] as $action) {
                                    if (($action['actionName'] ?? null) === $actionName) {
                                        return (int) ($action['actionChecked'] ?? 0) === 1;
                                    }
                                }

                                // Action was requested but not found
                                return false;
                            }

                            // No action requested = submenu permission check
                            return true;
                        }

                        // Check lastmenu permissions
                        foreach ($submenu['lastmenu'] ?? [] as $lastmenu) {
                            $lastmenuChecked = $lastmenu['lastmenuChecked'] ?? 1;

                            if (($lastmenu['lastmenuName'] ?? null) === $lastmenuName && $lastmenuChecked) {

                                // If only lastmenu level check required
                                if (!$actionName) {
                                    return true;
                                }

                                // Check action permissions
                                foreach ($lastmenu['actions'] ?? [] as $action) {
                                    $actionChecked = $action['actionChecked'] ?? 0;
                                    if (($action['actionName'] ?? null) === $actionName && $actionChecked) {
                                        return true;
                                    }
                                }
                                return false; // Action not allowed
                            }
                        }
                        return false; // Lastmenu not found or not allowed
                    }
                }
                return false; // Submenu not found or not allowed
            }
        }
        return false; // Menu not found or not allowed
    }



    public function hasPermissionradio($menuName, $submenuName, $radioValue)
    {
        // Accept either raw JSON or an array already decoded by the model.
        $rolePermissions = $this->rolePermissionsAsArray();

        if (!is_array($rolePermissions)) {
            throw new \Exception('Permissions data is not an array');
        }

        foreach ($rolePermissions as $menu) {
            if ($menu['menuName'] === $menuName && $menu['menuChecked']) {
                if (isset($menu['submenu']) && is_array($menu['submenu'])) {
                    foreach ($menu['submenu'] as $submenu) {
                        if ($submenu['submenuName'] === $submenuName && $submenu['submenuChecked']) {
                            if (isset($submenu['radios']) && is_array($submenu['radios'])) {
                                foreach ($submenu['radios'] as $radio) {
                                    if ($radio['radioValue'] === $radioValue && $radio['checked'] == 1) {
                                        return true; // Permission found
                                    }
                                }
                            }
                        }
                    }
                }


            }
        }

        return false; // Permission not found
    }
}
