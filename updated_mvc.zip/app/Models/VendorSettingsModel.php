<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VendorSettingsModel extends Model
{
    use HasFactory;
    public $table = "ryans_vendor_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'vendor_name',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
