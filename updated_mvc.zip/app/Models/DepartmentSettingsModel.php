<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepartmentSettingsModel extends Model
{
    use HasFactory;
    public $table = "ryans_department";
    public $primaryKey = 'sno';

    protected $fillable = [
        'department_name',
        'department_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
