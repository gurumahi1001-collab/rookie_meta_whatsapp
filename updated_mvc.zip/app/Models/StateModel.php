<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class StateModel extends Model
{
    use HasFactory;
    protected $table = 'ryans_states';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'country_id',
        'state_name',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
