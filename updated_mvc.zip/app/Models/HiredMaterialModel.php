<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class HiredMaterialModel extends Model
{
    use HasFactory;
    protected $table = 'rayans_hired_material';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = [
        'hired_material_name',
        'description',
        'created_by',
        'updated_by',
        'status',
    ];
}
