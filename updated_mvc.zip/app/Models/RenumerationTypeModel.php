<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RenumerationTypeModel extends Model
{
    use HasFactory;
    public $table = "ryans_renumeration_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'renumeration_name',
        'component_type',
        'renumeration_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
