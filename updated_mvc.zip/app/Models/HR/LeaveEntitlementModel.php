<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class LeaveEntitlementModel extends Model
{
    protected $table = 'ryans_leave_entitlements';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = true;
    protected $casts = ['annual_days' => 'decimal:2', 'year' => 'integer'];
}
