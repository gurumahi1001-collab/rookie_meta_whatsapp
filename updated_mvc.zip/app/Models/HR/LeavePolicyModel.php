<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

/** Leave policy applied when a new employee-specific anniversary cycle is initialized. */
class LeavePolicyModel extends Model
{
    protected $table = 'ryans_leave_policies';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $casts = [
        'employment_type' => 'integer',
        'annual_days' => 'decimal:2',
        'carry_forward_enabled' => 'boolean',
        'max_carry_forward_days' => 'decimal:2',
    ];
}
