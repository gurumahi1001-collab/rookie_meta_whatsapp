<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

/** Core staff record. Existing legacy columns retain their original meaning. */
class StaffModel extends Model
{
    protected $table = 'ryans_staff';
    protected $primaryKey = 'sno';
    protected $keyType = 'int';
    public $incrementing = true;
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $guarded = ['sno'];
}
