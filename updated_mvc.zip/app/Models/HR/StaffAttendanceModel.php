<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

/** Existing ryans_staff_attendance table plus additive GPS audit columns. */
class StaffAttendanceModel extends Model
{
    protected $table = 'ryans_staff_attendance';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $guarded = ['sno'];

    protected $casts = [
        'date' => 'date:Y-m-d',
        'check_in_latitude' => 'float',
        'check_in_longitude' => 'float',
        'check_in_accuracy_m' => 'float',
        'check_out_latitude' => 'float',
        'check_out_longitude' => 'float',
        'check_out_accuracy_m' => 'float',
    ];
}
