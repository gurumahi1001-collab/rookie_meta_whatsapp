<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClientModel extends Model
{
    use HasFactory;
    public $table = "ryans_clients";
    public $primaryKey = 'sno';

    protected $fillable = [
        'client_name',
        'client_code',
        'contact_person',
        'contact_no',
        'email_id',
        'alter_contact_person',
        'alter_contact_no',
        'country_id',
        'state_id',
        'city_id',
        'address',
        'gst_number',
        'pan_number',
        'upload_doc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',   
        'status',
    ];
}
