<?php

namespace App\Http\Controllers\settings;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Models\LanguageSettingModel;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LanguageSetting extends Controller
{
    public function index(Request $request)
    {
      $search = trim($request->input('search_filter', ''));
    $perPage = (int) $request->input('sorting_filter', 10);
    $perPage = max(1, min($perPage, 100));
    $countries = LanguageSettingModel::query()->where('status', '!=', 2)
        ->when($search !== '', function ($query) use ($search) {
            $query->where(function ($subquery) use ($search) {
                $subquery->where('name', 'LIKE', "%{$search}%");
            });
        })
        ->orderBy('sno', 'desc')->paginate($perPage)->appends($request->query());
    if ($request->ajax() || $request->expectsJson()) {
        $data = $countries->getCollection()->map(function ($item) {
            return [
                'sno' => $item->sno,
                'name' => $item->name,
                'status' => $item->status,
            ];
        })->values();
        return response()->json([
            'data' => $data,
            'current_page' => $countries->currentPage(),
            'last_page' => $countries->lastPage(),
            'total' => $countries->total(),
        ]);
    }

    return view('content.settings.common.language_setting', [
        'perpage' => $perPage,
        'search_filter' => $search,
        'categorylist' => $countries,
    ]);
}


    public function list(Request $request)
    {
        $perpage = (int) $request->input('sorting_filter', 10);
        $search = trim($request->input('search_filter', ''));

        $perpage = in_array($perpage, [5, 10, 25, 100])
            ? $perpage
            : 10;

        $query = LanguageSettingModel::query();

        if ($search !== '') {
            $query->where('name', 'like', "%{$search}%");
        }

        $languages = $query
            ->orderByDesc('sno')
            ->paginate($perpage);

        return response()->json([
            'data' => $languages->items(),
            'current_page' => $languages->currentPage(),
            'last_page' => $languages->lastPage(),
            'total' => $languages->total(),
        ]);
    }

   public function Add(Request $request)
{
    $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
            'errors' => $validator->errors(),
        ], 422);
    }

    $languageName = ucfirst(trim($request->name));

    $exists = LanguageSettingModel::whereRaw(
        'LOWER(name) = ?',
        [strtolower($languageName)]
    )
    ->where('status', '!=', 2)
    ->exists();

    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }

    $language = new LanguageSettingModel();
    $language->name = $languageName;
    $language->created_by = 1;
    $language->updated_by = 1;
    $language->status = 0;
    $language->save();

    return response()->json([
        'status' => 200,
        'message' => 'Language added successfully!',
    ]);
}

    public function edit($id)
    {
        $language = LanguageSettingModel::findOrFail($id);

        return response()->json([
            'status' => 200,
            'data' => $language,
        ]);
    }

   public function update(Request $request, $id)
{
    $validator = Validator::make($request->all(), [
        'name' => 'required|string|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => $validator->errors()->first(),
            'errors' => $validator->errors(),
        ], 422);
    }

    $language = LanguageSettingModel::where('sno', $id)
        ->where('status', '!=', 2)
        ->first();

    if (!$language) {
        return response()->json([
            'status' => 404,
            'message' => 'Language setting not found.',
        ], 404);
    }

    $languageName = ucfirst(trim($request->name));

    $exists = LanguageSettingModel::whereRaw(
        'LOWER(name) = ?',
        [strtolower($languageName)]
    )
        ->where('sno', '!=', $language->sno)
        ->where('status', '!=', 2)
        ->exists();

    if ($exists) {
        return response()->json([
            'status' => 200,
            'message' => 'Already Exist',
        ]);
    }

    $language->name = $languageName;
    $language->updated_by = 1;
    $language->save();

    return response()->json([
        'status' => 200,
        'message' => 'Language setting updated successfully!',
    ]);
}

    public function updateStatus(Request $request, $id)
    {
    $request->validate([
        'status' => 'required|in:0,1',
    ]);

    $country = LanguageSettingModel::where('sno', $id)->where('status', '!=', 2)->first();
    if (!$country) {
        return response()->json([
            'status' => 404,
            'message' => 'Country setting not found.',
        ], 404);
    }

    $country->status = (int) $request->status;
    $country->updated_by = 1;
    $country->save();

    return response()->json([
        'status' => 200,
        'message' => 'Language status updated successfully!',
    ]);
}
    public function destroy($id)
    {
        $language = LanguageSettingModel::findOrFail($id);
        $language->delete();

        return response()->json([
            'status' => 200,
            'message' => 'Language deleted successfully.',
        ]);
    }
}
