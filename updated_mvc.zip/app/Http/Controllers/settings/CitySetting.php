<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use App\Models\CityModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CitySetting extends Controller
{
    public function index(Request $request)
    {
        $search = trim($request->input('search_filter', ''));
        $perPage = (int) $request->input('sorting_filter', 10);
        $perPage = max(1, min($perPage, 500));
        $countries = CountryModel::where('status', 0)
            ->select('sno', 'country_name')
            ->orderBy('country_name', 'asc')
            ->get();

         $cities = CityModel::select('ryans_cities.*','ryans_states.state_name','ryans_countries.country_name','ryans_countries.sno as country_id')->where('ryans_cities.status', '!=', 2)
          ->join('ryans_states','ryans_states.sno','=','ryans_cities.state_id')
          ->join('ryans_countries','ryans_countries.sno','=','ryans_states.country_id');
          if ($search != '') {
              $cities->where(function ($subquery) use ($search) {
                  $subquery->where('ryans_cities.city_name', 'LIKE', "%{$search}%")
                      ->orWhere('ryans_cities.description', 'LIKE', "%{$search}%")
                      ->orWhere('ryans_states.state_name', 'LIKE', "%{$search}%")
                      ->orWhere('ryans_countries.country_name', 'LIKE', "%{$search}%");  
              });
          }
          $cities=$cities->orderBy('ryans_cities.sno', 'desc')->paginate($perPage);

          $helper = new \App\Helpers\Helpers();

          if ($request->ajax()) {
              $data = $cities->map(function ($item) {
                  return [
                      'sno' => $item->sno,
                      'status' => $item->status,
                      'city_name' => $item->city_name,
                      'state_name' => $item->state_name,
                      'state_id' => $item->state_id,
                      'country_id' => $item->country_id,
                      'country_name' => $item->country_name,
                      'description' => $item->description,
                  ];
              });

              return response()->json([
                  'data' => $data,
                  'current_page' => $cities->currentPage(),
                  'last_page' => $cities->lastPage(),
                  'total' => $cities->total(),
              ]);
          }

        return view('content.settings.common.city_setting', [
            'perpage' => $perPage,
            'search_filter' => $search,
            'categorylist' => $cities,
            'countries' => $countries,
        ]);
    }

   public function statesByCountry($countryId)
  {
      $countryExists = CountryModel::where('sno', $countryId)
          ->where('status', 0)
          ->exists();

      if (!$countryExists) {
          return response()->json([
              'status' => 404,
              'message' => 'Active country not found.',
              'data' => [],
          ], 404);
      }

      $states = StateModel::where('country_id', $countryId)
          ->where('status', 0)
          ->select('sno', 'country_id', 'state_name')
          ->orderBy('state_name', 'asc')
          ->get();

      return response()->json([
          'status' => 200,
          'message' => 'States fetched successfully.',
          'data' => $states,
      ]);
  }

    public function Add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'country_id' => ['required','integer','exists:ryans_countries,sno',],
            'state_id' => ['required','integer','exists:ryans_states,sno',],
            'city_name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }
        $countryExists = CountryModel::where('sno', $request->country_id)->where('status', 0)->exists();
        if (!$countryExists) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active country.',
                'errors' => [
                    'country_id' => ['Please select an active country.'],
                ],
            ], 422);
        }
        $state = StateModel::where('sno', $request->state_id)->where('country_id', $request->country_id)->where('status', 0)->first();
        if (!$state) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active state belonging to the selected country.',
                'errors' => [
                    'state_id' => ['Please select a valid state for this country.'],
                ],
            ], 422);
        }
        $cityName = ucfirst(trim($request->city_name));
        $exists = CityModel::where('state_id', $request->state_id)->whereRaw('LOWER(city_name) = ?', [strtolower($cityName)])->where('status', '!=', 2)->exists();
        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'This city already exists in the selected state.',
            ], 409);
        }
        $city = new CityModel();
        $city->country_id = $request->country_id;
        $city->state_id = $request->state_id;
        $city->city_name = $cityName;
        $city->description = $request->description;
        $city->created_by = 1;
        $city->updated_by = 1;
        $city->status = 0;
        $city->save();
        return response()->json([
            'status' => 200,
            'message' => 'City setting added successfully!',
        ]);
    }

    public function Edit($edit_id)
    {
        $city = CityModel::where('sno', $edit_id)
            ->where('status', '!=', 2)
            ->first();
        if (!$city) {
            return response()->json([
                'status' => 404,
                'message' => 'City setting not found.',
            ], 404);
        }

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $city,
        ]);
    }
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'edit_id' => 'required|integer',
            'country_id' => [
                'required',
                'integer',
                'exists:ryans_countries,sno',
            ],
            'state_id' => [
                'required',
                'integer',
                'exists:ryans_states,sno',
            ],
            'city_name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $city = CityModel::where('sno', $request->edit_id)
            ->where('status', '!=', 2)
            ->first();

        if (!$city) {
            return response()->json([
                'status' => 404,
                'message' => 'City setting not found.',
            ], 404);
        }

        $countryExists = CountryModel::where('sno', $request->country_id)
            ->where('status', 0)
            ->exists();

        if (!$countryExists) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active country.',
                'errors' => [
                    'country_id' => ['Please select an active country.'],
                ],
            ], 422);
        }

        // Validate the country/state relationship.
        $state = StateModel::where('sno', $request->state_id)
            ->where('country_id', $request->country_id)
            ->where('status', 0)
            ->first();

        if (!$state) {
            return response()->json([
                'status' => 422,
                'message' => 'Please select an active state belonging to the selected country.',
                'errors' => [
                    'state_id' => ['Please select a valid state for this country.'],
                ],
            ], 422);
        }

        $cityName = ucfirst(trim($request->city_name));

        // Exclude the current city when checking duplicates.
        $exists = CityModel::where('state_id', $request->state_id)
            ->whereRaw('LOWER(city_name) = ?', [strtolower($cityName)])
            ->where('sno', '!=', $city->sno)
            ->where('status', '!=', 2)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 409,
                'message' => 'This city already exists in the selected state.',
            ], 409);
        }

        $city->country_id = $request->country_id;
        $city->state_id = $request->state_id;
        $city->city_name = $cityName;
        $city->description = $request->description;
        $city->updated_by = 1;
        $city->save();

        return response()->json([
            'status' => 200,
            'message' => 'City setting updated successfully!',
        ]);
    }

    public function Status($id, Request $request)
    {
        $request->validate([
            'status' => 'required|in:0,1',
        ]);

        $city = CityModel::where('sno', $id)
            ->where('status', '!=', 2)
            ->first();

        if (!$city) {
            return response()->json([
                'status' => 404,
                'message' => 'City setting not found.',
            ], 404);
        }

        $city->status = (int) $request->status;
        $city->updated_by = 1;
        $city->save();

        return response()->json([
            'status' => 200,
            'message' => 'City status updated successfully!',
        ]);
    }

    public function Delete($id)
    {
        $city = CityModel::where('sno', $id)
            ->where('status', '!=', 2)
            ->first();

        if (!$city) {
            return response()->json([
                'status' => 404,
                'message' => 'City setting not found.',
            ], 404);
        }

        $city->status = 2;
        $city->updated_by = 1;
        $city->save();

        return response()->json([
            'status' => 200,
            'message' => 'City setting deleted successfully!',
        ]);
    }

    public function List(Request $request)
  {


      $stateId = $request->input('state_id');

      $city = CityModel::where('status', 0)->where('state_id', $stateId)
          ->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
}
