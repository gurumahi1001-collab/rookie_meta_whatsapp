<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MachineryType extends Controller
{
  public function index()
  {
    return view('content.settings.machinery.machinery_type');
  }
}
