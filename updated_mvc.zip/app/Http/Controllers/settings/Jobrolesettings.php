<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;

class Jobrolesettings extends Controller
{
    public function index()
    {
        return view('content.settings.adminhr.jobrole_setting');
    }
}
