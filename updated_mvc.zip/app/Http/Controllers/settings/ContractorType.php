<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\ContractorSettingsModel;

class ContractorType extends Controller
{
  
  public function index(Request $request)
    {
        
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $search_filter = $request->search_filter ?? '';

        $helper = new \App\Helpers\Helpers();

        $level = ContractorSettingsModel::where('ryans_contractor_type.status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('contractor_type', 'LIKE', "%{$search_filter}%");
              });
          }

          $level=$level->orderBy('sno', 'ASC')->paginate($perpage);

          if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {   
                return [
                    'sno' => $item->sno,
                    'contractor_type'=>$item->contractor_type,
                    'status' => $item->status,
                    'item' => $item,
               
                ];
            });
        
            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }


        return view('content.settings.site_log.contractor_setting', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function Add(Request $request)
    {
      $user_id = $request->user()->user_id ?? 1;
        $validator = Validator::make($request->all(), [
            'contractor_type' => 'required|max:255',
            
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $contractor_type = $request->input('contractor_type');
            
            $chk = ContractorSettingsModel::where('contractor_type', ucwords($contractor_type))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Vendor has been  already created!',
                ]);
            } else {
                $category_check = ContractorSettingsModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
                $add_category = new ContractorSettingsModel();
                $add_category->contractor_type = $contractor_type;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Vendor added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Vendor!',
                    ]);
                }
            }
            
            // return redirect()->back();
        }
    }

    public function View($id)
    {
        
        $data = ContractorSettingsModel::where('ryans_contractor_type.sno', $id)->first();
       
      if (!$data) { 
      return response([
        'status' => 404,
        'message' => 'Vendor not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }
        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $data,
        ], 200);
    }

    public function Update($id, Request $request)
    {

    $user_id = $request->user()->user_id ?? 1;
        $validator = Validator::make($request->all(), [
            'contractor_type' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $contractor_type = $request->input('contractor_type');            

            $upd_CourseCategoryModel = ContractorSettingsModel::where('sno', $id)->first();

             $chk = ContractorSettingsModel::where('contractor_type', ucwords($contractor_type))->where('status', '!=', 2)->where('sno', '!=', $id)->first();


            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Vendor has been already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->contractor_type = $contractor_type;
            $upd_CourseCategoryModel->updated_by = $user_id;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => $upd_CourseCategoryModel,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = ContractorSettingsModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {
        $upd_CourseCategoryModel = ContractorSettingsModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => $upd_CourseCategoryModel,
        ], 200);
    }

} 
