<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Ledger extends Controller
{
  public function index()
  {
    return view('content.settings.accounts.ledger');
  }
}
