<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CreditcardtypeSetting extends Controller
{
  public function index()
  {
    return view('content.settings.common.creditcardtype_setting');
  }

}
