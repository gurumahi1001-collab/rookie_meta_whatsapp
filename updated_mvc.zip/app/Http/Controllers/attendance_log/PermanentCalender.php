<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermanentCalender extends Controller
{
  public function calender ()
  {
    return view('content.admin_hr.attendance_log.permanent_calender');
  }
}
