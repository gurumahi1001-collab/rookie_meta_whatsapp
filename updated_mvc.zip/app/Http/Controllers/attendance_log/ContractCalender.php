<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ContractCalender extends Controller
{
  public function contract_calender ()
  {
    return view('content.admin_hr.attendance_log.contract_calender');
  }
}