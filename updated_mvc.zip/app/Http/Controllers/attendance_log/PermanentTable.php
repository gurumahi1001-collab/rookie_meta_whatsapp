<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermanentTable extends Controller
{
  public function table ()
  {
    return view('content.admin_hr.attendance_log.permanent_table');
  }
}
