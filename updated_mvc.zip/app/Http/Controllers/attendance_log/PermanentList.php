<?php

namespace App\Http\Controllers\attendance_log;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PermanentList extends Controller
{
  public function list ()
  {
    return view('content.admin_hr.attendance_log.permanent_list');
  }
}
