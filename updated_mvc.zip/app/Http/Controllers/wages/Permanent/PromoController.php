<?php

namespace App\Http\Controllers\wages\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PromoController extends Controller
{
  public function promo_controller ()
  {
    return view('content.admin_hr.wages.Permanent.promotion_permanent');
  }
}
