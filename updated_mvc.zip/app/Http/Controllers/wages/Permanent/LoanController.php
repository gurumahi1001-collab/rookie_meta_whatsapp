<?php

namespace App\Http\Controllers\wages\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoanController extends Controller
{
  public function ploan_controller ()
  {
    return view('content.admin_hr.wages.Permanent.loan_permanent');
  }
}
