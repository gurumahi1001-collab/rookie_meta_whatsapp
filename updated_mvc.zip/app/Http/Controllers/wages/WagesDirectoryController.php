<?php

namespace App\Http\Controllers\wages;

use App\Http\Controllers\Controller;
use App\Services\HR\WagesService;
use Illuminate\Http\Request;

class WagesDirectoryController extends Controller
{
    public function __construct(private WagesService $wagesService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate(['search' => ['nullable', 'string', 'max:120'], 'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100']]);
        $p = $this->wagesService->paginate($type, array_merge(['per_page' => 10], $filters));
        $data = $this->wagesService->enrichPage($p->items());
        return response()->json(['success' => true, 'data' => $data, 'meta' => ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()], 'summary' => $this->wagesService->dashboardSummary($type)]);
    }

    public function show(string $type, int $id)
    {
        return response()->json(['success' => true, 'data' => $this->wagesService->details($id, $type)]);
    }

    public function save(Request $request, string $type, int $id)
    {
        $data = $request->validate([
            'basic_salary' => ['nullable', 'numeric', 'min:0', 'max:999999999'], 'per_hour_cost' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'remuneration' => ['required', 'array'], 'remuneration.*.type_id' => ['required', 'integer', 'exists:ryans_renumeration_type,sno'],
            'remuneration.*.amount' => ['required', 'numeric', 'min:0', 'max:999999999'],
        ]);
        $this->wagesService->save($id, $type, $data, (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1))));
        return response()->json(['success' => true, 'message' => 'Wage structure saved.']);
    }
}
