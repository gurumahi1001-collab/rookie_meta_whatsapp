<?php

namespace App\Http\Controllers\wages\Contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoanContract extends Controller
{
  public function l_contract ()
  {
    return view('content.admin_hr.wages.Contract.loan_contract');
  }
}