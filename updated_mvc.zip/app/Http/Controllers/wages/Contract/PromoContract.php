<?php

namespace App\Http\Controllers\wages\Contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PromoContract extends Controller
{
  public function p_contract ()
  {
    return view('content.admin_hr.wages.Contract.promotion_contract');
  }
}