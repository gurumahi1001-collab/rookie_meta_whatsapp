<?php

namespace App\Http\Controllers\wages\Contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SalaryContract extends Controller
{
  public function s_contract ()
  {
    return view('content.admin_hr.wages.Contract.salary_contract');
  }
}
