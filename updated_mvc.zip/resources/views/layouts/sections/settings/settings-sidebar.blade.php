{{-- resources/views/partials/settings-sidebar.blade.php --}}

<div class="col-12 col-lg-3">
    <div class="card h-100">
        <div class="card-body p-2">

            <ul class="nav nav-pills flex-column w-100 gap-1 settings-nav">

                {{-- Country Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-common-setting') }}" class="nav-link {{ request()->routeIs('settings-common-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-earth fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Country Setting
                        </span>
                    </a>
                </li>


                {{-- State Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-state-setting') }}" class="nav-link {{ request()->routeIs('settings-state-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-map-marker-outline fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            State Setting
                        </span>
                    </a>
                </li>


                {{-- City Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-city-setting') ? route('settings-city-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-city-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-city-variant-outline fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            City Setting
                        </span>
                    </a>
                </li>


                {{-- Email Template --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-email-setting') ? route('settings-email-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-email-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-email-outline fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Email Template
                        </span>
                    </a>
                </li>


                {{-- Financial Year List --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-financial-setting') ? route('settings-financial-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-financial-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-calendar-range-outline fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Financial Year List
                        </span>
                    </a>
                </li>


                {{-- Credit Card --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-creditcard-setting') ? route('settings-creditcard-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-creditcard-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-credit-card-outline fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Credit Card
                        </span>
                    </a>
                </li>


                {{-- Credit Card Type --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-creditcardtype-setting') ? route('settings-creditcardtype-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-creditcardtype-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-credit-card-settings-outline fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Credit Card Type
                        </span>
                    </a>
                </li>


                {{-- Bank --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-bank-setting') ? route('settings-bank-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-bank-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-bank-outline fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Bank
                        </span>
                    </a>
                </li>


                {{-- Relation --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-relation-setting') ? route('settings-relation-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-relation-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-account-group-outline fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Relation
                        </span>
                    </a>
                </li>


                {{-- Language --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-language-setting') ? route('settings-language-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-language-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-translate fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Language
                        </span>
                    </a>
                </li>


                {{-- Course --}}
                <li class="nav-item w-100">
                    <a href="{{ Route::has('settings-course-setting') ? route('settings-course-setting') : 'javascript:void(0);' }}"
                        class="nav-link {{ request()->routeIs('settings-course-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-school-outline fs-5 flex-shrink-0"></i>
                        <span class="fw-semibold text-start">
                            Course
                        </span>
                    </a>
                </li>

                {{-- Brand Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-brand-setting') }}" class="nav-link {{ request()->routeIs('settings-brand-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-store-outline fs-4"></i>

                        <span class="fw-semibold text-start">
                            Brand Setting
                        </span>
                    </a>
                </li>

                {{-- Unit Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-unit-setting') }}" class="nav-link {{ request()->routeIs('settings-unit-setting') ? 'active' : 'text-muted' }}
                        d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-ruler-square fs-4"></i>

                        <span class="fw-semibold text-start">
                            Unit Setting
                        </span>
                    </a>
                </li>

                {{-- Company Mobile Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-companymobile-setting') }}" class="nav-link {{ request()->routeIs('settings-companymobile-setting') ? 'active' : 'text-muted' }}
                      d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-cellphone fs-5 flex-shrink-0"></i>

                        <span class="fw-semibold text-start">
                            Company Mobile
                        </span>
                    </a>
                </li>

                {{-- Company Mobile Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-document-setting') }}" class="nav-link {{ request()->routeIs('settings-document-setting') ? 'active' : 'text-muted' }}
                      d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">
                        <i class="mdi mdi-file-document-outline fs-4"></i>

                        <span class="fw-semibold text-start">
                            Document Type
                        </span>
                    </a>
                </li>
                {{-- Probation Period Setting --}}
                <li class="nav-item w-100">
                    <a href="{{ route('settings-probation-period') }}"
                    class="nav-link {{ request()->routeIs('settings-probation-period') ? 'active' : 'text-muted' }}
                    d-flex align-items-center justify-content-start w-100 gap-2 px-3 py-2 rounded text-start">

                        <i class="mdi mdi-calendar-clock-outline fs-4"></i>

                        <span class="fw-semibold text-start">
                            Probation Period
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>


<style>
/* ======= SETTINGS SIDEBAR - LIST FORMAT ====== */

.settings-sidebar {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    box-sizing: border-box;
}

/* UL */
.settings-sidebar ul {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}

/* LI */
.settings-sidebar ul li {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    margin: 0;
    padding: 0;

    list-style: none;
    box-sizing: border-box;
}

/* LINK */
.settings-sidebar ul li a {
    display: flex;
    align-items: center;

    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;

    padding: 8px 10px;
    gap: 8px;

    text-decoration: none;
    white-space: nowrap;

    overflow: hidden;
}

/* ICON */
.settings-sidebar ul li a i {
    flex: 0 0 18px;

    width: 18px;
    min-width: 18px;

    text-align: center;
}

/* TEXT */
.settings-sidebar ul li a span {
    flex: 1 1 auto;

    width: auto;
    min-width: 0;
    max-width: 100%;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;

    text-align: left;
}

/* ACTIVE */
.settings-sidebar ul li a.active {
    width: 100%;
    max-width: 100%;
}

/* CARD */
.settings-sidebar .card {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}

/* CARD BODY */
.settings-sidebar .card-body {
    width: 100%;
    max-width: 100%;
    min-width: 0;

    box-sizing: border-box;
}


/* ==========================================
   DESKTOP
========================================== */

@media (min-width: 992px) {

    .settings-sidebar {
        width: 100%;
        max-width: 100%;
        min-width: 0;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px;
    }
}


/* ========TABLET============= */

@media (max-width: 991.98px) {

    .settings-sidebar,
    .settings-sidebar .card,
    .settings-sidebar .card-body,
    .settings-sidebar ul,
    .settings-sidebar ul li,
    .settings-sidebar ul li a {
        width: 100%;
        max-width: 100%;
        min-width: 0;
    }
}


/* ==========================================
   MOBILE
========================================== */

@media (max-width: 575.98px) {

    .settings-sidebar .card-body {
        padding: 8px !important;
    }

    .settings-sidebar ul li a {
        padding: 8px 10px !important;
        gap: 6px !important;
    }

    .settings-sidebar ul li a i {
        flex: 0 0 18px;
        width: 18px;
        min-width: 18px;
    }

    .settings-sidebar ul li a span {
        font-size: 14px;
    }
}




/* =========================================================
   MOBILE SIDEBAR - HORIZONTAL SCROLL
   Existing desktop/tablet styles remain unchanged
   ========================================================= */

@media (max-width: 767.98px) {

    /* Sidebar column */
    .col-12.col-lg-3 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    /* Sidebar card */
    .settings-sidebar {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
        overflow: hidden !important;
    }

    .settings-sidebar .card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
        overflow: hidden !important;
    }

    /* Card body becomes horizontal scroll container */
    .settings-sidebar .card-body {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;

        overflow-x: auto !important;
        overflow-y: hidden !important;

        -webkit-overflow-scrolling: touch;

        scrollbar-width: thin;
        white-space: nowrap;
    }

    /* Keep the menu in one horizontal row */
    .settings-sidebar .settings-nav {
        display: flex !important;
        flex-direction: row !important;

        flex-wrap: nowrap !important;

        width: max-content !important;
        min-width: max-content !important;
        max-width: none !important;

        gap: 6px !important;
    }

    /* Each menu item keeps its natural width */
    .settings-sidebar .settings-nav .nav-item {
        flex: 0 0 auto !important;

        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;
    }

    /* Menu links */
    .settings-sidebar .settings-nav .nav-link {
        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;

        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;

        white-space: nowrap !important;

        padding: 8px 14px !important;
        gap: 7px !important;

        overflow: visible !important;
    }

    /* Icons */
    .settings-sidebar .settings-nav .nav-link i {
        flex: 0 0 auto !important;

        width: 18px !important;
        min-width: 18px !important;

        text-align: center;
    }

    /* Text */
    .settings-sidebar .settings-nav .nav-link span {
        flex: 0 0 auto !important;

        width: auto !important;
        max-width: none !important;
        min-width: max-content !important;

        white-space: nowrap !important;

        overflow: visible !important;
        text-overflow: unset !important;
    }

    /* Optional: make scrollbar less intrusive */
    .settings-sidebar .card-body::-webkit-scrollbar {
        height: 5px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-thumb {
        background: #b8b8b8;
        border-radius: 10px;
    }

    .settings-sidebar .card-body::-webkit-scrollbar-thumb:hover {
        background: #888;
    }
}
</style>
