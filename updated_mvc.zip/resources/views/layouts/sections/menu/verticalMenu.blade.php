@php
  $configData = Helper::appClasses();
  $currentRouteName = Route::currentRouteName();

  $menuJson  = File::get(resource_path('menu/verticalMenu.json'));
  $menuItems = json_decode(file_get_contents(resource_path('menu/verticalMenu.json')))->menu;
@endphp

@php
  $authStaffData =Auth::user()->staff;
@endphp

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme d-flex flex-column" style="background-color: #0F172B !important;">

  <!-- @if(!isset($navbarFull))
  <div class="app-brand demo m-2">
    <a href="{{ url('/dashboards') }}" class="app-brand-link">
      <img src="{{ asset('assets/img/Ryans-Logo.png') }}" class="app-brand-logo demo bg-white rounded p-2 ms-12" width="85" height="65" alt="Ryan Infra Logo">
     
    </a>
    <a href="javascript:;" class="layout-menu-toggle menu-link text-large ms-auto">
      <span class="mdi mdi-chevron-double-right text-white fs-3"></span>
    </a>
  </div>
  @endif -->
  @if(!isset($navbarFull))
  <div class="app-brand demo m-2">
    <a href="{{url('/dashboard')}}" class="app-brand-link ">
      <?php if (isset($logoUrl)): ?>
        <img id="logo-left" src="<?= $logoUrl ?>" class="app-brand-logo demo bg-white rounded p-2 ms-12" width="85" height="65" alt="Ryan Infra Logo">
        <!-- <img id="logo-left" src="" class="app-brand-logo demo" width="180px" height="50px" alt=" Logo"> -->
        <div class="app-brand-logo demo bg-white p-1 rounded" id="logo-right-container" style="display: none;">
            <img id="logo-right" src="<?= $favUrl ?>" class="app-brand-logo demo" width="45" alt="small logo" style="display: none;">
        </div>
        
      <?php else: ?>
        <img id="logo-left" src="{{ asset('assets/img/Ryans-Logo.png') }}" class="app-brand-logo demo bg-white rounded p-2 ms-12" width="85" height="65" alt="Ryan Infra Logo">
        <!-- <img id="logo-left" src="{{asset('assets/common/logo_full.png')}}" class="app-brand-logo demo" width="180px" height="50px" alt=" Logo"> src="https://ryansinfraui.client.elysiumproduct.com/assets/img/Ryans-Fav-icon.jpg" -->
        <div class="app-brand-logo demo bg-white p-1 rounded" id="logo-right-container" style="display: none;">
          <img id="logo-right" src="{{asset('assets/img/Ryans-Fav-icon.jpg')}}" class="app-brand-logo demo" width="45" alt="small logo" style="display: none;">
        </div>
      <?php endif; ?>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto me-2" style="  border: 2px solid rgba(255, 255, 255, 0.8);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.2);
      transition: all 0.3s ease;">
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.4854 4.88844C11.0081 4.41121 10.2344 4.41121 9.75715 4.88844L4.51028 10.1353C4.03297 10.6126 4.03297 11.3865 4.51028 11.8638L9.75715 17.1107C10.2344 17.5879 11.0081 17.5879 11.4854 17.1107C11.9626 16.6334 11.9626 15.8597 11.4854 15.3824L7.96672 11.8638C7.48942 11.3865 7.48942 10.6126 7.96672 10.1353L11.4854 6.61667C11.9626 6.13943 11.9626 5.36568 11.4854 4.88844Z" fill="#ffffff" />
        <path d="M15.8683 4.88844L10.6214 10.1353C10.1441 10.6126 10.1441 11.3865 10.6214 11.8638L15.8683 17.1107C16.3455 17.5879 17.1192 17.5879 17.5965 17.1107C18.0737 16.6334 18.0737 15.8597 17.5965 15.3824L14.0778 11.8638C13.6005 11.3865 13.6005 10.6126 14.0778 10.1353L17.5965 6.61667C18.0737 6.13943 18.0737 5.36568 17.5965 4.88844C17.1192 4.41121 16.3455 4.41121 15.8683 4.88844Z" fill="#ffffff" />
      </svg>
    </a>
  </div>
  @endif

  <ul class="menu-inner py-1 flex-grow-1 overflow-auto">
      @include('layouts.sections.menu.item', ['items' => $menuItems, 'depth' => 0])
  </ul>

  {{-- Role selector + profile footer (from Sidebar.tsx bottom section) --}}
  <div class="menu-footer border-top border-secondary p-3" style="background-color: rgba(2,6,23,.4);">

    <div class="d-flex align-items-center">
      <div class="avatar avatar-sm me-2 shrink-0">
        <img src="{{ $authStaffData ? ($authStaffData->staff_image ? url('/admin-hr/api/staff/' . $authStaffData->sno . '/photo') :  asset('assets/img/avatar/admin.png') ):  asset('assets/img/avatar/admin.png') }}" alt class="avatar-initial rounded-circle bg-label-primary">
       
      </div>
      <div class="d-menu-expanded-block text-truncate">
        <span class="d-block text-white fw-semibold small text-truncate">{{ Auth::user()->name ?? 'Super Admin' }}</span>
        <span class="d-block text-white-50 text-truncate" style="font-size: 10px;">{{ Auth::user()->email ?? 'superadmin@mail.com' }}</span>
      </div>
    </div>
  </div>

</aside>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    const html = document.documentElement;
    const toggleButton = document.querySelector('.layout-menu-toggle');
    const logoLeft = document.getElementById('logo-left'); // big
    const logoRight = document.getElementById('logo-right'); // small
    const logoRightContainer = document.getElementById('logo-right-container'); // small

    if (!logoLeft || !logoRight) return;

    // Decide which logo to show based on classes:
    // - if NOT collapsed -> big logo
    // - if collapsed AND hovered (layout-menu-hover) -> big logo
    // - if collapsed AND NOT hovered -> small logo
    function updateLogos() {
      const collapsed = html.classList.contains('layout-menu-collapsed');
      const hovered = html.classList.contains('layout-menu-hover');

      if (!collapsed) {
        // expanded -> show big
        logoLeft.style.display = 'block';
        logoRight.style.display = 'none';
        logoRightContainer.style.display = 'none';
      } else {
        // collapsed
        if (hovered) {
          // collapsed but hovered -> show big
          logoLeft.style.display = 'block';
          logoRight.style.display = 'none';
          logoRightContainer.style.display = 'none';
        } else {
          // collapsed and not hovered -> show small
          logoLeft.style.display = 'none';
          logoRight.style.display = 'block';
          logoRightContainer.style.display = 'block';
        }
      }
    }

    // Initial set
    updateLogos();

    // Toggle button may change classes after an animation; allow slight delay
    if (toggleButton) {
      toggleButton.addEventListener('click', function() {
        setTimeout(updateLogos, 120); // small delay to let template update classes
      });
    }

    // MutationObserver to watch for class changes on <html>
    const mo = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === 'attributes' && m.attributeName === 'class') {
          updateLogos();
          break;
        }
      }
    });

    mo.observe(html, {
      attributes: true,
      attributeFilter: ['class']
    });

    // Optional: clean up when page unloads
    window.addEventListener('beforeunload', () => mo.disconnect());
  });
</script>