@extends('layouts/layoutMaster')


@section('title', 'Vendor Type - Site Settings')


@section('content')


{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'site_log'])


{{-- ========================================================= --}}
{{-- Vendor Type Settings Main Content --}}
{{-- ========================================================= --}}


<div class="row g-4">


    {{-- ===================================================== --}}
    {{-- Left Area: Site Settings Sidebar --}}
    {{-- ===================================================== --}}


    @include('layouts.sections.settings.settings-site_sidebar')


    {{-- ===================================================== --}}
    {{-- Right Area: Main Settings Content --}}
    {{-- ===================================================== --}}


    <div class="col-12 col-md-8 col-lg-9">


        <div class="card">


            {{-- ================================================= --}}
            {{-- Card Header --}}
            {{-- ================================================= --}}


            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">


                <div class="d-flex align-items-center gap-3">


                    {{-- Vendor Icon --}}
                    <div
                        class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">


                        <i class="mdi mdi-storefront-outline fs-4 text-primary"></i>


                    </div>


                    {{-- Title --}}
                    <div>
                        <h5 class="mb-0 fw-bold">
                            Vendor Type
                        </h5>
                        <small class="text-muted">
                            Manage vendor types and their operating status
                        </small>
                    </div>
                </div>


                {{-- Create Button --}}
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#vendorTypeModal">


                    <i class="mdi mdi-plus fs-5"></i>


                    <span>
                        Create Vendor Type
                    </span>


                </button>


            </div>


            {{-- ================================================= --}}
            {{-- Card Body --}}
            {{-- ================================================= --}}
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <div>
                    <span>Show</span>
                    <select id="perpage" class="form-select form-select-sm w-75px"
                        onchange="loadThemes(1)">
                             @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                             <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                    </select>
                    </div>
                    <div class="col-12 col-md-6 col-lg-5 mt-4">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="search_filter" class="form-control"
                                placeholder="Search vendor" value="{{ $search_filter }}">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive rounded border">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr class="bg-light">
                                       <th class="min-w-50px">Vendor</th>
                                            <th class="min-w-100px">Status</th>
                                            <th class="min-w-100px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                        <tr class="skeleton-loader" id="skeleton-loader">
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                            <td class="skeleton-cell">
                                                <div class="skeleton"></div>
                                            </td>
                                           
                                        </tr> 
                                    </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
            </div>           


        </div>


    </div>


</div>



{{-- =========================================================
     Create Vendor Type Modal
     ========================================================= --}}


<div class="modal fade" id="vendorTypeModal" tabindex="-1" aria-labelledby="vendorTypeModalLabel" aria-hidden="true">


    <div class="modal-dialog modal-md modal-dialog-centered">


        <div class="modal-content">


            {{-- Modal Header --}}
            <div class="modal-header border-bottom">


                <h5 class="modal-title fw-bold" id="vendorTypeModalLabel">


                    Vendor Type


                </h5>


                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>


            </div>


            {{-- Form --}}
            <form action="{{ route('add_vendor_setting') }}" method="POST" enctype="multipart/form-data" autocomplete="off" id="addvendorsettingForm">


                @csrf


                {{-- Modal Body --}}
                <div class="modal-body">


                    <div class="row g-4">


                        {{-- Vendor Type --}}
                        <div class="col-12">


                            <label for="vendor_name" class="form-label fw-semibold">


                                Vendor Type
                                <span class="text-danger">*</span>


                            </label>


                            <input type="text" id="vendor_name" name="vendor_name" class="form-control"
                                placeholder="Enter vendor type" >
                                <div class="text-danger" id="vendor_name_err"></div>

                        </div>



                    </div>


                </div>


                {{-- Modal Footer --}}
                <div class="modal-footer border-top">


                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">


                        Cancel


                    </button>


                    <button type="button" class="btn btn-primary" id="savevendor" onclick="AddvalidationForm()">


                        <i class="mdi mdi-check me-1"></i>


                        Save Vendor Type


                    </button>


                </div>


            </form>


        </div>


    </div>


</div>


<!-- Edit vendor Modal -->
<div class="modal fade" id="editvendorModal" tabindex="-1"
     aria-labelledby="vendorModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <!-- Header -->
            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="vendorModalLabel">
                    Update Vendor Type
                </h5>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                </button>
            </div>

            <!-- Body -->
            <div class="modal-body">

                <input type="hidden" id="vendor_id">

                <div class="mb-3">
                    <label for="vendor" class="form-label">
                        Vendor Type <span class="text-danger">*</span>
                    </label>

                    <input type="text"
                           class="form-control"
                           id="edit_vendor_name"
                           name="edit_vendor_name"
                           placeholder="Enter vendor name"
                           >
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer">

                <button type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        class="btn btn-primary"
                        id="saveVendor" onclick="updatevendor()">

                    <i class="mdi mdi-content-save-outline me-1"></i>

                    <span id="savevendorText">
                        Update Vendor
                    </span>

                </button>

            </div>

        </div>
    </div>
</div>

{{-- =========================================================
     Delete Confirmation Modal
     ========================================================= --}}


<div class="modal fade" id="deleteVendorTypeModal" tabindex="-1" aria-labelledby="deleteVendorTypeModalLabel"
    aria-hidden="true">


    <div class="modal-dialog modal-sm modal-dialog-centered">


        <div class="modal-content">


            {{-- Modal Body --}}
            <div class="modal-body text-center py-4">


                <div
                    class="avatar bg-label-danger rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center">


                    <i class="mdi mdi-storefront-outline fs-3 text-danger"></i>


                </div>


                <h5 class="mb-2">
                    Are you sure?
                </h5>


                <p class="text-muted mb-0" id="delete_message">


                    You are about to delete
                    <strong>this vendor type</strong>.
                    This action cannot be undone.


                </p>


            </div>


            {{-- Modal Footer --}}
            <div class="modal-footer justify-content-center border-top">


                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">


                    Cancel


                </button>


                <button type="button" class="btn btn-danger" onclick="deletelevel()">


                    <i class="mdi mdi-delete-outline me-1"></i>


                    Delete


                </button>


            </div>


        </div>


    </div>


</div>


<!-- list Handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    

    let tableState = {
        currentPage: 1
    };

    function formatDate(date,generalDateFormat) {
        
        if (!date) return '';

        const parsedDate = date instanceof Date
            ? date
            : new Date(date);

        if (isNaN(parsedDate.getTime())) return '';

        const day = String(parsedDate.getDate()).padStart(2, '0');
        const month = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const year = parsedDate.getFullYear();

        const monthShort = parsedDate.toLocaleString('en-GB', {
            month: 'short'
        });

        const formats = {
            'd-m-Y': `${day}-${month}-${year}`,
            'Y-m-d': `${year}-${month}-${day}`,
            'Y/m/d': `${year}/${month}/${day}`,
            'd-M-Y': `${day}-${monthShort}-${year}`,
            'd/M/Y': `${day}/${monthShort}/${year}`
        };

        return formats[generalDateFormat] || formats['d-m-Y'];
    }

    function buildRow(item,index,common_date_format) {
        
        return `
            <tr>
                <td><label class="fs-7 fw-medium">${item.vendor_name}</label></td>               
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input" type="checkbox" id="RemunerationStatus1" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)">
                    </div>
                </td>
                <td>
                <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0" data-bs-toggle="modal"
                            data-bs-target="#editvendorModal" title="Edit" onclick="editmodel('${item.sno}')">
                    <i class="mdi mdi-pencil fs-5"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0" data-bs-toggle="modal"
                        data-bs-target="#deleteVendorTypeModal" onclick="confirmDelete('${item.sno}','${item.vendor_name}')">
                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                </button>
                </td>
                
            </tr>
        `;
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/vendor_settings?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1,res.common_date_format));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="3" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

</script>
<!-- list Handling End-->



<script>
        function editmodel(categoryId) {

            currentCategoryId = categoryId;
            fetch(`/vendor_edit/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const dept = data.data;

                        document.getElementById('edit_vendor_name').value = dept.vendor_name;
                                   
                    } else {
                        console.error('Error fetching vendor:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching vendor:', error);
                });
        }


        function updatevendor() {
            const id = currentCategoryId;
            const vendor_name = document.getElementById('edit_vendor_name').value;

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/vendor_update/${id}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        vendor_name: vendor_name,
                   

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        toastr.success('vendor Updated successfully!');
                         location.reload();
                    } else {
                        toastr.error('vendor Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating vendor:', error);

                });
        }

        document.getElementById('saveVendor').addEventListener('button', function(event) {
            event.preventDefault();
            updatevendor();
        });
</script>

<script>
    function updatelevelStatus(id, isChecked) {
        const reloadPage = tableState.currentPage;
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
            console.log(id);
            fetch(`/vendor_status/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('vendor status Updated successfully!');
                         loadThemes(reloadPage); 
                    } else {
                        console.error('Error updating vendor status:', data.message);
                        toastr.error('Failed to update vendor');
                    }
                })
                .catch(error => {
                    console.error('Error updating vendor status:', error);
                });
    }


        function confirmDelete(id, name) {
            document.querySelector('#deleteVendorTypeModal .btn-danger').setAttribute(
                'data-id', id);
            $('#delete_message').html('You want to delete <br> <b class="text-danger"> ' + name +
                '</b> Vendor ?');
        }

        function deletelevel() {

            var id = document.querySelector('#deleteVendorTypeModal .btn-danger').getAttribute('data-id');

            fetch('/delete_vendor/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Vendor Deleted successfully!');
                        location.reload();

                    } else {
                        toastr.error('Failed to Delete vendor');
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
</script>

<script>
    function AddvalidationForm() {
            let err=0;  
            var vendor_name=$('#vendor_name').val();
                       
            if(vendor_name == ""){
                $('#vendor_name_err').text('Vendor Name is required')
                err++
            }
            if (err>0){
            return false;
            }
            else{ 
                Addvendor();
            }
}

 
     function Addvendor() {
   
        const form = document.getElementById("addvendorsettingForm");
        
        const submitBtn = document.getElementById("saveVendor");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                 url: "{{ route('add_vendor_setting') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    toastr.success('Vendor Added successfully!');
                      location.reload();
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    toastr.error('Vendor Failed to Add!');
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

@endsection



@push('styles')


<style>
/* =========================================================
   Vendor Type Settings - Alignment
   ========================================================= */


.row {
    align-items: stretch;
}



/* =========================================================
   Settings Sidebar
   ========================================================= */


.settings-sidebar,
.settings-sidebar-wrapper {
    min-width: 0 !important;
    max-width: 100% !important;
}



/* =========================================================
   Main Content
   ========================================================= */


.col-12.col-md-8.col-lg-9 {
    min-width: 0 !important;
    display: flex;
    flex-direction: column;
}


.col-12.col-md-8.col-lg-9>.card {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
}



/* =========================================================
   Card Header
   ========================================================= */


.col-12.col-md-8.col-lg-9 .card-header {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    flex-wrap: wrap;
    gap: 1rem;
}


.col-12.col-md-8.col-lg-9 .card-header>div:first-child {
    display: flex !important;
    align-items: center !important;
    gap: 1rem !important;
    min-width: 0;
    flex: 1 1 auto;
}


.col-12.col-md-8.col-lg-9 .card-header .avatar {
    flex-shrink: 0 !important;
}


.col-12.col-md-8.col-lg-9 .card-header>div:first-child>div:last-child {
    min-width: 0;
}


.col-12.col-md-8.col-lg-9 .card-header h5 {
    margin-bottom: 0 !important;
    white-space: normal;
    overflow-wrap: anywhere;
}


.col-12.col-md-8.col-lg-9 .card-header small {
    display: block;
    white-space: normal;
    overflow-wrap: anywhere;
}



/* =========================================================
   Create Button
   ========================================================= */


.col-12.col-md-8.col-lg-9 .card-header>button {
    flex: 0 0 auto;
    white-space: nowrap;
}



/* =========================================================
   Card Body
   ========================================================= */


.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}



/* =========================================================
   Search
   ========================================================= */


.col-12.col-md-8.col-lg-9 .card-body>.row {
    width: 100%;
    align-items: center;
}


.col-12.col-md-8.col-lg-9 #tableSearch {
    width: 100%;
}



/* =========================================================
   Table
   ========================================================= */


.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
}


.col-12.col-md-8.col-lg-9 table {
    width: 100%;
}


.col-12.col-md-8.col-lg-9 table td:nth-child(2) {
    min-width: 0;
}


.col-12.col-md-8.col-lg-9 table td:nth-child(2) .fw-semibold {
    overflow-wrap: anywhere;
}



/* =========================================================
   Action Buttons
   ========================================================= */


.col-12.col-md-8.col-lg-9 table td:last-child {
    white-space: nowrap;
}



/* =========================================================
   Tablet
   ========================================================= */


@media (max-width: 991.98px) {


    .col-12.col-md-8.col-lg-9 .card-header {
        align-items: flex-start !important;
    }


}



/* =========================================================
   Mobile
   ========================================================= */


@media (max-width: 767.98px) {


    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header {
        display: flex !important;
        flex-direction: column !important;
        align-items: stretch !important;
        justify-content: flex-start !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        width: 100%;
        flex: 1 1 100%;
    }


    .col-12.col-md-8.col-lg-9 .card-header>button {
        width: 100%;
        flex: 1 1 100%;
        justify-content: center;
    }


    .col-12.col-md-8.col-lg-9 .card-body .row>div {
        width: 100%;
        max-width: 100%;
    }


    .col-12.col-md-8.col-lg-9 .table-responsive {
        width: 100%;
        overflow-x: auto;
    }


    .col-12.col-md-8.col-lg-9 table {
        min-width: 650px;
    }


}



/* =========================================================
   Very Small Screens
   ========================================================= */


@media (max-width: 320px) {


    .col-12.col-md-8.col-lg-9 .card-header {
        padding: .75rem !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header>div:first-child {
        gap: .5rem !important;
        align-items: flex-start !important;
    }


    .col-12.col-md-8.col-lg-9 .card-header h5 {
        font-size: .9rem;
    }


    .col-12.col-md-8.col-lg-9 .card-header small {
        font-size: .7rem;
        line-height: 1.3;
    }


    .col-12.col-md-8.col-lg-9 .card-header>button {
        font-size: .75rem;
        padding: .5rem;
    }


}



/* =========================================================
   Large Screens
   ========================================================= */


@media (min-width: 992px) {


    .col-12.col-md-8.col-lg-9 {
        min-width: 0 !important;
    }


    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }


}
</style>


@endpush
