@extends('layouts/layoutMaster')

@section('title', 'Material Type')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'purchase'])

<div class="row">

    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.purchase-settings-header')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-tools fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Material Type</h5>
                        <small class="text-muted">
                            Manage material type details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#addMaterialTypeModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Material Type</span>
                </button>
            </div>
            <div class="card-body p-3">
                {{-- Search --}}
                <div class="col-lg-12">
                    <<div class="row g-3 mb-2 justify-content-between align-items-center">
                    <div class="col-12">
                        <div class="d-flex align-items-center justify-content-between  ">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-2">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" id="search_filter" class="form-control"
                                        placeholder="Search Material Type..." />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="bankTable">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">Material Type</th>
                                <th class="text-nowrap">Description</th>
                                <th class="text-nowrap">Status</th>
                                <th class="text-end"> Actions </th>
                            </tr>
                        </thead>
                       <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
              </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addMaterialTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addMaterialTypeModalTitle">
                    Add Material Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
           <form id="categoryaddform_id">
              @csrf

              <div class="modal-body">
                  <div class="row g-3">
                      <div class="col-12">
                          <label for="category_name_id" class="form-label fw-semibold">
                              Material Type Name
                              <span class="text-danger">*</span>
                          </label>

                          <input
                              type="text"
                              id="category_name_id"
                              name="material_type"
                              class="form-control"
                              placeholder="Enter Material Type name"
                              required
                          >

                          <div class="text-danger" id="category_name_err"></div>
                      </div>

                      <div class="col-12">
                          <label for="description_id" class="form-label fw-semibold">
                              Description
                          </label>

                          <textarea
                              id="description_id"
                              name="description"
                              class="form-control"
                              rows="2"
                          ></textarea>
                      </div>
                  </div>
              </div>

              <div class="modal-footer border-top">
                  <button
                      type="button"
                      class="btn btn-outline-secondary"
                      data-bs-dismiss="modal"
                  >
                      Cancel
                  </button>

                  <button
                      type="button"
                      id="add_submit_btn"
                      class="btn btn-primary"
                      onclick="addValidateForm()"
                  >
                      <i class="mdi mdi-check me-1"></i>
                      Save Material Type
                  </button>
              </div>
          </form>


        </div>

    </div>

</div>

<div class="modal fade" id="editMaterialTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            {{-- Modal Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="addMaterialTypeModalTitle">
                    Update Material Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form action="{{route('material_settings.update')}}" method="POST" id="categoryeditForm" novalidate>
               @csrf
                <input type="hidden" id="edit_id" name="edit_id">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-12">
                            <label for="material_type" class="form-label fw-semibold">
                                Material Type Name
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" id="material_type" name="material_type" class="form-control" placeholder="Enter Material Type name"
                                required>
                             <div class="text-danger" id="category_name_edit_err"></div>
                        </div>
                        <div class="col-12 col-md-12">
                            <label for="ifsc_code" class="form-label fw-semibold">
                                Description
                            </label>
                            <textarea id="description_edit" name="description" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        <span id="">
                            Update Material Type
                        </span>

                    </button>

                </div>
            </form>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteMaterialTypeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold">
                    Delete Material Type
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-tools fs-3 text-danger"></i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong id="deleteBankName">
                        this Material Type
                    </strong>.
                    This action cannot be undone.
                </p>
            </div>

            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger me-3" onclick="deletelevel()">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



@push('styles')
<style>
/* =========================================================
   Bank Settings - Full Width + Zoom Safe
   ========================================================= */

/* Main content always uses available row width */
.col-12.col-md-8.col-lg-9 {
    min-width: 0;
    margin-left: 20%;
}


/* Desktop and above */
@media (min-width: 768px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        min-width: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
        min-width: 0 !important;
    }

}


/* Card */
.col-12.col-md-8.col-lg-9 .card {
    width: 100%;
    max-width: 100%;
}


/* Card body */
.col-12.col-md-8.col-lg-9 .card-body {
    width: 100%;
    min-width: 0;
}


/* Table container */
.col-12.col-md-8.col-lg-9 .table-responsive {
    width: 100%;
    max-width: 100%;
    min-width: 0;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}


/* Table */
.col-12.col-md-8.col-lg-9 #bankTable {
    width: 100%;
    min-width: 850px;
}


/* =========================================================
   Mobile
   ========================================================= */

@media (max-width: 767.98px) {

    .col-12.col-md-8.col-lg-9 {
        width: 100% !important;
        max-width: 100% !important;
        flex: 0 0 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .col-12.col-md-8.col-lg-9>.card {
        width: 100% !important;
        max-width: 100% !important;
    }

    .table-responsive {
        width: 100%;
        overflow-x: auto;
    }

}


/* =========================================================
   Small Mobile
   ========================================================= */

@media (max-width: 575.98px) {

    .col-12.col-md-8.col-lg-9 {
        padding-left: 0 !important;
        padding-right: 0 !important;
    }

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* =========================================================
   Modal - Zoom / Small Screen Safe
   ========================================================= */

.modal-dialog {
    max-width: calc(100% - 2rem);
}

.modal-content {
    width: 100%;
    max-width: 100%;
}


/* Modal form columns */
@media (max-width: 767.98px) {

    #addMaterialTypeModal .row.g-3>[class*="col-md-6"] {
        width: 100%;
    }

}


/* =========================================================
   Prevent flex children from creating unexpected width
   ========================================================= */

.row {
    min-width: 0;
}

.row>[class*="col-"] {
    min-width: 0;
}
</style>
@endpush
<!-- list page handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {
        return `<tr>
                          <td>
                      <span class="fw-bold text-heading">${item.material_type}</span>
                  </td>

                  <td>
                      <span class="text-truncate d-inline-block"
                            style="max-width:350px"
                            title="${item.description || '-' }">
                            ${item.description || '-'}
                      </span>
                  </td>

                  <td>
                      <div class="form-check form-switch mb-0">
                          <input class="form-check-input country-status"
                                  type="checkbox"
                                ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"">
                      </div>
                  </td>

                  <td class="text-end">
                      <div class="d-inline-flex gap-1">
                          <button
                              type="button"
                              class="btn btn-sm btn-icon btn-outline-secondary border-0"
                              data-bs-toggle="modal"
                              data-bs-target="#editMaterialTypeModal"
                              onclick="edit_vechicle_fetch_func(${item.sno})"
                              title="Edit">
                              <i class="mdi mdi-pencil-outline"></i>
                          </button>
                          <button
                              type="button"
                              class="btn btn-sm btn-icon btn-outline-danger border-0"
                              data-bs-toggle="modal"
                              data-bs-target="#deleteMaterialTypeModal"
                              onclick="confirmDelete('${item.sno}', '${item.material_type}')"
                              title="Delete">
                              <i class="mdi mdi-delete-outline"></i>
                          </button>
                      </div>
                  </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/material_type?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
                $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }
    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;

    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });


    // Initial load
    loadThemes(1);
</script>
<!-- list page handling End-->
<script>
   const editForm = document.getElementById('categoryeditForm');

if (editForm) {
    editForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const nameInput = document.getElementById('material_type');
        const descriptionInput = document.getElementById('description_edit');
        const errorElement = document.getElementById('category_name_edit_err');
        const submitBtn = editForm.querySelector('button[type="submit"]');

        const materialType = nameInput.value.trim();

        // Clear previous validation errors
        errorElement.textContent = '';
        nameInput.classList.remove('error_msg');

        if (!materialType) {
            errorElement.textContent = 'Material Type is required!';
            nameInput.classList.add('error_msg');
            nameInput.focus();
            return;
        }

        // Submit using AJAX
        submitBtn.disabled = true;

        fetch(editForm.action, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new FormData(editForm)
        })
        .then(async response => {
            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message || 'Unable to update Material Type.'
                );
            }

            return data;
        })
        .then(data => {
            if (data.message === 'Already Exist') {
                toastr.warning('Material Type already exists.');
                return;
            }

            if (data.status === 200) {
                toastr.success(data.message || 'Material Type updated successfully.');

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('editMaterialTypeModal')
                ).hide();

                loadThemes(1);
            } else {
                toastr.error(data.message || 'Unable to update Material Type.');
            }
        })
        .catch(error => {
            toastr.error(error.message || 'Something went wrong.');

            if (error.message.toLowerCase().includes('material type')) {
                errorElement.textContent = error.message;
                nameInput.classList.add('error_msg');
            }
        })
        .finally(() => {
            submitBtn.disabled = false;
        });
    });
}

// Clear validation errors while typing
document.getElementById('material_type')?.addEventListener('input', function () {
    if (this.value.trim()) {
        document.getElementById('category_name_edit_err').textContent = '';
        this.classList.remove('error_msg');
    }
});
</script>
<script>
            // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>
<script>
  function edit_vechicle_fetch_func(id) {
    fetch(`/material/edit/${id}`, {
        headers: {
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Unable to fetch material type.');
        }
        return response.json();
    })
    .then(data => {
        if (data.status !== 200) {
            throw new Error(data.message || 'Material type not found.');
        }

        const item = data.data;

        document.getElementById('edit_id').value = item.sno;
        document.getElementById('material_type').value = item.material_type || '';
        document.getElementById('description_edit').value = item.description || '';

        document.getElementById('category_name_edit_err').textContent = '';

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('editMaterialTypeModal')
        ).show();
    })
    .catch(error => {
        console.error('Edit error:', error);
        toastr.error(error.message || 'Unable to load material type.');
    });
}
let currentCategoryId;
function populateUpdateModal(id) {
    currentCategoryId = id;
    fetch(`/material/edit/${id}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                const vechicle = data.data;


                document.getElementById('edit_id').value = vechicle.sno;
                document.getElementById('description_edit').value = vechicle.description;
                document.getElementById('category_name_edit').value = vechicle.material_type;

            } else {
                console.error('Error fetching category:', data.message);
            }
        })
        .catch(error => {
            console.error('Error fetching category:', error);
        });
}
function updatelevelStatus(categoryId, isChecked) {
    const status = isChecked ? 0 : 1; // Set status based on checkbox state

    fetch(`/material/status/${categoryId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
            },
            body: JSON.stringify({
                status: status
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 200) {
                toastr.success('Material Type status Updated successfully!');
                  loadThemes(1);
            } else {
                console.error('Error updating Job Time status:', data.message);
            }
        })
        .catch(error => {
            console.error('Error updating Job Time status:', error);
        });
}
function confirmDelete(id, name) {
            document.querySelector('#deleteMaterialTypeModal .btn-danger').setAttribute('data-id', id);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Category ?');
  }

    function deletelevel() {

        var categoryId = document.querySelector('#deleteMaterialTypeModal .btn-danger').getAttribute('data-id');

        fetch('/material/delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Material Type Deleted successfully!');
                    location.reload();

                } else {

                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
function addValidateForm() {
    var err = 0;
    // Validate knowledge Name
    var category_name_id = document.getElementById("category_name_id").value.trim();
    var description_id = document.getElementById("description_id").value.trim();
    if (category_name_id === "") {
        document.getElementById('category_name_err').innerHTML = 'Material Type is required...!';
        document.getElementById('category_name_id').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('category_name_id').classList.remove('error_msg');
        document.getElementById('category_name_err').innerHTML = '';
    }
    if(err > 0){
      return false;
    }else{
      submit_form()
    }
    return err === 0;
}

    function submit_form() {
    const form = document.getElementById('categoryaddform_id');
    const submitBtn = document.getElementById('add_submit_btn');

    if (!form || !submitBtn) return;

    submitBtn.disabled = true;

    const formData = new FormData(form);

    $.ajax({
        url: "{{ route('material_settings.store') }}",
        method: "POST",
        data: formData,
        processData: false,
        contentType: false,

        success: function (response) {
            if (response.status === 200) {
                if (response.message === 'Already Exist') {
                    toastr.warning('Material Type already exists.');
                    submitBtn.disabled = false;
                    return;
                }

                toastr.success(response.message);
                window.location.reload();
            } else {
                toastr.error(response.message || 'Unable to save Material Type.');
                submitBtn.disabled = false;
            }
        },

        error: function (xhr) {
            submitBtn.disabled = false;

            if (xhr.status === 422) {
                const message =
                    xhr.responseJSON?.message ||
                    'Please check the required fields.';

                toastr.error(message);
            } else {
                toastr.error('Something went wrong while saving Material Type.');
                console.error(xhr.responseJSON || xhr.responseText);
            }
        }
    });
}
 </script>
  @endsection
