@extends('layouts/layoutMaster')

@section('title', 'City Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row">
    {{-- Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Main Content --}}
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">

            {{-- Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between gap-2 flex-wrap">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded">
                        <i class="mdi mdi-city fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">City Settings</h5>
                        <small class="text-muted">
                            Manage country, state and city configurations
                        </small>
                    </div>
                </div>

                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#citySettingModal" onclick="resetCityForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add City Setting</span>
                </button>
            </div>

            {{-- Body --}}
            <div class="card-body">

                {{-- Search --}}
                <div class="row mb-2">
                    <div class="col-12">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-2">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" id="search_filter" class="form-control"
                                        placeholder="Search country, state or city..." />
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>

                {{-- Table --}}
                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0" id="citySettingsTable">
                        <thead>
                            <tr class="bg-light">
                                <th class=" text-nowrap" style="">City</th>
                                <th class=" text-nowrap" style="">State</th>
                                <th class=" text-nowrap" style="">Country</th>
                                <th class="" style="">Description</th>
                                <th class="" style="">Status</th>
                                <th class=" text-end" style="width:100px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="list-table-body" class="table-border-bottom-0">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                        
                    </table>
                </div>

                <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
                </div>

            </div>
        </div>
    </div>
</div>


{{-- Add / Edit Modal --}}
<div class="modal fade" id="citySettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="cityModalTitle">City Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

             <form id="citySettingForm" action="{{ route('add_city_category') }}" method="POST" novalidate>
                @csrf

                <input type="hidden" id="edit_id" name="edit_id">

                <div class="modal-body">

                   <div class="mb-3">
                        <label for="country_id" class="form-label fw-semibold">
                            Country <span class="text-danger">*</span>
                        </label>

                        <select id="country_id"
                                name="country_id"
                                class="form-select select2"
                                required>
                            <option value="">Select a country</option>
                            @foreach ($countries as $country)
                                <option value="{{ $country->sno }}">
                                    {{ $country->country_name }}
                                </option>
                            @endforeach
                        </select>

                        <small id="country_id_err" class="text-danger"></small>
                    </div>

                     <div class="mb-3">
                        <label for="state_id" class="form-label fw-semibold">
                            State / Province <span class="text-danger">*</span>
                        </label>

                        <select id="state_id"
                                name="state_id"
                                class="form-select select2"
                                required
                                disabled>
                            <option value="">Select a country first</option>
                        </select>

                        <small id="state_id_err" class="text-danger"></small>
                    </div>
                      <div class="mb-3">
                        <label for="city_name" class="form-label fw-semibold">
                            City Name <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                               id="city_name"
                               name="city_name"
                               class="form-control"
                               placeholder="Enter city name"
                               maxlength="255"
                               required>

                        <small id="city_name_err" class="text-danger"></small>
                    </div>

                   <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">
                            Description
                        </label>

                        <textarea id="description"
                                  name="description"
                                  class="form-control"
                                  rows="3"
                                  placeholder="Enter description"></textarea>

                        <small id="description_err" class="text-danger"></small>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                      <button type="submit" id="saveCityButton" class="btn btn-primary">
                        <i class="mdi mdi-check"></i>
                        <span id="saveCityButtonText">Save Setting</span>
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>


{{-- Delete Modal --}}
<div class="modal fade" id="deleteCityModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">

            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                     style="width:56px;height:56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>

                <h6 class="fw-bold mb-1">Delete City Setting?</h6>
                <p class="text-muted text-xs mb-0" id="deleteCityMessage">
                    This action cannot be undone.
                </p>
            </div>

            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button"
                        class="btn btn-sm btn-outline-secondary px-3"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button"
                        id="confirmDeleteBtn"
                        class="btn btn-sm btn-danger px-3"
                        onclick="deleteCity()">
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>



<script>
    const CITY_CREATE_URL = @json(route('add_city_category'));
    const CITY_EDIT_URL = '/common/City_edit';
    const CITY_STATES_URL = '/common/states_by_country';
    const CITY_UPDATE_URL = @json(route('city_update_name'));
    const CITY_STATUS_URL = '/common/city_status';
    const CITY_DELETE_URL = '/common/city_delete';
    const CITY_CSRF_TOKEN = @json(csrf_token());

    let deleteCityId = null;

    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function resetCityForm() {
        const form = document.getElementById('citySettingForm');

        if (!form) {
            console.error('City form not found: #citySettingForm');
            return;
        }

        form.reset();

        const editId = document.getElementById('edit_id');
        const modalTitle = document.getElementById('cityModalTitle');
        const saveButtonText = document.getElementById('saveCityButtonText');

        if (editId) {
            editId.value = '';
        }

        if (modalTitle) {
            modalTitle.textContent = 'City Setting';
        }

        if (saveButtonText) {
            saveButtonText.textContent = 'Save Setting';
        }

        form.action = CITY_CREATE_URL;

        clearCityErrors();

        if ($('#country_id').length) {
            $('#country_id').val('').trigger('change.select2');
        }

        if (document.getElementById('state_id')) {
            setStatePlaceholder('Select a country first', true);
        }
    }

    function clearCityErrors() {
        ['country_id', 'state_id', 'city_name', 'description'].forEach(function (fieldName) {
            const field = document.getElementById(fieldName);
            const error = document.getElementById(`${fieldName}_err`);

            if (field) {
                field.classList.remove('is-invalid');
            }

            if (error) {
                error.textContent = '';
            }

            if (field && $(field).hasClass('select2-hidden-accessible')) {
                clearSelect2Invalid(field);
            }
        });
    }

    function clearSelect2Invalid(field) {
        $(field).next('.select2-container')
            .find('.select2-selection')
            .removeClass('is-invalid');
    }

    function buildRow(item, index) {
        const id = Number(item.sno);
        const country = escapeHtml(item.country_name ?? '');
        const state = escapeHtml(item.state_name ?? '');
        const city = escapeHtml(item.city_name ?? '');
        const description = escapeHtml(item.description == null || item.description === 0 || item.description === '0'? '': item.description);
        const active = Number(item.status) === 0;

        return `
                        
            <tr>
                <td class="text-nowrap fw-medium">${city}</td>
                <td class="text-nowrap">${state}</td>
                <td class="text-nowrap">
                    <span class="fw-semibold">${country}</span>
                </td>
                <td>
                    <span class="text-truncate d-inline-block"
                        style="max-width:200px"
                        title="${description}">
                        ${description || '-'}
                    </span>
                </td>
                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input city-status"
                            type="checkbox"
                            data-id="${id}"
                            ${active ? 'checked' : ''}
                            aria-label="Change status for ${city}"
                            onchange="updateCityStatus(${id}, this.checked, this)">
                    </div>
                </td>
                <td class="text-end">
                    <div class="d-inline-flex gap-1">
                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                onclick="editCity(${id})"
                                title="Edit">
                            <i class="mdi mdi-pencil-outline"></i>
                        </button>
                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-danger border-0"
                                onclick="confirmDeleteCity(${id}, '${city.replace(/'/g, '&#039;')}')"
                                title="Delete">
                            <i class="mdi mdi-delete-outline"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/city_settings?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="6" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);
</script>
<script>

    async function editCity(id) {
        try {
            const response = await fetch(`${CITY_EDIT_URL}/${id}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            });
            const result = await response.json();
            if (!response.ok || result.status !== 200) {
                throw new Error(
                    result.message || 'Unable to fetch city details.'
                );
            }
            const item = result.data;
            const form = document.getElementById('citySettingForm');
            clearCityErrors();
            document.getElementById('edit_id').value = item.sno;
            document.getElementById('city_name').value =
                item.city_name ?? '';
            document.getElementById('description').value =
                item.description ?? '';
            $('#country_id')
                .val(String(item.country_id))
                .trigger('change.select2');
            form.action = CITY_UPDATE_URL;
            document.getElementById('cityModalTitle').textContent ='Edit City Setting';
            document.getElementById('saveCityButtonText').textContent ='Update Setting';
            await loadStates(item.country_id, item.state_id);
            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('citySettingModal')
            ).show();
        } catch (error) {
            console.error('Edit city error:', error);
            toastr.error(error.message || 'Unable to open city settings.');
        }
    }

    function setStatePlaceholder(message, disabled = true) {
        const stateSelect = document.getElementById('state_id');
        stateSelect.innerHTML = '';
        const option = document.createElement('option');
        option.value = '';
        option.textContent = message;
        stateSelect.appendChild(option);
        stateSelect.disabled = disabled;
        $('#state_id').val('').trigger('change.select2');
    }

    async function loadStates(countryId, selectedStateId = '') {
        const stateSelect = document.getElementById('state_id');
        stateSelect.innerHTML = '<option value="">Loading states...</option>';
        stateSelect.disabled = true;
        $('#state_id').trigger('change.select2');
        if (!countryId) {
            stateSelect.innerHTML =
                '<option value="">Select a country first</option>';
            $('#state_id').val('').trigger('change.select2');
            return;
        }
        try {
            const response = await fetch(
                `${CITY_STATES_URL}/${encodeURIComponent(countryId)}`,
                {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json'
                    }
                }
            );
            if (!response.ok) {
                throw new Error(`Failed to load states: HTTP ${response.status}`);
            }
            const result = await response.json();
            const states = Array.isArray(result)? result: (result.data ?? result.states ?? []);
            stateSelect.innerHTML =
                '<option value="">Select a state</option>';

            states.forEach(item => {
                const option = document.createElement('option');
                option.value = item.sno ?? item.id;
                option.textContent = item.state_name ?? item.name ?? '';

                stateSelect.appendChild(option);
            });
            stateSelect.disabled = false;
            stateSelect.value = selectedStateId? String(selectedStateId): '';
            $('#state_id').trigger('change.select2');

        } catch (error) {
            console.error('Error loading states:', error);
            stateSelect.innerHTML ='<option value="">Unable to load states</option>';
            stateSelect.disabled = true;
            $('#state_id').val('').trigger('change.select2');
            toastr.error(error.message);
        }
    }

    function updateCityStatus(id, isChecked, checkbox) {
        const reloadPage = tableState.currentPage;
        const status = isChecked ? 0 : 1;
        checkbox.disabled = true;
        fetch(`${CITY_STATUS_URL}/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': CITY_CSRF_TOKEN,
                'Accept': 'application/json'
            },
            body: JSON.stringify({ status })
        })
        .then(async response => {
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Status update failed.');
            }

            return data;
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message || 'City status updated successfully.');
                loadThemes(reloadPage);
            } else {
                throw new Error(data.message || 'Unable to update city status.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error(error.message || 'Unable to update city status.');
            checkbox.checked = !isChecked;
        })
        .finally(() => {
            checkbox.disabled = false;
        });
    }
</script>



<!-- Delete Function -->
 <script>
    function confirmDeleteCity(id, name) {
        deleteCityId = id;
        document.getElementById('deleteCityMessage').textContent =`Delete "${name}"? This action cannot be undone.`;
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('deleteCityModal')
        ).show();
    }

    function deleteCity() {
        const reloadPage = tableState.currentPage;
        if (!deleteCityId) {
            toastr.error('No city selected.');
            return;
        }
        const button = document.getElementById('confirmDeleteBtn');
        button.disabled = true;
        fetch(`${CITY_DELETE_URL}/${deleteCityId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': CITY_CSRF_TOKEN,
                'Accept': 'application/json'
            }
        })
        .then(async response => {
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Delete request failed.');
            }

            return data;
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message || 'City deleted successfully.');
                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('deleteCityModal')
                ).hide();

                deleteCityId = null;
                loadThemes(reloadPage);
            } else {
                throw new Error(data.message || 'Unable to delete city.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error(error.message || 'Unable to delete city.');
        })
        .finally(() => {
            button.disabled = false;
        });
    }
</script>


<!-- add validate -->
<script>
    document.getElementById('citySettingForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const form = this;
        const submitButton = document.getElementById('saveCityButton');
        const country = document.getElementById('country_id');
        const state = document.getElementById('state_id');
        const city = document.getElementById('city_name');
        clearCityErrors();
        let valid = true;
        function setError(field, message) {
            document.getElementById(`${field.id}_err`).textContent = message;
            field.classList.add('is-invalid');

            if ($(field).hasClass('select2-hidden-accessible')) {
                $(field).next('.select2-container')
                    .find('.select2-selection')
                    .addClass('is-invalid');
            }

            valid = false;
        }
        if (!country.value) {
            setError(country, 'Please select a country.');
        }
        if (!state.value) {
            setError(state, 'Please select a state.');
        }
        if (!city.value.trim()) {
            setError(city, 'City name is required.');
        }
        if (!valid) return;
        city.value = city.value.trim();
        const isEdit = document.getElementById('edit_id').value !== '';
        const originalButtonHtml = submitButton.innerHTML;
        submitButton.disabled = true;
        submitButton.innerHTML ='<span class="spinner-border spinner-border-sm me-1"></span> Saving...';
        fetch(form.action, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: new FormData(form)
        })
        .then(async response => {
            const data = await response.json();

            if (response.status === 422) {
                const errors = data.errors || {};

                ['country_id', 'state_id', 'city_name', 'description'].forEach(fieldName => {
                    if (errors[fieldName]) {
                        const field = document.getElementById(fieldName);
                        setError(field, errors[fieldName][0]);
                    }
                });

                if (!Object.keys(errors).length) {
                    toastr.error(data.message || 'Please check the submitted values.');
                }

                return null;
            }

            if (!response.ok) {
                throw new Error(data.message || data.error_msg || 'Unable to save city setting.');
            }

            return data;
        })
        .then(data => {
            if (!data) return;

            if (data.status === 200 || data.success === true) {
                toastr.success(
                    data.message || (
                        isEdit
                            ? 'City setting updated successfully.'
                            : 'City setting added successfully.'
                    )
                );

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('citySettingModal')
                ).hide();

                resetCityForm();
                loadThemes(1);
            } else {
                toastr.error(data.message || 'Unable to save city setting.');
            }
        })
        .catch(error => {
            console.error('City save error:', error);
            toastr.error(error.message || 'Unable to save city setting.');
        })
        .finally(() => {
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonHtml;
        });
    });

    $('#country_id').on('change', function () {
        document.getElementById('country_id_err').textContent = '';
        this.classList.remove('is-invalid');
        clearSelect2Invalid(this);
        setStatePlaceholder('Select a country first', true);

        if (this.value) {
            loadStates(this.value);
        }
    });

    $('#state_id').on('change', function () {
        document.getElementById('state_id_err').textContent = '';
        this.classList.remove('is-invalid');
        clearSelect2Invalid(this);
    });

    document.getElementById('city_name').addEventListener('input', function () {
        document.getElementById('city_name_err').textContent = '';
        this.classList.remove('is-invalid');
    });

    document.getElementById('description').addEventListener('input', function () {
        document.getElementById('description_err').textContent = '';
        this.classList.remove('is-invalid');
    });

    document.getElementById('citySettingModal').addEventListener('hidden.bs.modal', resetCityForm);

   

   

</script>
<!-- edit Validate -->

@endsection