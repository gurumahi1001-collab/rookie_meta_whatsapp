@extends('layouts/layoutMaster')

@section('title', 'Relations - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- Relations Main Content --}}

<div class="row">

    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    {{-- Right Area: Main Relations Content --}}
    <div class="col-12 col-md-8 col-lg-9">

        <div class="card">

            {{-- Card Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">

                <div class="d-flex align-items-center gap-3">

                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-account-switch fs-4 text-primary"></i>
                    </div>

                    <div>
                        <h5 class="mb-0 fw-bold">Relations</h5>
                        <small class="text-muted">
                            Manage relation types and their status
                        </small>
                    </div>

                </div>

                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#relationModal">

                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Relation</span>

                </button>

            </div>


            {{-- Card Body --}}
            <div class="card-body pt-4">

                {{-- Search --}}
                <div class="row g-3 mb-2 justify-content-between align-items-center">
                    <div class="col-12">
                        <div class="d-flex align-items-center justify-content-between  ">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-2">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" id="search_filter" class="form-control"
                                        placeholder="Search RelationShip..." />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- Relations Table --}}
                <div class="table-responsive text-nowrap rounded border">

                    <table class="table table-hover align-middle mb-0">

                        <thead class="table-light">

                            <tr class="bg-light">
                                <th> Relation </th>
                                <th> Status </th>
                                <th class="text-end">
                                    Actions</th>
                            </tr>
                        </thead>
                        <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                              <tr class="skeleton-loader" id="skeleton-loader">
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                                  <td class="skeleton-cell">
                                      <div class="skeleton"></div>
                                  </td>
                              </tr>
                          </tbody>

                    </table>

                </div>
                <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
              </div>
            </div>

        </div>

    </div>

</div>


{{-- ========================================================= --}}
{{-- Add / Edit Relation Modal --}}
{{-- ========================================================= --}}
<div class="modal fade" id="relationModal" tabindex="-1" aria-labelledby="relationModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="relationModalTitle">
                    Relation
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>
            <form  id="relationSettingForm"  action="{{ route('add_relation_category') }}" method="POST" novalidate>
               @csrf
                  <input type="hidden" id="edit_id" name="edit_id">
                <div class="modal-body text-start">
                    <div class="mb-3">
                        <label for="relation" class="form-label fw-semibold">
                            Relation
                            <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="relationship_name" name="relationship_name" class="form-control"
                            placeholder="Enter relation" required>
                        <div id="relationship_name_err" class="invalid-feedback"></div>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit"
                            id="add_submit_btn"
                            class="btn btn-primary d-flex align-items-center gap-1">
                        <i class="mdi mdi-check"></i>
                        <span id="relationSubmitText">Save Relation</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteRelationModal" tabindex="-1"
     aria-labelledby="deleteRelationModalTitle" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">

            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3
                            d-flex align-items-center justify-content-center"
                     style="width:56px;height:56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>

                <h6 class="fw-bold mb-1" id="deleteRelationModalTitle">
                    Delete Relation?
                </h6>

                <p class="text-muted text-sm mb-0" id="deleteRelationMessage">
                    This action cannot be undone.
                </p>
            </div>

            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary"
                        data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" id="confirmDeleteBtn"
                        class="btn btn-sm btn-danger"
                        onclick="deleteRelation()">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>

        </div>
    </div>
</div>

<style>
/* Main Content */
.relations-main-content {
    width: 100%;
    max-width: 100%;
}


/* Table */
.table-responsive {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
}


.table-responsive table {
    width: 100%;
    min-width: 600px;
}


/* Mobile */
@media (max-width: 767.98px) {

    .card-header {
        align-items: flex-start !important;
    }

    .card-header>div:first-child {
        width: 100%;
    }

    .card-header>button {
        width: 100%;
        justify-content: center;
    }

}


/* Small Mobile */
@media (max-width: 575.98px) {

    .card-body {
        padding-left: 1rem;
        padding-right: 1rem;
    }

    .modal-dialog {
        margin: .75rem;
    }

}
</style>
</style>

 

    <!-- list page handling start-->
<script>
    const RELATION_CREATE_URL = @json(route('add_relation_category'));
    const RELATION_EDIT_URL = '/common/relation/ship_edit';
    const RELATION_UPDATE_URL = @json(route('common_relation_name'));
    const RELATION_STATUS_URL = '/common/relation/ship/status';
    const RELATION_DELETE_URL = '/common/relation/ship_delete';
    const RELATION_CSRF_TOKEN = @json(csrf_token());
    let abortController = new AbortController();
    let currentPage = 1;

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {
        let relationSearchTimer = null;
        let deleteRelationId = null;
        const id = Number(item.sno);
        const name = escapeHtml(item.relationship_name);
        const active = Number(item.status) === 0;

        let isLoading = false;


           return `
         <tr>
              <td>
                  <span class="fw-bold text-heading">
                     ${name}
                  </span>
              </td>
              <td>
               <div class="form-check form-switch mb-0">
                <input class="form-check-input country-status"
                      type="checkbox"
                      data-id="${id}"
                      ${active ? 'checked' : ''}
                      aria-label="Change status for ${name}"
                      onchange="updateRelationStatus(${id}, this.checked, this)">
            </div>
            </td>

            <td class="text-end">
                <div class="d-inline-flex gap-1">
                    <button type="button"
                            class="btn btn-sm btn-icon btn-outline-secondary border-0"
                            onclick="editRelation(${id})"
                            title="Edit">
                        <i class="mdi mdi-pencil-outline"></i>
                    </button>

                    <button type="button"
                            class="btn btn-sm btn-icon btn-outline-danger border-0"
                           onclick="confirmDeleteRelation(${id})"
                            title="Delete">
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </div>
            </td>
          </tr>
    `;
}

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/relation_settings?page=${page}&sorting_filter=${perpage}&search_filter=${encodeURIComponent(search)}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;

    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });


    // Initial load
    loadThemes(1);
</script>
<!-- list page handling End-->

<script>
function resetRelationForm() {
    const form = document.getElementById('relationSettingForm');
    const editId = document.getElementById('edit_id');
    const nameField = document.getElementById('relationship_name');
    const errorElement = document.getElementById('relationship_name_err');
    const modalTitle = document.getElementById('relationModalTitle');
    const submitText = document.getElementById('relationSubmitText');
    const submitButton = document.getElementById('add_submit_btn');
    if (!form) return;
    form.reset();
    if (editId) editId.value = '';
    if (errorElement) errorElement.textContent = '';
    if (nameField) {
        nameField.classList.remove('is-invalid');
    }
    if (modalTitle) {
        modalTitle.textContent = 'Relation Setting';
    }
    if (submitText) {
        submitText.textContent = 'Save Relation';
    }
    if (submitButton) {
        submitButton.disabled = false;
    }
    form.action = RELATION_CREATE_URL;
}
async function editRelation(id) {
    try {
        const response = await fetch(`${RELATION_EDIT_URL}/${id}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        });

        const result = await response.json();

        if (!response.ok || result.status !== 200 || !result.data) {
            throw new Error(result.message || 'Unable to fetch relation details.');
        }

        const item = result.data;
        const form = document.getElementById('relationSettingForm');

        resetRelationForm();

        document.getElementById('edit_id').value = item.sno;
        document.getElementById('relationship_name').value =
            item.relationship_name ?? '';

        form.action = RELATION_UPDATE_URL;

        document.getElementById('relationModalTitle').textContent = 'Edit Relation';
        document.getElementById('relationSubmitText').textContent = 'Update Relation';

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('relationModal')
        ).show();

    } catch (error) {
        console.error('Edit relation error:', error);
        toastr.error(error.message || 'Unable to open relation settings.');
    }
}
</script>

    <!-- status Change -->
 <script>
    function updateRelationStatus(id, isChecked, checkbox) {
    const previousChecked = !isChecked;
    checkbox.disabled = true;

    fetch(`${RELATION_STATUS_URL}/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': RELATION_CSRF_TOKEN,
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            status: isChecked ? 0 : 1
        })
    })
    .then(async response => {
        const data = await response.json();

        if (!response.ok || data.status !== 200) {
            throw new Error(data.message || 'Unable to update relation status.');
        }

        toastr.success(data.message || 'Relation status updated successfully.');
        loadThemes(currentPage);
    })
    .catch(error => {
        console.error('Relation status error:', error);
        checkbox.checked = previousChecked;
        toastr.error(error.message || 'Unable to update relation status.');
    })
    .finally(() => {
        checkbox.disabled = false;
    });
}
</script>

<!-- Delete Function -->
<script>
     function confirmDeleteRelation(id) {
    deleteRelationId = id;

    document.getElementById('deleteRelationMessage').textContent =
        'This action cannot be undone.';

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById('deleteRelationModal')
    ).show();
}

async function deleteRelation() {
    if (!deleteRelationId) {
        toastr.error('No relation selected.');
        return;
    }

    const button = document.getElementById('confirmDeleteBtn');
    button.disabled = true;

    try {
        const response = await fetch(`${RELATION_DELETE_URL}/${deleteRelationId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': RELATION_CSRF_TOKEN,
                'Accept': 'application/json'
            }
        });

        const data = await response.json();

        if (!response.ok || data.status !== 200) {
            throw new Error(data.message || 'Unable to delete relation.');
        }

        toastr.success(data.message || 'Relation deleted successfully.');

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('deleteRelationModal')
        ).hide();

        deleteRelationId = null;
        await loadThemes(1);

    } catch (error) {
        console.error('Delete relation error:', error);
        toastr.error(error.message || 'Unable to delete relation.');
    } finally {
        button.disabled = false;
    }
}

</script>

<!-- add validate -->
 <script>
 document.getElementById('relationSettingForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const form = this;
    const submitButton = document.getElementById('add_submit_btn');
    const submitText = document.getElementById('relationSubmitText');
    const nameField = document.getElementById('relationship_name');
    const errorElement = document.getElementById('relationship_name_err');

    errorElement.textContent = '';
    nameField.classList.remove('is-invalid');

    const name = nameField.value.trim();

    if (!name) {
        errorElement.textContent = 'Relation name is required.';
        nameField.classList.add('is-invalid');
        nameField.focus();
        return;
    }

    nameField.value = name;

    const isEdit = document.getElementById('edit_id').value !== '';
    const originalText = submitText.textContent;

    submitButton.disabled = true;
    submitText.textContent = isEdit ? 'Updating...' : 'Saving...';

    try {
        const response = await fetch(form.action, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: new FormData(form)
        });

        const data = await response.json();

        if (response.status === 422) {
            errorElement.textContent =
                data.errors?.relationship_name?.[0] ||
                data.message ||
                'Please check the relation name.';

            nameField.classList.add('is-invalid');
            return;
        }

        if (!response.ok || data.status !== 200) {
            throw new Error(data.message || 'Unable to save relation.');
        }

        // The controller currently returns status 200 with "Already Exist".
        if ((data.message || '').toLowerCase() === 'already exist') {
            errorElement.textContent = 'This relation already exists.';
            nameField.classList.add('is-invalid');
            return;
        }

        toastr.success(
            data.message ||
            (isEdit ? 'Relation updated successfully.' : 'Relation added successfully.')
        );

        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('relationModal')
        ).hide();

        resetRelationForm();
        await loadThemes(1);

    } catch (error) {
        console.error('Relation save error:', error);
        toastr.error(error.message || 'Unable to save relation.');
    } finally {
        submitButton.disabled = false;
        submitText.textContent = originalText;
    }
});

// Clear validation when the user starts typing.
document.getElementById('relationship_name').addEventListener('input', function () {
    document.getElementById('relationship_name_err').textContent = '';
    this.classList.remove('is-invalid');
});

// Reset the form whenever the modal closes.
document.getElementById('relationModal').addEventListener(
    'hidden.bs.modal',
    resetRelationForm
);


 </script>
  <!-- edit Validate -->
@endsection
