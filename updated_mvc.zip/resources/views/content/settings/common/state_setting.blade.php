@extends('layouts/layoutMaster')

@section('title', 'State Settings - Common Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- State Settings Main Content Card --}}
<div class="row g-4">
    {{-- Left Area: Settings Sidebar --}}
    @include('layouts.sections.settings.settings-sidebar')

    <!-- Right Area: Main Settings Content & Table -->
    <div class="col-12 col-md-8 col-lg-9">
        <div class="card">
            {{-- Card Header --}}
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2 text-start">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-map-marker-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">State Settings</h5>
                        <small class="text-muted">Manage state and province rules mapped to configured countries</small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#stateSettingModal" onclick="resetForm()">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add State Setting</span>
                </button>
            </div>

            {{-- Card Body --}}
            <div class="card-body pt-4">

                {{-- Search & Filter Toolbar --}}
                <div class="row g-3 mb-2 ">
                    <div class="col-12 ">
                        <div class="d-flex gap-2 justify-content-between align-items-center">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="row mt-4">
                                <div class="col-5">
                                    <select class="form-select select3 mt-4" id="filterCountry"  onchange="loadThemes(1)">
                                        <option value="">All Countries</option>
                                        @foreach ($countries as $country)
                                            <option value="{{ $country->sno }}">
                                                {{ $country->country_name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-7">
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                        <input type="text" id="search_filter" class="form-control"
                                            placeholder="Search state, country, or description..." />
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>

                {{-- Data Table --}}
                <div class="table-responsive text-nowrap rounded border">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr class="bg-light">
                                <th>State / Province</th>
                                <th>Country</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="list-table-body" class="table-border-bottom-0">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>

            </div>
        </div>
    </div>
</div>

{{-- Add / Edit State Setting Modal --}}

<div class="modal fade" id="stateSettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="StateModalTitle">State Setting</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

           <form id="StateSettingForm" action="{{ route('add_state_category') }}" method="POST" novalidate>
                @csrf
                <input type="hidden" id="edit_id" name="edit_id" value="">

                <div class="modal-body text-start">
                   <div class="mb-3">
                    <label for="country_id" class="form-label fw-semibold">
                        Country <span class="text-danger">*</span>
                    </label>

                    <select id="country_id" name="country_id" class="form-select select3" required>
                        <option value="">Select a country</option>
                        @foreach ($countries as $country)
                            <option value="{{ $country->sno }}">
                                {{ $country->country_name }}
                            </option>
                        @endforeach
                    </select>

                    <small id="country_id_err" class="text-danger"></small>
                </div>
                    <div class="mb-3">
                        <label for="State_name" class="form-label fw-semibold">
                            State Name <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                              id="State_name"
                              name="state_name"
                              class="form-control"
                              placeholder="Enter State Name"
                              required>

                        <small id="State_name_err" class="text-danger"></small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">
                            Description
                        </label>

                        <textarea id="description"
                                  name="description"
                                  class="form-control"
                                  rows="3"
                                  placeholder="Enter description"></textarea>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button"
                            class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit"
                            id="add_submit_btn"
                            class="btn btn-primary">
                        <i class="mdi mdi-check"></i>
                        <span>Save Setting</span>
                    </button>
                </div>
        </form>
        </div>
    </div>
</div>

{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteStateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete State Setting?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmDeleteBtn" class="btn btn-sm btn-danger px-3" onclick="deleteFunc()">Delete</button>
            </div>
        </div>
    </div>
</div>





<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {
        const id = Number(item.sno);
        const name = escapeHtml(item.state_name);
        const country_name = escapeHtml(item.country_name);
        const description = escapeHtml(item.description ?? '');
        const active = Number(item.status) === 0;

        return `
            <tr>
                <td>
                    <span class="fw-bold text-heading">${name}</span>
                </td>
                <td>
                    <span class="fw-bold text-heading">${country_name}</span>
                </td>
                

                <td>
                    <span class="text-truncate d-inline-block"
                        style="max-width:350px"
                        title="${description}">
                        ${description || '-'}
                    </span>
                </td>

                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input State-status"
                            type="checkbox"
                            data-id="${id}"
                            ${active ? 'checked' : ''}
                            aria-label="Change status for ${name}"
                            onchange="updatelevelStatus(${id}, this.checked)">
                    </div>
                </td>

                <td class="text-end">
                    <div class="d-inline-flex gap-1">
                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                onclick="editState(${id})"
                                title="Edit">
                            <i class="mdi mdi-pencil-outline"></i>
                        </button>

                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-danger border-0"
                                onclick="confirmDelete(${id}, '${name}', '')"
                                title="Delete">
                            <i class="mdi mdi-delete-outline"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const filterCountry = document.getElementById('filterCountry').value;

        const url = `/settings/state_settings?page=${page}&sorting_filter=${perpage}&search_filter=${search}&filterCountry=${filterCountry}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    
    // Initial load
    loadThemes(1);

    function editState(id) {
        fetch(`/common/State_edit/${id}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Unable to fetch State details.');
            }
            return response.json();
        })
        .then(data => {
            const item = data.data ?? data.State ?? data;

            const form = document.getElementById('StateSettingForm');

            document.getElementById('edit_id').value = item.sno ?? item.id ?? id;
            document.getElementById('State_name').value = item.state_name ?? '';
            document.getElementById('description').value = item.description ?? '';
            $('#country_id').val(item.country_id ?? '').trigger('change');
            document.getElementById('State_name_err').textContent = '';
            form.action = "{{ route('state_update_name') }}";

            document.getElementById('StateModalTitle').textContent =
                'Edit State Setting';

            form.querySelector('button[type="submit"] span').textContent =
                'Update Setting';

            const modalElement = document.getElementById('stateSettingModal');

            if (modalElement && window.bootstrap?.Modal) {
                window.bootstrap.Modal
                    .getOrCreateInstance(modalElement)
                    .show();
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to load State details.');
        });
    }

    const stateSettingModal = document.getElementById('stateSettingModal');

    if (stateSettingModal) {
        stateSettingModal.addEventListener('hidden.bs.modal', function () {
            const form = document.getElementById('StateSettingForm');

            if (!form) return;

            form.reset();

            document.getElementById('edit_id').value = '';
            document.getElementById('State_name_err').textContent = '';
            document.getElementById('country_id_err').textContent = '';

            document.getElementById('StateModalTitle').textContent =
                'State Setting';

            const submitText = form.querySelector(
                'button[type="submit"] span'
            );

            if (submitText) {
                submitText.textContent = 'Save Setting';
            }

            form.action = "{{ route('add_state_category') }}";

            // Reset Select2 if initialized.
            if (typeof $ !== 'undefined' &&
                $('#country_id').hasClass('select2-hidden-accessible')) {
                $('#country_id').val('').trigger('change');
            }
        });
    }
</script>

<!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const reloadPage = tableState.currentPage;

        const status = isChecked ? 0 : 1;

        fetch(`/common/state_status/${Id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ status })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Status update failed.');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success('Status updated successfully!');
                loadThemes(reloadPage);
            } else {
                toastr.error(data.message || 'Unable to update status.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to update status.');
            loadThemes(reloadPage);
        });
    }
</script>

<!-- Delete Function -->
<script>
    let deleteStateId = null;

    function confirmDelete(id, name, sortname = '') {
        deleteStateId = id;

        const modalElement = document.getElementById('deleteStateModal');
        const message = modalElement.querySelector('.modal-body p');

        message.textContent = `Delete "${name}"? This action cannot be undone.`;

        bootstrap.Modal.getOrCreateInstance(modalElement).show();
    }

    function deleteFunc() {
        if (!deleteStateId) {
            toastr.error('No State selected.');
            return;
        }

        const reloadPage = tableState.currentPage;

        const button = document.getElementById('confirmDeleteBtn');
        button.disabled = true;

        fetch(`/common/state_delete/${deleteStateId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Delete request failed.');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message || 'State deleted successfully.');

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('deleteStateModal')
                ).hide();

                deleteStateId = null;
                loadThemes(reloadPage);
            } else {
                toastr.error(data.error_msg || data.message || 'Unable to delete State.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to delete State.');
        })
        .finally(() => {
            button.disabled = false;
        });
    }
</script>
<!-- add validate -->
 <script>
 document.getElementById('StateSettingForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const form = this;
    const submitButton = document.getElementById('add_submit_btn');
    const countryInput = document.getElementById('country_id');
    const stateNameInput = document.getElementById('State_name');
    const reloadPage = tableState.currentPage;

    const countryError = document.getElementById('country_id_err');
    const stateNameError = document.getElementById('State_name_err');

    const stateName = stateNameInput.value.trim();
    const countryId = countryInput.value;
    const isEdit = document.getElementById('edit_id').value !== '';
    countryError.textContent = '';
    stateNameError.textContent = '';

    countryInput.classList.remove('is-invalid');
    stateNameInput.classList.remove('is-invalid');

    // Validate Country
    if (!countryId) {
        countryError.textContent = 'Please select a country.';
        countryInput.classList.add('is-invalid');

        if ($(countryInput).hasClass('select2-hidden-accessible')) {
            $(countryInput).next('.select2-container')
                .find('.select2-selection')
                .addClass('is-invalid');
        }
    }
    if (!stateName) {
        stateNameError.textContent = 'State name is required.';
        stateNameInput.classList.add('is-invalid');
    }

    if (!countryId || !stateName) {
        return;
    }

    stateNameInput.value = stateName;

    submitButton.disabled = true;
    submitButton.innerHTML =
        '<span class="spinner-border spinner-border-sm me-1"></span> Saving...';

    fetch(form.action, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        },
        body: new FormData(form)
    })
    .then(async response => {
        const data = await response.json();

        if (response.status === 422) {
            const errors = data.errors || {};

            if (errors.country_id) {
                countryError.textContent = errors.country_id[0];
                countryInput.classList.add('is-invalid');

                if ($(countryInput).hasClass('select2-hidden-accessible')) {
                    $(countryInput).next('.select2-container')
                        .find('.select2-selection')
                        .addClass('is-invalid');
                }
            }

            if (errors.state_name) {
                stateNameError.textContent = errors.state_name[0];
                stateNameInput.classList.add('is-invalid');
            }

            if (errors.description) {
                toastr.error(errors.description[0]);
            }

            return;
        }

        if (!response.ok) {
            throw new Error(
                data.message || data.error_msg ||
                'Unable to save State setting.'
            );
        }

        if (data.status === 200 || data.success === true) {
            toastr.success(
                data.message ||
                (isEdit
                    ? 'State setting updated successfully.'
                    : 'State setting added successfully.')
            );

            const modalElement = document.getElementById('stateSettingModal');

            if (modalElement && window.bootstrap?.Modal) {
                const modalInstance = window.bootstrap.Modal.getInstance(modalElement);

                if (modalInstance) {
                    modalInstance.hide();
                }
            }

            form.reset();
            $('#country_id').val('').trigger('change');

            document.getElementById('edit_id').value = '';
            countryError.textContent = '';
            stateNameError.textContent = '';
            countryInput.classList.remove('is-invalid');
            stateNameInput.classList.remove('is-invalid');
            $('#country_id').next('.select2-container')
                .find('.select2-selection')
                .removeClass('is-invalid');

            document.getElementById('StateModalTitle').textContent =
                'State Setting';

            form.action = "{{ route('add_state_category') }}";

            loadThemes(reloadPage);
        } else {
            toastr.error(
                data.message || data.error_msg ||
                'Unable to save State setting.'
            );
        }
    })
    .catch(error => {
        console.error('State save error:', error);
        toastr.error(error.message || 'Unable to save State setting.');
    })
    .finally(() => {
        submitButton.disabled = false;
        submitButton.innerHTML =
            '<i class="mdi mdi-check"></i><span>' +
            (document.getElementById('edit_id').value !== ''
                ? 'Update Setting'
                : 'Save Setting') +
            '</span>';
    });
});

document.getElementById('State_name').addEventListener('input', function () {
    document.getElementById('State_name_err').textContent = '';
    this.classList.remove('is-invalid');
});
$('#country_id').on('change', function () {
    document.getElementById('country_id_err').textContent = '';
    this.classList.remove('is-invalid');
    $(this).next('.select2-container').find('.select2-selection').removeClass('is-invalid');
});
 </script>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize Select2 dropdowns if jQuery & Select2 are loaded
        if (typeof $ !== 'undefined' && $.fn.select2) {
            $('.select2').select2();
            $('.select2-modal').select2({
                dropdownParent: $('#stateSettingModal')
            });
        }

        // Client-side active pill switching
        const navLinks = document.querySelectorAll('.nav-pills .nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                navLinks.forEach(item => {
                    item.classList.remove('active');
                    item.classList.add('text-muted');
                });
                this.classList.add('active');
                this.classList.remove('text-muted');
            });
        });
    });

    
    function resetForm() {
        const form = document.getElementById('StateSettingForm');
        if (!form) return;

        form.reset();

        document.getElementById('edit_id').value = '';

        document.getElementById('StateModalTitle').textContent =
            'State Setting';

        document.getElementById('State_name_err').textContent = '';
        document.getElementById('country_id_err').textContent = '';

        form.action = "{{ route('add_state_category') }}";

        const submitText = form.querySelector(
            'button[type="submit"] span'
        );

        if (submitText) {
            submitText.textContent = 'Save Setting';
        }

        if (typeof $ !== 'undefined' &&
            $('#country_id').hasClass('select2-hidden-accessible')) {
            $('#country_id').val('').trigger('change');
        }
    }

</script>
@endsection