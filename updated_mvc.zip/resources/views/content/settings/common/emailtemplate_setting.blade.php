@extends('layouts/layoutMaster')

@section('title', 'Email Template - Common Settings')

@section('vendor-style')

@vite(['resources/assets/vendor/libs/quill/katex.scss', 'resources/assets/vendor/libs/quill/editor.scss', 'resources/assets/vendor/libs/quill/quill.scss'])

@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/quill/katex.js', 'resources/assets/vendor/libs/quill/quill.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection

@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

<div class="row g-4 align-items-start">

    {{-- ===================================================== --}}
    {{-- Left Area: Settings Sidebar --}}
    {{-- ===================================================== --}}

    @include('layouts.sections.settings.settings-sidebar')

    {{-- ===================================================== --}}
    {{-- Right Area: Financial Year Content --}}
    {{-- ===================================================== --}}

    <div class="col-12 col-lg-9">

        <div class="card w-100">

            <div class="card-header border-bottom py-3">

                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">

                    {{-- Title --}}
                    <div class="d-flex align-items-center gap-3">

                        <div
                            class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">

                            <i class="mdi mdi-email-outline fs-4 text-primary"></i>

                        </div>

                        <div>

                            <h5 class="mb-0 fw-bold">
                                Email Template
                            </h5>

                            <small class="text-muted">
                                Create and manage email templates with rich text formatting
                            </small>

                        </div>

                    </div>


                    {{-- Create Button --}}
                    <button type="button" class="btn btn-primary d-flex align-items-center justify-content-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#emailTemplateModal">

                        <i class="mdi mdi-plus fs-5"></i>

                        <span>
                            Create Email Template
                        </span>

                    </button>

                </div>

            </div>

            <div class="card-body pt-4">
                <div class="row g-3 mb-4">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search email template...">
                        </div>
                    </div>
                </div>

                <div class="table-responsive rounded border">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr class="bg-light">
                                <th class="text-nowrap">
                                    Template Name
                                </th>
                                <th class="text-nowrap">
                                    Subject
                                </th>
                                <th class="text-nowrap">
                                    Status
                                </th>
                                <th class="text-end text-nowrap">
                                    Actions
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            {{-- Row 1 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">
                                        Welcome Email
                                    </span>
                                </td>
                                <td>
                                    Welcome to our organization
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#updateEmailTemplateModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline">
                                            </i>

                                        </button>


                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteEmailTemplateModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline">
                                            </i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            {{-- Row 2 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">
                                        Password Reset
                                    </span>
                                </td>
                                <td>
                                    Reset your account password
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#updateEmailTemplateModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline">
                                            </i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteEmailTemplateModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline">
                                            </i>
                                        </button>
                                    </div>
                                </td>
                            </tr>



                            {{-- Row 3 --}}
                            <tr>
                                <td class="text-nowrap">
                                    <span class="fw-semibold">
                                        Account Notification
                                    </span>
                                </td>
                                <td>
                                    Important account notification
                                </td>
                                <td>
                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>
                                </td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-1">
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#updateEmailTemplateModal" title="Edit">
                                            <i class="mdi mdi-pencil-outline">
                                            </i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteEmailTemplateModal"
                                            title="Delete">
                                            <i class="mdi mdi-delete-outline">
                                            </i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



{{-- Create / Edit Email Template Modal --}}

<div class="modal fade" id="emailTemplateModal" tabindex="-1" aria-labelledby="emailTemplateModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            {{-- Modal Header --}}

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="emailTemplateModalLabel">
                    Create Email Template
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="emailTemplateForm" action="#" method="POST">
                @csrf
                {{-- Modal Body --}}

                <div class="modal-body">
                    <div class="container-fluid px-0">
                        <div class="row g-3 g-md-4">
                            {{-- Template Name --}}
                            <div class="col-12 col-md-12">
                                <label for="template_name" class="form-label fw-semibold">
                                    Template Name
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" id="template_name" name="template_name" class="form-control"
                                    placeholder="Enter template name" required>
                            </div>

                            {{-- Email Subject --}}
                            <div class="col-12">
                                <label for="email_subject" class="form-label fw-semibold">
                                    Email Subject
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" id="email_subject" name="email_subject" class="form-control"
                                    placeholder="Enter email subject" required>
                            </div>
                            {{-- Email Content --}}

                           <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email Content<span class="text-danger">*</span></label>
                                <input type="hidden" name="email_content" id="email_content">
                                <div class="col-lg-12">
                                    <div id="create_exam_guideline_editor">
                                        <div class="ql-editor" name="email_content_text" id="email_content_text" placeholder="Type Something..."></div>
                                    </div>
                                    <div class="text-danger" id="email_content_err"></div>
                                </div>
                                {{-- <textarea class="form-control" rows="10" id="email_content" name="email_content" placeholder="Enter Subject Content"></textarea> --}}
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top d-flex flex-wrap gap-2 justify-content-end">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        <span>
                            Save Template
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="updateEmailTemplateModal" tabindex="-1" aria-labelledby="emailTemplateModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            {{-- Modal Header --}}

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="emailTemplateModalLabel">
                    Create Email Template
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            {{-- Form --}}
            <form id="emailTemplateForm" action="#" method="POST">
                @csrf
                {{-- Modal Body --}}

                <div class="modal-body">
                    <div class="container-fluid px-0">
                        <div class="row g-3 g-md-4">
                            {{-- Template Name --}}
                            <div class="col-12 col-md-12">
                                <label for="template_name" class="form-label fw-semibold">
                                    Template Name
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" id="template_name" name="template_name" class="form-control"
                                    placeholder="Enter template name" required>
                            </div>

                            {{-- Email Subject --}}
                            <div class="col-12">
                                <label for="email_subject" class="form-label fw-semibold">
                                    Email Subject
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" id="email_subject" name="email_subject" class="form-control"
                                    placeholder="Enter email subject" required>
                            </div>
                            {{-- Email Content --}}

                           <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email Content<span class="text-danger">*</span></label>
                                <input type="hidden" name="email_content" id="email_content">
                                <div class="col-lg-12">
                                    <div id="create_exam_guideline_editor_edit">
                                        <div class="ql-editor" name="email_content_text" id="email_content_text" placeholder="Type Something..."></div>
                                    </div>
                                    <div class="text-danger" id="email_content_err"></div>
                                </div>
                                {{-- <textarea class="form-control" rows="10" id="email_content" name="email_content" placeholder="Enter Subject Content"></textarea> --}}
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top d-flex flex-wrap gap-2 justify-content-end">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        <span>
                            Save Template
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>



{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteEmailTemplateModal" tabindex="-1" aria-labelledby="deleteEmailTemplateModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- Header --}}
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="deleteEmailTemplateModalLabel">
                    Delete Email Template
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Body --}}
            <div class="modal-body text-center py-4">
                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3">
                    <i class="mdi mdi-email-remove-outline fs-3 text-danger">
                    </i>
                </div>
                <h5 class="mb-2">
                    Are you sure?
                </h5>
                <p class="text-muted mb-0">
                    You are about to delete
                    <strong>
                        this email template
                    </strong>.

                    This action cannot be undone.
                </p>
            </div>
            {{-- Footer --}}
            <div class="modal-footer justify-content-center border-top">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                    <i class="mdi mdi-delete-outline me-1"></i>
                    Delete
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    function EditvalidateForm() {
        var exam_guidelines = $(".ql-editor").html().trim();
        var email_name = $("#email_name").val().trim();
        if (email_name == "") {
            $('#email_name_err').html('Enter Email Template Name is required...!');
            return false;
        } else {
            $('#email_name_err').html('');
        }
        if ($(".ql-editor").hasClass('ql-blank') || exam_guidelines === "" || exam_guidelines === '<p><br></p>') {
            $('#email_content_err').html('Enter Content of Email is required...!');
            return false;
        } else {
            $('#email_content_err').html('');

            const data = exam_guidelines;
            $('#email_content').val(data);
            return true;
        }
    }

</script>

@endsection