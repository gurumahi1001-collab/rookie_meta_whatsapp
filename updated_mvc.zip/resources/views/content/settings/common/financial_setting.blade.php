@extends('layouts/layoutMaster')

@section('title', 'Financial Year List - Common Settings')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('content')

{{-- Shared Settings Navigation Header --}}
@include('layouts.sections.settings.settings-header', ['activeTab' => 'common'])

{{-- ========================================================= --}}
{{-- Main Settings Row --}}
{{-- ========================================================= --}}

<div class="row g-4 align-items-start">

    {{-- ===================================================== --}}
    {{-- Left Area: Settings Sidebar --}}
    {{-- ===================================================== --}}

    @include('layouts.sections.settings.settings-sidebar')

    {{-- ===================================================== --}}
    {{-- Right Area: Financial Year Content --}}
    {{-- ===================================================== --}}

    <div class="col-12 col-lg-9">

        <div class="card">

            {{-- ================================================= --}}
            {{-- Card Header --}}
            {{-- ================================================= --}}

            <div class="card-header border-bottom py-3">

                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">

                    {{-- Title --}}
                    <div class="d-flex align-items-center gap-3">

                        <div
                            class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center flex-shrink-0">
                            <i class="mdi mdi-calendar-range-outline fs-4 text-primary"></i>
                        </div>

                        <div>
                            <h5 class="mb-0 fw-bold">
                                Financial Year List
                            </h5>

                            <small class="text-muted">
                                Manage financial years, project opening balances, and status
                            </small>
                        </div>

                    </div>

                    {{-- Create Button --}}
                    <button type="button" class="btn btn-primary d-flex align-items-center justify-content-center gap-1"
                        data-bs-toggle="modal" data-bs-target="#financialYearModal">

                        <i class="mdi mdi-plus fs-5"></i>

                        <span>
                            Create Financial Year
                        </span>

                    </button>

                </div>

            </div>

            {{-- ================================================= --}}
            {{-- Card Body --}}
            {{-- ================================================= --}}

            <div class="card-body pt-4">

                {{-- Search --}}
                <div class="row g-3 mb-4">

                    <div class="col-12 col-md-6 col-lg-5">

                        <div class="input-group input-group-merge">

                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>

                            <input type="text" id="tableSearch" class="form-control"
                                placeholder="Search financial year...">

                        </div>

                    </div>

                </div>

                {{-- ================================================= --}}
                {{-- Financial Year Table --}}
                {{-- ================================================= --}}

                <div class="table-responsive rounded border">

                    <table class="table table-hover align-middle mb-0">

                        <thead>

                            <tr class="bg-light">
                                <th class="text-nowrap">
                                    Financial Year
                                </th>

                                <th class="text-nowrap">
                                    Status
                                </th>

                                <th class="text-end text-nowrap">
                                    Actions
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                            {{-- Row 1 --}}
                            <tr>
                                <td class="text-nowrap">

                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            2025 - 2026
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#financialYearModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteFinancialYearModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            {{-- Row 2 --}}
                            <tr>
                                <td class="text-nowrap">

                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            2024 - 2025
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#financialYearModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteFinancialYearModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                            {{-- Row 3 --}}
                            <tr>

                                <td class="text-nowrap">

                                    <div class="d-flex align-items-center gap-2">

                                        <span class="fw-semibold">
                                            2023 - 2024
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="form-check form-switch mb-0">
                                        <input class="form-check-input"
                                            type="checkbox"
                                            id="RemunerationStatus1"
                                            checked>
                                    </div>

                                </td>

                                <td class="text-end">

                                    <div class="d-inline-flex gap-1">

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                            data-bs-toggle="modal" data-bs-target="#financialYearModal" title="Edit">

                                            <i class="mdi mdi-pencil-outline"></i>

                                        </button>

                                        <button type="button" class="btn btn-sm btn-icon btn-outline-danger border-0"
                                            data-bs-toggle="modal" data-bs-target="#deleteFinancialYearModal"
                                            title="Delete">

                                            <i class="mdi mdi-delete-outline"></i>

                                        </button>

                                    </div>

                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>
    ```

</div>

{{-- ========================================================= --}}
{{-- Create / Edit Financial Year Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="financialYearModal" tabindex="-1" aria-labelledby="financialYearModalLabel"
    aria-hidden="true">

    ```
    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">

            {{-- Modal Header --}}
            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold" id="financialYearModalLabel">
                    Create Financial Year
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>

            {{-- Form --}}
            <form action="#" method="POST">

                @csrf

                {{-- Modal Body --}}
                <div class="modal-body">

                    <div class="row g-4">

                        {{-- Financial Year --}}
                        <div class="col-12">

                            <label for="financial_year" class="form-label fw-semibold">

                                Financial Year

                                <span class="text-danger">
                                    *
                                </span>

                            </label>

                            <input type="text" id="financial_year" name="financial_year" class="form-control"
                                placeholder="Example: 2025 - 2026" required>

                        </div>


                        {{-- Project Section --}}
                        <div class="col-12">

                            <div class="border rounded p-3">

                                <h6 class="fw-bold mb-3">

                                    <i class="mdi mdi-office-building-outline me-1 text-primary"></i>

                                    Project

                                </h6>

                                <div class="row g-3">

                                    {{-- Head Office --}}
                                    <div class="col-12 col-md-4">

                                        <label for="head_office" class="form-label fw-semibold">

                                            Head Office

                                            <span class="text-danger">
                                                *
                                            </span>

                                        </label>

                                        <input type="number" id="head_office" name="head_office" class="form-control"
                                            placeholder="Opening balance" min="0" step="0.01" required>

                                    </div>


                                    {{-- Cube --}}
                                    <div class="col-12 col-md-4">

                                        <label for="cube" class="form-label fw-semibold">

                                            Cube

                                            <span class="text-danger">
                                                *
                                            </span>

                                        </label>

                                        <input type="number" id="cube" name="cube" class="form-control"
                                            placeholder="Opening balance" min="0" step="0.01" required>

                                    </div>


                                    {{-- Central Storage Hub --}}
                                    <div class="col-12 col-md-4">

                                        <label for="central_storage_hub" class="form-label fw-semibold">

                                            Central Storage Hub

                                            <span class="text-danger">
                                                *
                                            </span>

                                        </label>

                                        <input type="number" id="central_storage_hub" name="central_storage_hub"
                                            class="form-control" placeholder="Opening balance" min="0" step="0.01"
                                            required>

                                    </div>

                                </div>

                            </div>

                        </div>


                        {{-- Status --}}
                        <div class="col-12 col-md-6">

                            <label for="status" class="form-label fw-semibold">

                                Status

                                <span class="text-danger">
                                    *
                                </span>

                            </label>

                            <select id="status" name="status" class="form-select select3" required>

                                <option value="">
                                    Select Status
                                </option>

                                <option value="active">
                                    Active
                                </option>

                                <option value="closed">
                                    Closed
                                </option>

                            </select>

                        </div>

                    </div>

                </div>

                {{-- Modal Footer --}}
                <div class="modal-footer border-top">

                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary">

                        <i class="mdi mdi-check me-1"></i>

                        Save Financial Year

                    </button>

                </div>

            </form>

        </div>

    </div>
    ```

</div>

{{-- ========================================================= --}}
{{-- Delete Confirmation Modal --}}
{{-- ========================================================= --}}

<div class="modal fade" id="deleteFinancialYearModal" tabindex="-1" aria-labelledby="deleteFinancialYearModalLabel"
    aria-hidden="true">

    ```
    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header border-bottom">

                <h5 class="modal-title fw-bold" id="deleteFinancialYearModalLabel">

                    Delete Financial Year

                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>

            </div>

            <div class="modal-body text-center py-4">

                <div class="avatar bg-label-danger rounded-circle mx-auto mb-3
                        d-flex align-items-center justify-content-center">

                    <i class="mdi mdi-calendar-remove-outline fs-3 text-danger"></i>

                </div>

                <h5 class="mb-2">
                    Are you sure?
                </h5>

                <p class="text-muted mb-0">

                    You are about to delete
                    <strong>2025 - 2026</strong>.

                    This action cannot be undone.

                </p>

            </div>

            <div class="modal-footer justify-content-center border-top">

                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">

                    Cancel

                </button>

                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">

                    <i class="mdi mdi-delete-outline me-1"></i>

                    Delete

                </button>

            </div>

        </div>

    </div>


</div>

@endsection
