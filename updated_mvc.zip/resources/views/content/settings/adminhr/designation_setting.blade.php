@extends('layouts/layoutMaster')

@section('title', 'Designation')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', [
    'activeTab' => 'admin_hr'
])

<div class="row mt-4">

    {{-- LEFT SIDEBAR --}}
    <div class="col-md-3">

        @include('layouts.sections.settings.adminsettings-sidebar')

    </div>

    {{-- RIGHT CONTENT --}}
    <div class="col-md-9">
      <div class="card ">
            <div
                class="card-header border-bottom py-3 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar bg-label-primary p-2 rounded d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-badge-account-outline fs-4 text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold">Designation Settings</h5>
                        <small class="text-muted">
                            Manage designation and its details
                        </small>
                    </div>
                </div>
                <button type="button" class="btn btn-primary d-flex align-items-center gap-1" data-bs-toggle="modal"
                    data-bs-target="#countrySettingModal">
                    <i class="mdi mdi-plus fs-5"></i>
                    <span>Add Designation</span>
                </button>
            </div>
            <div class="card-body p-3">
                <div class="row g-3 mb-2 justify-content-between align-items-center">
                    <div class="col-12">
                        <div class="d-flex align-items-center justify-content-between  ">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                        <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                            {{ $option }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mt-2">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" id="search_filter" class="form-control"
                                        placeholder="Search Blood group or description..." />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive rounded border">
                  <table class="table table-hover align-middle mb-0 border">
                      <thead class="table-light">
                          <tr class="bg-light">
                              <th>
                                  Designation
                              </th>
                              <th>
                                  Description
                              </th>
                              <th>
                                  Status
                              </th>
                              <th>
                                  Actions
                              </th>
                          </tr>
                       </thead>
                       <tbody id="list-table-body" class="table-border-bottom-0">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                  </table>
                </div>
              <div class="text-center my-3" id="pagination-container">
                  <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>

</div>

{{-- ========================================================= --}}
{{-- CREATE DESIGNATION MODAL --}}
{{-- ========================================================= --}}
<div class="modal fade" id="countrySettingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-start">

            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold" id="countryModalTitle">Create Designation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

           <form id="countrySettingForm"
                action="{{ route('add_designation_category') }}"
                method="POST">
                @csrf

                  <input type="hidden" id="edit_id" name="edit_id" value="">

                <div class="modal-body text-start">
                    <div class="mb-3">
                        <label for="designation" class="form-label fw-semibold">
                            Designation <span class="text-danger">*</span>
                        </label>

                        <input type="text"
                              id="designation"
                              name="designation"
                              class="form-control"
                              placeholder="Enter Desigantion">

                        <small id="country_name_err" class="text-danger"></small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">
                            Description
                        </label>

                        <textarea id="description"
                                  name="description"
                                  class="form-control"
                                  rows="3"
                                  placeholder="Enter description"></textarea>
                    </div>
                </div>

                <div class="modal-footer border-top">
                    <button type="button"
                            class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="submit"
                            id="add_submit_btn"
                            class="btn btn-primary">
                        <i class="mdi mdi-check"></i>
                        <span>Save Designation</span>
                    </button>
                </div>
        </form>
        </div>
    </div>
</div>
{{-- Delete Confirmation Modal --}}
<div class="modal fade" id="deleteCountryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content text-center p-3">
            <div class="modal-body">
                <div class="avatar bg-label-danger p-3 rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                    style="width: 56px; height: 56px;">
                    <i class="mdi mdi-alert-outline fs-2 text-danger"></i>
                </div>
                <h6 class="fw-bold mb-1">Delete Designation?</h6>
                <p class="text-muted text-xs mb-0">This action cannot be undone.</p>
            </div>
            <div class="d-flex justify-content-center gap-2 mt-2">
                <button type="button" class="btn btn-sm btn-outline-secondary px-3"
                    data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmDeleteBtn" class="btn btn-sm btn-danger px-3" onclick="deleteFunc()">Delete</button>
            </div>
        </div>
    </div>
</div>
<!-- list page handling start-->
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {
        const id = Number(item.sno);
        const name = escapeHtml(item.designation);
        const description = escapeHtml(item.description == null || item.description === 0 || item.description === '0'? '': item.description);
        const active = Number(item.status) === 0;

        return `
            <tr>
                <td>
                    <span class="fw-bold text-heading">${name}</span>
                </td>

                <td>
                    <span class="text-truncate d-inline-block"
                        style="max-width:350px"
                        title="${description}">
                        ${description || '-'}
                    </span>
                </td>

                <td>
                    <div class="form-check form-switch mb-0">
                        <input class="form-check-input country-status"
                            type="checkbox"
                            data-id="${id}"
                            ${active ? 'checked' : ''}
                            aria-label="Change status for ${name}"
                            onchange="updatelevelStatus(${id}, this.checked)">
                    </div>
                </td>

                <td class="text-end">
                    <div class="d-inline-flex gap-1">
                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-secondary border-0"
                                onclick="editCountry(${id})"
                                title="Edit">
                            <i class="mdi mdi-pencil-outline"></i>
                        </button>

                        <button type="button"
                                class="btn btn-sm btn-icon btn-outline-danger border-0"
                                onclick="confirmDelete(${id}, '${name}', '')"
                                title="Delete">
                            <i class="mdi mdi-delete-outline"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }


    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;

        const url = `/settings/designation-setting?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="4" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;

    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('search_filter').addEventListener('keyup', function() {
        loadThemes(1); // Reload the table data without the search filter
    });


    // Initial load
    loadThemes(1);
</script>
<!-- list page handling End-->
 <script>

    function editCountry(id) {
        fetch(`/designation_edit/${id}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Unable to fetch Designation details.');
            }
            return response.json();
        })
        .then(data => {
            const item = data.data ?? data.country ?? data;

            const form = document.getElementById('countrySettingForm');
            document.getElementById('edit_id').value = item.sno ?? item.id ?? id;
            document.getElementById('designation').value = item.designation ?? '';
            document.getElementById('description').value = item.description ?? '';
            document.getElementById('country_name_err').textContent = '';
            form.action = "{{ route('designation_update_name') }}";

            document.getElementById('countryModalTitle').textContent =
                'Edit Designation';

            form.querySelector('button[type="submit"] span').textContent =
                'Update Setting';

            bootstrap.Modal.getOrCreateInstance(
                document.getElementById('countrySettingModal')
            ).show();
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to load Designation details.');
        });
    }

    document.getElementById('countrySettingModal')
    .addEventListener('hidden.bs.modal', function () {
        const form = document.getElementById('countrySettingForm');

        form.reset();

        document.getElementById('edit_id').value = '';
        document.getElementById('country_name_err').textContent = '';

        document.getElementById('countryModalTitle').textContent =
            'Designation';

        form.querySelector('button[type="submit"] span').textContent =
            'Save Setting';

        // IMPORTANT: Restore the ADD route
        form.action = "{{ route('add_designation_category') }}";
    });
</script>

<!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const reloadPage = tableState.currentPage;

        const status = isChecked ? 0 : 1;

        fetch(`/designation/group_status/${Id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ status })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Status update failed.');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success('Status updated successfully!');
                loadThemes(reloadPage);
            } else {
                toastr.error(data.message || 'Unable to update status.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to update status.');
            loadThemes(reloadPage);
        });
    }
</script>

<!-- Delete Function -->
<script>
    let deleteCountryId = null;

    function confirmDelete(id, name, sortname = '') {
        deleteCountryId = id;

        const modalElement = document.getElementById('deleteCountryModal');
        const message = modalElement.querySelector('.modal-body p');

        message.textContent = `Delete "${name}"? This action cannot be undone.`;

        bootstrap.Modal.getOrCreateInstance(modalElement).show();
    }

    function deleteFunc() {
        const reloadPage = tableState.currentPage;

        if (!deleteCountryId) {
            toastr.error('No country selected.');
            return;
        }

        const button = document.getElementById('confirmDeleteBtn');
        button.disabled = true;

        fetch(`/admin/designation_delete/${deleteCountryId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Delete request failed.');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 200) {
                toastr.success(data.message || 'Designation deleted successfully.');

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('deleteCountryModal')
                ).hide();

                deleteCountryId = null;
                loadThemes(reloadPage);
            } else {
                toastr.error(data.error_msg || data.message || 'Unable to delete Designation.');
            }
        })
        .catch(error => {
            console.error(error);
            toastr.error('Unable to delete Designation.');
        })
        .finally(() => {
            button.disabled = false;
        });
    }
</script>

<!-- add validate -->
<script>
    document.getElementById('countrySettingForm').addEventListener('submit', function (e) {
        e.preventDefault();

        const form = this;
        const submitButton = document.getElementById('add_submit_btn');
        const countryName = document.getElementById('designation').value.trim();
        const errorElement = document.getElementById('country_name_err');
        const isEdit = document.getElementById('edit_id').value !== '';
        const reloadPage = tableState.currentPage;


        errorElement.textContent = '';

        if (!countryName) {
            errorElement.textContent = 'Designation is required.';
            return;
        }

        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Saving...';

        fetch(form.action, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: new FormData(form)
        })
        .then(async response => {
            const data = await response.json();

            if (!response.ok) {
                if (response.status === 422 && data.errors) {
                    errorElement.textContent =
                        data.errors.designation?.[0] || 'Please check the form.';
                    return;
                }

                throw new Error(data.message || 'Unable to save country setting.');
            }

            if (data.status === 200 || data.success === true) {
                toastr.success(
                    data.message || (isEdit
                        ? 'Designation setting updated successfully.'
                        : 'Designation setting added successfully.')
                );

                bootstrap.Modal.getOrCreateInstance(
                    document.getElementById('countrySettingModal')
                ).hide();

                form.reset();
                document.getElementById('edit_id').value = '';

                document.getElementById('countryModalTitle').textContent =
                    'Designation';

                form.querySelector('button[type="submit"] span').textContent =
                    'Save Setting';

                form.action = "{{ route('add_designation_category') }}";

                loadThemes(reloadPage);
            } else {
                toastr.error(data.message || data.error_msg || 'Unable to save Designation setting.');
            }
        })
        .catch(error => {
            console.error('Country save error:', error);
            toastr.error(error.message || 'Unable to save Designation setting.');
        })
        .finally(() => {
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="mdi mdi-check"></i><span>Save Setting</span>';
        });
    });
</script>
@endsection
