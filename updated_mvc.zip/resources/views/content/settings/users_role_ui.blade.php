@extends('layouts/layoutMaster')

@section('title', 'Users & Role')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

  @include('layouts.sections.settings.settings-header', ['activeTab' => 'rbac'])

  @php
    // Static permission tree — mirrors resources/menu/verticalMenu.json structure.
    // Each submenu row gets 4 CRUD checkboxes: view / create / edit / delete.
    $permissionModules = [
      [
        'name' => 'Dashboard',
        'icon' => 'mdi mdi-view-dashboard-outline',
        'submenus' => [
          ['name' => 'Command Dashboard'],
        ],
      ],
      [
        'name' => 'Admin / HR',
        'icon' => 'mdi mdi-account-group-outline',
        'submenus' => [
          ['name' => 'Employee / Staff'],
          ['name' => 'Attendance Log'],
          ['name' => 'Leave Management'],
          ['name' => 'Wages'],
          ['name' => 'Payroll'],
          ['name' => 'ESI & PF Compliance'],
        ],
      ],
      [
        'name' => 'Accounts',
        'icon' => 'mdi mdi-currency-usd',
        'submenus' => [
          ['name' => 'Dashboard'],
          ['name' => 'Banking & Cash Management'],
          ['name' => 'General Ledger'],
          ['name' => 'Accounts Receivable'],
          ['name' => 'Accounts Payable'],
          ['name' => 'Expense Management'],
          ['name' => 'Tax Management'],
          ['name' => 'Reports'],
        ],
      ],
      [
        'name' => 'Site Log',
        'icon' => 'mdi mdi-account-hard-hat',
        'submenus' => [
          ['name' => 'Manage Project'],
          ['name' => 'Manage Structure'],
          ['name' => 'Manage Store'],
          ['name' => 'Client'],
          ['name' => 'Contractor'],
          ['name' => 'Vendor'],
        ],
      ],
      [
        'name' => 'Planning & QS',
        'icon' => 'mdi mdi-compass-outline',
        'submenus' => [
          ['name' => 'Planning'],
          ['name' => 'Work Orders'],
          ['name' => 'Schedule'],
          ['name' => 'Financial Bills'],
          ['name' => 'Verification'],
        ],
      ],
      [
        'name' => 'Store & Purchase',
        'icon' => 'mdi mdi-package-variant-closed',
        'submenus' => [
          ['name' => 'Warehouse'],
          ['name' => 'Material Management'],
          ['name' => 'Purchase Management'],
          ['name' => 'Fuel Management'],
          ['name' => 'Scrap Management'],
        ],
      ],
      [
        'name' => 'Plant & Machinery',
        'icon' => 'mdi mdi-truck-outline',
        'submenus' => [
          ['name' => 'Machine Master'],
          ['name' => 'Machine Operations'],
          ['name' => 'Maintenance'],
          ['name' => 'Billing'],
        ],
      ],
      [
        'name' => 'Settings',
        'icon' => 'mdi mdi-cog-outline',
        'submenus' => [
          ['name' => 'General Settings'],
          ['name' => 'Role Permission Matrix'],
        ],
      ],
    ];

  $roles = [
    [
      'name' => 'System Admin',
      'users' => 2,
      'site_scoped' => false,
      'active' => true,
    ],
    [
      'name' => 'Project Manager',
      'users' => 5,
      'site_scoped' => true,
      'active' => true,
    ],
    [
      'name' => 'Site Engineer',
      'users' => 11,
      'site_scoped' => true,
      'active' => true,
    ],
    [
      'name' => 'QS Auditor',
      'users' => 3,
      'site_scoped' => false,
      'active' => false,
    ],
  ];
  @endphp

  {{-- Roles list --}}
  <div class="card mb-4 settings-card">
    <div class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div>
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-shield-account-outline text-primary"></i> Roles
        </h6>
        <small class="text-muted">Manage roles and their module-level permissions</small>
      </div>
      <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="offcanvas" data-bs-target="#roleDrawer" onclick="openRoleModal('add')">
        <i class="mdi mdi-plus me-1"></i> Add Role
      </button>
    </div>

    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="fw-semibold text-black fs-8 uppercase bg-light">
          <tr>
            <th class="min-w-100px text-black">Role Name</th>
            <th class="min-w-100px text-black">Users</th>
            <th class="min-w-100px text-black">Site Management</th>
            <th class="min-w-100px text-black"> Status </th>
            <th class="min-w-100px text-black text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach ($roles as $role)
            <tr>
              <td class="fw-semibold">{{ $role['name'] }}</td>
              <td>{{ $role['users'] }}</td>
              <td>
                @if ($role['site_scoped'])
                  <span class="badge bg-label-success">Enabled</span>
                @else
                  <span class="badge bg-label-secondary">Disabled</span>
                @endif
              </td>
              <td>
                <div class="form-check form-switch mb-0">
                  <input
                    class="form-check-input role-status-toggle"
                    type="checkbox"
                    role="switch"
                    {{ $role['active'] ? 'checked' : '' }}
                    onchange="toggleRoleStatus(this, '{{ $role['name'] }}')"
                  >
                </div>
              </td>
              <td class="text-end">
                <button type="button" class="btn btn-sm btn-icon btn-text-secondary" data-bs-toggle="offcanvas" data-bs-target="#roleDrawer" onclick="openRoleModal('edit', '{{ $role['name'] }}')" title="Edit">
                  <i class="mdi mdi-pencil-outline"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-text-danger" data-bs-toggle="modal" data-bs-target="#deleteRoleModal" onclick="document.getElementById('deleteRoleName').innerText='{{ $role['name'] }}'" title="Delete">
                  <i class="mdi mdi-delete-outline"></i>
                </button>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>

  {{-- Add / Edit Role Offcanvas Drawer --}}
  <div class="offcanvas offcanvas-end role-drawer" tabindex="-1" id="roleDrawer" aria-labelledby="roleDrawerLabel" style="width: 600px;">
    <div class="offcanvas-header border-bottom">
      <h5 class="offcanvas-title" id="roleDrawerLabel">Add Role</h5>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column p-0">

      <div class="flex-grow-1 overflow-auto p-3">
        <form>
          <div class="row g-3 mb-3">
            <div class="col-12">
              <label class="form-label fw-semibold">Role Name <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="roleNameInput" placeholder="Enter Role Name">
            </div>
            <div class="col-12">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" role="switch" id="siteManagementSwitch">
                <label class="form-check-label fw-semibold" for="siteManagementSwitch">
                  Site Management Access
                </label>
              </div>
            </div>
          </div>

          <hr>

          <h6 class="fw-bold mb-2">Module Permissions</h6>
          <small class="text-muted d-block mb-3">Expand each module to set access at the submenu level.</small>

          <div class="accordion" id="permissionAccordion">
            @foreach ($permissionModules as $mIndex => $module)
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#module-{{ $mIndex }}">
                    <div class="form-check me-2 mb-0" onclick="event.stopPropagation()">
                      <input class="form-check-input module-select-all" type="checkbox" id="moduleAll-{{ $mIndex }}" data-module="{{ $mIndex }}">
                    </div>
                    <i class="{{ $module['icon'] }} me-2"></i> {{ $module['name'] }}
                  </button>
                </h2>
                <div id="module-{{ $mIndex }}" class="accordion-collapse collapse" data-bs-parent="#permissionAccordion">
                  <div class="accordion-body p-0">
                    <div class="table-responsive">
                      <table class="table table-sm mb-0 permission-table">
                        <thead>
                          <tr>
                            <th style="width:34%;">Submenu</th>
                            <th class="text-center">View</th>
                            <th class="text-center">Create</th>
                            <th class="text-center">Edit</th>
                            <th class="text-center">Delete</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach ($module['submenus'] as $sIndex => $submenu)
                            <tr>
                              <td>{{ $submenu['name'] }}</td>
                              @foreach (['view', 'create', 'edit', 'delete'] as $perm)
                                <td class="text-center">
                                  <input class="form-check-input perm-checkbox" type="checkbox" data-module="{{ $mIndex }}" data-perm="{{ $perm }}">
                                </td>
                              @endforeach
                            </tr>
                          @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            @endforeach
          </div>
        </form>
      </div>

      <div class="border-top p-3 d-flex justify-content-end gap-2 bg-white role-drawer-footer">
        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
        <button type="button" class="btn btn-primary px-4">
          <i class="mdi mdi-content-save-outline me-1"></i> Save Role
        </button>
      </div>

    </div>
  </div>

  {{-- Delete Confirmation Modal --}}
  <div class="modal fade" id="deleteRoleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body text-center p-4">
          <i class="mdi mdi-trash-can-outline text-danger fs-1"></i>
          <h6 class="fw-bold mt-2">Delete Role?</h6>
          <p class="text-muted mb-0">Are you sure you want to delete <strong id="deleteRoleName"></strong>? This action cannot be undone.</p>
        </div>
        <div class="modal-footer justify-content-center border-0 pt-0">
          <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger px-4" data-bs-dismiss="modal">Delete</button>
        </div>
      </div>
    </div>
  </div>

  <style>
  .settings-card {
    border: 1px solid #eef0f2;
    border-radius: 14px;
    box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
  }
  .settings-card .card-header {
    padding: 1rem 1.25rem;
  }
  .role-drawer-footer {
    position: sticky;
    bottom: 0;
  }
  .accordion-button:not(.collapsed) {
    background-color: #ecf7ff;
    color: #16659E;
  }
  .accordion-button:focus {
    box-shadow: none;
  }
  .permission-table thead th {
    background: #f8f9fa;
    font-size: .72rem;
    text-transform: uppercase;
    color: #6c757d;
    font-weight: 600;
  }
  .permission-table td, .permission-table th {
    padding: .6rem .75rem;
    vertical-align: middle;
  }
</style>

  <script>
    function openRoleModal(mode, roleName = '') {
      const title = document.getElementById('roleDrawerLabel');
      const nameInput = document.getElementById('roleNameInput');

      if (mode === 'edit') {
        title.innerText = 'Edit Role';
        nameInput.value = roleName;
      } else {
        title.innerText = 'Add Role';
        nameInput.value = '';
        document.getElementById('siteManagementSwitch').checked = false;
        document.querySelectorAll('.perm-checkbox, .module-select-all').forEach(cb => cb.checked = false);
      }
    }

    // Module "select all" toggles every CRUD checkbox under that module.
    document.querySelectorAll('.module-select-all').forEach(masterBox => {
      masterBox.addEventListener('change', function () {
        const moduleIndex = this.dataset.module;
        document.querySelectorAll(`.perm-checkbox[data-module="${moduleIndex}"]`)
          .forEach(cb => cb.checked = masterBox.checked);
      });
    });

    // If every checkbox in a module gets manually checked, sync the module master checkbox.
    document.querySelectorAll('.perm-checkbox').forEach(cb => {
      cb.addEventListener('change', function () {
        const moduleIndex = this.dataset.module;
        const moduleBoxes = document.querySelectorAll(`.perm-checkbox[data-module="${moduleIndex}"]`);
        const allChecked = Array.from(moduleBoxes).every(box => box.checked);
        document.getElementById(`moduleAll-${moduleIndex}`).checked = allChecked;
      });
    });

  function toggleRoleStatus(toggle, roleName) {
    const statusText = toggle
      .closest('.form-switch')
      .querySelector('.role-status-text');

    if (toggle.checked) {
      statusText.innerText = 'Active';
      statusText.classList.remove('text-secondary');
      statusText.classList.add('text-success');

      console.log(`${roleName} is now Active`);
    } else {
      statusText.innerText = 'Inactive';
      statusText.classList.remove('text-success');
      statusText.classList.add('text-secondary');

      console.log(`${roleName} is now Inactive`);
    }
  }

</script>

@endsection