@extends('layouts/layoutMaster')

@section('title', 'General Settings')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

  @include('layouts.sections.settings.settings-header', ['activeTab' => 'general'])

  <form id="validationForm" class="needs-validation" novalidate  method="POST" action="{{ route('general_settings_update') }}" enctype="multipart/form-data">
    @csrf

    {{-- Branding --}}
    <div class="card mb-4 settings-card" id="validationForm" class="needs-validation" novalidate  method="POST" action="{{ route('general_settings_update') }}" enctype="multipart/form-data">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-image-outline text-primary"></i> Branding
        </h6>
        <small class="text-muted">Your company logo and browser favicon</small>
      </div>
      <div class="card-body">
        <div class="row g-4">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Logo <span class="text-danger">*</span></label>
            <div class="upload-dropzone">
              @if($logoUrl)
                <img src="{{ $logoUrl }}" class="upload-preview" id="uploadedlogo" alt="Logo preview">
              @else
                <img src="{{ asset('assets/img/Ryans-Logo.png') }}" class="upload-preview" id="uploadedlogo" alt="Logo preview">
              @endif
              <div class="upload-actions">
                <label for="upload" class="btn btn-sm btn-primary">
                  <i class="mdi mdi-tray-arrow-up me-1"></i> Upload
                  <input type="file" id="upload" name="logo" class="file-in" hidden accept="image/png, image/jpeg">
                </label>
                <button type="button" class="btn btn-sm btn-outline-danger file-reset">
                  <i class="mdi mdi-reload"></i>
                </button>
              </div>
              <small class="text-muted d-block mt-2">JPG or PNG. Max 800KB.</small>
            </div>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Fav Icon <span class="text-danger">*</span></label>
            <div class="upload-dropzone">
              @if($favUrl)
                <img src="{{ $favUrl }}" class="upload-preview" id="fav_uploadedlogo" alt="Fav icon preview">
              @else
                <img src="{{ asset('assets/img/Ryans-Fav-icon.jpg') }}" class="upload-preview" id="fav_uploadedlogo" alt="Fav icon preview">
              @endif
              <div class="upload-actions">
                <label for="fav_upload" class="btn btn-sm btn-primary">
                  <i class="mdi mdi-tray-arrow-up me-1"></i> Upload
                  <input type="file" id="fav_upload" name="fav_icon" class="fav_file-in" hidden accept="image/png, image/jpeg">
                </label>
                <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset">
                  <i class="mdi mdi-reload"></i>
                </button>
              </div>
              <small class="text-muted d-block mt-2">JPG or PNG. Max 800KB.</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    {{-- Company Information --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-office-building-outline text-primary"></i> Company Information
        </h6>
        <small class="text-muted">Basic identity and contact details</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Title <span class="text-danger">*</span></label>
            <input type="text" class="form-control" placeholder="Enter Title" id="title" name="title" value="{{ $title ?? '' }}"  >
            <div class="invalid-feedback">Please enter the Title.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Website (URL)</label>
            <input type="text" class="form-control" id="website" name="url"  placeholder="Enter Website (URL)" value="{{ $url ?? '' }}">
            <div class="invalid-feedback">Please enter the Website (URL).</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Email ID</label>
            <input type="text" class="form-control" id="emailid" name="email_id" placeholder="Enter Email ID" value="{{ $email_id ?? '' }}">
            <div class="invalid-feedback">Please enter the Email ID.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Mobile No</label>
            <input type="text" class="form-control" placeholder="Enter Mobile No" id="mobileno" name="mobile_number" value="{{ $mobile_number ?? '' }}">
            <div class="invalid-feedback">Please enter the Mobile No.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Date Format <span class="text-danger">*</span></label>
            <select id="date_format" class="select3 form-select selectpicker w-100" data-style="btn-default"
                name="date_format" data-live-search="true">
                  <option value="d-m-Y" <?php if ($date_format=='d-m-Y' ) { echo 'selected' ; } else { echo '' ; }
                    ?>>dd-mm-yyyy</option>

                <option value="Y-m-d" <?php if ($date_format=='Y-m-d' ) { echo 'selected' ; } else { echo '' ; }
                    ?>>yyyy-mm-dd</option>

                <option value="Y/m/d" <?php if ($date_format=='Y/m/d' ) { echo 'selected' ; } else { echo '' ; }
                    ?>>yyyy/mm/dd</option>

                <option value="d-M-Y" <?php if ($date_format=='d-M-Y' ) { echo 'selected' ; } else { echo '' ; }
                    ?>>dd-mmm-yyyy</option>

                <option value="d/M/Y" <?php if ($date_format=='d/M/Y' ) { echo 'selected' ; } else { echo '' ; }
                    ?>>dd/mmm/yyyy</option>
            </select>
            <div class="invalid-feedback">Please Select Date Format</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Registered Name</label>
            <input type="text" class="form-control" id="registered_name" name="registered_name" placeholder="Enter Registered Name" value="{{ $registered_name ?? '' }}" >
            <div class="invalid-feedback">Please enter the Registered Name.</div>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Tax No</label>
            <input type="text" class="form-control" id="tax_no" name="tax_no" placeholder="Enter Tax No"  value="{{ $tax_no ?? '' }}">
            <div class="invalid-feedback">Please enter the Tax No.</div>
          </div>
        </div>
      </div>
    </div>

    {{-- Address --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-map-marker-outline text-primary"></i> Address
        </h6>
        <small class="text-muted">Registered office location</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Country</label>
            <select id="countryId" name="country" class="select3 form-select">
                <option value="">Select Country</option>
            </select>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">State</label>
            <select id="stateId" name="state" class="select3 form-select">
                <option value="">Select State</option>
            </select>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">City</label>
            <select id="cityId" name="city" class="select3 form-select">
                <option value="">Select City</option>
            </select>
          </div>
          <div class="col-lg-8">
            <label class="form-label fw-semibold">Area / Street</label>
            <textarea class="form-control" rows="2" id="address" name="address" placeholder="Enter Area/Street">{{ $address ?? '' }}</textarea>
          </div>
          <div class="col-lg-4">
            <label class="form-label fw-semibold">Pincode</label>
            <input type="text" class="form-control" id="pincode" name="pincode" placeholder="Enter Pincode" value="{{ $pincode ?? '' }}">
            <div class="invalid-feedback">Please enter the Pincode.</div>
          </div>
        </div>
      </div>
    </div>

    {{-- Social Media --}}
    <div class="card mb-4 settings-card">
      <div class="card-header bg-transparent border-bottom">
        <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
          <i class="mdi mdi-share-variant-outline text-primary"></i> Social Media Links
        </h6>
        <small class="text-muted">Public profile links shown on your site</small>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-facebook text-primary me-1"></i>Facebook</label>
            <input type="text" class="form-control"  placeholder="https://facebook.com/ryaninfra" id="fb_url" name="fb_url" value="{{$fb_url ?? ''}}" >
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-instagram text-danger me-1"></i>Instagram</label>
            <input type="text" class="form-control" placeholder="https://instagram.com/ryaninfra" id="insta_url" name="insta_url" value="{{$insta_url ?? ''}}" >
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-linkedin text-info me-1"></i>LinkedIn</label>
            <input type="text" class="form-control" placeholder="https://linkedin.com/ryan-infra" value="https://www.linkedin.com/ryan-infra/" id="linkedin_url" name="linkedin_url" value="{{$linkedin_url ?? ''}}">  
          </div>
          <div class="col-lg-6">
            <label class="form-label fw-semibold"><i class="mdi mdi-youtube text-danger me-1"></i>YouTube</label>
            <input type="text" class="form-control" placeholder="https://youtube.com/@ryan-infra" value="https://www.youtube.com/ryan-infra" id="fb_url" name="fb_url" value="{{$fb_url ?? ''}}">
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-end align-items-center gap-2 mb-4">
      <button type="reset" class="btn btn-label-secondary">Cancel</button>
      <button type="submit" class="btn btn-primary px-4">
        <i class="mdi mdi-content-save-outline me-1"></i> Update
      </button>
    </div>
  </form>

  <style>
    .settings-card {
      border: 1px solid #eef0f2;
      border-radius: 14px;
      box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
    }
    .settings-card .card-header {
      padding: 1rem 1.25rem;
    }
    .upload-dropzone {
      border: 1px dashed #d8dce1;
      border-radius: 12px;
      padding: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      background: #fafbfc;
    }
    .upload-preview {
      width: 72px;
      height: 72px;
      object-fit: cover;
      border-radius: 10px;
      border: 1px solid #e2e6ea;
      flex-shrink: 0;
    }
    .upload-actions {
      display: flex;
      gap: 0.5rem;
    }
  </style>

  <script>
    let logofile = document.getElementById('uploadedlogo');
    const fileInput = document.querySelector('.file-in'),
      resetFileInput = document.querySelector('.file-reset');

    if (logofile) {
      const resetImage = logofile.src;
      fileInput.onchange = () => {
        if (fileInput.files[0]) {
          logofile.src = window.URL.createObjectURL(fileInput.files[0]);
        }
      };
      resetFileInput.onclick = () => {
        fileInput.value = '';
        logofile.src = resetImage;
      };
    }

    let faviconfile = document.getElementById('fav_uploadedlogo');
    const fav_fileInput = document.querySelector('.fav_file-in'),
      fav_resetFileInput = document.querySelector('.fav_file-reset');

    if (faviconfile) {
      const fav_resetImage = faviconfile.src;
      fav_fileInput.onchange = () => {
        if (fav_fileInput.files[0]) {
          faviconfile.src = window.URL.createObjectURL(fav_fileInput.files[0]);
        }
      };
      fav_resetFileInput.onclick = () => {
        fav_fileInput.value = '';
        faviconfile.src = fav_resetImage;
      };
    }
  </script>

  <script>
    const form = document.getElementById('validationForm');
    const emailInput = document.getElementById('emailid');
    const mobileInput = document.getElementById('mobileno');
   

    emailInput.addEventListener('input', function(event) {
        if (!validateEmail(emailInput.value)) {
            displayError(emailInput, "Please enter a valid email address.");
        } else {
            clearError(emailInput);
        }
    });

    mobileInput.addEventListener('input', function(event) {
        if (!validatePhoneNumber(mobileInput.value)) {
            displayError(mobileInput, "Please enter a 10-digit phone number.");
        } else {
            clearError(mobileInput);
        }
    });

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        if (!form.checkValidity() || !validateEmail(emailInput.value)) {
            displayError(emailInput, "Please enter a valid email address.");
            event.stopPropagation();
        } else if (!validatePhoneNumber(mobileInput.value)) {
            displayError(mobileInput, "Please enter a 10-digit phone number.");
            event.stopPropagation();
        } else {
            form.submit();
            toastr.success('General Setting updated successfully!');
        }

        form.classList.add('was-validated');
    });

    function validateEmail(email) {
        const emailRegex =
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return emailRegex.test(email);
    }

    function validatePhoneNumber(phoneNumber) {
        // Remove non-numeric characters from phone number
        const numericPhoneNumber = phoneNumber.replace(/\D/g, '');
        return numericPhoneNumber.length === 10; // Assuming you want exactly 10 digits
    }

    function displayError(input, message) {
        const feedbackElement = input.nextElementSibling;
        feedbackElement.innerText = message;
        input.classList.add('is-invalid');
    }

    function clearError(input) {
        const feedbackElement = input.nextElementSibling;
        feedbackElement.innerText = "";
        input.classList.remove('is-invalid');
    }
</script>

<script>
  //   document.addEventListener('DOMContentLoaded', function() {
  //     const logoFileInput = document.querySelector('.file-in');
  //     const logoResetButton = document.querySelector('.file-reset');
  //     const faviconFileInput = document.querySelector('.fav_file-in');
  //     const faviconResetButton = document.querySelector('.fav_file-reset');

  //     // Function to reset logo image and input
  //     logoResetButton.addEventListener('click', function() {
  //         const logoImage = document.getElementById('uploadedlogo');
  //         const resetLogoImage = "{{ $logoUrl ?? asset('assets/common/logo_small.png') }}"; // Replace with the initial logo path
  //         logoImage.src = resetLogoImage;
  //         logoFileInput.value = null;
  //     });

  //     // Function to reset favicon image and input
  //     faviconResetButton.addEventListener('click', function() {
  //         const faviconImage = document.getElementById('fav_uploadedlogo');
  //         const resetFaviconImage ="{{ $logoUrl ?? asset('assets/common/logo_small.png') }}";  // Replace with the initial favicon path
  //         faviconImage.src = resetFaviconImage;
  //         faviconFileInput.value = null;
  //     });

  //     // Function to preview logo image
  //     logoFileInput.addEventListener('change', function() {
  //         const logoImage = document.getElementById('uploadedlogo');
  //         if (this.files[0]) {
  //             const reader = new FileReader();
  //             reader.onload = function(e) {
  //                 logoImage.src = e.target.result;
  //             };
  //             reader.readAsDataURL(this.files[0]);
  //         }
  //     });

  //     // Function to preview favicon image
  //     faviconFileInput.addEventListener('change', function() {
  //         const faviconImage = document.getElementById('fav_uploadedlogo');
  //         if (this.files[0]) {
  //             const reader = new FileReader();
  //             reader.onload = function(e) {
  //                 faviconImage.src = e.target.result;
  //             };
  //             reader.readAsDataURL(this.files[0]);
  //         }
  //     });
  // });
</script>

<script>
    $(document).ready(function() {
        var selectedCountryId = "{{ $country }}";
        var selectedStateId = "{{ $state }}";
        var selectedCityId = "{{ $city }}";
        var selectedCurrencyId = "{{ $currency_id }}";

        // Fetch and populate countries
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.sno).text(country.country_name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });

      

        // Event listener for country change
        $('select[name="country"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state"]');
            var cityDropdown = $('select[name="city"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('state_list') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.sno).text(state.state_name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                            console.log('selectedCityId',selectedStateId)
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change
        $('select[name="state"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country"]').val();
            var cityDropdown = $('select[name="city"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country
                $.ajax({
                    url: "{{ route('city_list') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.sno).text(city.city_name));
                            });
                            cityDropdown.val(selectedCityId).trigger('change'); // Set the selected city
                            console.log(selectedCityId)
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });
    });

</script>


@endsection