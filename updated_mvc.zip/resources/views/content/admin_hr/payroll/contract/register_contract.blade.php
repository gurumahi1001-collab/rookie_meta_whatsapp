@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-md-4">

    <!-- Metric 1: Monthly Gross Earnings -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-primary-subtle text-primary p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-credit-card-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Gross
                    Earnings</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-dark fs-4 mb-1 text-truncate">₹1,25,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Sum of Component A across active
                    workforce</span>
            </div>
        </div>
    </div>

    <!-- Metric 2: Monthly Net Take-Home -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-success-subtle text-success p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-check-circle-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Net
                    Take-Home</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-success fs-4 mb-1 text-truncate">₹1,02,500</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Total Net Disbursal across 12
                    personnel</span>
            </div>
        </div>
    </div>

    <!-- Metric 3: Total Monthly CTC Expenditure -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-purple-subtle text-purple p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-chart-pie fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Total Monthly CTC
                    Expenditure</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-purple fs-4 mb-1 text-truncate">₹1,45,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate w-90">Component A (Gross) +
                    Component C(Employer Share)</span>
            </div>
        </div>
    </div>

    <!-- Metric 4: Labour Code Compliance -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle   rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-indigo-subtle text-indigo p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-shield-check-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Labour Code
                    Compliance</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-indigo fs-4 mb-1 text-truncate">100%
                    Verified</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Basic+DA ≥ 50% CTC • PF 12% • ESI
                    3.25%</span>
            </div>
        </div>
    </div>
</div>

<div
    class="payroll-toolbar bg-white border border-light-subtle rounded-4 p-3 shadow-sm d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">

    <!-- Sub-Tab Navigation Group -->
    <div class="nav-scroll-container gap-2">
        {{-- Payroll Register (List View) --}}
        @php
        $isSalaryActive = request()->is('admin-hr/payroll/contract');
        @endphp
        <a href="{{ url('/admin-hr/payroll/contract') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-calendar-check-outline me-1"></i>
            Payroll Register (List View)
        </a>

        {{-- Monthly Variable Adjustments --}}
        @php
        $isPromotionActive = request()->is('/admin-hr/payroll/contract/monthly_variable_adjustment');
        @endphp
        <a href="{{ url('/admin-hr/payroll/contract/monthly_variable_adjustment') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isPromotionActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-trending-up me-1"></i>
            Monthly Variable Adjustments
        </a>

        {{-- Pay Slip Generator & Ledger --}}
        @php
        $isLoanActive = request()->is('/admin-hr/payroll');
        @endphp
        <a href="{{ url('/admin-hr/payroll') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isLoanActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-cash-refund me-1"></i>
            Pay Slip Generator & Ledger
        </a>

    </div>

    <!-- Right Side Controls / Filters -->
    <div class="payroll-controls-group d-flex flex-wrap align-items-center gap-3">

        <!-- Month Selector -->
        <div class="payroll-filter-item d-flex align-items-center gap-2">
            <span class="payroll-filter-label text-uppercase fw-bold text-secondary">Payroll Month:</span>
            <select id="select-payroll-month"
                class="select3 payroll-select form-select form-select-sm border-light-subtle rounded-3 fw-bold text-primary">
                <option value="JUL_2026" selected>July 2026 (Active Cycle)</option>
                <option value="JUN_2026">June 2026 (Disbursed)</option>
                <option value="MAY_2026">May 2026 (Disbursed)</option>
                <option value="APR_2026">April 2026 (Disbursed)</option>
                <option value="MAR_2026">March 2026 (Disbursed)</option>
            </select>
        </div>
    </div>
</div>

<div class="payroll-table-card card border-0 shadow-sm rounded-0 overflow-hidden">

    <!-- Responsive Table Wrapper with Horizontal Scroll -->
    <div class="table-responsive payroll-table-wrapper">
        <table class="table table-hover align-middle text-nowrap mb-0 payroll-table text-start w-100">
            <thead>
                <tr class="payroll-header-row text-uppercase text-secondary fw-bold align-middle">
                    <th scope="col" class="payroll-col-emp ps-3 text-black" style="min-width: 180px;">Employee Details
                    </th>
                    <th scope="col" class="payroll-col-role text-black" style="min-width: 160px;">Designation / Role
                    </th>
                    <th scope="col" class="payroll-col-num text-start payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 150px;">
                        <div>Actual Salary</div>
                        <div class="fw-normal text-muted extra-small lh-1">(Fixed Salary)</div>
                    </th>
                    <th scope="col" class="payroll-col-days text-center text-black" style="min-width: 80px;">Present
                    </th>
                    <th scope="col" class="payroll-col-days text-center text-black" style="min-width: 80px;">Leaves</th>
                    <th scope="col" class="payroll-col-days text-center text-black" style="min-width: 65px;">WO</th>
                    <th scope="col" class="payroll-col-days text-center text-black" style="min-width: 65px;">LOP</th>
                    <th scope="col" class="payroll-col-num text-success text-black" style="min-width: 110px;">Incentive
                    </th>
                    <th scope="col" class="payroll-col-num text-success text-black" style="min-width: 110px;">Bonus</th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>System</div>
                        <div class="fw-normal text-muted extra-small lh-1">Allowance</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-success text-black" style="min-width: 100px;">Arrears
                    </th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 120px;">
                        <div>Gross</div>
                        <div class="fw-normal text-muted extra-small lh-1">Salary</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 140px;">
                        <div>Employee</div>
                        <div class="fw-normal text-muted extra-small lh-1">Share(PF + ESi)</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 150px;">
                        <div>Advance</div>
                        <div class="fw-normal text-muted extra-small lh-1">Salary (Deduction)</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 140px;">
                        <div>Net Take Home</div>
                        <div class="fw-normal text-muted extra-small lh-1">(This Month Net)</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-center payroll-bg-blue-light text-black text-nowrap"
                        style="min-width: 140px;">
                        <div>Employer</div>
                        <div class="fw-normal text-muted extra-small lh-1">Share(PF + ESi)</div>
                    </th>
                    <th scope="col" class="payroll-col-num text-black" style="min-width: 120px;">Total (CTC)</th>
                    <th scope="col" class="payroll-col-action text-center pe-3 text-black" style="min-width: 110px;">
                        Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample Row 1 -->
                <tr class="payroll-row">
                    <td class="ps-3">
                        <div class="d-flex align-items-center gap-2">
                            <span class="fs-5 lh-1">👷‍♂️</span>
                            <div class="lh-sm">
                                <div class="fw-bold text-dark small text-nowrap">Alex Morgan</div>
                                <div class="font-monospace text-muted extra-small">SRK-EMP-0102</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="lh-sm">
                            <div class="fw-semibold text-dark small text-nowrap">Site Supervisor</div>
                            <div class="d-flex align-items-center gap-1 mt-1">
                                <span class="extra-small text-muted">Operations</span>

                            </div>
                        </div>
                    </td>
                    <td class="text-center payroll-bg-blue-subtle">
                        <div class="d-inline-flex align-items-center justify-content-start gap-1">
                            <span class="text-muted font-monospace extra-small">₹</span>
                            <input type="number" min="0" value="45000"
                                class="form-control form-control-sm font-monospace fw-bold payroll-input-sm w-100 text-center" />
                        </div>
                    </td>
                    <td class="text-center">
                        <input type="number" min="0" max="31" value="22"
                            class="form-control form-control-sm text-center font-monospace fw-bold payroll-input-sm mx-auto" />
                    </td>
                    <td class="text-center">
                        <input type="number" min="0" max="31" value="2"
                            class="form-control form-control-sm text-center font-monospace fw-bold payroll-input-sm mx-auto" />
                    </td>
                    <td class="text-center">
                        <span class="font-monospace fw-bold text-secondary small">4</span>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-danger-subtle text-danger font-monospace px-2 py-1">2</span>
                    </td>
                    <td class="text-end">
                        <div class="d-inline-flex align-items-center justify-content-start">
                            <span class="text-success font-monospace">+₹</span>
                            <input type="number" min="0" value="2500"
                                class="form-control form-control-sm font-monospace fw-bold payroll-input-sm payroll-input-emerald" />
                        </div>
                    </td>
                    <td class="text-start">
                        <div class="d-inline-flex align-items-center justify-content-start">
                            <span class="text-success font-monospace fs-7 p-1">+₹</span>
                            <input type="number" min="0" value="1000"
                                class="form-control form-control-sm text-start font-monospace fw-bold payroll-input-sm payroll-input-emerald p-1" />
                        </div>
                    </td>
                    <td class="text-start">
                        <div class="d-inline-flex align-items-center justify-content-end gap-1">
                            <span class="text-indigo font-monospace extra-small">+₹</span>
                            <input type="number" min="0" value="500"
                                class="form-control form-control-sm text-end font-monospace fw-bold payroll-input-sm payroll-input-indigo" />
                        </div>
                    </td>
                    <td class="text-end">
                        <div class="d-inline-flex align-items-center justify-content-end gap-1">
                            <span class="text-success font-monospace extra-small">+₹</span>
                            <input type="number" min="0" value="0"
                                class="form-control form-control-sm text-end font-monospace fw-bold payroll-input-sm payroll-input-emerald" />
                        </div>
                    </td>
                    <td class="text-center font-monospace fw-bold text-dark">₹49,000</td>
                    <td class="text-center font-monospace fw-bold text-danger fs-7">₹3,600</td>
                    <td class="text-end">
                        <div class="d-inline-flex align-items-center justify-content-center gap-1">
                            <span class="text-danger font-monospace">-₹</span>
                            <input type="number" min="0" value="2000"
                                class="form-control form-control-sm text-center font-monospace fw-bold payroll-input-sm payroll-input-rose" />
                        </div>
                    </td>
                    <td class="text-center payroll-bg-emerald-subtle">
                        <span class="badge text-light font-monospace fw-bold px-2 py-1 fs-6">₹43,400</span>
                    </td>
                    <td class="text-center font-monospace fw-bold text-primary fs-6">₹4,200</td>
                    <td class="text-center font-monospace fw-extrabold text-dark-blue fs-7">₹53,200</td>
                    <td class="text-center pe-3">
                        <button type="button"
                            onclick="window.location.href='/admin-hr/payroll/contract/contract_payslip';"
                            class="btn btn-primary btn-sm payroll-btn-action d-inline-flex align-items-center justify-content-center gap-1 mx-auto">
                            <i class="mdi mdi-file-document-outline"></i>
                            <span>View Slip</span>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Footer Summary Banner -->
    <div
        class="payroll-footer-banner bg-primary text-white p-3 p-md-4 d-flex flex-column flex-md-row justify-content-between align-items-stretch align-items-md-center gap-3">
        <div class="lh-sm">
            <span class="text-white text-uppercase fw-bold extra-small tracking-wider d-block mb-1">Payroll Register
                Summary (July 2026)</span>
            <span class="fw-bold text-light">Total Eligible Personnel: 1 Staff Member</span>
        </div>
        <div class="d-flex flex-wrap align-items-center gap-4 font-monospace">
            <div class="lh-sm">
                <span class="extra-small text-white text-uppercase d-block mb-1">Total Gross Earnings</span>
                <span class="fw-bold text-light fs-6">₹49,000</span>
            </div>
            <div class="lh-sm">
                <span class="extra-small text-white text-uppercase d-block mb-1">Total Net Take Home</span>
                <span class="fw-bold text-success fs-6">₹43,400</span>
            </div>
            <div class="lh-sm">
                <span class="extra-small text-white text-uppercase d-block mb-1">Total Disbursal CTC Outflow</span>
                <span class="fw-bold text-warning fs-6">₹53,200</span>
            </div>
        </div>
    </div>

</div>

<style>
/* Mini dashboard start */

/* Custom Palette Colors */
.text-purple {
    color: #7e22ce !important;
}

.bg-purple-subtle {
    background-color: #f3e8ff !important;
}

.text-indigo {
    color: #4f46e5 !important;
}

.bg-indigo-subtle {
    background-color: #e0e7ff !important;
}

/* Metrics Custom Typography & Layout */
.salary-metric-icon {
    width: 48px;
    height: 48px;
}

.salary-metric-label,
.salary-metric-subtext {
    font-size: 0.625rem;
}

.salary-metric-value {
    color: #0c3c62;
}


.salary-metric-card {
    padding: 10px;
}

.salary-metric-icon {
    height: 30px;
    width: 30px;
}

.salary-metric-content {
    padding-left: -15px;
}

/* Mini dashboard start */

/* Navigation Starts */
/* Base Container Styles */
.payroll-toolbar {
    font-family: inherit;
    margin-top: 20px;
}

/* Nav Tab Buttons */
.payroll-tab-btn {
    font-size: 0.75rem;
    color: #475569;
    padding: 0.4rem 0.75rem;
    transition: all 0.2s ease;
}

.payroll-tab-btn:hover {
    color: #0f172a;
}

.payroll-tab-btn.active {
    background-color: #16659e !important;
    color: #ffffff !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

/* Form Select Dropdown */
.payroll-filter-label {
    font-size: 0.625rem;
    letter-spacing: 0.05em;
    color: #94a3b8 !important;
}

.payroll-select {
    font-size: 0.75rem;
    color: #16659e !important;
    background-color: #f8fafc;
    cursor: pointer;
    padding-top: 0.35rem;
    padding-bottom: 0.35rem;
}

.payroll-select:focus {
    border-color: #16659e;
    box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
}

/* Staff Category Filter Pills */
.payroll-pill-btn {
    font-size: 0.6875rem;
    color: #64748b;
    padding: 0.25rem 0.75rem;
}

.payroll-pill-btn:hover {
    color: #0f172a;
}

.payroll-pill-btn.active {
    background-color: #ffffff !important;
    color: #1e293b !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.payroll-pill-btn.pill-primary.active {
    background-color: #2563eb !important;
    color: #ffffff !important;
}

.payroll-pill-btn.pill-warning.active {
    background-color: #d97706 !important;
    color: #ffffff !important;
}

/* Mobile Responsiveness Adjustments */
@media (max-width: 767.98px) {

    .payroll-tabs-group,
    .payroll-controls-group {
        width: 100%;
    }

    .payroll-filter-item {
        width: 100%;
        justify-content: space-between;
    }

    .payroll-select {
        flex-grow: 1;
    }
}

/* Navigation Ends */

/* table starts */
.payroll-table-card {
    font-size: 10px;
    color: black;
    margin-top: 2rem;

}

.table {
    width: 50%;
}

.text-start {
    padding: 0px;
}

.payroll-col-days {}

/* table ends */
</style>

<script>
document.getElementById('viewSlipBtn').addEventListener('click', function() {
    window.location.href = '/admin-hr/payroll/contract/contract_payslip'; // Replace with your URL or route
});
</script>
@endsection
