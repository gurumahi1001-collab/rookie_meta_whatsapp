@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-md-4">
    <!-- Metric 1: Monthly Gross Earnings -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-primary-subtle text-primary p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-credit-card-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Gross
                    Earnings</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-dark fs-4 mb-1 text-truncate">₹1,25,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Sum of Component A across active
                    workforce</span>
            </div>
        </div>
    </div>

    <!-- Metric 2: Monthly Net Take-Home -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-success-subtle text-success p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-check-circle-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Net
                    Take-Home</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-success fs-4 mb-1 text-truncate">₹1,02,500</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Total Net Disbursal across 12
                    personnel</span>
            </div>
        </div>
    </div>

    <!-- Metric 3: Total Monthly CTC Expenditure -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-purple-subtle text-purple p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-chart-pie fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Total Monthly CTC
                    Expenditure</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-purple fs-4 mb-1 text-truncate">₹1,45,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate w-90">Component A (Gross) +
                    Component C(Employer Share)</span>
            </div>
        </div>
    </div>

    <!-- Metric 4: Labour Code Compliance -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle   rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-indigo-subtle text-indigo p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-shield-check-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Labour Code
                    Compliance</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-indigo fs-4 mb-1 text-truncate">100%
                    Verified</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Basic+DA ≥ 50% CTC • PF 12% • ESI
                    3.25%</span>
            </div>
        </div>
    </div>
</div>

<div
    class="payroll-navbar bg-white border border-light-subtle rounded-4 p-3 shadow-sm d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">
    <!-- Sub-Tab Navigation Group -->
    <div class="nav-scroll-container gap-2">
        {{-- Payroll Register (List View) --}}
        @php
        $isSalaryActive = request()->is('/admin-hr/payroll/contract');
        @endphp
        <a href="{{ url('/admin-hr/payroll/contract') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-calendar-check-outline me-1"></i>
            Payroll Register (List View)
        </a>
        {{-- Monthly Variable Adjustments --}}
        @php
        $isPromotionActive = request()->is('admin-hr/payroll/contract/monthly_variable_adjustment');
        @endphp
        <a href="{{ url('/admin-hr/payroll/contract/monthly_variable_adjustment') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isPromotionActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-trending-up me-1"></i>
            Monthly Variable Adjustments
        </a>
        {{-- Pay Slip Generator & Ledger --}}
        @php
        $isLoanActive = request()->is('/admin-hr/payroll/contract/contract_payslip');
        @endphp
        <a href="{{ url('/admin-hr/payroll/contract/contract_payslip') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isLoanActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-cash-refund me-1"></i>
            Pay Slip Generator & Ledger
        </a>
    </div>

    <!-- Right Side Controls / Filters -->
    <div class="payroll-controls-group d-flex flex-wrap align-items-center gap-3">
        <!-- Month Selector -->
        <div class="payroll-filter-item d-flex align-items-center gap-2">
            <span class="payroll-filter-label text-uppercase fw-bold text-secondary">Payroll Month:</span>
            <select id="select-payroll-month"
                class="select3 payroll-select form-select form-select-sm border-light-subtle rounded-3 fw-bold text-primary">
                <option value="JUL_2026" selected>July 2026 (Active Cycle)</option>
                <option value="JUN_2026">June 2026 (Disbursed)</option>
                <option value="MAY_2026">May 2026 (Disbursed)</option>
                <option value="APR_2026">April 2026 (Disbursed)</option>
                <option value="MAR_2026">March 2026 (Disbursed)</option>
            </select>
        </div>
    </div>
</div>

<div class="appraisal-kpi-grid appraisal-kpi-mobile-scroll row g-3">
    <!-- KPI 1 - DAILY PERSONNEL WAGE OUTPUT -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-orange-subtle text-orange rounded-3
                        d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-currency-rupee fs-8"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Daily Personnel Wage Output
                </span>
                <span class="stat-value text-primary-dark font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹{{ is_numeric($totalWagesToday ?? null) ? number_format($totalWagesToday) : ($totalWagesToday ?? '0') }}
                </span>
                <span class="stat-description text-muted d-block">
                    Summed from present workforce checks
                </span>
            </div>
        </div>
    </div>


    <!--KPI 2 - AVG DAILY WAGE BASE RATE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                d-flex align-items-center gap-3 h-100">
            <!-- Icon -->
            <div class="stat-icon-wrapper bg-blue-subtle text-blue
                    rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-cash-clock fs-5"></i>
            </div>

            <!-- Content -->
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Avg Daily Wage Base Rate
                </span>
                <span class="stat-value text-blue font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹850 / Day
                </span>
                <span class="stat-description text-muted d-block">
                    Standard workforce daily rate cadence
                </span>
            </div>
        </div>
    </div>



    <!-- KPI 3 - OVERTIME RATE MULTIPLIER -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-purple-subtle text-purple rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-clock-fast fs-4 "></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Overtime Rate Multiplier
                </span>
                <span class="stat-value text-purple font-monospace fw-bolder d-block fs-5 mb-1">
                    1.5x / 2.0x
                </span>
                <span class="stat-description text-muted d-block">
                    Compliant OT rate as per Labour Code
                </span>
            </div>
        </div>
    </div>
    <!-- KPI 4 - MONTHLY TOTAL COST PROJECTION -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-emerald-subtle text-emerald rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-chart-line fs-4"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Monthly Total Cost Projection
                </span>
                <span class="stat-value text-emerald font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹{{ is_numeric($totalCostProjection ?? null) ? number_format($totalCostProjection) : ($totalCostProjection ?? '0') }}
                </span>
                <span class="stat-description text-muted d-block">
                    Component A + Component C
                </span>
            </div>
        </div>
    </div>
    <!-- KPI 5 - AVERAGE SALARY HIKE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-blue-subtle text-blue rounded-3
    d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-cash-check fs-4"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Total Recovered Amount
                </span>
                <span class="stat-value text-blue font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹66,000
                </span>
                <span class="stat-description text-muted d-block">
                    Recovered via payroll & direct installments
                </span>
            </div>
        </div>
    </div>


    <!-- KPI 6 - ANNUAL PAYROLL BUDGET HIKE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-indigo-subtle text-indigo rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-clock fs-5"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Total Pending Balance
                </span>
                <span class="stat-value text-indigo font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹64,000
                </span>
                <span class="stat-description text-muted d-block">
                    Outstanding loan recovery balance
                </span>
            </div>
        </div>
    </div>
</div>

<!-- Adjustments Table Container Card -->
<div class="card bg-white border shadow-sm my-3 payroll-table-card">
    <!-- Toolbar & Controls -->
    <div
        class="p-3 bg-light bg-opacity-50  d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3 payroll-toolbar">
        <!-- Search & Filter Controls -->
        <div class="d-flex flex-wrap align-items-center gap-2 gap-md-3 flex-grow-1 payroll-toolbar-left">
            <!-- Search Input Wrapper -->
            <div class="d-flex align-items-center bg-white border rounded-2 px-2 py-1 flex-grow-1 payroll-search-container"
                style="min-width: 200px; max-width: 380px;">
                <i class="mdi mdi-magnify text-secondary fs-6 me-2"></i>
                <input type="text"
                    class="form-control form-control-sm border-0 p-0 shadow-none bg-transparent payroll-search-input"
                    placeholder="Search personnel, ID, department..." />
            </div>
            <!-- Filter Toggle Button -->
            <button type="button"
                class="btn btn-sm btn-outline-secondary bg-white text-dark border rounded-2 fw-semibold d-inline-flex align-items-center gap-2 payroll-filter-btn">
                <i class="mdi mdi-filter-variant text-secondary"></i>
                <span>Showing: All Personnel</span>
            </button>
            <!-- Selected Month Badge -->
            <span
                class="badge text-dark bg-white border rounded-2 px-3 py-2 fw-semibold d-none d-lg-inline-block payroll-month-badge">
                Month: July 2026
            </span>
        </div>
        <!-- Action Buttons Group -->
        <div class="d-flex flex-wrap align-items-center gap-2 payroll-action-group">
            <button type="button"
                class="btn btn-sm btn-primary fw-semibold rounded-2 d-inline-flex align-items-center justify-content-center gap-1 payroll-add-btn"
                data-bs-toggle="modal" data-bs-target="#singleAdjustmentModal">
                <i class="mdi mdi-plus-thick"></i>
                <span>Add / Update</span>
            </button>
            <button type="button"
                class="btn btn-sm btn-outline-primary bg-primary-subtle border-primary fw-semibold rounded-2 d-inline-flex align-items-center justify-content-center gap-1 payroll-batch-btn"
                data-bs-toggle="modal" data-bs-target="#batchAdjustmentModal">
                <i class="mdi mdi-currency-usd"></i>
                <span>Batch Apply</span>
            </button>
            <button type="button"
                class="btn btn-sm btn-dark fw-semibold rounded-2 d-inline-flex align-items-center justify-content-center gap-1 payroll-export-btn">
                <i class="mdi mdi-download"></i>
                <span>Export CSV</span>
            </button>
        </div>
    </div>

    <!-- Responsive Table Wrapper -->
    <div class="table-responsive payroll-table-wrapper">
        <table class="table  table-hover align-middle mb-0 text-start payroll-adjustments-table">
            <thead>
                <tr class="bg-light border-bottom text-secondary align-middle payroll-header-row">
                    <th scope="col" class="py-2 px-3 text-start payroll-col-emp">Employee Details</th>
                    <th scope="col" class="py-2 px-3 text-start payroll-col-role">Designation / Dept</th>
                    <th scope="col" class="py-2 px-2 text-end payroll-col-salary">Actual Salary</th>
                    <th scope="col" class="py-2 px-2 text-end payroll-col-incentive">
                        Incentive<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(+
                            Variable)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-bonus">
                        Bonus<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(+
                            Discretionary)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-allowance">
                        System Allowance<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(+
                            Add-on)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-arrears">
                        Arrears<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(+
                            Retroactive)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-advance">
                        Advance Recovery<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(-
                            Deducted)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-end payroll-col-loan">
                        Loan Recovery<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">(-
                            Installment)</span>
                    </th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-net">
                        Net Variable<br /><span class="fw-normal text-muted" style="font-size: 0.65rem;">Impact</span>
                    </th>
                    <th scope="col" class="py-2 px-3 text-center payroll-col-remarks">Remarks / Reason</th>
                    <th scope="col" class="py-2 px-2 text-center payroll-col-status">Status</th>
                </tr>
            </thead>
            <tbody class="payroll-table-body">
                <tr class="payroll-table-row">
                    <!-- Employee Details -->
                    <td class="py-2 px-3 payroll-cell-emp">
                        <div class="d-flex flex-column">
                            <span class="fw-bold text-dark lh-sm payroll-emp-name">Alex Morgan</span>
                            <span class="text-muted font-monospace lh-sm payroll-emp-code">SRK-EMP-0102</span>
                        </div>
                    </td>
                    <!-- Designation / Dept -->
                    <td class="py-2 px-3 payroll-cell-role">
                        <div class="d-flex flex-column">
                            <span class="fw-semibold text-dark lh-sm payroll-role-title">Site Supervisor</span>
                            <span class="text-muted lh-sm payroll-role-dept">Operations</span>
                        </div>
                    </td>
                    <!-- Actual Salary -->
                    <td class="py-2 px-2 text-center font-monospace fw-bold text-dark payroll-cell-salary">
                        ₹45,000
                    </td>
                    <!-- Incentive -->
                    <td class="py-2 px-2 text-end payroll-cell-incentive">
                        <div class="d-flex align-items-center justify-content-end gap-1">
                            <span class="font-monospace text-muted small">+₹</span>
                            <input type="number" min="0" value="2500"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold payroll-input-num" />
                        </div>
                    </td>
                    <!-- Bonus -->
                    <td class="py-2 px-2 text-center payroll-cell-bonus">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <span class="font-monospace text-primary small">+₹</span>
                            <input type="number" min="0" value="1000"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold payroll-input-num" />
                        </div>
                    </td>
                    <!-- Allowance -->
                    <td class="py-2 px-2 text-end payroll-cell-allowance">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <span class="font-monospace text-muted small">+₹</span>
                            <input type="number" min="0" value="500"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold payroll-input-num" />
                        </div>
                    </td>
                    <!-- Arrears -->
                    <td class="py-2 px-2 text-end payroll-cell-arrears">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <span class="font-monospace text-warning-emphasis small">+₹</span>
                            <input type="number" min="0" value="0"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold text-warning-emphasis payroll-input-num" />
                        </div>
                    </td>
                    <!-- Advance Recovery -->
                    <td class="py-2 px-2 text-end payroll-cell-advance">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <span class="font-monospace text-danger small">-₹</span>
                            <input type="number" min="0" value="2000"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold text-danger payroll-input-num" />
                        </div>
                    </td>
                    <!-- Loan Recovery -->
                    <td class="py-2 px-2 text-end payroll-cell-loan">
                        <div class="d-flex align-items-center justify-content-center gap-1">
                            <span class="font-monospace text-muted small">-₹</span>
                            <input type="number" min="0" value="0"
                                class="form-control form-control-sm text-end border rounded font-monospace fw-semibold payroll-input-num" />
                        </div>
                    </td>
                    <!-- Net Variable Impact -->
                    <td class="py-2 px-2 text-center payroll-cell-net">
                        <span class="badge font-monospace fw-bold px-2 py-1 payroll-net-badge">
                            +₹2,000
                        </span>
                    </td>
                    <!-- Remarks Input -->
                    <td class="py-2 px-3 payroll-cell-remarks">
                        <input type="text" placeholder="e.g. Sales Target, Festival Bonus..."
                            value="Sales Target Completed"
                            class="form-control form-control-sm border rounded payroll-remarks-input" />
                    </td>
                    <!-- Status -->
                    <td class="py-2 px-2 text-center payroll-cell-status">
                        <span
                            class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-2 py-1 fw-semibold d-inline-flex align-items-center justify-content-center gap-1 payroll-status-badge">
                            <i class="mdi mdi-check"></i>
                            <span>Synced</span>
                        </span>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Container -->
<div class="modal fade" id="singleAdjustmentModal" tabindex="-1" aria-labelledby="singleAdjustmentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content border-0 rounded-3 overflow-hidden shadow-lg">
            <!-- Form Wrapper -->
            <form id="single-adjustment-form" class="single-adj-form mb-0">
                <!-- Header / Banner -->
                <div class="single-adj-header p-3 p-md-4 text-white d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center gap-3">
                        <div class="single-adj-icon-box p-2 rounded-3 d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-currency-usd text-white fs-5"></i>
                        </div>
                        <div>
                            <h3 class="single-adj-title m-0 fw-bold fs-6 text-white" id="singleAdjustmentModalLabel">
                                Add / Update Employee Adjustment
                            </h3>
                            <p class="single-adj-subtitle m-0 small text-white-50">
                                Set advances, incentives, arrears or bonuses for specific personnel
                            </p>
                        </div>
                    </div>
                    <!-- Close (X) Button -->
                    <button type="button" class="btn single-adj-close-btn p-1 border-0 text-white shadow-none"
                        data-bs-dismiss="modal" aria-label="Close">
                        <i class="mdi mdi-close fs-5"></i>
                    </button>
                </div>

                <!-- Form Content Body -->
                <div class="single-adj-body p-3 p-md-4">
                    <div class="row g-3">
                        <!-- 1. Month Selection -->
                        <div class="col-12">
                            <label for="adjModalMonth" class="form-label single-adj-label">
                                1. Month of Adjustment
                            </label>
                            <select id="adjModalMonth" name="adjModalMonth"
                                class=" select3 form-select form-select-sm single-adj-select">
                                <option value="JUL_2026" selected>July 2026 (Active Cycle)</option>
                                <option value="JUN_2026">June 2026 (Disbursed)</option>
                                <option value="MAY_2026">May 2026 (Disbursed)</option>
                                <option value="APR_2026">April 2026 (Disbursed)</option>
                                <option value="MAR_2026">March 2026 (Disbursed)</option>
                            </select>
                        </div>

                        <!-- 2. Employee Selection -->
                        <div class="col-12">
                            <label for="adjModalEmpId" class="form-label single-adj-label">
                                2. Choose Employee
                            </label>
                            <select id="adjModalEmpId" name="adjModalEmpId"
                                class="select3 form-select form-select-sm single-adj-select">
                                <option value="0102">Alex Morgan (SRK-EMP-0102) — Site Supervisor</option>
                                <option value="0103">Jane Doe (SRK-EMP-0103) — Project Manager</option>
                                <option value="0104">John Smith (SRK-EMP-0104) — Electrical Engineer</option>
                            </select>
                        </div>

                        <!-- 3. Adjustment Name / Component -->
                        <div class="col-12">
                            <label for="adjModalType" class="form-label single-adj-label">
                                3. Choose Adjustment Name
                            </label>
                            <select id="adjModalType" name="adjModalType"
                                class="select3 form-select form-select-sm single-adj-select">
                                <option value="incentive">Monthly Performance Incentive (+ Variable Pay)</option>
                                <option value="bonus">Festive / Discretionary Bonus (+ Bonus Pay)</option>
                                <option value="systemAllowance">System Allowance (+ Variable Add-on)</option>
                                <option value="arrears">Salary Arrears Adjustment (+ Retroactive Pay)</option>
                                <option value="advanceSalary">Advance Salary Recovery (- Salary Deduction)</option>
                                <option value="loanRecovery">Loan Monthly Recovery (- Scheduled Installment)</option>
                            </select>
                        </div>

                        <!-- 4. Adjustment Value -->
                        <div class="col-12">
                            <label for="adjModalValue" class="form-label single-adj-label">
                                4. Adjustment Value (₹)
                            </label>
                            <div class="input-group input-group-sm single-adj-input-group">
                                <span
                                    class="input-group-text bg-light text-secondary border-end-0 font-monospace fw-bold single-adj-addon">₹</span>
                                <input type="number" id="adjModalValue" name="adjModalValue" min="0"
                                    placeholder="Enter adjustment amount in INR..."
                                    class="form-control form-control-sm border-start-0 font-monospace fw-bold single-adj-input"
                                    required />
                            </div>
                        </div>

                        <!-- 5. Remarks / Reason -->
                        <div class="col-12">
                            <label for="adjModalRemarks" class="form-label single-adj-label">
                                5. Remarks / Description (Optional)
                            </label>
                            <input type="text" id="adjModalRemarks" name="adjModalRemarks"
                                placeholder="e.g. Sales Target Achieved, Festival Bonus..."
                                class="form-control form-control-sm single-adj-input" />
                        </div>
                    </div>

                    <!-- Footer Actions -->
                    <div
                        class="single-adj-footer pt-3 mt-4 border-top d-flex align-items-center justify-content-end gap-2">
                        <button type="button"
                            class="btn btn-sm btn-outline-secondary px-3 py-2 fw-bold single-adj-cancel-btn"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit"
                            class="btn btn-sm btn-primary px-4 py-2 fw-bold d-inline-flex align-items-center gap-2 single-adj-submit-btn">
                            <i class="mdi mdi-check-circle-outline"></i>
                            <span>Submit Adjustment</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Batch Adjustment Modal Container -->
<div class="modal fade" id="batchAdjustmentModal" tabindex="-1" aria-labelledby="batchAdjustmentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content border-0 rounded-3 overflow-hidden shadow-lg batch-adj-modal-content">

            <!-- Modal Header / Banner -->
            <div class="batch-adj-header p-3 p-md-4 text-white d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                    <div class="batch-adj-icon-box p-2 rounded-3 d-flex align-items-center justify-content-center">
                        <i class="mdi mdi-currency-usd text-white fs-5"></i>
                    </div>
                    <div>
                        <h3 class="batch-adj-title m-0 fw-bold fs-6 text-white" id="batchAdjustmentModalLabel">
                            Apply Batch Variable Adjustment
                        </h3>
                        <p class="batch-adj-subtitle m-0 small text-white-50">
                            Month: July 2026
                        </p>
                    </div>
                </div>
                <!-- Close (X) Button -->
                <button type="button" class="btn batch-adj-close-btn p-1 border-0 text-white shadow-none"
                    data-bs-dismiss="modal" aria-label="Close">
                    <i class="mdi mdi-close fs-5"></i>
                </button>
            </div>

            <!-- Modal Form Body -->
            <form id="batch-adjustment-form" class="batch-adj-form mb-0">
                <div class="batch-adj-body p-3 p-md-4">
                    <div class="row g-3">

                        <!-- 1. Adjustment Type -->
                        <div class="col-12">
                            <label for="batchComponentType" class="form-label batch-adj-label">
                                Adjustment Type
                            </label>
                            <select id="batchComponentType" name="batchComponentType"
                                class="select3 form-select form-select-sm batch-adj-select">
                                <option value="bonus" selected>Festive / Discretionary Bonus (+₹)</option>
                                <option value="incentive">Monthly Performance Incentive (+₹)</option>
                                <option value="systemAllowance">System Allowance (+ Add-on)</option>
                                <option value="arrears">Salary Arrears Adjustment (+₹)</option>
                                <option value="advanceSalary">Advance Salary Recovery (-₹)</option>
                                <option value="loanRecovery">Loan Monthly Recovery (- Installment Deduction)</option>
                            </select>
                        </div>

                        <!-- 2. Amount per Personnel -->
                        <div class="col-12">
                            <label for="batchAmount" class="form-label batch-adj-label">
                                Amount per Personnel (₹)
                            </label>
                            <div class="input-group input-group-sm batch-adj-input-group">
                                <span
                                    class="input-group-text bg-light text-secondary border-end-0 font-monospace fw-bold batch-adj-addon">₹</span>
                                <input type="number" id="batchAmount" name="batchAmount" min="0" placeholder="0"
                                    class="form-control form-control-sm border-start-0 font-monospace fw-bold batch-adj-input"
                                    required />
                            </div>
                        </div>

                        <!-- 3. Staff Category -->
                        <div class="col-12">
                            <label for="batchStaffType" class="form-label batch-adj-label">
                                Applies To Staff Category
                            </label>
                            <select id="batchStaffType" name="batchStaffType"
                                class="select3 form-select form-select-sm batch-adj-select">
                                <option value="ALL" selected>All Active Personnel (45)</option>
                                <option value="Permanent">Permanent Staff Only (32)</option>
                                <option value="Contract">Contract Workers Only (13)</option>
                            </select>
                        </div>

                        <!-- 4. Remarks / Reason -->
                        <div class="col-12">
                            <label for="batchRemarks" class="form-label batch-adj-label">
                                Adjustment Remarks / Reason
                            </label>
                            <input type="text" id="batchRemarks" name="batchRemarks"
                                placeholder="e.g. Festival Bonus, Diwali Payout, Target Incentive..."
                                class="form-control form-control-sm batch-adj-input" />
                        </div>
                    </div>

                    <!-- Modal Actions Footer -->
                    <div
                        class="batch-adj-footer pt-3 mt-4 border-top d-flex align-items-center justify-content-end gap-2">
                        <button type="button"
                            class="btn btn-sm btn-outline-secondary px-3 py-2 fw-bold batch-adj-cancel-btn"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit"
                            class="btn btn-sm btn-primary px-4 py-2 fw-bold d-inline-flex align-items-center gap-2 batch-adj-submit-btn">
                            <i class="mdi mdi-check-circle-outline"></i>
                            <span>Apply Batch Payout</span>
                        </button>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
<style>
/* Mini dashboard start */

/* Custom Palette Colors */
.text-purple {
    color: #7e22ce !important;
}

.bg-purple-subtle {
    background-color: #f3e8ff !important;
}

.text-indigo {
    color: #4f46e5 !important;
}

.bg-indigo-subtle {
    background-color: #e0e7ff !important;
}

/* Metrics Custom Typography & Layout */
.salary-metric-icon {
    width: 48px;
    height: 48px;
}

.salary-metric-label,
.salary-metric-subtext {
    font-size: 0.625rem;
}

.salary-metric-value {
    color: #0c3c62;
}


.salary-metric-card {
    padding: 10px;
}

.salary-metric-icon {
    height: 30px;
    width: 30px;
}

.salary-metric-content {
    padding-left: -15px;
}

/* Mini dashboard start */

/* Navigation Starts */
/* Base Container Styles */
.payroll-navbar {
    margin-top: 15px;
}



.payroll-toolbar {
    font-family: inherit;
    margin-top: 0px;

}

/* Nav Tab Buttons */
.payroll-tab-btn {
    font-size: 0.75rem;
    color: #475569;
    padding: 0.4rem 0.75rem;
    transition: all 0.2s ease;
}

.payroll-tab-btn:hover {
    color: #0f172a;
}

.payroll-tab-btn.active {
    background-color: #16659e !important;
    color: #ffffff !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

/* Form Select Dropdown */
.payroll-filter-label {
    font-size: 0.625rem;
    letter-spacing: 0.05em;
    color: #94a3b8 !important;
}

.payroll-select {
    font-size: 0.75rem;
    color: #16659e !important;
    background-color: #f8fafc;
    cursor: pointer;
    padding-top: 0.35rem;
    padding-bottom: 0.35rem;
}

.payroll-select:focus {
    border-color: #16659e;
    box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
}

/* Staff Category Filter Pills */
.payroll-pill-btn {
    font-size: 0.6875rem;
    color: #64748b;
    padding: 0.25rem 0.75rem;
}

.payroll-pill-btn:hover {
    color: #0f172a;
}

.payroll-pill-btn.active {
    background-color: #ffffff !important;
    color: #1e293b !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.payroll-pill-btn.pill-primary.active {
    background-color: #2563eb !important;
    color: #ffffff !important;
}

.payroll-pill-btn.pill-warning.active {
    background-color: #d97706 !important;
    color: #ffffff !important;
}

/* Mobile Responsiveness Adjustments */
@media (max-width: 767.98px) {

    .payroll-tabs-group,
    .payroll-controls-group {
        width: 100%;
    }

    .payroll-filter-item {
        width: 100%;
        justify-content: space-between;
    }

    .payroll-select {
        flex-grow: 1;
    }
}

/* Navigation Ends */

/* KPI Cards start */
/*  APPRAISAL / WAGE KPI GRID - BASE STYLES */
.appraisal-kpi-grid {
    width: 100%;
    margin-left: 0;
    margin-right: 0;
    margin-top: 10px;
}

/* Stat Card Shell */
.stat-card {
    width: 100%;
    min-height: 110px;
    overflow: hidden;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08) !important;
}

/* Icon Wrapper Alignment */
.stat-icon-wrapper {
    width: 42px;
    height: 42px;
    min-width: 42px;
    flex: 0 0 42px;
}

.stat-icon-wrapper i {
    line-height: 1;
}

/* Typography Base Defaults */
.stat-card>div:last-child {
    min-width: 0;
}

.stat-label {
    font-size: 10px;
    line-height: 1.25;
    letter-spacing: 0.04em;
    white-space: normal;
}

.stat-value {
    font-size: 15px !important;
    line-height: 1.2;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.stat-description {
    font-size: 8.5px;
    line-height: 1.3;
    color: #94a3b8;
    white-space: normal;
}

/* Color Palette Utility Classes */
.bg-orange-subtle {
    background-color: #fff7ed;
}

.text-orange {
    color: #ea580c;
}

.bg-blue-subtle {
    background-color: #eff6ff;
}

.text-blue {
    color: #2563eb;
}

.bg-purple-subtle {
    background-color: #faf5ff;
}

.text-purple {
    color: #9333ea;
}

.bg-emerald-subtle {
    background-color: #ecfdf5;
}

.text-emerald {
    color: #059669;
}

.bg-indigo-subtle {
    background-color: #eef2ff;
}

.text-indigo {
    color: #4f46e5;
}

.text-primary-dark {
    color: #0c3c62;
}


/* RESPONSIVE BREAKPOINT ALIGNMENTS */

/* 1. Mobile Horizontal Scroll View (max-width: 575.98px) */
@media (max-width: 575.98px) {
    .nav-action-btn {
        width: 100%;
    }

    .appraisal-kpi-mobile-scroll {
        display: flex !important;
        flex-wrap: nowrap !important;
        overflow-x: auto;
        overflow-y: hidden;
        scroll-behavior: smooth;
        -webkit-overflow-scrolling: touch;
        scroll-snap-type: x mandatory;
        padding-bottom: 4px;
        scrollbar-width: none;
        /* Hide standard scrollbar */
    }

    .appraisal-kpi-mobile-scroll::-webkit-scrollbar {
        display: none;
    }

    /* Fixed 2-Card Visible Width Ratio */
    .appraisal-kpi-mobile-scroll .stat-card-item {
        flex: 0 0 calc(50% - 0.375rem) !important;
        width: calc(50% - 0.375rem) !important;
        max-width: calc(50% - 0.375rem) !important;
        padding-left: 3px;
        padding-right: 3px;
        scroll-snap-align: start;
    }

    .appraisal-kpi-mobile-scroll .stat-card {
        min-height: 105px;
        padding: 10px !important;
        gap: 8px !important;
        border-radius: 14px !important;
    }

    .appraisal-kpi-mobile-scroll .stat-icon-wrapper {
        width: 36px;
        height: 36px;
        min-width: 36px;
        flex: 0 0 36px;
    }

    .appraisal-kpi-mobile-scroll .stat-label {
        font-size: 8.5px;
    }

    .appraisal-kpi-mobile-scroll .stat-value {
        font-size: 13.5px !important;
    }

    .appraisal-kpi-mobile-scroll .stat-description {
        font-size: 7.5px;
    }
}

/* 2. Tablet / Small Screens (576px - 991.98px) */
@media (min-width: 576px) and (max-width: 991.98px) {
    .stat-card {
        min-height: 115px;
        padding: 12px !important;

    }

    .stat-label {
        font-size: 9.5px;

    }

    .stat-value {
        font-size: 15px !important;
    }
}

/* 3. Laptops (992px - 1199.98px) */
@media (min-width: 992px) and (max-width: 1199.98px) {
    .stat-card {
        min-height: 118px;
    }

    .stat-label {
        font-size: 10px;
    }

    .stat-value {
        font-size: 16px !important;
    }
}

/* 4. Large Desktop - 6 Cards side-by-side in 1 Row (min-width: 1200px) */
@media (min-width: 1200px) {
    .appraisal-kpi-grid .stat-card-item {
        flex: 0 0 16.666667%;
        max-width: 16.666667%;


    }

    .stat-card {
        min-height: 120px;
        padding: 14px !important;
        border-radius: 15px;
    }

    .stat-label {
        font-size: 10.5px;
    }

    .stat-value {
        font-size: 16.5px !important;
    }

    .stat-description {
        font-size: 8.5px;
    }

    .stat-icon-wrapper {
        width: 40px;
        height: 40px;
        min-width: 40px;
        flex: 0 0 40px;
    }

    .appraisal-toolbar {
        margin-top: 13px;
    }
}

/* KPI Cards end */

/* list content start */
/* Card & Overall Wrapper Layout */


/* Header Baseline Adjustments */
.payroll-header-row th {
    font-size: 0.725rem;
    letter-spacing: 0.03em;
    text-transform: uppercase;
    font-weight: 700;
    color: #495057 !important;
    background-color: #f8f9fa !important;
    white-space: nowrap;
    vertical-align: bottom;
}

/* Specific Column Width Restrictions for Precision Grid Alignment */
.payroll-col-emp {
    min-width: 160px;
}

.payroll-col-role {
    min-width: 140px;
}

.payroll-col-salary {
    min-width: 100px;
}

.payroll-col-incentive,
.payroll-col-bonus,
.payroll-col-allowance,
.payroll-col-arrears,
.payroll-col-advance,
.payroll-col-loan {
    min-width: 110px;
}

.payroll-col-net {
    min-width: 100px;
}

.payroll-col-remarks {
    min-width: 180px;
}

.payroll-col-status {
    min-width: 90px;
}

/* Subtext & Code Styling */
.payroll-emp-code,
.payroll-role-dept {
    font-size: 0.7rem;
}

/* Input Fields Alignment & Spinners Removal */
.payroll-input-num {
    width: 70px;
    font-size: 0.75rem;
    padding: 0.2rem 0.4rem;
    -moz-appearance: textfield;
}

.payroll-input-num::-webkit-outer-spin-button,
.payroll-input-num::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.payroll-remarks-input {
    font-size: 0.75rem;
    padding: 0.2rem 0.5rem;
}

.payroll-remarks-input::placeholder {
    color: #adb5bd;
    font-size: 0.725rem;
}

.payroll-input-num:focus,
.payroll-remarks-input:focus {
    border-color: #86b7fe;
    box-shadow: 0 0 0 0.15rem rgba(13, 110, 253, 0.2);
}

/* Badge Tweaks */
.payroll-net-badge {
    background-color: #eef2ff;
    color: #3730a3;
    border: 1px solid #c7d2fe;
    font-size: 0.75rem;
}

.payroll-status-badge {
    font-size: 0.685rem;
}


.payroll-table-card {
    border-left: 0 !important;
    border-right: 0 !important;
    border-radius: 0 !important;
}

/* list content end */


/* Add update starts  */
/* Component Container Wrapper */
.single-adj-form {
    background-color: #ffffff;
    border-radius: 0.75rem;
    overflow: hidden;
    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
}

/* Gradient Header */
.single-adj-header {
    background: linear-gradient(135deg, #0C3C62 0%, #16659E 50%, #1e78b8 100%);
}

.single-adj-icon-box {
    background-color: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(4px);
    width: 36px;
    height: 36px;
}

.single-adj-subtitle {
    font-size: 0.725rem;
}

.single-adj-close-btn {
    background-color: rgba(255, 255, 255, 0.15);
    border-radius: 0.5rem;
    transition: background-color 0.2s ease;
}

.single-adj-close-btn:hover {
    background-color: rgba(255, 255, 255, 0.25);
}

/* Field Labels */
.single-adj-label {
    font-size: 0.675rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #64748b;
    margin-bottom: 0.35rem;
}

/* Controls & Inputs */
.single-adj-select,
.single-adj-input {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem;
    font-size: 0.8rem;
    font-weight: 600;
    color: #1e293b;
    padding: 0.5rem 0.75rem;
}

.single-adj-addon {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem 0 0 0.5rem;
    font-size: 0.8rem;
}

.single-adj-input-group .single-adj-input {
    border-radius: 0 0.5rem 0.5rem 0;
}

/* Input Focus States */
.single-adj-select:focus,
.single-adj-input:focus {
    background-color: #ffffff;
    border-color: #16659E;
    box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.15);
}

/* Custom Buttons */
.single-adj-cancel-btn {
    border-color: #cbd5e1;
    color: #475569;
    border-radius: 0.5rem;
    font-size: 0.775rem;
}

.single-adj-cancel-btn:hover {
    background-color: #f8fafc;
    color: #1e293b;
    border-color: #94a3b8;
}

.single-adj-submit-btn {
    background-color: #16659E;
    border-color: #16659E;
    color: #ffffff;
    border-radius: 0.5rem;
    font-size: 0.775rem;
    transition: background-color 0.2s ease;
}

.single-adj-submit-btn:hover {
    background-color: #0C3C62;
    border-color: #0C3C62;
}

/* Add update ends  */
/* Batch starts */
/* Card & Header Formatting */
.batch-adj-modal-content {
    background-color: #ffffff;
}

.batch-adj-header {
    background: linear-gradient(135deg, #0C3C62 0%, #16659E 50%, #1e78b8 100%);
}

.batch-adj-icon-box {
    background-color: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(4px);
    width: 36px;
    height: 36px;
}

.batch-adj-subtitle {
    font-size: 0.725rem;
}

.batch-adj-close-btn {
    background-color: rgba(255, 255, 255, 0.15);
    border-radius: 0.5rem;
    transition: background-color 0.2s ease;
}

.batch-adj-close-btn:hover {
    background-color: rgba(255, 255, 255, 0.25);
}

/* Field Labels */
.batch-adj-label {
    font-size: 0.675rem;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #64748b;
    margin-bottom: 0.35rem;
}

/* Form Controls & Inputs */
.batch-adj-select,
.batch-adj-input {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem;
    font-size: 0.8rem;
    font-weight: 600;
    color: #1e293b;
    padding: 0.5rem 0.75rem;
}

.batch-adj-addon {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem 0 0 0.5rem;
    font-size: 0.8rem;
}

.batch-adj-input-group .batch-adj-input {
    border-radius: 0 0.5rem 0.5rem 0;
}

/* Focus Highlights */
.batch-adj-select:focus,
.batch-adj-input:focus {
    background-color: #ffffff;
    border-color: #16659E;
    box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.15);
}

/* Buttons */
.batch-adj-cancel-btn {
    border-color: #cbd5e1;
    color: #475569;
    border-radius: 0.5rem;
    font-size: 0.775rem;
}

.batch-adj-cancel-btn:hover {
    background-color: #f8fafc;
    color: #1e293b;
    border-color: #94a3b8;
}

.batch-adj-submit-btn {
    background-color: #16659E;
    border-color: #16659E;
    color: #ffffff;
    border-radius: 0.5rem;
    font-size: 0.775rem;
    transition: background-color 0.2s ease;
}

.batch-adj-submit-btn:hover {
    background-color: #0C3C62;
    border-color: #0C3C62;
}

/* Batch ends */
</style>
@endsection
