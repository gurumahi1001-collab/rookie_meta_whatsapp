@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<div class="row g-3 g-md-4">
    <!-- Metric 1: Monthly Gross Earnings -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-primary-subtle text-primary p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-credit-card-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Gross
                    Earnings</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-dark fs-4 mb-1 text-truncate">₹1,25,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Sum of Component A across active
                    workforce</span>
            </div>
        </div>
    </div>

    <!-- Metric 2: Monthly Net Take-Home -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle  rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-success-subtle text-success p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-check-circle-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Monthly Net
                    Take-Home</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-success fs-4 mb-1 text-truncate">₹1,02,500</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Total Net Disbursal across 12
                    personnel</span>
            </div>
        </div>
    </div>

    <!-- Metric 3: Total Monthly CTC Expenditure -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-purple-subtle text-purple p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-chart-pie fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Total Monthly CTC
                    Expenditure</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-purple fs-4 mb-1 text-truncate">₹1,45,000</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate w-90">Component A (Gross) +
                    Component C(Employer Share)</span>
            </div>
        </div>
    </div>

    <!-- Metric 4: Labour Code Compliance -->
    <div class="col-12 col-sm-6 col-lg-3">
        <div
            class="salary-metric-card bg-white border border-light-subtle   rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="salary-metric-icon bg-indigo-subtle text-indigo p-3 rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-shield-check-outline fs-4"></i>
            </div>
            <div class="salary-metric-content overflow-hidden">
                <span class="salary-metric-label d-block text-uppercase fw-bold text-secondary mb-1">Labour Code
                    Compliance</span>
                <span
                    class="salary-metric-value d-block font-monospace fw-black text-indigo fs-4 mb-1 text-truncate">100%
                    Verified</span>
                <span class="salary-metric-subtext d-block text-muted text-truncate">Basic+DA ≥ 50% CTC • PF 12% • ESI
                    3.25%</span>
            </div>
        </div>
    </div>
</div>

<div
    class="payroll-navbar bg-white border border-light-subtle rounded-4 p-3 shadow-sm d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">
    <!-- Sub-Tab Navigation Group -->
    <div class="nav-scroll-container gap-2">
        {{-- Payroll Register (List View) --}}
        @php
        $isSalaryActive = request()->is('/admin-hr/payroll');
        @endphp
        <a href="{{ url('/admin-hr/payroll') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-calendar-check-outline me-1"></i>
            Payroll Register (List View)
        </a>
        {{-- Monthly Variable Adjustments --}}
        @php
        $isPromotionActive = request()->is('/admin-hr/payroll/monthly_variable_adjustment');
        @endphp
        <a href="{{ url('/admin-hr/payroll/monthly_variable_adjustment') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isPromotionActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-trending-up me-1"></i>
            Monthly Variable Adjustments
        </a>
        {{-- Pay Slip Generator & Ledger --}}
        @php
        $isLoanActive = request()->is('admin-hr/payroll/permanent_payslip');
        @endphp
        <a href="{{ url('/admin-hr/payroll/permanent_payslip') }}"
            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isLoanActive ? 'btn-primary' : 'btn-light' }}">
            <i class="mdi mdi-cash-refund me-1"></i>
            Pay Slip Generator & Ledger
        </a>
    </div>

    <!-- Right Side Controls / Filters -->
    <div class="payroll-controls-group d-flex flex-wrap align-items-center gap-3">
        <!-- Month Selector -->
        <div class="payroll-filter-item d-flex align-items-center gap-2">
            <span class="payroll-filter-label text-uppercase fw-bold text-secondary">Payroll Month:</span>
            <select id="select-payroll-month"
                class="select3 payroll-select form-select form-select-sm border-light-subtle rounded-3 fw-bold text-primary">
                <option value="JUL_2026" selected>July 2026 (Active Cycle)</option>
                <option value="JUN_2026">June 2026 (Disbursed)</option>
                <option value="MAY_2026">May 2026 (Disbursed)</option>
                <option value="APR_2026">April 2026 (Disbursed)</option>
                <option value="MAR_2026">March 2026 (Disbursed)</option>
            </select>
        </div>
    </div>
</div>


<div class="row g-3 font-sans payroll-container">

    <!-- Left Column: Payroll Registry Sheet -->
    <div class="col-12 col-lg-6 col-xl-6">
        <div class="card border shadow-sm rounded-4 overflow-hidden payroll-registry-card">

            <!-- Registry Header with Controls -->
            <div
                class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center payroll-registry-header">
                <div>
                    <h3 class="fs-7 fw-bold text-uppercase tracking-wider text-primary mb-0 registry-title">
                        Payroll Generation Registry
                    </h3>
                    <p class="fs-8 text-muted mb-0 registry-subtitle">
                        Configure Indian Labour Law salary components
                    </p>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <!-- <button type="button" class="payroll-create-btn" id="btnToggleSalaryEdit">
                        <span class="fs-7">+</span>
                        <span id="createBtnText">Create</span>
                    </button> -->
                    <span class="badge bg-secondary-subtle text-secondary border font-monospace fs-9">
                        12 Records
                    </span>
                </div>
            </div>

            <!-- Scrollable Employee List Container -->
            <div class="list-group list-group-flush overflow-auto payroll-employee-list" style="max-height: 560px;">

                <!-- EMPLOYEE 1 (Active / Selected) -->
                <a href="#" class="list-group-item list-group-item-action p-3 payroll-emp-item active-item"
                    id="payslip-emp-item-1">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="emp-avatar-bg">👷‍♂️</div>
                            <div>
                                <p class="mb-0 fw-bolder text-dark fs-7 emp-name">Rajesh Kumar</p>
                                <p class="mb-0 fs-8 text-muted font-monospace mt-0.5 emp-meta">
                                    SRK-EMP-001 • Senior Engineer
                                </p>
                            </div>
                        </div>
                        <span class="emp-chevron">›</span>
                    </div>

                    <!-- Financial Breakdown Block -->
                    <div class="p-2 rounded-2 d-flex justify-content-between align-items-center payroll-summary-block">
                        <div>
                            <span class="d-block text-uppercase fw-bold text-muted fs-9">Gross A</span>
                            <span class="font-monospace fw-bold text-dark fs-8">₹50,000</span>
                        </div>
                        <div class="text-end">
                            <span class="d-block text-uppercase fw-bold text-success fs-9">Net Take-Home</span>
                            <span class="font-monospace fw-bold text-success fs-7">₹44,250</span>
                        </div>
                    </div>
                </a>

                <!-- EMPLOYEE 2 (Unselected) -->
                <a href="#" class="list-group-item list-group-item-action p-3 payroll-emp-item" id="payslip-emp-item-2">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="emp-avatar-bg">👷‍♂️</div>
                            <div>
                                <p class="mb-0 fw-bolder text-dark fs-7 emp-name">Arun Kumar</p>
                                <p class="mb-0 fs-8 text-muted font-monospace mt-0.5 emp-meta">
                                    SRK-EMP-002 • Site Supervisor
                                </p>
                            </div>
                        </div>
                        <span class="emp-chevron">›</span>
                    </div>

                    <!-- Financial Breakdown Block -->
                    <div class="p-2 rounded-2 d-flex justify-content-between align-items-center payroll-summary-block">
                        <div>
                            <span class="d-block text-uppercase fw-bold text-muted fs-9">Gross A</span>
                            <span class="font-monospace fw-bold text-dark fs-8">₹35,000</span>
                        </div>
                        <div class="text-end">
                            <span class="d-block text-uppercase fw-bold text-success fs-9">Net Take-Home</span>
                            <span class="font-monospace fw-bold text-success fs-7">₹31,420</span>
                        </div>
                    </div>
                </a>

                <!-- EMPLOYEE 3 (Unselected) -->
                <a href="#" class="list-group-item list-group-item-action p-3 payroll-emp-item" id="payslip-emp-item-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="emp-avatar-bg">👷‍♀️</div>
                            <div>
                                <p class="mb-0 fw-bolder text-dark fs-7 emp-name">Priya Sharma</p>
                                <p class="mb-0 fs-8 text-muted font-monospace mt-0.5 emp-meta">
                                    SRK-EMP-003 • HR Executive
                                </p>
                            </div>
                        </div>
                        <span class="emp-chevron">›</span>
                    </div>

                    <!-- Financial Breakdown Block -->
                    <div class="p-2 rounded-2 d-flex justify-content-between align-items-center payroll-summary-block">
                        <div>
                            <span class="d-block text-uppercase fw-bold text-muted fs-9">Gross A</span>
                            <span class="font-monospace fw-bold text-dark fs-8">₹42,000</span>
                        </div>
                        <div class="text-end">
                            <span class="d-block text-uppercase fw-bold text-success fs-9">Net Take-Home</span>
                            <span class="font-monospace fw-bold text-success fs-7">₹37,850</span>
                        </div>
                    </div>
                </a>

                <!-- EMPLOYEE 4 (Unselected) -->
                <a href="#" class="list-group-item list-group-item-action p-3 payroll-emp-item" id="payslip-emp-item-4">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="emp-avatar-bg">👨‍💼</div>
                            <div>
                                <p class="mb-0 fw-bolder text-dark fs-7 emp-name">Suresh Babu</p>
                                <p class="mb-0 fs-8 text-muted font-monospace mt-0.5 emp-meta">
                                    SRK-EMP-004 • Accountant
                                </p>
                            </div>
                        </div>
                        <span class="emp-chevron">›</span>
                    </div>

                    <!-- Financial Breakdown Block -->
                    <div class="p-2 rounded-2 d-flex justify-content-between align-items-center payroll-summary-block">
                        <div>
                            <span class="d-block text-uppercase fw-bold text-muted fs-9">Gross A</span>
                            <span class="font-monospace fw-bold text-dark fs-8">₹38,000</span>
                        </div>
                        <div class="text-end">
                            <span class="d-block text-uppercase fw-bold text-success fs-9">Net Take-Home</span>
                            <span class="font-monospace fw-bold text-success fs-7">₹34,120</span>
                        </div>
                    </div>
                </a>

            </div>
        </div>
    </div>

    <!-- Right Column: Payslip Document Viewer -->
    <div class="col-12 col-lg-6">

        <!-- Active Payslip View -->
        <div class="card border shadow-lg rounded-4 overflow-hidden position-relative payslip-document-card">

            <!-- Accent Top Stripe -->
            <div class="payslip-accent-bar"
                style="height: 6px; background: linear-gradient(to right, #0C3C62, #16659E, #E86A33);"></div>

            <div class="card-body p-3 p-sm-4 d-flex flex-column gap-3 payslip-body">

                <!-- Document Header -->
                <div class="d-flex justify-content-between align-items-start pb-3 payslip-header">
                    <div>
                        <span class="fw-bold fs-7 font-monospace tracking-widest brand-title d-block"
                            style="color: #0C3C62;">
                            SRK INFRA DEVELOPERS
                        </span>
                        <p class="fs-8 text-muted mb-0 mt-0.5 brand-address">
                            Plot No 40, Cyber Towers Lane, Hyderabad
                        </p>
                        <p class="fs-9 text-muted font-monospace mb-0 brand-reg">
                            REG: HR-TS-55410-09 • LABOUR CODE 2026
                        </p>
                    </div>
                    <div class="text-end payslip-period-info">
                        <span
                            class="badge bg-light text-secondary font-monospace fw-bold text-uppercase border px-2 py-1 payslip-period-tag">
                            July 2026 Pay Slip
                        </span>
                        <p class="fs-9 text-muted mb-0 mt-1 payslip-issue-date">Date: 2026-07-20</p>
                    </div>
                </div>

                <!-- Employee Details Matrix -->
                <div class="bg-light border rounded-3 p-2.5 row g-2 fs-8 emp-details-matrix">
                    <div class="col-6">
                        <span class="text-muted d-block text-uppercase fw-bold fs-9 matrix-label">
                            Staff Registry ID
                        </span>
                        <span class="font-monospace fw-bold text-dark matrix-value">SRK-EMP-001</span>
                    </div>
                    <div class="col-6">
                        <span class="text-muted d-block text-uppercase fw-bold fs-9 matrix-label">
                            Designation & Type
                        </span>
                        <span class="fw-bold text-dark matrix-value">Site Engineer</span>
                    </div>
                    <div class="col-6">
                        <span class="text-muted d-block text-uppercase fw-bold fs-9 matrix-label">
                            Personnel Name
                        </span>
                        <span class="fw-bold text-dark matrix-value">Rajesh Kumar</span>
                    </div>
                    <div class="col-6">
                        <span class="text-muted d-block text-uppercase fw-bold fs-9 matrix-label">
                            Department Unit
                        </span>
                        <span class="fw-bold text-dark matrix-value">Civil Operations</span>
                    </div>
                    <div class="col-12">
                        <span class="text-muted d-block text-uppercase fw-bold fs-9 matrix-label">
                            UAN / PF Number
                        </span>
                        <span class="font-monospace text-secondary matrix-value">101245897412</span>
                    </div>
                </div>

                <!-- Earnings & Deductions Ledger Table -->
                <div class="border rounded-3 overflow-hidden fs-8 payslip-ledger-table">
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover mb-0 align-middle">
                            <thead class="table-light fw-bold text-uppercase fs-9 tracking-wider border-bottom">
                                <tr>
                                    <th scope="col" class="w-50 ps-3">Component Description</th>
                                    <th scope="col" class="text-end">Earnings (₹)</th>
                                    <th scope="col" class="text-end pe-3">Deductions (₹)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            Basic Pay + Dearness Allowance (DA)
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component A1 (50% Labour Code Rule)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace fw-bold text-dark earnings-val">₹25,000</td>
                                    <td class="text-end font-monospace text-muted pe-3 deductions-val">-</td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            House Rent Allowance (HRA) + OA
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component A2 (30% Wage Code Rule)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace fw-bold text-dark earnings-val">₹15,000</td>
                                    <td class="text-end font-monospace text-muted pe-3 deductions-val">-</td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            Special Allowance / Statutory Bonus
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component A3 (Balancing Allowance)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace fw-bold text-dark earnings-val">₹10,000</td>
                                    <td class="text-end font-monospace text-muted pe-3 deductions-val">-</td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-success component-title">
                                            Monthly Performance Incentive
                                        </span>
                                        <span class="fs-9 text-success font-monospace component-sub">
                                            Component A4 (Performance Variable)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace fw-bold text-success earnings-val">+₹2,000</td>
                                    <td class="text-end font-monospace text-muted pe-3 deductions-val">-</td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            EPF Employee Share (PF 12%)
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component B1 (12% of Basic+DA)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace text-muted earnings-val">-</td>
                                    <td class="text-end font-monospace fw-bold text-danger pe-3 deductions-val">₹3,000
                                    </td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            ESI & Professional Tax (PT)
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component B2 (Statutory State Levies)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace text-muted earnings-val">-</td>
                                    <td class="text-end font-monospace fw-bold text-danger pe-3 deductions-val">₹200
                                    </td>
                                </tr>
                                <tr class="ledger-row">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-dark component-title">
                                            Tax Deducted at Source (TDS)
                                        </span>
                                        <span class="fs-9 text-muted font-monospace component-sub">
                                            Component B3 (Income Tax Deduction)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace text-muted earnings-val">-</td>
                                    <td class="text-end font-monospace fw-bold text-danger pe-3 deductions-val">₹1,600
                                    </td>
                                </tr>
                                <tr class="ledger-row bg-danger-subtle">
                                    <td class="ps-3">
                                        <span class="fw-bold d-block text-danger-emphasis component-title">
                                            Advance Salary / Loan Recovery
                                        </span>
                                        <span class="fs-9 text-danger font-monospace component-sub">
                                            Component B4 (Monthly Advance Recovery)
                                        </span>
                                    </td>
                                    <td class="text-end font-monospace text-muted earnings-val">-</td>
                                    <td class="text-end font-monospace fw-bold text-danger pe-3 deductions-val">₹2,000
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot class="fw-bold border-top fs-8 ledger-footer">
                                <tr>
                                    <td class="ps-3 text-uppercase text-dark">TOTAL MONTHLY GROSS vs DEDUCTIONS</td>
                                    <td class="text-end font-monospace text-primary total-gross">₹52,000</td>
                                    <td class="text-end font-monospace text-danger pe-3 total-deductions">₹6,800</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

                <!-- Net Pay Banner -->
                <div
                    class="text-white p-3 rounded-3 d-flex justify-content-between align-items-center shadow-sm net-pay-banner">
                    <div>
                        <span class="fs-9 fw-bold text-uppercase tracking-widest d-block text-white-50 banner-title">
                            NET MONTHLY SALARY PAYABLE
                        </span>
                        <span class="fs-8 text-white-50 banner-sub">Direct Bank Transfer Disbursal</span>
                    </div>
                    <div class="text-end">
                        <span class="fs-4 fw-bold font-monospace net-pay-amount">₹45,200</span>
                    </div>
                </div>

                <!-- Total CTC Footer -->
                <div
                    class="p-2 bg-light border rounded-3 d-flex justify-content-between align-items-center fs-8 ctc-footer">
                    <span class="fw-bold text-secondary ctc-label">
                        Total Employer Outflow (CTC = Gross A + Employer C)
                    </span>
                    <div class="fw-bold ctc-amount-container" style="color: #0C3C62;">
                        <span class="font-monospace ctc-amount">₹58,500/mo</span>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-flex justify-content-end gap-2 pt-1 payslip-actions">
                    <button type="button" class="btn btn-outline-secondary btn-sm fs-8 fw-bold btn-close-simulator">
                        Close Simulator
                    </button>
                    <button type="button" id="print-slip-1"
                        class="btn btn-primary btn-sm fs-8 fw-bold d-flex align-items-center gap-1.5 btn-copy-xml"
                        style="background-color: #16659E; border-color: #16659E;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor"
                            class="bi bi-file-earmark-text" viewBox="0 0 16 16">
                            <path
                                d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5z" />
                            <path
                                d="M4.5 12.5A.5.5 0 0 1 5 12h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5M5 6a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1zm0 3a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1z" />
                        </svg>
                        <span>Copy Slip XML</span>
                    </button>
                </div>

            </div>
        </div>

    </div>
</div>
<style>
/* Mini dashboard start */

/* Custom Palette Colors */
.text-purple {
    color: #7e22ce !important;
}

.bg-purple-subtle {
    background-color: #f3e8ff !important;
}

.text-indigo {
    color: #4f46e5 !important;
}

.bg-indigo-subtle {
    background-color: #e0e7ff !important;
}

/* Metrics Custom Typography & Layout */
.salary-metric-icon {
    width: 48px;
    height: 48px;
}

.salary-metric-label,
.salary-metric-subtext {
    font-size: 0.625rem;
}

.salary-metric-value {
    color: #0c3c62;
}


.salary-metric-card {
    padding: 10px;
}

.salary-metric-icon {
    height: 30px;
    width: 30px;
}

.salary-metric-content {
    padding-left: -15px;
}

/* Mini dashboard start */

/* Navigation Starts */
/* Base Container Styles */
.payroll-navbar {
    margin-top: 15px;
}



.payroll-toolbar {
    font-family: inherit;
    margin-top: 0px;

}

/* Nav Tab Buttons */
.payroll-tab-btn {
    font-size: 0.75rem;
    color: #475569;
    padding: 0.4rem 0.75rem;
    transition: all 0.2s ease;
}

.payroll-tab-btn:hover {
    color: #0f172a;
}

.payroll-tab-btn.active {
    background-color: #16659e !important;
    color: #ffffff !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

/* Form Select Dropdown */
.payroll-filter-label {
    font-size: 0.625rem;
    letter-spacing: 0.05em;
    color: #94a3b8 !important;
}

.payroll-select {
    font-size: 0.75rem;
    color: #16659e !important;
    background-color: #f8fafc;
    cursor: pointer;
    padding-top: 0.35rem;
    padding-bottom: 0.35rem;
}

.payroll-select:focus {
    border-color: #16659e;
    box-shadow: 0 0 0 0.25rem rgba(22, 101, 158, 0.25);
}

/* Staff Category Filter Pills */
.payroll-pill-btn {
    font-size: 0.6875rem;
    color: #64748b;
    padding: 0.25rem 0.75rem;
}

.payroll-pill-btn:hover {
    color: #0f172a;
}

.payroll-pill-btn.active {
    background-color: #ffffff !important;
    color: #1e293b !important;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.payroll-pill-btn.pill-primary.active {
    background-color: #2563eb !important;
    color: #ffffff !important;
}

.payroll-pill-btn.pill-warning.active {
    background-color: #d97706 !important;
    color: #ffffff !important;
}

/* Mobile Responsiveness Adjustments */
@media (max-width: 767.98px) {

    .payroll-tabs-group,
    .payroll-controls-group {
        width: 100%;
    }

    .payroll-filter-item {
        width: 100%;
        justify-content: space-between;
    }

    .payroll-select {
        flex-grow: 1;
    }
}

/* Navigation Ends */

/* generation registry starts */
/* Base & Font Setup*/
.payroll-container {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    color: #333333;
    margin-top: 16px;
    width: 100%;
}

/* Font Size Utilities */
.fs-7 {
    font-size: 0.95rem;
}

.fs-8 {
    font-size: 0.85rem;
}

.fs-9 {
    font-size: 0.75rem;
}

/* Letter Spacing Utilities */
.tracking-wider {
    letter-spacing: 0.05em;
}

.tracking-widest {
    letter-spacing: 0.1em;
}

/* Custom Margin Adjustment */
.mt-0\.5 {
    margin-top: 0.125rem;
}

/* Left Column: Payroll Registry */
.payroll-registry-card {
    border-color: #e3e8ee !important;
    background-color: #ffffff;
}

.payroll-registry-header {
    border-bottom-color: #e3e8ee !important;
}

.payroll-create-btn {
    background-color: #0C3C62;
    color: #ffffff;
    border: none;
    padding: 0.25rem 0.6rem;
    border-radius: 0.375rem;
    font-size: 0.8rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
    transition: background-color 0.2s ease-in-out;
}

.payroll-create-btn:hover {
    background-color: #082944;
    color: #ffffff;
}

/* Custom Scrollbar for Employee List */
.payroll-employee-list::-webkit-scrollbar {
    width: 5px;
}

.payroll-employee-list::-webkit-scrollbar-track {
    background: #f1f1f1;
}

.payroll-employee-list::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 4px;
}

.payroll-employee-list::-webkit-scrollbar-thumb:hover {
    background: #aaa;
}

/* Employee Item List Styles */
.payroll-emp-item {
    border-color: #f0f4f8;
    transition: all 0.2s ease-in-out;
    text-decoration: none;
}

.payroll-emp-item:hover {
    background-color: #f8fafc;
}

/* Active Selected State */
.payroll-emp-item.active-item {
    background-color: #f0f7ff;
    border-left: 4px solid #16659E;
}

.emp-avatar-bg {
    width: 40px;
    height: 40px;
    background-color: #eef2f6;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    flex-shrink: 0;
}

.emp-chevron {
    font-size: 1.25rem;
    color: #a0aec0;
    font-weight: 300;
}

.payroll-summary-block {
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
}

.payroll-emp-item.active-item .payroll-summary-block {
    background-color: #ffffff;
    border-color: #cbd5e1;
}

/* ==========================================================================
   Right Column: Payslip Document Viewer
   ==========================================================================*/
.payslip-document-card {
    border-color: #e2e8f0 !important;
    background-color: #ffffff;

}

/* Accent Top Stripe Gradient */
.payslip-accent-bar {
    background: linear-gradient(to right, #0C3C62, #16659E, #E86A33);
}

.payslip-header {
    border-bottom: 1px dashed #e2e8f0;
}

.brand-title {
    letter-spacing: 0.12em;
}

.emp-details-matrix {
    background-color: #f8fafc !important;
    border-color: #e2e8f0 !important;
}

/* Ledger Table Styling */
.payslip-ledger-table {
    border-color: #e2e8f0 !important;
}

.payslip-ledger-table thead {
    background-color: #f1f5f9 !important;
}

.payslip-ledger-table th {
    color: #475569;
    padding-top: 0.6rem;
    padding-bottom: 0.6rem;
}

.ledger-row {
    border-bottom: 1px solid #f1f5f9;
}

.ledger-row:last-child {
    border-bottom: none;
}

.ledger-row td {
    padding-top: 0.55rem;
    padding-bottom: 0.55rem;
}

.ledger-footer {
    background-color: #f8fafc;
    border-top-color: #cbd5e1 !important;
}

.ledger-footer td {
    padding-top: 0.75rem;
    padding-bottom: 0.75rem;
}

/* Net Pay Banner Styling */
.net-pay-banner {
    background: linear-gradient(135deg, #0C3C62 0%, #16659E 100%);
    border-radius: 0.5rem;
}

.net-pay-amount {
    color: #ffffff;
    letter-spacing: -0.02em;
}

/* Total CTC Footer */
.ctc-footer {
    background-color: #f8fafc !important;
    border-color: #e2e8f0 !important;
}

/* Action Buttons */
.payslip-actions button {
    transition: all 0.2s ease-in-out;
}

.btn-copy-xml:hover {
    background-color: #0C3C62 !important;
    border-color: #0C3C62 !important;
}

/* generation registry ends */
</style>
@endsection
