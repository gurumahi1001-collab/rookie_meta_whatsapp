@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

{{-- ============================================================
    PERMANENT STAFF - LEAVE MANAGEMENT
============================================================= --}}

@php

/*
|--------------------------------------------------------------------------
| Permanent Employee Leave Data
|--------------------------------------------------------------------------
*/


@endphp


<div class="container-fluid px-0">

    {{-- PAGE HEADER--}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>


                    <h4 class="mb-1 fw-bold" style="color:#0C3C62;">
                        Leave Management
                    </h4>


                </div>

                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave

                </button>

            </div>

        </div>
    </div>


    {{-- LEAVE MANAGEMENT KPI CARDS --}}
    <div class="leave-kpi-scroll mb-4">
        <div class="leave-kpi-track">

            {{-- Total Personnel --}}
            <div class="leave-kpi-item">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            <div class="leave-kpi-icon bg-primary-subtle text-primary">
                                <i class="mdi mdi-account-group-outline"></i>
                            </div>

                            <div class="min-w-0">
                                <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                    Total Personnel
                                </span>

                                <span class="d-block fw-bold font-monospace leave-kpi-value" style="color:#0C3C62;">
                                    Loading…
                                </span>

                                <span class="d-block text-muted leave-kpi-description">
                                    Permanent employees
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {{-- On Leave Today --}}
            <div class="leave-kpi-item">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">

                            <div class="leave-kpi-icon bg-warning-subtle text-warning">
                                <i class="mdi mdi-calendar-account-outline"></i>
                            </div>

                            <div class="min-w-0">
                                <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                    On Leave Today
                                </span>

                                <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                    Loading…
                                </span>

                                <span class="d-block text-muted leave-kpi-description">
                                    Active leave records
                                </span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            {{-- Pending Requests --}}
            <div class="leave-kpi-item">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">

                            <div class="leave-kpi-icon bg-warning-subtle text-warning">
                                <i class="mdi mdi-alert-circle-outline"></i>
                            </div>

                            <div class="min-w-0">
                                <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                    Pending Requests
                                </span>

                                <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                    Loading…
                                </span>

                                <span class="d-block text-muted leave-kpi-description">
                                    Awaiting HR review
                                </span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            {{-- Approved --}}
            <div class="leave-kpi-item">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">

                            <div class="leave-kpi-icon bg-success-subtle text-success">
                                <i class="mdi mdi-check-circle-outline"></i>
                            </div>

                            <div class="min-w-0">
                                <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                    Approved This Month
                                </span>

                                <span class="d-block fw-bold font-monospace leave-kpi-value text-success">
                                    Loading…
                                </span>

                                <span class="d-block text-muted leave-kpi-description">
                                    August 2026
                                </span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    {{-- LEAVE MANAGEMENT NAVIGATION --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-2">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg">
                    <div class="d-flex flex-wrap gap-2">
                        {{-- Leave Applications Link --}}
                        <a href="{{ url('/admin-hr/leave_management/permanent') }}"
                            class="btn btn-sm rounded-3 text-decoration-none
                            {{ !request()->is('/admin-hr/leave_management/permanent') || request()->is('/admin-hr/leave_management/permanent') ? 'btn-primary' : 'btn-light' }}">

                            <i class="mdi mdi-calendar-check-outline me-1"></i>
                            Leave Applications

                            <span
                                class="badge {{ !request()->is('/admin-hr/leave_management/permanent') || request()->is('admin-hr/leave_management/permanent') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                                
                            </span>
                        </a>

                        {{-- Leave Entitlement / Table View Link --}}
                        <a href="{{ url('/admin-hr/leave_management/permanent/leave_entitle') }}" class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center gap-1
       {{ request()->is('admin-hr/leave_management/permanent/leave_entitle') ? 'btn-primary' : 'btn-light' }}">

                            <i class="mdi mdi-table me-1"></i>
                            Leave Entitlement

                            <span
                                class="badge {{ request()->is('admin-hr/leave_management/permanent/leave_entitle') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                                
                            </span>
                        </a>
                    </div>

                </div>

                <div class="col-12 col-lg-auto">
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-3" data-bs-toggle="modal"
                            data-bs-target="#leaveSettingsModal">

                            <i class="mdi mdi-cog-outline me-1"></i>
                            Configure Settings
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{-- LEAVE APPLICATIONS--}}
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-3 p-md-4">
            {{-- SECTION HEADER --}}
            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3
                        border-bottom pb-3 mb-3">
                <div>
                    <h5 class="mb-1 fw-bold text-dark">
                        <i class="mdi mdi-calendar-text-outline text-primary me-1"></i>
                        Leave Applications & Calendar Logs
                    </h5>

                    <p class="mb-0 text-muted small">
                        Review and manage leave requests for permanent employees.
                    </p>

                </div>
                <!--
                <button type="button" class="btn btn-primary btn-sm rounded-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave

                </button> -->

            </div>


            {{-- FILTER AREA --}}
            <div class="bg-light border rounded-4 p-3 mb-4">

                <form method="GET" action="{{ url()->current() }}">

                    <div class="row g-2 align-items-end">

                        {{-- SEARCH --}}
                        <div class="col-12 col-md-6 col-lg-3">

                            <label class="form-label small fw-bold text-muted mb-1">
                                Employee
                            </label>

                            <input type="text" name="employee" value="{{ request('employee') }}"
                                class="form-control form-control-sm" placeholder="Search employee...">

                        </div>


                        {{-- LEAVE TYPE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                Leave Type
                            </label>

                            <select name="leave_type" class="form-select form-select-sm">

                                <option value="ALL">
                                    All Types
                                </option>

                                <option value="Casual">
                                    Casual Leave
                                </option>

                                <option value="Privilege">
                                    Privilege Leave
                                </option>

                                <option value="Sick">
                                    Sick Leave
                                </option>

                            </select>

                        </div>


                        {{-- STATUS --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                Status
                            </label>

                            <select name="status" class="form-select form-select-sm">

                                <option value="ALL">
                                    All Status
                                </option>

                                <option value="Pending">
                                    Pending
                                </option>

                                <option value="Approved">
                                    Approved
                                </option>

                                <option value="Rejected">
                                    Rejected
                                </option>

                            </select>

                        </div>


                        {{-- FROM DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                From Date
                            </label>

                            <input type="date" name="from_date" value="{{ request('from_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- TO DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                To Date
                            </label>

                            <input type="date" name="to_date" value="{{ request('to_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- FILTER BUTTON --}}
                        <div class="col-12 col-lg-1">

                            <button type="submit" class="btn btn-primary btn-sm w-100">

                                <i class="mdi mdi-filter-outline"></i>

                            </button>

                        </div>

                    </div>

                </form>

            </div>


            {{-- LEAVE TABLE--}}
            <div class="table-responsive border rounded-4">

                <table id="leave-requests-table" class="table table-hover mb-0">

                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">

                        <tr>

                            <th class="min-w-100px text-black">
                                Employee
                            </th>

                            <th class="min-w-100px text-black">
                                Leave Type
                            </th>

                            <th class="min-w-100px text-black">
                                Leave Date
                            </th>

                            <th class="min-w-100px text-black">
                                Duration
                            </th>

                            <th class="min-w-100px text-black">
                                Applied Date
                            </th>

                            <th class="min-w-100px text-black">
                                Reason
                            </th>

                            <th class="min-w-100px text-black">
                                Status / Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>


{{-- APPLY LEAVE MODAL --}}
<div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header">

                <h5 class="modal-title fw-bold">
                    Apply Permanent Staff Leave
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

            </div>

            <form>

                @csrf

                <div class="modal-body">

                    <div class="row g-3">

                        <div class="col-12">

                            <label class="form-label small fw-bold">
                                Employee
                            </label>

                            <select name="employee_id" class="select3 form-select" required>

                                <option value="">
                                    Select Employee
                                </option>

                                

                            </select>

                        </div>


                        <div class="col-12">

                            <label class="form-label small fw-bold">
                                Leave Type
                            </label>

                            <select name="leave_type" class="form-select form-select-sm" required>

                                <option value="">
                                    Select Leave Type
                                </option>

                                <option value="Casual">
                                    Casual Leave
                                </option>

                                <option value="Privilege">
                                    Privilege Leave
                                </option>

                                <option value="Sick">
                                    Sick Leave
                                </option>

                            </select>

                        </div>


                        <div class="col-6">

                            <label class="form-label small fw-bold">
                                From Date
                            </label>

                            <input type="date" name="start_date" class="form-control form-control-sm" required>

                        </div>


                        <div class="col-6">

                            <label class="form-label small fw-bold">
                                To Date
                            </label>

                            <input type="date" name="end_date" class="form-control form-control-sm" required>

                        </div>


                        <div class="col-12">

                            <label class="form-label small fw-bold">
                                Reason / Remarks
                            </label>

                            <textarea name="reason" rows="3" class="form-control form-control-sm"
                                placeholder="Enter leave reason..."></textarea>

                        </div>

                    </div>

                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button type="submit" class="btn btn-primary btn-sm">

                        <i class="mdi mdi-check me-1"></i>
                        Submit Leave

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


{{-- LEAVE SETTINGS MODAL --}}
<div class="modal fade" id="leaveSettingsModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content border-0 rounded-4 shadow">

            <div class="modal-header">

                <h5 class="modal-title fw-bold">
                    Permanent Staff Leave Policy
                </h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>

            </div>

            <div class="modal-body">

                <div class="row g-3">

                    <div class="col-12 col-sm-4">

                        <label class="form-label small fw-bold">
                            Casual Leave
                        </label>

                        <input type="number" id="leavePolicyCasualDays" name="casual_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="12">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                    <div class="col-12 col-sm-4">

                        <label class="form-label small fw-bold">
                            Privilege Leave
                        </label>

                        <input type="number" id="leavePolicyPaidDays" name="paid_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="15">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                    <div class="col-12 col-sm-4">

                        <label class="form-label small fw-bold">
                            Sick Leave
                        </label>

                        <input type="number" id="leavePolicySickDays" name="sick_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="10">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                </div>

            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" id="saveLeavePolicyButton" class="btn btn-primary btn-sm">
                    Save Settings
                </button>

            </div>

        </div>

    </div>

</div>


<style>
/* LEAVE MANAGEMENT */

.leave-kpi-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    font-size: 20px;
}

.leave-kpi-label {
    font-size: 9px;
    letter-spacing: .5px;
    line-height: 1.4;
}

.leave-kpi-value {
    font-size: 18px;
    line-height: 1.3;
    margin-top: 2px;
}

.leave-kpi-description {
    font-size: 9px;
    margin-top: 2px;
}

.leave-reason {
    max-width: 180px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


/* RESPONSIVE */

@media (max-width: 767.98px) {

    .leave-kpi-value {
        font-size: 16px;
    }

    .leave-kpi-description {
        font-size: 8px;
    }

    .table {
        min-width: 900px;
    }

}

/* KPI horizontal scrolling */
.leave-kpi-scroll {
    width: 100%;
}

.leave-kpi-track {
    display: flex;
    gap: 1rem;
}

/* Normal desktop layout */
.leave-kpi-item {
    flex: 1 1 0;
    min-width: 0;
}

/* Small screens */
@media (max-width: 767.98px) {

    .leave-kpi-scroll {
        overflow-x: auto;
        overflow-y: hidden;
        width: 100%;
        padding-bottom: 8px;

        /* Smooth touch scrolling */
        -webkit-overflow-scrolling: touch;
        scroll-behavior: smooth;

        /* Hide scrollbar */
        scrollbar-width: none;
        -ms-overflow-style: none;
    }

    .leave-kpi-scroll::-webkit-scrollbar {
        display: none;
    }

    .leave-kpi-track {
        display: flex;
        flex-wrap: nowrap;
        gap: 12px;
        width: max-content;
    }

    .leave-kpi-item {
        flex: 0 0 290px;
        width: 290px;
    }
}
</style>

<script>
const permanentLeaveType = 'permanent';
const permanentLeaveBaseUrl = `/admin-hr/api/leave/${permanentLeaveType}`;
const permanentLeaveCsrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

const permanentLeaveState = {
    page: 1,
    perPage: 10,
    search: '',
    leaveType: 'ALL',
    status: 'ALL',
    fromDate: '',
    toDate: '',
    staff: []
};

function permanentLeaveEscape(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

async function permanentLeaveRequest(url, options = {}) {
    const headers = {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        ...(permanentLeaveCsrfToken
            ? { 'X-CSRF-TOKEN': permanentLeaveCsrfToken }
            : {}),
        ...(options.body
            ? { 'Content-Type': 'application/json' }
            : {}),
        ...(options.headers || {})
    };

    const response = await fetch(url, {
        credentials: 'same-origin',
        ...options,
        headers
    });

    let payload = {};

    try {
        payload = await response.json();
    } catch (error) {
        // A non-JSON response is handled by the standard request error below.
    }

    if (!response.ok || payload.success === false) {
        throw new Error(
            payload.message ||
            Object.values(payload.errors || {}).flat()[0] ||
            `Request failed (${response.status}).`
        );
    }

    return payload;
}

function permanentLeaveBuildParams() {
    const query = new URLSearchParams({
        page: String(permanentLeaveState.page),
        per_page: String(permanentLeaveState.perPage),
        employee: permanentLeaveState.search,
        leave_type: permanentLeaveState.leaveType,
        status: permanentLeaveState.status
    });

    if (permanentLeaveState.fromDate) {
        query.set('from_date', permanentLeaveState.fromDate);
    }

    if (permanentLeaveState.toDate) {
        query.set('to_date', permanentLeaveState.toDate);
    }

    return query.toString();
}

function permanentLeaveUpdateSummary(summary = {}) {
    const cards = [...document.querySelectorAll('.leave-kpi-item')];
    const values = [
        `${Number(summary.staff_count || 0)} Staff`,
        `${Number(summary.on_leave_today || 0)} Personnel`,
        `${Number(summary.pending_count || 0)} Pending`,
        `${Number(summary.approved_this_month || 0)} Approved`
    ];

    cards.forEach((card, index) => {
        const value = card.querySelector('.leave-kpi-value');

        if (value && values[index] !== undefined) {
            value.textContent = values[index];
        }
    });

    const descriptions = cards.map(card => card.querySelector('.leave-kpi-description'));

    if (descriptions[1]) {
        descriptions[1].textContent = 'Approved leave including today';
    }

    if (descriptions[2]) {
        descriptions[2].textContent = 'Awaiting HR review';
    }

    if (descriptions[3]) {
        descriptions[3].textContent = new Date().toLocaleDateString(undefined, {
            month: 'long',
            year: 'numeric'
        });
    }
}

function permanentLeaveStatusBadge(status) {
    const color = status === 'Approved'
        ? 'success'
        : status === 'Rejected'
            ? 'danger'
            : 'warning';

    return `<span class="badge bg-${color}-subtle text-${color}">${permanentLeaveEscape(status)}</span>`;
}

function permanentLeaveRenderRows(rows) {
    const table = document.getElementById('leave-requests-table');

    if (!table) {
        return;
    }

    const body = table.tBodies[0];

    if (!rows.length) {
        body.innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-muted py-5">
                    No leave requests found for the selected filters.
                </td>
            </tr>
        `;
        return;
    }

    body.innerHTML = rows.map(row => `
        <tr data-leave-id="${permanentLeaveEscape(row.id)}">
            <td>
                <div class="fw-bold text-dark small">${permanentLeaveEscape(row.staff_name || '—')}</div>
                <div class="text-muted" style="font-size:10px">
                    ${permanentLeaveEscape(row.designation || 'Staff')}
                    <span class="mx-1">•</span>
                    ${permanentLeaveEscape(row.department_name || 'General')}
                </div>
                <small class="text-muted">${permanentLeaveEscape(row.staff_code || '')}</small>
            </td>
            <td>
                <span class="badge rounded-2 bg-primary-subtle text-primary">
                    ${permanentLeaveEscape(row.leave_type || '—')}
                </span>
            </td>
            <td>
                <span class="small fw-semibold">
                    ${permanentLeaveEscape(row.from_date || '—')}
                    <span class="text-muted">to</span>
                    ${permanentLeaveEscape(row.to_date || '—')}
                </span>
            </td>
            <td>
                <span class="badge bg-light text-dark">
                    ${permanentLeaveEscape(row.days ?? '—')}
                    ${Number(row.days) === 1 ? 'Day' : 'Days'}
                </span>
            </td>
            <td>
                <small class="text-muted">${permanentLeaveEscape(String(row.created_at || '').slice(0, 10) || '—')}</small>
            </td>
            <td>
                <span class="small text-muted" title="${permanentLeaveEscape(row.reason || '—')}">
                    ${permanentLeaveEscape(row.reason || '—')}
                </span>
            </td>
            <td>
                ${permanentLeaveStatusBadge(row.approval_status)}
                ${row.approval_status === 'Pending' ? `
                    <div class="d-flex gap-1 mt-2">
                        <button type="button" class="btn btn-success btn-sm leave-review"
                            data-id="${permanentLeaveEscape(row.id)}" data-status="Approved">Approve</button>
                        <button type="button" class="btn btn-outline-danger btn-sm leave-review"
                            data-id="${permanentLeaveEscape(row.id)}" data-status="Rejected">Reject</button>
                    </div>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

function permanentLeaveRenderPager(meta = {}) {
    const table = document.getElementById('leave-requests-table');
    if (!table) return;

    let host = document.getElementById('leave-requests-pagination');
    if (!host) {
        host = document.createElement('div');
        host.id = 'leave-requests-pagination';
        host.className = 'd-flex flex-wrap align-items-center justify-content-between gap-2 p-3';
        table.closest('.card')?.appendChild(host);
    }
    if (!host) return;

    const currentPage = Number(meta.current_page || 1);
    const lastPage = Math.max(1, Number(meta.last_page || 1));
    const total = Number(meta.total || 0);
    const perPage = Number(meta.per_page || permanentLeaveState.perPage);
    const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
    const end = Math.min(currentPage * perPage, total);
    const firstPage = Math.max(1, currentPage - 2);
    const finalPage = Math.min(lastPage, currentPage + 2);
    const pageButtons = Array.from({ length: finalPage - firstPage + 1 }, (_, index) => {
        const page = firstPage + index;
        return `<li class="page-item ${page === currentPage ? 'active' : ''}"><button type="button" class="page-link" data-leave-page="${page}" ${page === currentPage ? 'aria-current="page"' : ''}>${page}</button></li>`;
    }).join('');

    host.innerHTML = `
        <div class="small text-muted">Showing ${start} to ${end} of ${total} results</div>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <label for="leaveRequestsPageSize" class="small text-muted mb-0">Rows</label>
            <select id="leaveRequestsPageSize" class="form-select form-select-sm" style="width:82px">
                <option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option>
            </select>
            <nav aria-label="Permanent leave requests table pagination"><ul class="pagination pagination-sm mb-0">
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="1" aria-label="First page" ${currentPage === 1 ? 'disabled' : ''}>«</button></li>
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${Math.max(1, currentPage - 1)}" aria-label="Previous page" ${currentPage === 1 ? 'disabled' : ''}>‹</button></li>
                ${pageButtons}
                <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${Math.min(lastPage, currentPage + 1)}" aria-label="Next page" ${currentPage === lastPage ? 'disabled' : ''}>›</button></li>
                <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${lastPage}" aria-label="Last page" ${currentPage === lastPage ? 'disabled' : ''}>»</button></li>
            </ul></nav>
        </div>`;

    host.querySelector('#leaveRequestsPageSize').value = String(perPage);
    host.querySelector('#leaveRequestsPageSize').addEventListener('change', event => {
        permanentLeaveState.perPage = Number(event.currentTarget.value);
        permanentLeaveState.page = 1;
        permanentLeaveLoadRequests();
    });
    host.querySelectorAll('[data-leave-page]').forEach(button => button.addEventListener('click', () => {
        if (button.disabled) return;
        permanentLeaveState.page = Number(button.dataset.leavePage);
        permanentLeaveLoadRequests();
    }));
}

async function permanentLeaveLoadRequests() {
    const table = document.getElementById('leave-requests-table');

    if (!table) {
        return;
    }

    const body = table.tBodies[0];
    body.innerHTML = Array.from({ length: 5 }, () => `
        <tr class="skeleton-loader">
            ${Array.from({ length: 7 }, () => '<td class="skeleton-cell"><div class="skeleton-loader-view"></div></td>').join('')}
        </tr>
    `).join('');

    try {
        const response = await permanentLeaveRequest(`${permanentLeaveBaseUrl}?${permanentLeaveBuildParams()}`);

        permanentLeaveRenderRows(response.data || []);
        permanentLeaveRenderPager(response.meta || {});
        permanentLeaveUpdateSummary(response.summary || {});

        const countBadge = document.querySelector(`a[href*="leave_management/${permanentLeaveType}"] .badge`);

        if (countBadge) {
            countBadge.textContent = Number(response.summary?.pending_count || 0);
        }
    } catch (error) {
        body.innerHTML = `
            <tr>
                <td colspan="7" class="text-danger text-center py-4">${permanentLeaveEscape(error.message)}</td>
            </tr>
        `;

        document.querySelectorAll('.leave-kpi-value').forEach(value => {
            value.textContent = '—';
        });
    }
}

async function permanentLeaveLoadStaffOptions() {
    const selects = [
        ...document.querySelectorAll('#applyLeaveModal select[name="employee_id"], #applyLeaveModal select[name="staff_id"]')
    ];

    if (!selects.length) {
        return;
    }

    try {
        let staff = [];
        let page = 1;
        let lastPage = 1;

        do {
            const response = await permanentLeaveRequest(
                `/admin-hr/api/staff/${permanentLeaveType}?per_page=100&sort=name&direction=asc&page=${page}`
            );

            staff.push(...(response.data || []));
            lastPage = Number(response.meta?.last_page || 1);
            page += 1;
        } while (page <= lastPage && page <= 100);

        permanentLeaveState.staff = staff;

        const options = staff.map(employee => `
            <option value="${permanentLeaveEscape(employee.id)}">
                ${permanentLeaveEscape(employee.name)} · ${permanentLeaveEscape(employee.staff_id || '')}
            </option>
        `).join('');

        selects.forEach(select => {
            const previousValue = select.value;
            select.innerHTML = `<option value="">Select Employee</option>${options}`;
            select.value = previousValue;
        });
    } catch (error) {
        console.warn('Could not load staff selector:', error.message);
    }
}

async function permanentLeaveReviewRequest(button) {
    const id = button.dataset.id;
    const status = button.dataset.status;

    if (!id || !status) {
        return;
    }

    if (status === 'Approved' && !confirm('Approve this leave request and mark working days as Leave in Attendance?')) {
        return;
    }

    if (status === 'Rejected' && !confirm('Reject this leave request?')) {
        return;
    }

    button.disabled = true;

    try {
        await permanentLeaveRequest(`${permanentLeaveBaseUrl}/${id}/review`, {
            method: 'PATCH',
            body: JSON.stringify({ approval_status: status })
        });

        await permanentLeaveLoadRequests();
    } catch (error) {
        alert(error.message);
    } finally {
        button.disabled = false;
    }
}

async function permanentLeaveLoadPolicy() {
    const modal = document.getElementById('leaveSettingsModal');

    if (!modal) {
        return;
    }

    try {
        const response = await permanentLeaveRequest(`${permanentLeaveBaseUrl}/policies`);
        const policies = response.data || [];
        const findPolicy = typeName => policies.find(policy =>
            String(policy.leave_type).toLowerCase().replace(/[^a-z]/g, '') === typeName
        );
        const casualLeave = findPolicy('casualleave');
        const paidLeave = findPolicy('paidleave') || findPolicy('privilegeleave');
        const sickLeave = findPolicy('sickleave');

        const setValue = (id, value) => {
            const element = document.getElementById(id);

            if (element && value !== undefined) {
                element.value = value;
            }
        };

        setValue('leavePolicyCasualDays', casualLeave?.annual_days ?? 12);
        setValue('leavePolicyPaidDays', paidLeave?.annual_days ?? 15);
        setValue('leavePolicySickDays', sickLeave?.annual_days ?? 12);
        setValue('leavePolicyCarryCap', paidLeave?.max_carry_forward_days ?? 30);
    } catch (error) {
        console.warn('Could not load leave policies:', error.message);
    }
}

async function permanentLeaveSavePolicy(button) {
    const readNumber = id => Number(document.getElementById(id)?.value || 0);
    const policies = [
        {
            leave_type: 'Casual Leave',
            annual_days: readNumber('leavePolicyCasualDays'),
            carry_forward_enabled: 0,
            max_carry_forward_days: 0,
            accrual_method: 'annual'
        },
        {
            leave_type: 'Paid Leave',
            annual_days: readNumber('leavePolicyPaidDays'),
            carry_forward_enabled: 1,
            max_carry_forward_days: document.getElementById('leavePolicyCarryCap')
                ? readNumber('leavePolicyCarryCap')
                : 30,
            accrual_method: 'annual'
        },
        {
            leave_type: 'Sick Leave',
            annual_days: readNumber('leavePolicySickDays'),
            carry_forward_enabled: 0,
            max_carry_forward_days: 0,
            accrual_method: 'annual'
        }
    ];

    button.disabled = true;

    try {
        const response = await permanentLeaveRequest(`${permanentLeaveBaseUrl}/policies`, {
            method: 'PUT',
            body: JSON.stringify({ policies })
        });

        alert(response.message || 'Leave policy saved.');
        bootstrap.Modal.getInstance(document.getElementById('leaveSettingsModal'))?.hide();
    } catch (error) {
        alert(error.message);
    } finally {
        button.disabled = false;
    }
}

function permanentLeaveBindFilters() {
    const form = document.querySelector(`form[action*="leave_management/${permanentLeaveType}"][method="GET"]`)
        || document.querySelector('.card form[method="GET"]');

    if (!form) {
        return;
    }

    const employeeInput = form.querySelector('[name="employee"]');
    const leaveTypeSelect = form.querySelector('[name="leave_type"]');
    const statusSelect = form.querySelector('[name="status"]');
    const fromDateInput = form.querySelector('[name="from_date"]');
    const toDateInput = form.querySelector('[name="to_date"]');

    if (employeeInput) {
        permanentLeaveState.search = employeeInput.value || '';
        let debounceTimer;

        employeeInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                permanentLeaveState.search = employeeInput.value.trim();
                permanentLeaveState.page = 1;
                permanentLeaveLoadRequests();
            }, 250);
        });
    }

    if (leaveTypeSelect) {
        permanentLeaveState.leaveType = leaveTypeSelect.value || 'ALL';
        leaveTypeSelect.addEventListener('change', () => {
            permanentLeaveState.leaveType = leaveTypeSelect.value || 'ALL';
            permanentLeaveState.page = 1;
            permanentLeaveLoadRequests();
        });
    }

    if (statusSelect) {
        permanentLeaveState.status = statusSelect.value || 'ALL';
        statusSelect.addEventListener('change', () => {
            permanentLeaveState.status = statusSelect.value || 'ALL';
            permanentLeaveState.page = 1;
            permanentLeaveLoadRequests();
        });
    }

    if (fromDateInput) {
        permanentLeaveState.fromDate = fromDateInput.value || '';
        fromDateInput.addEventListener('change', () => {
            permanentLeaveState.fromDate = fromDateInput.value;
            permanentLeaveState.page = 1;
            permanentLeaveLoadRequests();
        });
    }

    if (toDateInput) {
        permanentLeaveState.toDate = toDateInput.value || '';
        toDateInput.addEventListener('change', () => {
            permanentLeaveState.toDate = toDateInput.value;
            permanentLeaveState.page = 1;
            permanentLeaveLoadRequests();
        });
    }

    form.addEventListener('submit', event => {
        event.preventDefault();
        event.stopImmediatePropagation();

        permanentLeaveState.search = employeeInput?.value?.trim() || '';
        permanentLeaveState.leaveType = leaveTypeSelect?.value || 'ALL';
        permanentLeaveState.status = statusSelect?.value || 'ALL';
        permanentLeaveState.fromDate = fromDateInput?.value || '';
        permanentLeaveState.toDate = toDateInput?.value || '';
        permanentLeaveState.page = 1;

        permanentLeaveLoadRequests();
    });
}

document.addEventListener('click', event => {
    const reviewButton = event.target.closest('.leave-review');

    if (reviewButton) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        permanentLeaveReviewRequest(reviewButton);
        return;
    }

    const saveButton = event.target.closest('#saveLeavePolicyButton');

    if (saveButton) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        permanentLeaveSavePolicy(saveButton);
    }
}, true);

document.addEventListener('submit', event => {
    const form = event.target;

    if (!form?.closest('#applyLeaveModal') || !form.querySelector('[name="employee_id"], [name="staff_id"]')) {
        return;
    }

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    const formData = new FormData(form);
    const staffId = Number(formData.get('staff_id') || formData.get('employee_id'));
    const payload = {
        staff_id: staffId,
        leave_type: formData.get('leave_type'),
        from_date: formData.get('from_date') || formData.get('start_date'),
        to_date: formData.get('to_date') || formData.get('end_date'),
        reason: formData.get('reason') || ''
    };
    const submitButton = form.querySelector('[type="submit"]');

    if (submitButton) {
        submitButton.disabled = true;
    }

    permanentLeaveRequest(permanentLeaveBaseUrl, {
        method: 'POST',
        body: JSON.stringify(payload)
    }).then(response => {
        alert(response.message || 'Leave request submitted.');
        bootstrap.Modal.getInstance(form.closest('.modal'))?.hide();
        form.reset();
        permanentLeaveState.page = 1;
        permanentLeaveLoadRequests();
    }).catch(error => {
        alert(error.message);
    }).finally(() => {
        if (submitButton) {
            submitButton.disabled = false;
        }
    });
}, true);

function permanentLeaveInit() {
    permanentLeaveBindFilters();
    permanentLeaveLoadStaffOptions();
    permanentLeaveLoadPolicy();
    permanentLeaveLoadRequests();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', permanentLeaveInit, { once: true });
} else {
    permanentLeaveInit();
}
</script>

@endsection