@extends('layouts.layoutMaster')

@section('title', 'Contract Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')



<!-- Navigation Tab Bar -->
<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-2">
        <div class="nav-scroll-wrapper">

            {{-- Scrollable Tabs Container --}}
            <div class="nav-scroll-container gap-2">
                {{-- Salary Structure & Wages Rate Link --}}
                @php
                $isSalaryActive = request()->is('admin-hr/wages/contractstaff');
                @endphp
                <a href="{{ url('/admin-hr/wages/contractstaff') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary' : 'btn-light' }}">
                    <i class="mdi mdi-calendar-check-outline me-1"></i>
                    Salary Structure & Wages Rate
                </a>

                {{-- Promotion & Appraisal Link --}}
                @php
                $isPromotionActive = request()->is('/admin-hr/wages/contractstaff/promotion&appraisal');
                @endphp
                <a href="{{ url('/admin-hr/wages/contractstaff/promotion&appraisal') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isPromotionActive ? 'btn-primary' : 'btn-light' }}">
                    <i class="mdi mdi-trending-up me-1"></i>
                    Promotion & Appraisal
                </a>

                {{-- Loan Disbursement & Recovery Link --}}
                @php
                $isLoanActive = request()->is('admin-hr/wages/loan-disbursement*');
                @endphp
                <a href="{{ url('/admin-hr/wages/contractstaff/LoanDisbursement') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isLoanActive ? 'btn-primary' : 'btn-light' }}">
                    <i class="mdi mdi-cash-refund me-1"></i>
                    Loan Disbursement & Recovery
                </a>

            </div>

            {{-- Create Action Button --}}
            <!-- <div class="nav-action-btn">
                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3 w-100" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">
                    <i class="mdi mdi-plus me-1"></i>
                    Create Salary Structure
                </button>
            </div> -->

        </div>
    </div>
</div>

<!-- Stat Cards Container -->
<div class="stat-card-container gap-3">

    <!-- Daily Personnel Wage Output -->
    <div class="stat-card-item">
        <div
            class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="stat-icon-wrapper bg-orange-subtle text-orange rounded-3 d-flex align-items-center justify-content-center">
                <i class="mdi mdi-chart-box fs-2"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">Daily Personnel Wage
                    Output</span>
                <span class="stat-value text-primary-dark font-monospace fw-bolder d-block fs-4 mb-1">
                    Loading…
                </span>
                <span class="stat-description text-muted d-block">Summed from present workforce checks</span>
            </div>
        </div>
    </div>

    <!-- Avg Daily Wage Base Rate -->
    <div class="stat-card-item">
        <div
            class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="stat-icon-wrapper bg-blue-subtle text-blue rounded-3 d-flex align-items-center justify-content-center">

                <i class="mdi mdi-cash-100 fs-2"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">Avg Daily Wage Base Rate</span>
                <span class="stat-value text-blue font-monospace fw-bolder d-block fs-4 mb-1">Loading…</span>
                <span class="stat-description text-muted d-block">Standard workforce daily rate cadence</span>
            </div>
        </div>
    </div>

    <!-- Overtime Rate Multiplier -->
    <div class="stat-card-item">
        <div
            class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="stat-icon-wrapper bg-purple-subtle text-purple rounded-3 d-flex align-items-center justify-content-center">
                <i class="mdi mdi-clock-outline fs-3"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">Overtime Rate Multiplier</span>
                <span class="stat-value text-purple font-monospace fw-bolder d-block fs-4 mb-1">1.5x / 2.0x</span>
                <span class="stat-description text-muted d-block">Compliant OT rate as per Labour Code</span>
            </div>
        </div>
    </div>

    <!-- Monthly Total Cost Projection -->
    <div class="stat-card-item">
        <div
            class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm d-flex align-items-center gap-3">
            <div
                class="stat-icon-wrapper bg-emerald-subtle text-emerald rounded-3 d-flex align-items-center justify-content-center">
                <i class="mdi mdi-shield-check-outline fs-3"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">Monthly Total Cost
                    Projection</span>
                <span class="stat-value text-emerald font-monospace fw-bolder d-block fs-4 mb-1">
                    Loading…
                </span>
                <span class="stat-description text-muted d-block">Component A (Gross) + Component C (Employer
                    Share)</span>
            </div>
        </div>
    </div>
</div>


<div class="salary-builder container-fluid">
    <div class="salary-layout row g-4 align-items-start">
        <!-- LEFT: PERSONNEL DIRECTORY  -->
        <div class="salary-left-column col-12 col-xl-4">
            <div class="salary-personnel-card">
                <!-- Header -->
                <div class="salary-personnel-header">
                    <div class="salary-personnel-heading">
                        <div class="salary-personnel-title">
                            <h3>Select Personnel</h3>
                            <p>Configure Indian Labour Law salary components</p>
                        </div>
                        <div class="salary-personnel-actions">
                            <button type="button" class="salary-create-btn" id="btnToggleSalaryEdit">
                                <span class="salary-create-icon">+</span>
                                <span id="createBtnText">Create</span>
                            </button>
                            <span class="salary-record-count">
                                12 Records
                            </span>
                        </div>
                    </div>
                </div>
                <!-- Personnel List -->
                <div class="salary-personnel-list">

                    <!-- EMPLOYEE 1 -->
                    <div class="salary-personnel-item salary-personnel-item-active">
                        <div class="salary-personnel-main">
                            <div class="salary-personnel-info">
                                <span class="salary-profile-icon">
                                    👷‍♂️
                                </span>
                                <div class="salary-employee-details">
                                    <div class="salary-employee-heading">
                                        <p class="salary-employee-name">
                                            Rajesh Kumar
                                        </p>

                                    </div>
                                    <p class="salary-employee-meta">
                                        SRK-EMP-001 • Senior Engineer
                                    </p>
                                </div>
                            </div>
                            <span class="salary-chevron salary-chevron-active">
                                ›
                            </span>
                        </div>
                        <div class="salary-personnel-summary">
                            <div class="salary-summary-item">
                                <span class="salary-summary-label">
                                    Gross A
                                </span>
                                <span class="salary-summary-value">
                                    ₹50,000
                                </span>
                            </div>
                            <div class="salary-summary-item salary-summary-item-right">
                                <span class="salary-summary-label salary-summary-net-label">
                                    Net Take-Home
                                </span>
                                <span class="salary-summary-value salary-summary-net-value">
                                    ₹44,250
                                </span>
                            </div>
                        </div>
                    </div>


                    <!-- EMPLOYEE 2 -->
                    <div class="salary-personnel-item">
                        <div class="salary-personnel-main">
                            <div class="salary-personnel-info">
                                <span class="salary-profile-icon">
                                    👷‍♂️
                                </span>
                                <div class="salary-employee-details">
                                    <div class="salary-employee-heading">
                                        <p class="salary-employee-name">
                                            Arun Kumar
                                        </p>

                                    </div>
                                    <p class="salary-employee-meta">
                                        SRK-EMP-002 • Site Supervisor
                                    </p>
                                </div>
                            </div>
                            <span class="salary-chevron">
                                ›
                            </span>
                        </div>
                        <div class="salary-personnel-summary">
                            <div class="salary-summary-item">
                                <span class="salary-summary-label">
                                    Gross A
                                </span>
                                <span class="salary-summary-value">
                                    ₹35,000
                                </span>
                            </div>

                            <div class="salary-summary-item salary-summary-item-right">
                                <span class="salary-summary-label salary-summary-net-label">
                                    Net Take-Home
                                </span>
                                <span class="salary-summary-value salary-summary-net-value">
                                    ₹31,420
                                </span>
                            </div>
                        </div>
                    </div>


                    <!-- EMPLOYEE 3 -->
                    <div class="salary-personnel-item">
                        <div class="salary-personnel-main">
                            <div class="salary-personnel-info">
                                <span class="salary-profile-icon">
                                    👷‍♀️
                                </span>
                                <div class="salary-employee-details">
                                    <div class="salary-employee-heading">
                                        <p class="salary-employee-name">
                                            Priya Sharma
                                        </p>

                                    </div>
                                    <p class="salary-employee-meta">
                                        SRK-EMP-003 • HR Executive
                                    </p>
                                </div>
                            </div>
                            <span class="salary-chevron">
                                ›
                            </span>
                        </div>
                        <div class="salary-personnel-summary">
                            <div class="salary-summary-item">
                                <span class="salary-summary-label">
                                    Gross A
                                </span>
                                <span class="salary-summary-value">
                                    ₹42,000
                                </span>
                            </div>
                            <div class="salary-summary-item salary-summary-item-right">
                                <span class="salary-summary-label salary-summary-net-label">
                                    Net Take-Home
                                </span>
                                <span class="salary-summary-value salary-summary-net-value">
                                    ₹37,850
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- EMPLOYEE 4  -->
                    <div class="salary-personnel-item">
                        <div class="salary-personnel-main">
                            <div class="salary-personnel-info">
                                <span class="salary-profile-icon">
                                    👨‍💼
                                </span>
                                <div class="salary-employee-details">
                                    <div class="salary-employee-heading">
                                        <p class="salary-employee-name">
                                            Suresh Babu
                                        </p>

                                    </div>
                                    <p class="salary-employee-meta">
                                        SRK-EMP-004 • Accountant
                                    </p>
                                </div>
                            </div>
                            <span class="salary-chevron">
                                ›
                            </span>
                        </div>
                        <div class="salary-personnel-summary">
                            <div class="salary-summary-item">
                                <span class="salary-summary-label">
                                    Gross A
                                </span>
                                <span class="salary-summary-value">
                                    ₹38,000
                                </span>
                            </div>
                            <div class="salary-summary-item salary-summary-item-right">
                                <span class="salary-summary-label salary-summary-net-label">
                                    Net Take-Home
                                </span>
                                <span class="salary-summary-value salary-summary-net-value">
                                    ₹34,120
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- RIGHT: SALARY STRUCTURE BUILDER-->
        <div class="salary-right-column col-12 col-xl-8">
            <div class="salary-structure-card">
                <!-- HEADER -->
                <div class="salary-header-banner bg-primary" id="salaryHeaderBanner">
                    <div class="salary-header-content">

                        <!-- Employee Selection Section -->
                        <div class="salary-header-employee-section">
                            <span class="salary-header-profile">👷‍♂️</span>

                            <div class="salary-header-employee">

                                <!-- View Mode: Static Text -->
                                <div class="salary-view-group" id="salaryHeaderViewGroup">
                                    <div class="salary-header-employee-title">
                                        <h3 class="salary-header-name" id="viewEmployeeName">Rajesh Kumar</h3>

                                    </div>
                                    <p class="salary-header-meta">
                                        <span id="viewEmployeeCode">SRK-EMP-001</span>
                                        <span>•</span>
                                        <span id="viewEmployeeRole">Senior Engineer</span>
                                        <span>•</span>
                                        <strong id="viewEmployeeDept">Engineering</strong>
                                    </p>
                                </div>

                                <!-- Edit Mode: Dropdown Input (Hidden by default) -->
                                <div class="salary-edit-group salary-hidden" id="salaryHeaderEditGroup">
                                    <label for="employeeSelectDropdown" class="salary-edit-label">Select
                                        Employee</label>
                                    <select id="employeeSelectDropdown" class="salary-edit-select">
                                        <option value="EMP-001" data-code="SRK-EMP-001" data-role="Senior Engineer"
                                            data-dept="Engineering" selected>
                                            Rajesh Kumar (SRK-EMP-001)
                                        </option>
                                        <option value="EMP-002" data-code="SRK-EMP-002" data-status="Contract Staff"
                                            data-role="Site Supervisor" data-dept="Operations">
                                            Arun Kumar (SRK-EMP-002)
                                        </option>
                                        <option value="EMP-003" data-code="SRK-EMP-003" data-role="HR Executive"
                                            data-dept="Human Resources">
                                            Priya Sharma (SRK-EMP-003)
                                        </option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <!-- Salary CTC Section -->
                        <div class="salary-header-ctc">
                            <span class="salary-header-ctc-label">Total Cost to Company (CTC)</span>

                            <!-- View Mode: Static Value -->
                            <span class="salary-header-ctc-value salary-view-group"
                                id="viewCtcValue">₹58,250/month</span>

                            <!-- Edit Mode: Input Control -->
                            <div class="salary-edit-group salary-hidden" id="editCtcGroup">
                                <div class="salary-input-prefix-box">
                                    <span class="salary-currency-symbol">₹</span>
                                    <input type="number" id="inputCtcValue" class="salary-edit-input" value="58250"
                                        placeholder="0.00" />
                                    <span class="salary-unit-symbol">/month</span>
                                </div>
                            </div>
                        </div>

                        <!-- Actions for Edit Mode (Save / Cancel) -->
                        <div class="salary-header-actions salary-edit-group salary-hidden" id="editActionsGroup">
                            <button type="button" class="salary-action-save" id="btnSaveSalaryHeader">Save</button>
                            <button type="button" class="salary-action-cancel"
                                id="btnCancelSalaryHeader">Cancel</button>
                        </div>

                    </div>
                </div>


                <!-- SUCCESS MESSAGE -->
                <div class="salary-success-banner">
                    <div class="salary-success-message">
                        <span class="salary-success-icon">
                            ✓
                        </span>
                        <span>
                            Salary Structure saved successfully for
                            Rajesh Kumar! Live payroll updated.
                        </span>
                    </div>
                    <span class="salary-compliant-badge">
                        COMPLIANT
                    </span>
                </div>
                <!-- BODY-->
                <div class="salary-structure-body">
                    <!-- AUTO CALCULATOR -->
                    <div class="salary-auto-calculator">
                        <div class="salary-calculator-header">
                            <div class="salary-calculator-title-wrapper">
                                <span class="salary-calculator-icon">
                                    🧮
                                </span>
                                <h4 class="salary-auto-title">
                                    Indian Labour Code Auto-Calculator
                                    <span>(50-30-20 Rule)</span>
                                </h4>
                            </div>
                            <span class="salary-law-label">
                                2026 Wage Code Mandate
                            </span>
                        </div>


                        <div class="salary-calculator-form row g-3 align-items-end">
                            <div class="col-12 col-md-6">
                                <label class="form-label salary-form-label">
                                    Target Monthly Gross Earnings (₹)
                                </label>
                                <div class="input-group salary-input-wrapper flex-nowrap align-items-center">
                                    <span class="input-group-text salary-currency border-end-0">₹</span>
                                    <input type="number"
                                        class="form-control salary-form-control target-salary border-start-0"
                                        placeholder="50000">
                                </div>
                            </div>


                        </div>
                    </div>


                    <!-- COMPONENT A -->
                    <div class="salary-component salary-component-a">
                        <div class="salary-component-header">
                            <div class="salary-component-heading">
                                <span class="salary-component-number">
                                    A
                                </span>
                                <h4 class="salary-component-title">
                                    Component A - Employee Gross Earnings
                                </h4>
                            </div>
                            <span class="salary-component-total">
                                Total A: ₹50,000/mo
                            </span>
                        </div>
                        <div class="salary-component-body">
                            <div class="row g-3">
                                <!-- Basic -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <div class="salary-field-heading">
                                            <label class="salary-field-label">
                                                Basic Pay + DA
                                            </label>
                                            <span class="salary-percentage-badge salary-blue-badge">
                                                50%
                                            </span>
                                        </div>
                                        <p class="salary-field-help">
                                            Min 50% CTC per Wage Code
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="25000">
                                        </div>
                                    </div>
                                </div>
                                <!-- HRA -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <div class="salary-field-heading">
                                            <label class="salary-field-label">
                                                HRA + OA
                                            </label>
                                            <span class="salary-percentage-badge">
                                                30%
                                            </span>
                                        </div>
                                        <p class="salary-field-help">
                                            House Rent & Other Allowance
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="15000">
                                        </div>
                                    </div>
                                </div>
                                <!-- Special -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <div class="salary-field-heading">
                                            <label class="salary-field-label">
                                                Special Allowance
                                            </label>
                                            <span class="salary-percentage-badge">
                                                20%
                                            </span>
                                        </div>
                                        <p class="salary-field-help">
                                            Balancing Component
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="10000">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- COMPONENT B-->
                    <div class="salary-component salary-component-b">
                        <div class="salary-component-header">
                            <div class="salary-component-heading">
                                <span class="salary-component-number">
                                    B
                                </span>
                                <h4 class="salary-component-title">
                                    Component B - Employee Share (Deductions)
                                </h4>
                            </div>
                            <span class="salary-component-total">
                                Total Deductions B: ₹5,750/mo
                            </span>
                        </div>

                        <div class="salary-component-body">
                            <div class="row g-3">
                                <!-- EPF -->
                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            EPF Share (12%)
                                        </label>
                                        <p class="salary-field-help">
                                            12% of Basic + DA
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="3000">
                                        </div>
                                    </div>
                                </div>
                                <!-- ESI -->
                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            ESI Share (0.75%)
                                        </label>
                                        <p class="salary-field-help">
                                            Gross ≤ ₹21k limit
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="0">
                                        </div>
                                    </div>
                                </div>


                                <!-- PT -->
                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            Prof. Tax (PT)
                                        </label>
                                        <p class="salary-field-help">
                                            State Statutory PT
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="200">
                                        </div>
                                    </div>
                                </div>

                                <!-- TDS -->
                                <div class="col-12 col-sm-6 col-xl-3">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            TDS / Income Tax
                                        </label>
                                        <p class="salary-field-help">
                                            Direct Tax Deduction
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="2550">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- NET SALARY -->
                        <div class="salary-net-banner">
                            <div class="salary-net-info">
                                <span class="salary-net-title">
                                    💵 NET TAKE-HOME SALARY
                                </span>
                                <span class="salary-net-subtitle">
                                    Component A - Component B
                                </span>
                            </div>
                            <div class="salary-net-result">
                                <span class="salary-net-amount">
                                    ₹44,250/mo
                                </span>
                                <span class="salary-net-day">
                                    ≈ ₹2,011/day
                                </span>
                            </div>
                        </div>
                    </div>
                    <!-- COMPONENT C -->
                    <div class="salary-component salary-component-c">
                        <div class="salary-component-header">
                            <div class="salary-component-heading">
                                <span class="salary-component-number">
                                    C
                                </span>
                                <h4 class="salary-component-title">
                                    Component C - Employer Share
                                    (Contributions & Benefits)
                                </h4>
                            </div>
                            <span class="salary-component-total">
                                Total Employer Share C: ₹8,250/mo
                            </span>
                        </div>
                        <div class="salary-component-body">
                            <div class="row g-3">
                                <!-- Employer EPF -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            EPF Employer Share (12%)
                                        </label>
                                        <p class="salary-field-help">
                                            EPS 8.33% + PF 3.67% + EDLI
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="3000">
                                        </div>
                                    </div>
                                </div>


                                <!-- Employer ESI -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            ESI Employer Share (3.25%)
                                        </label>
                                        <p class="salary-field-help">
                                            Employer ESI Statutory Contribution
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="0">
                                        </div>
                                    </div>
                                </div>
                                <!-- Gratuity -->
                                <div class="col-12 col-md-6 col-xl-4">
                                    <div class="salary-field-card">
                                        <label class="salary-field-label">
                                            Gratuity & LWF
                                        </label>
                                        <p class="salary-field-help">
                                            4.81% Accrual + Labor Welfare
                                        </p>
                                        <div class="salary-input-wrapper">
                                            <span class="salary-currency">
                                                ₹
                                            </span>
                                            <input type="number" class="salary-field-input" value="5250">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- CTC -->
                        <div class="salary-ctc-banner">
                            <div class="salary-ctc-info">
                                <span class="salary-ctc-title">
                                    💼 TOTAL COST TO COMPANY
                                </span>
                                <span class="salary-ctc-subtitle">
                                    CTC = Component A + Component C
                                </span>
                            </div>
                            <div class="salary-ctc-result">
                                <span class="salary-ctc-amount">
                                    ₹58,250/month
                                </span>
                            </div>
                        </div>
                    </div>


                    <!-- ACTIONS-->
                    <div class="salary-actions">
                        <button type="button" class="salary-reset-btn">
                            <span>↻</span>
                            <span>Reset to Default 50-30-20 Rules</span>
                        </button>
                        <button type="button" class="salary-save-btn">
                            <span>✓</span>
                            <span>Update & Save Salary Structure</span>
                        </button>
                    </div>
                </div>

            </div>

        </div>

    </div>


</div>



<style>
/* Custom Color Classes */
.text-primary-dark {
    color: #0C3C62;
}

.text-orange {
    color: #E86A33;
}

.bg-orange-subtle {
    background-color: #FFF4EF;
}

.text-blue {
    color: #16659E;
}

.bg-blue-subtle {
    background-color: #F0F7FF !important;
}

.text-purple {
    color: #9333EA !important;
}

.bg-purple-subtle {
    background-color: #FAF5FF !important;
}

.text-emerald {
    color: #059669 !important;
}

.bg-emerald-subtle {
    background-color: #ECFDF5 !important;
}

/* Horizontal Scroll Layout for Navigation Wrapper */
.nav-scroll-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.nav-scroll-container {
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 2px;
    flex: 1 1 auto;
    min-width: 0;
}

/* Hide scrollbar for cleaner tab navigation */
.nav-scroll-container::-webkit-scrollbar {
    display: none;
}

.nav-scroll-container {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

.nav-scroll-container .btn {
    flex-shrink: 0;
}

@media (max-width: 575.98px) {
    .nav-action-btn {
        width: 100%;
    }
}

/* Horizontal Scroll Layout for Stat Cards */
.stat-card-container {
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    scroll-behavior: smooth;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 0.5rem;
}

/* Custom subtle scrollbar for stat cards */
.stat-card-container::-webkit-scrollbar {
    height: 4px;
}

.stat-card-container::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
}

.stat-card-item {
    flex: 0 0 82%;
    min-width: 270px;
}

/* Desktop View Grid Override (≥992px) */
@media (min-width: 992px) {
    .stat-card-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        overflow-x: visible;
        padding-bottom: 0;
    }

    .stat-card-item {
        flex: initial;
        min-width: 0;
        width: 100%;
    }

    .nav-scroll-container {
        flex-wrap: wrap;
        overflow-x: visible;
        white-space: normal;
    }
}

/* Stat Card Internal Styling */
.stat-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    height: 100%;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon-wrapper {
    width: 48px;
    height: 48px;
    flex-shrink: 0;
}

.stat-label {
    font-size: 0.65rem;
    letter-spacing: 0.05em;
    line-height: 1.2;
}

.stat-value {
    letter-spacing: -0.02em;
    line-height: 1.1;
    word-break: break-all;
}

.stat-description {
    font-size: 0.65rem;
    line-height: 1.2;
}

/* For salary structure - starting */
/* SALARY BUILDER - BASE*/

.salary-builder {
    width: 100%;
    max-width: 1920px;
    margin: 0 auto;
    padding: 0px;
    font-family: Arial, Helvetica, sans-serif;
    color: #1e293b;
}

.salary-layout {
    width: 100%;
}


/* LEFT COLUMN*/

.salary-left-column {
    min-width: 0;
}

.salary-personnel-card {
    width: 100%;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 0px;
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(15, 23, 42, 0.06);
}

.salary-personnel-header {
    background: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
    padding: 16px;
}

.salary-personnel-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
}

.salary-personnel-title {
    min-width: 0;
}

.salary-personnel-title h3 {
    margin: 0 0 4px;
    color: #334155;
    font-size: 13px;
    line-height: 1.3;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.06em;
}

.salary-personnel-title p {
    margin: 0;
    color: #94a3b8;
    font-size: 11px;
    line-height: 1.4;
}

.salary-personnel-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    flex-shrink: 0;
}

.salary-create-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    min-height: 30px;
    padding: 5px 10px;
    border: 0;
    border-radius: 7px;
    background: #16659e;
    color: #ffffff;
    font-size: 11px;
    font-weight: 700;
    cursor: pointer;
    transition: 0.2s ease;
}

.salary-create-btn:hover {
    background: #0c3c62;
}

.salary-create-icon {
    font-size: 15px;
    line-height: 1;
}

.salary-record-count {
    display: inline-flex;
    align-items: center;
    white-space: nowrap;
    padding: 5px 8px;
    border-radius: 20px;
    background: #e2e8f0;
    color: #475569;
    font-size: 10px;
    font-weight: 700;
}


/* PERSONNEL LIST */

/* Container Spacing */
.salary-personnel-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

/* Base Personnel Card */
.salary-personnel-item {
    position: relative;
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-left: 4px solid transparent;
    /* Reserve space for border-left */

    padding: 1rem;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
}

/* Hover State - Dynamic Left Border & Background Elevation */
.salary-personnel-item:hover {
    background-color: #f8fafc;
    border-color: #cbd5e1;
    border-left-color: #16659e;
    /* Blue highlight on hover */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    transform: translateX(2px);
}

/* Active Selected State - Permanent Accent Left Border */
.salary-personnel-item.salary-personnel-item-active,
.salary-personnel-item.salary-personnel-item-active:hover {
    background-color: #f0f9ff;
    /* Subtle blue tint */
    border-color: #bfdbfe;
    border-left-color: #16659e;
    /* Primary active theme color */
    box-shadow: 0 4px 14px rgba(22, 101, 158, 0.1);
    transform: translateX(0);
}

/* Header & Meta Alignments */
.salary-personnel-main {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 0.75rem;
}

.salary-personnel-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.salary-profile-icon {
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 2.5rem;
    height: 2.5rem;
    background-color: #f1f5f9;
    border-radius: 50%;
    flex-shrink: 0;
}

.salary-employee-details {
    display: flex;
    flex-direction: column;
}

.salary-employee-heading {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.salary-employee-name {
    font-size: 0.875rem;
    font-weight: 800;
    color: #0f172a;
    margin: 0;
}

/* Badges */
.salary-employment-badge {
    font-size: 0.625rem;
    font-weight: 700;
    padding: 0.125rem 0.375rem;
    border-radius: 0.25rem;
    text-transform: uppercase;
}

.salary-permanent-badge {
    background-color: #d1fae5;
    color: #065f46;
}

.salary-contract-badge {
    background-color: #fef3c7;
    color: #92400e;
}

.salary-employee-meta {
    font-size: 0.6875rem;
    color: #64748b;
    margin: 0.125rem 0 0 0;
}

/* Chevron Direction Icon */
.salary-chevron {
    font-size: 1.25rem;
    color: #cbd5e1;
    transition: transform 0.2s ease, color 0.2s ease;
}

.salary-personnel-item:hover .salary-chevron {
    color: #3b82f6;
    transform: translateX(3px);
}

.salary-chevron-active,
.salary-personnel-item-active .salary-chevron {
    color: #16659e !important;
    font-weight: bold;
}

/* Financial Summary Footer Inside Card */
.salary-personnel-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 0.625rem;
    border-top: 1px dashed #e2e8f0;
}

.salary-summary-item {
    display: flex;
    flex-direction: column;
}

.salary-summary-item-right {
    text-align: right;
}

.salary-summary-label {
    font-size: 0.625rem;
    color: #64748b;
    text-transform: uppercase;
    font-weight: 700;
}

.salary-summary-value {
    font-size: 0.78rem;
    font-weight: 800;
    color: #1e293b;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.salary-summary-net-label {
    color: #047857;
}

.salary-summary-net-value {
    color: #047857;
}


/* RIGHT COLUMN */

.salary-right-column {
    min-width: 0;
    margin-right: -15px;
    padding: 0px;
}

.salary-structure-card {
    width: 100%;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 0px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(15, 23, 42, 0.08);
}


/* HEADER */

.salary-header-banner {
    padding: 20px;

    color: #ffffff;
}

.salary-header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.salary-header-employee-section {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.salary-header-profile {
    width: 48px;
    height: 48px;
    min-width: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.12);
    font-size: 26px;
}

.salary-header-employee {
    min-width: 0;
}

.salary-header-employee-title {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.salary-header-name {
    margin: 0;
    color: #ffffff;
    font-size: 16px;
    line-height: 1.3;
    font-weight: 800;
}

.salary-header-status {
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 9px;
    line-height: 1;
    font-weight: 800;
    text-transform: uppercase;
}

.salary-header-permanent {
    background: rgba(96, 165, 250, 0.25);
    border: 1px solid rgba(147, 197, 253, 0.3);
    color: #dbeafe;
}

.salary-header-meta {
    margin: 5px 0 0;
    color: rgba(219, 234, 254, 0.8);
    font-family: monospace;
    font-size: 10px;
    line-height: 1.5;
}

.salary-header-meta strong {
    color: #fde68a;
    font-weight: 600;
}

.salary-header-ctc {
    flex-shrink: 0;
    min-width: 190px;
    padding: 10px 14px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.1);
    text-align: right;
}

.salary-header-ctc-label {
    display: block;
    margin-bottom: 3px;
    color: #dbeafe;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}

.salary-header-ctc-value {
    display: block;
    color: #ffffff;
    font-family: monospace;
    font-size: 19px;
    line-height: 1.2;
    font-weight: 900;
}


/* SUCCESS BANNER */

.salary-success-banner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 10px 18px;
    background: #10b981;
    color: #ffffff;
}

.salary-success-message {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    font-size: 11px;
    font-weight: 700;
}

.salary-success-icon {
    width: 20px;
    height: 20px;
    min-width: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
}

.salary-compliant-badge {
    flex-shrink: 0;
    padding: 4px 8px;
    border-radius: 4px;
    background: rgba(4, 120, 87, 0.45);
    color: #ffffff;
    font-family: monospace;
    font-size: 9px;
    font-weight: 800;
}


/* BODY */

.salary-structure-body {
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 18px;
}


/* AUTO CALCULATOR */

.salary-auto-calculator {
    padding: 15px;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    background: #f8fafc;
}

.salary-calculator-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 14px;
}

.salary-calculator-title-wrapper {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
}

.salary-calculator-icon {
    font-size: 18px;
}

.salary-auto-title {
    margin: 0;
    color: #1e293b;
    font-size: 12px;
    line-height: 1.4;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.salary-auto-title span {
    white-space: nowrap;
}

.salary-law-label {
    flex-shrink: 0;
    color: #94a3b8;
    font-family: monospace;
    font-size: 9px;
}

.salary-form-label {
    display: block;
    margin-bottom: 6px;
    color: #64748b;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.salary-input-wrapper {
    position: relative;
    width: 100%;
}

/* Currency Prefix Styling */
.salary-currency {
    background-color: #f8f9fa;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    padding: 0.375rem 0.75rem;
}

.salary-form-control,
.salary-field-input {
    width: 100%;
    height: 36px;
    padding: 7px 10px 7px 28px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    outline: none;
    background: #ffffff;
    color: #1e293b;
    font-family: monospace;
    font-size: 12px;
    font-weight: 700;
    box-shadow: none;
}

.salary-form-control:focus,
.salary-field-input:focus {
    border-color: #16659e;
    box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.1);
}

/* Input Field Styling */
.salary-form-control {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    height: 100%;
}

.salary-input-wrapper {
    display: flex;
    align-items: center;
}

/* Focus State Cleanup */
.salary-form-control:focus {
    z-index: 2;
}

.target-salary {
    margin-left: 15px;
}

.salary-auto-btn {
    width: 100%;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    border: 0;
    border-radius: 7px;
    background: #16659e;
    color: #ffffff;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    transition: 0.2s ease;
}

.salary-auto-btn:hover {
    background: #0c3c62;
}


/* COMPONENT COMMON */

.salary-component {
    width: 100%;
    overflow: hidden;
    border-radius: 12px;
}

.salary-component-a {
    border: 1px solid #bfdbfe;
    background: rgba(239, 246, 255, 0.35);
}

.salary-component-b {
    border: 1px solid #fecdd3;
    background: rgba(255, 241, 242, 0.35);
}

.salary-component-c {
    border: 1px solid #c7d2fe;
    background: rgba(238, 242, 255, 0.35);
}

.salary-component-header {
    min-height: 48px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 10px 14px;
}

.salary-component-a .salary-component-header {
    background: rgba(219, 234, 254, 0.7);
    border-bottom: 1px solid #bfdbfe;
}

.salary-component-b .salary-component-header {
    background: rgba(255, 228, 230, 0.7);
    border-bottom: 1px solid #fecdd3;
}

.salary-component-c .salary-component-header {
    background: rgba(224, 231, 255, 0.7);
    border-bottom: 1px solid #c7d2fe;
}

.salary-component-heading {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.salary-component-number {
    width: 22px;
    height: 22px;
    min-width: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: #ffffff;
    font-size: 10px;
    font-weight: 900;
}

.salary-component-a .salary-component-number {
    background: #16659e;
}

.salary-component-b .salary-component-number {
    background: #e11d48;
}

.salary-component-c .salary-component-number {
    background: #4f46e5;
}

.salary-component-title {
    margin: 0;
    color: #334155;
    font-size: 11px;
    line-height: 1.4;
    font-weight: 800;
    text-transform: uppercase;
}

.salary-component-total {
    flex-shrink: 0;
    color: #334155;
    font-family: monospace;
    font-size: 11px;
    font-weight: 900;
}

.salary-component-body {
    padding: 14px;
}


/* FIELD CARDS */

.salary-field-card {
    width: 100%;
    height: 100%;
    padding: 12px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    background: #ffffff;
    box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);
}

.salary-field-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
}

.salary-field-label {
    display: block;
    min-width: 0;
    margin: 0;
    color: #334155;
    font-size: 10px;
    line-height: 1.35;
    font-weight: 800;
    text-transform: uppercase;
}

.salary-field-help {
    min-height: 25px;
    margin: 5px 0 8px;
    color: #94a3b8;
    font-size: 8px;
    line-height: 1.4;
}

.salary-percentage-badge {
    flex-shrink: 0;
    padding: 3px 6px;
    border-radius: 4px;
    background: #f1f5f9;
    color: #64748b;
    font-size: 8px;
    font-weight: 800;
}

.salary-blue-badge {
    background: #dbeafe;
    color: #1d4ed8;
}

.salary-field-input {
    height: 32px;
    padding-left: 27px;
    background: #f8fafc;
    font-size: 11px;
}

.salary-field-input:focus {
    background: #ffffff;
}


/* NET SALARY */

.salary-net-banner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 13px 15px;
    background: #10b981;
    color: #ffffff;
}

.salary-net-info,
.salary-net-result {
    min-width: 0;
}

.salary-net-title {
    display: block;
    color: #ffffff;
    font-size: 10px;
    line-height: 1.3;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.salary-net-subtitle {
    display: block;
    margin-top: 3px;
    color: #d1fae5;
    font-size: 9px;
}

.salary-net-result {
    text-align: right;
}

.salary-net-amount {
    display: block;
    color: #ffffff;
    font-family: monospace;
    font-size: 17px;
    line-height: 1.2;
    font-weight: 900;
}

.salary-net-day {
    display: block;
    margin-top: 3px;
    color: #d1fae5;
    font-family: monospace;
    font-size: 9px;
}


/* CTC */

.salary-ctc-banner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding: 13px 15px;
    background: #0c3c62;
    color: #ffffff;
}

.salary-ctc-info,
.salary-ctc-result {
    min-width: 0;
}

.salary-ctc-title {
    display: block;
    color: #ffffff;
    font-size: 10px;
    line-height: 1.3;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}

.salary-ctc-subtitle {
    display: block;
    margin-top: 3px;
    color: #bfdbfe;
    font-size: 9px;
}

.salary-ctc-result {
    text-align: right;
}

.salary-ctc-amount {
    color: #fcd34d;
    font-family: monospace;
    font-size: 17px;
    font-weight: 900;
}


/* ACTION BAR */

.salary-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding-top: 16px;
    border-top: 1px solid #e2e8f0;
}

.salary-reset-btn,
.salary-save-btn {
    min-height: 38px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 8px 14px;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    transition: 0.2s ease;
}

.salary-reset-btn {
    border: 1px solid #e2e8f0;
    background: #f8fafc;
    color: #475569;
}

.salary-reset-btn:hover {
    background: #e2e8f0;
}

.salary-save-btn {
    border: 1px solid #16659e;
    background: #16659e;
    color: #ffffff;
    box-shadow: 0 3px 8px rgba(22, 101, 158, 0.2);
}

.salary-save-btn:hover {
    background: #0c3c62;
}


/* LARGE DESKTOP 1200px+ */

@media (min-width: 1200px) {

    .salary-builder {
        padding: 0px 0px;
    }

    .salary-layout {
        --bs-gutter-x: 24px;
    }

    .salary-left-column {
        flex: 0 0 32%;
        max-width: 32%;
    }

    .salary-right-column {
        flex: 0 0 68%;
        max-width: 68%;
    }

}


/* EXTRA LARGE DESKTOP 1400px+ */

@media (min-width: 1400px) {

    .salary-builder {
        padding-top: 20px;

    }

    .salary-left-column {
        flex: 0 0 31%;
        max-width: 31%;
    }

    .salary-right-column {
        flex: 0 0 70%;
        max-width: 70%;
    }

    .salary-structure-body {
        padding: 22px;
    }

    .salary-field-card {
        padding: 14px;
    }

}


/* MEDIUM DEVICES 768px - 1199px */

@media (min-width: 768px) and (max-width: 1199.98px) {

    .salary-builder {
        padding: 16px;
    }

    .salary-personnel-heading {
        align-items: flex-start;
    }

    .salary-header-content {
        align-items: flex-start;
    }

    .salary-header-ctc {
        min-width: 170px;
    }

    .salary-component-title {
        font-size: 10px;
    }

}


/* TABLET / SMALL BELOW 768px */

@media (max-width: 767.98px) {

    .salary-builder {
        padding: 12px;
    }

    .salary-personnel-heading {
        flex-direction: column;
        align-items: stretch;
    }

    .salary-personnel-actions {
        justify-content: space-between;
    }

    .salary-header-content {
        flex-direction: column;
        align-items: stretch;
    }

    .salary-header-ctc {
        width: 100%;
        text-align: left;
    }

    .salary-header-ctc-value {
        font-size: 18px;
    }

    .salary-success-banner {
        align-items: flex-start;
        flex-direction: column;
    }

    .salary-calculator-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .salary-component-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .salary-component-total {
        font-size: 10px;
    }

    .salary-actions {
        align-items: stretch;
        flex-direction: column;
    }

    .salary-reset-btn,
    .salary-save-btn {
        width: 100%;
    }

}


/* MOBILE BELOW 576px */

@media (max-width: 575.98px) {

    .salary-builder {
        padding: 0px;
    }

    .salary-left-column {
        flex: 0 0 100%;
        max-width: 100%;
    }

    .salary-right-column {
        flex: 0 0 100%;
        max-width: 100%;
    }

    .salary-personnel-header {
        padding: 10px;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
    }

    .salary-personnel-actions {
        width: auto;
        display: flex;
        align-items: center;
        gap: 6px;
        flex-shrink: 0;
    }

    .salary-create-btn {
        flex: initial;
        padding: 4px 10px;
        font-size: 11px;
        white-space: nowrap;
    }

    .salary-record-count {
        flex-shrink: 0;
        font-size: 10px;
        padding: 4px 8px;
        white-space: nowrap;
    }

    .salary-header-banner {
        padding: 12px;
        flex-direction: column;
        gap: 10px;
    }

    .salary-structure-body {
        padding: 12px;
        gap: 14px;
    }

    .salary-header-employee-section {
        align-items: flex-start;
    }

    .salary-header-profile {
        width: 40px;
        height: 40px;
        min-width: 40px;
        font-size: 22px;
    }

    .salary-header-name {
        font-size: 14px;
    }

    .salary-header-meta {
        font-size: 9px;
    }

    .salary-auto-calculator {
        padding: 12px;
    }

    .salary-component-body {
        padding: 10px;
    }

    .salary-component-title {
        font-size: 10px;
    }

    .salary-net-banner,
    .salary-ctc-banner {
        align-items: flex-start;
        flex-direction: column;
        gap: 4px;
    }

    .salary-net-result,
    .salary-ctc-result {
        width: 100%;
        text-align: left;
    }

    .salary-net-amount,
    .salary-ctc-amount {
        font-size: 16px;
    }

}

/* For salary structure - ending */

/* For Header editing section starts */
/* Base Container Banner */
.salary-header-banner {
    background-color: #16659e;

    padding: 1.25rem 1.5rem;
    color: #ffffff;
    transition: all 0.2s ease-in-out;
}

.salary-header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1.5rem;
    flex-wrap: wrap;
}

/* Employee Avatar & Detail Block */
.salary-header-employee-section {
    display: flex;
    align-items: center;
    gap: 1rem;
    flex: 1;
    min-width: 280px;
}

.salary-header-profile {
    font-size: 2rem;
    width: 3.25rem;
    height: 3.25rem;
    background-color: rgba(255, 255, 255, 0.15);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.salary-header-employee {
    display: flex;
    flex-direction: column;
    width: 100%;
}

.salary-header-employee-title {
    display: flex;
    align-items: center;
    gap: 0.625rem;
}

.salary-header-name {
    font-size: 1.125rem;
    font-weight: 800;
    margin: 0;
    color: #ffffff;
}

.salary-header-status {
    font-size: 0.625rem;
    font-weight: 800;
    padding: 0.2rem 0.5rem;
    border-radius: 50rem;
    text-transform: uppercase;
}

.salary-header-permanent {
    background-color: #d1fae5;
    color: #065f46;
}

.salary-header-meta {
    font-size: 0.75rem;
    color: rgba(255, 255, 255, 0.8);
    margin: 0.25rem 0 0 0;
    display: flex;
    gap: 0.375rem;
    align-items: center;
}

/* Edit Form Controls */
.salary-hidden {
    display: none !important;
}

.salary-edit-label {
    display: block;
    font-size: 0.6875rem;
    font-weight: 700;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.8);
    margin-bottom: 0.25rem;
}

.salary-edit-select {
    width: 100%;
    max-width: 320px;
    padding: 0.4rem 0.75rem;
    font-size: 0.875rem;
    font-weight: 700;
    color: #0f172a;
    background-color: #ffffff;
    border: 2px solid transparent;
    border-radius: 0.5rem;
    outline: none;
}

.salary-edit-select:focus {
    border-color: #93c5fd;
    box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.3);
}

/* CTC Input Box */
.salary-header-ctc {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
}

.salary-header-ctc-label {
    font-size: 0.6875rem;
    font-weight: 700;
    text-transform: uppercase;
    color: rgba(255, 255, 255, 0.8);
}

.salary-header-ctc-value {
    font-size: 1.25rem;
    font-weight: 800;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    color: #ffffff;
}

.salary-input-prefix-box {
    display: flex;
    align-items: center;
    background-color: #ffffff;
    border-radius: 0.5rem;
    padding: 0.25rem 0.5rem;
    margin-top: 0.25rem;
}

.salary-currency-symbol,
.salary-unit-symbol {
    color: #64748b;
    font-weight: 800;
    font-size: 0.875rem;
    padding: 0 0.25rem;
}

.salary-edit-input {
    border: none;
    outline: none;
    width: 110px;
    font-size: 0.9375rem;
    font-weight: 800;
    color: #0f172a;
    text-align: right;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

/* Save / Cancel Action Buttons */
.salary-header-actions {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.salary-action-save {
    background-color: #10b981;
    color: #ffffff;
    border: none;
    padding: 0.4rem 1rem;
    font-size: 0.75rem;
    font-weight: 800;
    border-radius: 0.5rem;
    cursor: pointer;
}

.salary-action-save:hover {
    background-color: #059669;
}

.salary-action-cancel {
    background-color: rgba(255, 255, 255, 0.2);
    color: #ffffff;
    border: none;
    padding: 0.4rem 0.875rem;
    font-size: 0.75rem;
    font-weight: 700;
    border-radius: 0.5rem;
    cursor: pointer;
}

.salary-action-cancel:hover {
    background-color: rgba(255, 255, 255, 0.3);
}

/* Responsive Alignment */
@media (max-width: 767.98px) {
    .salary-header-content {
        flex-direction: column;
        align-items: flex-start;
    }

    .salary-header-ctc {
        align-items: flex-start;
        width: 100%;
    }

    .salary-edit-select {
        max-width: 100%;
    }
}

/* For Header editing section ends */
</style>

<script>
document.querySelectorAll('.salary-personnel-item').forEach(item => {
    item.addEventListener('click', function() {
        // Remove active class from all personnel items
        document.querySelectorAll('.salary-personnel-item').forEach(el => {
            el.classList.remove('salary-personnel-item-active');
            const chevron = el.querySelector('.salary-chevron');
            if (chevron) chevron.classList.remove('salary-chevron-active');
        });

        // Add active class to the clicked item
        this.classList.add('salary-personnel-item-active');
        const chevron = this.querySelector('.salary-chevron');
        if (chevron) chevron.classList.add('salary-chevron-active');
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const btnToggle = document.getElementById('btnToggleSalaryEdit');
    const btnSave = document.getElementById('btnSaveSalaryHeader');
    const btnCancel = document.getElementById('btnCancelSalaryHeader');

    const viewGroups = document.querySelectorAll('.salary-view-group');
    const editGroups = document.querySelectorAll('.salary-edit-group');

    const dropdown = document.getElementById('employeeSelectDropdown');
    const inputCtc = document.getElementById('inputCtcValue');

    // Toggle Read / Edit State
    function setEditMode(isEditing) {
        viewGroups.forEach(el => el.classList.toggle('salary-hidden', isEditing));
        editGroups.forEach(el => el.classList.toggle('salary-hidden', !isEditing));
    }

    // Trigger Edit Mode on Button Click
    btnToggle.addEventListener('click', () => setEditMode(true));
    btnCancel.addEventListener('click', () => setEditMode(false));

    // Save Actions & Update View State
    btnSave.addEventListener('click', () => {
        const selectedOption = dropdown.options[dropdown.selectedIndex];

        // Read attributes from selected option
        const name = selectedOption.text.split(' (')[0];
        const code = selectedOption.dataset.code;
        const status = selectedOption.dataset.status;
        const role = selectedOption.dataset.role;
        const dept = selectedOption.dataset.dept;
        const ctc = Number(inputCtc.value).toLocaleString('en-IN');

        // Update View DOM
        document.getElementById('viewEmployeeName').textContent = name;
        document.getElementById('viewEmployeeStatus').textContent = status;
        document.getElementById('viewEmployeeCode').textContent = code;
        document.getElementById('viewEmployeeRole').textContent = role;
        document.getElementById('viewEmployeeDept').textContent = dept;
        document.getElementById('viewCtcValue').textContent = `₹${ctc}/monthhhhh`;

        // Switch back to view mode
        setEditMode(false);
    });
});
</script>
<script>
(function(){
  'use strict';
  const type='contract', api='/admin-hr/api/wages/'+type, csrf=document.querySelector('meta[name="csrf-token"]')?.content||'';
  const state={page:1,perPage:10,search:'',rows:[],current:null,detail:null};
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function request(url,opts={}){const r=await fetch(url,{credentials:'same-origin',...opts,headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':csrf,...(opts.headers||{})}});let j={};try{j=await r.json()}catch(_){}if(!r.ok||j.success===false)throw Error(j.message||Object.values(j.errors||{}).flat()[0]||'Request failed.');return j;}
  function money(v){return '₹'+Number(v||0).toLocaleString('en-IN',{maximumFractionDigits:2});}
  function bucket(x){const s=String(x.component_type||'').toLowerCase();if(['b','2'].includes(s)||s.includes('deduct')||s.includes('employee share'))return 'b';if(['c','3'].includes(s)||s.includes('employer')||s.includes('contribution'))return 'c';return 'a';}
  function renderDashboard(summary){const values=document.querySelectorAll('.stat-value');const currency=value=>'₹'+Number(value||0).toLocaleString('en-IN',{maximumFractionDigits:0});if(values[0])values[0].textContent=currency(summary.daily_wage_output);if(values[1])values[1].textContent=currency(summary.average_daily_wage_rate)+' / Day';if(values[3])values[3].textContent=currency(summary.monthly_cost_projection);}
  function dashboardError(){const values=document.querySelectorAll('.stat-value');[0,1,3].forEach(i=>{if(values[i])values[i].textContent='—';});}
  async function loadRows(){const q=new URLSearchParams({page:state.page,per_page:state.perPage,search:state.search});const directory=document.querySelector('.salary-personnel-list');if(directory)directory.innerHTML=Array.from({length:5},()=>'<div class="p-3 border-bottom skeleton-loader"><div class="d-flex align-items-center gap-3"><div class="skeleton-loader-view" style="width:36px;height:36px;border-radius:50%"></div><div class="flex-grow-1"><div class="skeleton-loader-view max-w-75 mb-2"></div><div class="skeleton-loader-view mb-2"></div><div class="skeleton-loader-view max-w-75"></div></div></div></div>').join('');try{const j=await request(api+'?'+q.toString());state.rows=j.data||[];renderDirectory();renderPager(j.meta||{});renderDashboard(j.summary||{});const count=document.querySelector('.salary-record-count');if(count)count.textContent=(j.meta?.total||0)+' Records';if(state.current){const match=state.rows.find(x=>Number(x.staff_pk)===Number(state.current));if(!match)state.current=null;}if(!state.current&&state.rows.length)await loadDetail(state.rows[0].staff_pk);}catch(e){dashboardError();const host=document.querySelector('.salary-personnel-list');if(host)host.innerHTML='<div class="p-3 text-danger">'+esc(e.message)+'</div>';}}
  function renderDirectory(){const host=document.querySelector('.salary-personnel-list');if(!host)return;host.innerHTML=state.rows.map(r=>'<button type="button" class="salary-personnel-item '+(Number(r.staff_pk)===Number(state.current)?'salary-personnel-item-active':'')+'" data-staff-id="'+esc(r.staff_pk)+'" style="width:100%;text-align:left;border:0;background:transparent"><div class="salary-personnel-main"><div class="salary-personnel-info"><span class="salary-profile-icon">👷</span><div class="salary-employee-details"><div class="salary-employee-heading"><p class="salary-employee-name">'+esc(r.staff_name||'—')+'</p></div><p class="salary-employee-meta">'+esc(r.staff_code||'')+' • '+esc(r.designation||'')+'</p></div></div><span class="salary-chevron '+(Number(r.staff_pk)===Number(state.current)?'salary-chevron-active':'')+'">›</span></div><div class="salary-personnel-summary"><div class="salary-summary-item"><span class="salary-summary-label">Base Salary</span><span class="salary-summary-value">'+money(r.basic_salary)+'</span></div><div class="salary-summary-item salary-summary-item-right"><span class="salary-summary-label salary-summary-net-label">Configured Components</span><span class="salary-summary-value salary-summary-net-value">'+money(r.total_components)+'</span></div></div></button>').join('')||'<div class="p-3 text-muted">No staff records found.</div>';}
  function renderPager(meta){
    const list=document.querySelector('.salary-personnel-list'); if(!list)return;
    let host=document.getElementById('wagesStaffPager');
    if(!host){host=document.createElement('div');host.id='wagesStaffPager';host.className='d-flex align-items-center justify-content-between flex-wrap gap-2 p-2 border-top';list.insertAdjacentElement('afterend',host);}
    host.innerHTML='<small class="text-muted">'+Number(meta.total||0)+' staff · Page '+Number(meta.current_page||1)+' / '+Number(meta.last_page||1)+'</small><div class="btn-group btn-group-sm"><button type="button" class="btn btn-outline-secondary" id="wagesPrev" '+(Number(meta.current_page||1)<=1?'disabled':'')+'>Previous</button><button type="button" class="btn btn-outline-secondary" id="wagesNext" '+(Number(meta.current_page||1)>=Number(meta.last_page||1)?'disabled':'')+'>Next</button></div>';
    host.querySelector('#wagesPrev').onclick=()=>{state.page=Math.max(1,state.page-1);loadRows();};
    host.querySelector('#wagesNext').onclick=()=>{state.page=Math.min(Number(meta.last_page||1),state.page+1);loadRows();};
  }
  function ensureSearch(){const head=document.querySelector('.salary-personnel-header');if(!head||document.getElementById('wagesStaffSearch'))return;const input=document.createElement('input');input.id='wagesStaffSearch';input.type='search';input.className='form-control form-control-sm mt-3';input.placeholder='Search staff name, ID or department';head.appendChild(input);let timer;input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{state.search=input.value.trim();state.page=1;loadRows();},250);});}
  function renderComponents(data){const comps=data.components||[];const groups={a:[],b:[],c:[]};comps.forEach(x=>groups[bucket(x)].push(x));[['a','.salary-component-a'],['b','.salary-component-b'],['c','.salary-component-c']].forEach(([key,sel])=>{const card=document.querySelector(sel);if(!card)return;const row=card.querySelector('.salary-component-body .row');if(!row)return;row.innerHTML=groups[key].map(x=>'<div class="col-12 col-md-6 col-xl-4"><div class="salary-field-card"><div class="salary-field-heading"><label class="salary-field-label">'+esc(x.name)+'</label><span class="salary-percentage-badge">'+esc(x.component_type||'Configured')+'</span></div><p class="salary-field-help">'+esc(x.description||'Configured in Settings · Remuneration Type')+'</p><div class="salary-input-wrapper"><span class="salary-currency">₹</span><input type="number" min="0" step="0.01" class="salary-field-input hr-remuneration-amount" data-type-id="'+esc(x.type_id)+'" value="'+esc(x.amount??0)+'"></div></div></div>').join('')||'<div class="col-12"><p class="text-muted mb-0">No active remuneration types configured in Settings for this component group.</p></div>';const total=groups[key].reduce((sum,x)=>sum+Number(x.amount||0),0);const totalLabel=card.querySelector('.salary-component-total');if(totalLabel)totalLabel.textContent=(key==='a'?'Total A: ':key==='b'?'Total Deductions B: ':'Total Employer Share C: ')+money(total)+'/mo';});
    const totalA=groups.a.reduce((n,x)=>n+Number(x.amount||0),0), totalB=groups.b.reduce((n,x)=>n+Number(x.amount||0),0), totalC=groups.c.reduce((n,x)=>n+Number(x.amount||0),0);
    const net=document.querySelector('.salary-net-amount');if(net)net.textContent=money(totalA-totalB)+'/mo';
    const ctc=document.querySelector('.salary-ctc-title');if(ctc)ctc.textContent='Configured Employer Cost (A + C)';
    const ctcAmount=document.querySelector('.salary-ctc-banner .salary-ctc-amount, .salary-ctc-banner .salary-ctc-value');if(ctcAmount)ctcAmount.textContent=money(totalA+totalC)+'/mo';
  }
  async function loadDetail(id){const j=await request(api+'/'+id);state.detail=j.data;state.current=Number(id);const d=state.detail.staff;document.getElementById('viewEmployeeName').textContent=d.staff_name||'—';document.getElementById('viewEmployeeCode').textContent=d.staff_code||'—';document.getElementById('viewEmployeeRole').textContent=d.designation||'—';document.getElementById('viewEmployeeDept').textContent=d.department_name||'—';const ctc=document.getElementById('viewCtcValue');if(ctc)ctc.textContent=money(d.basic_salary)+'/month';const input=document.getElementById('inputCtcValue');if(input)input.value=Number(d.basic_salary||0);const select=document.getElementById('employeeSelectDropdown');if(select){select.innerHTML=state.rows.map(r=>'<option value="'+esc(r.staff_pk)+'">'+esc(r.staff_name)+' ('+esc(r.staff_code||'')+')</option>').join('');select.value=String(id);}document.querySelectorAll('.salary-personnel-item').forEach(el=>{el.classList.toggle('salary-personnel-item-active',Number(el.dataset.staffId)===Number(id));el.querySelector('.salary-chevron')?.classList.toggle('salary-chevron-active',Number(el.dataset.staffId)===Number(id));});renderComponents(j.data);const success=document.querySelector('.salary-success-message span:last-child');if(success)success.textContent='Loaded saved wage structure for '+(d.staff_name||'staff')+'. Save persists the values to the HR remuneration tables.';}
  async function save(){if(!state.current)throw Error('Select a staff member first.');const components=[...document.querySelectorAll('.hr-remuneration-amount')].map(el=>({type_id:Number(el.dataset.typeId),amount:Number(el.value||0)}));const payload={basic_salary:Number(document.getElementById('inputCtcValue')?.value||0),remuneration:components};const j=await request(api+'/'+state.current,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});await loadRows();await loadDetail(state.current);alert(j.message||'Wage structure saved.');}
  document.addEventListener('click',function(e){const saveBtn=e.target.closest('#btnSaveSalaryHeader');if(saveBtn){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();saveBtn.disabled=true;save().catch(err=>alert(err.message)).finally(()=>saveBtn.disabled=false);return;}const item=e.target.closest('.salary-personnel-item[data-staff-id]');if(item){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();loadDetail(item.dataset.staffId).catch(err=>alert(err.message));}},true);
  function initWagesDirectory(){const ctcLabel=document.querySelector('.salary-header-ctc-label');if(ctcLabel)ctcLabel.textContent='Base Monthly Salary';ensureSearch();loadRows();const dropdown=document.getElementById('employeeSelectDropdown');dropdown?.addEventListener('change',()=>{if(dropdown.value)loadDetail(dropdown.value).catch(err=>alert(err.message));});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initWagesDirectory,{once:true});else initWagesDirectory();
})();
</script>
@endsection
