<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dashboard\Login;
// Admin_Hr
use App\Http\Controllers\emp_staff\PermanentEmpController;
use App\Http\Controllers\emp_staff\ContractorEmpController;

use App\Http\Controllers\emp_staff\StaffDirectoryController;
use App\Http\Controllers\attendance_log\AttendanceDirectoryController;
use App\Http\Controllers\leave_management\LeaveDirectoryController;
use App\Http\Controllers\wages\WagesDirectoryController;
use App\Http\Controllers\auth\WebAuthController;

// Permanent - Attendance
use App\Http\Controllers\attendance_log\PermanentList;
use App\Http\Controllers\attendance_log\PermanentTable;
use App\Http\Controllers\attendance_log\PermanentCalender;
// Contract - Attendance
use App\Http\Controllers\attendance_log\ContractList;
use App\Http\Controllers\attendance_log\ContractTable;
use App\Http\Controllers\attendance_log\ContractCalender;

// Permanent - Leave
use App\Http\Controllers\leave_management\PermanentLeave;
use App\Http\Controllers\leave_management\Permanent_Entitle;
// Contract - Leave
use App\Http\Controllers\leave_management\ContractLeave;
use App\Http\Controllers\leave_management\Contract_Entitle;

// Wages - permanent
use App\Http\Controllers\wages\Permanent\SalaryController;
use App\Http\Controllers\wages\Permanent\PromoController;
use App\Http\Controllers\wages\Permanent\LoanController;

// Wages - contract
use App\Http\Controllers\wages\Contract\SalaryContract;
use App\Http\Controllers\wages\Contract\PromoContract;
use App\Http\Controllers\wages\Contract\LoanContract;

// Payroll - Permanent
use App\Http\Controllers\payroll\permanent\RegisterPermanent;
use App\Http\Controllers\payroll\permanent\MonthlyPermanent;
use App\Http\Controllers\payroll\permanent\PayslipPermanent;

// Payroll - Contract
use App\Http\Controllers\payroll\contract\RegisterContract;
use App\Http\Controllers\payroll\contract\MonthlyContract;
use App\Http\Controllers\payroll\contract\PayslipContract;

// EsiPF
use App\Http\Controllers\esipf\Esipf_Permanent;
use App\Http\Controllers\esipf\Esipf_Contract;

// Sitelog
use App\Http\Controllers\sitelog\VendorController;
use App\Http\Controllers\sitelog\ManageStore_Controller;
use App\Http\Controllers\sitelog\StockTransfer_Controller;
use App\Http\Controllers\sitelog\StockInventory_Controller;
use App\Http\Controllers\sitelog\ManageProjectController;

use App\Http\Controllers\sitelog\Client;
use App\Http\Controllers\sitelog\ContractorList;
use App\Http\Controllers\settings\GeneralSettings;
use App\Http\Controllers\settings\UserRole;
use App\Http\Controllers\settings\CountrySetting;
use App\Http\Controllers\settings\StateSetting;
use App\Http\Controllers\settings\CitySetting;
use App\Http\Controllers\settings\FinancialSetting;
use App\Http\Controllers\settings\CreditcardSetting;
use App\Http\Controllers\settings\CreditcardtypeSetting;
use App\Http\Controllers\settings\BankSetting;
use App\Http\Controllers\settings\BloodGroup;
use App\Http\Controllers\settings\EmailtemplateSetting;
use App\Http\Controllers\settings\RelationSetting;
use App\Http\Controllers\settings\LanguageSetting;
use App\Http\Controllers\settings\CourseSetting;
use App\Http\Controllers\settings\BrandSetting;
use App\Http\Controllers\settings\UnitSetting;
use App\Http\Controllers\settings\ProbationSetting;
use App\Http\Controllers\settings\CompanymobileSetting;
use App\Http\Controllers\settings\Document;
use App\Http\Controllers\settings\StructureSetting;
use App\Http\Controllers\settings\Structuretypeitem;
use App\Http\Controllers\settings\VendorType;
use App\Http\Controllers\settings\ContractorType;
use App\Http\Controllers\settings\PayslipType;
use App\Http\Controllers\settings\Ledger;
use App\Http\Controllers\settings\SubLedger;
use App\Http\Controllers\settings\Departmentsettings;
use App\Http\Controllers\settings\Jobrolesettings;
use App\Http\Controllers\settings\Designationsettings;
use App\Http\Controllers\settings\Gradelistsettings;
use App\Http\Controllers\settings\Shiftsettings;
use App\Http\Controllers\settings\HiredMaterial;
use App\Http\Controllers\settings\MaterialType;
use App\Http\Controllers\settings\MachineryType;
use App\Http\Controllers\settings\RemunerationType;
use App\Http\Controllers\warehouse\DepotYard;
use App\Http\Controllers\warehouse\InventoryLedgerBalance;
use App\Http\Controllers\warehouse\StockTransfer;
use App\Http\Controllers\warehouse\MaterialAllocation;
use App\Http\Controllers\material_master\MaterialMaster;
use App\Http\Controllers\material_master\SiteIndent;
use App\Http\Controllers\Planning\PlanningController;
use App\Http\Controllers\Workorders\workordersController;
use App\Http\Controllers\Schedule\SchedulerController;
use App\Http\Controllers\Financial\FinancialController;

use App\Http\Controllers\purchase\Quotation;

// Plant and Machinery
use App\Http\Controllers\plant_machinary\machine_master\Machine_Controller;
use App\Http\Controllers\plant_machinary\machine_master\Manage_flate;
use App\Http\Controllers\plant_machinary\machine_operation\assign_controller;
use App\Http\Controllers\plant_machinary\machine_operation\machine_log;
use App\Http\Controllers\plant_machinary\maintainance;
use App\Http\Controllers\plant_machinary\billing;
use App\Http\Controllers\verification\verificationController;
// Plant and Machinery ends

// Accounts starts
use App\Http\Controllers\accounts\Receivable_Controller;
use App\Http\Controllers\accounts\Accounts_Controller;
use App\Http\Controllers\accounts\expense_manage\Expense_list; 
use App\Http\Controllers\accounts\expense_manage\Expense_summary; 

// Fuel management starts
use App\Http\Controllers\fuel_manage\fuel_entry_controller;
use App\Http\Controllers\fuel_manage\fuel_stock_controller;
use App\Http\Controllers\fuel_manage\fuel_reconciliation_controller;
use App\Http\Controllers\fuel_manage\fuel_summary_controller;
use App\Http\Controllers\fuel_manage\fuel_tank_controller;
use App\Http\Controllers\fuel_manage\fuel_bulk_controller;
use App\Http\Controllers\fuel_manage\Equipment_controller;
// Fuel management ends

// Main Menu Starts  

use App\Http\Controllers\accounts\accounts_site;
use App\Http\Controllers\accounts\taxmanage\gst_entry_controller;
use App\Http\Controllers\accounts\taxmanage\gst_estimate_controller;
use App\Http\Controllers\accounts\taxmanage\gst_payable;
use App\Http\Controllers\accounts\taxmanage\gst_recollination;
use App\Http\Controllers\accounts\taxmanage\file_controller;
use App\Http\Controllers\accounts\taxmanage\create_file_controller;
use App\Http\Controllers\accounts\reports\profit_loss_controller;
use App\Http\Controllers\accounts\reports\client_controller;
use App\Http\Controllers\accounts\reports\client_view_controller;
use App\Http\Controllers\accounts\reports\contractor_controller;
use App\Http\Controllers\accounts\reports\contractor_view_controller;
use App\Http\Controllers\accounts\reports\vendor_controller;
use App\Http\Controllers\accounts\reports\vendor_view_controller;
use App\Http\Controllers\accounts\reports\staff_report;
use App\Http\Controllers\accounts\reports\staff_view_controller;

// Main Menu Starts 
//Accounts
use App\Http\Controllers\Accounts\Banking\Accounts\Banking\AccountsController;
use App\Http\Controllers\Accounts\Banking\Accounts\Banking\BankholdController;
use App\Http\Controllers\Accounts\Banking\Accounts\Banking\CashflowController;
use App\Http\Controllers\Accounts\Banking\Accounts\Banking\CreditcardController;
use App\Http\Controllers\Accounts\Banking\Accounts\Banking\MobileController;

//scrap management
use App\Http\Controllers\scrapmanagement\scrapController;
use App\Http\Controllers\scrapmanagement\disposalController;

//sitelog
use App\Http\Controllers\Manage_structure\manageController;

//General ledger
use App\Http\Controllers\GeneralLedger\DailyAccountsController;




Route::middleware(['auth:web', 'timezone'])->group(function () {

    // Under Development
    Route::get('/under-development', function () {
        return view('under-development');
    })->name('under-development');

    $srkUnderDevelopmentRoutes = [
        'dashboards' => '/dashboards',
        // Site Log

        // 'site.manage-structure' => '/site/manage-structure',

        // Accounts
        'accounts.dashboard'           => '/accounts/dashboard',
        // 'accounts.general-ledger'      => '/accounts/general-ledger',
        // 'accounts.accounts-receivable' => '/accounts/accounts-receivable',
        // 'accounts.accounts-payable'    => '/accounts/accounts-payable',
        // 'accounts.expense-management'  => '/accounts/expense-management',
        // 'accounts.tax-management'      => '/accounts/tax-management',
        // 'accounts.reports'             => '/accounts/reports',


        // Store & Purchase
        // 'store-purchase.purchase-management' => '/store-purchase/purchase-management',
        // 'store-purchase.fuel-management'     => '/store-purchase/fuel-management',
        // 'store-purchase.scrap-management'    => '/store-purchase/scrap-management',

        // // Plant & Machinery
        // Plant & Machinery
        // 'plant-machinery.machine-master'     => '/plant-machinery/machine-master',
        // 'plant-machinery.machine-operations' => '/plant-machinery/machine-operations',
        // 'plant-machinery.maintenance'        => '/plant-machinery/maintenance',
        // 'plant-machinery.billing'            => '/plant-machinery/billing',
    ];

    foreach ($srkUnderDevelopmentRoutes as $name => $url) {
        Route::view($url, 'content.under-development')->name($name);
    }

// Safety net — any URL that still doesn't match a route above shows
// Under Development instead of Laravel's default 404 page.
Route::get('/under-development', function () {
    return view('content.under-development');
})->name('under-development');
// Settings Menu Starts
// General Setting Start
Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general-settings');
Route::post('/general_settings-update', [GeneralSettings::class, 'Update'])->name('general_settings_update');
// General Setting End


// User Role Setting Start
Route::get('/settings/users_role', [UserRole::class, 'index'])->name('settings-user-role');
Route::get('/settings/users_role/data', [UserRole::class, 'data'])->name('settings-user-role.data');
Route::post('/settings/users_role', [UserRole::class, 'store'])->name('settings-user-role.store');
Route::get('/settings/users_role/{id}', [UserRole::class, 'show'])->whereNumber('id')->name('settings-user-role.show');
Route::put('/settings/users_role/{id}', [UserRole::class, 'update'])->whereNumber('id')->name('settings-user-role.update');
Route::patch('/settings/users_role/{id}/status', [UserRole::class, 'status'])->whereNumber('id')->name('settings-user-role.status');
Route::delete('/settings/users_role/{id}', [UserRole::class, 'destroy'])->whereNumber('id')->name('settings-user-role.destroy');
// User Role Setting End

//Settings Country Start
Route::get('/settings/common_settings', [CountrySetting::class, 'index'])->name('settings-common-setting');
Route::post('/add_common/country/category', [CountrySetting::class, 'Add'])->name('add_country_category');
Route::get('/common/country_edit/{id}', [CountrySetting::class, 'Edit']);
Route::post('/common/country_update', [CountrySetting::class, 'update'])->name('country_update_name');
Route::post('/common/country_status/{id}', [CountrySetting::class, 'Status']);
Route::delete('/common/country_delete/{id}', [CountrySetting::class, 'Delete']);
Route::get('/country', [CountrySetting::class, 'List'])->name('country');
//Settings Country End

//Settings state Start
Route::get('/settings/state_settings', [StateSetting::class, 'index'])->name('settings-state-setting');
Route::post('/add_common/state/category', [StateSetting::class, 'Add'])->name('add_state_category');
Route::get('/common/State_edit/{id}', [StateSetting::class, 'Edit']);
Route::get('/state_list', [StateSetting::class, 'List'])->name('state_list');
Route::post('/common/state_update', [StateSetting::class, 'update'])->name('state_update_name');
Route::post('/common/state_status/{id}', [StateSetting::class, 'Status']);
Route::delete('/common/state_delete/{id}', [StateSetting::class, 'Delete']);
//Settings state End

//Settings city
Route::get('/settings/city_settings', [CitySetting::class, 'index'])->name('settings-city-setting');
Route::post('/common/add_city',[CitySetting::class, 'Add'])->name('add_city_category');
Route::post('/common/update_city',[CitySetting::class, 'update'])->name('city_update_name');
Route::get('/common/states_by_country/{countryId}',[CitySetting::class, 'statesByCountry']);
Route::get('/common/City_edit/{edit_id}',[CitySetting::class, 'Edit']);
Route::post('/common/city_status/{id}',[CitySetting::class, 'Status']);
Route::get('/city_list', [CitySetting::class, 'List'])->name('city_list');
Route::delete('/common/city_delete/{id}',[CitySetting::class, 'Delete']);
//Settings city End

//Settings Relation Start
Route::get('/settings/relation_settings', [RelationSetting::class, 'index'])->name('settings-relation-setting');
Route::post('/add_common/relation/ship/category', [RelationSetting::class, 'Add'])->name('add_relation_category');
Route::get('/common/relation/ship_edit/{id}', [RelationSetting::class, 'Edit']);
Route::post('/common/relation/ship_update', [RelationSetting::class, 'update'])->name('common_relation_name');
Route::post('/common/relation/ship/status/{id}', [RelationSetting::class, 'Status']);
Route::delete('/common/relation/ship_delete/{id}', [RelationSetting::class, 'Delete']);
//Settings Relation End

//Vendor settings Start
Route::get('/settings/vendor_settings', [VendorType::class, 'index'])->name('settings-vendor-setting');
Route::post('add_vendor_setting', [VendorType::class, 'Add'])->name('add_vendor_setting');
Route::post('/vendor_update/{id}', [VendorType::class, 'Update'])->name('vendor_update');
Route::get('/vendor_edit/{categoryId}', [VendorType::class, 'View'])->name('vendor_edit');
Route::post('/vendor_status/{id}', [VendorType::class, 'Status'])->name('vendor_status');
Route::delete('/delete_vendor/{id}', [VendorType::class, 'Delete'])->name('delete_vendor');
//Vendor settings End

//Contractor settings Start
Route::get('/settings/contractor_settings', [ContractorType::class, 'index'])->name('settings-contractor-setting');
Route::post('add_contractor_setting', [ContractorType::class, 'Add'])->name('add_contractor_setting');
Route::post('/contractor_update/{id}', [ContractorType::class, 'Update'])->name('contractor_update');
Route::get('/contractor_edit/{categoryId}', [ContractorType::class, 'View'])->name('contractor_edit');
Route::post('/contractor_status/{id}', [ContractorType::class, 'Status'])->name('contractor_status');
Route::delete('/delete_contractor/{id}', [ContractorType::class, 'Delete'])->name('delete_contractor');
//Contractor settings End

//Settings Languages Start
Route::get('/settings/language_settings', [LanguageSetting::class, 'index'])->name('settings-language-setting');
Route::post('/settings/language/store',[LanguageSetting::class, 'Add'])->name('language_settings.store');
Route::get('/settings/language/edit/{id}',[LanguageSetting::class, 'Edit'])->name('language_settings.edit');
Route::post('/settings/language/update/{id}',[LanguageSetting::class, 'update'])->name('language_settings.update');
Route::post('/settings/language/status/{id}',[LanguageSetting::class, 'updateStatus'])->name('language_settings.status');
Route::delete('/settings/language/delete/{id}',[LanguageSetting::class, 'destroy'])->name('language_settings.delete');
//Settings Languages End

//Settings Document Start
Route::get('/settings/document_settings', [Document::class, 'index'])->name('settings-document-setting');
Route::post('/add/settings/doucument/store', [Document::class, 'Add'])->name('doucument_settings.store');
Route::get('/settings/doucument/edit/{id}', [Document::class, 'Edit']);
Route::post('/settings/doucument/update/', [Document::class, 'update'])->name('doucument_settings.update');
Route::post('/settings/doucument/status/{id}', [Document::class, 'Status']);
Route::delete('/settings/doucument/delete/{id}', [Document::class, 'Delete']);
//Settings Document End

//Settings UnitSetting Start
Route::get('/settings/unit_settings', [UnitSetting::class, 'index'])->name('settings-unit-setting');
Route::post('/add/unit', [UnitSetting::class, 'Add'])->name('unit_settings.store');
Route::get('/unit/edit/{id}', [UnitSetting::class, 'Edit']);
Route::post('/unit/update', [UnitSetting::class, 'update'])->name('unit_settings.update');
Route::post('/unit/status/{id}', [UnitSetting::class, 'Status']);
Route::delete('/unit/delete/{id}', [UnitSetting::class, 'Delete']);
//Settings UnitSetting End

//Settings ProbationSetting start
Route::get('/settings/probation_period', [ProbationSetting::class, 'probation'])->name('settings-probation-period');
Route::post('/add/probation_period', [ProbationSetting::class, 'Add'])->name('probation-period.store');
Route::get('/probation_period/edit/{id}', [ProbationSetting::class, 'Edit']);
Route::post('/probation_period/update', [ProbationSetting::class, 'update'])->name('probation-period.update');
Route::post('/probation_period/status/{id}', [ProbationSetting::class, 'Status']);
Route::delete('/probation_period/delete/{id}', [ProbationSetting::class, 'Delete']);
//Settings ProbationSetting end

//Settings Material
Route::get('/settings/material_type', [MaterialType::class, 'index'])->name('settings-material-type');
Route::post('/add/material', [MaterialType::class, 'Add'])->name('material_settings.store');
Route::get('/material/edit/{id}', [MaterialType::class, 'Edit']);
Route::post('/material/update', [MaterialType::class, 'update'])->name('material_settings.update');
Route::post('/material/status/{id}', [MaterialType::class, 'Status']);
Route::delete('/material/delete/{id}', [MaterialType::class, 'Delete']);
//Settings Material
 
//Settings HiredMaterial STart 
Route::get('/settings/hired_material', [HiredMaterial::class, 'index'])->name('settings-hired-material');
Route::post('/add/hired_material', [HiredMaterial::class, 'Add'])->name('hired_material_settings.store');
Route::get('/hired_material/edit/{id}', [HiredMaterial::class, 'Edit']);
Route::post('/hired_material/update', [HiredMaterial::class, 'update'])->name('hired_material_settings.update');
Route::post('/hired_material/status/{id}', [HiredMaterial::class, 'Status']);
Route::delete('/hired_material/delete/{id}', [HiredMaterial::class, 'Delete']);
//Settings HiredMaterial End

// Settings Designationsettings Start
Route::get('/settings/designation-setting', [Designationsettings::class, 'index'])->name('settings-designation-setting');
Route::post('/add_admin/designation/group', [Designationsettings::class, 'Add'])->name('add_designation_category');
Route::get('/designation_edit/{id}', [Designationsettings::class, 'Edit']);
Route::post('/designation/group_update', [Designationsettings::class, 'update'])->name('designation_update_name');
Route::post('/designation/group_status/{id}', [Designationsettings::class, 'Status']);
Route::delete('/admin/designation_delete/{id}', [Designationsettings::class, 'Delete']);
// Settings Designationsettings End

Route::get('/settings/financial_settings', [FinancialSetting::class, 'index'])->name('settings-financial-setting');
Route::get('/settings/creditcard_settings', [CreditcardSetting::class, 'index'])->name('settings-creditcard-setting');
Route::get('/settings/creditcardtype_settings', [CreditcardtypeSetting::class, 'index'])->name('settings-creditcardtype-setting');
Route::get('/settings/bank_settings', [BankSetting::class, 'index'])->name('settings-bank-setting');
Route::get('/settings/email_settings', [EmailtemplateSetting::class, 'index'])->name('settings-email-setting');




Route::get('/settings/course_settings', [CourseSetting::class, 'index'])->name('settings-course-setting');
Route::get('/settings/brand_settings', [BrandSetting::class, 'index'])->name('settings-brand-setting');

Route::get('/settings/companymobile_settings', [CompanymobileSetting::class, 'index'])->name('settings-companymobile-setting');

Route::get('/settings/structure_type_settings', [StructureSetting::class, 'index'])->name('settings-structure-setting');
Route::get('/settings/structure_type_item_settings', [Structuretypeitem::class, 'index'])->name('settings-structuretypeitem-setting');




//Site Log Client Start 
Route::get('/client_state_listing', [Client::class, 'StateList'])->name('client_state_listing');
Route::get('/client_city_listing', [Client::class, 'CityList'])->name('client_city_listing');
Route::post('/add_client', [Client::class, 'Add'])->name('add_client');
Route::get('/client_view/{id}', [Client::class, 'View'])->name('client_view');
Route::delete('/delete_client/{id}', [Client::class, 'Delete'])->name('delete_client');
Route::post('/client_status/{id}', [Client::class, 'Status'])->name('client_status');
Route::post('/client_updates/{id}', [Client::class, 'Update'])->name('client_updates');
//Site Log Client End

//Site Log Contractor Start
Route::get('/site/contractor', [ContractorList::class, 'index'])->name('manage-contractor');
Route::post('/add_contractor', [ContractorList::class, 'Add'])->name('add_contractor');
Route::get('/contractor_view/{id}', [ContractorList::class, 'View'])->name('contractor_view');
Route::get('/contactor_state_listing', [ContractorList::class, 'ContractStateList'])->name('contactor_state_listing');
Route::get('/contractor_city_listing', [ContractorList::class, 'ContractCityList'])->name('contractor_city_listing');
Route::get('/bank_state_listing', [ContractorList::class, 'BankStateList'])->name('bank_state_listing');
Route::get('/bank_city_listing', [ContractorList::class, 'BankCityList'])->name('bank_city_listing');
Route::delete('/delete_contractor/{id}', [ContractorList::class, 'Delete'])->name('delete_contractor');
Route::post('/contractor_status/{id}', [ContractorList::class, 'Status'])->name('contractor_status');
Route::post('/contract_updates/{id}', [ContractorList::class, 'Update'])->name('contract_updates');
//Site Log Contractor End



//Site Log Vendor Start
Route::get('/site/vendor',[VendorController::class, 'vendor_controller'])->name('site.vendor');
Route::post('/add_vendor', [VendorController::class, 'Add'])->name('add_vendor');
Route::get('/vendor_view/{id}', [VendorController::class, 'View'])->name('vendor_view');
Route::get('/vendor_state_listing', [VendorController::class, 'VendorStateList'])->name('vendor_state_listing');
Route::get('/vendor_city_listing', [VendorController::class, 'VendorCityList'])->name('vendor_city_listing');
Route::get('/bank_state_listing', [VendorController::class, 'BankStateList'])->name('bank_state_listing');
Route::get('/bank_city_listing', [VendorController::class, 'BankCityList'])->name('bank_city_listing');
Route::delete('/delete_vendor/{id}', [VendorController::class, 'Delete'])->name('delete_vendor');
Route::post('/vendor_updates/{id}', [VendorController::class, 'Update'])->name('vendor_updates');
//Site Log Vendor End
 

Route::get('/settings/payslip_type', [PayslipType::class, 'index'])->name('settings-payslip-type');
Route::get('/settings/ledger', [Ledger::class, 'index'])->name('settings-ledger');
Route::get('/settings/sub_ledger', [SubLedger::class, 'index'])->name('settings-sub-ledger');


// Department Settings Start
Route::get('/settings/department-setting', [Departmentsettings::class, 'index'])->name('settings-department-setting');
Route::post('/add_department_setting', [Departmentsettings::class, 'Add'])->name('add_department_setting');
Route::get('/department_edit/{categoryId}', [Departmentsettings::class, 'View'])->name('department_edit');
Route::post('/department_update/{id}', [Departmentsettings::class, 'Update'])->name('department_update');
Route::post('/department_status/{id}', [Departmentsettings::class, 'Status'])->name('department_status');
Route::delete('/delete_department/{id}', [Departmentsettings::class, 'Delete'])->name('delete_department');
// Department Settings End

Route::get('/settings/jobrole-setting', [Jobrolesettings::class, 'index'])->name('settings-jobrole-setting');



//Grade settings Start
Route::get('/settings/gradelist-setting', [Gradelistsettings::class, 'index'])->name('settings-gradelist-setting');
Route::post('/add_grade_setting', [Gradelistsettings::class, 'Add'])->name('add_grade_setting');
Route::get('/grade_edit/{categoryId}', [Gradelistsettings::class, 'View'])->name('grade_edit');
Route::post('/grade_update/{id}', [Gradelistsettings::class, 'Update'])->name('grade_update');
Route::post('/grade_status/{id}', [Gradelistsettings::class, 'Status'])->name('grade_status');
Route::delete('/delete_grade/{id}', [Gradelistsettings::class, 'Delete'])->name('delete_grade');
//Grade settings End

//Renumeration settings Start
Route::get('/settings/remuneration_type', [RemunerationType::class, 'index'])->name('settings-remuneration-type');
Route::post('/add_renumeration_setting', [RemunerationType::class, 'Add'])->name('add_renumeration_setting');
Route::post('/renumeration_update/{id}', [RemunerationType::class, 'Update'])->name('renumeration_update');
Route::get('/renumeration_edit/{categoryId}', [RemunerationType::class, 'View'])->name('renumeration_edit');
Route::post('/renumeration_status/{id}', [RemunerationType::class, 'Status'])->name('renumeration_status');
Route::delete('/delete_renumeration/{id}', [RemunerationType::class, 'Delete'])->name('delete_renumeration');
//Renumeration settings End

//Shift settings Start
Route::get('/settings/shift-setting', [Shiftsettings::class, 'index'])->name('settings-shift-setting');
Route::post('/add_shift_setting', [Shiftsettings::class, 'Add'])->name('add_shift_setting');
Route::get('/shift_time_edit/{categoryId}', [Shiftsettings::class, 'View'])->name('shift_time_edit');
Route::post('/shift_time_status/{id}', [Shiftsettings::class, 'Status'])->name('shift_time_status');
Route::post('/shift_time_update/{id}', [Shiftsettings::class, 'Update'])->name('shift_time_update');
Route::delete('/delete_shift_time/{id}', [Shiftsettings::class, 'Delete'])->name('delete_shift_time');
//Shift settings End


//Store&PurchaseManagement Start
Route::get('/store-purchase/warehouse', [DepotYard::class, 'index'])->name('store-purchase.warehouse');
Route::get('/store/states_by_country', [DepotYard::class, 'ListCountry']);
Route::get('/store/states_by_country/{countryId}', [DepotYard::class, 'List']);
Route::get('/store/city_by_state/{stateId}', [DepotYard::class, 'ListCity']);
Route::get('/depotyard/edit/fetch/{warehouse_id}',[DepotYard::class, 'EditFetch'])->name('depot-yard-editfetch');
Route::post('/depot-yard/update/{id}',[DepotYard::class, 'Update'])->name('depot-yard.update');
Route::post('/warehouse/depot-yard/add',[DepotYard::class, 'Add'])->name('depot-yard.store');
Route::post('/depot-yard/status/{id}',[DepotYard::class, 'UpdateStatus'])->name('depot-yard.update-status');
Route::get('/store-purchase/warehouse/list',[DepotYard::class, 'listWarehouses'])->name('store-purchase.warehouse.list');
//Store&PurchaseManagement End

// Settings Blood Group Start
Route::get('/settings/blood_group', [BloodGroup::class, 'index'])->name('settings-blood-group');
Route::post('/add_admin/blood/group', [BloodGroup::class, 'Add'])->name('add_blood_category');
Route::get('/blood/group_edit/{id}', [BloodGroup::class, 'Edit']);
Route::post('/blood/group_update', [BloodGroup::class, 'update'])->name('blood_update_name');
Route::post('/blood/group_status/{id}', [BloodGroup::class, 'Status']);
Route::delete('/admin/blood_delete/{id}', [BloodGroup::class, 'Delete']);
// Settings Blood Group End



Route::get('/settings/machinery_type', [MachineryType::class, 'index'])->name('settings-machinery-type');


// Settings Menu End

// Admin/Hr Menu Starts
Route::get('/admin-hr/permanent-staff', [PermanentEmpController::class,'index'])->name('admin-hr.staff.permanent');
Route::get('/admin-hr/contract-staff', [ContractorEmpController::class,'index'])->name('admin-hr.staff.contract');

// Permanent attendance
Route::get('/admin-hr/permanent-log', [PermanentList::class, 'list'])->name('admin-hr.attendance.list');
Route::get('admin-hr/permanent-log/table', [PermanentTable::class, 'table'])->name('admin-hr.attendance.table');
Route::get('admin-hr/permanent-log/calender', [PermanentCalender::class, 'calender'])->name('admin-hr.attendance.calender');

// Contract attendance
Route::get('/admin-hr/contract-log', [ContractList::class,'contract_list'])->name("admin-hr.attendance.clist");
Route::get('/admin-hr/contract-log/table',[ContractTable::class,'contract_table'])->name("admin-hr.attendance.ctable");
Route::get('/admin-hr/contract-log/calender',[ContractCalender::class,'contract_calender'])->name("admin-hr.attendance.ccalender");

// Permanent leave
Route::get('/admin-hr/leave_management/permanent', [PermanentLeave::class,'leave'])->name("admin-hr.leave.permanent");
Route::get('/admin-hr/leave_management/permanent/leave_entitle', [Permanent_Entitle::class,'p_entitle'])->name("admin-hr.leave.permanent_entitle");

// Contract leave
Route::get('/admin-hr/leave_management/contract', [ContractLeave::class,'cleave'])->name("admin-hr.leave.contract");
Route::get('/admin-hr/leave_management/contract/leave_entitle', [Contract_Entitle::class,'c_entitle'])->name("admin-hr.leave.contract_entitle");

// Wages Permanent
Route::get('/admin-hr/wages/permanent-staff', [SalaryController::class, 'p_controller'])->name("admin-hr.wages.permanent");
Route::get('/admin-hr/wages/permanent-staff/promotion&appraisal', [PromoController::class, 'promo_controller'])->name("admin-hr.wages.permanent.promotion&appraisal");
Route::get('/admin-hr/wages/permanent-staff/LoanDisbursement', [LoanController::class, 'ploan_controller'])->name("admin-hr.wages.permanent.LoanDisbursement");

// Wages Contract
Route::get('/admin-hr/wages/contractstaff', [SalaryContract::class, 's_contract'])->name("admin-hr.wages.contract-staff");
Route::get('/admin-hr/wages/contractstaff/promotion&appraisal', [PromoContract::class, 'p_contract'])->name("admin-hr.wages.contract-staff.promotion&appraisal");
Route::get('/admin-hr/wages/contractstaff/LoanDisbursement', [LoanContract::class, 'l_contract'])->name("admin-hr.wages.contract-staff.LoanDisbursement");

// Payroll Permanent
Route::get('/admin-hr/payroll', [RegisterPermanent::class, 'register_pcontroller'])->name('admin-hr.payroll.permanent');
Route::get('/admin-hr/payroll/monthly_variable_adjustment', [MonthlyPermanent::class, 'monthly_pcontroller'])->name('admin-hr.payroll.permanent.monthlyvariableadjustment');
Route::get('/admin-hr/payroll/permanent_payslip', [PayslipPermanent::class, 'payslip_pcontroller'])->name('admin-hr.payroll.permanent.payslip');

// Payroll Contract
Route::get('/admin-hr/payroll/contract', [RegisterContract::class, 'register_ccontroller'])->name('admin-hr.payroll.contract');
Route::get('/admin-hr/payroll/contract/monthly_variable_adjustment', [MonthlyContract::class, 'monthly_ccontroller'])->name('admin-hr.payroll.monthlyvariableadjustment');
Route::get('/admin-hr/payroll/contract/contract_payslip', [PayslipContract::class, 'payslip_ccontroller'])->name('admin-hr.payroll.payslip');

// EsiPF Permanent
Route::get("/admin-hr/esipf/permanent-staff", [Esipf_Permanent::class, 'esi_permanent'])->name('admin-hr.esipf.permanent');
Route::get("/admin-hr/esipf/contract-staff", [Esipf_Contract::class, 'esi_contract'])->name('admin-hr.esipf.contract');
// Admin/Hr Menu Ends

// Site-log Starts

Route::get('/site/manage-store/site&warehouse',[ManageStore_Controller::class, 'manage_store_controller'])->name('site.manage-store');
Route::get('/site/manage-store/stock_transfer', [StockTransfer_Controller::class, 'stock_transfer_controller'])->name('site.stock_transfer');
Route::get('/site/manage-store/stock_inventory', [StockInventory_Controller::class, 'stock_inventory_controller'])->name('site.stock_inventory');
Route::get('/site/client', [Client::class, 'index'])->name('manage-client');



Route::get('/site/manage-structure', [manageController::class, 'structure'])->name('site.manage-structure');
Route::get('/site/manage-structure/view',[manageController::class, 'structureView'])->name('site.manage-structure.view');

//  Site-log Ends
// accounts 
Route::get('/accounts/accounts-receivable', [Receivable_Controller::class, 'Receive']) -> name('accounts.accounts-receivable');

Route::get('/accounts/accounts-payable', [Accounts_Controller::class, 'accounts_pay']) -> name('accounts.accounts-payable');
Route::get('/accounts/expense-management', [Expense_list::class, 'expense_list']) -> name('accounts.expense-manage.list');
Route::get('/accounts/expense-management/summary', [Expense_summary::class, 'expense_summary']) -> name('accounts.expense-manage.summary');
Route::get('/accounts/expense-management/list', [Expense_list::class, 'expense_list']) -> name('accounts.expense-manage.list');

Route::get('/accounts/tax-management',[gst_entry_controller::class,'gst_entry']) -> name('accounts.tax-management');
Route::get('/accounts/tax-management/gst_estimation',[gst_estimate_controller::class,'gst_estimate']) -> name('accounts.tax-management.gst-estimate');
Route::get('/accounts/tax-management/gst_payable',[gst_payable::class,'gst_pay']) -> name('accounts.tax-management.gst-payable');
Route::get('/accounts/tax-management/gst_recollination',[gst_recollination::class,'gst_recol']) -> name('accounts.tax-management.gst-recollination');
Route::get('/accounts/tax-management/file_return',[file_controller::class,'file_return']) -> name('accounts.tax-management.gst-file_return');
Route::get('/accounts/tax-management/create_file_return',[create_file_controller::class,'create_file']) -> name('accounts.tax-management.create_file_return');
Route::get('/accounts/reports',[profit_loss_controller::class,'profit_loss']) -> name('accounts.reports');
Route::get('/accounts/client-reports',[client_controller::class,'client']) -> name('accounts.client.reports');
Route::get('/accounts/client-reports/client_view',[client_view_controller::class,'client_view']) -> name('accounts.reports.client_view');
Route::get('/accounts/client-reports/contractor',[contractor_controller::class,'contract']) -> name('accounts.reports.contract');
Route::get('/accounts/client-reports/contractor_view',[contractor_view_controller::class,'contract_view']) -> name('accounts.reports.contract_view');
Route::get('/accounts/vendor-reports',[vendor_controller::class,'vendor']) -> name('accounts.reports.vendor');
Route::get('/accounts/vendor-reports/vendor_view',[vendor_view_controller::class,'vendor']) -> name('accounts.reports.vendor.view');
Route::get('/accounts/vendor-reports/staff_report',[staff_report::class,'staff_report']) -> name('accounts.reports.staff');
Route::get('/accounts/vendor-reports/staff_view_report',[staff_view_controller::class,'staff_view']) -> name('accounts.reports.staff.view');


Route::get('/store-purchase/fuel-management',[fuel_entry_controller::class,'fuel_entry'])->name('store-purchase.fuel-management');
Route::get('/store-purchase/fuel-stock',[fuel_stock_controller::class,'fuel_stock'])->name('store-purchase.fuel-stock');


Route::get('/site/manage-project', [ManageProjectController::class, 'manage_project_controller']) ->name('site.manage-project');

Route::get('/sitelog/manage-project/view', [ManageProjectController::class, 'view_project']) ->name('sitelog.manage_project.view');
Route::get('/manage-project/tabs/page/create-client-work-order',[ManageProjectController::class, 'create_client_work_order'])->name('manage_project.tabs.page.create-client-work-order');


// Plants and Machinary Starts
Route::get('/plant-machinery/machine-master' ,[Machine_Controller::class, 'machine_controller']) -> name('plant-machinery.machine-master');
Route::get('/plant-machinery/manage_flate' ,[Manage_flate::class,'manage_controller']) -> name('plant-machinery.machine-list');
Route::get('/plant-machinery/machine-operations' ,[assign_controller::class,'assign']) -> name('plant-machinery.assign-machine');
Route::get('/plant-machinery/machine-operations/machine_log', [machine_log::class,'log']) -> name('plant-machinery.machine-log');
Route::get('/plant-machinery/maintenance', [maintainance::class,'maintain']) -> name('plant-machinery.maintenance');
Route::get('/plant-machinery/billing', [billing::class,'bill']) -> name('plant-machinery.billing');
// Plants and Machinary Ends



Route::get('/store-purchase/inventory-ledger-balance', [InventoryLedgerBalance::class, 'index'])->name('store-purchase.inventory-ledger');
Route::get('/store-purchase/stock-transfer', [StockTransfer::class, 'index'])->name('store-purchase.stock-transfer');
Route::get('/store-purchase/material_allocation', [MaterialAllocation::class, 'index'])->name('store-purchase.material_allocation');
Route::get('/store-purchase/unused_material_return', [MaterialAllocation::class, 'unused_material'])->name('store-purchase.unused_material_return');
Route::get('/store-purchase/material_master', [MaterialMaster::class, 'index'])->name('store-purchase.material_master');
Route::get('/store-purchase/site_indent', [SiteIndent::class, 'index'])->name('store-purchase.site_indent');


// fuel management
Route::get('/store-purchase/fuel-management',[fuel_entry_controller::class,'fuel_entry'])->name('store-purchase.fuel-management');
Route::get('/store-purchase/fuel-stock',[fuel_stock_controller::class,'fuel_stock'])->name('store-purchase.fuel-stock');
Route::get('/store-purchase/fuel-reconciliation',[fuel_reconciliation_controller::class,'fuel_reconciliation']) ->name('store-purchase.fuel-reconciliation');
Route::get('/store-purchase/fuel-reconciliation/summary',[fuel_summary_controller::class,'fuel_summary']) ->name('store-purchase.fuel-reconciliation.summary');
Route::get('/store-purchase/fuel-tank_level',[fuel_tank_controller::class,'fuel_tank']) ->name('store-purchase.fuel-tank-level');
Route::get('/store-purchase/fuel-bulk',[fuel_bulk_controller::class,'fuel_bulk']) ->name('store-purchase.bulk_diesel');
Route::get('/store-purchase/Equipment_log',[Equipment_controller::class,'fuel_log']) ->name('store-purchase.fuel_log');
Route::get( '/store-purchase/quotation-comparison',[Quotation::class, 'quotationComparison'])->name('store-purchase.quotation-comparison');
Route::get( '/store-purchase/receipt-inspect', [Quotation::class, 'receiptInspect'])->name('store-purchase.receipt-inspect');
Route::get('/store-purchase/analytical-report', [Quotation::class, 'analyticalReport'])->name('store-purchase.analytical-report');




//scrap management 
Route::get('/store-purchase/scrap-management',[scrapController::class, 'scrap'])->name('store-purchase.scrap-management');

Route::get('/store-purchase/scrap-management/material-view',[scrapController::class, 'materialView'])->name('store-purchase.scrap-material-view');

Route::get('/store-purchase/scrap-management/disposal',[disposalController::class, 'disposal'])->name('store-purchase.scrap-disposal');


Route::get('/store-purchase/scrap-management/disposal-entry',[disposalController::class, 'disposalEntry'])->name('store-purchase.scrap-disposal-entry');

Route::get('/store-purchase/scrap-management/disposal-view',[disposalController::class, 'disposalView'])->name('store-purchase.scrap-disposal-view');

// Main Planning
Route::get('/planning-qs/planning', [PlanningController::class, 'index'])->name('planning-qs.planning');
Route::get('/planning/management', [PlanningController::class, 'index'])->name('planning-qs.management');
Route::get('/planning/daily', [PlanningController::class, 'dailyProgress'])->name('planning-qs.daily');
Route::get('/planning/achieved', [PlanningController::class, 'plannedVsAchieved'])->name('planning-qs.achieved');



Route::get('/planning-qs/work-orders', [workordersController::class, 'index'])->name('planning-qs.work-orders');

Route::get('/planning-qs/work-orders/sub', [workordersController::class, 'sub'])->name('planning-qs.work-orders.sub');


Route::get('/planning-qs/schedule', [SchedulerController::class, 'index'])->name('planning-qs.schedule');

Route::get('/planning-qs/schedule/balance', [SchedulerController::class, 'balance'])->name('planning-qs.schedule.balance');


Route::get('/planning-qs/financial-bills', [FinancialController::class, 'index'])->name('planning-qs.client');


Route::get('planning-qs/financial/contractor', [FinancialController::class, 'contractor'])->name('planning-qs.financial.contractor');


Route::get('planning-qs/financial/credit', [FinancialController::class, 'credit'])->name('planning-qs.financial.credit');


Route::get('planning-qs/financial/security', [FinancialController::class, 'security'])->name('planning-qs.financial.security');

Route::get('planning-qs/financial/report', [FinancialController::class, 'report'])->name('planning-qs.financial.report');



Route::get('/planning-qs/verification', [verificationController::class, 'index'])->name('planning-qs.verification');

Route::get('/planning-qs/verification/passing', [verificationController::class, 'passing'])->name('planning-qs.verification.passing');

//main accounts
Route::get('/accounts/banking', [AccountsController::class, 'index'])->name('accounts.banking');

Route::get('/accounts/ledger', [AccountsController::class, 'ledger'])->name('accounts.ledger');

Route::get('/accounts/bank-hold', [BankholdController::class, 'hold'])->name('accounts.bank.hold');

Route::get('/accounts/cashflow', [CashflowController::class, 'cash'])->name('accounts.cashflow');

Route::get('/accounts/creditcard', [CreditcardController::class, 'card'])->name('accounts.creditcard');

Route::get('/accounts/mobilebill', [MobileController::class, 'mobile'])->name('accounts.mobilebill');

//General Ledger
Route::get('/accounts/general-ledger', [DailyAccountsController::class, 'account'])->name('accounts.general-ledger');

Route::prefix('admin-hr/api')->name('admin-hr.api.')->group(function () {
    // Static endpoints must precede parameterized staff routes.
    Route::get('/staff/options', [StaffDirectoryController::class, 'options'])->name('staff.options');
    Route::get('/staff/unclassified', [StaffDirectoryController::class, 'unclassified'])->name('staff.unclassified');
    Route::patch('/staff/{id}/employment-type', [StaffDirectoryController::class, 'classify'])->whereNumber('id')->name('staff.classify');
    Route::get('/staff/{type}', [StaffDirectoryController::class, 'index'])->where('type', 'permanent|contract')->name('staff.index');
    Route::post('/staff/{type}', [StaffDirectoryController::class, 'store'])->where('type', 'permanent|contract')->name('staff.store');
     Route::get('/staff/{id}/photo', [StaffDirectoryController::class, 'photo'])->whereNumber('id')->name('staff.photo');
    Route::get('/staff/{id}', [StaffDirectoryController::class, 'show'])->whereNumber('id')->name('staff.show');
    Route::patch('/staff/{id}', [StaffDirectoryController::class, 'update'])->whereNumber('id')->name('staff.update');
    Route::patch('/staff/{id}/status', [StaffDirectoryController::class, 'status'])->whereNumber('id')->name('staff.status');
    Route::delete('/staff/{id}', [StaffDirectoryController::class, 'destroy'])->whereNumber('id')->name('staff.destroy');

    

    Route::get('/attendance/{type}/matrix', [AttendanceDirectoryController::class, 'matrix'])->where('type', 'permanent|contract')->name('attendance.matrix');
    Route::get('/attendance/{type}', [AttendanceDirectoryController::class, 'index'])->where('type', 'permanent|contract')->name('attendance.index');
    Route::post('/attendance/{type}', [AttendanceDirectoryController::class, 'save'])->where('type', 'permanent|contract')->name('attendance.save');

    Route::post('/leave/batch-credit', [LeaveDirectoryController::class, 'batchCreditGroup'])->name('leave.batch-credit');
    Route::post('/leave/{type}', [LeaveDirectoryController::class, 'storeRequest'])->where('type', 'permanent|contract')->name('leave.store');
    Route::get('/leave/{type}/policies', [LeaveDirectoryController::class, 'policies'])->where('type', 'permanent|contract')->name('leave.policies');
    Route::put('/leave/{type}/policies', [LeaveDirectoryController::class, 'savePolicies'])->where('type', 'permanent|contract')->name('leave.policies.save');
    Route::get('/leave/{type}/history', [LeaveDirectoryController::class, 'history'])->where('type', 'permanent|contract')->name('leave.history');
    Route::get('/leave/{type}', [LeaveDirectoryController::class, 'index'])->where('type', 'permanent|contract')->name('leave.index');
    Route::get('/leave/{type}/entitlements', [LeaveDirectoryController::class, 'entitlements'])->where('type', 'permanent|contract')->name('leave.entitlements');
    Route::post('/leave/{type}/entitlements', [LeaveDirectoryController::class, 'saveEntitlement'])->where('type', 'permanent|contract')->name('leave.entitlements.save');
    Route::post('/leave/{type}/entitlements/bulk', [LeaveDirectoryController::class, 'saveEntitlementsBulk'])->where('type', 'permanent|contract')->name('leave.entitlements.bulk');
    Route::post('/leave/{type}/entitlements/batch-credit', [LeaveDirectoryController::class, 'batchCredit'])->where('type', 'permanent|contract')->name('leave.entitlements.batch-credit');
    Route::patch('/leave/{type}/{id}/review', [LeaveDirectoryController::class, 'review'])->where(['type' => 'permanent|contract', 'id' => '[0-9]+'])->name('leave.review');

    Route::get('/wages/{type}', [WagesDirectoryController::class, 'index'])->where('type', 'permanent|contract')->name('wages.index');
    Route::get('/wages/{type}/{id}', [WagesDirectoryController::class, 'show'])->where(['type' => 'permanent|contract', 'id' => '[0-9]+'])->name('wages.show');
    Route::put('/wages/{type}/{id}', [WagesDirectoryController::class, 'save'])->where(['type' => 'permanent|contract', 'id' => '[0-9]+'])->name('wages.save');
});

    Route::post('/check-staff-mobile-exists', [StaffDirectoryController::class, 'checkStaffMobileExists'])->name('checkStaffMobileExists');
    Route::post('/checkunique_mobile_edit', [StaffDirectoryController::class, 'checkStaffMobileExists_edit'])->name('checkunique_mobile_edit');

});

// Main Page Route
Route::get('/', [Login::class, 'index'])->name('login');
// Login
Route::post('/login', [Login::class, 'Login'])->name('login_auth');
// logout
Route::post('/logout', [Login::class, 'destroy'])->name('logout');
Route::get('/get_staff', [Login::class, 'get_staff'])->name('get-staff');
Route::get('/forgot_password', [Login::class, 'forgot_password'])->name('forgot-password');
Route::get('/change_password', [Login::class, 'new_password'])->name('new-password');
// Route::get('/dashboards', [Login::class, 'dashboards'])->name('dashboards');


// locale

// icons
// Route::get('/icons/icons-mdi', [MdiIcons::class, 'index'])->name('icons-mdi');

