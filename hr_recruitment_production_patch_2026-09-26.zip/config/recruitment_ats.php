<?php

return [
    'model' => env('RECRUITMENT_ATS_MODEL', env('HF_RESUME_MODEL', 'Qwen/Qwen3-32B')),
    'queue' => env('RECRUITMENT_ATS_QUEUE', 'ats-role-matching'),
    'minimum_match_score' => (float) env('RECRUITMENT_ATS_MIN_SCORE', 70),
    'near_match_min_score' => (float) env('RECRUITMENT_ATS_NEAR_MIN_SCORE', 45),
    'near_match_max_items' => (int) env('RECRUITMENT_ATS_NEAR_MAX_ITEMS', 8),
    'verified_evidence_cap' => (float) env('RECRUITMENT_ATS_VERIFIED_EVIDENCE_CAP', 69),
    'default_batch_size' => (int) env('RECRUITMENT_ATS_BATCH_SIZE', 2),
    'default_workers' => (int) env('RECRUITMENT_ATS_WORKERS', 3),
    'max_batch_size' => (int) env('RECRUITMENT_ATS_MAX_BATCH', 3),
    'max_workers' => (int) env('RECRUITMENT_ATS_MAX_WORKERS', 8),
    'max_bulk_limit' => (int) env('RECRUITMENT_ATS_MAX_BULK', 50000),
    // ERP role_id values: 1 Super Admin/Developer, 2 HR Recruiter, 3 HR Executive.
    'allowed_role_ids' => array_values(array_filter(array_map('intval', preg_split('/[,;\s]+/', (string) env('RECRUITMENT_ATS_ALLOWED_ROLES', '1,2,3'))))),
    'force_reprocess_role_ids' => array_values(array_filter(array_map('intval', preg_split('/[,;\s]+/', (string) env('RECRUITMENT_ATS_FORCE_ROLES', '1'))))),
    'resume_model_max_chars' => (int) env('RECRUITMENT_ATS_RESUME_MAX_CHARS', 90000),
    'schema_version' => env('RECRUITMENT_ATS_SCHEMA_VERSION', 'ats_role_matching.v4'),
    'engine' => env('RECRUITMENT_ATS_ENGINE', 'egc_ats_role_matching_hybrid_v4'),
];
