# HR Recruitment Production Patch

This patch targets only the Manage Candidate resume extraction/save path and the ATS individual/bulk role-matching path.

## Accuracy model

No resume parser can guarantee 100% factual extraction for every arbitrary, damaged, ambiguous, or image-only resume. The implementation therefore uses an evidence-first design:

- deterministic extraction for Indian mobile numbers, email, explicit gender/marital status, education and employment dates
- Hugging Face structured JSON extraction for semantic fields and experience entries
- AI values are accepted only when corroborated by the extracted resume text
- no AI inference for gender or marital status
- ambiguous master-data major matches are left as source text for HR review instead of being silently mapped
- resume parsing result is cached for 15 minutes and bound to the uploaded file SHA-256, so the Add Candidate preview and final save use the same extraction
- final ATS role scores are recalculated against the actual resume and current enabled role catalogue; model-only scores are not accepted as final truth

## Hugging Face

Recommended model configuration:

`RECRUITMENT_ATS_MODEL=Qwen/Qwen3-32B`

For resume extraction:

`HF_RESUME_MODEL=Qwen/Qwen3-32B`
`HF_RESUME_TIMEOUT=55`
`HF_RESUME_ALWAYS_AI=true`

Token can be supplied through `HF_TOKEN` or `HUGGINGFACE_API_TOKEN`. The resume parser also falls back to the existing ERP `egc_api_integration` Hugging Face credential (`egc_huggingface_api_1`).

## ATS access

Default ERP role IDs enabled for the ATS screen:

`RECRUITMENT_ATS_ALLOWED_ROLES=1,2,3`

Force reprocessing remains Super Admin/Developer by default:

`RECRUITMENT_ATS_FORCE_ROLES=1`

The current codebase's existing role references identify role 3 as HR Executive and role 2 as HR Recruiter.

## Bulk processing

Bulk ATS matching is asynchronous and intended for 100+ candidates. Configure an async Laravel queue in production. The code deliberately rejects `sync` for bulk ATS runs.

Recommended queue:

`RECRUITMENT_ATS_QUEUE=ats-role-matching`

Run/Horizon the queue with a worker timeout that exceeds the Hugging Face request timeout.

## OCR

For image/scanned resumes:

`RESUME_OCR_LANG=eng`
`RESUME_OCR_DPI=170`
`RESUME_OCR_MAX_PAGES=25`

The server must have Tesseract and `pdftoppm` installed for scanned-image/scanned-PDF fallback.

## Deployment

After replacing these files, clear Laravel configuration/cache and restart queue workers so the new configuration and code are loaded.
