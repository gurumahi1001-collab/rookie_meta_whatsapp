<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class RecruitmentRoleProfileService
{
    public function activeRoles(): array
    {
        return DB::table('egc_recruitment_roles')
            ->where('status', 0)
            ->where(function ($query) {
                $query->where('match_enabled', 1)->orWhereNull('match_enabled');
            })
            ->orderBy('sno')
            ->get()
            ->map(function ($role) {
                $hasNew = property_exists($role, 'role_name') || property_exists($role, 'description');
                return [
                    'role_id' => (int) $role->sno,
                    'role_code' => trim((string) ($role->role_code ?? '')),
                    'role_name' => trim((string) ($hasNew ? ($role->role_name ?? '') : ($role->jobrole_name ?? ''))),
                    'description' => trim((string) ($hasNew ? ($role->description ?? '') : ($role->role_description ?? ''))),
                    'mandatory_skills' => $this->jsonArray($role->mandatory_skills ?? null),
                    'preferred_skills' => $this->jsonArray($role->preferred_skills ?? null),
                    'responsibilities' => $this->jsonArray($role->responsibilities ?? null),
                    'minimum_experience' => isset($role->minimum_experience) && is_numeric($role->minimum_experience) ? (float) $role->minimum_experience : null,
                    'education' => $this->jsonArray($role->education_requirements ?? null),
                    'seniority' => trim((string) ($role->seniority ?? ($role->seniority_level ?? ''))),
                    'aliases' => $this->jsonArray($role->aliases ?? null),
                ];
            })
            ->values()->toArray();
    }

    protected function jsonArray($value): array
    {
        if (is_array($value)) return array_values(array_filter(array_map('trim', $value)));
        if (!$value) return [];
        $decoded = json_decode((string) $value, true);
        if (is_array($decoded)) return array_values(array_filter(array_map('trim', $decoded)));
        return array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', (string) $value))));
    }
}
