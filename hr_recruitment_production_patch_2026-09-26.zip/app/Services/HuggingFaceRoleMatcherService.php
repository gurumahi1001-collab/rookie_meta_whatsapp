<?php

namespace App\Services;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;
use App\Services\PromptBuilderService;
use App\Services\AIResponseValidatorService;
use App\Services\ApplicantUpdaterService;

class HuggingFaceRoleMatcherService
{

    protected PromptBuilderService $promptBuilder;
    protected AIResponseValidatorService $validator;
    protected ApplicantUpdaterService $updater;

    public function __construct(
        HuggingFaceClientService $hf,
        PromptBuilderService $promptBuilder,
        AIResponseValidatorService $validator,
         ApplicantUpdaterService $updater
    ){

        $this->hf = $hf;

        $this->promptBuilder = $promptBuilder;

        $this->validator = $validator;
          $this->updater = $updater;

    }
    /**
     * Match Applicant
     */
    public function matchApplicant(ApplicantModel $applicant): array
    {
        try {

            /*
            |--------------------------------------------------------------------------
            | Resume
            |--------------------------------------------------------------------------
            */

            $resume = trim($applicant->resume_text ?? '');

            if (empty($resume)) {

                return [
                    'status' => false,
                    'message' => 'Resume text not found.'
                ];
            }

            /*
            |--------------------------------------------------------------------------
            | Reduce Prompt Tokens
            |--------------------------------------------------------------------------
            */

            $resume = mb_substr($resume, 0, 30000);

            /*
            |--------------------------------------------------------------------------
            | Roles
            |--------------------------------------------------------------------------
            */

            $roles = $this->getRoles();

            if (empty($roles)) {

                return [
                    'status' => false,
                    'message' => 'No active roles found.'
                ];
            }

            /*
            |--------------------------------------------------------------------------
            | Prompt
            |--------------------------------------------------------------------------
            */

            $prompt = $this->promptBuilder
                    ->roleMatching(
                        $resume,
                        $roles
                    );

            /*
            |--------------------------------------------------------------------------
            | AI
            |--------------------------------------------------------------------------
            */

            $result = app(HuggingFaceClientService::class)
                        ->askJson($prompt);

            if (!$result['status']) {

                return $result;
            }

            /*
            |--------------------------------------------------------------------------
            | Validate
            |--------------------------------------------------------------------------
            */

            $validated = $this->validator
                ->validateRoleMatching(
                    $result['data'],
                    $resume
                );

            if(!$validated['status']){

                return $validated;

            }

            $matches = $validated['matches'];

            if (empty($matches)) {

                return [
                    'status' => false,
                    'message' => 'No valid roles returned.'
                ];
            }

            /*
            |--------------------------------------------------------------------------
            | Save
            |--------------------------------------------------------------------------
            */

            $save = $this->updater
                ->saveRoleMatching(
                    $applicant,
                    $matches,
                    $result
                );

            if (!$save['status']) {

                return $save;

            }

            return [

                'status' => true,

                'job_role_ids' => $save['job_role_ids'],

                'confidence' => $save['confidence'],

                'matches' => $matches

            ];

        

        } catch (Exception $e) {

            Log::error(

                'HF ROLE MATCH ERROR',

                [

                    'applicant_id' => $applicant->sno,

                    'message' => $e->getMessage()

                ]

            );

            return [

                'status' => false,

                'message' => $e->getMessage()

            ];
        }
    }

    /**
     * Roles
     */
    private function getRoles(): array
    {
        return Cache::rememberForever(

            'hf_job_roles',

            function () {

                return DB::table('egc_recruitment_roles')

                    ->where('status', 0)

                    ->orderBy('sno')

                    ->get(['sno', 'jobrole_name'])

                    ->map(function ($role) {

                        return [

                            'role_id' => (int)$role->sno,

                            'role_name' => trim($role->jobrole_name)

                        ];

                    })

                    ->values()

                    ->toArray();
            }

        );
    }

    /**
     * Prompt
     */
    private function buildPrompt(
        string $resume,
        array $roles
    ): string {

        return <<<PROMPT
You are an AI Recruitment Engine.

Match the resume against ONLY the given roles.

Rules

- Never create a new role.
- Use ONLY role_id values provided.
- Return maximum 3 role_ids.
- Highest confidence first.
- Confidence between 0 and 100.
- Return ONLY JSON.

Roles

{$this->json($roles)}

Resume

{$resume}

Output

{
 "matches":[
  {
   "role_id":1,
   "confidence":96
  }
 ]
}
PROMPT;

    }

    /**
     * AI Call
     */
    private function callAI(string $prompt): array
    {
        $apiKey = $this->getApiKey();

        if (!$apiKey) {

            return [

                'status' => false,

                'message' => 'HF API Key Missing.'

            ];
        }

        $response = Http::timeout(120)

            ->retry(3, 3000)

            ->withToken($apiKey)

            ->post(

                'https://router.huggingface.co/v1/chat/completions',

                [

                    'model' => 'meta-llama/Llama-3.1-8B-Instruct:novita',

                    'temperature' => 0,

                    'stream' => false,

                    'messages' => [

                        [

                            'role' => 'user',

                            'content' => $prompt

                        ]

                    ]

                ]

            );

        if (!$response->successful()) {

            return [

                'status' => false,

                'message' => $response->body()

            ];
        }

        $content = data_get(

            $response->json(),

            'choices.0.message.content'

        );

        $content = preg_replace(

            '/```json|```/',

            '',

            trim($content)

        );

        $json = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {

            return [

                'status' => false,

                'message' => 'Invalid AI JSON.'

            ];
        }

        return [

            'status' => true,

            'matches' => $json['matches'] ?? []

        ];
    }

    /**
     * Validate
     */
    private function validateMatches(
        array $matches,
        array $roles
    ): array {

        $valid = array_column(

            $roles,

            'role_id'

        );

        $output = [];

        foreach ($matches as $match) {

            if (

                isset($match['role_id']) &&

                in_array(

                    $match['role_id'],

                    $valid

                )

            ) {

                $output[] = [

                    'role_id' => (int)$match['role_id'],

                    'confidence' => (float)$match['confidence']

                ];
            }

        }

        usort(

            $output,

            fn($a, $b) =>

            $b['confidence'] <=> $a['confidence']

        );

        return array_slice(

            $output,

            0,

            3

        );
    }

    /**
     * Save
     */
    private function saveApplicant(
        ApplicantModel $applicant,
        array $matches,
        array $response
    ): void {

        $applicant->job_role_id = json_encode(

            array_column(

                $matches,

                'role_id'

            )

        );

        $applicant->match_score =

            $matches[0]['confidence'];

        $applicant->ai_response = json_encode(

            $response,

            JSON_UNESCAPED_UNICODE

        );

        $applicant->save();
    }

    /**
     * API Key
     */
    private function getApiKey(): ?string
    {
        return Cache::rememberForever(

            'hf_api_key',

            function () {

                $api = DB::table(

                    'egc_api_integration'

                )

                    ->where(

                        'api_key',

                        'egc_huggingface_api_1'

                    )

                    ->where(

                        'status',

                        0

                    )

                    ->latest('sno')

                    ->first();

                if (!$api) {

                    return null;
                }

                foreach (

                    json_decode(

                        $api->api_fields,

                        true

                    ) as $field

                ) {

                    if (

                        $field['key'] == 'api_key'

                    ) {

                        return $field['value'];
                    }

                }

                return null;

            }

        );
    }

    /**
     * JSON
     */
    private function json(array $data): string
    {
        return json_encode(

            $data,

            JSON_UNESCAPED_UNICODE

        );
    }
}