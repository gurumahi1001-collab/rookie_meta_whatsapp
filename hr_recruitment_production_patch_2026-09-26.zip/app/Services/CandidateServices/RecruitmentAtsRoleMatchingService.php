<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantAtsRoleAnalysisModel;
use App\Models\ApplicantAtsRoleMatchModel;
use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class RecruitmentAtsRoleMatchingService
{
    public function __construct(
        protected RecruitmentAtsRoleCatalogService $roleCatalog,
        protected RecruitmentAtsResumeSourceService $resumeSource,
        protected RecruitmentAtsPromptService $prompt,
        protected RecruitmentAtsResponseValidator $validator,
        protected HuggingFaceClientService $huggingFace,
    ) {
    }

    /**
     * Run a detailed ATS analysis for one candidate.
     *
     * This feature uses dedicated ATS tables and intentionally does not modify
     * egc_applicant.ai_response, job_role_id or match_score. Existing candidate
     * intelligence features therefore remain independent.
     */
    public function analyzeApplicant(
        ApplicantModel $applicant,
        array $sourceOverride = [],
        ?int $runSno = null,
        int $actorId = 0,
        bool $persistResume = false
    ): array {
        if ((int) $applicant->status === 2) {
            return [
                'status' => false,
                'message' => 'Applicant is not eligible for ATS role matching.',
            ];
        }

        $source = $this->resumeSource->resolve($applicant, $sourceOverride);
        $roles = $this->roleCatalog->getActiveRoles();
        $roleCatalogHash = $this->roleCatalog->getCatalogHash($roles);

        if (empty($roles)) {
            return [
                'status' => false,
                'message' => 'No active ATS-enabled recruitment roles are configured.',
            ];
        }

        if ($persistResume && ($sourceOverride['source_type'] ?? 'stored') !== RecruitmentAtsResumeSourceService::SOURCE_STORED) {
            $this->persistResumeOverride($applicant, $source['text']);
        }

        $payload = [[
            'sno' => (string) $applicant->sno,
            'resume' => $this->resumeSource->prepareForModel($source['text']),
        ]];

        $aiResponse = $this->requestAi($payload, $roles);
        if (!$aiResponse['status']) {
            return $aiResponse;
        }

        $validated = $this->validator->validateBatch(
            $aiResponse['data'] ?? [],
            [(string) $applicant->sno],
            $roles,
            [(string) $applicant->sno => $source['text']]
        );

        if (!$validated['status']) {
            // One clean retry with the same data is safer than persisting an
            // incomplete analysis. HuggingFaceClientService already has HTTP retries.
            Log::warning('ATS individual response validation failed.', [
                'applicant_sno' => $applicant->sno,
                'message' => $validated['message'] ?? 'unknown',
            ]);

            $fallback = $this->requestSingleApplicantFallback($applicant, $source, $roles);
            if (!$fallback['status']) {
                return $fallback;
            }

            $validated = $this->validator->validateBatch(
                $fallback['data'] ?? [],
                [(string) $applicant->sno],
                $roles,
                [(string) $applicant->sno => $source['text']]
            );

            if (!$validated['status']) {
                return [
                    'status' => false,
                    'message' => 'AI returned an invalid ATS analysis.',
                ];
            }
        }

        $result = $validated['results'][(string) $applicant->sno] ?? null;

        // A structurally valid JSON response can still omit the requested
        // applicant. Retry once with a single-candidate prompt before failing.
        if (!$result) {
            $fallback = $this->requestSingleApplicantFallback($applicant, $source, $roles);

            if ($fallback['status']) {
                $retryValidated = $this->validator->validateBatch(
                    $fallback['data'] ?? [],
                    [(string) $applicant->sno],
                    $roles,
                    [(string) $applicant->sno => $source['text']]
                );

                $result = $retryValidated['results'][(string) $applicant->sno] ?? null;
            }
        }

        if (!$result) {
            return [
                'status' => false,
                'message' => 'AI did not return a complete analysis for this candidate.',
            ];
        }

        $analysis = $this->persistResult(
            $applicant,
            $result,
            $source,
            $roles,
            $runSno,
            $actorId,
            $roleCatalogHash
        );

        return [
            'status' => true,
            'message' => 'ATS role matching completed successfully.',
            'data' => $this->formatAnalysis($applicant, $analysis, $source),
        ];
    }

    /**
     * Process a single queue chunk. Each applicant gets an independent
     * persisted ATS result even when a batch AI call partially fails.
     */
    public function analyzeApplicantsByIds(
        array $applicantIds,
        int $runSno,
        bool $forceReprocess,
        int $actorId = 0
    ): array {
        $ids = array_values(array_unique(array_map('intval', $applicantIds)));

        if (empty($ids)) {
            return [];
        }

        $applicants = ApplicantModel::query()
            ->whereIn('sno', $ids)
            ->where('status', '!=', 2)
            ->orderBy('sno')
            ->get();

        $roles = $this->roleCatalog->getActiveRoles();
        $roleCatalogHash = $this->roleCatalog->getCatalogHash($roles);
        if (empty($roles)) {
            return collect($ids)->mapWithKeys(fn ($id) => [
                (string) $id => [
                    'status' => false,
                    'message' => 'No active ATS-enabled roles configured.',
                ],
            ])->all();
        }

        $payload = [];
        $sources = [];
        $results = [];

        foreach ($applicants as $applicant) {
            $id = (string) $applicant->sno;

            try {
                if (!$forceReprocess && $this->hasCurrentAnalysis($applicant->sno, $roleCatalogHash)) {
                    $results[$id] = [
                        'status' => true,
                        'skipped' => true,
                        'message' => 'Candidate already has a current ATS analysis.',
                    ];
                    continue;
                }

                $source = $this->resumeSource->resolve($applicant);

                $payload[] = [
                    'sno' => $id,
                    'resume' => $this->resumeSource->prepareForModel($source['text']),
                ];
                $sources[$id] = $source;
            } catch (Throwable $e) {
                $results[$id] = [
                    'status' => false,
                    'message' => $e->getMessage(),
                ];
            }
        }

        if (empty($payload)) {
            return $results;
        }

        $aiResponse = $this->requestAi($payload, $roles);
        $resumeTexts = [];
        foreach ($sources as $id => $source) {
            $resumeTexts[(string) $id] = (string) ($source['text'] ?? '');
        }

        $validated = $aiResponse['status']
            ? $this->validator->validateBatch($aiResponse['data'] ?? [], array_column($payload, 'sno'), $roles, $resumeTexts)
            : [
                'status' => false,
                'message' => $aiResponse['message'] ?? 'AI request failed.',
            ];

        // Batch validation failure should not make an otherwise healthy run stop.
        if (!$validated['status']) {
            foreach ($payload as $item) {
                $id = (string) $item['sno'];
                $applicant = $applicants->firstWhere('sno', (int) $id);

                if (!$applicant || !isset($sources[$id])) {
                    continue;
                }

                $fallback = $this->requestSingleApplicantFallback(
                    $applicant,
                    $sources[$id],
                    $roles
                );

                if (!$fallback['status']) {
                    $results[$id] = [
                        'status' => false,
                        'message' => $fallback['message'] ?? 'AI matching failed.',
                    ];
                    continue;
                }

                $single = $this->validator->validateBatch(
                    $fallback['data'] ?? [],
                    [$id],
                    $roles,
                    [$id => (string) ($sources[$id]['text'] ?? '')]
                );

                if (!$single['status'] || empty($single['results'][$id])) {
                    $results[$id] = [
                        'status' => false,
                        'message' => 'AI returned an invalid applicant analysis.',
                    ];
                    continue;
                }

                try {
                    $saved = $this->persistResult(
                        $applicant,
                        $single['results'][$id],
                        $sources[$id],
                        $roles,
                        $runSno,
                        $actorId,
                        $roleCatalogHash
                    );

                    $results[$id] = [
                        'status' => true,
                        'analysis_sno' => $saved->sno,
                        'match_count' => $saved->match_count,
                        'best_match_score' => $saved->best_role_score,
                    ];
                } catch (Throwable $e) {
                    $results[$id] = [
                        'status' => false,
                        'message' => 'Unable to persist ATS analysis.',
                    ];
                }
            }

            return $results;
        }

        foreach ($payload as $item) {
            $id = (string) $item['sno'];
            $applicant = $applicants->firstWhere('sno', (int) $id);
            $result = $validated['results'][$id] ?? null;

            if (!$applicant || !isset($sources[$id])) {
                if (!isset($results[$id])) {
                    $results[$id] = [
                        'status' => false,
                        'message' => 'Candidate data could not be resolved for ATS processing.',
                    ];
                }
                continue;
            }

            // A valid batch JSON can omit one applicant. Retry only that
            // applicant rather than marking the candidate permanently failed.
            if (!$result) {
                $fallback = $this->requestSingleApplicantFallback(
                    $applicant,
                    $sources[$id],
                    $roles
                );

                if ($fallback['status']) {
                    $single = $this->validator->validateBatch(
                        $fallback['data'] ?? [],
                        [$id],
                        $roles,
                        [$id => (string) ($sources[$id]['text'] ?? '')]
                    );
                    $result = $single['results'][$id] ?? null;
                }
            }

            if (!$result) {
                $results[$id] = [
                    'status' => false,
                    'message' => 'AI omitted this candidate from the batch response and the retry did not produce a valid analysis.',
                ];
                continue;
            }

            try {
                $saved = $this->persistResult(
                    $applicant,
                    $result,
                    $sources[$id],
                    $roles,
                    $runSno,
                    $actorId,
                    $roleCatalogHash
                );

                $results[$id] = [
                    'status' => true,
                    'analysis_sno' => $saved->sno,
                    'match_count' => $saved->match_count,
                    'best_match_score' => $saved->best_role_score,
                ];
            } catch (Throwable $e) {
                Log::error('ATS analysis persistence failed.', [
                    'applicant_sno' => $id,
                    'message' => $e->getMessage(),
                ]);

                $results[$id] = [
                    'status' => false,
                    'message' => 'Unable to persist ATS analysis.',
                ];
            }
        }

        return $results;
    }

    public function getStoredAnalysis(ApplicantModel $applicant): ?ApplicantAtsRoleAnalysisModel
    {
        return ApplicantAtsRoleAnalysisModel::query()
            ->where('applicant_sno', $applicant->sno)
            ->first();
    }

    public function formatStoredAnalysis(ApplicantModel $applicant, ApplicantAtsRoleAnalysisModel $analysis): array
    {
        $payload = is_array($analysis->analysis_json)
            ? $analysis->analysis_json
            : (json_decode((string) $analysis->analysis_json, true) ?: []);

        return $this->formatAnalysis($applicant, $analysis, [
            'source_type' => $analysis->source_type,
            'source_label' => $analysis->source_label,
            'resume_sha256' => $analysis->resume_sha256,
            'resume_chars' => $analysis->resume_chars,
        ], $payload);
    }

    private function requestAi(array $payload, array $roles): array
    {
        try {
            $prompt = $this->prompt->buildBatchPrompt($payload, $roles);
            return $this->huggingFace->askJson(
                $prompt,
                config('recruitment_ats.model') ?: null
            );
        } catch (Throwable $e) {
            Log::error('ATS AI request exception.', [
                'message' => $e->getMessage(),
            ]);

            return [
                'status' => false,
                'message' => 'Unable to contact the ATS AI model.',
            ];
        }
    }

    private function requestSingleApplicantFallback(
        ApplicantModel $applicant,
        array $source,
        array $roles
    ): array {
        return $this->requestAi([
            [
                'sno' => (string) $applicant->sno,
                'resume' => $this->resumeSource->prepareForModel($source['text']),
            ],
        ], $roles);
    }

    private function persistResult(
        ApplicantModel $applicant,
        array $result,
        array $source,
        array $roles,
        ?int $runSno,
        int $actorId,
        string $roleCatalogHash
    ): ApplicantAtsRoleAnalysisModel {
        $analysisPayload = [
            'schema_version' => config('recruitment_ats.schema_version', 'ats_role_matching.v3'),
            'engine' => config('recruitment_ats.engine', 'egc_ats_role_matching'),
            'model' => config('recruitment_ats.model') ?: 'configured Hugging Face model',
            'role_catalog_hash' => $roleCatalogHash,
            'analysis' => $result['analysis'] ?? [],
            'matches' => $result['matches'] ?? [],
            'near_matches' => $result['near_matches'] ?? [],
            'processed_at' => now()->toIso8601String(),
        ];

        $matches = $result['matches'] ?? [];
        $bestRoleScore = empty($matches)
            ? 0
            : max(array_map(fn ($match) => (float) ($match['match_score'] ?? 0), $matches));

        return DB::transaction(function () use (
            $applicant,
            $result,
            $source,
            $analysisPayload,
            $bestRoleScore,
            $runSno,
            $actorId,
            $roleCatalogHash
        ) {
            $analysis = ApplicantAtsRoleAnalysisModel::query()->firstOrNew(
                ['applicant_sno' => $applicant->sno]
            );

            $analysis->fill([
                    'run_sno' => $runSno,
                    'schema_version' => config('recruitment_ats.schema_version', 'ats_role_matching.v3'),
                    'engine' => config('recruitment_ats.engine', 'egc_ats_role_matching'),
                    'model' => config('recruitment_ats.model') ?: null,
                    'source_type' => $source['source_type'],
                    'source_label' => $source['source_label'],
                    'role_catalog_hash' => $roleCatalogHash,
                    'resume_sha256' => $source['resume_sha256'],
                    'resume_chars' => $source['resume_chars'],
                    'overall_match_score' => $bestRoleScore,
                    'best_role_score' => $bestRoleScore,
                    'resume_quality_score' => (float) data_get($result, 'analysis.resume_quality_score', 0),
                    'match_count' => count($result['matches'] ?? []),
                    'analysis_json' => $analysisPayload,
                    'processed_at' => now(),
                    'updated_by' => $actorId,
                ]
            );

            if (!$analysis->exists) {
                $analysis->created_by = $actorId;
            }

            $analysis->save();

            ApplicantAtsRoleMatchModel::query()
                ->where('analysis_sno', $analysis->sno)
                ->delete();

            $rows = [];
            foreach (($result['matches'] ?? []) as $match) {
                $rows[] = [
                    'analysis_sno' => $analysis->sno,
                    'applicant_sno' => $applicant->sno,
                    'role_sno' => (int) $match['role_id'],
                    'role_code' => $match['role_code'] ?? null,
                    'role_name' => $match['role_name'] ?? 'Role',
                    'role_family' => $match['role_family'] ?? null,
                    'seniority_level' => $match['seniority_level'] ?? null,
                    'match_score' => $match['match_score'] ?? 0,
                    'decision' => $match['decision'] ?? 'match',
                    'title_alignment_score' => $match['title_alignment_score'] ?? 0,
                    'skill_alignment_score' => $match['skill_alignment_score'] ?? 0,
                    'experience_alignment_score' => $match['experience_alignment_score'] ?? 0,
                    'responsibility_alignment_score' => $match['responsibility_alignment_score'] ?? 0,
                    'seniority_alignment_score' => $match['seniority_alignment_score'] ?? 0,
                    'evidence_quality_score' => $match['evidence_quality_score'] ?? 0,
                    'reason' => $match['reason'] ?? null,
                    'evidence_json' => json_encode($match['evidence'] ?? [], JSON_UNESCAPED_UNICODE),
                    'gaps_json' => json_encode($match['gaps'] ?? [], JSON_UNESCAPED_UNICODE),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }

            if (!empty($rows)) {
                ApplicantAtsRoleMatchModel::query()->insert($rows);
            }

            return $analysis->fresh();
        });
    }

    private function formatAnalysis(
        ApplicantModel $applicant,
        ApplicantAtsRoleAnalysisModel $analysis,
        array $source,
        ?array $payloadOverride = null
    ): array {
        $payload = $payloadOverride
            ?? (is_array($analysis->analysis_json)
                ? $analysis->analysis_json
                : (json_decode((string) $analysis->analysis_json, true) ?: []));

        $matches = ApplicantAtsRoleMatchModel::query()
            ->where('analysis_sno', $analysis->sno)
            ->orderByDesc('match_score')
            ->get()
            ->map(function (ApplicantAtsRoleMatchModel $match) {
                return [
                    'role_id' => (int) $match->role_sno,
                    'role_code' => $match->role_code,
                    'role_name' => $match->role_name,
                    'role_family' => $match->role_family,
                    'seniority_level' => $match->seniority_level,
                    'match_score' => (float) $match->match_score,
                    'decision' => $match->decision,
                    'title_alignment_score' => (float) $match->title_alignment_score,
                    'skill_alignment_score' => (float) $match->skill_alignment_score,
                    'experience_alignment_score' => (float) $match->experience_alignment_score,
                    'responsibility_alignment_score' => (float) $match->responsibility_alignment_score,
                    'seniority_alignment_score' => (float) $match->seniority_alignment_score,
                    'evidence_quality_score' => (float) $match->evidence_quality_score,
                    'reason' => $match->reason,
                    'evidence' => is_array($match->evidence_json) ? $match->evidence_json : [],
                    'gaps' => is_array($match->gaps_json) ? $match->gaps_json : [],
                ];
            })
            ->values()
            ->all();

        $payload['matches'] = $matches;

        return [
            'analysis_sno' => (int) $analysis->sno,
            'applicant' => [
                'sno' => (int) $applicant->sno,
                'applicant_id' => $applicant->applicant_id,
                'name' => $applicant->applicant_name,
                'email' => $applicant->email,
                'mobile' => $applicant->mobile,
            ],
            'source' => [
                'type' => $source['source_type'] ?? $analysis->source_type,
                'label' => $source['source_label'] ?? $analysis->source_label,
                'resume_chars' => (int) ($source['resume_chars'] ?? $analysis->resume_chars),
                'resume_sha256' => $source['resume_sha256'] ?? $analysis->resume_sha256,
                'role_catalog_hash' => $analysis->role_catalog_hash,
            ],
            'overall_match_score' => (float) $analysis->overall_match_score,
            'best_role_score' => (float) $analysis->best_role_score,
            'resume_quality_score' => (float) $analysis->resume_quality_score,
            'match_count' => (int) $analysis->match_count,
            'matches' => $matches,
            'near_matches' => $payload['near_matches'] ?? [],
            'analysis' => $payload['analysis'] ?? [],
            'meta' => [
                'schema_version' => $analysis->schema_version,
                'engine' => $analysis->engine,
                'model' => $analysis->model,
                'processed_at' => optional($analysis->processed_at)->toIso8601String(),
                'updated_at' => optional($analysis->updated_at)->toIso8601String(),
            ],
        ];
    }

    private function persistResumeOverride(ApplicantModel $applicant, string $resume): void
    {
        $applicant->resume_text = $resume;
        $applicant->updated_at = now();
        $applicant->save();
    }

    private function hasCurrentAnalysis(int $applicantSno, string $roleCatalogHash): bool
    {
        return ApplicantAtsRoleAnalysisModel::query()
            ->where('applicant_sno', $applicantSno)
            ->where('role_catalog_hash', $roleCatalogHash)
            ->exists();
    }
}
