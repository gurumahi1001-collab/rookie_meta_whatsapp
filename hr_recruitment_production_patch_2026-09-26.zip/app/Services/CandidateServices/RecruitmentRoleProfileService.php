<?php

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\DB;

class RecruitmentRoleProfileService
{
    public function getActiveProfiles(): array
    {
        return $this->loadProfiles();
    }

    public function getProfile(int $roleId): ?array
    {
        $row = DB::table('egc_recruitment_roles')
            ->where('sno', $roleId)
            ->where('status', 0)
            ->where('match_enabled', 1)
            ->first();
        return $row ? $this->normalize($row) : null;
    }

    protected function loadProfiles(): array
    {
        return DB::table('egc_recruitment_roles')
            ->where('status', 0)
            ->where('match_enabled', 1)
            ->orderBy('sno')
            ->get()
            ->map(fn ($role) => $this->normalize($role))
            ->values()
            ->toArray();
    }

    protected function normalize(object $role): array
    {
        $hasNew = property_exists($role, 'role_name') || property_exists($role, 'description');
        $name = $hasNew ? ($role->role_name ?? '') : ($role->jobrole_name ?? '');
        $description = $hasNew ? ($role->description ?? '') : ($role->role_description ?? '');
        $aliases = $this->decodeArray($role->aliases ?? null);
        $mandatory = $this->decodeArray($role->mandatory_skills ?? null);
        $preferred = $this->decodeArray($role->preferred_skills ?? null);
        $responsibilities = $this->decodeArray($role->responsibilities ?? null);
        $education = $this->decodeArray($role->education_requirements ?? null);
        $minExp = $role->minimum_experience ?? null;
        $seniority = $role->seniority ?? ($role->seniority_label ?? ($role->seniority_level ?? ''));

        if ($hasNew && empty($preferred)) $preferred = $aliases;
        return [
            'role_id' => (int) $role->sno,
            'role_code' => trim((string) ($role->role_code ?? '')),
            'role_name' => trim((string) $name),
            'role_description' => $this->cleanText($description),
            'mandatory_skills' => $mandatory,
            'preferred_skills' => $preferred,
            'responsibilities' => $responsibilities,
            'minimum_experience' => $minExp !== null ? $this->cleanText($minExp) : '',
            'education_requirements' => $education,
            'seniority' => $this->cleanText($seniority),
            'aliases' => $aliases,
            'profile_version' => 2,
        ];
    }

    protected function decodeArray(mixed $value): array
    {
        if (is_array($value)) return array_values(array_filter(array_map(fn ($v) => trim((string) $v), $value)));
        if ($value === null || trim((string) $value) === '') return [];
        $decoded = json_decode((string) $value, true);
        if (is_array($decoded)) return array_values(array_filter(array_map(fn ($v) => trim((string) $v), $decoded)));
        return array_values(array_filter(array_map('trim', preg_split('/[,;\n]+/', (string) $value))));
    }

    protected function cleanText(mixed $value): string
    {
        $value = strip_tags((string) ($value ?? ''));
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value) ?? '';
        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }

    public function clearCache(): void
    {
        // No persistent role cache: Manage Roles changes take effect immediately.
    }
}
