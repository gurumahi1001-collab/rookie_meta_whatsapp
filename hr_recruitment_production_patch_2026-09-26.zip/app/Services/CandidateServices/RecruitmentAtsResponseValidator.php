<?php

namespace App\Services\CandidateServices;

class RecruitmentAtsResponseValidator
{
    public function __construct(
        protected RecruitmentAtsEvidenceMatcher $evidenceMatcher
    ) {
    }
    public function validateBatch(
        array $response,
        array $requestedApplicantIds,
        array $roles,
        array $resumeTexts = []
    ): array {
        $results = $response['results'] ?? null;

        if (!is_array($results)) {
            return [
                'status' => false,
                'message' => 'AI response does not contain a valid results array.',
            ];
        }

        $allowedApplicants = array_fill_keys(
            array_map('strval', $requestedApplicantIds),
            true
        );

        $roleIndex = [];
        foreach ($roles as $role) {
            $roleIndex[(string) $role['sno']] = $role;
        }

        $validated = [];
        foreach ($results as $item) {
            if (!is_array($item)) {
                continue;
            }

            $applicantId = (string) ($item['applicant_id'] ?? '');
            if ($applicantId === '' || !isset($allowedApplicants[$applicantId])) {
                continue;
            }

            $analysis = $this->normalizeAnalysis($item['analysis'] ?? $item['ai_response'] ?? []);
            $matches = $this->normalizeMatches(
                $item['matches'] ?? [],
                $roleIndex,
                true,
                (string) ($resumeTexts[$applicantId] ?? '')
            );

            $nearMatches = $this->normalizeMatches(
                $item['near_matches'] ?? [],
                $roleIndex,
                false,
                (string) ($resumeTexts[$applicantId] ?? '')
            );

            // The backend owns the final role score semantics.
            $bestScore = !empty($matches)
                ? max(array_map(fn ($m) => (float) $m['match_score'], $matches))
                : 0.0;

            $analysis['overall_match_score'] = $this->score($bestScore);

            $validated[$applicantId] = [
                'applicant_id' => $applicantId,
                'analysis' => $analysis,
                'matches' => $matches,
                'near_matches' => $nearMatches,
            ];
        }

        return [
            'status' => true,
            'results' => $validated,
        ];
    }

    private function normalizeAnalysis(mixed $analysis): array
    {
        $analysis = is_array($analysis) ? $analysis : [];

        return [
            'overall_match_score' => $this->score($analysis['overall_match_score'] ?? 0),
            'resume_quality_score' => $this->score($analysis['resume_quality_score'] ?? 0),
            'ats_keyword_match_score' => $this->score($analysis['ats_keyword_match_score'] ?? 0),
            'skills_alignment_score' => $this->score($analysis['skills_alignment_score'] ?? 0),
            'experience_relevance_score' => $this->score($analysis['experience_relevance_score'] ?? 0),
            'impact_metrics_score' => $this->score($analysis['impact_metrics_score'] ?? 0),
            'role_responsibility_match_score' => $this->score($analysis['role_responsibility_match_score'] ?? 0),
            'candidate_summary' => $this->string($analysis['candidate_summary'] ?? ''),
            'professional_domains' => $this->stringArray($analysis['professional_domains'] ?? []),
            'current_designation' => $this->string($analysis['current_designation'] ?? ''),
            'previous_designations' => $this->stringArray($analysis['previous_designations'] ?? []),
            'experience_summary' => $this->string($analysis['experience_summary'] ?? ''),
            'seniority_assessment' => $this->string($analysis['seniority_assessment'] ?? ''),
            'education_summary' => $this->string($analysis['education_summary'] ?? ''),
            'strengths' => $this->stringArray($analysis['strengths'] ?? []),
            'weaknesses' => $this->stringArray($analysis['weaknesses'] ?? []),
            'missing_keywords' => $this->stringArray($analysis['missing_keywords'] ?? []),
            'resume_improvements' => $this->stringArray($analysis['resume_improvements'] ?? []),
            'optimized_summary' => mb_substr($this->string($analysis['optimized_summary'] ?? ''), 0, 5000),
            'data_quality_notes' => $this->stringArray($analysis['data_quality_notes'] ?? []),
        ];
    }

    private function normalizeMatches(mixed $matches, array $roleIndex, bool $accepted, string $resumeText = ''): array
    {
        if (!is_array($matches)) {
            return [];
        }

        $out = [];
        $minimumAccepted = (float) config('recruitment_ats.minimum_match_score', 70);
        $minimumNear = (float) config('recruitment_ats.near_match_min_score', 45);

        foreach ($matches as $match) {
            if (!is_array($match)) {
                continue;
            }

            $roleId = (string) ($match['role_id'] ?? $match['role_sno'] ?? $match['sno'] ?? '');
            if ($roleId === '' || !isset($roleIndex[$roleId])) {
                continue;
            }

            $title = $this->score($match['title_alignment_score'] ?? 0);
            $skills = $this->score($match['skill_alignment_score'] ?? $match['skills_alignment_score'] ?? 0);
            $experience = $this->score($match['experience_alignment_score'] ?? 0);
            $responsibility = $this->score($match['responsibility_alignment_score'] ?? 0);
            $seniority = $this->score($match['seniority_alignment_score'] ?? 0);
            $evidence = $this->score($match['evidence_quality_score'] ?? 0);

            $hasComponents = isset($match['title_alignment_score'], $match['skill_alignment_score'])
                || isset($match['skills_alignment_score']);

            $modelScore = $this->score(
                $match['match_score']
                    ?? $match['confidence']
                    ?? 0
            );

            $calculated = $hasComponents
                ? $this->calculateWeightedScore($title, $skills, $experience, $responsibility, $seniority, $evidence)
                : $modelScore;

            $role = $roleIndex[$roleId];
            if ($resumeText !== '') {
                $calibrated = $this->evidenceMatcher->calibrate(
                    [
                        'title_alignment_score' => $title,
                        'skill_alignment_score' => $skills,
                        'experience_alignment_score' => $experience,
                        'responsibility_alignment_score' => $responsibility,
                        'seniority_alignment_score' => $seniority,
                        'evidence_quality_score' => $evidence,
                        'evidence' => $match['evidence'] ?? [],
                        'gaps' => $match['gaps'] ?? [],
                        'reason' => $match['reason'] ?? '',
                    ],
                    $role,
                    $resumeText
                );
                $title = $calibrated['title_alignment_score'];
                $skills = $calibrated['skill_alignment_score'];
                $experience = $calibrated['experience_alignment_score'];
                $responsibility = $calibrated['responsibility_alignment_score'];
                $seniority = $calibrated['seniority_alignment_score'];
                $evidence = $calibrated['evidence_quality_score'];
                $calculated = $calibrated['match_score'];
                $matchEvidence = $calibrated['evidence'];
            } else {
                $matchEvidence = $this->stringArray($match['evidence'] ?? []);
            }

            $score = $this->score($calculated);

            if ($accepted && $score < $minimumAccepted) {
                continue;
            }

            if (!$accepted && ($score < $minimumNear || $score >= $minimumAccepted)) {
                continue;
            }

            $out[] = [
                'role_id' => (int) $role['sno'],
                'role_code' => $role['role_code'],
                'role_name' => $role['role_name'],
                'role_family' => $role['role_family'],
                'seniority_level' => (int) $role['seniority_level'],
                'match_score' => $score,
                'decision' => $accepted
                    ? ($score >= 85 ? 'strong_match' : 'match')
                    : 'near_match',
                'title_alignment_score' => $title,
                'skill_alignment_score' => $skills,
                'experience_alignment_score' => $experience,
                'responsibility_alignment_score' => $responsibility,
                'seniority_alignment_score' => $seniority,
                'evidence_quality_score' => $evidence,
                'reason' => mb_substr($this->string($match['reason'] ?? ''), 0, 1500),
                'evidence' => $matchEvidence,
                'gaps' => $this->stringArray($match['gaps'] ?? []),
            ];
        }

        $out = collect($out)
            ->unique('role_id')
            ->sortByDesc('match_score')
            ->values()
            ->all();

        $maxNear = (int) config('recruitment_ats.near_match_max_items', 8);
        return $accepted ? $out : array_slice($out, 0, max(1, $maxNear));
    }

    private function calculateWeightedScore(
        float $title,
        float $skills,
        float $experience,
        float $responsibility,
        float $seniority,
        float $evidence
    ): float {
        return round(
            ($title * 0.20)
            + ($skills * 0.25)
            + ($experience * 0.20)
            + ($responsibility * 0.20)
            + ($seniority * 0.10)
            + ($evidence * 0.05),
            2
        );
    }

    private function score(mixed $value): float
    {
        return max(0, min(100, round((float) $value, 2)));
    }

    private function string(mixed $value): string
    {
        return trim(mb_substr((string) ($value ?? ''), 0, 5000));
    }

    private function stringArray(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        return collect($value)
            ->map(fn ($item) => trim((string) $item))
            ->filter()
            ->map(fn ($item) => mb_substr($item, 0, 1000))
            ->unique()
            ->values()
            ->all();
    }
}
