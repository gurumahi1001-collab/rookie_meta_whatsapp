<?php

namespace App\Services\CandidateServices;

/**
 * Deterministic ATS calibration layer.
 *
 * The LLM supplies semantic component scores, but the backend never accepts a
 * model-only score as proof of a role match. Scores are recalibrated against
 * the actual resume text and the current role catalogue.
 */
class RecruitmentAtsEvidenceMatcher
{
    public function calibrate(array $match, array $role, string $resume): array
    {
        $resume = $this->normalize($resume);
        $roleText = $this->roleText($role);

        $title = $this->scoreCandidateTitle($resume, $this->roleValues($role, ['role_name', 'role_family', 'aliases']));
        $skills = $this->keywordCoverage($resume, $this->roleValues($role, ['role_name', 'role_family', 'aliases', 'description']), 0.35);
        $responsibility = $this->keywordCoverage($resume, [$role['description'] ?? '', $role['role_family'] ?? '', $role['role_name'] ?? ''], 0.40);
        $experience = $this->experienceScore($resume, (int)($role['seniority_level'] ?? 1));
        $seniority = $this->seniorityScore($resume, (int)($role['seniority_level'] ?? 1));
        $evidence = $this->evidenceScore($match, $resume, $roleText);

        $aiTitle = $this->score($match['title_alignment_score'] ?? 0);
        $aiSkills = $this->score($match['skill_alignment_score'] ?? $match['skills_alignment_score'] ?? 0);
        $aiExperience = $this->score($match['experience_alignment_score'] ?? 0);
        $aiResponsibility = $this->score($match['responsibility_alignment_score'] ?? 0);
        $aiSeniority = $this->score($match['seniority_alignment_score'] ?? 0);
        $aiEvidence = $this->score($match['evidence_quality_score'] ?? 0);

        $components = [
            'title_alignment_score' => $this->blend($aiTitle, $title),
            'skill_alignment_score' => $this->blend($aiSkills, $skills),
            'experience_alignment_score' => $this->blend($aiExperience, $experience),
            'responsibility_alignment_score' => $this->blend($aiResponsibility, $responsibility),
            'seniority_alignment_score' => $this->blend($aiSeniority, $seniority),
            'evidence_quality_score' => $this->blend($aiEvidence, $evidence),
        ];

        $final = round(
            ($components['title_alignment_score'] * 0.20)
            + ($components['skill_alignment_score'] * 0.25)
            + ($components['experience_alignment_score'] * 0.20)
            + ($components['responsibility_alignment_score'] * 0.20)
            + ($components['seniority_alignment_score'] * 0.10)
            + ($components['evidence_quality_score'] * 0.05),
            2
        );

        $verifiedEvidence = $this->verifiedEvidence($match['evidence'] ?? [], $resume);
        if (count($verifiedEvidence) === 0) {
            $verifiedEvidence = $this->fallbackEvidence($resume, $role);
        }
        $hasSubstantiveSignal = max($components['title_alignment_score'], $components['skill_alignment_score'], $components['responsibility_alignment_score']) >= 45;

        // A high score requires both substantive resume-role signal and traceable
        // evidence. This prevents a hallucinated LLM score from becoming an ATS match.
        if (count($verifiedEvidence) === 0 || !$hasSubstantiveSignal) {
            $final = min($final, (float) config('recruitment_ats.verified_evidence_cap', 69));
        }

        $decision = $final >= (float) config('recruitment_ats.minimum_match_score', 70)
            ? ($final >= 85 ? 'strong_match' : 'match')
            : 'near_match';

        $match['match_score'] = $this->score($final);
        $match['decision'] = $decision;
        foreach ($components as $key => $value) $match[$key] = $this->score($value);
        $match['evidence'] = $verifiedEvidence ?: $this->fallbackEvidence($resume, $role);

        return $match;
    }

    private function roleValues(array $role, array $fields): array
    {
        $out = [];
        foreach ($fields as $field) {
            $value = $role[$field] ?? null;
            if (is_array($value)) $out = array_merge($out, $value);
            elseif ($value !== null && trim((string)$value) !== '') $out[] = (string)$value;
        }
        return array_values(array_filter($out, fn($v) => trim((string)$v) !== ''));
    }

    private function roleText(array $role): string
    {
        return $this->normalize(implode(' ', $this->roleValues($role, [
            'role_name', 'role_family', 'description', 'aliases'
        ])));
    }

    private function scoreCandidateTitle(string $resume, array $roleValues): float
    {
        $roleTokens = [];
        foreach ($roleValues as $value) {
            $roleTokens = array_merge($roleTokens, $this->tokens((string)$value, true));
        }
        $roleTokens = array_values(array_unique($roleTokens));
        if (!$roleTokens) return 0;

        $header = implode(' ', array_slice(preg_split('/\R+/', $resume) ?: [], 0, 30));
        $headerTokens = $this->tokens($header, true);
        $common = count(array_intersect($roleTokens, $headerTokens));
        $coverage = $common / max(1, count($roleTokens));

        $resumeTokens = $this->tokens($resume, true);
        $global = count(array_intersect($roleTokens, $resumeTokens)) / max(1, count($roleTokens));
        return $this->score(max($coverage * 100, $global * 65));
    }

    private function keywordCoverage(string $resume, array $phrases, float $minimumRatio): float
    {
        $resumeTokens = array_flip($this->tokens($resume, true));
        $groups = [];
        foreach ($phrases as $phrase) {
            $tokens = $this->tokens((string)$phrase, true);
            if (count($tokens) >= 2) $groups[] = $tokens;
        }
        if (!$groups) return 0;

        $best = 0.0;
        foreach ($groups as $tokens) {
            $hits = 0;
            foreach (array_unique($tokens) as $token) {
                if (isset($resumeTokens[$token])) $hits++;
            }
            $coverage = $hits / max(1, count(array_unique($tokens)));
            if ($coverage >= $minimumRatio) $best = max($best, $coverage * 100);
        }
        return $this->score($best);
    }

    private function experienceScore(string $resume, int $seniority): float
    {
        $years = $this->resumeYears($resume);
        $minimum = match (true) {
            $seniority <= 1 => 0,
            $seniority === 2 => 2,
            $seniority === 3 => 4,
            $seniority === 4 => 6,
            default => 8,
        };
        if ($years <= 0 && $minimum > 0) return 10;
        if ($minimum <= 0) return 85;
        if ($years >= $minimum) return 100;
        return $this->score(($years / $minimum) * 100);
    }

    private function seniorityScore(string $resume, int $seniority): float
    {
        $years = $this->resumeYears($resume);
        $leadership = preg_match('/\b(managed|manage|leading|lead|supervised|supervisor|mentor|mentored|team lead|manager|head of|director)\b/i', $resume) === 1;
        return match (true) {
            $seniority <= 1 => $years <= 3 && !$leadership ? 95 : ($years <= 5 ? 75 : 55),
            $seniority === 2 => $years >= 2 ? 95 : 45,
            $seniority === 3 => ($years >= 4 && $leadership) ? 95 : ($years >= 4 ? 75 : 40),
            $seniority === 4 => ($years >= 6 && $leadership) ? 95 : ($years >= 6 ? 70 : 35),
            default => ($years >= 8 && $leadership) ? 95 : ($years >= 8 ? 65 : 25),
        };
    }

    private function resumeYears(string $resume): float
    {
        if (preg_match('/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i', $resume, $m)) {
            return min(60, (float)$m[1]);
        }
        if (preg_match('/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant)\s+experience\b/i', $resume, $m)) {
            return min(60, (float)$m[1]);
        }

        $ranges = [];
        $months = ['jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,'aug'=>8,'august'=>8,'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,'october'=>10,'nov'=>11,'november'=>11,'dec'=>12,'december'=>12];
        $mw = implode('|', array_keys($months));
        foreach (preg_split('/\R+/', $resume) ?: [] as $line) {
            if (preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic project|coursework|training)\b/i', $line)) continue;
            if (!preg_match('/((?:'.$mw.')\s+\d{4})\s*(?:-|–|—|to)\s*(Present|Current|(?:'.$mw.')\s+\d{4})/i', $line, $m)) continue;
            if (!preg_match('/^([A-Za-z]+)\s+(\d{4})$/', $m[1], $st)) continue;
            $start=$st[2]*12+($months[strtolower($st[1])]??1);
            if (in_array(strtolower($m[2]), ['present','current'], true)) $end=date('Y')*12+date('n');
            elseif (preg_match('/^([A-Za-z]+)\s+(\d{4})$/', $m[2], $en)) $end=$en[2]*12+($months[strtolower($en[1])]??1);
            else continue;
            if ($end >= $start) $ranges[] = [$start,$end];
        }
        if (!$ranges) return 0;
        $monthsCovered=[];
        foreach ($ranges as [$s,$e]) for ($i=$s; $i<$e; $i++) $monthsCovered[$i]=true;
        return min(60, round(count($monthsCovered)/12,1));
    }

    private function evidenceScore(array $match, string $resume, string $roleText): float
    {
        $verified = $this->verifiedEvidence($match['evidence'] ?? [], $resume);
        if (!$verified) return 0;
        $roleTokens = array_flip($this->tokens($roleText, true));
        $relevant = 0;
        foreach ($verified as $line) {
            $tokens = $this->tokens($line, true);
            foreach (array_unique($tokens) as $token) if (isset($roleTokens[$token])) $relevant++;
        }
        return $this->score(min(100, 45 + min(55, count($verified)*15 + $relevant*4)));
    }

    private function verifiedEvidence(array $evidence, string $resume): array
    {
        if (!is_array($evidence)) return [];
        $normalizedResume = $this->normalize($resume);
        $out=[];
        foreach ($evidence as $item) {
            $item=trim((string)$item);
            if ($item==='' || mb_strlen($item)<8) continue;
            $normalizedItem=$this->normalize($item);
            if (str_contains($normalizedResume,$normalizedItem)) {
                $out[] = mb_substr($item,0,1000);
                continue;
            }
            $tokens=$this->tokens($item,true);
            $resumeTokens=array_flip($this->tokens($resume,true));
            $hits=0;
            foreach(array_unique($tokens) as $t) if(isset($resumeTokens[$t])) $hits++;
            if (count(array_unique($tokens)) >= 4 && ($hits/max(1,count(array_unique($tokens)))) >= 0.72) {
                $out[] = mb_substr($item,0,1000);
            }
        }
        return array_values(array_unique($out));
    }

    private function fallbackEvidence(string $resume, array $role): array
    {
        $needles=$this->tokens(($role['role_name']??'').' '.($role['role_family']??''),true);
        $out=[];
        foreach(preg_split('/\R+/', $resume) ?: [] as $line){
            $line=trim($line);
            if($line==='') continue;
            $tokens=$this->tokens($line,true);
            $hits=count(array_intersect($needles,$tokens));
            if($hits>0) $out[]=mb_substr($line,0,1000);
            if(count($out)>=3) break;
        }
        return $out;
    }

    private function tokens(string $text, bool $removeStop=false): array
    {
        $text=strtolower($this->normalize($text));
        $map=['javascript'=>'js','typescript'=>'ts','nodejs'=>'node','node.js'=>'node','react.js'=>'react','php'=>'php','laravel'=>'laravel','postgresql'=>'postgres','mysql'=>'mysql','microsoft excel'=>'excel'];
        $text=str_replace(array_keys($map),array_values($map),$text);
        preg_match_all('/[a-z0-9]+/',$text,$m);
        $tokens=$m[0]??[];
        if($removeStop){
            $stop=['and','the','for','with','from','into','this','that','role','roles','job','position','candidate','years','year','of','in','to','a','an','on','at','as','or','is','be','by','our','your','company','using','work','working','experience'];
            $tokens=array_values(array_filter($tokens,fn($t)=>!in_array($t,$stop,true) && strlen($t)>=2));
        }
        return array_values(array_unique($tokens));
    }

    private function normalize(string $text): string
    {
        $text=strip_tags($text);
        $text=preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',' ',$text)??'';
        $text=mb_strtolower($text);
        return trim(preg_replace('/\s+/u',' ',$text)??$text);
    }

    private function blend(float $ai,float $det): float
    {
        return $this->score(($ai*0.55)+($det*0.45));
    }

    private function score(mixed $value): float
    {
        return max(0,min(100,round((float)$value,2)));
    }
}
