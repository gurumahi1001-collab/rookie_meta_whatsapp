<?php

namespace App\Services\CandidateServices;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use PhpOffice\PhpWord\IOFactory;
use Smalot\PdfParser\Parser as PdfParser;
use thiagoalessio\TesseractOCR\TesseractOCR;

class ResumeExtractionService
{
    private ?string $lastAIError = null;
    private const MAX_FILE_KB = 10240;
    private const MAX_AI_CHARS = 90000;
    private const MAX_RESUME_CACHE_MINUTES = 15;

    public function extract(UploadedFile $file, bool $includeText = false): array
    {
        $extension = strtolower($file->getClientOriginalExtension());
        $path = $file->getRealPath();
        $this->lastAIError = null;
        $started = microtime(true);

        $text = $this->extractText($path, $extension);
        $text = $this->normalizeText($text);
        $ocrUsed = in_array($extension, ['jpg', 'jpeg', 'png', 'webp', 'tif', 'tiff'], true)
            || ($extension === 'pdf' && mb_strlen(trim($text)) < 100);

        if (mb_strlen($text) < 20) {
            throw new \RuntimeException('The resume contains no readable text. Upload a clearer document or image.');
        }

        // Fast deterministic pass first. This handles contact information,
        // education and date ranges without spending an LLM request.
        $local = $this->localExtract($text);

        // Escalate to Hugging Face only when semantic fields are missing.
        $needsAI = !$local['candidate_name']
            || !$local['candidate_major_text']
            || $local['candidate_exper_count'] <= 0;

        $ai = [];
        $aiAttempted = false;
        $alwaysAI = filter_var(env('HF_RESUME_ALWAYS_AI', true), FILTER_VALIDATE_BOOLEAN);
        $token = $this->getHuggingFaceToken();
        if (($needsAI || $alwaysAI) && $token) {
            $aiAttempted = true;
            $ai = $this->extractWithAI($text, $token);
        }

        $data = $this->merge($local, $ai, $text);
        $education = $this->matchEducation($text, $data);

        $data['candidate_qualification'] = $education['qualification_sno'];
        $data['candidate_major'] = $education['major_sno'];
        $data['candidate_other_major'] = $education['major_sno'] ? null : ($data['candidate_major_text'] ?: null);
        $data['degree_full'] = $education['degree_full'] ?: ($data['degree_full'] ?? null);

        $data['candidate_exper_type'] = ((float)$data['candidate_exper_count'] > 0) ? 2 : 1;

        $data['confidence'] = $this->confidence($data, $education, $text, $ai);
        $data['extraction_meta'] = [
            'extension' => $extension,
            'text_length' => mb_strlen($text),
            'ai_configured' => !empty($token),
            'ai_attempted' => $aiAttempted,
            'ai_used' => !empty($ai),
            'ai_error' => $this->lastAIError,
            'ocr_used' => $ocrUsed,
            'engine' => !empty($ai)
                ? 'native-extraction+rules+HuggingFace'
                : 'native-extraction+rules',
            'processing_ms' => (int) round((microtime(true) - $started) * 1000),
            'model' => $aiAttempted ? env('HF_RESUME_MODEL', 'Qwen/Qwen3-32B') : null,
            'field_source' => [
                'name' => !empty($data['candidate_name']) ? ($local['candidate_name'] ? 'source_rules' : 'ai_review') : 'missing',
                'email' => !empty($data['candidate_email']) ? 'source_rules' : 'missing',
                'mobile' => !empty($data['candidate_mobile']) ? 'source_rules' : 'missing',
                'gender' => !empty($data['candidate_gender']) ? 'explicit_source' : 'not_explicit',
                'marital_status' => !empty($data['candidate_marital_status']) ? 'explicit_source' : 'not_explicit',
                'qualification' => !empty($data['candidate_qualification']) ? 'master_match' : (!empty($data['degree_full']) ? 'ai_or_source_text' : 'missing'),
                'major' => !empty($data['candidate_major']) ? 'master_match' : (!empty($data['candidate_major_text']) ? 'ai_or_source_text' : 'missing'),
                'experience' => ((float)($data['candidate_exper_count'] ?? 0) > 0) ? 'source_dates_or_explicit_total' : 'not_confirmed',
            ],
            'manual_review' => $this->manualReviewFields($data, $education),
        ];

        if ($includeText) {
            $data['resume_text'] = $text;
        }

        return $data;
    }

    private function manualReviewFields(array $data, array $education): array
    {
        $review = [];
        foreach ([
            'candidate_name' => 'Name',
            'candidate_email' => 'Email',
            'candidate_mobile' => 'Mobile',
        ] as $field => $label) {
            if (empty($data[$field])) {
                $review[] = $label;
            }
        }
        if (empty($data['candidate_qualification']) && empty($data['degree_full'])) {
            $review[] = 'Qualification';
        }
        if (empty($data['candidate_major']) && empty($data['candidate_major_text']) && empty($data['candidate_other_major'])) {
            $review[] = 'Major';
        }
        if ((float)($data['candidate_exper_count'] ?? 0) <= 0 && empty($data['experience_evidence'])) {
            $review[] = 'Experience';
        }
        return array_values(array_unique($review));
    }

    private function localExtract(string $text): array
    {
        $email = $this->extractEmail($text);
        $phone = $this->extractPhone($text);
        $name = $this->extractName($text, $email, $phone);
        $education = $this->extractEducation($text);
        $experience = $this->extractExperienceYears($text);

        return [
            'candidate_name' => $name,
            'candidate_email' => $email,
            'candidate_mobile' => $phone,
            'candidate_gender' => $this->extractExplicitGender($text),
            'candidate_marital_status' => $this->extractExplicitMarital($text),
            'candidate_exper_count' => $experience,
            'candidate_major_text' => $education['major_text'],
            'degree_full' => $education['degree_full'],
        ];
    }

    private function merge(array $local, array $ai, string $text): array
    {
        $result = $local;

        // LLM values are advisory only. A value is allowed into the persisted
        // candidate record only when the same fact can be traced back to the
        // extracted resume text. This prevents plausible-but-false AI values.
        $supportedAiFields = [
            'candidate_name' => 'name',
            'candidate_major_text' => 'major',
            'degree_full' => 'degree',
        ];

        foreach ($supportedAiFields as $field => $evidenceType) {
            if (($result[$field] ?? null) === null || ($result[$field] ?? '') === '') {
                $value = trim((string) ($ai[$field] ?? ''));
                if ($value !== '' && $this->aiValueSupportedByResume($value, $text, $evidenceType)) {
                    $result[$field] = $value;
                }
            }
        }

        // Contact details are parsed deterministically below. Do not use an
        // LLM-generated phone/email when the source cannot corroborate it.
        $sourceEmail = $this->extractEmail($text);
        $sourcePhone = $this->extractPhone($text);
        $result['candidate_email'] = $sourceEmail ?: null;
        $result['candidate_mobile'] = $sourcePhone ?: null;

        // Gender and marital status are accepted only when an explicit source
        // label was detected by deterministic extraction. Never infer them.
        $result['candidate_gender'] = $local['candidate_gender'] ?? null;
        $result['candidate_marital_status'] = $local['candidate_marital_status'] ?? null;

        // Prefer deterministic employment-date evidence. If it is absent, allow
        // the AI total only when the AI's own employment entries are traceable
        // to the resume and produce a defensible non-overlapping duration.
        if ((float) ($result['candidate_exper_count'] ?? 0) <= 0) {
            $aiExperience = $this->validatedAiExperienceYears($ai['experience_evidence'] ?? [], $text);
            if ($aiExperience > 0) {
                $result['candidate_exper_count'] = $aiExperience;
            } elseif ((float) ($ai['candidate_exper_count'] ?? 0) > 0 && $this->explicitTotalExperienceSupports($ai['candidate_exper_count'], $text)) {
                $result['candidate_exper_count'] = (float) $ai['candidate_exper_count'];
            }
        }

        $result['candidate_name'] = $this->cleanName($result['candidate_name'] ?? null);
        $result['candidate_mobile'] = $this->cleanPhone($result['candidate_mobile'] ?? null);
        $result['candidate_exper_count'] = round((float) ($result['candidate_exper_count'] ?? 0), 1);

        return $result;
    }

    private function aiValueSupportedByResume(string $value, string $text, string $type): bool
    {
        $value = trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
        if ($value === '' || $text === '') return false;

        $normalizedValue = $this->canonical($value);
        $normalizedText = $this->canonical($text);
        if ($normalizedValue === '') return false;

        // Exact substring is strongest, including flattened PDF/DOCX text.
        if (str_contains($normalizedText, $normalizedValue)) return true;

        $candidateTokens = array_values(array_unique($this->semanticTokens($normalizedValue)));
        if (!$candidateTokens) return false;

        // Name should be corroborated in the header; education facts should be
        // corroborated in the education section, avoiding job-ad wording.
        if ($type === 'name') {
            $header = $this->canonical(mb_substr($text, 0, 2500));
            $headerTokens = array_values(array_unique($this->semanticTokens($header)));
            $overlap = count(array_intersect($candidateTokens, $headerTokens)) / max(1, count($candidateTokens));
            return $overlap >= 0.85;
        }

        $education = $text;
        if (preg_match('/\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS?)\b(.*?)(?=\b(?:CERTIFICATIONS?|PROJECTS?|KEY\s+PROJECTS|PERSONAL\s+DETAILS|ACHIEVEMENTS?|SKILLS|TECHNICAL\s+SKILLS|EXPERIENCE|EMPLOYMENT|WORK\s+HISTORY)\b|$)/is', $text, $m)) {
            $education = $m[1];
        }
        $educationTokens = array_values(array_unique($this->semanticTokens($this->canonical($education))));
        $overlap = count(array_intersect($candidateTokens, $educationTokens)) / max(1, count($candidateTokens));
        return $overlap >= ($type === 'degree' ? 0.60 : 0.70);
    }

    private function semanticTokens(string $text): array
    {
        preg_match_all('/[\p{L}\p{N}]+/u', mb_strtolower($text), $m);
        $stop = [
            'and','the','for','with','from','into','this','that','role','job','position',
            'candidate','of','in','to','a','an','on','at','as','or','is','be','by','our',
            'your','university','college','institute','degree','bachelor','master',
        ];
        return array_values(array_filter($m[0] ?? [], function ($token) use ($stop) {
            return mb_strlen($token) >= 2 && !in_array($token, $stop, true);
        }));
    }

    private function explicitTotalExperienceSupports(mixed $aiYears, string $text): bool
    {
        $years = (float) $aiYears;
        if ($years <= 0 || $years > 60) return false;

        $patterns = [
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant)\s+experience\b/i',
        ];
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $text, $matches)) {
                foreach ($matches[1] as $value) {
                    if (abs((float) $value - $years) < 0.01) return true;
                }
            }
        }
        return false;
    }

    private function validatedAiExperienceYears(array $entries, string $text): float
    {
        $ranges = [];
        foreach ($entries as $entry) {
            if (!is_array($entry)) continue;
            $evidence = trim((string) ($entry['evidence'] ?? ''));
            $title = trim((string) ($entry['title'] ?? ''));
            $company = trim((string) ($entry['company'] ?? ''));
            $lineEvidence = trim(implode(' ', array_filter([$title, $company, $evidence])));
            if ($lineEvidence === '' || !$this->aiValueSupportedByResume($lineEvidence, $text, 'experience')) continue;

            if (preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic project|coursework|training)\b/i', $lineEvidence)) continue;

            $startValue = (string) ($entry['start_date'] ?? '');
            $endValue = (string) ($entry['end_date'] ?? '');
            $start = $this->parseExperienceMonth($startValue);
            $end = $this->parseExperienceMonth($endValue);
            if ($start === null || $end === null || $end < $start) continue;
            if (!$this->experienceDateSupportedByResume($startValue, $text) || !$this->experienceDateSupportedByResume($endValue, $text)) continue;
            $ranges[] = [$start, $end];
        }

        if (!$ranges) return 0.0;
        usort($ranges, fn($a, $b) => $a[0] <=> $b[0]);
        $merged = [];
        foreach ($ranges as $range) {
            if (!$merged || $range[0] > $merged[count($merged) - 1][1] + 1) {
                $merged[] = $range;
                continue;
            }
            $merged[count($merged) - 1][1] = max($merged[count($merged) - 1][1], $range[1]);
        }
        $months = 0;
        foreach ($merged as [$start, $end]) $months += $end - $start + 1;
        return min(60.0, round($months / 12, 1));
    }

    private function experienceDateSupportedByResume(string $value, string $text): bool
    {
        $value = trim($value);
        if ($value === '') return false;

        if (preg_match('/\b(present|current|now)\b/i', $value)) {
            return preg_match('/\b(present|current|now)\b/i', $text) === 1;
        }

        $monthIndex = $this->parseExperienceMonth($value);
        if ($monthIndex === null) return false;

        $year = intdiv($monthIndex, 12);
        $month = $monthIndex % 12;
        if ($month === 0) { $year--; $month = 12; }

        $monthNames = [1=>'jan(?:uary)?',2=>'feb(?:ruary)?',3=>'mar(?:ch)?',4=>'apr(?:il)?',5=>'may',6=>'jun(?:e)?',7=>'jul(?:y)?',8=>'aug(?:ust)?',9=>'sep(?:t(?:ember)?)?',10=>'oct(?:ober)?',11=>'nov(?:ember)?',12=>'dec(?:ember)?'];
        $pattern = '/\b(?:' . $monthNames[$month] . ')[\s,\-\/]+(?:' . $year . ')\b|\b(?:' . $year . ')[\-\/]0?' . $month . '\b/i';
        return preg_match($pattern, $text) === 1;
    }

    private function parseExperienceMonth(string $value): ?int
    {
        $value = trim($value);
        if ($value === '') return null;
        if (preg_match('/\b((?:19|20)\d{2})[-\/](\d{1,2})\b/', $value, $m)) {
            $month = max(1, min(12, (int) $m[2]));
            return ((int) $m[1]) * 12 + $month;
        }
        if (preg_match('/\b((?:19|20)\d{2})\b/', $value, $m)) {
            return ((int) $m[1]) * 12 + 1;
        }
        if (preg_match('/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|sept|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+((?:19|20)\d{2})\b/i', $value, $m)) {
            $months = ['jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,'aug'=>8,'august'=>8,'sep'=>9,'september'=>9,'sept'=>9,'oct'=>10,'october'=>10,'nov'=>11,'november'=>11,'dec'=>12,'december'=>12];
            $month = $months[mb_strtolower($m[1])] ?? null;
            return $month ? ((int) $m[2]) * 12 + $month : null;
        }
        return null;
    }

    private function extractWithAI(string $text, ?string $token = null): array
    {
        $this->lastAIError = null;
        $token = $token ?: $this->getHuggingFaceToken();
        if (!$token) {
            $this->lastAIError = 'Hugging Face token is not configured.';
            return [];
        }

        $schema = [
            'type' => 'object',
            'properties' => [
                'name' => ['type' => 'string'],
                'email' => ['type' => 'string'],
                'phone' => ['type' => 'string'],
                'gender' => ['type' => 'string'],
                'marital_status' => ['type' => 'string'],
                'qualification' => ['type' => 'string'],
                'degree' => ['type' => 'string'],
                'degree_full' => ['type' => 'string'],
                'major' => ['type' => 'string'],
                'experience_years' => ['type' => 'number'],
                'experience_entries' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'title' => ['type' => 'string'],
                            'company' => ['type' => 'string'],
                            'start_date' => ['type' => 'string'],
                            'end_date' => ['type' => 'string'],
                            'employment_type' => ['type' => 'string'],
                            'evidence' => ['type' => 'string'],
                        ],
                        'required' => ['title', 'company', 'start_date', 'end_date', 'employment_type', 'evidence'],
                        'additionalProperties' => false,
                    ],
                ],
            ],
            'required' => [
                'name', 'email', 'phone', 'gender', 'marital_status',
                'qualification', 'degree', 'degree_full', 'major', 'experience_years',
                'experience_entries',
            ],
            'additionalProperties' => false,
        ];

        $system = <<<'PROMPT'
You are a production HR resume extraction engine.
Extract ONLY facts explicitly supported by the supplied resume.
Never infer gender or marital status.
The candidate name must come from the visible resume header/contact area.
For education, identify the highest clearly stated degree and specialization.
For experience, calculate total professional experience only from explicit employment dates or an explicit total-experience statement; never count education dates, job advertisements, required-experience statements, or unrelated numbers.
For experience_entries, include only the candidate's own employment/paid professional roles and use empty strings when dates are not explicit. Do not treat internships, academic projects, volunteering, training, or coursework as professional experience unless the resume explicitly describes them as paid employment.
For every non-empty extracted field, preserve the exact factual meaning from the resume. Never guess a field from convention or a name.
Return empty strings for missing text fields, 0 for unsupported experience, and [] when there are no defensible experience entries.
Return JSON only.
PROMPT;

        $userText = $this->buildModelContext($text);
        $configuredModel = trim((string) env('HF_RESUME_MODEL', 'Qwen/Qwen3-32B')) ?: 'Qwen/Qwen3-32B';
        $timeout = max(12, (int) env('HF_RESUME_TIMEOUT', 55));
        $url = 'https://router.huggingface.co/v1/chat/completions';
        $messages = [
            ['role' => 'system', 'content' => $system],
            ['role' => 'user', 'content' => "Resume:\n" . $userText],
        ];

        $base = [
            'messages' => $messages,
            'temperature' => 0.0,
            'max_tokens' => 1200,
            'stream' => false,
        ];

        // Try configured model first, then an explicit Cerebras route for Qwen3-32B
        // when a provider rejects structured output with HTTP 400.
        $models = [$configuredModel];
        if ($configuredModel === 'Qwen/Qwen3-32B') $models[] = 'Qwen/Qwen3-32B:cerebras';
        $lastStatus = null;

        foreach (array_values(array_unique($models)) as $modelIndex => $model) {
            $strictPayload = $base;
            $strictPayload['model'] = $model;
            $strictPayload['response_format'] = [
                'type' => 'json_schema',
                'json_schema' => [
                    'name' => 'resume_candidate',
                    'schema' => $schema,
                    'strict' => true,
                ],
            ];

            try {
                $response = Http::connectTimeout(4)
                    ->timeout($timeout)
                    ->withToken($token)
                    ->acceptJson()
                    ->asJson()
                    ->post($url, $strictPayload);
                $lastStatus = $response->status();

                if ($response->successful()) {
                    $parsed = $this->parseAIJsonResponse($response);
                    if ($parsed) return $parsed;
                }

                if ($response->status() === 400) {
                    $jsonPayload = $base;
                    $jsonPayload['model'] = $model;
                    $jsonPayload['response_format'] = ['type' => 'json_object'];
                    $jsonResponse = Http::connectTimeout(4)
                        ->timeout($timeout)
                        ->withToken($token)
                        ->acceptJson()
                        ->asJson()
                        ->post($url, $jsonPayload);

                    if ($jsonResponse->successful()) {
                        $parsed = $this->parseAIJsonResponse($jsonResponse);
                        if ($parsed) return $parsed;
                    }
                }
            } catch (\Throwable $e) {
                $this->lastAIError = $e->getMessage();
            }
        }

        // Provider-independent last pass with a single explicit JSON instruction.
        try {
            $plainPayload = [
                'model' => $configuredModel,
                'messages' => [
                    ['role' => 'system', 'content' => $system . ' Return exactly one JSON object with keys: name,email,phone,gender,marital_status,qualification,degree,degree_full,major,experience_years,experience_entries.'],
                    ['role' => 'user', 'content' => "Resume:\n" . $userText],
                ],
                'temperature' => 0.0,
                'max_tokens' => 1200,
                'stream' => false,
            ];
            $plainResponse = Http::connectTimeout(4)
                ->timeout($timeout)
                ->withToken($token)
                ->acceptJson()
                ->asJson()
                ->post($url, $plainPayload);
            if ($plainResponse->successful()) {
                $parsed = $this->parseAIJsonResponse($plainResponse);
                if ($parsed) return $parsed;
            } else {
                $lastStatus = $plainResponse->status();
            }
        } catch (\Throwable $e) {
            $this->lastAIError = $e->getMessage();
        }

        if (!$this->lastAIError) {
            $this->lastAIError = $lastStatus ? 'HTTP ' . $lastStatus : 'Hugging Face returned no usable extraction.';
        }

        \Log::warning('HuggingFace resume extraction failed after all parsing modes', [
            'message' => $this->lastAIError,
            'model' => $configuredModel,
        ]);

        return [];
    }

    private function parseAIJsonResponse($response): array
    {
        $content = data_get($response->json(), 'choices.0.message.content');
        if (is_array($content)) {
            $json = $content;
        } else {
            $raw = trim((string) $content);
            $raw = preg_replace('/^```(?:json)?\s*/i', '', $raw);
            $raw = preg_replace('/\s*```$/', '', $raw);
            $json = json_decode($raw, true);
        }

        if (!is_array($json)) return [];

        $entries = is_array($json['experience_entries'] ?? null) ? $json['experience_entries'] : [];
        $entries = array_values(array_filter(array_map(function ($entry) {
            if (!is_array($entry)) return null;
            return [
                'title' => trim((string)($entry['title'] ?? '')),
                'company' => trim((string)($entry['company'] ?? '')),
                'start_date' => trim((string)($entry['start_date'] ?? '')),
                'end_date' => trim((string)($entry['end_date'] ?? '')),
                'employment_type' => trim((string)($entry['employment_type'] ?? '')),
                'evidence' => trim((string)($entry['evidence'] ?? '')),
            ];
        }, $entries), fn ($e) => is_array($e) && ($e['title'] !== '' || $e['company'] !== '' || $e['evidence'] !== '')));

        return [
            'candidate_name' => trim((string)($json['name'] ?? '')) ?: null,
            'candidate_email' => trim((string)($json['email'] ?? '')) ?: null,
            'candidate_mobile' => trim((string)($json['phone'] ?? '')) ?: null,
            'candidate_gender' => null,
            'candidate_marital_status' => null,
            'candidate_exper_count' => max(0, (float)($json['experience_years'] ?? 0)),
            'candidate_major_text' => trim((string)($json['major'] ?? '')) ?: null,
            'degree_full' => trim((string)($json['degree_full'] ?? $json['degree'] ?? '')) ?: null,
            'experience_evidence' => $entries,
        ];
    }

    private function matchEducation(string $text, array $data): array
    {
        $levels = DB::table('egc_qualification_level')
            ->select('sno', 'qualification_level_name')
            ->get();

        $majors = Cache::remember('resume_major_master_v5', 3600, function () {
            return DB::table('egc_major')
                ->where('status', 0)
                ->select('sno', 'qualification_id', 'major_name', 'description')
                ->get();
        });

        $degreeFull = trim((string)($data['degree_full'] ?? ''));
        $majorText = trim((string)($data['candidate_major_text'] ?? ''));
        $education = $this->extractEducation($text);

        $degreeFull = $education['degree_full'] ?: $degreeFull;
        $majorText = $education['major_text'] ?: $majorText;

        // Highest-confidence database match: look for a specific active master-data
        // major inside the EDUCATION section before doing fuzzy scoring. This avoids
        // mapping a specialized degree to generic B.E./B.Tech rows.
        if (!$majorText) {
            $educationSection = $text;
            if (preg_match('/\\b(?:EDUCATION|ACADEMIC\\s+QUALIFICATIONS?|QUALIFICATIONS?)\\b(.*?)(?=\\b(?:CERTIFICATIONS?|PROJECTS?|KEY\\s+PROJECTS|PERSONAL\\s+DETAILS|ACHIEVEMENTS?|SKILLS|TECHNICAL\\s+SKILLS)\\b|$)/is', $text, $em)) {
                $educationSection = $em[1];
            }

            $educationCanonical = $this->canonical($educationSection);
            $bestMaster = null;
            $bestMasterScore = 0;

            foreach ($majors as $major) {
                $specialization = $this->majorSpecializationCanonical((string)($major->major_name ?? ''));
                if ($specialization === '' || strlen($specialization) < 4) continue;
                if (!str_contains($educationCanonical, $specialization)) continue;

                $score = strlen($specialization);
                if ($score > $bestMasterScore) {
                    $bestMasterScore = $score;
                    $bestMaster = $major;
                }
            }

            if ($bestMaster) {
                $majorText = $bestMaster->major_name;
                $degreeFull = $degreeFull ?: $bestMaster->major_name;
            }
        }

        $evidence = trim($degreeFull . ' ' . $majorText);
        $qualificationName = $this->qualificationName($evidence);
        $qualificationId = $this->levelId($levels, $qualificationName);

        $best = null;
        $bestScore = 0.0;
        $target = $this->canonical($majorText ?: $evidence);

        foreach ($majors as $major) {
            $name = $this->canonical($major->major_name ?? '');
            $description = $this->canonical($major->description ?? '');
            if ($name === '') continue;

            $score = $this->majorScore($target, $name, $description);
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $major;
            }
        }

        // Prefer precision over a false master-data mapping. If the text does
        // not match an active major strongly enough, keep the source text and
        // let HR review it instead of silently assigning the wrong major.
        $majorMatchThreshold = 0.85;
        if ($best && $bestScore >= $majorMatchThreshold) {
            $qualificationId = $best->qualification_id ?: $qualificationId;
        }

        return [
            'qualification_sno' => $qualificationId,
            'major_sno' => ($best && $bestScore >= $majorMatchThreshold) ? $best->sno : null,
            'major_name' => ($best && $bestScore >= $majorMatchThreshold) ? $best->major_name : null,
            'degree_full' => $degreeFull ?: null,
            'major_score' => round($bestScore * 100),
        ];
    }

    private function majorSpecializationCanonical(string $majorName): string
    {
        $canonical = $this->canonical($majorName);
        $generic = [
            'B', 'BE', 'B E', 'BTECH', 'B TECH', 'BACHELOR',
            'M', 'ME', 'M E', 'MTECH', 'M TECH', 'MASTER',
            'OF', 'IN', 'THE', 'ENGINEERING', 'TECHNOLOGY',
        ];
        $words = array_values(array_filter(array_unique(explode(' ', $canonical)), function ($word) use ($generic) {
            return $word !== '' && !in_array($word, $generic, true);
        }));
        return trim(implode(' ', $words));
    }

    private function majorScore(string $target, string $name, string $description): float
    {
        if ($target === '' || $name === '') return 0;

        $aliases = [
            'AGRICULTURAL ENGINEERING' => 'AGRICULTURE ENGINEERING',
            'AGRICULTURE ENGINEERING' => 'AGRICULTURE ENGINEERING',
            'COMPUTER SCIENCE AND ENGINEERING' => 'COMPUTER SCIENCE ENGINEERING',
            'ELECTRICAL AND ELECTRONICS ENGINEERING' => 'ELECTRICAL ELECTRONICS ENGINEERING',
            'ELECTRONICS AND COMMUNICATION ENGINEERING' => 'ELECTRONICS COMMUNICATION ENGINEERING',
        ];

        foreach ($aliases as $from => $to) {
            $target = str_replace($from, $to, $target);
            $name = str_replace($from, $to, $name);
            $description = str_replace($from, $to, $description);
        }

        if (str_contains($target, $name) || str_contains($name, $target)) {
            return 0.98;
        }

        $targetWords = array_values(array_filter(array_unique(explode(' ', $target))));
        $nameWords = array_values(array_filter(array_unique(explode(' ', $name))));
        $descriptionWords = array_values(array_filter(array_unique(explode(' ', $description))));

        // Remove generic degree words from the specialization comparison.
        $generic = ['B', 'BE', 'BTECH', 'BACHELOR', 'ENGINEERING', 'M', 'ME', 'MTECH', 'MASTER', 'OF', 'IN', 'THE', 'TECHNOLOGY'];
        $targetWords = array_values(array_diff($targetWords, $generic));
        $nameWords = array_values(array_diff($nameWords, $generic));
        $descriptionWords = array_values(array_diff($descriptionWords, $generic));

        if (!$targetWords || !$nameWords) return 0;

        $common = count(array_intersect($targetWords, $nameWords));
        $nameCoverage = $common / count($nameWords);
        $targetCoverage = $common / count($targetWords);

        if ($nameCoverage >= 0.8 && $targetCoverage >= 0.5) {
            return 0.90 + min(0.08, count($nameWords) / 100);
        }

        $descCommon = count(array_intersect($targetWords, $descriptionWords));
        $descScore = $descCommon / max(1, count($targetWords));

        return max(($nameCoverage * 0.75) + ($targetCoverage * 0.25), $descScore * 0.85);
    }

    private function extractEducation(string $text): array
    {
        $section = $text;
        if (preg_match('/\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS?)\b(.*?)(?=\b(?:CERTIFICATIONS?|PROJECTS?|KEY\s+PROJECTS|PERSONAL\s+DETAILS|ACHIEVEMENTS?|SKILLS|TECHNICAL\s+SKILLS)\b|$)/is', $text, $m)) {
            $section = $m[1];
        }

        $section = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $section);
        $degree = null;
        $major = null;

        $patterns = [
            '/\b(Bachelor\s+of\s+Engineering|Bachelor\s+of\s+Technology|B\.?\s*E\.?|B\.?\s*Tech\.?)\s*(?:in|of|[-:]\s*)\s*([A-Za-z][A-Za-z &\/.-]{2,100}?)(?=\s+(?:Hindusthan|University|College|Institute|Coimbatore|Chennai|Madurai)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
            '/\b(Master\s+of\s+Engineering|Master\s+of\s+Technology|M\.?\s*E\.?|M\.?\s*Tech\.?)\s*(?:in|of|[-:]\s*)\s*([A-Za-z][A-Za-z &\/.-]{2,100}?)(?=\s+(?:University|College|Institute)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
            '/\b(Bachelor\s+of\s+Science|B\.?\s*Sc\.?)\s*(?:in|of|[-:]\s*)\s*([A-Za-z][A-Za-z &\/.-]{2,100}?)(?=\s+(?:University|College|Institute)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
            '/\b(Bachelor\s+of\s+Commerce|B\.?\s*Com\.?)\s*(?:in|of|[-:]\s*)\s*([A-Za-z][A-Za-z &\/.-]{2,100}?)(?=\s+(?:University|College|Institute)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
            '/\b(Master\s+of\s+Business\s+Administration|MBA)\s*(?:in|of|[-:]\s*)?([A-Za-z][A-Za-z &\/.-]{0,100}?)(?=\s+(?:University|College|Institute)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
            '/\b(Ph\.?\s*D\.?|Doctor\s+of\s+Philosophy)\s*(?:in|of|[-:]\s*)?([A-Za-z][A-Za-z &\/.-]{0,100}?)(?=\s+(?:University|College|Institute)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $section, $m)) {
                $degreeRaw = trim(preg_replace('/\s+/', ' ', $m[1]));
                $majorRaw = trim(preg_replace('/\s+/', ' ', $m[2] ?? ''));
                $majorRaw = preg_replace('/\s*[|•].*$/', '', $majorRaw);
                $majorRaw = preg_replace('/\s+(?:August|January|February|March|April|May|June|July|September|October|November|December)\b.*$/i', '', $majorRaw);
                $majorRaw = preg_replace('/\s+(?:19|20)\d{2}\s*[-–—]\s*(?:Present|(?:19|20)\d{2}).*$/i', '', $majorRaw);
                $majorRaw = trim($majorRaw, " .,-–—|:");
                if ($majorRaw !== '') {
                    $degree = $degreeRaw . ' in ' . $majorRaw;
                    $major = $majorRaw;
                } else {
                    $degree = $degreeRaw;
                }
                break;
            }
        }

        // Explicit B.E. / B.Tech lines often use a dash or en dash instead of the word "in".
        if (!$major && preg_match('/\b(B\.?\s*E\.?|B\.?\s*Tech\.?)\s*[-:]\s*([A-Za-z][A-Za-z &\/.-]{2,100}?)(?=\s+(?:Hindusthan|University|College|Institute|Coimbatore|Chennai|Madurai)\b|\s+\d{4}\b|\s+CGPA\b|\s+GPA\b|\s*\||$)/i', $section, $m)) {
            $major = trim(preg_replace('/\s+/', ' ', $m[2]));
            $major = trim($major, " .,-–—|:");
            $degree = trim($m[1]) . ' in ' . $major;
        }

        // Flattened-document fallback for the exact wording used in many resumes.
        if (!$major && preg_match('/\bBachelor\s+of\s+Engineering\s+in\s+([A-Za-z][A-Za-z ]+?)(?=\s*\||\s+(?:August|January|February|March|April|May|June|July|September|October|November|December)\b|\s+\d{4}\b|$)/i', $section, $m)) {
            $major = trim($m[1]);
            $degree = 'Bachelor of Engineering in ' . $major;
        }

        return [
            'degree_full' => $degree,
            'major_text' => $major,
        ];
    }

    private function extractName(string $text, ?string $email, ?string $phone): ?string
    {
        $header = trim(mb_substr($text, 0, 2200));
        $header = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $header);

        // Primary DOCX/PDF-safe strategy: inspect the first visible lines.
        $lines = preg_split('/\R+/', $header) ?: [];
        foreach (array_slice($lines, 0, 12) as $line) {
            $line = trim($line);
            if ($line === '') continue;

            // Remove leading/trailing decorative emoji and separators.
            $candidateLine = preg_replace('/^[^A-Za-z0-9]+/u', '', $line);
            $candidateLine = trim($candidateLine);
            $candidateLine = preg_replace('/\s*(?:\+?\d[\d\s()\-]{8,}\d|[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}).*$/i', '', $candidateLine);
            $candidateLine = trim($candidateLine, " |,;:.-");
            $candidateLine = preg_replace('/^(?:name|candidate\s+name)\s*[:\-]?\s*/i', '', $candidateLine);

            if ($this->looksLikeName($candidateLine)) return $candidateLine;
        }

        // Flattened header: find text immediately before the first contact separator.
        $contactPos = [];
        if ($email) {
            $p = mb_stripos($header, $email);
            if ($p !== false) $contactPos[] = $p;
        }
        if ($phone) {
            // Accept spaced phone numbers as well as normalized digits.
            $phoneRegex = '/(?:\+?91[\s\-()]*)?(?:\d[\s\-()]*){10}/';
            if (preg_match($phoneRegex, $header, $m, PREG_OFFSET_CAPTURE)) $contactPos[] = $m[0][1];
        }
        if ($contactPos) {
            $prefix = trim(mb_substr($header, 0, min($contactPos)));
            $prefix = preg_replace('/^[^A-Za-z]+/u', '', $prefix);
            foreach (array_reverse(preg_split('/[\n|•·,]+/', $prefix) ?: []) as $piece) {
                $piece = trim($piece);
                if ($this->looksLikeName($piece)) return $piece;
            }
        }

        return null;
    }

    private function looksLikeName(string $value): bool
    {
        $value = trim(preg_replace('/\s+/', ' ', $value));
        if (mb_strlen($value) < 3 || mb_strlen($value) > 100) return false;
        if (preg_match('/\b(profile|summary|experience|education|skills|projects?|certifications?|linkedin|github|email|phone|madurai|india|tamil|resume|technical\s+skills|developer|engineer|programmer|analyst|consultant|manager|executive|administrator|administrator|specialist|designer|architect|lead|team\s+lead|director|intern|trainee|recruiter|hr)\b/i', $value)) return false;
        if (preg_match('/\d|@|https?:\/\//i', $value)) return false;
        return (bool)preg_match('/^\p{L}[\p{L}.\'\-]*(?:\s+\p{L}[\p{L}.\'\-]*){1,5}$/u', $value);
    }

    private function extractEmail(string $text): ?string
    {
        preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $text, $m, PREG_OFFSET_CAPTURE);
        $best = null;
        $bestScore = -INF;
        foreach ($m[0] ?? [] as $hit) {
            $email = strtolower(trim($hit[0]));
            if (str_contains($email, 'example.') || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
            $context = strtolower(substr($text, max(0, $hit[1] - 140), 140));
            $score = 0;
            if (preg_match('/\b(email|e-mail|mail|contact|personal)\b/', $context)) $score += 20;
            if (preg_match('/\b(recruit|hr|hiring|reference|referee|emergency|manager|company)\b/', $context)) $score -= 30;
            if ($hit[1] < 1600) $score += 8;
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $email;
            }
        }
        return $best;
    }

    private function extractPhone(string $text): ?string
    {
        // Indian candidate numbers only: optional +91/0091 followed by a
        // 10-digit mobile beginning with 6-9. This deliberately excludes broad
        // 10-14 digit matches such as Aadhaar/reference numbers.
        preg_match_all('/(?:\+?91[\s\-()]*)?[6-9](?:[\s\-()]?\d){9}\b/', $text, $m, PREG_OFFSET_CAPTURE);
        $best = null;
        $bestScore = -INF;
        foreach ($m[0] ?? [] as $hit) {
            $clean = $this->cleanPhone($hit[0]);
            if (!$clean) continue;
            $context = strtolower(substr($text, max(0, $hit[1] - 160), 160));
            $score = 0;
            if (preg_match('/\b(mobile|phone|contact|tel|telephone|cell|whatsapp)\b/', $context)) $score += 20;
            if (preg_match('/\b(emergency|reference|referee|parent|father|mother|recruit|hr|manager)\b/', $context)) $score -= 35;
            if ($hit[1] < 1600) $score += 8;
            if (preg_match('/^[6-9]\d{9}$/', $clean)) $score += 5;
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $clean;
            }
        }
        return $best;
    }

    private function cleanPhone(?string $phone): ?string
    {
        if (!$phone) return null;
        $digits = preg_replace('/\D+/', '', $phone);
        if (str_starts_with($digits, '0091')) $digits = substr($digits, 4);
        if (str_starts_with($digits, '91') && strlen($digits) > 10) $digits = substr($digits, -10);
        if (strlen($digits) > 10) $digits = substr($digits, -10);
        return preg_match('/^[6-9]\d{9}$/', $digits) ? $digits : null;
    }

    private function extractExperienceYears(string $text): float
    {
        $explicit = 0.0;

        $summaryPatterns = [
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant)\s+experience\b/i',
        ];

        foreach ($summaryPatterns as $pattern) {
            if (preg_match_all($pattern, $text, $matches)) {
                foreach ($matches[1] as $years) {
                    $value = (float)$years;
                    if ($value > 0 && $value <= 60) $explicit = max($explicit, $value);
                }
            }
        }

        $section = $text;
        if (preg_match('/\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE)\b(.*?)(?=\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|PROJECTS?|KEY\s+PROJECTS|CERTIFICATIONS?|PERSONAL\s+DETAILS|SKILLS|TECHNICAL\s+SKILLS|ACHIEVEMENTS?)\b|$)/is', $text, $sectionMatch)) {
            $section = $sectionMatch[1];
        }

        $months = [
            'jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,
            'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,
            'aug'=>8,'august'=>8,'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,'october'=>10,
            'nov'=>11,'november'=>11,'dec'=>12,'december'=>12,
        ];
        $monthWords = implode('|', array_keys($months));
        $workedMonths = [];

        $rangePattern = '/((?:' . $monthWords . ')\s+\d{4})\s*(?:-|–|—|to)\s*(Present|Current|(?:' . $monthWords . ')\s+\d{4})/i';
        foreach (preg_split('/\R+/', $section) ?: [] as $line) {
            $lineLower = strtolower($line);
            if (preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic project|coursework|training)\b/', $lineLower)) {
                continue;
            }
            if (!preg_match_all($rangePattern, $line, $ranges, PREG_SET_ORDER)) continue;

            foreach ($ranges as $range) {
                if (!preg_match('/^([A-Za-z]+)\s+(\d{4})$/', trim($range[1]), $st)) continue;
                $startMonth = $months[strtolower($st[1])] ?? null;
                $startYear = (int)$st[2];
                if (!$startMonth || $startYear < 1950) continue;
                $startIndex = $startYear * 12 + $startMonth;

                $endValue = trim($range[2]);
                if (in_array(strtolower($endValue), ['present','current'], true)) {
                    $endIndex = (int)date('Y') * 12 + (int)date('n');
                } elseif (preg_match('/^([A-Za-z]+)\s+(\d{4})$/', $endValue, $en)) {
                    $endMonth = $months[strtolower($en[1])] ?? null;
                    $endYear = (int)$en[2];
                    if (!$endMonth || $endYear < 1950) continue;
                    $endIndex = $endYear * 12 + $endMonth;
                } else {
                    continue;
                }

                if ($endIndex < $startIndex) continue;
                for ($monthIndex = $startIndex; $monthIndex < max($startIndex + 1, $endIndex); $monthIndex++) {
                    $workedMonths[$monthIndex] = true;
                }
            }
        }

        $calculated = $workedMonths
            ? round(count($workedMonths) / 12, 1)
            : 0.0;

        if ($calculated <= 0) {
            foreach (preg_split('/\R+/', $section) ?: [] as $line) {
                $lineLower = strtolower($line);
                if (preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic project|coursework|training)\b/', $lineLower)) continue;
                if (!preg_match_all('/\b((?:19|20)\d{2})\s*(?:-|–|—|to)\s*(Present|Current|(?:19|20)\d{2})\b/i', $line, $ranges, PREG_SET_ORDER)) continue;
                foreach ($ranges as $range) {
                    $startYear = (int)$range[1];
                    $endYear = in_array(strtolower($range[2]), ['present','current'], true) ? (int)date('Y') : (int)$range[2];
                    if ($startYear >= 1950 && $endYear >= $startYear) {
                        $calculated = max($calculated, (float)max(1, $endYear - $startYear));
                    }
                }
            }
        }

        return round(min(60, max($explicit, $calculated)), 1);
    }

    private function extractExplicitGender(string $text): ?int
    {
        if (preg_match('/\b(?:gender|sex)\s*[:\-]?\s*(male|m)\b/i', $text, $m)) return 1;
        if (preg_match('/\b(?:gender|sex)\s*[:\-]?\s*(female|f)\b/i', $text, $m)) return 2;
        return null;
    }

    private function extractExplicitMarital(string $text): ?int
    {
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]?\s*(married)\b/i', $text)) return 1;
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]?\s*(single|unmarried)\b/i', $text)) return 2;
        return null;
    }

    private function cleanName(?string $name): ?string
    {
        if (!$name) return null;
        $name = trim(preg_replace('/\s+/', ' ', $name));
        $name = trim($name, "|,;:.- ");
        return $this->looksLikeName($name) ? $name : null;
    }

    private function mapGender($gender): ?int
    {
        $gender = strtolower(trim((string)$gender));
        if (in_array($gender, ['male', 'm'], true)) return 1;
        if (in_array($gender, ['female', 'f'], true)) return 2;
        return null;
    }

    private function mapMarital($status): ?int
    {
        $status = strtolower(trim((string)$status));
        if (str_contains($status, 'married') && !str_contains($status, 'unmarried')) return 1;
        if (str_contains($status, 'single') || str_contains($status, 'unmarried') || str_contains($status, 'not married')) return 2;
        return null;
    }

    private function qualificationName(string $text): ?string
    {
        $u = $this->canonical($text);
        if (preg_match('/\b(PHD|DOCTORATE|DOCTOR OF PHILOSOPHY)\b/', $u)) return 'Doctorate';
        if (preg_match('/\b(MASTER|MTECH|M TECH|MBA|MSC|M SC|MCA|M E|ME|M COM|MA)\b/', $u)) return 'PG';
        if (preg_match('/\b(BACHELOR|BTECH|B TECH|B E|BE|BSC|B SC|BCA|BCOM|B COM|BA|BBA|MBBS|B PHARM|B ARCH|B ED)\b/', $u)) return 'UG';
        if (str_contains($u, 'DIPLOMA')) return 'Diploma';
        return null;
    }

    private function levelId($levels, ?string $name): ?int
    {
        if (!$name) return null;
        $row = $levels->first(function ($level) use ($name) {
            return strtoupper(trim((string)$level->qualification_level_name)) === strtoupper($name);
        });
        return $row->sno ?? null;
    }

    private function canonical(string $text): string
    {
        $text = strtoupper($text);
        $text = str_replace(['&', '/', '-', '.', ',', '(', ')', ':', '|'], ' ', $text);
        $text = preg_replace('/\s+/', ' ', $text);
        $aliases = [
            'AGRICULTURAL' => 'AGRICULTURE',
            'COMPUTER SCIENCE AND ENGINEERING' => 'COMPUTER SCIENCE ENGINEERING',
            'ELECTRICAL AND ELECTRONICS ENGINEERING' => 'ELECTRICAL ELECTRONICS ENGINEERING',
            'ELECTRONICS AND COMMUNICATION ENGINEERING' => 'ELECTRONICS COMMUNICATION ENGINEERING',
        ];
        foreach ($aliases as $from => $to) $text = str_replace($from, $to, $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }

    private function confidence(array $data, array $education, string $text, array $ai): int
    {
        $score = 0;
        if (!empty($data['candidate_name'])) $score += 20;
        if (!empty($data['candidate_email'])) $score += 15;
        if (!empty($data['candidate_mobile'])) $score += 15;
        if (!empty($data['candidate_qualification'])) $score += 15;
        if (!empty($data['candidate_major'])) $score += 20;
        if ((float)($data['candidate_exper_count'] ?? 0) > 0) $score += 15;
        return min(100, $score);
    }

    private function buildModelContext(string $text): string
    {
        $text = trim($text);
        if (mb_strlen($text) <= self::MAX_AI_CHARS) return $text;

        $chunks = [mb_substr($text, 0, 18000)];

        $importantSections = [
            'WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY',
            'EDUCATION|ACADEMIC\s+QUALIFICATIONS|QUALIFICATIONS',
            'SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS',
            'PROJECTS|KEY\s+PROJECTS',
            'CERTIFICATIONS|CERTIFICATES',
            'PERSONAL\s+DETAILS|CONTACT',
        ];

        foreach ($importantSections as $sectionPattern) {
            $pattern = '/\b(?:' . $sectionPattern . ')\b(.*?)(?=\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS|QUALIFICATIONS|WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS|PROJECTS|KEY\s+PROJECTS|CERTIFICATIONS|CERTIFICATES|PERSONAL\s+DETAILS|CONTACT|ACHIEVEMENTS|REFERENCES)\b|$)/is';
            if (preg_match($pattern, $text, $m)) {
                $chunks[] = mb_substr(trim($m[0]), 0, 18000);
            }
        }

        $chunks[] = mb_substr($text, -12000);

        $unique = [];
        foreach ($chunks as $chunk) {
            $chunk = trim($chunk);
            if ($chunk !== '') $unique[$chunk] = true;
        }

        $context = implode("\n\n--- IMPORTANT RESUME SECTION ---\n\n", array_keys($unique));
        return mb_strlen($context) > self::MAX_AI_CHARS
            ? mb_substr($context, 0, self::MAX_AI_CHARS)
            : $context;
    }

    private function getHuggingFaceToken(): ?string
    {
        foreach ([env('HF_TOKEN'), env('HUGGINGFACE_API_TOKEN')] as $configuredToken) {
            $configuredToken = trim((string) $configuredToken);
            if ($configuredToken !== '') {
                return $configuredToken;
            }
        }

        try {
            $row = DB::table('egc_api_integration')
            ->where('api_key', 'egc_huggingface_api_1')
            ->where('status', 0)
            ->orderByDesc('sno')
            ->first();

        if (!$row) return null;

        $fields = json_decode($row->api_fields ?? '[]', true);
        if (!is_array($fields)) return null;

            foreach ($fields as $field) {
                if (($field['key'] ?? '') === 'api_key' && !empty($field['value'])) {
                    return trim((string)$field['value']);
                }
            }
        } catch (\Throwable $e) {
            \Log::warning('Unable to read Hugging Face credential from ERP API integration', [
                'message' => $e->getMessage(),
            ]);
        }

        return null;
    }

    private function extractText(string $path, string $extension): string
    {
        $extension = strtolower(trim($extension));

        switch ($extension) {
            case 'pdf':
                try {
                    $parser = new PdfParser();
                    $pdf = $parser->parseFile($path);
                    $text = (string)$pdf->getText();
                } catch (\Throwable $e) {
                    \Log::warning('PDF text extraction failed', ['message' => $e->getMessage()]);
                    $text = '';
                }
                if (mb_strlen(trim($text)) < 100) {
                    try { $text = $this->ocrPdf($path); } catch (\Throwable $e) {
                        \Log::warning('PDF OCR fallback failed', ['message' => $e->getMessage()]);
                    }
                }
                return $text;

            case 'docx':
            case 'docm':
                return $this->extractDocx($path);

            case 'doc':
                return $this->extractDoc($path);

            case 'odt':
                return $this->extractOdt($path);

            case 'rtf':
                return $this->extractRtf($path);

            case 'txt':
            case 'text':
            case 'md':
            case 'markdown':
            case 'csv':
            case 'tsv':
            case 'json':
            case 'xml':
            case 'html':
            case 'htm':
                $raw = @file_get_contents($path);
                return is_string($raw) ? $this->genericTextCleanup($raw) : '';

            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'webp':
            case 'bmp':
            case 'gif':
            case 'tif':
            case 'tiff':
                return $this->ocrImage($path);
        }

        // Last-resort text sniffing for extensionless/mislabeled text documents.
        $raw = @file_get_contents($path, false, null, 0, 200000);
        if (is_string($raw) && $raw !== '' && $this->looksLikePlainText($raw)) {
            return $this->genericTextCleanup($raw);
        }

        throw new \RuntimeException('Unsupported resume format. The file was uploaded successfully, but no readable text/image content was detected.');
    }

    private function genericTextCleanup(string $text): string
    {
        if (preg_match('/<html|<body|<p\b|<div\b|<br\b/i', $text)) {
            $text = strip_tags($text, '<br><p><div>');
            $text = preg_replace('/<\s*br\s*\/?\s*>/i', "\n", $text);
            $text = preg_replace('/<\s*\/p\s*>/i', "\n", $text);
            $text = preg_replace('/<\s*\/div\s*>/i', "\n", $text);
        }
        return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    private function looksLikePlainText(string $raw): bool
    {
        $sample = substr($raw, 0, 5000);
        if ($sample === '') return false;
        $nul = substr_count($sample, "\0");
        if ($nul > 0) return false;
        $printable = preg_match_all('/[\x09\x0A\x0D\x20-\x7E\x80-\xFF]/', $sample);
        return $printable !== false && $printable / max(1, strlen($sample)) > 0.85;
    }

    private function extractDocx(string $path): string
    {
        // DOCX is a ZIP package. Reading word/document.xml directly preserves
        // paragraph boundaries much more reliably than depending only on reader internals.
        $text = '';
        if (class_exists('ZipArchive')) {
            try {
                $zip = new \ZipArchive();
                if ($zip->open($path) === true) {
                    $xmlNames = [];
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $stat = $zip->statIndex($i);
                        $name = $stat['name'] ?? '';
                        if (preg_match('#^word/(?:document|header\d+|footer\d+)\.xml$#i', $name)) {
                            $xmlNames[] = $name;
                        }
                    }

                    foreach ($xmlNames as $xmlName) {
                        $xml = $zip->getFromName($xmlName);
                        if ($xml === false || $xml === '') continue;
                        $dom = new \DOMDocument();
                        $dom->preserveWhiteSpace = false;
                        if (@$dom->loadXML($xml)) {
                            $xp = new \DOMXPath($dom);
                            $xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');
                            foreach ($xp->query('//w:p') as $pNode) {
                                $parts = [];
                                foreach ($xp->query('.//w:t', $pNode) as $tNode) {
                                    $parts[] = $tNode->textContent;
                                }
                                $line = trim(implode('', $parts));
                                if ($line !== '') $text .= $line . "\n";
                            }
                        }
                    }
                    $zip->close();
                }
            } catch (\Throwable $e) {
                \Log::debug('Raw DOCX XML extraction warning', ['message' => $e->getMessage()]);
            }
        }

        if (mb_strlen(trim($text)) >= 20) return $text;

        // Fallback for environments where ZipArchive/XML parsing is unavailable.
        try {
            $word = IOFactory::load($path);
            $parts = [];
            foreach ($word->getSections() as $section) {
                foreach ($section->getElements() as $element) {
                    $value = $this->phpWordText($element);
                    if ($value !== '') $parts[] = $value;
                }
            }
            $text = implode("\n", $parts);
        } catch (\Throwable $e) {
            \Log::warning('DOCX extraction failed', ['message' => $e->getMessage()]);
        }

        return $text;
    }

    private function phpWordText($element): string
    {
        $text = '';
        try {
            if (method_exists($element, 'getText')) {
                $value = $element->getText();
                if (is_string($value)) $text .= $value . ' ';
            }
            if (method_exists($element, 'getElements')) {
                foreach ($element->getElements() as $child) {
                    $text .= $this->phpWordText($child) . ' ';
                }
            }
        } catch (\Throwable $e) {
            \Log::debug('PHPWord extraction warning', ['message' => $e->getMessage()]);
        }
        return trim($text);
    }

    private function extractDoc(string $path): string
    {
        foreach (['antiword', 'catdoc'] as $command) {
            $binary = trim((string)shell_exec('command -v ' . escapeshellarg($command)));
            if ($binary === '') continue;
            $text = (string)shell_exec(escapeshellcmd($binary) . ' ' . escapeshellarg($path));
            if (mb_strlen(trim($text)) >= 20) return $text;
        }
        throw new \RuntimeException('Legacy DOC extraction requires antiword or catdoc on the server.');
    }

    private function ocrImage(string $path): string
    {
        return (new TesseractOCR($path))
            ->lang(env('RESUME_OCR_LANG', 'eng'))
            ->psm(6)
            ->run();
    }

    private function ocrPdf(string $path): string
    {
        $dir = storage_path('app/resume_ocr');
        if (!is_dir($dir)) @mkdir($dir, 0755, true);

        $prefix = $dir . DIRECTORY_SEPARATOR . 'resume_' . bin2hex(random_bytes(8));
        $pdftoppm = trim((string)shell_exec('command -v pdftoppm'));
        if ($pdftoppm === '') throw new \RuntimeException('pdftoppm is required for scanned PDF resumes.');

        shell_exec(
            escapeshellcmd($pdftoppm) .
            ' -r ' . max(120, (int) env('RESUME_OCR_DPI', 170))
            . ' -png -f 1 -l ' . max(1, (int) env('RESUME_OCR_MAX_PAGES', 25)) . ' ' .
            escapeshellarg($path) . ' ' .
            escapeshellarg($prefix)
        );

        $text = '';
        foreach (glob($prefix . '-*.png') ?: [] as $image) {
            try {
                $page = $this->ocrImage($image);
                if ($page !== '') $text .= "\n" . $page;
            } finally {
                @unlink($image);
            }
        }

        return $text;
    }

    private function pdfRequiredOCR(string $path, string $text): bool
    {
        return mb_strlen(trim($text)) < 100;
    }

    private function normalizeText(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = str_replace(["–", "—", "−", "‑", "‒"], '-', $text);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text);
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\n{3,}/', "\n\n", $text);
        return trim($text);
    }
}
