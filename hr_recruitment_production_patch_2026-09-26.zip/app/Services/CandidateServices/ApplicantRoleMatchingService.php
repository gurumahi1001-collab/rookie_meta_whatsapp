<?php

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class ApplicantRoleMatchingService
{
    protected ResumeParserService $resumeParser;

    protected PromptBuilderService $promptBuilder;

    protected HuggingFaceClientService $hfClient;

    protected AIResponseValidatorService $validator;

    protected ApplicantUpdaterService $updater;
    protected RecruitmentRoleProfileService $roleProfiles;

    public function __construct(
        ResumeParserService $resumeParser,
        PromptBuilderService $promptBuilder,
        HuggingFaceClientService $hfClient,
        AIResponseValidatorService $validator,
        ApplicantUpdaterService $updater,
        RecruitmentRoleProfileService $roleProfiles
    ) {
        $this->resumeParser = $resumeParser;
        $this->promptBuilder = $promptBuilder;
        $this->hfClient = $hfClient;
        $this->validator = $validator;
        $this->updater = $updater;
         $this->roleProfiles = $roleProfiles;
    }

    /**
     * ---------------------------------------------------------
     * Match One Applicant
     * ---------------------------------------------------------
     */
    public function matchApplicant(int $sno): array
    {
        $applicant = ApplicantModel::query()
            ->where('sno', $sno)
            ->first();

        if (!$applicant) {

            return [
                'status' => false,
                'message' => 'Applicant not found.'
            ];
        }

        if ((int) $applicant->status === 2) {
            return [
                'status' => false,
                'message' => 'Applicant is not eligible for AI matching.'
            ];
        }

        try {

            /*Resume */

            $resume = trim((string) $applicant->resume_text );

            if ($resume === '') {

                $resume = $this->resumeParser->getResumeText($applicant);

                if (!empty($resume)) {
                    $this->updater->updateResumeText($applicant, $resume);
                }
            }

            if (trim((string) $resume) === '') {
                return [
                    'status' => false,
                    'message' => 'Resume content is not available.'
                ];
            }

            /*
             * -------------------------------------------------
             * Normalize Resume
             * -------------------------------------------------
             */

            $resume = $this->cleanResume(
                $resume
            );

            /*
             * -------------------------------------------------
             * Company Roles
             * -------------------------------------------------
             */

            // $roles = $this->getActiveRoles();
            $roles = $this->roleProfiles
                ->getActiveProfiles();
            if (empty($roles)) {

                return [
                    'status' => false,
                    'message' => 'No active recruitment roles configured.'
                ];
            }

            /*
             * -------------------------------------------------
             * Build Prompt
             * -------------------------------------------------
             */

            $prompt = $this->promptBuilder
                ->roleMatching(
                    $resume,
                    $roles
                );

            /*
             * -------------------------------------------------
             * AI
             * -------------------------------------------------
             */

            $response = $this->hfClient
                ->askJson($prompt);

            if (!$response['status']) {

                return [
                    'status' => false,
                    'message' => $response['message']
                        ?? 'AI request failed.'
                ];
            }

            /*
             * -------------------------------------------------
             * Validate
             * -------------------------------------------------
             */

            $validated = $this->validator
                ->validateRoleMatching(
                    $response['data'] ?? $response,
                    $resume
                );

            /*
             * -------------------------------------------------
             * IMPORTANT
             *
             * A valid analysis can contain zero matches.
             * -------------------------------------------------
             */

            if (!$validated['status']) {

                return [
                    'status' => false,
                    'message' => $validated['message']
                ];
            }

            /*
             * -------------------------------------------------
             * Save
             * -------------------------------------------------
             */

            $saveData = [
                'matches' => $validated['matches'],
                'ai_response' => $validated['ai_response']
                    ?? [],
            ];

            $saved = $this->updater
                ->saveRoleMatching(
                    $applicant,
                    $saveData
                );

            if (!$saved['status']) {

                return $saved;
            }

            /*
             * -------------------------------------------------
             * Response
             * -------------------------------------------------
             */

            return [
                'status' => true,
                'message' => 'AI role matching completed.',
                'data' => [
                    'applicant_sno' => $applicant->sno,
                    'job_role_ids' => $saved['job_role_ids'],
                    'match_score' => $saved['match_score']
                        ?? null,
                    'matches' => $validated['matches'],
                    'ai_response' => $validated['ai_response']
                        ?? [],
                ]
            ];

        } catch (Throwable $e) {

            Log::error(
                'Applicant Role Matching Service Error',
                [
                    'applicant_sno' => $sno,
                    'message' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                ]
            );

            return [
                'status' => false,
                'message' => 'AI matching failed.',
                'err'=>$e->getMessage()
            ];
        }
    }

    /**
     * ---------------------------------------------------------
     * Get Stored Analysis
     * ---------------------------------------------------------
     */
    public function getAnalysis(int $sno): array
    {
        $applicant = ApplicantModel::query()
            ->where('sno', $sno)
            ->first();

        if (!$applicant) {

            return [
                'status' => false,
                'message' => 'Applicant not found.'
            ];
        }

        if (
            empty($applicant->ai_response)
        ) {

            return [
                'status' => false,
                'message' => 'AI analysis is not available.'
            ];
        }

        $aiResponse = json_decode(
            $applicant->ai_response,
            true
        );

        if (!is_array($aiResponse)) {

            return [
                'status' => false,
                'message' => 'Stored AI response is invalid.'
            ];
        }

        return [
            'status' => true,
            'data' => [
                'applicant' => [
                    'sno' => $applicant->sno,
                    'name' => $applicant->applicant_name,
                    'email' => $applicant->email,
                    'mobile' => $applicant->mobile,
                ],
                'job_role_ids' => $this->decodeRoleIds(
                    $applicant->job_role_id
                ),
                'match_score' => $applicant->match_score,
                'ai_response' => $aiResponse,
            ]
        ];
    }

    /**
     * ---------------------------------------------------------
     * Bulk Matching
     * ---------------------------------------------------------
     */
    public function bulkMatch(array $options): array
    {
        $ids = array_values(
            array_unique(
                array_map(
                    'intval',
                    $options['applicant_ids'] ?? []
                )
            )
        );

        $limit = min(
            (int) ($options['limit'] ?? 100),
            500
        );

        $batchSize = min(
            (int) ($options['batch_size'] ?? 5),
            10
        );

        $force = (bool) (
            $options['force'] ?? false
        );

        /*
         * -----------------------------------------------------
         * Explicit applicants
         * -----------------------------------------------------
         */

        if (!empty($ids)) {

            $query = ApplicantModel::query()
                ->whereIn('sno', $ids)
                ->where('status', '!=', 2)
                ->orderBy('sno');

        } else {

            /*
             * -------------------------------------------------
             * Automatically process applicants without AI
             * -------------------------------------------------
             */

            $query = ApplicantModel::query()
                ->where('status', '!=', 2);

            if (!$force) {

                $query->where(function ($q) {

                    $q->whereNull('ai_response')
                        ->orWhere(
                            'ai_response',
                            ''
                        );
                });
            }

            $query->orderByDesc('sno');
        }

        $applicants = $query
            ->limit($limit)
            ->get();

        $total = $applicants->count();

        if ($total === 0) {

            return [
                'status' => true,
                'message' => 'No applicants available for AI matching.',
                'data' => [
                    'total' => 0,
                    'processed' => 0,
                    'success' => 0,
                    'failed' => 0,
                    'matched' => 0,
                    'unmatched' => 0,
                ]
            ];
        }

        $processed = 0;
        $success = 0;
        $failed = 0;
        $matched = 0;
        $unmatched = 0;

        /*
         * -----------------------------------------------------
         * Process in small controlled batches
         * -----------------------------------------------------
         */

        foreach (
            $applicants->chunk($batchSize)
            as $batch
        ) {

            foreach ($batch as $applicant) {

                $result = $this->matchApplicant(
                    (int) $applicant->sno
                );

                $processed++;

                if (!$result['status']) {

                    $failed++;

                    continue;
                }

                $success++;

                $roleIds = $result['data']['job_role_ids']
                    ?? [];

                if (!empty($roleIds)) {

                    $matched++;

                } else {

                    $unmatched++;
                }
            }
        }

        return [
            'status' => true,
            'message' => 'Bulk AI role matching completed.',
            'data' => [
                'total' => $total,
                'processed' => $processed,
                'success' => $success,
                'failed' => $failed,
                'matched' => $matched,
                'unmatched' => $unmatched,
            ]
        ];
    }

    /**
     * ---------------------------------------------------------
     * Active Company Roles
     * ---------------------------------------------------------
     */
    protected function getActiveRoles(): array
    {
        return $this->roleProfiles->getActiveProfiles();
    }

    /**
     * ---------------------------------------------------------
     * Clean Resume
     * ---------------------------------------------------------
     */
    protected function cleanResume(
        string $resume
    ): string {

        $resume = strip_tags(
            $resume
        );

        $resume = mb_convert_encoding(
            $resume,
            'UTF-8',
            'UTF-8'
        );

        $resume = preg_replace(
            '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/',
            '',
            $resume
        );

        $resume = preg_replace(
            '/[ \t]+/',
            ' ',
            $resume
        );

        $resume = preg_replace(
            "/\n{3,}/",
            "\n\n",
            $resume
        );

        return trim(
            mb_substr(
                $resume,
                0,
                (int) config(
                    'ai.max_resume_length',
                    6000
                )
            )
        );
    }

    /**
     * ---------------------------------------------------------
     * Decode Role IDs
     * ---------------------------------------------------------
     */
    protected function decodeRoleIds(
        mixed $value
    ): array {

        if (is_array($value)) {

            return array_values(
                array_map(
                    'intval',
                    $value
                )
            );
        }

        if (
            !is_string($value) ||
            trim($value) === ''
        ) {
            return [];
        }

        $decoded = json_decode(
            $value,
            true
        );

        return is_array($decoded)
            ? array_values(
                array_map(
                    'intval',
                    $decoded
                )
            )
            : [];
    }

    protected function attachRoleNames(
    array $matches
): array {

    if (empty($matches)) {
        return [];
    }

    $roleIds = collect(
        $matches
    )
        ->pluck('role_id')
        ->map(fn ($id) => (int) $id)
        ->values()
        ->toArray();

    $roles = collect($this->roleProfiles->getActiveProfiles())
        ->filter(fn ($role) => in_array((int) ($role['role_id'] ?? 0), $roleIds, true))
        ->keyBy(fn ($role) => (int) $role['role_id']);

    return collect(
        $matches
    )
        ->map(function ($match) use ($roles) {

            $roleId =
                (int) $match['role_id'];

            return [
                'role_id' =>
                    $roleId,

                'role_name' =>
                    $roles->get($roleId)['role_name']
                    ?? 'Unknown Role',

                'confidence' =>
                    $match['confidence'],

                'reason' =>
                    $match['reason'] ?? '',
            ];

        })
        ->values()
        ->toArray();
}
} 