<?php

namespace App\Services\CandidateServices;

class PromptBuilderService
{
    /**
     * =========================================================
     * SINGLE ROLE MATCHING
     * =========================================================
     */
    public function roleMatching(
        string $resume,
        array $roles
    ): string {

        return $this->buildRoleMatchingPrompt(
            [
                [
                    'applicant_id' => 'single',
                    'resume' => $resume
                ]
            ],
            $roles
        );
    }


    /**
     * =========================================================
     * BATCH ROLE MATCHING
     * =========================================================
     *
     * Dynamic production ATS prompt.
     *
     * IMPORTANT:
     *
     * No hard-coded company role names.
     *
     * Roles come entirely from:
     *
     * egc_recruitment_roles
     */
    public function batchRoleMatching(
        array $applicants,
        array $roles
    ): string {

        return $this->buildRoleMatchingPrompt(
            $applicants,
            $roles
        );
    }


    /**
     * =========================================================
     * BUILD MASTER ATS PROMPT
     * =========================================================
     */
    protected function buildRoleMatchingPrompt(
        array $applicants,
        array $roles
    ): string {

        /*
        |--------------------------------------------------------------------------
        | Normalize role data.
        |--------------------------------------------------------------------------
        */

        $normalizedRoles =
            $this->normalizeRoles(
                $roles
            );


        /*
        |--------------------------------------------------------------------------
        | Normalize applicant data.
        |--------------------------------------------------------------------------
        */

        $normalizedApplicants =
            $this->normalizeApplicants(
                $applicants
            );


        /*
        |--------------------------------------------------------------------------
        | Encode as JSON.
        |--------------------------------------------------------------------------
        */

        $rolesJson =
            json_encode(
                $normalizedRoles,
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES |
                JSON_PRETTY_PRINT
            );


        $applicantsJson =
            json_encode(
                $normalizedApplicants,
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES |
                JSON_PRETTY_PRINT
            );


        /*
        |--------------------------------------------------------------------------
        | Enterprise ATS Prompt
        |--------------------------------------------------------------------------
        */

        return <<<PROMPT

You are an enterprise-grade Applicant Tracking System (ATS) and senior recruitment assessment engine.

You are NOT a conversational assistant.

You are NOT allowed to invent company roles.

You are NOT allowed to assume that every applicant must match a role.

You are NOT allowed to force a candidate into the nearest-looking role.

Your output is consumed directly by a PHP application.

Therefore your entire response MUST be exactly one valid JSON object and nothing else.

============================================================
PRIMARY OBJECTIVE
============================================================

For EVERY applicant supplied in APPLICANTS:

1. Independently understand the candidate's resume.
2. Independently understand the supplied COMPANY ROLES.
3. Compare the candidate against the actual requirements represented by those roles.
4. Return every company role that has a genuinely defensible match.
5. Return zero roles when no supplied role is sufficiently suitable.
6. Produce a detailed recruiter-grade ATS analysis for every applicant.

The role matching decision must be evidence-driven.

The existence of a company role does NOT mean the applicant must be matched to it.

============================================================
MOST IMPORTANT MATCHING PRINCIPLE
============================================================

DO NOT START WITH:

"Which role name looks similar to this resume?"

Instead reason in this order:

STEP 1
Understand the candidate.

Identify:

- actual professional domain
- recent/current designation
- previous designations
- years of relevant experience
- seniority
- technical skills
- tools
- technologies
- frameworks
- programming languages
- platforms
- certifications
- education
- industries/domains
- responsibilities
- project experience
- measurable achievements
- leadership experience
- management experience
- functional/business skills

STEP 2
Understand each supplied company role.

Use the actual role data supplied in COMPANY ROLES.

Consider any available:

- role name
- role code
- department
- description
- responsibilities
- required skills
- preferred skills
- qualifications
- experience requirements
- seniority
- domain
- location-related information
- employment requirements

Do NOT assume missing role information.

If a field is not supplied, do not invent it.

STEP 3
Compare candidate evidence against the role.

STEP 4
Decide whether the candidate genuinely qualifies for that role.

STEP 5
Only then create a match.

============================================================
NO FORCED MATCHING
============================================================

This rule is critical.

If the applicant does not sufficiently match any supplied company role:

"matches": []

This is a VALID and EXPECTED result.

Do NOT select a role simply because:

- the job title sounds similar
- one keyword overlaps
- the candidate has generic computer skills
- the candidate has a degree related to the role
- the role is common in the company
- the role is the closest available option
- the applicant appears employable
- the applicant has transferable skills only
- the applicant has one technology used by the role

A role match requires meaningful evidence.

============================================================
MULTIPLE ROLE MATCHING
============================================================

An applicant MAY match multiple supplied company roles.

Do NOT artificially restrict the number of matches.

For example, if a candidate genuinely satisfies:

Role A
Role B
Role C

all three may be returned.

However:

DO NOT return multiple roles merely because they are vaguely related.

Each returned role must independently pass the matching standard.

Sort returned matches by confidence descending.

============================================================
ROLE ID INTEGRITY
============================================================

The role_id MUST come directly from the supplied COMPANY ROLES data.

NEVER:

- invent role IDs
- modify role IDs
- guess role IDs
- create role IDs
- use applicant IDs as role IDs
- use role names as role IDs

Only supplied role IDs are legal.

============================================================
EVIDENCE STANDARD
============================================================

A match should be based primarily on explicit evidence in the resume.

Strong evidence includes:

- explicit technology usage
- explicit responsibility
- explicit job designation
- explicit project experience
- explicit years of experience
- explicit domain experience
- explicit leadership responsibility
- explicit certification
- explicit measurable achievement
- repeated relevant skills
- recent relevant experience

Weak evidence includes:

- generic statements
- unrelated education
- vague transferable skills
- one isolated keyword
- inferred knowledge without evidence

Do not convert weak evidence into a high-confidence match.

============================================================
KEYWORD MATCHING RULE
============================================================

NEVER use simple keyword presence as the sole basis for role matching.

Example:

Resume contains:

"Java"

That does NOT automatically mean:

Java Developer

The resume must provide sufficient supporting evidence such as:

- Java development experience
- Java projects
- Spring/Spring Boot
- backend development
- APIs
- relevant responsibilities
- professional experience

Similarly:

"Excel"

does NOT automatically mean:

Accountant

or

Financial Analyst.

Context matters.

============================================================
TITLE MATCHING RULE
============================================================

Job titles are useful evidence but are NOT sufficient by themselves.

Example:

Resume title:

"Software Engineer"

Role:

"Senior Backend Developer"

Do NOT automatically match.

Check:

- backend experience
- technologies
- responsibilities
- seniority
- years of experience
- relevant projects

============================================================
SENIORITY RULE
============================================================

Consider seniority carefully.

Do not treat:

Intern

Junior

Mid-level

Senior

Lead

Manager

Director

as interchangeable.

A candidate can still be considered for a role with imperfect seniority only when the overall evidence supports it.

Confidence should decrease when the seniority mismatch is significant.

============================================================
EXPERIENCE RELEVANCE
============================================================

Do not count unrelated experience as directly relevant experience.

Example:

5 years of sales experience

does not equal:

5 years of software development experience.

Evaluate:

- total experience
- relevant experience
- recent experience
- domain relevance
- responsibility level

============================================================
SKILLS ANALYSIS
============================================================

Separate:

1. Clearly demonstrated skills
2. Mentioned but weakly supported skills
3. Missing required skills
4. Preferred skills
5. Transferable skills

Do not claim a skill is present merely because it is implied.

============================================================
ROLE REQUIREMENTS
============================================================

When a role contains explicit required skills or requirements:

Treat them as important evidence.

If multiple critical requirements are absent:

reduce confidence significantly.

If the candidate lacks a fundamental requirement necessary for the role:

the role should normally NOT be returned as a match.

However, do not reject a role merely because an optional/preferred skill is missing.

============================================================
MISSING ROLE DATA
============================================================

If the COMPANY ROLES data does not contain enough information to determine a requirement:

DO NOT invent the requirement.

Use only available role evidence.

============================================================
CONFIDENCE
============================================================

confidence is NOT a probability of employment.

It represents:

"How strongly does the supplied resume evidence support that this applicant is suitable for this specific company role?"

Use:

90-100
Exceptional and strongly evidenced match.

80-89
Strong match with minor gaps.

70-79
Good/credible match with noticeable but manageable gaps.

60-69
Borderline match.

0-59
Normally NOT a valid role match.

IMPORTANT:

Do NOT return a role merely to populate the matches array.

Normally only return roles with confidence >= 70.

A role below 70 should generally be excluded from matches.

============================================================
MATCH REASON
============================================================

Every returned role MUST have a specific reason.

Do NOT write generic text such as:

"Good match."

"Strong candidate."

"Skills match."

Instead identify actual evidence.

Example style:

"Candidate has 4+ years of Laravel and PHP backend development, REST API implementation and MySQL experience, closely aligning with the supplied role responsibilities."

The reason must be based on the supplied resume and supplied role data.

Do not invent facts.

============================================================
OVERALL ATS EVALUATION
============================================================

The ATS evaluation is independent from role matching.

Even if:

"matches": []

you MUST still generate a complete ai_response.

The candidate may have a strong resume but simply not fit any currently supplied company role.

============================================================
ATS SCORE DEFINITIONS
============================================================

overall_match_score

Overall quality and relevance of the candidate against the available company-role context.

ats_keyword_match_score

How effectively the resume contains relevant terminology and searchable evidence.

skills_alignment_score

How strongly the demonstrated skills align with relevant role requirements.

experience_relevance_score

How relevant the candidate's actual professional experience is.

impact_metrics_score

Quality and quantity of measurable achievements.

Look for:

- percentages
- revenue
- cost reduction
- growth
- performance improvements
- productivity improvements
- team size
- transaction volume
- customer metrics
- delivery metrics
- time savings
- measurable business outcomes

Do NOT penalize a candidate excessively when the resume naturally contains few measurable metrics, but identify the weakness.

role_responsibility_match_score

How closely the candidate's demonstrated responsibilities align with the supplied company-role responsibilities.

If no role is suitable, this score should reflect the relationship between the candidate and available role requirements rather than artificially producing a high score.

============================================================
MISSING KEYWORDS
============================================================

Identify meaningful keywords or competencies that are relevant to the strongest available role(s) but are absent or insufficiently evidenced in the resume.

Do NOT manufacture missing keywords.

Do NOT list every possible technology.

Only include useful recruiter-relevant gaps.

============================================================
STRENGTHS
============================================================

Return specific strengths supported by the resume.

Examples:

- strong backend development experience
- extensive Laravel experience
- demonstrated team leadership
- measurable revenue growth
- strong cloud deployment experience

Avoid generic statements.

============================================================
WEAKNESSES
============================================================

Identify genuine weaknesses such as:

- missing critical skill
- unclear career progression
- insufficient relevant experience
- weak achievement evidence
- vague responsibilities
- outdated technology exposure
- missing certification where relevant

Do not fabricate weaknesses.

============================================================
RESUME IMPROVEMENTS
============================================================

Give actionable recruiter-quality improvements.

Examples:

- add measurable outcomes
- clarify technology stack per project
- quantify team leadership
- remove outdated technologies
- make responsibilities achievement-focused
- improve professional summary
- clarify employment dates

============================================================
REWRITTEN BULLETS
============================================================

Rewrite weak resume statements into achievement-focused bullets ONLY when the original resume provides enough factual information.

Never invent:

- percentages
- revenue
- team size
- project results
- customers
- awards
- technologies

If the resume does not contain enough factual information for a safe rewrite, return fewer rewritten bullets rather than fabricating information.

============================================================
OPTIMIZED SUMMARY
============================================================

Create a concise professional summary based ONLY on the supplied resume.

Do not invent experience.

Do not invent skills.

Do not invent seniority.

Do not invent achievements.

============================================================
NO RESUME TEXT
============================================================

If an applicant has no usable resume text:

Return:

"matches": []

and produce a conservative ATS analysis.

Do not invent candidate information.

============================================================
DUPLICATES
============================================================

Do not return the same role_id more than once for an applicant.

============================================================
APPLICANT INTEGRITY
============================================================

Every supplied applicant MUST appear exactly once in results.

Never remove an applicant.

Never duplicate an applicant.

Maintain applicant_id exactly as supplied.

============================================================
JSON OUTPUT CONTRACT
============================================================

Return ONLY one JSON object.

No markdown.

No code fences.

No explanation.

No comments.

No text before JSON.

No text after JSON.

The response MUST start with:

{

The response MUST end with:

}

The top-level structure MUST be:

{
    "results": []
}

Each applicant MUST follow this structure:

{
    "applicant_id": "",
    "matches": [
        {
            "role_id": 0,
            "role_name": "",
            "confidence": 0,
            "reason": ""
        }
    ],
    "ai_response": {
        "overall_match_score": 0,
        "ats_keyword_match_score": 0,
        "skills_alignment_score": 0,
        "experience_relevance_score": 0,
        "impact_metrics_score": 0,
        "role_responsibility_match_score": 0,
        "missing_keywords": [],
        "strengths": [],
        "weaknesses": [],
        "resume_improvements": [],
        "rewritten_bullets": [],
        "optimized_summary": ""
    }
}

============================================================
IMPORTANT OUTPUT RULE
============================================================

The following example values are STRUCTURAL examples only.

Do NOT copy the role IDs.

Do NOT copy the scores.

Do NOT copy the example reasons.

Do NOT assume that the example roles exist.

Your actual output must be generated entirely from:

COMPANY ROLES

and

APPLICANTS.

============================================================
STRUCTURAL EXAMPLE
============================================================

Use the required JSON shape only. Do not copy role names, role IDs, scores, reasons, or any other candidate-specific example data.

{
  "results": [
    {
      "applicant_id": "123",
      "matches": [],
      "ai_response": {
        "overall_match_score": 0,
        "ats_keyword_match_score": 0,
        "skills_alignment_score": 0,
        "experience_relevance_score": 0,
        "impact_metrics_score": 0,
        "role_responsibility_match_score": 0,
        "missing_keywords": [],
        "strengths": [],
        "weaknesses": [],
        "resume_improvements": [],
        "rewritten_bullets": [],
        "optimized_summary": ""
      }
    }
  ]
}


    ]
}

============================================================
CRITICAL FINAL CHECK BEFORE RESPONDING
============================================================

Before generating the final JSON, internally verify:

1. Every applicant appears exactly once.
2. Every returned role_id exists in COMPANY ROLES.
3. No role was invented.
4. No role was selected only because of a keyword.
5. Every returned role has meaningful resume evidence.
6. Multiple roles are returned only when each independently qualifies.
7. Weak candidates are allowed to have matches: [].
8. No-match applicants still receive ai_response.
9. Confidence values are 0-100.
10. Matches are sorted by confidence descending.
11. Duplicate role IDs are removed.
12. No unsupported candidate facts were invented.
13. No unsupported achievements were invented.
14. The response is valid JSON.
15. There is absolutely no text outside the JSON object.

============================================================
COMPANY ROLES
============================================================

$rolesJson

============================================================
APPLICANTS
============================================================

$applicantsJson

============================================================
FINAL RESPONSE
============================================================

Return ONLY the JSON object.

PROMPT;
    }


    /**
     * =========================================================
     * NORMALIZE ROLE DATA
     * =========================================================
     *
     * Keep useful role information while avoiding
     * unnecessary database metadata.
     */
    protected function normalizeRoles(
        array $roles
    ): array {

        $output = [];


        foreach (
            $roles as $role
        ) {

            if (
                !is_array($role)
            ) {
                continue;
            }


            /*
            |--------------------------------------------------------------------------
            | Role ID is mandatory.
            |--------------------------------------------------------------------------
            */

            if (
                !isset(
                    $role['sno']
                )
            ) {
                continue;
            }


            $normalized = [

                'role_id' => (int) $role['sno'],

                'role_name' =>
                    $this->stringValue(
                        $role,
                        [
                            'role_name',
                            'name',
                            'designation',
                            'job_title'
                        ]
                    ),

                'role_code' =>
                    $this->stringValue(
                        $role,
                        [
                            'role_code',
                            'code'
                        ]
                    ),

                'department' =>
                    $this->stringValue(
                        $role,
                        [
                            'department',
                            'department_name'
                        ]
                    ),

                'description' =>
                    $this->stringValue(
                        $role,
                        [
                            'description',
                            'role_description',
                            'job_description'
                        ]
                    ),

                'responsibilities' =>
                    $this->value(
                        $role,
                        [
                            'responsibilities',
                            'job_responsibilities'
                        ]
                    ),

                'required_skills' =>
                    $this->value(
                        $role,
                        [
                            'required_skills',
                            'skills',
                            'mandatory_skills'
                        ]
                    ),

                'preferred_skills' =>
                    $this->value(
                        $role,
                        [
                            'preferred_skills',
                            'optional_skills'
                        ]
                    ),

                'experience' =>
                    $this->value(
                        $role,
                        [
                            'experience',
                            'experience_required',
                            'experience_years'
                        ]
                    ),

                'qualification' =>
                    $this->value(
                        $role,
                        [
                            'qualification',
                            'education',
                            'education_requirement'
                        ]
                    ),

                'seniority' =>
                    $this->value(
                        $role,
                        [
                            'seniority',
                            'level'
                        ]
                    ),

                'domain' =>
                    $this->value(
                        $role,
                        [
                            'domain',
                            'industry'
                        ]
                    )

            ];


            /*
            |--------------------------------------------------------------------------
            | Remove empty fields.
            |--------------------------------------------------------------------------
            */

            $normalized =
                array_filter(
                    $normalized,
                    function ($value) {

                        if (
                            is_array($value)
                        ) {

                            return !empty(
                                $value
                            );
                        }

                        return trim(
                            (string) $value
                        ) !== '';
                    }
                );


            $output[] =
                $normalized;
        }


        return $output;
    }


    /**
     * =========================================================
     * NORMALIZE APPLICANTS
     * =========================================================
     */
    protected function normalizeApplicants(
        array $applicants
    ): array {

        $output = [];


        foreach (
            $applicants as $applicant
        ) {

            if (
                !is_array($applicant)
            ) {
                continue;
            }


            $id =
                $applicant['sno']
                ?? $applicant['applicant_id']
                ?? null;


            if (
                $id === null
            ) {
                continue;
            }


            $resume =
                trim(
                    (string) (
                        $applicant['resume']
                        ?? ''
                    )
                );


            $output[] = [

                'applicant_id' =>
                    (string) $id,

                'resume' =>
                    mb_substr(
                        $resume,
                        0,
                        5000
                    )

            ];
        }


        return $output;
    }


    /**
     * =========================================================
     * FIND STRING FIELD
     * =========================================================
     */
    protected function stringValue(
        array $data,
        array $keys
    ): string {

        foreach (
            $keys as $key
        ) {

            if (
                isset(
                    $data[$key]
                ) &&
                !is_array(
                    $data[$key]
                )
            ) {

                $value =
                    trim(
                        (string)
                        $data[$key]
                    );


                if (
                    $value !== ''
                ) {

                    return $value;
                }
            }
        }


        return '';
    }


    /**
     * =========================================================
     * FIND ANY FIELD
     * =========================================================
     */
    protected function value(
        array $data,
        array $keys
    ): mixed {

        foreach (
            $keys as $key
        ) {

            if (
                isset(
                    $data[$key]
                )
            ) {

                return $data[$key];
            }
        }


        return null;
    }


    /**
     * =========================================================
     * RESUME SUMMARY
     * =========================================================
     */
    public function resumeSummary(
        string $resume
    ): string {

        $resume =
            $this->limitText(
                $resume,
                6000
            );


        return <<<PROMPT
You are an enterprise recruitment ATS.

Analyze the supplied resume.

Do not invent information.

Return ONLY valid JSON.

{
    "summary":"",
    "experience_years":"",
    "education":"",
    "strengths":[]
}

Resume:

$resume
PROMPT;
    }


    /**
     * =========================================================
     * SKILL EXTRACTION
     * =========================================================
     */
    public function skillExtraction(
        string $resume
    ): string {

        $resume =
            $this->limitText(
                $resume,
                6000
            );


        return <<<PROMPT
You are an enterprise recruitment ATS.

Extract skills explicitly supported by the resume.

Separate technical and soft skills.

Do not infer unsupported skills.

Return ONLY valid JSON.

{
    "technical_skills":[],
    "soft_skills":[]
}

Resume:

$resume
PROMPT;
    }


    /**
     * =========================================================
     * EXPERIENCE EXTRACTION
     * =========================================================
     */
    public function experienceExtraction(
        string $resume
    ): string {

        $resume =
            $this->limitText(
                $resume,
                6000
            );


        return <<<PROMPT
You are an enterprise recruitment ATS.

Extract professional experience explicitly present in the resume.

Do not invent companies, dates, designations or skills.

Return ONLY valid JSON.

{
    "experience":[
        {
            "company":"",
            "designation":"",
            "duration":"",
            "skills":[]
        }
    ]
}

Resume:

$resume
PROMPT;
    }


    /**
     * =========================================================
     * INTERVIEW QUESTIONS
     * =========================================================
     */
    public function interviewQuestions(
        string $resume,
        string $role
    ): string {

        $resume =
            $this->limitText(
                $resume,
                6000
            );


        $role =
            $this->limitText(
                $role,
                3000
            );


        return <<<PROMPT
You are a senior technical recruiter.

Generate 10 interview questions based ONLY on the supplied resume and role.

Do not invent candidate experience.

Return ONLY valid JSON.

{
    "questions":[]
}

ROLE:

$role

RESUME:

$resume
PROMPT;
    }


    /**
     * =========================================================
     * RESUME SCORE
     * =========================================================
     */
    public function resumeScore(
        string $resume
    ): string {

        $resume =
            $this->limitText(
                $resume,
                6000
            );


        return <<<PROMPT
You are an enterprise ATS resume quality evaluator.

Score the resume based on evidence, clarity, completeness and recruiter usefulness.

Do not invent information.

Return ONLY valid JSON.

{
    "score":0,
    "remarks":""
}

Resume:

$resume
PROMPT;
    }


    /**
     * =========================================================
     * LIMIT TEXT
     * =========================================================
     */
    protected function limitText(
        string $text,
        int $length
    ): string {

        $text =
            preg_replace(
                '/\s+/u',
                ' ',
                $text
            );


        return mb_substr(
            trim($text),
            0,
            $length
        );
    }
}