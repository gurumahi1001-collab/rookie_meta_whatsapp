CANDIDATE MANAGEMENT / ATS PRODUCTION PATCH
===========================================

Purpose
-------
This patch restores the missing candidate profile and bulk ATS analysis UI on the
new Candidate Management page, wires candidate intake to the current verified
resume extraction path, persists ATS role-match reports, and retains the existing
private Wasabi upload service.

Changed files
-------------
app/Http/Controllers/hr_management/hr_recruiter/candidate_management/CandidateManagement.php
routes/web.php
resources/views/content/hr_management/hr_recruiter/candidate_management/index.blade.php
resources/views/content/hr_management/hr_recruiter/candidate_management/candidate_list.blade.php
resources/views/content/hr_management/hr_recruiter/candidate_management/partials/ats_candidate_modals.blade.php
database/sql/candidate_ats_analysis.sql

What changes
------------
1. Both Candidate Management add-candidate forms in this patch post to the
   save_candidate_data route, which uses the verified candidate intake flow.
   It validates the resume extraction token against both the exact file SHA-256 and
   the current session. Expired/mismatched tokens use the existing resume parsing
   services rather than the missing CandidateServices\\ResumeExtractionService.
2. Selected recruitment roles are validated and saved into egc_applicant.job_role_id.
   The ATS-generated role suggestions/evidence are stored separately in the ATS tables.
3. The resume continues through the current local/Google Drive flow and is also sent
   to WasabiResumeStorageService::storePath(). Wasabi upload remains private and is
   checksum-verified by that service. Existing local/Drive content is not deleted.
4. ATS report and role evidence are stored in egc_applicant_ats_role_analyses and
   egc_applicant_ats_role_matches. Legacy egc_applicant.ai_response is not overwritten.
5. Candidate profile modal shows candidate details, latest saved role ranking,
   matched evidence, parser/extraction provenance, and authorized resume-open link.
   Any historical egc_applicant.ai_response is also displayed in a separate legacy
   resume-quality tab; the new pipeline does not overwrite or fabricate that field.
6. Bulk ATS analysis processes a small number of candidates per web request and
   saves a separate report for each. It is browser-initiated, not a background queue;
   the user should keep the page open until the run completes.

Deployment
----------
1. Back up the database and deploy the changed PHP/Blade files.
2. Review database/sql/candidate_ats_analysis.sql and run it on the application DB.
   It creates only the two ATS analysis tables when they do not already exist.
   It does not modify egc_applicant or the existing recruitment-role tables.
3. Confirm the existing egc_applicant_resume_extractions table is present. The
   candidate intake flow already uses ApplicantResumeExtractionModel and expects it.
4. Confirm Wasabi config('wasabi.enabled'), access_key, secret_key, bucket, endpoint
   and region are supplied by your deployment config/.env. Also confirm the existing
   ERP common-storage SQL is installed: WasabiResumeStorageService requires
   egc_applicant_file_storage, egc_applicant_storage_audit,
   egc_storage_feature_settings, egc_storage_objects and egc_storage_audit.
   The uploaded ZIP did not include database/sql/erp_common_storage.sql, so this
   patch does not recreate or modify those existing shared-storage tables.
5. Confirm the egc_storage_feature_settings entry for feature_key 'applicant.resume'
   is enabled, private_access is enabled, and driver is 'wasabi' when that feature
   registry is used by the deployment.
6. Clear Laravel caches after deployment (config, route and view caches) and verify:
   - Add Candidate saves a candidate and extraction snapshot.
   - The response reports resume_storage='wasabi_verified' after a successful upload.
   - Candidate profile opens the newest persisted ATS analysis and evidence.
   - Bulk analysis is tested with a small batch before processing the full backlog.

Important behavior / honesty
----------------------------
The role matcher in the supplied code is CandidateJobRoleMatchingService, a local,
explainable evidence-based matcher. It is not an LLM-generated hiring decision.
The archive's Hugging Face inference adapter is limited to candidate-name extraction;
the older save method's full ATS LLM prompt is commented out, and the ATS queue /
evaluator controllers referenced by the old bulk UI are not included in the ZIP.
Therefore this patch persists the current role-evidence report and displays any
pre-existing ai_response, but does not claim to generate a new LLM resume-quality
report. That separate LLM evaluator must be supplied/configured before enabling it.
Candidate name extraction may use the configured AI-first service. The report labels
the ATS engine accurately and includes its version, score, role evidence and review
flags. Missing ATS tables are reported by the UI/API instead of silently claiming
that a report was saved.

The ZIP did not include the live database, migrations, composer vendor directory,
Wasabi shared-storage SQL, or several separately referenced AI/storage controllers.
The PHP files were syntax-checked, but deployment database connectivity, external
Wasabi credentials, and browser interaction could not be executed in this sandbox.
