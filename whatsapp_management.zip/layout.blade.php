@extends('layouts.contentNavbarLayout')

@section('title', 'WhatsApp Management')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id;
$user_data=$helper->get_staff_data($user_id);
@endphp



@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">

<div class="wa-app" id="waApp" data-section="{{ $section }}" data-kind="{{ $kind }}" data-default-branch="{{ $defaultBranchId }}">
  <aside class="wa-sidebar">

    <div class="wa-brand">
      <span class="wa-brand-mark">WA</span>
      <div>
        <strong>WhatsApp</strong>
        <small>Management Center</small>
      </div>
    </div>

    <div class="wa-side-scroll">
      <a class="wa-nav {{ $section === 'dashboard' ? 'active' : '' }}" href="{{ url('/wa-management') }}">
        <span>▦</span> Overview
      </a>

      <div class="wa-nav-group-label">MESSAGING</div>
      <div class="wa-nav-parent">Chats</div>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'lead' ? 'active' : '' }}" data-wa-feature="lead_chat" href="{{ url('/wa-management/chats/lead') }}">Lead chat</a>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'customer' ? 'active' : '' }}" data-wa-feature="customer_chat" href="{{ url('/wa-management/chats/customer') }}">Customer chat</a>
      <a class="wa-subnav {{ $section === 'chat' && $kind === 'common' ? 'active' : '' }}" data-wa-feature="common_chat" href="{{ url('/wa-management/chats/common') }}">Common chat</a>
      <a class="wa-subnav {{ $section === 'groups' ? 'active' : '' }}" data-wa-feature="custom_group_chat" href="{{ url('/wa-management/groups') }}">Custom audiences</a>
      <a class="wa-subnav {{ $section === 'broadcast' ? 'active' : '' }}" data-wa-feature="broadcast_channel" href="{{ url('/wa-management/broadcast') }}">Broadcast manager</a>
      <a class="wa-nav {{ $section === 'templates' ? 'active' : '' }}" href="{{ url('/wa-management/templates') }}">
        <span>▤</span> Templates
      </a>
      <a class="wa-nav {{ $section === 'automation' ? 'active' : '' }}" href="{{ url('/wa-management/automation') }}">
        <span>⤷</span> Automation rules
      </a>
      <a class="wa-nav {{ $section === 'campaigns' ? 'active' : '' }}" data-wa-feature="bulk_campaigns" href="{{ url('/wa-management/campaigns') }}">
        <span>➤</span> Bulk campaigns
      </a>
      <a class="wa-nav {{ $section === 'logs' ? 'active' : '' }}" href="{{ url('/wa-management/logs') }}">
        <span>≡</span> Message logs
      </a>

      <div class="wa-nav-group-label">CONTROL</div>
      <a class="wa-nav {{ $section === 'consent' ? 'active' : '' }}" href="{{ url('/wa-management/consent') }}">
        <span>✓</span> Consent registry
      </a>
      <a class="wa-nav {{ $section === 'setup' ? 'active' : '' }}" href="{{ url('/wa-management/setup') }}">
        <span>⚙</span> API & menu setup
      </a>
      <a class="wa-nav {{ $section === 'calling' ? 'active' : '' }}" data-wa-feature="calling" href="{{ url('/wa-management/calling') }}">
        <span>☎</span> Calling capability
      </a>
    </div>

    <div class="wa-side-foot">
      <span class="wa-status-dot"></span> Outbox-first messaging
      <br>
      <small>Shared ERP profile • branch-scoped CRM</small>
    </div>

  </aside>
  
  <main class="wa-main">
    <header class="wa-topbar">
      <div>
        <div class="wa-eyebrow">ERP / WHATSAPP</div>
        <div class="wa-top-title">{{ ucfirst(str_replace('_', ' ', $section === 'chat' ? $kind . ' chat' : $section)) }}</div>
      </div>
      <div class="wa-top-actions">
        <span id="waBranchControl">
          <label for="waBranchId">CRM branch</label>
          <input id="waBranchId" type="number" min="1" value="{{ $defaultBranchId }}" class="wa-branch-input">
        </span>
        <span id="waGlobalState" class="wa-state-pill">Checking status…</span>
        <button type="button" id="waGlobalKill" class="wa-btn wa-btn-danger">Pause all sending</button>
      </div>
    </header>
    <div class="wa-body">
      @include('content.whatsapp_management.pages.' . $section)
    </div>
    <div id="waToast" class="wa-toast" role="status" aria-live="polite">

    </div>
  </main>

</div>

<style>
  .wa-app{
    display:flex;
    min-height:calc(100vh - 120px);
    margin:-.5rem 0 0;
    background:#f5f7f9;
    border:1px solid #e4e9ef;
    border-radius:16px;
    overflow:hidden;
    color:#1c2b33;
    font-family:inherit;
    --wa-green:#0b806c;
    --wa-green-dark:#075e54;
    --wa-soft:#e8f5ef;
    --wa-line:#e4e9ed;
    --wa-muted:#71818a;
  }
  .wa-sidebar{
    width:242px;
    flex:0 0 242px;
    background:#fff;
    border-right:1px solid var(--wa-line);
    display:flex;
    flex-direction:column;
  }
  .wa-brand{
    display:flex;
    align-items:center;
    gap:11px;
    padding:23px 19px 21px;
    border-bottom:1px solid #f0f2f3;
  }
  .wa-brand-mark{
    width:38px;
    height:38px;
    border-radius:13px;
    background:var(--wa-green);
    color:#fff;
    display:grid;
    place-items:center;
    font-size:12px;
    font-weight:800;
    letter-spacing:.04em;
  }
  .wa-brand strong{
    display:block;
    font-size:15px;
    color:#192f36;
  }
  .wa-brand small{
    display:block;
    color:#809096;
    font-size:10px;
    margin-top:2px;
    letter-spacing:.06em;
  }
  .wa-side-scroll{
    padding:13px 11px;
    flex:1;
    overflow:auto;
  }
  .wa-nav,.wa-subnav{
    display:flex;
    align-items:center;
    gap:11px;
    color:#506169;
    text-decoration:none!important;
    border-radius:9px;
    padding:10px 12px;
    margin:2px 0;
    font-size:12px;
    font-weight:600;
    transition:.15s;
  }
  .wa-nav span{
    width:17px;
    text-align:center;
    font-size:16px;
    color:#789096;
  }
  .wa-nav:hover,.wa-subnav:hover{
    background:#f4f8f7;
    color:var(--wa-green-dark);
  }
  .wa-nav.active,.wa-subnav.active{
    background:#e8f6ef;
    color:#087b63;
  }
  .wa-nav.active span{
    color:#087b63;
  }
  .wa-nav-group-label{
    color:#9aabad;
    font-size:9px;
    letter-spacing:.14em;
    font-weight:800;
    margin:22px 12px 8px;
  }
  .wa-nav-parent{
    padding:8px 12px 2px;
    font-size:11px;
    font-weight:800;
    color:#77868b;
  }
  .wa-subnav{
    margin-left:12px;
    padding:9px 10px;
    font-size:11px;
    border-left:2px solid #e8eeee;
    border-radius:0 8px 8px 0;
  }
  .wa-side-foot{
    padding:14px 17px;
    border-top:1px solid var(--wa-line);
    font-size:10px;
    line-height:1.8;
    color:#53676b;
  }
  .wa-status-dot{
    display:inline-block;
    width:7px;
    height:7px;
    background:#1da875;
    border-radius:50%;
    margin-right:6px;
  }
  .wa-side-foot small{
    color:#96a2a5;
  }
  .wa-main{
    min-width:0;
    flex:1;
    display:flex;
    flex-direction:column;
  }
  .wa-topbar{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
    background:#fff;
    border-bottom:1px solid var(--wa-line);
    padding:15px 22px;
  }
  .wa-eyebrow{
    font-size:9px;
    letter-spacing:.15em;
    color:#9aa8ac;
    font-weight:800;
    margin-bottom:4px;
  }
  .wa-top-title{
    font-size:18px;
    font-weight:800;
    color:#1f343b;
  }
  .wa-top-actions{
    display:flex;
    align-items:center;
    gap:9px;
    flex-wrap:wrap;
  }
  .wa-top-actions label{
    font-size:10px;
    color:#728389;
    font-weight:700;
  }
  .wa-branch-input{
    width:78px!important;
    min-width:0!important;
    padding:7px 8px!important;
    border:1px solid #dbe4e6!important;
    border-radius:8px!important;
    font-size:12px!important;
  }
  .wa-state-pill{
    font-size:10px;
    padding:7px 10px;
    border-radius:99px;
    background:#f1f5f5;
    color:#5b6d71;
    font-weight:800;
  }
  .wa-state-pill.paused{
    background:#fff0e8;
    color:#a8471a;
  }
  .wa-btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    padding:9px 13px;
    border-radius:9px;
    border:1px solid #d9e2e4;
    background:#fff;
    color:#41575d;
    font-size:11px;
    font-weight:800;
    cursor:pointer;
    line-height:1.2;
  }
  .wa-btn:hover{
    filter:brightness(.98);
  }
  .wa-btn-primary{
    background:var(--wa-green);
    border-color:var(--wa-green);
    color:#fff;
  }
  .wa-btn-soft{
    background:#eef8f3;
    border-color:#d4eee2;
    color:#06765e;
  }

  .wa-btn-danger{
    background:#fff5f0;
    border-color:#ffdcca;
    color:#a84522;
  }

  .wa-btn:disabled{
    opacity:.4;
    cursor:not-allowed;
  }

  .wa-body{
    padding:22px;
    flex:1;
    min-width:0;
  }

  .wa-page-head{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:15px;
    margin-bottom:18px;
  }

  .wa-page-head h2{
    font-size:17px;
    font-weight:800;
    margin:0 0 5px;
    color:#243940;
  }

  .wa-page-head p{
    font-size:11px;
    color:#7e8e93;
    margin:0;
    max-width:740px;
  }

  .wa-card{
    background:#fff;
    border:1px solid #e6ebed;
    border-radius:13px;
    padding:18px;
    margin-bottom:15px;
    box-shadow:0 2px 8px rgba(18,48,55,.025);
  }

  .wa-card-title{
    font-size:12px;
    font-weight:800;
    color:#2e454c;
    margin-bottom:13px;
  }

  .wa-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:13px;
  }

  .wa-grid-2{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:14px;
  }

  .wa-stat{
    background:#fff;
    border:1px solid #e5ebed;
    border-radius:13px;
    padding:16px;
    min-width:0;
  }

  .wa-stat-label{
    color:#809096;
    font-size:10px;
    font-weight:700;
    margin-bottom:9px;
  }

  .wa-stat-value{
    font-size:24px;
    font-weight:800;
    color:#20363e;
  }

  .wa-stat-note{
    font-size:10px;
    color:#98a4a7;
    margin-top:5px;
  }
  .wa-field{
    margin-bottom:13px;
  }

  .wa-field label{
    display:block;
    font-size:10px;
    font-weight:800;
    color:#62757a;
    margin-bottom:6px;
  }

  .wa-field input,
  .wa-field select,
  .wa-field textarea,
  .wa-search{
    width:100%;
    border:1px solid #dfe7e9;
    border-radius:8px;
    padding:10px 11px;
    font:inherit;
    font-size:11px;
    color:#253e45;
    background:#fff;
  }

  .wa-field textarea{
    min-height:90px;
    resize:vertical;
  }

  .wa-field small{
    display:block;
    color:#8d9a9e;
    font-size:9px;
    margin-top:5px;
    line-height:1.6;
  }

  .wa-row{
    display:flex;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
  }

  .wa-table-wrap{
    width:100%;
    overflow:auto;
  }

  .wa-table{
    width:100%;
    border-collapse:collapse;
    font-size:11px;
  }

  .wa-table th{
    text-align:left;
    background:#f7f9fa;
    color:#819197;
    font-size:9px;
    text-transform:uppercase;
    letter-spacing:.05em;
    padding:11px 10px;
    white-space:nowrap;
  }

  .wa-table td{
    padding:11px 10px;
    border-bottom:1px solid #eff2f3;
    color:#53676d;
    vertical-align:middle;
  }

  .wa-table td strong{
    color:#273e45;
  }

  .wa-muted{
    color:#89979b;
  }

  .wa-badge{
    display:inline-block;
    padding:4px 7px;
    border-radius:99px;
    font-size:9px;
    font-weight:800;
    background:#eef2f3;
    color:#62757a;
  }

  .wa-badge.ok{
    background:#e7f7ee;
    color:#087753;
  }

  .wa-badge.warn{
    background:#fff4de;
    color:#a56700;
  }

  .wa-badge.bad{
    background:#ffeded;
    color:#b42318;
  }

  .wa-empty{
    padding:27px;
    text-align:center;
    color:#90a0a4;
    font-size:11px;
  }

  .wa-inline-note{
    border:1px solid #ddeae5;
    background:#f5fbf8;
    border-radius:9px;
    padding:12px 14px;
    color:#527168;
    font-size:10px;
    line-height:1.7;
  }

  .wa-inline-warning{
    border-color:#f3dfc9;
    background:#fff9f2;
    color:#91673a;
  }

  .wa-toggle{
    display:flex;
    align-items:center;
    gap:8px;
    font-size:11px;
    color:#52696e;
  }

  .wa-toggle input{
    accent-color:var(--wa-green);
  }

  .wa-toast{
    position:fixed;
    bottom:22px;
    right:24px;
    z-index:99999;
    display:none;
    max-width:440px;
    background:#193b3d;
    color:#fff;
    padding:13px 17px;
    border-radius:10px;
    font-size:11px;
    box-shadow:0 10px 30px #1233;
  }

  .wa-chat-shell{
    display:grid;
    grid-template-columns:minmax(230px,31%) minmax(0,1fr);
    height:min(690px,calc(100vh - 225px));
    min-height:480px;
    border:1px solid #e1e8ea;
    border-radius:13px;
    overflow:hidden;
    background:#fff;
  }

  .wa-chat-left{
    border-right:1px solid var(--wa-line);
    display:flex;
    flex-direction:column;
    min-width:0;
  }

  .wa-chat-listhead{
    padding:14px;
    border-bottom:1px solid #edf0f1;
  }

  .wa-chat-contact-list{
    overflow:auto;
    flex:1;
  }

  .wa-chat-contact{
    display:flex;
    gap:10px;
    align-items:center;
    padding:13px;
    border-bottom:1px solid #f0f2f3;
    cursor:pointer;
  }

  .wa-chat-contact:hover,
  .wa-chat-contact.selected{
    background:#f1f8f5;
  }

  .wa-avatar{
    width:36px;
    height:36px;
    flex:0 0 36px;
    display:grid;
    place-items:center;
    border-radius:50%;
    background:#dfeee7;
    color:#087b63;
    font-weight:800;
    font-size:12px;
  }

  .wa-contact-meta{
    min-width:0;
    flex:1;
  }

  .wa-contact-meta strong{
    display:block;
    color:#2b4249;
    font-size:11px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }

  .wa-contact-meta small{
    display:block;
    color:#8b999d;
    font-size:9px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    margin-top:4px;
  }

  .wa-chat-window{
    display:flex;
    flex-direction:column;
    min-width:0;
    background:#f4f7f7;
  }

  .wa-chat-window-head{
    padding:13px 16px;
    background:#fff;
    border-bottom:1px solid #e6edef;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:10px;
  }
  .wa-chat-window-head strong{
    display:block;
    color:#2d444a;
    font-size:12px;
  }
  .wa-chat-window-head small{
    color:#7e9094;
    font-size:9px;
  }

  .wa-message-list{
    padding:18px;
    overflow:auto;
    flex:1;
    background-color:#f5f8f7;
    background-image:radial-gradient(#e1e9e5 .7px,transparent .7px);
    background-size:14px 14px;
  }

  .wa-message-row{
    display:flex;
    margin:8px 0;
  }

  .wa-message-row.outbound{
    justify-content:flex-end;
  }

  .wa-message-bubble{
    max-width:min(75%,520px);
    background:#fff;
    border:1px solid #e6ece8;
    border-radius:11px 11px 11px 3px;
    padding:9px 11px;
    color:#3f565c;
    font-size:11px;
    line-height:1.6;
    white-space:pre-wrap;
    overflow-wrap:anywhere;
    box-shadow:0 1px 2px #1931;
  }

  .wa-message-row.outbound .wa-message-bubble{
    background:#dff5e7;
    border-color:#d5eee0;
    border-radius:11px 11px 3px 11px;
  }

  .wa-message-status{
    display:block;
    text-align:right;
    font-size:8px;
    color:#8fa19b;
    margin-top:3px;
  }
  .wa-chat-compose{
    padding:12px;
    background:#fff;
    border-top:1px solid #e1e9e7;
    display:flex;
    gap:8px;
    align-items:flex-end;
  }

  .wa-chat-compose textarea{
    flex:1;
    min-height:39px;
    max-height:120px;
    border:1px solid #dfe8e5;
    border-radius:10px;
    padding:10px 12px;
    font-size:11px;
    resize:vertical;
  }

  .wa-window-closed{
    padding:9px 14px;
    background:#fff2dc;
    color:#855e24;
    font-size:10px;
    border-top:1px solid #f2e3c8;
  }

  .wa-feature-disabled{
    padding:28px;
    background:#fff;
    border:1px dashed #d9e2e3;
    border-radius:13px;
    text-align:center;
    color:#75878c;
    font-size:12px;
  }

  .wa-check-grid{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:12px;
  }
  .wa-check-card{
    border:1px solid #e5ebed;
    border-radius:9px;
    padding:12px;
  }

  .wa-check-card strong{
    font-size:11px;
    color:#43585e;
    display:block;
    margin-bottom:5px;
  }

  .wa-check-card small{
    font-size:9px;
    color:#8a999e;
    display:block;
    line-height:1.6;
  }

  .wa-code{
    font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
    background:#f5f7f8;
    border-radius:5px;
    padding:2px 5px;
    font-size:10px;
    color:#475e65;
  }

  @media(max-width:1150px){
    .wa-sidebar{
      width:200px;
      flex-basis:200px;
    }

    .wa-grid{
      grid-template-columns:repeat(2,minmax(0,1fr));
    }
    .wa-topbar{
      align-items:flex-start;
      flex-direction:column;
    }
    .wa-top-actions{
      width:100%;
    }

  }
  @media(max-width:760px){
    .wa-app{
      display:block;
      overflow:visible;
    }
    .wa-sidebar{
      width:100%;
      border-right:0;
      border-bottom:1px solid var(--wa-line);
    }
    .wa-brand{
      padding:14px;
    }
    .wa-side-scroll{
      display:flex;
      flex-wrap:wrap;
      padding:8px;
    }
    .wa-nav,.wa-subnav{
      margin:3px;
      padding:8px 10px;
    }
    .wa-nav-group-label,.wa-nav-parent,.wa-side-foot{
      display:none;
    }
    .wa-subnav{
      border-left:0;
      margin-left:0;
    }
    .wa-body{
      padding:12px;
    }
    .wa-chat-shell{
      grid-template-columns:1fr;
      height:auto;
      min-height:600px;
    }
    .wa-chat-left{
      max-height:240px;
    }
    .wa-chat-window{
      min-height:430px;
    }
    .wa-grid-2,.wa-check-grid{
      grid-template-columns:1fr;
    }
    .wa-page-head{
      flex-direction:column;
    }
    .wa-topbar{
      padding:13px;
    }
    .wa-chat-window-head{
      align-items:flex-start;
    }
    .wa-message-bubble{
      max-width:92%;
    }
  }
</style>



<script>
(function ($) {
  'use strict';

  var root = document.getElementById('waApp');

  window.WA = window.WA || {};

  window.WA.branch = function () {
    return parseInt(
      $('#waBranchId').val() || root.dataset.defaultBranch || '1',
      10
    );
  };

  window.WA.url = function (path) {
    return `/wa-management/api${path}`;
  };

  // Fetch-backed request helper. Keep the existing done/fail/always interface
  // so the page's current event handlers do not need to change.
  window.WA.request = function (url, options) {
    var callbacks = {
      done: [],
      fail: [],
      always: []
    };
    var state = 'pending';
    var settledValue;
    var request;

    function invoke(callbackList, value) {
      callbackList.slice().forEach(function (callback) {
        callback(value);
      });
    }

    request = {
      done: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state === 'resolved') {
          callback(settledValue);
        } else if (state === 'pending') {
          callbacks.done.push(callback);
        }

        return request;
      },
      fail: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state === 'rejected') {
          callback(settledValue);
        } else if (state === 'pending') {
          callbacks.fail.push(callback);
        }

        return request;
      },
      always: function (callback) {
        if (typeof callback !== 'function') {
          return request;
        }

        if (state !== 'pending') {
          callback(settledValue);
        } else {
          callbacks.always.push(callback);
        }

        return request;
      }
    };

    Promise.resolve()
      .then(function () {
        return fetch(url, options);
      })
      .then(async function (response) {
        var responseData = null;

        if (response.status !== 204) {
          try {
            responseData = await response.json();
          } catch (error) {
            if (response.ok) {
              throw error;
            }
          }
        }

        if (!response.ok) {
          var requestError = new Error(
            (responseData && responseData.message) ||
              `Request failed with status ${response.status}.`
          );

          requestError.responseJSON = responseData;
          requestError.status = response.status;
          throw requestError;
        }

        return responseData;
      })
      .then(
        function (responseData) {
          state = 'resolved';
          settledValue = responseData;
          invoke(callbacks.done, responseData);
          invoke(callbacks.always, responseData);
        },
        function (error) {
          state = 'rejected';
          settledValue = error;
          invoke(callbacks.fail, error);
          invoke(callbacks.always, error);
        }
      );

    return request;
  };

  window.WA.api = function (path, method, data) {
    data = data || {};

    var requestMethod = (method || 'GET').toUpperCase();

    if (requestMethod !== 'GET') {
      data._token =
        $('meta[name="csrf-token"]').attr('content') ||
        $('input[name="_token"]').val();
    }

    if (typeof data.branch_id === 'undefined') {
      data.branch_id = window.WA.branch();
    }

    var requestUrl = window.WA.url(path);
    var requestOptions = {
      method: requestMethod,
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') || ''
      }
    };

    if (requestMethod === 'GET') {
      var queryString = new URLSearchParams(data).toString();

      if (queryString) {
        requestUrl += `${requestUrl.indexOf('?') === -1 ? '?' : '&'}${queryString}`;
      }
    } else {
      requestOptions.headers['Content-Type'] =
        'application/x-www-form-urlencoded; charset=UTF-8';
      requestOptions.body = new URLSearchParams(data).toString();
    }

    return window.WA.request(requestUrl, requestOptions);
  };

  window.WA.esc = function (value) {
    return $('<div>').text(value == null ? '' : String(value)).html();
  };

  window.WA.toast = function (message, bad) {
    var element = $('#waToast');

    element
      .stop(true, true)
      .text(message || 'Done')
      .css('background', bad ? '#812c25' : '#193b3d')
      .fadeIn(120);

    setTimeout(function () {
      element.fadeOut(250);
    }, 4200);
  };

  window.WA.status = function (status) {
    status = status || {};

    $('#waGlobalState')
      .text(
        status.global_kill_switch
          ? 'All sending paused'
          : status.profile_enabled
            ? 'Sending enabled'
            : 'Shared profile paused'
      )
      .toggleClass(
        'paused',
        !!status.global_kill_switch || !status.profile_enabled
      );

    $('#waGlobalKill')
      .text(
        status.global_kill_switch
          ? 'Resume global sending'
          : 'Pause all sending'
      )
      .toggleClass('wa-btn-danger', !status.global_kill_switch)
      .toggleClass('wa-btn-soft', !!status.global_kill_switch)
      .data('enabled', !status.global_kill_switch);
  };

  function refreshHeader() {
    window.WA.api('/overview', 'GET', {})
      .done(function (response) {
        if (response && response.ok) {
          window.WA.status(response.data);
        }
      })
      .fail(function () {
        $('#waGlobalState').text('Status unavailable');
      });
  }

  if (
    !(
      root.dataset.section === 'chat' &&
      ['lead', 'customer'].indexOf(root.dataset.kind) >= 0
    )
  ) {
    $('#waBranchControl').hide();
  }

  $('#waBranchId').on('change', function () {
    var url = new URL(window.location.href);

    url.searchParams.set('branch_id', window.WA.branch());
    window.location.href = url.toString();
  });

  $('#waGlobalKill').on('click', function () {
    var button = $(this);

    button.prop('disabled', true);

    window.WA.api('/kill-switch', 'POST', {
      enabled: button.data('enabled')
    })
      .done(function (response) {
        window.WA.toast(response.message);
        refreshHeader();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Unable to change global switch.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  window.WA.api('/features', 'GET', {})
    .done(function (response) {
      if (!response || !response.data) {
        return;
      }

      Object.keys(response.data.features || {}).forEach(function (key) {
        if (!response.data.features[key]) {
          $(`[data-wa-feature="${key}"]`).hide();
        }
      });
    });

  refreshHeader();
})(jQuery);
</script>

<!-- chat -->
<script>
(function ($) {
  'use strict';

  var kind = @json($kind);
  var selected = null;
  var open = false;
  var allContacts = [];

  var emojis = [
    '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '🙂',
    '😉', '😍', '🥰', '😘', '😎', '🤔', '😢', '😭', '😡', '🙏',
    '👏', '👍', '👎', '👌', '✅', '❌', '❤️', '💚', '💙', '🎉',
    '🔥', '⭐', '📍', '📅', '📞', '💬', '🤝', '💯'
  ];

  var esc = function (value) {
    return $('<div>').text(value == null ? '' : String(value)).html();
  };

  function contactHtml(contact) {
    var phone = contact.phone_e164 || '';
    var name = contact.display_name || phone;
    var preview = contact.last_message_preview || 'Open conversation';
    var isSelected = selected && selected.phone_e164 === phone;
    var sessionLabel = contact.session_open ? ' · 24h open' : '';

    return `
      <div
        class="wa-chat-contact ${isSelected ? 'selected' : ''}"
        data-phone="${esc(phone)}"
        data-name="${esc(name)}"
      >
        <div class="wa-avatar">${esc((name.trim().charAt(0) || '?').toUpperCase())}</div>
        <div class="wa-contact-meta">
          <strong>${esc(name)}</strong>
          <small>${esc(preview)}</small>
          <small>${esc(phone)}${sessionLabel}</small>
        </div>
      </div>
    `;
  }

  function renderContacts(items) {
    allContacts = items || [];

    $('#waChatCount').text(`${allContacts.length} contacts`);
    $('#waChatContacts').html(
      allContacts.length
        ? allContacts.map(contactHtml).join('')
        : '<div class="wa-empty">No contacts found. Search the branch contacts or add a new number from Common Chat.</div>'
    );
  }

  function loadContacts() {
    window.WA.api('/conversations', 'GET', {
      kind: kind,
      q: $('#waChatSearch').val() || ''
    })
      .done(function (response) {
        renderContacts((response.data || {}).conversations || []);
      })
      .fail(function (xhr) {
        $('#waChatContacts').html(
          '<div class="wa-empty">Unable to load contacts.</div>'
        );
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Conversation list failed.',
          true
        );
      });
  }

  function messageMedia(message) {
    if (!message.media_id) {
      return '';
    }

    var url = `/wa-management/api/media/${encodeURIComponent(message.id)}?kind=${encodeURIComponent(kind)}&branch_id=${encodeURIComponent(window.WA.branch())}`;
    var type = (message.message_type || '').toLowerCase();
    var filename = esc(message.media_filename || 'Open attachment');

    if (type === 'image' || type === 'sticker') {
      return `
        <a href="${url}" target="_blank" rel="noopener noreferrer">
          <img
            class="wa-message-media"
            src="${url}"
            loading="lazy"
            alt="WhatsApp image"
          >
        </a>
      `;
    }

    if (type === 'video') {
      return `
        <video
          class="wa-message-media video"
          controls
          preload="metadata"
          src="${url}"
        ></video>
      `;
    }

    if (type === 'audio') {
      return `
        <audio
          class="wa-message-media audio"
          controls
          preload="none"
          src="${url}"
        ></audio>
      `;
    }

    return `
      <a
        class="wa-message-file"
        href="${url}"
        target="_blank"
        rel="noopener noreferrer"
      >
        📄 ${filename} · Open attachment
      </a>
    `;
  }

  function messageHtml(message) {
    var isOutbound = message.direction === 'outbound';
    var messageId = message.meta_message_id || '';
    var media = messageMedia(message);
    var body = message.body || '';

    if (media && /^\[(Image|Video|Audio|Document|Sticker) received\]$/i.test(body)) {
      body = '';
    }

    var bodyHtml = body ? `<div>${esc(body)}</div>` : '';
    var reactionHtml = messageId.indexOf('wamid.') === 0
      ? `
          <div class="wa-message-actions">
            <button
              class="wa-reaction-button"
              data-mid="${esc(messageId)}"
              title="React"
            >
              ☺ React
            </button>
          </div>
        `
      : '';

    return `
      <div
        class="wa-message-row ${isOutbound ? 'outbound' : 'inbound'}"
        data-id="${Number(message.id || 0)}"
      >
        <div class="wa-message-bubble">
          ${media}
          ${bodyHtml}
          <span class="wa-message-status">
            ${esc(message.status || '')} · ${esc(message.created_at || message.sent_at || '')}
          </span>
          ${reactionHtml}
        </div>
      </div>
    `;
  }

  function renderMessages(data) {
    var rows = data.messages || [];

    open = !!data.session_open;

    if (!selected) {
      return;
    }

    $('#waChatHeading').text(
      (data.contact && data.contact.display_name) ||
        selected.display_name ||
        selected.phone_e164
    );
    $('#waChatSubheading').text(
      `${selected.phone_e164} · ${open ? '24-hour service window open' : '24-hour service window closed'}`
    );

    var queryString = `?to=${encodeURIComponent(selected.phone_e164)}&kind=${encodeURIComponent(kind)}&branch_id=${encodeURIComponent(window.WA.branch())}`;

    $('#waChatTemplateLink, #waTopTemplateLink').attr(
      'href',
      `/wa-management/templates${queryString}`
    );

    $('#waWindowWarning')
      .toggle(!open)
      .text(
        open
          ? ''
          : [
              'The customer-service window is closed. Send an approved template to start/reopen the conversation;',
              'media, text, reactions and interactive sends are blocked until the recipient messages again.'
            ].join(' ')
      );

    $(
      '#waChatText, #waChatSend, #waAttachButton, #waLocationButton, #waContactCardButton, #waInteractiveButton, #waFlowToggle'
    ).prop('disabled', !open);

    $('#waMessageList').html(
      rows.length
        ? rows.map(messageHtml).join('')
        : '<div class="wa-empty">No history stored yet. Start from an approved template or wait for the contact to message your WhatsApp number.</div>'
    );

    var messageList = $('#waMessageList')[0];
    messageList.scrollTop = messageList.scrollHeight;

    var hasUnreadInbound = rows.some(function (message) {
      return (
        message.direction === 'inbound' &&
        message.status === 'received' &&
        message.meta_message_id
      );
    });

    if (hasUnreadInbound) {
      window.WA.api(
        `/conversations/${encodeURIComponent(selected.phone_e164)}/read`,
        'POST',
        { kind: kind }
      ).done(function () {
        window.setTimeout(function () {
          window.WA.api(
            `/conversations/${encodeURIComponent(selected.phone_e164)}/messages`,
            'GET',
            { kind: kind }
          ).done(function (response) {
            if (selected && response.data) {
              renderMessages(response.data);
            }
          });
        }, 300);
      });
    }
  }

  function openContact(contact) {
    selected = {
      phone_e164: contact.phone_e164,
      display_name: contact.display_name || contact.phone_e164
    };

    renderContacts(allContacts);
    $('#waChatHeading').text(selected.display_name);
    $('#waMessageList').html(
      '<div class="wa-empty">Loading messages…</div>'
    );
    $('#waChatText').prop('disabled', true);

    window.WA.api(
      `/conversations/${encodeURIComponent(selected.phone_e164)}/messages`,
      'GET',
      { kind: kind }
    )
      .done(function (response) {
        renderMessages(response.data || {});
      })
      .fail(function (xhr) {
        $('#waMessageList').html(
          '<div class="wa-empty">Conversation could not be opened.</div>'
        );
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Conversation failed.',
          true
        );
      });
  }

  $('#waChatContacts').on('click', '.wa-chat-contact', function () {
    openContact({
      phone_e164: $(this).data('phone'),
      display_name: $(this).data('name')
    });
  });

  function refreshCurrent() {
    loadContacts();

    if (selected) {
      window.WA.api(
        `/conversations/${encodeURIComponent(selected.phone_e164)}/messages`,
        'GET',
        { kind: kind }
      ).done(function (response) {
        if (selected && response && response.data) {
          renderMessages(response.data);
        }
      });
    }
  }

  $('#waChatSearch').on('keydown', function (event) {
    if (event.key === 'Enter') {
      loadContacts();
    }
  });

  $('#waChatRefresh').on('click', refreshCurrent);

  $('#waChatSend').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var text = $.trim($('#waChatText').val());

    if (!text) {
      return;
    }

    var button = $(this);
    button.prop('disabled', true);

    window.WA.api('/send/text', 'POST', {
      to: selected.phone_e164,
      text: text,
      kind: kind
    })
      .done(function () {
        $('#waChatText').val('');
        window.WA.toast(
          'Message queued. Delivery status updates from Meta webhooks.'
        );
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Message blocked. Check the service window and consent.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', !open);
      });
  });

  $('#waChatText').on('keydown', function (event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      $('#waChatSend').click();
    }
  });

  $('#waNewContactToggle').on('click', function () {
    $('#waNewContactForm').slideToggle(120);
  });

  $('#waNewContactCancel').on('click', function () {
    $('#waNewContactForm').slideUp(120);
  });

  $('#waNewContactSave').on('click', function () {
    var name = $.trim($('#waNewContactName').val());
    var phone = $.trim($('#waNewContactPhone').val());

    if (!phone) {
      window.WA.toast('Enter an international phone number.', true);
      return;
    }

    var button = $(this);
    button.prop('disabled', true);

    window.WA.api('/contacts/create', 'POST', {
      phone: phone,
      display_name: name,
      kind: 'common'
    })
      .done(function (response) {
        var contact = (response.data || {}).contact || {};

        if (kind !== 'common') {
          var url = `/wa-management/chats/common?new_contact=${encodeURIComponent(contact.phone_e164 || phone)}&display_name=${encodeURIComponent(contact.display_name || name)}`;
          window.location.href = url;
          return;
        }

        $('#waNewContactName, #waNewContactPhone').val('');
        $('#waNewContactForm').slideUp(120);
        $('#waChatSearch').val('');
        loadContacts();

        selected = {
          phone_e164: contact.phone_e164 || phone,
          display_name: contact.display_name || name || phone
        };

        window.setTimeout(function () {
          openContact(selected);
        }, 250);

        window.WA.toast(response.message || 'Contact saved.');
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Contact could not be saved.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  $('#waEmojiTray').html(
    emojis.map(function (emoji) {
      return `
        <button type="button" class="wa-emoji" data-emoji="${emoji}">
          ${emoji}
        </button>
      `;
    }).join('')
  );

  $('#waEmojiToggle').on('click', function () {
    $('#waEmojiTray').slideToggle(100);
  });

  $('#waEmojiTray').on('click', '.wa-emoji', function () {
    var textarea = $('#waChatText')[0];
    var emoji = $(this).data('emoji');

    if (!textarea) {
      return;
    }

    var start = textarea.selectionStart || textarea.value.length;
    var end = textarea.selectionEnd || start;

    textarea.value =
      textarea.value.substring(0, start) +
      emoji +
      textarea.value.substring(end);

    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + emoji.length;
  });

  $('#waMessageList').on('click', '.wa-reaction-button', function () {
    if (!selected || !open) {
      return;
    }

    var emoji = window.prompt(
      'Enter one emoji to react with, e.g. 👍 or ❤️',
      '👍'
    );

    if (!emoji) {
      return;
    }

    window.WA.api('/send/reaction', 'POST', {
      to: selected.phone_e164,
      target_message_id: $(this).data('mid'),
      emoji: emoji,
      kind: kind
    })
      .done(function () {
        window.WA.toast('Reaction queued.');
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Reaction failed.',
          true
        );
      });
  });

  $('#waAttachButton').on('click', function () {
    if (!selected || !open) {
      window.WA.toast(
        'Attachments can be sent only inside the 24-hour service window.',
        true
      );
      return;
    }

    $('#waChatMedia').trigger('click');
  });

  $('#waChatMedia').on('change', function () {
    var file = this.files && this.files[0];

    if (!file) {
      return;
    }

    $('#waSelectedFileLabel').text(
      `${file.name} · ${Math.ceil(file.size / 1024)} KB`
    );
    $('#waMediaCaptionRow').show();
  });

  $('#waCancelMedia').on('click', function () {
    $('#waChatMedia').val('');
    $('#waMediaCaption').val('');
    $('#waSelectedFileLabel').text('');
    $('#waMediaCaptionRow').hide();
  });

  $('#waSendMedia').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var file = $('#waChatMedia')[0].files[0];

    if (!file) {
      return;
    }

    var form = new FormData();
    form.append('media', file);
    form.append('to', selected.phone_e164);
    form.append('kind', kind);
    form.append('caption', $('#waMediaCaption').val());
    form.append('_token', $('meta[name="csrf-token"]').attr('content') || '');
    form.append('branch_id', window.WA.branch());

    var button = $(this);
    button.prop('disabled', true).text('Uploading…');

    window.WA.request('/wa-management/api/send/media', {
      method: 'POST',
      credentials: 'same-origin',
      body: form,
      headers: {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') || ''
      }
    })
      .done(function () {
        window.WA.toast('Attachment queued.');
        $('#waCancelMedia').click();
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Attachment blocked or upload failed.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false).text('Send attachment');
      });
  });

  $('#waLocationButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    if (!navigator.geolocation) {
      window.WA.toast(
        'This browser does not provide location sharing.',
        true
      );
      return;
    }

    if (!window.confirm('Share your current device location with this contact?')) {
      return;
    }

    var button = $(this);
    button.prop('disabled', true);

    navigator.geolocation.getCurrentPosition(
      function (position) {
        window.WA.api('/send/location', 'POST', {
          to: selected.phone_e164,
          kind: kind,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        })
          .done(function () {
            window.WA.toast('Location queued.');
            refreshCurrent();
          })
          .fail(function (xhr) {
            window.WA.toast(
              (xhr.responseJSON && xhr.responseJSON.message) ||
                'Location could not be sent.',
              true
            );
          })
          .always(function () {
            button.prop('disabled', false);
          });
      },
      function () {
        button.prop('disabled', false);
        window.WA.toast(
          'Location access was denied or unavailable.',
          true
        );
      },
      {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });

  $('#waContactCardButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var name = window.prompt('Contact display name:', '');

    if (name === null || !name.trim()) {
      return;
    }

    var phone = window.prompt(
      'Contact phone in international format:',
      '+91'
    );

    if (phone === null || !phone.trim()) {
      return;
    }

    window.WA.api('/send/contact', 'POST', {
      to: selected.phone_e164,
      kind: kind,
      contact_name: name,
      contact_phone: phone
    })
      .done(function () {
        window.WA.toast('Contact card queued.');
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Contact card could not be sent.',
          true
        );
      });
  });

  $('#waInteractiveButton').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var body = window.prompt('Interactive message body text:', 'Choose an option');

    if (body === null || !body.trim()) {
      return;
    }

    var title = window.prompt('Reply button label (max 20 characters):', 'Yes');

    if (title === null || !title.trim()) {
      return;
    }

    title = title.substring(0, 20);

    var interactive = {
      type: 'button',
      body: {
        text: body.substring(0, 1024)
      },
      action: {
        buttons: [
          {
            type: 'reply',
            reply: {
              id: `choice_${Date.now()}`,
              title: title
            }
          }
        ]
      }
    };

    window.WA.api('/send/interactive', 'POST', {
      to: selected.phone_e164,
      kind: kind,
      interactive_json: JSON.stringify(interactive)
    })
      .done(function () {
        window.WA.toast('Interactive message queued.');
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Interactive message failed.',
          true
        );
      });
  });

  $('#waFlowToggle').on('click', function () {
    if (!selected || !open) {
      return;
    }

    $('#waFlowPanel').slideToggle(100);
  });

  $('#waCloseFlow').on('click', function () {
    $('#waFlowPanel').slideUp(100);
  });

  $('#waSendFlow').on('click', function () {
    if (!selected || !open) {
      return;
    }

    var data = $.trim($('#waFlowData').val() || '{}');

    try {
      JSON.parse(data);
    } catch (error) {
      window.WA.toast('Initial Flow data must be valid JSON.', true);
      return;
    }

    var payload = {
      to: selected.phone_e164,
      kind: kind,
      flow_id: $('#waFlowId').val(),
      flow_token: $('#waFlowToken').val() || `eapl_${Date.now()}`,
      flow_cta: $('#waFlowCta').val(),
      body: $('#waFlowBody').val(),
      flow_action: 'navigate',
      flow_action_payload: data
    };

    window.WA.api('/send/flow', 'POST', payload)
      .done(function () {
        window.WA.toast('Flow message queued.');
        $('#waFlowPanel').slideUp(100);
        refreshCurrent();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Flow could not be sent. Check published Flow ID and account support.',
          true
        );
      });
  });

  // Keep branch scoping for Lead/Customer CRM lists. API configuration,
  // templates, rules, and message history remain shared.
  var searchParams = new URLSearchParams(window.location.search);
  var newContact = searchParams.get('new_contact');
  var newName = searchParams.get('display_name');

  loadContacts();

  if (newContact) {
    $('#waChatSearch').val(newContact);

    window.setTimeout(function () {
      openContact({
        phone_e164: newContact,
        display_name: newName || newContact
      });
    }, 350);
  }
})(jQuery);
</script>

<!-- templates -->
<script>
(function ($) {
  'use strict';

  var all = [];

  function load() {
    window.WA.api('/templates', 'GET', {})
      .done(function (response) {
        all = (response.data || {}).templates || [];
        render();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Templates unavailable.',
          true
        );
      });
  }

  function render() {
    var query = ($.trim($('#waTemplateSearch').val() || '')).toLowerCase();
    var rows = all.filter(function (template) {
      return (
        `${template.name} ${template.language} ${template.category}`
          .toLowerCase()
          .indexOf(query) >= 0
      );
    });

    $('#waTemplateRows').html(
      rows.length
        ? rows.map(function (template) {
            var isApproved = template.approval_status === 'APPROVED';
            var isEnabled = !!template.is_enabled;
            var statusClass = isApproved ? 'ok' : 'bad';
            var disabledAttribute = isApproved ? '' : 'disabled';
            var checkedAttribute = isEnabled ? 'checked' : '';

            return `
              <tr>
                <td>
                  <strong>${window.WA.esc(template.name)}</strong><br>
                  <small class="wa-muted">ID ${window.WA.esc(template.id)}</small>
                </td>
                <td>${window.WA.esc(template.language)}</td>
                <td>${window.WA.esc(template.category)}</td>
                <td>
                  <span class="wa-badge ${statusClass}">
                    ${window.WA.esc(template.approval_status)}
                  </span>
                </td>
                <td>
                  <label class="wa-toggle">
                    <input
                      type="checkbox"
                      class="waTemplateEnable"
                      data-id="${window.WA.esc(template.id)}"
                      ${checkedAttribute}
                      ${disabledAttribute}
                    >
                    Enabled
                  </label>
                </td>
                <td>${window.WA.esc(template.last_synced_at || '—')}</td>
              </tr>
            `;
          }).join('')
        : '<tr><td colspan="6" class="wa-empty">No templates. Sync after API setup, or change the search.</td></tr>'
    );

    var approvedTemplates = all.filter(function (template) {
      return template.approval_status === 'APPROVED' && template.is_enabled;
    });

    $('#waSendTemplate').html(`
      <option value="">Choose approved template</option>
      ${approvedTemplates.map(function (template) {
        return `
          <option
            value="${window.WA.esc(template.name)}"
            data-language="${window.WA.esc(template.language)}"
          >
            ${window.WA.esc(template.name)} · ${window.WA.esc(template.language)}
          </option>
        `;
      }).join('')}
    `);
  }

  $('#waTemplateSearch').on('input', render);

  $('#waSyncTemplates').on('click', function () {
    var button = $(this);

    button.prop('disabled', true).text('Syncing…');

    window.WA.api('/templates/sync', 'POST', {})
      .done(function (response) {
        window.WA.toast(response.message || 'Template sync complete.');
        load();
      })
      .fail(function (xhr) {
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Template sync failed.',
          true
        );
      })
      .always(function () {
        button.prop('disabled', false).text('↻ Sync from Meta');
      });
  });

  $('#waTemplateRows').on('change', '.waTemplateEnable', function () {
    var element = $(this);

    window.WA.api('/templates/toggle', 'POST', {
      id: element.data('id'),
      enabled: element.is(':checked') ? 1 : 0
    })
      .done(function (response) {
        window.WA.toast(response.message || 'Template status saved.');
        load();
      })
      .fail(function (xhr) {
        element.prop('checked', !element.is(':checked'));
        window.WA.toast(
          (xhr.responseJSON && xhr.responseJSON.message) ||
            'Could not update template.',
          true
        );
      });
  });

  $('#waSendTemplate').on('change', function () {
    var option = $(this).find(':selected');
    var language = option.data('language') || 'en';

    $('#waSendLanguage')
      .html(`<option value="${window.WA.esc(language)}">${window.WA.esc(language)}</option>`)
      .val(language);
  });

  $('#waSendTemplateButton').on('click', function () {
    var button = $(this);
    var components = $.trim($('#waSendComponents').val() || '[]');

    try {
      JSON.parse(components);
    } catch (error) {
      window.WA.toast('Components field is not valid JSON.', true);
      return;
    }

    var recipient = $('#waSendTo').val();
    var templateName = $('#waSendTemplate').val();

    if (!recipient || !templateName) {
      window.WA.toast('Recipient and template are required.', true);
      return;
    }

    button.prop('disabled', true);

    window.WA.api('/send/template', 'POST', {
      to: recipient,
      template_name: templateName,
      language: $('#waSendLanguage').val(),
      components: components,
      source_type: 'admin_manual'
    })
      .done(function (response) {
        var outboxId = response.id || (response.data || {}).id || '—';
        var status = response.status || 'queued';

        $('#waSingleSendStatus').text(
          `Outbox ID ${outboxId} · ${status}`
        );
        window.WA.toast(
          'Accepted into outbox. Delivery receipts update asynchronously.'
        );
      })
      .fail(function (xhr) {
        var message =
          (xhr.responseJSON && xhr.responseJSON.message) ||
          'Template blocked. Check consent/profile/status.';

        $('#waSingleSendStatus').text(message);
        window.WA.toast(message, true);
      })
      .always(function () {
        button.prop('disabled', false);
      });
  });

  load();
})(jQuery);
</script>
@endsection
