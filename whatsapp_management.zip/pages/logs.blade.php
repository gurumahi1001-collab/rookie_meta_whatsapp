<div class="wa-page-head"><div><h2>Message log monitor</h2><p>Search queue history, event/automation origin and Meta delivery status. Filter by month (default) or full year.</p></div><button id="waLogRefresh" class="wa-btn wa-btn-primary">Refresh logs</button></div>
<div class="wa-card"><div class="wa-row" style="margin-bottom:14px"><select id="waLogPeriod" class="wa-search" style="max-width:110px"><option value="month">Month</option><option value="year">Year</option></select><select id="waLogMonth" class="wa-search" style="max-width:130px"></select><select id="waLogYear" class="wa-search" style="max-width:100px"></select><select id="waLogStatus" class="wa-search" style="max-width:150px"><option value="all">All statuses</option><option>queued</option><option>processing</option><option>sent</option><option>delivered</option><option>read</option><option>failed</option><option>blocked</option><option>unknown</option></select><input id="waLogSearch" class="wa-search" style="max-width:250px" placeholder="Phone, template, event…"><button id="waLogApply" class="wa-btn">Apply filters</button></div><div class="wa-row" style="margin-bottom:12px"><span id="waLogCount" class="wa-muted" style="font-size:10px"></span><span class="wa-inline-note" style="padding:7px 10px">Unknown = network result ambiguous. Do not blindly resend; verify provider status first.</span></div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Created</th><th>Recipient</th><th>Template / type</th><th>Source event</th><th>Status</th><th>Error</th><th>Lifecycle</th></tr></thead><tbody id="waLogRows"><tr><td colspan="7" class="wa-empty">Loading messages…</td></tr></tbody></table></div><div class="wa-row" style="justify-content:space-between;margin-top:13px"><button id="waLogPrev" class="wa-btn" disabled>Previous</button><span id="waLogPageLabel" class="wa-muted" style="font-size:10px">Page 1</span><button id="waLogNext" class="wa-btn" disabled>Next</button></div></div>
<script>
(function ($) {
    'use strict';

    var page = 1;
    var lastPage = 1;
    var months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;

    months.forEach(function (monthName, index) {
        var monthNumber = index + 1;
        $('#waLogMonth').append(`
            <option value="${monthNumber}" ${monthNumber === currentMonth ? 'selected' : ''}>
                ${monthName}
            </option>
        `);
    });

    for (var year = currentYear - 4; year <= currentYear + 1; year++) {
        $('#waLogYear').append(`
            <option value="${year}" ${year === currentYear ? 'selected' : ''}>
                ${year}
            </option>
        `);
    }

    function loadLogs() {
        var period = $('#waLogPeriod').val();
        $('#waLogMonth').prop('disabled', period === 'year');

        window.WA.api('/outbox', 'GET', {
            period: period,
            month: $('#waLogMonth').val(),
            year: $('#waLogYear').val(),
            status: $('#waLogStatus').val(),
            q: $('#waLogSearch').val(),
            page: page
        })
            .done(function (response) {
                var data = response.data || {};
                lastPage = data.last_page || 1;

                $('#waLogCount').text(
                    `${Number(data.total || 0).toLocaleString()} messages matching this filter`
                );
                $('#waLogPageLabel').text(`Page ${data.page || 1} of ${lastPage}`);
                $('#waLogPrev').prop('disabled', page <= 1);
                $('#waLogNext').prop('disabled', page >= lastPage);

                var rows = data.rows || [];
                $('#waLogRows').html(rows.length
                    ? rows.map(function (row) {
                        var statusClass = ['delivered', 'read', 'sent'].indexOf(row.status) >= 0
                            ? 'ok'
                            : (['failed', 'blocked'].indexOf(row.status) >= 0 ? 'bad' : 'warn');
                        var campaignHtml = row.campaign_id
                            ? `<br><small>Campaign #${WA.esc(row.campaign_id)}</small>`
                            : '';
                        var errorHtml = row.error_message
                            ? `<br><small>${WA.esc(row.error_message)}</small>`
                            : '';

                        return `
                            <tr>
                                <td>
                                    ${WA.esc(row.created_at || '')}<br>
                                    <small class="wa-muted">#${WA.esc(row.id)}</small>
                                </td>
                                <td><strong>${WA.esc(row.phone_e164 || '')}</strong></td>
                                <td>
                                    ${WA.esc(row.template_name || row.message_type || '')}<br>
                                    <small class="wa-muted">${WA.esc(row.language || '')}</small>
                                </td>
                                <td>
                                    ${WA.esc(row.workflow_event_key || row.source_type || '')}
                                    ${campaignHtml}
                                </td>
                                <td><span class="wa-badge ${statusClass}">${WA.esc(row.status || '')}</span></td>
                                <td>${WA.esc(row.error_code || '')}${errorHtml}</td>
                                <td>
                                    <small>
                                        Sent: ${WA.esc(row.sent_at || '—')}<br>
                                        Delivered: ${WA.esc(row.delivered_at || '—')}<br>
                                        Read: ${WA.esc(row.read_at || '—')}<br>
                                        Failed: ${WA.esc(row.failed_at || '—')}
                                    </small>
                                </td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="7" class="wa-empty">No outbox records in this period.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Log query failed.',
                    true
                );
            });
    }

    $('#waLogApply, #waLogRefresh').on('click', function () {
        page = 1;
        loadLogs();
    });

    $('#waLogPrev').on('click', function () {
        if (page > 1) {
            page--;
            loadLogs();
        }
    });

    $('#waLogNext').on('click', function () {
        if (page < lastPage) {
            page++;
            loadLogs();
        }
    });

    $('#waLogPeriod, #waLogMonth, #waLogYear, #waLogStatus').on('change', function () {
        page = 1;
        loadLogs();
    });

    $('#waLogSearch').on('keydown', function (event) {
        if (event.key === 'Enter') {
            page = 1;
            loadLogs();
        }
    });

    loadLogs();
})(jQuery);
</script>
