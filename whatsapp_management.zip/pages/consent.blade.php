<div class="wa-page-head"><div><h2>Consent & opt-out registry</h2><p>Record the evidence source for each recipient. Never treat an existing CRM phone number as proof of WhatsApp opt-in.</p></div></div>
<div class="wa-grid-2"><div class="wa-card"><div class="wa-card-title">Record opt-in or opt-out</div><div class="wa-field"><label>Phone number in international format</label><input id="waConsentPhone" placeholder="+919876543210"></div><div class="wa-grid-2"><div class="wa-field"><label>Consent category</label><select id="waConsentCategory" class="wa-search"><option value="all">All messaging</option><option value="marketing">Marketing</option><option value="utility">Utility</option><option value="authentication">Authentication</option></select></div><div class="wa-field"><label>Decision</label><select id="waConsentStatus" class="wa-search"><option value="opted_in">Opted in</option><option value="opted_out">Opted out</option></select></div></div><div class="wa-field"><label>Consent source</label><select id="waConsentSource" class="wa-search"><option value="website_checkbox">Website checkbox</option><option value="signed_form">Signed form</option><option value="in_person">In-person / written evidence</option><option value="inbound_whatsapp">Inbound WhatsApp request</option><option value="legacy_import_verified">Legacy import with verified evidence</option></select></div><div class="wa-field"><label>Evidence reference</label><textarea id="waConsentEvidence" placeholder="Record ID, timestamp, source system, form version or Meta inbound message ID"></textarea><small>Do not paste sensitive unrelated personal information. Preserve a real audit reference that your team can retrieve.</small></div><button id="waSaveConsent" class="wa-btn wa-btn-primary">Save consent record</button></div><div class="wa-card"><div class="wa-card-title">Consent operation rules</div><div class="wa-check-card"><strong>Outbound protection</strong><small>Template queue checks require current opt-in evidence in the template category or an “all” consent record.</small></div><div class="wa-check-card" style="margin-top:10px"><strong>Opt-out precedence</strong><small>Opt-out blocks future sends even if another category had been opted in. Re-opt-in should require fresh proof and explicit re-consent.</small></div><div class="wa-check-card" style="margin-top:10px"><strong>Inbound STOP keywords</strong><small>STOP, unsubscribe, cancel, opt out and opt-out are recorded as global opt-outs when received through the signed webhook.</small></div><div class="wa-inline-note wa-inline-warning" style="margin-top:13px">The database cannot infer consent retroactively. Audit existing lists and import only recipients with provable, current opt-in evidence.</div></div></div>
<script>
(function ($) {
    'use strict';

    $('#waSaveConsent').on('click', function () {
        var button = $(this);
        var payload = {
            phone: $('#waConsentPhone').val(),
            category: $('#waConsentCategory').val(),
            consent_status: $('#waConsentStatus').val(),
            source: $('#waConsentSource').val(),
            evidence_ref: $('#waConsentEvidence').val()
        };

        if (!payload.phone || !payload.evidence_ref) {
            WA.toast('Phone and evidence reference are required.', true);
            return;
        }

        button.prop('disabled', true);

        WA.api('/consent', 'POST', payload)
            .done(function (response) {
                WA.toast(response.message || 'Consent saved.');
                $('#waConsentEvidence').val('');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save consent.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });
})(jQuery);
</script>
