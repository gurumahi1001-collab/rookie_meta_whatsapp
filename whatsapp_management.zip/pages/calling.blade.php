<div class="wa-page-head">
    <div>
        <h2>WhatsApp Calling capability</h2>
        <p>Calling is a separate Cloud API integration with eligibility, permission, configuration and event handling requirements.</p>
    </div>
</div>

<div class="wa-card">
    <div class="wa-inline-note wa-inline-warning">
        <strong>Not enabled in this package:</strong>
        this page is a capability gate, not a live dialer. It will not display fake call buttons or claim that calls are working.
    </div>

    <div class="wa-grid-2" style="margin-top:16px">
        <div class="wa-check-card">
            <strong>Before implementation</strong>
            <small>Verify that calling is available for this WhatsApp Business Account and phone number, grant the required Meta permissions, and configure call-specific webhook events and lifecycle callbacks.</small>
        </div>
        <div class="wa-check-card">
            <strong>Separate call workflows</strong>
            <small>Actual calling requires an additional service for call offers/answer/hangup events, media/signaling integration, permission prompts, error handling and call history. Message templates and text outbox do not implement those flows.</small>
        </div>
    </div>

    <div style="margin-top:14px">
        <a
            href="https://developers.facebook.com/docs/whatsapp/cloud-api/calling/"
            target="_blank"
            rel="noopener noreferrer"
            class="wa-btn"
        >Read Meta calling documentation ↗</a>
        <a href="{{ url('/wa-management/setup') }}" class="wa-btn">Check feature switch</a>
    </div>
</div>
