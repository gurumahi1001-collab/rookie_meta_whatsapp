<div class="wa-page-head"><div><h2>Broadcast manager</h2><p>Broadcast campaigns are individual, paced template sends to eligible recipients. This panel does not publish to native WhatsApp Channels.</p></div><a class="wa-btn wa-btn-primary" href="{{ url('/wa-management/campaigns') }}">Create campaign</a></div>
<div class="wa-card"><div class="wa-card-title">Broadcast lifecycle</div><div class="wa-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))"><div class="wa-check-card"><strong>1 · Audience quality</strong><small>Document opt-in, remove stale/unverified records, and use the correct category template.</small></div><div class="wa-check-card"><strong>2 · Queue pacing</strong><small>Outbox deduplicates per campaign recipient and schedules sends to reduce sudden bursts.</small></div><div class="wa-check-card"><strong>3 · Delivery monitor</strong><small>Use sent, delivered, read and failed webhook statuses. Stop campaigns if feedback or failures spike.</small></div></div><div class="wa-inline-note" style="margin-top:16px">Meta maintains separate product features and eligibility rules for the Business Platform, WhatsApp Groups API, Calling APIs, and consumer WhatsApp Channels. A CRM audience list is not the same thing as a native WhatsApp group or Channel.</div></div>
<div class="wa-card"><div class="wa-card-title">Recent campaigns</div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Name</th><th>Template</th><th>State</th><th>Total</th><th>Queued</th><th>Blocked</th></tr></thead><tbody id="waBroadcastRows"><tr><td colspan="6" class="wa-empty">Loading campaigns…</td></tr></tbody></table></div></div>
<script>
(function ($) {
    'use strict';

    window.WA.api('/campaigns', 'GET', {})
        .done(function (response) {
            var campaigns = (response.data || {}).campaigns || [];

            $('#waBroadcastRows').html(campaigns.length
                ? campaigns.map(function (campaign) {
                    return `
                        <tr>
                            <td>${WA.esc(campaign.name || '')}</td>
                            <td>${WA.esc(campaign.template_name || '')}</td>
                            <td>${WA.esc(campaign.state || '')}</td>
                            <td>${Number(campaign.total_recipients || 0)}</td>
                            <td>${Number(campaign.queued_count || 0)}</td>
                            <td>${Number(campaign.blocked_count || 0)}</td>
                        </tr>
                    `;
                }).join('')
                : '<tr><td colspan="6" class="wa-empty">No campaigns yet.</td></tr>'
            );
        })
        .fail(function (error) {
            $('#waBroadcastRows').html(
                '<tr><td colspan="6" class="wa-empty">Unable to load campaigns.</td></tr>'
            );
            WA.toast(
                error.responseJSON && error.responseJSON.message ||
                'Campaign list unavailable.',
                true
            );
        });
})(jQuery);
</script>
