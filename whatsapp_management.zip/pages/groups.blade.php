<div class="wa-page-head"><div><h2>Custom group audiences</h2><p>Store reusable recipient lists for approved-template sends. These are ERP-managed audiences, not native WhatsApp group chats.</p></div><a class="wa-btn" href="{{ url('/wa-management/campaigns') }}">Open campaign sender</a></div>
<div class="wa-grid-2"><div class="wa-card"><div class="wa-card-title">Create audience</div><div class="wa-field"><label>Audience name</label><input id="waAudienceName" placeholder="Academy event registrants"></div><div class="wa-field"><label>Description</label><textarea id="waAudienceDescription" placeholder="Who is included and source of data"></textarea></div><button id="waCreateAudience" class="wa-btn wa-btn-primary">Create audience</button><hr style="border-color:#eef2f3;margin:20px 0"><div class="wa-card-title">Add members</div><div class="wa-field"><label>Existing audience</label><select id="waAudienceSelect" class="wa-search"><option value="">Select audience</option></select></div><div class="wa-field"><label>International-format phone numbers</label><textarea id="waAudiencePhones" placeholder="+919876543210"></textarea><small>Only add recipients your company is permitted to contact. Campaign sends will independently recheck consent.</small></div><button id="waAddMembers" class="wa-btn wa-btn-soft">Save recipient list</button></div><div class="wa-card"><div class="wa-card-title">Saved audiences</div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Name</th><th>Description</th><th>Created</th><th>Action</th></tr></thead><tbody id="waAudienceRows"><tr><td colspan="4" class="wa-empty">Loading audiences…</td></tr></tbody></table></div><div class="wa-inline-note" style="margin-top:12px">Recipient list membership does not itself grant consent. Consent source and evidence are maintained in the Consent Registry.</div></div></div>
<script>
(function ($) {
    'use strict';

    function loadAudiences() {
        window.WA.api('/audiences', 'GET', {})
            .done(function (response) {
                var audiences = (response.data || {}).audiences || [];

                $('#waAudienceSelect').html(
                    '<option value="">Select audience</option>' +
                    audiences.map(function (audience) {
                        return `
                            <option value="${WA.esc(audience.id)}">
                                ${WA.esc(audience.name)}
                            </option>
                        `;
                    }).join('')
                );

                $('#waAudienceRows').html(audiences.length
                    ? audiences.map(function (audience) {
                        return `
                            <tr>
                                <td>
                                    <strong>${WA.esc(audience.name)}</strong><br>
                                    <small>#${WA.esc(audience.id)}</small>
                                </td>
                                <td>${WA.esc(audience.description || '')}</td>
                                <td>${WA.esc(audience.created_at || '')}</td>
                                <td>
                                    <button type="button" class="wa-btn waAudienceChoose" data-id="${WA.esc(audience.id)}">
                                        Select
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="4" class="wa-empty">No audiences created.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audiences unavailable.',
                    true
                );
            });
    }

    $('#waCreateAudience').on('click', function () {
        var name = $.trim($('#waAudienceName').val());
        var description = $('#waAudienceDescription').val();

        if (!name) {
            WA.toast('Audience name is required.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/audiences', 'POST', {
            name: name,
            description: description
        })
            .done(function (response) {
                WA.toast(response.message || 'Audience created.');
                $('#waAudienceName, #waAudienceDescription').val('');
                loadAudiences();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audience creation failed.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waAudienceRows').on('click', '.waAudienceChoose', function () {
        $('#waAudienceSelect').val($(this).data('id'));
    });

    $('#waAddMembers').on('click', function () {
        var audienceId = $('#waAudienceSelect').val();
        var recipients = $.trim($('#waAudiencePhones').val());

        if (!audienceId || !recipients) {
            WA.toast('Select an audience and enter recipient numbers.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/audiences/members', 'POST', {
            audience_id: audienceId,
            recipients: recipients
        })
            .done(function (response) {
                var savedCount = (response.data || {}).members_saved || 0;
                WA.toast(`${response.message || 'Members saved.'} Saved: ${savedCount}`);
                $('#waAudiencePhones').val('');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save recipients.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    loadAudiences();
})(jQuery);
</script>
