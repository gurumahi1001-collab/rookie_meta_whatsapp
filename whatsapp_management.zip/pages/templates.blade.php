<div class="wa-page-head">
    <div>
        <h2>Template registry</h2>
        <p>Sync live templates from the selected WhatsApp Business Account. Only Meta-approved, ERP-enabled templates can be queued.</p>
    </div>
    <button id="waSyncTemplates" class="wa-btn wa-btn-primary">↻ Sync from Meta</button>
</div>

<div class="wa-card">
    <div class="wa-row" style="justify-content:space-between;margin-bottom:12px">
        <div class="wa-card-title" style="margin:0">Synced templates</div>
        <input
            id="waTemplateSearch"
            class="wa-search"
            style="max-width:280px"
            placeholder="Filter by name or language"
        >
    </div>

    <div class="wa-table-wrap">
        <table class="wa-table">
            <thead>
                <tr>
                    <th>Template</th>
                    <th>Language</th>
                    <th>Category</th>
                    <th>Meta status</th>
                    <th>ERP sending</th>
                    <th>Last sync</th>
                </tr>
            </thead>
            <tbody id="waTemplateRows">
                <tr>
                    <td colspan="6" class="wa-empty">Loading templates…</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="wa-card">
    <div class="wa-card-title">Send a single approved template (queued, not instantly delivered)</div>

    <div class="wa-grid-2">
        <div class="wa-field">
            <label>Recipient in international format</label>
            <input id="waSendTo" placeholder="+919876543210" value="{{ request('to') }}">
            <small>Use the original opt-in record. A phone number alone does not establish consent.</small>
        </div>
        <div class="wa-field">
            <label>Template / language</label>
            <div class="wa-row">
                <select id="waSendTemplate" class="wa-search" style="flex:1">
                    <option value="">Choose approved template</option>
                </select>
                <select id="waSendLanguage" class="wa-search" style="width:118px">
                    <option value="en">en</option>
                </select>
            </div>
        </div>
    </div>

    <div class="wa-field">
        <label>Template components JSON (must match the approved template exactly)</label>
        <textarea id="waSendComponents" spellcheck="false">[]</textarea>
        <small>Leave as [] for templates without variable components. For dynamic values, prefer Automation rules.</small>
    </div>

    <button id="waSendTemplateButton" class="wa-btn wa-btn-primary">Queue template message</button>
    <span id="waSingleSendStatus" class="wa-muted" style="margin-left:10px;font-size:10px"></span>
</div>
