<div class="wa-page-head"><div><h2>Bulk campaign queue</h2><p>Admin-controlled, paced sends. Every recipient is independently checked for an approved template and recorded opt-in; sending is capped to reduce accidental blasts.</p></div></div>
<div class="wa-grid-2">
  <div class="wa-card">
    <div class="wa-card-title">Create campaign</div>
    <div class="wa-field"><label>Campaign name</label><input id="waCampaignName" placeholder="October academy update"></div>
    <div class="wa-grid-2">
      <div class="wa-field"><label>Approved template</label><select id="waCampaignTemplate" class="wa-search"><option value="">Select template</option></select></div>
      <div class="wa-field"><label>Language</label><select id="waCampaignLanguage" class="wa-search"><option value="en">en</option></select></div>
    </div>
    <div class="wa-field"><label>Saved audience (optional)</label><select id="waCampaignAudience" class="wa-search"><option value="">Manual numbers only</option></select><small>A saved ERP audience is a reusable recipient list, not a native WhatsApp group. Consent is checked separately for every recipient.</small></div>
    <div class="wa-field"><label>Additional recipients (optional; E.164, one per line)</label><textarea id="waCampaignRecipients" placeholder="+919876543210&#10;+919876543211"></textarea><small>Choose a saved audience, enter manual numbers, or use both. Numbers must include their country code. Recipients without documented opt-in will be blocked.</small></div>
    <div class="wa-field"><label>Template components JSON</label><textarea id="waCampaignComponents" spellcheck="false">[]</textarea><small>Use the exact component structure and parameter order for the approved Meta template. The preview here does not replace validation by Meta.</small></div>
    <button id="waCampaignSend" class="wa-btn wa-btn-primary">Validate and queue campaign</button><div id="waCampaignResult" style="margin-top:12px"></div>
  </div>
  <div class="wa-card">
    <div class="wa-card-title">Recent campaigns</div>
    <div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Name</th><th>Template</th><th>State</th><th>Queued</th><th>Blocked</th><th>Created</th></tr></thead><tbody id="waCampaignRows"><tr><td colspan="6" class="wa-empty">Loading campaigns…</td></tr></tbody></table></div>
    <div class="wa-inline-note" style="margin-top:12px">Campaign status describes queue admission, not final delivery. Use Message Logs for sent, delivered, read and failed provider statuses. A blocked recipient should not be re-added until the reason is resolved.</div>
  </div>
</div>
<script>
(function ($) {
    'use strict';

    function loadTemplates() {
        window.WA.api('/templates', 'GET', {})
            .done(function (response) {
                var approvedTemplates = ((response.data || {}).templates || []).filter(function (template) {
                    return template.approval_status === 'APPROVED' && template.is_enabled;
                });

                $('#waCampaignTemplate').html(
                    '<option value="">Select template</option>' +
                    approvedTemplates.map(function (template) {
                        return `
                            <option value="${WA.esc(template.name)}" data-lang="${WA.esc(template.language)}">
                                ${WA.esc(template.name)} · ${WA.esc(template.language)}
                            </option>
                        `;
                    }).join('')
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Templates unavailable for campaigns.',
                    true
                );
            });
    }

    function loadAudiences() {
        window.WA.api('/audiences', 'GET', {})
            .done(function (response) {
                var audiences = (response.data || {}).audiences || [];

                $('#waCampaignAudience').html(
                    '<option value="">Manual numbers only</option>' +
                    audiences.map(function (audience) {
                        return `
                            <option value="${Number(audience.id)}">
                                ${WA.esc(audience.name)} · #${Number(audience.id)}
                            </option>
                        `;
                    }).join('')
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Audiences unavailable for campaigns.',
                    true
                );
            });
    }

    function loadCampaigns() {
        window.WA.api('/campaigns', 'GET', {})
            .done(function (response) {
                var campaigns = (response.data || {}).campaigns || [];

                $('#waCampaignRows').html(campaigns.length
                    ? campaigns.map(function (campaign) {
                        var stateClass = campaign.state === 'queued'
                            ? 'ok'
                            : (campaign.state === 'blocked' ? 'bad' : 'warn');

                        return `
                            <tr>
                                <td><strong>${WA.esc(campaign.name || '')}</strong></td>
                                <td>${WA.esc(campaign.template_name || '')}</td>
                                <td>
                                    <span class="wa-badge ${stateClass}">
                                        ${WA.esc(campaign.state || '')}
                                    </span>
                                </td>
                                <td>${Number(campaign.queued_count || 0)}</td>
                                <td>${Number(campaign.blocked_count || 0)}</td>
                                <td>${WA.esc(campaign.created_at || '')}</td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="6" class="wa-empty">No campaigns have been created.</td></tr>'
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Campaign list unavailable.',
                    true
                );
            });
    }

    $('#waCampaignTemplate').on('change', function () {
        var language = $(this).find(':selected').data('lang') || 'en';

        $('#waCampaignLanguage')
            .html(`<option value="${WA.esc(language)}">${WA.esc(language)}</option>`)
            .val(language);
    });

    $('#waCampaignSend').on('click', function () {
        var componentsJson = $.trim($('#waCampaignComponents').val() || '[]');
        var audienceId = $('#waCampaignAudience').val();
        var recipients = $.trim($('#waCampaignRecipients').val());
        var campaignName = $('#waCampaignName').val();
        var templateName = $('#waCampaignTemplate').val();

        try {
            if (!Array.isArray(JSON.parse(componentsJson))) {
                throw new Error('Components must be a JSON array.');
            }
        } catch (error) {
            WA.toast('Components must be a JSON array.', true);
            return;
        }

        if (!campaignName || !templateName || (!audienceId && !recipients)) {
            WA.toast(
                'Campaign name, approved template, and either a saved audience or manual recipients are required.',
                true
            );
            return;
        }

        if (!window.confirm(
            'Queue this campaign? Each recipient will be checked for an enabled template, opt-in and global pause status.'
        )) {
            return;
        }

        var button = $(this);
        button.prop('disabled', true).text('Validating & queuing…');

        window.WA.api('/send/bulk', 'POST', {
            name: campaignName,
            template_name: templateName,
            language: $('#waCampaignLanguage').val(),
            components: componentsJson,
            recipients: recipients,
            audience_id: audienceId || ''
        })
            .done(function (response) {
                var data = response.data || {};

                $('#waCampaignResult').html(`
                    <div class="wa-inline-note">
                        <strong>Campaign #${WA.esc(data.campaign_id || '—')}</strong><br>
                        Total: ${Number(data.total || 0)} ·
                        Queued: ${Number(data.queued || 0)} ·
                        Blocked: ${Number(data.blocked || 0)}<br>
                        See Message Logs for delivery statuses and block reasons.
                    </div>
                `);

                WA.toast(response.message || 'Campaign processed.');
                loadCampaigns();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Campaign could not be queued.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false).text('Validate and queue campaign');
            });
    });

    loadTemplates();
    loadAudiences();
    loadCampaigns();
})(jQuery);
</script>
