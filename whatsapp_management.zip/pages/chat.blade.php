<div class="wa-page-head">
    <div>
        <h2>{{ ucfirst($kind) }} conversations</h2>
        <p>Shared WABA message history. Lead and Customer lists come from the selected ERP branch; unsaved numbers are managed in Common Chat. Free-form, media, reactions and interactive sends are limited by Meta's service window.</p>
    </div>
    <div class="wa-row">
        <button type="button" id="waNewContactToggle" class="wa-btn">＋ New contact</button>
        <a class="wa-btn wa-btn-primary" id="waTopTemplateLink" href="{{ url('/wa-management/templates') }}">Send approved template</a>
    </div>
</div>

<div id="waNewContactForm" class="wa-card" style="display:none">
    <div class="wa-card-title">Start a conversation with a new number</div>
    <div class="wa-grid-2">
        <div class="wa-field">
            <label>Contact name</label>
            <input id="waNewContactName" placeholder="Contact display name">
        </div>
        <div class="wa-field">
            <label>WhatsApp number in international format</label>
            <input id="waNewContactPhone" placeholder="+919876543210">
            <small>Unsaved numbers are added to Common Chat. A template is required to initiate outside the 24-hour customer-service window.</small>
        </div>
    </div>

    <div class="wa-row">
        <button type="button" id="waNewContactSave" class="wa-btn wa-btn-primary">Save and open chat</button>
        <button type="button" id="waNewContactCancel" class="wa-btn">Cancel</button>
    </div>
</div>

<div class="wa-chat-shell">

    <aside class="wa-chat-left">
        <div class="wa-chat-listhead">
            <input id="waChatSearch" class="wa-search" placeholder="Search contact name or number…">
            <div class="wa-row" style="margin-top:9px">
                <button id="waChatRefresh" class="wa-btn">↻ Refresh</button>
                <span class="wa-muted" id="waChatCount" style="font-size:9px"></span>
            </div>
            <div class="wa-muted" style="font-size:9px;line-height:1.6;margin-top:8px">
                {{ $kind === 'common' ? 'Common Chat includes new contacts and numbers that have messaged the shared WhatsApp number.' : 'Saved CRM contacts only · use the Branch ID field above to switch branch.' }}
            </div>
        </div>
        <div class="wa-chat-contact-list" id="waChatContacts">
            <div class="wa-empty">Loading conversations…</div>
        </div>
    </aside>

    <section class="wa-chat-window">

        <div class="wa-chat-window-head">
            <div>
                <strong id="waChatHeading">Select a conversation</strong>
                <small id="waChatSubheading">Select a contact to view message history.</small>
            </div>
            <div class="wa-row">
                <a id="waChatTemplateLink" class="wa-btn wa-btn-soft" href="{{ url('/wa-management/templates') }}">Use template</a>
                <a id="waChatCallLink" data-wa-feature="calling" class="wa-btn" href="{{ url('/wa-management/calling') }}" title="Calling requires separate Meta Calling API access">☎ Call</a>
            </div>
        </div>

        <div id="waWindowWarning" class="wa-window-closed" style="display:none"></div>

        <div id="waMessageList" class="wa-message-list">
            <div class="wa-empty">Choose a contact from the left.</div>
        </div>

        <div class="wa-chat-tools">
            <button id="waEmojiToggle" class="wa-tool-btn" type="button" title="Emoji">😀</button>
            <button id="waAttachButton" class="wa-tool-btn" type="button" title="Attach image, video, audio, PDF or document">📎</button>
            <input id="waChatMedia" type="file" style="display:none" accept="image/jpeg,image/png,image/webp,video/mp4,video/3gpp,audio/aac,audio/mp4,audio/mpeg,audio/amr,audio/ogg,audio/opus,application/pdf,text/plain,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.webp">
            <button id="waLocationButton" class="wa-tool-btn" type="button" title="Share current location">📍</button>
            <button id="waContactCardButton" class="wa-tool-btn" type="button" title="Share a contact card">♙ Contact</button>
            <button id="waInteractiveButton" class="wa-tool-btn" type="button" title="Send reply button">▤ Buttons</button>
            <button id="waFlowToggle" class="wa-tool-btn" type="button" title="Send WhatsApp Flow">Flow</button>
            <span id="waSelectedFileLabel" class="wa-selected-file"></span>
        </div>

        <div id="waEmojiTray" class="wa-emoji-tray" style="display:none"></div>

        <div id="waMediaCaptionRow" class="wa-media-caption-row" style="display:none">
            <input id="waMediaCaption" placeholder="Attachment caption (optional)">
            <button id="waSendMedia" class="wa-btn wa-btn-primary">Send attachment</button>
            <button id="waCancelMedia" class="wa-btn">Cancel</button>
        </div>

        <div id="waFlowPanel" class="wa-flow-panel" style="display:none">

            <div class="wa-grid-2">
                <div class="wa-field">
                    <label>Published Flow ID</label>
                    <input id="waFlowId" placeholder="Meta Flow ID">
                </div>
                <div class="wa-field">
                    <label>Flow token</label>
                    <input id="waFlowToken" placeholder="Unique per-session token">
                </div>
            </div>

            <div class="wa-grid-2">
                <div class="wa-field">
                    <label>Button text (CTA)</label>
                    <input id="waFlowCta" maxlength="30" value="Continue">
                </div>
                <div class="wa-field">
                    <label>Message body</label>
                    <input id="waFlowBody" maxlength="1024" placeholder="Open this form to continue">
                </div>
            </div>

            <div class="wa-field">
                <label>Initial Flow data JSON</label>
                <textarea id="waFlowData" rows="2">{}</textarea>
            </div>

            <div class="wa-row">
                <button id="waSendFlow" class="wa-btn wa-btn-primary" type="button">Queue Flow message</button>
                <button id="waCloseFlow" class="wa-btn" type="button">Close</button>
            </div>
            <small class="wa-muted">Requires a published Flow and an eligible recipient WhatsApp client. This sends a Flow message through Cloud API; Flow design and data-exchange endpoint are managed separately.</small>
        </div>

        <div class="wa-chat-compose">
            <textarea id="waChatText" placeholder="Message (free-form only inside the 24-hour customer-service window)" disabled></textarea>
            <button id="waChatSend" class="wa-btn wa-btn-primary" disabled>Send</button>
        </div>

        <div class="wa-chat-footer-note">Meta Cloud API does not expose every feature of consumer WhatsApp Web. Calls, native Groups and Channels have separate API availability/eligibility and are not simulated here.</div>
    </section>
</div>
<style>
    .wa-chat-tools{
        display:flex;
        gap:7px;
        align-items:center;
        flex-wrap:wrap;
        padding:9px 12px 0;
        background:#fff;
    }
    .wa-tool-btn{
        border:1px solid #e0e8e5;
        border-radius:9px;
        background:#fff;
        color:#50676b;
        font-size:11px;
        padding:7px 10px;
        cursor:pointer;
        font-weight:800;
    }
    .wa-tool-btn:hover{
        background:#eff8f3;
        color:#087b63;
    }

    .wa-selected-file{
        font-size:9px;
        color:#648078;
        max-width:220px;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }

    .wa-emoji-tray {
        padding: 9px 12px;
        background: #fff;
        border-top: 1px solid #eef2f0;
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }

    .wa-emoji {
        width: 31px;
        height: 31px;
        border: 0;
        background: #f5f7f6;
        border-radius: 7px;
        font-size: 19px;
        cursor: pointer;
    }

    .wa-emoji:hover{
        background:#ddf2e7;
    }

    .wa-media-caption-row{
        background:#fff;
        padding:8px 12px;
        display:flex;
        gap:8px;
        align-items:center;
        border-top:1px solid #eef2f0;
    }

    .wa-media-caption-row input{
        min-width:0;
        flex:1;
        border:1px solid #dfe8e5;
        border-radius:8px;
        padding:9px;
        font-size:11px;
    }

    .wa-flow-panel{
        padding:12px;
        background:#fff;
        border-top:1px solid #e7eeea;
        max-height:260px;
        overflow:auto;
    }

    .wa-flow-panel .wa-field{
        margin-bottom:7px;
    }

    .wa-flow-panel .wa-field input,.wa-flow-panel .wa-field textarea{
        padding:7px;
    }

    .wa-flow-panel .wa-field textarea{
        min-height:44px;
    }

    .wa-chat-footer-note{
        font-size:9px;
        padding:7px 12px;
        background:#fff;
        color:#93a0a2;
        border-top:1px solid #f0f2f2;
        line-height:1.5;
    }

    .wa-message-media{
        display:block;
        max-width:300px;
        max-height:260px;
        border-radius:8px;
        margin:2px 0 6px;
    }

    .wa-message-media.audio{
        width:260px;
        height:38px;
    }

    .wa-message-media.video{
        width:300px;
    }

    .wa-message-file{
        display:block;
        border:1px solid #d7e5df;
        background:#f8fcfa;
        padding:9px;
        border-radius:8px;
        margin:3px 0 6px;
        font-size:10px;
        color:#1b7560;
        text-decoration:none;
    }

    .wa-message-actions{
        display:flex;
        justify-content:flex-end;
        gap:5px;
        margin-top:4px;
    }

    .wa-reaction-button{
        font-size:10px;
        border:0;
        background:transparent;
        color:#8ba09a;
        cursor:pointer;
        padding:0 4px;
    }
    .wa-reaction-button:hover{
        color:#087b63;
    }
    .wa-message-bubble img{
        object-fit:contain;
    }

</style>

