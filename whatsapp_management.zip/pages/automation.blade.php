<div class="wa-page-head"><div><h2>Workflow automation</h2><p>Business events map to approved templates for the shared ERP profile. Template selection and variable mapping live in the admin database, not in every controller.</p></div><button id="waWorkflowRefresh" class="wa-btn">Refresh rules</button></div>
<div class="wa-grid-2"><div class="wa-card"><div class="wa-card-title">Create or update workflow rule</div><div class="wa-field"><label>Event key</label><input id="waEventKey" placeholder="lead.created"><small>Lowercase, for example <span class="wa-code">lead.created</span>, <span class="wa-code">customer.created</span>, <span class="wa-code">academy.event_certificate</span>.</small></div><div class="wa-grid-2"><div class="wa-field"><label>Approved template</label><select id="waWorkflowTemplate" class="wa-search"><option value="">Select template</option></select></div><div class="wa-field"><label>Language</label><select id="waWorkflowLanguage" class="wa-search"><option value="en">en</option></select></div></div><div class="wa-field"><label>Parameter mapping JSON</label><textarea id="waParameterMap" spellcheck="false">[
  {"type":"header","parameters":[{"type":"image","source":"header_image"}]},
  {"type":"body","parameters":[{"type":"text","source":"lead_name"},{"type":"text","source":"sales_mobile"}]}
]</textarea><small>Must match the approved template's exact component order/type. Media sources must be public HTTPS URLs. Use [] only for no-parameter templates.</small></div><div class="wa-field"><label>Notes</label><input id="waRuleNotes" placeholder="Lead creation welcome message"></div><label class="wa-toggle"><input type="checkbox" id="waRuleEnabled" checked> Enable this workflow rule</label><div style="margin-top:14px"><button id="waSaveRule" class="wa-btn wa-btn-primary">Save rule</button><button id="waResetRule" class="wa-btn">Clear form</button></div></div><div class="wa-card"><div class="wa-card-title">Configured event mappings</div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Event key</th><th>Template</th><th>Language</th><th>Enabled</th><th>Action</th></tr></thead><tbody id="waRuleRows"><tr><td colspan="5" class="wa-empty">Loading rules…</td></tr></tbody></table></div><div class="wa-inline-note" style="margin-top:12px">Workflow rules are shared ERP-wide. Legacy events use the exact event key shown in blocked Message Logs (pattern: legacy.controller.method.template). The sender must pass named variables. Missing mappings or unavailable templates are recorded as blocked outbox rows and do not stop the underlying ERP operation.</div></div></div>
<script>
(function ($) {
    'use strict';

    var templates = [];
    var rules = [];

    function loadTemplates() {
        window.WA.api('/templates', 'GET', {})
            .done(function (response) {
                templates = ((response.data || {}).templates || []).filter(function (template) {
                    return template.approval_status === 'APPROVED' && template.is_enabled;
                });

                $('#waWorkflowTemplate').html(
                    '<option value="">Select template</option>' +
                    templates.map(function (template) {
                        return `
                            <option value="${WA.esc(template.name)}" data-lang="${WA.esc(template.language)}">
                                ${WA.esc(template.name)} · ${WA.esc(template.language)}
                            </option>
                        `;
                    }).join('')
                );
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Templates unavailable for workflow rules.',
                    true
                );
            });
    }

    function renderRules() {
        $('#waRuleRows').html(rules.length
            ? rules.map(function (rule) {
                return `
                    <tr>
                        <td>
                            <strong>${WA.esc(rule.event_key)}</strong><br>
                            <small class="wa-muted">${WA.esc(rule.notes || '')}</small>
                        </td>
                        <td>${WA.esc(rule.template_name || '')}</td>
                        <td>${WA.esc(rule.language || '')}</td>
                        <td>
                            <span class="wa-badge ${rule.is_enabled ? 'ok' : 'warn'}">
                                ${rule.is_enabled ? 'Enabled' : 'Disabled'}
                            </span>
                        </td>
                        <td>
                            <button
                                type="button"
                                class="wa-btn waRuleToggle"
                                data-id="${WA.esc(rule.id)}"
                                data-enabled="${rule.is_enabled ? 0 : 1}"
                            >
                                ${rule.is_enabled ? 'Disable' : 'Enable'}
                            </button>
                            <button type="button" class="wa-btn waRuleEdit" data-id="${WA.esc(rule.id)}">
                                Edit
                            </button>
                        </td>
                    </tr>
                `;
            }).join('')
            : '<tr><td colspan="5" class="wa-empty">No workflow rules configured yet.</td></tr>'
        );
    }

    function loadRules() {
        window.WA.api('/workflow-rules', 'GET', {})
            .done(function (response) {
                rules = (response.data || {}).rules || [];
                renderRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Rules unavailable.',
                    true
                );
            });
    }

    $('#waWorkflowTemplate').on('change', function () {
        var language = $(this).find(':selected').data('lang') || 'en';

        $('#waWorkflowLanguage')
            .html(`<option value="${WA.esc(language)}">${WA.esc(language)}</option>`)
            .val(language);
    });

    $('#waSaveRule').on('click', function () {
        var mappingJson = $.trim($('#waParameterMap').val() || '[]');

        try {
            var mapping = JSON.parse(mappingJson);
            if (!Array.isArray(mapping)) {
                throw new Error('Parameter mapping must be an array.');
            }
        } catch (error) {
            WA.toast('Parameter mapping must be a JSON array.', true);
            return;
        }

        var payload = {
            event_key: $.trim($('#waEventKey').val()),
            template_name: $('#waWorkflowTemplate').val(),
            language: $('#waWorkflowLanguage').val(),
            parameter_map_json: mappingJson,
            notes: $('#waRuleNotes').val(),
            is_enabled: $('#waRuleEnabled').is(':checked') ? 1 : 0
        };

        if (!payload.event_key || !payload.template_name) {
            WA.toast('Event key and template are required.', true);
            return;
        }

        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/workflow-rules', 'POST', payload)
            .done(function (response) {
                WA.toast(response.message || 'Rule saved.');
                loadRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save workflow.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waRuleRows').on('click', '.waRuleToggle', function () {
        var button = $(this);

        window.WA.api('/workflow-rules/toggle', 'POST', {
            id: button.data('id'),
            enabled: button.data('enabled')
        })
            .done(function () {
                loadRules();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Update failed.',
                    true
                );
            });
    });

    $('#waRuleRows').on('click', '.waRuleEdit', function () {
        var ruleId = Number($(this).data('id'));
        var rule = rules.find(function (item) {
            return Number(item.id) === ruleId;
        });

        if (!rule) {
            return;
        }

        $('#waEventKey').val(rule.event_key);
        $('#waWorkflowTemplate').val(rule.template_name).trigger('change');
        $('#waWorkflowLanguage').val(rule.language);
        $('#waParameterMap').val(rule.parameter_map_json || '[]');
        $('#waRuleNotes').val(rule.notes || '');
        $('#waRuleEnabled').prop('checked', !!rule.is_enabled);
    });

    $('#waWorkflowRefresh').on('click', function () {
        loadRules();
        loadTemplates();
    });

    $('#waResetRule').on('click', function () {
        $('#waEventKey, #waRuleNotes').val('');
        $('#waParameterMap').val('[]');
        $('#waRuleEnabled').prop('checked', true);
    });

    loadTemplates();
    loadRules();
})(jQuery);
</script>
