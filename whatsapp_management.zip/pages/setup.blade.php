<div class="wa-page-head"><div><h2>API & menu controls</h2><p>Keep tokens encrypted at rest, choose the correct WABA and phone-number ID, and keep sending disabled until an internal opt-in test passes.</p></div><button id="waSetupReload" class="wa-btn">Reload configuration</button></div>
<div class="wa-grid-2"><div class="wa-card"><div class="wa-card-title">Meta Cloud API profile</div><div class="wa-field"><label>WhatsApp Business Account ID (WABA ID)</label><input id="waWabaId" placeholder="Meta WABA ID"></div><div class="wa-field"><label>Phone Number ID (not the visible phone number)</label><input id="waPhoneNumberId" placeholder="Meta Phone Number ID"></div><div class="wa-field"><label>Graph API version</label><input id="waGraphVersion" value="{{ config('whatsapp.api_version', 'v26.0') }}" placeholder="v26.0"><small>Pin a currently supported version; review Meta version deprecation before upgrades.</small></div><div class="wa-field"><label>System-user access token</label><input id="waAccessToken" type="password" autocomplete="new-password" placeholder="Leave blank to keep the currently saved token"><small>Token is stored encrypted using Laravel APP_KEY and is never returned to the browser. Do not paste tokens into logs or source files.</small></div><div class="wa-field"><label>Minimum interval between sends (seconds)</label><input type="number" id="waSendInterval" min="5" max="60" value="10"></div><label class="wa-toggle"><input type="checkbox" id="waProfileEnabled"> Enable the shared ERP outbound API profile</label><div class="wa-row" style="margin-top:14px"><button id="waSaveConfig" class="wa-btn wa-btn-primary">Save profile</button><button id="waTestConfig" class="wa-btn wa-btn-soft">Test credentials</button><button id="waToggleProfile" class="wa-btn">Pause shared sends</button></div><div id="waProfileStatus" style="margin-top:12px"></div></div>
<div class="wa-card"><div class="wa-card-title">Feature switches · shared ERP</div><p class="wa-muted" style="font-size:10px;line-height:1.7">Menus and chat modules can be enabled only where the destination ERP tables and permissions exist. Disabling a menu does not delete message history.</p><div id="waFeatureList" class="wa-check-grid"><div class="wa-empty">Loading feature settings…</div></div><button id="waSaveFeatures" class="wa-btn wa-btn-primary" style="margin-top:14px">Save menu switches</button><div class="wa-inline-note wa-inline-warning" style="margin-top:18px"><strong>Webhook security:</strong> set <span class="wa-code">WHATSAPP_VERIFY_TOKEN</span> and <span class="wa-code">META_APP_SECRET</span> in server environment. The webhook verifies the HMAC signature. The access token itself belongs in the encrypted profile.</div></div></div>
<div class="wa-card"><div class="wa-card-title">Production guardrails</div><div class="wa-check-grid"><div class="wa-check-card"><strong>Approved templates only</strong><small>Initiating a business conversation uses an approved, enabled template matching the recipient's consent category.</small></div><div class="wa-check-card"><strong>24-hour customer-service window</strong><small>Free-form text is rejected unless the last inbound customer message was within 24 hours.</small></div><div class="wa-check-card"><strong>Global kill switch</strong><small>The button in the top bar pauses all outbound sends without removing saved configuration.</small></div><div class="wa-check-card"><strong>Safe uncertain delivery</strong><small>Ambiguous network errors are marked unknown rather than blindly retried, preventing duplicate sends.</small></div></div><div class="wa-inline-note" style="margin-top:12px">Use a dedicated least-privilege Meta system user, rotate exposed credentials, configure webhook subscriptions and a durable queue worker, and test against staging numbers before enabling production events.</div></div>
<script>
(function ($) {
    'use strict';

    var profile = null;
    var featureLabels = {
        lead_chat: [
            'Lead chat',
            'Uses the configured lead table and branch scoping.'
        ],
        customer_chat: [
            'Customer chat',
            'Optional; enable only when this ERP has the customer module.'
        ],
        common_chat: [
            'Common chat',
            'General one-to-one conversation list.'
        ],
        custom_group_chat: [
            'Custom audiences',
            'ERP saved recipient lists; not native WhatsApp groups.'
        ],
        broadcast_channel: [
            'Broadcast manager',
            'Paced template campaigns; not WhatsApp Channels publishing.'
        ],
        bulk_campaigns: [
            'Bulk campaigns',
            'Allows paced template campaigns with per-recipient consent checks.'
        ],
        calling: [
            'Calling capability',
            'Requires separate Meta calling eligibility, permissions and call flow implementation.'
        ]
    };

    function loadFeatures() {
        window.WA.api('/features', 'GET', {})
            .done(function (response) {
                var features = (response.data || {}).features || {};

                $('#waFeatureList').html(Object.keys(featureLabels).map(function (key) {
                    var label = featureLabels[key];

                    return `
                        <label class="wa-check-card">
                            <span class="wa-toggle">
                                <input
                                    type="checkbox"
                                    class="waFeature"
                                    data-key="${WA.esc(key)}"
                                    ${features[key] ? 'checked' : ''}
                                >
                                <strong>${WA.esc(label[0])}</strong>
                            </span>
                            <small>${WA.esc(label[1])}</small>
                        </label>
                    `;
                }).join(''));
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Feature settings unavailable.',
                    true
                );
            });
    }

    function loadProfile() {
        window.WA.api('/config', 'GET', {})
            .done(function (response) {
                profile = response.data || {};

                $('#waWabaId').val(profile.waba_id || '');
                $('#waPhoneNumberId').val(profile.phone_number_id || '');
                $('#waGraphVersion').val(profile.graph_api_version || 'v26.0');
                $('#waSendInterval').val(profile.min_send_interval_seconds || 10);
                $('#waProfileEnabled').prop('checked', !!profile.is_enabled);
                $('#waToggleProfile')
                    .text(profile.is_enabled ? 'Pause shared sends' : 'Resume shared sends')
                    .data('enabled', !profile.is_enabled);

                $('#waProfileStatus').html(`
                    <div class="wa-inline-note">
                        ${profile.configured ? 'Shared profile exists' : 'No shared profile saved yet'}
                        · Token: ${profile.token_saved ? 'encrypted token present' : 'not saved'}
                        · Sending: ${profile.is_enabled ? 'enabled' : 'paused'}
                    </div>
                `);
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not load profile.',
                    true
                );
            });

        loadFeatures();
    }

    $('#waSetupReload').on('click', loadProfile);

    $('#waSaveConfig').on('click', function () {
        var button = $(this);
        button.prop('disabled', true);

        window.WA.api('/config', 'POST', {
            waba_id: $('#waWabaId').val(),
            phone_number_id: $('#waPhoneNumberId').val(),
            graph_api_version: $('#waGraphVersion').val(),
            access_token: $('#waAccessToken').val(),
            is_enabled: $('#waProfileEnabled').is(':checked') ? 1 : 0,
            min_send_interval_seconds: $('#waSendInterval').val()
        })
            .done(function () {
                $('#waAccessToken').val('');
                WA.toast('Profile saved.');
                loadProfile();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Profile save failed.',
                    true
                );
            })
            .always(function () {
                button.prop('disabled', false);
            });
    });

    $('#waTestConfig').on('click', function () {
        var button = $(this);
        button.prop('disabled', true).text('Testing…');

        window.WA.api('/config/test', 'POST', {})
            .done(function (response) {
                var message = response.message || 'Connection success';
                $('#waProfileStatus').html(`
                    <div class="wa-inline-note">${WA.esc(message)}</div>
                `);
                WA.toast(message);
            })
            .fail(function (error) {
                var response = error.responseJSON || {};
                var message = response.message || 'Connection failed';

                $('#waProfileStatus').html(`
                    <div class="wa-inline-note wa-inline-warning">${WA.esc(message)}</div>
                `);
                WA.toast(response.message || 'Test failed.', true);
            })
            .always(function () {
                button.prop('disabled', false).text('Test credentials');
            });
    });

    $('#waToggleProfile').on('click', function () {
        var button = $(this);

        window.WA.api('/config/toggle', 'POST', {
            enabled: button.data('enabled')
        })
            .done(function (response) {
                WA.toast(response.message || 'Shared ERP setting updated.');
                loadProfile();
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not update profile.',
                    true
                );
            });
    });

    $('#waSaveFeatures').on('click', function () {
        var payload = {};

        // Match jQuery's nested form encoding for the shared Fetch-backed WA.api helper.
        $('.waFeature').each(function () {
            var key = $(this).data('key');
            payload[`features[${key}]`] = $(this).is(':checked');
        });

        window.WA.api('/features', 'POST', payload)
            .done(function () {
                WA.toast('Feature switches saved. Reload to apply sidebar visibility.');
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Could not save menu switches.',
                    true
                );
            });
    });

    loadProfile();
})(jQuery);
</script>
