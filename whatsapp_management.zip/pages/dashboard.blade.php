<div class="wa-page-head"><div><h2>Messaging overview</h2><p>Template traffic, queue outcomes and delivery receipts for the selected branch. Month-to-date is the default reporting period.</p></div><div class="wa-row"><select id="waAnalyticsPeriod" class="wa-search" style="width:110px"><option value="month">Month</option><option value="year">Year</option></select><select id="waAnalyticsMonth" class="wa-search" style="width:130px"></select><select id="waAnalyticsYear" class="wa-search" style="width:95px"></select><button class="wa-btn wa-btn-primary" id="waAnalyticsRefresh">Refresh</button></div></div>
<div class="wa-grid" id="waStats"><div class="wa-stat"><div class="wa-stat-label">Sent / accepted</div><div class="wa-stat-value">—</div></div><div class="wa-stat"><div class="wa-stat-label">Delivered</div><div class="wa-stat-value">—</div></div><div class="wa-stat"><div class="wa-stat-label">Read</div><div class="wa-stat-value">—</div></div><div class="wa-stat"><div class="wa-stat-label">Failed / blocked</div><div class="wa-stat-value">—</div></div></div>
<div class="wa-grid-2" style="margin-top:14px"><div class="wa-card"><div class="wa-card-title">Delivery status breakdown</div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Status</th><th>Messages</th><th>Share</th></tr></thead><tbody id="waStatusRows"><tr><td colspan="3" class="wa-empty">Loading analytics…</td></tr></tbody></table></div></div><div class="wa-card"><div class="wa-card-title">Monthly send volume · selected year</div><div class="wa-table-wrap"><table class="wa-table"><thead><tr><th>Month</th><th>Queued</th><th>Sent</th><th>Delivered</th><th>Read</th><th>Failed</th></tr></thead><tbody id="waMonthlyRows"></tbody></table></div><div class="wa-inline-note" style="margin-top:12px">“Sent” means accepted by Meta, not guaranteed delivered. Delivery/read/failure counts depend on signed webhook receipts.</div></div></div>
<div class="wa-card" style="margin-top:14px"><div class="wa-card-title">Operational status</div><div class="wa-grid-2"><div><div id="waProfileSummary" class="wa-inline-note">Loading branch configuration…</div></div><div><div id="waTotalsSummary" class="wa-inline-note">Loading campaign summary…</div><div style="margin-top:10px"><a class="wa-btn" href="{{ url('/wa-management/setup') }}">Open setup</a> <a class="wa-btn" href="{{ url('/wa-management/logs') }}">Inspect message logs</a> <a class="wa-btn" href="{{ url('/wa-management/templates') }}">Review templates</a></div></div></div></div>
<script>
(function ($) {
    'use strict';

    var months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    var currentMonth = currentDate.getMonth() + 1;

    for (var month = 1; month <= 12; month++) {
        $('#waAnalyticsMonth').append(`
            <option value="${month}" ${month === currentMonth ? 'selected' : ''}>
                ${months[month - 1]}
            </option>
        `);
    }

    for (var year = currentYear - 3; year <= currentYear + 1; year++) {
        $('#waAnalyticsYear').append(`
            <option value="${year}" ${year === currentYear ? 'selected' : ''}>
                ${year}
            </option>
        `);
    }

    function formatNumber(value) {
        return Number(value || 0).toLocaleString();
    }

    function loadAnalytics() {
        var period = $('#waAnalyticsPeriod').val();

        $('#waAnalyticsMonth').prop('disabled', period === 'year');

        window.WA.api('/analytics', 'GET', {
            period: period,
            month: $('#waAnalyticsMonth').val(),
            year: $('#waAnalyticsYear').val()
        })
            .done(function (response) {
                var data = response.data || {};
                var counts = data.counts || {};
                var total = Object.keys(counts).reduce(function (sum, key) {
                    return sum + Number(counts[key] || 0);
                }, 0);
                var sent = Number(counts.sent || 0) +
                    Number(counts.delivered || 0) +
                    Number(counts.read || 0);
                var statistics = [
                    ['Sent / accepted', sent, 'Meta accepted this month'],
                    ['Delivered', counts.delivered || 0, 'Confirmed delivery receipts'],
                    ['Read', counts.read || 0, 'Confirmed read receipts'],
                    [
                        'Failed / blocked',
                        Number(counts.failed || 0) + Number(counts.blocked || 0),
                        'Inspect errors and consent blocks'
                    ]
                ];

                $('#waStats').html(statistics.map(function (item) {
                    return `
                        <div class="wa-stat">
                            <div class="wa-stat-label">${item[0]}</div>
                            <div class="wa-stat-value">${formatNumber(item[1])}</div>
                            <div class="wa-stat-note">${item[2]}</div>
                        </div>
                    `;
                }).join(''));

                var statusKeys = Object.keys(counts).sort();
                $('#waStatusRows').html(statusKeys.length
                    ? statusKeys.map(function (key) {
                        var statusClass = ['delivered', 'read'].indexOf(key) >= 0
                            ? 'ok'
                            : (['failed', 'blocked'].indexOf(key) >= 0 ? 'bad' : 'warn');
                        var share = (100 * Number(counts[key] || 0) / (total || 1)).toFixed(1);

                        return `
                            <tr>
                                <td><span class="wa-badge ${statusClass}">${WA.esc(key)}</span></td>
                                <td>${formatNumber(counts[key])}</td>
                                <td>${share}%</td>
                            </tr>
                        `;
                    }).join('')
                    : '<tr><td colspan="3" class="wa-empty">No messages in this period.</td></tr>'
                );

                var monthlyRows = Array.from({ length: 12 }, function () {
                    return {};
                });

                (data.by_month || []).forEach(function (item) {
                    if (item.month_num >= 1 && item.month_num <= 12) {
                        monthlyRows[item.month_num - 1][item.status] = item.total;
                    }
                });

                $('#waMonthlyRows').html(monthlyRows.map(function (row, index) {
                    return `
                        <tr>
                            <td>${months[index]}</td>
                            <td>${formatNumber(row.queued || 0)}</td>
                            <td>${formatNumber(row.sent || 0)}</td>
                            <td>${formatNumber(row.delivered || 0)}</td>
                            <td>${formatNumber(row.read || 0)}</td>
                            <td>${formatNumber(row.failed || 0)}</td>
                        </tr>
                    `;
                }).join(''));
            })
            .fail(function (error) {
                WA.toast(
                    error.responseJSON && error.responseJSON.message ||
                    'Analytics unavailable.',
                    true
                );
            });

        window.WA.api('/overview', 'GET', {})
            .done(function (response) {
                var data = response.data || {};

                $('#waProfileSummary').html(`
                    <strong>Branch profile:</strong> ${data.profile_configured ? 'API profile configured' : 'Not configured'}<br>
                    <strong>Sending:</strong> ${data.profile_enabled ? 'Enabled' : 'Paused'}<br>
                    <strong>Approved templates:</strong> ${formatNumber(data.templates_approved)} / ${formatNumber(data.templates_total)}<br>
                    <strong>Global pause:</strong> ${data.global_kill_switch ? 'ON' : 'OFF'}
                `);

                $('#waTotalsSummary').html(`
                    <strong>Campaigns this month:</strong> ${formatNumber(data.campaigns_month)}<br>
                    <strong>Month starts:</strong> ${WA.esc(new Date().toLocaleDateString())}<br>
                    <small>Configure template approval, explicit consent and a durable queue before production activation.</small>
                `);
            });
    }

    $('#waAnalyticsRefresh, #waAnalyticsPeriod, #waAnalyticsMonth, #waAnalyticsYear')
        .on('change click', loadAnalytics);

    loadAnalytics();
})(jQuery);
</script>
