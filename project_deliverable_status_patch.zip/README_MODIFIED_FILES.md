# ARGUS Project Overview — Deliverable and Project Status Fix

This is a **modified-files-only patch** based on the latest supplied `ui_src(4).zip`, `vendor_src(1).zip`, and `server_src(1).zip`. The UI source was used as the interaction reference. The patch contains only four source files and this README; it does not include a complete application, build output, dependencies, or environment secrets.

## Modified files

### Vendor panel

1. `vendor/src/components/projects/project_overview.tsx`
   - Removes the unconditional vendor block from the Add Deliverable submit handler.
   - Enables submission for users with the existing `project.edit` permission when a deliverable name and due date have been entered, following the UI source validation behavior.
   - Adds a saving state to prevent duplicate submissions and provides success/error handling while updating the visible list after the API returns the saved deliverable.
   - Enables the status selector for users with `project.edit` permission, saves the selection to the existing project update API, refreshes project details after saving, and reports errors instead of silently ignoring the selection.
   - Normalizes backend statuses such as `in_progress` and `on_hold` into the UI labels shown in the dropdown.

2. `vendor/src/components/projects/project.tsx`
   - Includes `status` in the project PATCH payload when a status update is requested (the previous allowlist silently omitted it).
   - Normalizes backend status values for the project list/context so the selected status and badge stay in sync after a save.

### Backend

3. `backend/src/routes/project.routes.js`
   - Allows vendors with the existing `project.edit` permission to use the status-update and add-deliverable endpoints, while preserving internal/admin authorization behavior.

4. `backend/src/services/project/projectService.js`
   - Allows `status` as the only new vendor-editable project field. Existing vendor field restrictions still apply to all other project properties.
   - Uses existing project ownership validation so a vendor can only change the status of that vendor's own project.
   - Reuses existing audit behavior and status validation.

## Behavior and security

- Deliverable name and due date are required in the form, matching the supplied UI source. The Add button remains disabled until both fields are valid and the user has `project.edit` permission.
- Vendor authorization remains permission- and record-scoped: the API checks project edit permission and the service checks that the project belongs to the current vendor. The patch does not grant vendors access to other vendors' projects.
- Status choices remain `Planned`, `In Progress`, `On Hold`, `Completed`, and `Closed`.
- Existing project fields, deliverable update/delete permissions, payment schedule logic, and unrelated screens are unchanged.

## Validation

- All backend JavaScript files passed `node --check`.
- The two modified TSX files passed TypeScript TSX syntax transpilation.
- Relative import-path checks passed for both modified vendor files.
- A full application production build and authenticated staging test were not run because the supplied source archives did not include project dependency manifests/dependencies in the workspace. Syntax checks are not a substitute for the production build.

## Apply

The ZIP keeps `vendor/` and `backend/` prefixes for clarity. Copy the files beneath `vendor/src/...` into the vendor application repository and beneath `backend/src/...` into the backend repository, overwriting only the same four files after making backups. Then build both projects and test adding a deliverable and changing project status using an authorized vendor account in staging before deploying.
