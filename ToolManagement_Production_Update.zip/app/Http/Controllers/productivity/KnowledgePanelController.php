<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\KnowledgePost;
use App\Models\StaffModel;
use App\Services\FavIcon\BookmarkFaviconService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KnowledgePanelController extends ProductivityBaseController
{
    public function index()
    {
        return view('content.productivity.knowledge.index');
    }

    public function categories(Request $request): JsonResponse
    {
        $ctx = $this->knowledgeUserContext($request);
        
        $uid = (int) $ctx['uid'];

        /*
         * role_id = 1 is the Knowledge full-view administrator.
         * This account can legitimately use user_id = 0, so do not reject it
         * just because there is no staff sno.
         */
        if ((int) $ctx['role_id'] !== 1) {
            abort_unless($uid > 0, 401, 'Authenticated Knowledge user is required.');
        }

        $query = DB::table('egc_tool_knowledge_categories as c')
            ->leftJoin('egc_company as co', function ($join) {
                $join->on('co.sno', '=', 'c.company_id')->where('co.status', 0);
            })
            ->where('c.status', 0)
            ->whereNull('c.deleted_at')
            ->select([
                'c.sno', 'c.company_id', 'c.category_name', 'c.color', 'c.status', 'c.audience_json',
                DB::raw("COALESCE(co.company_name, 'Group') as company_name"),
            ])
            ->selectSub(function ($q) use ($uid) {
                $q->from('egc_tool_knowledge_follows as f')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('f.category_id', 'c.sno')
                    ->where('f.user_id', $uid);
            }, 'following')
            ->selectSub(function ($q) use ($request) {
                $q->from('egc_tool_knowledge_posts as p')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('p.category_id', 'c.sno')
                    ->where('p.status', 'published')
                    ->whereNull('p.deleted_at');

                // Category counts must use exactly the same audience authorization
                // as the Knowledge feed. This keeps sidebar counts from exposing
                // posts the logged-in user cannot actually read.
                $this->applyKnowledgeReadableQueryScope($q, $request);
            }, 'post_count')
            ->orderBy('c.category_name');

        // Categories themselves remain available as before; only the post_count
        // is audience-filtered for the logged-in user.

        $categories = $query->get()->map(function ($category) {
            $category->audience_json = $this->decodeKnowledgeAudience($category->audience_json ?? null);
            $category->audience_mode = $category->audience_json['audience_mode'] ?? 'company';
            return $category;
        });

        return $this->ok([
            'categories' => $categories,
        ]);
    }

    public function settingsData(Request $request): JsonResponse
    {
        $query = DB::table('egc_tool_knowledge_categories as c')
            ->leftJoin('egc_company as co', function ($join) {
                $join->on('co.sno', '=', 'c.company_id')->where('co.status', 0);
            })
            ->whereNull('c.deleted_at')
            ->select([
                'c.sno', 'c.company_id', 'c.category_name', 'c.color', 'c.status',
                'c.audience_json', 'c.created_at', 'c.updated_at',
                DB::raw("COALESCE(co.company_name, 'Group') as company_name"),
            ])
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_posts as p')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('p.category_id', 'c.sno')
                    ->whereNull('p.deleted_at');
            }, 'post_count')
            ->orderBy('c.category_name');

        $this->applySettingsCompanyScope($query, $request, 'c.company_id');
        $categories = $query->get()->map(function ($category) {
            $audience = $this->decodeKnowledgeAudience($category->audience_json ?? null);
            $category->audience_json = $audience;
            $category->audience_mode = $audience['audience_mode'] ?? 'company';
            $category->audience_label = ucfirst($category->audience_mode) . ' access';
            return $category;
        });

        return $this->ok([
            'categories' => $categories,
            'can_manage' => $this->canManageSettings($request),
            'is_group_admin' => $this->access->isGroupAdmin($request),
            'is_company_admin' => $this->access->isCompanyAdmin($request),
        ]);
    }

    public function data(Request $r): JsonResponse
    {
        $status = (string) $r->get('status', 'published');
        abort_unless(in_array($status, ['draft', 'published', 'unpublished'], true), 422, 'Invalid knowledge post status.');
        $q = KnowledgePost::withoutGlobalScopes()
            ->from('egc_tool_knowledge_posts as p')
            ->leftJoin('egc_company as co', function ($join) {
                $join->on('co.sno', '=', 'p.company_id')->where('co.status', 0);
            })
            ->leftJoin('egc_staff as s', 's.sno', '=', 'p.author_user_id')
            ->leftJoin('egc_tool_knowledge_categories as c', 'c.sno', '=', 'p.category_id')
            ->whereNull('p.deleted_at')
            ->where('p.status', $status)
            ->whereNull('c.deleted_at')
            ->where('c.status', 0)
            ->select([
                'p.*',
                DB::raw("COALESCE(s.staff_name, 'ERP User') as author_name"),
                DB::raw("COALESCE(co.company_name, 'Group') as company_name"),
                'c.category_name',
                'c.color as category_color',
                'c.audience_json as category_audience_json',
                's.gender as author_gender',
                's.staff_image as author_staff_image',
                's.company_type as author_company_type',
                's.company_id as author_company_id',
                's.entity_id as author_entity_id',
            ])
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_replies as r')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('r.post_id', 'p.sno');
            }, 'replies_count')
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_reactions as rx')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('rx.post_id', 'p.sno');
            }, 'likes_count')
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_saves as sv')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('sv.post_id', 'p.sno');
            }, 'saves_count')
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_reactions as rx')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('rx.post_id', 'p.sno')
                    ->where('rx.user_id', $this->uid())
                    ->where('rx.reaction', 'like');
            }, 'liked_by_me')
            ->selectSub(function ($q) {
                $q->from('egc_tool_knowledge_saves as sv')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('sv.post_id', 'p.sno')
                    ->where('sv.user_id', $this->uid());
            }, 'saved_by_me');

        $this->applyKnowledgeReadableQueryScope($q, $r);

        /*
         * Trending is a separate, audience-filtered feed.
         * Do not inherit the current category/search/content filters.
         * The UI labels this as "30 days", so enforce that window here.
         */
        $trendingQuery = clone $q;
        $trendingQuery->where('p.published_at', '>=', now()->subDays(30));

        if ($r->boolean('saved_only')) {
            $q->whereExists(function ($saveQuery) {
                $saveQuery->from('egc_tool_knowledge_saves as my_save')
                    ->whereColumn('my_save.post_id', 'p.sno')
                    ->where('my_save.user_id', $this->uid());
            });
        }

        if ($r->filled('category_id')) {
            $q->where('p.category_id', (int) $r->input('category_id'));
        }
        if ($r->filled('search')) {
            $search = trim((string) $r->input('search'));
            $q->where(function ($x) use ($search) {
                $like = '%' . $search . '%';
                $x->where('p.title', 'like', $like)
                    ->orWhere('p.body_html', 'like', $like)
                    ->orWhere('p.tags_json', 'like', $like)
                    ->orWhere('s.staff_name', 'like', $like)
                    ->orWhere('c.category_name', 'like', $like);
            });
        }
        if ($r->filled('content_type')) {
            $type = strtolower((string) $r->input('content_type'));
            $q->where(function ($x) use ($type) {
                if ($type === 'text') {
                    $x->whereNotExists(function ($m) {
                        $m->from('egc_tool_knowledge_post_media as m')->whereColumn('m.post_id', 'p.sno');
                    });
                } elseif ($type === 'image' || $type === 'video' || $type === 'audio') {
                    $x->whereExists(function ($m) use ($type) {
                        $m->from('egc_tool_knowledge_post_media as m')
                            ->whereColumn('m.post_id', 'p.sno')
                            ->where('m.media_type', $type);
                    });
                } elseif ($type === 'pdf') {
                    $x->whereExists(function ($m) {
                        $m->from('egc_tool_knowledge_post_media as m')
                            ->whereColumn('m.post_id', 'p.sno')
                            ->where('m.mime_type', 'application/pdf');
                    });
                } elseif ($type === 'files') {
                    $x->whereExists(function ($m) {
                        $m->from('egc_tool_knowledge_post_media as m')
                            ->whereColumn('m.post_id', 'p.sno')
                            ->where('m.media_type', 'file');
                    });
                } elseif ($type === 'url') {
                    $x->where('p.body_html', 'like', '%http%');
                }
            });
        }

        $sort = strtolower((string) $r->get('sort', 'newest'));
        if ($sort === 'most-liked') {
            $q->orderByDesc('likes_count')->orderByDesc('p.published_at');
        } elseif ($sort === 'relevance' && $r->filled('search')) {
            $q->orderByDesc('p.published_at');
        } else {
            $q->orderByDesc('p.published_at')->orderByDesc('p.sno');
        }

        $authorProfileUrl = function ($post) {
            $staff = new StaffModel();
            $staff->setRawAttributes([
                'gender' => $post->author_gender,
                'staff_image' => $post->author_staff_image,
                'company_type' => $post->author_company_type,
                'company_id' => $post->author_company_id,
                'entity_id' => $post->author_entity_id,
            ], true);

            $post->author_profile_url = $staff->profile_image_url;

            unset(
                $post->author_gender,
                $post->author_staff_image,
                $post->author_company_type,
                $post->author_company_id,
                $post->author_entity_id
            );

            return $post;
        };

        $pageSize = min(max((int) $r->get('per_page', 12), 6), 30);
        $rows = $q->paginate($pageSize);
        $rows->getCollection()->transform(function ($post) use ($authorProfileUrl) {
            $post->body_html = $this->cleanHtml($post->body_html);
            $post->media = $this->mediaForPost((int) $post->sno);
            $post->url_preview = $this->buildUrlPreview($post);
            $post->category_audience_label = $this->knowledgeAudienceLabel($post->category_audience_json ?? null);
            unset($post->category_audience_json);
            return $authorProfileUrl($post);
        });

        $trending = $trendingQuery->get()->map(function ($post) use ($authorProfileUrl) {
            $post->body_html = $this->cleanHtml($post->body_html);
            $post->url_preview = $this->buildUrlPreview($post);
            $post->category_audience_label = $this->knowledgeAudienceLabel($post->category_audience_json ?? null);
            unset($post->category_audience_json);
            return $authorProfileUrl($post);
        });
        $trending = $trending->sortByDesc(function ($row) {
            return ((int) $row->likes_count * 10) + ((int) $row->replies_count * 4) + ((int) $row->saves_count * 2);
        })->take(5)->values();

        return $this->ok([
            'rows' => $rows,
            'trending' => $trending,
        ]);
    }

    public function audienceOptions(Request $r): JsonResponse
    {
        $mode = strtolower((string) $r->input('mode', 'company'));
        abort_unless(in_array($mode, ['company', 'entity', 'role', 'staff'], true), 422, 'Invalid audience type.');

        $generalTitle = trim((string) (DB::table('egc_general_settings')->where('sno', 1)->value('title') ?? 'General'));
        $groupAdmin = $this->access->isGroupAdmin($r);
        $companyId = $this->cid();

        $selectedEntityIds = $this->normalizeAudienceValue($r->input('entity_ids', []), true);
        $selectedCompanyIds = $this->normalizeAudienceValue($r->input('company_ids', []), true);

        if ($mode === 'company') {
            $query = DB::table('egc_company')
                ->where('status', 0)
                ->select(['sno', 'company_name', 'company_short_name', 'company_base_color'])
                ->orderBy('company_name');

            if (!$groupAdmin && $companyId !== null) {
                $query->where('sno', $companyId);
            }

            return $this->ok([
                'mode' => 'company',
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All companies'],
                'items' => $query->get(),
            ]);
        }

        $entityQuery = DB::table('egc_entity as e')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'e.company_id')
            ->where('e.status', 0)
            ->select([
                'e.sno', 'e.company_id', 'e.entity_name', 'e.entity_short_name',
                'c.company_name',
            ])
            ->orderBy('e.entity_name');

        if (!$groupAdmin && $companyId !== null) {
            $entityQuery->where('e.company_id', $companyId);
        }

        $entities = $entityQuery->get();

        if ($mode === 'entity') {
            return $this->ok([
                'mode' => 'entity',
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All entities'],
                'items' => $entities,
            ]);
        }

        $entityIds = array_values(array_filter($selectedEntityIds, static fn ($v) => $v !== 'all'));
        if (in_array('all', $selectedEntityIds, true)) {
            $entityIds = $entities->pluck('sno')->map(fn ($v) => (int) $v)->all();
            $entityIds[] = 0;
        }
        if (!$entityIds) {
            return $this->ok([
                'mode' => $mode,
                'items' => [],
                'entities' => [
                    'general' => ['value' => 0, 'label' => $generalTitle],
                    'all' => ['value' => 'all', 'label' => 'All entities'],
                    'items' => $entities,
                ],
            ]);
        }

        if ($mode === 'role') {
            $roleQuery = DB::table('egc_user_role as ur')
                ->where('ur.status', 0)
                ->leftJoin('egc_entity as entity', 'entity.sno', '=', 'ur.entity_id')
                ->select(['ur.sno', 'ur.entity_id','entity.entity_name', 'ur.role_name', 'ur.company_id'])
                ->orderBy('ur.role_name');

            if (!in_array(0, $entityIds, true) || count($entityIds) > 1) {
                $roleQuery->whereIn('ur.entity_id', $entityIds);
            } else {
                $roleQuery->where('ur.entity_id', 0);
            }

            $roles = $roleQuery->get();
            return $this->ok([
                'mode' => 'role',
                'items' => $roles,
                'entities' => [
                    'general' => ['value' => 0, 'label' => $generalTitle],
                    'all' => ['value' => 'all', 'label' => 'All entities'],
                    'items' => $entities,
                ],
                'all_roles' => ['value' => 'all', 'label' => 'All roles'],
            ]);
        }

        $staffQuery = DB::table('egc_staff as s')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->where('s.status', 0)
            ->where('s.sno', '>', 0)
            ->select([
                's.sno', 's.staff_name', 's.staff_id', 's.email_id', 's.role_id',
                's.entity_id', 's.company_id', 'e.entity_name', 'c.company_name',
            ])
            ->orderBy('s.staff_name');

        if (!$groupAdmin && $companyId !== null) {
            $staffQuery->where('s.company_id', $companyId);
        }
        if (!in_array(0, $entityIds, true) || count($entityIds) > 1) {
            $staffQuery->whereIn('s.entity_id', $entityIds);
        } else {
            $staffQuery->where('s.entity_id', 0);
        }

        return $this->ok([
            'mode' => 'staff',
            'items' => $staffQuery->get(),
            'entities' => [
                'general' => ['value' => 0, 'label' => $generalTitle],
                'all' => ['value' => 'all', 'label' => 'All entities'],
                'items' => $entities,
            ],
        ]);
    }

    public function shareData(int $id, Request $r): JsonResponse
    {
        $post = KnowledgePost::findOrFail($id);
        abort_unless($this->canManageKnowledgeResource($r, $post), 403, 'You do not have permission to share this Knowledge post.');

        $rows = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'knowledge')
            ->where('resource_id', $id)
            ->whereIn('status', ['active', 'pending'])
            ->where(function ($q) {
                $q->where(function ($audience) {
                    $audience->where('metadata_json', 'like', '%"source":"knowledge_audience"%')
                        ->where(function ($context) {
                            $context->whereNull('metadata_json')
                                ->orWhere('metadata_json', 'like', '%"audience_context":"share"%');
                        });
                })->orWhere(function ($legacy) {
                    $legacy->whereNull('metadata_json')
                        ->orWhere('metadata_json', 'not like', '%"source":"knowledge_audience"%');
                });
            })
            ->orderByDesc('created_at')
            ->get();

        $items = $rows->map(function ($row) {
            $meta = json_decode((string) ($row->metadata_json ?? ''), true);
            if (is_array($meta) && ($meta['source'] ?? null) === 'knowledge_audience') {
                return [
                    'sno' => $row->sno,
                    'permission' => $row->permission,
                    'status' => $row->status,
                    'expires_at' => $row->expires_at,
                    'audience_mode' => $meta['audience_mode'] ?? null,
                    'audience' => $meta,
                ];
            }

            return [
                'sno' => $row->sno,
                'permission' => $row->permission,
                'status' => $row->status,
                'expires_at' => $row->expires_at,
                'audience_mode' => match ($row->grantee_type) {
                    'company' => 'company',
                    'role' => 'role',
                    'user' => 'staff',
                    default => 'group',
                },
                'legacy_grantee_type' => $row->grantee_type,
                'legacy_grantee_id' => $row->grantee_id,
            ];
        })->values();

        // Existing Share entries are stored as IDs in metadata. Hydrate only the
        // display data for the Share modal; grant/security behavior remains unchanged.
        $items = $this->hydrateKnowledgeShareAudienceNames($items);

        return $this->ok($items);
    }

    private function hydrateKnowledgeShareAudienceNames($items)
    {
        $companyIds = collect();
        $entityIds = collect();
        $roleIds = collect();
        $staffIds = collect();
        $legacyRoleValues = collect();

        foreach ($items as $item) {
            $mode = (string) ($item['audience_mode'] ?? '');
            $meta = is_array($item['audience'] ?? null) ? $item['audience'] : [];

            foreach ((array) ($meta['company_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id >= 0) {
                    $companyIds->push((int) $id);
                }
            }

            foreach ((array) ($meta['entity_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id >= 0) {
                    $entityIds->push((int) $id);
                }
            }

            foreach ((array) ($meta['role_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id > 0) {
                    $roleIds->push((int) $id);
                }
            }

            foreach ((array) ($meta['staff_ids'] ?? []) as $id) {
                if (is_numeric($id) && (int) $id > 0) {
                    $staffIds->push((int) $id);
                }
            }

            // Legacy Share rows can store the role name or role id directly.
            if ($mode === 'role' && !empty($item['legacy_grantee_id'])) {
                $legacyRoleValues->push((string) $item['legacy_grantee_id']);
            }

            if ($mode === 'company' && !empty($item['legacy_grantee_id']) && is_numeric($item['legacy_grantee_id'])) {
                $companyIds->push((int) $item['legacy_grantee_id']);
            }

            if ($mode === 'staff' && !empty($item['legacy_grantee_id']) && is_numeric($item['legacy_grantee_id'])) {
                $staffIds->push((int) $item['legacy_grantee_id']);
            }
        }

        $companies = DB::table('egc_company')
            ->where('status', 0)
            ->whereIn('sno', $companyIds->unique()->values()->all())
            ->get(['sno', 'company_name', 'company_short_name'])
            ->keyBy('sno');

        $entities = DB::table('egc_entity as e')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'e.company_id')
            ->where('e.status', 0)
            ->whereIn('e.sno', $entityIds->unique()->values()->all())
            ->get([
                'e.sno',
                'e.entity_name',
                'e.company_id',
                'c.company_name',
            ])
            ->keyBy('sno');

        $roles = DB::table('egc_user_role as ur')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 'ur.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'ur.company_id')
            ->where('ur.status', 0)
            ->where(function ($q) use ($roleIds, $legacyRoleValues) {
                $positiveRoleIds = $roleIds->unique()->values()->all();
                $legacyValues = $legacyRoleValues->unique()->values()->all();

                if ($positiveRoleIds) {
                    $q->whereIn('ur.sno', $positiveRoleIds);
                }

                if ($legacyValues) {
                    if ($positiveRoleIds) {
                        $q->orWhereIn('ur.role_name', $legacyValues);
                    } else {
                        $q->whereIn('ur.role_name', $legacyValues);
                    }
                }

                if (!$positiveRoleIds && !$legacyValues) {
                    $q->whereRaw('1 = 0');
                }
            })
            ->get([
                'ur.sno',
                'ur.role_name',
                'ur.entity_id',
                'ur.company_id',
                'e.entity_name',
                'c.company_name',
            ]);

        $rolesById = $roles->keyBy('sno');
        $rolesByName = $roles->keyBy(fn ($row) => (string) $row->role_name);

        $staff = DB::table('egc_staff as s')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->leftJoin('egc_user_role as ur', function ($join) {
                $join->on('ur.sno', '=', 's.role_id')
                    ->where('ur.status', 0);
            })
            ->where('s.status', 0)
            ->whereIn('s.sno', $staffIds->unique()->values()->all())
            ->get([
                's.sno',
                's.staff_name',
                's.staff_id',
                's.email_id',
                's.entity_id',
                's.company_id',
                's.role_id',
                'e.entity_name',
                'c.company_name',
                'ur.role_name',
            ])
            ->keyBy('sno');

        return $items->map(function ($item) use ($companies, $entities, $rolesById, $rolesByName, $staff) {
            $mode = (string) ($item['audience_mode'] ?? '');
            $meta = is_array($item['audience'] ?? null) ? $item['audience'] : [];
            $details = [];

            if ($mode === 'company') {
                foreach ((array) ($meta['company_ids'] ?? []) as $id) {
                    if ((string) $id === 'all') {
                        $details[] = [
                            'type' => 'company',
                            'company_name' => 'All companies',
                        ];
                        continue;
                    }

                    $company = $companies->get((int) $id);
                    $name = trim((string) ($company->company_name ?? $company->company_short_name ?? ''));
                    if ($name !== '') {
                        $details[] = [
                            'type' => 'company',
                            'id' => (int) $id,
                            'company_name' => $name,
                        ];
                    }
                }

                if (!$details && ($item['legacy_grantee_type'] ?? null) === 'company') {
                    $company = $companies->get((int) ($item['legacy_grantee_id'] ?? 0));
                    if ($company) {
                        $details[] = [
                            'type' => 'company',
                            'id' => (int) $company->sno,
                            'company_name' => trim((string) ($company->company_name ?? $company->company_short_name ?? '')),
                        ];
                    }
                }
            } elseif ($mode === 'entity') {
                foreach ((array) ($meta['entity_ids'] ?? []) as $id) {
                    if ((string) $id === 'all') {
                        $details[] = [
                            'type' => 'entity',
                            'entity_name' => 'All entities',
                        ];
                        continue;
                    }

                    $entity = $entities->get((int) $id);
                    if ($entity) {
                        $details[] = [
                            'type' => 'entity',
                            'id' => (int) $entity->sno,
                            'entity_name' => trim((string) $entity->entity_name),
                            'company_name' => trim((string) ($entity->company_name ?? '')),
                        ];
                    }
                }
            } elseif ($mode === 'role') {
                foreach ((array) ($meta['role_ids'] ?? []) as $id) {
                    if ((string) $id === 'all') {
                        $details[] = [
                            'type' => 'role',
                            'role_name' => 'All roles',
                        ];
                        continue;
                    }

                    $role = $rolesById->get((int) $id);
                    if ($role) {
                        $details[] = [
                            'type' => 'role',
                            'id' => (int) $role->sno,
                            'role_name' => trim((string) $role->role_name),
                            'entity_name' => trim((string) ($role->entity_name ?? '')),
                            'company_name' => trim((string) ($role->company_name ?? '')),
                        ];
                    }
                }

                if (!$details && ($item['legacy_grantee_type'] ?? null) === 'role') {
                    $legacyId = (string) ($item['legacy_grantee_id'] ?? '');
                    $role = is_numeric($legacyId)
                        ? $rolesById->get((int) $legacyId)
                        : $rolesByName->get($legacyId);

                    if ($role) {
                        $details[] = [
                            'type' => 'role',
                            'id' => (int) $role->sno,
                            'role_name' => trim((string) $role->role_name),
                            'entity_name' => trim((string) ($role->entity_name ?? '')),
                            'company_name' => trim((string) ($role->company_name ?? '')),
                        ];
                    }
                }
            } elseif ($mode === 'staff') {
                foreach ((array) ($meta['staff_ids'] ?? []) as $id) {
                    $member = $staff->get((int) $id);
                    if ($member) {
                        $details[] = [
                            'type' => 'staff',
                            'id' => (int) $member->sno,
                            'staff_name' => trim((string) $member->staff_name),
                            'entity_name' => trim((string) ($member->entity_name ?? '')),
                            'company_name' => trim((string) ($member->company_name ?? '')),
                            'role_name' => trim((string) ($member->role_name ?? '')),
                        ];
                    }
                }

                if (!$details && ($item['legacy_grantee_type'] ?? null) === 'user') {
                    $member = $staff->get((int) ($item['legacy_grantee_id'] ?? 0));
                    if ($member) {
                        $details[] = [
                            'type' => 'staff',
                            'id' => (int) $member->sno,
                            'staff_name' => trim((string) $member->staff_name),
                            'entity_name' => trim((string) ($member->entity_name ?? '')),
                            'company_name' => trim((string) ($member->company_name ?? '')),
                            'role_name' => trim((string) ($member->role_name ?? '')),
                        ];
                    }
                }
            }

            $item['audience_details'] = array_values(array_filter($details));
            return $item;
        })->values();
    }


    public function shareStore(Request $r, int $id): JsonResponse
    {
        abort_unless($this->access->canWrite($r), 403);
        $post = KnowledgePost::findOrFail($id);
        abort_unless($this->canManageKnowledgeResource($r, $post), 403, 'You do not have permission to share this Knowledge post.');

        $data = $r->validate([
            'audience_mode' => ['required', 'in:company,entity,role,staff'],
            'permission' => ['required', 'in:View,Manage'],
            'expires_at' => ['nullable', 'date', 'after:now'],
        ]);

        $audience = $this->normalizeKnowledgeAudience($r);
        $this->assertKnowledgeAudienceAllowed($r, $audience);

        $grant = $this->upsertKnowledgeShareGrant(
            $id,
            (int) $post->author_user_id,
            $audience,
            $data['permission'],
            $data['expires_at'] ?? null
        );

        $this->audit($r, 'Knowledge Panel', 'knowledge_audience_shared', 'knowledge_post', $id, null, [
            'audience_mode' => $audience['mode'],
            'permission' => $data['permission'],
            'grant_id' => $grant,
        ]);

        return $this->ok([
            'audience' => $audience,
            'grant_id' => $grant,
        ], 'Knowledge audience shared successfully.');
    }

    public function show(int $id, Request $r): JsonResponse
    {
        $p = KnowledgePost::findOrFail($id);
        abort_unless($this->canViewKnowledgePost($r, $p), 403);
        $autherStaffData =StaffModel::where('sno', $p->author_user_id)->first();
        $p->author_name = DB::table('egc_staff')->where('sno', $p->author_user_id)->value('staff_name') ?: 'ERP User';
        $p->author_profile_url = $autherStaffData ? $autherStaffData->profile_image_url : '';
        $p->company_name = DB::table('egc_company')->where('sno', $p->company_id)->where('status', 0)->value('company_name') ?: 'Group';
        $p->category_name = DB::table('egc_tool_knowledge_categories')->where('sno', $p->category_id)->value('category_name');
        $p->likes_count = DB::table('egc_tool_knowledge_reactions')->where('post_id', $id)->count();
        $p->replies_count = DB::table('egc_tool_knowledge_replies')->where('post_id', $id)->count();
        $p->saves_count = DB::table('egc_tool_knowledge_saves')->where('post_id', $id)->count();
        $p->liked_by_me = DB::table('egc_tool_knowledge_reactions')
            ->where('post_id', $id)
            ->where('user_id', $this->uid())
            ->where('reaction', 'like')
            ->exists();
        $p->saved_by_me = DB::table('egc_tool_knowledge_saves')
            ->where('post_id', $id)
            ->where('user_id', $this->uid())
            ->exists();

        $versions = DB::table('egc_tool_knowledge_post_versions as v')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'v.edited_by')
            ->where('v.post_id', $id)
            ->orderByDesc('v.version_no')
            ->get(['v.*', 's.staff_name as edited_by_name']);

        $replies = DB::table('egc_tool_knowledge_replies as r')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'r.author_user_id')
            ->where('r.post_id', $id)
            ->orderBy('r.created_at')
            ->get(['r.*', 's.staff_name as author_name']);

        $media = $this->mediaForPost($id);

        $p->body_html = $this->cleanHtml($p->body_html);
        $p->url_preview = $this->buildUrlPreview($p);

        return $this->ok([
            'post' => $p,
            'versions' => $versions,
            'replies' => $replies,
            'media' => $media,
        ]);
    }

    private function normalizeAudienceValue($value, bool $allowAll = false): array
    {
        if (!is_array($value)) {
            $value = ($value === null || $value === '') ? [] : [$value];
        }

        $result = [];
        foreach ($value as $item) {
            $item = trim((string) $item);
            if ($item === '') continue;
            if ($allowAll && $item === 'all') {
                $result[] = 'all';
                continue;
            }
            if (preg_match('/^0$|^[1-9][0-9]*$/', $item)) {
                $result[] = (int) $item;
            }
        }

        return array_values(array_unique($result, SORT_REGULAR));
    }

    private function decodeKnowledgeAudience($value): array
    {
        if (is_array($value)) return $value;
        if (is_object($value)) return (array) $value;
        if (!is_string($value) || trim($value) === '') return [];
        $decoded = json_decode($value, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function knowledgeAudienceLabel($value): string
    {
        $audience = $this->decodeKnowledgeAudience($value);
        $mode = strtolower((string) ($audience['audience_mode'] ?? $audience['mode'] ?? 'company'));
        $labels = ['company' => 'Company', 'entity' => 'Entity', 'role' => 'Role', 'staff' => 'Staff'];
        return ($labels[$mode] ?? 'Company') . ' access';
    }

    private function resolveKnowledgeCategoryAudience(Request $r, $category): array
    {
        $audience = $this->decodeKnowledgeAudience($category->audience_json ?? null);
        if ($audience && $this->knowledgeAudienceHasSelection($audience)) {
            return $audience;
        }

        // Legacy categories receive a safe company-scoped default until an
        // administrator explicitly configures their audience in Category Settings.
        $companyId = $category->company_id !== null && (int) $category->company_id > 0
            ? (int) $category->company_id
            : (int) ($this->cid() ?? 0);
        if ($companyId <= 0 && $this->access->isGroupAdmin($r)) {
            $companyIds = ['all'];
        } else {
            $companyIds = [$companyId];
        }

        return [
            'source' => 'knowledge_audience',
            'audience_mode' => 'company',
            'mode' => 'company',
            'company_ids' => $companyIds,
            'entity_ids' => [],
            'role_ids' => [],
            'staff_ids' => [],
        ];
    }

    private function replaceKnowledgeCategoryAudienceGrant(int $postId, int $ownerUserId, array $audience): void
    {
        DB::table('egc_tool_share_grants')
            ->where('resource_type', 'knowledge')
            ->where('resource_id', $postId)
            ->where('metadata_json', 'like', '%"source":"knowledge_audience"%')
            ->where(function ($q) {
                $q->whereNull('metadata_json')
                    ->orWhere('metadata_json', 'not like', '%"audience_context":"share"%');
            })
            ->update([
                'status' => 'revoked',
                'updated_at' => now(),
                'revoked_by' => $this->uid(),
                'revoked_at' => now(),
            ]);

        $metadata = array_merge($audience, [
            'source' => 'knowledge_audience',
            'audience_context' => 'category',
        ]);

        DB::table('egc_tool_share_grants')->insert([
            'resource_type' => 'knowledge',
            'resource_id' => $postId,
            'owner_user_id' => $ownerUserId,
            'grantee_type' => 'group',
            'grantee_id' => '0',
            'permission' => 'View',
            'status' => 'active',
            'expires_at' => null,
            'requested_by' => $this->uid(),
            'approved_by' => $this->uid(),
            'approval_required' => 0,
            'approved_at' => now(),
            'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    private function syncKnowledgeCategoryAudienceToPosts(int $categoryId, array $audience): void
    {
        $posts = DB::table('egc_tool_knowledge_posts')
            ->where('category_id', $categoryId)
            ->whereNull('deleted_at')
            ->get(['sno', 'author_user_id']);

        foreach ($posts as $post) {
            $this->replaceKnowledgeCategoryAudienceGrant(
                (int) $post->sno,
                (int) $post->author_user_id,
                $audience
            );
        }
    }

    private function normalizeKnowledgeAudience(Request $r): array
    {
        $mode = strtolower((string) $r->input('audience_mode', 'company'));
        $audience = [
            'source' => 'knowledge_audience',
            'audience_mode' => $mode,
            'mode' => $mode,
            'company_ids' => [],
            'entity_ids' => [],
            'role_ids' => [],
            'staff_ids' => [],
        ];

        if ($mode === 'company') {
            $audience['company_ids'] = $this->normalizeAudienceValue($r->input('audience_company_ids', []), true);
        } elseif ($mode === 'entity') {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
        } elseif ($mode === 'role') {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
            $audience['role_ids'] = $this->normalizeAudienceValue($r->input('audience_role_ids', []), true);
        } else {
            $audience['entity_ids'] = $this->normalizeAudienceValue($r->input('audience_entity_ids', []), true);
            $audience['staff_ids'] = $this->normalizeAudienceValue($r->input('audience_staff_ids', []), false);
        }

        abort_unless($this->knowledgeAudienceHasSelection($audience), 422, 'Choose at least one audience option.');
        return $audience;
    }

    private function knowledgeAudienceHasSelection(array $audience): bool
    {
        return match ($audience['mode']) {
            'company' => !empty($audience['company_ids']),
            'entity' => !empty($audience['entity_ids']),
            'role' => !empty($audience['entity_ids']) && !empty($audience['role_ids']),
            'staff' => !empty($audience['entity_ids']) && !empty($audience['staff_ids']),
            default => false,
        };
    }

    private function assertKnowledgeAudienceAllowed(Request $r, array $audience): void
    {
        $groupAdmin = $this->access->isGroupAdmin($r);
        $companyId = $this->cid();

        if ($audience['mode'] === 'company') {
            $ids = $audience['company_ids'];
            if (in_array('all', $ids, true)) {
                abort_unless($groupAdmin, 403, 'Only Group Admin can target all companies.');
                return;
            }
            if (!$groupAdmin && $companyId !== null) {
                foreach ($ids as $id) {
                    abort_unless((int) $id === (int) $companyId, 403, 'Selected company is outside your scope.');
                }
            }

            $positive = array_values(array_filter($ids, static fn ($id) => is_int($id) && $id > 0));
            if ($positive) {
                $count = DB::table('egc_company')->whereIn('sno', $positive)->where('status', 0)->count();
                abort_unless((int) $count === count($positive), 422, 'One or more selected companies are not active.');
            }
            return;
        }

        $entityIds = $audience['entity_ids'];
        if (in_array('all', $entityIds, true)) {
            abort_unless($groupAdmin, 403, 'Only Group Admin can target all entities.');
        }

        $positive = array_values(array_filter($entityIds, static fn ($id) => is_int($id) && $id > 0));
        $entityQuery = DB::table('egc_entity')->whereIn('sno', $positive)->where('status', 0);
        if (!$groupAdmin && $companyId !== null) {
            $entityQuery->where('company_id', $companyId);
        }
        if ($positive) {
            abort_unless((int) $entityQuery->count() === count($positive), 422, 'One or more selected entities are outside your scope.');
        }

        if ($audience['mode'] === 'entity') {
            return;
        }

        if ($audience['mode'] === 'role') {
            $roleIds = $audience['role_ids'];
            $rolePositive = array_values(array_filter($roleIds, static fn ($id) => is_int($id) && $id > 0));
            $roleQuery = DB::table('egc_user_role as ur')->where('ur.status', 0);

            if (in_array('all', $entityIds, true)) {
                // All active roles for all visible entities are valid.
            } elseif ($positive) {
                $roleQuery->whereIn('ur.entity_id', $positive);
            } elseif (in_array(0, $entityIds, true)) {
                $roleQuery->where('ur.entity_id', 0);
            }

            if ($rolePositive) {
                abort_unless(
                    (int) $roleQuery->whereIn('ur.sno', $rolePositive)->count() === count($rolePositive),
                    422,
                    'One or more selected roles are unavailable.'
                );
            }
            return;
        }

        $staffIds = $audience['staff_ids'];
        $staffPositive = array_values(array_filter($staffIds, static fn ($id) => is_int($id) && $id > 0));
        if ($staffPositive) {
            $staffQuery = DB::table('egc_staff as s')
                ->where('s.status', 0)
                ->whereIn('s.sno', $staffPositive);

            if (!in_array('all', $entityIds, true)) {
                if ($positive) {
                    $staffQuery->whereIn('s.entity_id', $positive);
                } elseif (in_array(0, $entityIds, true)) {
                    $staffQuery->where('s.entity_id', 0);
                }
            }

            if (!$groupAdmin && $companyId !== null) {
                $staffQuery->where('s.company_id', $companyId);
            }

            abort_unless(
                (int) $staffQuery->count() === count($staffPositive),
                422,
                'One or more selected staff members are outside your scope.'
            );
        }
    }

    private function replaceKnowledgeAudienceGrants(int $postId, int $ownerUserId, array $audience, string $permission = 'View', ?string $expiresAt = null): void
    {
        DB::table('egc_tool_share_grants')
            ->where('resource_type', 'knowledge')
            ->where('resource_id', $postId)
            ->where('metadata_json', 'like', '%"source":"knowledge_audience"%')
            ->where(function ($q) {
                $q->whereNull('metadata_json')
                    ->orWhere('metadata_json', 'not like', '%"audience_context":"share"%');
            })
            ->update([
                'status' => 'revoked',
                'updated_at' => now(),
                'revoked_by' => $this->uid(),
                'revoked_at' => now(),
            ]);

        $metadata = array_merge($audience, [
            'source' => 'knowledge_audience',
            'audience_context' => 'post',
        ]);

        DB::table('egc_tool_share_grants')->insert([
            'resource_type' => 'knowledge',
            'resource_id' => $postId,
            'owner_user_id' => $ownerUserId,
            'grantee_type' => 'group',
            'grantee_id' => '0',
            'permission' => $permission,
            'status' => 'active',
            'expires_at' => $expiresAt,
            'requested_by' => $this->uid(),
            'approved_by' => $this->uid(),
            'approval_required' => 0,
            'approved_at' => now(),
            'metadata_json' => json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    private function upsertKnowledgeShareGrant(int $postId, int $ownerUserId, array $audience, string $permission = 'View', ?string $expiresAt = null): int
    {
        $metadata = array_merge($audience, [
            'source' => 'knowledge_audience',
            'audience_context' => 'share',
        ]);
        $metadataJson = json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $existing = DB::table('egc_tool_share_grants')
            ->where('resource_type', 'knowledge')
            ->where('resource_id', $postId)
            ->where('grantee_type', 'group')
            ->where('grantee_id', '0')
            ->whereIn('status', ['active', 'pending'])
            ->where('metadata_json', $metadataJson)
            ->first();

        if ($existing) {
            DB::table('egc_tool_share_grants')
                ->where('sno', $existing->sno)
                ->update([
                    'owner_user_id' => $ownerUserId,
                    'permission' => $permission,
                    'status' => 'active',
                    'expires_at' => $expiresAt,
                    'requested_by' => $this->uid(),
                    'approved_by' => $this->uid(),
                    'approval_required' => 0,
                    'approved_at' => now(),
                    'revoked_by' => null,
                    'revoked_at' => null,
                    'updated_at' => now(),
                ]);

            return (int) $existing->sno;
        }

        return (int) DB::table('egc_tool_share_grants')->insertGetId([
            'resource_type' => 'knowledge',
            'resource_id' => $postId,
            'owner_user_id' => $ownerUserId,
            'grantee_type' => 'group',
            'grantee_id' => '0',
            'permission' => $permission,
            'status' => 'active',
            'expires_at' => $expiresAt,
            'requested_by' => $this->uid(),
            'approved_by' => $this->uid(),
            'approval_required' => 0,
            'approved_at' => now(),
            'metadata_json' => $metadataJson,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    private function knowledgeUserContext(Request $r): array
    {
        /*
         * Knowledge visibility is tied to the authenticated ERP user.
         * The login user carries:
         *   user_id    => egc_staff.sno
         *   company_id => staff company
         *   entity_d   => staff entity
         *   role_id    => staff role
         *
         * Use these values first so the Knowledge audience check always
         * evaluates the same identity that is actually logged in.
         */
        $user = $r->user();

        $uid = (int) ($user?->user_id ?? 0);
        $companyId = $user?->company_id !== null ? (int) $user->company_id : null;
        $entityId = $user?->entity_d !== null ? (int) $user->entity_d : null;
        $roleId = $user?->role_id !== null ? (int) $user->role_id : null;

        /*
         * Keep a defensive fallback for older/non-standard auth payloads.
         * This does not change the normal authenticated path above.
         */
        if ($uid <= 0) {
            $uid = (int) $this->access->userId($r);
        }

        $staff = null;
        if ($uid > 0 && ($companyId === null || $entityId === null || $roleId === null)) {
            $staff = DB::table('egc_staff')
                ->where('sno', $uid)
                ->select(['sno', 'company_id', 'entity_id', 'role_id'])
                ->first();
        }

        if ($companyId === null) {
            $companyId = $staff?->company_id !== null
                ? (int) $staff->company_id
                : $this->access->companyId($r);
        }

        if ($entityId === null) {
            $entityId = $staff?->entity_id !== null ? (int) $staff->entity_id : 0;
        }

        if ($roleId === null) {
            $roleId = $staff?->role_id !== null
                ? (int) $staff->role_id
                : $this->access->roleId($r);
        }

        return [
            'uid' => $uid,
            'company_id' => $companyId,
            'entity_id' => $entityId,
            'role_id' => $roleId,
            'role_name' => $this->access->role($r),
        ];
    }

    private function knowledgeAudienceGrantExists(Request $r, int $postId, bool $manage = false): bool
    {
        $ctx = $this->knowledgeUserContext($r);
        $q = DB::table('egc_tool_share_grants as g')
            ->where('g.resource_type', 'knowledge')
            ->where('g.resource_id', $postId)
            ->where('g.status', 'active')
            ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()))
            ->when($manage, fn ($x) => $x->where('g.permission', 'Manage'));

        $q->where(function ($aud) use ($ctx) {
            $aud->where(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"knowledge_audience"%')
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'company'")
                    ->where(function ($ids) use ($ctx) {
                        $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", [json_encode((int) ($ctx['company_id'] ?? 0))])
                            ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"knowledge_audience"%')
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'entity'")
                    ->where(function ($ids) use ($ctx) {
                        $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $ctx['entity_id'])])
                            ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"knowledge_audience"%')
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'role'")
                    ->where(function ($ids) use ($ctx) {
                        $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", [json_encode((int) $ctx['entity_id'])])
                            ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                    })
                    ->where(function ($roles) use ($ctx) {
                        $roles->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", [json_encode((int) $ctx['role_id'])])
                            ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)", ['"all"']);
                    });
            })
            ->orWhere(function ($x) use ($ctx) {
                $x->where('g.metadata_json', 'like', '%"source":"knowledge_audience"%')
                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'staff'")
                    ->whereRaw("JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.staff_ids'), ?)", [json_encode((int) $ctx['uid'])]);
            });
        });

        return $q->exists();
    }

    private function canViewKnowledgePost(Request $r, KnowledgePost $post): bool
    {
        $ctx = $this->knowledgeUserContext($r);

        /*
         * role_id = 1 is the only Knowledge full-view role.
         */
        if ((int) $ctx['role_id'] === 1) {
            return true;
        }

        /*
         * Keep author access so a creator can open their own post.
         */
        if ((int) $post->author_user_id === (int) $ctx['uid']) {
            return true;
        }

        /*
         * For modern Knowledge posts, the audience grant is the only
         * non-admin read authorization.
         */
        if ($this->knowledgeAudienceDefinitionExists((int) $post->sno)) {
            return $this->knowledgeAudienceGrantExists($r, (int) $post->sno);
        }

        /*
         * Older posts that pre-date the Knowledge audience metadata continue
         * using the existing resource-access implementation.
         */
        return $this->access->canReadResource(
            'knowledge',
            (int) $post->sno,
            $post->author_user_id,
            $post->company_id,
            $post->audience_scope,
            $r
        ) || $this->knowledgeAudienceGrantExists($r, (int) $post->sno);
    }

    private function knowledgeAudienceDefinitionExists(int $postId): bool
    {
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', 'knowledge')
            ->where('resource_id', $postId)
            ->where('metadata_json', 'like', '%"source":"knowledge_audience"%')
            ->where(function ($q) {
                $q->where('metadata_json', 'like', '%"audience_context":"post"%')
                    ->orWhere('metadata_json', 'like', '%"audience_context":"category"%');
            })
            ->exists();
    }

    private function canManageKnowledgeResource(Request $r, KnowledgePost $post): bool
    {
        $ctx = $this->knowledgeUserContext($r);
        $uid = (int) $ctx['uid'];

        if ((int) $ctx['role_id'] === 1 || (int) $post->author_user_id === $uid) {
            return true;
        }

        if ($this->access->canManageResource('knowledge', $post->sno, $post->author_user_id, $r)) {
            return true;
        }

        return $this->knowledgeAudienceGrantExists($r, (int) $post->sno, true);
    }

    private function applyKnowledgeReadableQueryScope($query, Request $r): void
    {
        $ctx = $this->knowledgeUserContext($r);

        /*
         * role_id = 1 is the Knowledge full-view administrator.
         * No other role is allowed to bypass audience filtering.
         */
        if ((int) $ctx['role_id'] === 1) {
            return;
        }

        if ((int) $ctx['uid'] <= 0) {
            $query->whereRaw('1=0');
            return;
        }

        $companyId = $ctx['company_id'];
        $entityId = $ctx['entity_id'];
        $roleId = $ctx['role_id'];
        $uid = $ctx['uid'];
        $roleName = $ctx['role_name'];

        $query->where(function ($scope) use ($uid, $companyId, $roleName, $entityId, $roleId) {
            /*
             * The author can always see their own post.
             */
            $scope->where('p.author_user_id', $uid)

                /*
                 * New Knowledge audience grants are the source of truth.
                 * Matching is strictly against the logged-in user's:
                 *   user_id / company_id / entity_d / role_id
                 */
                ->orWhereExists(function ($g) use ($uid, $companyId, $entityId, $roleId) {
                    $g->selectRaw('1')
                        ->from('egc_tool_share_grants as g')
                        ->where('g.resource_type', 'knowledge')
                        ->whereColumn('g.resource_id', 'p.sno')
                        ->where('g.status', 'active')
                        ->where('g.grantee_type', 'group')
                        ->where('g.grantee_id', '0')
                        ->where(function ($aud) use ($uid, $companyId, $entityId, $roleId) {
                            $aud->where(function ($x) use ($companyId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'knowledge_audience'")
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'company'")
                                    ->where(function ($ids) use ($companyId) {
                                        $ids->when($companyId !== null, function ($q) use ($companyId) {
                                            $q->whereRaw(
                                                "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)",
                                                [json_encode((int) $companyId)]
                                            );
                                        })
                                        ->orWhereRaw(
                                            "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.company_ids'), ?)",
                                            ['"all"']
                                        );
                                    });
                            })
                            ->orWhere(function ($x) use ($entityId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'knowledge_audience'")
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'entity'")
                                    ->where(function ($ids) use ($entityId) {
                                        $ids->when($entityId !== null, function ($q) use ($entityId) {
                                            $q->whereRaw(
                                                "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)",
                                                [json_encode((int) $entityId)]
                                            );
                                        })
                                        ->orWhereRaw(
                                            "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)",
                                            ['"all"']
                                        );
                                    });
                            })
                            ->orWhere(function ($x) use ($entityId, $roleId) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'knowledge_audience'")
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'role'")
                                    ->where(function ($ids) use ($entityId) {
                                        $ids->when($entityId !== null, function ($q) use ($entityId) {
                                            $q->whereRaw(
                                                "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)",
                                                [json_encode((int) $entityId)]
                                            );
                                        })
                                        ->orWhereRaw(
                                            "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.entity_ids'), ?)",
                                            ['"all"']
                                        );
                                    })
                                    ->where(function ($roles) use ($roleId) {
                                        $roles->when($roleId !== null, function ($q) use ($roleId) {
                                            $q->whereRaw(
                                                "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)",
                                                [json_encode((int) $roleId)]
                                            );
                                        })
                                        ->orWhereRaw(
                                            "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.role_ids'), ?)",
                                            ['"all"']
                                        );
                                    });
                            })
                            ->orWhere(function ($x) use ($uid) {
                                $x->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.source')) = 'knowledge_audience'")
                                    ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(g.metadata_json, '$.audience_mode')) = 'staff'")
                                    ->whereRaw(
                                        "JSON_CONTAINS(JSON_EXTRACT(g.metadata_json, '$.staff_ids'), ?)",
                                        [json_encode((int) $uid)]
                                    );
                            });
                        })
                        ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()));
                })

                /*
                 * Backward compatibility:
                 * Preserve the old Share/Resource access path only for posts
                 * that were not created with the new Knowledge audience metadata.
                 *
                 * This prevents a legacy "group" grant from broadening a modern
                 * audience-controlled post to everybody.
                 */
                ->orWhere(function ($legacy) use ($uid, $companyId, $roleName) {
                    $legacy->whereNotExists(function ($audiencePost) {
                        $audiencePost->selectRaw('1')
                            ->from('egc_tool_share_grants as ka')
                            ->where('ka.resource_type', 'knowledge')
                            ->whereColumn('ka.resource_id', 'p.sno')
                            ->where('ka.metadata_json', 'like', '%"source":"knowledge_audience"%')
                            ->where(function ($context) {
                                $context->where('ka.metadata_json', 'like', '%"audience_context":"post"%')
                                    ->orWhere('ka.metadata_json', 'like', '%"audience_context":"category"%');
                            });
                    })
                    ->whereExists(function ($g) use ($uid, $companyId, $roleName) {
                        $g->selectRaw('1')
                            ->from('egc_tool_share_grants as g')
                            ->where('g.resource_type', 'knowledge')
                            ->whereColumn('g.resource_id', 'p.sno')
                            ->where('g.status', 'active')
                            ->where(function ($grantee) use ($uid, $companyId, $roleName) {
                                $grantee->where(fn ($x) => $x->where('g.grantee_type', 'user')->where('g.grantee_id', (string) $uid))
                                    ->orWhere(fn ($x) => $x->where('g.grantee_type', 'role')->where('g.grantee_id', (string) $roleName))
                                    ->when($companyId !== null, fn ($x) => $x->orWhere(fn ($co) => $co->where('g.grantee_type', 'company')->where('g.grantee_id', (string) $companyId)))
                                    ->orWhere(fn ($x) => $x->where('g.grantee_type', 'group')->where('g.grantee_id', '0'));
                            })
                            ->where(fn ($e) => $e->whereNull('g.expires_at')->orWhere('g.expires_at', '>=', now()));
                    });
                });
        });
    }

    private function cleanHtml($html): string
    {
        $html = strip_tags((string) $html, '<p><br><b><strong><i><em><u><ul><ol><li><a><h1><h2><h3><blockquote><pre><code><table><thead><tbody><tr><th><td><mark>');
        $html = preg_replace('/\s(on[a-z]+)\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html) ?? $html;
        $html = preg_replace('/(href|src)\s*=\s*("|\')\s*javascript:[^"\']*("|\')/i', '$1=$2#$3', $html) ?? $html;
        $html = preg_replace('/(href|src)\s*=\s*("|\')\s*data:text\/html[^"\']*("|\')/i', '$1=$2#$3', $html) ?? $html;
        $html = preg_replace_callback('/\b(href|src)\s*=\s*("|\')(.*?)\2/i', function ($m) {
            $value = html_entity_decode(trim($m[3]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($value === '' || preg_match('/^(?:https?:|\/|#)/i', $value)) {
                return $m[0];
            }
            return $m[1] . '=' . $m[2] . '#' . $m[2];
        }, $html) ?? $html;
        return $html;
    }

    public function store(Request $r): JsonResponse
    {
        abort_unless($this->access->canWrite($r), 403);

        $d = $r->validate([
            'category_id' => ['required', 'integer'],
            'title' => ['required', 'string', 'max:220'],
            'body_html' => ['nullable', 'string'],
            'content_type' => ['nullable', 'in:text,image,video,audio,pdf,url,files'],
            'post_url' => ['nullable', 'url', 'max:2000'],
            'tags' => ['nullable', 'array'],
            'status' => ['required', 'in:draft,published'],
            'media' => ['nullable', 'array', 'max:10'],
            'media.*' => ['file', 'max:51200', 'mimes:jpg,jpeg,png,webp,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,txt,csv,mp3,wav,mp4,webm'],
        ]);

        $category = $this->visibleCategory($r, (int) $d['category_id']);
        $audience = $this->resolveKnowledgeCategoryAudience($r, $category);
        $this->assertKnowledgeAudienceAllowed($r, $audience);
        $companyId = $this->resolvePostCompany($r, null, $category->company_id);

        $type = strtolower((string) ($d['content_type'] ?? ''));
        $files = array_values(array_filter((array) $r->file('media', [])));
        $bodyInput = trim((string) ($d['body_html'] ?? ''));

        if ($type === '') {
            if (!empty($d['post_url'])) {
                $type = 'url';
            } elseif ($files) {
                $type = 'files';
            } else {
                $type = 'text';
            }
        }

        if ($type === 'text') {
            abort_unless($bodyInput !== '', 422, 'Knowledge content is required for a Text post.');
        }

        if ($type === 'url') {
            abort_unless(!empty($d['post_url']), 422, 'A valid URL is required for a Url post.');
            $safeUrl = e(trim((string) $d['post_url']));
            $description = $bodyInput !== '' ? '<p>' . e($bodyInput) . '</p>' : '';
            $bodyInput = '<p><a href="' . $safeUrl . '" target="_blank" rel="noopener noreferrer">' . $safeUrl . '</a></p>' . $description;
        }

        if (in_array($type, ['image', 'video', 'audio', 'pdf', 'files'], true)) {
            abort_unless($files, 422, ucfirst($type) . ' content requires at least one file.');
        }

        foreach ($files as $file) {
            $mime = (string) $file->getMimeType();
            $detectedType = $this->knowledgeMediaType($mime);

            if ($type === 'image') {
                abort_unless($detectedType === 'image', 422, 'Please choose a supported image file.');
            } elseif ($type === 'video') {
                abort_unless($detectedType === 'video', 422, 'Please choose a supported video file.');
            } elseif ($type === 'audio') {
                abort_unless($detectedType === 'audio', 422, 'Please choose a supported audio file.');
            } elseif ($type === 'pdf') {
                abort_unless($mime === 'application/pdf', 422, 'Please choose a PDF file.');
            }
        }

        $body = $this->cleanHtml($bodyInput);
        $now = now();

        $post = DB::transaction(function () use ($d, $category, $companyId, $body, $files, $r, $now, $audience) {
            $post = KnowledgePost::create([
                'company_id' => $companyId,
                'author_user_id' => $this->uid(),
                'category_id' => $category->sno,
                'subcategory_id' => null,
                'title' => trim($d['title']),
                'body_html' => $body,
                'tags_json' => $d['tags'] ?? [],
                // Custom Knowledge audience grants below are the source of truth.
                // Keep the legacy enum populated with Private so old readers do not
                // accidentally broaden visibility while the new audience model is used.
                'audience_scope' => 'Private',
                'status' => $d['status'],
                'published_at' => $d['status'] === 'published' ? $now : null,
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);

            DB::table('egc_tool_knowledge_post_versions')->insert([
                'post_id' => $post->sno,
                'version_no' => 1,
                'title' => $post->title,
                'body_html' => $body,
                'edited_by' => $this->uid(),
                'created_at' => $now,
            ]);

            foreach ($files as $index => $file) {
                [$path, $disk] = $this->storeKnowledgeFile($file);
                $mime = (string) $file->getMimeType();
                $storagePath = $disk === 'local' ? 'local://' . $path : $path;

                DB::table('egc_tool_knowledge_post_media')->insert([
                    'post_id' => $post->sno,
                    'media_type' => $this->knowledgeMediaType($mime),
                    'storage_path' => $storagePath,
                    'original_name' => $file->getClientOriginalName(),
                    'mime_type' => $mime,
                    'file_size' => $file->getSize(),
                    'display_order' => $index,
                    'status' => 'ready',
                    'created_at' => $now,
                ]);
            }

            $this->replaceKnowledgeCategoryAudienceGrant(
                (int) $post->sno,
                $this->uid(),
                $audience
            );

            return $post;
        });

        $this->audit($r, 'Knowledge Panel', 'post_created', 'knowledge_post', $post->sno, null, $post->toArray());
        return $this->ok($post->fresh(), 'Knowledge post saved.');
    }

    public function update(Request $r, int $id): JsonResponse
    {
        $post = KnowledgePost::findOrFail($id);
        abort_unless($this->access->canManageResource('knowledge', $id, $post->author_user_id, $r), 403);

        $d = $r->validate([
            'category_id' => ['required', 'integer'],
            'title' => ['required', 'string', 'max:220'],
            'body_html' => ['required', 'string'],
            'tags' => ['nullable', 'array'],
            'status' => ['required', 'in:draft,published,unpublished'],
        ]);

        $category = $this->visibleCategory($r, (int) $d['category_id']);
        $audience = $this->resolveKnowledgeCategoryAudience($r, $category);
        $this->assertKnowledgeAudienceAllowed($r, $audience);
        $companyId = $this->resolvePostCompany($r, null, $category->company_id);
        $version = (int) $post->edit_version + 1;
        $body = $this->cleanHtml($d['body_html']);

        $post->update([
            'company_id' => $companyId,
            'category_id' => $category->sno,
            'subcategory_id' => null,
            'title' => trim($d['title']),
            'body_html' => $body,
            'tags_json' => $d['tags'] ?? [],
            'audience_scope' => 'Private',
            'status' => $d['status'],
            'edit_version' => $version,
            'edited_at' => now(),
            'published_at' => $d['status'] === 'published' ? ($post->published_at ?: now()) : $post->published_at,
            'updated_by' => $this->uid(),
        ]);

        DB::table('egc_tool_knowledge_post_versions')->insert([
            'post_id' => $id,
            'version_no' => $version,
            'title' => $post->title,
            'body_html' => $body,
            'edited_by' => $this->uid(),
            'created_at' => now(),
        ]);

        $this->replaceKnowledgeCategoryAudienceGrant(
            $id,
            (int) $post->author_user_id,
            $audience
        );

        $this->audit($r, 'Knowledge Panel', 'post_updated', 'knowledge_post', $id, null, $post->fresh()->toArray());
        return $this->ok($post->fresh(), 'Knowledge post updated.');
    }

    public function react(Request $r, int $id): JsonResponse
    {
        $p = KnowledgePost::findOrFail($id);
        $this->assertReadablePost($r, $p);
        $exists = DB::table('egc_tool_knowledge_reactions')->where('post_id', $id)->where('user_id', $this->uid())->where('reaction', 'like')->exists();
        if ($exists) {
            DB::table('egc_tool_knowledge_reactions')->where('post_id', $id)->where('user_id', $this->uid())->where('reaction', 'like')->delete();
        } else {
            DB::table('egc_tool_knowledge_reactions')->insert(['post_id' => $id, 'user_id' => $this->uid(), 'reaction' => 'like', 'created_at' => now()]);
        }
        return $this->ok(['liked' => !$exists], !$exists ? 'Post liked.' : 'Like removed.');
    }

    public function save(Request $r, int $id): JsonResponse
    {
        $p = KnowledgePost::findOrFail($id);
        $this->assertReadablePost($r, $p);
        $exists = DB::table('egc_tool_knowledge_saves')->where('post_id', $id)->where('user_id', $this->uid())->exists();
        if ($exists) {
            DB::table('egc_tool_knowledge_saves')->where('post_id', $id)->where('user_id', $this->uid())->delete();
        } else {
            DB::table('egc_tool_knowledge_saves')->insert(['post_id' => $id, 'user_id' => $this->uid(), 'created_at' => now()]);
        }
        return $this->ok(['saved' => !$exists], !$exists ? 'Saved to My Library.' : 'Removed from My Library.');
    }

    public function reply(Request $r, int $id): JsonResponse
    {
        $d = $r->validate(['body_html' => ['required', 'string', 'max:10000'], 'parent_reply_id' => ['nullable', 'integer']]);
        $p = KnowledgePost::findOrFail($id);
        $this->assertReadablePost($r, $p);
        $rid = DB::table('egc_tool_knowledge_replies')->insertGetId([
            'post_id' => $id,
            'parent_reply_id' => $r->integer('parent_reply_id') ?: null,
            'author_user_id' => $this->uid(),
            'body_html' => $this->cleanHtml($d['body_html']),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        return $this->ok(['id' => $rid], 'Reply added.');
    }

    public function report(Request $r, int $id): JsonResponse
    {
        $d = $r->validate(['reason' => ['required', 'string', 'max:500']]);
        $p = KnowledgePost::findOrFail($id);
        $this->assertReadablePost($r, $p);
        DB::table('egc_tool_knowledge_reports')->insert([
            'post_id' => $id, 'reported_by' => $this->uid(), 'reason' => trim($d['reason']),
            'status' => 'open', 'created_at' => now(), 'updated_at' => now(),
        ]);
        return $this->ok(null, 'Report submitted.');
    }

    public function follow(Request $r, int $categoryId): JsonResponse
    {
        $ctx = $this->knowledgeUserContext($r);
        $uid = (int) $ctx['uid'];

        /*
         * role_id = 1 may intentionally use user_id = 0.
         * All other users must resolve to a real staff/user id.
         */
        if ((int) $ctx['role_id'] !== 1) {
            abort_unless($uid > 0, 401, 'Authenticated Knowledge user is required.');
        }

        $category = DB::table('egc_tool_knowledge_categories')
            ->where('sno', $categoryId)
            ->where('status', 0)
            ->whereNull('deleted_at')
            ->first();

        abort_unless($category, 404);

        // A category with company_id NULL/0 is a Group category and is readable
        // by all authenticated Knowledge users. Company-specific categories are
        // restricted to the logged-in user's company.
        $this->assertReadableCategory($r, $category->company_id);

        $exists = DB::table('egc_tool_knowledge_follows')
            ->where('category_id', $categoryId)
            ->where('user_id', $uid)
            ->exists();

        if ($exists) {
            DB::table('egc_tool_knowledge_follows')
                ->where('category_id', $categoryId)
                ->where('user_id', $uid)
                ->delete();
        } else {
            DB::table('egc_tool_knowledge_follows')->insert([
                'category_id' => $categoryId,
                'user_id' => $uid,
                'created_at' => now(),
            ]);
        }

        return $this->ok(
            ['following' => !$exists],
            !$exists ? 'Category followed.' : 'Category unfollowed.'
        );
    }

    public function moderate(Request $r, int $id): JsonResponse
    {
        abort_unless($this->access->isGroupAdmin($r) || $this->access->isCompanyAdmin($r), 403);
        $d = $r->validate(['status' => ['required', 'in:published,unpublished,draft']]);
        $p = KnowledgePost::findOrFail($id);
        $before = $p->status;
        $p->update(['status' => $d['status'], 'published_at' => $d['status'] === 'published' ? ($p->published_at ?: now()) : $p->published_at, 'updated_by' => $this->uid()]);
        $this->audit($r, 'Knowledge Panel', 'post_moderated', 'knowledge_post', $id, ['status' => $before], ['status' => $d['status']]);
        return $this->ok(null, 'Post status updated.');
    }

    public function mediaUpload(Request $r, int $id): JsonResponse
    {
        abort_unless($this->access->canWrite($r), 403);
        $p = KnowledgePost::findOrFail($id);
        abort_unless($this->access->canManageResource('knowledge', $id, $p->author_user_id, $r), 403);

        $r->validate([
            'media' => ['required', 'file', 'max:51200', 'mimes:jpg,jpeg,png,webp,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,txt,csv,mp3,wav,mp4,webm'],
        ]);

        $f = $r->file('media');
        $mime = (string) $f->getMimeType();
        $type = $this->knowledgeMediaType($mime);
        [$path, $disk] = $this->storeKnowledgeFile($f);
        $storagePath = $disk === 'local' ? 'local://' . $path : $path;

        $mid = DB::table('egc_tool_knowledge_post_media')->insertGetId([
            'post_id' => $id,
            'media_type' => $type,
            'storage_path' => $storagePath,
            'original_name' => $f->getClientOriginalName(),
            'mime_type' => $mime,
            'file_size' => $f->getSize(),
            'display_order' => (int) DB::table('egc_tool_knowledge_post_media')->where('post_id', $id)->max('display_order') + 1,
            'status' => 'ready',
            'created_at' => now(),
        ]);

        return $this->ok([
            'id' => $mid,
            'media_type' => $type,
            'path' => $path,
            'disk' => $disk,
            'url' => route('productivity.knowledge.media.view', ['id' => $mid]),
        ], 'Media uploaded.');
    }

    public function mediaView(Request $r, int $id)
    {
        $media = DB::table('egc_tool_knowledge_post_media as m')
            ->join('egc_tool_knowledge_posts as p', 'p.sno', '=', 'm.post_id')
            ->where('m.sno', $id)
            ->where('m.status', 'ready')
            ->whereNull('p.deleted_at')
            ->select('m.*', 'p.author_user_id', 'p.company_id', 'p.audience_scope')
            ->first();

        abort_unless($media, 404);

        $post = KnowledgePost::find((int) $media->post_id);
        abort_unless($post && $this->canViewKnowledgePost($r, $post), 403);

        $storagePath = (string) $media->storage_path;
        if (str_starts_with($storagePath, 'local://')) {
            $path = substr($storagePath, 8);
            $disk = Storage::disk('local');

            abort_unless($disk->exists($path), 404, 'Knowledge media file was not found.');

            return response()->file($disk->path($path), [
                'Content-Type' => $media->mime_type ?: 'application/octet-stream',
                'Content-Disposition' => 'inline; filename="' . addslashes($media->original_name ?: 'knowledge-file') . '"',
                'X-Content-Type-Options' => 'nosniff',
            ]);
        }

        abort_unless($this->knowledgeS3Available(), 503, 'Knowledge media storage is not configured.');

        try {
            $s3 = Storage::disk('s3');
            abort_unless($s3->exists($storagePath), 404, 'Knowledge media file was not found.');

            return redirect()->away($s3->temporaryUrl($storagePath, now()->addMinutes(10)));
        } catch (\Throwable $e) {
            abort(503, 'Knowledge media storage is temporarily unavailable.');
        }
    }

    private function knowledgeMediaType(string $mime): string
    {
        if (str_starts_with($mime, 'image/')) return 'image';
        if (str_starts_with($mime, 'audio/')) return 'audio';
        if (str_starts_with($mime, 'video/')) return 'video';
        return 'file';
    }

    private function knowledgeS3Available(): bool
    {
        return class_exists('League\\Flysystem\\AwsS3V3\\PortableVisibilityConverter');
    }

    private function storeKnowledgeFile($file): array
    {
        $directory = 'egpk/knowledge/' . date('Y/m');

        if ($this->knowledgeS3Available()) {
            try {
                return [$file->store($directory, 's3'), 's3'];
            } catch (\Throwable $e) {
                // Fall back to private local storage for the Knowledge module only.
            }
        }

        return [$file->store($directory, 'local'), 'local'];
    }

    /**
     * Build a social-style preview payload for Knowledge URL posts.
     *
     * The Knowledge store keeps URL posts inside body_html as a sanitized
     * anchor followed by optional descriptive text. This helper extracts
     * that first external URL, derives the domain/description, and resolves
     * the site's official favicon through the existing Bookmark favicon service.
     *
     * Returns null for non-URL posts so the existing rendering path is left
     * completely unchanged for text/media/file posts.
     */
    private function buildUrlPreview($post): ?array
    {
        $html = trim((string) ($post->body_html ?? ''));
        if ($html === '' || stripos($html, 'http') === false) {
            return null;
        }

        $url = null;
        $description = '';

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();

        if (@$dom->loadHTML('<?xml encoding="utf-8"?><div>' . $html . '</div>')) {
            $xpath = new \DOMXPath($dom);

            $link = $xpath->query('//a[@href][1]')->item(0);
            if ($link instanceof \DOMElement) {
                $candidate = trim((string) $link->getAttribute('href'));
                if (filter_var($candidate, FILTER_VALIDATE_URL)) {
                    $scheme = strtolower((string) parse_url($candidate, PHP_URL_SCHEME));
                    if (in_array($scheme, ['http', 'https'], true)) {
                        $url = $candidate;
                    }
                }
            }

            $textNodes = $xpath->query('//text()[not(ancestor::a)]');
            $parts = [];
            if ($textNodes) {
                foreach ($textNodes as $node) {
                    $value = trim((string) $node->nodeValue);
                    if ($value !== '') {
                        $parts[] = $value;
                    }
                }
            }
            $description = trim(preg_replace('/\s+/u', ' ', implode(' ', $parts)) ?? '');
        }

        libxml_clear_errors();

        // Legacy URL posts may not contain an anchor. Fall back to the first
        // plain http(s) URL present in the sanitized HTML.
        if (!$url && preg_match('~https?://[^\s<>"\']+~i', $html, $match)) {
            $candidate = trim($match[0], " \t\n\r\0\x0B.,);]}>");
            if (filter_var($candidate, FILTER_VALIDATE_URL)) {
                $scheme = strtolower((string) parse_url($candidate, PHP_URL_SCHEME));
                if (in_array($scheme, ['http', 'https'], true)) {
                    $url = $candidate;
                }
            }
        }

        if (!$url) {
            return null;
        }

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $domain = preg_replace('/^www\./i', '', $host) ?: $host;
        $title = trim((string) ($post->title ?? '')) ?: $domain;

        // Do not expose the raw URL as the description when it is the only
        // visible text in the stored HTML.
        if ($description === $url || strcasecmp($description, $domain) === 0) {
            $description = '';
        }

        $faviconUrl = null;
        $officialTitle = null;
        try {
            /** @var BookmarkFaviconService $faviconService */
            $faviconService = app(BookmarkFaviconService::class);
            $faviconUrl = $faviconService->getFavicon($url);
            $officialTitle = $faviconService->getOfficialTitle($url);
        } catch (\Throwable $exception) {
            report($exception);
        }

        // URL cards should present the target site's own page title. When the
        // target does not expose a usable <title>, use the clean domain rather
        // than the internal Knowledge post title so the card remains a true
        // external-site preview.
        $siteTitle = trim((string) ($officialTitle ?: $domain));

        return [
            'url' => $url,
            'title' => $siteTitle,
            'site_title' => $siteTitle,
            'description' => $description,
            'domain' => $domain,
            'favicon_url' => $faviconUrl,
        ];
    }

    private function mediaForPost(int $postId)
    {
        return DB::table('egc_tool_knowledge_post_media')
            ->where('post_id', $postId)
            ->where('status', 'ready')
            ->orderBy('display_order')
            ->get()
            ->map(function ($media) {
                $media->url = route('productivity.knowledge.media.view', ['id' => $media->sno]);

                return $media;
            });
    }

    /* ---------------- Knowledge settings ---------------- */

    public function storeCategory(Request $r): JsonResponse
    {
        $this->assertSettingsManager($r);
        $d = $r->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'audience_mode' => ['required', 'in:company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
        ]);
        $audience = $this->normalizeKnowledgeAudience($r);
        $this->assertKnowledgeAudienceAllowed($r, $audience);
        $companyId = $this->access->isGroupAdmin($r) ? null : $this->cid();
        $duplicate = DB::table('egc_tool_knowledge_categories')
            ->whereNull('deleted_at')
            ->whereRaw('LOWER(category_name) = ?', [mb_strtolower(trim($d['category_name']))])
            ->where(function ($q) use ($companyId) {
                $q->where('company_id', $companyId);
                $companyId === null ? $q->orWhereNull('company_id') : null;
            })->exists();
        abort_if($duplicate, 422, 'A category with this name already exists.');

        $id = DB::table('egc_tool_knowledge_categories')->insertGetId([
            'company_id' => $companyId,
            'category_name' => trim($d['category_name']),
            'color' => $d['color'] ?? '#b52b25',
            'audience_json' => json_encode($audience, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'status' => 0,
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $this->audit($r, 'Knowledge Panel', 'category_created', 'knowledge_category', $id, null, [
            'category_name' => trim($d['category_name']),
            'audience_mode' => $audience['audience_mode'],
        ]);
        return $this->ok(['id' => $id], 'Category created.');
    }

    public function updateCategory(Request $r, int $id): JsonResponse
    {
        $this->assertSettingsManager($r);
        $category = DB::table('egc_tool_knowledge_categories')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($category, 404);
        $this->assertSettingsScope($r, $category->company_id);
        $d = $r->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['nullable', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'audience_mode' => ['required', 'in:company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
        ]);
        $audience = $this->normalizeKnowledgeAudience($r);
        $this->assertKnowledgeAudienceAllowed($r, $audience);
        $companyId = $category->company_id;
        $duplicate = DB::table('egc_tool_knowledge_categories')
            ->whereNull('deleted_at')->where('sno', '!=', $id)
            ->whereRaw('LOWER(category_name) = ?', [mb_strtolower(trim($d['category_name']))])
            ->where(function ($q) use ($companyId) {
                $q->where('company_id', $companyId);
                $companyId === null ? $q->orWhereNull('company_id') : null;
            })->exists();
        abort_if($duplicate, 422, 'A category with this name already exists.');
        DB::transaction(function () use ($id, $d, $category, $audience) {
            DB::table('egc_tool_knowledge_categories')->where('sno', $id)->update([
                'category_name' => trim($d['category_name']),
                'color' => $d['color'] ?? ($category->color ?: '#b52b25'),
                'audience_json' => json_encode($audience, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'updated_by' => $this->uid(), 'updated_at' => now(),
            ]);
            $this->syncKnowledgeCategoryAudienceToPosts($id, $audience);
        });
        $this->audit($r, 'Knowledge Panel', 'category_updated', 'knowledge_category', $id, [
            'category_name' => $category->category_name,
            'audience_mode' => $this->decodeKnowledgeAudience($category->audience_json ?? null)['audience_mode'] ?? null,
        ], [
            'category_name' => trim($d['category_name']),
            'audience_mode' => $audience['audience_mode'],
        ]);
        return $this->ok(['id' => $id], 'Category updated.');
    }

    public function deleteCategory(Request $r, int $id): JsonResponse
    {
        $this->assertSettingsManager($r);
        $category = DB::table('egc_tool_knowledge_categories')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($category, 404);
        $this->assertSettingsScope($r, $category->company_id);

        DB::table('egc_tool_knowledge_categories')->where('sno', $id)->update([
            'status' => 1,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
            'updated_at' => now(),
        ]);
        $this->audit($r, 'Knowledge Panel', 'category_deleted', 'knowledge_category', $id, ['status' => $category->status], ['status' => 1]);
        return $this->ok(null, 'Category deleted.');
    }

    public function categoryStatus(Request $r, int $id): JsonResponse
    {
        $this->assertSettingsManager($r);
        $category = DB::table('egc_tool_knowledge_categories')->where('sno', $id)->whereNull('deleted_at')->first();
        abort_unless($category, 404);
        $this->assertSettingsScope($r, $category->company_id);
        $status = (int) ($r->input('status', ((int) $category->status === 0 ? 1 : 0)));
        abort_unless(in_array($status, [0,1], true), 422);
        DB::table('egc_tool_knowledge_categories')->where('sno', $id)->update(['status' => $status, 'updated_by' => $this->uid(), 'updated_at' => now()]);
        $this->audit($r, 'Knowledge Panel', 'category_status_changed', 'knowledge_category', $id, ['status' => (int) $category->status], ['status' => $status]);
        return $this->ok(['status' => $status], $status === 0 ? 'Category activated.' : 'Category deactivated.');
    }

    private function canManageSettings(Request $r): bool
    {
        return !$this->access->isAuditor($r) && ($this->access->isGroupAdmin($r) || $this->access->isCompanyAdmin($r));
    }

    private function assertSettingsManager(Request $r): void
    {
        abort_unless($this->canManageSettings($r), 403);
    }

    private function applySettingsCompanyScope($query, Request $r, string $column): void
    {
        if ($this->access->isGroupAdmin($r)) return;
        $cid = $this->cid();
        $query->where(function ($q) use ($column, $cid) {
            $q->whereNull($column)->orWhere($column, $cid);
        });
    }

    private function assertSettingsScope(Request $r, $companyId): void
    {
        if ($this->access->isGroupAdmin($r)) return;
        $cid = $this->cid();
        abort_unless($companyId === null || (int) $companyId === (int) $cid, 403);
    }

    private function settingsCompanyId(Request $r, $requested): ?int
    {
        if ($this->access->isGroupAdmin($r)) {
            if ($requested === null || $requested === '') return null;
            $id = (int) $requested;
            abort_unless(DB::table('egc_company')->where('sno', $id)->where('status', 0)->exists(), 422, 'Selected company is inactive.');
            return $id;
        }
        $cid = $this->cid();
        if ($requested !== null && $requested !== '' && (int) $requested !== (int) $cid) abort(403);
        return $cid;
    }

    private function resolvePostCompany(Request $r, $requested, $categoryCompanyId): ?int
    {
        if ($this->access->isGroupAdmin($r)) return ($requested === null || $requested === '') ? ($categoryCompanyId !== null ? (int) $categoryCompanyId : null) : $this->settingsCompanyId($r, $requested);
        return $this->cid();
    }

    private function visibleCategory(Request $r, int $id)
    {
        $q = DB::table('egc_tool_knowledge_categories')->where('sno', $id)->where('status', 0)->whereNull('deleted_at');
        $this->applySettingsCompanyScope($q, $r, 'company_id');
        $category = $q->first();
        abort_unless($category, 422, 'Selected category is not available in your scope.');
        return $category;
    }

    private function assertReadableCategory(Request $r, $companyId): void
    {
        $ctx = $this->knowledgeUserContext($r);

        /*
         * role_id = 1 is the Knowledge full-view administrator and may use
         * user_id = 0 by design.
         */
        if ((int) $ctx['role_id'] !== 1) {
            abort_unless((int) $ctx['uid'] > 0, 401, 'Authenticated Knowledge user is required.');
        }

        if ((int) $ctx['role_id'] === 1) return;

        // NULL/0 denotes a Group category, which is available to all
        // authenticated Knowledge users.
        if ($companyId === null || (int) $companyId === 0) return;

        $userCompanyId = $ctx['company_id'];
        abort_unless(
            $userCompanyId !== null && (int) $companyId === (int) $userCompanyId,
            403
        );
    }

    private function assertReadablePost(Request $r, KnowledgePost $p): void
    {
        abort_unless($this->canViewKnowledgePost($r, $p), 403);
    }
}
