<?php
namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bookmark extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'egc_tool_bookmarks';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];
    protected $fillable = [
        'board_id',
        'category_id',
        'owner_user_id',
        'bookmark_name',
        'url',
        'description',
        'favicon_url',
        'manual_icon',
        'tags_json',
        'click_count',
        'sort_order',
        'is_pinned',
        'health_status',
        'last_checked_at',
        'status',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'deleted_at',
    ];
    protected $casts = ['board_id' => 'integer', 'category_id' => 'integer', 'owner_user_id' => 'integer', 'click_count' => 'integer', 'sort_order' => 'integer', 'is_pinned' => 'boolean', 'tags_json' => 'array', 'last_checked_at' => 'datetime'];

    public function board(){return $this->belongsTo(Board::class,'board_id','sno');}
    public function category(){return $this->belongsTo(BoardCategory::class,'category_id','sno');}
}