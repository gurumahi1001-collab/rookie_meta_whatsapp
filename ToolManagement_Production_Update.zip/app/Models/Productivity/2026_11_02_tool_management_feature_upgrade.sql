-- Tool Management feature update: category audience, mobile OS and pinned bookmarks.
-- Run once against the target ERP database before deploying the updated PHP/Blade files.
-- Idempotent on MySQL 8: each column is added only when it is not already present.

SET @db_name = DATABASE();

SET @ddl = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'egc_tool_knowledge_categories' AND COLUMN_NAME = 'audience_json') = 0,
    'ALTER TABLE egc_tool_knowledge_categories ADD COLUMN audience_json JSON NULL AFTER color',
    'SELECT 1'
);
PREPARE tool_mgmt_stmt FROM @ddl;
EXECUTE tool_mgmt_stmt;
DEALLOCATE PREPARE tool_mgmt_stmt;

SET @ddl = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'egc_tool_portal_apps' AND COLUMN_NAME = 'mobile_platform') = 0,
    'ALTER TABLE egc_tool_portal_apps ADD COLUMN mobile_platform ENUM(''Android'',''iOS'') NULL AFTER platform',
    'SELECT 1'
);
PREPARE tool_mgmt_stmt FROM @ddl;
EXECUTE tool_mgmt_stmt;
DEALLOCATE PREPARE tool_mgmt_stmt;

SET @ddl = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'egc_tool_bookmarks' AND COLUMN_NAME = 'is_pinned') = 0,
    'ALTER TABLE egc_tool_bookmarks ADD COLUMN is_pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER sort_order',
    'SELECT 1'
);
PREPARE tool_mgmt_stmt FROM @ddl;
EXECUTE tool_mgmt_stmt;
DEALLOCATE PREPARE tool_mgmt_stmt;

SET @ddl = IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'egc_tool_bookmarks' AND INDEX_NAME = 'idx_bookmark_board_pinned_order') = 0,
    'ALTER TABLE egc_tool_bookmarks ADD INDEX idx_bookmark_board_pinned_order (board_id, is_pinned, status, sort_order)',
    'SELECT 1'
);
PREPARE tool_mgmt_stmt FROM @ddl;
EXECUTE tool_mgmt_stmt;
DEALLOCATE PREPARE tool_mgmt_stmt;
