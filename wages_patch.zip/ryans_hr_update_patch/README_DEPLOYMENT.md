# Ryan Infra — Attendance, Leave and Wages incremental patch

## Source and scope

Prepared against the uploaded `txt271026.zip` MVC source and its `ryans_infra` SQL dump. Only the 15 changed files in this archive are included. Copy them over the same relative paths in the existing Laravel application; do not replace the whole application.

This is a code-only patch. No new database columns or tables are required for these corrections. The supplied schema already defines the staff, attendance, leave request, entitlement and remuneration tables used here, and the needed API routes are already registered in `routes/web.php` inside the existing `admin-hr/api` route group. Therefore, no route file or SQL migration is included intentionally.

## Fixes

- **Attendance list:** loads active permanent/contract staff for the selected current day even if no attendance record exists yet; preserves the existing list table and action modals; adds skeleton/loading, search, department filtering, pagination and summary refresh. Present, Absent, Leave and Check-out save through the existing POST endpoint.
- **Attendance table:** forces the correct staff category on each Blade page. In particular, contract table requests no longer depend on a global `data-staff-type` attribute that may be absent or incorrect. Existing month matrix cells remain editable.
- **Attendance calendar:** normalizes `HH:mm:ss` database times to `HH:mm` before submitting, clears time fields when saving Absent/Leave, and fetches all result pages so staff beyond the first 100 are available without adding new UI controls.
- **Attendance persistence:** checks the staff category, prevents writes to deleted staff, blocks marking an inactive staff member for today, normalizes non-present statuses to have no in/out times, and locks the staff row during save to reduce duplicate concurrent attendance creation.
- **Leave management:** queries leave request primary key `sno` (not nonexistent `id`) and returns `sno as id` for existing UI actions. AJAX errors now surface API validation responses; directory initialization handles both loading and already-loaded documents.
- **Wages:** fixes detail/save URLs so they match existing routes (`GET /admin-hr/api/wages/{type}/{id}` and `PUT /admin-hr/api/wages/{type}/{id}`), checks API error responses, and adds pagination to the existing staff list without replacing the remuneration layout.

## Changed files

- `app/Http/Controllers/attendance_log/AttendanceDirectoryController.php`
- `app/Services/HR/AttendanceService.php`
- `app/Services/HR/LeaveService.php`
- `resources/views/content/admin_hr/attendance_log/permanent_list.blade.php`
- `resources/views/content/admin_hr/attendance_log/contract_list.blade.php`
- `resources/views/content/admin_hr/attendance_log/permanent_table.blade.php`
- `resources/views/content/admin_hr/attendance_log/contract_table.blade.php`
- `resources/views/content/admin_hr/attendance_log/permanent_calender.blade.php`
- `resources/views/content/admin_hr/attendance_log/contract_calender.blade.php`
- `resources/views/content/admin_hr/leave_manage/permanent_lisst.blade.php`
- `resources/views/content/admin_hr/leave_manage/contract_lisst.blade.php`
- `resources/views/content/admin_hr/leave_manage/permanent_entitle.blade.php`
- `resources/views/content/admin_hr/leave_manage/contract_entitle.blade.php`
- `resources/views/content/admin_hr/wages/Permanent/salary_permanent.blade.php`
- `resources/views/content/admin_hr/wages/Contract/salary_contract.blade.php`

## Validation and deployment

- PHP syntax checks passed for the included PHP files.
- Node syntax checks passed for all 16 script blocks in the modified Blade files.
- Static checks verified the existing route patterns, type-specific attendance URLs, leave primary-key correction, and wages detail/save URL correction.
- A live Laravel boot, database integration test, permissions/role test and full browser click-through were not available in this environment. Treat this as a staging patch until those are completed against a copy of the target database.

Recommended deployment:

1. Back up the application files and `ryans_infra` database.
2. Copy the 15 files to the exact relative paths above; retain all other files.
3. Run `php artisan view:clear` and `php artisan route:clear` only if needed by your release process (no routes are changed by this patch).
4. In staging, verify permanent and contract list/table/calendar attendance edits; check-in/check-out time validation; leave creation/review/entitlement changes; and wage component load/save.
5. Confirm unaffected ERP modules and role permissions continue to behave as expected before production rollout.
