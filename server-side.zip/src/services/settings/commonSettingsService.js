import mongoose from "mongoose";

import Unit from "../../models/Unit.js";
import ValidityPeriod from "../../models/ValidityPeriod.js";
import TermsCondition from "../../models/TermsCondition.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const SETTING_TYPES = Object.freeze({
    UNIT: "unit",
    VALIDITY_PERIOD: "validity_period",
    TERMS_CONDITION: "terms_condition",
});

const SUPPORTED_TYPES = Object.freeze(
    Object.values(SETTING_TYPES),
);

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;

/*
|--------------------------------------------------------------------------
| Service Error
|--------------------------------------------------------------------------
*/

export class CommonSettingsServiceError
    extends Error {
    constructor(
        message,
        {
            code =
                "COMMON_SETTINGS_ERROR",
            statusCode = 400,
            details = undefined,
            cause = undefined,
        } = {},
    ) {
        super(message);

        this.name =
            "CommonSettingsServiceError";

        this.code =
            code;

        this.statusCode =
            statusCode;

        this.details =
            details;

        if (cause) {
            this.cause =
                cause;
        }

        Error.captureStackTrace?.(
            this,
            CommonSettingsServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Type Registry                                                              */
/* -------------------------------------------------------------------------- */

const TYPE_CONFIG = Object.freeze({
    [SETTING_TYPES.UNIT]: {
        Model: Unit,
        label: "Unit",
        pluralLabel: "Units",
    },

    [SETTING_TYPES.VALIDITY_PERIOD]: {
        Model: ValidityPeriod,
        label: "Validity Period",
        pluralLabel:
            "Validity Periods",
    },

    [SETTING_TYPES.TERMS_CONDITION]: {
        Model: TermsCondition,
        label: "Terms & Conditions",
        pluralLabel:
            "Terms & Conditions",
    },
});

/* -------------------------------------------------------------------------- */
/* Normalization Helpers                                                      */
/* -------------------------------------------------------------------------- */

function normalizeString(
    value,
) {
    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value).trim();
}

function normalizeType(
    type,
) {
    const normalized =
        normalizeString(
            type,
        ).toLowerCase();

    if (
        !SUPPORTED_TYPES.includes(
            normalized,
        )
    ) {
        throw new CommonSettingsServiceError(
            "Unsupported common setting type.",
            {
                code:
                    "INVALID_COMMON_SETTING_TYPE",
                statusCode: 400,
                details: {
                    type:
                        normalized ||
                        null,
                    supportedTypes:
                        SUPPORTED_TYPES,
                },
            },
        );
    }

    return normalized;
}

function getTypeConfig(
    type,
) {
    const normalizedType =
        normalizeType(type);

    return {
        type:
            normalizedType,

        ...TYPE_CONFIG[
            normalizedType
        ],
    };
}

function ensureObjectId(
    id,
) {
    const value =
        normalizeString(id);

    if (
        !mongoose.Types.ObjectId.isValid(
            value,
        )
    ) {
        throw new CommonSettingsServiceError(
            "Invalid common setting ID.",
            {
                code:
                    "INVALID_COMMON_SETTING_ID",
                statusCode: 400,
            },
        );
    }

    return new mongoose.Types.ObjectId(
        value,
    );
}

function normalizeBoolean(
    value,
    fieldName = "status",
) {
    if (
        typeof value ===
        "boolean"
    ) {
        return value;
    }

    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    const normalized =
        String(value)
            .trim()
            .toLowerCase();

    if (
        normalized === "true" ||
        normalized === "1"
    ) {
        return true;
    }

    if (
        normalized === "false" ||
        normalized === "0"
    ) {
        return false;
    }

    throw new CommonSettingsServiceError(
        `${fieldName} must be true or false.`,
        {
            code:
                "INVALID_BOOLEAN_VALUE",
            statusCode: 422,
            details: {
                field:
                    fieldName,
            },
        },
    );
}

function normalizePage(
    value,
) {
    const page =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(page) ||
        page < 1
    ) {
        return DEFAULT_PAGE;
    }

    return page;
}

function normalizeLimit(
    value,
) {
    const limit =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(limit) ||
        limit < 1
    ) {
        return DEFAULT_LIMIT;
    }

    return Math.min(
        MAX_LIMIT,
        limit,
    );
}

function getUserId(
    user,
) {
    return (
        user?.id ||
        user?._id ||
        null
    );
}

/**
 * Normalize the authenticated user id before assigning it to an ObjectId
 * audit field. The service owns this boundary so all common-setting writes
 * behave consistently.
 */
function normalizeAuditUserId(
    userId,
    fieldName = "updatedBy",
) {
    if (
        userId === undefined ||
        userId === null ||
        userId === ""
    ) {
        return null;
    }

    const value =
        String(userId).trim();

    if (
        !mongoose.Types.ObjectId.isValid(
            value,
        )
    ) {
        throw new CommonSettingsServiceError(
            `Invalid ${fieldName} user identifier.`,
            {
                code:
                    "INVALID_AUDIT_USER_ID",
                statusCode: 400,
                details: {
                    field:
                        fieldName,
                },
            },
        );
    }

    return new mongoose.Types.ObjectId(
        value,
    );
}

/**
 * Convert common Mongoose persistence errors into stable application
 * errors. Unexpected infrastructure errors are re-thrown unchanged so the
 * centralized error handler can log the real cause without exposing it to
 * the browser.
 */
function normalizePersistenceError(
    error,
    {
        label = "Common setting",
        operation = "saving",
    } = {},
) {
    if (
        error instanceof
        CommonSettingsServiceError
    ) {
        return error;
    }

    if (
        error?.code === 11000
    ) {
        return new CommonSettingsServiceError(
            `${label} already exists.`,
            {
                code:
                    "COMMON_SETTING_DUPLICATE",
                statusCode: 409,
                details: {
                    operation,
                },
                cause:
                    error,
            },
        );
    }

    if (
        error?.name ===
        "ValidationError"
    ) {
        const fields =
            Object.fromEntries(
                Object.entries(
                    error.errors ||
                        {},
                ).map(
                    ([
                        field,
                        fieldError,
                    ]) => [
                        field,
                        fieldError?.message ||
                            "Invalid value.",
                    ],
                ),
            );

        return new CommonSettingsServiceError(
            `${label} validation failed while ${operation}.`,
            {
                code:
                    "COMMON_SETTING_VALIDATION_FAILED",
                statusCode: 422,
                details: {
                    fields,
                },
                cause:
                    error,
            },
        );
    }

    if (
        error?.name ===
            "CastError" &&
        error?.kind ===
            "ObjectId"
    ) {
        return new CommonSettingsServiceError(
            `Invalid ${label.toLowerCase()} identifier.`,
            {
                code:
                    "INVALID_COMMON_SETTING_ID",
                statusCode: 400,
                details: {
                    field:
                        error.path ||
                        undefined,
                },
                cause:
                    error,
            },
        );
    }

    return error;
}

/* -------------------------------------------------------------------------- */
/* Serialization                                                              */
/* -------------------------------------------------------------------------- */

function serializeDocument(
    document,
    type,
) {
    if (!document) {
        return null;
    }

    if (
        typeof document.toSafeJSON ===
        "function"
    ) {
        const data =
            document.toSafeJSON();

        return {
            ...data,

            id:
                data.id ||
                document._id?.toString(),

            type,
        };
    }

    const object =
        typeof document.toObject ===
        "function"
            ? document.toObject({
                  depopulate: true,
              })
            : document;

    if (
        type ===
        SETTING_TYPES.UNIT
    ) {
        return {
            id:
                object._id?.toString(),

            type,

            name:
                object.name || "",

            description:
                object.description || "",

            status:
                object.status === true,

            ...(object.sortOrder !==
            undefined
                ? {
                      sortOrder:
                          object.sortOrder,
                  }
                : {}),

            createdAt:
                object.createdAt ||
                null,

            updatedAt:
                object.updatedAt ||
                null,
        };
    }

    if (
        type ===
        SETTING_TYPES.VALIDITY_PERIOD
    ) {
        return {
            id:
                object._id?.toString(),

            type,

            name:
                object.name || "",

            description:
                object.description || "",

            status:
                object.status === true,

            ...(object.sortOrder !==
            undefined
                ? {
                      sortOrder:
                          object.sortOrder,
                  }
                : {}),

            createdAt:
                object.createdAt ||
                null,

            updatedAt:
                object.updatedAt ||
                null,
        };
    }

    return {
        id:
            object._id?.toString(),

        type,

        title:
            object.title || "",

        content:
            object.content || "",

        status:
            object.status === true,

        ...(object.sortOrder !==
        undefined
            ? {
                  sortOrder:
                      object.sortOrder,
              }
            : {}),

        createdAt:
            object.createdAt ||
            null,

        updatedAt:
            object.updatedAt ||
            null,
    };
}

/* -------------------------------------------------------------------------- */
/* Validation                                                                 */
/* -------------------------------------------------------------------------- */

function validateUnitPayload(
    payload,
) {
    const name =
        normalizeString(
            payload.name,
        );

    const description =
        normalizeString(
            payload.description,
        );

    if (!name) {
        throw new CommonSettingsServiceError(
            "Unit name is required.",
            {
                code:
                    "UNIT_NAME_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        name.length > 100
    ) {
        throw new CommonSettingsServiceError(
            "Unit name cannot exceed 100 characters.",
            {
                code:
                    "INVALID_UNIT_NAME",
                statusCode: 422,
            },
        );
    }

    if (!description) {
        throw new CommonSettingsServiceError(
            "Unit description is required.",
            {
                code:
                    "UNIT_DESCRIPTION_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        description.length > 1000
    ) {
        throw new CommonSettingsServiceError(
            "Unit description cannot exceed 1000 characters.",
            {
                code:
                    "INVALID_UNIT_DESCRIPTION",
                statusCode: 422,
            },
        );
    }

    return {
        name,
        description,
    };
}

function validateValidityPeriodPayload(
    payload,
) {
    const name =
        normalizeString(
            payload.name,
        );

    const description =
        normalizeString(
            payload.description,
        );

    if (!name) {
        throw new CommonSettingsServiceError(
            "Validity period name is required.",
            {
                code:
                    "VALIDITY_PERIOD_NAME_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        name.length > 150
    ) {
        throw new CommonSettingsServiceError(
            "Validity period name cannot exceed 150 characters.",
            {
                code:
                    "INVALID_VALIDITY_PERIOD_NAME",
                statusCode: 422,
            },
        );
    }

    if (!description) {
        throw new CommonSettingsServiceError(
            "Validity period description is required.",
            {
                code:
                    "VALIDITY_PERIOD_DESCRIPTION_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        description.length >
        1000
    ) {
        throw new CommonSettingsServiceError(
            "Validity period description cannot exceed 1000 characters.",
            {
                code:
                    "INVALID_VALIDITY_PERIOD_DESCRIPTION",
                statusCode: 422,
            },
        );
    }

    return {
        name,
        description,
    };
}

function stripHtml(
    html,
) {
    return normalizeString(
        String(html || "")
            .replace(
                /<script\b[^>]*>[\s\S]*?<\/script>/gi,
                " ",
            )
            .replace(
                /<style\b[^>]*>[\s\S]*?<\/style>/gi,
                " ",
            )
            .replace(
                /<[^>]*>/g,
                " ",
            )
            .replace(
                /&nbsp;/gi,
                " ",
            )
            .replace(
                /\s+/g,
                " ",
            ),
    );
}

function validateTermsPayload(
    payload,
) {
    const title =
        normalizeString(
            payload.title,
        );

    const content =
        typeof payload.content ===
        "string"
            ? payload.content.trim()
            : "";

    if (!title) {
        throw new CommonSettingsServiceError(
            "Terms & Conditions title is required.",
            {
                code:
                    "TERMS_TITLE_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        title.length > 250
    ) {
        throw new CommonSettingsServiceError(
            "Terms & Conditions title cannot exceed 250 characters.",
            {
                code:
                    "INVALID_TERMS_TITLE",
                statusCode: 422,
            },
        );
    }

    if (
        !content ||
        !stripHtml(content)
    ) {
        throw new CommonSettingsServiceError(
            "Terms & Conditions content is required.",
            {
                code:
                    "TERMS_CONTENT_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        content.length >
        200000
    ) {
        throw new CommonSettingsServiceError(
            "Terms & Conditions content is too large.",
            {
                code:
                    "INVALID_TERMS_CONTENT",
                statusCode: 422,
            },
        );
    }

    return {
        title,
        content,
    };
}

/* -------------------------------------------------------------------------- */
/* Duplicate Protection                                                       */
/* -------------------------------------------------------------------------- */

async function ensureUniqueName(
    Model,
    name,
    {
        excludeId = null,
        label = "Setting",
    } = {},
) {
    const filter = {
        name,
    };

    if (excludeId) {
        filter._id = {
            $ne: excludeId,
        };
    }

    const existing =
        await Model.findOne(
            filter,
        ).select("_id");

    if (existing) {
        throw new CommonSettingsServiceError(
            `${label} with this name already exists.`,
            {
                code:
                    "COMMON_SETTING_DUPLICATE",
                statusCode: 409,
                details: {
                    field: "name",
                },
            },
        );
    }
}

async function ensureUniqueTitle(
    Model,
    title,
    {
        excludeId = null,
    } = {},
) {
    const filter = {
        title,
    };

    if (excludeId) {
        filter._id = {
            $ne: excludeId,
        };
    }

    const existing =
        await Model.findOne(
            filter,
        ).select("_id");

    if (existing) {
        throw new CommonSettingsServiceError(
            "Terms & Conditions with this title already exists.",
            {
                code:
                    "COMMON_SETTING_DUPLICATE",
                statusCode: 409,
                details: {
                    field: "title",
                },
            },
        );
    }
}

/* -------------------------------------------------------------------------- */
/* LIST                                                                       */
/* -------------------------------------------------------------------------- */

export async function listCommonSettings(
    {
        type,
        page = DEFAULT_PAGE,
        limit = DEFAULT_LIMIT,
        search = "",
        status,
    } = {},
) {
    const {
        Model,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    const normalizedPage =
        normalizePage(page);

    const normalizedLimit =
        normalizeLimit(limit);

    const normalizedSearch =
        normalizeString(
            search,
        );

    const filter = {};

    /*
     * Search the fields that actually exist in the current UI.
     */
    if (
        normalizedSearch
    ) {
        const escaped =
            normalizedSearch.replace(
                /[.*+?^${}()|[\]\\]/g,
                "\\$&",
            );

        const regex =
            new RegExp(
                escaped,
                "i",
            );

        if (
            normalizedType ===
                SETTING_TYPES.TERMS_CONDITION
        ) {
            filter.$or = [
                {
                    title: regex,
                },
                {
                    content: regex,
                },
            ];
        } else {
            filter.$or = [
                {
                    name: regex,
                },
                {
                    description:
                        regex,
                },
            ];
        }
    }

    const normalizedStatus =
        normalizeBoolean(
            status,
            "status",
        );

    if (
        normalizedStatus !==
        undefined
    ) {
        filter.status =
            normalizedStatus;
    }

    const skip =
        (normalizedPage - 1) *
        normalizedLimit;

    const sort = {
        sortOrder: 1,
        ...(normalizedType ===
        SETTING_TYPES.TERMS_CONDITION
            ? {
                  createdAt: -1,
              }
            : {
                  name: 1,
              }),
    };

    const [
        documents,
        total,
    ] = await Promise.all([
        Model.find(filter)
            .sort(sort)
            .skip(skip)
            .limit(
                normalizedLimit,
            )
            .lean(false),

        Model.countDocuments(
            filter,
        ),
    ]);

    const items =
        documents.map(
            (document) =>
                serializeDocument(
                    document,
                    normalizedType,
                ),
        );

    return {
        type:
            normalizedType,

        items,

        data:
            items,

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            totalPages:
                Math.ceil(
                    total /
                        normalizedLimit,
                ),
        },

        filters: {
            search:
                normalizedSearch,

            status:
                normalizedStatus,
        },
    };
}

/* -------------------------------------------------------------------------- */
/* GET                                                                        */
/* -------------------------------------------------------------------------- */

export async function getCommonSetting(
    type,
    id,
) {
    const {
        Model,
        label,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    const objectId =
        ensureObjectId(id);

    const document =
        await Model.findById(
            objectId,
        );

    if (!document) {
        throw new CommonSettingsServiceError(
            `${label} not found.`,
            {
                code:
                    "COMMON_SETTING_NOT_FOUND",
                statusCode: 404,
                details: {
                    type:
                        normalizedType,
                    id:
                        objectId.toString(),
                },
            },
        );
    }

    return serializeDocument(
        document,
        normalizedType,
    );
}

/* -------------------------------------------------------------------------- */
/* CREATE                                                                     */
/* -------------------------------------------------------------------------- */

export async function createCommonSetting(
    type,
    payload,
    {
        userId = null,
    } = {},
) {
    const {
        Model,
        label,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(
            payload,
        )
    ) {
        throw new CommonSettingsServiceError(
            "Common setting payload must be an object.",
            {
                code:
                    "INVALID_COMMON_SETTING_PAYLOAD",
                statusCode: 400,
            },
        );
    }

    let data;

    if (
        normalizedType ===
        SETTING_TYPES.UNIT
    ) {
        data =
            validateUnitPayload(
                payload,
            );

        await ensureUniqueName(
            Model,
            data.name,
            {
                label,
            },
        );
    } else if (
        normalizedType ===
        SETTING_TYPES.VALIDITY_PERIOD
    ) {
        data =
            validateValidityPeriodPayload(
                payload,
            );

        await ensureUniqueName(
            Model,
            data.name,
            {
                label,
            },
        );
    } else {
        data =
            validateTermsPayload(
                payload,
            );

        await ensureUniqueTitle(
            Model,
            data.title,
        );
    }

    const requestedStatus =
        normalizeBoolean(
            payload.status,
            "status",
        );

    data.status =
        requestedStatus ??
        true;

    /*
     * Keep ordering deterministic within the same setting type/model.
     */
    const latest =
        await Model.findOne({})
            .sort({
                sortOrder:
                    -1,
            })
            .select(
                "sortOrder",
            )
            .lean();

    data.sortOrder =
        Number(
            latest?.sortOrder ??
                -1,
        ) + 1;

    const auditUserId =
        normalizeAuditUserId(
            userId,
            "createdBy",
        );

    if (auditUserId) {
        data.createdBy =
            auditUserId;

        data.updatedBy =
            auditUserId;
    }

    try {
        /*
         * create() runs schema validation. Keeping this in one try block
         * ensures duplicate / validation errors receive stable API codes.
         */
        const document =
            await Model.create(
                data,
            );

        return serializeDocument(
            document,
            normalizedType,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                {
                    label,
                    operation:
                        "creating the setting",
                },
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* UPDATE                                                                     */
/* -------------------------------------------------------------------------- */

export async function updateCommonSetting(
    type,
    id,
    payload,
    {
        userId = null,
    } = {},
) {
    const {
        Model,
        label,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    const objectId =
        ensureObjectId(id);

    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(payload)
    ) {
        throw new CommonSettingsServiceError(
            "Common setting payload must be an object.",
            {
                code:
                    "INVALID_COMMON_SETTING_PAYLOAD",
                statusCode: 400,
            },
        );
    }

    const document =
        await Model.findById(
            objectId,
        );

    if (!document) {
        throw new CommonSettingsServiceError(
            `${label} not found.`,
            {
                code:
                    "COMMON_SETTING_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * Current frontend sends the setting-specific fields.
     *
     * Fields are intentionally not merged blindly into the document.
     * This prevents accidental persistence of unsupported frontend
     * payload properties.
     */
    if (
        normalizedType ===
        SETTING_TYPES.UNIT
    ) {
        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "name",
            )
        ) {
            const name =
                normalizeString(
                    payload.name,
                );

            if (!name) {
                throw new CommonSettingsServiceError(
                    "Unit name is required.",
                    {
                        code:
                            "UNIT_NAME_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                name.length >
                100
            ) {
                throw new CommonSettingsServiceError(
                    "Unit name cannot exceed 100 characters.",
                    {
                        code:
                            "INVALID_UNIT_NAME",
                        statusCode: 422,
                    },
                );
            }

            if (
                name.toLowerCase() !==
                String(
                    document.name,
                ).toLowerCase()
            ) {
                await ensureUniqueName(
                    Model,
                    name,
                    {
                        excludeId:
                            objectId,
                        label,
                    },
                );
            }

            document.name =
                name;
        }

        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "description",
            )
        ) {
            const description =
                normalizeString(
                    payload.description,
                );

            if (!description) {
                throw new CommonSettingsServiceError(
                    "Unit description is required.",
                    {
                        code:
                            "UNIT_DESCRIPTION_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                description.length >
                1000
            ) {
                throw new CommonSettingsServiceError(
                    "Unit description cannot exceed 1000 characters.",
                    {
                        code:
                            "INVALID_UNIT_DESCRIPTION",
                        statusCode: 422,
                    },
                );
            }

            document.description =
                description;
        }
    } else if (
        normalizedType ===
        SETTING_TYPES.VALIDITY_PERIOD
    ) {
        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "name",
            )
        ) {
            const name =
                normalizeString(
                    payload.name,
                );

            if (!name) {
                throw new CommonSettingsServiceError(
                    "Validity period name is required.",
                    {
                        code:
                            "VALIDITY_PERIOD_NAME_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                name.length >
                150
            ) {
                throw new CommonSettingsServiceError(
                    "Validity period name cannot exceed 150 characters.",
                    {
                        code:
                            "INVALID_VALIDITY_PERIOD_NAME",
                        statusCode: 422,
                    },
                );
            }

            if (
                name.toLowerCase() !==
                String(
                    document.name,
                ).toLowerCase()
            ) {
                await ensureUniqueName(
                    Model,
                    name,
                    {
                        excludeId:
                            objectId,
                        label,
                    },
                );
            }

            document.name =
                name;
        }

        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "description",
            )
        ) {
            const description =
                normalizeString(
                    payload.description,
                );

            if (!description) {
                throw new CommonSettingsServiceError(
                    "Validity period description is required.",
                    {
                        code:
                            "VALIDITY_PERIOD_DESCRIPTION_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                description.length >
                1000
            ) {
                throw new CommonSettingsServiceError(
                    "Validity period description cannot exceed 1000 characters.",
                    {
                        code:
                            "INVALID_VALIDITY_PERIOD_DESCRIPTION",
                        statusCode: 422,
                    },
                );
            }

            document.description =
                description;
        }
    } else {
        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "title",
            )
        ) {
            const title =
                normalizeString(
                    payload.title,
                );

            if (!title) {
                throw new CommonSettingsServiceError(
                    "Terms & Conditions title is required.",
                    {
                        code:
                            "TERMS_TITLE_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                title.length >
                250
            ) {
                throw new CommonSettingsServiceError(
                    "Terms & Conditions title cannot exceed 250 characters.",
                    {
                        code:
                            "INVALID_TERMS_TITLE",
                        statusCode: 422,
                    },
                );
            }

            if (
                title.toLowerCase() !==
                String(
                    document.title,
                ).toLowerCase()
            ) {
                await ensureUniqueTitle(
                    Model,
                    title,
                    {
                        excludeId:
                            objectId,
                    },
                );
            }

            document.title =
                title;
        }

        if (
            Object.prototype.hasOwnProperty.call(
                payload,
                "content",
            )
        ) {
            const content =
                typeof payload.content ===
                "string"
                    ? payload.content.trim()
                    : "";

            if (
                !content ||
                !stripHtml(content)
            ) {
                throw new CommonSettingsServiceError(
                    "Terms & Conditions content is required.",
                    {
                        code:
                            "TERMS_CONTENT_REQUIRED",
                        statusCode: 422,
                    },
                );
            }

            if (
                content.length >
                200000
            ) {
                throw new CommonSettingsServiceError(
                    "Terms & Conditions content is too large.",
                    {
                        code:
                            "INVALID_TERMS_CONTENT",
                        statusCode: 422,
                    },
                );
            }

            document.content =
                content;
        }
    }

    /*
     * Common status handling.
     *
     * The current Unit UI uses its own ToggleSwitch and Terms UI
     * currently does not expose a status field, but accepting `status`
     * here makes the backend reusable without affecting either UI.
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "status",
        )
    ) {
        const status =
            normalizeBoolean(
                payload.status,
                "status",
            );

        if (
            status !==
            undefined
        ) {
            document.status =
                status;
        }
    }

    const auditUserId =
        normalizeAuditUserId(
            userId,
            "updatedBy",
        );

    if (auditUserId) {
        document.updatedBy =
            auditUserId;
    }

    try {
        await document.save({
            /*
             * Existing installations can contain unrelated legacy fields.
             * Validate only what the current update modifies while still
             * enforcing every validator for those changed fields.
             */
            validateModifiedOnly:
                true,
        });

        return serializeDocument(
            document,
            normalizedType,
        );
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                {
                    label,
                    operation:
                        "updating the setting",
                },
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* STATUS                                                                     */
/* -------------------------------------------------------------------------- */

export async function setCommonSettingStatus(
    type,
    id,
    status,
    {
        userId = null,
    } = {},
) {
    const {
        Model,
        label,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    const objectId =
        ensureObjectId(id);

    const normalizedStatus =
        normalizeBoolean(
            status,
            "status",
        );

    if (
        normalizedStatus ===
        undefined
    ) {
        throw new CommonSettingsServiceError(
            "Status is required.",
            {
                code:
                    "COMMON_SETTING_STATUS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const document =
        await Model.findById(
            objectId,
        );

    if (!document) {
        throw new CommonSettingsServiceError(
            `${label} not found.`,
            {
                code:
                    "COMMON_SETTING_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    document.status =
        normalizedStatus;

    const auditUserId =
        normalizeAuditUserId(
            userId,
            "updatedBy",
        );

    if (auditUserId) {
        document.updatedBy =
            auditUserId;
    }

    try {
        await document.save({
            validateModifiedOnly:
                true,
        });
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                {
                    label,
                    operation:
                        "updating status",
                },
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    return serializeDocument(
        document,
        normalizedType,
    );
}

/* -------------------------------------------------------------------------- */
/* DELETE                                                                     */
/* -------------------------------------------------------------------------- */

export async function deleteCommonSetting(
    type,
    id,
    {
        userId = null,
    } = {},
) {
    const {
        Model,
        label,
        type: normalizedType,
    } = getTypeConfig(
        type,
    );

    const objectId =
        ensureObjectId(id);

    const document =
        await Model.findById(
            objectId,
        );

    if (!document) {
        throw new CommonSettingsServiceError(
            `${label} not found.`,
            {
                code:
                    "COMMON_SETTING_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    if (
        normalizedType ===
            SETTING_TYPES.TERMS_CONDITION &&
        document.status === true
    ) {
        const activeCount =
            await Model.countDocuments(
                {
                    status: true,
                    _id: {
                        $ne:
                            objectId,
                    },
                },
            );

        if (
            activeCount === 0
        ) {
            throw new CommonSettingsServiceError(
                "The active Terms & Conditions record cannot be deleted until another active record is available.",
                {
                    code:
                        "FINAL_ACTIVE_TERMS_DELETE_FORBIDDEN",
                    statusCode: 409,
                },
            );
        }
    }

    /*
     * Keep the current API's DELETE semantics. Referenced settings should
     * be protected by domain validation in the consuming module before
     * deletion is exposed there.
     */
    try {
        await Model.deleteOne({
            _id: objectId,
        });
    } catch (error) {
        const normalizedError =
            normalizePersistenceError(
                error,
                {
                    label,
                    operation:
                        "deleting the setting",
                },
            );

        if (
            normalizedError !==
            error
        ) {
            throw normalizedError;
        }

        throw error;
    }

    return {
        id:
            objectId.toString(),

        type:
            normalizedType,

        deleted:
            true,

        deletedBy:
            userId
                ? String(
                      userId,
                  )
                : null,
    };
}

/* -------------------------------------------------------------------------- */
/* Convenience Methods                                                        */
/* -------------------------------------------------------------------------- */

/**
 * Return all active units.
 */
export async function listActiveUnits() {
    const documents =
        typeof Unit.findActive ===
        "function"
            ? await Unit.findActive()
            : await Unit.find({
                  status: true,
              }).sort({
                  sortOrder: 1,
                  name: 1,
              });

    return documents.map(
        (document) =>
            serializeDocument(
                document,
                SETTING_TYPES.UNIT,
            ),
    );
}

/**
 * Return all active validity periods.
 */
export async function listActiveValidityPeriods() {
    const documents =
        typeof ValidityPeriod.findActive ===
        "function"
            ? await ValidityPeriod.findActive()
            : await ValidityPeriod.find({
                  status: true,
              }).sort({
                  sortOrder: 1,
                  name: 1,
              });

    return documents.map(
        (document) =>
            serializeDocument(
                document,
                SETTING_TYPES.VALIDITY_PERIOD,
            ),
    );
}

/**
 * Return the active Terms & Conditions.
 */
export async function getActiveTermsCondition() {
    let document;

    if (
        typeof TermsCondition.findPrimaryActive ===
        "function"
    ) {
        document =
            await TermsCondition.findPrimaryActive();
    } else {
        document =
            await TermsCondition.findOne({
                status: true,
            }).sort({
                sortOrder: 1,
                createdAt: -1,
            });
    }

    if (!document) {
        return null;
    }

    return serializeDocument(
        document,
        SETTING_TYPES.TERMS_CONDITION,
    );
}

/* -------------------------------------------------------------------------- */
/* Service Object                                                             */
/* -------------------------------------------------------------------------- */

const commonSettingsService = {
    list:
        listCommonSettings,

    get:
        getCommonSetting,

    create:
        createCommonSetting,

    update:
        updateCommonSetting,

    setStatus:
        setCommonSettingStatus,

    delete:
        deleteCommonSetting,

    listActiveUnits,

    listActiveValidityPeriods,

    getActiveTermsCondition,
};

export default commonSettingsService;