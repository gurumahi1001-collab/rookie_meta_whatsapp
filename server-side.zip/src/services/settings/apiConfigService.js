// src/services/settings/apiConfigService.js

import mongoose from "mongoose";
import ApiConfiguration from "../../models/ApiConfiguration.js";

/* -------------------------------------------------------------------------- */
/* Constants                                                                  */
/* -------------------------------------------------------------------------- */

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 25;
const MAX_LIMIT = 100;

const SORT_FIELDS = Object.freeze({
    name: "name",
    label: "name",
    code: "code",
    active: "active",
    createdAt: "createdAt",
    updatedAt: "updatedAt",
    sortOrder: "sortOrder",
});

const ALLOWED_CREATE_FIELDS = Object.freeze([
    "label",
    "key",
    "description",
    "code",
    "baseUrl",
    "active",
]);

const ALLOWED_UPDATE_FIELDS = Object.freeze([
    "label",
    "key",
    "description",
    "code",
    "baseUrl",
    "active",
]);

/* -------------------------------------------------------------------------- */
/* Error                                                                      */
/* -------------------------------------------------------------------------- */

export class ApiConfigServiceError extends Error {
    constructor(
        message,
        {
            code = "API_CONFIGURATION_ERROR",
            statusCode = 400,
            details = undefined,
            cause = undefined,
        } = {},
    ) {
        super(message);

        this.name = "ApiConfigServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;

        if (cause) {
            this.cause = cause;
        }

        Error.captureStackTrace?.(
            this,
            ApiConfigServiceError,
        );
    }
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function normalizeString(value) {
    if (
        value === undefined ||
        value === null
    ) {
        return "";
    }

    return String(value).trim();
}

function normalizeOptionalString(value) {
    const normalized =
        normalizeString(value);

    return normalized || null;
}

function normalizeBoolean(
    value,
    fieldName,
) {
    if (
        typeof value ===
        "boolean"
    ) {
        return value;
    }

    if (
        value ===
            undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    if (
        value === true ||
        value === 1 ||
        value === "1" ||
        String(value)
            .trim()
            .toLowerCase() ===
            "true"
    ) {
        return true;
    }

    if (
        value === false ||
        value === 0 ||
        value === "0" ||
        String(value)
            .trim()
            .toLowerCase() ===
            "false"
    ) {
        return false;
    }

    throw new ApiConfigServiceError(
        `${fieldName} must be true or false.`,
        {
            code:
                "INVALID_BOOLEAN_VALUE",
            statusCode: 422,
            details: {
                field: fieldName,
            },
        },
    );
}

function normalizePage(
    value,
) {
    const page =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(
            page,
        ) ||
        page < 1
    ) {
        return DEFAULT_PAGE;
    }

    return page;
}

function normalizeLimit(
    value,
) {
    const limit =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(
            limit,
        ) ||
        limit < 1
    ) {
        return DEFAULT_LIMIT;
    }

    return Math.min(
        MAX_LIMIT,
        limit,
    );
}

function normalizeSort(
    sort,
) {
    const requested =
        normalizeString(sort)
            .toLowerCase();

    if (
        requested &&
        SORT_FIELDS[
            requested
        ]
    ) {
        return SORT_FIELDS[
            requested
        ];
    }

    return "sortOrder";
}

function normalizeSortOrder(
    sortOrder,
) {
    const normalized =
        normalizeString(
            sortOrder,
        ).toLowerCase();

    return normalized === "desc"
        ? -1
        : 1;
}

function ensureObjectId(
    id,
) {
    const normalized =
        normalizeString(id);

    if (
        !mongoose.Types.ObjectId.isValid(
            normalized,
        )
    ) {
        throw new ApiConfigServiceError(
            "Invalid API configuration ID.",
            {
                code:
                    "INVALID_API_CONFIGURATION_ID",
                statusCode: 400,
            },
        );
    }

    return new mongoose.Types.ObjectId(
        normalized,
    );
}

function assertPlainObject(
    payload,
    message,
) {
    if (
        !payload ||
        typeof payload !==
            "object" ||
        Array.isArray(payload)
    ) {
        throw new ApiConfigServiceError(
            message,
            {
                code:
                    "INVALID_API_CONFIGURATION_PAYLOAD",
                statusCode: 400,
            },
        );
    }
}

function rejectUnknownFields(
    payload,
    allowedFields,
) {
    const receivedFields =
        Object.keys(
            payload,
        );

    const allowed =
        new Set(
            allowedFields,
        );

    const unknownFields =
        receivedFields.filter(
            (field) =>
                !allowed.has(
                    field,
                ),
        );

    if (
        unknownFields.length
    ) {
        throw new ApiConfigServiceError(
            "API configuration contains unsupported fields.",
            {
                code:
                    "UNSUPPORTED_API_CONFIGURATION_FIELDS",
                statusCode: 400,
                details: {
                    fields:
                        unknownFields,
                },
            },
        );
    }
}

function buildKeyMask(
    keyLast4 = "",
) {
    if (!keyLast4) {
        return "••••••••••••";
    }

    return `••••••••••••${keyLast4}`;
}

function serializeConfiguration(
    document,
) {
    if (!document) {
        return null;
    }

    /*
     * toSafeJSON() is the preferred model-level serializer.
     */
    if (
        typeof document.toSafeJSON ===
        "function"
    ) {
        const serialized =
            document.toSafeJSON();

        return {
            ...serialized,

            /*
             * Keep the current frontend contract.
             */
            id:
                serialized.id ||
                document._id?.toString(),

            label:
                serialized.label ||
                serialized.name ||
                document.name,

            key:
                serialized.key ||
                buildKeyMask(
                    serialized.keyLast4 ||
                        document.keyLast4 ||
                        "",
                ),

            description:
                serialized.description ||
                "",

            active:
                serialized.active ??
                false,
        };
    }

    const source =
        typeof document.toObject ===
        "function"
            ? document.toObject({
                  depopulate: true,
              })
            : document;

    return {
        id:
            source._id?.toString(),

        label:
            source.name || "",

        code:
            source.code || null,

        baseUrl:
            source.baseUrl || null,

        key:
            buildKeyMask(
                source.keyLast4 ||
                    "",
            ),

        keyLast4:
            source.keyLast4 || "",

        description:
            source.description || "",

        active:
            source.active === true,

        system:
            source.system === true,

        sortOrder:
            source.sortOrder || 0,

        keyUpdatedAt:
            source.keyUpdatedAt ||
            null,

        createdAt:
            source.createdAt ||
            null,

        updatedAt:
            source.updatedAt ||
            null,
    };
}

function buildCreatePayload(
    payload,
) {
    assertPlainObject(
        payload,
        "API configuration payload must be an object.",
    );

    rejectUnknownFields(
        payload,
        ALLOWED_CREATE_FIELDS,
    );

    const label =
        normalizeString(
            payload.label,
        );

    if (!label) {
        throw new ApiConfigServiceError(
            "API label is required.",
            {
                code:
                    "API_LABEL_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        label.length < 2 ||
        label.length > 150
    ) {
        throw new ApiConfigServiceError(
            "API label must contain between 2 and 150 characters.",
            {
                code:
                    "INVALID_API_LABEL",
                statusCode: 422,
            },
        );
    }

    const key =
        normalizeString(
            payload.key,
        );

    if (!key) {
        throw new ApiConfigServiceError(
            "API key is required.",
            {
                code:
                    "API_KEY_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        key.length > 4000
    ) {
        throw new ApiConfigServiceError(
            "API key cannot exceed 4000 characters.",
            {
                code:
                    "INVALID_API_KEY",
                statusCode: 422,
            },
        );
    }

    const description =
        normalizeString(
            payload.description,
        );

    if (
        description.length >
        1000
    ) {
        throw new ApiConfigServiceError(
            "Description cannot exceed 1000 characters.",
            {
                code:
                    "INVALID_API_DESCRIPTION",
                statusCode: 422,
            },
        );
    }

    const codeValue =
        normalizeOptionalString(
            payload.code,
        );

    if (
        codeValue &&
        codeValue.length > 100
    ) {
        throw new ApiConfigServiceError(
            "API code cannot exceed 100 characters.",
            {
                code:
                    "INVALID_API_CODE",
                statusCode: 422,
            },
        );
    }

    const baseUrl =
        normalizeOptionalString(
            payload.baseUrl,
        );

    if (
        baseUrl &&
        baseUrl.length > 1000
    ) {
        throw new ApiConfigServiceError(
            "Base URL cannot exceed 1000 characters.",
            {
                code:
                    "INVALID_API_BASE_URL",
                statusCode: 422,
            },
        );
    }

    return {
        name: label,

        ...(codeValue !==
        undefined
            ? {
                  code:
                      codeValue,
              }
            : {}),

        ...(baseUrl !==
        undefined
            ? {
                  baseUrl,
              }
            : {}),

        apiKey: key,

        description,

        active:
            normalizeBoolean(
                payload.active,
                "active",
            ) ?? true,
    };
}

function buildUpdatePayload(
    payload,
) {
    assertPlainObject(
        payload,
        "API configuration payload must be an object.",
    );

    rejectUnknownFields(
        payload,
        ALLOWED_UPDATE_FIELDS,
    );

    const update = {};

    /*
     * Label
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "label",
        )
    ) {
        const label =
            normalizeString(
                payload.label,
            );

        if (!label) {
            throw new ApiConfigServiceError(
                "API label is required.",
                {
                    code:
                        "API_LABEL_REQUIRED",
                    statusCode: 422,
                },
            );
        }

        if (
            label.length < 2 ||
            label.length > 150
        ) {
            throw new ApiConfigServiceError(
                "API label must contain between 2 and 150 characters.",
                {
                    code:
                        "INVALID_API_LABEL",
                    statusCode: 422,
                },
            );
        }

        update.name =
            label;
    }

    /*
     * API Key
     *
     * Empty key on edit means:
     *
     *   keep the existing secret
     *
     * This is important because the frontend can display a masked
     * existing key without having access to the original secret.
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "key",
        )
    ) {
        const key =
            normalizeString(
                payload.key,
            );

        if (
            key.length > 4000
        ) {
            throw new ApiConfigServiceError(
                "API key cannot exceed 4000 characters.",
                {
                    code:
                        "INVALID_API_KEY",
                    statusCode: 422,
                },
            );
        }

        if (key) {
            update.apiKey =
                key;
        }
    }

    /*
     * Description
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "description",
        )
    ) {
        const description =
            normalizeString(
                payload.description,
            );

        if (
            description.length >
            1000
        ) {
            throw new ApiConfigServiceError(
                "Description cannot exceed 1000 characters.",
                {
                    code:
                        "INVALID_API_DESCRIPTION",
                    statusCode: 422,
                },
            );
        }

        update.description =
            description;
    }

    /*
     * Stable integration code.
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "code",
        )
    ) {
        const codeValue =
            normalizeOptionalString(
                payload.code,
            );

        if (
            codeValue &&
            codeValue.length > 100
        ) {
            throw new ApiConfigServiceError(
                "API code cannot exceed 100 characters.",
                {
                    code:
                        "INVALID_API_CODE",
                    statusCode: 422,
                },
            );
        }

        update.code =
            codeValue;
    }

    /*
     * Base URL
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "baseUrl",
        )
    ) {
        const baseUrl =
            normalizeOptionalString(
                payload.baseUrl,
            );

        if (
            baseUrl &&
            baseUrl.length > 1000
        ) {
            throw new ApiConfigServiceError(
                "Base URL cannot exceed 1000 characters.",
                {
                    code:
                        "INVALID_API_BASE_URL",
                    statusCode: 422,
                },
            );
        }

        update.baseUrl =
            baseUrl;
    }

    /*
     * Active status.
     */
    if (
        Object.prototype.hasOwnProperty.call(
            payload,
            "active",
        )
    ) {
        update.active =
            normalizeBoolean(
                payload.active,
                "active",
            );
    }

    if (
        Object.keys(
            update,
        ).length === 0
    ) {
        throw new ApiConfigServiceError(
            "No API configuration changes were provided.",
            {
                code:
                    "NO_API_CONFIGURATION_CHANGES",
                statusCode: 422,
            },
        );
    }

    return update;
}

/* -------------------------------------------------------------------------- */
/* List                                                                       */
/* -------------------------------------------------------------------------- */

export async function listApiConfigurations(
    {
        page = DEFAULT_PAGE,
        limit = DEFAULT_LIMIT,
        search = "",
        active,
        sort = "sortOrder",
        sortOrder = "asc",
    } = {},
) {
    const normalizedPage =
        normalizePage(page);

    const normalizedLimit =
        normalizeLimit(limit);

    const normalizedSearch =
        normalizeString(
            search,
        );

    const normalizedSort =
        normalizeSort(sort);

    const normalizedSortOrder =
        normalizeSortOrder(
            sortOrder,
        );

    const filter = {};

    /*
     * Search current frontend-visible label/description.
     *
     * Code is included for backend/admin use.
     */
    if (
        normalizedSearch
    ) {
        const escapedSearch =
            normalizedSearch.replace(
                /[.*+?^${}()|[\]\\]/g,
                "\\$&",
            );

        const regex =
            new RegExp(
                escapedSearch,
                "i",
            );

        filter.$or = [
            {
                name: regex,
            },
            {
                description:
                    regex,
            },
            {
                code: regex,
            },
        ];
    }

    const normalizedActive =
        normalizeBoolean(
            active,
            "active",
        );

    if (
        normalizedActive !==
        undefined
    ) {
        filter.active =
            normalizedActive;
    }

    const skip =
        (normalizedPage - 1) *
        normalizedLimit;

    const sortSpec = {
        [normalizedSort]:
            normalizedSortOrder,

        /*
         * Stable secondary ordering.
         */
        name: 1,
    };

    const [
        documents,
        total,
    ] = await Promise.all([
        ApiConfiguration.find(
            filter,
        )
            .sort(sortSpec)
            .skip(skip)
            .limit(
                normalizedLimit,
            )
            .lean(false),

        ApiConfiguration.countDocuments(
            filter,
        ),
    ]);

    const items =
        documents.map(
            serializeConfiguration,
        );

    return {
        items,

        data:
            items,

        pagination: {
            page:
                normalizedPage,

            limit:
                normalizedLimit,

            total,

            totalPages:
                Math.ceil(
                    total /
                        normalizedLimit,
                ),
        },

        filters: {
            search:
                normalizedSearch,

            active:
                normalizedActive,
        },

        sort: {
            field:
                normalizedSort,

            order:
                normalizedSortOrder ===
                -1
                    ? "desc"
                    : "asc",
        },
    };
}

/* -------------------------------------------------------------------------- */
/* Get                                                                        */
/* -------------------------------------------------------------------------- */

export async function getApiConfiguration(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await ApiConfiguration.findById(
            objectId,
        );

    if (!document) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeConfiguration(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* Get With Secret                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Internal backend use only.
 *
 * This method intentionally returns the actual key.
 *
 * Controllers should NOT call this method for normal frontend GET
 * requests. It exists for future backend integrations that need the
 * configured credential.
 */
export async function getApiConfigurationWithSecret(
    id,
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await ApiConfiguration.findById(
            objectId,
        ).select(
            "+apiKey",
        );

    if (!document) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    if (
        typeof document.toSecretJSON ===
        "function"
    ) {
        return document.toSecretJSON();
    }

    return {
        id:
            document._id.toString(),

        label:
            document.name,

        code:
            document.code ||
            null,

        baseUrl:
            document.baseUrl ||
            null,

        key:
            document.apiKey,

        description:
            document.description ||
            "",

        active:
            document.active === true,
    };
}

/* -------------------------------------------------------------------------- */
/* Create                                                                     */
/* -------------------------------------------------------------------------- */

export async function createApiConfiguration(
    payload,
    {
        userId = null,
    } = {},
) {
    const createData =
        buildCreatePayload(
            payload,
        );

    if (userId) {
        createData.createdBy =
            userId;
        createData.updatedBy =
            userId;
    }

    /*
     * Give automatically created records a stable ordering value.
     */
    if (
        createData.sortOrder ===
        undefined
    ) {
        const latest =
            await ApiConfiguration.findOne(
                {},
            )
                .sort({
                    sortOrder:
                        -1,
                })
                .select(
                    "sortOrder",
                )
                .lean();

        createData.sortOrder =
            Number(
                latest?.sortOrder ||
                    0,
            ) + 1;
    }

    try {
        const document =
            await ApiConfiguration.create(
                createData,
            );

        return serializeConfiguration(
            document,
        );
    } catch (error) {
        if (
            error?.code ===
            11000
        ) {
            throw new ApiConfigServiceError(
                "An API configuration with the same code already exists.",
                {
                    code:
                        "API_CONFIGURATION_DUPLICATE",
                    statusCode: 409,
                    details: {
                        key:
                            error.keyValue ||
                            null,
                    },
                    cause:
                        error,
                },
            );
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* Update                                                                     */
/* -------------------------------------------------------------------------- */

export async function updateApiConfiguration(
    id,
    payload,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const update =
        buildUpdatePayload(
            payload,
        );

    if (userId) {
        update.updatedBy =
            userId;
    }

    /*
     * Do not allow normal update operations to accidentally modify
     * the system flag.
     */
    const existing =
        await ApiConfiguration.findById(
            objectId,
        ).select(
            "+apiKey",
        );

    if (!existing) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * When a system configuration is being modified, the service still
     * allows metadata/credential updates. Destructive protection is
     * handled in delete().
     */

    /*
     * Detect explicit key rotation.
     *
     * The model's validation hook updates keyUpdatedAt.
     */
    try {
        Object.assign(
            existing,
            update,
        );

        await existing.save();

        return serializeConfiguration(
            existing,
        );
    } catch (error) {
        if (
            error?.code ===
            11000
        ) {
            throw new ApiConfigServiceError(
                "An API configuration with the same code already exists.",
                {
                    code:
                        "API_CONFIGURATION_DUPLICATE",
                    statusCode: 409,
                    details: {
                        key:
                            error.keyValue ||
                            null,
                    },
                    cause:
                        error,
                },
            );
        }

        throw error;
    }
}

/* -------------------------------------------------------------------------- */
/* Status                                                                     */
/* -------------------------------------------------------------------------- */

export async function setApiConfigurationStatus(
    id,
    active,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const normalizedActive =
        normalizeBoolean(
            active,
            "active",
        );

    if (
        normalizedActive ===
        undefined
    ) {
        throw new ApiConfigServiceError(
            "Active status is required.",
            {
                code:
                    "API_STATUS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const update = {
        active:
            normalizedActive,
    };

    if (userId) {
        update.updatedBy =
            userId;
    }

    const document =
        await ApiConfiguration.findByIdAndUpdate(
            objectId,
            {
                $set:
                    update,
            },
            {
                new: true,
                runValidators:
                    true,
            },
        );

    if (!document) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    return serializeConfiguration(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* Delete                                                                     */
/* -------------------------------------------------------------------------- */

export async function deleteApiConfiguration(
    id,
    {
        userId = null,
        hardDelete = true,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const document =
        await ApiConfiguration.findById(
            objectId,
        );

    if (!document) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    /*
     * System-managed configurations are intentionally protected from
     * destructive deletion.
     */
    if (
        document.system === true
    ) {
        throw new ApiConfigServiceError(
            "System API configurations cannot be deleted.",
            {
                code:
                    "SYSTEM_API_CONFIGURATION_DELETE_FORBIDDEN",
                statusCode: 403,
            },
        );
    }

    /*
     * The current UI's delete operation means actual removal.
     *
     * hardDelete defaults to true so the existing frontend behavior
     * remains unchanged.
     */
    if (hardDelete) {
        await ApiConfiguration.deleteOne(
            {
                _id: objectId,
            },
        );

        return {
            id:
                document._id.toString(),

            deleted: true,
        };
    }

    /*
     * Optional safe-disable behavior for callers that prefer
     * retaining the record.
     */
    const update = {
        active: false,
    };

    if (userId) {
        update.updatedBy =
            userId;
    }

    document.set(
        update,
    );

    await document.save();

    return {
        ...serializeConfiguration(
            document,
        ),

        deleted: false,

        disabled: true,
    };
}

/* -------------------------------------------------------------------------- */
/* Key Rotation                                                               */
/* -------------------------------------------------------------------------- */

/**
 * Explicit key rotation helper for internal backend callers.
 *
 * It does not return the secret.
 */
export async function rotateApiConfigurationKey(
    id,
    newKey,
    {
        userId = null,
    } = {},
) {
    const objectId =
        ensureObjectId(id);

    const normalizedKey =
        normalizeString(
            newKey,
        );

    if (!normalizedKey) {
        throw new ApiConfigServiceError(
            "New API key is required.",
            {
                code:
                    "NEW_API_KEY_REQUIRED",
                statusCode: 422,
            },
        );
    }

    if (
        normalizedKey.length >
        4000
    ) {
        throw new ApiConfigServiceError(
            "API key cannot exceed 4000 characters.",
            {
                code:
                    "INVALID_API_KEY",
                statusCode: 422,
            },
        );
    }

    const document =
        await ApiConfiguration.findById(
            objectId,
        ).select(
            "+apiKey",
        );

    if (!document) {
        throw new ApiConfigServiceError(
            "API configuration not found.",
            {
                code:
                    "API_CONFIGURATION_NOT_FOUND",
                statusCode: 404,
            },
        );
    }

    document.apiKey =
        normalizedKey;

    if (userId) {
        document.updatedBy =
            userId;
    }

    await document.save();

    return serializeConfiguration(
        document,
    );
}

/* -------------------------------------------------------------------------- */
/* Bulk Status                                                                */
/* -------------------------------------------------------------------------- */

export async function bulkUpdateStatus(
    ids,
    active,
    {
        userId = null,
    } = {},
) {
    if (
        !Array.isArray(ids) ||
        ids.length === 0
    ) {
        throw new ApiConfigServiceError(
            "At least one API configuration ID is required.",
            {
                code:
                    "API_CONFIGURATION_IDS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const normalizedActive =
        normalizeBoolean(
            active,
            "active",
        );

    if (
        normalizedActive ===
        undefined
    ) {
        throw new ApiConfigServiceError(
            "Active status is required.",
            {
                code:
                    "API_STATUS_REQUIRED",
                statusCode: 422,
            },
        );
    }

    const objectIds =
        ids.map(
            ensureObjectId,
        );

    const update = {
        active:
            normalizedActive,
    };

    if (userId) {
        update.updatedBy =
            userId;
    }

    const result =
        await ApiConfiguration.updateMany(
            {
                _id: {
                    $in: objectIds,
                },
            },
            {
                $set:
                    update,
            },
        );

    return {
        matched:
            result.matchedCount ??
            result.n ??
            0,

        modified:
            result.modifiedCount ??
            result.nModified ??
            0,

        active:
            normalizedActive,
    };
}

/* -------------------------------------------------------------------------- */
/* Service Object                                                             */
/* -------------------------------------------------------------------------- */

const apiConfigService = {
    list:
        listApiConfigurations,

    get:
        getApiConfiguration,

    getWithSecret:
        getApiConfigurationWithSecret,

    create:
        createApiConfiguration,

    update:
        updateApiConfiguration,

    setStatus:
        setApiConfigurationStatus,

    delete:
        deleteApiConfiguration,

    rotateKey:
        rotateApiConfigurationKey,

    bulkUpdateStatus:
        bulkUpdateStatus,
};

export default apiConfigService;