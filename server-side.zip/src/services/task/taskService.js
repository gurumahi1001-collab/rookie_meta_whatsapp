export const serviceName = 'taskService';
