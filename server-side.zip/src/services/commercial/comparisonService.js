// Business-logic boundary: comparisonService.js
// Keep HTTP concerns in controllers and perform multi-step writes in PostgreSQL transactions.
export const serviceName = 'comparisonService';
