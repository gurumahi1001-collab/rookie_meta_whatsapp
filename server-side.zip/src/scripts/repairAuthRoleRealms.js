// src/scripts/repairAuthRoleRealms.js

import {
    connectDatabase,
    disconnectDatabase,
} from "../config/database.js";
import Role from "../models/Role.js";

/*
|--------------------------------------------------------------------------
| ARGUS Authentication Role Realm Repair
|--------------------------------------------------------------------------
|
| Admin users authenticate in the "admin" realm.
| Internal users authenticate in the "internal" realm.
|
| System roles such as Workspace Owner / Network Admin are assignable
| to both user types, therefore their role realm must be "both".
|
| This script also repairs custom roles whose allowedUserTypes include
| "admin" but whose realm is still "internal" (a legacy/inconsistent
| configuration that causes ROLE_REALM_MISMATCH at admin login).
|
| Run once against the current MongoDB database:
|
|   npm run db:repair:auth-roles
|
|--------------------------------------------------------------------------
*/

const SYSTEM_CROSS_REALM_KEYS = [
    "workspace_owner",
    "network_admin",
    "field_technician",
    "billing_manager",
];

async function run() {
    await connectDatabase();

    const systemResult =
        await Role.updateMany(
            {
                key: {
                    $in:
                        SYSTEM_CROSS_REALM_KEYS,
                },
            },
            {
                $set: {
                    realm: "both",
                },
            },
        );

    const customResult =
        await Role.updateMany(
            {
                key: {
                    $nin:
                        SYSTEM_CROSS_REALM_KEYS,
                },
                realm: "internal",
                allowedUserTypes:
                    "admin",
            },
            {
                $set: {
                    realm: "both",
                },
            },
        );

    console.info(
        `[AUTH-ROLE-REPAIR] System roles updated: ${systemResult.modifiedCount}`,
    );

    console.info(
        `[AUTH-ROLE-REPAIR] Custom admin-compatible roles updated: ${customResult.modifiedCount}`,
    );
}

try {
    await run();

    console.info(
        "[AUTH-ROLE-REPAIR] Authentication role realm repair completed successfully.",
    );
} catch (error) {
    console.error(
        "[AUTH-ROLE-REPAIR] Repair failed:",
        error,
    );

    process.exitCode = 1;
} finally {
    await disconnectDatabase().catch(
        (error) => {
            console.error(
                "[AUTH-ROLE-REPAIR] Database disconnect failed:",
                error,
            );
        },
    );
}
