import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Rate Category
|--------------------------------------------------------------------------
|
| Existing frontend contract:
|
|   id
|   categoryType
|   category
|   description
|   status
|
| Duplicate rule from the current UI:
|
|   categoryType + category
|
|--------------------------------------------------------------------------
*/

const CATEGORY_TYPES = Object.freeze([
    "Material",
    "Service",
    "Equipment",
]);

const rateCategorySchema = new Schema(
    {
        /*
         * Category Type selected in the existing UI.
         */
        categoryType: {
            type: String,
            required: [
                true,
                "Category type is required.",
            ],
            trim: true,
            enum: {
                values: CATEGORY_TYPES,
                message:
                    "Invalid category type.",
            },
            index: true,
        },

        /*
         * Category name entered in the existing UI.
         *
         * Examples:
         *   Fiber Optic
         *   Civil Works
         *   Installation
         *   Splicing & Testing
         *   Network Equipment
         */
        category: {
            type: String,
            required: [
                true,
                "Category is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 150,
        },

        /*
         * Existing UI requires a description.
         */
        description: {
            type: String,
            required: [
                true,
                "Description is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        /*
         * Existing ToggleSwitch maps directly to this field.
         */
        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        /*
         * Deterministic ordering for future server-driven tables
         * and dropdowns.
         */
        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "rate_categories",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * Core business uniqueness rule:
 *
 * Material + Fiber Optic
 * Material + Civil Works
 * Service + Installation
 *
 * must not produce duplicate records.
 *
 * A simple compound unique index protects against exact duplicates.
 */
rateCategorySchema.index(
    {
        categoryType: 1,
        category: 1,
    },
    {
        unique: true,
        name:
            "rate_categories_type_category_unique",
    },
);

rateCategorySchema.index(
    {
        status: 1,
        sortOrder: 1,
        categoryType: 1,
        category: 1,
    },
    {
        name:
            "rate_categories_status_sort",
    },
);

rateCategorySchema.index(
    {
        categoryType: 1,
        status: 1,
    },
    {
        name:
            "rate_categories_type_status",
    },
);

rateCategorySchema.index(
    {
        category: 1,
        status: 1,
    },
    {
        name:
            "rate_categories_category_status",
    },
);

rateCategorySchema.index(
    {
        createdAt: -1,
    },
    {
        name:
            "rate_categories_created_at",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

rateCategorySchema.pre(
    "validate",
    function rateCategoryValidation() {
        if (
            typeof this.categoryType ===
            "string"
        ) {
            const normalizedType =
                this.categoryType.trim();

            /*
             * Keep the source UI values exactly:
             *
             * Material
             * Service
             * Equipment
             */
            this.categoryType =
                normalizedType;
        }

        if (
            typeof this.category ===
            "string"
        ) {
            this.category =
                this.category.trim();
        }

        if (
            typeof this.description ===
            "string"
        ) {
            this.description =
                this.description.trim();
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

rateCategorySchema.methods.isActive =
    function isActive() {
        return this.status === true;
    };

rateCategorySchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            categoryType:
                this.categoryType,

            category:
                this.category,

            description:
                this.description,

            status:
                this.status === true,

            sortOrder:
                this.sortOrder,

            createdBy:
                this.createdBy
                    ? this.createdBy.toString()
                    : null,

            updatedBy:
                this.updatedBy
                    ? this.updatedBy.toString()
                    : null,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Active categories for master-rate selection.
 */
rateCategorySchema.statics.findActive =
    function findActive() {
        return this.find({
            status: true,
        }).sort({
            sortOrder: 1,
            categoryType: 1,
            category: 1,
        });
    };

/**
 * Find a category using the exact business key.
 */
rateCategorySchema.statics.findByBusinessKey =
    function findByBusinessKey(
        categoryType,
        category,
    ) {
        if (
            typeof categoryType !==
                "string" ||
            typeof category !==
                "string"
        ) {
            return null;
        }

        return this.findOne({
            categoryType:
                categoryType.trim(),

            category:
                category.trim(),
        });
    };

/**
 * Find active category by Mongo ID.
 */
rateCategorySchema.statics.findActiveById =
    function findActiveById(
        id,
    ) {
        return this.findOne({
            _id: id,
            status: true,
        });
    };

/**
 * Return categories for one category type.
 */
rateCategorySchema.statics.findActiveByType =
    function findActiveByType(
        categoryType,
    ) {
        if (
            typeof categoryType !==
                "string" ||
            !categoryType.trim()
        ) {
            return this.find({
                _id: null,
            });
        }

        return this.find({
            categoryType:
                categoryType.trim(),

            status: true,
        }).sort({
            sortOrder: 1,
            category: 1,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

rateCategorySchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

rateCategorySchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const RateCategory =
    models.RateCategory ||
    model(
        "RateCategory",
        rateCategorySchema,
    );

export {
    CATEGORY_TYPES,
    RateCategory,
    rateCategorySchema,
};

export default RateCategory;