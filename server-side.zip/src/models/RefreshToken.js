
import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Refresh Token Schema
|--------------------------------------------------------------------------
|
| Refresh tokens are persisted so ARGUS can:
|
| - revoke individual sessions
| - revoke all sessions for a user
| - rotate refresh tokens
| - detect token reuse
| - expire old sessions automatically
| - support secure logout
|
| The actual refresh token is NEVER stored in plaintext.
| Only its SHA-256 hash is persisted.
|--------------------------------------------------------------------------
*/

const refreshTokenSchema = new Schema(
    {
        /*
         * User who owns this refresh session.
         */
        userId: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: true,
            index: true,
        },

        /*
         * SHA-256 hash of the opaque refresh token.
         *
         * Never store the raw refresh token in MongoDB.
         */
        tokenHash: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
            minlength: 64,
            maxlength: 64,
            match: /^[a-f0-9]{64}$/,
        },

        /*
         * Refresh token expiry.
         */
        expiresAt: {
            type: Date,
            required: true,
            index: true,
        },

        /*
         * Set when this refresh token has been explicitly revoked.
         */
        revokedAt: {
            type: Date,
            default: null,
            index: true,
        },

        /*
         * Token rotation chain.
         *
         * When token A is rotated into token B:
         *
         * token A.replacedBy = token B._id
         */
        replacedBy: {
            type: Schema.Types.ObjectId,
            ref: "RefreshToken",
            default: null,
        },

        /*
         * Session identifier shared by the access token and refresh
         * token issued during the same login session.
         */
        sessionId: {
            type: String,
            required: true,
            index: true,
            trim: true,
            maxlength: 120,
        },

        /*
         * Authentication realm.
         */
        realm: {
            type: String,
            enum: [
                "admin",
                "internal",
                "vendor",
            ],
            required: true,
            index: true,
        },

        /*
         * Optional request/device information.
         *
         * These are operational audit fields, not authentication
         * credentials.
         */
        ipAddress: {
            type: String,
            default: null,
            trim: true,
            maxlength: 120,
        },

        userAgent: {
            type: String,
            default: null,
            trim: true,
            maxlength: 1000,
        },

        /*
         * Token family allows reuse detection.
         *
         * All rotated tokens belonging to one login session share
         * the same tokenFamilyId.
         */
        tokenFamilyId: {
            type: String,
            required: true,
            index: true,
            trim: true,
            maxlength: 120,
        },

        /*
         * Optional security state.
         */
        reusedAt: {
            type: Date,
            default: null,
        },

        /*
         * Timestamps are maintained by Mongoose.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * Fast lookup of active sessions belonging to a user.
 */
refreshTokenSchema.index({
    userId: 1,
    revokedAt: 1,
    expiresAt: 1,
});

/*
 * Fast lookup of a session chain.
 */
refreshTokenSchema.index({
    sessionId: 1,
    createdAt: -1,
});

/*
 * Fast token-family lookup for reuse detection.
 */
refreshTokenSchema.index({
    tokenFamilyId: 1,
    createdAt: -1,
});

/*
 * MongoDB TTL cleanup.
 *
 * Documents are automatically eligible for deletion after
 * expiresAt has passed.
 *
 * IMPORTANT:
 * TTL cleanup is eventual, not an authentication rule.
 * Authentication must still explicitly check expiresAt.
 */
refreshTokenSchema.index(
    {
        expiresAt: 1,
    },
    {
        expireAfterSeconds: 0,
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Whether this refresh token is currently valid.
 *
 * Revocation and expiry are checked independently.
 */
refreshTokenSchema.methods.isUsable =
    function isUsable() {
        if (
            this.revokedAt
        ) {
            return false;
        }

        if (
            this.reusedAt
        ) {
            return false;
        }

        if (
            !this.expiresAt
        ) {
            return false;
        }

        return (
            this.expiresAt.getTime() >
            Date.now()
        );
    };

/**
 * Revoke this token.
 */
refreshTokenSchema.methods.revoke =
    function revoke() {
        if (
            !this.revokedAt
        ) {
            this.revokedAt =
                new Date();
        }
    };

/**
 * Mark this token as reused.
 *
 * Refresh-token reuse should be treated as a security event by
 * authService and should normally trigger revocation of the entire
 * token family.
 */
refreshTokenSchema.methods.markReused =
    function markReused() {
        if (
            !this.reusedAt
        ) {
            this.reusedAt =
                new Date();
        }

        if (
            !this.revokedAt
        ) {
            this.revokedAt =
                new Date();
        }
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find a refresh token by its SHA-256 hash.
 */
refreshTokenSchema.statics.findByHash =
    function findByHash(
        tokenHash,
    ) {
        if (
            typeof tokenHash !==
                "string" ||
            !tokenHash.trim()
        ) {
            return null;
        }

        return this.findOne({
            tokenHash:
                tokenHash
                    .trim()
                    .toLowerCase(),
        });
    };

/**
 * Find an active token by hash.
 *
 * Expiry is checked explicitly rather than relying on TTL deletion.
 */
refreshTokenSchema.statics.findActiveByHash =
    async function findActiveByHash(
        tokenHash,
    ) {
        const token =
            await this.findByHash(
                tokenHash,
            );

        if (
            !token ||
            !token.isUsable()
        ) {
            return null;
        }

        return token;
    };

/**
 * Revoke one session.
 */
refreshTokenSchema.statics.revokeSession =
    async function revokeSession(
        sessionId,
    ) {
        if (
            !sessionId
        ) {
            return {
                modifiedCount: 0,
            };
        }

        return this.updateMany(
            {
                sessionId,
                revokedAt: null,
            },
            {
                $set: {
                    revokedAt:
                        new Date(),
                },
            },
        );
    };

/**
 * Revoke all refresh tokens belonging to one user.
 */
refreshTokenSchema.statics.revokeAllForUser =
    async function revokeAllForUser(
        userId,
    ) {
        if (
            !userId
        ) {
            return {
                modifiedCount: 0,
            };
        }

        return this.updateMany(
            {
                userId,
                revokedAt: null,
            },
            {
                $set: {
                    revokedAt:
                        new Date(),
                },
            },
        );
    };

/**
 * Revoke an entire token family.
 *
 * This is used when refresh-token reuse is detected.
 */
refreshTokenSchema.statics.revokeTokenFamily =
    async function revokeTokenFamily(
        tokenFamilyId,
    ) {
        if (
            !tokenFamilyId
        ) {
            return {
                modifiedCount: 0,
            };
        }

        return this.updateMany(
            {
                tokenFamilyId,
                revokedAt: null,
            },
            {
                $set: {
                    revokedAt:
                        new Date(),
                },
            },
        );
    };

/**
 * Revoke a specific token hash.
 */
refreshTokenSchema.statics.revokeByHash =
    async function revokeByHash(
        tokenHash,
    ) {
        if (
            typeof tokenHash !==
                "string" ||
            !tokenHash.trim()
        ) {
            return {
                modifiedCount: 0,
            };
        }

        return this.updateOne(
            {
                tokenHash:
                    tokenHash
                        .trim()
                        .toLowerCase(),

                revokedAt: null,
            },
            {
                $set: {
                    revokedAt:
                        new Date(),
                },
            },
        );
    };

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const RefreshToken =
    models.RefreshToken ||
    model(
        "RefreshToken",
        refreshTokenSchema,
    );

export default RefreshToken;
export { RefreshToken };