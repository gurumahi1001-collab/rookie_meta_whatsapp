// ARGUS data model contract for Budget.
// SQL is authoritative; service layer owns transaction/query rules.
export const Budget = Object.freeze({ table: 'Budget' });
