// ARGUS data model contract for RFQVendor.
// SQL is authoritative; service layer owns transaction/query rules.
export const RFQVendor = Object.freeze({ table: 'RFQVendor' });
