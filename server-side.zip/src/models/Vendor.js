import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const VENDOR_STATUSES = [
    "PENDING",
    "APPROVED",
    "REJECTED",
    "DEACTIVE",
];

const bankInformationSchema = new Schema(
    {
        bankName: { type: String, trim: true, maxlength: 160, default: "" },
        branch: { type: String, trim: true, maxlength: 160, default: "" },
        accountHolderName: { type: String, trim: true, maxlength: 160, default: "" },
        accountNumber: { type: String, trim: true, maxlength: 80, default: "" },
        ifscCode: { type: String, trim: true, maxlength: 40, default: "" },
        swiftCode: { type: String, trim: true, maxlength: 40, default: "" },
    },
    { _id: false },
);

const contactSchema = new Schema(
    {
        name: { type: String, trim: true, maxlength: 160, default: "" },
        designation: { type: String, trim: true, maxlength: 160, default: "" },
        email: { type: String, trim: true, lowercase: true, maxlength: 320, default: "" },
        phone: { type: String, trim: true, maxlength: 50, default: "" },
        whatsapp: { type: String, trim: true, maxlength: 50, default: "" },
    },
    { _id: false },
);

const vendorSchema = new Schema(
    {
        companyName: {
            type: String,
            required: [true, "Company name is required."],
            trim: true,
            minlength: 2,
            maxlength: 200,
            index: true,
        },
        trn: {
            type: String,
            required: [true, "TRN is required."],
            trim: true,
            uppercase: true,
            maxlength: 80,
            index: true,
        },
        vendorCategory: { type: String, trim: true, maxlength: 120, default: "" },
        industrySector: { type: String, trim: true, maxlength: 120, default: "" },
        accountStatus: {
            type: String,
            enum: VENDOR_STATUSES,
            default: "PENDING",
            index: true,
        },
        contact: { type: contactSchema, default: () => ({}) },
        secondaryContact: { type: contactSchema, default: () => ({}) },
        currency: { type: String, trim: true, uppercase: true, maxlength: 12, default: "" },
        paymentTerms: { type: String, trim: true, maxlength: 120, default: "" },
        creditLimit: { type: String, trim: true, maxlength: 80, default: "" },
        billingAddress: { type: String, trim: true, maxlength: 1000, default: "" },
        siteAddress: { type: String, trim: true, maxlength: 1000, default: "" },
        projectLocations: { type: String, trim: true, maxlength: 2000, default: "" },
        internalNotes: { type: String, trim: true, maxlength: 3000, default: "" },
        bankInformation: { type: bankInformationSchema, default: () => ({}) },
        createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
    },
    {
        collection: "vendors",
        timestamps: true,
        strict: "throw",
        versionKey: false,
    },
);

vendorSchema.index(
    { trn: 1 },
    { unique: true, name: "vendors_trn_unique" },
);

vendorSchema.index({ companyName: 1, accountStatus: 1 });
vendorSchema.index({ createdAt: -1 });

vendorSchema.virtual("initial").get(function initial() {
    return (this.companyName || "?").trim().charAt(0).toUpperCase();
});

vendorSchema.methods.toSafeJSON = function toSafeJSON({ maskBank = false } = {}) {
    const bank = this.bankInformation?.toObject?.() || this.bankInformation || {};
    return {
        id: String(this._id),
        initial: this.initial,
        name: this.companyName,
        tagline: this.industrySector || this.vendorCategory || "",
        trn: this.trn,
        category: this.vendorCategory,
        industrySector: this.industrySector,
        status: this.accountStatus,
        contactName: this.contact?.name || "",
        contactRole: this.contact?.designation || "",
        email: this.contact?.email || "",
        phone: this.contact?.phone || "",
        whatsapp: this.contact?.whatsapp || "",
        locations: this.siteAddress || this.projectLocations || "",
        paymentTerms: this.paymentTerms,
        creditLimit: this.creditLimit,
        currency: this.currency,
        billingAddress: this.billingAddress,
        siteAddress: this.siteAddress,
        projectLocations: this.projectLocations,
        internalNotes: this.internalNotes,
        bankInformation: {
            bankName: bank.bankName || "",
            branch: bank.branch || "",
            accountHolderName: bank.accountHolderName || "",
            accountNumber: maskBank && bank.accountNumber
                ? `****${String(bank.accountNumber).slice(-4)}`
                : bank.accountNumber || "",
            ifscCode: bank.ifscCode || "",
            swiftCode: bank.swiftCode || "",
        },
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
    };
};

vendorSchema.set("toJSON", { virtuals: true });

const Vendor = models.Vendor || model("Vendor", vendorSchema);

export { Vendor, VENDOR_STATUSES, vendorSchema };
export default Vendor;
