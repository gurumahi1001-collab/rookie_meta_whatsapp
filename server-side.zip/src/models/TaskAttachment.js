// ARGUS data model contract for TaskAttachment.
// SQL is authoritative; service layer owns transaction/query rules.
export const TaskAttachment = Object.freeze({ table: 'TaskAttachment' });
