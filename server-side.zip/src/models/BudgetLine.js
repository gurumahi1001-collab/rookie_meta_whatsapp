// ARGUS data model contract for BudgetLine.
// SQL is authoritative; service layer owns transaction/query rules.
export const BudgetLine = Object.freeze({ table: 'BudgetLine' });
