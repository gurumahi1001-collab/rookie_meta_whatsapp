import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Terms & Conditions
|--------------------------------------------------------------------------
|
| Current frontend contract:
|
|   title
|   content
|
| Current Common Settings service contract additionally uses:
|
|   status
|   sortOrder
|
|--------------------------------------------------------------------------
*/

const termsConditionSchema = new Schema(
    {
        /*
         * Display title.
         */
        title: {
            type: String,
            required: [
                true,
                "Terms & Conditions title is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 250,
        },

        /*
         * Rich-text HTML content from the existing RichTextEditor.
         */
        content: {
            type: String,
            required: [
                true,
                "Terms & Conditions content is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 200000,
        },

        /*
         * Common Settings status.
         */
        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        /*
         * Deterministic ordering.
         */
        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit fields.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "terms_conditions",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * Prevent duplicate titles.
 */
termsConditionSchema.index(
    {
        title: 1,
    },
    {
        unique: true,
        name:
            "terms_conditions_title_unique",
    },
);

/*
 * Used when resolving the active/default record.
 */
termsConditionSchema.index(
    {
        status: 1,
        sortOrder: 1,
        createdAt: -1,
    },
    {
        name:
            "terms_conditions_status_sort_created",
    },
);

/*
 * Recent-record ordering.
 */
termsConditionSchema.index(
    {
        createdAt: -1,
    },
    {
        name:
            "terms_conditions_created_at",
    },
);

/*
|--------------------------------------------------------------------------
| Content Validation
|--------------------------------------------------------------------------
*/

function decodeHtmlEntities(
    value,
) {
    return value
        .replace(
            /&nbsp;/gi,
            " ",
        )
        .replace(
            /&amp;/gi,
            "&",
        )
        .replace(
            /&lt;/gi,
            "<",
        )
        .replace(
            /&gt;/gi,
            ">",
        )
        .replace(
            /&quot;/gi,
            '"',
        )
        .replace(
            /&#39;/gi,
            "'",
        );
}

function getPlainText(
    html,
) {
    if (
        typeof html !==
        "string"
    ) {
        return "";
    }

    return decodeHtmlEntities(
        html
            .replace(
                /<script\b[^>]*>[\s\S]*?<\/script>/gi,
                " ",
            )
            .replace(
                /<style\b[^>]*>[\s\S]*?<\/style>/gi,
                " ",
            )
            .replace(
                /<[^>]*>/g,
                " ",
            )
            .replace(
                /\s+/g,
                " ",
            ),
    ).trim();
}

/*
|--------------------------------------------------------------------------
| Normalization / Validation
|--------------------------------------------------------------------------
*/

termsConditionSchema.pre(
    "validate",
    function termsConditionValidation() {
        if (
            typeof this.title ===
            "string"
        ) {
            this.title =
                this.title.trim();
        }

        if (
            typeof this.content ===
            "string"
        ) {
            this.content =
                this.content.trim();
        }

        /*
         * Reject empty rich-text HTML such as:
         *
         *   <p></p>
         *   <p><br></p>
         */
        if (
            !getPlainText(
                this.content,
            )
        ) {
            this.invalidate(
                "content",
                "Terms & Conditions content is required.",
            );
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

termsConditionSchema.methods.isActive =
    function isActive() {
        return this.status === true;
    };

termsConditionSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            title:
                this.title,

            content:
                this.content,

            status:
                this.status === true,

            sortOrder:
                this.sortOrder,

            createdBy:
                this.createdBy
                    ? this.createdBy.toString()
                    : null,

            updatedBy:
                this.updatedBy
                    ? this.updatedBy.toString()
                    : null,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return all active Terms & Conditions.
 */
termsConditionSchema.statics.findActive =
    function findActive() {
        return this.find({
            status: true,
        }).sort({
            sortOrder: 1,
            createdAt: -1,
        });
    };

/**
 * Return the primary active record.
 */
termsConditionSchema.statics.findPrimaryActive =
    function findPrimaryActive() {
        return this.findOne({
            status: true,
        }).sort({
            sortOrder: 1,
            createdAt: -1,
        });
    };

/**
 * Find by title.
 */
termsConditionSchema.statics.findByTitle =
    function findByTitle(
        title,
    ) {
        if (
            typeof title !==
                "string" ||
            !title.trim()
        ) {
            return null;
        }

        return this.findOne({
            title:
                title.trim(),
        });
    };

/**
 * Find active record by Mongo ID.
 */
termsConditionSchema.statics.findActiveById =
    function findActiveById(
        id,
    ) {
        return this.findOne({
            _id: id,
            status: true,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

termsConditionSchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

termsConditionSchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const TermsCondition =
    models.TermsCondition ||
    model(
        "TermsCondition",
        termsConditionSchema,
    );

export {
    TermsCondition,
    termsConditionSchema,
};

export default TermsCondition;