// ARGUS data model contract for QuotationLine.
// SQL is authoritative; service layer owns transaction/query rules.
export const QuotationLine = Object.freeze({ table: 'QuotationLine' });
