// src/models/MarketRateItem.js

import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Constants
|--------------------------------------------------------------------------
*/

const RATE_STATUS = Object.freeze([
    "active",
    "inactive",
]);

/*
|--------------------------------------------------------------------------
| Market Rate Item
|--------------------------------------------------------------------------
|
| Frontend contract from rateSchedule.ts:
|
|   id
|   code
|   rate
|   categoryType
|   category
|   subcategory
|   module
|   description
|   unit
|   standardRate
|   effectiveDate
|   status
|   history
|
| Database adds:
|
|   createdBy
|   updatedBy
|   createdAt
|   updatedAt
|
|--------------------------------------------------------------------------
*/

const marketRateItemSchema =
    new Schema(
        {
            /*
             * Stable business code.
             *
             * Examples:
             *
             *   C-001
             *   F-001
             *   M-003
             *   S-001
             */
            code: {
                type: String,
                required: [
                    true,
                    "Rate code is required.",
                ],
                trim: true,
                uppercase: true,
                minlength: 1,
                maxlength: 50,
            },

            /*
             * Category type from the existing rate schedule UI.
             *
             * IMPORTANT:
             * The uploaded seed data currently uses:
             *
             *   Project Milestone
             *   Material Specifications
             *   Technical Services
             *
             * Therefore these values are intentionally NOT hardcoded
             * as enum values here. Categories are master-configurable.
             */
            categoryType: {
                type: String,
                required: [
                    true,
                    "Category type is required.",
                ],
                trim: true,
                maxlength: 150,
                index: true,
            },

            /*
             * Category.
             */
            category: {
                type: String,
                required: [
                    true,
                    "Category is required.",
                ],
                trim: true,
                maxlength: 150,
                index: true,
            },

            /*
             * Existing UI labels this table column "Module", but
             * rateSchedule.ts calls the field `subcategory`.
             *
             * Preserve `subcategory` as the authoritative field.
             */
            subcategory: {
                type: String,
                required: [
                    true,
                    "Subcategory is required.",
                ],
                trim: true,
                maxlength: 150,
                index: true,
            },

            /*
             * Legacy compatibility field present in the current
             * RateItem TypeScript contract.
             *
             * The current frontend seed initializes it to "".
             *
             * Do not use this as the primary hierarchy field.
             */
            module: {
                type: String,
                trim: true,
                maxlength: 150,
                default: "",
            },

            /*
             * Rate description.
             */
            description: {
                type: String,
                required: [
                    true,
                    "Rate description is required.",
                ],
                trim: true,
                maxlength: 2000,
            },

            /*
             * Unit display value.
             *
             * Existing frontend seed values include:
             *
             *   Meter
             *   SqM
             *   Each
             *   Hour
             *   Day
             *   Km
             *   Site
             */
            unit: {
                type: String,
                required: [
                    true,
                    "Unit is required.",
                ],
                trim: true,
                maxlength: 100,
                index: true,
            },

            /*
             * Authoritative current standard rate.
             */
            standardRate: {
                type: Number,
                required: [
                    true,
                    "Standard rate is required.",
                ],
                min: [
                    0,
                    "Standard rate cannot be negative.",
                ],
            },

            /*
             * Legacy frontend field.
             *
             * The current seed data always sets:
             *
             *   rate: 0
             *
             * while `standardRate` contains the actual value.
             *
             * Preserve it for frontend compatibility but do not treat
             * it as the source of truth for Master Rate calculations.
             */
            rate: {
                type: Number,
                min: [
                    0,
                    "Rate cannot be negative.",
                ],
                default: 0,
            },

            /*
             * Business-effective date.
             */
            effectiveDate: {
                type: Date,
                required: [
                    true,
                    "Effective date is required.",
                ],
                index: true,
            },

            /*
             * Master rate status.
             */
            status: {
                type: String,
                required: true,
                enum: {
                    values:
                        RATE_STATUS,
                    message:
                        "Invalid rate status.",
                },
                default: "active",
                index: true,
            },

            /*
             * Historical rate snapshots.
             *
             * This is retained on the item for efficient retrieval by
             * the existing RateHistoryOffcanvas UI.
             *
             * The normalized backend also has RateHistory as a separate
             * collection. Service code should keep the two representations
             * synchronized when rate changes are made.
             */
            history: {
                type: [
                    {
                        rate: {
                            type: Number,
                            required: true,
                            min: 0,
                        },

                        effectiveDate: {
                            type: Date,
                            required: true,
                        },

                        updatedAt: {
                            type: Date,
                            required: true,
                            default:
                                Date.now,
                        },

                        updatedBy: {
                            type: Schema.Types.ObjectId,
                            ref: "User",
                            default:
                                null,
                        },

                        updatedByName: {
                            type: String,
                            trim: true,
                            maxlength: 150,
                            default: "",
                        },
                    },
                ],
                default: [],
            },

            /*
             * Audit identity.
             */
            createdBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },

            updatedBy: {
                type: Schema.Types.ObjectId,
                ref: "User",
                default: null,
            },
        },
        {
            collection:
                "market_rate_items",
            timestamps: true,
            strict: "throw",
            versionKey: false,
            minimize: false,
        },
    );

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * Master rate code must be unique.
 */
marketRateItemSchema.index(
    {
        code: 1,
    },
    {
        unique: true,
        name:
            "market_rate_items_code_unique",
    },
);

/*
 * Main search/filter index.
 */
marketRateItemSchema.index(
    {
        status: 1,
        categoryType: 1,
        category: 1,
        subcategory: 1,
    },
    {
        name:
            "market_rate_items_status_category_hierarchy",
    },
);

/*
 * Category lookup.
 */
marketRateItemSchema.index(
    {
        category: 1,
        status: 1,
    },
    {
        name:
            "market_rate_items_category_status",
    },
);

/*
 * Effective-date lookup.
 */
marketRateItemSchema.index(
    {
        effectiveDate: -1,
        status: 1,
    },
    {
        name:
            "market_rate_items_effective_status",
    },
);

/*
 * Common listing sort.
 */
marketRateItemSchema.index(
    {
        updatedAt: -1,
    },
    {
        name:
            "market_rate_items_updated_at",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

marketRateItemSchema.pre(
    "validate",
    function marketRateItemValidation() {
        if (
            typeof this.code ===
            "string"
        ) {
            this.code =
                this.code
                    .trim()
                    .toUpperCase();
        }

        if (
            typeof this.categoryType ===
            "string"
        ) {
            this.categoryType =
                this.categoryType.trim();
        }

        if (
            typeof this.category ===
            "string"
        ) {
            this.category =
                this.category.trim();
        }

        if (
            typeof this.subcategory ===
            "string"
        ) {
            this.subcategory =
                this.subcategory.trim();
        }

        if (
            typeof this.module ===
            "string"
        ) {
            this.module =
                this.module.trim();
        }

        if (
            typeof this.description ===
            "string"
        ) {
            this.description =
                this.description.trim();
        }

        if (
            typeof this.unit ===
            "string"
        ) {
            this.unit =
                this.unit.trim();
        }

        /*
         * Current frontend uses standardRate as the actual rate.
         *
         * Keep legacy `rate` synchronized when it is not explicitly
         * provided by a caller.
         */
        if (
            (
                this.rate ===
                    undefined ||
                this.rate ===
                    null ||
                this.rate ===
                    0
            ) &&
            this.standardRate !==
                undefined
        ) {
            this.rate =
                this.standardRate;
        }

        /*
         * Date-only business value.
         */
        if (
            this.effectiveDate
        ) {
            const date =
                new Date(
                    this.effectiveDate,
                );

            if (
                Number.isNaN(
                    date.getTime(),
                )
            ) {
                this.invalidate(
                    "effectiveDate",
                    "Invalid effective date.",
                );
            } else {
                date.setHours(
                    0,
                    0,
                    0,
                    0,
                );

                this.effectiveDate =
                    date;
            }
        }
    },
);

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find active rate by business code.
 */
marketRateItemSchema.statics.findActiveByCode =
    function findActiveByCode(
        code,
    ) {
        if (
            typeof code !==
                "string" ||
            !code.trim()
        ) {
            return null;
        }

        return this.findOne({
            code: code
                .trim()
                .toUpperCase(),
            status: "active",
        });
    };

/**
 * Find by code regardless of status.
 */
marketRateItemSchema.statics.findByCode =
    function findByCode(
        code,
    ) {
        if (
            typeof code !==
                "string" ||
            !code.trim()
        ) {
            return null;
        }

        return this.findOne({
            code: code
                .trim()
                .toUpperCase(),
        });
    };

/**
 * Active master rates for selection.
 */
marketRateItemSchema.statics.findActive =
    function findActive() {
        return this.find({
            status: "active",
        }).sort({
            categoryType: 1,
            category: 1,
            subcategory: 1,
            code: 1,
        });
    };

/**
 * Active rates in one category.
 */
marketRateItemSchema.statics.findActiveByCategory =
    function findActiveByCategory(
        category,
    ) {
        return this.find({
            category:
                category,
            status: "active",
        }).sort({
            subcategory: 1,
            code: 1,
        });
    };

/**
 * Active rates in one category type.
 */
marketRateItemSchema.statics.findActiveByCategoryType =
    function findActiveByCategoryType(
        categoryType,
    ) {
        return this.find({
            categoryType:
                categoryType,
            status: "active",
        }).sort({
            category: 1,
            subcategory: 1,
            code: 1,
        });
    };

/**
 * Find a rate effective on a supplied date.
 *
 * This uses the item's current effectiveDate. Historical lookup should
 * use RateHistory when exact historical reconstruction is needed.
 */
marketRateItemSchema.statics.findEffective =
    function findEffective(
        code,
        date = new Date(),
    ) {
        const effectiveDate =
            new Date(date);

        effectiveDate.setHours(
            23,
            59,
            59,
            999,
        );

        return this.findOne({
            code: String(code)
                .trim()
                .toUpperCase(),

            status: "active",

            effectiveDate: {
                $lte:
                    effectiveDate,
            },
        });
    };

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Whether rate is active.
 */
marketRateItemSchema.methods.isActive =
    function isActive() {
        return this.status ===
            "active";
    };

/**
 * Return date in YYYY-MM-DD form.
 */
marketRateItemSchema.methods.getEffectiveDateISO =
    function getEffectiveDateISO() {
        return formatDateOnly(
            this.effectiveDate,
        );
    };

/**
 * Return latest embedded history entry.
 */
marketRateItemSchema.methods.getCurrentHistoryEntry =
    function getCurrentHistoryEntry() {
        if (
            !Array.isArray(
                this.history,
            ) ||
            this.history.length ===
                0
        ) {
            return null;
        }

        return (
            [...this.history]
                .sort(
                    (
                        a,
                        b,
                    ) =>
                        new Date(
                            b.effectiveDate,
                        ).getTime() -
                        new Date(
                            a.effectiveDate,
                        ).getTime(),
                )
                .at(0) ||
            null
        );
    };

/**
 * Convert to the exact frontend RateItem contract.
 */
marketRateItemSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            code:
                this.code,

            /*
             * Keep compatibility with current UI.
             */
            rate:
                Number(
                    this.rate ??
                        0,
                ),

            categoryType:
                this.categoryType,

            category:
                this.category,

            subcategory:
                this.subcategory,

            module:
                this.module || "",

            description:
                this.description,

            unit:
                this.unit,

            standardRate:
                Number(
                    this.standardRate,
                ),

            effectiveDate:
                formatDateOnly(
                    this.effectiveDate,
                ),

            status:
                this.status,

            history:
                Array.isArray(
                    this.history,
                )
                    ? this.history
                          .slice()
                          .sort(
                              (
                                  a,
                                  b,
                              ) =>
                                  new Date(
                                      b.effectiveDate,
                                  ).getTime() -
                                  new Date(
                                      a.effectiveDate,
                                  ).getTime(),
                          )
                          .map(
                              (
                                  item,
                              ) => ({
                                  rate:
                                      Number(
                                          item.rate,
                                      ),

                                  effectiveDate:
                                      formatDateOnly(
                                          item.effectiveDate,
                                      ),

                                  updatedAt:
                                      item.updatedAt
                                          ? new Date(
                                                item.updatedAt,
                                            ).toISOString()
                                          : "",

                                  updatedBy:
                                      item.updatedByName ||
                                      (
                                          item.updatedBy
                                              ? item.updatedBy.toString()
                                              : ""
                                      ),
                              }),
                          )
                    : [],

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

marketRateItemSchema.set(
    "toJSON",
    {
        transform(
            _doc,
            ret,
        ) {
            const response = {
                id:
                    ret._id
                        ? ret._id.toString()
                        : undefined,

                code:
                    ret.code,

                rate:
                    Number(
                        ret.rate ??
                            0,
                    ),

                categoryType:
                    ret.categoryType,

                category:
                    ret.category,

                subcategory:
                    ret.subcategory,

                module:
                    ret.module || "",

                description:
                    ret.description,

                unit:
                    ret.unit,

                standardRate:
                    Number(
                        ret.standardRate,
                    ),

                effectiveDate:
                    formatDateOnly(
                        ret.effectiveDate,
                    ),

                status:
                    ret.status,

                history:
                    Array.isArray(
                        ret.history,
                    )
                        ? ret.history
                              .slice()
                              .sort(
                                  (
                                      a,
                                      b,
                                  ) =>
                                      new Date(
                                          b.effectiveDate,
                                      ).getTime() -
                                      new Date(
                                          a.effectiveDate,
                                      ).getTime(),
                              )
                              .map(
                                  (
                                      item,
                                  ) => ({
                                      rate:
                                          Number(
                                              item.rate,
                                          ),

                                      effectiveDate:
                                          formatDateOnly(
                                              item.effectiveDate,
                                          ),

                                      updatedAt:
                                          item.updatedAt
                                              ? new Date(
                                                    item.updatedAt,
                                                ).toISOString()
                                              : "",

                                      updatedBy:
                                          item.updatedByName ||
                                          (
                                              item.updatedBy
                                                  ? item.updatedBy.toString()
                                                  : ""
                                          ),
                                  }),
                              )
                        : [],

                createdAt:
                    ret.createdAt,

                updatedAt:
                    ret.updatedAt,
            };

            return response;
        },
    },
);

marketRateItemSchema.set(
    "toObject",
    {
        transform(
            _doc,
            ret,
        ) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function formatDateOnly(
    value,
) {
    if (!value) {
        return "";
    }

    const date =
        value instanceof Date
            ? value
            : new Date(value);

    if (
        Number.isNaN(
            date.getTime(),
        )
    ) {
        return "";
    }

    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1,
        ).padStart(
            2,
            "0",
        );

    const day =
        String(
            date.getDate(),
        ).padStart(
            2,
            "0",
        );

    return `${year}-${month}-${day}`;
}

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const MarketRateItem =
    models.MarketRateItem ||
    model(
        "MarketRateItem",
        marketRateItemSchema,
    );

export {
    RATE_STATUS,
    MarketRateItem,
    marketRateItemSchema,
};

export default MarketRateItem;