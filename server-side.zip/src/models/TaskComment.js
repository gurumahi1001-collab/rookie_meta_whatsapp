// ARGUS data model contract for TaskComment.
// SQL is authoritative; service layer owns transaction/query rules.
export const TaskComment = Object.freeze({ table: 'TaskComment' });
