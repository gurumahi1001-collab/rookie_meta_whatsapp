// ARGUS data model contract for BOQ.
// SQL is authoritative; service layer owns transaction/query rules.
export const BOQ = Object.freeze({ table: 'BOQ' });
