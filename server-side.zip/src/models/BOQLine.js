// ARGUS data model contract for BOQLine.
// SQL is authoritative; service layer owns transaction/query rules.
export const BOQLine = Object.freeze({ table: 'BOQLine' });
