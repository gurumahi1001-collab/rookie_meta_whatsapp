import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Unit
|--------------------------------------------------------------------------
|
| Common master setting used across:
|
| - BOQ
| - Master Rate
| - Quotation
| - Project quantities
| - Invoice quantities
|
| Frontend contract:
|
|   id
|   name
|   description
|   status
|
|--------------------------------------------------------------------------
*/

const unitSchema = new Schema(
    {
        /*
         * Human-readable unit name.
         *
         * Examples:
         *   Meter
         *   SqM
         *   Each
         *   Hour
         *   Day
         *   Km
         *   Site
         */
        name: {
            type: String,
            required: [
                true,
                "Unit name is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 100,
        },

        /*
         * Description shown in the existing Unit Settings UI.
         */
        description: {
            type: String,
            required: [
                true,
                "Unit description is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        /*
         * Existing frontend calls this field `status`
         * and uses a boolean toggle.
         */
        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        /*
         * Stable display/order sequence.
         *
         * The current UI does not expose this field, but keeping the
         * order server-side avoids depending on Mongo insertion order.
         */
        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "units",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

/*
 * Unit names must be unique from a business perspective.
 *
 * Case-insensitive uniqueness is enforced at service level as well,
 * while this index protects exact duplicate values at database level.
 */
unitSchema.index(
    {
        name: 1,
    },
    {
        unique: true,
        name: "units_name_unique",
    },
);

unitSchema.index(
    {
        status: 1,
        sortOrder: 1,
        name: 1,
    },
    {
        name: "units_status_sort_name",
    },
);

unitSchema.index(
    {
        createdAt: -1,
    },
    {
        name: "units_created_at",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

unitSchema.pre(
    "validate",
    function unitValidation() {
        if (typeof this.name === "string") {
            this.name =
                this.name
                    .trim();
        }

        if (
            typeof this.description ===
            "string"
        ) {
            this.description =
                this.description.trim();
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Whether the unit is currently available for selection.
 */
unitSchema.methods.isActive =
    function isActive() {
        return this.status === true;
    };

/**
 * Safe API representation matching the existing frontend.
 */
unitSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            name:
                this.name,

            description:
                this.description,

            status:
                this.status === true,

            sortOrder:
                this.sortOrder,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Find active units for dropdowns and master-data selection.
 */
unitSchema.statics.findActive =
    function findActive() {
        return this.find({
            status: true,
        }).sort({
            sortOrder: 1,
            name: 1,
        });
    };

/**
 * Find by exact normalized name.
 *
 * Useful before create/update to provide a clean duplicate error.
 */
unitSchema.statics.findByNormalizedName =
    function findByNormalizedName(
        name,
    ) {
        if (
            typeof name !== "string" ||
            !name.trim()
        ) {
            return null;
        }

        return this.findOne({
            name:
                name.trim(),
        });
    };

/**
 * Find an active unit by Mongo ID.
 */
unitSchema.statics.findActiveById =
    function findActiveById(
        id,
    ) {
        return this.findOne({
            _id: id,
            status: true,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

unitSchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

unitSchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const Unit =
    models.Unit ||
    model(
        "Unit",
        unitSchema,
    );

export {
    Unit,
    unitSchema,
};

export default Unit;