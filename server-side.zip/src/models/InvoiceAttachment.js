// ARGUS data model contract for InvoiceAttachment.
// SQL is authoritative; service layer owns transaction/query rules.
export const InvoiceAttachment = Object.freeze({ table: 'InvoiceAttachment' });
