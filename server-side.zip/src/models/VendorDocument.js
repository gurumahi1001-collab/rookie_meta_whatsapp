// ARGUS data model contract for VendorDocument.
// SQL is authoritative; service layer owns transaction/query rules.
export const VendorDocument = Object.freeze({ table: 'VendorDocument' });
