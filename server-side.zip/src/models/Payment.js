// ARGUS data model contract for Payment.
// SQL is authoritative; service layer owns transaction/query rules.
export const Payment = Object.freeze({ table: 'Payment' });
