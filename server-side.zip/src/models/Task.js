// ARGUS data model contract for Task.
// SQL is authoritative; service layer owns transaction/query rules.
export const Task = Object.freeze({ table: 'Task' });
