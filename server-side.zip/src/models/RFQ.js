// ARGUS data model contract for RFQ.
// SQL is authoritative; service layer owns transaction/query rules.
export const RFQ = Object.freeze({ table: 'RFQ' });
