import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

/*
|--------------------------------------------------------------------------
| Validity Period
|--------------------------------------------------------------------------
|
| Existing frontend contract:
|
|   id
|   name
|   description
|   status
|
| The current UI uses this master setting for quotation / offer
| validity periods.
|
|--------------------------------------------------------------------------
*/

const validityPeriodSchema = new Schema(
    {
        /*
         * Display name.
         *
         * Examples from the existing frontend:
         *
         *   15 Calendar Days
         *   30 Calendar Days
         *   60 Calendar Days
         *   90 Calendar Days
         */
        name: {
            type: String,
            required: [
                true,
                "Validity period is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 150,
        },

        /*
         * Description displayed by the existing UI.
         */
        description: {
            type: String,
            required: [
                true,
                "Description is required.",
            ],
            trim: true,
            minlength: 1,
            maxlength: 1000,
        },

        /*
         * Existing UI uses a boolean status toggle.
         */
        status: {
            type: Boolean,
            required: true,
            default: true,
            index: true,
        },

        /*
         * Stable ordering for the settings table and future
         * quotation dropdowns.
         */
        sortOrder: {
            type: Number,
            required: true,
            default: 0,
            min: 0,
            index: true,
        },

        /*
         * Audit identity.
         */
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "validity_periods",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

validityPeriodSchema.index(
    {
        name: 1,
    },
    {
        unique: true,
        name: "validity_periods_name_unique",
    },
);

validityPeriodSchema.index(
    {
        status: 1,
        sortOrder: 1,
        name: 1,
    },
    {
        name: "validity_periods_status_sort_name",
    },
);

validityPeriodSchema.index(
    {
        createdAt: -1,
    },
    {
        name: "validity_periods_created_at",
    },
);

/*
|--------------------------------------------------------------------------
| Validation / Normalization
|--------------------------------------------------------------------------
*/

validityPeriodSchema.pre(
    "validate",
    function validityPeriodValidation() {
        if (
            typeof this.name ===
            "string"
        ) {
            this.name =
                this.name.trim();
        }

        if (
            typeof this.description ===
            "string"
        ) {
            this.description =
                this.description.trim();
        }
    },
);

/*
|--------------------------------------------------------------------------
| Instance Helpers
|--------------------------------------------------------------------------
*/

/**
 * Whether this validity period can currently be selected.
 */
validityPeriodSchema.methods.isActive =
    function isActive() {
        return this.status === true;
    };

/**
 * Safe frontend representation.
 */
validityPeriodSchema.methods.toSafeJSON =
    function toSafeJSON() {
        return {
            id:
                this._id?.toString(),

            name:
                this.name,

            description:
                this.description,

            status:
                this.status === true,

            sortOrder:
                this.sortOrder,

            createdAt:
                this.createdAt,

            updatedAt:
                this.updatedAt,
        };
    };

/*
|--------------------------------------------------------------------------
| Static Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return all active validity periods in deterministic order.
 */
validityPeriodSchema.statics.findActive =
    function findActive() {
        return this.find({
            status: true,
        }).sort({
            sortOrder: 1,
            name: 1,
        });
    };

/**
 * Find a validity period by exact normalized name.
 */
validityPeriodSchema.statics.findByNormalizedName =
    function findByNormalizedName(
        name,
    ) {
        if (
            typeof name !==
                "string" ||
            !name.trim()
        ) {
            return null;
        }

        return this.findOne({
            name:
                name.trim(),
        });
    };

/**
 * Find active validity period by id.
 */
validityPeriodSchema.statics.findActiveById =
    function findActiveById(
        id,
    ) {
        return this.findOne({
            _id: id,
            status: true,
        });
    };

/*
|--------------------------------------------------------------------------
| JSON Serialization
|--------------------------------------------------------------------------
*/

validityPeriodSchema.set(
    "toJSON",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

validityPeriodSchema.set(
    "toObject",
    {
        transform(_doc, ret) {
            if (ret._id) {
                ret.id =
                    ret._id.toString();
            }

            delete ret._id;

            return ret;
        },
    },
);

/*
|--------------------------------------------------------------------------
| Model
|--------------------------------------------------------------------------
*/

const ValidityPeriod =
    models.ValidityPeriod ||
    model(
        "ValidityPeriod",
        validityPeriodSchema,
    );

export {
    ValidityPeriod,
    validityPeriodSchema,
};

export default ValidityPeriod;