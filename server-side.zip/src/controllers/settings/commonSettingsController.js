import {
  listCommonSettings,
  getCommonSetting,
  createCommonSetting,
  updateCommonSetting,
  setCommonSettingStatus,
  deleteCommonSetting,
  CommonSettingsServiceError,
} from "../../services/settings/commonSettingsService.js";

/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function getAuthenticatedUserId(req) {
  return (
    req.user?.id ||
    req.user?._id ||
    req.user?.userId ||
    null
  );
}

function requireAuthenticatedUser(req) {
  const userId =
    getAuthenticatedUserId(req);

  if (!userId) {
    throw new CommonSettingsServiceError(
      "Authentication is required.",
      {
        code:
          "AUTHENTICATION_REQUIRED",
        statusCode: 401,
      },
    );
  }

  return userId;
}

function getQueryValue(
  value,
  fallback = "",
) {
  if (
    value === undefined ||
    value === null
  ) {
    return fallback;
  }

  if (Array.isArray(value)) {
    return String(
      value[0] ?? fallback,
    ).trim();
  }

  return String(value).trim();
}

const SUPPORTED_SETTING_TYPES =
  new Set([
    "unit",
    "validity_period",
    "terms_condition",
  ]);

function normalizeSettingType(
  value,
) {
  const type =
    getQueryValue(
      value,
    ).toLowerCase();

  if (
    !SUPPORTED_SETTING_TYPES.has(
      type,
    )
  ) {
    throw new CommonSettingsServiceError(
      "A valid common setting type is required.",
      {
        code:
          "INVALID_COMMON_SETTING_TYPE",
        statusCode: 400,
        details: {
          supportedTypes:
            Array.from(
              SUPPORTED_SETTING_TYPES,
            ),
        },
      },
    );
  }

  return type;
}

function getBooleanQuery(
  value,
) {
  if (
    value === undefined ||
    value === null ||
    value === ""
  ) {
    return undefined;
  }

  if (
    typeof value === "boolean"
  ) {
    return value;
  }

  const normalized =
    String(value)
      .trim()
      .toLowerCase();

  if (
    normalized === "true" ||
    normalized === "1"
  ) {
    return true;
  }

  if (
    normalized === "false" ||
    normalized === "0"
  ) {
    return false;
  }

  return value;
}


function requireId(
  value,
) {
  const id =
    getQueryValue(
      value,
    );

  if (!id) {
    throw new CommonSettingsServiceError(
      "Common setting ID is required.",
      {
        code:
          "COMMON_SETTING_ID_REQUIRED",
        statusCode: 400,
      },
    );
  }

  return id;
}

/*
|--------------------------------------------------------------------------
| Error response
|--------------------------------------------------------------------------
*/

function sendError(
  res,
  error,
) {
  if (
    error instanceof
    CommonSettingsServiceError
  ) {
    return res
      .status(
        error.statusCode || 400,
      )
      .json({
        success: false,

        message:
          error.message,

        code:
          error.code,

        ...(error.details
          ? {
              details:
                error.details,
            }
          : {}),
      });
  }

  /*
   * Mongoose validation.
   */
  if (
    error?.name ===
    "ValidationError"
  ) {
    const fields = {};

    for (
      const [
        field,
        fieldError,
      ] of Object.entries(
        error.errors || {},
      )
    ) {
      fields[field] =
        fieldError.message;
    }

    return res
      .status(422)
      .json({
        success: false,

        message:
          "Common setting validation failed.",

        code:
          "VALIDATION_ERROR",

        fields,
      });
  }

  /*
   * Invalid Mongo ObjectId.
   */
  if (
    error?.name ===
      "CastError" &&
    error?.kind === "ObjectId"
  ) {
    return res
      .status(400)
      .json({
        success: false,

        message:
          "Invalid common setting ID.",

        code:
          "INVALID_COMMON_SETTING_ID",
      });
  }

  /*
   * Duplicate key.
   */
  if (
    error?.code === 11000
  ) {
    return res
      .status(409)
      .json({
        success: false,

        message:
          "A common setting with the same value already exists.",

        code:
          "COMMON_SETTING_DUPLICATE",
      });
  }

  /*
   * Do not expose database/internal implementation details.
   */
  /*
   * Log the full error server-side. Never send stack traces, Mongo details,
   * query contents, or secrets to the browser.
   */
  console.error(
    "[commonSettingsController] Internal error",
    {
      name:
        error?.name,
      message:
        error?.message,
      code:
        error?.code,
      stack:
        error?.stack,
    },
  );

  return res
    .status(500)
    .json({
      success: false,

      message:
        "An unexpected error occurred while processing the common setting.",

      code:
        "INTERNAL_SERVER_ERROR",
    });
}

/* -------------------------------------------------------------------------- */
/* LIST                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/common?type=unit
 * GET /api/v1/settings/common?type=validity_period
 * GET /api/v1/settings/common?type=terms_condition
 */
export async function list(
  req,
  res,
) {
  try {
    requireAuthenticatedUser(
      req,
    );

    const type =
      normalizeSettingType(
        req.query?.type,
      );

    const result =
      await listCommonSettings({
        type,

        page:
          getQueryValue(
            req.query?.page,
            "1",
          ),

        limit:
          getQueryValue(
            req.query?.limit,
            "50",
          ),

        search:
          getQueryValue(
            req.query?.search,
            "",
          ),

        status:
          getBooleanQuery(
            req.query?.status,
          ),
      });

    return res
      .status(200)
      .json({
        success: true,

        message:
          "Common settings retrieved successfully.",

        data:
          result.items,

        pagination:
          result.pagination,

        filters:
          result.filters,

        type:
          result.type,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* GET                                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/common/:id?type=unit
 */
export async function get(
  req,
  res,
) {
  try {
    requireAuthenticatedUser(
      req,
    );

    const type =
      normalizeSettingType(
        req.query?.type,
      );

    const id =
      requireId(
        req.params?.id,
      );

    const result =
      await getCommonSetting(
        type,
        id,
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "Common setting retrieved successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* CREATE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/settings/common?type=unit
 *
 * Unit payload:
 * {
 *   "name": "Meter",
 *   "description": "Measurement in meters"
 * }
 *
 * Validity Period payload:
 * {
 *   "name": "30 Calendar Days",
 *   "description": "Quotation validity"
 * }
 *
 * Terms & Condition payload:
 * {
 *   "title": "Standard Terms",
 *   "content": "<p>...</p>"
 * }
 */
export async function create(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const type =
      normalizeSettingType(
        req.query?.type ||
          req.body?.type,
      );

    /*
     * `type` is a routing concern and is not passed to the model
     * payload.
     */
    const payload = {
      ...(req.body || {}),
    };

    delete payload.type;

    const result =
      await createCommonSetting(
        type,
        payload,
        {
          userId,
        },
      );

    return res
      .status(201)
      .json({
        success: true,

        message:
          "Common setting created successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* UPDATE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/settings/common/:id?type=unit
 */
export async function update(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const type =
      normalizeSettingType(
        req.query?.type ||
          req.body?.type,
      );

    const id =
      requireId(
        req.params?.id,
      );

    const payload = {
      ...(req.body || {}),
    };

    delete payload.type;

    const result =
      await updateCommonSetting(
        type,
        id,
        payload,
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "Common setting updated successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* STATUS                                                                     */
/* -------------------------------------------------------------------------- */

/*
 * The current uploaded route file does not expose a dedicated
 * `/status` route for common settings.
 *
 * This handler is therefore provided for future route reuse and for
 * controller-level completeness, but it does not alter the existing
 * route contract.
 *
 * Supported body:
 *
 * {
 *   "status": true
 * }
 *
 * or:
 *
 * {
 *   "active": true
 * }
 */
export async function setStatus(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const type =
      normalizeSettingType(
        req.query?.type ||
          req.body?.type,
      );

    const id =
      requireId(
        req.params?.id,
      );

    let status =
      req.body?.status;

    if (
      status ===
      undefined
    ) {
      status =
        req.body?.active;
    }

    const result =
      await setCommonSettingStatus(
        type,
        id,
        status,
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          status === true ||
          status === "true" ||
          status === 1 ||
          status === "1"
            ? "Common setting enabled successfully."
            : "Common setting disabled successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* DELETE                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /api/v1/settings/common/:id?type=unit
 */
export async function remove(
  req,
  res,
) {
  try {
    const userId =
      requireAuthenticatedUser(
        req,
      );

    const type =
      normalizeSettingType(
        req.query?.type ||
          req.body?.type,
      );

    const id =
      requireId(
        req.params?.id,
      );

    const result =
      await deleteCommonSetting(
        type,
        id,
        {
          userId,
        },
      );

    return res
      .status(200)
      .json({
        success: true,

        message:
          "Common setting deleted successfully.",

        data:
          result,
      });
  } catch (error) {
    return sendError(
      res,
      error,
    );
  }
}

/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

const commonSettingsController = {
  list,

  get,

  create,

  update,

  setStatus,

  remove,
};

export default commonSettingsController;