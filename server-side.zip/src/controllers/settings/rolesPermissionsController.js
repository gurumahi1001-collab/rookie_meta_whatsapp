// src/controllers/settings/rolesPermissionsController.js

import rolesPermissionsService, {
    RolesPermissionsServiceError,
} from "../../services/settings/rolesPermissionsService.js";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getAuthenticatedUserId(req) {
    return (
        req?.user?.id ||
        req?.user?.userId ||
        req?.user?._id ||
        null
    );
}

function getQueryValue(
    value,
) {
    if (
        Array.isArray(value)
    ) {
        return value[0];
    }

    return value;
}

function parseOptionalBoolean(
    value,
) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    if (
        typeof value ===
        "boolean"
    ) {
        return value;
    }

    const normalized =
        String(value)
            .trim()
            .toLowerCase();

    if (
        normalized ===
            "true" ||
        normalized === "1"
    ) {
        return true;
    }

    if (
        normalized ===
            "false" ||
        normalized === "0"
    ) {
        return false;
    }

    return undefined;
}

function parsePositiveInteger(
    value,
    fallback,
) {
    const parsed =
        Number.parseInt(
            String(value ?? ""),
            10,
        );

    if (
        !Number.isFinite(
            parsed,
        ) ||
        parsed <= 0
    ) {
        return fallback;
    }

    return parsed;
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = "Request completed successfully.",
        data = null,
    } = {},
) {
    return res.status(
        statusCode,
    ).json({
        success: true,
        message,
        data,
    });
}

function sendError(
    res,
    error,
) {
    if (
        error instanceof
        RolesPermissionsServiceError
    ) {
        return res
            .status(
                error.statusCode ||
                    400,
            )
            .json({
                success: false,

                message:
                    error.message,

                code:
                    error.code,

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Mongo duplicate key
    |--------------------------------------------------------------------------
    */

    if (
        error?.code === 11000
    ) {
        const duplicateField =
            Object.keys(
                error.keyPattern ||
                    {},
            )[0] ||
            "value";

        return res
            .status(409)
            .json({
                success: false,

                message:
                    `A record with the same ${duplicateField} already exists.`,

                code:
                    "DUPLICATE_RECORD",
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Mongoose validation
    |--------------------------------------------------------------------------
    */

    if (
        error?.name ===
        "ValidationError"
    ) {
        const fields =
            {};

        for (const [
            field,
            detail,
        ] of Object.entries(
            error.errors || {},
        )) {
            fields[field] =
                detail.message;
        }

        return res
            .status(422)
            .json({
                success: false,

                message:
                    "Validation failed.",

                code:
                    "VALIDATION_ERROR",

                details: {
                    fields,
                },
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Invalid ObjectId / Cast
    |--------------------------------------------------------------------------
    */

    if (
        error?.name ===
        "CastError"
    ) {
        return res
            .status(422)
            .json({
                success: false,

                message:
                    "One or more supplied identifiers are invalid.",

                code:
                    "INVALID_IDENTIFIER",
            });
    }

    /*
    |--------------------------------------------------------------------------
    | Unexpected server error
    |--------------------------------------------------------------------------
    */

    console.error(
        "[RolesPermissionsController]",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "Unable to process the roles and permissions request.",

            code:
                "INTERNAL_SERVER_ERROR",
        });
}

/*
|--------------------------------------------------------------------------
| GET /roles
|--------------------------------------------------------------------------
|
| List roles with optional:
|
| search
| active
| realm
| userType
| page
| limit
|
|--------------------------------------------------------------------------
*/

export const list = async (
    req,
    res,
) => {
    try {
        const query =
            req.query || {};

        const result =
            await rolesPermissionsService.listRoles(
                {
                    search:
                        getQueryValue(
                            query.search,
                        ) || "",

                    active:
                        parseOptionalBoolean(
                            getQueryValue(
                                query.active,
                            ),
                        ),

                    realm:
                        getQueryValue(
                            query.realm,
                        ),

                    userType:
                        getQueryValue(
                            query.userType,
                        ),

                    page:
                        parsePositiveInteger(
                            getQueryValue(
                                query.page,
                            ),
                            1,
                        ),

                    limit:
                        Math.min(
                            100,
                            parsePositiveInteger(
                                getQueryValue(
                                    query.limit,
                                ),
                                50,
                            ),
                        ),
                },
            );

        return sendSuccess(
            res,
            {
                message:
                    "Roles loaded successfully.",

                data:
                    result,
            },
        );
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
};

/*
|--------------------------------------------------------------------------
| GET /roles/:roleId
|--------------------------------------------------------------------------
|
| Returns:
|
| {
|   role,
|   permissions
| }
|
|--------------------------------------------------------------------------
*/

export const get = async (
    req,
    res,
) => {
    try {
        const roleId =
            req.params?.roleId;

        const result =
            await rolesPermissionsService.getRole(
                roleId,
            );

        return sendSuccess(
            res,
            {
                message:
                    "Role loaded successfully.",

                data:
                    result,
            },
        );
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
};

/*
|--------------------------------------------------------------------------
| GET /permissions
|--------------------------------------------------------------------------
|
| Permission/module catalog used by the matrix UI.
|
|--------------------------------------------------------------------------
*/

export const permissions =
    async (
        req,
        res,
    ) => {
        try {
            const query =
                req.query ||
                {};

            const result =
                await rolesPermissionsService.listPermissions(
                    {
                        search:
                            getQueryValue(
                                query.search,
                            ) || "",

                        category:
                            getQueryValue(
                                query.category,
                            ),

                        active:
                            parseOptionalBoolean(
                                getQueryValue(
                                    query.active,
                                ),
                            ) ??
                            true,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Permissions loaded successfully.",

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| GET /roles/:roleId/permissions
|--------------------------------------------------------------------------
|
| Full matrix for one role.
|
|--------------------------------------------------------------------------
*/

export const matrix =
    async (
        req,
        res,
    ) => {
        try {
            const roleId =
                req.params?.roleId;

            const result =
                await rolesPermissionsService.getRolePermissionMatrix(
                    roleId,
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Role permissions loaded successfully.",

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| POST /roles
|--------------------------------------------------------------------------
|
| Create a custom role.
|
|--------------------------------------------------------------------------
*/

export const create =
    async (
        req,
        res,
    ) => {
        try {
            const body =
                req.body || {};

            const userId =
                getAuthenticatedUserId(
                    req,
                );

            const role =
                await rolesPermissionsService.createRole(
                    {
                        name:
                            body.name,

                        key:
                            body.key,

                        description:
                            body.description,

                        realm:
                            body.realm,

                        allowedUserTypes:
                            body.allowedUserTypes,

                        sortOrder:
                            body.sortOrder,

                        createdBy:
                            userId,
                    },
                );

            return sendSuccess(
                res,
                {
                    statusCode:
                        201,

                    message:
                        "Role created successfully.",

                    data:
                        role,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| PATCH /roles/:roleId
|--------------------------------------------------------------------------
|
| Update role metadata.
|
|--------------------------------------------------------------------------
*/

export const update =
    async (
        req,
        res,
    ) => {
        try {
            const roleId =
                req.params?.roleId;

            const body =
                req.body || {};

            const userId =
                getAuthenticatedUserId(
                    req,
                );

            const role =
                await rolesPermissionsService.updateRole(
                    {
                        roleId,

                        name:
                            body.name,

                        key:
                            body.key,

                        description:
                            body.description,

                        realm:
                            body.realm,

                        allowedUserTypes:
                            body.allowedUserTypes,

                        sortOrder:
                            body.sortOrder,

                        active:
                            body.active,

                        updatedBy:
                            userId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Role updated successfully.",

                    data:
                        role,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| DELETE /roles/:roleId
|--------------------------------------------------------------------------
|
| Soft-delete/deactivate a custom role.
|
|--------------------------------------------------------------------------
*/

export const remove =
    async (
        req,
        res,
    ) => {
        try {
            const roleId =
                req.params?.roleId;

            const result =
                await rolesPermissionsService.deleteRole(
                    {
                        roleId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Role removed successfully.",

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| PUT /roles/:roleId/permissions
|--------------------------------------------------------------------------
|
| Replace complete permission matrix.
|
| Expected body:
|
| {
|   "assignments": [
|     {
|       "permissionId": "...",
|       "actions": {
|         "view": true,
|         "add": false,
|         "edit": true,
|         "delete": false
|       }
|     }
|   ]
| }
|
|--------------------------------------------------------------------------
*/

export const replacePermissions =
    async (
        req,
        res,
    ) => {
        try {
            const roleId =
                req.params?.roleId;

            const body =
                req.body || {};

            const userId =
                getAuthenticatedUserId(
                    req,
                );

            const result =
                await rolesPermissionsService.replaceRolePermissions(
                    {
                        roleId,

                        assignments:
                            body.assignments ??
                            body.permissions ??
                            [],

                        updatedBy:
                            userId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Role permissions saved successfully.",

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| PATCH /roles/:roleId/permissions/:permissionId
|--------------------------------------------------------------------------
|
| Update one permission assignment.
|
| Expected body:
|
| {
|   "actions": {
|     "view": true,
|     "add": true,
|     "edit": false,
|     "delete": false
|   }
| }
|
|--------------------------------------------------------------------------
*/

export const updatePermission =
    async (
        req,
        res,
    ) => {
        try {
            const roleId =
                req.params?.roleId;

            const permissionId =
                req.params?.permissionId;

            const body =
                req.body || {};

            const userId =
                getAuthenticatedUserId(
                    req,
                );

            const result =
                await rolesPermissionsService.updateRolePermission(
                    {
                        roleId,

                        permissionId,

                        actions:
                            body.actions ??
                            body,

                        updatedBy:
                            userId,
                    },
                );

            return sendSuccess(
                res,
                {
                    message:
                        "Permission updated successfully.",

                    data:
                        result,
                },
            );
        } catch (error) {
            return sendError(
                res,
                error,
            );
        }
    };

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

export default {
    list,
    get,
    permissions,
    matrix,
    create,
    update,
    remove,
    replacePermissions,
    updatePermission,
};