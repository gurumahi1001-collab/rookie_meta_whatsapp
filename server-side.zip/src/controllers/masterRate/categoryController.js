// src/controllers/masterRate/categoryController.js

import {
    listCategories,
    getCategory,
    createCategory,
    updateCategory,
    setCategoryStatus,
    deleteCategory,
    bulkUpdateStatus,
    listActiveCategories,
    listCategoryTypes,
    CategoryServiceError,
} from "../../services/masterRate/categoryService.js";

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getAuthenticatedUserId(req) {
    return (
        req.user?.id ||
        req.user?._id ||
        req.user?.userId ||
        null
    );
}

function requireAuthenticatedUser(req) {
    const userId =
        getAuthenticatedUserId(req);

    if (!userId) {
        throw new CategoryServiceError(
            "Authentication is required.",
            {
                code:
                    "AUTHENTICATION_REQUIRED",
                statusCode: 401,
            },
        );
    }

    return String(userId).trim();
}

function getQueryValue(
    value,
    fallback = "",
) {
    if (
        value === undefined ||
        value === null
    ) {
        return fallback;
    }

    if (Array.isArray(value)) {
        return String(
            value[0] ?? fallback,
        ).trim();
    }

    return String(value).trim();
}

function parseBoolean(
    value,
) {
    if (
        value === undefined ||
        value === null ||
        value === ""
    ) {
        return undefined;
    }

    if (
        typeof value === "boolean"
    ) {
        return value;
    }

    const normalized =
        String(value)
            .trim()
            .toLowerCase();

    if (
        normalized === "true" ||
        normalized === "1"
    ) {
        return true;
    }

    if (
        normalized === "false" ||
        normalized === "0"
    ) {
        return false;
    }

    throw new CategoryServiceError(
        "Status must be true or false.",
        {
            code:
                "INVALID_BOOLEAN_VALUE",
            statusCode: 422,
            details: {
                field: "status",
            },
        },
    );
}

function parseIds(
    value,
) {
    if (
        Array.isArray(value)
    ) {
        return value
            .map((id) =>
                String(id).trim(),
            )
            .filter(Boolean);
    }

    if (
        typeof value === "string"
    ) {
        return value
            .split(",")
            .map((id) => id.trim())
            .filter(Boolean);
    }

    return [];
}

function requireCategoryId(
    req,
) {
    const id =
        getQueryValue(
            req.params?.id,
        );

    if (!id) {
        throw new CategoryServiceError(
            "Category ID is required.",
            {
                code:
                    "CATEGORY_ID_REQUIRED",
                statusCode: 400,
            },
        );
    }

    return id;
}

/*
|--------------------------------------------------------------------------
| Error Handler
|--------------------------------------------------------------------------
*/

function sendError(
    res,
    error,
) {
    if (
        error instanceof
        CategoryServiceError
    ) {
        return res
            .status(
                error.statusCode || 400,
            )
            .json({
                success: false,

                message:
                    error.message,

                code:
                    error.code,

                ...(error.details
                    ? {
                          details:
                              error.details,
                      }
                    : {}),
            });
    }

    if (
        error?.name ===
        "ValidationError"
    ) {
        const fields = {};

        Object.entries(
            error.errors || {},
        ).forEach(
            ([
                field,
                fieldError,
            ]) => {
                fields[field] =
                    fieldError.message;
            },
        );

        return res
            .status(422)
            .json({
                success: false,

                message:
                    "Category validation failed.",

                code:
                    "VALIDATION_ERROR",

                fields,
            });
    }

    if (
        error?.name ===
        "CastError"
    ) {
        return res
            .status(400)
            .json({
                success: false,

                message:
                    "Invalid category ID.",

                code:
                    "INVALID_CATEGORY_ID",
            });
    }

    if (
        error?.code === 11000
    ) {
        return res
            .status(409)
            .json({
                success: false,

                message:
                    "This category already exists under the selected category type.",

                code:
                    "CATEGORY_DUPLICATE",
            });
    }

    console.error(
        "[categoryController]",
        error,
    );

    return res
        .status(500)
        .json({
            success: false,

            message:
                "An unexpected error occurred while processing the category.",

            code:
                "INTERNAL_SERVER_ERROR",
        });
}

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
|
| GET /master-rate/categories
|
| Query:
|
| ?page=1
| ?limit=25
| ?search=fiber
| ?categoryType=Material
| ?status=true
| ?sort=category
| ?sortOrder=asc
|
|--------------------------------------------------------------------------
*/

export async function list(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await listCategories({
                page:
                    getQueryValue(
                        req.query?.page,
                        "1",
                    ),

                limit:
                    getQueryValue(
                        req.query?.limit,
                        "25",
                    ),

                search:
                    getQueryValue(
                        req.query?.search,
                        "",
                    ),

                categoryType:
                    getQueryValue(
                        req.query
                            ?.categoryType,
                        "",
                    ),

                status:
                    parseBoolean(
                        req.query?.status,
                    ),

                sort:
                    getQueryValue(
                        req.query?.sort,
                        "sortOrder",
                    ),

                sortOrder:
                    getQueryValue(
                        req.query
                            ?.sortOrder,
                        "asc",
                    ),
            });

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate categories retrieved successfully.",

                data:
                    result.items,

                pagination:
                    result.pagination,

                filters:
                    result.filters,

                sort:
                    result.sort,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| GET
|--------------------------------------------------------------------------
|
| GET /master-rate/categories/:id
|
|--------------------------------------------------------------------------
*/

export async function get(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const result =
            await getCategory(
                requireCategoryId(req),
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate category retrieved successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| CREATE
|--------------------------------------------------------------------------
|
| POST /master-rate/categories
|
| Body:
|
| {
|   categoryType: "Material",
|   category: "Fiber Optic",
|   description: "Fiber optic material",
|   status: true
| }
|
|--------------------------------------------------------------------------
*/

export async function create(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const result =
            await createCategory(
                req.body || {},
                {
                    userId,
                },
            );

        return res
            .status(201)
            .json({
                success: true,

                message:
                    "Rate category created successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
|
| PATCH /master-rate/categories/:id
|
|--------------------------------------------------------------------------
*/

export async function update(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const result =
            await updateCategory(
                requireCategoryId(req),
                req.body || {},
                {
                    userId,
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate category updated successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
|
| PATCH /master-rate/categories/:id/status
|
| Body:
|
| {
|   status: true
| }
|
| Compatibility:
|
| {
|   active: true
| }
|
|--------------------------------------------------------------------------
*/

export async function setStatus(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        let status =
            req.body?.status;

        if (
            status ===
            undefined
        ) {
            status =
                req.body?.active;
        }

        const result =
            await setCategoryStatus(
                requireCategoryId(req),
                status,
                {
                    userId,
                },
            );

        const enabled =
            status === true ||
            status === "true" ||
            status === 1 ||
            status === "1";

        return res
            .status(200)
            .json({
                success: true,

                message:
                    enabled
                        ? "Rate category enabled successfully."
                        : "Rate category disabled successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| DELETE
|--------------------------------------------------------------------------
|
| DELETE /master-rate/categories/:id
|
|--------------------------------------------------------------------------
*/

export async function remove(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const result =
            await deleteCategory(
                req.params?.id,
                {
                    userId,
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate category deleted successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| BULK STATUS
|--------------------------------------------------------------------------
|
| PATCH /master-rate/categories/bulk-status
|
| Body:
|
| {
|   ids: ["...", "..."],
|   status: true
| }
|
|--------------------------------------------------------------------------
*/

export async function bulkStatus(
    req,
    res,
) {
    try {
        const userId =
            requireAuthenticatedUser(
                req,
            );

        const ids =
            parseIds(
                req.body?.ids,
            );

        let status =
            req.body?.status;

        if (
            status ===
            undefined
        ) {
            status =
                req.body?.active;
        }

        const result =
            await bulkUpdateStatus(
                ids,
                status,
                {
                    userId,
                },
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Rate category statuses updated successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| ACTIVE
|--------------------------------------------------------------------------
|
| GET /master-rate/categories/active
|
| Optional:
|
| ?categoryType=Material
|
|--------------------------------------------------------------------------
*/

export async function active(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        const categoryType =
            getQueryValue(
                req.query
                    ?.categoryType,
                "",
            );

        const result =
            await listActiveCategories(
                categoryType ||
                    null,
            );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Active rate categories retrieved successfully.",

                data:
                    result,
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| TYPES
|--------------------------------------------------------------------------
|
| GET /master-rate/categories/types
|
|--------------------------------------------------------------------------
*/

export async function types(
    req,
    res,
) {
    try {
        requireAuthenticatedUser(
            req,
        );

        return res
            .status(200)
            .json({
                success: true,

                message:
                    "Category types retrieved successfully.",

                data:
                    listCategoryTypes(),
            });
    } catch (error) {
        return sendError(
            res,
            error,
        );
    }
}

/*
|--------------------------------------------------------------------------
| Export
|--------------------------------------------------------------------------
*/

const categoryController = {
    list,

    get,

    create,

    update,

    setStatus,

    remove,

    bulkStatus,

    active,

    types,
};

export default categoryController;