// src/controllers/audit/auditLogController.js

import auditService, {
    AuditServiceError,
} from '../../services/audit/auditService.js';


/* -------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function queryValue(value) {
    if (Array.isArray(value)) {
        return value[0];
    }

    return value;
}

function sendSuccess(
    res,
    {
        statusCode = 200,
        message = 'Request completed successfully.',
        data = null,
        meta = null,
    } = {},
) {
    return res.status(statusCode).json({
        success: true,
        message,
        data,
        ...(meta && typeof meta === 'object' ? meta : {}),
    });
}

function sendError(res, error) {
    if (error instanceof AuditServiceError) {
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message,
            code: error.code,
            ...(error.details
                ? { details: error.details }
                : {}),
        });
    }

    if (error?.name === 'ValidationError') {
        const fields = {};

        for (const [field, detail] of Object.entries(error.errors || {})) {
            fields[field] = detail?.message || 'Invalid value.';
        }

        return res.status(422).json({
            success: false,
            message: 'Validation failed.',
            code: 'VALIDATION_ERROR',
            details: { fields },
        });
    }

    if (error?.name === 'CastError') {
        return res.status(422).json({
            success: false,
            message: 'One or more supplied identifiers are invalid.',
            code: 'INVALID_IDENTIFIER',
        });
    }

    console.error('[AuditLogController]', error);

    return res.status(500).json({
        success: false,
        message: 'Unable to process the audit log request.',
        code: 'INTERNAL_SERVER_ERROR',
    });
}

function buildListOptions(req) {
    return {
        page: queryValue(req.query?.page),
        limit: queryValue(req.query?.limit),
        search: queryValue(req.query?.search),
        action: queryValue(req.query?.action),
        module: queryValue(req.query?.module),
        actorType: queryValue(
            req.query?.actorType ?? req.query?.userType,
        ),
        entityType: queryValue(req.query?.entityType),
        entityId: queryValue(req.query?.entityId),
        actorUserId: queryValue(
            req.query?.actorUserId ?? req.query?.userId,
        ),
        vendorId: queryValue(req.query?.vendorId),
        status: queryValue(req.query?.status),
        fromDate: queryValue(
            req.query?.fromDate ?? req.query?.startDate,
        ),
        toDate: queryValue(
            req.query?.toDate ?? req.query?.endDate,
        ),
    };
}


/* -------------------------------------------------------------------------- */
/* GET /audit                                                                 */
/* -------------------------------------------------------------------------- */

export async function list(req, res) {
    try {
        const result = await auditService.listAuditLogs(
            buildListOptions(req),
        );

        return sendSuccess(res, {
            data: result.items,
            message: 'Audit logs retrieved successfully.',
            meta: {
                pagination: result.pagination,
                filters: result.filters,
            },
        });
    } catch (error) {
        return sendError(res, error);
    }
}


/* -------------------------------------------------------------------------- */
/* GET /audit/:id                                                             */
/* -------------------------------------------------------------------------- */

export async function get(req, res) {
    try {
        const id = queryValue(req.params?.id);

        if (!id || typeof id !== 'string' || !id.trim()) {
            return res.status(422).json({
                success: false,
                message: 'Audit log id is required.',
                code: 'AUDIT_ID_REQUIRED',
            });
        }

        const data = await auditService.getAuditLogById(id.trim());

        return sendSuccess(res, {
            data,
            message: 'Audit log entry retrieved successfully.',
        });
    } catch (error) {
        return sendError(res, error);
    }
}


/* -------------------------------------------------------------------------- */
/* POST /audit                                                                */
/*                                                                            */
/* Audit records are normally created by trusted application services, not    */
/* directly by browser clients. This endpoint is therefore intentionally not */
/* exposed by the production audit router.                                   */
/* -------------------------------------------------------------------------- */

export async function create(_req, res) {
    return res.status(405).json({
        success: false,
        message: 'Audit events are created internally by application services.',
        code: 'AUDIT_WRITE_NOT_ALLOWED',
    });
}


/* -------------------------------------------------------------------------- */
/* PUT/PATCH /audit/:id                                                       */
/*                                                                            */
/* Audit records are immutable.                                               */
/* -------------------------------------------------------------------------- */

export async function update(_req, res) {
    return res.status(409).json({
        success: false,
        message: 'Audit log records are immutable and cannot be updated.',
        code: 'AUDIT_IMMUTABLE',
    });
}


/* -------------------------------------------------------------------------- */
/* DELETE /audit/:id                                                          */
/*                                                                            */
/* Audit records are immutable and deletion is intentionally unavailable.     */
/* -------------------------------------------------------------------------- */

export async function remove(_req, res) {
    return res.status(409).json({
        success: false,
        message: 'Audit log records are immutable and cannot be deleted.',
        code: 'AUDIT_IMMUTABLE',
    });
}


export default {
    list,
    get,
    create,
    update,
    remove,
};
