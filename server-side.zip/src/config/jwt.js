import jwt from 'jsonwebtoken';
import { env } from './env.js';

export const signAccessToken = (payload) => jwt.sign(payload, env.jwt.accessSecret, { expiresIn: env.jwt.accessExpiresIn, issuer: 'argus-api' });
export const signRefreshToken = (payload) => jwt.sign(payload, env.jwt.refreshSecret, { expiresIn: env.jwt.refreshExpiresIn, issuer: 'argus-api' });
export const verifyAccessToken = (token) => jwt.verify(token, env.jwt.accessSecret, { issuer: 'argus-api' });
export const verifyRefreshToken = (token) => jwt.verify(token, env.jwt.refreshSecret, { issuer: 'argus-api' });
