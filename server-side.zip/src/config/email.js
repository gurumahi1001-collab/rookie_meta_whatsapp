import nodemailer from 'nodemailer';
import { env } from './env.js';

export const mailer = env.smtp.host ? nodemailer.createTransport({ host: env.smtp.host, port: env.smtp.port, secure: env.smtp.secure, auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.password } : undefined }) : null;
