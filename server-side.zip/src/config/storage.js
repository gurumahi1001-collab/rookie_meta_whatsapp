import path from 'node:path';
import { env } from './env.js';

export const storageRoot = path.resolve(env.storage.root);
export const storagePaths = {
  vendors: 'vendors', quotations: 'quotations', tasks: 'tasks', invoices: 'invoices', payments: 'payments',
  company: 'company', users: 'users', surveys: 'surveys', exports: 'exports', temp: 'temp'
};
