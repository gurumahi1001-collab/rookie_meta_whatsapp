// import pg from 'pg';
// import { env } from './env.js';
// import { logger } from '../utils/logger.js';

// const { Pool } = pg;
// export const pool = new Pool({
//   host: env.db.host, port: env.db.port, database: env.db.database, user: env.db.user, password: env.db.password,
//   max: env.db.max, idleTimeoutMillis: env.db.idleTimeoutMillis, connectionTimeoutMillis: env.db.connectionTimeoutMillis
// });

// pool.on('error', (err) => logger.error('Unexpected PostgreSQL pool error', { error: err.message }));

// export const query = (text, params) => pool.query(text, params);
// export const withTransaction = async (callback) => {
//   const client = await pool.connect();
//   try { await client.query('BEGIN'); const result = await callback(client); await client.query('COMMIT'); return result; }
//   catch (error) { await client.query('ROLLBACK'); throw error; }
//   finally { client.release(); }
// };


// src/config/database.js
// src/config/database.js

import mongoose from 'mongoose';
import env from './env.js';

/**
 * ARGUS MongoDB Database Configuration
 *
 * Responsibilities:
 * - Establish MongoDB connection
 * - Configure Mongoose connection pool
 * - Handle connection lifecycle events
 * - Provide database health checks
 * - Gracefully close the database
 * - Prevent commands from being silently buffered
 *
 * MongoDB is the only database used by ARGUS.
 */


/* -------------------------------------------------------------------------- */
/* Mongoose configuration                                                     */
/* -------------------------------------------------------------------------- */

const mongooseOptions = {
  appName: env.app.name,

  dbName: env.database.name,

  serverSelectionTimeoutMS:
    env.database.serverSelectionTimeoutMs,

  socketTimeoutMS:
    env.database.socketTimeoutMs,

  minPoolSize:
    env.database.minPoolSize,

  maxPoolSize:
    env.database.maxPoolSize,

  maxIdleTimeMS:
    env.database.maxIdleTimeMs,

  retryWrites:
    env.database.retryWrites,

  /**
   * Do not silently queue operations when the
   * database is unavailable.
   *
   * This allows application health/status handling
   * to detect database outages immediately.
   */
  bufferCommands: false,
};


/* -------------------------------------------------------------------------- */
/* Internal state                                                             */
/* -------------------------------------------------------------------------- */

let connectionPromise = null;


/* -------------------------------------------------------------------------- */
/* Connection state                                                           */
/* -------------------------------------------------------------------------- */

/**
 * Mongoose readyState values:
 *
 * 0 = disconnected
 * 1 = connected
 * 2 = connecting
 * 3 = disconnecting
 */

export function getConnectionState() {
  const state =
    mongoose.connection.readyState;

  switch (state) {
    case 0:
      return 'disconnected';

    case 1:
      return 'connected';

    case 2:
      return 'connecting';

    case 3:
      return 'disconnecting';

    default:
      return 'unknown';
  }
}


/**
 * Check whether MongoDB is connected.
 */
export function isDatabaseConnected() {
  return (
    mongoose.connection.readyState === 1
  );
}


/**
 * Get the active Mongoose connection.
 */
export function getDatabaseConnection() {
  return mongoose.connection;
}


/* -------------------------------------------------------------------------- */
/* Connect                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Connect ARGUS to MongoDB.
 *
 * The same promise is reused when multiple parts of the
 * application request a connection at the same time.
 *
 * @returns {Promise<mongoose.Connection>}
 */
export async function connectDatabase() {
  /**
   * Already connected.
   */
  if (
    mongoose.connection.readyState === 1
  ) {
    return mongoose.connection;
  }


  /**
   * A connection attempt is already running.
   *
   * Return the existing promise instead of initiating
   * another connection.
   */
  if (connectionPromise) {
    return connectionPromise;
  }


  connectionPromise =
    mongoose
      .connect(
        env.database.uri,
        mongooseOptions,
      )
      .then(
        (mongooseInstance) => {
          console.info(
            `[DATABASE] MongoDB connected successfully: ${mongoose.connection.host}:${mongoose.connection.port}/${mongoose.connection.name}`,
          );

          return mongooseInstance.connection;
        },
      )
      .catch(
        (error) => {
          console.error(
            '[DATABASE] MongoDB connection failed.',
          );

          /**
           * Do not expose connection strings,
           * credentials, or full configuration
           * to normal application logs.
           */
          console.error(
            `[DATABASE] ${error.message}`,
          );

          throw error;
        },
      )
      .finally(
        () => {
          connectionPromise = null;
        },
      );


  return connectionPromise;
}


/* -------------------------------------------------------------------------- */
/* Disconnect                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Gracefully disconnect MongoDB.
 *
 * Safe to call during:
 * - SIGTERM
 * - SIGINT
 * - application restart
 * - testing
 */
export async function disconnectDatabase() {
  if (
    mongoose.connection.readyState === 0
  ) {
    return;
  }


  try {
    await mongoose.disconnect();

    console.info(
      '[DATABASE] MongoDB disconnected successfully.',
    );
  } catch (error) {
    console.error(
      '[DATABASE] MongoDB disconnect failed:',
      error.message,
    );

    throw error;
  }
}


/* -------------------------------------------------------------------------- */
/* Database health check                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Perform an actual MongoDB ping.
 *
 * Checking readyState alone is not enough because the
 * connection can appear established while the database
 * server is temporarily unreachable.
 */
export async function checkDatabaseHealth() {
  const connection =
    mongoose.connection;


  if (
    connection.readyState !== 1
  ) {
    return {
      status: 'unhealthy',

      database: 'mongodb',

      connected: false,

      state:
        getConnectionState(),

      databaseName:
        connection.name || null,
    };
  }


  try {
    await connection.db
      .admin()
      .ping();


    return {
      status: 'healthy',

      database: 'mongodb',

      connected: true,

      state:
        getConnectionState(),

      host:
        connection.host || null,

      port:
        connection.port || null,

      databaseName:
        connection.name || null,
    };
  } catch (error) {
    return {
      status: 'unhealthy',

      database: 'mongodb',

      connected: false,

      state:
        getConnectionState(),

      databaseName:
        connection.name || null,

      /**
       * Detailed MongoDB errors remain hidden
       * when running production.
       */
      ...(env.isProduction
        ? {}
        : {
            error: error.message,
          }),
    };
  }
}


/* -------------------------------------------------------------------------- */
/* Connection information                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Return sanitized connection information.
 *
 * Never return env.database.uri because it may
 * contain MongoDB credentials.
 */
export function getDatabaseInfo() {
  const connection =
    mongoose.connection;


  return {
    driver: 'mongodb',

    state:
      getConnectionState(),

    connected:
      connection.readyState === 1,

    connecting:
      connection.readyState === 2,

    disconnecting:
      connection.readyState === 3,

    host:
      connection.host || null,

    port:
      connection.port || null,

    database:
      connection.name || null,

    models:
      Object.keys(
        connection.models,
      ).length,
  };
}


/* -------------------------------------------------------------------------- */
/* MongoDB events                                                             */
/* -------------------------------------------------------------------------- */

mongoose.connection.on(
  'connecting',
  () => {
    console.info(
      '[DATABASE] MongoDB connection is being established...',
    );
  },
);


mongoose.connection.on(
  'connected',
  () => {
    console.info(
      `[DATABASE] MongoDB connection established: ${mongoose.connection.host}:${mongoose.connection.port}/${mongoose.connection.name}`,
    );
  },
);


mongoose.connection.on(
  'open',
  () => {
    console.info(
      '[DATABASE] MongoDB connection is open.',
    );
  },
);


mongoose.connection.on(
  'reconnected',
  () => {
    console.warn(
      '[DATABASE] MongoDB connection re-established.',
    );
  },
);


mongoose.connection.on(
  'disconnected',
  () => {
    console.error(
      '[DATABASE] MongoDB connection was lost.',
    );
  },
);


mongoose.connection.on(
  'disconnecting',
  () => {
    console.warn(
      '[DATABASE] MongoDB connection is closing...',
    );
  },
);


mongoose.connection.on(
  'close',
  () => {
    console.info(
      '[DATABASE] MongoDB connection closed.',
    );
  },
);


mongoose.connection.on(
  'error',
  (error) => {
    console.error(
      '[DATABASE] MongoDB connection error:',
      error.message,
    );
  },
);


/* -------------------------------------------------------------------------- */
/* Graceful database shutdown                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Close MongoDB connection during application shutdown.
 */
export async function shutdownDatabase() {
  try {
    await disconnectDatabase();
  } catch (error) {
    console.error(
      '[DATABASE] Database shutdown failed:',
      error.message,
    );

    throw error;
  }
}


/* -------------------------------------------------------------------------- */
/* Default export                                                             */
/* -------------------------------------------------------------------------- */

const database = Object.freeze({
  connect:
    connectDatabase,

  disconnect:
    disconnectDatabase,

  shutdown:
    shutdownDatabase,

  health:
    checkDatabaseHealth,

  info:
    getDatabaseInfo,

  isConnected:
    isDatabaseConnected,

  connection:
    getDatabaseConnection,
});


export default database;