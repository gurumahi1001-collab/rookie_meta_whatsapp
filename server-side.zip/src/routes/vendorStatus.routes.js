import { Router } from "express";

import authMiddleware, {
    requireInternalUser,
} from "../middleware/auth.js";
import rbacMiddleware from "../middleware/rbac.js";

import * as controller from "../controllers/vendor/vendorStatusController.js";

const router = Router();

const view = [
    authMiddleware,
    requireInternalUser,
    rbacMiddleware({ module: "vendor_settings", action: "view" }),
];

const add = [
    authMiddleware,
    requireInternalUser,
    rbacMiddleware({ module: "vendor_settings", action: "add" }),
];

const edit = [
    authMiddleware,
    requireInternalUser,
    rbacMiddleware({ module: "vendor_settings", action: "edit" }),
];

const remove = [
    authMiddleware,
    requireInternalUser,
    rbacMiddleware({ module: "vendor_settings", action: "delete" }),
];

router.get("/", ...view, controller.list);
router.get("/:id", ...view, controller.get);
router.post("/", ...add, controller.create);
router.patch("/:id", ...edit, controller.update);
router.patch("/:id/status", ...edit, controller.setStatus);
router.delete("/:id", ...remove, controller.remove);

export default router;
