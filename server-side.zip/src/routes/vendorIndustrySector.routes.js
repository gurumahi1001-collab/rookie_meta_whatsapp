import { Router } from "express";
import authenticate, { requireInternalUser } from "../../src/middleware/auth.js";
import authorize from "../../src/middleware/rbac.js";
import controller from "../controllers/vendor/vendorIndustrySectorController.js";

const router = Router();
router.use(authenticate);
router.use(requireInternalUser);

const canView = authorize({ module: "vendor_settings", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canAdd = authorize({ module: "vendor_settings", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canEdit = authorize({ module: "vendor_settings", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });
const canDelete = authorize({ module: "vendor_settings", action: "delete", realms: ["admin", "internal"], userTypes: ["admin", "internal"] });

router.get("/", canView, controller.list);
router.get("/:id", canView, controller.get);
router.post("/", canAdd, controller.create);
router.patch("/:id", canEdit, controller.update);
router.patch("/:id/status", canEdit, controller.setStatus);
router.delete("/:id", canDelete, controller.remove);

export default router;
