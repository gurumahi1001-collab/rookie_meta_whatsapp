
// src/routes/auth.routes.js

import { Router } from "express";

import {
    adminLogin,
    vendorLogin,
    refresh,
    logout,
    me,
} from "../controllers/auth/authController.js";

import authMiddleware from "../middleware/auth.js";

const router = Router();

/*
|--------------------------------------------------------------------------
| Authentication Routes
|--------------------------------------------------------------------------
|
| Full API paths after mounting:
|
| POST /api/v1/auth/admin/login
| POST /api/v1/auth/vendor/login
| POST /api/v1/auth/refresh
| POST /api/v1/auth/logout
| GET  /api/v1/auth/me
|
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Admin / Internal Login
|--------------------------------------------------------------------------
|
| The controller currently uses the admin authentication flow for the
| internal administrative workspace.
|
| User type validation is performed inside authService.
|--------------------------------------------------------------------------
*/

router.post(
    "/admin/login",
    adminLogin,
);

/*
|--------------------------------------------------------------------------
| Vendor Portal Login
|--------------------------------------------------------------------------
*/

router.post(
    "/vendor/login",
    vendorLogin,
);

/*
|--------------------------------------------------------------------------
| Refresh Access Session
|--------------------------------------------------------------------------
|
| Refresh authentication itself is handled by the refresh token.
| No access-token middleware is placed here.
|--------------------------------------------------------------------------
*/

router.post(
    "/refresh",
    refresh,
);

/*
|--------------------------------------------------------------------------
| Logout
|--------------------------------------------------------------------------
|
| Authentication is required when a valid access token is available.
| The controller also revokes the persisted refresh session.
|--------------------------------------------------------------------------
*/

router.post(
    "/logout",
    authMiddleware,
    logout,
);

/*
|--------------------------------------------------------------------------
| Current Authenticated User
|--------------------------------------------------------------------------
*/

router.get(
    "/me",
    authMiddleware,
    me,
);

export default router;