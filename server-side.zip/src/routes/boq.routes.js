import { Router } from 'express';
const router = Router();
// TODO: register boq controllers with auth, RBAC, validation and service calls.
export default router;
