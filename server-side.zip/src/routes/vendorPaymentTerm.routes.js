import { Router } from "express";

import authMiddleware, {
  requireInternalUser,
} from "../middleware/auth.js";

import rbacMiddleware from "../middleware/rbac.js";

import vendorPaymentTermController from "../controllers/vendor/vendorPaymentTermController.js";

const router = Router();

const canView = [
  authMiddleware,
  requireInternalUser,
  rbacMiddleware({
    module: "vendor_settings",
    action: "view",
  }),
];

const canAdd = [
  authMiddleware,
  requireInternalUser,
  rbacMiddleware({
    module: "vendor_settings",
    action: "add",
  }),
];

const canEdit = [
  authMiddleware,
  requireInternalUser,
  rbacMiddleware({
    module: "vendor_settings",
    action: "edit",
  }),
];

const canDelete = [
  authMiddleware,
  requireInternalUser,
  rbacMiddleware({
    module: "vendor_settings",
    action: "delete",
  }),
];

router.get("/", ...canView, vendorPaymentTermController.list);
router.get("/:id", ...canView, vendorPaymentTermController.get);
router.post("/", ...canAdd, vendorPaymentTermController.create);
router.patch("/:id", ...canEdit, vendorPaymentTermController.update);
router.patch("/:id/status", ...canEdit, vendorPaymentTermController.setStatus);
router.delete("/:id", ...canDelete, vendorPaymentTermController.remove);

export default router;
