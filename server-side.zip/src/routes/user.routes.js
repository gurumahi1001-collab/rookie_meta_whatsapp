// src/routes/user.routes.js

import { Router } from 'express';

import userManagementController from '../controllers/user/userManagementController.js';
import { profileImageUpload } from '../middleware/upload.js';

import authenticate, {
  requireInternalUser,
} from '../middleware/auth.js';

import authorize, { hasPermission } from '../middleware/rbac.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router =
  Router();


/* -------------------------------------------------------------------------- */
/* User Management RBAC                                                       */
/* -------------------------------------------------------------------------- */

/**
 * User Management permission module.
 *
 * Permission actions:
 *
 *   view
 *   add
 *   edit
 *   delete
 *
 * "all" remains supported internally by RBAC when applicable.
 */

const canViewUsers =
  authorize({
    module:
      'user_management',

    action:
      'view',

    realms: [
      'admin',
      'internal',
    ],

    userTypes: [
      'admin',
      'internal',
    ],
  });


const canAddUsers =
  authorize({
    module:
      'user_management',

    action:
      'add',

    realms: [
      'admin',
      'internal',
    ],

    userTypes: [
      'admin',
      'internal',
    ],
  });


const canEditUsers =
  authorize({
    module:
      'user_management',

    action:
      'edit',

    realms: [
      'admin',
      'internal',
    ],

    userTypes: [
      'admin',
      'internal',
    ],
  });


const canDeleteUsers =
  authorize({
    module:
      'user_management',

    action:
      'delete',

    realms: [
      'admin',
      'internal',
    ],

    userTypes: [
      'admin',
      'internal',
    ],
  });


const canManageProfileImage = (req, res, next) => {
  const userType = String(req.user?.userType || '').toLowerCase();

  if (!['admin', 'internal'].includes(userType)) {
    return res.status(403).json({
      success: false,
      message: 'Your account type cannot manage user profile images.',
      code: 'FORBIDDEN',
    });
  }

  const allowed =
    hasPermission(req, { module: 'user_management', action: 'all' }) ||
    hasPermission(req, { module: 'user_management', action: 'add' }) ||
    hasPermission(req, { module: 'user_management', action: 'edit' });

  if (!allowed) {
    return res.status(403).json({
      success: false,
      message: 'You do not have permission to manage user profile images.',
      code: 'FORBIDDEN',
    });
  }

  return next();
};


/* -------------------------------------------------------------------------- */
/* LIST USERS                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/users
 *
 * Supports:
 *
 * ?search=
 * ?roleId=
 * ?status=
 * ?userType=
 * ?vendorId=
 * ?page=
 * ?limit=
 */
router.get(
  '/',
  authenticate,
  requireInternalUser,
  canViewUsers,
  userManagementController.list,
);


/* -------------------------------------------------------------------------- */
/* CHECK EMAIL                                                                */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/users/check-email
 *
 * This route MUST appear before /:id so "check-email" is not treated
 * as a MongoDB identifier.
 */
router.get(
  '/check-email',
  authenticate,
  requireInternalUser,
  canViewUsers,
  userManagementController.checkEmail,
);


/* -------------------------------------------------------------------------- */
/* BULK STATUS                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/users/bulk-status
 *
 * Activate/deactivate multiple users in one request.
 *
 * This route MUST appear before /:id.
 */
router.patch(
  '/bulk-status',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.bulkUpdateStatus,
);


/* -------------------------------------------------------------------------- */
/* CREATE USER                                                                */
/* -------------------------------------------------------------------------- */

/**
 * POST /api/v1/users
 */
router.post(
  '/',
  authenticate,
  requireInternalUser,
  canAddUsers,
  userManagementController.create,
);



/* -------------------------------------------------------------------------- */
/* PROFILE IMAGE                                                              */
/* -------------------------------------------------------------------------- */

router.get(
  '/:id/avatar',
  authenticate,
  requireInternalUser,
  canViewUsers,
  userManagementController.getProfileImage,
);

router.post(
  '/:id/avatar',
  authenticate,
  requireInternalUser,
  canManageProfileImage,
  profileImageUpload,
  userManagementController.uploadProfileImage,
);

router.delete(
  '/:id/avatar',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.removeProfileImage,
);

/* -------------------------------------------------------------------------- */
/* GET USER                                                                    */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/users/:id
 */
router.get(
  '/:id',
  authenticate,
  requireInternalUser,
  canViewUsers,
  userManagementController.get,
);


/* -------------------------------------------------------------------------- */
/* UPDATE USER                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/users/:id
 */
router.patch(
  '/:id',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.update,
);


/* -------------------------------------------------------------------------- */
/* UPDATE USER STATUS                                                         */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/users/:id/status
 */
router.patch(
  '/:id/status',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.updateStatus,
);


/* -------------------------------------------------------------------------- */
/* RESET PASSWORD                                                             */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/users/:id/password
 *
 * Administrative password reset.
 */
router.patch(
  '/:id/password',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.resetPassword,
);


/* -------------------------------------------------------------------------- */
/* ASSIGN ROLE                                                                */
/* -------------------------------------------------------------------------- */

/**
 * PATCH /api/v1/users/:id/role
 *
 * Assign an existing RBAC role to a user.
 */
router.patch(
  '/:id/role',
  authenticate,
  requireInternalUser,
  canEditUsers,
  userManagementController.assignRole,
);


/* -------------------------------------------------------------------------- */
/* DELETE / DEACTIVATE USER                                                   */
/* -------------------------------------------------------------------------- */

/**
 * DELETE /api/v1/users/:id
 *
 * User removal is intentionally implemented as a controlled
 * service-level operation rather than exposing physical database
 * deletion.
 *
 * NOTE:
 * The current controller contract in the ZIP still exposes
 * `remove`. Once the service/controller implementation is aligned,
 * this route can use that handler.
 */
router.delete(
  '/:id',
  authenticate,
  requireInternalUser,
  canDeleteUsers,
  async (req, res, next) => {
    try {
      /*
       * Keep compatibility with both the current controller contract
       * and the newer deactivate-user service operation.
       */

      if (
        typeof userManagementController.remove ===
        'function'
      ) {
        return userManagementController.remove(
          req,
          res,
          next,
        );
      }

      return res
        .status(501)
        .json({
          success:
            false,

          message:
            'User removal is not implemented.',

          code:
            'USER_REMOVE_NOT_IMPLEMENTED',

          requestId:
            req.requestId,
        });
    } catch (error) {
      return next(
        error,
      );
    }
  },
);


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;