// src/routes/audit.routes.js

import { Router } from 'express';

import auditLogController from '../controllers/audit/auditLogController.js';

import authenticate, {
  requireInternalUser,
} from '../middleware/auth.js';

import authorize from '../middleware/rbac.js';


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();


/* -------------------------------------------------------------------------- */
/* Audit Log RBAC                                                             */
/* -------------------------------------------------------------------------- */

/**
 * Audit Log is an Admin/Internal-only read surface.
 *
 * Audit records are append-only and are created by trusted application
 * services. Browser clients are intentionally given no audit-write route.
 */
const canViewAuditLog = authorize({
  module: 'audit_log',
  action: 'view',
  realms: [
    'admin',
    'internal',
  ],
  userTypes: [
    'admin',
    'internal',
  ],
});


/* -------------------------------------------------------------------------- */
/* LIST AUDIT LOGS                                                            */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/audit
 *
 * Supported query parameters are handled by the controller/service:
 *   page, limit, search
 *   action, module
 *   actorType / userType
 *   actorUserId / userId
 *   entityType, entityId
 *   vendorId
 *   status
 *   fromDate / startDate
 *   toDate / endDate
 */
router.get(
  '/',
  authenticate,
  requireInternalUser,
  canViewAuditLog,
  auditLogController.list,
);


/* -------------------------------------------------------------------------- */
/* GET SINGLE AUDIT ENTRY                                                     */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/audit/:id
 */
router.get(
  '/:id',
  authenticate,
  requireInternalUser,
  canViewAuditLog,
  auditLogController.get,
);


/* -------------------------------------------------------------------------- */
/* No browser write endpoints                                                 */
/* -------------------------------------------------------------------------- */

/**
 * Do not expose POST / PATCH / PUT / DELETE routes here.
 *
 * Audit events must be written from trusted application services so that a
 * normal authenticated client cannot create, modify, or delete its own
 * audit history.
 */


export default router;
