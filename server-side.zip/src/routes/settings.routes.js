// src/routes/settings.routes.js

import { Router } from "express";

import companySettingsController from "../controllers/settings/companySettingsController.js";
import rolesPermissionsController from "../controllers/settings/rolesPermissionsController.js";
import apiConfigController from "../controllers/settings/apiConfigController.js";
import commonSettingsController from "../controllers/settings/commonSettingsController.js";
import fileController from "../controllers/storage/fileController.js";

import authMiddleware, {
    requireInternalUser,
} from "../middleware/auth.js";

import rbacMiddleware from "../middleware/rbac.js";

import {
    companyLogoUpload,
    companyFaviconUpload,
} from "../middleware/validation.js";


/* -------------------------------------------------------------------------- */
/* Router                                                                     */
/* -------------------------------------------------------------------------- */

const router = Router();

/*
|--------------------------------------------------------------------------
| Permission vocabulary
|--------------------------------------------------------------------------
|
| These route permission keys intentionally match seedData.js:
|
|   company_settings
|   roles_permissions
|   api_configuration
|   common_settings
|
| Vendor settings and Master Rate Settings are mounted by their
| dedicated routers and must use the same canonical permission keys there.
|--------------------------------------------------------------------------
*/



/* -------------------------------------------------------------------------- */
/* COMPANY INFORMATION                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/company
 *
 * Get the current singleton company profile.
 */
router.get(
    "/company",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),

    companySettingsController.getCompanyProfile,
);


/**
 * POST /api/v1/settings/company
 *
 * Initialize the singleton company profile when the workspace
 * does not have a company record yet.
 *
 * This route is required for the first-time Company Information
 * save flow from the frontend.
 */
router.post(
    "/company",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companySettingsController.initializeCompanyProfile,
);


/**
 * PATCH /api/v1/settings/company
 *
 * Update the existing company profile.
 */
router.patch(
    "/company",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companySettingsController.updateCompanyProfile,
);


/**
 * POST /api/v1/settings/company/logo
 *
 * multipart/form-data
 * field: logo
 */
router.post(
    "/company/logo",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companyLogoUpload,

    companySettingsController.uploadCompanyLogo,
);


/**
 * DELETE /api/v1/settings/company/logo
 */
router.delete(
    "/company/logo",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companySettingsController.deleteCompanyLogo,
);


/**
 * POST /api/v1/settings/company/favicon
 *
 * multipart/form-data
 * field: favicon
 */
router.post(
    "/company/favicon",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companyFaviconUpload,

    companySettingsController.uploadCompanyFavicon,
);


/**
 * DELETE /api/v1/settings/company/favicon
 */
router.delete(
    "/company/favicon",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companySettingsController.deleteCompanyFavicon,
);


/**
 * PATCH /api/v1/settings/company/status
 *
 * Activate/deactivate the company profile.
 */
router.patch(
    "/company/status",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "edit",
    }),

    companySettingsController.updateCompanyStatus,
);


/* -------------------------------------------------------------------------- */
/* PROTECTED COMPANY FILE ACCESS                                              */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/company/logo
 *
 * Protected inline logo access.
 */
router.get(
    "/company/logo",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),

    fileController.getCompanyLogo,
);


/**
 * GET /api/v1/settings/company/logo/download
 */
router.get(
    "/company/logo/download",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),

    fileController.downloadCompanyLogo,
);


/**
 * GET /api/v1/settings/company/favicon
 */
router.get(
    "/company/favicon",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),

    fileController.getCompanyFavicon,
);


/**
 * GET /api/v1/settings/company/favicon/download
 */
router.get(
    "/company/favicon/download",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "company_settings",
        action: "view",
    }),

    fileController.downloadCompanyFavicon,
);


/* -------------------------------------------------------------------------- */
/* ROLES & PERMISSIONS                                                        */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/roles
 *
 * List roles.
 *
 * NOTE:
 * `roles_permissions` is the actual permission key used by the
 * application. Do not use the old `user_role` key here.
 */
router.get(
    "/roles",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "view",
    }),

    rolesPermissionsController.list,
);


/**
 * GET /api/v1/settings/roles/permissions
 *
 * Return the complete permission/module catalog.
 *
 * IMPORTANT:
 * This route must come before `/roles/:roleId`.
 * Otherwise "permissions" can be interpreted as a roleId.
 */
router.get(
    "/roles/permissions",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "view",
    }),

    rolesPermissionsController.permissions,
);


/**
 * GET /api/v1/settings/roles/:roleId/permissions
 *
 * Load the complete permission matrix for a role.
 */
router.get(
    "/roles/:roleId/permissions",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "view",
    }),

    rolesPermissionsController.matrix,
);


/**
 * PUT /api/v1/settings/roles/:roleId/permissions
 *
 * Replace the complete permission matrix for a role.
 */
router.put(
    "/roles/:roleId/permissions",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "edit",
    }),

    rolesPermissionsController.replacePermissions,
);


/**
 * PATCH /api/v1/settings/roles/:roleId/permissions/:permissionId
 *
 * Update one permission assignment.
 */
router.patch(
    "/roles/:roleId/permissions/:permissionId",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "edit",
    }),

    rolesPermissionsController.updatePermission,
);


/**
 * GET /api/v1/settings/roles/:roleId
 *
 * Get one role.
 *
 * This route comes after the more specific `/roles/permissions`
 * and `/roles/:roleId/permissions` routes.
 */
router.get(
    "/roles/:roleId",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "view",
    }),

    rolesPermissionsController.get,
);


/**
 * POST /api/v1/settings/roles
 *
 * Create a new role.
 */
router.post(
    "/roles",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "add",
    }),

    rolesPermissionsController.create,
);


/**
 * PATCH /api/v1/settings/roles/:roleId
 *
 * Update role metadata.
 */
router.patch(
    "/roles/:roleId",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "edit",
    }),

    rolesPermissionsController.update,
);


/**
 * DELETE /api/v1/settings/roles/:roleId
 *
 * Delete/deactivate a role.
 */
router.delete(
    "/roles/:roleId",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "roles_permissions",
        action: "delete",
    }),

    rolesPermissionsController.remove,
);


/* -------------------------------------------------------------------------- */
/* API CONFIGURATION                                                          */
/* -------------------------------------------------------------------------- */

/**
 * GET /api/v1/settings/api-configurations
 */
router.get(
    "/api-configurations",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "api_configuration",
        action: "view",
    }),

    apiConfigController.list,
);


/**
 * GET /api/v1/settings/api-configurations/:id
 */
router.get(
    "/api-configurations/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "api_configuration",
        action: "view",
    }),

    apiConfigController.get,
);


/**
 * POST /api/v1/settings/api-configurations
 */
router.post(
    "/api-configurations",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "api_configuration",
        action: "add",
    }),

    apiConfigController.create,
);


/**
 * PATCH /api/v1/settings/api-configurations/:id
 */
router.patch(
    "/api-configurations/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "api_configuration",
        action: "edit",
    }),

    apiConfigController.update,
);


/**
 * DELETE /api/v1/settings/api-configurations/:id
 */
router.delete(
    "/api-configurations/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "api_configuration",
        action: "delete",
    }),

    apiConfigController.remove,
);


/* -------------------------------------------------------------------------- */
/* COMMON SETTINGS                                                            */
/* -------------------------------------------------------------------------- */

/**
 * Common Settings:
 *
 * - Units
 * - Validity Period
 * - Terms & Conditions
 *
 * Query examples:
 *
 * ?type=unit
 * ?type=validity_period
 * ?type=terms_condition
 */


/**
 * GET /api/v1/settings/common
 */
router.get(
    "/common",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "common_settings",
        action: "view",
    }),

    commonSettingsController.list,
);


/**
 * GET /api/v1/settings/common/:id
 */
router.get(
    "/common/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "common_settings",
        action: "view",
    }),

    commonSettingsController.get,
);


/**
 * POST /api/v1/settings/common
 */
router.post(
    "/common",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "common_settings",
        action: "add",
    }),

    commonSettingsController.create,
);


/**
 * PATCH /api/v1/settings/common/:id
 */
router.patch(
    "/common/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "common_settings",
        action: "edit",
    }),

    commonSettingsController.update,
);


/**
 * DELETE /api/v1/settings/common/:id
 */
router.delete(
    "/common/:id",

    authMiddleware,

    requireInternalUser,

    rbacMiddleware({
        module: "common_settings",
        action: "delete",
    }),

    commonSettingsController.remove,
);


/* -------------------------------------------------------------------------- */
/* FUTURE / DOMAIN-SPECIFIC SETTINGS                                          */
/* -------------------------------------------------------------------------- */

/**
 * Vendor Settings
 *
 * Vendor-specific configuration should be kept separate from
 * vendor transaction routes.
 *
 * Planned settings can include:
 *
 * - Vendor Category
 * - Currency
 * - Payment Terms
 * - Industry Sector
 * - Vendor Status
 *
 * These should be connected here only after their dedicated
 * production controllers/services are ready.
 */


/**
 * Master Rate Settings
 *
 * Category configuration remains a Settings concern while
 * actual rate scheduling stays under `/master-rates`.
 */


/* -------------------------------------------------------------------------- */
/* Export                                                                     */
/* -------------------------------------------------------------------------- */

export default router;