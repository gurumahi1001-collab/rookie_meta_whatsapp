import { Router } from 'express';
const router = Router();
// TODO: register project controllers with auth, RBAC, validation and service calls.
export default router;
