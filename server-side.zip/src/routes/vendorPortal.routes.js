import { Router } from "express";

import authenticate, {
    requireInternalUser,
    requireVendorUser,
} from "../middleware/auth.js";

import authorize from "../middleware/rbac.js";

import * as vendorPortalController from "../controllers/vendor/vendorPortalController.js";

const router = Router();

/* Vendor portal user: read own scoped profile. */
router.get(
    "/me",
    authenticate,
    requireVendorUser,
    vendorPortalController.profile,
);

/* Internal user: inspect a vendor's existing portal account. */
router.get(
    "/vendors/:id/account",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.getAccount,
);

/* Internal user: provision portal access for an approved vendor. */
router.post(
    "/vendors/:id/account",
    authenticate,
    requireInternalUser,
    authorize({ module: "vendors", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"] }),
    vendorPortalController.provision,
);

export default router;
