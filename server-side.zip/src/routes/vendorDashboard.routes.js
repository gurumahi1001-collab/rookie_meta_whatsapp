import { Router } from "express";

import authMiddleware, {
    requireVendorUser,
} from "../middleware/auth.js";

import * as controller from "../controllers/vendor/vendorDashboardController.js";

const router = Router();

router.get(
    "/dashboard",
    authMiddleware,
    requireVendorUser,
    controller.get,
);

export default router;
