const write = (level, message, meta = {}) => console.log(JSON.stringify({ time: new Date().toISOString(), level, message, ...meta }));
export const logger = { info: (m, x) => write('info', m, x), error: (m, x) => write('error', m, x), warn: (m, x) => write('warn', m, x), debug: (m, x) => write('debug', m, x), http: (m, x) => write('http', m, x) };
