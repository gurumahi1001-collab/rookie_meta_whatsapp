import { randomUUID } from 'node:crypto';
export const uuid = () => randomUUID();
export const pageMeta = ({ page=1, limit=25, total=0 }) => ({ page, limit, total, totalPages: Math.ceil(total / limit) });
export const parsePagination = (query) => ({ page: Math.max(1, Number(query.page || 1)), limit: Math.min(100, Math.max(1, Number(query.limit || 25))) });
