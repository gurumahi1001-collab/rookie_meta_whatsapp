import { z } from 'zod';
export const idSchema = z.object({ id: z.string().uuid() });
export const paginationSchema = z.object({ page:z.coerce.number().int().min(1).default(1), limit:z.coerce.number().int().min(1).max(100).default(25), search:z.string().trim().optional(), status:z.string().trim().optional() });
