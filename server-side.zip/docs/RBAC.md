# RBAC

Server-side permission matrix: module -> VIEW / ADD / EDIT / DELETE / ALL.

System admin roles: Workspace Owner, Network Admin, Field Technician, Billing Manager. Vendor portal role: Vendor Admin. Each access token carries userType, roleCode and vendorId where applicable.
