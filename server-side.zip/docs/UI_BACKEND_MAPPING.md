# UI -> Backend mapping

`/admin_dashboard` and `/vendor_dashboard` -> dashboard; `/vendor*` -> vendor; `/quotation*` and BOQ paths -> quotation/BOQ; `/projects*` -> project; `/tasks` and `/timline` -> task/project progress; `/invoices*` -> invoice/payment; `/survey_report*` and survey-form -> survey/report; `/user_management` -> user; `/master_rate_schedule` -> masterRate; `/settings/*` -> settings domains.
