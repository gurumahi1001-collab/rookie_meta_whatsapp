@extends('layouts/layoutMaster')

@section('title', 'Users & Role')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

@include('layouts.sections.settings.settings-header', ['activeTab' => 'rbac'])

<div class="card mb-4 settings-card">
  <div class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
    <div>
      <h6 class="mb-0 fw-bold d-flex align-items-center gap-2">
        <i class="mdi mdi-shield-account-outline text-primary"></i> Roles
      </h6>
      <small class="text-muted">Manage roles and their module-level permissions</small>
    </div>
    <button type="button" id="addRoleButton" class="btn btn-primary btn-sm" data-bs-toggle="offcanvas" data-bs-target="#roleDrawer">
      <i class="mdi mdi-plus me-1"></i> Add Role
    </button>
  </div>

  <div class="table-responsive">
    <table class="table table-hover mb-0" id="rolesTable">
      <thead class="fw-semibold text-black fs-8 uppercase bg-light">
        <tr>
          <th class="min-w-100px text-black">Role Name</th>
          <th class="min-w-100px text-black">Users</th>
          <th class="min-w-100px text-black">Site Management</th>
          <th class="min-w-100px text-black">Status</th>
          <th class="min-w-100px text-black text-end">Actions</th>
        </tr>
      </thead>
      <tbody id="roleTableBody" aria-live="polite">
        @for ($i = 0; $i < 4; $i++)
          <tr class="role-skeleton-row">
            <td><span class="role-skeleton" style="width: 58%;"></span></td>
            <td><span class="role-skeleton" style="width: 24px;"></span></td>
            <td><span class="role-skeleton" style="width: 78px;"></span></td>
            <td><span class="role-skeleton" style="width: 32px;"></span></td>
            <td class="text-end"><span class="role-skeleton ms-auto" style="width: 72px;"></span></td>
          </tr>
        @endfor
      </tbody>
    </table>
  </div>
</div>

{{-- Add / Edit Role Offcanvas: layout and table structure are intentionally retained. --}}
<div class="offcanvas offcanvas-end role-drawer" tabindex="-1" id="roleDrawer" aria-labelledby="roleDrawerLabel" style="width: 600px; max-width: 100vw;">
  <div class="offcanvas-header border-bottom">
    <h5 class="offcanvas-title" id="roleDrawerLabel">Add Role</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body d-flex flex-column p-0">
    <div class="flex-grow-1 overflow-auto p-3">
      <form id="rolePermissionForm" autocomplete="off" novalidate>
        <input type="hidden" id="roleIdInput" value="">
        <div class="row g-3 mb-3">
          <div class="col-12">
            <label class="form-label fw-semibold" for="roleNameInput">Role Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="roleNameInput" maxlength="255" placeholder="Enter Role Name" required>
            <div class="invalid-feedback" id="roleNameError"></div>
          </div>
          <div class="col-12">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" role="switch" id="siteManagementSwitch">
              <label class="form-check-label fw-semibold" for="siteManagementSwitch">Site Management Access</label>
            </div>
          </div>
        </div>

        <hr>
        <h6 class="fw-bold mb-2">Module Permissions</h6>
        <small class="text-muted d-block mb-3">Expand each module to set access at the submenu level.</small>

        <div class="accordion" id="permissionAccordion" aria-live="polite">
          <div class="p-3">
            <span class="role-skeleton mb-3" style="height: 42px;"></span>
            <span class="role-skeleton mb-3" style="height: 42px;"></span>
            <span class="role-skeleton mb-3" style="height: 42px;"></span>
            <span class="role-skeleton" style="height: 42px;"></span>
          </div>
        </div>
      </form>
    </div>

    <div class="border-top p-3 d-flex justify-content-end gap-2 bg-white role-drawer-footer">
      <button type="button" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
      <button type="button" class="btn btn-primary px-4" id="saveRoleButton">
        <i class="mdi mdi-content-save-outline me-1"></i> <span id="saveRoleButtonText">Save Role</span>
      </button>
    </div>
  </div>
</div>

{{-- Delete confirmation stays in the same Bootstrap modal pattern as the current UI. --}}
<div class="modal fade" id="deleteRoleModal" tabindex="-1" aria-hidden="true" aria-labelledby="deleteRoleModalTitle">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body text-center p-4">
        <i class="mdi mdi-trash-can-outline text-danger fs-1"></i>
        <h6 class="fw-bold mt-2" id="deleteRoleModalTitle">Delete Role?</h6>
        <p class="text-muted mb-0">Are you sure you want to delete <strong id="deleteRoleName"></strong>? This action cannot be undone.</p>
      </div>
      <div class="modal-footer justify-content-center border-0 pt-0">
        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger px-4" id="confirmDeleteRoleButton">Delete</button>
      </div>
    </div>
  </div>
</div>

<style>
  .settings-card {
    border: 1px solid #eef0f2;
    border-radius: 14px;
    box-shadow: 0 1px 2px rgba(16, 24, 40, .04);
  }
  .settings-card .card-header { padding: 1rem 1.25rem; }
  .role-drawer-footer { position: sticky; bottom: 0; }
  .accordion-button:not(.collapsed) { background-color: #ecf7ff; color: #16659e; }
  .accordion-button:focus { box-shadow: none; }
  .permission-table thead th {
    background: #f8f9fa;
    font-size: .72rem;
    text-transform: uppercase;
    color: #6c757d;
    font-weight: 600;
  }
  .permission-table td, .permission-table th { padding: .6rem .75rem; vertical-align: middle; }
  .permission-table .form-check-input { cursor: pointer; }
  .role-skeleton {
    display: block;
    height: 18px;
    border-radius: 5px;
    background: linear-gradient(90deg, #eef0f3 25%, #f8f9fb 50%, #eef0f3 75%);
    background-size: 300px 100%;
    animation: roleSkeletonShimmer 1.2s linear infinite;
  }
  @keyframes roleSkeletonShimmer {
    from { background-position: -300px 0; }
    to { background-position: 300px 0; }
  }
  #roleTableBody td { vertical-align: middle; }
  .role-empty-state { padding: 2rem 1rem !important; text-align: center; color: #6c757d; }
  @media (max-width: 575.98px) {
    .role-drawer { width: 100vw !important; }
    .permission-table { min-width: 460px; }
  }
</style>

<script>
(() => {
  'use strict';

  const urls = {
    data: @json(route('settings-user-role.data')),
    store: @json(route('settings-user-role.store')),
    base: @json(url('/settings/users_role'))
  };
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || @json(csrf_token());
  const actionNames = ['view', 'create', 'edit', 'delete'];
  const roleTableBody = document.getElementById('roleTableBody');
  const permissionAccordion = document.getElementById('permissionAccordion');
  const roleNameInput = document.getElementById('roleNameInput');
  const roleIdInput = document.getElementById('roleIdInput');
  const saveRoleButton = document.getElementById('saveRoleButton');
  const saveRoleButtonText = document.getElementById('saveRoleButtonText');
  const siteManagementSwitch = document.getElementById('siteManagementSwitch');
  const deleteModalElement = document.getElementById('deleteRoleModal');

  let roles = [];
  let modules = [];
  let modulesLoaded = false;
  let loadPromise = null;
  let currentRoleId = null;
  let pendingDeleteRoleId = null;
  let isSaving = false;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
  }

  function notify(type, message) {
    if (window.toastr && typeof window.toastr[type] === 'function') {
      window.toastr[type](message);
      return;
    }
    window.alert(message);
  }

  async function requestJson(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: {
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': csrfToken,
        ...(options.headers || {})
      }
    });

    let body;
    try {
      body = await response.json();
    } catch (_) {
      body = { message: 'The server returned an unexpected response. Please refresh and try again.' };
    }

    if (!response.ok || body.success === false) {
      let message = body.message || 'The request could not be completed.';
      if (body.errors && typeof body.errors === 'object') {
        const first = Object.values(body.errors).flat().find(Boolean);
        if (first) message = first;
      }
      throw new Error(message);
    }
    return body;
  }

  function renderSkeletonRows() {
    roleTableBody.innerHTML = Array.from({ length: 4 }, () => `
      <tr class="role-skeleton-row">
        <td><span class="role-skeleton" style="width:58%"></span></td>
        <td><span class="role-skeleton" style="width:24px"></span></td>
        <td><span class="role-skeleton" style="width:78px"></span></td>
        <td><span class="role-skeleton" style="width:32px"></span></td>
        <td class="text-end"><span class="role-skeleton ms-auto" style="width:72px"></span></td>
      </tr>`).join('');
  }

  function renderRoles() {
    if (!roles.length) {
      roleTableBody.innerHTML = '<tr><td colspan="5" class="role-empty-state">No roles found. Use <strong>Add Role</strong> to create the first role.</td></tr>';
      return;
    }

    roleTableBody.innerHTML = roles.map(role => {
      const isActive = Number(role.status) === 0;
      const siteAccess = Boolean(role.site_management_access);
      return `
        <tr data-role-id="${Number(role.id)}">
          <td class="fw-semibold">${escapeHtml(role.name)}</td>
          <td>${Number(role.users) || 0}</td>
          <td><span class="badge ${siteAccess ? 'bg-label-success' : 'bg-label-secondary'}">${siteAccess ? 'Enabled' : 'Disabled'}</span></td>
          <td>
            <div class="form-check form-switch mb-0">
              <input class="form-check-input role-status-toggle" type="checkbox" role="switch"
                aria-label="${isActive ? 'Disable' : 'Enable'} ${escapeHtml(role.name)}"
                data-role-action="status" data-role-id="${Number(role.id)}" ${isActive ? 'checked' : ''}>
            </div>
          </td>
          <td class="text-end">
            <button type="button" class="btn btn-sm btn-icon btn-text-secondary" data-role-action="edit" data-role-id="${Number(role.id)}"
              data-bs-toggle="offcanvas" data-bs-target="#roleDrawer" title="Edit" aria-label="Edit ${escapeHtml(role.name)}">
              <i class="mdi mdi-pencil-outline"></i>
            </button>
            <button type="button" class="btn btn-sm btn-icon btn-text-danger" data-role-action="delete" data-role-id="${Number(role.id)}"
              data-bs-toggle="modal" data-bs-target="#deleteRoleModal" title="Delete" aria-label="Delete ${escapeHtml(role.name)}">
              <i class="mdi mdi-delete-outline"></i>
            </button>
          </td>
        </tr>`;
    }).join('');
  }

  function renderModules() {
    if (!modules.length) {
      permissionAccordion.innerHTML = '<div class="role-empty-state">No modules were found in verticalMenu.json.</div>';
      return;
    }

    permissionAccordion.innerHTML = modules.map((module, moduleIndex) => {
      const moduleId = `roleModule${moduleIndex}`;
      const rows = Array.isArray(module.rows) ? module.rows : [];
      const rowsHtml = rows.length ? rows.map(row => `
        <tr data-permission-row data-key="${escapeHtml(row.key)}">
          <td>${escapeHtml(row.label)}</td>
          ${actionNames.map(action => `
            <td class="text-center">
              <input class="form-check-input perm-checkbox" type="checkbox" data-module="${moduleIndex}" data-action="${action}"
                aria-label="${escapeHtml(action)} permission for ${escapeHtml(row.label)}">
            </td>`).join('')}
        </tr>`).join('') : '<tr><td colspan="5" class="text-muted text-center">No submenu items in this module.</td></tr>';

      return `
        <div class="accordion-item">
          <h2 class="accordion-header" id="heading-${moduleId}">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-${moduleId}"
              aria-expanded="false" aria-controls="collapse-${moduleId}">
              <span class="form-check me-2 mb-0" data-stop-accordion>
                <input class="form-check-input module-select-all" type="checkbox" id="moduleAll-${moduleIndex}" data-module="${moduleIndex}"
                  aria-label="Select all permissions for ${escapeHtml(module.name)}">
              </span>
              <i class="${escapeHtml(module.icon || 'mdi mdi-folder-outline')} me-2"></i>${escapeHtml(module.name)}
            </button>
          </h2>
          <div id="collapse-${moduleId}" class="accordion-collapse collapse" aria-labelledby="heading-${moduleId}" data-bs-parent="#permissionAccordion">
            <div class="accordion-body p-0">
              <div class="table-responsive">
                <table class="table table-sm mb-0 permission-table">
                  <thead><tr><th style="width:40%;">Submenu</th><th class="text-center">View</th><th class="text-center">Create</th><th class="text-center">Edit</th><th class="text-center">Delete</th></tr></thead>
                  <tbody>${rowsHtml}</tbody>
                </table>
              </div>
            </div>
          </div>
        </div>`;
    }).join('');
  }

  async function loadRoleData() {
    renderSkeletonRows();
    loadPromise = requestJson(urls.data)
      .then(response => {
        roles = Array.isArray(response.data?.roles) ? response.data.roles : [];
        modules = Array.isArray(response.data?.modules) ? response.data.modules : [];
        renderRoles();
        renderModules();
        modulesLoaded = true;
      })
      .catch(error => {
        modulesLoaded = false;
        roleTableBody.innerHTML = `<tr><td colspan="5" class="role-empty-state">${escapeHtml(error.message)}<div class="mt-2"><button type="button" class="btn btn-sm btn-outline-primary" data-role-action="retry">Retry</button></div></td></tr>`;
        permissionAccordion.innerHTML = '<div class="role-empty-state">Unable to load the module tree. Close this panel and retry.</div>';
        throw error;
      });

    try {
      await loadPromise;
    } catch (_) {
      // Error state is already shown in the table; do not create an unhandled promise rejection.
    }
  }

  function clearPermissionChecks() {
    permissionAccordion.querySelectorAll('.perm-checkbox, .module-select-all').forEach(input => {
      input.checked = false;
      input.indeterminate = false;
    });
  }

  function syncModuleMaster(moduleIndex) {
    const master = document.getElementById(`moduleAll-${moduleIndex}`);
    if (!master) return;
    const boxes = Array.from(permissionAccordion.querySelectorAll(`.perm-checkbox[data-module="${moduleIndex}"]`));
    const checkedCount = boxes.filter(box => box.checked).length;
    master.checked = boxes.length > 0 && checkedCount === boxes.length;
    master.indeterminate = checkedCount > 0 && checkedCount < boxes.length;
  }

  function applyPermissionMap(permissionMap) {
    clearPermissionChecks();
    permissionAccordion.querySelectorAll('[data-permission-row]').forEach(row => {
      const current = permissionMap?.[row.dataset.key] || {};
      row.querySelectorAll('.perm-checkbox').forEach(box => {
        box.checked = Boolean(current[box.dataset.action]);
      });
    });
    modules.forEach((_, index) => syncModuleMaster(index));
  }

  function openRoleModal(mode, roleId = null) {
    currentRoleId = mode === 'edit' ? Number(roleId) : null;
    const requestedRoleId = currentRoleId;
    roleIdInput.value = currentRoleId || '';
    document.getElementById('roleDrawerLabel').textContent = mode === 'edit' ? 'Edit Role' : 'Add Role';
    saveRoleButtonText.textContent = mode === 'edit' ? 'Update Role' : 'Save Role';
    document.getElementById('roleNameError').textContent = '';
    roleNameInput.classList.remove('is-invalid');
    roleNameInput.disabled = false;
    siteManagementSwitch.disabled = false;
    saveRoleButton.disabled = false;

    if (mode === 'add') {
      roleNameInput.value = '';
      siteManagementSwitch.checked = false;
      clearPermissionChecks();
      return;
    }

    roleNameInput.value = '';
    siteManagementSwitch.checked = false;
    clearPermissionChecks();
    roleNameInput.disabled = true;
    siteManagementSwitch.disabled = true;
    saveRoleButton.disabled = true;

    (async () => {
      try {
        if (loadPromise) await loadPromise;
        const response = await requestJson(`${urls.base}/${requestedRoleId}`);
        if (Number(roleIdInput.value) !== Number(requestedRoleId)) return;
        const role = response.data;
        roleNameInput.value = role.name || '';
        siteManagementSwitch.checked = Boolean(role.site_management_access);
        applyPermissionMap(role.permissions || {});
      } catch (error) {
        notify('error', error.message);
        const drawer = bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('roleDrawer'));
        drawer.hide();
      } finally {
        if (Number(roleIdInput.value) === Number(requestedRoleId)) {
          roleNameInput.disabled = false;
          siteManagementSwitch.disabled = false;
          saveRoleButton.disabled = false;
        }
      }
    })();
  }

  function collectPermissions() {
    const permissions = [];
    permissionAccordion.querySelectorAll('[data-permission-row]').forEach(row => {
      const actions = {};
      row.querySelectorAll('.perm-checkbox').forEach(box => {
        actions[box.dataset.action] = box.checked;
      });
      permissions.push({ key: row.dataset.key, actions });
    });
    return permissions;
  }

  async function saveRole() {
    if (isSaving) return;
    const name = roleNameInput.value.trim();
    document.getElementById('roleNameError').textContent = '';
    roleNameInput.classList.remove('is-invalid');

    if (!name) {
      roleNameInput.classList.add('is-invalid');
      document.getElementById('roleNameError').textContent = 'Role Name is required.';
      roleNameInput.focus();
      return;
    }
    if (!modulesLoaded) {
      notify('error', 'The permission modules have not loaded. Reload the page and try again.');
      return;
    }

    isSaving = true;
    saveRoleButton.disabled = true;
    saveRoleButtonText.textContent = currentRoleId ? 'Updating…' : 'Saving…';
    const payload = {
      role_name: name,
      site_management_access: siteManagementSwitch.checked,
      permissions: collectPermissions()
    };

    try {
      const editing = Boolean(currentRoleId);
      const targetUrl = editing ? `${urls.base}/${currentRoleId}` : urls.store;
      await requestJson(targetUrl, {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('roleDrawer')).hide();
      notify('success', editing ? 'Role updated successfully.' : 'Role created successfully.');
      await loadRoleData();
    } catch (error) {
      notify('error', error.message);
    } finally {
      isSaving = false;
      saveRoleButton.disabled = false;
      saveRoleButtonText.textContent = currentRoleId ? 'Update Role' : 'Save Role';
    }
  }

  async function changeRoleStatus(toggle) {
    const id = Number(toggle.dataset.roleId);
    const previousValue = !toggle.checked;
    toggle.disabled = true;

    try {
      await requestJson(`${urls.base}/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: toggle.checked ? 0 : 1 })
      });
      const role = roles.find(item => Number(item.id) === id);
      if (role) role.status = toggle.checked ? 0 : 1;
      notify('success', toggle.checked ? 'Role enabled successfully.' : 'Role disabled successfully.');
    } catch (error) {
      toggle.checked = previousValue;
      notify('error', error.message);
    } finally {
      toggle.disabled = false;
    }
  }

  async function deleteRole() {
    if (!pendingDeleteRoleId) return;
    const button = document.getElementById('confirmDeleteRoleButton');
    button.disabled = true;
    button.textContent = 'Deleting…';

    try {
      await requestJson(`${urls.base}/${pendingDeleteRoleId}`, { method: 'DELETE' });
      bootstrap.Modal.getOrCreateInstance(deleteModalElement).hide();
      notify('success', 'Role deleted successfully.');
      pendingDeleteRoleId = null;
      await loadRoleData();
    } catch (error) {
      notify('error', error.message);
    } finally {
      button.disabled = false;
      button.textContent = 'Delete';
    }
  }

  document.getElementById('addRoleButton').addEventListener('click', () => openRoleModal('add'));
  saveRoleButton.addEventListener('click', saveRole);
  document.getElementById('confirmDeleteRoleButton').addEventListener('click', deleteRole);

  roleTableBody.addEventListener('click', event => {
    const button = event.target.closest('[data-role-action]');
    if (!button) return;
    const action = button.dataset.roleAction;
    if (action === 'edit') openRoleModal('edit', button.dataset.roleId);
    if (action === 'delete') {
      pendingDeleteRoleId = Number(button.dataset.roleId);
      const role = roles.find(item => Number(item.id) === pendingDeleteRoleId);
      document.getElementById('deleteRoleName').textContent = role?.name || 'this role';
    }
    if (action === 'retry') loadRoleData();
  });

  roleTableBody.addEventListener('change', event => {
    const toggle = event.target.closest('[data-role-action="status"]');
    if (toggle) changeRoleStatus(toggle);
  });

  permissionAccordion.addEventListener('click', event => {
    if (event.target.closest('[data-stop-accordion]')) event.stopPropagation();
  });

  permissionAccordion.addEventListener('change', event => {
    const master = event.target.closest('.module-select-all');
    if (master) {
      const moduleIndex = master.dataset.module;
      permissionAccordion.querySelectorAll(`.perm-checkbox[data-module="${moduleIndex}"]`).forEach(box => {
        box.checked = master.checked;
      });
      master.indeterminate = false;
      return;
    }

    const permission = event.target.closest('.perm-checkbox');
    if (permission) syncModuleMaster(permission.dataset.module);
  });

  loadRoleData();
})();
</script>

@endsection
