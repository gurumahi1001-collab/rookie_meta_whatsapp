# Staff View/Edit Production Patch

This is a focused replacement patch for the existing Laravel MVC project. It updates the permanent and contract staff View/Edit drawers and the staff directory API workflow used by those pages.

## Files to replace

Copy these files into the matching paths in the existing project, overwriting the current versions:

- `resources/views/content/admin_hr/emp_staff/permanent_staff.blade.php`
- `resources/views/content/admin_hr/emp_staff/Contractor_staff.blade.php`
- `app/Http/Controllers/emp_staff/StaffDirectoryController.php`
- `app/Services/HR/StaffService.php`
- `routes/web.php`

Back up the five existing files before replacement. Do not replace the full project with this patch.

## Included changes

- The identity block beside the profile image (name, designation and department) remains display-only.
- The Personal Profile & KYC panel includes editable name, contact, personal, employment assignment, grade, probation, leave, KYC, statutory and bank fields.
- Department, designation, job role, user role, blood group, languages, grade, probation, document categories and relationships use active settings lookups where available.
- Grade A/B/C/E and employee-document category fallback choices remain available when the corresponding settings tables contain no active rows.
- Emergency contacts, education, experience, family/dependent records, training induction, reference checks and interview notes support add/remove repeatable records.
- Remuneration uses the existing Add Staff Wages calculator and current Payroll Configuration. Applying a recalculated wage structure and saving the employee updates the existing remuneration records/history.
- Employee Files supports multiple uploads, saved-file download and remove actions using the existing local `ryans_staff_attachment` workflow.
- New repeatable profile sections are stored in `ryans_staff_profile_data.profile_json`.

## Database and storage

- No SQL dump import or schema migration is required for this patch.
- Employee documents and profile images use Laravel's `local` storage disk. Ensure the application's configured local storage directory is writable by the PHP process.
- Keep the existing settings tables populated and mark the lookup rows intended for selection as active (`status = 0`).

## Validation performed

- `php -l` passed for `StaffService.php`, `StaffDirectoryController.php` and `routes/web.php`.
- `node --check` passed for the staff-directory JavaScript in both Blade pages.
- The SQL dump was checked for the existing profile JSON, attachment, remuneration, education, work-history, family and lookup table/column definitions used by this patch.

The supplied project ZIP does not include Composer's `vendor` directory, and no live database was available in this environment. Therefore `php artisan route:list`, Laravel boot, browser interaction and end-to-end database/upload tests could not be run here. Perform those checks in a staging copy before deploying to production.

## Intentionally unchanged

- The header identity fields remain display-only; edit the name, department and designation in the Personal Profile & KYC panel.
- Login Access state and stored login PIN are not exposed as editable profile fields. The existing backend does not create or remove linked login accounts during profile edits. Username and user role remain editable for an already-linked account.
- Unrelated HR modules, payroll screens, attendance, leave and other ERP menus are not included in this patch.
