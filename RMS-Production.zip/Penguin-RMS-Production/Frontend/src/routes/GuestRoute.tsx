import { Navigate, Outlet } from "react-router-dom";

import { useUnauthenticatedRoute } from "@/hooks/useUnauthenticatedRoute";
import { ROUTES } from "./routePaths";

/**
 * Public pages (login, register ...). Logged-in users are
 * redirected to the dashboard.
 */
export function GuestRoute() {
  const isGuest = useUnauthenticatedRoute();

  if (!isGuest) {
    return <Navigate to={ROUTES.app.dashboard} replace />;
  }

  return <Outlet />;
}
