
/**
 * Central place for every URL in the app.
 * Never hard-code a path string anywhere else.
 */
export const ROUTES = {
  root: "/",

  auth: {
    login: "/login",
  },

  app: {
    index:'/',
    dashboard: "/dashboard",
    purchaseOrders: "/purchase-orders",
    qrRework: "/qr-rework",
    stationManagement: "/station-management",
    qaInspection: "/qa-inspection",
    packingDispatch: "/packing-dispatch",
    reportsAnalytics: "/reports-analytics",
    masterData: "/master-data",
    usersRoles: "/users-roles",
    settings: "/settings",
  },
} as const;
