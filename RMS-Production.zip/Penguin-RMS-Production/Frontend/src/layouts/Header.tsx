import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import {
  Bell,
  CheckCheck,
  ChevronDown,
  CircleCheck,
  Clock3,
  LogOut,
  Menu as MenuIcon,
  Search,
  Settings,
  ShieldCheck,
  UserRound,
  X,
  Rocket,
} from "lucide-react";

import { Logo } from "@/components/common/Logo";
import { ROUTES } from "@/routes/routePaths";
import { removeToken } from "@/utils/token";
import { api } from "@/lib/api";
import { connectRealtime, disconnectRealtime } from "@/lib/realtime";

// ============================================================
// TYPES
// ============================================================

interface HeaderProps {
  onToggleSidebar: () => void;
  showLogo: boolean;
}

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: "success" | "info" | "warning" | "milestone";
  read: boolean;
}
type NotificationDto = { id: string; title: string; message: string; eventType?: string; readAt?: string | null; createdAt?: string };

// ============================================================
// COMPONENT
// ============================================================

export function Header({ onToggleSidebar, showLogo }: HeaderProps) {
  const navigate = useNavigate();

  const [activeDropdown, setActiveDropdown] = useState<
    "profile" | "notifications" | null
  >(null);

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [profile, setProfile] = useState({ name: "", email: "", role: "" });

  const [searchValue, setSearchValue] = useState("");

  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let mounted = true;
    const mapNotification = (item: NotificationDto): NotificationItem => ({
      id: item.id,
      title: item.title,
      message: item.message,
      time: item.createdAt ? new Date(item.createdAt).toLocaleString("en-IN") : "Just now",
      type: item.eventType?.toLowerCase().includes("qa") ? "success" : item.eventType?.toLowerCase().includes("reject") ? "warning" : "info",
      read: Boolean(item.readAt),
    });
    api.get<NotificationDto[]>("/notifications").then((items) => { if (mounted) setNotifications(items.map(mapNotification)); }).catch(() => undefined);
    api.get<{ user?: { name?: string; email?: string; roleName?: string } }>("/auth/me").then((result) => { const user = result.user || {}; if (mounted) setProfile({ name: user.name || "", email: user.email || "", role: user.roleName || "" }); }).catch(() => undefined);
    const socket = connectRealtime();
    const onUpdated = (item: NotificationDto) => setNotifications((current) => [mapNotification(item), ...current.filter((value) => value.id !== item.id)]);
    const onReadAll = () => setNotifications((current) => current.map((value) => ({ ...value, read: true })));
    socket?.on("notification:updated", onUpdated);
    socket?.on("notification:read-all", onReadAll);
    return () => { mounted = false; socket?.off("notification:updated", onUpdated); socket?.off("notification:read-all", onReadAll); };
  }, []);

  const unreadCount = notifications.filter(
    (notification) => !notification.read,
  ).length;

  // ==========================================================
  // CLOSE DROPDOWNS ON OUTSIDE CLICK
  // ==========================================================

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setActiveDropdown(null);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setActiveDropdown(null);
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleEscape);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleEscape);
    };
  }, []);

  // ==========================================================
  // SEARCH SHORTCUT
  // ==========================================================

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
      }
    };

    document.addEventListener("keydown", handleShortcut);

    return () => {
      document.removeEventListener("keydown", handleShortcut);
    };
  }, []);

  // ==========================================================
  // TOGGLE DROPDOWN
  // ==========================================================

  const toggleDropdown = (dropdown: "profile" | "notifications") => {
    setActiveDropdown((current) => (current === dropdown ? null : dropdown));
  };

  // ==========================================================
  // MARK NOTIFICATION AS READ
  // ==========================================================

  const markAsRead = async (id: string) => {
    setNotifications((current) => current.map((item) => item.id === id ? { ...item, read: true } : item));
    try { await api.patch(`/notifications/${encodeURIComponent(id)}/read`, {}); } catch { /* Keep the visual state; the next load will reconcile it. */ }
  };

  const markAllAsRead = async () => {
    setNotifications((current) => current.map((item) => ({ ...item, read: true })));
    try { await api.patch("/notifications/read-all", {}); } catch { /* The dropdown remains usable when the API is offline. */ }
  };

  // ==========================================================
  // LOGOUT
  // ==========================================================

  const handleLogout = async () => {
    setActiveDropdown(null);
    try { await api.post("/auth/logout", {}); } catch { /* Clear local state even when the session has expired. */ }
    disconnectRealtime();
    removeToken();
    navigate(ROUTES.auth.login, { replace: true });
  };

  // ==========================================================
  // NOTIFICATION ICON
  // ==========================================================

  const getNotificationIcon = (type: NotificationItem["type"]) => {
    switch (type) {
      case "success":
        return <CircleCheck size={18} />;

      case "milestone":
        return <Rocket size={18} />;

      case "warning":
        return <Clock3 size={18} />;

      default:
        return <ShieldCheck size={18} />;
    }
  };

  return (
    <header className="app-header">
      {/* ================================================== */}
      {/* LEFT SECTION */}
      {/* ================================================== */}

      <div className="app-header__left">
        <button
          type="button"
          className="app-header__menu-btn"
          onClick={onToggleSidebar}
          aria-label="Toggle sidebar"
        >
          <MenuIcon size={21} />
        </button>

        {showLogo && (
          <div className="app-header__mobile-logo d-md-none">
            <Logo variant="dark" size={45} />
          </div>
        )}
      </div>

      {/* ================================================== */}
      {/* SEARCH */}
      {/* ================================================== */}

      <div className="app-header__search d-none d-md-flex">
        <Search size={18} className="app-header__search-icon" />

        <input
          ref={searchRef}
          type="search"
          className="app-header__search-input"
          placeholder="Search anything..."
          aria-label="Search anything"
          value={searchValue}
          onChange={(event) => setSearchValue(event.target.value)}
        />

        {searchValue ? (
          <button
            type="button"
            className="app-header__search-clear"
            onClick={() => setSearchValue("")}
            aria-label="Clear search"
          >
            <X size={15} />
          </button>
        ) : (
          <span className="app-header__search-shortcut">Ctrl K</span>
        )}
      </div>

      {/* ================================================== */}
      {/* RIGHT SECTION */}
      {/* ================================================== */}

      <div className="app-header__right" ref={dropdownRef}>
        {/* ---------------------------------------------- */}
        {/* NOTIFICATION BUTTON */}
        {/* ---------------------------------------------- */}

        <div className="app-header__dropdown-wrapper">
          <button
            type="button"
            className={`app-header__notification ${
              activeDropdown === "notifications" ? "is-active" : ""
            }`}
            onClick={() => toggleDropdown("notifications")}
            aria-label="Notifications"
            aria-expanded={activeDropdown === "notifications"}
          >
            <Bell size={20} strokeWidth={1.9} />

            {unreadCount > 0 && (
              <span className="app-header__notification-count">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>

          {/* NOTIFICATION DROPDOWN */}

          {activeDropdown === "notifications" && (
            <div className="app-notification-dropdown">
              <div className="app-notification-dropdown__header">
                <div>
                  <h6>Notifications</h6>

                  <span>You have {unreadCount} unread messages</span>
                </div>

                <button
                  type="button"
                  className="app-notification-dropdown__close"
                  onClick={() => setActiveDropdown(null)}
                  aria-label="Close notifications"
                >
                  <X size={17} />
                </button>
              </div>

              {/* NOTIFICATION ACTION */}

              {unreadCount > 0 && (
                <div className="app-notification-dropdown__actions">
                  <button type="button" onClick={markAllAsRead}>
                    <CheckCheck size={15} />
                    Mark all as read
                  </button>
                </div>
              )}

              {/* NOTIFICATION LIST */}

              <div className="app-notification-dropdown__list">
                {notifications.length > 0 ? (
                  notifications.map((notification) => (
                    <button
                      type="button"
                      key={notification.id}
                      className={`app-notification-item ${
                        !notification.read ? "is-unread" : ""
                      }`}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <span
                        className={`app-notification-item__icon app-notification-item__icon--${notification.type}`}
                      >
                        {getNotificationIcon(notification.type)}
                      </span>

                      <span className="app-notification-item__content">
                        <span className="app-notification-item__top">
                          <span className="app-notification-item__title">
                            {notification.title}
                          </span>

                          {!notification.read && (
                            <span className="app-notification-item__unread-dot" />
                          )}
                        </span>

                        <span className="app-notification-item__message">
                          {notification.message}
                        </span>

                        <span className="app-notification-item__time">
                          <Clock3 size={12} />
                          {notification.time}
                        </span>
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="app-notification-empty">
                    <Bell size={28} />
                    <span>No notifications yet</span>
                    <small>You're all caught up!</small>
                  </div>
                )}
              </div>

              <div className="app-notification-dropdown__footer">
                <button type="button" onClick={() => setActiveDropdown(null)}>
                  Close notifications
                </button>
              </div>
            </div>
          )}
        </div>

        {/* DIVIDER */}

        <span className="app-header__divider d-none d-sm-block" />

        {/* ---------------------------------------------- */}
        {/* PROFILE BUTTON */}
        {/* ---------------------------------------------- */}

        <div className="app-header__dropdown-wrapper">
          <button
            type="button"
            className={`app-header__profile ${
              activeDropdown === "profile" ? "is-active" : ""
            }`}
            onClick={() => toggleDropdown("profile")}
            aria-expanded={activeDropdown === "profile"}
            aria-haspopup="true"
          >
            <span className="app-header__avatar">
              <UserRound size={20} />
            </span>

            <span className="app-header__profile-info d-none d-sm-flex">
              <span className="app-header__profile-name">Admin</span>

              <span className="app-header__profile-role">Super Admin</span>
            </span>

            <ChevronDown
              size={16}
              className={`app-header__profile-arrow d-none d-sm-block ${
                activeDropdown === "profile" ? "is-open" : ""
              }`}
            />
          </button>

          {/* PROFILE DROPDOWN */}

          {activeDropdown === "profile" && (
            <div className="app-profile-dropdown">
              <div className="app-profile-dropdown__header">
                <span className="app-profile-dropdown__avatar">
                  <UserRound size={25} />
                </span>

                <div className="app-profile-dropdown__details">
                  <span className="app-profile-dropdown__name">
                    {profile.name || "Application User"}
                  </span>

                  <span className="app-profile-dropdown__email">
                    {profile.email || profile.role || "Signed in"}
                  </span>
                </div>
              </div>

              <div className="app-profile-dropdown__divider" />

              <div className="app-profile-dropdown__menu">
                <button
                  type="button"
                  onClick={() => {
                    setActiveDropdown(null);
                    navigate(ROUTES.app.settings);
                  }}
                >
                  <Settings size={17} />
                  <span>Settings</span>
                </button>
              </div>

              <div className="app-profile-dropdown__divider" />

              <div className="app-profile-dropdown__menu">
                <button
                  type="button"
                  className="is-logout"
                  onClick={handleLogout}
                >
                  <LogOut size={17} />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
