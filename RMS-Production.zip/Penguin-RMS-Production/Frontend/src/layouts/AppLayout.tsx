import { Suspense, useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";

import PageLoader from "@/components/common/spinner-loader";
import { useBreakpoint } from "@/hooks/useBreakpoint";
import { Header } from "./Header";
import { Sidebar, type SidebarState } from "./Sidebar";

/**
 * Responsive shell
 *
 *  desktop (>=1200) : full sidebar (260px) <-> icon rail (72px) toggle
 *  tablet (768-1199): icon rail always visible, toggle opens a full drawer
 *  mobile (<768)    : sidebar hidden, toggle opens a full drawer
 */
export function AppLayout() {
  const breakpoint = useBreakpoint();
  const { pathname } = useLocation();

  const [collapsed, setCollapsed] = useState(false); // desktop only
  const [drawerOpen, setDrawerOpen] = useState(false); // tablet + mobile

  // Close the drawer on navigation or when the screen size class changes.
  useEffect(() => {
    setDrawerOpen(false);
  }, [pathname, breakpoint]);

  // Esc closes the drawer.
  useEffect(() => {
    if (!drawerOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setDrawerOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawerOpen]);

  const overlay = breakpoint !== "desktop" && drawerOpen;

  // Lock page scroll while the drawer is open.
  useEffect(() => {
    document.body.classList.toggle("no-scroll", overlay);
    return () => document.body.classList.remove("no-scroll");
  }, [overlay]);

  let sidebarState: SidebarState;
  let mainOffset: "full" | "rail" | "none";

  if (breakpoint === "desktop") {
    sidebarState = collapsed ? "rail" : "expanded";
    mainOffset = collapsed ? "rail" : "full";
  } else if (breakpoint === "tablet") {
    sidebarState = drawerOpen ? "expanded" : "rail";
    mainOffset = "rail";
  } else {
    sidebarState = drawerOpen ? "expanded" : "hidden";
    mainOffset = "none";
  }

  const handleToggle = () => {
    if (breakpoint === "desktop") setCollapsed((c) => !c);
    else setDrawerOpen((o) => !o);
  };

  return (
    <div className="app-shell">
      <Sidebar
        state={sidebarState}
        overlay={overlay}
        onClose={() => setDrawerOpen(false)}
      />

      {overlay && (
        <div className="app-backdrop" onClick={() => setDrawerOpen(false)} aria-hidden="true" />
      )}

      <div className="app-main" data-offset={mainOffset}>
        <Header onToggleSidebar={handleToggle} showLogo={breakpoint === "mobile"} />
        <main className="app-content">
          <Suspense fallback={<PageLoader />}>
            <Outlet />
          </Suspense>
        </main>
      </div>
    </div>
  );
}
