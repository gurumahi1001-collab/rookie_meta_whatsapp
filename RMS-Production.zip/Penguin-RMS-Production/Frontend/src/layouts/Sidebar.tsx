
import { Link, NavLink, useNavigate } from "react-router-dom";
import { LogOut, UserRound, X } from "lucide-react";

import { Logo } from "@/components/common/Logo";
import { CommonTooltip } from "@/components/common/ui/tooltip";

import { ROUTES } from "@/routes/routePaths";
import { removeToken } from "@/utils/token";
import { sidebarSections } from "./sidebarConfig";

export type SidebarState = "expanded" | "rail" | "hidden";

export interface SidebarUser {
  name: string;
  role: string;
  email: string;
  avatarUrl?: string;
}

interface SidebarProps {
  state: SidebarState;
  overlay: boolean;
  onClose: () => void;
  onLogout?: () => void;
  user?: SidebarUser;
}

export function Sidebar({
  state,
  overlay,
  onClose,
  onLogout,
  user,
}: SidebarProps) {
  const navigate = useNavigate();

  const isRail = state === "rail";

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
      return;
    }

    removeToken();
    navigate(ROUTES.auth.login, { replace: true });
  };

  return (
    <aside
      className="app-sidebar"
      data-state={state}
      data-overlay={overlay}
      aria-label="Main navigation"
    >
      {/* Brand */}
      <div className="app-sidebar__brand">
        <Link
          to={ROUTES.app.dashboard}
          className="app-sidebar__brand-link"
          aria-label="Go to dashboard"
        >
          <Logo showText={!isRail} />
        </Link>

        {overlay && (
          <button
            type="button"
            className="app-sidebar__close"
            onClick={onClose}
            aria-label="Close menu"
          >
            <X size={20} />
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav
        className="app-sidebar__nav"
        aria-label="Sidebar navigation"
      >
        {sidebarSections.map((section) => (
          <div key={section.title} className="app-sidebar__group">
            <div className="app-sidebar__section">
              {section.title}
            </div>

            <div className="app-sidebar__items">
              {section.items.map(
                ({ label, to, icon: Icon, badge }) => (
                  <CommonTooltip
                    key={to}
                    content={label}
                    placement="right"
                    disabled={!isRail}
                  >
                    <NavLink
                      to={to}
                      onClick={overlay ? onClose : undefined}
                      aria-label={isRail ? label : undefined}
                      className={({ isActive }) =>
                        `app-nav__link${isActive ? " is-active" : ""}`
                      }
                    >
                      <span className="app-nav__icon">
                        <Icon size={19} strokeWidth={1.8} />
                      </span>

                      <span className="app-nav__label">
                        {label}
                      </span>

                      {badge !== undefined && (
                        <span
                          className="app-nav__badge"
                          aria-label={`${badge} notifications`}
                        >
                          {badge}
                        </span>
                      )}
                    </NavLink>
                  </CommonTooltip>
                )
              )}
            </div>
          </div>
        ))}
      </nav>

      {/* User profile */}
      <div className="app-sidebar__footer">
        <div className="app-sidebar__profile">
          <CommonTooltip
            content={user?.name || "Super Admin"}
            placement="right"
            disabled={!isRail}
          >
            <div className="app-sidebar__avatar">
              {user?.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name || "User avatar"}
                />
              ) : (
                <UserRound size={20} strokeWidth={1.8} />
              )}
            </div>
          </CommonTooltip>

          <div className="app-sidebar__user-details">
            <span className="app-sidebar__user-name">
              {user?.name || "Super Admin"}
            </span>

            <span className="app-sidebar__user-email">
              {user?.email || "admin@example.com"}
            </span>
          </div>

          <CommonTooltip
            content="Logout"
            placement="right"
            disabled={!isRail}
          >
            <button
              type="button"
              className="app-sidebar__logout"
              onClick={handleLogout}
              aria-label="Logout"
            >
              <LogOut size={18} />
            </button>
          </CommonTooltip>
        </div>
      </div>
    </aside>
  );
}
