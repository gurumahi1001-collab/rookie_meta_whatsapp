import { getToken, setToken, removeToken } from "@/utils/token";
import { reconnectRealtime } from "@/lib/realtime";

const API_BASE = (import.meta.env.VITE_API_BASE_URL || "http://localhost:4000/api/v1").replace(/\/$/, "");
let refreshPromise: Promise<string | null> | null = null;

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(message: string, status: number, code = "API_ERROR", details?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

type ApiEnvelope<T> = { success: boolean; data: T; error?: { message?: string; code?: string; details?: unknown }; message?: string };

async function refreshAccessToken(): Promise<string | null> {
  if (refreshPromise) return refreshPromise;
  refreshPromise = (async () => {
    try {
      const response = await fetch(`${API_BASE}/auth/refresh`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: "{}" });
      if (!response.ok) { removeToken(); return null; }
      const result = (await response.json()) as ApiEnvelope<{ accessToken: string }>;
      const token = result.data?.accessToken;
      if (!token) { removeToken(); return null; }
      setToken(token, Boolean(localStorage.getItem("app_remember")));
      reconnectRealtime();
      return token;
    } catch {
      return null;
    } finally {
      refreshPromise = null;
    }
  })();
  return refreshPromise;
}

async function request<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const headers = new Headers(init.headers || {});
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  headers.set("Accept", "application/json");
  const response = await fetch(`${API_BASE}${path.startsWith("/") ? path : `/${path}`}`, { ...init, headers, credentials: "include" });
  const refreshableAuthRequest = !["/auth/login", "/auth/refresh", "/auth/logout"].includes(path);
  if (response.status === 401 && retry && refreshableAuthRequest) {
    const nextToken = await refreshAccessToken();
    if (nextToken) return request<T>(path, init, false);
  }
  const payload = (await response.json().catch(() => ({}))) as ApiEnvelope<T>;
  if (!response.ok || payload.success === false) {
    throw new ApiError(payload.error?.message || payload.message || `Request failed (${response.status}).`, response.status, payload.error?.code, payload.error?.details);
  }
  return payload.data as T;
}

export const api = {
  get: <T>(path: string, params?: Record<string, string | number | boolean | undefined>) => {
    const query = new URLSearchParams();
    Object.entries(params || {}).forEach(([key, value]) => { if (value !== undefined && value !== "") query.set(key, String(value)); });
    const queryString = query.toString();
    return request<T>(`${path}${queryString ? `?${queryString}` : ""}`);
  },
  post: <T>(path: string, body: unknown) => request<T>(path, { method: "POST", body: JSON.stringify(body) }),
  put: <T>(path: string, body: unknown) => request<T>(path, { method: "PUT", body: JSON.stringify(body) }),
  patch: <T>(path: string, body: unknown) => request<T>(path, { method: "PATCH", body: JSON.stringify(body) }),
  delete: <T>(path: string) => request<T>(path, { method: "DELETE" }),
  upload: <T>(path: string, form: FormData) => request<T>(path, { method: "POST", body: form }),
};

export function getApiBaseUrl() { return API_BASE; }
