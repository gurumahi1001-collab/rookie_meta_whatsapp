import { io, type Socket } from "socket.io-client";
import { getToken } from "@/utils/token";

let socket: Socket | null = null;

export function connectRealtime() {
  const token = getToken();
  if (!token) return null;
  if (!socket) {
    socket = io(import.meta.env.VITE_SOCKET_URL || import.meta.env.VITE_API_ORIGIN || "http://localhost:4000", {
      autoConnect: false,
      transports: ["websocket", "polling"],
      withCredentials: true,
      auth: { token },
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 800,
      reconnectionDelayMax: 10000,
    });
  } else {
    socket.auth = { token };
  }
  if (!socket.connected) socket.connect();
  return socket;
}

export function reconnectRealtime() {
  if (!socket) return connectRealtime();
  socket.disconnect();
  socket.auth = { token: getToken() };
  socket.connect();
  return socket;
}

export function getRealtimeSocket() {
  return socket;
}

export function disconnectRealtime() {
  socket?.disconnect();
  socket = null;
}
