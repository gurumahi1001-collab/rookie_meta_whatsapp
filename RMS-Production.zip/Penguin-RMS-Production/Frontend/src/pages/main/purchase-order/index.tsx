import { useEffect, useMemo, useState } from "react";
import {
  Plus,
  Search,
  ShoppingCart,
  RefreshCw,
  Clock3,
  CheckCircle2,
  AlertCircle,
  Eye,
  FileBarChart,
} from "lucide-react";

import "./PurchaseOrdersPage.scss";

import {
  type TableColumn,
  CommonDataTable,
} from "@/components/common/data-table";

import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import CommonButton from "@/components/common/ui/button/CommonButton";
import { CommonTooltip } from "@/components/common/ui/tooltip";

import CreatePurchaseOrderDrawer, {
  type PurchaseOrderFormData,
  type PurchaseOrderItem,
} from "./modal/CreatePurchaseOrders";

import PurchaseOrderDetailsPage from "./view-orders/PurchaseOrderDetailsPage";
import { useLiveResource } from "@/hooks/useLiveResource";

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplier: string;
  style: string;
  articleSku: string;
  description: string;
  orderedQty: number;
  items: PurchaseOrderItem[];
  size: string;
  color: string;
  batch: string;
  totalReworks: number;
  inProgress: number;
  completed: number;
  irreparable: number;
  deliveryDate: string;
  status: "Active" | "Completed" | "On Hold";
}

type DetailsTab = "overview" | "reworks" | "quality";

interface PurchaseOrdersPageProps {
  onCreatePurchaseOrder?: () => void;
  onViewDetails?: (order: PurchaseOrder) => void;
  onViewScorecard?: (order: PurchaseOrder) => void;
}

export default function PurchaseOrdersPage({}: PurchaseOrdersPageProps) {
  const purchaseOrderResource = useLiveResource<PurchaseOrder>({
    endpoint: "/purchase-orders",
    resource: "purchase-orders",
  });
  const orders = purchaseOrderResource.data;

  const [search, setSearch] = useState("");
  const [showCreateDrawer, setShowCreateDrawer] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<PurchaseOrder | null>(
    null,
  );

  const [initialDetailsTab, setInitialDetailsTab] =
    useState<DetailsTab>("overview");

  useEffect(() => {
    if (!selectedOrder) return;
    const latest = orders.find((item) => item.id === selectedOrder.id);
    if (latest) setSelectedOrder(latest);
    else setSelectedOrder(null);
  }, [orders, selectedOrder]);

  const handleCreatePurchaseOrder = async (formData: PurchaseOrderFormData) => {
    const safeText = (value: unknown): string => String(value ?? "").trim();

    const items: PurchaseOrderItem[] = (
      Array.isArray(formData.items) ? formData.items : []
    ).map((item) => ({
      size: safeText(item.size),
      color: safeText(item.color),
      orderedQty: safeText(item.orderedQty),
    }));

    const orderedQty = items.reduce(
      (total, item) => total + (Number(item.orderedQty) || 0),
      0,
    );

    const uniqueSizes = [
      ...new Set(items.map((item) => item.size).filter(Boolean)),
    ];

    const uniqueColors = [
      ...new Set(items.map((item) => item.color).filter(Boolean)),
    ];

    try {
      const created = await purchaseOrderResource.create({
        poNumber: safeText(formData.poNumber),
        supplier: safeText(formData.supplier),
        style: safeText(formData.style),
        articleSku: safeText(formData.articleSku),
        description: safeText(formData.description),
        orderedQty,
        items,
        size: uniqueSizes.join(", "),
        color: uniqueColors.join(", "),
        batch: safeText(formData.batch),
        deliveryDate: safeText(formData.deliveryDate) || null,
        status: "Active",
      } as Partial<PurchaseOrder>);
      setSearch("");
      setShowCreateDrawer(false);
      setSelectedOrder(created);
      setInitialDetailsTab("overview");
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "Unable to save purchase order.");
    }
  };

  const handleViewDetails = (order: PurchaseOrder) => {
    setSelectedOrder(order);
    setInitialDetailsTab("overview");
  };

  const handleViewScorecard = (order: PurchaseOrder) => {
    setSelectedOrder(order);
    setInitialDetailsTab("quality");
  };

  const handleBackToList = () => {
    setSelectedOrder(null);
  };

  const totalOrders = orders.length;

  const totalReworks = orders.reduce(
    (total, order) => total + order.totalReworks,
    0,
  );

  const totalInProgress = orders.reduce(
    (total, order) => total + order.inProgress,
    0,
  );

  const totalCompleted = orders.reduce(
    (total, order) => total + order.completed,
    0,
  );

  const totalIrreparable = orders.reduce(
    (total, order) => total + order.irreparable,
    0,
  );

  const filteredOrders = useMemo(() => {
    const searchValue = search.trim().toLowerCase();

    if (!searchValue) return orders;

    return orders.filter((order) => {
      const itemValues = order.items.flatMap((item) => [
        item.size,
        item.color,
        item.orderedQty,
      ]);

      const values = [
        order.poNumber,
        order.supplier,
        order.style,
        order.articleSku,
        order.description,
        order.batch,
        ...itemValues,
      ];

      return values.some((value) =>
        String(value ?? "")
          .toLowerCase()
          .includes(searchValue),
      );
    });
  }, [search, orders]);

  const columns: TableColumn<PurchaseOrder>[] = [
    {
      field: "poNumber",
      header: "PO Number",
      sortable: true,
      minWidth: "125px",
      body: (row) => <span className="po-number">{row.poNumber}</span>,
    },
    {
      field: "supplier",
      header: "Supplier",
      sortable: true,
      minWidth: "155px",
      body: (row) => <span className="po-supplier">{row.supplier}</span>,
    },
    {
      field: "style",
      header: "Style / SKU",
      sortable: true,
      minWidth: "105px",
      body: (row) => (
        <div className="po-style-cell">
          <span>{row.style}</span>
          <small>{row.articleSku}</small>
        </div>
      ),
    },
    /*     {
      field: "orderedQty",
      header: "Ordered Qty",
      sortable: true,
      align: "center",
      minWidth: "105px",
      body: (row) => (
        <strong>{Number(row.orderedQty || 0).toLocaleString("en-IN")}</strong>
      ),
    }, */
    {
      field: "batch",
      header: "Batch / Lot",
      sortable: true,
      minWidth: "120px",
    },
    {
      field: "totalReworks",
      header: "Total Reworks",
      sortable: true,
      align: "center",
      minWidth: "100px",
      body: (row) => (
        <span className="po-count po-count--blue">{row.totalReworks}</span>
      ),
    },
    {
      field: "inProgress",
      header: "In Progress",
      sortable: true,
      align: "center",
      minWidth: "95px",
      body: (row) => (
        <span className="po-count po-count--warning">{row.inProgress}</span>
      ),
    },
    {
      field: "completed",
      header: "Completed",
      sortable: true,
      align: "center",
      minWidth: "90px",
      body: (row) => (
        <span className="po-count po-count--success">{row.completed}</span>
      ),
    },
    {
      field: "irreparable",
      header: "Irreparable",
      sortable: true,
      align: "center",
      minWidth: "95px",
      body: (row) => (
        <span className="po-count po-count--danger">{row.irreparable}</span>
      ),
    },
    {
      field: "deliveryDate",
      header: "Delivery Date",
      sortable: true,
      minWidth: "110px",
    },
    {
      field: "status",
      header: "Status",
      sortable: true,
      minWidth: "90px",
      body: (row) => (
        <span
          className={`po-status po-status--${row.status
            .toLowerCase()
            .replace(" ", "-")}`}
        >
          {row.status}
        </span>
      ),
    },
    {
      field: "id",
      header: "Actions",
      minWidth: "120px",
      align: "center",
      body: (row) => (
        <div className="po-actions">
          <CommonTooltip content="View Details" placement="left">
            <button
              type="button"
              className="po-action-icon po-action-icon--view"
              onClick={() => handleViewDetails(row)}
              aria-label="View Details"
            >
              <Eye size={17} />
            </button>
          </CommonTooltip>

          <CommonTooltip content="View Scorecard" placement="left">
            <button
              type="button"
              className="po-action-icon po-action-icon--scorecard"
              onClick={() => handleViewScorecard(row)}
              aria-label="View Scorecard"
            >
              <FileBarChart size={17} />
            </button>
          </CommonTooltip>
        </div>
      ),
    },
  ];

  const summaryCards = [
    {
      label: "Total Purchase Orders",
      value: totalOrders,
      description: "Active supplier orders",
      icon: ShoppingCart,
      color: "primary",
    },
    {
      label: "Total Reworks",
      value: totalReworks,
      description: "Across all batches",
      icon: RefreshCw,
      color: "info",
    },
    {
      label: "In Progress",
      value: totalInProgress,
      description: "Active floor repairs",
      icon: Clock3,
      color: "warning",
    },
    {
      label: "Completed",
      value: totalCompleted,
      description: "Passed & packed",
      icon: CheckCircle2,
      color: "success",
    },
    {
      label: "Irreparable",
      value: totalIrreparable,
      description: "Scrapped / rejected",
      icon: AlertCircle,
      color: "danger",
    },
  ];

  return (
    <div className="purchase-orders-page">
      {selectedOrder ? (
        <PurchaseOrderDetailsPage
          order={selectedOrder}
          onBack={handleBackToList}
          initialTab={initialDetailsTab}
          key={`${selectedOrder.id}-${initialDetailsTab}`}
        />
      ) : (
        <>
          <CommonPageHeader
            icon={<ShoppingCart />}
            title="Purchase Orders Management"
            subtitle="Manage supplier purchase orders, line items, batches, and delivery tracking."
            rightContent={
              <CommonButton
                variant="primary"
                size="md"
                leftIcon={<Plus size={16} />}
                onClick={() => setShowCreateDrawer(true)}
                className="po-create-btn"
              >
                Create Purchase Order
              </CommonButton>
            }
          />

          <div className="row g-3 po-summary-row">
            {summaryCards.map((card) => {
              const Icon = card.icon;

              return (
                <div
                  className="col-12 col-sm-6 col-lg-4 col-xl"
                  key={card.label}
                >
                  <div
                    className={`po-summary-card po-summary-card--${card.color}`}
                  >
                    <div className="po-summary-top">
                      <span className="po-summary-label">{card.label}</span>
                      <span className="po-summary-icon">
                        <Icon size={17} />
                      </span>
                    </div>

                    <h3 className="po-summary-value">{card.value}</h3>

                    <p className="po-summary-description">{card.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="po-search-card">
            <div className="po-search-wrapper">
              <Search size={16} className="po-search-icon" />

              <input
                type="search"
                className="form-control po-search-input"
                placeholder="Search PO number, supplier, style, size..."
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />

              {search && (
                <CommonButton
                  variant="ghost"
                  size="sm"
                  onClick={() => setSearch("")}
                  className="po-search-clear"
                  aria-label="Clear search"
                >
                  Clear
                </CommonButton>
              )}
            </div>
          </div>

          <div className="po-table-card">
            <CommonDataTable
              data={filteredOrders}
              columns={columns}
              dataKey="id"
              paginator
              rows={8}
              rowsPerPageOptions={[5, 8, 10, 25]}
              stripedRows={false}
              showGridlines={false}
              size="small"
              emptyMessage="No purchase orders found"
              className="po-common-table"
            />
          </div>
        </>
      )}

      <CreatePurchaseOrderDrawer
        show={showCreateDrawer}
        onClose={() => setShowCreateDrawer(false)}
        onSubmit={handleCreatePurchaseOrder}
      />
    </div>
  );
}
