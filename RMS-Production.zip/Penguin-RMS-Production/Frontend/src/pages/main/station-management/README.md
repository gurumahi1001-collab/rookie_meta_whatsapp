# Station Management & Operator Work Queue

This module was created against the uploaded `src` project structure and reuses the existing common components:
- `CommonButton`
- `CommonModal`
- `CommonInput`
- `CommonSelect`
- `CommonTextArea`
- `CommonPageHeader`

## Included workflow
1. Station configuration: create/edit, factory, category, location, capacity, operators, active/inactive.
2. Operator management: create/edit, employee details, eligible stations, active/inactive.
3. Station work queue: station selector, QR/PO/style search, status filters and queue cards.
4. Operator workbench: selected garment details, defect image placeholder, activity history, repair details, remarks, materials and status update.
5. QR scanning: reusable `ReusableQRScanner` with camera scanning and manual QR entry. Reuse this component in QA Inspection by rendering it and handling `onDetected`.
6. Capacity: queue count compared with configured capacity. Current demo threshold: below 80% Normal Load, 80%-99% High Queue, 100%+ Capacity Reached.
7. Performance: counts derived from current work-order transaction records. Average processing time is shown only when start and completion timestamps exist.

## Install
Copy the `station-management` folder into:
`src/pages/main/station-management`

The QR scanner component is deliberately inside this module at:
`src/pages/main/station-management/components/ReusableQRScanner.tsx`
For future reuse, move it to a shared location such as `src/components/common/qr-scanner/ReusableQRScanner.tsx` and update imports, or import it from this module until then.

## Route integration
Your uploaded `routePaths.ts` already contains:
`ROUTES.app.stationManagement`

In `src/routes/routeConfig.tsx`, add:
```tsx
const StationManagementPage = lazy(
  () => import("@/pages/main/station-management"),
);
```
Then add inside `protectedRoutes`:
```tsx
{
  path: ROUTES.app.stationManagement,
  element: <StationManagementPage />,
},
```
Your uploaded sidebar configuration already contains the Station Management navigation item.

## Existing data relationship
The module uses its own typed static demo data in `data/stationData.ts`. Station IDs and operator IDs are linked separately. Inactive stations/operators remain in the records; inactive entries are excluded from new assignment choices.

## Notes
- This is a frontend static-data prototype. Changes live in React state and reset on page refresh; connect API calls/backend persistence when endpoints are ready.
- Camera scanning requires browser camera permission and a secure context (HTTPS or localhost). Manual QR entry is provided as a fallback.
- The QR parser searches exact QR ID, garment ID, or rework ID from the work-order data.
- Workload thresholds are demo defaults because the functional requirement did not specify numeric thresholds.
- QA approval/rejection is represented in the work-order status history for UI flow demonstration. A dedicated QA Inspection module should own actual QA decisions in the integrated production workflow.
