export type RecordStatus = "Active" | "Inactive";
export type QueueStatus = "Assigned" | "In Progress" | "Sent to QA" | "QA Passed" | "QA Rejected" | "Packed" | "Scrap";

export interface Station {
  id: string;
  code: string;
  name: string;
  factory: string;
  category: string;
  location: string;
  capacity: number;
  operatorIds: string[];
  status: RecordStatus;
  remarks: string;
}

export interface Operator {
  id: string;
  name: string;
  employeeCode: string;
  role: string;
  phone: string;
  stationIds: string[];
  status: RecordStatus;
}

export interface WorkOrder {
  id: string;
  reworkId: string;
  qrId: string;
  poNumber: string;
  garmentId: string;
  styleNumber: string;
  size: string;
  defectCategory: string;
  severity: "Minor" | "Major" | "Critical";
  stationId: string;
  operatorId: string;
  status: QueueStatus;
  description: string;
  defectImage?: string;
  registeredAt: string;
  startedAt?: string;
  completedAt?: string;
  submittedAt?: string;
  repairDetails: string;
  repairRemarks: string;
  materialsUsed: string;
  history: { title: string; description: string; date: string }[];
}
