import { useEffect, useState } from "react";
import { UserRound } from "lucide-react";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import type { Operator, Station } from "../types/stationTypes";

interface Props {
  show: boolean;
  value: Operator | null;
  stations: Station[];
  onClose: () => void;
  onSave: (item: Operator) => void;
}
export default function OperatorFormModal({
  show,
  value,
  stations,
  onClose,
  onSave,
}: Props) {
  const [form, setForm] = useState<Operator>({
    id: "",
    employeeCode: "",
    name: "",
    role: "Station Operator",
    phone: "",
    stationIds: [],
    status: "Active",
  });
  const update = (key: keyof Operator, next: string | string[]) =>
    setForm((p) => ({ ...p, [key]: next }));
  useEffect(() => {
    if (show)
      setForm(
        value
          ? { ...value }
          : {
              id: `OP-${Date.now()}`,
              employeeCode: "",
              name: "",
              role: "Station Operator",
              phone: "",
              stationIds: [],
              status: "Active",
            },
      );
  }, [show, value]);
  const toggle = (id: string) =>
    update(
      "stationIds",
      form.stationIds.includes(id)
        ? form.stationIds.filter((x) => x !== id)
        : [...form.stationIds, id],
    );
  const save = () => {
    if (!form.name.trim() || !form.employeeCode.trim()) return;
    onSave({
      ...form,
      name: form.name.trim(),
      employeeCode: form.employeeCode.trim().toUpperCase(),
    });
  };
  return (
    <CommonModal
      show={show}
      onClose={onClose}
      variant="drawer"
      size="md"
      title={value ? "Edit Operator" : "Add Operator"}
      subtitle="Maintain operator details and station eligibility."
      headerIcon={<UserRound size={18} />}
      footer={
        <>
          <CommonButton variant="outline" onClick={onClose}>
            Cancel
          </CommonButton>
          <CommonButton
            onClick={save}
            disabled={!form.name.trim() || !form.employeeCode.trim()}
          >
            {value ? "Update Operator" : "Save Operator"}
          </CommonButton>
        </>
      }
    >
      <div className="row g-3">
        <div className="col-md-6">
          <CommonInput
            label="Operator Name"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            required
            placeholder="Full name"
          />
        </div>
        <div className="col-md-6">
          <CommonInput
            label="Employee Code"
            value={form.employeeCode}
            onChange={(e) => update("employeeCode", e.target.value)}
            required
            placeholder="EMP-001"
          />
        </div>
        <div className="col-md-6">
          <CommonInput
            label="Role"
            value={form.role}
            onChange={(e) => update("role", e.target.value)}
            placeholder="Station Operator"
          />
        </div>
        <div className="col-md-6">
          <CommonInput
            label="Phone"
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="Contact number"
          />
        </div>
        <div className="col-md-6">
          <CommonSelect
            label="Status"
            value={form.status}
            onChange={(v) => update("status", String(v ?? "Active"))}
            options={["Active", "Inactive"].map((x) => ({
              label: x,
              value: x,
            }))}
          />
        </div>
        <div className="col-12">
          <label className="sm-form-label">Eligible Stations</label>
          <div className="sm-check-grid">
            {stations.map((st) => (
              <label key={st.id} className="sm-check-option">
                <input
                  type="checkbox"
                  checked={form.stationIds.includes(st.id)}
                  onChange={() => toggle(st.id)}
                  disabled={st.status !== "Active"}
                />
                <span>
                  <b>{st.name}</b>
                  <small>{st.code}</small>
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </CommonModal>
  );
}
