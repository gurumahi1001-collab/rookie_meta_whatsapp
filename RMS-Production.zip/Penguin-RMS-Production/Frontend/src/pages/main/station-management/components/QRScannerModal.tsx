import { QrCode } from "lucide-react";

import CommonModal from "@/components/common/ui/modal/CommonModal";
import ReusableQRScanner from "./ReusableQRScanner";

export default function QRScannerModal({
  show,
  onClose,
  onDetected,
}: {
  show: boolean;
  onClose: () => void;
  onDetected: (value: string) => void;
}) {
  return (
    <CommonModal
      show={show}
      onClose={onClose}
      title="Scan Garment QR Code"
      subtitle="Scan a garment label or enter its QR ID manually."
      headerIcon={<QrCode size={18} />}
      size="md"
    >
      <ReusableQRScanner
        onClose={onClose}
        onDetected={onDetected}
      />
    </CommonModal>
  );
}