import { useEffect, useId, useRef, useState } from "react";
import {
  AlertCircle,
  Camera,
  CameraOff,
  CheckCircle2,
  Keyboard,
  QrCode,
  ScanLine,
} from "lucide-react";
import { Html5Qrcode, Html5QrcodeScannerState } from "html5-qrcode";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";

import "./QRScannerModal.scss";

interface Props {
  onDetected: (value: string) => void;
  onClose: () => void;
}

type CameraMode = "environment" | "user";

// =====================================================
// HELPERS
// =====================================================

const isScannerRunning = (scanner: Html5Qrcode | null): boolean => {
  if (!scanner) return false;

  try {
    const state = scanner.getState();

    return (
      state === Html5QrcodeScannerState.SCANNING ||
      state === Html5QrcodeScannerState.PAUSED
    );
  } catch {
    return false;
  }
};

const getFriendlyError = (err: unknown): string => {
  const name =
    typeof err === "object" && err !== null && "name" in err
      ? String((err as { name?: unknown }).name)
      : "";

  const message = String(
    typeof err === "object" && err !== null && "message" in err
      ? (err as { message?: unknown }).message
      : err,
  );

  if (typeof window !== "undefined" && !window.isSecureContext) {
    return "Camera needs a secure connection. Please open this page using HTTPS (or localhost).";
  }

  if (
    name === "NotAllowedError" ||
    name === "PermissionDeniedError" ||
    /permission|denied|notallowed/i.test(message)
  ) {
    return "Camera permission is blocked. Please allow camera access in your browser/site settings and try again.";
  }

  if (
    name === "NotFoundError" ||
    name === "OverconstrainedError" ||
    /no camera|not found|requested device/i.test(message)
  ) {
    return "No matching camera was found on this device. Try the other camera.";
  }

  if (
    name === "NotReadableError" ||
    name === "AbortError" ||
    /in use|could not start|not readable/i.test(message)
  ) {
    return "Camera is being used by another app or tab. Close it and try again.";
  }

  return "Unable to access the selected camera. Please allow camera permission or try another camera.";
};

export default function ReusableQRScanner({
  onDetected,
  onClose,
}: Props) {
  const [manualValue, setManualValue] = useState("");
  const [error, setError] = useState("");
  const [starting, setStarting] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraMode, setCameraMode] =
    useState<CameraMode>("environment");

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const handledRef = useRef(false);
  const startingRef = useRef(false);
  const mountedRef = useRef(false);

  const startTaskRef = useRef<Promise<void> | null>(null);
  const stopTaskRef = useRef<Promise<void> | null>(null);

  const generatedId = useId();
  const elementId = `penguin-qr-reader-${generatedId.replace(/:/g, "")}`;

  // =====================================================
  // STOP SCANNER SAFELY
  // =====================================================

  const stopScanner = async () => {
    if (stopTaskRef.current) {
      return stopTaskRef.current;
    }

    const task = (async () => {
      // Wait for initialization to finish.
      if (startTaskRef.current) {
        try {
          await startTaskRef.current;
        } catch {
          // Initialization may have failed.
        }
      }

      const scanner = scannerRef.current;

      if (!scanner) {
        if (mountedRef.current) {
          setIsScanning(false);
          setStarting(false);
        }
        return;
      }

      try {
        if (isScannerRunning(scanner)) {
          await scanner.stop();
        }
      } catch {
        // Ignore already stopped scanner.
      }

      try {
        scanner.clear();
      } catch {
        // Ignore DOM cleanup errors.
      } finally {
        if (scannerRef.current === scanner) {
          scannerRef.current = null;
        }

        if (mountedRef.current) {
          setIsScanning(false);
          setStarting(false);
        }
      }
    })();

    stopTaskRef.current = task;

    try {
      await task;
    } finally {
      if (stopTaskRef.current === task) {
        stopTaskRef.current = null;
      }
    }
  };

  // =====================================================
  // START SCANNER
  // =====================================================

  const startScanner = async (
    selectedCamera: CameraMode = cameraMode,
  ) => {
    if (
      scannerRef.current ||
      startingRef.current ||
      stopTaskRef.current ||
      handledRef.current
    ) {
      return;
    }

    setError("");

    startingRef.current = true;
    setStarting(true);

    const scanner = new Html5Qrcode(elementId);

    scannerRef.current = scanner;

    // NOTE: qrbox size (220) should match .sm-qr-scan-box in the SCSS.
    const scanConfig = {
      fps: 10,
      qrbox: {
        width: 220,
        height: 220,
      },
      aspectRatio: 1,
    };

    const onScanSuccess = (decodedText: string) => {
      if (handledRef.current) return;

      const value = decodedText.trim();

      if (!value) return;

      handledRef.current = true;

      // Stop camera before notifying parent.
      void (async () => {
        await stopScanner();

        if (mountedRef.current) {
          onDetected(value);
        }
      })();
    };

    const onScanFailure = () => undefined;

    let started = false;

    const startTask = (async () => {
      try {
        // Attempt 1: use facingMode (back camera by default).
        try {
          await scanner.start(
            { facingMode: selectedCamera },
            scanConfig,
            onScanSuccess,
            onScanFailure,
          );
          started = true;
        } catch (firstError) {
          console.warn(
            "facingMode start failed, trying camera list",
            firstError,
          );

          // Attempt 2: pick a camera from the device list.
          const cameras = await Html5Qrcode.getCameras();

          if (!cameras || cameras.length === 0) {
            throw firstError;
          }

          const backRegex = /back|rear|environment/i;
          const frontRegex = /front|user|face|selfie/i;

          let picked =
            selectedCamera === "environment"
              ? cameras.find((c) => backRegex.test(c.label))
              : cameras.find((c) => frontRegex.test(c.label));

          if (!picked) {
            picked =
              selectedCamera === "environment"
                ? cameras[cameras.length - 1]
                : cameras[0];
          }

          await scanner.start(
            picked.id,
            scanConfig,
            onScanSuccess,
            onScanFailure,
          );
          started = true;
        }

        if (!mountedRef.current) return;

        setIsScanning(true);
      } catch (err) {
        console.error("QR scanner initialization failed:", err);

        if (mountedRef.current) {
          setError(getFriendlyError(err));
        }

        throw err;
      } finally {
        startingRef.current = false;

        if (mountedRef.current) {
          setStarting(false);
        }
      }
    })();

    startTaskRef.current = startTask;

    try {
      await startTask;
    } catch {
      // Error is displayed in the UI.
    } finally {
      if (startTaskRef.current === startTask) {
        startTaskRef.current = null;
      }
    }

    // Release scanner only if initialization failed.
    if (!started && scannerRef.current === scanner) {
      await stopScanner();
      return;
    }

    // Handle modal closing during initialization.
    if (!mountedRef.current) {
      await stopScanner();
    }
  };

  // =====================================================
  // SWITCH CAMERA
  // =====================================================

  const changeCamera = async (nextCamera: CameraMode) => {
    if (
      startingRef.current ||
      stopTaskRef.current ||
      handledRef.current ||
      cameraMode === nextCamera
    ) {
      return;
    }

    const shouldRestart = isScanning;

    setError("");

    // Release currently active camera.
    await stopScanner();

    if (!mountedRef.current) return;

    // Update selected camera.
    setCameraMode(nextCamera);

    // Restart only when the scanner was already active.
    if (shouldRestart && !handledRef.current) {
      await startScanner(nextCamera);
    }
  };

  // =====================================================
  // COMPONENT LIFECYCLE
  // =====================================================

  useEffect(() => {
    mountedRef.current = true;

    return () => {
      mountedRef.current = false;
      void stopScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // =====================================================
  // MANUAL QR ENTRY
  // =====================================================

  const submitManual = async () => {
    const value = manualValue.trim();

    if (
      !value ||
      handledRef.current ||
      startingRef.current
    ) {
      return;
    }

    handledRef.current = true;

    await stopScanner();

    if (mountedRef.current) {
      onDetected(value);
    }
  };

  // =====================================================
  // CLOSE MODAL
  // =====================================================

  const handleClose = async () => {
    await stopScanner();

    if (mountedRef.current) {
      onClose();
    }
  };

  // =====================================================
  // UI
  // =====================================================

  return (
    <div className="sm-qr-scanner">

      {/* CAMERA PREVIEW */}

      <div className="sm-qr-camera-card">

        {/* CAMERA HEADER */}

        <div className="sm-qr-camera-top">
          <div className="sm-qr-camera-label">
            <span
              className={`sm-qr-status-dot ${
                isScanning ? "active" : ""
              }`}
            />

            {isScanning
              ? "Camera is active"
              : starting
                ? "Starting camera..."
                : "Camera preview"}
          </div>

          <span className="sm-qr-camera-badge">
            <ScanLine size={13} />
            QR SCAN
          </span>
        </div>

        {/* CAMERA READER */}

        <div className="sm-qr-reader-wrap">

          <div
            id={elementId}
            className={`sm-qr-reader ${
              isScanning ? "is-active" : ""
            }`}
          />

          {/* SCANNING OVERLAY */}

          {isScanning && (
            <div className="sm-qr-scan-overlay">
              <div className="sm-qr-scan-box">
                <span className="scan-corner top-left" />
                <span className="scan-corner top-right" />
                <span className="scan-corner bottom-left" />
                <span className="scan-corner bottom-right" />

                <span className="sm-qr-scan-line" />
              </div>

              <div className="sm-qr-scan-hint">
                <span className="sm-qr-scan-hint-dot" />
                Scanning... align the QR code inside the frame
              </div>
            </div>
          )}

          {/* PLACEHOLDER */}

          {!isScanning && (
            <div className="sm-qr-placeholder">
              <div className="sm-qr-frame">
                <span className="corner top-left" />
                <span className="corner top-right" />
                <span className="corner bottom-left" />
                <span className="corner bottom-right" />

                {starting ? (
                  <span className="sm-qr-spinner" />
                ) : (
                  <QrCode size={66} strokeWidth={1.25} />
                )}
              </div>

              <div className="sm-qr-placeholder-text">
                <strong>
                  {starting
                    ? "Initializing camera"
                    : "Ready to scan"}
                </strong>

                <span>
                  {starting
                    ? "Please wait while your camera starts"
                    : "Start your camera to scan a garment QR code"}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* CAMERA ERROR */}

        {error && (
          <div className="sm-inline-alert">
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}

        {/* CAMERA SWITCHER - ONLY AFTER CAMERA STARTS */}

        {isScanning && (
          <div className="sm-qr-camera-selector">

            <div className="sm-qr-camera-selector-header">
              <div>
                <h6>Select Camera</h6>
                <p>Choose which camera you want to use</p>
              </div>

              <span className="sm-qr-selected-label">
                <span className="sm-qr-selected-dot" />
                Active
              </span>
            </div>

            <div className="sm-qr-camera-options">

              {/* BACK CAMERA */}

              <button
                type="button"
                className={`sm-qr-camera-option ${
                  cameraMode === "environment" ? "selected" : ""
                }`}
                onClick={() =>
                  void changeCamera("environment")
                }
                disabled={
                  starting ||
                  cameraMode === "environment"
                }
              >
                <span className="sm-qr-option-icon">
                  <Camera size={19} />
                </span>

                <span className="sm-qr-option-content">
                  <strong>Back Camera</strong>
                  <small>Rear camera</small>
                </span>

                {cameraMode === "environment" && (
                  <CheckCircle2
                    className="sm-qr-option-check"
                    size={18}
                  />
                )}
              </button>

              {/* FRONT CAMERA */}

              <button
                type="button"
                className={`sm-qr-camera-option ${
                  cameraMode === "user" ? "selected" : ""
                }`}
                onClick={() => void changeCamera("user")}
                disabled={
                  starting ||
                  cameraMode === "user"
                }
              >
                <span className="sm-qr-option-icon">
                  <Camera size={19} />
                </span>

                <span className="sm-qr-option-content">
                  <strong>Front Camera</strong>
                  <small>Selfie camera</small>
                </span>

                {cameraMode === "user" && (
                  <CheckCircle2
                    className="sm-qr-option-check"
                    size={18}
                  />
                )}
              </button>

            </div>
          </div>
        )}

        {/* CAMERA ACTION */}

        <div className="sm-qr-camera-actions">
          {!isScanning ? (
            <CommonButton
              leftIcon={<Camera size={16} />}
              onClick={() => void startScanner()}
              loading={starting}
              disabled={starting}
            >
              {starting
                ? "Starting Camera..."
                : "Start Camera Scan"}
            </CommonButton>
          ) : (
            <CommonButton
              variant="outline"
              leftIcon={<CameraOff size={16} />}
              onClick={() => void stopScanner()}
            >
              Stop Camera
            </CommonButton>
          )}
        </div>
      </div>

      {/* MANUAL QR ENTRY */}

      <div className="sm-qr-manual-card">

        <div className="sm-qr-manual-heading">
          <div className="sm-qr-manual-icon">
            <Keyboard size={18} />
          </div>

          <div>
            <h6>Enter QR code manually</h6>
            <p>
              Use this option if you already know the garment QR ID.
            </p>
          </div>
        </div>

        <div className="sm-qr-manual-form">

          <div className="sm-qr-input">
            <CommonInput
              value={manualValue}
              onChange={(e) => setManualValue(e.target.value)}
              placeholder="Enter QR ID (e.g. QR-9041-001)"
            />
          </div>

          <div className="sm-qr-submit">
            <CommonButton
              fullWidth
              leftIcon={<QrCode size={16} />}
              disabled={
                !manualValue.trim() ||
                starting ||
                handledRef.current
              }
              onClick={() => void submitManual()}
            >
              Find Work Order
            </CommonButton>
          </div>

        </div>
      </div>

      {/* FOOTER */}

      <div className="sm-qr-footer">
        <span>
          QR scanning is available for Station and QA workflows.
        </span>

        <button
          type="button"
          onClick={() => void handleClose()}
        >
          Cancel
        </button>
      </div>

    </div>
  );
}