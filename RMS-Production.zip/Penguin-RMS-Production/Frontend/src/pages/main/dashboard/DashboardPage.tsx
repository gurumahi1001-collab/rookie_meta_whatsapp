import { useCallback, useEffect, useState } from "react";
import { Activity, Boxes, ClipboardCheck, ClipboardList, PackageCheck, PackageOpen, RefreshCw, RotateCcw, Truck, Wrench } from "lucide-react";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import CommonButton from "@/components/common/ui/button/CommonButton";
import { api } from "@/lib/api";
import { connectRealtime } from "@/lib/realtime";

type DashboardSummary = {
  kpis: {
    activePurchaseOrders: number; totalWorkOrders: number; assigned: number; inProgress: number;
    awaitingQA: number; qaPassed: number; qaRejected: number; packed: number; scrap: number;
    activeStations: number; openCartons: number; inspectionsToday: number;
  };
  workflow: Array<{ status: string; count: number }>;
  recentActivity: Array<{ id: string; action: string; module: string; title: string; description: string; actorName: string; entityName: string; createdAt: string }>;
};

const cards = [
  { key: "activePurchaseOrders", label: "Active Purchase Orders", icon: ClipboardList },
  { key: "totalWorkOrders", label: "Registered Reworks", icon: RotateCcw },
  { key: "inProgress", label: "In Repair", icon: Wrench },
  { key: "awaitingQA", label: "Awaiting QA", icon: ClipboardCheck },
  { key: "qaPassed", label: "QA Passed", icon: PackageCheck },
  { key: "qaRejected", label: "QA Rejected", icon: Activity },
  { key: "openCartons", label: "Open Cartons", icon: PackageOpen },
  { key: "packed", label: "Packed Garments", icon: Boxes },
] as const;

export default function DashboardPage() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const response = await api.get<DashboardSummary>("/dashboard/summary");
      setSummary(response); setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Dashboard data is unavailable.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const socket = connectRealtime();
    const onRefresh = () => { void load(); };
    socket?.on("dashboard:refresh", onRefresh);
    return () => { socket?.off("dashboard:refresh", onRefresh); };
  }, [load]);

  const kpis = summary?.kpis;
  const maxWorkflow = Math.max(1, ...(summary?.workflow || []).map((item) => item.count));

  return (
    <div className="container-fluid px-0">
      <CommonPageHeader
        icon={<Activity size={20} />}
        title="Dashboard"
        subtitle="Live production, rework, quality and dispatch overview."
        rightContent={<CommonButton variant="outline" leftIcon={<RefreshCw size={15} />} onClick={() => void load()}>{loading ? "Refreshing…" : "Refresh"}</CommonButton>}
      />
      {error && <div className="alert alert-warning py-2" role="status">{error}</div>}
      {loading && !summary && <div className="text-muted py-4">Loading production summary…</div>}
      {summary && <>
        <div className="row g-3 mt-1">
          {cards.map(({ key, label, icon: Icon }) => (
            <div className="col-12 col-sm-6 col-xl-3" key={key}>
              <div className="card h-100 border-0 shadow-sm">
                <div className="card-body d-flex align-items-center justify-content-between">
                  <div><div className="small text-muted mb-1">{label}</div><div className="fs-3 fw-semibold">{kpis?.[key] ?? 0}</div></div>
                  <div className="rounded-3 bg-light p-3 text-primary"><Icon size={22} /></div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="row g-3 mt-1">
          <div className="col-12 col-xl-7">
            <div className="card h-100 border-0 shadow-sm">
              <div className="card-header bg-white border-0 pt-3"><h6 className="mb-0">Production Workflow</h6><small className="text-muted">Live work-order distribution by status</small></div>
              <div className="card-body">
                {(summary.workflow || []).map((item) => (
                  <div className="mb-3" key={item.status}>
                    <div className="d-flex justify-content-between small mb-1"><span>{item.status}</span><strong>{item.count}</strong></div>
                    <div className="progress" style={{ height: 8 }}><div className="progress-bar" role="progressbar" style={{ width: `${(item.count / maxWorkflow) * 100}%` }} aria-valuenow={item.count} aria-valuemin={0} aria-valuemax={maxWorkflow} /></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="col-12 col-xl-5">
            <div className="card h-100 border-0 shadow-sm">
              <div className="card-header bg-white border-0 pt-3"><h6 className="mb-0">Operational Snapshot</h6><small className="text-muted">Current capacity and today’s QA activity</small></div>
              <div className="card-body">
                <div className="d-flex justify-content-between py-2 border-bottom"><span className="text-muted">Active stations</span><strong>{kpis?.activeStations ?? 0}</strong></div>
                <div className="d-flex justify-content-between py-2 border-bottom"><span className="text-muted">Inspections today</span><strong>{kpis?.inspectionsToday ?? 0}</strong></div>
                <div className="d-flex justify-content-between py-2 border-bottom"><span className="text-muted">Scrapped garments</span><strong>{kpis?.scrap ?? 0}</strong></div>
                <div className="d-flex justify-content-between py-2"><span className="text-muted">Dispatched / packed</span><strong>{kpis?.packed ?? 0}</strong></div>
              </div>
            </div>
          </div>
        </div>
        <div className="card border-0 shadow-sm mt-3">
          <div className="card-header bg-white border-0 pt-3 d-flex align-items-center gap-2"><Truck size={18} /><h6 className="mb-0">Recent Activity</h6></div>
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0"><thead><tr><th>Activity</th><th>Reference</th><th>Performed By</th><th>Module</th><th className="text-end">Time</th></tr></thead>
              <tbody>{summary.recentActivity?.length ? summary.recentActivity.map((item) => <tr key={item.id}><td><div className="fw-medium">{item.title || item.action}</div><small className="text-muted">{item.description}</small></td><td>{item.entityName || "—"}</td><td>{item.actorName || "System"}</td><td><span className="badge text-bg-light">{item.module}</span></td><td className="text-end text-nowrap">{item.createdAt ? new Date(item.createdAt).toLocaleString() : "—"}</td></tr>) : <tr><td colSpan={5} className="text-center text-muted py-4">No activity recorded yet.</td></tr>}</tbody>
            </table>
          </div>
        </div>
      </>}
    </div>
  );
}
