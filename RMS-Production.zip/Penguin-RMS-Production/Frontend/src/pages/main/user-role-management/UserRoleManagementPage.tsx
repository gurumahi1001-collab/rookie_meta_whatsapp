import { useState } from "react";
import { useLiveResource } from "@/hooks/useLiveResource";
import { api } from "@/lib/api";
import { ShieldCheck, Users } from "lucide-react";
import { moduleOptions as knownModules } from "./data/userRoleData";
import type { ModuleItem } from "./types/userRoleTypes";

import type { RoleRecord, UserRecord } from "./types/userRoleTypes";

import "./UserRoleManagementPage.scss";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import RoleManagementTab from "./tab/RoleManagementTab";
import SystemUsersTab from "./tab/SystemUsersTab";

type ActiveTab = "roles" | "users";

export default function UserRoleManagementPage() {
  const roleResource = useLiveResource<RoleRecord>({ endpoint: "/roles", resource: "roles" });
  const permissionResource = useLiveResource<{ id: string; key: string; name: string; description?: string }>({ endpoint: "/permissions", resource: "permissions" });
  const modules: ModuleItem[] = permissionResource.data.map((permission) => ({
    id: permission.key, label: permission.name,
    icon: knownModules.find((item) => item.id === permission.key)?.icon || <ShieldCheck size={16} />,
  }));
  type UserDto = UserRecord & { password?: string; avatarFile?: File; phone?: string; employeeId?: string; department?: string; jobTitle?: string };
  const userResource = useLiveResource<UserDto>({ endpoint: "/users", resource: "users" });
  const stationOptionResource = useLiveResource<{ id: string; name: string }>({ endpoint: "/users/options", resource: "user-options" });
  const stationOptions = stationOptionResource.data.map((station) => station.name);
  const [activeTab, setActiveTab] = useState<ActiveTab>("roles");
  const roles = roleResource.data;
  const users = userResource.data;

  const persistRoles = async (next: RoleRecord[]) => {
    try {
      const previous = roleResource.data;
      for (const item of next) {
        const existing = previous.find((record) => record.id === item.id);
        if (!existing) await roleResource.create({ name: item.name, description: item.description, modules: item.modules });
        else if (existing.name !== item.name || existing.description !== item.description || JSON.stringify(existing.modules) !== JSON.stringify(item.modules)) {
          await roleResource.update(item.id, { name: item.name, description: item.description, modules: item.modules });
        }
      }
      for (const item of previous) if (!next.some((record) => record.id === item.id)) await roleResource.remove(item.id);
      await userResource.reload();
    } catch (error) { window.alert(error instanceof Error ? error.message : "Unable to save role changes."); }
  };

  const persistUsers = async (next: UserRecord[]) => {
    try {
      const previous = userResource.data;
      for (const user of next as UserDto[]) {
        const existing = previous.find((record) => record.id === user.id);
        let avatarUrl = user.avatar;
        if (user.avatarFile) {
          const form = new FormData();
          form.append("file", user.avatarFile);
          const uploaded = await api.upload<{ url: string }>("/uploads/avatar", form);
          avatarUrl = uploaded.url;
        }
        if (!existing) {
          await userResource.create({ name: user.name, email: user.email, password: user.password, role: user.role, station: user.station, avatar: avatarUrl, active: user.active });
        } else {
          const payload: Record<string, unknown> = {};
          for (const key of ["name", "email", "role", "station", "active"] as const) if (existing[key] !== user[key]) payload[key] = user[key];
          if (avatarUrl !== existing.avatar) payload.avatar = avatarUrl;
          if (user.password) payload.password = user.password;
          if (Object.keys(payload).length) await userResource.update(user.id, payload as Partial<UserDto>);
        }
      }
      for (const item of previous) if (!next.some((record) => record.id === item.id)) await userResource.remove(item.id);
      await userResource.reload();
    } catch (error) { window.alert(error instanceof Error ? error.message : "Unable to save user changes."); }
  };

  return (
    <div className="user-role-page">
      <CommonPageHeader
        title="User & Role Management"
        icon={<ShieldCheck size={22} />}
        subtitle="Configure security roles, map module permissions, and manage system users."
      />

      {/* Tab Navigation */}
      <div className="urm-tabs-card">
        <div className="urm-tabs" role="tablist" aria-label="User management">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "roles"}
            className={`urm-tab ${activeTab === "roles" ? "active" : ""}`}
            onClick={() => setActiveTab("roles")}
          >
            <ShieldCheck size={18} />
            <span>Roles & Module Mappings</span>
            <span className="urm-tab-count">{roles.length}</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeTab === "users"}
            className={`urm-tab ${activeTab === "users" ? "active" : ""}`}
            onClick={() => setActiveTab("users")}
          >
            <Users size={18} />
            <span>System Users</span>
            <span className="urm-tab-count">{users.length}</span>
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="urm-tab-content">
        {activeTab === "roles" ? (
          <RoleManagementTab
            roles={roles}
            users={users}
            onRolesChange={persistRoles}
            modules={modules}
          />
        ) : (
          <SystemUsersTab
            users={users}
            roles={roles}
            stationOptions={stationOptions}
            onUsersChange={persistUsers}
          />
        )}
      </div>
    </div>
  );
}
