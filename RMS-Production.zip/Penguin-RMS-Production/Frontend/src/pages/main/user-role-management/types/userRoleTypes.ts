import type { ReactNode } from "react";

export interface ModuleItem {
  id: string;
  label: string;
  icon: ReactNode;
}

export interface RoleRecord {
  id: string;
  name: string;
  description: string;
  modules: string[];
  systemRole: boolean;
}

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  station: string;
  avatar?: string;
  active: boolean;
}

export interface SelectOption {
  label: string;
  value: string;
}