import { LockKeyhole, Pencil, Trash2, UserCog } from "lucide-react";

import type { ModuleItem, RoleRecord } from "../types/userRoleTypes";

interface RoleCardProps {
  role: RoleRecord;
  onEdit: (role: RoleRecord) => void;
  onDelete: (role: RoleRecord) => void;
  modules: ModuleItem[];
}

export default function RoleCard({
  role,
  onEdit,
  onDelete,
  modules,
}: RoleCardProps) {
  const selectedModules = modules.filter((module) =>
    role.modules.includes(module.id),
  );

  return (
    <article className="urm-role-card">
      <div className="urm-role-card-top">
        <span className="urm-role-id">{role.id}</span>

        <span className="urm-module-count">
          {role.modules.length} Modules Allowed
        </span>
      </div>

      <div className="urm-role-card-content">
        <h3>{role.name}</h3>
        <p>{role.description || "No description provided."}</p>
      </div>

      <div className="urm-mapped-section">
        <div className="urm-mapped-heading">
          <span>Mapped Modules</span>
          <span>{role.modules.length} selected</span>
        </div>

        <div className="urm-module-badges">
          {selectedModules.map((module) => (
            <span className="urm-module-badge" key={module.id}>
              {module.icon}
              {module.label}
            </span>
          ))}
        </div>
      </div>

      <div className="urm-role-card-footer">
        <span className="urm-role-type">
          {role.systemRole ? (
            <>
              <LockKeyhole size={13} />
              System Role
            </>
          ) : (
            <>
              <UserCog size={13} />
              Custom Role
            </>
          )}
        </span>

        <div className="urm-role-actions">
          <button
            type="button"
            className="urm-icon-button"
            title="Edit role"
            onClick={() => onEdit(role)}
          >
            <Pencil size={16} />
          </button>

          <button
            type="button"
            className="urm-icon-button danger"
            title={role.systemRole ? "System roles cannot be deleted" : "Delete role"}
            disabled={role.systemRole}
            onClick={() => onDelete(role)}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>
    </article>
  );
}