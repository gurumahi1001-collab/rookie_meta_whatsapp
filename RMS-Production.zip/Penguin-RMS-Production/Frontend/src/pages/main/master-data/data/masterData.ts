import type {
  CategoryRecord,
  DefectRecord,
  StaffOption,
  StationRecord,
} from "../types/masterDataTypes";

export const stationTypes = [
  "Cutting Station",
  "Stitching Station",
  "Stain Removal Station",
  "Fabric Repair Station",
  "Measurement Correction Station",
  "Finishing Station",
  "Packing Station",
];

export const staffOptions: StaffOption[] = [
  { id: "USR-001", name: "Karthik Subramanian", role: "Admin" },
  { id: "USR-002", name: "Ananya Ramesh", role: "Rework Inspector" },
  { id: "USR-003", name: "Senthil Kumar", role: "Station Operator" },
  { id: "USR-004", name: "Divya Balaji", role: "Station Operator" },
  { id: "USR-005", name: "Arunachalam Nathan", role: "Station Operator" },
  { id: "USR-006", name: "Vijay Anand", role: "QA Inspector" },
  { id: "USR-007", name: "Murugan Selvam", role: "Packing Operator" },
  { id: "USR-008", name: "Kavitha Ramasamy", role: "Production Manager" },
];

export const initialStations: StationRecord[] = [
  { id: "STN-01", code: "ST-STITCH-01", name: "Stitching Repair Station Alpha", type: "Stitching Station", location: "Floor 2, Zone B", status: "Active", operatorIds: ["USR-003", "USR-005"] },
  { id: "STN-02", code: "ST-STAIN-02", name: "Stain Removal & Wash Station", type: "Stain Removal Station", location: "Floor 1, Zone A", status: "Active", operatorIds: ["USR-004", "USR-005"] },
  { id: "STN-03", code: "ST-FABRIC-03", name: "Fabric & Darning Station", type: "Fabric Repair Station", location: "Floor 2, Zone C", status: "Active", operatorIds: ["USR-006", "USR-007"] },
  { id: "STN-04", code: "ST-MEAS-04", name: "Measurement & Alteration Station", type: "Measurement Correction Station", location: "Floor 3, Zone A", status: "Active", operatorIds: ["USR-008"] },
  { id: "STN-05", code: "ST-FINISH-05", name: "Final Finishing & Buttoning", type: "Finishing Station", location: "Floor 3, Zone B", status: "Active", operatorIds: ["USR-007"] },
  { id: "STN-06", code: "ST-STITCH-02", name: "Stitching Repair Station Beta", type: "Stitching Station", location: "Floor 2, Zone D", status: "Active", operatorIds: ["USR-003"] },
];

export const initialCategories: CategoryRecord[] = [
  { id: "CAT-01", code: "CAT-STITCH", name: "Stitching Defect", description: "Skipped stitches, broken threads, uneven hems, and tension issues.", severity: "Major", status: "Active" },
  { id: "CAT-02", code: "CAT-STAIN", name: "Stain", description: "Oil spots, dye marks, water stains, and chemical residues.", severity: "Minor", status: "Active" },
  { id: "CAT-03", code: "CAT-FABRIC", name: "Fabric Damage", description: "Snags, pulls, yarn defects, and weaving flaws.", severity: "Critical", status: "Active" },
  { id: "CAT-04", code: "CAT-TEAR", name: "Tear or Hole", description: "Accidental cuts, needle punctures, and fabric tears.", severity: "Critical", status: "Active" },
  { id: "CAT-05", code: "CAT-COLOR", name: "Color Defect", description: "Shade variation, dye bleeding, and fading.", severity: "Major", status: "Active" },
  { id: "CAT-06", code: "CAT-MEAS", name: "Measurement Issue", description: "Size tolerance deviations and measurement mismatch.", severity: "Major", status: "Active" },
  { id: "CAT-07", code: "CAT-ACCESSORY", name: "Missing Button/Accessory", description: "Missing, loose, or incorrectly attached accessories.", severity: "Minor", status: "Inactive" },
];

export const initialDefects: DefectRecord[] = [
  { id: "DEF-01", code: "DEF-ST-001", name: "Skip Stitch on Collar", categoryId: "CAT-01", severity: "Major", reworkMinutes: 15, description: "Missing stitch lock on collar band or collar point.", status: "Active" },
  { id: "DEF-02", code: "DEF-TR-002", name: "Needle Drop Hole", categoryId: "CAT-04", severity: "Critical", reworkMinutes: 25, description: "Hole caused by needle strike during sewing.", status: "Active" },
  { id: "DEF-03", code: "DEF-STN-003", name: "Machine Oil Spot", categoryId: "CAT-02", severity: "Minor", reworkMinutes: 10, description: "Lubricant oil droplet on cuff, pocket, or placket.", status: "Active" },
  { id: "DEF-04", code: "DEF-ME-004", name: "Sleeve Length Deviation", categoryId: "CAT-06", severity: "Major", reworkMinutes: 30, description: "Sleeve length exceeds the permitted tolerance.", status: "Active" },
  { id: "DEF-05", code: "DEF-AC-005", name: "Missing Waist Button", categoryId: "CAT-07", severity: "Minor", reworkMinutes: 8, description: "Button is missing or not secured on waistband.", status: "Active" },
  { id: "DEF-06", code: "DEF-FB-006", name: "Fabric Yarn Snag", categoryId: "CAT-03", severity: "Major", reworkMinutes: 20, description: "Pulled yarn fiber on front or back body panel.", status: "Active" },
];
