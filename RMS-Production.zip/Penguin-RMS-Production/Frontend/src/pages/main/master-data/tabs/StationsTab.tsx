import { useMemo, useState } from "react";
import {
  MapPin,
  Users,
  Wrench,
  Pencil,
  Trash2,
  Factory,
} from "lucide-react";

import CommonTooltip from "@/components/common/ui/tooltip/CommonTooltip";
import CommonSelect from "@/components/common/ui/select/CommonSelect";


import MasterDataToolbar from "../components/MasterDataToolbar";
import StationCard from "../cards/StationCard";
import { StatusBadge } from "../components/StatusBadge";

import type {
  StaffOption,
  StationRecord,
  ViewMode,
} from "../types/masterDataTypes";
import { type TableColumn, CommonDataTable } from "@/components/common/data-table";



interface Props {
  records: StationRecord[];
  staff: StaffOption[];
  onEdit: (item: StationRecord) => void;
  onDelete: (item: StationRecord) => void;
}

export default function StationsTab({
  records,
  staff,
  onEdit,
  onDelete,
}: Props) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string | number>("All");
  const [type, setType] = useState<string | number>("All");
  const [view, setView] = useState<ViewMode>("grid");

  const types = useMemo(
    () => [...new Set(records.map((item) => item.type))],
    [records],
  );

  const filtered = useMemo(() => {
    const searchValue = search.toLowerCase().trim();

    return records.filter(
      (item) =>
        (status === "All" || item.status === status) &&
        (type === "All" || item.type === type) &&
        `${item.name} ${item.code} ${item.location} ${item.type}`
          .toLowerCase()
          .includes(searchValue),
    );
  }, [records, search, status, type]);

  const columns: TableColumn<StationRecord>[] = [
    {
      field: "name",
      header: "Station",
      sortable: true,
      minWidth: "230px",
      body: (item) => (
        <div className="mdm-table-record">
          <span className="mdm-table-record__icon mdm-table-record__icon--station">
            <Factory size={17} />
          </span>
          <span className="mdm-table-record__content">
            <strong>{item.name}</strong>
            <small>{item.code}</small>
          </span>
        </div>
      ),
    },
    {
      field: "type",
      header: "Station Type",
      sortable: true,
      minWidth: "190px",
      body: (item) => (
        <span className="mdm-table-meta">
          <Wrench size={15} />
          {item.type}
        </span>
      ),
    },
    {
      field: "location",
      header: "Location",
      sortable: true,
      minWidth: "170px",
      body: (item) => (
        <span className="mdm-table-meta">
          <MapPin size={15} />
          {item.location}
        </span>
      ),
    },
    {
      field: "operatorIds",
      header: "Operators",
      minWidth: "130px",
      body: (item) => {
        const assignedCount = staff.filter((person) =>
          item.operatorIds.includes(person.id),
        ).length;

        return (
          <span className="mdm-table-meta">
            <Users size={15} />
            {assignedCount} assigned
          </span>
        );
      },
    },
    {
      field: "status",
      header: "Status",
      align: "center",
      minWidth: "110px",
      body: (item) => <StatusBadge status={item.status} />,
    },
    {
      field: "id",
      header: "Actions",
      align: "center",
      minWidth: "110px",
      body: (item) => (
        <div className="mdm-icon-actions">
          <CommonTooltip content="Edit">
            <button
              type="button"
              aria-label={`Edit ${item.name}`}
              onClick={() => onEdit(item)}
            >
              <Pencil size={16} />
            </button>
          </CommonTooltip>

          <CommonTooltip content="Delete">
            <button
              type="button"
              className="is-danger"
              aria-label={`Delete ${item.name}`}
              onClick={() => onDelete(item)}
            >
              <Trash2 size={16} />
            </button>
          </CommonTooltip>
        </div>
      ),
    },
  ];

  return (
    <section className="mdm-tab-content mdm-tab-content--stations">
      <MasterDataToolbar
        search={search}
        onSearch={setSearch}
        status={String(status)}
        onStatus={(value) => setStatus(value ?? "All")}
        view={view}
        onView={setView}
        filters={
          <CommonSelect
            value={type}
            onChange={(value) => setType(value ?? "All")}
            options={[
              { label: "All Station Types", value: "All" },
              ...types.map((value) => ({
                label: value,
                value,
              })),
            ]}
            placeholder="Station Type"
          />
        }
      />

      {filtered.length > 0 && (
        <>
          {view === "grid" ? (
            <div className="row g-3 mdm-card-grid">
              {filtered.map((item) => (
                <div className="col-12 col-md-6 col-xl-4" key={item.id}>
                  <StationCard
                    station={item}
                    staff={staff}
                    onEdit={onEdit}
                    onDelete={onDelete}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="mdm-data-table">
              <CommonDataTable
                data={filtered}
                columns={columns}
                dataKey="id"
                paginator
                rows={10}
                rowsPerPageOptions={[5, 10, 20, 50]}
                emptyMessage="No stations found"
                stripedRows
                size="small"
                className="mdm-common-table"
              />
            </div>
          )}
        </>
      )}

      {filtered.length === 0 && (
        <div className="mdm-empty-state">
          <Factory size={30} />
          <b>No stations found</b>
          <span>Try changing your search or filters.</span>
        </div>
      )}

      <div className="mdm-results-count">
        Showing {filtered.length} of {records.length} stations
      </div>
    </section>
  );
}