# Penguin RMS — Master Data Management

A self-contained React + TypeScript module with three independent master-data tabs:
- Factory Stations
- Defect Categories
- Defect Types

## Features
- Create, edit and delete records
- Search and combined filters
- Station and category card/list views
- Defect types table view
- Dynamic summary and tab counts
- Registered staff selection for stations
- Category-to-defect relationship
- Prevent deleting categories while defect types are linked
- Responsive SCSS styling
- Uses the project's shared CommonPageHeader, CommonButton, CommonInput, CommonSelect, CommonModal, CommonTextArea and CommonTooltip components

## Install
1. Copy the `master-data-management` folder into your feature/module directory.
2. Confirm the shared component import paths in the files under `components`, `tabs`, and `modals`.
3. Install/use `lucide-react` and PrimeReact (already used by the shared CommonSelect).
4. Import `MasterDataManagementPage` into your route.

Example:
```tsx
import MasterDataManagementPage from "@/features/master-data-management/MasterDataManagementPage";

<Route path="/master-data" element={<MasterDataManagementPage />} />
```

## Shared component paths assumed
- `@/components/common/ui/button/CommonButton`
- `@/components/common/ui/input/CommonInput`
- `@/components/common/ui/modal/CommonModal`
- `@/components/common/ui/select/CommonSelect`
- `@/components/common/ui/textarea/CommonTextArea`
- `@/components/common/ui/tooltip/CommonTooltip`
- `@/components/common/ui/page-header/CommonPageHeader`

If your actual folder names differ, update only those import paths.

## Data integration
This starter uses local React state and sample records. Replace the state initialization and save/delete handlers in `MasterDataManagementPage.tsx` with your API calls when backend endpoints are ready.

Station staff options are currently sample registered users in `data/masterData.ts`. Replace with your users API response.
