import { useMemo, useState } from "react";
import { useLiveResource } from "@/hooks/useLiveResource";
import { Database, Plus } from "lucide-react";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import MasterDataTabs from "./components/MasterDataTabs";
import StationsTab from "./tabs/StationsTab";
import CategoriesTab from "./tabs/CategoriesTab";
import DefectsTab from "./tabs/DefectsTab";
import StationFormModal from "./modals/StationFormModal";
import CategoryFormModal from "./modals/CategoryFormModal";
import DefectFormModal from "./modals/DefectFormModal";
import DeleteConfirmModal from "./components/DeleteConfirmModal";
import { stationTypes as initialStationTypes } from "./data/masterData";
import type {
  CategoryRecord,
  DefectRecord,
  MasterTab,
  StationRecord,
} from "./types/masterDataTypes";
import "./MasterDataManagementPage.scss";
type DeleteTarget = { kind: MasterTab; id: string; name: string } | null;

export default function MasterDataManagementPage() {
  const stationResource = useLiveResource<StationRecord>({ endpoint: "/master-data/stations", resource: "stations" });
  const categoryResource = useLiveResource<CategoryRecord>({ endpoint: "/master-data/categories", resource: "categories" });
  const defectResource = useLiveResource<DefectRecord>({ endpoint: "/master-data/defects", resource: "defects" });
  const operatorResource = useLiveResource<{ id: string; name: string; role: string }>({ endpoint: "/master-data/operators", resource: "operators" });
  const stations = stationResource.data;
  const categories = categoryResource.data;
  const defects = defectResource.data;
  const staff = useMemo(() => operatorResource.data.map((item) => ({ id: item.id, name: item.name, role: item.role })), [operatorResource.data]);
  const [addedStationTypes, setAddedStationTypes] = useState<string[]>([]);
  const stationTypes = useMemo(() => [...new Set([...initialStationTypes, ...addedStationTypes, ...stations.map((item) => item.type).filter(Boolean)])], [stations, addedStationTypes]);
  const [activeTab, setActiveTab] = useState<MasterTab>("stations");
  const [stationModal, setStationModal] = useState(false);
  const [categoryModal, setCategoryModal] = useState(false);
  const [defectModal, setDefectModal] = useState(false);
  const [editingStation, setEditingStation] = useState<StationRecord | null>(
    null,
  );
  const [editingCategory, setEditingCategory] = useState<CategoryRecord | null>(
    null,
  );
  const [editingDefect, setEditingDefect] = useState<DefectRecord | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget>(null);
  const [deleteError, setDeleteError] = useState("");

  const counts = useMemo(
    () => ({
      stations: stations.length,
      categories: categories.length,
      defects: defects.length,
    }),
    [stations, categories, defects],
  );

  const openCreate = () => {
    if (activeTab === "stations") {
      setEditingStation(null);
      setStationModal(true);
    }
    if (activeTab === "categories") {
      setEditingCategory(null);
      setCategoryModal(true);
    }
    if (activeTab === "defects") {
      setEditingDefect(null);
      setDefectModal(true);
    }
  };

  const saveStation = async (item: StationRecord) => {
    try {
      const payload = { code: item.code, name: item.name, type: item.type, location: item.location, status: item.status, operatorIds: item.operatorIds };
      if (stationResource.data.some((record) => record.id === item.id)) await stationResource.update(item.id, payload);
      else await stationResource.create(payload);
      setStationModal(false);
    } catch (error) { window.alert(error instanceof Error ? error.message : "Unable to save station."); }
  };
  const saveCategory = async (item: CategoryRecord) => {
    try {
      const payload = { code: item.code, name: item.name, description: item.description, severity: item.severity, status: item.status };
      if (categoryResource.data.some((record) => record.id === item.id)) await categoryResource.update(item.id, payload);
      else await categoryResource.create(payload);
      setCategoryModal(false);
    } catch (error) { window.alert(error instanceof Error ? error.message : "Unable to save category."); }
  };
  const saveDefect = async (item: DefectRecord) => {
    try {
      const category = categories.find((record) => record.id === item.categoryId);
      const payload = { code: item.code, name: item.name, categoryId: item.categoryId, categoryName: category?.name || "", severity: item.severity, reworkMinutes: item.reworkMinutes, description: item.description, status: item.status };
      if (defectResource.data.some((record) => record.id === item.id)) await defectResource.update(item.id, payload);
      else await defectResource.create(payload);
      setDefectModal(false);
    } catch (error) { window.alert(error instanceof Error ? error.message : "Unable to save defect type."); }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      if (deleteTarget.kind === "categories") {
        const linked = defects.some((item) => item.categoryId === deleteTarget.id);
        if (linked) { setDeleteError("This category has linked defect types. Reassign or delete those defects before deleting the category."); return; }
        await categoryResource.remove(deleteTarget.id);
      }
      if (deleteTarget.kind === "stations") await stationResource.remove(deleteTarget.id);
      if (deleteTarget.kind === "defects") await defectResource.remove(deleteTarget.id);
      setDeleteTarget(null);
      setDeleteError("");
    } catch (error) { setDeleteError(error instanceof Error ? error.message : "Unable to delete this record."); }
  };

  const requestDelete = (
    kind: MasterTab,
    item: { id: string; name: string },
  ) => {
    setDeleteError("");
    setDeleteTarget({ kind, id: item.id, name: item.name });
  };

  const actionLabel =
    activeTab === "stations"
      ? "Create Station"
      : activeTab === "categories"
        ? "Add Category"
        : "Add Defect Type";
  const actionIcon = <Plus size={16} />;
  const pageIcon = <Database size={20} />;

  return (
    <div className="mdm-page">
      <CommonPageHeader
        icon={pageIcon}
        title="Master Data Management"
        subtitle="Configure factory stations, defect categories, and specific defect codes with enriched attributes."
        rightContent={
          <CommonButton leftIcon={actionIcon} onClick={openCreate}>
            {actionLabel}
          </CommonButton>
        }
        className="mdm-page-header"
      />

      <div className="mdm-workspace">
        <div className="mdm-workspace-heading">
          <div>
            <h2>Master Records</h2>
            <p>
              Manage reference data used across production and quality
              workflows.
            </p>
          </div>
          <MasterDataTabs
            activeTab={activeTab}
            counts={counts}
            onChange={setActiveTab}
          />
        </div>

        {activeTab === "stations" && (
          <StationsTab
            records={stations}
            staff={staff}
            onEdit={(item) => {
              setEditingStation(item);
              setStationModal(true);
            }}
            onDelete={(item) => requestDelete("stations", item)}
          />
        )}
        {activeTab === "categories" && (
          <CategoriesTab
            records={categories}
            defects={defects}
            onEdit={(item) => {
              setEditingCategory(item);
              setCategoryModal(true);
            }}
            onDelete={(item) => requestDelete("categories", item)}
          />
        )}
        {activeTab === "defects" && (
          <DefectsTab
            records={defects}
            categories={categories}
            onEdit={(item) => {
              setEditingDefect(item);
              setDefectModal(true);
            }}
            onDelete={(item) => requestDelete("defects", item)}
          />
        )}
      </div>

      <StationFormModal
        show={stationModal}
        station={editingStation}
        staff={staff}
        stationTypes={stationTypes}
        onAddStationType={(newType) => {
          setAddedStationTypes((current) => current.some((item) => item.toLowerCase() === newType.toLowerCase()) ? current : [...current, newType]);
        }}
        onClose={() => setStationModal(false)}
        onSave={saveStation}
      />
      <CategoryFormModal
        show={categoryModal}
        category={editingCategory}
        onClose={() => setCategoryModal(false)}
        onSave={saveCategory}
      />
      <DefectFormModal
        show={defectModal}
        defect={editingDefect}
        categories={categories}
        onClose={() => setDefectModal(false)}
        onSave={saveDefect}
      />

      <DeleteConfirmModal
        show={!!deleteTarget}
        title={`Delete ${deleteTarget?.kind === "stations" ? "Station" : deleteTarget?.kind === "categories" ? "Category" : "Defect"}?`}
        description={
          deleteError || (
            <>
              Are you sure you want to delete{" "}
              <strong>{deleteTarget?.name ?? ""}</strong>?
            </>
          )
        }
        onClose={() => {
          setDeleteTarget(null);
          setDeleteError("");
        }}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
