import { Grid2X2, List, Search, X } from "lucide-react";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import type { ViewMode } from "../types/masterDataTypes";

interface Props {
  search: string;
  onSearch: (value: string) => void;
  status: string;
  onStatus: (value: string | number | null) => void;
  view: ViewMode;
  onView: (value: ViewMode) => void;
  filters?: React.ReactNode;
  showViewToggle?: boolean;
}

export default function MasterDataToolbar({
  search, onSearch, status, onStatus, view, onView, filters, showViewToggle = true,
}: Props) {
  return (
    <div className="mdm-toolbar">
      <div className="mdm-toolbar__search">
        <CommonInput
          value={search}
          onChange={(event) => onSearch(event.target.value)}
          placeholder="Search records..."
          leftElement={<Search size={16} />}
          rightElement={search ? <button type="button" className="mdm-clear-search" onClick={() => onSearch("")}><X size={14} /></button> : undefined}
        />
      </div>
      <div className="mdm-toolbar__filters">
        <CommonSelect
          value={status}
          onChange={onStatus}
          options={[
            { label: "All Status", value: "All" },
            { label: "Active", value: "Active" },
            { label: "Inactive", value: "Inactive" },
          ]}
          placeholder="All Status"
        />
        {filters}
      </div>
      {showViewToggle && (
        <div className="mdm-view-toggle" aria-label="Choose view">
          <button type="button" className={view === "grid" ? "is-active" : ""} onClick={() => onView("grid")} aria-label="Card view"><Grid2X2 size={16} /></button>
          <button type="button" className={view === "list" ? "is-active" : ""} onClick={() => onView("list")} aria-label="List view"><List size={17} /></button>
        </div>
      )}
    </div>
  );
}
