import type { RecordStatus, Severity } from "../types/masterDataTypes";

export function StatusBadge({ status }: { status: RecordStatus }) {
  return <span className={`mdm-status mdm-status--${status.toLowerCase()}`}>{status}</span>;
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <span className={`mdm-severity mdm-severity--${severity.toLowerCase()}`}>{severity}</span>;
}
