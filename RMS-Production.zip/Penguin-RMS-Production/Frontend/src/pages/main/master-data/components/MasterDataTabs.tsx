import { AlertTriangle, Factory, Layers3 } from "lucide-react";
import type { MasterTab } from "../types/masterDataTypes";

interface Props {
  activeTab: MasterTab;
  counts: Record<MasterTab, number>;
  onChange: (tab: MasterTab) => void;
}

const tabs = [
  { id: "stations" as const, label: "Stations", icon: Factory },
  { id: "categories" as const, label: "Categories", icon: Layers3 },
  { id: "defects" as const, label: "Defects", icon: AlertTriangle },
];

export default function MasterDataTabs({ activeTab, counts, onChange }: Props) {
  return (
    <div className="mdm-tabs" role="tablist" aria-label="Master data sections">
      {tabs.map(({ id, label, icon: Icon }) => (
        <button
          type="button"
          role="tab"
          aria-selected={activeTab === id}
          className={`mdm-tab ${activeTab === id ? "is-active" : ""}`}
          key={id}
          onClick={() => onChange(id)}
        >
          <Icon size={16} />
          <span>{label}</span>
          <span className="mdm-tab__count">{counts[id]}</span>
        </button>
      ))}
    </div>
  );
}
