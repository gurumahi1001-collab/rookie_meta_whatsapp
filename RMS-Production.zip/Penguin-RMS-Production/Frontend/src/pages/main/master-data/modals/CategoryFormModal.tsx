import { useEffect, useState } from "react";
import { Layers3 } from "lucide-react";
import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import type { CategoryRecord } from "../types/masterDataTypes";

interface Props {
  show: boolean;
  category: CategoryRecord | null;
  onClose: () => void;
  onSave: (item: CategoryRecord) => void;
}
export default function CategoryFormModal({
  show,
  category,
  onClose,
  onSave,
}: Props) {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [severity, setSeverity] = useState<string | null>("Major");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<string | null>("Active");

  useEffect(() => {
    if (!show) return;
    setName(category?.name ?? "");
    setCode(category?.code ?? "");
    setSeverity(category?.severity ?? "Major");
    setDescription(category?.description ?? "");
    setStatus(category?.status ?? "Active");
  }, [show, category]);

  const save = () => {
    if (!name.trim() || !code.trim() || !severity || !status) return;
    onSave({
      id: category?.id ?? `CAT-${Date.now().toString().slice(-5)}`,
      name: name.trim(),
      code: code.trim().toUpperCase(),
      severity: severity as CategoryRecord["severity"],
      description: description.trim(),
      status: status as CategoryRecord["status"],
    });
  };

  return (
    <CommonModal
      show={show}
      onClose={onClose}
      size="md"
      title={category ? "Edit Defect Category" : "Add Defect Category"}
      subtitle="Define a defect group and its default severity."
      headerIcon={<Layers3 size={19} />}
      className="mdm-form-modal"
      footer={
        <>
          <CommonButton variant="outline" onClick={onClose}>
            Cancel
          </CommonButton>
          <CommonButton disabled={!name.trim() || !code.trim()} onClick={save}>
            {category ? "Update Category" : "Save Category"}
          </CommonButton>
        </>
      }
    >
      <div className="mdm-form-grid">
        <div className="mdm-form-full">
          <CommonInput
            label="Category Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Stitching Defect"
            required
          />
        </div>
        <CommonInput
          label="Category Code"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="e.g. CAT-STITCH"
          required
        />
        <CommonSelect
          label="Default Severity"
          value={severity}
          onChange={(v) => setSeverity(v == null ? null : String(v))}
          options={["Minor", "Major", "Critical"].map((v) => ({
            label: v,
            value: v,
          }))}
          required
        />
        <div className="mdm-form-full">
          <CommonTextArea
            label="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the category and defects included..."
            rows={3}
          />
        </div>
        <div className="mdm-form-full">
          <CommonSelect
            label="Status"
            value={status}
            onChange={(v) => setStatus(v == null ? null : String(v))}
            options={[
              { label: "Active", value: "Active" },
              { label: "Inactive", value: "Inactive" },
            ]}
            required
          />
        </div>
      </div>
    </CommonModal>
  );
}
