import { Pencil, Trash2, Tag } from "lucide-react";
import CommonTooltip from "@/components/common/ui/tooltip/CommonTooltip";
import type { CategoryRecord } from "../types/masterDataTypes";
import { SeverityBadge, StatusBadge } from "../components/StatusBadge";

interface Props {
  category: CategoryRecord;
  defectCount: number;
  onEdit: (item: CategoryRecord) => void;
  onDelete: (item: CategoryRecord) => void;
}
export default function CategoryCard({ category, defectCount, onEdit, onDelete }: Props) {
  return (
    <article className="mdm-record-card mdm-category-card">
      <div className="mdm-card-top">
        <span className="mdm-code">{category.code}</span>
        <StatusBadge status={category.status} />
      </div>
      <h3>{category.name}</h3>
      <p className="mdm-card-description">{category.description || "No description added."}</p>
      <div className="mdm-category-info">
        <span>Default severity <SeverityBadge severity={category.severity} /></span>
        <span><Tag size={14} /> {defectCount} linked defects</span>
      </div>
      <div className="mdm-card-footer">
        <span>ID: {category.id}</span>
        <div className="mdm-icon-actions">
          <CommonTooltip content="Edit category"><button type="button" onClick={() => onEdit(category)} aria-label="Edit category"><Pencil size={16} /></button></CommonTooltip>
          <CommonTooltip content="Delete category"><button type="button" className="is-danger" onClick={() => onDelete(category)} aria-label="Delete category"><Trash2 size={16} /></button></CommonTooltip>
        </div>
      </div>
    </article>
  );
}
