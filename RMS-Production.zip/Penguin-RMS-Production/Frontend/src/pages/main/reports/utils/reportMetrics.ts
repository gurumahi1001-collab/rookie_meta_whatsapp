import {
  AUDIT_EVENTS,
  CHECKLIST_ITEMS,
  DAY,
  FACTORIES,
  GARMENTS,
  HOUR,
  NOW,
  SHIFTS,
  STATIONS,
} from "../data/reportData";
import type {
  AuditEvent,
  AuditType,
  GarmentReportRecord,
  GarmentStatus,
  ReportFilters,
} from "../types/reportTypes";
import { percent, round1 } from "./reportHelpers";

/* ------------------------------------------------------------------ */
/* Filtering                                                           */
/* ------------------------------------------------------------------ */

export const startOfDay = (ms: number) => {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

export function getRangeMs(filters: ReportFilters) {
  let start = new Date(`${filters.from}T00:00:00`).getTime();
  let end = new Date(`${filters.to}T23:59:59.999`).getTime();
  if (Number.isNaN(start)) start = NOW - 30 * DAY;
  if (Number.isNaN(end)) end = NOW;
  if (start > end) [start, end] = [startOfDay(end), start + DAY - 1];
  return { start, end };
}

const factoryOk = (filters: ReportFilters, id: string) =>
  filters.factory === "all" || filters.factory === id;

export function selectGarments(filters: ReportFilters): GarmentReportRecord[] {
  const { start, end } = getRangeMs(filters);
  return GARMENTS.filter((g) => {
    const t = Date.parse(g.registeredAt);
    return t >= start && t <= end && factoryOk(filters, g.factoryId);
  });
}

export function selectAudit(filters: ReportFilters): AuditEvent[] {
  const { start, end } = getRangeMs(filters);
  return AUDIT_EVENTS.filter((e) => {
    const t = Date.parse(e.at);
    return t >= start && t <= end && factoryOk(filters, e.factoryId);
  });
}

export const factoryName = (id: string) => FACTORIES.find((f) => f.id === id)?.name ?? id;
export const stationLabel = (id: string) => STATIONS.find((s) => s.id === id)?.name ?? id;
export const stationCode = (id: string) => STATIONS.find((s) => s.id === id)?.code ?? id;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

export const BACKLOG_STATUSES: GarmentStatus[] = [
  "Registered",
  "In Repair",
  "Awaiting QA",
  "Awaiting Rework",
  "Awaiting Packing",
];

const isApproved = (g: GarmentReportRecord) =>
  g.status === "Awaiting Packing" || g.status === "Packed";

const approvalTime = (g: GarmentReportRecord) => {
  const pass = g.inspections.find((i) => i.outcome === "Pass");
  return pass ? Date.parse(pass.at) : undefined;
};

const sum = (values: number[]) => values.reduce((a, b) => a + b, 0);
const avg = (values: number[]) => (values.length ? sum(values) / values.length : 0);

function makeBuckets(filters: ReportFilters) {
  const { start, end } = getRangeMs(filters);
  const first = startOfDay(start);
  const spanDays = Math.max(1, Math.round((startOfDay(end) - first) / DAY) + 1);
  const step = spanDays > 45 ? 7 : 1;
  const count = Math.ceil(spanDays / step);
  const labels = Array.from({ length: count }, (_, i) =>
    new Date(first + i * step * DAY).toLocaleDateString("en-IN", { day: "2-digit", month: "short" }),
  );
  const index = (ms: number) => {
    const i = Math.floor((startOfDay(ms) - first) / (step * DAY));
    return i >= 0 && i < count ? i : -1;
  };
  return { labels, count, index, weekly: step === 7 };
}

const zeros = (n: number) => Array.from({ length: n }, () => 0);

/* ------------------------------------------------------------------ */
/* FR-RPT-001 Operational overview                                     */
/* ------------------------------------------------------------------ */

export interface BacklogRow {
  id: string;
  status: GarmentStatus;
  count: number;
  share: number;
  avgAgeDays: number;
  oldestDays: number;
}

export interface FactoryFlowRow {
  factory: string;
  open: number;
  awaitingPacking: number;
  packed: number;
  scrapped: number;
}

export interface OverviewMetrics {
  registered: number;
  repaired: number;
  qaApproved: number;
  qaRejected: number;
  awaitingRework: number;
  awaitingPacking: number;
  avgTurnaround: number;
  trend: { labels: string[]; registered: number[]; repaired: number[]; approved: number[]; weekly: boolean };
  turnaround: { avgHours: number[]; approved: number[] };
  backlog: BacklogRow[];
  factoryFlow: FactoryFlowRow[];
}

export function computeOverview(filters: ReportFilters): OverviewMetrics {
  const rows = selectGarments(filters);
  const b = makeBuckets(filters);

  const registeredS = zeros(b.count);
  const repairedS = zeros(b.count);
  const approvedS = zeros(b.count);
  const ttSum = zeros(b.count);
  const ttCnt = zeros(b.count);
  const turnarounds: number[] = [];
  let repaired = 0;
  let approved = 0;
  let rejections = 0;

  rows.forEach((g) => {
    const reg = b.index(Date.parse(g.registeredAt));
    if (reg >= 0) registeredS[reg]++;
    if (g.repairedAt) {
      repaired++;
      const i = b.index(Date.parse(g.repairedAt));
      if (i >= 0) repairedS[i]++;
    }
    rejections += g.reworkCycles;
    if (isApproved(g)) {
      approved++;
      const at = approvalTime(g);
      const i = at ? b.index(at) : -1;
      if (i >= 0) approvedS[i]++;
      if (g.turnaroundHours !== undefined) {
        turnarounds.push(g.turnaroundHours);
        if (i >= 0) {
          ttSum[i] += g.turnaroundHours;
          ttCnt[i]++;
        }
      }
    }
  });

  const backlogTotal = rows.filter((g) => BACKLOG_STATUSES.includes(g.status)).length;
  const backlog: BacklogRow[] = BACKLOG_STATUSES.map((status) => {
    const list = rows.filter((g) => g.status === status);
    const ages = list.map((g) => (NOW - Date.parse(g.registeredAt)) / DAY);
    return {
      id: status,
      status,
      count: list.length,
      share: percent(list.length, backlogTotal),
      avgAgeDays: round1(avg(ages)),
      oldestDays: round1(ages.length ? Math.max(...ages) : 0),
    };
  });

  const factoryFlow: FactoryFlowRow[] = FACTORIES.filter((f) => factoryOk(filters, f.id)).map((f) => {
    const list = rows.filter((g) => g.factoryId === f.id);
    return {
      factory: f.name,
      open: list.filter((g) => ["Registered", "In Repair", "Awaiting QA", "Awaiting Rework"].includes(g.status)).length,
      awaitingPacking: list.filter((g) => g.status === "Awaiting Packing").length,
      packed: list.filter((g) => g.status === "Packed").length,
      scrapped: list.filter((g) => g.status === "Scrapped").length,
    };
  });

  return {
    registered: rows.length,
    repaired,
    qaApproved: approved,
    qaRejected: rejections,
    awaitingRework: rows.filter((g) => g.status === "Awaiting Rework").length,
    awaitingPacking: rows.filter((g) => g.status === "Awaiting Packing").length,
    avgTurnaround: round1(avg(turnarounds)),
    trend: { labels: b.labels, registered: registeredS, repaired: repairedS, approved: approvedS, weekly: b.weekly },
    turnaround: {
      avgHours: ttSum.map((s, i) => (ttCnt[i] ? round1(s / ttCnt[i]) : 0)),
      approved: approvedS,
    },
    backlog,
    factoryFlow,
  };
}

/* ------------------------------------------------------------------ */
/* FR-RPT-002 Station & operator                                       */
/* ------------------------------------------------------------------ */

export interface StationRow {
  id: string;
  station: string;
  code: string;
  assigned: number;
  processed: number;
  pending: number;
  avgMinutes: number;
  rejections: number;
  throughput: number;
}

export interface OperatorRow {
  id: string;
  operator: string;
  stations: string;
  assigned: number;
  completed: number;
  pending: number;
  avgMinutes: number;
  rejections: number;
  rejectionRate: number;
}

const QUEUE_STATUSES: GarmentStatus[] = ["Registered", "In Repair", "Awaiting Rework"];

export function computeStations(filters: ReportFilters) {
  const rows = selectGarments(filters);

  const stations: StationRow[] = STATIONS.map((s) => {
    const list = rows.filter((g) => g.stationId === s.id);
    const done = list.filter((g) => g.repairedAt);
    return {
      id: s.id,
      station: s.name,
      code: s.code,
      assigned: list.length,
      processed: done.length,
      pending: list.filter((g) => QUEUE_STATUSES.includes(g.status)).length,
      avgMinutes: Math.round(avg(done.map((g) => g.processMinutes))),
      rejections: sum(list.map((g) => g.reworkCycles)),
      throughput: percent(done.length, list.length),
    };
  });

  const names = Array.from(new Set(STATIONS.flatMap((s) => s.operators)));
  const operators: OperatorRow[] = names
    .map((name) => {
      const list = rows.filter((g) => g.operator === name);
      const done = list.filter((g) => g.repairedAt);
      const rejections = sum(list.map((g) => g.reworkCycles));
      return {
        id: name,
        operator: name,
        stations: STATIONS.filter((s) => s.operators.includes(name))
          .map((s) => s.code.replace("ST-", ""))
          .join(", "),
        assigned: list.length,
        completed: done.length,
        pending: list.filter((g) => QUEUE_STATUSES.includes(g.status)).length,
        avgMinutes: Math.round(avg(done.map((g) => g.processMinutes))),
        rejections,
        rejectionRate: percent(rejections, done.length),
      };
    })
    .sort((a, b) => b.completed - a.completed);

  const allDone = rows.filter((g) => g.repairedAt);
  return {
    stations,
    operators,
    totals: {
      processed: allDone.length,
      pending: sum(stations.map((s) => s.pending)),
      avgMinutes: Math.round(avg(allDone.map((g) => g.processMinutes))),
      rejections: sum(stations.map((s) => s.rejections)),
      activeOperators: operators.filter((o) => o.assigned > 0).length,
    },
  };
}

/* ------------------------------------------------------------------ */
/* FR-RPT-003 QA & re-rework                                           */
/* ------------------------------------------------------------------ */

export interface ReasonRow {
  id: string;
  reason: string;
  count: number;
  share: number;
  repeatGarments: number;
  topStation: string;
}

export interface MultiCycleRow {
  id: string;
  poNumber: string;
  station: string;
  cycles: number;
  lastReason: string;
  status: GarmentStatus;
}

export function computeQa(filters: ReportFilters) {
  const rows = selectGarments(filters);

  let pass = 0;
  let reject = 0;
  let scrap = 0;
  let inspected = 0;
  let firstPass = 0;
  let withReject = 0;
  let recovered = 0;
  const cycles = [0, 0, 0, 0];
  const checklist = new Map<string, number>();
  CHECKLIST_ITEMS.forEach((c) => checklist.set(c, 0));
  const reasons = new Map<string, { count: number; garments: Map<string, number>; stations: Map<string, number> }>();
  const heat = new Map<string, Map<string, number>>();

  rows.forEach((g) => {
    if (!g.inspections.length) return;
    inspected++;
    if (g.inspections[0].outcome === "Pass") firstPass++;
    cycles[Math.min(g.reworkCycles, 3)]++;
    if (g.reworkCycles > 0) {
      withReject++;
      if (isApproved(g)) recovered++;
    }

    g.inspections.forEach((ins) => {
      if (ins.outcome === "Pass") pass++;
      if (ins.outcome === "Scrap") scrap++;
      if (ins.outcome !== "Reject") return;
      reject++;
      ins.failedChecks.forEach((c) => checklist.set(c, (checklist.get(c) ?? 0) + 1));

      const reason = ins.reason ?? "Unspecified";
      const entry = reasons.get(reason) ?? { count: 0, garments: new Map(), stations: new Map() };
      entry.count++;
      entry.garments.set(g.id, (entry.garments.get(g.id) ?? 0) + 1);
      entry.stations.set(g.stationId, (entry.stations.get(g.stationId) ?? 0) + 1);
      reasons.set(reason, entry);

      const row = heat.get(g.defectCategory) ?? new Map<string, number>();
      row.set(g.stationId, (row.get(g.stationId) ?? 0) + 1);
      heat.set(g.defectCategory, row);
    });
  });

  const reasonRows: ReasonRow[] = Array.from(reasons.entries())
    .map(([reason, e]) => {
      const top = Array.from(e.stations.entries()).sort((a, b) => b[1] - a[1])[0];
      return {
        id: reason,
        reason,
        count: e.count,
        share: percent(e.count, reject),
        repeatGarments: Array.from(e.garments.values()).filter((n) => n >= 2).length,
        topStation: top ? stationCode(top[0]) : "-",
      };
    })
    .sort((a, b) => b.count - a.count);

  const multiCycle: MultiCycleRow[] = rows
    .filter((g) => g.reworkCycles >= 2)
    .sort((a, b) => b.reworkCycles - a.reworkCycles)
    .slice(0, 30)
    .map((g) => {
      const rejects = g.inspections.filter((i) => i.outcome === "Reject");
      return {
        id: g.id,
        poNumber: g.poNumber,
        station: stationCode(g.stationId),
        cycles: g.reworkCycles,
        lastReason: rejects[rejects.length - 1]?.reason ?? "-",
        status: g.status,
      };
    });

  const scrapList = rows
    .filter((g) => g.status === "Scrapped")
    .map((g) => {
      const s = g.inspections.find((i) => i.outcome === "Scrap");
      return { id: g.id, reason: s?.reason ?? "-", at: s?.at ?? g.registeredAt, inspector: s?.inspector ?? "-" };
    })
    .sort((a, b) => (a.at < b.at ? 1 : -1));

  const heatSeries = Array.from(heat.entries()).map(([category, byStation]) => ({
    name: category,
    data: STATIONS.map((s) => ({ x: s.code.replace("ST-", ""), y: byStation.get(s.id) ?? 0 })),
  }));

  return {
    inspections: pass + reject + scrap,
    pass,
    reject,
    scrap,
    inspected,
    firstTimeYield: percent(firstPass, inspected),
    recoveryRate: percent(recovered, withReject),
    multiCycleCount: rows.filter((g) => g.reworkCycles >= 2).length,
    repeatDefectGarments: reasonRows.reduce((a, r) => a + r.repeatGarments, 0),
    avgCycles: round1(avg(rows.filter((g) => g.inspections.length).map((g) => g.reworkCycles))),
    cycles,
    checklist: Array.from(checklist.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count),
    reasonRows,
    multiCycle,
    scrapList,
    heatSeries,
  };
}

/* ------------------------------------------------------------------ */
/* FR-RPT-004 Audit & activity                                         */
/* ------------------------------------------------------------------ */

export const AUDIT_TYPES: AuditType[] = [
  "Status Change",
  "Assignment",
  "Reassignment",
  "QA Decision",
  "Scrap Decision",
  "Carton Created",
  "Carton Closed",
  "User Activity",
];

export const AUDIT_GROUPS: Record<string, AuditType[]> = {
  "Status & assignment": ["Status Change", "Assignment", "Reassignment"],
  "QA decisions": ["QA Decision"],
  "Scrap decisions": ["Scrap Decision"],
  "Carton activity": ["Carton Created", "Carton Closed"],
  "User sessions": ["User Activity"],
};

export function computeAudit(filters: ReportFilters) {
  const events = selectAudit(filters);
  const b = makeBuckets(filters);

  const byType = AUDIT_TYPES.map((type) => ({ type, count: events.filter((e) => e.type === type).length }));
  const countOf = (type: AuditType) => byType.find((t) => t.type === type)?.count ?? 0;

  const groupSeries = Object.entries(AUDIT_GROUPS).map(([name, types]) => {
    const data = zeros(b.count);
    events.forEach((e) => {
      if (!types.includes(e.type)) return;
      const i = b.index(Date.parse(e.at));
      if (i >= 0) data[i]++;
    });
    return { name, data };
  });

  const users = new Map<string, number>();
  events.forEach((e) => users.set(e.user, (users.get(e.user) ?? 0) + 1));
  const topUsers = Array.from(users.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  return {
    events,
    byType,
    labels: b.labels,
    groupSeries,
    topUsers,
    totals: {
      events: events.length,
      statusChanges: countOf("Status Change"),
      assignments: countOf("Assignment") + countOf("Reassignment"),
      qaDecisions: countOf("QA Decision"),
      scrapDecisions: countOf("Scrap Decision"),
      cartonsCreated: countOf("Carton Created"),
      cartonsClosed: countOf("Carton Closed"),
    },
  };
}

/* ------------------------------------------------------------------ */
/* FR-RPT-006 Shift handover (print)                                   */
/* ------------------------------------------------------------------ */

export interface HandoverQueueRow {
  station: string;
  queued: number;
  awaitingQa: number;
  oldestHours: number;
}

export function computeHandover(filters: ReportFilters, shiftId: string) {
  const shift = SHIFTS.find((s) => s.id === shiftId) ?? SHIFTS[0];
  const start = new Date(`${filters.to}T00:00:00`).getTime() + shift.startHour * HOUR;
  const end = start + 8 * HOUR;

  const events = AUDIT_EVENTS.filter((e) => {
    const t = Date.parse(e.at);
    return t >= start && t < end && factoryOk(filters, e.factoryId);
  });
  const count = (action: string) => events.filter((e) => e.action === action).length;

  const scope = GARMENTS.filter((g) => factoryOk(filters, g.factoryId));
  const queues: HandoverQueueRow[] = STATIONS.map((s) => {
    const list = scope.filter((g) => g.stationId === s.id);
    const queued = list.filter((g) => QUEUE_STATUSES.includes(g.status));
    const oldest = queued.length ? Math.max(...queued.map((g) => (NOW - Date.parse(g.registeredAt)) / HOUR)) : 0;
    return {
      station: s.name,
      queued: queued.length,
      awaitingQa: list.filter((g) => g.status === "Awaiting QA").length,
      oldestHours: Math.round(oldest),
    };
  });

  const created = AUDIT_EVENTS.filter((e) => e.type === "Carton Created" && factoryOk(filters, e.factoryId));
  const closedRefs = new Set(
    AUDIT_EVENTS.filter((e) => e.type === "Carton Closed" && factoryOk(filters, e.factoryId)).map((e) => e.reference),
  );

  return {
    shift,
    start,
    end,
    summary: [
      { label: "Garments registered", value: count("Registered") },
      { label: "Repairs completed", value: count("Repair Completed") },
      { label: "QA approved", value: count("QA Approved") },
      { label: "QA rejected", value: count("QA Rejected") },
      { label: "Scrap decisions", value: count("Scrapped") },
      { label: "Reassignments", value: count("Reassigned") },
      { label: "Cartons created", value: count("Carton Created") },
      { label: "Cartons closed", value: count("Carton Closed") },
    ],
    queues,
    awaitingPacking: scope.filter((g) => g.status === "Awaiting Packing").length,
    openCartons: created.filter((e) => !closedRefs.has(e.reference)).length,
  };
}
