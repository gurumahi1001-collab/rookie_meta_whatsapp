import type { ApexOptions } from "apexcharts";

/** Colour system for every chart (matches the app's navy theme). */
export const CHART = {
  navy: "#242842",
  blue: "#477da8",
  green: "#087a4c",
  amber: "#c28a32",
  red: "#dc2626",
  violet: "#7c5cbf",
  teal: "#14a3a3",
  pink: "#d6558b",
  orange: "#e07a2f",
  slate: "#8a91ac",
};

export const PALETTE = [
  CHART.navy,
  CHART.blue,
  CHART.green,
  CHART.amber,
  CHART.violet,
  CHART.teal,
  CHART.red,
  CHART.pink,
  CHART.orange,
  CHART.slate,
];

const BASE: ApexOptions = {
  chart: {
    fontFamily: "Inter, sans-serif",
    foreColor: "#737b95",
    toolbar: { show: false },
    zoom: { enabled: false },
    animations: { enabled: true, speed: 450 },
  },
  colors: PALETTE,
  dataLabels: { enabled: false },
  grid: { borderColor: "#edf0f5", strokeDashArray: 4 },
  legend: {
    position: "bottom",
    fontSize: "12px",
    fontWeight: 500,
    markers: { size: 6 },
    itemMargin: { horizontal: 10, vertical: 4 },
  },
  tooltip: { theme: "light" },
  noData: { text: "No data for the selected filters" },
};

type Obj = Record<string, unknown>;

const isObj = (value: unknown): value is Obj =>
  typeof value === "object" && value !== null && !Array.isArray(value);

function deepMerge(base: Obj, extra: Obj): Obj {
  const out: Obj = { ...base };
  Object.keys(extra).forEach((key) => {
    const b = out[key];
    const e = extra[key];
    out[key] = isObj(b) && isObj(e) ? deepMerge(b, e) : e;
  });
  return out;
}

export function buildOptions(custom: ApexOptions = {}): ApexOptions {
  return deepMerge(BASE as unknown as Obj, custom as unknown as Obj) as ApexOptions;
}
