import type { DatePreset, ReportFilters } from "../types/reportTypes";

export const pad = (n: number) => String(n).padStart(2, "0");

export function toISODate(date: Date): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function presetFilters(preset: Exclude<DatePreset, "custom">, factory = "all"): ReportFilters {
  const to = new Date();
  const from = new Date();
  from.setDate(from.getDate() - (Number(preset) - 1));
  return { preset, from: toISODate(from), to: toISODate(to), factory };
}

export const formatDateTime = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });

export const formatNumber = (value: number) => value.toLocaleString("en-IN");

export const percent = (part: number, total: number, digits = 1) =>
  total > 0 ? Math.round((part / total) * 100 * 10 ** digits) / 10 ** digits : 0;

export const round1 = (value: number) => Math.round(value * 10) / 10;

export type CsvCell = string | number | null | undefined;

/** Excel / Google Sheets friendly CSV (UTF-8 BOM, CRLF, quoted cells). */
export function downloadCsv(filename: string, headers: string[], rows: CsvCell[][]) {
  const escape = (value: CsvCell) => {
    const text = value === null || value === undefined ? "" : String(value);
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };

  const csv = [headers, ...rows].map((row) => row.map(escape).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export const csvName = (report: string, filters: ReportFilters) =>
  `${report}_${filters.from}_to_${filters.to}.csv`;
