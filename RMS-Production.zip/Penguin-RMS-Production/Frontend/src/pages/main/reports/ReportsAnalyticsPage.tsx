import { useCallback, useEffect, useState } from "react";
import { ChartNoAxesColumn, FileText, Printer } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import { api } from "@/lib/api";
import { connectRealtime } from "@/lib/realtime";

import PrintPreviewModal from "./components/PrintPreviewModal";
import ReportFiltersBar from "./components/ReportFiltersBar";
import ReportTabs from "./components/ReportTabs";
import AuditActivityTab from "./tabs/AuditActivityTab";
import OverviewTab from "./tabs/OverviewTab";
import QaReworkTab from "./tabs/QaReworkTab";
import StationOperatorTab from "./tabs/StationOperatorTab";
import { setLiveReportData } from "./data/reportData";
import type { AuditEvent, AuditType, Factory, GarmentReportRecord, GarmentStatus, InspectionEntry, StationInfo } from "./types/reportTypes";
import type { PrintType, ReportFilters, ReportTab } from "./types/reportTypes";
import { presetFilters } from "./utils/reportHelpers";

import "./ReportsAnalyticsPage.scss";

type ReportDataset = {
  workOrders: Array<Record<string, unknown> & { id: string; status: string; registeredAt: string; stationId?: string; poNumber: string; qrId: string; defectCategory: string }>;
  inspections: Array<Record<string, unknown> & { workOrderId: string; decision: "Pass" | "Reject" | "Scrap"; inspectedAt: string; failedChecks?: string[]; reason?: string; inspectorName?: string }>;
  stations: Array<Record<string, unknown> & { id: string; code: string; name: string; factory?: string; operatorIds?: string[] }>;
  operators: Array<Record<string, unknown> & { id: string; name: string; stationIds?: string[] }>;
  auditActivity: Array<Record<string, unknown> & { id: string; action: string; createdAt: string; actorName?: string; title?: string; description?: string; entityName?: string; entityId?: string; module?: string }>;
};

const statusMap: Record<string, GarmentStatus> = {
  Assigned: "Registered", "In Progress": "In Repair", "Sent to QA": "Awaiting QA",
  "QA Rejected": "Awaiting Rework", "QA Passed": "Awaiting Packing", Packed: "Packed", Scrap: "Scrapped",
};

function mapAuditType(action: string): AuditType {
  if (action.startsWith("qa.scrap")) return "Scrap Decision";
  if (action.startsWith("qa.")) return "QA Decision";
  if (action.includes("carton_created") || action.includes("carton.created")) return "Carton Created";
  if (action.includes("carton_closed") || action.includes("carton.closed") || action.includes("carton.dispatched")) return "Carton Closed";
  if (action.startsWith("user.")) return "User Activity";
  if (action.includes("assigned") || action.includes("reassigned")) return "Reassignment";
  if (action.includes("work-order") || action.includes("work_order")) return "Status Change";
  return "Assignment";
}

function toReportData(raw: ReportDataset) {
  const factoryNames = [...new Set((raw.stations || []).map((item) => String(item.factory || "Factory A")))];
  const factories: Factory[] = factoryNames.map((name) => ({ id: `factory:${name}`, name }));
  if (!factories.length) factories.push({ id: "factory:unassigned", name: "Unassigned" });
  const stationFactory = new Map((raw.stations || []).map((station) => [station.id, `factory:${String(station.factory || "Factory A")}`]));
  const factoryFallback = factories[0].id;
  const stationRows: StationInfo[] = (raw.stations || []).map((station) => ({
    id: station.id, code: station.code, name: station.name, defectPool: [], baseMinutes: 0,
    operators: (raw.operators || []).filter((operator) => (operator.stationIds || []).includes(station.id)).map((operator) => operator.name),
  }));
  const inspectionsByWorkOrder = new Map<string, ReportDataset["inspections"]>();
  for (const inspection of raw.inspections || []) {
    const rows = inspectionsByWorkOrder.get(inspection.workOrderId) || [];
    rows.push(inspection); inspectionsByWorkOrder.set(inspection.workOrderId, rows);
  }
  const garments: GarmentReportRecord[] = (raw.workOrders || []).map((workOrder) => {
    const rows = inspectionsByWorkOrder.get(workOrder.id) || [];
    const inspections: InspectionEntry[] = rows.map((item) => ({
      outcome: item.decision, reason: item.reason ? String(item.reason) : undefined,
      failedChecks: Array.isArray(item.failedChecks) ? item.failedChecks.map(String) : [],
      at: item.inspectedAt, inspector: String(item.inspectorName || "Unassigned"),
    }));
    const pass = inspections.find((item) => item.outcome === "Pass");
    const registeredMs = Date.parse(workOrder.registeredAt);
    const passMs = pass ? Date.parse(pass.at) : NaN;
    const stationId = String(workOrder.stationId || "");
    return {
      id: String(workOrder.id), qrId: String(workOrder.qrId || ""), poNumber: String(workOrder.poNumber || ""),
      factoryId: stationFactory.get(stationId) || factoryFallback, registeredAt: workOrder.registeredAt,
      stationId, operator: String(workOrder.operator || ""), status: statusMap[workOrder.status] || "Registered",
      defectCategory: String(workOrder.defectCategory || "Unclassified"), processMinutes: Number(workOrder.duration || 0),
      repairedAt: workOrder.completedAt ? String(workOrder.completedAt) : workOrder.startedAt ? String(workOrder.startedAt) : undefined,
      turnaroundHours: pass && Number.isFinite(registeredMs) && Number.isFinite(passMs) ? Math.round(((passMs - registeredMs) / 3600000) * 10) / 10 : undefined,
      reworkCycles: inspections.filter((item) => item.outcome === "Reject").length, inspections,
    };
  });
  const auditEvents: AuditEvent[] = (raw.auditActivity || []).map((event) => ({
    id: String(event.id), at: String(event.createdAt), factoryId: factoryFallback,
    type: mapAuditType(String(event.action || "")), action: String(event.action || "Activity"),
    reference: String(event.entityName || event.entityId || "—"), detail: String(event.description || event.title || ""),
    user: String(event.actorName || "System"), role: "",
  }));
  return { factories, stations: stationRows, garments, auditEvents };
}

export default function ReportsAnalyticsPage() {
  const [filters, setFilters] = useState<ReportFilters>(() => presetFilters("30"));
  const [activeTab, setActiveTab] = useState<ReportTab>("overview");
  const [printType, setPrintType] = useState<PrintType | null>(null);
  const [revision, setRevision] = useState(0);
  const [loadError, setLoadError] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchDataset = useCallback(async () => {
    setLoading(true);
    try {
      const dataset = await api.get<ReportDataset>("/reports/dataset", { from: filters.from, to: filters.to });
      setLiveReportData(toReportData(dataset));
      setLoadError("");
      setRevision((value) => value + 1);
    } catch (error) {
      setLiveReportData({ factories: [], stations: [], garments: [], auditEvents: [] });
      setRevision((value) => value + 1);
      setLoadError(error instanceof Error ? error.message : "Unable to load report data.");
    } finally { setLoading(false); }
  }, [filters.from, filters.to]);

  useEffect(() => { void fetchDataset(); }, [fetchDataset]);
  useEffect(() => {
    const socket = connectRealtime();
    const onChange = () => { void fetchDataset(); };
    socket?.on("resource:changed", onChange);
    return () => { socket?.off("resource:changed", onChange); };
  }, [fetchDataset]);

  return (
    <div className="rpt-page">
      <CommonPageHeader
        className="rpt-page-header"
        icon={<ChartNoAxesColumn size={20} />}
        title="Reports & Analytics"
        subtitle="Operational, station, quality and audit reports with date range and factory filters."
        rightContent={
          <div className="rpt-header-actions">
            <CommonButton variant="outline" leftIcon={<Printer size={16} />} onClick={() => setPrintType("handover")}>Shift Handover</CommonButton>
            <CommonButton leftIcon={<FileText size={16} />} onClick={() => setPrintType("quality")}>Quality Audit Summary</CommonButton>
          </div>
        }
      />
      {loadError && <div className="alert alert-warning py-2" role="status">Live report data could not be loaded: {loadError}</div>}
      {loading && <div className="small text-muted mb-2">Refreshing report data…</div>}
      <ReportFiltersBar filters={filters} onChange={setFilters} />
      <ReportTabs activeTab={activeTab} onChange={setActiveTab} />
      {activeTab === "overview" && <OverviewTab filters={filters} revision={revision} />}
      {activeTab === "stations" && <StationOperatorTab filters={filters} revision={revision} />}
      {activeTab === "qa" && <QaReworkTab filters={filters} revision={revision} />}
      {activeTab === "audit" && <AuditActivityTab filters={filters} revision={revision} />}
      <PrintPreviewModal type={printType} filters={filters} onClose={() => setPrintType(null)} />
    </div>
  );
}
