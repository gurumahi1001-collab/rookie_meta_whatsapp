import { useMemo } from "react";
import type { ApexOptions } from "apexcharts";
import { Clock, Hourglass, PackageCheck, ShieldX, Users } from "lucide-react";

import { CommonDataTable, type TableColumn } from "@/components/common/data-table";

import ChartCard from "../components/ChartCard";
import KpiCard from "../components/KpiCard";
import ReportChart from "../components/ReportChart";
import TableCard from "../components/TableCard";
import type { ReportFilters } from "../types/reportTypes";
import { CHART, PALETTE } from "../utils/chartTheme";
import { csvName, downloadCsv, formatNumber } from "../utils/reportHelpers";
import { computeStations, type OperatorRow, type StationRow } from "../utils/reportMetrics";

const Progress = ({ value, color }: { value: number; color: string }) => (
  <div className="rpt-progress">
    <span style={{ width: `${Math.min(100, value)}%`, background: color }} />
    <em>{value}%</em>
  </div>
);

export default function StationOperatorTab({ filters, revision = 0 }: { filters: ReportFilters; revision?: number }) {
  const data = useMemo(() => computeStations(filters), [filters, revision]);
  const stationNames = data.stations.map((s) => s.code.replace("ST-", ""));

  const processedOptions: ApexOptions = {
    colors: [CHART.green, CHART.amber],
    chart: { stacked: true },
    plotOptions: { bar: { columnWidth: "48%", borderRadius: 4 } },
    xaxis: { categories: stationNames },
  };

  const queueOptions: ApexOptions = {
    labels: stationNames,
    colors: PALETTE,
    stroke: { width: 2, colors: ["#fff"] },
    plotOptions: { pie: { donut: { size: "64%", labels: { show: true, total: { show: true, label: "Pending" } } } } },
  };

  const workloadOptions: ApexOptions = {
    colors: [CHART.navy, CHART.teal, CHART.orange],
    stroke: { width: [0, 0, 3], curve: "smooth" },
    plotOptions: { bar: { columnWidth: "55%", borderRadius: 3 } },
    xaxis: { categories: stationNames },
    yaxis: [
      { title: { text: "Garments" } },
      { show: false },
      { opposite: true, max: 100, title: { text: "Throughput %" } },
    ],
  };

  const avgTimeOptions: ApexOptions = {
    colors: [CHART.violet],
    stroke: { width: 2 },
    fill: { opacity: 0.25 },
    markers: { size: 4 },
    xaxis: { categories: stationNames },
  };

  const operatorOptions: ApexOptions = {
    colors: [CHART.blue],
    chart: { stacked: true },
    plotOptions: { bar: { horizontal: true, barHeight: "58%", borderRadius: 3 } },
    xaxis: { categories: data.operators.map((o) => o.operator) },
  };

  const rejectOptions: ApexOptions = {
    colors: [CHART.red, CHART.pink],
    plotOptions: { bar: { columnWidth: "50%", borderRadius: 4 } },
    xaxis: { categories: data.operators.map((o) => o.operator.split(" ")[0]) },
    yaxis: { labels: { formatter: (v: number) => String(Math.round(v)) } },
  };

  const stationColumns: TableColumn<StationRow>[] = [
    {
      field: "station",
      header: "Station",
      minWidth: "220px",
      body: (r) => (
        <div className="rpt-cell">
          <strong>{r.station}</strong>
          <small>{r.code}</small>
        </div>
      ),
    },
    { field: "assigned", header: "Assigned", align: "right", sortable: true },
    { field: "processed", header: "Processed", align: "right", sortable: true },
    { field: "pending", header: "Pending queue", align: "right", sortable: true },
    { field: "avgMinutes", header: "Avg time (min)", align: "right", sortable: true },
    { field: "rejections", header: "QA rejections", align: "right", sortable: true },
    {
      field: "throughput",
      header: "Throughput",
      minWidth: "170px",
      body: (r) => <Progress value={r.throughput} color={CHART.green} />,
    },
  ];

  const operatorColumns: TableColumn<OperatorRow>[] = [
    { field: "operator", header: "Operator", minWidth: "180px", sortable: true },
    { field: "stations", header: "Stations", minWidth: "170px" },
    { field: "assigned", header: "Assigned", align: "right", sortable: true },
    { field: "completed", header: "Completed jobs", align: "right", sortable: true },
    { field: "pending", header: "Pending", align: "right", sortable: true },
    { field: "avgMinutes", header: "Avg time (min)", align: "right", sortable: true },
    { field: "rejections", header: "QA rejections", align: "right", sortable: true },
    {
      field: "rejectionRate",
      header: "Rejection rate",
      minWidth: "160px",
      body: (r) => <Progress value={r.rejectionRate} color={CHART.red} />,
    },
  ];

  const exportStations = () =>
    downloadCsv(
      csvName("station-report", filters),
      ["Station", "Code", "Assigned", "Processed", "Pending queue", "Avg time (min)", "QA rejections", "Throughput %"],
      data.stations.map((r) => [r.station, r.code, r.assigned, r.processed, r.pending, r.avgMinutes, r.rejections, r.throughput]),
    );

  const exportOperators = () =>
    downloadCsv(
      csvName("operator-report", filters),
      ["Operator", "Stations", "Assigned", "Completed jobs", "Pending", "Avg time (min)", "QA rejections", "Rejection rate %"],
      data.operators.map((r) => [r.operator, r.stations, r.assigned, r.completed, r.pending, r.avgMinutes, r.rejections, r.rejectionRate]),
    );

  return (
    <div className="rpt-grid">
      <div className="rpt-kpis rpt-span-12">
        <KpiCard label="Garments processed" value={formatNumber(data.totals.processed)} icon={<PackageCheck size={20} />} tone="success" />
        <KpiCard label="Pending queue" value={formatNumber(data.totals.pending)} icon={<Hourglass size={20} />} tone="warning" />
        <KpiCard label="Avg processing time" value={`${data.totals.avgMinutes} min`} icon={<Clock size={20} />} tone="info" />
        <KpiCard label="QA rejections" value={formatNumber(data.totals.rejections)} icon={<ShieldX size={20} />} tone="danger" />
        <KpiCard label="Active operators" value={data.totals.activeOperators} icon={<Users size={20} />} tone="primary" />
      </div>

      <ChartCard span={7} title="Garments processed by station" subtitle="Processed vs still pending">
        <ReportChart
          type="bar"
          options={processedOptions}
          series={[
            { name: "Processed", data: data.stations.map((s) => s.processed) },
            { name: "Pending", data: data.stations.map((s) => s.pending) },
          ]}
        />
      </ChartCard>

      <ChartCard span={5} title="Pending queue share" subtitle="Where the waiting garments are">
        <ReportChart type="donut" options={queueOptions} series={data.stations.map((s) => s.pending)} />
      </ChartCard>

      <ChartCard span={7} title="Workload vs throughput" subtitle="Assigned and processed volume with throughput %">
        <ReportChart
          type="line"
          options={workloadOptions}
          series={[
            { name: "Assigned", type: "column", data: data.stations.map((s) => s.assigned) },
            { name: "Processed", type: "column", data: data.stations.map((s) => s.processed) },
            { name: "Throughput %", type: "line", data: data.stations.map((s) => s.throughput) },
          ]}
        />
      </ChartCard>

      <ChartCard span={5} title="Average processing time" subtitle="Minutes per garment">
        <ReportChart
          type="radar"
          options={avgTimeOptions}
          series={[{ name: "Avg minutes", data: data.stations.map((s) => s.avgMinutes) }]}
        />
      </ChartCard>

      <ChartCard span={6} title="Completed jobs by operator" subtitle="Completed vs pending jobs">
        <ReportChart
          type="bar"
          height={340}
          options={{ ...operatorOptions, colors: [CHART.blue, CHART.amber] }}
          series={[
            { name: "Completed", data: data.operators.map((o) => o.completed) },
            { name: "Pending", data: data.operators.map((o) => o.pending) },
          ]}
        />
      </ChartCard>

      <ChartCard span={6} title="QA rejections by operator" subtitle="Rejection count and rate (%)">
        <ReportChart
          type="bar"
          height={340}
          options={rejectOptions}
          series={[
            { name: "Rejections", data: data.operators.map((o) => o.rejections) },
            { name: "Rejection rate %", data: data.operators.map((o) => o.rejectionRate) },
          ]}
        />
      </ChartCard>

      <TableCard title="Station performance" subtitle="Processed volume, queue, time and QA rejections" onExport={exportStations}>
        <CommonDataTable data={data.stations} columns={stationColumns} dataKey="id" paginator={false} />
      </TableCard>

      <TableCard title="Operator performance" subtitle="Completed jobs, pending queue and rejection rate" onExport={exportOperators}>
        <CommonDataTable data={data.operators} columns={operatorColumns} dataKey="id" rows={8} rowsPerPageOptions={[8, 16]} />
      </TableCard>
    </div>
  );
}
