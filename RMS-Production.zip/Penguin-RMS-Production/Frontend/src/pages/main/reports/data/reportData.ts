import type { AuditEvent, Factory, GarmentReportRecord, StationInfo, ShiftInfo } from "../types/reportTypes";

export const HOUR = 3600000;
export const DAY = 24 * HOUR;
export const NOW = Date.now();
export const DATA_DAYS = 90;

// These collections are populated from /reports/dataset and replaced on live updates.
export let FACTORIES: Factory[] = [];
export let STATIONS: StationInfo[] = [];
export let GARMENTS: GarmentReportRecord[] = [];
export let AUDIT_EVENTS: AuditEvent[] = [];

export const SHIFTS: ShiftInfo[] = [
  { id: "A", label: "Shift A (06:00 - 14:00)", startHour: 6 },
  { id: "B", label: "Shift B (14:00 - 22:00)", startHour: 14 },
  { id: "C", label: "Shift C (22:00 - 06:00)", startHour: 22 },
];

export const DEFECT_CATEGORIES = [
  "Stitching Defect", "Stain", "Fabric Damage", "Tear or Hole",
  "Color Defect", "Measurement Issue", "Missing Button/Accessory",
];

export const CHECKLIST_ITEMS = [
  "Stitching uniformity", "Seam and stitch quality", "Stain removal",
  "Fabric reinforcement / darning", "Measurements within tolerance",
  "Accessories and trims", "Final finishing", "Other agreed inspection items",
];

export function setLiveReportData(data: {
  factories: Factory[]; stations: StationInfo[]; garments: GarmentReportRecord[]; auditEvents: AuditEvent[];
}) {
  FACTORIES = data.factories;
  STATIONS = data.stations;
  GARMENTS = data.garments;
  AUDIT_EVENTS = data.auditEvents;
}
