import { useMemo } from "react";
import Chart from "react-apexcharts";
import type { ApexOptions } from "apexcharts";

import { buildOptions } from "../utils/chartTheme";

type ChartType =
  | "area"
  | "line"
  | "bar"
  | "pie"
  | "donut"
  | "radialBar"
  | "scatter"
  | "bubble"
  | "heatmap"
  | "treemap"
  | "radar"
  | "polarArea";

interface ReportChartProps {
  type: ChartType;
  series: ApexOptions["series"];
  options?: ApexOptions;
  height?: number | string;
}

/** Thin wrapper: applies the shared theme to every ApexChart. */
export default function ReportChart({ type, series, options, height = 300 }: ReportChartProps) {
  const merged = useMemo(
    () => buildOptions({ ...options, chart: { ...options?.chart, type } }),
    [options, type],
  );

  return <Chart type={type} series={series} options={merged} height={height} width="100%" />;
}
