import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Printer } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

import { SHIFTS } from "../data/reportData";
import type { PrintType, ReportFilters } from "../types/reportTypes";
import { QualityAuditSheet, ShiftHandoverSheet } from "./PrintSheets";

interface Props {
  type: PrintType | null;
  filters: ReportFilters;
  onClose: () => void;
}

const shiftOptions = SHIFTS.map((s) => ({ label: s.label, value: s.id }));

export default function PrintPreviewModal({ type, filters, onClose }: Props) {
  const [shiftId, setShiftId] = useState("A");

  // Safety: never leave the print class on <body>
  useEffect(() => () => document.body.classList.remove("rpt-printing"), []);

  if (!type) return null;

  const sheet =
    type === "handover" ? (
      <ShiftHandoverSheet filters={filters} shiftId={shiftId} />
    ) : (
      <QualityAuditSheet filters={filters} />
    );

  const handlePrint = () => {
    const cleanup = () => {
      document.body.classList.remove("rpt-printing");
      window.removeEventListener("afterprint", cleanup);
    };
    document.body.classList.add("rpt-printing");
    window.addEventListener("afterprint", cleanup);
    window.print();
  };

  return (
    <>
      <CommonModal
        show
        size="xl"
        onClose={onClose}
        headerIcon={<Printer size={18} />}
        title={type === "handover" ? "Shift Handover Report" : "Quality Audit Summary"}
        subtitle="Preview the printable report, then press Print."
        bodyClassName="rpt-print-modal-body"
        footer={
          <>
            <CommonButton variant="outline" onClick={onClose}>
              Close
            </CommonButton>
            <CommonButton leftIcon={<Printer size={16} />} onClick={handlePrint}>
              Print
            </CommonButton>
          </>
        }
      >
        {type === "handover" && (
          <div className="rpt-print-controls">
            <CommonSelect
              label="Shift"
              options={shiftOptions}
              value={shiftId}
              onChange={(v) => setShiftId(String(v ?? "A"))}
              hint={`Covers the selected "To" date: ${filters.to}`}
            />
          </div>
        )}
        <div className="rpt-print-preview">{sheet}</div>
      </CommonModal>

      {createPortal(<div className="rpt-print-root">{sheet}</div>, document.body)}
    </>
  );
}
