import type { ReactNode } from "react";

interface ChartCardProps {
  title: string;
  subtitle?: string;
  /** Grid columns out of 12 on desktop. */
  span?: 3 | 4 | 5 | 6 | 7 | 8 | 12;
  actions?: ReactNode;
  children: ReactNode;
}

export default function ChartCard({ title, subtitle, span = 6, actions, children }: ChartCardProps) {
  return (
    <section className={`rpt-card rpt-span-${span}`}>
      <header className="rpt-card__head">
        <div>
          <h3>{title}</h3>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {actions}
      </header>
      <div className="rpt-card__body">{children}</div>
    </section>
  );
}
