import type { ReactNode } from "react";
import { Download } from "lucide-react";

import CommonButton from "@/components/common/ui/button/CommonButton";

interface TableCardProps {
  title: string;
  subtitle?: string;
  onExport?: () => void;
  toolbar?: ReactNode;
  children: ReactNode;
}

export default function TableCard({ title, subtitle, onExport, toolbar, children }: TableCardProps) {
  return (
    <section className="rpt-card rpt-span-12">
      <header className="rpt-card__head">
        <div>
          <h3>{title}</h3>
          {subtitle && <p>{subtitle}</p>}
        </div>
        <div className="rpt-card__tools">
          {toolbar}
          {onExport && (
            <CommonButton size="sm" variant="outline" leftIcon={<Download size={14} />} onClick={onExport}>
              Export CSV
            </CommonButton>
          )}
        </div>
      </header>
      <div className="rpt-card__body rpt-card__body--table">{children}</div>
    </section>
  );
}
