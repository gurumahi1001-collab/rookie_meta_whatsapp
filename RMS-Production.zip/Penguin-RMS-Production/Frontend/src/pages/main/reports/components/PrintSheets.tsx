import type { ReactNode } from "react";

import { FACTORIES } from "../data/reportData";
import type { ReportFilters } from "../types/reportTypes";
import { formatDate, formatDateTime, formatNumber } from "../utils/reportHelpers";
import { computeHandover, computeQa } from "../utils/reportMetrics";

const factoryLabel = (filters: ReportFilters) =>
  filters.factory === "all"
    ? "All factories"
    : (FACTORIES.find((f) => f.id === filters.factory)?.name ?? filters.factory);

function SheetHead({ title, lines }: { title: string; lines: Array<[string, string]> }) {
  return (
    <header className="rpt-sheet__head">
      <div>
        <h1>{title}</h1>
        <p>Garment Rework &amp; QA Management System</p>
      </div>
      <dl>
        {lines.map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
    </header>
  );
}

function Signatures({ left, right }: { left: string; right: string }) {
  return (
    <div className="rpt-sheet__sign">
      {[left, right].map((label) => (
        <div key={label}>
          <span />
          <p>{label}</p>
          <small>Name / Signature / Date &amp; time</small>
        </div>
      ))}
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rpt-sheet__section">
      <h2>{title}</h2>
      {children}
    </section>
  );
}

/* ---------------- FR-RPT-006: shift handover ---------------- */

export function ShiftHandoverSheet({ filters, shiftId }: { filters: ReportFilters; shiftId: string }) {
  const data = computeHandover(filters, shiftId);

  return (
    <div className="rpt-sheet">
      <SheetHead
        title="Shift Handover Report"
        lines={[
          ["Factory", factoryLabel(filters)],
          ["Shift", data.shift.label],
          ["Window", `${formatDateTime(new Date(data.start).toISOString())} - ${formatDateTime(new Date(data.end).toISOString())}`],
          ["Generated", formatDateTime(new Date().toISOString())],
        ]}
      />

      <Section title="1. Shift summary">
        <table className="rpt-sheet__table">
          <tbody>
            {[0, 4].map((offset) => (
              <tr key={offset}>
                {data.summary.slice(offset, offset + 4).map((item) => (
                  <td key={item.label}>
                    <b>{item.value}</b>
                    <span>{item.label}</span>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section title="2. Pending queues at handover">
        <table className="rpt-sheet__table rpt-sheet__table--grid">
          <thead>
            <tr>
              <th>Station</th>
              <th>Queued for repair / rework</th>
              <th>Awaiting QA</th>
              <th>Oldest item (hrs)</th>
            </tr>
          </thead>
          <tbody>
            {data.queues.map((row) => (
              <tr key={row.station}>
                <td>{row.station}</td>
                <td>{row.queued}</td>
                <td>{row.awaitingQa}</td>
                <td>{row.oldestHours}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section title="3. Packing status">
        <p className="rpt-sheet__text">
          Garments awaiting packing: <b>{data.awaitingPacking}</b> &nbsp;|&nbsp; Open cartons: <b>{data.openCartons}</b>
        </p>
      </Section>

      <Section title="4. Notes for incoming shift">
        <div className="rpt-sheet__lines">
          <span />
          <span />
          <span />
        </div>
      </Section>

      <Signatures left="Outgoing shift supervisor" right="Incoming shift supervisor" />
    </div>
  );
}

/* ---------------- FR-RPT-006: quality audit summary ---------------- */

export function QualityAuditSheet({ filters }: { filters: ReportFilters }) {
  const qa = computeQa(filters);

  return (
    <div className="rpt-sheet">
      <SheetHead
        title="Quality Audit Summary"
        lines={[
          ["Factory", factoryLabel(filters)],
          ["Period", `${formatDate(`${filters.from}T00:00:00`)} - ${formatDate(`${filters.to}T00:00:00`)}`],
          ["Generated", formatDateTime(new Date().toISOString())],
        ]}
      />

      <Section title="1. Inspection summary">
        <table className="rpt-sheet__table">
          <tbody>
            <tr>
              {[
                ["Inspections", formatNumber(qa.inspections)],
                ["Passed", formatNumber(qa.pass)],
                ["Rejected", formatNumber(qa.reject)],
                ["Scrapped", formatNumber(qa.scrap)],
              ].map(([label, value]) => (
                <td key={label}>
                  <b>{value}</b>
                  <span>{label}</span>
                </td>
              ))}
            </tr>
            <tr>
              {[
                ["First-time yield", `${qa.firstTimeYield}%`],
                ["Rework recovery rate", `${qa.recoveryRate}%`],
                ["Multi-cycle garments", formatNumber(qa.multiCycleCount)],
                ["Avg rework cycles", String(qa.avgCycles)],
              ].map(([label, value]) => (
                <td key={label}>
                  <b>{value}</b>
                  <span>{label}</span>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </Section>

      <Section title="2. Top rejection reasons">
        <table className="rpt-sheet__table rpt-sheet__table--grid">
          <thead>
            <tr>
              <th>Reason</th>
              <th>Rejections</th>
              <th>Share</th>
              <th>Main station</th>
            </tr>
          </thead>
          <tbody>
            {qa.reasonRows.slice(0, 6).map((row) => (
              <tr key={row.id}>
                <td>{row.reason}</td>
                <td>{row.count}</td>
                <td>{row.share}%</td>
                <td>{row.topStation}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section title="3. Checklist failures">
        <table className="rpt-sheet__table rpt-sheet__table--grid">
          <thead>
            <tr>
              <th>Checklist item</th>
              <th>Failures</th>
            </tr>
          </thead>
          <tbody>
            {qa.checklist.slice(0, 6).map((row) => (
              <tr key={row.name}>
                <td>{row.name}</td>
                <td>{row.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section title="4. Scrap decisions">
        {qa.scrapList.length === 0 ? (
          <p className="rpt-sheet__text">No scrap decisions in this period.</p>
        ) : (
          <table className="rpt-sheet__table rpt-sheet__table--grid">
            <thead>
              <tr>
                <th>Garment</th>
                <th>Reason</th>
                <th>Inspector</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {qa.scrapList.slice(0, 8).map((row) => (
                <tr key={row.id}>
                  <td>{row.id}</td>
                  <td>{row.reason}</td>
                  <td>{row.inspector}</td>
                  <td>{formatDate(row.at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Section>

      <Signatures left="QA Manager" right="Production Manager" />
    </div>
  );
}
