import type { ReactNode } from "react";
import type { Tone } from "@/constants/status";

interface KpiCardProps {
  label: string;
  value: string | number;
  hint?: string;
  icon: ReactNode;
  tone?: Tone;
}

export default function KpiCard({ label, value, hint, icon, tone = "primary" }: KpiCardProps) {
  return (
    <div className="rpt-kpi">
      <span className={`app-icon-box app-icon-box--${tone}`}>{icon}</span>
      <div className="rpt-kpi__copy">
        <small>{label}</small>
        <strong>{value}</strong>
        {hint && <em>{hint}</em>}
      </div>
    </div>
  );
}
