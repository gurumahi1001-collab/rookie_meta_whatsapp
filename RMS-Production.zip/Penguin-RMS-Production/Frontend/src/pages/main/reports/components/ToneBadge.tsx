import type { Tone } from "@/constants/status";

/** Re-uses the global `.app-status` badge styles from _theme.scss. */
export default function ToneBadge({ label, tone }: { label: string; tone: Tone }) {
  return (
    <span className={`app-status app-status--${tone}`}>
      <span className="app-status__dot" />
      {label}
    </span>
  );
}
