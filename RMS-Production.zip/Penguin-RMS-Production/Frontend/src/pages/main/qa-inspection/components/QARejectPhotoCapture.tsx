import { useEffect, useRef, useState } from "react";
import { Camera, ImagePlus, LoaderCircle, Pencil, Trash2, Upload, X } from "lucide-react";
import DefectPhotoEditor from "../../qr-rework/tab/editor/DefectPhotoEditor";

type Props = { value: string; onChange: (image: string) => void };

export default function QARejectPhotoCapture({ value, onChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraLoading, setCameraLoading] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [rawImage, setRawImage] = useState("");
  const [imageName, setImageName] = useState("Rejected-item-photo.jpg");
  const [showEditor, setShowEditor] = useState(false);

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (!showCamera) return;
    let cancelled = false;
    const start = async () => {
      setCameraLoading(true);
      setCameraError("");
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera is unavailable");
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" } }, audio: false,
        });
        if (cancelled) { stream.getTracks().forEach((track) => track.stop()); return; }
        streamRef.current = stream;
        if (!videoRef.current) throw new Error("Camera preview is unavailable");
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        if (!cancelled) setCameraLoading(false);
      } catch {
        if (!cancelled) {
          setCameraLoading(false);
          setCameraError("Unable to access the camera. Please allow permission or upload an image instead.");
        }
      }
    };
    void start();
    return () => { cancelled = true; stopCamera(); };
  }, [showCamera]);

  const loadFile = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setRawImage(reader.result);
        setImageName(file.name);
        setShowEditor(true);
      }
    };
    reader.readAsDataURL(file);
  };

  const capture = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth || !video.videoHeight) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    if (!context) return;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    setRawImage(canvas.toDataURL("image/jpeg", 0.92));
    setImageName(`QA-Rejected-${Date.now()}.jpg`);
    setShowCamera(false);
    setShowEditor(true);
  };

  return (
    <div className="qa-reject-photo-field">
      <div className="qa-reject-photo-heading">
        <div><strong>Rejected Item Photo</strong><small>Upload or capture the damaged area, then mark it before saving.</small></div>
        <ImagePlus size={19} />
      </div>
      <input ref={inputRef} hidden type="file" accept="image/*" onChange={(event) => { loadFile(event.target.files?.[0]); event.target.value = ""; }} />
      {value ? (
        <div className="qa-reject-photo-preview">
          <img src={value} alt="Annotated rejected garment" />
          <div className="qa-reject-photo-actions">
            <button type="button" title="Edit damage marks" onClick={() => { setRawImage(value); setShowEditor(true); }}><Pencil size={15} /></button>
            <button type="button" title="Replace photo" onClick={() => inputRef.current?.click()}><Upload size={15} /></button>
            <button type="button" title="Remove photo" onClick={() => onChange("")}><Trash2 size={15} /></button>
          </div>
        </div>
      ) : (
        <div className="qa-reject-photo-empty">
          <Camera size={24} />
          <span>No rejected-item photo added</span>
          <div>
            <button type="button" onClick={() => inputRef.current?.click()}><Upload size={14} /> Upload Photo</button>
            <button type="button" onClick={() => setShowCamera(true)}><Camera size={14} /> Take Photo</button>
          </div>
        </div>
      )}
      {showCamera && (
        <div className="qa-reject-camera-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) { stopCamera(); setShowCamera(false); } }}>
          <div className="qa-reject-camera-modal" role="dialog" aria-modal="true" aria-label="Capture rejected item photo">
            <header><div><strong>Capture Rejected Item Photo</strong><small>Keep the damaged area clearly visible.</small></div><button type="button" title="Close" onClick={() => { stopCamera(); setShowCamera(false); }}><X size={18} /></button></header>
            <div className="qa-reject-camera-preview">
              <video ref={videoRef} autoPlay playsInline muted />
              {cameraLoading && <div><LoaderCircle className="qa-camera-spin" size={28} /><span>Preparing camera...</span></div>}
              {cameraError && <div className="qa-reject-camera-error"><span>{cameraError}</span></div>}
            </div>
            <footer><button type="button" className="qa-reject-camera-cancel" onClick={() => { stopCamera(); setShowCamera(false); }}>Cancel</button><button type="button" disabled={cameraLoading || !!cameraError} onClick={capture}><Camera size={16} /> Capture Photo</button></footer>
          </div>
        </div>
      )}
      {showEditor && rawImage && <DefectPhotoEditor image={rawImage} imageName={imageName} onClose={() => { setShowEditor(false); setRawImage(""); }} onSave={(annotated) => { onChange(annotated); setShowEditor(false); setRawImage(""); }} />}
    </div>
  );
}
