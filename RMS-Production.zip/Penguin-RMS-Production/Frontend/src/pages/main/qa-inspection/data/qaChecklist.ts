import type { ChecklistItem } from "../types/qaTypes";

/**
 * Demo checklist configuration.
 * In production, load and save this configuration through an Administrator API.
 */
export const initialQAChecklist: ChecklistItem[] = [
  { id: "CHK-01", title: "Stitching uniformity", category: "Stitching & Seams", active: true, required: true },
  { id: "CHK-02", title: "Seam and stitch quality", category: "Stitching & Seams", active: true, required: true },
  { id: "CHK-03", title: "Stain removal", category: "Fabric Appearance", active: true, required: true },
  { id: "CHK-04", title: "Fabric reinforcement / darning", category: "Fabric Integrity", active: true, required: true },
  { id: "CHK-05", title: "Measurements within tolerance", category: "Measurements", active: true, required: true },
  { id: "CHK-06", title: "Accessories and trims", category: "Accessories & Trims", active: true, required: true },
  { id: "CHK-07", title: "Final finishing", category: "Finishing", active: true, required: true },
  { id: "CHK-08", title: "Other agreed inspection items", category: "Additional Checks", active: true, required: false },
];
