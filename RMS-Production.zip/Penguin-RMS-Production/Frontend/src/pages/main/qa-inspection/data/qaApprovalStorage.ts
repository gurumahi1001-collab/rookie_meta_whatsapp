export const QA_APPROVED_GARMENTS_STORAGE_KEY = "penguin.qa-approved-garments.v1";

export interface QAApprovedGarmentSnapshot {
  id: string;
  workOrderId: string;
  garmentId: string;
  qrId: string;
  poNumber: string;
  styleNumber: string;
  size: string;
  qaApprovedAt: string;
}
