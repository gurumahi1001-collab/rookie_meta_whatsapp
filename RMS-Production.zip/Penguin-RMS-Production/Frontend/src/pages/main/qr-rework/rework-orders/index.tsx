import { useEffect, useState } from "react";
import { QrCode, ScanLine } from "lucide-react";

import CommonPageHeader from "@/components/common/ui/page-header/CommonPageHeader";
import type { ReworkRecord } from "../type/type";
import { useLiveResource } from "@/hooks/useLiveResource";
import { api } from "@/lib/api";

import "./QRReworkManagementPage.scss";

import QRScannerRegistrationTab from "../tab/QRScannerRegistrationTab";
import ReworkOrdersTab from "../tab/ReworkOrdersTab";
import ReworkTracePage from "../trace";

type ActiveTab = "orders" | "scanner";

export default function QRReworkManagementPage() {
  const workOrders = useLiveResource<ReworkRecord>({ endpoint: "/work-orders", resource: "work-orders" });
  const [records, setRecords] = useState<ReworkRecord[]>([]);
  const [activeTab, setActiveTab] = useState<ActiveTab>("scanner");
  const [traceRecord, setTraceRecord] = useState<ReworkRecord | null>(null);

  useEffect(() => {
    setRecords(workOrders.data.map((item) => ({
      ...item,
      registeredDate: item.registeredDate || (item.registeredAt ? new Date(item.registeredAt).toLocaleDateString("en-GB") : ""),
      history: Array.isArray(item.history) ? item.history : [],
    })));
  }, [workOrders.data]);

  const handleRegister = async (record: ReworkRecord) => {
    try {
      let defectImage = record.defectImage || "";
      if (defectImage.startsWith("data:image/")) {
        const blob = await fetch(defectImage).then((response) => response.blob());
        const form = new FormData();
        form.append("file", blob, `defect-${record.qrId}.jpg`);
        const uploaded = await api.upload<{ url: string }>("/uploads", form);
        defectImage = uploaded.url;
      }
      await workOrders.create({
        ...record,
        defectImage,
        defectImageUrl: defectImage,
        registeredAt: new Date().toISOString(),
        registeredDate: record.registeredDate || new Date().toLocaleDateString("en-GB"),
        history: record.history || [],
      });
      setActiveTab("orders");
      setTraceRecord(null);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "Unable to register the garment.");
    }
  };

  const handleTabChange = (tab: ActiveTab) => {
    setActiveTab(tab);
    setTraceRecord(null);
  };

  return (
    <div className="qr-rework-page">
      {!traceRecord && (
        <>
          <CommonPageHeader
            icon={<QrCode size={21} />}
            title="QR & Rework Management"
            subtitle="Scan garment QR labels, register defects and manage active rework orders."
          />

          <div className="qr-tab-navigation">
            <button
              type="button"
              className={`qr-header-tab ${
                activeTab === "scanner" ? "active" : ""
              }`}
              onClick={() => handleTabChange("scanner")}
            >
              <span className="qr-tab-icon">
                <ScanLine size={17} />
              </span>

              <span className="qr-tab-content">
                <strong>QR Scanner & Registration</strong>
                <small>Scan labels and register defects</small>
              </span>
            </button>

            <button
              type="button"
              className={`qr-header-tab ${
                activeTab === "orders" ? "active" : ""
              }`}
              onClick={() => handleTabChange("orders")}
            >
              <span className="qr-tab-icon">
                <QrCode size={17} />
              </span>

              <span className="qr-tab-content">
                <strong>Rework Orders</strong>
                <small>{records.length} registered orders</small>
              </span>

              <span className="qr-tab-count">{records.length}</span>
            </button>
          </div>
        </>
      )}

      {traceRecord ? (
        <ReworkTracePage
          record={traceRecord}
          onBack={() => setTraceRecord(null)}
        />
      ) : activeTab === "orders" ? (
        <ReworkOrdersTab records={records} onTrace={setTraceRecord} />
      ) : (
        <QRScannerRegistrationTab onRegister={handleRegister} />
      )}
    </div>
  );
}