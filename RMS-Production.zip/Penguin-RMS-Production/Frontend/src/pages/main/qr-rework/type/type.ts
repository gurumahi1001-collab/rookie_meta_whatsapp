export type ReworkStatus =
  | "Assigned" | "In Progress" | "Sent to QA" | "QA Passed"
  | "QA Rejected" | "Packed" | "Scrap";
export type Severity = "Minor" | "Major" | "Critical";

export interface ReworkHistoryItem {
  title: string;
  description: string;
  date: string;
  status: "completed" | "pending";
}

export interface ReworkRecord {
  id: string;
  reworkId: string;
  qrId: string;
  poNumber: string;
  defectCategory: string;
  severity: Severity;
  assignedStation: string;
  duration: number;
  status: ReworkStatus;
  garmentId: string;
  styleNumber: string;
  operator: string;
  description: string;
  registeredDate: string;
  history: ReworkHistoryItem[];
   defectImage?: string;
  stationId?: string;
  operatorId?: string;
  size?: string;
}
