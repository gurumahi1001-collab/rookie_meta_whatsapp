import { useMemo, useState } from "react";
import { Eye, RefreshCw, Search } from "lucide-react";

import type { ReworkRecord } from "../type/type";
import {
  type TableColumn,
  CommonDataTable,
} from "@/components/common/data-table";
import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";

const statuses = [
  "Assigned",
  "In Progress",
  "Sent to QA",
  "QA Passed",
  "QA Rejected",
  "Packed",
  "Scrap",
];

export default function ReworkOrdersTab({
  records,
  onTrace,
}: {
  records: ReworkRecord[];
  onTrace: (record: ReworkRecord) => void;
}) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [po, setPo] = useState("all");
  const [operator, setOperator] = useState("all");
  const [age, setAge] = useState("all");

  const statusOptions = [
    { label: "All Statuses", value: "all" },
    ...statuses.map((v) => ({ label: v, value: v })),
  ];
  const poOptions = useMemo(
    () => [
      { label: "All Purchase Orders", value: "all" },
      ...Array.from(new Set(records.map((r) => r.poNumber))).map((v) => ({
        label: v,
        value: v,
      })),
    ],
    [records],
  );
  const operatorOptions = useMemo(
    () => [
      { label: "All Stations & Operators", value: "all" },
      ...Array.from(new Set(records.map((r) => r.assignedStation))).map(
        (v) => ({ label: v, value: v }),
      ),
    ],
    [records],
  );
  const ageOptions = [
    { label: "All Durations / Ages", value: "all" },
    { label: "0 - 7 Days", value: "0-7" },
    { label: "8 - 15 Days", value: "8-15" },
    { label: "16 - 30 Days", value: "16-30" },
    { label: "Above 30 Days", value: "30+" },
  ];

  const filteredRecords = useMemo(
    () =>
      records.filter((record) => {
        const query = search.trim().toLowerCase();
        const matchesSearch =
          !query ||
          [
            record.reworkId,
            record.qrId,
            record.poNumber,
            record.defectCategory,
          ].some((value) => value.toLowerCase().includes(query));
        const matchesAge =
          age === "all" ||
          (age === "0-7" && record.duration <= 7) ||
          (age === "8-15" && record.duration >= 8 && record.duration <= 15) ||
          (age === "16-30" && record.duration >= 16 && record.duration <= 30) ||
          (age === "30+" && record.duration > 30);
        return (
          matchesSearch &&
          (status === "all" || record.status === status) &&
          (po === "all" || record.poNumber === po) &&
          (operator === "all" || record.assignedStation === operator) &&
          matchesAge
        );
      }),
    [records, search, status, po, operator, age],
  );

  const count = (predicate: (record: ReworkRecord) => boolean) =>
    records.filter(predicate).length;
  const statusClass = (value: string) =>
    value.toLowerCase().replace(/\s+/g, "-");

  const columns: TableColumn<ReworkRecord>[] = [
    {
      field: "reworkId",
      header: "REWORK ID",
      sortable: true,
      minWidth: "135px",
      body: (row) => <strong className="qr-rework-id">{row.reworkId}</strong>,
    },
    { field: "qrId", header: "QR ID", sortable: true, minWidth: "125px" },
    {
      field: "poNumber",
      header: "PO NUMBER",
      sortable: true,
      minWidth: "135px",
    },
    {
      field: "defectCategory",
      header: "DEFECT CATEGORY",
      sortable: true,
      minWidth: "175px",
    },
    {
      field: "severity",
      header: "SEVERITY",
      sortable: true,
      minWidth: "100px",
      body: (row) => (
        <span
          className={`qr-severity qr-severity--${row.severity.toLowerCase()}`}
        >
          {row.severity}
        </span>
      ),
    },
    {
      field: "assignedStation",
      header: "ASSIGNED STATION",
      sortable: true,
      minWidth: "165px",
    },
    {
      field: "duration",
      header: "DURATION / DAYS",
      sortable: true,
      minWidth: "125px",
      body: (row) => (
        <span className="qr-duration">
          {row.duration} {row.duration === 1 ? "Day" : "Days"}
        </span>
      ),
    },
    {
      field: "status",
      header: "STATUS",
      sortable: true,
      minWidth: "125px",
      body: (row) => (
        <span className={`qr-status qr-status--${statusClass(row.status)}`}>
          {row.status}
        </span>
      ),
    },
    {
      field: "id",
      header: "ACTIONS",
      align: "center",
      minWidth: "95px",
      body: (row) => (
        <button
          type="button"
          className="qr-trace-button"
          onClick={() => onTrace(row)}
        >
          <Eye size={14} /> Trace
        </button>
      ),
    },
  ];

  const resetFilters = () => {
    setSearch("");
    setStatus("all");
    setPo("all");
    setOperator("all");
    setAge("all");
  };

  return (
    <div className="qr-orders-view">
      <div className="qr-summary-grid">
        <article className="qr-summary-card">
          <span>Total Rework Cases</span>
          <strong>{records.length}</strong>
          <small>Active factory queue</small>
        </article>
        <article className="qr-summary-card warning">
          <span>In Progress / Assigned</span>
          <strong>
            {count((r) => ["Assigned", "In Progress"].includes(r.status))}
          </strong>
          <small>Being repaired on floor</small>
        </article>
        <article className="qr-summary-card danger">
          <span>Critical Defects</span>
          <strong>{count((r) => r.severity === "Critical")}</strong>
          <small>Requires supervisor signoff</small>
        </article>
        <article className="qr-summary-card success">
          <span>QA Passed / Packed</span>
          <strong>
            {count((r) => ["QA Passed", "Packed"].includes(r.status))}
          </strong>
          <small>Ready for final dispatch</small>
        </article>
      </div>

      <div className="qr-filter-panel">
        <div className="qr-filter-search">
          <CommonInput
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search ID, QR, PO..."
            leftElement={<Search size={15} />}
          />
        </div>
        <CommonSelect
          options={statusOptions}
          value={status}
          onChange={(value) => setStatus(String(value ?? "all"))}
          placeholder="All Statuses"
        />
        <CommonSelect
          options={poOptions}
          value={po}
          onChange={(value) => setPo(String(value ?? "all"))}
          placeholder="All Purchase Orders"
        />
        <CommonSelect
          options={operatorOptions}
          value={operator}
          onChange={(value) => setOperator(String(value ?? "all"))}
          placeholder="All Stations & Operators"
        />
        <CommonSelect
          options={ageOptions}
          value={age}
          onChange={(value) => setAge(String(value ?? "all"))}
          placeholder="All Durations / Ages"
        />
        <button
          type="button"
          className="qr-reset-button"
          onClick={resetFilters}
          title="Reset filters"
        >
          <RefreshCw size={15} />
        </button>
      </div>

      <div className="qr-table-card">
        <CommonDataTable
          data={filteredRecords}
          columns={columns}
          dataKey="id"
          paginator
          rows={10}
          rowsPerPageOptions={[5, 10, 25, 50]}
          stripedRows={false}
          size="normal"
          emptyMessage="No rework orders found."
          className="qr-rework-table"
        />
      </div>
    </div>
  );
}
