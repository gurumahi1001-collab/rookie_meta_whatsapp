import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Camera,
  SwitchCamera,
  CheckCircle2,
  FilePlus2,
  Play,
  ScanLine,
  Square,
  Plus,
  Upload,
  Image as ImageIcon,
  Trash2,
  MapPin,
  X,
  Pencil,
  QrCode,
  LoaderCircle,
  ShieldCheck,
  ClipboardCheck,
} from "lucide-react";

import { Html5Qrcode, Html5QrcodeScannerState } from "html5-qrcode";

import { severityOptions } from "../type/reworkData";

import type { ReworkRecord } from "../type/type";

import CommonInput from "@/components/common/ui/input/CommonInput";
import CommonSelect from "@/components/common/ui/select/CommonSelect";
import CommonModal from "@/components/common/ui/modal/CommonModal";
import CommonTextArea from "@/components/common/ui/textarea/CommonTextArea";
import DefectPhotoEditor from "./editor/DefectPhotoEditor";
import { api } from "@/lib/api";

type SelectOption = {
  label: string;
  value: string;
};

type CameraStatus = "idle" | "starting" | "scanning" | "error";

// Scan area = 70% of the preview's shorter side.
// Keep in sync with .qr-scan-box (70cqmin) in the SCSS.
const QR_BOX_RATIO = 0.7;

const getQrBox = (viewWidth: number, viewHeight: number) => {
  const size = Math.floor(Math.min(viewWidth, viewHeight) * QR_BOX_RATIO);

  return { width: size, height: size };
};

// html5-qrcode has no `isScanning` property; use getState().
const isScannerRunning = (scanner: Html5Qrcode | null): boolean => {
  if (!scanner) return false;

  try {
    const state = scanner.getState();

    return (
      state === Html5QrcodeScannerState.SCANNING ||
      state === Html5QrcodeScannerState.PAUSED
    );
  } catch {
    return false;
  }
};

export default function QRScannerRegistrationTab({
  onRegister,
}: {
  onRegister: (record: ReworkRecord) => void;
}) {
  // QR scanner
  const [cameraStatus, setCameraStatus] = useState<CameraStatus>("idle");
  const [cameraError, setCameraError] = useState("");
  const [cameraActive, setCameraActive] = useState(false);
  const [qrFacingMode, setQrFacingMode] = useState<"environment" | "user">(
    "environment",
  );
  const [qrId, setQrId] = useState("");
  const [isQrScanned, setIsQrScanned] = useState(false);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerStartingRef = useRef(false);
  const scanHandledRef = useRef(false);
  const scannerElementRef = useRef<HTMLDivElement>(null);

  // Registration fields
  const [po, setPo] = useState<string | null>(null);
  const [defect, setDefect] = useState<string | null>(null);
  const [severity, setSeverity] = useState<string | null>("Minor");

  const [stationOptions, setStationOptions] =
    useState<SelectOption[]>([]);
  const [poChoices, setPoChoices] = useState<SelectOption[]>([]);
  const [defectChoices, setDefectChoices] = useState<SelectOption[]>([]);
  const [operatorChoices, setOperatorChoices] = useState<SelectOption[]>([]);
  const [purchaseOrderRecords, setPurchaseOrderRecords] = useState<Array<{ poNumber: string; style?: string; size?: string }>>([]);
  const [operatorRecords, setOperatorRecords] = useState<Array<{ id: string; name: string }>>([]);

  useEffect(() => {
    let active = true;
    api.get<{
      purchaseOrders: Array<{ id: string; poNumber: string; style?: string; size?: string }>;
      stations: Array<{ id: string; name: string; location?: string }>;
      operators: Array<{ id: string; name: string }>;
      defects: Array<{ id: string; name: string; severity?: string }>;
    }>("/qr-rework/options").then((data) => {
      if (!active) return;
      setPurchaseOrderRecords(data.purchaseOrders);
      setPoChoices(data.purchaseOrders.map((item) => ({ label: item.poNumber, value: item.poNumber })));
      setStationOptions(data.stations.map((item) => ({ label: `${item.name}${item.location ? ` (${item.location})` : ""}`, value: item.id })));
      setOperatorRecords(data.operators);
      setOperatorChoices(data.operators.map((item) => ({ label: item.name, value: item.id })));
      setDefectChoices(data.defects.map((item) => ({ label: item.name, value: item.name })));
    }).catch((error) => {
      if (active) {
        setMessage(error instanceof Error ? error.message : "Unable to load registration options. Check the server connection.");
        setMessageIsSuccess(false);
      }
    });
    return () => { active = false; };
  }, []);

  const [station, setStation] = useState<string | null>(null);
  const [operator, setOperator] = useState<string | null>(null);
  const [description, setDescription] = useState("");

  // Station modal
  const [showStationModal, setShowStationModal] = useState(false);
  const [newStationName, setNewStationName] = useState("");
  const [newStationLocation, setNewStationLocation] = useState("");

  // Defect photo
  const [defectImage, setDefectImage] = useState("");
  const [rawDefectImage, setRawDefectImage] = useState("");
  const [imageName, setImageName] = useState("");
  const [defectImageCaption, setDefectImageCaption] = useState("");

  const [showPhotoEditor, setShowPhotoEditor] = useState(false);
  const [showPhotoCamera, setShowPhotoCamera] = useState(false);
  const [photoCameraLoading, setPhotoCameraLoading] = useState(false);
  const [photoCameraError, setPhotoCameraError] = useState("");
  const [photoFacingMode, setPhotoFacingMode] = useState<
    "environment" | "user"
  >("environment");

  const uploadInputRef = useRef<HTMLInputElement>(null);
  const photoVideoRef = useRef<HTMLVideoElement>(null);
  const photoStreamRef = useRef<MediaStream | null>(null);
  const photoCanvasRef = useRef<HTMLCanvasElement>(null);

  // Messages
  const [message, setMessage] = useState("");
  const [messageIsSuccess, setMessageIsSuccess] = useState(false);

  // =====================================================
  // STOP QR SCANNER
  // =====================================================

  const stopQrScanner = async () => {
    const scanner = scannerRef.current;

    if (!scanner) {
      setCameraActive(false);
      setCameraStatus("idle");
      return;
    }

    try {
      if (isScannerRunning(scanner)) {
        await scanner.stop();
      }
    } catch (error) {
      console.warn("QR scanner stop:", error);
    }

    try {
      scanner.clear();
    } catch {
      // Scanner may already be cleared.
    }

    scannerRef.current = null;
    scannerStartingRef.current = false;

    setCameraActive(false);
    setCameraStatus("idle");
  };

  // =====================================================
  // START QR SCANNER
  // =====================================================

  const startQrScanner = async (
    requestedFacingMode: "environment" | "user" = qrFacingMode,
    forceRestart = false,
  ) => {
    if (scannerStartingRef.current || (cameraActive && !forceRestart)) return;

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError(
        "Camera access requires HTTPS or localhost. Please check your browser.",
      );
      setCameraStatus("error");
      return;
    }

    setCameraError("");
    setCameraStatus("starting");
    setCameraActive(true);
    scannerStartingRef.current = true;
    scanHandledRef.current = false;

    // Wait until the reader element has been rendered.
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => resolve());
    });

    if (!scannerElementRef.current) {
      setCameraActive(false);
      setCameraStatus("error");
      setCameraError("Unable to initialize the scanner area. Please retry.");
      scannerStartingRef.current = false;
      return;
    }

    const scanner = new Html5Qrcode("qr-camera-reader", {
      verbose: false,
    });

    scannerRef.current = scanner;

    const scanConfig = {
      fps: 10,
      qrbox: getQrBox,
      aspectRatio: 1,
      disableFlip: false,
    };

    const onScanSuccess = async (decodedText: string) => {
      if (scanHandledRef.current) return;

      scanHandledRef.current = true;

      const scannedValue = decodedText.trim();

      if (!scannedValue) {
        scanHandledRef.current = false;
        return;
      }

      setQrId(scannedValue);
      setIsQrScanned(true);
      setMessage("QR code scanned successfully.");
      setMessageIsSuccess(true);

      await stopQrScanner();
    };

    const onScanFailure = () => {
      // Normal frame without a QR code.
    };

    try {
      const cameras = await Html5Qrcode.getCameras();

      if (!cameras.length) {
        throw new Error("No camera device was found.");
      }

      const preferredCamera =
        requestedFacingMode === "environment"
          ? cameras.find((camera) =>
              /back|rear|environment/i.test(camera.label),
            ) ?? cameras[cameras.length - 1]
          : cameras.find((camera) =>
              /front|user|facetime/i.test(camera.label),
            ) ?? cameras[0];

      try {
        await scanner.start(
          { deviceId: { exact: preferredCamera.id } },
          scanConfig,
          onScanSuccess,
          onScanFailure,
        );
      } catch (firstError) {
        // Retry using facingMode for browsers with different camera handling.
        try {
          if (isScannerRunning(scanner)) {
            await scanner.stop();
          }

          await scanner.start(
            { facingMode: requestedFacingMode },
            scanConfig,
            onScanSuccess,
            onScanFailure,
          );
        } catch {
          throw firstError;
        }
      }

      setCameraStatus("scanning");
    } catch (error) {
      console.error("QR camera initialization:", error);

      try {
        if (isScannerRunning(scanner)) await scanner.stop();
        scanner.clear();
      } catch {
        // Ignore cleanup errors.
      }

      scannerRef.current = null;
      setCameraActive(false);
      setCameraStatus("error");
      setCameraError(
        "Unable to start the camera. Please allow camera permission, check that another app is not using the camera, and try again.",
      );
    } finally {
      scannerStartingRef.current = false;
    }
  };

  const toggleQrCamera = async () => {
    if (cameraStatus !== "scanning" || scannerStartingRef.current) return;

    const nextMode =
      qrFacingMode === "environment" ? "user" : "environment";

    await stopQrScanner();
    setQrFacingMode(nextMode);
    await startQrScanner(nextMode, true);
  };

  useEffect(() => {
    return () => {
      const scanner = scannerRef.current;

      if (scanner) {
        void (async () => {
          try {
            if (isScannerRunning(scanner)) await scanner.stop();
          } catch {
            // Ignore cleanup errors.
          }

          try {
            scanner.clear();
          } catch {
            // Ignore cleanup errors.
          }
        })();
      }
    };
  }, []);

  // =====================================================
  // PHOTO CAMERA CLEANUP
  // =====================================================

  const stopPhotoCamera = () => {
    const stream = photoStreamRef.current;

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      photoStreamRef.current = null;
    }

    if (photoVideoRef.current) {
      photoVideoRef.current.pause();
      photoVideoRef.current.srcObject = null;
    }
  };

  // =====================================================
  // START PHOTO CAMERA
  // =====================================================

  useEffect(() => {
    if (!showPhotoCamera) return;

    let cancelled = false;

    const startPhotoCamera = async () => {
      setPhotoCameraLoading(true);
      setPhotoCameraError("");

      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("Camera API is not available.");
        }

        let stream: MediaStream;

        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: photoFacingMode },
              width: { ideal: 1920 },
              height: { ideal: 1080 },
            },
            audio: false,
          });
        } catch {
          // Fallback for devices that cannot satisfy the preferred settings.
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: photoFacingMode } },
            audio: false,
          });
        }

        if (cancelled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }

        photoStreamRef.current = stream;

        const video = photoVideoRef.current;

        if (!video) {
          throw new Error("Video preview is unavailable.");
        }

        video.srcObject = stream;

        await new Promise<void>((resolve, reject) => {
          const timeout = window.setTimeout(() => {
            reject(new Error("Camera preview timed out."));
          }, 10000);

          video.onloadedmetadata = () => {
            window.clearTimeout(timeout);
            resolve();
          };

          video.onerror = () => {
            window.clearTimeout(timeout);
            reject(new Error("Unable to load camera preview."));
          };
        });

        if (cancelled) return;

        await video.play();

        if (!cancelled) {
          setPhotoCameraLoading(false);
        }
      } catch (error) {
        console.error("Photo camera:", error);

        if (!cancelled) {
          stopPhotoCamera();
          setPhotoCameraLoading(false);
          setPhotoCameraError(
            "Unable to start the camera. Check camera permission or try uploading an image.",
          );
        }
      }
    };

    void startPhotoCamera();

    return () => {
      cancelled = true;
      stopPhotoCamera();
    };
  }, [showPhotoCamera, photoFacingMode]);

  // =====================================================
  // PHOTO UPLOAD
  // =====================================================

  const handleImageChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setMessage("Please select a valid image file.");
      setMessageIsSuccess(false);
      event.target.value = "";
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result === "string") {
        setRawDefectImage(reader.result);
        setImageName(file.name);
        setShowPhotoEditor(true);
        setMessage("");
      }
    };

    reader.onerror = () => {
      setMessage("Unable to read the selected image.");
      setMessageIsSuccess(false);
    };

    reader.readAsDataURL(file);
    event.target.value = "";
  };

  // =====================================================
  // CAPTURE PHOTO
  // =====================================================

  const captureDefectPhoto = () => {
    const video = photoVideoRef.current;
    const canvas = photoCanvasRef.current;

    if (
      !video ||
      !canvas ||
      video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA ||
      !video.videoWidth ||
      !video.videoHeight
    ) {
      setPhotoCameraError(
        "Camera is still loading. Please wait until the preview is visible.",
      );
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const context = canvas.getContext("2d");

    if (!context) {
      setPhotoCameraError("Unable to capture the photo. Please retry.");
      return;
    }

    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const capturedImage = canvas.toDataURL("image/jpeg", 0.92);

    setRawDefectImage(capturedImage);
    setImageName(`Defect-Photo-${Date.now()}.jpg`);

    setShowPhotoCamera(false);
    setShowPhotoEditor(true);
    setMessage("");
  };

  const closePhotoCamera = () => {
    stopPhotoCamera();
    setShowPhotoCamera(false);
    setPhotoCameraError("");
  };

  // =====================================================
  // PHOTO EDITOR
  // =====================================================

  const handleSaveAnnotatedPhoto = (
    annotatedImage: string,
    caption: string,
  ) => {
    setDefectImage(annotatedImage);
    setDefectImageCaption(caption);

    setShowPhotoEditor(false);
    setRawDefectImage("");

    setMessage("");
    setMessageIsSuccess(false);
  };

  const closePhotoEditor = () => {
    setShowPhotoEditor(false);
    setRawDefectImage("");
  };

  const editDefectImage = () => {
    if (!defectImage) return;

    setRawDefectImage(defectImage);
    setShowPhotoEditor(true);
  };

  const removeImage = () => {
    setDefectImage("");
    setRawDefectImage("");
    setImageName("");
    setDefectImageCaption("");

    setMessage("");
    setMessageIsSuccess(false);
  };

  // =====================================================
  // STATION
  // =====================================================

  const handleAddStation = async () => {
    if (!newStationName.trim() || !newStationLocation.trim()) return;
    try {
      const created = await api.post<{ id: string; name: string; location: string }>("/qr-rework/stations", {
        name: newStationName.trim(),
        location: newStationLocation.trim(),
      });
      setStationOptions((previous) => [
        ...previous,
        { label: `${created.name} (${created.location})`, value: created.id },
      ]);
      setStation(created.id);
      setNewStationName("");
      setNewStationLocation("");
      setShowStationModal(false);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to create station.");
      setMessageIsSuccess(false);
    }
  };

  const closeStationModal = () => {
    setShowStationModal(false);
    setNewStationName("");
    setNewStationLocation("");
  };

  // =====================================================
  // CLEAR FORM
  // =====================================================

  const clearForm = () => {
    void stopQrScanner();

    setQrId("");
    setIsQrScanned(false);

    setPo(null);
    setDefect(null);
    setSeverity("Minor");
    setStation(null);
    setOperator(null);
    setDescription("");

    setDefectImage("");
    setRawDefectImage("");
    setImageName("");
    setDefectImageCaption("");

    setShowPhotoEditor(false);
    closePhotoCamera();

    setMessage("");
    setMessageIsSuccess(false);
    setCameraError("");

    if (uploadInputRef.current) {
      uploadInputRef.current.value = "";
    }
  };

  // =====================================================
  // REGISTER
  // =====================================================

  const handleRegister = () => {
    if (!isQrScanned || !qrId.trim()) {
      setMessage("Please scan a garment QR code first.");
      setMessageIsSuccess(false);
      return;
    }

    if (!po || !defect || !severity || !station || !operator) {
      setMessage("Please complete all required fields before registering.");
      setMessageIsSuccess(false);
      return;
    }

    const timestamp = new Date();
    const suffix = String(Date.now()).slice(-5);
    const formattedNow = timestamp.toLocaleString();

    const selectedStation = stationOptions.find(
      (item) => item.value === station,
    );
    const selectedOperator = operatorRecords.find((item) => item.id === operator);
    const selectedPurchaseOrder = purchaseOrderRecords.find((item) => item.poNumber === po);

    const finalDescription = [
      description.trim(),
      defectImageCaption.trim(),
    ]
      .filter(Boolean)
      .join(" | ");

    const newRecord: ReworkRecord = {
      id: crypto.randomUUID(),
      reworkId: `RW-${timestamp.getFullYear()}-${suffix}`,
      qrId: qrId.trim(),
      poNumber: po,
      defectCategory: defect,
      severity: severity as ReworkRecord["severity"],
      assignedStation: selectedStation?.label ?? station,
      stationId: station ?? undefined,
      operatorId: operator ?? undefined,
      operator: selectedOperator?.name ?? operator ?? "",
      defectImage: defectImage || undefined,
      duration: 0,
      status: "Assigned",
      garmentId: `GR-${timestamp.getFullYear()}-${suffix}`,
      styleNumber: selectedPurchaseOrder?.style || "",
      size: selectedPurchaseOrder?.size || "",
      description: finalDescription || "Defect registered.",
      registeredDate: timestamp.toLocaleDateString("en-GB"),
      history: [
        {
          title: "Defect Registered",
          description: "New garment defect registered.",
          date: formattedNow,
          status: "completed",
        },
        {
          title: "Station & Staff Assigned",
          description: `Assigned to ${station} and ${operator}.`,
          date: formattedNow,
          status: "completed",
        },
      ],
    };

    onRegister(newRecord);
    clearForm();
  };

  // =====================================================
  // UI
  // =====================================================

  return (
    <section className="qr-registration-view">
      <div className="qr-registration-grid">
        {/* LEFT: QR SCANNER */}

        <article className="qr-registration-card qr-scanner-card">
          <div className="qr-section-heading">
            <div className="qr-section-icon">
              <ScanLine size={20} />
            </div>

            <div>
              <h4>Live Garment QR Scanner</h4>
              <p>Scan the garment QR label to continue registration.</p>
            </div>
          </div>

          <div
            className={`qr-camera-frame ${
              cameraStatus === "starting" ? "is-loading" : ""
            } ${cameraStatus === "scanning" ? "is-scanning" : ""}`}
          >
            {cameraActive ? (
              <div
                id="qr-camera-reader"
                ref={scannerElementRef}
                className="qr-camera-reader"
              />
            ) : (
              <div className="qr-camera-placeholder">
                <div className="qr-camera-icon">
                  {isQrScanned ? (
                    <CheckCircle2 size={36} />
                  ) : (
                    <Camera size={36} />
                  )}
                </div>

                <strong>
                  {isQrScanned
                    ? "QR code scanned successfully"
                    : cameraStatus === "error"
                      ? "Camera unavailable"
                      : "Camera scanner is ready"}
                </strong>

                <span>
                  {isQrScanned
                    ? "Your garment is identified. Complete the registration on the right."
                    : "Start the camera and position the garment QR label inside the scanning area."}
                </span>
              </div>
            )}

            {/* SCANNING OVERLAY (LASER LINE) */}

            {cameraStatus === "scanning" && (
              <div className="qr-scan-overlay">
                <div className="qr-scan-box">
                  <span className="qr-scan-corner top-left" />
                  <span className="qr-scan-corner top-right" />
                  <span className="qr-scan-corner bottom-left" />
                  <span className="qr-scan-corner bottom-right" />

                  <span className="qr-scan-line" />
                </div>

                <div className="qr-scan-hint">
                  <span className="qr-scan-hint-dot" />
                  Scanning... align the QR code inside the frame
                </div>
              </div>
            )}

            {cameraStatus === "starting" && (
              <div className="qr-camera-loading">
                <LoaderCircle size={30} className="qr-spin" />
                <strong>Starting camera...</strong>
                <span>Please allow camera access.</span>
              </div>
            )}

            {cameraStatus === "scanning" && (
              <div className="qr-camera-status">
                <span />
                Camera active
              </div>
            )}
          </div>

          {cameraError && (
            <div className="qr-camera-error">
              <AlertCircle size={16} />
              <span>{cameraError}</span>
            </div>
          )}

          <div className="qr-camera-actions">
            <button
              type="button"
              className="qr-secondary-button"
              disabled={!cameraActive}
              onClick={() => void stopQrScanner()}
            >
              <Square size={14} />
              Stop Camera
            </button>

            {cameraStatus === "scanning" && (
              <button
                type="button"
                className="qr-camera-switch-button"
                onClick={() => void toggleQrCamera()}
                title={`Switch to ${
                  qrFacingMode === "environment" ? "front" : "back"
                } camera`}
                aria-label={`Switch to ${
                  qrFacingMode === "environment" ? "front" : "back"
                } camera`}
              >
                <SwitchCamera size={16} />
                {qrFacingMode === "environment"
                  ? "Front Camera"
                  : "Back Camera"}
              </button>
            )}

            <button
              type="button"
              className="qr-primary-button"
              disabled={
                cameraActive ||
                cameraStatus === "starting" ||
                isQrScanned
              }
              onClick={() => void startQrScanner()}
            >
              <Play size={14} />
              {cameraStatus === "error" ? "Retry Camera" : "Start Camera"}
            </button>
          </div>

          {isQrScanned && (
            <div className="qr-scanned-result">
              <div className="qr-scanned-result-icon">
                <CheckCircle2 size={19} />
              </div>

              <div>
                <small>SCANNED GARMENT QR ID</small>
                <strong>{qrId}</strong>
              </div>

              <span className="qr-scanned-badge">Verified</span>
            </div>
          )}

          <div className="qr-scanner-instructions">
            <strong>Scanning instructions</strong>

            <div>
              <span>01</span>
              <p>Allow camera permission when prompted.</p>
            </div>

            <div>
              <span>02</span>
              <p>Keep the QR label clearly visible inside the frame.</p>
            </div>

            <div>
              <span>03</span>
              <p>After scanning, continue with defect registration.</p>
            </div>
          </div>
        </article>

        {/* RIGHT: PLACEHOLDER BEFORE SCAN */}

        {!isQrScanned ? (
          <article className="qr-registration-card qr-form-placeholder-card">
            <div className="qr-form-placeholder">
              <div className="qr-form-placeholder-icon">
                <QrCode size={36} />
              </div>

              <span className="qr-placeholder-step">
                GARMENT IDENTIFICATION REQUIRED
              </span>

              <h3>Ready to register a defect?</h3>

              <p>
                Scan a garment QR code first. Once the garment is identified,
                the defect registration form will become available here.
              </p>

              <div className="qr-placeholder-steps">
                <div>
                  <span className="qr-placeholder-number">
                    <ScanLine size={17} />
                  </span>

                  <div>
                    <strong>Scan garment QR</strong>
                    <small>Identify the garment using its QR label.</small>
                  </div>

                  <span className="qr-step-status">Required</span>
                </div>

                <div>
                  <span className="qr-placeholder-number">
                    <ClipboardCheck size={17} />
                  </span>

                  <div>
                    <strong>Enter defect information</strong>
                    <small>Select category, severity and assignment.</small>
                  </div>

                  <span className="qr-step-status">Locked</span>
                </div>

                <div>
                  <span className="qr-placeholder-number">
                    <Camera size={17} />
                  </span>

                  <div>
                    <strong>Attach defect photo</strong>
                    <small>Upload or capture and mark the damaged area.</small>
                  </div>

                  <span className="qr-step-status">Locked</span>
                </div>
              </div>

              <div className="qr-placeholder-note">
                <ShieldCheck size={17} />
                <span>
                  Registration is enabled only after a successful QR scan.
                </span>
              </div>
            </div>
          </article>
        ) : (
          /* RIGHT: REGISTRATION FORM AFTER SCAN */

          <article className="qr-registration-card qr-registration-form-card">
            <div className="qr-section-heading">
              <div className="qr-section-icon">
                <FilePlus2 size={20} />
              </div>

              <div>
                <h4>Defect & Rework Information</h4>
                <p>Enter defect details and assign a station and operator.</p>
              </div>

              <span className="qr-form-verified">
                <CheckCircle2 size={14} />
                QR Verified
              </span>
            </div>

            <div className="qr-form-scanned-banner">
              <QrCode size={18} />
              <div>
                <small>SCANNED GARMENT ID</small>
                <strong>{qrId}</strong>
              </div>
              <CheckCircle2 size={19} />
            </div>

            <div className="qr-form-grid">
              <CommonSelect
                label="Associated Purchase Order"
                options={poChoices}
                value={po}
                onChange={(value) =>
                  setPo(value == null ? null : String(value))
                }
                filter
                placeholder="Select purchase order"
                required
              />

              <CommonSelect
                label="Defect Category"
                options={defectChoices}
                value={defect}
                onChange={(value) =>
                  setDefect(value == null ? null : String(value))
                }
                placeholder="Select defect category"
                filter
                required
              />

              <CommonSelect
                label="Severity"
                options={severityOptions}
                value={severity}
                onChange={(value) =>
                  setSeverity(value == null ? null : String(value))
                }
                placeholder="Select severity"
                required
              />

              <div className="qr-station-field">
                <div className="qr-field-heading">
                  <label>Assign Station</label>

                  <button
                    type="button"
                    className="qr-add-station-button"
                    onClick={() => setShowStationModal(true)}
                  >
                    <Plus size={14} />
                    Add Station
                  </button>
                </div>

                <CommonSelect
                  label=""
                  options={stationOptions}
                  value={station}
                  onChange={(value) =>
                    setStation(value == null ? null : String(value))
                  }
                  placeholder="Select station"
                  required
                  filter
                />
              </div>

              <div className="qr-form-full">
                <CommonSelect
                  label="Assign Operator / Staff"
                  options={operatorChoices}
                  value={operator}
                  onChange={(value) =>
                    setOperator(value == null ? null : String(value))
                  }
                  placeholder="Select operator / staff"
                  required
                  filter
                />
              </div>

              <div className="qr-form-full">
                <CommonTextArea
                  label="Defect Description"
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  placeholder="Describe the defect and damaged area..."
                  rows={4}
                />
              </div>

              {/* DEFECT PHOTO */}

              <div className="qr-form-full">
                <div className="qr-photo-section">
                  <div className="qr-photo-heading">
                    <div>
                      <label>Defect Photo</label>
                      <p>
                        Upload or capture an image and mark the damaged area.
                      </p>
                    </div>

                    <ImageIcon size={20} />
                  </div>

                  <input
                    ref={uploadInputRef}
                    type="file"
                    accept="image/*"
                    className="qr-hidden-input"
                    onChange={handleImageChange}
                  />

                  <canvas
                    ref={photoCanvasRef}
                    className="qr-hidden-input"
                  />

                  {defectImage ? (
                    <div className="qr-photo-preview">
                      <img
                        src={defectImage}
                        alt="Annotated defect preview"
                      />

                      <div className="qr-photo-preview-info">
                        <div>
                          <strong>Defect Photo Annotated</strong>
                          <span>{imageName}</span>

                          {defectImageCaption && (
                            <span>{defectImageCaption}</span>
                          )}
                        </div>

                        <div className="qr-photo-preview-actions">
                          <button
                            type="button"
                            title="Edit damage marks"
                            onClick={editDefectImage}
                          >
                            <Pencil size={15} />
                          </button>

                          <button
                            type="button"
                            title="Replace image"
                            onClick={() => uploadInputRef.current?.click()}
                          >
                            <Upload size={15} />
                          </button>

                          <button
                            type="button"
                            title="Remove image"
                            onClick={removeImage}
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="qr-photo-upload">
                      <div className="qr-photo-upload-icon">
                        <Camera size={25} />
                      </div>

                      <strong>Upload or capture defect photo</strong>

                      <span>
                        Add a clear image of the damaged garment.
                      </span>

                      <div className="qr-photo-buttons">
                        <button
                          type="button"
                          className="qr-secondary-button"
                          onClick={() => uploadInputRef.current?.click()}
                        >
                          <Upload size={15} />
                          Upload Image
                        </button>

                        <button
                          type="button"
                          className="qr-primary-button"
                          onClick={() => {
                            setMessage("");
                            setShowPhotoCamera(true);
                          }}
                        >
                          <Camera size={15} />
                          Take Photo
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {message && (
              <div
                className={`qr-registration-message ${
                  messageIsSuccess ? "success" : "error"
                }`}
              >
                {messageIsSuccess ? (
                  <CheckCircle2 size={16} />
                ) : (
                  <AlertCircle size={16} />
                )}
                {message}
              </div>
            )}

            <div className="qr-form-actions">
              <button
                type="button"
                className="qr-secondary-button"
                onClick={clearForm}
              >
                Clear Form
              </button>

              <button
                type="button"
                className="qr-primary-button"
                onClick={handleRegister}
              >
                <FilePlus2 size={16} />
                Register Garment & Create Rework Order
              </button>
            </div>
          </article>
        )}
      </div>

      {/* ADD STATION MODAL */}

      <CommonModal
        show={showStationModal}
        onClose={closeStationModal}
        variant="drawer"
        size="md"
        title="Add New Station"
        subtitle="Create a new rework station and assign its location."
        headerIcon={<MapPin size={20} />}
        showCloseButton
        showFooter
        footer={
          <>
            <button
              type="button"
              className="qr-secondary-button"
              onClick={closeStationModal}
            >
              Cancel
            </button>

            <button
              type="button"
              className="qr-primary-button"
              onClick={handleAddStation}
              disabled={
                !newStationName.trim() || !newStationLocation.trim()
              }
            >
              <Plus size={15} />
              Save Station
            </button>
          </>
        }
        className="qr-station-modal"
      >
        <div className="qr-station-modal-content">
          <div className="qr-station-modal-intro">
            <div className="qr-station-modal-icon">
              <MapPin size={22} />
            </div>

            <div>
              <strong>Station Information</strong>
              <p>Enter the station name and its floor or zone location.</p>
            </div>
          </div>

          <CommonInput
            label="Station Name"
            value={newStationName}
            onChange={(event) => setNewStationName(event.target.value)}
            placeholder="Enter station name"
            required
          />

          <CommonInput
            label="Location / Zone"
            value={newStationLocation}
            onChange={(event) => setNewStationLocation(event.target.value)}
            placeholder="Example: Floor 2, Zone B"
            leftElement={<MapPin size={16} />}
            required
          />
        </div>
      </CommonModal>

      {/* DEFECT PHOTO CAMERA MODAL */}

      {showPhotoCamera && (
        <div
          className="qr-photo-camera-overlay"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) closePhotoCamera();
          }}
        >
          <div
            className="qr-photo-camera-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="qr-photo-camera-title"
          >
            <div className="qr-photo-camera-header">
              <div className="qr-photo-camera-heading-icon">
                <Camera size={20} />
              </div>

              <div>
                <h3 id="qr-photo-camera-title">Capture Defect Photo</h3>
                <p>
                  Position the damaged garment inside the camera frame.
                </p>
              </div>

              <button
                type="button"
                onClick={closePhotoCamera}
                aria-label="Close camera"
              >
                <X size={19} />
              </button>
            </div>

            <div className="qr-photo-camera-body">
              <div className="qr-photo-camera-preview">
                <video
                  ref={photoVideoRef}
                  autoPlay
                  playsInline
                  muted
                />

                {photoCameraLoading && (
                  <div className="qr-photo-camera-loading">
                    <LoaderCircle size={34} className="qr-spin" />
                    <strong>Preparing camera...</strong>
                    <span>Please wait while the camera initializes.</span>
                  </div>
                )}

                {!photoCameraLoading && photoCameraError && (
                  <div className="qr-photo-camera-error">
                    <AlertCircle size={28} />
                    <strong>Camera unavailable</strong>
                    <span>{photoCameraError}</span>
                    <button
                      type="button"
                      className="qr-secondary-button"
                      onClick={() => {
                        setShowPhotoCamera(false);
                        window.setTimeout(
                          () => setShowPhotoCamera(true),
                          100,
                        );
                      }}
                    >
                      Retry Camera
                    </button>
                  </div>
                )}

                {!photoCameraLoading && !photoCameraError && (
                  <div className="qr-photo-camera-guide">
                    <span />
                  </div>
                )}

                {!photoCameraLoading && !photoCameraError && (
                  <button
                    type="button"
                    className="qr-camera-switch-button qr-photo-camera-switch-button"
                    onClick={() =>
                      setPhotoFacingMode((current) =>
                        current === "environment" ? "user" : "environment",
                      )
                    }
                    title={`Switch to ${
                      photoFacingMode === "environment" ? "front" : "back"
                    } camera`}
                    aria-label={`Switch to ${
                      photoFacingMode === "environment" ? "front" : "back"
                    } camera`}
                  >
                    <SwitchCamera size={17} />
                    {photoFacingMode === "environment" ? "Front" : "Back"}
                  </button>
                )}

                <span className="qr-camera-live-label">
                  <i />
                  LIVE PREVIEW
                </span>
              </div>

              <div className="qr-photo-camera-hint">
                <ShieldCheck size={16} />
                <span>
                  Keep the garment steady and ensure the damaged area is
                  clearly visible.
                </span>
              </div>
            </div>

            <div className="qr-photo-camera-footer">
              <button
                type="button"
                className="qr-secondary-button"
                onClick={closePhotoCamera}
              >
                Cancel
              </button>

              <button
                type="button"
                className="qr-capture-button"
                onClick={captureDefectPhoto}
                disabled={photoCameraLoading || !!photoCameraError}
              >
                <Camera size={19} />
                Capture Photo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DAMAGE MARKING EDITOR */}

      {showPhotoEditor && rawDefectImage && (
        <DefectPhotoEditor
          image={rawDefectImage}
          imageName={imageName}
          onClose={closePhotoEditor}
          onSave={handleSaveAnnotatedPhoto}
        />
      )}
    </section>
  );
}