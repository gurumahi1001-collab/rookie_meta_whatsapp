import {
  Activity, AlertCircle, ArrowLeft, CalendarDays, CheckCircle2,
  ClipboardList, Clock3, MapPin, QrCode, UserRound,
} from "lucide-react";
import type { ReworkRecord } from "../type/type";

export default function ReworkTracePage({
  record, onBack,
}: {
  record: ReworkRecord;
  onBack: () => void;
}) {
  const statusClass = record.status.toLowerCase().replace(/\s+/g, "-");
  const summary = [
    { icon: <QrCode size={19} />, label: "QR ID", value: record.qrId },
    { icon: <ClipboardList size={19} />, label: "Rework ID", value: record.reworkId },
    { icon: <CalendarDays size={19} />, label: "Purchase Order", value: record.poNumber },
    { icon: <UserRound size={19} />, label: "Assigned Operator", value: record.operator },
  ];

  return (
    <section className="qr-trace-page">
      <header className="qr-trace-page-header">
        <div>
          <button type="button" className="qr-back-button" onClick={onBack}><ArrowLeft size={15} /> Back to Rework Orders</button>
          <h3>Garment Traceability</h3>
          <p>Complete lifecycle and rework activity for this garment.</p>
        </div>
        <span className={`qr-status qr-status--${statusClass}`}>{record.status}</span>
      </header>

      <div className="qr-trace-summary-grid">
        {summary.map((item) => (
          <article className="qr-trace-info-card" key={item.label}>
            <div className="qr-trace-info-icon">{item.icon}</div>
            <span>{item.label}</span>
            <strong>{item.value}</strong>
          </article>
        ))}
      </div>

      <div className="qr-trace-details-grid">
        <article className="qr-trace-section-card">
          <div className="qr-section-heading"><div className="qr-section-icon"><AlertCircle size={19} /></div><div><h4>Defect & Damage Information</h4><p>Registered garment defect details.</p></div></div>
          <div className="qr-trace-detail-row"><span>Defect Category</span><strong>{record.defectCategory}</strong></div>
          <div className="qr-trace-detail-row"><span>Severity</span><strong>{record.severity}</strong></div>
          <div className="qr-trace-detail-row"><span>Style Number</span><strong>{record.styleNumber}</strong></div>
          <div className="qr-trace-detail-row"><span>Description</span><strong>{record.description}</strong></div>
        </article>

        <article className="qr-trace-section-card">
          <div className="qr-section-heading"><div className="qr-section-icon"><MapPin size={19} /></div><div><h4>Workstation & Staff Assignment</h4><p>Current assignment information.</p></div></div>
          <div className="qr-trace-detail-row"><span>Assigned Station / Staff</span><strong>{record.assignedStation}</strong></div>
          <div className="qr-trace-detail-row"><span>Garment ID</span><strong>{record.garmentId}</strong></div>
          <div className="qr-trace-detail-row"><span>Registered Date</span><strong>{record.registeredDate}</strong></div>
          <div className="qr-trace-detail-row"><span>Duration</span><strong>{record.duration} {record.duration === 1 ? "Day" : "Days"}</strong></div>
        </article>
      </div>

      <article className="qr-trace-section-card qr-audit-card">
        <div className="qr-section-heading"><div className="qr-section-icon"><Activity size={19} /></div><div><h4>Traceability & Audit Trail</h4><p>Chronological registration and rework activities.</p></div></div>
        {record.history.length > 0 ? (
          <div className="qr-timeline">
            {record.history.map((item, index) => (
              <div className="qr-timeline-item" key={`${item.title}-${index}`}>
                <div className={`qr-timeline-marker ${item.status === "completed" ? "completed" : ""}`}>
                  {item.status === "completed" ? <CheckCircle2 size={15} /> : <Clock3 size={15} />}
                </div>
                <div className="qr-timeline-details"><strong>{item.title}</strong><p>{item.description}</p><small>{item.date}</small></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="qr-history-empty"><Clock3 size={28} /><strong>No detailed activity history</strong><p>Activity records will appear here as the garment moves through rework.</p></div>
        )}
      </article>
    </section>
  );
}
