/**
 * Single place that maps business statuses -> theme tones.
 * Tones map 1:1 to the colours in src/assets/styles/_variables.scss
 */
export type Tone = "primary" | "secondary" | "success" | "info" | "warning" | "danger";

export type StatusKey =
  | "active"
  | "completed"
  | "pending"
  | "processing"
  | "inactive"
  | "rejected";

export const STATUS_META: Record<StatusKey, { label: string; tone: Tone }> = {
  active: { label: "Active", tone: "success" },
  completed: { label: "Completed", tone: "success" },
  pending: { label: "Pending", tone: "warning" },
  processing: { label: "Processing", tone: "info" },
  inactive: { label: "Inactive", tone: "secondary" },
  rejected: { label: "Rejected", tone: "danger" },
};
