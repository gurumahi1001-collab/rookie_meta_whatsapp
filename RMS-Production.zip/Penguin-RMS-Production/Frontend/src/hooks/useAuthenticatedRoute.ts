import { isTokenValid, getToken } from "@/utils/token";

/**
 * Returns true when a token exists.
 * Used by protected routes.
 */
export function useAuthenticatedRoute(): boolean {
  return isTokenValid(getToken());
}
