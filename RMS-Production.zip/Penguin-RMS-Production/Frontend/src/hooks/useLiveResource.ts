import { useCallback, useEffect, useRef, useState, type Dispatch, type SetStateAction } from "react";
import { api } from "@/lib/api";
import { connectRealtime } from "@/lib/realtime";

type ResourceEnvelope<T> = T[] | { items: T[]; total?: number; page?: number; pageSize?: number; totalPages?: number };
interface UseLiveResourceOptions { endpoint: string; resource: string; enabled?: boolean; params?: Record<string, string | number | boolean | undefined>; }
interface UseLiveResourceResult<T> { data: T[]; loading: boolean; error: string; reload: () => Promise<T[]>; create: (value: Partial<T>) => Promise<T>; update: (id: string, value: Partial<T>) => Promise<T>; remove: (id: string) => Promise<void>; setData: Dispatch<SetStateAction<T[]>>; }

export function useLiveResource<T extends { id?: string }>(options: UseLiveResourceOptions): UseLiveResourceResult<T> {
  const { endpoint, resource, enabled = true, params } = options;
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(Boolean(enabled));
  const [error, setError] = useState("");
  const mounted = useRef(true);
  const paramsKey = JSON.stringify(params || {});

  const reload = useCallback(async () => {
    if (!enabled) return [] as T[];
    setLoading(true);
    try {
      const requestParams = (params ? JSON.parse(paramsKey) : {}) as Record<string, string | number | boolean | undefined>;
      const pageSize = Math.min(200, Math.max(1, Number(requestParams.pageSize || 200)));
      const first = await api.get<ResourceEnvelope<T>>(endpoint, { ...requestParams, page: 1, pageSize });
      let rows = Array.isArray(first) ? first : first.items || [];
      if (!Array.isArray(first) && first.totalPages && first.totalPages > 1) {
        // These screens use local filtering/pagination, so fetch subsequent API pages
        // in bounded batches. Large installations should move the table to server-side paging.
        const pageCount = Math.min(first.totalPages, 50); // at most 10,000 rows per resource refresh
        for (let page = 2; page <= pageCount; page += 1) {
          const next = await api.get<ResourceEnvelope<T>>(endpoint, { ...requestParams, page, pageSize });
          if (Array.isArray(next)) { rows = [...rows, ...next]; break; }
          rows = [...rows, ...(next.items || [])];
        }
      }
      if (mounted.current) { setData(rows); setError(""); }
      return rows;
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to load records.";
      if (mounted.current) setError(message);
      return [] as T[];
    } finally { if (mounted.current) setLoading(false); }
  }, [enabled, endpoint, paramsKey]);

  useEffect(() => {
    mounted.current = true;
    void reload();
    return () => { mounted.current = false; };
  }, [reload]);

  useEffect(() => {
    if (!enabled) return;
    const socket = connectRealtime();
    const onChange = (event: { resource?: string }) => {
      if (!event.resource || event.resource === resource || event.resource === "*") void reload();
    };
    socket?.on("resource:changed", onChange);
    return () => { socket?.off("resource:changed", onChange); };
  }, [enabled, resource, reload]);

  const create = useCallback(async (value: Partial<T>) => {
    const created = await api.post<T>(endpoint, value);
    setData((current) => [created, ...current.filter((item) => item.id !== created.id)]);
    return created;
  }, [endpoint]);
  const update = useCallback(async (id: string, value: Partial<T>) => {
    const updated = await api.patch<T>(`${endpoint}/${encodeURIComponent(id)}`, value);
    setData((current) => current.map((item) => item.id === id ? updated : item));
    return updated;
  }, [endpoint]);
  const remove = useCallback(async (id: string) => {
    await api.delete(`${endpoint}/${encodeURIComponent(id)}`);
    setData((current) => current.filter((item) => item.id !== id));
  }, [endpoint]);

  return { data, loading, error, reload, create, update, remove, setData };
}
