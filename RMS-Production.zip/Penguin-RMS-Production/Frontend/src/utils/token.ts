const TOKEN_KEY = "app_token";
const REMEMBER_KEY = "app_remember";

export function getToken(): string | null {
  try { return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY); }
  catch { return null; }
}

export function setToken(token: string, remember = false): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
    if (remember) {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(REMEMBER_KEY, "1");
    } else {
      sessionStorage.setItem(TOKEN_KEY, token);
      localStorage.removeItem(REMEMBER_KEY);
    }
  } catch { /* Storage may be disabled by browser privacy settings. */ }
}

export function removeToken(): void {
  try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(REMEMBER_KEY); sessionStorage.removeItem(TOKEN_KEY); }
  catch { /* Ignore unavailable storage. */ }
}

export function isTokenValid(token: string | null | undefined): boolean {
  // The API rotates an expired access token through the HttpOnly refresh cookie.
  // Keep protected routes mounted so the API client can perform that refresh.
  return typeof token === "string" && token.split(".").length === 3;
}
