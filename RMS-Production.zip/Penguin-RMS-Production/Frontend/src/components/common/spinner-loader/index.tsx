import { useEffect, useMemo, useState, type CSSProperties } from "react";
import "./PageLoader.scss";

const DEFAULT_MESSAGES = [
  "Measuring your workspace",
  "Picking the perfect fit",
  "Stitching the pages together",
  "Ironing out the wrinkles",
  "Folding your data neatly",
  "Almost ready to wear",
];

interface PageLoaderProps {
  /** Main heading under the scene */
  title?: string;
  /** One fixed message (turns off the rotation) */
  label?: string;
  /** Rotating messages (default = apparel themed) */
  messages?: string[];
  /** Cover the whole screen (use for the top-level Suspense) */
  fullScreen?: boolean;
  /** Penguin width in px. The rack and track scale with it */
  size?: number;
  /** Milliseconds between messages */
  interval?: number;
}

/**
 * Suspense fallback: the penguin (in his scarf) walks along a stitched line
 * to a clothes rack. A bold "LOADING" title sits below, with a themed
 * message rotating under it.
 */
export default function PageLoader({
  title = "Loading",
  label,
  messages = DEFAULT_MESSAGES,
  fullScreen = false,
  size = 90,
  interval = 2400,
}: PageLoaderProps) {
  const list = useMemo(() => (label ? [label] : messages), [label, messages]);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (list.length < 2) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % list.length), interval);
    return () => window.clearInterval(id);
  }, [list.length, interval]);

  return (
    <div
      className={`page-loader${fullScreen ? " page-loader--fullscreen" : ""}`}
      role="status"
      aria-live="polite"
    >
      <span className="visually-hidden">{title}</span>

      <div
        className="penguin-loader"
        style={{ "--loader-size": `${size}px` } as CSSProperties}
        aria-hidden="true"
      >
        {/* ---------------- scene ---------------- */}
        <div className="penguin-loader__scene">
          {/* clothes rack (the destination) */}
          <svg className="penguin-loader__rack" viewBox="0 0 180 170" focusable="false">
            <path
              className="penguin-loader__rack-frame"
              d="M14 32 V160 M166 32 V160 M6 160 H26 M154 160 H174 M6 32 H174"
            />

            {/* dress */}
            <g className="penguin-loader__garment penguin-loader__garment--dress">
              <path className="penguin-loader__rack-frame" d="M42 32 V40" />
              <path
                className="penguin-loader__dress"
                d="M34 44 L38 44 L40 52 L44 52 L46 44 L50 44 L55 64 L68 120 Q42 126 16 120 L29 64 Z"
              />
              <path className="penguin-loader__stitch" d="M22 112 Q42 117 62 112" />
            </g>

            {/* tee */}
            <g className="penguin-loader__garment penguin-loader__garment--tee">
              <path className="penguin-loader__rack-frame" d="M90 32 V40" />
              <path
                className="penguin-loader__tee"
                d="M72 52 L83 46 Q90 54 97 46 L108 52 L118 66 L109 72 L105 66 L105 112 L75 112 L75 66 L71 72 L62 66 Z"
              />
              <path className="penguin-loader__stitch" d="M76 105 H104" />
            </g>

            {/* skirt */}
            <g className="penguin-loader__garment penguin-loader__garment--skirt">
              <path className="penguin-loader__rack-frame" d="M138 32 V40" />
              <path className="penguin-loader__skirt" d="M122 46 L154 46 L164 114 L112 114 Z" />
              <path className="penguin-loader__stitch" d="M118 106 H158" />
            </g>
          </svg>

          {/* stitched track + thread that follows the penguin */}
          <div className="penguin-loader__track">
            <span className="penguin-loader__thread" />
          </div>

          {/* walking penguin */}
          <div className="penguin-loader__walker">
            <svg className="penguin-loader__svg" viewBox="0 0 434 638" focusable="false">
              <ellipse className="penguin-loader__shadow" cx="190" cy="628" rx="170" ry="12" />

              <g className="penguin-loader__penguin">
                {/* back flipper */}
                <g className="penguin-loader__flipper penguin-loader__flipper--back">
                  <path
                    className="penguin-loader__outline"
                    d="M78 196 C40 206 10 245 12 290 C13 318 32 335 48 322 C70 300 80 262 84 232 Z"
                  />
                </g>

                {/* torso */}
                <path
                  className="penguin-loader__torso"
                  d="M200 112 C175 70 205 8 262 6 C305 4 322 30 322 52 C322 88 292 102 284 130 C292 190 318 235 345 262 L316 335 C308 410 304 480 298 540 C302 575 330 596 362 608 L262 616 L170 604 L150 300 L190 130 Z"
                />

                {/* belly */}
                <path
                  className="penguin-loader__belly"
                  d="M212 104 C192 86 152 100 130 142 C98 200 76 270 78 345 C80 450 106 545 152 574 C192 590 240 572 260 520 C280 470 284 360 270 262 C260 172 240 114 212 104 Z"
                />

                {/* scarf */}
                <path
                  className="penguin-loader__scarf"
                  d="M176 104 C212 134 262 142 298 120 L306 148 C264 172 210 164 170 132 Z"
                />
                <path
                  className="penguin-loader__scarf-stripe"
                  d="M206 128 L202 152 M238 143 L236 166 M270 142 L271 166"
                />
                <g className="penguin-loader__scarf-tail">
                  <path
                    className="penguin-loader__scarf"
                    d="M266 148 L304 142 L310 216 C298 226 280 226 270 218 Z"
                  />
                  <path
                    className="penguin-loader__scarf-stripe"
                    d="M268 178 L308 172 M270 198 L309 192"
                  />
                  <path
                    className="penguin-loader__scarf-fringe"
                    d="M276 222 L276 236 M290 224 L290 238 M304 220 L304 234"
                  />
                </g>

                {/* front flipper */}
                <g className="penguin-loader__flipper penguin-loader__flipper--front">
                  <path
                    className="penguin-loader__outline"
                    d="M280 268 C335 290 398 345 427 412 C432 428 414 434 398 426 C358 410 318 384 290 345 Z"
                  />
                </g>

                {/* beak + eye */}
                <path
                  className="penguin-loader__beak"
                  d="M305 28 C355 32 408 48 433 66 C392 70 350 70 318 64 Z"
                />
                <path
                  className="penguin-loader__beak"
                  d="M330 78 C368 78 398 90 418 106 C382 108 348 100 322 90 Z"
                />
                <circle className="penguin-loader__eye" cx="288" cy="42" r="9" />

                {/* feet */}
                <g className="penguin-loader__foot penguin-loader__foot--left">
                  <path
                    className="penguin-loader__foot-shape"
                    d="M70 608 C62 590 90 578 112 584 C130 562 170 574 172 600 C176 618 150 626 120 624 C96 624 74 620 70 608 Z"
                  />
                  <path className="penguin-loader__toe" d="M104 592 L108 612 M138 588 L140 612" />
                </g>
                <g className="penguin-loader__foot penguin-loader__foot--right">
                  <path
                    className="penguin-loader__foot-shape"
                    d="M186 612 C180 594 205 582 225 588 C240 566 268 580 268 604 C270 622 244 628 220 626 C202 626 188 622 186 612 Z"
                  />
                  <path className="penguin-loader__toe" d="M214 596 L216 616 M244 592 L244 616" />
                </g>
              </g>
            </svg>
          </div>
        </div>

        {/* ---------------- caption ---------------- */}
        <div className="penguin-loader__caption">
          <p className="penguin-loader__title">
            {title}
            <span className="penguin-loader__dots">
              <span>.</span>
              <span>.</span>
              <span>.</span>
            </span>
          </p>

          {/* key restarts the fade-in every time the message changes */}
          <p key={index} className="penguin-loader__text">
            {list[index]}
          </p>
        </div>
      </div>
    </div>
  );
}