
import type { ReactNode } from "react";

import "./CommonPageHeader.scss";

interface CommonPageHeaderProps {
  icon?: ReactNode;
  title: string;
  subtitle?: string;

  rightContent?: ReactNode;

  className?: string;
}

export default function CommonPageHeader({
  icon,
  title,
  subtitle,
  rightContent,
  className = "",
}: CommonPageHeaderProps) {
  return (
    <div className={`common-page-header ${className}`}>
      {/* LEFT CONTENT */}
      <div className="common-page-header__left">
        {icon && (
          <div className="common-page-header__icon">
            {icon}
          </div>
        )}

        <div className="common-page-header__content">
          <h4 className="common-page-header__title">
            {title}
          </h4>

          {subtitle && (
            <p className="common-page-header__subtitle">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      {/* RIGHT CONTENT */}
      {rightContent && (
        <div className="common-page-header__right">
          {rightContent}
        </div>
      )}
    </div>
  );
}
