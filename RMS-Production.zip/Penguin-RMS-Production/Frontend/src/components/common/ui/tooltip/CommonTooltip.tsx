import {
  useCallback,
  useEffect,
  useId,
  useState,
  type ReactNode,
  type MouseEvent,
  type FocusEvent,
} from "react";

import { createPortal } from "react-dom";

import "./CommonTooltip.scss";

export type TooltipPlacement = "top" | "bottom" | "left" | "right";

interface CommonTooltipProps {
  content: ReactNode;
  children: ReactNode;
  placement?: TooltipPlacement;
  disabled?: boolean;
  className?: string;
}

interface TooltipPosition {
  top: number;
  left: number;
}

const CommonTooltip = ({
  content,
  children,
  placement = "left",
  disabled = false,
  className = "",
}: CommonTooltipProps) => {
  const tooltipId = useId();

  const [visible, setVisible] = useState(false);

  const [position, setPosition] = useState<TooltipPosition>({
    top: 0,
    left: 0,
  });

  // Get the actual child element instead of the wrapper.
  const getTrigger = (wrapper: HTMLElement): HTMLElement => {
    const child = wrapper.firstElementChild;

    return child instanceof HTMLElement ? child : wrapper;
  };

  // Calculate tooltip position.
  const updatePosition = useCallback(
    (element: HTMLElement) => {
      const rect = element.getBoundingClientRect();
      const gap = 10;

      let top = rect.top + rect.height / 2;
      let left = rect.right + gap;

      switch (placement) {
        case "left":
          left = rect.left - gap;
          break;

        case "top":
          top = rect.top - gap;
          left = rect.left + rect.width / 2;
          break;

        case "bottom":
          top = rect.bottom + gap;
          left = rect.left + rect.width / 2;
          break;

        case "right":
        default:
          left = rect.right + gap;
          break;
      }

      setPosition({ top, left });
    },
    [placement],
  );

  // Mouse enter.
  const handleMouseEnter = (event: MouseEvent<HTMLSpanElement>) => {
    if (disabled || !content) return;

    updatePosition(getTrigger(event.currentTarget));
    setVisible(true);
  };

  // Keyboard focus.
  const handleFocus = (event: FocusEvent<HTMLSpanElement>) => {
    if (disabled || !content) return;

    updatePosition(getTrigger(event.currentTarget));
    setVisible(true);
  };

  // Hide tooltip.
  const handleLeave = () => {
    setVisible(false);
  };

  // Update position when scrolling or resizing.
  useEffect(() => {
    if (!visible) return;

    const wrapper = document.getElementById(tooltipId);

    if (!wrapper) return;

    const update = () => {
      updatePosition(getTrigger(wrapper));
    };

    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);

    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [visible, tooltipId, updatePosition]);

  if (disabled || !content) {
    return <>{children}</>;
  }

  return (
    <>
      <span
        id={tooltipId}
        className={`common-tooltip-wrapper ${className}`}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleLeave}
        onFocus={handleFocus}
        onBlur={handleLeave}
      >
        {children}
      </span>

      {visible &&
        createPortal(
          <span
            className="common-tooltip-portal"
            data-placement={placement}
            role="tooltip"
            style={{
              top: position.top,
              left: position.left,
            }}
          >
            {content}
          </span>,
          document.body,
        )}
    </>
  );
};

export default CommonTooltip;

export { CommonTooltip };