export { default as CommonTooltip } from "./CommonTooltip";

export type { TooltipPlacement } from "./CommonTooltip";