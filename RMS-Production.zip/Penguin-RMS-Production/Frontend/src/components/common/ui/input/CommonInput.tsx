import {
  forwardRef,
  useId,
  type InputHTMLAttributes,
  type ReactNode,
} from "react";

import "./Input.scss";

interface CommonInputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "size"> {
  label?: string;
  error?: string;
  hint?: string;
  leftElement?: ReactNode;
  rightElement?: ReactNode;
  containerClassName?: string;
  inputClassName?: string;
}

const CommonInput = forwardRef<HTMLInputElement, CommonInputProps>(
  (
    {
      id,
      label,
      error,
      hint,
      leftElement,
      rightElement,
      containerClassName = "",
      inputClassName = "",
      className,
      required,
      disabled,
      ...inputProps
    },
    ref,
  ) => {
    const generatedId = useId();
    const inputId = id || generatedId;
    const messageId = `${inputId}-message`;

    return (
      <div
        className={`common-input-group ${containerClassName}`.trim()}
      >
        {label && (
          <label htmlFor={inputId} className="common-input-label">
            {label}

            {required && (
              <span className="common-input-required">*</span>
            )}
          </label>
        )}

        <div
          className={[
            "common-input-wrapper",
            leftElement ? "has-left-element" : "",
            rightElement ? "has-right-element" : "",
            error ? "has-error" : "",
            disabled ? "is-disabled" : "",
          ]
            .filter(Boolean)
            .join(" ")}
        >
          {leftElement && (
            <span className="common-input-element common-input-left">
              {leftElement}
            </span>
          )}

          <input
            {...inputProps}
            ref={ref}
            id={inputId}
            required={required}
            disabled={disabled}
            aria-invalid={!!error}
            aria-describedby={error || hint ? messageId : undefined}
            className={`common-input-field ${inputClassName} ${className || ""}`.trim()}
          />

          {rightElement && (
            <span className="common-input-element common-input-right">
              {rightElement}
            </span>
          )}
        </div>

        {(error || hint) && (
          <small
            id={messageId}
            className={`common-input-message ${
              error ? "is-error" : "is-hint"
            }`}
          >
            {error || hint}
          </small>
        )}
      </div>
    );
  },
);

CommonInput.displayName = "CommonInput";

export default CommonInput;