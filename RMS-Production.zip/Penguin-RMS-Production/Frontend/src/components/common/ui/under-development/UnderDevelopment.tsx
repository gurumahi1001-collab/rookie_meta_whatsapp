
import type { ReactNode } from "react";
import {

  CheckCircle2,
  Clock3,
  Construction,
  Hammer,
  Sparkles,
  Wrench,
} from "lucide-react";

import "./UnderDevelopment.scss";

interface UnderDevelopmentProps {
  icon?: ReactNode;
  className?: string;
}

export default function UnderDevelopment({

  icon,
  className = "",
}: UnderDevelopmentProps) {
  return (
    <section className={`under-development ${className}`}>
      <div className="under-development-card">
        {/* BACKGROUND DECORATION */}
        <div className="under-development-decoration">
          <span className="under-development-decoration__circle" />
          <span className="under-development-decoration__circle under-development-decoration__circle--two" />
        </div>

        {/* ANIMATED ILLUSTRATION */}
        <div className="under-development-visual">
          <div className="under-development-visual__orbit">
            <span className="under-development-visual__dot" />
            <span className="under-development-visual__dot under-development-visual__dot--two" />
          </div>

          <div className="under-development-visual__icon under-development-visual__icon--left">
            <Wrench size={19} />
          </div>

          <div className="under-development-visual__main">
            {icon || <Construction size={43} strokeWidth={1.5} />}
          </div>

          <div className="under-development-visual__icon under-development-visual__icon--right">
            <Hammer size={19} />
          </div>

          <span className="under-development-visual__spark under-development-visual__spark--one">
            <Sparkles size={16} />
          </span>

          <span className="under-development-visual__spark under-development-visual__spark--two">
            <Sparkles size={13} />
          </span>
        </div>

        {/* COMMON MESSAGE */}
        <div className="under-development-content">
          <span className="under-development-status">
            <span className="under-development-status__indicator" />
            <Clock3 size={13} />
            UNDER DEVELOPMENT
          </span>

          <h2>
            Something exciting is in the works!
          </h2>

          <p>
            We're working hard to bring you a better experience.
            This page is currently under development and will be
            available soon. Thank you for your patience!
          </p>

          {/* PROGRESS INFORMATION */}
          <div className="under-development-progress">
            <div className="under-development-progress__heading">
              <span>Our team is working on it</span>
              <Sparkles size={15} />
            </div>

            <div className="under-development-progress__track">
              <span />
            </div>

            <div className="under-development-progress__footer">
              <span>
                <CheckCircle2 size={13} />
                Design and development in progress
              </span>
            </div>
          </div>

      
        </div>

        {/* FOOTER */}
        <div className="under-development-card-footer">
          <span>GARMENT MANAGEMENT SYSTEM</span>
          <span className="under-development-card-footer__separator" />
          <span>Better workflows. Smarter production.</span>
        </div>
      </div>
    </section>
  );
}
