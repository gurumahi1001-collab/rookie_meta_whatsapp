
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Compass,
  Factory,
  Home,
  Package,
  Search,
  Scissors,
  Shirt,
  Sparkles,
} from "lucide-react";

import { ROUTES } from "@/routes/routePaths";

import "./NotFoundPage.scss";

export default function NotFoundPage() {
  const navigate = useNavigate();

  const handleGoBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(ROUTES.app.dashboard, { replace: true });
    }
  };

  const handleGoHome = () => {
    navigate(ROUTES.app.dashboard, { replace: true });
  };

  return (
    <main className="not-found-page">
      <div className="not-found-background">
        <span className="not-found-orb not-found-orb--one" />
        <span className="not-found-orb not-found-orb--two" />
        <span className="not-found-grid" />
      </div>

      <section className="not-found-content">
        {/* TOP LABEL */}
        <div className="not-found-tag">
          <Sparkles size={14} />
          <span>GARMENT MANAGEMENT SYSTEM</span>
        </div>

        {/* ANIMATED ILLUSTRATION */}
        <div className="not-found-illustration">
          <div className="not-found-circle not-found-circle--outer" />
          <div className="not-found-circle not-found-circle--middle" />
          <div className="not-found-circle not-found-circle--inner" />

          <div className="not-found-floating-icon not-found-floating-icon--one">
            <Package size={23} />
          </div>

          <div className="not-found-floating-icon not-found-floating-icon--two">
            <Scissors size={22} />
          </div>

          <div className="not-found-floating-icon not-found-floating-icon--three">
            <Shirt size={24} />
          </div>

          <div className="not-found-floating-icon not-found-floating-icon--four">
            <Compass size={20} />
          </div>

          <div className="not-found-main-icon">
            <div className="not-found-search-icon">
              <Search size={54} strokeWidth={1.5} />
            </div>

            <span className="not-found-question-mark">?</span>
          </div>

          <span className="not-found-spark not-found-spark--one" />
          <span className="not-found-spark not-found-spark--two" />
          <span className="not-found-spark not-found-spark--three" />
          <span className="not-found-spark not-found-spark--four" />
        </div>

        {/* ERROR TEXT */}
        <div className="not-found-error-code">
          <span>4</span>
          <span className="not-found-error-zero">0</span>
          <span>4</span>
        </div>

        <div className="not-found-heading">
          <h1>
            Oops! This page is <span>missing.</span>
          </h1>

          <p>
            Looks like this page has gone out of production.
            The page you're looking for doesn't exist or may have
            been moved to another location.
          </p>
        </div>

        {/* ACTION BUTTONS */}
        <div className="not-found-actions">
          <button
            type="button"
            className="not-found-primary-button"
            onClick={handleGoHome}
          >
            <Home size={17} />
            <span>Back to Dashboard</span>
            <ArrowRight size={17} />
          </button>

          <button
            type="button"
            className="not-found-secondary-button"
            onClick={handleGoBack}
          >
            <ArrowLeft size={17} />
            <span>Go Back</span>
          </button>
        </div>

        {/* FOOTER */}
        <div className="not-found-footer">
          <div className="not-found-footer-brand">
            <span className="not-found-footer-icon">
              <Factory size={16} />
            </span>

            <span>Garment Management System</span>
          </div>

          <span className="not-found-footer-divider" />

          <span className="not-found-footer-message">
            Let's get you back on track.
          </span>
        </div>
      </section>
    </main>
  );
}
