import { useEffect, useState, type ReactNode } from "react";

import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";

import "./CommonDataTable.scss";

/* =========================================
   COLUMN INTERFACE
========================================= */

export interface TableColumn<T> {
  field: keyof T & string;
  header: string;

  sortable?: boolean;

  width?: string;
  minWidth?: string;

  align?: "left" | "center" | "right";

  body?: (rowData: T) => ReactNode;

  bodyStyle?: React.CSSProperties;
  headerStyle?: React.CSSProperties;
}

/* =========================================
   COMPONENT PROPS
========================================= */

interface CommonDataTableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  dataKey: keyof T & string;

  loading?: boolean;

  paginator?: boolean;
  rows?: number;
  rowsPerPageOptions?: number[];

  emptyMessage?: string;

  stripedRows?: boolean;
  showGridlines?: boolean;

  size?: "small" | "normal" | "large";

  className?: string;
}

/* =========================================
   COMMON DATA TABLE
========================================= */

export function CommonDataTable<T extends object>({
  data,
  columns,
  dataKey,

  loading = false,

  paginator = true,
  rows = 10,
  rowsPerPageOptions = [5, 10, 25, 50],

  emptyMessage = "No records found",

  stripedRows = true,
  showGridlines = false,

  size = "normal",

  className = "",
}: CommonDataTableProps<T>) {
  const [first, setFirst] = useState(0);
  const [pageSize, setPageSize] = useState(rows);

  const totalRecords = data.length;
  const totalPages = Math.ceil(totalRecords / pageSize);

  const currentPage = Math.floor(first / pageSize) + 1;

  const startRecord = totalRecords === 0 ? 0 : first + 1;
  const endRecord = Math.min(first + pageSize, totalRecords);

  // Keep pagination valid when the data changes
  useEffect(() => {
    setFirst((currentFirst) => {
      const lastValidFirst =
        Math.max(0, Math.ceil(data.length / pageSize) - 1) * pageSize;

      return Math.min(currentFirst, lastValidFirst);
    });
  }, [data.length, pageSize]);

  // Change page
  const goToPage = (page: number) => {
    const nextPage = Math.max(1, Math.min(page, totalPages));

    setFirst((nextPage - 1) * pageSize);
  };

  // Change rows per page
  const handlePageSizeChange = (
    event: React.ChangeEvent<HTMLSelectElement>,
  ) => {
    setPageSize(Number(event.target.value));
    setFirst(0);
  };

  // Display a maximum of five nearby page numbers
  const startPage = Math.max(1, currentPage - 2);
  const endPage = Math.min(totalPages, currentPage + 2);

  const pageNumbers = Array.from(
    { length: Math.max(0, endPage - startPage + 1) },
    (_, index) => startPage + index,
  );

  return (
    <div className={`common-table ${className}`}>
      <DataTable
        value={data}
        dataKey={dataKey as string}
        first={first}
        rows={pageSize}
        totalRecords={totalRecords}
        onPage={(event) => {
          setFirst(event.first);
          setPageSize(event.rows);
        }}
        loading={loading}
        paginator={paginator}
        emptyMessage={emptyMessage}
        stripedRows={stripedRows}
        showGridlines={showGridlines}
        size={size}
        responsiveLayout="scroll"
        scrollable
        className="common-table__datatable"
      >
        {columns.map((column) => (
          <Column
            key={column.field}
            field={column.field}
            header={column.header}
            sortable={column.sortable ?? false}
            body={column.body}
            style={{
              width: column.width,
              minWidth: column.minWidth,
              textAlign: column.align ?? "left",
              ...column.bodyStyle,
            }}
            headerStyle={{
              textAlign: column.align ?? "left",
              ...column.headerStyle,
            }}
          />
        ))}
      </DataTable>

      {/* CUSTOM PAGINATION */}
      {paginator && (
        <div className="common-table__pagination">
          {/* LEFT: RECORD COUNT */}
          <div className="common-table__pagination-info">
            Showing{" "}
            <span>{startRecord}</span>
            {" "}to{" "}
            <span>{endRecord}</span>
            {" "}of{" "}
            <span>{totalRecords}</span>
            {" "}entries
          </div>

          {/* RIGHT: PAGINATION CONTROLS */}
          <div className="common-table__pagination-controls">
            {/* ROWS PER PAGE */}
            <div className="common-table__page-size">
              <span>Rows per page</span>

              <select
                value={pageSize}
                onChange={handlePageSizeChange}
                aria-label="Rows per page"
              >
                {rowsPerPageOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>

            {/* PAGE NAVIGATION */}
            <div className="common-table__page-navigation">
              <button
                type="button"
                className="common-table__page-button"
                onClick={() => goToPage(1)}
                disabled={currentPage <= 1 || totalPages === 0}
                aria-label="First page"
              >
                <ChevronsLeft size={14} />
              </button>

              <button
                type="button"
                className="common-table__page-button"
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage <= 1 || totalPages === 0}
                aria-label="Previous page"
              >
                <ChevronLeft size={14} />
              </button>

              {startPage > 1 && (
                <>
                  <button
                    type="button"
                    className="common-table__page-button"
                    onClick={() => goToPage(1)}
                  >
                    1
                  </button>

                  {startPage > 2 && (
                    <span className="common-table__page-dots">...</span>
                  )}
                </>
              )}

              {pageNumbers.map((page) => (
                <button
                  key={page}
                  type="button"
                  className={`common-table__page-button ${
                    currentPage === page ? "is-active" : ""
                  }`}
                  onClick={() => goToPage(page)}
                  aria-current={currentPage === page ? "page" : undefined}
                >
                  {page}
                </button>
              ))}

              {endPage < totalPages && (
                <>
                  {endPage < totalPages - 1 && (
                    <span className="common-table__page-dots">...</span>
                  )}

                  <button
                    type="button"
                    className="common-table__page-button"
                    onClick={() => goToPage(totalPages)}
                  >
                    {totalPages}
                  </button>
                </>
              )}

              <button
                type="button"
                className="common-table__page-button"
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage >= totalPages || totalPages === 0}
                aria-label="Next page"
              >
                <ChevronRight size={14} />
              </button>

              <button
                type="button"
                className="common-table__page-button"
                onClick={() => goToPage(totalPages)}
                disabled={currentPage >= totalPages || totalPages === 0}
                aria-label="Last page"
              >
                <ChevronsRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}