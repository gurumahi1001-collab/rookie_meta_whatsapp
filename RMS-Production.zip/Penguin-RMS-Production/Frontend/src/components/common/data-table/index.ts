export { CommonDataTable } from "./CommonDataTable";

export type { TableColumn } from "./CommonDataTable";