# Penguin React + Bootstrap Starter

React 18 · Vite · TypeScript · Bootstrap 5 (SCSS) · PrimeReact · lucide-react · React Router v6

## Run

```bash
npm install
npm run dev        # http://localhost:5173 
npm run build      # type-check + production build
npm run preview
```

Login page accepts anything - it stores a **static token** in `localStorage` (`app_token`).

## Folder structure

```
src/
├─ assets/styles/
│  ├─ _variables.scss          ← ALL theme colours (edit here only)
│  ├─ _theme.scss              ← CSS vars, status badges, icon boxes, PrimeReact colour bridge
│  ├─ _layout.scss             ← sidebar / header / content responsive rules
│  ├─ _primereact-overrides.scss
│  └─ main.scss                ← import order: variables → bootstrap → theme → layout
├─ components/common/          ← Logo, PenguinIcon, StatusBadge, PageHeader, spinner-loader
├─ config/app.ts               ← APP_NAME (from .env)
├─ constants/status.ts         ← status → colour-tone map
├─ hooks/                      ← useAuthenticatedRoute, useUnauthenticatedRoute, useBreakpoint, useMediaQuery
├─ layouts/                    ← AppLayout, Header, Sidebar, sidebarConfig
├─ pages/                      ← auth, dashboard, users, settings, errors (all lazy-loaded)
├─ routes/
│  ├─ routePaths.ts            ← every URL in one place
│  ├─ routeConfig.tsx          ← publicRoutes, protectedRoutes, fallbackRoute (lazy pages)
│  ├─ AppRoutes.tsx            ← Suspense + recursive renderer
│  ├─ ProtectedRoute.tsx / GuestRoute.tsx / Errorboundary.tsx
├─ utils/token.ts              ← get / set / remove / isTokenValid
├─ App.tsx · main.tsx
```

## Responsive layout

| Screen | Sidebar | Toggle button |
|---|---|---|
| Desktop ≥ 1200px | full 260px | collapses to 72px icon rail |
| Tablet 768–1199px | 72px icon rail | opens full drawer + backdrop |
| Mobile < 768px | hidden | opens full drawer + backdrop |

The drawer closes on route change, backdrop click and `Esc`.

## One theme everywhere

Edit `src/assets/styles/_variables.scss`:

- `$primary`, `$success`, `$warning`, `$danger`, `$info`, `$secondary` → buttons, badges, text colours, links
- `$body-color`, `$body-secondary-color` → text
- `$sidebar-*` → sidebar

Bootstrap classes (`btn-primary`, `text-success`, `bg-warning`...), PrimeReact components
(through the `--primary-*` bridge in `_theme.scss`) and `<StatusBadge />` all read the same palette.
Open **Settings** in the app to preview it.

## Add a page

1. Add the path in `routes/routePaths.ts`
2. Create `pages/xyz/XyzPage.tsx` with `export default`
3. Lazy-import it in `routes/routeConfig.tsx` and add it to `protectedRoutes` (or `publicRoutes`)
4. Add a menu item in `layouts/sidebarConfig.ts`

## Replace the penguin with an image later

Open `components/common/Logo.tsx` and swap `<PenguinIcon />` for
`<img src={logo} alt={APP_NAME} height={size} />`. Also replace `public/favicon.svg`.

## Replace the static token with a real one

- `pages/auth/LoginPage.tsx` → call your API, then `setToken(response.token)`
- `utils/token.ts` → `isTokenValid()` can decode the JWT and check `exp`
