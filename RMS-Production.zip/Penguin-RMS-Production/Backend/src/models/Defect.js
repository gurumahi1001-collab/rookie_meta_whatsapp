import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  code: { type: String, required: true, trim: true, unique: true, index: true }, name: { type: String, required: true, trim: true, maxlength: 160 },
  categoryId: { type: String, required: true, index: true }, categoryName: { type: String, default: '' }, severity: { type: String, enum: ['Minor', 'Major', 'Critical'], default: 'Minor' },
  reworkMinutes: { type: Number, default: 0, min: 0 }, description: { type: String, default: '' }, status: { type: String, enum: ['Active', 'Inactive'], default: 'Active', index: true }
}, modelOptions);
export default models.Defect || model('Defect', schema, 'defects');
