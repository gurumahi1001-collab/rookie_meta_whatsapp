import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  code: { type: String, required: true, trim: true, unique: true, index: true }, name: { type: String, required: true, trim: true, maxlength: 150 },
  description: { type: String, default: '' }, severity: { type: String, enum: ['Minor', 'Major', 'Critical'], default: 'Minor' },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Active', index: true }
}, modelOptions);
export default models.DefectCategory || model('DefectCategory', schema, 'defect_categories');
