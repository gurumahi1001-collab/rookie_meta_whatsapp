import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  code: { type: String, required: true, trim: true, unique: true, index: true }, name: { type: String, required: true, trim: true, maxlength: 180 },
  type: { type: String, trim: true, default: '' }, category: { type: String, trim: true, default: '' }, factory: { type: String, trim: true, default: 'Factory A' },
  location: { type: String, trim: true, default: '' }, capacity: { type: Number, default: 0, min: 0 }, operatorIds: { type: [String], default: [] },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Active', index: true }, remarks: { type: String, default: '' },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ factory: 1, status: 1 });
export default models.Station || model('Station', schema, 'stations');
