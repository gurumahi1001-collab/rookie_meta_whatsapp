import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  action: { type: String, required: true, trim: true, lowercase: true, index: true }, module: { type: String, required: true, trim: true, lowercase: true, index: true },
  title: { type: String, default: '' }, description: { type: String, default: '' }, actorUserId: { type: Schema.Types.ObjectId, ref: 'User', default: null, index: true },
  actorName: { type: String, default: '' }, actorEmail: { type: String, default: '' }, entityType: { type: String, default: '', index: true }, entityId: { type: String, default: '', index: true },
  entityName: { type: String, default: '' }, requestId: { type: String, default: '' }, ipAddress: { type: String, default: '' }, userAgent: { type: String, default: '' }, metadata: { type: Schema.Types.Mixed, default: {} }
}, { ...modelOptions, timestamps: { createdAt: true, updatedAt: false } });
schema.index({ module: 1, createdAt: -1 });
export default models.AuditLog || model('AuditLog', schema, 'audit_logs');
