import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  code: { type: String, required: true, trim: true, unique: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 180 },
  category: { type: String, required: true, trim: true, maxlength: 100 },
  active: { type: Boolean, default: true, index: true },
  required: { type: Boolean, default: false },
  sortOrder: { type: Number, default: 100, index: true },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null },
  updatedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ active: 1, sortOrder: 1, createdAt: 1 });
export default models.QAChecklistItem || model('QAChecklistItem', schema, 'qa_checklist_items');
