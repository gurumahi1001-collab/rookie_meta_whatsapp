import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 150 }, employeeCode: { type: String, required: true, unique: true, trim: true },
  role: { type: String, default: 'Station Operator', trim: true }, phone: { type: String, default: '' }, email: { type: String, default: '', lowercase: true, trim: true },
  stationIds: { type: [String], default: [] }, status: { type: String, enum: ['Active', 'Inactive'], default: 'Active', index: true }
}, modelOptions);
export default models.Operator || model('Operator', schema, 'operators');
