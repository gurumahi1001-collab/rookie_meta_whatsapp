import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({ key: { type: String, required: true, unique: true, index: true }, value: { type: Schema.Types.Mixed, default: {} }, updatedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null } }, modelOptions);
export default models.Setting || model('Setting', schema, 'settings');
