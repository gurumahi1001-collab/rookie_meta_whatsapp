import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const historyItem = new Schema({ title: { type: String, required: true }, description: { type: String, default: '' }, date: { type: Date, default: Date.now }, status: { type: String, enum: ['completed', 'pending'], default: 'completed' } }, { _id: false });
const schema = new Schema({
  reworkId: { type: String, required: true, trim: true, unique: true, index: true }, qrId: { type: String, required: true, trim: true, index: true },
  poNumber: { type: String, required: true, trim: true, index: true }, garmentId: { type: String, required: true, trim: true, index: true }, styleNumber: { type: String, default: '' }, size: { type: String, default: '' },
  defectCategory: { type: String, required: true, trim: true }, severity: { type: String, enum: ['Minor', 'Major', 'Critical'], default: 'Minor' },
  stationId: { type: String, default: '' }, assignedStation: { type: String, default: '' }, operatorId: { type: String, default: '' }, operator: { type: String, default: '' },
  duration: { type: Number, default: 0, min: 0 }, status: { type: String, enum: ['Assigned', 'In Progress', 'Sent to QA', 'QA Passed', 'QA Rejected', 'Packed', 'Scrap'], default: 'Assigned', index: true },
  description: { type: String, default: '' }, defectImage: { type: String, default: '' }, defectImageUrl: { type: String, default: '' },
  registeredAt: { type: Date, default: Date.now, index: true }, registeredDate: { type: String, default: '' }, startedAt: { type: Date, default: null }, completedAt: { type: Date, default: null }, submittedAt: { type: Date, default: null },
  repairDetails: { type: String, default: '' }, repairRemarks: { type: String, default: '' }, materialsUsed: { type: String, default: '' },
  history: { type: [historyItem], default: [] }, cartonId: { type: String, default: '', index: true },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }, updatedBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ status: 1, stationId: 1, registeredAt: -1 });
schema.index({ poNumber: 1, status: 1 });
schema.index({ qrId: 1, garmentId: 1 });
export default models.WorkOrder || model('WorkOrder', schema, 'work_orders');
