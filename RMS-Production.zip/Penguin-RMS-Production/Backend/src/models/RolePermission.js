import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const actionSchema = new Schema({ view: { type: Boolean, default: false }, create: { type: Boolean, default: false }, update: { type: Boolean, default: false }, delete: { type: Boolean, default: false }, approve: { type: Boolean, default: false }, export: { type: Boolean, default: false }, manage: { type: Boolean, default: false } }, { _id: false });
const schema = new Schema({
  roleId: { type: Schema.Types.ObjectId, ref: 'Role', required: true },
  permissionId: { type: Schema.Types.ObjectId, ref: 'Permission', required: true },
  actions: { type: actionSchema, default: () => ({}) },
  active: { type: Boolean, default: true }
}, modelOptions);
schema.index({ roleId: 1, permissionId: 1 }, { unique: true });
export default models.RolePermission || model('RolePermission', schema, 'role_permissions');
