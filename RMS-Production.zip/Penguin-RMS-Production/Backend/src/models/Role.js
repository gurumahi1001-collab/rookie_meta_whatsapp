import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  key: { type: String, required: true, lowercase: true, trim: true, unique: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, default: '', maxlength: 500 },
  modules: { type: [String], default: [] },
  systemRole: { type: Boolean, default: false },
  active: { type: Boolean, default: true, index: true },
  sortOrder: { type: Number, default: 100 }
}, modelOptions);
export default models.Role || model('Role', schema, 'roles');
