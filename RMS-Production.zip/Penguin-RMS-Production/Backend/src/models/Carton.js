import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const removal = new Schema({ garmentId: { type: String, required: true }, reason: { type: String, required: true }, removedAt: { type: Date, default: Date.now }, removedBy: { type: String, default: '' } }, { _id: false });
const schema = new Schema({
  cartonId: { type: String, required: true, unique: true, index: true }, poNumber: { type: String, required: true, index: true },
  packingDateTime: { type: Date, default: Date.now }, packedBy: { type: String, default: '' }, remarks: { type: String, default: '' },
  status: { type: String, enum: ['Open', 'Closed'], default: 'Open', index: true }, dispatchStatus: { type: String, enum: ['Not Ready', 'Ready for Dispatch', 'Dispatched'], default: 'Not Ready', index: true },
  garmentIds: { type: [String], default: [] }, closedAt: { type: Date, default: null }, dispatchedAt: { type: Date, default: null }, removalLogs: { type: [removal], default: [] },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ poNumber: 1, status: 1, createdAt: -1 });
export default models.Carton || model('Carton', schema, 'cartons');
