import mongoose from 'mongoose';
const { Schema, model, models } = mongoose;
const schema = new Schema({ key: { type: String, required: true, unique: true }, description: { type: String, default: '' }, checksum: { type: String, default: '' }, appliedAt: { type: Date, default: Date.now } }, { timestamps: true, versionKey: false });
export default models.Migration || model('Migration', schema, 'system_migrations');
