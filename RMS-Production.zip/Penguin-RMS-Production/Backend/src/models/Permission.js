import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  key: { type: String, required: true, lowercase: true, trim: true, unique: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, default: '', maxlength: 500 },
  category: { type: String, default: 'operations', trim: true },
  actions: { type: [String], default: ['view', 'create', 'update', 'delete'] },
  active: { type: Boolean, default: true },
  system: { type: Boolean, default: true },
  sortOrder: { type: Number, default: 100 }
}, modelOptions);
export default models.Permission || model('Permission', schema, 'permissions');
