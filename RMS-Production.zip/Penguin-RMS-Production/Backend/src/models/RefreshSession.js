import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  sessionId: { type: String, required: true, unique: true, index: true },
  tokenHash: { type: String, required: true, select: false },
  expiresAt: { type: Date, required: true, index: true },
  revokedAt: { type: Date, default: null, index: true },
  ipAddress: { type: String, default: '' },
  userAgent: { type: String, default: '' }
}, modelOptions);
schema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
export default models.RefreshSession || model('RefreshSession', schema, 'refresh_sessions');
