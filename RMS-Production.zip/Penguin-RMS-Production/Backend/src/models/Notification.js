import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({ recipientId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true }, eventType: { type: String, required: true }, title: { type: String, required: true }, message: { type: String, required: true }, payload: { type: Schema.Types.Mixed, default: null }, readAt: { type: Date, default: null, index: true } }, modelOptions);
schema.index({ recipientId: 1, createdAt: -1 });
export default models.Notification || model('Notification', schema, 'notifications');
