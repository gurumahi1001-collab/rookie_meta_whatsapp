export const modelOptions = {
  timestamps: true,
  versionKey: false,
  strict: 'throw',
  minimize: false,
  toJSON: {
    virtuals: true,
    transform(_doc, ret) {
      ret.id = String(ret._id);
      delete ret._id;
      delete ret.__v;
      delete ret.passwordHash;
      delete ret.refreshTokenHash;
      return ret;
    }
  },
  toObject: { virtuals: true }
};
