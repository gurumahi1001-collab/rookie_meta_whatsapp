import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const response = new Schema({ itemId: { type: String, default: '' }, title: { type: String, default: '' }, response: { type: String, default: '' }, passed: { type: Boolean, default: false }, remarks: { type: String, default: '' } }, { _id: false });
const schema = new Schema({
  workOrderId: { type: String, required: true, index: true }, stationId: { type: String, default: '' }, stationName: { type: String, default: '' }, operatorName: { type: String, default: '' }, size: { type: String, default: '' }, styleNumber: { type: String, default: '' }, defectCategory: { type: String, default: '' }, severity: { type: String, default: 'Minor' }, description: { type: String, default: '' }, defectImage: { type: String, default: '' }, submittedAt: { type: Date, default: null }, reworkId: { type: String, default: '' }, qrId: { type: String, default: '' }, garmentId: { type: String, default: '' }, poNumber: { type: String, default: '' },
  decision: { type: String, enum: ['Pass', 'Reject', 'Scrap'], required: true, index: true }, checklistResponses: { type: [response], default: [] },
  failedChecks: { type: [String], default: [] }, reason: { type: String, default: '' }, remarks: { type: String, default: '' }, rejectedPhotoUrl: { type: String, default: '' },
  returnStationId: { type: String, default: '' }, inspectorId: { type: Schema.Types.ObjectId, ref: 'User', default: null }, inspectorName: { type: String, default: '' }, inspectedAt: { type: Date, default: Date.now, index: true }
}, modelOptions);
schema.index({ workOrderId: 1, inspectedAt: -1 });
export default models.QAInspection || model('QAInspection', schema, 'qa_inspections');
