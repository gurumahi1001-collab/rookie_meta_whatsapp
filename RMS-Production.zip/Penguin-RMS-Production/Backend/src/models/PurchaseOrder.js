import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const item = new Schema({ size: { type: String, trim: true }, color: { type: String, trim: true }, orderedQty: { type: Number, min: 0, default: 0 } }, { _id: false });
const schema = new Schema({
  poNumber: { type: String, required: true, trim: true, unique: true, index: true },
  supplier: { type: String, required: true, trim: true, maxlength: 180 },
  style: { type: String, trim: true, default: '' }, articleSku: { type: String, trim: true, default: '' },
  description: { type: String, default: '' }, items: { type: [item], default: [] },
  orderedQty: { type: Number, min: 0, default: 0 }, size: { type: String, default: '' }, color: { type: String, default: '' }, batch: { type: String, default: '' },
  totalReworks: { type: Number, default: 0, min: 0 }, inProgress: { type: Number, default: 0, min: 0 }, completed: { type: Number, default: 0, min: 0 }, irreparable: { type: Number, default: 0, min: 0 },
  deliveryDate: { type: Date, default: null }, status: { type: String, enum: ['Active', 'Completed', 'On Hold'], default: 'Active', index: true },
  remarks: { type: String, default: '' }, createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ status: 1, deliveryDate: 1 });
export default models.PurchaseOrder || model('PurchaseOrder', schema, 'purchase_orders');
