import mongoose from 'mongoose';
import { modelOptions } from './modelOptions.js';
const { Schema, model, models } = mongoose;
const schema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 150 },
  email: { type: String, required: true, lowercase: true, trim: true, maxlength: 254, unique: true, index: true },
  employeeId: { type: String, trim: true, maxlength: 80, default: '' },
  phone: { type: String, trim: true, maxlength: 40, default: '' },
  department: { type: String, trim: true, maxlength: 120, default: '' },
  jobTitle: { type: String, trim: true, maxlength: 120, default: '' },
  avatarUrl: { type: String, default: '' },
  passwordHash: { type: String, required: true, select: false },
  roleId: { type: Schema.Types.ObjectId, ref: 'Role', required: true, index: true },
  roleKey: { type: String, required: true, lowercase: true, index: true },
  stationId: { type: String, default: '' },
  status: { type: String, enum: ['active', 'inactive', 'locked'], default: 'active', index: true },
  lastLoginAt: { type: Date, default: null },
  passwordChangedAt: { type: Date, default: null },
  failedLoginAttempts: { type: Number, default: 0, min: 0 },
  lockUntil: { type: Date, default: null },
  mustChangePassword: { type: Boolean, default: false },
  createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null }
}, modelOptions);
schema.index({ roleId: 1, status: 1 });
export default models.User || model('User', schema, 'users');
