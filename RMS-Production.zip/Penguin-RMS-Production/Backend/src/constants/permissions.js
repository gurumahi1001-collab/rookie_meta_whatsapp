export const ACTIONS = Object.freeze(['view', 'create', 'update', 'delete', 'approve', 'export', 'manage']);
export const MODULES = Object.freeze([
  { key: 'dashboard', name: 'Dashboard', category: 'core' },
  { key: 'purchase-orders', name: 'Purchase Orders', category: 'production' },
  { key: 'qr-rework', name: 'QR & Rework', category: 'production' },
  { key: 'station-management', name: 'Station Management', category: 'production' },
  { key: 'qa-inspection', name: 'QA Inspection', category: 'quality' },
  { key: 'packing', name: 'Packing & Dispatch', category: 'dispatch' },
  { key: 'reports', name: 'Reports & Analytics', category: 'analytics' },
  { key: 'master-data', name: 'Master Data', category: 'administration' },
  { key: 'garment-registry', name: 'Garment Registry', category: 'production' },
  { key: 'user-management', name: 'User & Roles', category: 'administration' },
  { key: 'settings', name: 'Settings', category: 'administration' }
]);

export const ROLE_DEFINITIONS = Object.freeze([
  { key: 'superadmin', name: 'Super Admin', description: 'Full access to every application module and administrative control.', modules: MODULES.map((x) => x.key), systemRole: true, sortOrder: 1 },
  { key: 'production_manager', name: 'Production Manager', description: 'Production visibility and factory workflow management.', modules: ['dashboard', 'purchase-orders', 'qr-rework', 'station-management', 'qa-inspection', 'packing', 'reports', 'master-data', 'garment-registry'], systemRole: true, sortOrder: 10 },
  { key: 'purchase_manager', name: 'Purchase Manager', description: 'Purchase orders and production reporting.', modules: ['dashboard', 'purchase-orders', 'reports'], systemRole: true, sortOrder: 20 },
  { key: 'rework_inspector', name: 'Rework Inspector', description: 'Defect registration and garment traceability.', modules: ['dashboard', 'qr-rework', 'reports'], systemRole: true, sortOrder: 30 },
  { key: 'station_operator', name: 'Station Operator', description: 'Station repair queue and work-order updates.', modules: ['dashboard', 'station-management', 'qr-rework'], systemRole: true, sortOrder: 40 },
  { key: 'qa_inspector', name: 'QA Inspector', description: 'Quality checklist, inspection decisions and history.', modules: ['dashboard', 'qa-inspection', 'reports'], systemRole: true, sortOrder: 50 },
  { key: 'packing_operator', name: 'Packing Operator', description: 'Pack approved garments and manage cartons.', modules: ['dashboard', 'packing'], systemRole: true, sortOrder: 60 }
]);

export const DEFAULT_ACTIONS = Object.freeze({ view: true, create: true, update: true, delete: true, approve: true, export: true, manage: true });
