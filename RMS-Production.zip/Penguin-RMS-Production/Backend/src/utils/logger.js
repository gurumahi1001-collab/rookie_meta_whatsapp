import pino from 'pino';
import env from '../config/env.js';
const logger = pino({
  level: env.logging.level,
  redact: { paths: ['req.headers.authorization', 'req.headers.cookie', 'password', 'passwordHash', 'refreshToken', 'token', '*.password', '*.passwordHash'], censor: '[REDACTED]' },
  base: { application: env.app.name, environment: env.app.environment },
  timestamp: pino.stdTimeFunctions.isoTime
});
export default logger;
