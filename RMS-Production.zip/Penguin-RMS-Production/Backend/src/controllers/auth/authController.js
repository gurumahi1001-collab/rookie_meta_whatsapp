import env from '../../config/env.js';
import * as authService from '../../services/auth/authService.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import RefreshSession from '../../models/RefreshSession.js';

const cookieOptions = () => ({ httpOnly: true, secure: env.cookies.secure, sameSite: env.cookies.sameSite, path: `${env.api.prefix}/auth`, maxAge: env.jwt.refreshTtlDays * 86400000 });
const setRefreshCookie = (res, token) => res.cookie('penguin_refresh_token', token, cookieOptions());
const clearRefreshCookie = (res) => res.clearCookie('penguin_refresh_token', { ...cookieOptions(), maxAge: undefined });

export async function login(req, res) {
  const identifier = String(req.body.identifier || req.body.username || req.body.email || '').trim();
  const password = String(req.body.password || '');
  if (!identifier || !password) throw new AppError('Email and password are required.', 422, 'VALIDATION_ERROR');
  const result = await authService.login({ identifier, password }, req);
  setRefreshCookie(res, result.refreshToken);
  res.json({ success: true, data: { accessToken: result.accessToken, user: result.user, permissions: result.permissions } });
}

export async function refresh(req, res) {
  const result = await authService.refresh(req.cookies?.penguin_refresh_token || req.body?.refreshToken, req);
  setRefreshCookie(res, result.refreshToken);
  res.json({ success: true, data: { accessToken: result.accessToken, user: result.user, permissions: result.permissions } });
}

export async function logout(req, res) {
  await authService.logout(req.cookies?.penguin_refresh_token || req.body?.refreshToken, req.user?.id);
  clearRefreshCookie(res);
  res.json({ success: true, data: { loggedOut: true } });
}

export async function me(req, res) {
  res.json({ success: true, data: await authService.getProfile(req.user.id) });
}

export async function changePassword(req, res) {
  await authService.changePassword(req.user.id, req.body);
  clearRefreshCookie(res);
  res.json({ success: true, message: 'Password updated. Sign in again to continue.' });
}
