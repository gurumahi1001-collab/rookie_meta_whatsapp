import Notification from '../../models/Notification.js';
import AppError from '../../utils/AppError.js';
import { emitToUser } from '../../services/realtime/realtimeService.js';
export async function list(req, res) {
  const items = await Notification.find({ recipientId: req.user.id }).sort({ createdAt: -1 }).limit(100);
  res.json({ success: true, data: items.map((x) => x.toJSON()) });
}
export async function markRead(req, res) {
  const item = await Notification.findOneAndUpdate({ _id: req.params.id, recipientId: req.user.id }, { $set: { readAt: new Date() } }, { new: true });
  if (!item) throw new AppError('Notification not found.', 404, 'NOTIFICATION_NOT_FOUND');
  emitToUser(req.user.id, 'notification:updated', item.toJSON());
  res.json({ success: true, data: item.toJSON() });
}
export async function markAllRead(req, res) {
  await Notification.updateMany({ recipientId: req.user.id, readAt: null }, { $set: { readAt: new Date() } });
  emitToUser(req.user.id, 'notification:read-all', { readAt: new Date().toISOString() });
  res.json({ success: true, data: { updated: true } });
}
