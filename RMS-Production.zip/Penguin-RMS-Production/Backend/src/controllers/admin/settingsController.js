import Setting from '../../models/Setting.js';
import User from '../../models/User.js';
import Role from '../../models/Role.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

const DEFAULT_PREFERENCES = {
  timezone: 'Asia/Kolkata', dateFormat: 'DD/MM/YYYY', pageSize: 25, landingPage: 'dashboard',
  autoRefresh: true, refreshInterval: 60, defaultWorkStatus: 'Assigned', qrSound: true
};
const DEFAULT_NOTIFICATIONS = {
  email: false, inApp: true, rework: true, quality: true, station: true, purchaseOrders: false, announcements: true
};
export async function getSettings(req, res) {
  const [user, prefs, notifications, api] = await Promise.all([
    User.findById(req.user.id), Setting.findOne({ key: 'preferences' }), Setting.findOne({ key: 'notifications' }), Setting.findOne({ key: 'api' })
  ]);
  const role = user ? await Role.findById(user.roleId) : null;
  res.json({ success: true, data: {
    profile: user ? { id: String(user._id), name: user.name, email: user.email, phone: user.phone, department: user.department, jobTitle: user.jobTitle, employeeId: user.employeeId, avatarUrl: user.avatarUrl, role: role?.name || '' } : null,
    preferences: { ...DEFAULT_PREFERENCES, ...(prefs?.value || {}) }, notifications: { ...DEFAULT_NOTIFICATIONS, ...(notifications?.value || {}) },
    api: { environment: process.env.NODE_ENV || 'development', version: 'v1', timeout: 30000, baseUrl: process.env.PUBLIC_API_URL || '', ...(api?.value || {}), health: 'managed-by-server' }
  } });
}
export async function updateSettings(req, res) {
  const { profile, preferences, notifications } = req.body || {};
  if (profile) {
    const user = await User.findById(req.user.id); if (!user) throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
    for (const key of ['name', 'phone', 'department', 'jobTitle', 'avatarUrl']) if (profile[key] !== undefined) user[key] = profile[key];
    await user.save();
  }
  if (preferences) await Setting.findOneAndUpdate({ key: 'preferences' }, { $set: { value: preferences, updatedBy: req.user.id } }, { upsert: true, new: true, setDefaultsOnInsert: true });
  if (notifications) await Setting.findOneAndUpdate({ key: 'notifications' }, { $set: { value: notifications, updatedBy: req.user.id } }, { upsert: true, new: true, setDefaultsOnInsert: true });
  await writeAudit(req, { action: 'settings.updated', module: 'settings', title: 'Application settings updated' });
  emitResourceChange({ resource: 'settings', module: 'settings', action: 'updated', actorId: req.user.id });
  return getSettings(req, res);
}
export async function updateApiSettings(req, res) {
  const allowed = ['environment', 'version', 'timeout', 'baseUrl'];
  const value = Object.fromEntries(allowed.filter((key) => req.body?.[key] !== undefined).map((key) => [key, req.body[key]]));
  await Setting.findOneAndUpdate({ key: 'api' }, { $set: { value, updatedBy: req.user.id } }, { upsert: true, new: true });
  await writeAudit(req, { action: 'settings.api_updated', module: 'settings', title: 'API display settings updated' });
  res.json({ success: true, data: value });
}

export async function updateProfileAvatar(req, res) {
  if (!req.file) throw new AppError('Choose a profile image to upload.', 422, 'FILE_REQUIRED');
  const user = await User.findById(req.user.id);
  if (!user) throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
  user.avatarUrl = `${req.protocol}://${req.get('host')}/uploads/${encodeURIComponent(req.file.filename)}`;
  await user.save();
  await writeAudit(req, { action: 'settings.avatar_updated', module: 'settings', title: 'Profile photo updated', entityType: 'user', entityId: user._id, entityName: user.name });
  emitResourceChange({ resource: 'profile', module: 'settings', action: 'updated', entityId: user._id, actorId: req.user.id });
  res.json({ success: true, data: { avatarUrl: user.avatarUrl } });
}
