import bcrypt from 'bcryptjs';
import User from '../../models/User.js';
import Role from '../../models/Role.js';
import Permission from '../../models/Permission.js';
import RolePermission from '../../models/RolePermission.js';
import Station from '../../models/Station.js';
import RefreshSession from '../../models/RefreshSession.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

const roleDto = (role) => ({ id: String(role._id), key: role.key, name: role.name, description: role.description, modules: role.modules || [], systemRole: !!role.systemRole, active: !!role.active });
const userDto = (user, role) => ({ id: String(user._id), name: user.name, email: user.email, role: role?.name || '', roleKey: role?.key || '', roleId: role ? String(role._id) : '', station: user.stationId || '', avatar: user.avatarUrl || '', active: user.status === 'active', phone: user.phone || '', employeeId: user.employeeId || '', department: user.department || '', jobTitle: user.jobTitle || '', lastLoginAt: user.lastLoginAt || null });

function roleLookup(value) {
  const token = String(value || '').trim();
  const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const alternatives = [{ key: token.toLowerCase() }, { name: new RegExp(`^${escaped}$`, 'i') }];
  if (/^[a-f\d]{24}$/i.test(token)) alternatives.unshift({ _id: token });
  return { $or: alternatives };
}

export async function listUserOptions(_req, res) {
  const stations = await Station.find({ status: 'Active' }).sort({ name: 1 }).select('name').lean();
  res.json({ success: true, data: stations.map((station) => ({ id: String(station._id), name: station.name })) });
}

export async function listUsers(_req, res) {
  const users = await User.find().sort({ createdAt: -1 });
  const roles = await Role.find().lean(); const map = new Map(roles.map((r) => [String(r._id), r]));
  res.json({ success: true, data: users.map((u) => userDto(u, map.get(String(u.roleId)))) });
}
export async function createUser(req, res) {
  const body = req.body || {};
  if (!body.name || !body.email || !body.password || !body.role) throw new AppError('Name, email, password and role are required.', 422, 'VALIDATION_ERROR');
  if (String(body.password).length < 12) throw new AppError('Password must be at least 12 characters.', 422, 'WEAK_PASSWORD');
  const role = await Role.findOne(roleLookup(body.role));
  if (!role) throw new AppError('Selected role does not exist.', 422, 'ROLE_NOT_FOUND');
  const user = await User.create({ name: body.name, email: body.email, passwordHash: await bcrypt.hash(body.password, 12), roleId: role._id, roleKey: role.key, stationId: body.station || body.stationId || '', avatarUrl: body.avatar || body.avatarUrl || '', phone: body.phone || '', employeeId: body.employeeId || '', department: body.department || '', jobTitle: body.jobTitle || '', status: body.active === false ? 'inactive' : 'active', createdBy: req.user.id });
  await writeAudit(req, { action: 'user.created', module: 'user-management', title: 'User created', entityType: 'user', entityId: user._id, entityName: user.name });
  emitResourceChange({ resource: 'users', module: 'user-management', action: 'created', entityId: user._id, actorId: req.user.id });
  res.status(201).json({ success: true, data: userDto(user, role) });
}
export async function updateUser(req, res) {
  const user = await User.findById(req.params.id); if (!user) throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
  const body = req.body || {};
  if (body.name !== undefined) user.name = body.name;
  if (body.email !== undefined) user.email = body.email;
  if (body.phone !== undefined) user.phone = body.phone;
  if (body.employeeId !== undefined) user.employeeId = body.employeeId;
  if (body.department !== undefined) user.department = body.department;
  if (body.jobTitle !== undefined) user.jobTitle = body.jobTitle;
  if (body.station !== undefined || body.stationId !== undefined) user.stationId = body.station ?? body.stationId;
  if (body.avatar !== undefined || body.avatarUrl !== undefined) user.avatarUrl = body.avatar ?? body.avatarUrl;
  if (body.active !== undefined) user.status = body.active ? 'active' : 'inactive';
  if (body.role !== undefined || body.roleId !== undefined) {
    const role = await Role.findOne(roleLookup(body.roleId || body.role));
    if (!role) throw new AppError('Selected role does not exist.', 422, 'ROLE_NOT_FOUND');
    user.roleId = role._id; user.roleKey = role.key;
  }
  if (body.password) { if (String(body.password).length < 12) throw new AppError('Password must be at least 12 characters.', 422, 'WEAK_PASSWORD'); user.passwordHash = await bcrypt.hash(body.password, 12); user.passwordChangedAt = new Date(); await RefreshSession.updateMany({ userId: user._id, revokedAt: null }, { $set: { revokedAt: new Date() } }); }
  await user.save(); const role = await Role.findById(user.roleId);
  await writeAudit(req, { action: 'user.updated', module: 'user-management', title: 'User updated', entityType: 'user', entityId: user._id, entityName: user.name });
  emitResourceChange({ resource: 'users', module: 'user-management', action: 'updated', entityId: user._id, actorId: req.user.id });
  res.json({ success: true, data: userDto(user, role) });
}
export async function deleteUser(req, res) {
  if (String(req.params.id) === req.user.id) throw new AppError('You cannot delete your own signed-in account.', 409, 'SELF_DELETE_BLOCKED');
  const user = await User.findById(req.params.id); if (!user) throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
  user.status = 'inactive'; await user.save(); await RefreshSession.updateMany({ userId: user._id, revokedAt: null }, { $set: { revokedAt: new Date() } });
  await writeAudit(req, { action: 'user.deactivated', module: 'user-management', title: 'User deactivated', entityType: 'user', entityId: user._id, entityName: user.name });
  emitResourceChange({ resource: 'users', module: 'user-management', action: 'deactivated', entityId: user._id, actorId: req.user.id });
  res.json({ success: true, data: { id: String(user._id), active: false } });
}
export async function listRoles(_req, res) {
  const roles = await Role.find().sort({ sortOrder: 1, name: 1 });
  res.json({ success: true, data: roles.map(roleDto) });
}
async function setRolePermissions(role, modules) {
  if (role.key === 'superadmin') throw new AppError('The built-in Super Admin role cannot be edited.', 409, 'SYSTEM_ROLE_LOCKED');
  const validModules = await Permission.find({ key: { $in: modules || [] }, active: true }).select('key');
  role.modules = [...new Set(validModules.map((item) => item.key))]; await role.save();
  const permissions = await Permission.find({ key: { $in: role.modules }, active: true });
  for (const permission of permissions) await RolePermission.findOneAndUpdate({ roleId: role._id, permissionId: permission._id }, { $set: { active: true, actions: { view: true, create: true, update: true, delete: false, approve: false, export: true, manage: false } }, $setOnInsert: { roleId: role._id, permissionId: permission._id } }, { upsert: true, new: true });
  await RolePermission.updateMany({ roleId: role._id, permissionId: { $nin: permissions.map((p) => p._id) } }, { $set: { active: false } });
}
export async function createRole(req, res) {
  const body = req.body || {}; if (!body.name) throw new AppError('Role name is required.', 422, 'VALIDATION_ERROR');
  const key = String(body.key || body.name).toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  const role = await Role.create({ key, name: body.name, description: body.description || '', modules: [], systemRole: false, active: true });
  await setRolePermissions(role, body.modules || []);
  await writeAudit(req, { action: 'role.created', module: 'user-management', title: 'Role created', entityType: 'role', entityId: role._id, entityName: role.name });
  emitResourceChange({ resource: 'roles', module: 'user-management', action: 'created', entityId: role._id, actorId: req.user.id });
  res.status(201).json({ success: true, data: roleDto(role) });
}
export async function updateRole(req, res) {
  const role = await Role.findById(req.params.id); if (!role) throw new AppError('Role not found.', 404, 'ROLE_NOT_FOUND');
  if (role.key === 'superadmin' && req.body.modules && req.body.modules.length !== role.modules.length) throw new AppError('Super Admin permissions cannot be reduced.', 409, 'SYSTEM_ROLE_PROTECTED');
  if (req.body.name !== undefined) role.name = req.body.name;
  if (req.body.description !== undefined) role.description = req.body.description;
  if (req.body.active !== undefined && role.key !== 'superadmin') role.active = !!req.body.active;
  await role.save(); if (req.body.modules) await setRolePermissions(role, req.body.modules);
  await writeAudit(req, { action: 'role.updated', module: 'user-management', title: 'Role updated', entityType: 'role', entityId: role._id, entityName: role.name });
  emitResourceChange({ resource: 'roles', module: 'user-management', action: 'updated', entityId: role._id, actorId: req.user.id });
  res.json({ success: true, data: roleDto(role) });
}
export async function deleteRole(req, res) {
  const role = await Role.findById(req.params.id); if (!role) throw new AppError('Role not found.', 404, 'ROLE_NOT_FOUND');
  if (role.systemRole || role.key === 'superadmin') throw new AppError('System roles cannot be deleted.', 409, 'SYSTEM_ROLE_PROTECTED');
  if (await User.exists({ roleId: role._id })) throw new AppError('This role is assigned to users. Reassign them before deleting it.', 409, 'ROLE_IN_USE');
  await RolePermission.deleteMany({ roleId: role._id }); await role.deleteOne();
  emitResourceChange({ resource: 'roles', module: 'user-management', action: 'deleted', entityId: role._id, actorId: req.user.id });
  res.json({ success: true, data: { id: String(role._id) } });
}
export async function listPermissions(_req, res) {
  const permissions = await Permission.find({ active: true }).sort({ sortOrder: 1 });
  res.json({ success: true, data: permissions.map((p) => p.toJSON()) });
}
