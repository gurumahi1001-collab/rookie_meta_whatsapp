import { getDashboardSummary } from '../../services/dashboard/dashboardService.js';
export async function summary(_req, res) { res.json({ success: true, data: await getDashboardSummary() }); }
