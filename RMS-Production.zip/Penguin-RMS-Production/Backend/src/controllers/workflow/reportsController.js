import WorkOrder from '../../models/WorkOrder.js';
import QAInspection from '../../models/QAInspection.js';
import AuditLog from '../../models/AuditLog.js';
import PurchaseOrder from '../../models/PurchaseOrder.js';
import Carton from '../../models/Carton.js';
import Station from '../../models/Station.js';
import Operator from '../../models/Operator.js';
import AppError from '../../utils/AppError.js';
export async function summary(req, res) {
  const days = Math.min(365, Math.max(7, Number(req.query.days) || 30));
  const from = new Date(); from.setDate(from.getDate() - days); from.setHours(0, 0, 0, 0);
  const [statusRows, dailyRows, inspectionRows, recentActivity, poRows, cartonCount] = await Promise.all([
    WorkOrder.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    WorkOrder.aggregate([{ $match: { registeredAt: { $gte: from } } }, { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$registeredAt' } }, registered: { $sum: 1 } } }, { $sort: { _id: 1 } }]),
    QAInspection.aggregate([{ $match: { inspectedAt: { $gte: from } } }, { $group: { _id: '$decision', count: { $sum: 1 } } }]),
    AuditLog.find({ createdAt: { $gte: from } }).sort({ createdAt: -1 }).limit(100).select('action module title description actorName entityName createdAt'),
    PurchaseOrder.countDocuments(), Carton.countDocuments()
  ]);
  const statuses = Object.fromEntries(statusRows.map((x) => [x._id, x.count]));
  const decisions = Object.fromEntries(inspectionRows.map((x) => [x._id, x.count]));
  const inspected = (decisions.Pass || 0) + (decisions.Reject || 0) + (decisions.Scrap || 0);
  res.json({ success: true, data: { periodDays: days, kpis: { purchaseOrders: poRows, cartons: cartonCount, totalWorkOrders: Object.values(statuses).reduce((a, b) => a + b, 0), qaPass: decisions.Pass || 0, qaReject: decisions.Reject || 0, qaScrap: decisions.Scrap || 0, qaPassRate: inspected ? Math.round(((decisions.Pass || 0) / inspected) * 1000) / 10 : 0 }, statusBreakdown: Object.entries(statuses).map(([status, count]) => ({ status, count })), dailyRegistrations: dailyRows.map((x) => ({ date: x._id, count: x.registered })), inspections: Object.entries(decisions).map(([decision, count]) => ({ decision, count })), auditActivity: recentActivity.map((x) => x.toJSON()) } });
}


export async function dataset(req, res) {
  const from = req.query.from ? new Date(String(req.query.from)) : new Date(Date.now() - 90 * 86400000);
  const to = req.query.to ? new Date(`${String(req.query.to).slice(0, 10)}T23:59:59.999Z`) : new Date();
  if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || from > to) throw new AppError('Invalid report date range.', 422, 'INVALID_DATE_RANGE');
  const workOrders = await WorkOrder.find({ registeredAt: { $gte: from, $lte: to } }).sort({ registeredAt: -1 }).limit(10000);
  const ids = workOrders.map((item) => String(item._id));
  const [inspections, stations, operators, auditActivity] = await Promise.all([
    QAInspection.find({ workOrderId: { $in: ids } }).sort({ inspectedAt: 1 }).limit(30000),
    Station.find().sort({ name: 1 }),
    Operator.find({ status: 'Active' }).sort({ name: 1 }),
    AuditLog.find({ createdAt: { $gte: from, $lte: to } }).sort({ createdAt: -1 }).limit(10000)
  ]);
  res.json({ success: true, data: { workOrders: workOrders.map((x) => x.toJSON()), inspections: inspections.map((x) => x.toJSON()), stations: stations.map((x) => x.toJSON()), operators: operators.map((x) => x.toJSON()), auditActivity: auditActivity.map((x) => x.toJSON()), from, to } });
}
