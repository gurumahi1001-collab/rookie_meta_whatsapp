import Station from '../../models/Station.js';
export async function options(_req, res) {
  const stations = await Station.find({ status: 'Active' }).sort({ name: 1 }).select('code name location');
  res.json({ success: true, data: { stations: stations.map((station) => station.toJSON()) } });
}
