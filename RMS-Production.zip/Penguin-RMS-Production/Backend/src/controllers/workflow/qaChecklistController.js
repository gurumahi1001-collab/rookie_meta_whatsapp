import crypto from 'node:crypto';
import QAChecklistItem from '../../models/QAChecklistItem.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

export async function listChecklist(_req, res) {
  const rows = await QAChecklistItem.find().sort({ sortOrder: 1, createdAt: 1 });
  res.json({ success: true, data: rows.map((row) => row.toJSON()) });
}

export async function createChecklistItem(req, res) {
  const title = String(req.body?.title || '').trim();
  const category = String(req.body?.category || '').trim();
  if (!title || !category) throw new AppError('Checklist item title and category are required.', 422, 'VALIDATION_ERROR');
  const last = await QAChecklistItem.findOne().sort({ sortOrder: -1 }).select('sortOrder').lean();
  const code = `CHK-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const item = await QAChecklistItem.create({ code, title, category, active: true, required: req.body?.required === true, sortOrder: (last?.sortOrder || 0) + 10, createdBy: req.user.id });
  await writeAudit(req, { action: 'qa_checklist.created', module: 'qa-inspection', title: 'QA checklist item created', entityType: 'qa_checklist_item', entityId: item._id, entityName: item.title });
  emitResourceChange({ resource: 'qa-checklist', module: 'qa-inspection', action: 'created', entityId: item._id, actorId: req.user.id });
  res.status(201).json({ success: true, data: item.toJSON() });
}

export async function updateChecklistItem(req, res) {
  const item = await QAChecklistItem.findById(req.params.id);
  if (!item) throw new AppError('QA checklist item not found.', 404, 'CHECKLIST_ITEM_NOT_FOUND');
  const body = req.body || {};
  if (body.title !== undefined) {
    const title = String(body.title).trim();
    if (!title) throw new AppError('Checklist item title cannot be empty.', 422, 'VALIDATION_ERROR');
    item.title = title;
  }
  if (body.category !== undefined) {
    const category = String(body.category).trim();
    if (!category) throw new AppError('Checklist category cannot be empty.', 422, 'VALIDATION_ERROR');
    item.category = category;
  }
  if (body.active !== undefined) item.active = Boolean(body.active);
  if (body.required !== undefined) item.required = Boolean(body.required);
  item.updatedBy = req.user.id;
  await item.save();
  await writeAudit(req, { action: 'qa_checklist.updated', module: 'qa-inspection', title: 'QA checklist item updated', entityType: 'qa_checklist_item', entityId: item._id, entityName: item.title });
  emitResourceChange({ resource: 'qa-checklist', module: 'qa-inspection', action: 'updated', entityId: item._id, actorId: req.user.id });
  res.json({ success: true, data: item.toJSON() });
}
