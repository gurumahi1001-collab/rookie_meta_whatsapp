import crypto from 'node:crypto';
import WorkOrder from '../../models/WorkOrder.js';
import Carton from '../../models/Carton.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

const asId = (value) => String(value?._id || value?.id || value || '');
const packableFilter = { status: { $in: ['QA Passed', 'Packed'] } };

export async function listPackableGarments(req, res) {
  const filter = { ...packableFilter };
  if (req.query.poNumber) filter.poNumber = String(req.query.poNumber);
  const records = await WorkOrder.find(filter).sort({ completedAt: 1, registeredAt: 1 });
  res.json({ success: true, data: records.map((x) => ({ ...x.toJSON(), workOrderId: String(x._id), qaStatus: 'QA Passed', qaApprovedAt: x.completedAt || x.updatedAt })) });
}

export async function listCartons(_req, res) {
  const records = await Carton.find().sort({ createdAt: -1 }).limit(500);
  res.json({ success: true, data: records.map((x) => x.toJSON()) });
}

function emitPackingChanges(carton, actorId, action = 'updated') {
  emitResourceChange({ resource: 'cartons', module: 'packing', action, entityId: carton?._id, actorId });
  emitResourceChange({ resource: 'packing-garments', module: 'packing', action: 'updated', actorId });
  emitResourceChange({ resource: 'work-orders', module: 'qr-rework', action: 'updated', actorId });
  emitResourceChange({ resource: 'work-orders', module: 'station-management', action: 'updated', actorId });
}

async function resolvePackableWorkOrders(ids) {
  const values = [...new Set((Array.isArray(ids) ? ids : []).map((x) => String(x).trim()).filter(Boolean))];
  if (!values.length) return [];
  const rows = await WorkOrder.find({
    $or: [
      { _id: { $in: values.filter((x) => /^[a-f\d]{24}$/i.test(x)) } },
      { garmentId: { $in: values } },
      { qrId: { $in: values } },
      { reworkId: { $in: values } }
    ]
  });
  if (rows.length !== values.length) throw new AppError('One or more selected garments could not be found.', 404, 'GARMENT_NOT_FOUND');
  return rows;
}

export async function createCarton(req, res) {
  const body = req.body || {};
  const requestedIds = Array.isArray(body.garmentIds) ? body.garmentIds : [];
  const garments = requestedIds.length ? await resolvePackableWorkOrders(requestedIds) : [];
  if (garments.some((x) => x.status !== 'QA Passed' || x.cartonId)) throw new AppError('One or more garments are no longer available for packing.', 409, 'GARMENT_NOT_PACKABLE');
  const poNumbers = [...new Set(garments.map((x) => x.poNumber))];
  const poNumber = String(body.poNumber || poNumbers[0] || '').trim();
  if (!poNumber) throw new AppError('Purchase order is required when creating an empty carton.', 422, 'PO_REQUIRED');
  if (poNumbers.length > 1 || (poNumbers.length && poNumbers[0] !== poNumber)) throw new AppError('A carton can contain garments from only one purchase order.', 422, 'MIXED_PURCHASE_ORDERS');
  const cartonId = String(body.cartonId || `CTN-${new Date().getFullYear()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`);
  const workOrderIds = garments.map((x) => String(x._id));
  const carton = await Carton.create({ cartonId, poNumber, packedBy: body.packedBy || req.user.name, remarks: body.remarks || '', packingDateTime: body.packingDateTime || new Date(), garmentIds: workOrderIds, createdBy: req.user.id, status: 'Open', dispatchStatus: 'Not Ready' });
  if (workOrderIds.length) {
    const result = await WorkOrder.updateMany({ _id: { $in: workOrderIds }, status: 'QA Passed', cartonId: '' }, { $set: { status: 'Packed', cartonId }, $push: { history: { title: 'Packed', description: `Added to carton ${cartonId}`, date: new Date(), status: 'completed' } } });
    if (result.modifiedCount !== workOrderIds.length) {
      await carton.deleteOne();
      await WorkOrder.updateMany({ _id: { $in: workOrderIds }, cartonId }, { $set: { status: 'QA Passed', cartonId: '' } });
      throw new AppError('Packing could not be committed because garment availability changed. Please retry.', 409, 'PACKING_CONFLICT');
    }
  }
  await writeAudit(req, { action: 'packing.carton_created', module: 'packing', title: 'Carton created', description: `${cartonId} created for ${poNumber}`, entityType: 'carton', entityId: carton._id, entityName: cartonId, metadata: { garmentIds: workOrderIds } });
  emitPackingChanges(carton, req.user.id, 'created');
  res.status(201).json({ success: true, data: carton.toJSON() });
}

export async function addGarments(req, res) {
  const carton = await Carton.findById(req.params.id);
  if (!carton) throw new AppError('Carton not found.', 404, 'CARTON_NOT_FOUND');
  if (carton.status !== 'Open') throw new AppError('Garments can only be added to an open carton.', 409, 'CARTON_LOCKED');
  const rows = await resolvePackableWorkOrders(req.body?.garmentIds);
  if (!rows.length) throw new AppError('Select at least one garment.', 422, 'GARMENTS_REQUIRED');
  if (rows.some((x) => x.status !== 'QA Passed' || x.cartonId)) throw new AppError('One or more garments are no longer available for packing.', 409, 'GARMENT_NOT_PACKABLE');
  if (rows.some((x) => x.poNumber !== carton.poNumber)) throw new AppError('A carton can contain garments from only one purchase order.', 422, 'MIXED_PURCHASE_ORDERS');
  const ids = rows.map((x) => String(x._id));
  const result = await WorkOrder.updateMany({ _id: { $in: ids }, status: 'QA Passed', cartonId: '' }, { $set: { status: 'Packed', cartonId: carton.cartonId }, $push: { history: { title: 'Packed', description: `Added to carton ${carton.cartonId}`, date: new Date(), status: 'completed' } } });
  if (result.modifiedCount !== ids.length) throw new AppError('Garment availability changed during packing. Refresh and retry.', 409, 'PACKING_CONFLICT');
  carton.garmentIds = [...new Set([...carton.garmentIds.map(String), ...ids])];
  await carton.save();
  await writeAudit(req, { action: 'packing.garments_added', module: 'packing', title: 'Garments added to carton', description: `${ids.length} garment(s) added to ${carton.cartonId}`, entityType: 'carton', entityId: carton._id, entityName: carton.cartonId, metadata: { garmentIds: ids } });
  emitPackingChanges(carton, req.user.id);
  res.json({ success: true, data: carton.toJSON() });
}

export async function closeCarton(req, res) {
  const carton = await Carton.findById(req.params.id);
  if (!carton) throw new AppError('Carton not found.', 404, 'CARTON_NOT_FOUND');
  if (carton.status !== 'Open') throw new AppError('Only open cartons can be closed.', 409, 'CARTON_LOCKED');
  if (!carton.garmentIds.length) throw new AppError('An empty carton cannot be closed.', 409, 'EMPTY_CARTON');
  carton.status = 'Closed'; carton.dispatchStatus = 'Ready for Dispatch'; carton.closedAt = new Date(); await carton.save();
  await writeAudit(req, { action: 'packing.carton_closed', module: 'packing', title: 'Carton closed', entityType: 'carton', entityId: carton._id, entityName: carton.cartonId });
  emitPackingChanges(carton, req.user.id);
  res.json({ success: true, data: carton.toJSON() });
}

export async function removeGarment(req, res) {
  const garmentCode = String(req.body?.garmentId || '').trim();
  const reason = String(req.body?.reason || '').trim();
  if (!garmentCode || !reason) throw new AppError('Garment and removal reason are required.', 422, 'VALIDATION_ERROR');
  const carton = await Carton.findById(req.params.id);
  if (!carton) throw new AppError('Carton not found.', 404, 'CARTON_NOT_FOUND');
  if (carton.status !== 'Open') throw new AppError('Garments can only be removed from an open carton.', 409, 'CARTON_LOCKED');
  const lookup = [{ garmentId: garmentCode }, { qrId: garmentCode }, { reworkId: garmentCode }];
  if (/^[a-f\d]{24}$/i.test(garmentCode)) lookup.unshift({ _id: garmentCode });
  const workOrder = await WorkOrder.findOne({ $or: lookup, cartonId: carton.cartonId });
  if (!workOrder || !carton.garmentIds.map(String).includes(String(workOrder._id))) throw new AppError('Garment is not in this carton.', 404, 'GARMENT_NOT_IN_CARTON');
  carton.garmentIds = carton.garmentIds.map(String).filter((x) => x !== String(workOrder._id));
  carton.removalLogs.push({ garmentId: workOrder.garmentId, reason, removedBy: req.user.name });
  await carton.save();
  workOrder.status = 'QA Passed'; workOrder.cartonId = '';
  workOrder.history.push({ title: 'Removed from carton', description: reason, date: new Date(), status: 'completed' });
  await workOrder.save();
  await writeAudit(req, { action: 'packing.garment_removed', module: 'packing', title: 'Garment removed from carton', description: `${workOrder.garmentId} removed from ${carton.cartonId}: ${reason}`, entityType: 'work_order', entityId: workOrder._id, entityName: workOrder.qrId });
  emitPackingChanges(carton, req.user.id);
  res.json({ success: true, data: carton.toJSON() });
}

export async function dispatchCarton(req, res) {
  const carton = await Carton.findById(req.params.id);
  if (!carton) throw new AppError('Carton not found.', 404, 'CARTON_NOT_FOUND');
  if (carton.status !== 'Closed') throw new AppError('Close the carton before dispatch.', 409, 'CARTON_NOT_CLOSED');
  carton.dispatchStatus = 'Dispatched';
  carton.dispatchedAt = new Date();
  await carton.save();
  await writeAudit(req, { action: 'packing.carton_dispatched', module: 'packing', title: 'Carton dispatched', entityType: 'carton', entityId: carton._id, entityName: carton.cartonId });
  emitPackingChanges(carton, req.user.id);
  res.json({ success: true, data: carton.toJSON() });
}
