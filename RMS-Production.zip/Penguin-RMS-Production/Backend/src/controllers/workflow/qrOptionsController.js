import PurchaseOrder from '../../models/PurchaseOrder.js';
import Station from '../../models/Station.js';
import Operator from '../../models/Operator.js';
import Defect from '../../models/Defect.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

export async function listOptions(_req, res) {
  const [purchaseOrders, stations, operators, defects] = await Promise.all([
    PurchaseOrder.find({ status: 'Active' }).sort({ poNumber: -1 }).select('poNumber style articleSku size color'),
    Station.find({ status: 'Active' }).sort({ name: 1 }).select('code name type location factory'),
    Operator.find({ status: 'Active' }).sort({ name: 1 }).select('employeeCode name role stationIds'),
    Defect.find({ status: 'Active' }).sort({ name: 1 }).select('code name severity categoryId categoryName reworkMinutes')
  ]);
  res.json({ success: true, data: {
    purchaseOrders: purchaseOrders.map((x) => x.toJSON()),
    stations: stations.map((x) => x.toJSON()),
    operators: operators.map((x) => x.toJSON()),
    defects: defects.map((x) => x.toJSON())
  } });
}

export async function createRegistrationStation(req, res) {
  const name = String(req.body?.name || '').trim();
  const location = String(req.body?.location || '').trim();
  if (!name || !location) throw new AppError('Station name and location are required.', 422, 'VALIDATION_ERROR');
  const code = String(req.body?.code || `ST-${name.toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24)}-${Date.now().toString().slice(-4)}`);
  const station = await Station.create({ code, name, type: req.body?.type || 'Repair Station', category: req.body?.category || 'Repair', location, factory: req.body?.factory || 'Factory A', status: 'Active', createdBy: req.user.id });
  await writeAudit(req, { action: 'station.created_from_rework', module: 'qr-rework', title: 'Station created', entityType: 'station', entityId: station._id, entityName: station.name });
  emitResourceChange({ resource: 'stations', module: 'qr-rework', action: 'created', entityId: station._id, actorId: req.user.id });
  emitResourceChange({ resource: 'stations', module: 'master-data', action: 'created', entityId: station._id, actorId: req.user.id });
  res.status(201).json({ success: true, data: station.toJSON() });
}
