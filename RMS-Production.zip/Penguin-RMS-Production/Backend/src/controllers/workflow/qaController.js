import WorkOrder from '../../models/WorkOrder.js';
import QAInspection from '../../models/QAInspection.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

export async function listQueue(_req, res) {
  const rows = await WorkOrder.find({ status: 'Sent to QA' }).sort({ submittedAt: 1, registeredAt: 1 });
  res.json({ success: true, data: rows.map((x) => x.toJSON()) });
}
export async function submitInspection(req, res) {
  const body = req.body || {};
  const workOrderId = body.workOrderId || body.id;
  const workOrder = await WorkOrder.findById(workOrderId);
  if (!workOrder) throw new AppError('Work order not found.', 404, 'WORK_ORDER_NOT_FOUND');
  if (!['Sent to QA', 'QA Rejected'].includes(workOrder.status)) throw new AppError('This work order is not waiting for QA inspection.', 409, 'INVALID_WORKFLOW_STATE');
  const decision = String(body.decision || body.outcome || '').trim();
  if (!['Pass', 'Reject', 'Scrap'].includes(decision)) throw new AppError('Inspection decision must be Pass, Reject or Scrap.', 422, 'INVALID_QA_DECISION');
  if (decision === 'Scrap' && req.user.roleKey !== 'superadmin' && req.user.roleKey !== 'production_manager') throw new AppError('Only authorized production administrators can scrap a garment.', 403, 'SCRAP_NOT_ALLOWED');
  const failedChecks = Array.isArray(body.failedChecks) ? body.failedChecks : [];
  if (decision === 'Reject' && failedChecks.length === 0 && !body.reason) throw new AppError('A rejection reason or failed checklist item is required.', 422, 'REJECTION_REASON_REQUIRED');
  const inspection = await QAInspection.create({
    workOrderId: String(workOrder._id), stationId: workOrder.stationId, stationName: workOrder.assignedStation, operatorName: workOrder.operator, size: workOrder.size, styleNumber: workOrder.styleNumber, defectCategory: workOrder.defectCategory, severity: workOrder.severity, description: workOrder.description, defectImage: workOrder.defectImageUrl || workOrder.defectImage, submittedAt: workOrder.submittedAt, reworkId: workOrder.reworkId, qrId: workOrder.qrId, garmentId: workOrder.garmentId, poNumber: workOrder.poNumber,
    decision, checklistResponses: Array.isArray(body.checklistResponses) ? body.checklistResponses : [], failedChecks,
    reason: body.reason || '', remarks: body.remarks || '', rejectedPhotoUrl: body.rejectedPhotoUrl || '', returnStationId: body.returnStationId || '',
    inspectorId: req.user.id, inspectorName: req.user.name, inspectedAt: new Date()
  });
  const nextStatus = decision === 'Pass' ? 'QA Passed' : decision === 'Reject' ? 'QA Rejected' : 'Scrap';
  workOrder.status = nextStatus;
  if (decision === 'Reject' && body.returnStationId) workOrder.stationId = body.returnStationId;
  workOrder.history.push({ title: `QA ${decision}`, description: body.remarks || body.reason || `Inspection decision: ${decision}`, date: new Date(), status: 'completed' });
  await workOrder.save();
  await writeAudit(req, { action: `qa.${decision.toLowerCase()}`, module: 'qa-inspection', title: `QA ${decision}`, description: `Inspection ${decision.toLowerCase()} for ${workOrder.qrId}`, entityType: 'work_order', entityId: workOrder._id, entityName: workOrder.qrId, metadata: { inspectionId: String(inspection._id), failedChecks } });
  emitResourceChange({ resource: 'work-orders', module: 'qa-inspection', action: 'updated', entityId: workOrder._id, actorId: req.user.id });
  emitResourceChange({ resource: 'qa-queue', module: 'qa-inspection', action: 'updated', entityId: workOrder._id, actorId: req.user.id });
  emitResourceChange({ resource: 'inspections', module: 'qa-inspection', action: 'created', entityId: inspection._id, actorId: req.user.id });
  emitResourceChange({ resource: 'packing-garments', module: 'packing', action: 'updated', entityId: workOrder._id, actorId: req.user.id });
  res.status(201).json({ success: true, data: { inspection: inspection.toJSON(), workOrder: workOrder.toJSON() } });
}
export async function garmentHistory(req, res) {
  const value = String(req.params.code || '');
  const workOrder = await WorkOrder.findOne({ $or: [{ qrId: value }, { garmentId: value }, { reworkId: value }] });
  if (!workOrder) throw new AppError('No garment trace was found for this code.', 404, 'GARMENT_NOT_FOUND');
  const inspections = await QAInspection.find({ workOrderId: String(workOrder._id) }).sort({ inspectedAt: -1 });
  res.json({ success: true, data: { workOrder: workOrder.toJSON(), inspections: inspections.map((x) => x.toJSON()) } });
}

export async function resubmitForInspection(req, res) {
  const workOrder = await WorkOrder.findById(req.params.id);
  if (!workOrder) throw new AppError('Work order not found.', 404, 'WORK_ORDER_NOT_FOUND');
  if (workOrder.status !== 'QA Rejected') throw new AppError('Only rejected garments can be resubmitted for QA.', 409, 'INVALID_WORKFLOW_STATE');
  workOrder.status = 'In Progress';
  workOrder.history.push({ title: 'Repair Resumed', description: 'Garment marked ready for corrective rework.', date: new Date(), status: 'completed' });
  workOrder.status = 'Sent to QA';
  workOrder.submittedAt = new Date();
  workOrder.completedAt = new Date();
  workOrder.history.push({ title: 'Resubmitted to QA', description: 'Garment returned to the QA inspection queue.', date: new Date(), status: 'completed' });
  await workOrder.save();
  await writeAudit(req, { action: 'qa.resubmitted', module: 'qa-inspection', title: 'Garment resubmitted to QA', entityType: 'work_order', entityId: workOrder._id, entityName: workOrder.qrId });
  emitResourceChange({ resource: 'qa-queue', module: 'qa-inspection', action: 'created', entityId: workOrder._id, actorId: req.user.id });
  emitResourceChange({ resource: 'work-orders', module: 'qr-rework', action: 'updated', entityId: workOrder._id, actorId: req.user.id });
  res.json({ success: true, data: workOrder.toJSON() });
}
