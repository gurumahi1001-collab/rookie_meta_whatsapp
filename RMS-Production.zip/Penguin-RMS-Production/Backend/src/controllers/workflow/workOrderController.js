import WorkOrder from '../../models/WorkOrder.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';

const transitions = {
  Assigned: ['In Progress'],
  'In Progress': ['In Progress', 'Assigned', 'Sent to QA'],
  'QA Rejected': ['In Progress'],
  'Sent to QA': [],
  'QA Passed': [],
  Packed: [],
  Scrap: []
};
export async function updateWorkOrder(req, res) {
  const row = await WorkOrder.findById(req.params.id);
  if (!row) throw new AppError('Work order not found.', 404, 'WORK_ORDER_NOT_FOUND');
  const body = req.body || {};
  const nextStatus = body.status || row.status;
  if (nextStatus !== row.status && !transitions[row.status]?.includes(nextStatus)) throw new AppError(`Transition from ${row.status} to ${nextStatus} is not allowed.`, 409, 'INVALID_WORKFLOW_TRANSITION');
  for (const key of ['repairDetails', 'repairRemarks', 'materialsUsed']) if (body[key] !== undefined) row[key] = body[key];
  if (body.operatorId !== undefined) row.operatorId = body.operatorId;
  if (body.operator !== undefined) row.operator = body.operator;
  if (body.stationId !== undefined) row.stationId = body.stationId;
  if (body.assignedStation !== undefined) row.assignedStation = body.assignedStation;
  if (body.duration !== undefined) row.duration = Math.max(0, Number(body.duration) || 0);
  if (nextStatus !== row.status) {
    row.status = nextStatus;
    if (nextStatus === 'In Progress' && !row.startedAt) row.startedAt = new Date();
    if (nextStatus === 'Sent to QA') { row.submittedAt = new Date(); row.completedAt = new Date(); }
    row.history.unshift({ title: 'Repair Progress Updated', description: `Status changed to ${nextStatus}. ${body.repairRemarks || ''}`.trim(), date: new Date(), status: 'completed' });
  }
  row.updatedBy = req.user.id; await row.save();
  await writeAudit(req, { action: 'work_order.updated', module: 'station-management', title: 'Work order updated', description: `${row.reworkId} changed to ${row.status}`, entityType: 'work_order', entityId: row._id, entityName: row.qrId, metadata: { status: row.status } });
  emitResourceChange({ resource: 'work-orders', module: 'station-management', action: 'updated', entityId: row._id, actorId: req.user.id });
  emitResourceChange({ resource: 'work-orders', module: 'qr-rework', action: 'updated', entityId: row._id, actorId: req.user.id });
  if (row.status === 'Sent to QA') emitResourceChange({ resource: 'qa-queue', module: 'qa-inspection', action: 'created', entityId: row._id, actorId: req.user.id });
  res.json({ success: true, data: row.toJSON() });
}
