import AppError from '../utils/AppError.js';
export async function uploadImage(req, res) {
  if (!req.file) throw new AppError('Choose an image file to upload.', 422, 'FILE_REQUIRED');
  const url = `${req.protocol}://${req.get('host')}/uploads/${encodeURIComponent(req.file.filename)}`;
  res.status(201).json({ success: true, data: { url, filename: req.file.filename, mimeType: req.file.mimetype, size: req.file.size } });
}
