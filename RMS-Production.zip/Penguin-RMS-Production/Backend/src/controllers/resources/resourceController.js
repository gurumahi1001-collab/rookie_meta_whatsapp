import AppError from '../../utils/AppError.js';
import { RESOURCES } from '../../services/resources/resourceRegistry.js';
import { writeAudit } from '../../services/audit/auditService.js';
import { emitResourceChange } from '../../services/realtime/realtimeService.js';
import WorkOrder from '../../models/WorkOrder.js';

const escapeRegExp = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const cleanBody = (body) => {
  const value = { ...body };
  for (const key of Object.keys(value)) if (key.startsWith('$') || key.includes('.')) delete value[key];
  delete value._id; delete value.id; delete value.createdAt; delete value.updatedAt;
  return value;
};

function emitResourceEvent(req, { resource, module, action, entityId, actorId }) {
  const routeModule = req.baseUrl.startsWith('/master-data/') ? 'master-data'
    : (resource === 'stations' || resource === 'operators') ? 'station-management' : module;
  emitResourceChange({ resource, module: routeModule, action, entityId, actorId });
  if (routeModule !== module) emitResourceChange({ resource, module, action, entityId, actorId });
}

export function resourceController(resourceKey) {
  const config = RESOURCES[resourceKey];
  if (!config) throw new Error(`Unknown resource '${resourceKey}'`);
  const { model: Model, module, search: searchFields, sort: defaultSort } = config;

  return {
    list: async (req, res) => {
      const page = Math.max(1, Number.parseInt(req.query.page || '1', 10) || 1);
      const pageSize = Math.min(200, Math.max(1, Number.parseInt(req.query.pageSize || '50', 10) || 50));
      const filter = {};
      if (req.query.status && req.query.status !== 'all') filter.status = req.query.status;
      if (req.query.poNumber) filter.poNumber = String(req.query.poNumber);
      if (req.query.stationId) filter.stationId = String(req.query.stationId);
      if (req.query.categoryId) filter.categoryId = String(req.query.categoryId);
      if (req.query.from || req.query.to) {
        const field = resourceKey === 'inspections' ? 'inspectedAt' : resourceKey === 'work-orders' ? 'registeredAt' : 'createdAt';
        filter[field] = {};
        if (req.query.from) filter[field].$gte = new Date(String(req.query.from));
        if (req.query.to) filter[field].$lte = new Date(`${String(req.query.to).slice(0, 10)}T23:59:59.999Z`);
      }
      const search = String(req.query.search || '').trim();
      if (search) {
        const regex = new RegExp(escapeRegExp(search), 'i');
        filter.$or = searchFields.map((field) => ({ [field]: regex }));
      }
      const [rows, total] = await Promise.all([
        Model.find(filter).sort(defaultSort).skip((page - 1) * pageSize).limit(pageSize),
        Model.countDocuments(filter)
      ]);
      let items = rows.map((row) => row.toJSON());
      if (resourceKey === 'purchase-orders' && items.length) {
        const poNumbers = items.map((item) => item.poNumber);
        const aggregates = await WorkOrder.aggregate([
          { $match: { poNumber: { $in: poNumbers } } },
          { $group: { _id: '$poNumber', totalReworks: { $sum: 1 }, inProgress: { $sum: { $cond: [{ $in: ['$status', ['Assigned', 'In Progress', 'Sent to QA', 'QA Rejected']] }, 1, 0] } }, completed: { $sum: { $cond: [{ $in: ['$status', ['QA Passed', 'Packed']] }, 1, 0] } }, irreparable: { $sum: { $cond: [{ $eq: ['$status', 'Scrap'] }, 1, 0] } } } }
        ]);
        const metrics = new Map(aggregates.map((item) => [item._id, item]));
        items = items.map((item) => ({ ...item, ...(metrics.get(item.poNumber) || { totalReworks: 0, inProgress: 0, completed: 0, irreparable: 0 }) }));
      }
      res.json({ success: true, data: { items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) } });
    },
    getOne: async (req, res) => {
      const row = await Model.findById(req.params.id);
      if (!row) throw new AppError('Record not found.', 404, 'RECORD_NOT_FOUND');
      res.json({ success: true, data: row.toJSON() });
    },
    create: async (req, res) => {
      const payload = cleanBody(req.body);
      if (resourceKey === 'work-orders') {
        payload.createdBy = req.user.id;
        payload.history = Array.isArray(payload.history) ? payload.history : [];
        payload.registeredAt = payload.registeredAt ? new Date(payload.registeredAt) : new Date();
        payload.registeredDate = payload.registeredDate || payload.registeredAt.toLocaleDateString('en-GB');
        payload.stationId = String(payload.stationId || '');
        payload.operatorId = String(payload.operatorId || '');
        payload.assignedStation = String(payload.assignedStation || '');
        payload.operator = String(payload.operator || '');
        payload.status = payload.status || 'Assigned';
        payload.history.unshift({ title: 'Defect Registered', description: payload.description || 'New garment defect registered.', date: new Date(), status: 'completed' });
      } else if (resourceKey === 'purchase-orders') {
        payload.createdBy = req.user.id;
        payload.orderedQty = Array.isArray(payload.items) ? payload.items.reduce((sum, item) => sum + Number(item.orderedQty || 0), 0) : Number(payload.orderedQty || 0);
      } else if (resourceKey === 'cartons') payload.createdBy = req.user.id;
      const row = await Model.create(payload);
      await writeAudit(req, { action: `${resourceKey}.created`, module, title: 'Record created', entityType: resourceKey, entityId: row._id, entityName: row.name || row.poNumber || row.cartonId || row.reworkId || '' });
      emitResourceEvent(req, { resource: resourceKey, module, action: 'created', entityId: row._id, actorId: req.user.id });
      if (resourceKey === 'work-orders') emitResourceChange({ resource: 'work-orders', module: 'qr-rework', action: 'created', entityId: row._id, actorId: req.user.id });
      res.status(201).json({ success: true, data: row.toJSON() });
    },
    update: async (req, res) => {
      const row = await Model.findById(req.params.id);
      if (!row) throw new AppError('Record not found.', 404, 'RECORD_NOT_FOUND');
      const payload = cleanBody(req.body);
      if (resourceKey === 'work-orders') payload.updatedBy = req.user.id;
      if (resourceKey === 'purchase-orders' && Array.isArray(payload.items)) payload.orderedQty = payload.items.reduce((sum, item) => sum + Number(item.orderedQty || 0), 0);
      Object.assign(row, payload);
      await row.save();
      await writeAudit(req, { action: `${resourceKey}.updated`, module, title: 'Record updated', entityType: resourceKey, entityId: row._id, entityName: row.name || row.poNumber || row.cartonId || row.reworkId || '' });
      emitResourceEvent(req, { resource: resourceKey, module, action: 'updated', entityId: row._id, actorId: req.user.id });
      res.json({ success: true, data: row.toJSON() });
    },
    remove: async (req, res) => {
      const row = await Model.findById(req.params.id);
      if (!row) throw new AppError('Record not found.', 404, 'RECORD_NOT_FOUND');
      if (resourceKey === 'work-orders' && ['Packed', 'QA Passed'].includes(row.status)) throw new AppError('Completed garments cannot be deleted from the traceability history.', 409, 'WORK_ORDER_LOCKED');
      await row.deleteOne();
      await writeAudit(req, { action: `${resourceKey}.deleted`, module, title: 'Record deleted', entityType: resourceKey, entityId: row._id, entityName: row.name || row.poNumber || row.cartonId || row.reworkId || '' });
      emitResourceEvent(req, { resource: resourceKey, module, action: 'deleted', entityId: row._id, actorId: req.user.id });
      res.json({ success: true, data: { id: String(row._id) } });
    }
  };
}
