import RolePermission from '../models/RolePermission.js';
import Permission from '../models/Permission.js';
import AppError from '../utils/AppError.js';

export function requirePermission(moduleKey, action = 'view') {
  return async (req, _res, next) => {
    try {
      if (!req.user) throw new AppError('Authentication required.', 401, 'AUTHENTICATION_REQUIRED');
      if (req.user.roleKey === 'superadmin') return next();
      const permission = await Permission.findOne({ key: moduleKey, active: true }).select('_id');
      if (!permission) throw new AppError('Permission module is not configured.', 403, 'PERMISSION_NOT_CONFIGURED');
      const assignment = await RolePermission.findOne({ roleId: req.user.roleId, permissionId: permission._id, active: true }).lean();
      const allowed = assignment?.actions?.[action] === true || assignment?.actions?.manage === true;
      if (!allowed) throw new AppError('You do not have permission to perform this action.', 403, 'FORBIDDEN', { module: moduleKey, action });
      next();
    } catch (error) { next(error); }
  };
}

export function requireAnyPermission(moduleKey, actions = []) {
  return async (req, _res, next) => {
    try {
      if (!req.user) throw new AppError('Authentication required.', 401, 'AUTHENTICATION_REQUIRED');
      if (req.user.roleKey === 'superadmin') return next();
      const permission = await Permission.findOne({ key: moduleKey, active: true }).select('_id');
      if (!permission) throw new AppError('Permission module is not configured.', 403, 'PERMISSION_NOT_CONFIGURED');
      const assignment = await RolePermission.findOne({ roleId: req.user.roleId, permissionId: permission._id, active: true }).lean();
      const allowed = actions.some((action) => assignment?.actions?.[action] === true) || assignment?.actions?.manage === true;
      if (!allowed) throw new AppError('You do not have permission to perform this action.', 403, 'FORBIDDEN', { module: moduleKey, actions });
      next();
    } catch (error) { next(error); }
  };
}
