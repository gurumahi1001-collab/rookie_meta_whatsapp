import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import multer from 'multer';
import env from '../config/env.js';
import AppError from '../utils/AppError.js';

const uploadPath = path.resolve(process.cwd(), env.uploads.directory);
fs.mkdirSync(uploadPath, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, callback) => callback(null, uploadPath),
  filename: (_req, file, callback) => {
    const extension = ({ 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' })[file.mimetype];
    callback(null, `${Date.now()}-${crypto.randomBytes(12).toString('hex')}${extension || ''}`);
  }
});
const parser = multer({
  storage,
  limits: { fileSize: env.uploads.maxFileSizeBytes, files: 1, fields: 5 },
  fileFilter: (_req, file, callback) => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) return callback(new AppError('Only JPEG, PNG and WebP images are allowed.', 415, 'UNSUPPORTED_FILE_TYPE'));
    callback(null, true);
  }
});
export default parser;
