import mongoose from 'mongoose';
import logger from '../utils/logger.js';
export function notFound(req, _res, next) {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.statusCode = 404; error.code = 'ROUTE_NOT_FOUND'; next(error);
}
export function errorHandler(error, req, res, _next) {
  let status = Number(error.statusCode || error.status || 500);
  let code = error.code || 'INTERNAL_SERVER_ERROR';
  let message = error.message || 'An unexpected error occurred.';
  if (error instanceof mongoose.Error.ValidationError) { status = 422; code = 'VALIDATION_ERROR'; message = 'Submitted data did not pass validation.'; }
  if (error instanceof mongoose.Error.CastError) { status = 400; code = 'INVALID_IDENTIFIER'; message = 'The requested identifier is invalid.'; }
  if (error?.code === 11000) { status = 409; code = 'DUPLICATE_RECORD'; message = 'A record with this unique value already exists.'; }
  if (status >= 500) logger.error({ err: error, requestId: req.requestId, method: req.method, path: req.originalUrl }, 'Unhandled API error');
  else logger.warn({ code, requestId: req.requestId, message }, 'API request rejected');
  res.status(status).json({ success: false, error: { code, message: status >= 500 && process.env.NODE_ENV === 'production' ? 'An unexpected server error occurred.' : message, ...(error.details ? { details: error.details } : {}) }, requestId: req.requestId });
}
