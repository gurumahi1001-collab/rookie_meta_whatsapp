import jwt from 'jsonwebtoken';
import env from '../config/env.js';
import User from '../models/User.js';
import Role from '../models/Role.js';
import AppError from '../utils/AppError.js';
import RefreshSession from '../models/RefreshSession.js';

function extractToken(req) {
  const header = req.get('authorization');
  if (header) {
    const [scheme, token, extra] = header.trim().split(/\s+/);
    if (scheme !== 'Bearer' || !token || extra) throw new AppError('Authorization header must use Bearer authentication.', 401, 'INVALID_AUTHORIZATION_HEADER');
    return token;
  }
  return req.cookies?.penguin_access_token || null;
}

export async function authenticate(req, _res, next) {
  try {
    const token = extractToken(req);
    if (!token) throw new AppError('Authentication required.', 401, 'AUTHENTICATION_REQUIRED');
    let payload;
    try { payload = jwt.verify(token, env.jwt.accessSecret, { issuer: 'penguin-rms', audience: 'penguin-rms-web' }); }
    catch { throw new AppError('Access token is invalid or expired.', 401, 'ACCESS_TOKEN_INVALID'); }
    if (payload.type !== 'access' || !payload.sid) throw new AppError('Invalid access token type.', 401, 'ACCESS_TOKEN_INVALID');
    const session = await RefreshSession.findOne({ sessionId: payload.sid, userId: payload.sub, revokedAt: null, expiresAt: { $gt: new Date() } }).select('_id');
    if (!session) throw new AppError('Session has expired or was revoked. Please sign in again.', 401, 'SESSION_REVOKED');
    const user = await User.findById(payload.sub);
    if (!user || user.status !== 'active') throw new AppError('User account is unavailable.', 401, 'ACCOUNT_INACTIVE');
    const role = await Role.findById(user.roleId);
    if (!role || !role.active) throw new AppError('Assigned role is unavailable.', 403, 'ROLE_INACTIVE');
    req.user = { id: String(user._id), email: user.email, name: user.name, roleId: String(role._id), roleKey: role.key, roleName: role.name, stationId: user.stationId };
    req.auth = { sessionId: payload.sid, issuedAt: payload.iat, expiresAt: payload.exp };
    next();
  } catch (error) { next(error); }
}

export function optionalAuthenticate(req, _res, next) {
  const token = extractToken(req);
  if (!token) return next();
  authenticate(req, _res, next);
}
