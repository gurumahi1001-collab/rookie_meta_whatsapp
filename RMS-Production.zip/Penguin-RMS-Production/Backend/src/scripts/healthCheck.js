import { connectDatabase, disconnectDatabase, getConnectionState } from '../config/database.js';
try { await connectDatabase(); console.log(JSON.stringify({ status: 'ok', database: getConnectionState() })); }
catch (error) { console.error(JSON.stringify({ status: 'error', message: error.message })); process.exitCode = 1; }
finally { await disconnectDatabase(); }
