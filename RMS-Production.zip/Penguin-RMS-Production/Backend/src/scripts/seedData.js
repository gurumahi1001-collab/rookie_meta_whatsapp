import { pathToFileURL } from 'node:url';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import env from '../config/env.js';
import { connectDatabase, disconnectDatabase } from '../config/database.js';
import User from '../models/User.js';
import Role from '../models/Role.js';
import Permission from '../models/Permission.js';
import RolePermission from '../models/RolePermission.js';
import Station from '../models/Station.js';
import Operator from '../models/Operator.js';
import DefectCategory from '../models/DefectCategory.js';
import Defect from '../models/Defect.js';
import QAChecklistItem from '../models/QAChecklistItem.js';
import { MODULES, ROLE_DEFINITIONS, ACTIONS } from '../constants/permissions.js';
import logger from '../utils/logger.js';

const STATIONS = [
  { code: 'ST-STITCH-01', name: 'Stitching Repair Station Alpha', type: 'Stitching Station', category: 'Stitching', location: 'Floor 2, Zone B', factory: 'Factory A', capacity: 30 },
  { code: 'ST-STAIN-02', name: 'Stain Removal & Wash Station', type: 'Stain Removal Station', category: 'Stain Removal', location: 'Floor 1, Zone A', factory: 'Factory A', capacity: 24 },
  { code: 'ST-FABRIC-03', name: 'Fabric & Darning Station', type: 'Fabric Repair Station', category: 'Fabric Repair', location: 'Floor 2, Zone C', factory: 'Factory A', capacity: 20 },
  { code: 'ST-MEAS-04', name: 'Measurement & Alteration Station', type: 'Measurement Correction Station', category: 'Measurement', location: 'Floor 3, Zone A', factory: 'Factory A', capacity: 18 },
  { code: 'ST-FINISH-05', name: 'Final Finishing & Buttoning', type: 'Finishing Station', category: 'Finishing', location: 'Floor 3, Zone B', factory: 'Factory A', capacity: 35 },
  { code: 'ST-STITCH-02', name: 'Stitching Repair Station Beta', type: 'Stitching Station', category: 'Stitching', location: 'Floor 2, Zone D', factory: 'Factory A', capacity: 25 }
];
const CATEGORIES = [
  { code: 'CAT-STITCH', name: 'Stitching Defect', description: 'Skipped stitches, broken threads, uneven hems, and tension issues.', severity: 'Major' },
  { code: 'CAT-STAIN', name: 'Stain', description: 'Oil spots, dye marks, water stains, and chemical residues.', severity: 'Minor' },
  { code: 'CAT-FABRIC', name: 'Fabric Damage', description: 'Snags, pulls, yarn defects, and weaving flaws.', severity: 'Critical' },
  { code: 'CAT-TEAR', name: 'Tear or Hole', description: 'Accidental cuts, needle punctures, and fabric tears.', severity: 'Critical' },
  { code: 'CAT-COLOR', name: 'Color Defect', description: 'Shade variation, dye bleeding, and fading.', severity: 'Major' },
  { code: 'CAT-MEAS', name: 'Measurement Issue', description: 'Size tolerance deviations and measurement mismatch.', severity: 'Major' },
  { code: 'CAT-ACCESSORY', name: 'Missing Button/Accessory', description: 'Missing, loose, or incorrectly attached accessories.', severity: 'Minor' }
];
const DEFECTS = [
  { code: 'DEF-ST-001', name: 'Skip Stitch on Collar', categoryCode: 'CAT-STITCH', severity: 'Major', reworkMinutes: 15, description: 'Missing stitch lock on collar band or collar point.' },
  { code: 'DEF-TR-002', name: 'Needle Drop Hole', categoryCode: 'CAT-TEAR', severity: 'Critical', reworkMinutes: 25, description: 'Hole caused by needle strike during sewing.' },
  { code: 'DEF-STN-003', name: 'Machine Oil Spot', categoryCode: 'CAT-STAIN', severity: 'Minor', reworkMinutes: 10, description: 'Lubricant oil droplet on cuff, pocket, or placket.' },
  { code: 'DEF-ME-004', name: 'Sleeve Length Deviation', categoryCode: 'CAT-MEAS', severity: 'Major', reworkMinutes: 30, description: 'Sleeve length exceeds the permitted tolerance.' },
  { code: 'DEF-AC-005', name: 'Missing Waist Button', categoryCode: 'CAT-ACCESSORY', severity: 'Minor', reworkMinutes: 8, description: 'Button is missing or not secured on waistband.' },
  { code: 'DEF-FB-006', name: 'Fabric Yarn Snag', categoryCode: 'CAT-FABRIC', severity: 'Major', reworkMinutes: 20, description: 'Pulled yarn fiber on front or back body panel.' }
];
const QA_CHECKLIST = [
  { code: 'CHK-01', title: 'Stitching uniformity', category: 'Stitching & Seams', active: true, required: true, sortOrder: 10 },
  { code: 'CHK-02', title: 'Seam and stitch quality', category: 'Stitching & Seams', active: true, required: true, sortOrder: 20 },
  { code: 'CHK-03', title: 'Stain removal', category: 'Fabric Appearance', active: true, required: true, sortOrder: 30 },
  { code: 'CHK-04', title: 'Fabric reinforcement / darning', category: 'Fabric Integrity', active: true, required: true, sortOrder: 40 },
  { code: 'CHK-05', title: 'Measurements within tolerance', category: 'Measurements', active: true, required: true, sortOrder: 50 },
  { code: 'CHK-06', title: 'Accessories and trims', category: 'Accessories & Trims', active: true, required: true, sortOrder: 60 },
  { code: 'CHK-07', title: 'Final finishing', category: 'Finishing', active: true, required: true, sortOrder: 70 },
  { code: 'CHK-08', title: 'Other agreed inspection items', category: 'Additional Checks', active: true, required: false, sortOrder: 80 }
];
const OPERATORS = [
  { employeeCode: 'USR-001', name: 'Karthik Subramanian', role: 'Admin' },
  { employeeCode: 'USR-002', name: 'Ananya Ramesh', role: 'Rework Inspector' },
  { employeeCode: 'USR-003', name: 'Senthil Kumar', role: 'Station Operator' },
  { employeeCode: 'USR-004', name: 'Divya Balaji', role: 'Station Operator' },
  { employeeCode: 'USR-005', name: 'Arunachalam Nathan', role: 'Station Operator' },
  { employeeCode: 'USR-006', name: 'Vijay Anand', role: 'QA Inspector' },
  { employeeCode: 'USR-007', name: 'Murugan Selvam', role: 'Packing Operator' },
  { employeeCode: 'USR-008', name: 'Kavitha Ramasamy', role: 'Production Manager' }
];

function actionsForRole(roleKey, moduleKey) {
  if (roleKey === 'superadmin') return Object.fromEntries(ACTIONS.map((action) => [action, true]));
  const matrix = {
    production_manager: { view: true, create: true, update: true, delete: false, approve: true, export: true, manage: false },
    purchase_manager: { view: true, create: true, update: true, delete: false, approve: false, export: true, manage: false },
    rework_inspector: { view: true, create: true, update: true, delete: false, approve: false, export: true, manage: false },
    station_operator: { view: true, create: false, update: true, delete: false, approve: false, export: false, manage: false },
    qa_inspector: { view: true, create: true, update: true, delete: false, approve: true, export: true, manage: false },
    packing_operator: { view: true, create: true, update: true, delete: false, approve: true, export: false, manage: false }
  };
  const roleActions = matrix[roleKey] || {};
  if (roleKey === 'purchase_manager' && !['dashboard', 'purchase-orders', 'reports'].includes(moduleKey)) return {};
  if (roleKey === 'rework_inspector' && !['dashboard', 'qr-rework', 'reports'].includes(moduleKey)) return {};
  if (roleKey === 'station_operator' && !['dashboard', 'station-management', 'qr-rework'].includes(moduleKey)) return {};
  if (roleKey === 'qa_inspector' && !['dashboard', 'qa-inspection', 'reports'].includes(moduleKey)) return {};
  if (roleKey === 'packing_operator' && !['dashboard', 'packing'].includes(moduleKey)) return {};
  if (roleKey === 'production_manager' && ['user-management', 'settings'].includes(moduleKey)) return {};
  return roleActions;
}

async function seedPermissions() {
  const map = new Map();
  for (const [index, definition] of MODULES.entries()) {
    const permission = await Permission.findOneAndUpdate({ key: definition.key }, { $setOnInsert: { key: definition.key, name: definition.name, description: `${definition.name} access.`, category: definition.category, actions: ACTIONS, active: true, system: true, sortOrder: (index + 1) * 10 } }, { upsert: true, new: true, setDefaultsOnInsert: true });
    map.set(permission.key, permission);
  }
  return map;
}
async function seedRoles(permissionMap) {
  const roleMap = new Map();
  for (const definition of ROLE_DEFINITIONS) {
    const role = await Role.findOneAndUpdate({ key: definition.key }, { $setOnInsert: definition }, { upsert: true, new: true, setDefaultsOnInsert: true });
    roleMap.set(role.key, role);
    for (const moduleKey of definition.modules) {
      const permission = permissionMap.get(moduleKey); if (!permission) continue;
      await RolePermission.findOneAndUpdate({ roleId: role._id, permissionId: permission._id }, { $setOnInsert: { roleId: role._id, permissionId: permission._id, active: true, actions: actionsForRole(role.key, moduleKey) } }, { upsert: true, new: true, setDefaultsOnInsert: true });
    }
    if (role.key === 'superadmin') {
      for (const permission of permissionMap.values()) await RolePermission.findOneAndUpdate({ roleId: role._id, permissionId: permission._id }, { $set: { active: true, actions: actionsForRole('superadmin', permission.key) }, $setOnInsert: { roleId: role._id, permissionId: permission._id } }, { upsert: true, new: true, setDefaultsOnInsert: true });
    }
  }
  return roleMap;
}
async function seedMasterData() {
  for (const item of STATIONS) await Station.updateOne({ code: item.code }, { $setOnInsert: { ...item, status: 'Active', operatorIds: [] } }, { upsert: true });
  const categories = new Map();
  for (const item of CATEGORIES) {
    const row = await DefectCategory.findOneAndUpdate({ code: item.code }, { $setOnInsert: { ...item, status: 'Active' } }, { upsert: true, new: true, setDefaultsOnInsert: true });
    categories.set(item.code, row);
  }
  for (const item of DEFECTS) {
    const category = categories.get(item.categoryCode);
    await Defect.updateOne({ code: item.code }, { $setOnInsert: { code: item.code, name: item.name, categoryId: String(category._id), categoryName: category.name, severity: item.severity, reworkMinutes: item.reworkMinutes, description: item.description, status: 'Active' } }, { upsert: true });
  }
  for (const item of OPERATORS) await Operator.updateOne({ employeeCode: item.employeeCode }, { $setOnInsert: { ...item, status: 'Active', stationIds: [] } }, { upsert: true });
}

async function seedQAChecklist() {
  for (const item of QA_CHECKLIST) await QAChecklistItem.updateOne({ code: item.code }, { $setOnInsert: item }, { upsert: true });
}

async function seedBootstrapAdmin(roleMap) {
  const { adminEmail, adminPassword, adminName, employeeId } = env.bootstrap;
  if (!adminEmail && !adminPassword) {
    logger.warn('Super Admin role is seeded, but no login user was created. Set BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD to create the initial account.');
    return;
  }
  if (!adminEmail || !adminPassword || adminPassword.length < 12) throw new Error('Set both BOOTSTRAP_ADMIN_EMAIL and a BOOTSTRAP_ADMIN_PASSWORD with at least 12 characters.')
  const role = roleMap.get('superadmin');
  const passwordHash = await bcrypt.hash(adminPassword, 12);
  await User.findOneAndUpdate({ email: adminEmail.toLowerCase() }, { $setOnInsert: { name: adminName, email: adminEmail.toLowerCase(), employeeId, passwordHash, roleId: role._id, roleKey: role.key, status: 'active', mustChangePassword: false } }, { upsert: true, new: true, setDefaultsOnInsert: true });
  logger.info({ email: adminEmail.toLowerCase() }, 'Bootstrap Super Admin account ensured');
}

export async function runSeed() {
  const permissionMap = await seedPermissions();
  const roleMap = await seedRoles(permissionMap);
  await seedMasterData();
  await seedQAChecklist();
  await seedBootstrapAdmin(roleMap);
  logger.info({ roles: roleMap.size, permissions: permissionMap.size }, 'Idempotent application seed completed');
}

const direct = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (direct) {
  try { await connectDatabase(); await runSeed(); }
  catch (error) { logger.error({ err: error }, 'Seeding failed'); process.exitCode = 1; }
  finally { await disconnectDatabase(); }
}
