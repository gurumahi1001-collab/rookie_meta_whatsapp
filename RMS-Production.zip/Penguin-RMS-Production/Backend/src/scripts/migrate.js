import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { connectDatabase, disconnectDatabase } from '../config/database.js';
import Migration from '../models/Migration.js';
import User from '../models/User.js';
import Role from '../models/Role.js';
import Permission from '../models/Permission.js';
import RolePermission from '../models/RolePermission.js';
import RefreshSession from '../models/RefreshSession.js';
import PurchaseOrder from '../models/PurchaseOrder.js';
import Station from '../models/Station.js';
import Operator from '../models/Operator.js';
import DefectCategory from '../models/DefectCategory.js';
import Defect from '../models/Defect.js';
import WorkOrder from '../models/WorkOrder.js';
import QAInspection from '../models/QAInspection.js';
import Carton from '../models/Carton.js';
import Setting from '../models/Setting.js';
import AuditLog from '../models/AuditLog.js';
import Notification from '../models/Notification.js';
import QAChecklistItem from '../models/QAChecklistItem.js';
import logger from '../utils/logger.js';

const migrations = [
  {
    key: '001_core_collections_and_indexes',
    description: 'Create application collections and enforce production indexes.',
    run: async () => {
      const models = [User, Role, Permission, RolePermission, RefreshSession, PurchaseOrder, Station, Operator, DefectCategory, Defect, WorkOrder, QAInspection, Carton, Setting, AuditLog, Notification];
      for (const Model of models) await Model.createIndexes();
    }
  },
  {
    key: '002_qa_checklist_collection_and_indexes',
    description: 'Create indexes for shared QA inspection checklist records.',
    run: async () => { await QAChecklistItem.createIndexes(); }
  }
];

export async function runMigrations() {
  for (const migration of migrations) {
    const exists = await Migration.exists({ key: migration.key });
    if (exists) continue;
    logger.info({ migration: migration.key }, 'Applying migration');
    await migration.run();
    await Migration.create({ key: migration.key, description: migration.description, appliedAt: new Date() });
    logger.info({ migration: migration.key }, 'Migration applied');
  }
  return migrations.length;
}

const direct = process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;
if (direct) {
  try { await connectDatabase(); await runMigrations(); logger.info('Migrations completed'); }
  catch (error) { logger.error({ err: error }, 'Migration failed'); process.exitCode = 1; }
  finally { await disconnectDatabase(); }
}
