let io;
export function setSocketServer(server) { io = server; }
export function getSocketServer() { return io; }
export function emitResourceChange({ resource, module, action, entityId = null, actorId = null, summary = '' }) {
  if (!io) return;
  const payload = { resource, module, action, entityId: entityId ? String(entityId) : null, actorId: actorId ? String(actorId) : null, summary, occurredAt: new Date().toISOString() };
  io.to(`module:${module}:view`).emit('resource:changed', payload);
  io.to('module:reports:view').emit('resource:changed', payload);
  if (['work-orders', 'inspections', 'packing-garments', 'cartons'].includes(resource)) {
    io.to('module:purchase-orders:view').emit('resource:changed', { ...payload, resource: 'purchase-orders', module: 'purchase-orders' });
  }
  io.to('dashboard:view').emit('dashboard:refresh', { module, action, occurredAt: payload.occurredAt });
}
export function emitToUser(userId, event, payload) { if (io && userId) io.to(`user:${String(userId)}`).emit(event, payload); }
