import PurchaseOrder from '../../models/PurchaseOrder.js';
import Station from '../../models/Station.js';
import Operator from '../../models/Operator.js';
import DefectCategory from '../../models/DefectCategory.js';
import Defect from '../../models/Defect.js';
import WorkOrder from '../../models/WorkOrder.js';
import Carton from '../../models/Carton.js';
import QAInspection from '../../models/QAInspection.js';

export const RESOURCES = Object.freeze({
  'purchase-orders': { model: PurchaseOrder, module: 'purchase-orders', search: ['poNumber', 'supplier', 'style', 'articleSku', 'batch'], sort: { createdAt: -1 } },
  stations: { model: Station, module: 'master-data', search: ['code', 'name', 'type', 'location', 'factory'], sort: { code: 1 } },
  operators: { model: Operator, module: 'station-management', search: ['name', 'employeeCode', 'role', 'phone'], sort: { name: 1 } },
  categories: { model: DefectCategory, module: 'master-data', search: ['code', 'name', 'description'], sort: { code: 1 } },
  defects: { model: Defect, module: 'master-data', search: ['code', 'name', 'categoryName', 'description'], sort: { code: 1 } },
  'work-orders': { model: WorkOrder, module: 'station-management', search: ['reworkId', 'qrId', 'poNumber', 'garmentId', 'styleNumber', 'defectCategory', 'operator', 'assignedStation'], sort: { registeredAt: -1 } },
  cartons: { model: Carton, module: 'packing', search: ['cartonId', 'poNumber', 'packedBy'], sort: { createdAt: -1 } },
  inspections: { model: QAInspection, module: 'qa-inspection', search: ['qrId', 'poNumber', 'reworkId', 'inspectorName'], sort: { inspectedAt: -1 } }
});
