import AuditLog from '../../models/AuditLog.js';
export async function writeAudit(req, { action, module, title, description = '', entityType = '', entityId = '', entityName = '', metadata = {} }) {
  const actor = req?.user;
  return AuditLog.create({ action, module, title: title || action, description, actorUserId: actor?.id || actor?._id || null, actorName: actor?.name || 'System', actorEmail: actor?.email || '', entityType, entityId: String(entityId || ''), entityName, requestId: req?.requestId || '', ipAddress: req?.ip || '', userAgent: req?.get?.('user-agent') || '', metadata });
}
