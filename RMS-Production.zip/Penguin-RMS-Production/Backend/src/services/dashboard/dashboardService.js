import PurchaseOrder from '../../models/PurchaseOrder.js';
import WorkOrder from '../../models/WorkOrder.js';
import Station from '../../models/Station.js';
import Carton from '../../models/Carton.js';
import QAInspection from '../../models/QAInspection.js';
import AuditLog from '../../models/AuditLog.js';
export async function getDashboardSummary() {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const [purchaseOrders, workOrderStatus, activeStations, openCartons, inspectionsToday, recentActivity, totalWorkOrders] = await Promise.all([
    PurchaseOrder.countDocuments({ status: 'Active' }), WorkOrder.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    Station.countDocuments({ status: 'Active' }), Carton.countDocuments({ status: 'Open' }), QAInspection.countDocuments({ inspectedAt: { $gte: today } }),
    AuditLog.find().sort({ createdAt: -1 }).limit(10).select('action module title description actorName entityName createdAt'), WorkOrder.countDocuments()
  ]);
  const statuses = Object.fromEntries(workOrderStatus.map((row) => [row._id, row.count]));
  return {
    kpis: { activePurchaseOrders: purchaseOrders, totalWorkOrders, assigned: statuses.Assigned || 0, inProgress: statuses['In Progress'] || 0, awaitingQA: statuses['Sent to QA'] || 0, qaPassed: statuses['QA Passed'] || 0, qaRejected: statuses['QA Rejected'] || 0, packed: statuses.Packed || 0, scrap: statuses.Scrap || 0, activeStations, openCartons, inspectionsToday },
    workflow: ['Assigned', 'In Progress', 'Sent to QA', 'QA Passed', 'Packed', 'Scrap'].map((status) => ({ status, count: statuses[status] || 0 })),
    recentActivity: recentActivity.map((event) => event.toJSON())
  };
}
