import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import env from '../../config/env.js';
import User from '../../models/User.js';
import Role from '../../models/Role.js';
import RolePermission from '../../models/RolePermission.js';
import RefreshSession from '../../models/RefreshSession.js';
import AppError from '../../utils/AppError.js';
import { writeAudit } from '../audit/auditService.js';

const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const safeUser = (user, role) => ({ id: String(user._id), name: user.name, email: user.email, employeeId: user.employeeId, phone: user.phone, department: user.department, jobTitle: user.jobTitle, avatarUrl: user.avatarUrl, role: role?.name || 'Unknown', roleKey: role?.key || user.roleKey, stationId: user.stationId, status: user.status, mustChangePassword: user.mustChangePassword, lastLoginAt: user.lastLoginAt });
async function permissionsForRole(roleId) {
  const assignments = await RolePermission.find({ roleId, active: true }).populate('permissionId').lean();
  return assignments.filter((x) => x.permissionId?.active).map((x) => ({ module: x.permissionId.key, name: x.permissionId.name, actions: x.actions }));
}
const signAccess = (user, sid) => jwt.sign({ sub: String(user._id), sid: String(sid), type: 'access' }, env.jwt.accessSecret, { expiresIn: env.jwt.accessTtl, issuer: 'penguin-rms', audience: 'penguin-rms-web' });
const signRefresh = (user, sid) => jwt.sign({ sub: String(user._id), sid: String(sid), type: 'refresh' }, env.jwt.refreshSecret, { expiresIn: `${env.jwt.refreshTtlDays}d`, issuer: 'penguin-rms', audience: 'penguin-rms-web' });

export async function login({ identifier, password }, req) {
  const normalizedIdentifier = String(identifier).trim();
  const user = await User.findOne({ $or: [{ email: normalizedIdentifier.toLowerCase() }, { employeeId: normalizedIdentifier }] }).select('+passwordHash');
  if (!user) throw new AppError('Invalid username/email or password.', 401, 'INVALID_CREDENTIALS');
  if (user.status !== 'active') throw new AppError('This user account is inactive. Contact an administrator.', 403, 'ACCOUNT_INACTIVE');
  if (user.lockUntil && user.lockUntil > new Date()) throw new AppError('Account is temporarily locked. Try again later.', 423, 'ACCOUNT_LOCKED');
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) { user.failedLoginAttempts += 1; if (user.failedLoginAttempts >= 8) user.lockUntil = new Date(Date.now() + 900000); await user.save(); throw new AppError('Invalid username/email or password.', 401, 'INVALID_CREDENTIALS'); }
  user.failedLoginAttempts = 0; user.lockUntil = null; user.lastLoginAt = new Date(); await user.save();
  const role = await Role.findById(user.roleId);
  if (!role?.active) throw new AppError('The assigned role is disabled.', 403, 'ROLE_INACTIVE');
  const sid = crypto.randomUUID(); const refreshToken = signRefresh(user, sid);
  await RefreshSession.create({ userId: user._id, sessionId: sid, tokenHash: sha256(refreshToken), expiresAt: new Date(Date.now() + env.jwt.refreshTtlDays * 86400000), ipAddress: req.ip, userAgent: req.get('user-agent') || '' });
  await writeAudit(req, { action: 'auth.login', module: 'authentication', title: 'User signed in', description: `${user.email} signed in`, entityType: 'user', entityId: user._id, entityName: user.name });
  return { accessToken: signAccess(user, sid), refreshToken, user: safeUser(user, role), permissions: await permissionsForRole(role._id) };
}

export async function refresh(refreshToken, req) {
  if (!refreshToken) throw new AppError('Refresh session is missing.', 401, 'REFRESH_TOKEN_MISSING');
  let payload;
  try { payload = jwt.verify(refreshToken, env.jwt.refreshSecret, { issuer: 'penguin-rms', audience: 'penguin-rms-web' }); } catch { throw new AppError('Refresh session is invalid or expired.', 401, 'REFRESH_TOKEN_INVALID'); }
  if (payload.type !== 'refresh') throw new AppError('Invalid token type.', 401, 'REFRESH_TOKEN_INVALID');
  const session = await RefreshSession.findOne({ userId: payload.sub, sessionId: payload.sid, revokedAt: null, expiresAt: { $gt: new Date() } }).select('+tokenHash');
  if (!session || session.tokenHash !== sha256(refreshToken)) { if (session) { session.revokedAt = new Date(); await session.save(); } throw new AppError('Refresh session has already been used or revoked.', 401, 'REFRESH_TOKEN_REUSED'); }
  const user = await User.findById(payload.sub);
  if (!user || user.status !== 'active') throw new AppError('User account is not active.', 401, 'ACCOUNT_INACTIVE');
  session.revokedAt = new Date(); await session.save();
  const sid = crypto.randomUUID(); const nextRefresh = signRefresh(user, sid);
  await RefreshSession.create({ userId: user._id, sessionId: sid, tokenHash: sha256(nextRefresh), expiresAt: new Date(Date.now() + env.jwt.refreshTtlDays * 86400000), ipAddress: req.ip, userAgent: req.get('user-agent') || '' });
  const role = await Role.findById(user.roleId);
  return { accessToken: signAccess(user, sid), refreshToken: nextRefresh, user: safeUser(user, role), permissions: await permissionsForRole(role._id) };
}

export async function logout(refreshToken, userId) {
  if (refreshToken) { try { const payload = jwt.verify(refreshToken, env.jwt.refreshSecret, { issuer: 'penguin-rms', audience: 'penguin-rms-web' }); await RefreshSession.updateOne({ sessionId: payload.sid, userId: payload.sub, revokedAt: null }, { $set: { revokedAt: new Date() } }); } catch { /* clear cookies even when expired */ } }
  if (userId) await RefreshSession.updateMany({ userId, revokedAt: null }, { $set: { revokedAt: new Date() } });
}
export async function getProfile(userId) {
  const user = await User.findById(userId); if (!user) throw new AppError('User not found.', 404, 'USER_NOT_FOUND');
  const role = await Role.findById(user.roleId); return { user: safeUser(user, role), permissions: await permissionsForRole(role._id) };
}
export async function changePassword(userId, { currentPassword, newPassword }) {
  const user = await User.findById(userId).select('+passwordHash');
  if (!user || !(await bcrypt.compare(currentPassword, user.passwordHash))) throw new AppError('Current password is incorrect.', 400, 'CURRENT_PASSWORD_INVALID');
  if (String(newPassword).length < 12) throw new AppError('New password must be at least 12 characters.', 400, 'WEAK_PASSWORD');
  user.passwordHash = await bcrypt.hash(newPassword, 12); user.passwordChangedAt = new Date(); user.mustChangePassword = false; await user.save();
  await RefreshSession.updateMany({ userId, revokedAt: null }, { $set: { revokedAt: new Date() } });
}
export async function getUserSafeById(userId) { const user = await User.findById(userId); if (!user) return null; return safeUser(user, await Role.findById(user.roleId)); }
