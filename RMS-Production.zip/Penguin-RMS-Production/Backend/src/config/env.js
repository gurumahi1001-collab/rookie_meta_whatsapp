import 'dotenv/config';
import { z } from 'zod';

const bool = (fallback) => z.preprocess((value) => {
  if (value === undefined || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}, z.boolean());

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
  APP_NAME: z.string().default('Penguin Apparel RMS'),
  PORT: z.coerce.number().int().min(1).max(65535).default(4000),
  API_PREFIX: z.string().default('/api/v1'),
  FRONTEND_ORIGINS: z.string().default('http://localhost:5173'),
  MONGODB_URI: z.string().min(1).default('mongodb://127.0.0.1:27017/penguin_rms'),
  MONGODB_DB_NAME: z.string().default('penguin_rms'),
  MONGODB_MIN_POOL_SIZE: z.coerce.number().int().min(0).default(2),
  MONGODB_MAX_POOL_SIZE: z.coerce.number().int().min(1).default(20),
  JWT_ACCESS_SECRET: z.string().min(32).default('development-access-secret-change-before-deploy-0001'),
  JWT_REFRESH_SECRET: z.string().min(32).default('development-refresh-secret-change-before-deploy-0002'),
  JWT_ACCESS_TTL: z.string().default('15m'),
  JWT_REFRESH_TTL_DAYS: z.coerce.number().int().min(1).max(365).default(30),
  COOKIE_SECURE: bool(false),
  COOKIE_SAME_SITE: z.enum(['strict', 'lax', 'none']).default('lax'),
  AUTO_MIGRATE: bool(true),
  AUTO_SEED: bool(false),
  BOOTSTRAP_ADMIN_NAME: z.string().default('Super Admin'),
  BOOTSTRAP_ADMIN_EMAIL: z.string().email().optional().or(z.literal('')),
  BOOTSTRAP_ADMIN_PASSWORD: z.string().optional().default(''),
  BOOTSTRAP_ADMIN_EMPLOYEE_ID: z.string().default('PENG-ADM-001'),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(900000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(300),
  AUTH_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(10),
  MAX_BODY_SIZE: z.string().default('2mb'),
  UPLOAD_MAX_FILE_SIZE_MB: z.coerce.number().int().positive().default(10),
  UPLOAD_DIR: z.string().default('storage/uploads'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info')
}).superRefine((value, ctx) => {
  if (value.NODE_ENV === 'production') {
    if (value.JWT_ACCESS_SECRET.startsWith('development-') || value.JWT_REFRESH_SECRET.startsWith('development-')) {
      ctx.addIssue({ code: 'custom', path: ['JWT_ACCESS_SECRET'], message: 'Production JWT secrets must be replaced.' });
    }
    if (value.COOKIE_SAME_SITE === 'none' && !value.COOKIE_SECURE) {
      ctx.addIssue({ code: 'custom', path: ['COOKIE_SECURE'], message: 'SameSite=None cookies require COOKIE_SECURE=true.' });
    }
    if (!value.BOOTSTRAP_ADMIN_EMAIL || value.BOOTSTRAP_ADMIN_PASSWORD.length < 12) {
      // The user can create the first administrator from a controlled provisioning script.
      // No default production credentials are ever installed.
    }
  }
  if (value.MONGODB_MAX_POOL_SIZE < value.MONGODB_MIN_POOL_SIZE) {
    ctx.addIssue({ code: 'custom', path: ['MONGODB_MAX_POOL_SIZE'], message: 'MongoDB max pool size must be >= min pool size.' });
  }
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('[CONFIG] Invalid environment configuration:', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

const raw = parsed.data;
export default Object.freeze({
  app: { name: raw.APP_NAME, environment: raw.NODE_ENV, port: raw.PORT, isProduction: raw.NODE_ENV === 'production', isStaging: raw.NODE_ENV === 'staging' },
  api: { prefix: raw.API_PREFIX },
  cors: { origins: raw.FRONTEND_ORIGINS.split(',').map((x) => x.trim()).filter(Boolean) },
  database: { uri: raw.MONGODB_URI, name: raw.MONGODB_DB_NAME, minPoolSize: raw.MONGODB_MIN_POOL_SIZE, maxPoolSize: raw.MONGODB_MAX_POOL_SIZE },
  jwt: { accessSecret: raw.JWT_ACCESS_SECRET, refreshSecret: raw.JWT_REFRESH_SECRET, accessTtl: raw.JWT_ACCESS_TTL, refreshTtlDays: raw.JWT_REFRESH_TTL_DAYS },
  cookies: { secure: raw.COOKIE_SECURE || raw.NODE_ENV === 'production', sameSite: raw.COOKIE_SAME_SITE },
  bootstrap: { adminName: raw.BOOTSTRAP_ADMIN_NAME, adminEmail: raw.BOOTSTRAP_ADMIN_EMAIL || '', adminPassword: raw.BOOTSTRAP_ADMIN_PASSWORD, employeeId: raw.BOOTSTRAP_ADMIN_EMPLOYEE_ID },
  migrations: { auto: raw.AUTO_MIGRATE },
  seeding: { auto: raw.AUTO_SEED },
  rateLimit: { windowMs: raw.RATE_LIMIT_WINDOW_MS, max: raw.RATE_LIMIT_MAX, authMax: raw.AUTH_RATE_LIMIT_MAX },
  uploads: { maxBodySize: raw.MAX_BODY_SIZE, maxFileSizeBytes: raw.UPLOAD_MAX_FILE_SIZE_MB * 1024 * 1024, directory: raw.UPLOAD_DIR },
  logging: { level: raw.LOG_LEVEL }
});
