import mongoose from 'mongoose';
import env from './env.js';
import logger from '../utils/logger.js';

let connecting;
mongoose.set('strictQuery', true);
mongoose.connection.on('connected', () => logger.info({ database: mongoose.connection.name }, 'MongoDB connected'));
mongoose.connection.on('disconnected', () => logger.warn('MongoDB disconnected'));
mongoose.connection.on('error', (error) => logger.error({ err: error }, 'MongoDB connection error'));

export function getConnectionState() {
  return ['disconnected', 'connected', 'connecting', 'disconnecting'][mongoose.connection.readyState] ?? 'unknown';
}
export function isDatabaseConnected() { return mongoose.connection.readyState === 1; }
export async function connectDatabase() {
  if (isDatabaseConnected()) return mongoose.connection;
  if (connecting) return connecting;
  connecting = mongoose.connect(env.database.uri, {
    appName: env.app.name, dbName: env.database.name,
    minPoolSize: env.database.minPoolSize, maxPoolSize: env.database.maxPoolSize,
    serverSelectionTimeoutMS: 10000, socketTimeoutMS: 45000, maxIdleTimeMS: 60000,
    retryWrites: true, bufferCommands: false, autoIndex: !env.app.isProduction
  }).then(() => mongoose.connection).finally(() => { connecting = null; });
  return connecting;
}
export async function disconnectDatabase() { if (mongoose.connection.readyState !== 0) await mongoose.disconnect(); }
export default { connectDatabase, disconnectDatabase, getConnectionState, isDatabaseConnected };
