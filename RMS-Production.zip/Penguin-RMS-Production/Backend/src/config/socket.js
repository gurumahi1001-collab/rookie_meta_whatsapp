import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import env from './env.js';
import User from '../models/User.js';
import Role from '../models/Role.js';
import RolePermission from '../models/RolePermission.js';
import Permission from '../models/Permission.js';
import RefreshSession from '../models/RefreshSession.js';
import logger from '../utils/logger.js';
import { setSocketServer } from '../services/realtime/realtimeService.js';

export function configureSocket(httpServer) {
  const io = new Server(httpServer, {
    cors: { origin: env.cors.origins, credentials: true, methods: ['GET', 'POST'] },
    transports: ['websocket', 'polling'],
    pingInterval: 25000,
    pingTimeout: 20000,
    maxHttpBufferSize: 1e6
  });
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Authentication required'));
      const payload = jwt.verify(token, env.jwt.accessSecret, { issuer: 'penguin-rms', audience: 'penguin-rms-web' });
      if (payload.type !== 'access' || !payload.sid) return next(new Error('Invalid token type'));
      const session = await RefreshSession.findOne({ sessionId: payload.sid, userId: payload.sub, revokedAt: null, expiresAt: { $gt: new Date() } }).select('_id');
      if (!session) return next(new Error('Session revoked or expired'));
      const user = await User.findById(payload.sub);
      if (!user || user.status !== 'active') return next(new Error('Account unavailable'));
      const role = await Role.findById(user.roleId);
      if (!role?.active) return next(new Error('Role unavailable'));
      socket.data.user = { id: String(user._id), roleId: String(role._id), roleKey: role.key };
      next();
    } catch (error) { next(new Error(error.name === 'TokenExpiredError' ? 'Access token expired' : 'Unauthorized')); }
  });
  io.on('connection', async (socket) => {
    const { id, roleId, roleKey } = socket.data.user;
    socket.join(`user:${id}`);
    socket.join('authenticated');
    if (roleKey === 'superadmin') {
      for (const permission of await Permission.find({ active: true }).select('key').lean()) socket.join(`module:${permission.key}:view`);
      socket.join('dashboard:view');
    } else {
      const assignments = await RolePermission.find({ roleId, active: true }).populate('permissionId').lean();
      for (const item of assignments) if (item.actions?.view || item.actions?.manage) socket.join(`module:${item.permissionId.key}:view`);
      if (assignments.some((item) => item.permissionId?.key === 'dashboard' && (item.actions?.view || item.actions?.manage))) socket.join('dashboard:view');
    }
    logger.debug({ socketId: socket.id, userId: id }, 'Realtime client connected');
    socket.on('client:ping', (callback) => { if (typeof callback === 'function') callback({ ok: true, at: new Date().toISOString() }); });
    socket.on('disconnect', (reason) => logger.debug({ socketId: socket.id, reason }, 'Realtime client disconnected'));
  });
  setSocketServer(io);
  return io;
}
