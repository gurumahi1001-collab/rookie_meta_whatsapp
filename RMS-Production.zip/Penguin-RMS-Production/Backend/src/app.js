import express from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import morgan from 'morgan';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import env from './config/env.js';
import apiRoutes from './routes/index.js';
import requestId from './middleware/requestId.js';
import { errorHandler, notFound } from './middleware/errorHandler.js';
import { isDatabaseConnected, getConnectionState } from './config/database.js';

const app = express();
const filename = fileURLToPath(import.meta.url);
const dirname = path.dirname(filename);
if (env.app.isProduction || env.app.isStaging) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.set('case sensitive routing', true);
app.use(requestId);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' }, hsts: env.app.isProduction ? { maxAge: 31536000, includeSubDomains: true } : false, contentSecurityPolicy: false }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || env.cors.origins.includes(origin)) return callback(null, true);
    return callback(new Error('CORS policy: origin is not allowed.'));
  }, credentials: true, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Accept', 'Authorization', 'Content-Type', 'X-Requested-With', 'X-Request-ID'],
  exposedHeaders: ['X-Request-ID', 'Content-Disposition'], maxAge: 86400
}));
app.use(compression({ threshold: 1024 }));
app.use(morgan(env.app.isProduction ? 'combined' : 'dev', { skip: (req) => req.path === '/health/live' || req.path === '/health/ready' }));
app.use(cookieParser());
app.use(express.json({ limit: env.uploads.maxBodySize, strict: true }));
app.use(express.urlencoded({ extended: false, limit: env.uploads.maxBodySize, parameterLimit: 1000 }));
app.use('/uploads', express.static(path.resolve(process.cwd(), env.uploads.directory), { dotfiles: 'deny', fallthrough: false, maxAge: '1d', immutable: true }));
app.get('/health/live', (_req, res) => res.status(200).json({ status: 'alive' }));
app.get('/health/ready', (_req, res) => {
  const ready = isDatabaseConnected();
  res.status(ready ? 200 : 503).json({ status: ready ? 'ready' : 'not-ready', database: getConnectionState() });
});
app.use(env.api.prefix, rateLimit({ windowMs: env.rateLimit.windowMs, limit: env.rateLimit.max, standardHeaders: 'draft-8', legacyHeaders: false, skip: (req) => req.path === '/health' }));
app.use(env.api.prefix, apiRoutes);
app.use(notFound);
app.use(errorHandler);
export default app;
