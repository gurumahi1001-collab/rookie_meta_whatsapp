import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import env from '../config/env.js';
import { authenticate } from '../middleware/auth.js';
import { requirePermission, requireAnyPermission } from '../middleware/rbac.js';
import AppError from '../utils/AppError.js';
import { resourceController } from '../controllers/resources/resourceController.js';
import * as authController from '../controllers/auth/authController.js';
import * as userRoleController from '../controllers/admin/userRoleController.js';
import * as settingsController from '../controllers/admin/settingsController.js';
import * as notificationController from '../controllers/admin/notificationController.js';
import * as dashboardController from '../controllers/dashboard/dashboardController.js';
import * as qaController from '../controllers/workflow/qaController.js';
import * as qaChecklistController from '../controllers/workflow/qaChecklistController.js';
import * as packingController from '../controllers/workflow/packingController.js';
import * as workOrderController from '../controllers/workflow/workOrderController.js';
import * as reportsController from '../controllers/workflow/reportsController.js';
import * as qrOptionsController from '../controllers/workflow/qrOptionsController.js';
import * as qaOptionsController from '../controllers/workflow/qaOptionsController.js';
import AuditLog from '../models/AuditLog.js';
import upload from '../middleware/upload.js';
import { uploadImage } from '../controllers/uploadController.js';

const router = Router();
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: env.rateLimit.authMax, standardHeaders: 'draft-8', legacyHeaders: false, message: { success: false, error: { code: 'AUTH_RATE_LIMIT', message: 'Too many sign-in attempts. Try again later.' } } });

router.get('/health', (_req, res) => res.json({ success: true, data: { status: 'ok', service: env.app.name, time: new Date().toISOString() } }));
router.post('/auth/login', authLimiter, authController.login);
router.post('/auth/refresh', authLimiter, authController.refresh);
router.post('/auth/logout', authenticate, authController.logout);
router.get('/auth/me', authenticate, authController.me);
router.patch('/auth/password', authenticate, authController.changePassword);

router.use(authenticate);
router.get('/dashboard/summary', requirePermission('dashboard', 'view'), dashboardController.summary);
router.post('/uploads', requirePermission('qr-rework', 'create'), upload.single('file'), uploadImage);
router.post('/uploads/qa', requirePermission('qa-inspection', 'approve'), upload.single('file'), uploadImage);
router.post('/uploads/avatar', requireAnyPermission('user-management', ['create', 'update']), upload.single('file'), uploadImage);
router.get('/qr-rework/options', requirePermission('qr-rework', 'view'), qrOptionsController.listOptions);
router.post('/qr-rework/stations', requirePermission('qr-rework', 'create'), qrOptionsController.createRegistrationStation);
router.get('/reports/summary', requirePermission('reports', 'view'), reportsController.summary);
router.get('/reports/dataset', requirePermission('reports', 'view'), reportsController.dataset);
router.get('/reports/audit-activity', requirePermission('reports', 'view'), async (req, res) => {
  const items = await AuditLog.find().sort({ createdAt: -1 }).limit(Math.min(500, Number(req.query.limit) || 100));
  res.json({ success: true, data: items.map((x) => x.toJSON()) });
});

function mountResource(path, key, module, options = {}) {
  const controller = resourceController(key);
  const target = Router();
  const viewModule = options.viewModule || module;
  const createModule = options.createModule || module;
  const updateModule = options.updateModule || module;
  target.get('/', requirePermission(viewModule, 'view'), controller.list);
  target.get('/:id', requirePermission(viewModule, 'view'), controller.getOne);
  target.post('/', requirePermission(createModule, 'create'), controller.create);
  if (options.customUpdate) target.patch('/:id', requirePermission(updateModule, 'update'), options.customUpdate);
  else target.patch('/:id', requirePermission(updateModule, 'update'), controller.update);
  target.delete('/:id', requirePermission(module, 'delete'), controller.remove);
  router.use(path, target);
}

mountResource('/purchase-orders', 'purchase-orders', 'purchase-orders');
mountResource('/stations', 'stations', 'station-management', { viewModule: 'station-management', createModule: 'station-management', updateModule: 'station-management' });
mountResource('/operators', 'operators', 'station-management');
mountResource('/master-data/operators', 'operators', 'master-data');
mountResource('/master-data/stations', 'stations', 'master-data');
mountResource('/master-data/categories', 'categories', 'master-data');
mountResource('/master-data/defects', 'defects', 'master-data');
mountResource('/categories', 'categories', 'master-data');
mountResource('/defects', 'defects', 'master-data');
mountResource('/work-orders', 'work-orders', 'qr-rework', { viewModule: 'qr-rework', createModule: 'qr-rework', updateModule: 'station-management', customUpdate: workOrderController.updateWorkOrder });
mountResource('/cartons', 'cartons', 'packing');
mountResource('/inspections', 'inspections', 'qa-inspection');

router.get('/qa/checklist', requirePermission('qa-inspection', 'view'), qaChecklistController.listChecklist);
router.post('/qa/checklist', requirePermission('qa-inspection', 'create'), qaChecklistController.createChecklistItem);
router.patch('/qa/checklist/:id', requirePermission('qa-inspection', 'update'), qaChecklistController.updateChecklistItem);
router.get('/qa/queue', requirePermission('qa-inspection', 'view'), qaController.listQueue);
router.get('/qa/options', requirePermission('qa-inspection', 'view'), qaOptionsController.options);
router.post('/qa/inspections', requirePermission('qa-inspection', 'approve'), qaController.submitInspection);
router.post('/qa/resubmit/:id', requirePermission('qa-inspection', 'approve'), qaController.resubmitForInspection);
router.get('/qa/trace/:code', requirePermission('qa-inspection', 'view'), qaController.garmentHistory);
router.get('/packing/garments', requirePermission('packing', 'view'), packingController.listPackableGarments);
router.get('/packing/cartons', requirePermission('packing', 'view'), packingController.listCartons);
router.post('/packing/cartons', requirePermission('packing', 'create'), packingController.createCarton);
router.post('/packing/cartons/:id/garments', requirePermission('packing', 'update'), packingController.addGarments);
router.patch('/packing/cartons/:id/close', requirePermission('packing', 'approve'), packingController.closeCarton);
router.patch('/packing/cartons/:id/dispatch', requirePermission('packing', 'approve'), packingController.dispatchCarton);
router.post('/packing/cartons/:id/remove-garment', requirePermission('packing', 'update'), packingController.removeGarment);

router.get('/users/options', requirePermission('user-management', 'view'), userRoleController.listUserOptions);
router.get('/users', requirePermission('user-management', 'view'), userRoleController.listUsers);
router.post('/users', requirePermission('user-management', 'create'), userRoleController.createUser);
router.patch('/users/:id', requirePermission('user-management', 'update'), userRoleController.updateUser);
router.delete('/users/:id', requirePermission('user-management', 'delete'), userRoleController.deleteUser);
router.get('/roles', requirePermission('user-management', 'view'), userRoleController.listRoles);
router.post('/roles', requirePermission('user-management', 'create'), userRoleController.createRole);
router.patch('/roles/:id', requirePermission('user-management', 'update'), userRoleController.updateRole);
router.delete('/roles/:id', requirePermission('user-management', 'delete'), userRoleController.deleteRole);
router.get('/permissions', requirePermission('user-management', 'view'), userRoleController.listPermissions);

router.get('/settings', requirePermission('settings', 'view'), settingsController.getSettings);
router.put('/settings', requirePermission('settings', 'update'), settingsController.updateSettings);
router.post('/settings/avatar', requirePermission('settings', 'update'), upload.single('file'), settingsController.updateProfileAvatar);
router.put('/settings/api', requirePermission('settings', 'manage'), settingsController.updateApiSettings);
router.get('/notifications', notificationController.list);
router.patch('/notifications/:id/read', notificationController.markRead);
router.patch('/notifications/read-all', notificationController.markAllRead);

router.use((_req, _res, next) => next(new AppError('API endpoint not found.', 404, 'API_NOT_FOUND')));
export default router;
