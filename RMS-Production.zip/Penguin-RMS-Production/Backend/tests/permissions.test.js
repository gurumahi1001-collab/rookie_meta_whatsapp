import test from 'node:test';
import assert from 'node:assert/strict';
import { ACTIONS, MODULES, ROLE_DEFINITIONS, DEFAULT_ACTIONS } from '../src/constants/permissions.js';

test('permission matrix contains the core actions', () => {
  assert.deepEqual(ACTIONS, ['view', 'create', 'update', 'delete', 'approve', 'export', 'manage']);
});

test('Super Admin is a seeded system role with access to every defined module', () => {
  const role = ROLE_DEFINITIONS.find((item) => item.key === 'superadmin');
  assert.ok(role);
  assert.equal(role.name, 'Super Admin');
  assert.equal(role.systemRole, true);
  assert.deepEqual(new Set(role.modules), new Set(MODULES.map((item) => item.key)));
});

test('default action matrix grants the defined administrator capabilities', () => {
  for (const action of ACTIONS) assert.equal(DEFAULT_ACTIONS[action], true);
});
