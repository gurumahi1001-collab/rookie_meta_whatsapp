import http from 'node:http';
import app from './src/app.js';
import env from './src/config/env.js';
import { connectDatabase, disconnectDatabase } from './src/config/database.js';
import { configureSocket } from './src/config/socket.js';
import { runMigrations } from './src/scripts/migrate.js';
import { runSeed } from './src/scripts/seedData.js';
import logger from './src/utils/logger.js';

const server = http.createServer(app);
configureSocket(server);
let shuttingDown = false;

async function start() {
  await connectDatabase();
  if (env.migrations.auto) await runMigrations();
  if (env.seeding.auto) await runSeed();
  server.listen(env.app.port, () => logger.info({ port: env.app.port, env: env.app.environment }, 'Penguin RMS API listening'));
}

async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'Graceful shutdown started');
  server.close(async (error) => {
    if (error) logger.error({ err: error }, 'HTTP server close failed');
    try { await disconnectDatabase(); process.exit(error ? 1 : 0); }
    catch (dbError) { logger.error({ err: dbError }, 'MongoDB shutdown failed'); process.exit(1); }
  });
  setTimeout(() => process.exit(1), 15000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (error) => { logger.fatal({ err: error }, 'Unhandled promise rejection'); shutdown('unhandledRejection'); });
process.on('uncaughtException', (error) => { logger.fatal({ err: error }, 'Uncaught exception'); shutdown('uncaughtException'); });

start().catch((error) => { logger.fatal({ err: error }, 'Application startup failed'); process.exit(1); });
