# Architecture and local setup

## 1. Architecture overview

The solution follows the layered style identified in the supplied old server copy:

- `config`: validated environment, MongoDB connection pool and Socket.IO server.
- `models`: Mongoose schemas, indexes and JSON transformations.
- `controllers`: transport-layer request validation and response composition.
- `services`: authentication/session lifecycle, audit writes, dashboard aggregates and realtime event emission.
- `middleware`: authentication, RBAC, upload validation, request correlation and centralized errors.
- `routes`: versioned API and permission gates.
- `scripts`: explicit MongoDB migration and seed entry points.

The old copy contains both PostgreSQL-oriented README/migration references and a Mongoose implementation. This integration follows the active Mongoose runtime and uses MongoDB collections and indexes. It does not copy old credentials or the old project's data.

### Request path

```text
React page
  └─ src/lib/api.ts (Bearer access token, refresh retry, JSON envelope)
       └─ Express /api/v1
            ├─ request ID + security/CORS/rate-limit middleware
            ├─ JWT + refresh-session verification
            ├─ role/module/action authorization
            ├─ controller → service/model
            ├─ MongoDB write/read
            ├─ AuditLog write for material changes
            └─ Socket.IO resource:changed / dashboard:refresh
                  └─ subscribed React pages refetch the affected dataset
```

### Backend entry points

| Path | Purpose |
|---|---|
| `Backend/server.js` | Connects MongoDB, optionally runs migrations/seeds, starts HTTP and Socket.IO, handles graceful shutdown. |
| `Backend/src/app.js` | Express middleware, health routes, static upload route, API mount and centralized errors. |
| `Backend/src/routes/index.js` | All `/api/v1` routes and permission requirements. |
| `Backend/src/config/env.js` | Validates environment variables with Zod. |
| `Backend/src/config/database.js` | Mongoose connection and pool settings. |
| `Backend/src/config/socket.js` | Authenticated Socket.IO setup and permission rooms. |

### Frontend integration points

| Path | Purpose |
|---|---|
| `Frontend/src/lib/api.ts` | Shared API client, access-token header, refresh-cookie rotation and retry. |
| `Frontend/src/lib/realtime.ts` | Socket.IO connection lifecycle. |
| `Frontend/src/hooks/useLiveResource.ts` | Fetch, bounded multi-page loading, CRUD helpers and socket-driven refetch. |
| `Frontend/src/utils/token.ts` | Remember-me/local or session token lifecycle. |
| `Frontend/.env.example` | API and Socket.IO endpoints. |

## 2. Environment setup

Copy `Backend/.env.example` to `Backend/.env` and set at minimum:

```dotenv
NODE_ENV=development
PORT=4000
API_PREFIX=/api/v1
FRONTEND_ORIGINS=http://localhost:5173
MONGODB_URI=mongodb://127.0.0.1:27017/penguin_rms
MONGODB_DB_NAME=penguin_rms
JWT_ACCESS_SECRET=<at-least-32-random-characters>
JWT_REFRESH_SECRET=<different-at-least-32-random-characters>
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
AUTO_MIGRATE=true
AUTO_SEED=false
BOOTSTRAP_ADMIN_NAME=Super Admin
BOOTSTRAP_ADMIN_EMAIL=admin@example.com
BOOTSTRAP_ADMIN_PASSWORD=<at-least-12-characters>
```

Use different random secrets in production. A typical generator is `openssl rand -base64 48`; do not commit `.env` files or share the secrets. `COOKIE_SECURE=false` is only suitable for local HTTP development. For production HTTPS use `COOKIE_SECURE=true`. For a cross-site frontend/API deployment, configure `COOKIE_SAME_SITE=none` together with `COOKIE_SECURE=true` and deploy both origins over HTTPS.

Copy `Frontend/.env.example` to `Frontend/.env`:

```dotenv
VITE_API_BASE_URL=http://localhost:4000/api/v1
VITE_API_ORIGIN=http://localhost:4000
VITE_SOCKET_URL=http://localhost:4000
```

`VITE_API_BASE_URL` includes the API prefix. Socket and API origin do not.

## 3. Install and run

Backend:

```bash
cd Backend
npm install
npm run db:check
npm run db:setup
npm run dev
```

Frontend, in a separate terminal:

```bash
cd Frontend
npm install
npm run dev
```

Use a compatible Node.js 20.19+ runtime; this is the version floor specified by `Backend/package.json`.

## 4. Migration and seed lifecycle

- `npm run db:migrate`: applies registered MongoDB index/collection migrations.
- `npm run db:seed`: upserts permissions, system roles, role-permission assignments and initial master data.
- `npm run db:setup`: executes migrations then seeds.
- `AUTO_MIGRATE=true`: runs migrations during server startup.
- `AUTO_SEED=true`: runs seed data during server startup. Leave this off in normal production deployments and run the release step explicitly.

Migrations are recorded in `system_migrations` using a unique key. Each new schema evolution must add a new migration object; do not edit an already-applied migration to perform a production data change.

The seed upserts the default roles, including `Super Admin`, and the permission catalog. It also inserts starter station, operator, defect-category and defect-code records only when their unique key/code does not already exist. Existing operator assignments and master-data edits are not overwritten by rerunning seeds.

The `Super Admin` role always gets all defined modules and actions. An initial login account is optional and controlled by the two bootstrap environment variables. Configure both before running `db:seed` to create the first user.

## 5. API response and error pattern

Successful API responses use:

```json
{"success":true,"data":{}}
```

Errors use the central error format with `success:false`, a stable error `code`, a safe `message`, and optional validation `details`. Include the returned `X-Request-ID` when reporting a backend issue.

## 6. Page data integration

| UI page | Persistent data / endpoint | Live update source |
|---|---|---|
| Dashboard | `/dashboard/summary` | `dashboard:refresh` |
| Purchase Orders | `/purchase-orders` | `purchase-orders` resource events, including derived counts after work-order/QA/packing changes |
| QR & Rework | `/qr-rework/options`, `/work-orders`, `/uploads` | `work-orders`, `stations` |
| Station Management | `/stations`, `/operators`, `/work-orders` | station/work-order resource events |
| QA Inspection | `/qa/checklist`, `/qa/queue`, `/qa/options`, `/inspections`, `/qa/inspections`, `/qa/resubmit/:id` | `qa-queue`, `inspections`, work-order events |
| Packing & Dispatch | `/packing/garments`, `/packing/cartons` and carton actions | `cartons`, `packing-garments`, work orders |
| Reports & Analytics | `/reports/dataset` | all permitted `resource:changed` events |
| Master Data | `/master-data/stations`, `/master-data/categories`, `/master-data/defects`, `/master-data/operators` | master-data resource events |
| Users & Roles | `/users`, `/roles`, `/permissions` | user/role resource events |
| Settings | `/settings`, `/settings/avatar`, `/settings/api`, `/auth/password` | settings resource events |
| Header notifications | `/notifications` | per-user notification events |

The existing UI's page layout, controls, table structure and chart components are retained. The dashboard placeholder was replaced with live KPI/workflow/recent-activity content because the original dashboard component was an `UnderDevelopment` placeholder.
