# Application workflow and business rules

This document describes the implemented server workflow based on the supplied React UI and screenshot reference. The browser is not the system of record: MongoDB is authoritative, and the UI reloads persisted data after a successful API operation or a socket event.

## 1. End-to-end workflow

```text
Purchase Order
    │
    ▼
QR / Garment Defect Registration
    │  Creates a WorkOrder in Assigned state
    ▼
Station Assignment and Repair
    │  Assigned → In Progress
    │  Repair details, remarks, materials and duration are recorded
    ▼
Submit to QA
    │  In Progress → Sent to QA
    ▼
QA Inspection
    ├── Pass   → QA Passed ──► Packing ──► Carton Close ──► Dispatch
    ├── Reject → QA Rejected ──► Corrective repair / resubmission
    └── Scrap  → Scrap (terminal)
```

## 2. Purchase order setup

Purchase orders are stored in `purchase_orders`. A PO can include multiple size/color item rows. `orderedQty` is calculated from those item quantities on create/update rather than relying solely on a UI-entered total.

The PO list endpoint returns pagination metadata and derives these garment metrics from `work_orders`:

- `totalReworks`: all registered rework records for the PO.
- `inProgress`: Assigned, In Progress, Sent to QA or QA Rejected.
- `completed`: QA Passed or Packed.
- `irreparable`: Scrap.

The counts are calculated when a PO page is fetched so they do not become stale when another module updates the garment.

## 3. QR defect registration

The registration form obtains its live choice lists from `GET /qr-rework/options`. The options endpoint provides active purchase orders, defect categories/codes, stations and operators for the form. The QR registration flow creates a `WorkOrder` with identifiers including `reworkId`, `qrId`, `garmentId` and `poNumber` plus the defect, severity, assignment and image metadata.

The uploaded defect image is sent as multipart form data to `POST /uploads`. The upload route is authenticated and requires `qr-rework:create`. The server returns a URL for the saved file; the URL is then persisted on the work order.

New records start in `Assigned`. The work-order history receives a `Defect Registered` entry. The server emits a resource event so open QR, station, reports and dashboard views can refresh.

## 4. Station repair lifecycle

Station and operator information comes from `/stations` and `/operators`; the master-data versions are available below `/master-data/*`. An operator/station assignment is stored as string references consistent with the supplied frontend's existing data contract.

Permitted work-order status transitions are enforced by the custom work-order update controller:

| Current state | Allowed next state |
|---|---|
| `Assigned` | `In Progress` |
| `In Progress` | `In Progress`, `Assigned`, `Sent to QA` |
| `QA Rejected` | `In Progress` |
| `Sent to QA` | No direct transition |
| `QA Passed` | No direct transition |
| `Packed` | No direct transition |
| `Scrap` | No direct transition |

The repair screen can update repair details, remarks, materials used, operator, station and duration. Moving to `In Progress` sets `startedAt` if it has not already been set. Moving to `Sent to QA` sets `submittedAt` and `completedAt` and appends a status-history entry. The work order then appears in the QA queue.

## 5. QA inspection

The QA queue is built from work orders in `Sent to QA`. `GET /qa/options` provides the current QA form choices, while `GET /qa/checklist` loads the shared inspection checklist. Checklist additions and active/inactive changes are persisted through `POST /qa/checklist` and `PATCH /qa/checklist/:id`; all QA clients receive a `qa-checklist` socket invalidation and reload the shared list. The initial eight checklist items are seeded idempotently. `GET /qa/trace/:code` returns the garment trace and all inspection records for a QR, garment or rework identifier.

`POST /qa/inspections` records a separate `QAInspection` document containing the decision, checklist responses, failed checklist entries, inspector identity and snapshot fields from the work order. Previous inspection documents are retained, providing a decision history.

Decision outcomes:

- **Pass**: work order becomes `QA Passed`; it becomes eligible for packing.
- **Reject**: work order becomes `QA Rejected`. A rejection reason or at least one failed checklist item is required. A return station can be supplied to direct corrective work.
- **Scrap**: work order becomes `Scrap`. Only `superadmin` and `production_manager` accounts are allowed to scrap garments, even if another role can submit QA decisions.

QA photo uploads use `POST /uploads/qa`. The route has its own QA permission gate. A rejected garment can be sent through the dedicated `POST /qa/resubmit/:id` action, which checks that the current state is `QA Rejected`, writes history/audit data and requeues the work order for another QA inspection.

## 6. Packing and dispatch

`GET /packing/garments` returns garments in `QA Passed` or `Packed` status, with optional `poNumber` filtering. A garment already assigned to a carton is excluded from the unassigned packable list by the server's packing logic. The frontend maps the `workOrderId` to the garment record while preserving the existing UI carton layout.

Packing actions:

1. `POST /packing/cartons` creates an Open carton.
2. `POST /packing/cartons/:id/garments` adds one or more eligible QA-passed garments.
3. `POST /packing/cartons/:id/remove-garment` removes a garment with a reason and records a removal log.
4. `PATCH /packing/cartons/:id/close` closes a non-empty carton and updates its dispatch readiness.
5. `PATCH /packing/cartons/:id/dispatch` marks a closed carton as dispatched.

Only QA-approved garments can be packed. Carton and work-order references are both updated so the garment is not added to a second carton. The server rechecks garment status/assignment on each pack action; frontend state is not trusted as the authority.

**Transaction note:** the controller validates and updates the involved documents, but the current version does not wrap every multi-document write in a MongoDB transaction. For strict atomicity under concurrent packers, deploy MongoDB as a replica set and add explicit transaction/session wrappers around the carton/work-order mutation operations before high-volume production use.

## 7. Reports, audit and dashboard

The dashboard summary is aggregated from live purchase orders, work-order states, stations, open cartons, today's inspections and recent audit rows. It is not generated from fixture data.

The reports page requests a date-scoped dataset from `/reports/dataset`; the server returns work orders, associated inspections, active stations/operators and audit activity for the chosen date range. Existing charts, filters, tables and layout remain in the React UI. The response is bounded (10,000 work orders and audit rows, 30,000 inspections) and should be redesigned around server-side aggregates/exports as data volume grows.

Material writes create `audit_logs` records with the actor, action, module, entity and request metadata. The audit activity endpoint is separately permission-gated by `reports:view`.

## 8. Users, roles and settings

The seed provides these system roles:

- Super Admin
- Production Manager
- Purchase Manager
- Rework Inspector
- Station Operator
- QA Inspector
- Packing Operator

The permission catalog contains modules for Dashboard, Purchase Orders, QR & Rework, Station Management, QA Inspection, Packing & Dispatch, Reports & Analytics, Master Data, Garment Registry, User & Roles and Settings. The available actions are `view`, `create`, `update`, `delete`, `approve`, `export` and `manage`.

The Super Admin **role** is seeded with every defined action for every module, and protected against deletion or permission reduction. A first Super Admin **user account** is created only when both bootstrap email and password are configured before running the seed. No production credential is hardcoded.

Settings store non-secret profile preferences, notification preferences and safe API-display metadata. Database URLs, JWT keys and other secrets must remain server-side environment variables; they are not written through the settings screen.

## 9. Concurrency and operational rules

- MongoDB unique indexes protect defined identifiers such as PO number, QR/rework IDs, station code, operator code, defect/category code and carton ID.
- The backend is the source of truth. A socket event tells clients that a module has changed; clients refetch records instead of trusting event payloads as a complete updated document.
- Work-order traceability is retained; generic deletion is blocked for QA Passed and Packed work orders.
- API routes require authentication and module/action permissions. UI visibility alone is not authorization.
- `notifications` and per-user socket delivery are present, but automatic notification fan-out rules for each workflow transition are not configured in this first integration. The UI notification inbox will show records created by an explicit notification producer; workflow events alone do not create inbox notifications.
