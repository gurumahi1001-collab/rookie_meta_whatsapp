# REST API and Socket.IO contract

## Conventions

- Base URL: `/api/v1` (configurable with `API_PREFIX`).
- JSON success envelope: `{ "success": true, "data": ... }`.
- Error envelope: `{ "success": false, "error": { "code": "...", "message": "..." } }` with optional validation details.
- Authenticated endpoints require `Authorization: Bearer <access-token>`.
- Resource list endpoints support `page`, `pageSize` (maximum 200), `search`, `status`, and relevant query filters. The response includes `items`, `total`, `page`, `pageSize` and `totalPages`.
- Dates sent in query filters should be ISO-8601 values. Report `to` dates are interpreted through the end of the supplied calendar day.
- Include the `X-Request-ID` response header when reporting a production failure.

## Authentication

| Method | Path | Permission / behavior |
|---|---|---|
| POST | `/auth/login` | Public; rate-limited; accepts email/password and issues access plus rotating refresh session. |
| POST | `/auth/refresh` | Public with refresh cookie/session; rotates the refresh token. |
| POST | `/auth/logout` | Authenticated; revokes the current refresh session. |
| GET | `/auth/me` | Authenticated; returns current user and permission context. |
| PATCH | `/auth/password` | Authenticated; changes password and revokes existing sessions. |

The refresh token is stored as a hash in `refresh_sessions`; the browser API client retries eligible requests once after refreshing an expired access token. A request is rejected if the corresponding refresh session is revoked or expired. Socket handshake validation uses the same session check.

## Dashboard and uploads

| Method | Path | Permission |
|---|---|---|
| GET | `/dashboard/summary` | `dashboard:view` |
| POST | `/uploads` | `qr-rework:create` |
| POST | `/uploads/qa` | `qa-inspection:approve` |
| POST | `/uploads/avatar` | `user-management:create` or `user-management:update` |

Multipart uploads use the form field name `file`. The upload service currently stores files on local disk under `UPLOAD_DIR` and serves them through the `/uploads` static path. The URL is a file reference; use shared object storage for multiple API replicas in production.

## Production resources

Each generic resource route provides `GET /`, `GET /:id`, `POST /`, `PATCH /:id`, and `DELETE /:id`, subject to the module permissions in the table. The endpoints below are mounted separately and use the named module:

| Resource path | Permission module | Resource |
|---|---|---|
| `/purchase-orders` | `purchase-orders` | purchase orders |
| `/stations` | `station-management` | stations |
| `/operators` | `station-management` | operators |
| `/master-data/operators` | `master-data` | operators master data |
| `/master-data/stations` | `master-data` | station master data |
| `/master-data/categories` | `master-data` | defect categories |
| `/master-data/defects` | `master-data` | defect codes |
| `/categories` | `master-data` | defect categories (compatibility path) |
| `/defects` | `master-data` | defect codes (compatibility path) |
| `/work-orders` | `qr-rework` for view/create; `station-management` for update | rework work orders (custom status-transition handler) |
| `/cartons` | `packing` | cartons (generic CRUD; specialized workflow below) |
| `/inspections` | `qa-inspection` | inspection history |

Generic route delete uses the route's module `delete` permission. Completed QA Passed/Packed work orders cannot be deleted through generic work-order deletion.

## Workflow-specific endpoints

| Method | Path | Permission | Purpose |
|---|---|---|---|
| GET | `/qr-rework/options` | `qr-rework:view` | Live registration form choices. |
| POST | `/qr-rework/stations` | `qr-rework:create` | Create a station from QR registration. |
| GET | `/qa/checklist` | `qa-inspection:view` | Shared checklist used for new inspections. |
| POST | `/qa/checklist` | `qa-inspection:create` | Add a checklist item. |
| PATCH | `/qa/checklist/:id` | `qa-inspection:update` | Update title/category or enable/disable an item. |
| GET | `/qa/queue` | `qa-inspection:view` | Work orders currently waiting for QA. |
| GET | `/qa/options` | `qa-inspection:view` | Live QA form options. |
| POST | `/qa/inspections` | `qa-inspection:approve` | Persist Pass/Reject/Scrap decision and checklist. |
| POST | `/qa/resubmit/:id` | `qa-inspection:approve` | Requeue a rejected garment for inspection. |
| GET | `/qa/trace/:code` | `qa-inspection:view` | Work-order and inspection trace by QR/garment/rework code. |
| GET | `/packing/garments` | `packing:view` | QA-passed garments eligible for packing. |
| GET | `/packing/cartons` | `packing:view` | Carton list. |
| POST | `/packing/cartons` | `packing:create` | Create carton. |
| POST | `/packing/cartons/:id/garments` | `packing:update` | Add garments to carton. |
| POST | `/packing/cartons/:id/remove-garment` | `packing:update` | Remove garment with removal log. |
| PATCH | `/packing/cartons/:id/close` | `packing:approve` | Close a non-empty carton. |
| PATCH | `/packing/cartons/:id/dispatch` | `packing:approve` | Dispatch a closed carton. |
| GET | `/reports/summary` | `reports:view` | Aggregate report KPIs. |
| GET | `/reports/dataset` | `reports:view` | Date-scoped report rows for existing UI visualizations. |
| GET | `/reports/audit-activity` | `reports:view` | Recent audit activity (bounded by query limit). |

## Administration endpoints

| Method | Path | Permission |
|---|---|---|
| GET | `/users/options` | `user-management:view` (active station choices) |
| GET/POST | `/users` | `user-management:view/create` |
| PATCH/DELETE | `/users/:id` | `user-management:update/delete` |
| GET/POST | `/roles` | `user-management:view/create` |
| PATCH/DELETE | `/roles/:id` | `user-management:update/delete` |
| GET | `/permissions` | `user-management:view` |
| GET/PUT | `/settings` | `settings:view/update` |
| POST | `/settings/avatar` | `settings:update` |
| PUT | `/settings/api` | `settings:manage` |
| GET | `/notifications` | authenticated; recipient-scoped |
| PATCH | `/notifications/:id/read` | authenticated; recipient-scoped |
| PATCH | `/notifications/read-all` | authenticated; recipient-scoped |

The settings API endpoint is for non-secret display/configuration metadata. Secrets and connection URLs are not accepted as a substitute for environment configuration.

## Socket.IO authentication and rooms

Connect to the Socket.IO origin (the `VITE_SOCKET_URL`, not the `/api/v1` URL) using the current access token:

```ts
const socket = io(import.meta.env.VITE_SOCKET_URL, {
  transports: ['websocket', 'polling'],
  auth: { token: accessToken },
});
```

The server validates JWT issuer/audience/type, access-token session ID, refresh-session revocation/expiry, active user and active role during the socket handshake. Clients are assigned to:

- `user:<userId>` — per-user events.
- `module:<moduleKey>:view` — module room only when the user's role has view/manage access for that module.
- `dashboard:view` — dashboard viewers.
- `authenticated` — all authenticated socket connections (not used for data broadcasts in the current event service).

The server emits these events:

### `resource:changed`

```json
{
  "resource": "work-orders",
  "module": "station-management",
  "action": "updated",
  "entityId": "<mongo-id-or-null>",
  "actorId": "<user-id-or-null>",
  "summary": "",
  "occurredAt": "2026-01-01T10:00:00.000Z"
}
```

The payload is an invalidation signal, not a full entity snapshot. On receipt, the relevant page should refetch its collection/summary. Event actions currently include `created`, `updated` and `deleted`.

### `dashboard:refresh`

```json
{ "module": "qa-inspection", "action": "updated", "occurredAt": "2026-01-01T10:00:00.000Z" }
```

Dashboard subscribers refetch `/dashboard/summary` after the event.

### Per-user notification events

`emitToUser(userId, event, payload)` is available to send an event into the recipient room. The notification endpoints are recipient-scoped. Workflow controllers do not yet create automatic notification documents for every event; add specific notification business rules before expecting a populated inbox from workflow activity.

## Current event fan-out behavior

- Resource changes broadcast to the relevant module's viewer room and to `module:reports:view`.
- Dashboard viewers receive `dashboard:refresh` for resource changes.
- Work-order, inspection, packing-garment and carton changes also invalidate the purchase-order list because its counts are derived from workflow state.
- Master-data CRUD emits master-data events; station/operator endpoints also emit station-management events.
- Work-order creation and transitions emit events for QR/rework, station management and/or QA queue depending on the operation.

## Client integration pattern

The frontend uses `src/lib/api.ts` for REST and `src/lib/realtime.ts` plus `src/hooks/useLiveResource.ts` for Socket.IO. The hook fetches authoritative rows, listens to scoped resource events and refetches. It currently fetches a bounded number of pages (up to 10,000 records) because some original UI tables filter locally. For larger datasets, switch each table to server-side search/filter/sort/pagination instead of increasing the bound indefinitely.
