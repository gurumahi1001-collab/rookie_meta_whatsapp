# MongoDB collections and model reference

MongoDB uses collections rather than relational SQL tables. The model names below map to these collection names. Mongoose timestamps are enabled for business collections unless noted. All ordinary model JSON responses expose `id` (string) rather than `_id`, and hide password/token hashes.

## Collection inventory

| Collection | Model | Purpose | Important indexes / uniqueness |
|---|---|---|---|
| `users` | `User` | Login identity, profile and role assignment | Unique `email`; indexes on `roleId`, `roleKey`, `status` |
| `roles` | `Role` | Named system/custom roles and module mapping | Unique `key`; `active`, `sortOrder` |
| `permissions` | `Permission` | Server-side module catalog and available actions | Unique `key`; `active`, `sortOrder` |
| `role_permissions` | `RolePermission` | Role-to-module action grants | Unique compound `(roleId, permissionId)` |
| `refresh_sessions` | `RefreshSession` | Rotating refresh-session hashes and revocation | Unique `sessionId`; TTL index on `expiresAt` |
| `purchase_orders` | `PurchaseOrder` | PO header and size/color quantities | Unique `poNumber`; status/delivery date index |
| `stations` | `Station` | Production/work stations and staff assignments | Unique `code`; `(factory, status)` |
| `operators` | `Operator` | Shop-floor operator master records | Unique `employeeCode`; status |
| `defect_categories` | `DefectCategory` | Defect taxonomy | Unique `code`; status |
| `defects` | `Defect` | Defect type/code, category, severity and expected minutes | Unique `code`; `categoryId`, status |
| `work_orders` | `WorkOrder` | Rework/garment tracking and lifecycle | Unique `reworkId`; indexes on `qrId`, `garmentId`, `poNumber`, status, station and registration date |
| `qa_inspections` | `QAInspection` | Immutable inspection decisions and checklist snapshots | `(workOrderId, inspectedAt)`; decision/date |
| `qa_checklist_items` | `QAChecklistItem` | Shared, editable QA checklist configuration | Unique `code`; `(active, sortOrder, createdAt)` |
| `cartons` | `Carton` | Packing carton, contents and dispatch state | Unique `cartonId`; `(poNumber, status, createdAt)` |
| `settings` | `Setting` | Application preferences, notification preferences and safe API display settings | Unique `key` |
| `audit_logs` | `AuditLog` | Actor, action, module, entity and request audit trail | action/module/entity/actor; `(module, createdAt)` |
| `notifications` | `Notification` | Per-user inbox notifications | `(recipientId, createdAt)`; `readAt` |
| `system_migrations` | `Migration` | Applied migration versions | Unique migration `key` |

## Model fields

### `users`

`name`, `email`, `employeeId`, `phone`, `department`, `jobTitle`, `avatarUrl`, `passwordHash`, `roleId`, `roleKey`, `stationId`, `status` (`active|inactive|locked`), `lastLoginAt`, `passwordChangedAt`, `failedLoginAttempts`, `lockUntil`, `mustChangePassword`, `createdBy`. `passwordHash` is excluded from normal selection/JSON.

### `roles`

`key`, `name`, `description`, `modules[]`, `systemRole`, `active`, `sortOrder`. `Super Admin` is protected against deletion and permission reduction.

### `permissions`

`key`, `name`, `description`, `category`, `actions[]`, `active`, `system`, `sortOrder`. The action vocabulary is `view`, `create`, `update`, `delete`, `approve`, `export`, `manage`.

### `role_permissions`

`roleId`, `permissionId`, `actions` (booleans for the seven actions), `active`. A user must have an active role, an active permission and an active assignment with the requested action (or `manage`) to pass RBAC middleware.

### `refresh_sessions`

`userId`, `sessionId`, `tokenHash`, `expiresAt`, `revokedAt`, `ipAddress`, `userAgent`. Only the SHA-256 digest of the rotating refresh JWT is persisted. Expired documents are eligible for MongoDB TTL cleanup.

### `purchase_orders`

`poNumber`, `supplier`, `style`, `articleSku`, `description`, `items[]` (`size`, `color`, `orderedQty`), `orderedQty`, summary `size`/`color`/`batch`, derived metrics `totalReworks`, `inProgress`, `completed`, `irreparable`, `deliveryDate`, `status` (`Active|Completed|On Hold`), `remarks`, `createdBy`. The list endpoint derives the rework metrics from `work_orders` instead of trusting stale UI counters.

### `stations`

`code`, `name`, `type`, `category`, `factory`, `location`, `capacity`, `operatorIds[]`, `status` (`Active|Inactive`), `remarks`, `createdBy`.

### `operators`

`name`, `employeeCode`, `role`, `phone`, `email`, `stationIds[]`, `status` (`Active|Inactive`).

### `defect_categories`

`code`, `name`, `description`, `severity` (`Minor|Major|Critical`), `status`.

### `defects`

`code`, `name`, `categoryId`, denormalized `categoryName`, `severity`, `reworkMinutes`, `description`, `status`.

### `work_orders`

`reworkId`, `qrId`, `poNumber`, `garmentId`, `styleNumber`, `size`, `defectCategory`, `severity`, `stationId`, `assignedStation`, `operatorId`, `operator`, `duration`, `status`, `description`, `defectImage`, `defectImageUrl`, `registeredAt`, `registeredDate`, `startedAt`, `completedAt`, `submittedAt`, `repairDetails`, `repairRemarks`, `materialsUsed`, `history[]`, `cartonId`, `createdBy`, `updatedBy`.

Allowed status values: `Assigned`, `In Progress`, `Sent to QA`, `QA Passed`, `QA Rejected`, `Packed`, `Scrap`.

### `qa_checklist_items`

`code`, `title`, `category`, `active`, `required`, `sortOrder`, `createdBy`, `updatedBy`. Seeded checklist entries are insert-only; administrator/QA users can add items and toggle their active state. Every submitted inspection copies checklist response text into `qa_inspections`, so later checklist edits do not mutate historical inspection snapshots.

### `qa_inspections`

`workOrderId`, station/operator snapshot fields, garment/PO/defect snapshot fields, `decision` (`Pass|Reject|Scrap`), `checklistResponses[]` (`itemId`, `title`, `response`, `passed`, `remarks`), `failedChecks[]`, `reason`, `remarks`, `rejectedPhotoUrl`, `returnStationId`, `inspectorId`, `inspectorName`, `inspectedAt`. QA results are separate records; previous inspections are retained when an item returns for another QA cycle.

### `cartons`

`cartonId`, `poNumber`, `packingDateTime`, `packedBy`, `remarks`, `status` (`Open|Closed`), `dispatchStatus` (`Not Ready|Ready for Dispatch|Dispatched`), `garmentIds[]` (work-order ObjectId strings), `closedAt`, `dispatchedAt`, `removalLogs[]` (`garmentId`, `reason`, `removedAt`, `removedBy`), `createdBy`.

### `settings`

`key`, arbitrary structured `value`, `updatedBy`. Current keys include `preferences`, `notifications` and `api`. API settings are display metadata only; JWT/database secrets remain environment-managed.

### `audit_logs`

`action`, `module`, `title`, `description`, `actorUserId`, `actorName`, `actorEmail`, `entityType`, `entityId`, `entityName`, `requestId`, `ipAddress`, `userAgent`, `metadata`, `createdAt`. Audit rows intentionally have no `updatedAt`.

### `notifications`

`recipientId`, `eventType`, `title`, `message`, `payload`, `readAt`, timestamps. Read state is owned by the recipient.

### `system_migrations`

`key`, `description`, `checksum`, `appliedAt`, timestamps. The migration key is unique and acts as the one-time migration ledger.

## Relationships (logical)

```text
Role 1 ── * User
Role * ── * Permission  (through RolePermission)
User 1 ── * RefreshSession
PurchaseOrder 1 ── * WorkOrder (joined by poNumber)
Station 1 ── * WorkOrder (stationId is a string key/reference)
Operator 1 ── * WorkOrder (operatorId is a string key/reference)
DefectCategory 1 ── * Defect (categoryId is a string key/reference)
WorkOrder 1 ── * QAInspection (workOrderId)
QAChecklistItem configuration ── copied into each QAInspection.checklistResponses snapshot
Carton 1 ── * WorkOrder (Carton.garmentIds contains work-order IDs; WorkOrder.cartonId stores carton code)
User 1 ── * AuditLog / Notification
```

The UI and source data use string station/operator/category references, so those references remain strings instead of forced ObjectIds. Role/user/inspection actor relations use ObjectIds where a Mongoose relation is useful.

## Data integrity notes

- `reworkId`, `poNumber`, `qrId`, `garmentId`, station code, employee code, defect/category code and carton ID must be unique where declared by model indexes.
- A QA-passed garment can be placed in one open carton. The backend checks its status and current `cartonId` before packing.
- Cartons are closed only when non-empty. Dispatch is only allowed after close.
- `work_orders` are traceability records; completed/packed records are protected from generic deletion.
- If production needs multi-document transactional guarantees, deploy MongoDB as a replica set and add explicit `withTransaction` wrappers around the carton/work-order commit flow.
