# Source analysis and implementation traceability

## Inputs reviewed

The implementation was based on the three supplied archives:

1. `newapp.zip` — existing React application source.
2. `NEW APP UI Screenshots.zip` — screenshots of the target/current application UI and workflow screens.
3. `oldprojectServercopy.zip` — previous server implementation used as the architectural and coding-pattern reference.

The screenshots were used as a visual/workflow reference. The source application was treated as the authoritative UI implementation so that styling and component structure were preserved rather than redrawn.

## 1. Existing frontend findings

The application is a React 18, TypeScript and Vite SPA using React Router, Bootstrap/SCSS, PrimeReact and ApexCharts. The primary screens are:

- Dashboard
- Purchase Orders
- QR & Rework Management and QR registration
- Station Management
- QA Inspection
- Packing & Dispatch
- Reports & Analytics
- Master Data
- User & Roles
- Settings

The application already contained its page composition, visual components, forms, tables, filters and chart layouts. Several areas were demonstrations or placeholders: the dashboard rendered an `UnderDevelopment` placeholder; packing carton records used browser-local state; QA, report and some master-data lists used local or deterministic demo data; QR registration used preselected/hardcoded station/operator options.

## 2. Screenshot-derived process

The screenshots show the same production flow documented in `WORKFLOW.md`: register defect against PO/garment using QR data, route to repair station/operator, capture repair progress, inspect via QA checklist, then pack and dispatch passed garments through cartons. Master data and user/role/settings screens administer the workflow.

The new integration keeps the page framing and style language while moving system-of-record data to MongoDB-backed endpoints. UI-only constants (such as chart labels, allowed severity values, icons and presentation assets) remain static where they describe display behavior rather than mutable business records.

## 3. Old server reference findings

The old server copy was useful for its layered folder structure, Express routing, Mongoose models, authentication/RBAC patterns, seeding approach and separation of controllers/services/configuration. Its README/migration material also contained PostgreSQL-oriented material that did not match its active Mongoose model/runtime structure. The new project therefore uses MongoDB/Mongoose-native model indexes and a versioned `system_migrations` ledger; it does not run SQL migrations.

The old server's credentials, private environment settings and user records were not copied. The new seed defines a safe initial Super Admin role and optionally creates the first user from secret environment variables.

## 4. Implementation map

| Existing page/area | New backend/UI integration |
|---|---|
| Login and user session | `/auth/login`, refresh rotation, `/auth/me`, logout and password change. |
| Dashboard | live `/dashboard/summary` KPI/workflow/activity aggregation. |
| Purchase Orders | MongoDB PO CRUD with work-order-derived live metrics. |
| QR & Rework | live PO/defect/station/operator options, persistent work-order creation and image upload. |
| Station Management | station/operator master data and controlled work-order state updates. |
| QA Inspection | persisted queue, checklist decision documents, image upload, resubmission and garment trace. |
| Packing & Dispatch | persistent cartons/garment assignment, removal logs, close and dispatch actions. |
| Reports & Analytics | date-scoped server dataset with existing chart/filter/table presentation retained. |
| Master Data | persistent station/operator/category/defect records. |
| User & Roles | user CRUD, system/custom role management and server-backed permission catalog. |
| Settings | persisted preferences/profile/avatar/API display settings and password update. |
| Header | authenticated user details, persisted notification inbox and socket invalidation. |

## 5. Deliberate compatibility choices

- Page layout, route organization, existing visual controls and chart components were retained.
- The backend follows the React app's manufacturing/rework domain, not the old server's unrelated entities.
- Station/operator/category references remain string identifiers where they match the UI data contract.
- MongoDB collections use explicit unique indexes for business identifiers.
- Sockets send scoped invalidation events; clients refetch data so list/card contents always originate from the server.
- The dashboard placeholder was replaced by a functioning dashboard view because the original dashboard screen was explicitly a development placeholder. The QA checklist, whose source comment explicitly marked it as demo-only, was moved into a MongoDB collection with idempotent defaults and a shared API.
- Existing static UI values remain only where they are presentation choices or fixed enumerations, not mutable business records.

## 6. Known limitations and decisions

- The backend syntax check and three permission tests pass. A full frontend install/build and live MongoDB integration test were not completed in the generation environment because package installation timed out. A CI run with dependency access and MongoDB is required.
- The current local-disk upload adapter must be replaced with shared object storage before multi-instance deployment.
- Socket.IO is configured in-process; add a Redis adapter and sticky sessions for multi-replica deployment.
- Multi-document packing operations need MongoDB transaction wrappers and concurrency tests before high-concurrency deployment.
- The frontend resource hook currently caps preload at 10,000 records to preserve existing client-side table behavior; migrate tables to server-side pagination for larger datasets.
- Notification models and APIs are connected, but workflow transitions do not yet fan out automatic inbox notifications. That requires explicit product rules per event/recipient role.
- The existing app's settings API screen stores display metadata; actual server secrets/configuration remain environment-managed and cannot be dynamically edited from the browser.
