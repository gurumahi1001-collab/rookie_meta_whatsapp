# Production deployment and operations

This package is a production-oriented integration baseline, not a claim that a high-availability production environment has already been provisioned or load-tested. Complete the deployment controls below before exposing it to public traffic.

## 1. Runtime and topology

- Backend runtime: Node.js 20.19+ (the backend package declares this minimum).
- Frontend: React + TypeScript + Vite static build.
- Database: MongoDB. Use a replica set for transaction support and high availability.
- Realtime: Socket.IO 4.x.
- Serve the frontend and backend behind HTTPS using a reverse proxy/load balancer.
- Set a fixed, explicit allow-list of frontend origins; do not use wildcard CORS with credentials.

Recommended logical topology:

```text
Browser ── HTTPS ── CDN / reverse proxy ── React build
                         │
                         └── /api and /socket.io ── Express/Socket.IO service
                                                       │
                              ┌────────────────────────┴──────────────────┐
                              │                                           │
                          MongoDB replica set                    Shared object storage
```

## 2. Environment and secrets

Create `Backend/.env` from `.env.example` in the secret manager or deployment environment. Required controls:

- `NODE_ENV=production`
- `PORT` and `API_PREFIX`
- `FRONTEND_ORIGINS` set to the deployed frontend origin(s), comma-separated as supported by the environment parser.
- `MONGODB_URI` and `MONGODB_DB_NAME`
- `JWT_ACCESS_SECRET` and `JWT_REFRESH_SECRET`, generated independently with strong entropy.
- `COOKIE_SECURE=true` when using HTTPS.
- `COOKIE_SAME_SITE=lax` for same-site deployment; use `none` only for a truly cross-site HTTPS frontend/API arrangement.
- `UPLOAD_DIR` only when using persistent local storage.
- `UPLOAD_MAX_FILE_SIZE_MB`, rate limit settings and `LOG_LEVEL`.

Do not place secrets in `Frontend/.env`. Vite variables prefixed by `VITE_` are embedded in browser assets and are public. The frontend should only receive API base/origin/socket URLs.

Do not set a bootstrap password in committed templates. Supply `BOOTSTRAP_ADMIN_EMAIL` and a unique `BOOTSTRAP_ADMIN_PASSWORD` through the protected deployment secret store for the initial seed only. After first login, change the initial password. The seed uses insert-only semantics for an existing user and will not rotate a pre-existing user's password when the environment value changes.

## 3. Build and release steps

### Backend

```bash
cd Backend
npm install             # Backend lockfile is not included; pin resolved versions in CI
npm run lint
npm test
npm run db:check
npm run db:migrate
npm run db:seed          # only when installing/refreshing required seed records
npm start
```

Do not run `AUTO_SEED=true` on every application instance in production. Run migrations and seed as a controlled release job with a database backup and an operator-approved change window. `AUTO_MIGRATE` is available for development/single-process startup; production teams should usually run explicit migrations before deploying new app instances.

### Frontend

```bash
cd Frontend
npm install
npm run typecheck
npm run build
```

Deploy the generated `dist/` directory to static hosting/CDN. Set `VITE_API_BASE_URL`, `VITE_API_ORIGIN` and `VITE_SOCKET_URL` at build time for the target environment.

### Validation caveat for this handoff

The backend source lint and unit tests were run during package assembly. Dependency installation timed out and the package registry could not be reached in the file-generation environment; the frontend package manifest includes `socket.io-client`, but its existing lockfile could not be regenerated here. Use `npm install` (not `npm ci`) once registry access is available so npm reconciles the lockfile, then commit the updated lockfile. A full frontend TypeScript/Vite build and live MongoDB integration test were not completed in that environment. Run the commands above in CI with dependency/network access and a disposable MongoDB replica set before production release.

## 4. Required production hardening

### Shared uploads

The current upload middleware saves files to local disk and the Express app serves `/uploads`. This is acceptable for local development or one persistent backend host only. In a multi-replica deployment, use S3-compatible object storage (for example, AWS S3 or MinIO), store object keys/URLs in MongoDB, and use signed/private delivery where defect/QA images should not be public. Do not rely on container ephemeral disks for user uploads.

### Socket.IO across replicas

The current Socket.IO server and room membership are process-local. For multiple backend replicas:

1. Add the Socket.IO Redis adapter and a managed Redis/compatible pub-sub service.
2. Configure sticky sessions if polling transport remains enabled; alternatively enforce WebSocket-only transport where network constraints permit.
3. Ensure every instance validates the same JWT/session state and uses consistent CORS/origin settings.
4. Test reconnect, token refresh and cross-instance event delivery.

Without a shared adapter, a write handled by replica A will not reliably broadcast to clients connected to replica B.

### Database transactions and race protection

Use a MongoDB replica set. Wrap carton creation/garment assignment/removal/close/dispatch operations in Mongoose sessions and transactions to make updates across carton and work-order documents atomic. Add concurrency tests for two packers attempting to add the same garment simultaneously. For strict consistency, enforce the assignment with a conditional update or unique relation/claim document, not only an application-side read-before-write.

### Authorization and security

- Review every role's permission matrix with business owners before go-live.
- Verify the intended users can only access their permitted module/action combinations.
- Enforce HTTPS and secure refresh cookies. Configure trusted proxy settings correctly when deployed behind a reverse proxy.
- Use strong independent JWT secrets and a rotation/revocation runbook.
- Add account lockout/monitoring alerts and MFA if organizational policy requires it.
- Keep dependencies patched and run an automated vulnerability scan in CI.
- Configure a restrictive Content Security Policy and security headers in the frontend hosting/reverse proxy.
- The current frontend stores the short-lived access token in browser local/session storage to support the existing remember-me flow. This makes XSS prevention especially important; consider moving access tokens to in-memory storage and relying on secure HttpOnly cookies for refresh/session continuation in a future security iteration.
- Confirm upload MIME/content validation, file size limits, image transformation and malware scanning meet the organization's policy. Restrict uploaded images if they contain sensitive production information.

### Scalability and data retention

- `useLiveResource` currently loads up to 10,000 rows because several existing tables perform client-side filtering. Move larger lists to true server-side sort/filter/page and request only visible rows.
- `/reports/dataset` has bounded row counts. For larger reporting workloads, create aggregate pipelines/materialized reporting collections and asynchronous export jobs.
- Define retention and archival for audit logs, inspection images and expired refresh sessions. A TTL index is used for refresh-session expiry; audit data should not be deleted without compliance approval.
- Add MongoDB backups, point-in-time recovery, restore drills and index monitoring.

## 5. Observability and health

- Liveness: `GET /health/live` — process is responding.
- Readiness: `GET /health/ready` — app/database readiness as implemented in the Express app.
- API health: `GET /api/v1/health`.
- Logs use Pino and request correlation; preserve `X-Request-ID` in reverse proxy/access logs.
- Add metrics/alerts for request latency/error rate, MongoDB pool saturation, auth failures, socket connections/reconnects, upload failures, memory/CPU and queue backlogs.
- Avoid logging passwords, JWTs, refresh tokens, uploaded file contents or other sensitive payload data.

## 6. Backup and rollback

1. Take a verified MongoDB backup before migration.
2. Record the deployed app version and migration ledger (`system_migrations`).
3. Apply additive, backward-compatible migrations before rolling out application code.
4. Confirm health and critical user journeys with production-like data.
5. Keep previous frontend/backend artifacts available for rollback.
6. Prefer forward-fix for irreversible data migrations; a code rollback alone does not reverse transformed data.

## 7. Go-live checklist

- [ ] Node runtime meets the declared engine requirement.
- [ ] All secrets injected by secret manager; no `.env` committed.
- [ ] MongoDB replica set, auth, TLS, backups and restore test completed.
- [ ] Explicit production frontend origins and HTTPS cookie settings.
- [ ] Backend lint/tests and frontend typecheck/build pass in CI.
- [ ] Migrations reviewed and applied once as a release job.
- [ ] Bootstrap administrator created, initial password changed and admin access reviewed.
- [ ] Role permissions tested with representative accounts.
- [ ] Image upload storage is persistent/shared and access policy approved.
- [ ] Socket.IO Redis adapter and sticky sessions configured if more than one replica is used.
- [ ] Carton workflow transactions/concurrency protection completed before high-concurrency packing.
- [ ] Load tests, monitoring, alerts and runbooks in place.
- [ ] Data retention, privacy and audit requirements signed off.
