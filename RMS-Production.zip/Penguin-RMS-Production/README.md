# Penguin Apparel Rework Management System — Production Integration

This deliverable converts the supplied React/Vite UI into a connected application and adds a Node.js, Express, MongoDB and Socket.IO backend. The supplied visual components, route structure, page layouts, styling and workflow terminology are retained. The main functional changes are API-backed data, authentication, permissions, persistence, audit logging and real-time refresh.

## Project layout

```text
Penguin-RMS-Production/
├── Backend/                 # Express 5, Mongoose, Socket.IO API
│   ├── src/
│   │   ├── config/          # Environment, MongoDB, Socket.IO
│   │   ├── constants/       # Module/action/role definitions
│   │   ├── controllers/     # Auth, admin, resource and workflow handlers
│   │   ├── middleware/      # Auth, RBAC, upload, request ID, errors
│   │   ├── models/          # MongoDB collections and indexes
│   │   ├── routes/          # Versioned API routes
│   │   ├── scripts/         # Versioned migrations and idempotent seeds
│   │   ├── services/        # Authentication, audit, dashboard, realtime
│   │   └── utils/
│   ├── storage/uploads/     # Local image storage in development
│   ├── tests/
│   ├── .env.example
│   └── server.js
├── Frontend/                # Supplied React/Vite UI with API integration
└── docs/                    # Architecture, models, workflow, API and deploy guides
```

## Quick start

### 1. MongoDB and backend

Use a reachable MongoDB database. In `Backend/`:

```bash
cp .env.example .env
# Edit .env: MONGODB_URI, JWT secrets, FRONTEND_ORIGINS,
# BOOTSTRAP_ADMIN_EMAIL and BOOTSTRAP_ADMIN_PASSWORD.
npm install
npm run db:check
npm run db:setup
npm run dev
```

The bootstrap password must be at least 12 characters. The seed creates the `Super Admin` **role** and its complete permission matrix by default, plus initial stations/operators/defects and the shared QA checklist. A login user is only created when both bootstrap email and password are configured; no default production password is embedded in the code.

Backend API: `http://localhost:4000/api/v1` by default. Health checks:

- `GET /health/live`
- `GET /health/ready`
- `GET /api/v1/health`

### 2. Frontend

In `Frontend/`:

```bash
cp .env.example .env
# Set VITE_API_BASE_URL, VITE_API_ORIGIN and VITE_SOCKET_URL if your API is not local.
npm install
npm run dev
```

Build the production bundle:

```bash
npm run build
```

Default local frontend URL: `http://localhost:5173`.

## Seeded first login

Set `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_PASSWORD` in `Backend/.env`, then run:

```bash
cd Backend
npm run db:seed
```

The seed is idempotent. It inserts the initial account only when the email does not already exist; changing the environment password does not reset an existing user password. Change the initial password after first sign-in.

## Documentation

- [Architecture and setup](docs/ARCHITECTURE_AND_SETUP.md)
- [MongoDB collections and model fields](docs/DATABASE_MODELS.md)
- [End-to-end workflow](docs/WORKFLOW.md)
- [REST API and Socket.IO contract](docs/API_AND_REALTIME.md)
- [Production deployment and operational checklist](docs/PRODUCTION_DEPLOYMENT.md)
- [Source analysis and integration notes](docs/SOURCE_ANALYSIS.md)

## Main application flow

Purchase Order → QR defect registration → station repair → QA decision (Pass / Reject / Scrap) using the shared MongoDB-backed checklist → QA-passed garment packing → carton close → dispatch. The server validates workflow transitions and keeps inspection and audit history. Client pages refetch the affected API data when a scoped Socket.IO event arrives, so all open sessions converge on the persisted server state.

## Validation note

Backend JavaScript syntax checks and the permissions unit tests are provided. Frontend dependencies could not be installed in the file-generation environment, so a Vite/TypeScript production build could not be completed here. The supplied frontend package-lock.json predates the added `socket.io-client` dependency; run `npm install` (not `npm ci`) in the Frontend directory to reconcile and regenerate the lockfile, then run `npm run build` before deployment. The deployment guide also calls out infrastructure steps needed for multi-instance uploads and Socket.IO scaling.
