import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const invoiceAttachmentSchema = new Schema(
    {
        invoiceId: {
            type: Schema.Types.ObjectId,
            ref: "Invoice",
            required: true,
            index: true,
        },
        originalName: { type: String, required: true, trim: true, maxlength: 255 },
        storageKey: { type: String, required: true, trim: true, maxlength: 1000, unique: true },
        relativePath: { type: String, required: true, trim: true, maxlength: 1000 },
        mimeType: { type: String, required: true, trim: true, lowercase: true, maxlength: 150 },
        extension: { type: String, trim: true, lowercase: true, maxlength: 20, default: "" },
        size: { type: Number, required: true, min: 0, max: 52428800 },
        checksum: { type: String, trim: true, maxlength: 128, default: "" },
        category: { type: String, enum: ["supporting_document", "invoice_document"], default: "supporting_document" },
        uploadedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
        uploadedAt: { type: Date, default: Date.now },
    },
    {
        collection: "invoice_attachments",
        timestamps: true,
        strict: "throw",
        versionKey: false,
    },
);

invoiceAttachmentSchema.index({ invoiceId: 1, createdAt: -1 });

invoiceAttachmentSchema.virtual("id").get(function id() {
    return String(this._id);
});

invoiceAttachmentSchema.methods.toSafeJSON = function toSafeJSON() {
    return {
        id: String(this._id),
        invoiceId: String(this.invoiceId),
        originalName: this.originalName,
        mimeType: this.mimeType,
        extension: this.extension,
        size: Number(this.size || 0),
        checksum: this.checksum || null,
        category: this.category,
        uploadedBy: this.uploadedBy ? String(this.uploadedBy) : null,
        uploadedAt: this.uploadedAt,
        url: `/invoices/${String(this.invoiceId)}/attachments/${String(this._id)}`,
    };
};

invoiceAttachmentSchema.set("toJSON", { virtuals: true });

const InvoiceAttachment =
    models.InvoiceAttachment || model("InvoiceAttachment", invoiceAttachmentSchema);

export default InvoiceAttachment;
export { invoiceAttachmentSchema };
