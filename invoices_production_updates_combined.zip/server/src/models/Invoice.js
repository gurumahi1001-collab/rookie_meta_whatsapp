import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

export const INVOICE_STATUSES = Object.freeze([
    "Draft",
    "Submitted",
    "Approved",
    "Rejected",
    "Paid",
]);

const invoiceSchema = new Schema(
    {
        invoiceNo: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true,
            uppercase: true,
            maxlength: 80,
        },
        quotationId: {
            type: Schema.Types.ObjectId,
            ref: "Quotation",
            required: true,
            index: true,
        },
        projectId: {
            type: Schema.Types.ObjectId,
            ref: "Project",
            required: true,
            index: true,
        },
        vendorId: {
            type: Schema.Types.ObjectId,
            ref: "Vendor",
            required: true,
            index: true,
        },
        vendorName: {
            type: String,
            required: true,
            trim: true,
            maxlength: 255,
        },
        projectName: {
            type: String,
            required: true,
            trim: true,
            maxlength: 255,
        },
        quotationNo: {
            type: String,
            trim: true,
            uppercase: true,
            maxlength: 80,
            default: "",
        },
        currency: {
            type: String,
            required: true,
            trim: true,
            uppercase: true,
            maxlength: 10,
            default: "USD",
        },
        siteReference: {
            type: String,
            trim: true,
            maxlength: 500,
            default: "",
        },
        milestoneName: {
            type: String,
            trim: true,
            maxlength: 1000,
            default: "",
        },
        installmentIndexes: {
            type: [Number],
            default: [],
            validate: {
                validator(value) {
                    return Array.isArray(value) && value.every((item) => Number.isInteger(item) && item >= 0);
                },
                message: "Installment indexes must contain non-negative integers.",
            },
        },
        installmentNames: {
            type: [String],
            default: [],
        },
        subtotal: {
            type: Number,
            required: true,
            min: 0,
        },
        taxRate: {
            type: Number,
            min: 0,
            max: 100,
            default: 0,
        },
        taxAmount: {
            type: Number,
            min: 0,
            required: true,
            default: 0,
        },
        totalAmount: {
            type: Number,
            min: 0,
            required: true,
            index: true,
        },
        dueDate: {
            type: Date,
            default: null,
            index: true,
        },
        issuedDate: {
            type: Date,
            default: null,
            index: true,
        },
        status: {
            type: String,
            enum: INVOICE_STATUSES,
            default: "Draft",
            index: true,
        },
        remarks: {
            type: String,
            trim: true,
            maxlength: 3000,
            default: "",
        },
        rejectionRemarks: {
            type: String,
            trim: true,
            maxlength: 3000,
            default: "",
        },
        submittedAt: {
            type: Date,
            default: null,
            index: true,
        },
        reviewedAt: {
            type: Date,
            default: null,
        },
        reviewedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
        paidAt: {
            type: Date,
            default: null,
            index: true,
        },
        paymentId: {
            type: Schema.Types.ObjectId,
            ref: "Payment",
            default: null,
            index: true,
        },
        revision: {
            type: Number,
            min: 1,
            default: 1,
        },
        parentInvoiceId: {
            type: Schema.Types.ObjectId,
            ref: "Invoice",
            default: null,
            index: true,
        },
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
            index: true,
        },
        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            default: null,
        },
    },
    {
        collection: "invoices",
        timestamps: true,
        strict: "throw",
        versionKey: false,
        minimize: false,
    },
);

invoiceSchema.index({ vendorId: 1, status: 1, updatedAt: -1 });
invoiceSchema.index({ projectId: 1, status: 1, dueDate: 1 });
invoiceSchema.index({ quotationId: 1, status: 1, createdAt: -1 });
invoiceSchema.index({ installmentIndexes: 1, quotationId: 1, status: 1 });

invoiceSchema.pre("validate", function normalizeInvoice() {
    this.invoiceNo = String(this.invoiceNo || "").trim().toUpperCase();
    this.currency = String(this.currency || "USD").trim().toUpperCase();
    this.vendorName = String(this.vendorName || "").trim();
    this.projectName = String(this.projectName || "").trim();
    this.quotationNo = String(this.quotationNo || "").trim().toUpperCase();
    this.subtotal = Number(this.subtotal || 0);
    this.taxRate = Math.max(0, Math.min(100, Number(this.taxRate || 0)));
    this.taxAmount = Number(this.taxAmount || 0);
    this.totalAmount = Number(this.totalAmount || 0);
    this.revision = Math.max(1, Number(this.revision || 1));
});

invoiceSchema.virtual("id").get(function id() {
    return String(this._id);
});

invoiceSchema.methods.toSafeJSON = function toSafeJSON() {
    const now = new Date();
    const isOverdue =
        Boolean(this.dueDate) &&
        this.dueDate < now &&
        ["Draft", "Submitted", "Approved"].includes(this.status);

    const displayStatus = isOverdue ? "Overdue" : this.status;

    return {
        id: String(this._id),
        invoiceNo: this.invoiceNo,
        quotationId: this.quotationId ? String(this.quotationId) : null,
        projectId: this.projectId ? String(this.projectId) : null,
        vendorId: this.vendorId ? String(this.vendorId) : null,
        vendor: this.vendorName,
        vendorName: this.vendorName,
        project: this.projectName,
        projectName: this.projectName,
        quotationNo: this.quotationNo,
        currency: this.currency,
        siteReference: this.siteReference || "",
        milestoneName: this.milestoneName || "",
        installmentIndexes: Array.isArray(this.installmentIndexes) ? this.installmentIndexes : [],
        installmentNames: Array.isArray(this.installmentNames) ? this.installmentNames : [],
        subtotal: Number(this.subtotal || 0),
        taxRate: Number(this.taxRate || 0),
        taxAmount: Number(this.taxAmount || 0),
        totalAmount: Number(this.totalAmount || 0),
        amount: Number(this.totalAmount || 0),
        issuedDate: this.issuedDate || null,
        dueDate: this.dueDate || null,
        status: displayStatus,
        baseStatus: this.status,
        isOverdue,
        remarks: this.remarks || "",
        rejectionRemarks: this.rejectionRemarks || "",
        submittedAt: this.submittedAt || null,
        reviewedAt: this.reviewedAt || null,
        reviewedBy: this.reviewedBy ? String(this.reviewedBy) : null,
        paidAt: this.paidAt || null,
        paymentId: this.paymentId ? String(this.paymentId) : null,
        revision: Number(this.revision || 1),
        parentInvoiceId: this.parentInvoiceId ? String(this.parentInvoiceId) : null,
        createdBy: this.createdBy ? String(this.createdBy) : null,
        updatedBy: this.updatedBy ? String(this.updatedBy) : null,
        createdAt: this.createdAt,
        updatedAt: this.updatedAt,
        attachments: [],
        payment: null,
        auditTrace: null,
    };
};

invoiceSchema.set("toJSON", { virtuals: true });

const Invoice = models.Invoice || model("Invoice", invoiceSchema);
export default Invoice;
