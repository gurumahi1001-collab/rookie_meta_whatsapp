import { Router } from "express";
import multer from "multer";
import * as controller from "../controllers/payment/paymentController.js";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";

const router = Router();
router.use(authenticate);

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024, files: 10 },
    fileFilter: (_req, file, cb) => {
        if (file.mimetype === "application/pdf" || String(file.mimetype || "").startsWith("image/")) return cb(null, true);
        return cb(Object.assign(new Error("Payment proof must be a PDF or image."), { statusCode: 422, code: "UNSUPPORTED_PAYMENT_PROOF" }));
    },
});

const uploadPaymentProof = (req, res, next) => {
    upload.array("proof", 10)(req, res, (error) => {
        if (!error) return next();
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message || "Invalid payment proof upload.",
            code: error.code || "PAYMENT_PROOF_UPLOAD_FAILED",
        });
    });
};

const internalView = authorize({ module: "payment", action: "view", realms: ["admin", "internal"], userTypes: ["admin", "internal"], allowSuperAdmin: true });
const internalAdd = authorize({ module: "payment", action: "add", realms: ["admin", "internal"], userTypes: ["admin", "internal"], allowSuperAdmin: true });

router.get("/", internalView, controller.list);
router.get("/:id/proof/:proofId", internalView, controller.proof);
router.get("/:id", internalView, controller.get);
router.post("/", internalAdd, uploadPaymentProof, controller.create);

export default router;
