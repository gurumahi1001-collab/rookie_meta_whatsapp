import { Router } from "express";
import multer from "multer";
import * as controller from "../controllers/invoice/invoiceController.js";
import { authenticate } from "../middleware/auth.js";
import { authorize } from "../middleware/rbac.js";

const router = Router();
router.use(authenticate);

const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024, files: 10 },
    fileFilter: (_req, file, cb) => {
        const allowed = new Set([
            "application/pdf",
            "text/plain",
            "text/csv",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ]);
        if (allowed.has(file.mimetype) || String(file.mimetype || "").startsWith("image/")) return cb(null, true);
        return cb(Object.assign(new Error("Unsupported invoice attachment type."), { statusCode: 422, code: "UNSUPPORTED_INVOICE_ATTACHMENT" }));
    },
});

const uploadInvoiceFiles = (req, res, next) => {
    upload.array("documents", 10)(req, res, (error) => {
        if (!error) return next();
        return res.status(error.statusCode || 400).json({
            success: false,
            message: error.message || "Invalid invoice attachment upload.",
            code: error.code || "INVOICE_ATTACHMENT_UPLOAD_FAILED",
        });
    });
};

const view = authorize({ module: "invoice", action: "view", realms: ["admin", "internal", "vendor"], userTypes: ["admin", "internal", "vendor"], allowSuperAdmin: true });
const add = authorize({ module: "invoice", action: "add", realms: ["admin", "internal", "vendor"], userTypes: ["admin", "internal", "vendor"], allowSuperAdmin: true });
const edit = authorize({ module: "invoice", action: "edit", realms: ["admin", "internal", "vendor"], userTypes: ["admin", "internal", "vendor"], allowSuperAdmin: true });
const del = authorize({ module: "invoice", action: "delete", realms: ["admin", "internal", "vendor"], userTypes: ["admin", "internal", "vendor"], allowSuperAdmin: true });
const internalEdit = authorize({ module: "invoice", action: "edit", realms: ["admin", "internal"], userTypes: ["admin", "internal"], allowSuperAdmin: true });

router.get("/available-quotations", view, controller.availableQuotations);
router.get("/quotations/:quotationId/context", view, controller.creationContext);
router.get("/", view, controller.list);
router.get("/:id/attachments/:attachmentId", view, controller.attachments);
router.get("/:id", view, controller.get);
router.post("/", add, uploadInvoiceFiles, controller.create);
router.patch("/:id", edit, uploadInvoiceFiles, controller.update);
router.post("/:id/submit", edit, controller.submit);
router.post("/:id/approve", internalEdit, controller.approve);
router.post("/:id/reject", internalEdit, controller.reject);
router.delete("/:id", del, controller.remove);

export default router;
