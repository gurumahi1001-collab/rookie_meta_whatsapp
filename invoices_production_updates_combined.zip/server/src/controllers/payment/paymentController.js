import * as service from "../../services/payment/paymentService.js";

function actor(req) {
    return req?.user ? { userId: req.user.id || req.user._id, userType: req.user.userType, roleId: req.user.roleId, vendorId: req.user.vendorId, actor: req.user } : {};
}
function body(req) { return req?.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {}; }
function request(req) { return { ipAddress: req?.ip, headers: req?.headers, get: req?.get?.bind(req) }; }
function errorResponse(res, error) {
    if (error instanceof service.PaymentServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}) });
    if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Payment validation failed.", code: "PAYMENT_VALIDATION_FAILED", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([key, value]) => [key, value?.message || "Invalid value."])) });
    if (error?.code === 11000) return res.status(409).json({ success: false, message: "A payment already exists for this invoice.", code: "PAYMENT_DUPLICATE" });
    console.error("[paymentController]", error);
    return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the payment.", code: "INTERNAL_SERVER_ERROR" });
}

export async function list(req, res) { try { return res.json({ success: true, ...(await service.listPayments({ actor: actor(req), invoiceId: req.query.invoiceId, page: req.query.page, limit: req.query.limit })) }); } catch (e) { return errorResponse(res, e); } }
export async function get(req, res) { try { return res.json({ success: true, data: await service.getPayment(req.params.id, { actor: actor(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "Payment recorded successfully.", data: await service.createPayment(body(req), req.files || [], { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function proof(req, res) { try { const result = await service.getPaymentProof(req.params.id, req.params.proofId, { actor: actor(req) }); res.setHeader("Content-Type", result.proof.mimeType || "application/octet-stream"); res.setHeader("Content-Length", String(result.stream.size)); res.setHeader("Content-Disposition", `attachment; filename="${String(result.proof.originalName || "payment-proof").replace(/"/g, "")}"`); return result.stream.stream.pipe(res); } catch (e) { return errorResponse(res, e); } }

export default { list, get, create, proof };
