import * as service from "../../services/invoice/invoiceService.js";

function actor(req) {
    return req?.user ? {
        userId: req.user.id || req.user._id,
        userType: req.user.userType,
        roleId: req.user.roleId,
        vendorId: req.user.vendorId,
        actor: req.user,
    } : {};
}
function body(req) { return req?.body && typeof req.body === "object" && !Array.isArray(req.body) ? req.body : {}; }
function request(req) { return { ipAddress: req?.ip, headers: req?.headers, get: req?.get?.bind(req) }; }
function errorResponse(res, error) {
    if (error instanceof service.InvoiceServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}) });
    if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Invoice validation failed.", code: "INVOICE_VALIDATION_FAILED", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([key, value]) => [key, value?.message || "Invalid value."])) });
    if (error?.code === 11000) return res.status(409).json({ success: false, message: "An invoice reference already exists.", code: "INVOICE_DUPLICATE" });
    console.error("[invoiceController]", error);
    return res.status(500).json({ success: false, message: "An unexpected error occurred while processing the invoice.", code: "INTERNAL_SERVER_ERROR" });
}
function streamAttachment(res, result, filename) {
    res.setHeader("Content-Type", result.attachment?.mimeType || "application/octet-stream");
    res.setHeader("Content-Length", String(result.stream.size));
    res.setHeader("Content-Disposition", `attachment; filename="${String(filename || "invoice-file").replace(/"/g, "")}"`);
    return result.stream.stream.pipe(res);
}

export async function list(req, res) { try { return res.json({ success: true, ...(await service.listInvoices({ actor: actor(req), ...req.query })) }); } catch (e) { return errorResponse(res, e); } }
export async function get(req, res) { try { return res.json({ success: true, data: await service.getInvoice(req.params.id, { actor: actor(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function availableQuotations(req, res) { try { return res.json({ success: true, ...(await service.listAvailableQuotations({ actor: actor(req), ...req.query })) }); } catch (e) { return errorResponse(res, e); } }
export async function creationContext(req, res) { try { return res.json({ success: true, data: await service.getInvoiceCreationContext(req.params.quotationId, { actor: actor(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function create(req, res) { try { return res.status(201).json({ success: true, message: "Invoice created successfully.", data: await service.createInvoice(body(req), req.files || (req.file ? [req.file] : []), { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function update(req, res) { try { return res.json({ success: true, message: "Invoice updated successfully.", data: await service.updateInvoice(req.params.id, body(req), req.files || [], { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function submit(req, res) { try { return res.json({ success: true, message: "Invoice submitted for approval.", data: await service.submitInvoice(req.params.id, { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function approve(req, res) { try { return res.json({ success: true, message: "Invoice approved successfully.", data: await service.approveInvoice(req.params.id, body(req).remarks, { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function reject(req, res) { try { return res.json({ success: true, message: "Invoice rejected successfully.", data: await service.rejectInvoice(req.params.id, body(req).remarks, { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function remove(req, res) { try { return res.json({ success: true, message: "Invoice deleted successfully.", data: await service.deleteInvoice(req.params.id, { actor: actor(req), request: request(req) }) }); } catch (e) { return errorResponse(res, e); } }
export async function attachments(req, res) { try { const result = await service.getInvoiceAttachment(req.params.id, req.params.attachmentId, { actor: actor(req) }); return streamAttachment(res, result, result.attachment.originalName); } catch (e) { return errorResponse(res, e); } }

export default { list, get, availableQuotations, creationContext, create, update, submit, approve, reject, remove, attachments };
