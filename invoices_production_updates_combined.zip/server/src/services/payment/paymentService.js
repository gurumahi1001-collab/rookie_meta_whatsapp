import { randomUUID } from "node:crypto";
import mongoose from "mongoose";
import Payment from "../../models/Payment.js";
import Invoice from "../../models/Invoice.js";
import auditService from "../audit/auditService.js";
import notificationService from "../notification/notificationService.js";
import * as storageService from "../storage/storageService.js";

const MAX_PROOF_FILES = 10;
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const INTERNAL_TYPES = ["admin", "internal"];

export class PaymentServiceError extends Error {
    constructor(message, { code = "PAYMENT_ERROR", statusCode = 400, details = undefined } = {}) {
        super(message);
        this.name = "PaymentServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, PaymentServiceError);
    }
}

const text = (v) => (typeof v === "string" ? v.trim() : "");
const num = (v, fallback = 0) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
};
function oid(v, field = "id") {
    if (!v || !mongoose.isValidObjectId(v)) throw new PaymentServiceError(`Invalid ${field}.`, { code: `INVALID_${String(field).toUpperCase()}`, statusCode: 422 });
    return new mongoose.Types.ObjectId(v);
}
function actorId(actor) { return actor?.userId && mongoose.isValidObjectId(actor.userId) ? new mongoose.Types.ObjectId(actor.userId) : null; }
function internal(actor) { return INTERNAL_TYPES.includes(String(actor?.userType || "").toLowerCase()); }
function serialize(row) { return row?.toSafeJSON ? row.toSafeJSON() : row?.toJSON?.() || row; }

async function audit(action, payment, invoice, actor, request, metadata = {}) {
    try {
        await auditService.recordAudit({
            action,
            module: "payment",
            title: `Payment ${action.replace(/_/g, " ")}`,
            description: invoice?.invoiceNo || "",
            actor: actor?.actor || actor || null,
            request,
            entityType: "payment",
            entityId: String(payment?._id || ""),
            entityName: invoice?.invoiceNo || "",
            vendorId: invoice?.vendorId || null,
            metadata,
        });
    } catch (error) { console.error("[paymentService] audit write failed", error); }
}

async function storeProof(files, paymentId, actor) {
    const input = Array.isArray(files) ? files.filter(Boolean) : [];
    if (input.length > MAX_PROOF_FILES) throw new PaymentServiceError(`A maximum of ${MAX_PROOF_FILES} payment proof files is allowed.`, { code: "TOO_MANY_PAYMENT_PROOFS", statusCode: 422 });
    const rows = [];
    try {
        for (const file of input) {
            if (!file?.buffer || Number(file.size || 0) <= 0 || Number(file.size || 0) > MAX_FILE_BYTES) {
                throw new PaymentServiceError("Each payment proof must be a valid file up to 10 MB.", { code: "PAYMENT_PROOF_TOO_LARGE", statusCode: 422 });
            }
            const original = text(file.originalname) || "payment-proof";
            const ext = original.includes(".") ? original.split(".").pop().toLowerCase() : "bin";
            const stored = await storageService.saveBuffer({ buffer: file.buffer, context: "payment", filename: `payment_${paymentId}_${randomUUID()}.${ext}` });
            const metadata = await storageService.buildFileMetadata({ storageKey: stored.storageKey, originalName: original, mimeType: file.mimetype || "application/octet-stream", extension: ext, uploadedBy: actorId(actor) });
            rows.push({
                originalName: metadata.originalName,
                storageKey: metadata.storageKey,
                relativePath: metadata.relativePath,
                mimeType: metadata.mimeType,
                extension: metadata.extension,
                size: metadata.size,
                checksum: metadata.checksum,
                uploadedAt: metadata.uploadedAt,
            });
        }
        return rows;
    } catch (error) {
        await Promise.all(rows.map(async (row) => { try { await storageService.deleteFile?.(row.storageKey); } catch {} }));
        throw error;
    }
}

export async function listPayments({ actor, invoiceId, page = 1, limit = 50 } = {}) {
    if (!internal(actor)) throw new PaymentServiceError("Only internal users can access payment records.", { code: "PAYMENT_ACCESS_FORBIDDEN", statusCode: 403 });
    const p = Math.max(1, Number.parseInt(String(page), 10) || 1);
    const l = Math.min(200, Math.max(1, Number.parseInt(String(limit), 10) || 50));
    const filter = invoiceId ? { invoiceId: oid(invoiceId, "invoiceId") } : {};
    const [rows, total] = await Promise.all([
        Payment.find(filter).sort({ paymentDate: -1, recordedAt: -1, _id: -1 }).skip((p - 1) * l).limit(l),
        Payment.countDocuments(filter),
    ]);
    return { data: rows.map(serialize), pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) } };
}

export async function getPayment(id, { actor } = {}) {
    if (!internal(actor)) throw new PaymentServiceError("Only internal users can access payment records.", { code: "PAYMENT_ACCESS_FORBIDDEN", statusCode: 403 });
    const row = await Payment.findById(oid(id, "paymentId"));
    if (!row) throw new PaymentServiceError("Payment record was not found.", { code: "PAYMENT_NOT_FOUND", statusCode: 404 });
    return serialize(row);
}

export async function createPayment(payload, files = [], { actor, request = null } = {}) {
    if (!internal(actor)) throw new PaymentServiceError("Only internal users can record payments.", { code: "PAYMENT_CREATE_FORBIDDEN", statusCode: 403 });
    const invoiceId = oid(payload?.invoiceId, "invoiceId");
    const invoice = await Invoice.findById(invoiceId);
    if (!invoice) throw new PaymentServiceError("Invoice was not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
    if (invoice.status !== "Approved") throw new PaymentServiceError("Only approved invoices can be marked as paid.", { code: "INVOICE_NOT_APPROVED", statusCode: 409 });
    const existing = await Payment.findOne({ invoiceId: invoice._id });
    if (existing) throw new PaymentServiceError("Payment has already been recorded for this invoice.", { code: "PAYMENT_ALREADY_RECORDED", statusCode: 409 });

    const amount = Math.round(num(payload?.amount, invoice.totalAmount) * 100) / 100;
    if (amount <= 0 || Math.abs(amount - num(invoice.totalAmount)) > 0.009) throw new PaymentServiceError("Payment amount must equal the approved invoice total.", { code: "PAYMENT_AMOUNT_MISMATCH", statusCode: 422, details: { invoiceTotal: invoice.totalAmount } });
    const reference = text(payload?.transactionReference ?? payload?.transactionRefId);
    if (!reference) throw new PaymentServiceError("Payment transaction reference is required.", { code: "TRANSACTION_REFERENCE_REQUIRED", statusCode: 422 });
    const paymentDate = payload?.paymentDate ? new Date(payload.paymentDate) : null;
    if (!paymentDate || Number.isNaN(paymentDate.getTime())) throw new PaymentServiceError("Payment date is required and must be valid.", { code: "PAYMENT_DATE_REQUIRED", statusCode: 422 });
    if (!Array.isArray(files) || files.length === 0) throw new PaymentServiceError("At least one payment proof document is required.", { code: "PAYMENT_PROOF_REQUIRED", statusCode: 422 });

    const paymentId = new mongoose.Types.ObjectId();
    const proof = await storeProof(files, paymentId, actor);
    let payment;
    let paymentPersisted = false;
    try {
        payment = new Payment({
            _id: paymentId,
            invoiceId: invoice._id,
            projectId: invoice.projectId,
            vendorId: invoice.vendorId,
            amount,
            currency: invoice.currency,
            transactionReference: reference,
            paymentDate,
            notes: text(payload?.notes),
            proof,
            recordedBy: actorId(actor),
            recordedAt: new Date(),
        });
        await payment.save();
        paymentPersisted = true;
        invoice.status = "Paid";
        invoice.paymentId = payment._id;
        invoice.paidAt = new Date();
        invoice.updatedBy = actorId(actor);
        await invoice.save();
    } catch (error) {
        if (paymentPersisted) {
            try { await Payment.deleteOne({ _id: paymentId }); } catch (cleanupError) { console.error("[paymentService] payment rollback failed", cleanupError); }
        }
        await Promise.all(proof.map(async (row) => { try { await storageService.deleteFile?.(row.storageKey); } catch {} }));
        throw error;
    }

    await audit("recorded", payment, invoice, actor, request, { invoiceId: String(invoice._id), amount, transactionReference: reference, paymentDate });
    try {
        const User = mongoose.model("User");
        const vendorUsers = await User.find({ vendorId: invoice.vendorId, userType: "vendor", status: "active" }).select("_id").lean();
        await Promise.all(vendorUsers.map((user) => notificationService.createNotification({
            recipientId: user._id,
            eventType: "invoice_paid",
            title: "Invoice payment recorded",
            message: `${invoice.invoiceNo} has been marked as paid.`,
            payload: { invoiceId: String(invoice._id), paymentId: String(payment._id), amount },
        })));
    } catch (error) { console.error("[paymentService] vendor payment notification failed", error); }
    return serialize(payment);
}

export async function getPaymentProof(paymentId, proofId, { actor } = {}) {
    if (!internal(actor)) throw new PaymentServiceError("Only internal users can access payment proof.", { code: "PAYMENT_ACCESS_FORBIDDEN", statusCode: 403 });
    const payment = await Payment.findById(oid(paymentId, "paymentId"));
    if (!payment) throw new PaymentServiceError("Payment record was not found.", { code: "PAYMENT_NOT_FOUND", statusCode: 404 });
    const proof = (payment.proof || []).find((row) => String(row._id) === String(proofId));
    if (!proof) throw new PaymentServiceError("Payment proof was not found.", { code: "PAYMENT_PROOF_NOT_FOUND", statusCode: 404 });
    const stream = await storageService.createReadStream(proof.storageKey);
    return { proof, stream };
}
