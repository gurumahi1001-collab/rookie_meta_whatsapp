import { randomUUID } from "node:crypto";
import mongoose from "mongoose";
import Invoice, { INVOICE_STATUSES } from "../../models/Invoice.js";
import InvoiceAttachment from "../../models/InvoiceAttachment.js";
import Payment from "../../models/Payment.js";
import Quotation from "../../models/Quotation.js";
import Project from "../../models/Project.js";
import Task from "../../models/Task.js";
import Vendor from "../../models/Vendor.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";
import auditService from "../audit/auditService.js";
import notificationService from "../notification/notificationService.js";
import * as storageService from "../storage/storageService.js";

const EDITABLE_STATUSES = ["Draft"];
const ACTIVE_INVOICE_STATUSES = ["Draft", "Submitted", "Approved", "Paid"];
const INTERNAL_TYPES = ["admin", "internal"];
const VENDOR_TYPE = "vendor";
const MAX_PAGE = 200;
const MAX_ATTACHMENTS = 10;
const MAX_FILE_BYTES = 10 * 1024 * 1024;

export class InvoiceServiceError extends Error {
    constructor(message, { code = "INVOICE_ERROR", statusCode = 400, details = undefined } = {}) {
        super(message);
        this.name = "InvoiceServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, InvoiceServiceError);
    }
}

const text = (value) => (typeof value === "string" ? value.trim() : "");
const num = (value, fallback = 0) => {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
};

function oid(value, field = "id") {
    if (!value) return null;
    if (!mongoose.isValidObjectId(value)) {
        throw new InvoiceServiceError(`Invalid ${field}.`, {
            code: `INVALID_${String(field).toUpperCase()}`,
            statusCode: 422,
        });
    }
    return new mongoose.Types.ObjectId(value);
}

function actorId(actor) {
    return actor?.userId && mongoose.isValidObjectId(actor.userId)
        ? new mongoose.Types.ObjectId(actor.userId)
        : null;
}
function actorVendorId(actor) {
    return actor?.vendorId && mongoose.isValidObjectId(actor.vendorId)
        ? new mongoose.Types.ObjectId(actor.vendorId)
        : null;
}
function isVendor(actor) {
    return String(actor?.userType || "").toLowerCase() === VENDOR_TYPE;
}
function isInternal(actor) {
    return INTERNAL_TYPES.includes(String(actor?.userType || "").toLowerCase());
}
function dateValue(value, field = "date") {
    if (value === undefined || value === null || value === "") return null;
    const parsed = value instanceof Date ? new Date(value.getTime()) : new Date(value);
    if (Number.isNaN(parsed.getTime())) {
        throw new InvoiceServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 });
    }
    return parsed;
}
function money(value) {
    return Math.round((num(value) + Number.EPSILON) * 100) / 100;
}
function serialize(doc) {
    return doc?.toSafeJSON ? doc.toSafeJSON() : doc?.toJSON ? doc.toJSON() : doc;
}
function safeRegex(value) {
    return new RegExp(text(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
}

async function nextInvoiceNumber() {
    const row = await MasterRateSequence.findOneAndUpdate(
        { _id: "invoice" },
        { $inc: { value: 1 } },
        { upsert: true, new: true, setDefaultsOnInsert: true },
    ).lean();
    const sequence = Math.max(1, Math.floor(num(row?.value)));
    return `INV-${new Date().getFullYear()}-${String(sequence).padStart(3, "0")}`;
}

async function audit(action, invoice, actor, request, metadata = {}, changes = null) {
    try {
        await auditService.recordAudit({
            action,
            module: "invoice",
            title: `Invoice ${action.replace(/_/g, " ")}`,
            description: invoice?.invoiceNo || "",
            actor: actor?.actor || actor || null,
            request,
            entityType: "invoice",
            entityId: String(invoice?._id || ""),
            entityName: invoice?.invoiceNo || invoice?.projectName || "",
            vendorId: invoice?.vendorId || null,
            metadata,
            changes,
        });
    } catch (error) {
        console.error("[invoiceService] audit write failed", error);
    }
}

function assertAuthenticatedActor(actor) {
    if (!actor?.userId || !mongoose.isValidObjectId(actor.userId)) {
        throw new InvoiceServiceError("Authenticated identity is required.", {
            code: "AUTHENTICATION_REQUIRED",
            statusCode: 401,
        });
    }
    if (!isInternal(actor) && !isVendor(actor)) {
        throw new InvoiceServiceError("This account cannot access invoices.", {
            code: "INVOICE_ACCESS_FORBIDDEN",
            statusCode: 403,
        });
    }
}

function assertVendorOwns(row, actor) {
    if (!isVendor(actor)) return;
    const vendorId = actorVendorId(actor);
    if (!vendorId || String(row.vendorId) !== String(vendorId)) {
        throw new InvoiceServiceError("You can only access invoices for your vendor account.", {
            code: "VENDOR_SCOPE_FORBIDDEN",
            statusCode: 403,
        });
    }
}

function normalizeSchedule(quotation) {
    const raw = Array.isArray(quotation?.paymentSchedule) ? quotation.paymentSchedule : [];
    if (raw.length) {
        return raw.map((item, index) => ({
            index,
            id: item?._id ? String(item._id) : String(index),
            name: text(item?.name) || `Installment ${index + 1}`,
            amount: money(item?.amount),
            type: text(item?.type) || "custom",
            dueDate: item?.dueDate || null,
        }));
    }
    return [{
        index: 0,
        id: "0",
        name: "Contract Invoice",
        amount: money(quotation?.grandTotal),
        type: "balance",
        dueDate: quotation?.dueDate || null,
    }];
}

function isInvoiceActive(row) {
    return ACTIVE_INVOICE_STATUSES.includes(row.status);
}

async function findInvoiceById(id) {
    const invoice = await Invoice.findById(oid(id, "invoiceId"));
    if (!invoice) {
        throw new InvoiceServiceError("Invoice was not found.", { code: "INVOICE_NOT_FOUND", statusCode: 404 });
    }
    return invoice;
}

async function loadQuotationAndProject(quotationId) {
    const quotation = await Quotation.findById(oid(quotationId, "quotationId"));
    if (!quotation) {
        throw new InvoiceServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    }
    if (!Object.prototype.hasOwnProperty.call(quotation, "status") || String(quotation.status) !== "Awarded") {
        throw new InvoiceServiceError("Only awarded quotations are available for invoice generation.", {
            code: "QUOTATION_NOT_AWARDED",
            statusCode: 409,
        });
    }
    const vendor = await Vendor.findById(quotation.vendorId).lean();
    if (!vendor) {
        throw new InvoiceServiceError("The vendor linked to this awarded quotation was not found.", {
            code: "VENDOR_NOT_FOUND_FOR_QUOTATION",
            statusCode: 409,
        });
    }
    if (String(vendor.accountStatus || "").toUpperCase() !== "APPROVED") {
        throw new InvoiceServiceError("Invoices can only be generated for an approved vendor.", {
            code: "VENDOR_NOT_APPROVED",
            statusCode: 409,
        });
    }

    let project = await Project.findOne({ sourceQuotationId: quotation._id });
    if (!project) {
        project = await Project.findOne({ sourceQuotationNo: quotation.quotationNo });
    }
    if (!project) {
        throw new InvoiceServiceError("The project linked to this awarded quotation was not found.", {
            code: "PROJECT_NOT_FOUND_FOR_QUOTATION",
            statusCode: 409,
        });
    }
    return { quotation, project, vendor };
}

function scheduleUsageMap(invoices) {
    const map = new Map();
    for (const row of invoices) {
        if (!isInvoiceActive(row)) continue;
        for (const index of row.installmentIndexes || []) {
            if (!map.has(index)) map.set(index, []);
            map.get(index).push(row);
        }
    }
    return map;
}

function summarizeSchedule(schedule, usage) {
    return schedule.map((item) => {
        const rows = usage.get(item.index) || [];
        const paid = rows.some((row) => row.status === "Paid");
        return {
            ...item,
            invoiced: rows.length > 0,
            paid,
            available: rows.length === 0,
            invoiceIds: rows.map((row) => String(row._id)),
            status: paid ? "Paid" : rows.length ? rows[0].status : "Pending",
        };
    });
}

function moduleItems(quotation) {
    const rows = Array.isArray(quotation?.lines) ? quotation.lines : [];
    const grouped = new Map();
    for (const row of rows) {
        const name = text(row?.module) || text(row?.description) || "Module Item";
        const key = name;
        grouped.set(key, money(num(grouped.get(key), 0) + num(row?.lineTotal ?? num(row?.quantity) * num(row?.vendorRate))));
    }
    return Array.from(grouped.entries()).map(([name, rate]) => ({ name, rate }));
}

function cumulativeInvoiceFilter(quotationId, excludeId = null) {
    return {
        quotationId,
        status: { $in: ACTIVE_INVOICE_STATUSES },
        ...(excludeId ? { _id: { $ne: excludeId } } : {}),
    };
}

async function assertWithinProjectValue({ project, quotationId, amount, excludeInvoiceId = null }) {
    const current = await Invoice.aggregate([
        { $match: cumulativeInvoiceFilter(quotationId, excludeInvoiceId) },
        { $group: { _id: null, total: { $sum: "$totalAmount" } } },
    ]);
    const used = money(current?.[0]?.total || 0);
    const ceiling = money(project.projectValue || 0);
    if (money(used + amount) > ceiling + 0.009) {
        throw new InvoiceServiceError(
            `Cumulative invoiced amount cannot exceed the project value. Remaining balance is ${money(Math.max(0, ceiling - used)).toFixed(2)}.`,
            {
                code: "INVOICE_PROJECT_VALUE_EXCEEDED",
                statusCode: 422,
                details: {
                    projectValue: ceiling,
                    invoicedAmount: used,
                    requestedAmount: money(amount),
                    remainingAmount: money(Math.max(0, ceiling - used)),
                },
            },
        );
    }
}

function getSelectedIndexes(payload) {
    const raw = payload?.installmentIndexes ?? payload?.installments ?? [];
    if (Array.isArray(raw) && raw.length) {
        const values = raw.map((value) => Number.parseInt(String(value), 10));
        if (values.some((value) => !Number.isInteger(value) || value < 0)) {
            throw new InvoiceServiceError("Invalid installment selection.", { code: "INVALID_INSTALLMENT_SELECTION", statusCode: 422 });
        }
        return Array.from(new Set(values));
    }
    return [0];
}

async function validateInvoicePayload(payload, { quotation, project, existingId = null } = {}) {
    const requestedCurrency = text(payload?.currency).toUpperCase();
    const quotationCurrency = text(quotation?.currency).toUpperCase();
    if (requestedCurrency && quotationCurrency && requestedCurrency !== quotationCurrency) {
        throw new InvoiceServiceError("Invoice currency must match the awarded quotation currency.", {
            code: "INVOICE_CURRENCY_MISMATCH",
            statusCode: 422,
            details: { quotationCurrency, requestedCurrency },
        });
    }

    const schedule = normalizeSchedule(quotation);
    const indexes = getSelectedIndexes(payload);
    const chosen = [];
    for (const index of indexes) {
        const item = schedule[index];
        if (!item) {
            throw new InvoiceServiceError("One or more selected installments are invalid.", { code: "INSTALLMENT_NOT_FOUND", statusCode: 422 });
        }
        chosen.push(item);
    }

    const existing = await Invoice.find(cumulativeInvoiceFilter(quotation._id, existingId)).lean();
    const usage = scheduleUsageMap(existing);
    for (const index of indexes) {
        const rows = usage.get(index) || [];
        if (rows.length) {
            throw new InvoiceServiceError(`Installment ${index + 1} has already been invoiced.`, {
                code: "INSTALLMENT_ALREADY_INVOICED",
                statusCode: 409,
                details: { installmentIndex: index, invoiceIds: rows.map((row) => String(row._id)) },
            });
        }
    }

    const subtotal = money(chosen.reduce((sum, item) => sum + money(item.amount), 0));
    const requestedSubtotal = payload?.subtotal !== undefined ? money(payload.subtotal) : subtotal;
    if (Math.abs(requestedSubtotal - subtotal) > 0.009) {
        throw new InvoiceServiceError("Invoice amount must match the selected installment total.", {
            code: "INVOICE_AMOUNT_MISMATCH",
            statusCode: 422,
            details: { expectedSubtotal: subtotal, receivedSubtotal: requestedSubtotal },
        });
    }
    const taxRate = Math.max(0, Math.min(100, num(payload?.taxRatePercent ?? payload?.taxRate, 0)));
    const taxAmount = money(subtotal * taxRate / 100);
    const totalAmount = money(subtotal + taxAmount);

    await assertWithinProjectValue({ project, quotationId: quotation._id, amount: totalAmount, excludeInvoiceId: existingId });

    const dueDate = dateValue(payload?.dueDate ?? chosen[chosen.length - 1]?.dueDate ?? quotation.dueDate, "dueDate");
    const siteReference = text(payload?.siteReference ?? quotation.projectSiteLocation);
    const milestoneName = text(payload?.milestoneName) || chosen.map((item) => item.name).join(", ");
    return {
        schedule,
        indexes,
        chosen,
        subtotal,
        taxRate,
        taxAmount,
        totalAmount,
        dueDate,
        siteReference,
        milestoneName,
        installmentNames: chosen.map((item) => item.name),
    };
}

function fileSizeValid(file) {
    return file && Number(file.size || 0) > 0 && Number(file.size || 0) <= MAX_FILE_BYTES;
}

async function storeAttachments(files, invoiceId, actor) {
    const input = Array.isArray(files) ? files.filter(Boolean) : [];
    if (input.length > MAX_ATTACHMENTS) {
        throw new InvoiceServiceError(`A maximum of ${MAX_ATTACHMENTS} attachments is allowed.`, {
            code: "TOO_MANY_ATTACHMENTS",
            statusCode: 422,
        });
    }
    const created = [];
    try {
        for (const file of input) {
            if (!fileSizeValid(file)) {
                throw new InvoiceServiceError("Each invoice attachment must be smaller than 10 MB.", {
                    code: "INVOICE_ATTACHMENT_TOO_LARGE",
                    statusCode: 422,
                });
            }
            const ext = text(file.originalname).includes(".") ? text(file.originalname).split(".").pop().toLowerCase() : "";
            const storage = await storageService.saveBuffer({
                buffer: file.buffer,
                context: "invoice",
                filename: `invoice_${invoiceId}_${randomUUID()}.${ext || "bin"}`,
            });
            const metadata = await storageService.buildFileMetadata({
                storageKey: storage.storageKey,
                originalName: file.originalname,
                mimeType: file.mimetype || "application/octet-stream",
                extension: ext,
                uploadedBy: actorId(actor),
            });
            const row = await InvoiceAttachment.create({
                invoiceId,
                originalName: metadata.originalName,
                storageKey: metadata.storageKey,
                relativePath: metadata.relativePath,
                mimeType: metadata.mimeType,
                extension: metadata.extension,
                size: metadata.size,
                checksum: metadata.checksum,
                category: "supporting_document",
                uploadedBy: metadata.uploadedBy,
                uploadedAt: metadata.uploadedAt,
            });
            created.push(row);
        }
        return created;
    } catch (error) {
        await Promise.all(created.map(async (row) => {
            try { await storageService.deleteFile?.(row.storageKey); } catch { /* best effort */ }
        }));
        throw error;
    }
}

async function attachSafeData(invoice) {
    const [attachments, payment] = await Promise.all([
        InvoiceAttachment.find({ invoiceId: invoice._id }).sort({ createdAt: 1, _id: 1 }),
        Payment.findOne({ invoiceId: invoice._id }),
    ]);
    const result = serialize(invoice);
    result.attachments = attachments.map(serialize);
    result.payment = payment ? serialize(payment) : null;
    return result;
}

export async function listInvoices({ actor, page = 1, limit = 50, search = "", status = "" } = {}) {
    assertAuthenticatedActor(actor);
    const safePage = Math.max(1, Number.parseInt(String(page), 10) || 1);
    const safeLimit = Math.min(MAX_PAGE, Math.max(1, Number.parseInt(String(limit), 10) || 50));
    const filter = {};
    if (isVendor(actor)) {
        const vendorId = actorVendorId(actor);
        if (!vendorId) {
            throw new InvoiceServiceError("Vendor identity is not available.", { code: "VENDOR_ID_REQUIRED", statusCode: 403 });
        }
        filter.vendorId = vendorId;
    }
    const wantedStatus = text(status);
    if (wantedStatus) {
        if (wantedStatus === "Overdue") {
            filter.status = { $in: ["Draft", "Submitted", "Approved"] };
            filter.dueDate = { $lt: new Date() };
        } else if (INVOICE_STATUSES.includes(wantedStatus)) {
            filter.status = wantedStatus;
        }
    }
    const term = text(search);
    if (term) {
        const regex = safeRegex(term);
        filter.$or = [
            { invoiceNo: regex },
            { vendorName: regex },
            { projectName: regex },
            { quotationNo: regex },
        ];
    }
    const [rows, total] = await Promise.all([
        Invoice.find(filter).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit),
        Invoice.countDocuments(filter),
    ]);
    return {
        data: rows.map(serialize),
        pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) },
    };
}

export async function getInvoice(id, { actor } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(id);
    assertVendorOwns(invoice, actor);

    const [detail, project, tasks, quotation] = await Promise.all([
        attachSafeData(invoice),
        Project.findById(invoice.projectId).lean(),
        Task.find({ projectId: invoice.projectId }).sort({ phaseId: 1, createdAt: 1, _id: 1 }),
        Quotation.findById(invoice.quotationId).lean(),
    ]);

    const phaseMap = new Map();
    for (const task of tasks) {
        const phaseKey = String(task.phaseId || "no-phase");
        const phaseName = text(task.phaseName) || "Project Tasks";
        if (!phaseMap.has(phaseKey)) phaseMap.set(phaseKey, { name: phaseName, tasks: [] });
        phaseMap.get(phaseKey).tasks.push({
            id: String(task._id),
            name: task.title,
            status: text(task.status) || "Pending",
            progress: num(task.progress),
        });
    }
    const phaseRows = Array.from(phaseMap.values());
    const progress = project ? num(project.progressPercentage) : 0;
    detail.auditTrace = {
        projectId: project ? String(project._id) : String(invoice.projectId),
        projectName: project?.name || invoice.projectName,
        progress,
        phases: phaseRows,
    };
    detail.milestoneModules = moduleItems(quotation);
    return detail;
}

export async function listAvailableQuotations({ actor, page = 1, limit = 50, search = "" } = {}) {
    assertAuthenticatedActor(actor);
    const safePage = Math.max(1, Number.parseInt(String(page), 10) || 1);
    const safeLimit = Math.min(MAX_PAGE, Math.max(1, Number.parseInt(String(limit), 10) || 50));
    const q = { status: "Awarded" };
    if (isVendor(actor)) {
        const vendorId = actorVendorId(actor);
        if (!vendorId) {
            throw new InvoiceServiceError("Vendor identity is not available.", { code: "VENDOR_ID_REQUIRED", statusCode: 403 });
        }
        q.vendorId = vendorId;
    }
    const term = text(search);
    if (term) {
        const regex = safeRegex(term);
        q.$or = [{ quotationNo: regex }, { vendorName: regex }, { projectTitle: regex }];
    }
    const quotations = await Quotation.find(q).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit).lean();
    const total = await Quotation.countDocuments(q);
    const rows = [];
    for (const quotation of quotations) {
        const project = await Project.findOne({
            $or: [
                { sourceQuotationId: quotation._id },
                { sourceQuotationNo: quotation.quotationNo },
            ],
        }).lean();
        if (!project) continue;
        if (isVendor(actor) && String(project.vendorId) !== String(actorVendorId(actor))) continue;
        const invoices = await Invoice.find({ quotationId: quotation._id }).sort({ createdAt: 1, _id: 1 }).lean();
        const schedule = normalizeSchedule(quotation);
        const scheduleSummary = summarizeSchedule(schedule, scheduleUsageMap(invoices));
        const activeInvoices = invoices.filter(isInvoiceActive);
        const paidInvoices = activeInvoices.filter((row) => row.status === "Paid");
        const billedTotal = money(activeInvoices.reduce((sum, row) => sum + num(row.totalAmount), 0));
        rows.push({
            id: String(quotation._id),
            quotationId: String(quotation._id),
            projectId: String(project._id),
            quotationNo: quotation.quotationNo,
            projectTitle: quotation.projectTitle,
            vendor: quotation.vendorName,
            vendorId: String(quotation.vendorId),
            contractValue: money(quotation.grandTotal),
            currency: quotation.currency || "USD",
            status: "Approved",
            sourceStatus: quotation.status,
            totalInstallments: scheduleSummary.length,
            pendingInstallments: scheduleSummary.filter((item) => item.available).length,
            invoicesGenerated: activeInvoices.length,
            invoicesPaid: paidInvoices.length,
            balanceAmount: money(Math.max(0, num(project.projectValue || quotation.grandTotal) - billedTotal)),
            remarks: text(quotation.award?.remarks),
            paymentSchedule: scheduleSummary,
            moduleItems: moduleItems(quotation),
        });
    }
    return {
        data: rows,
        pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) },
    };
}

export async function getInvoiceCreationContext(quotationId, { actor } = {}) {
    assertAuthenticatedActor(actor);
    const { quotation, project } = await loadQuotationAndProject(quotationId);
    if (isVendor(actor) && String(quotation.vendorId) !== String(actorVendorId(actor))) {
        throw new InvoiceServiceError("You can only generate invoices for your vendor's awarded projects.", {
            code: "VENDOR_SCOPE_FORBIDDEN",
            statusCode: 403,
        });
    }
    const [invoices, tasks] = await Promise.all([
        Invoice.find({ quotationId: quotation._id }).sort({ createdAt: 1, _id: 1 }).lean(),
        Task.find({ projectId: project._id }).sort({ phaseId: 1, createdAt: 1, _id: 1 }).lean(),
    ]);
    const schedule = summarizeSchedule(normalizeSchedule(quotation), scheduleUsageMap(invoices));
    return {
        quotation: serialize(quotation),
        project: project.toSafeJSON ? project.toSafeJSON() : project,
        paymentSchedule: schedule,
        moduleItems: moduleItems(quotation),
        tasks: tasks.map((task) => ({
            id: String(task._id),
            title: task.title,
            description: task.description || "",
            status: task.status || "Pending",
            progress: num(task.progress),
            priority: task.priority || "Medium",
            estimatedHours: num(task.estimatedHours),
        })),
        balanceAmount: money(Math.max(0, num(project.projectValue || quotation.grandTotal) - invoices.filter(isInvoiceActive).reduce((sum, row) => sum + num(row.totalAmount), 0))),
    };
}

export async function createInvoice(payload, files = [], { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    const quotationId = oid(payload?.quotationId, "quotationId");
    const { quotation, project } = await loadQuotationAndProject(quotationId);
    if (isVendor(actor) && String(quotation.vendorId) !== String(actorVendorId(actor))) {
        throw new InvoiceServiceError("You can only create invoices for your vendor account.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
    }
    const calculation = await validateInvoicePayload(payload, { quotation, project });
    const requestedStatus = text(payload?.status) || "Draft";
    if (!INVOICE_STATUSES.includes(requestedStatus) || !["Draft", "Submitted"].includes(requestedStatus)) {
        throw new InvoiceServiceError("Invoice can only be created as Draft or Submitted.", { code: "INVALID_INVOICE_STATUS", statusCode: 422 });
    }
    const invoice = await Invoice.create({
        invoiceNo: await nextInvoiceNumber(),
        quotationId: quotation._id,
        projectId: project._id,
        vendorId: quotation.vendorId,
        vendorName: quotation.vendorName,
        projectName: quotation.projectTitle,
        quotationNo: quotation.quotationNo,
        currency: quotation.currency || "USD",
        siteReference: calculation.siteReference,
        milestoneName: calculation.milestoneName,
        installmentIndexes: calculation.indexes,
        installmentNames: calculation.installmentNames,
        subtotal: calculation.subtotal,
        taxRate: calculation.taxRate,
        taxAmount: calculation.taxAmount,
        totalAmount: calculation.totalAmount,
        dueDate: calculation.dueDate,
        issuedDate: requestedStatus === "Submitted" ? new Date() : null,
        status: requestedStatus,
        remarks: text(payload?.remarks),
        submittedAt: requestedStatus === "Submitted" ? new Date() : null,
        revision: 1,
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });

    let attachments = [];
    try {
        attachments = await storeAttachments(files, invoice._id, actor);
        if (requestedStatus === "Submitted") {
            await notifyWorkspaceOwners({
                eventType: "invoice_submitted",
                title: "Invoice submitted for review",
                message: `${invoice.invoiceNo} was submitted by ${invoice.vendorName}.`,
                payload: { invoiceId: String(invoice._id), quotationId: String(quotation._id), projectId: String(project._id) },
                excludeUserId: actor?.userId,
            });
        }
        await audit(requestedStatus === "Submitted" ? "submitted" : "created", invoice, actor, request, {
            quotationId: String(quotation._id),
            projectId: String(project._id),
            installmentIndexes: calculation.indexes,
        });
    } catch (error) {
        await Promise.all(attachments.map(async (row) => { try { await storageService.deleteFile?.(row.storageKey); } catch {} }));
        await InvoiceAttachment.deleteMany({ invoiceId: invoice._id });
        await Invoice.deleteOne({ _id: invoice._id });
        throw error;
    }
    return attachSafeData(invoice);
}

export async function updateInvoice(id, payload, files = [], { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(id);
    assertVendorOwns(invoice, actor);
    if (!EDITABLE_STATUSES.includes(invoice.status)) {
        throw new InvoiceServiceError("Only draft invoices can be edited.", { code: "INVOICE_NOT_EDITABLE", statusCode: 409 });
    }
    const { quotation, project } = await loadQuotationAndProject(invoice.quotationId);
    const calculation = await validateInvoicePayload(payload, { quotation, project, existingId: invoice._id });
    const before = {
        dueDate: invoice.dueDate,
        siteReference: invoice.siteReference,
        subtotal: invoice.subtotal,
        taxRate: invoice.taxRate,
        taxAmount: invoice.taxAmount,
        totalAmount: invoice.totalAmount,
        installmentIndexes: invoice.installmentIndexes,
    };
    invoice.siteReference = calculation.siteReference;
    invoice.milestoneName = calculation.milestoneName;
    invoice.installmentIndexes = calculation.indexes;
    invoice.installmentNames = calculation.installmentNames;
    invoice.subtotal = calculation.subtotal;
    invoice.taxRate = calculation.taxRate;
    invoice.taxAmount = calculation.taxAmount;
    invoice.totalAmount = calculation.totalAmount;
    invoice.dueDate = calculation.dueDate;
    if (payload?.remarks !== undefined) invoice.remarks = text(payload.remarks);
    invoice.updatedBy = actorId(actor);
    await invoice.save();
    if (files.length) await storeAttachments(files, invoice._id, actor);
    await audit("updated", invoice, actor, request, {}, { before, after: { dueDate: invoice.dueDate, siteReference: invoice.siteReference, subtotal: invoice.subtotal, taxRate: invoice.taxRate, totalAmount: invoice.totalAmount, installmentIndexes: invoice.installmentIndexes } });
    return attachSafeData(invoice);
}

export async function submitInvoice(id, { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(id);
    assertVendorOwns(invoice, actor);
    if (invoice.status !== "Draft") {
        throw new InvoiceServiceError("Only draft invoices can be submitted.", { code: "INVOICE_NOT_SUBMITTABLE", statusCode: 409 });
    }
    const { quotation, project } = await loadQuotationAndProject(invoice.quotationId);
    await assertWithinProjectValue({ project, quotationId: quotation._id, amount: num(invoice.totalAmount), excludeInvoiceId: invoice._id });
    invoice.status = "Submitted";
    invoice.submittedAt = new Date();
    invoice.issuedDate = new Date();
    invoice.updatedBy = actorId(actor);
    await invoice.save();
    await audit("submitted", invoice, actor, request);
    await notifyWorkspaceOwners({
        eventType: "invoice_submitted",
        title: "Invoice submitted for review",
        message: `${invoice.invoiceNo} was submitted by ${invoice.vendorName}.`,
        payload: { invoiceId: String(invoice._id), projectId: String(invoice.projectId) },
        excludeUserId: actor?.userId,
    }).catch(() => undefined);
    return attachSafeData(invoice);
}

export async function approveInvoice(id, remarks = "", { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    if (!isInternal(actor)) throw new InvoiceServiceError("Only internal users can approve invoices.", { code: "INVOICE_APPROVAL_FORBIDDEN", statusCode: 403 });
    const invoice = await findInvoiceById(id);
    if (invoice.status !== "Submitted") throw new InvoiceServiceError("Only submitted invoices can be approved.", { code: "INVOICE_NOT_REVIEWABLE", statusCode: 409 });
    invoice.status = "Approved";
    invoice.reviewedAt = new Date();
    invoice.reviewedBy = actorId(actor);
    invoice.rejectionRemarks = "";
    if (text(remarks)) invoice.remarks = text(remarks);
    invoice.updatedBy = actorId(actor);
    await invoice.save();
    await audit("approved", invoice, actor, request, { remarks: text(remarks) });
    if (invoice.vendorId) {
        try {
            const vendorUsers = await mongoose.model("User").find({ vendorId: invoice.vendorId, userType: "vendor", status: "active" }).select("_id").lean();
            await Promise.all(vendorUsers.map((user) => notificationService.createNotification({
                recipientId: user._id,
                eventType: "invoice_approved",
                title: "Invoice approved",
                message: `${invoice.invoiceNo} has been approved.`,
                payload: { invoiceId: String(invoice._id), projectId: String(invoice.projectId) },
            })));
        } catch (error) { console.error("[invoiceService] vendor notification failed", error); }
    }
    return attachSafeData(invoice);
}

export async function rejectInvoice(id, remarks, { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    if (!isInternal(actor)) throw new InvoiceServiceError("Only internal users can reject invoices.", { code: "INVOICE_REJECTION_FORBIDDEN", statusCode: 403 });
    const normalizedRemarks = text(remarks);
    if (!normalizedRemarks) throw new InvoiceServiceError("Rejection remarks are required.", { code: "REJECTION_REMARKS_REQUIRED", statusCode: 422 });
    const invoice = await findInvoiceById(id);
    if (invoice.status !== "Submitted") throw new InvoiceServiceError("Only submitted invoices can be rejected.", { code: "INVOICE_NOT_REVIEWABLE", statusCode: 409 });
    invoice.status = "Rejected";
    invoice.reviewedAt = new Date();
    invoice.reviewedBy = actorId(actor);
    invoice.rejectionRemarks = normalizedRemarks;
    invoice.updatedBy = actorId(actor);
    await invoice.save();
    await audit("rejected", invoice, actor, request, { remarks: normalizedRemarks });
    if (invoice.vendorId) {
        try {
            const vendorUsers = await mongoose.model("User").find({ vendorId: invoice.vendorId, userType: "vendor", status: "active" }).select("_id").lean();
            await Promise.all(vendorUsers.map((user) => notificationService.createNotification({
                recipientId: user._id,
                eventType: "invoice_rejected",
                title: "Invoice rejected",
                message: `${invoice.invoiceNo} was rejected.`,
                payload: { invoiceId: String(invoice._id), projectId: String(invoice.projectId), remarks: normalizedRemarks },
            })));
        } catch (error) { console.error("[invoiceService] vendor rejection notification failed", error); }
    }
    return attachSafeData(invoice);
}

export async function deleteInvoice(id, { actor, request = null } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(id);
    assertVendorOwns(invoice, actor);
    if (invoice.status !== "Draft") throw new InvoiceServiceError("Only draft invoices can be deleted.", { code: "INVOICE_DELETE_FORBIDDEN", statusCode: 409 });
    const attachments = await InvoiceAttachment.find({ invoiceId: invoice._id });
    await Promise.all(attachments.map(async (row) => { try { await storageService.deleteFile?.(row.storageKey); } catch {} }));
    await InvoiceAttachment.deleteMany({ invoiceId: invoice._id });
    await Invoice.deleteOne({ _id: invoice._id });
    await audit("deleted", invoice, actor, request);
    return { id: String(invoice._id), invoiceNo: invoice.invoiceNo, deleted: true };
}

export async function listInvoicePayments(invoiceId, { actor } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(invoiceId);
    assertVendorOwns(invoice, actor);
    const rows = await Payment.find({ invoiceId: invoice._id }).sort({ recordedAt: -1, _id: -1 });
    return rows.map(serialize);
}

export async function getInvoiceAttachment(invoiceId, attachmentId, { actor } = {}) {
    assertAuthenticatedActor(actor);
    const invoice = await findInvoiceById(invoiceId);
    assertVendorOwns(invoice, actor);
    const attachment = await InvoiceAttachment.findOne({ _id: oid(attachmentId, "attachmentId"), invoiceId: invoice._id });
    if (!attachment) throw new InvoiceServiceError("Invoice attachment was not found.", { code: "INVOICE_ATTACHMENT_NOT_FOUND", statusCode: 404 });
    const stream = await storageService.createReadStream(attachment.storageKey);
    return { attachment, stream };
}
