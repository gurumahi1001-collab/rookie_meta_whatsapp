@php
$containerNav = $containerNav ?? 'container-fluid';
$navbarDetached = ($navbarDetached ?? '');
@endphp
<style>
    .navbar-search-wrapper {
        position: relative;
        width: 250px;
        /* adjust width as needed */
    }

    .navbar-search-wrapper input.form-control {
        width: 100%;
        padding-left: 40px;
        /* space for the icon */
        border-radius: 12px;
        background: rgba(153, 152, 152, 0.2);
        border-right: 1px solid #eee;
        /* backdrop-filter: blur(8px);
  border: 1px solid rgba(0,0,0,0.2); */
        color: #000;
    }

    .navbar-search-wrapper i.mdi {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        pointer-events: none;
        /* so click goes to input */
        color: black;
    }
</style>

@php
$menuName ='Settings';
$user_id = auth()->user()->user_id;
$helper = new \App\Helpers\Helpers();
$entity_data = $helper->get_entity_access_list($user_id);
$active_entity_list = $helper->get_entity_list();
$entity_list = $entity_data['enity_list'];
@endphp
@php

@endphp

<!-- Navbar -->
@if(isset($navbarDetached) && $navbarDetached == 'navbar-detached')
<nav class="layout-navbar {{$containerNav}} navbar navbar-expand-xl {{$navbarDetached}} align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
    @endif
    @if(isset($navbarDetached) && $navbarDetached == '')
    <nav class="layout-navbar navbar navbar-expand-xl align-items-center" style="background-color: #ffffff !important;" id="layout-navbar">
        <div class="{{$containerNav}}">
            @endif

            <!--  Brand demo (display only for navbar-full and hide on below xl) -->
            @if(isset($navbarFull))
            <div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
                <a href="{{url('/')}}" class="app-brand-link gap-2">
                    <img src="{{asset('assets/common/logo_full.png')}}" class="app-brand-logo demo" alt="EGC Logo">
                    <span class="app-brand-text demo menu-text fw-bold">EGC</span>
                </a>
                @if(isset($menuHorizontal))
                <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                    <i class="mdi mdi-close align-middle"></i>
                </a>
                @endif
            </div>
            @endif


            <!-- ! Not required for layout-without-menu -->
            @if(!isset($navbarHideToggle))
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0{{ isset($menuHorizontal) ? ' d-xl-none ' : '' }} {{ isset($contentNavbar) ?' d-xl-none ' : '' }}">
                <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                    <i class="mdi mdi-menu mdi-24px"></i>
                </a>
            </div>
            @endif

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

                <ul class="navbar-nav flex-row align-items-center ms-auto mx-4 px-2">
                    <!-- Search -->
                    <!-- <li class="nav-item me-2 me-xl-1">
              <form id="switch-erp-form" action="{{ route('switch.erp.portal') }}" method="POST" style="display:none;">
                  @csrf
                  <input type="hidden" name="switch_entity_id" id="switch_entity_id">
              </form>
              @if(Auth::user()->staff->company_type == 2)
              <button type="button" id="switch-erp-btn-self" class="btn btn-sm btn-primary" onclick="switchErp('{{Auth::user()->staff->entity_id}}')">
                <span class="me-2"><i class="mdi mdi-home-switch-outline"></i></span>
                  Switch ERP
              </button>
              @else
              <div class="position-relative">
                 @if(Auth::user()->staff->role_id == 1)
                <button type="button" id="switch-erp-btn" class="btn btn-sm btn-primary " data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                  <span class="me-2"><i class="mdi mdi-home-switch-outline"></i></span>
                    Switch ERP 
                </button>
                @endif
                <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                    <button type="button" class="dropdown-item" onclick="switchErp('1')">ETPL</button>
                    <button type="button" class="dropdown-item" onclick="switchErp('2')">EAPL</button>
                    <button type="button" class="dropdown-item" onclick="switchErp('3')">EIBS</button>
                </div>
              </div>
              @endif

            </li> -->
                    <style>
                        .erp-switch-pill {
                            display: flex;
                            align-items: center;
                            gap: 8px;
                            padding: 5px 10px;
                            border-radius: 999px;
                            background: #fff;
                            border: 1px solid rgba(0, 0, 0, 0.06);
                            cursor: pointer;
                            transition: all 0.25s ease;
                            height: 34px;
                            position: relative;
                        }

                        .erp-switch-pill:hover {
                            transform: translateY(-1px);
                            box-shadow: 0 6px 14px rgba(0, 0, 0, 0.08);
                        }

                        .erp-pill-logo {
                            width: 24px;
                            height: 24px;
                            border-radius: 6px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            overflow: hidden;
                        }

                        .erp-pill-logo img {
                            width: 70%;
                        }

                        .erp-pill-text {
                            font-size: 12px;
                            font-weight: 600;
                            color: #333;
                            white-space: nowrap;
                        }

                        .erp-pill-indicator {
                            width: 6px;
                            height: 6px;
                            background: #10b981;
                            border-radius: 50%;
                        }

                        .erp-switch-pill::after {
                            content: "";
                            position: absolute;
                            inset: 0;
                            border-radius: 999px;
                            background: linear-gradient(120deg, transparent, rgba(255, 255, 255, 0.6), transparent);
                            opacity: 0;
                            transition: 0.4s;
                        }

                        .erp-switch-pill:hover::after {
                            opacity: 1;
                        }

                        .erp-switch-menu {
                            width: 260px;
                            border-radius: 14px;
                            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
                        }

                        .erp-switch-item {
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            padding: 8px;
                            border-radius: 10px;
                            cursor: pointer;
                            transition: all 0.25s ease;
                        }

                        .erp-switch-item:hover {
                            background: rgba(250, 184, 69, 0.15);
                            border-left: 4px solid var(--entity-color);
                            transform: translateX(4px);
                        }

                        .erp-name {
                            font-size: 13px;
                            font-weight: 600;
                        }

                        .erp-active-dot {
                            width: 7px;
                            height: 7px;
                            background: #10b981;
                            border-radius: 50%;
                        }
                    </style>
                    @if(isset($entity_list))
                    @if(count($entity_list)>0)
                    <li class="nav-item me-2 me-xl-1 d-flex align-items-center">

                        <form id="switch-erp-form" action="{{ route('switch.erp.portal') }}" method="POST" style="display:none;">
                            @csrf
                            <input type="hidden" name="switch_entity_id" id="switch_entity_id">
                        </form>

                        @php
                        @if(count($entity_list) == 1)
                        <div class="erp-switch-pill" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Switch Workspace"
                            onclick="switchErp('{{ $entity_list[0]->sno }}')" style="border-color: {{ $entity_list[0]->entity_base_color }}33">

                            <!-- Logo -->
                            <div class="erp-pill-logo"
                                style="background: white">
                                <img src="{{ asset('Entity_favicons/'.$entity_list[0]->company_id.'/'.$entity_list[0]->entity_favicon) }}">
                            </div>

                            <!-- Name -->
                            <div class="erp-pill-text">
                                {{ Str::limit($entity_list[0]->entity_name, 18) }}
                            </div>

                            <!-- Indicator -->
                            <div class="erp-pill-indicator"></div>

                        </div>
                        @else

                        <div class="dropdown">

                            <!-- Trigger Pill -->
                            <div class="erp-switch-pill"
                                data-bs-toggle="dropdown"
                                style="border-color: {{ $entity_list[0]->entity_base_color }}33">

                                <div class="erp-pill-logo"
                                    style="background: white">
                                    <img src="{{ asset('Entity_favicons/'.$entity_list[0]->sno.'/'.$entity_list[0]->entity_favicon) }}">
                                </div>

                                <div class="erp-pill-text">
                                    {{ Str::limit($entity_list[0]->entity_name, 15) }}
                                </div>

                                <i class="mdi mdi-chevron-down ms-1 small"></i>
                            </div>

                            <!-- Dropdown Panel -->
                            <div class="dropdown-menu dropdown-menu-end p-2 erp-switch-menu">

                                @foreach($entity_list as $idx=> $entity)
                                <div class="erp-switch-item"
                                    onclick="switchErp('{{ $entity->sno }}')" style="--entity-color: {{ $entity->entity_base_color }};">

                                    <div class="d-flex align-items-center gap-2">

                                        <div class="erp-pill-logo"
                                            style="border: 2px solid {{ $entity->entity_base_color }}">
                                            <img src="{{ asset('Entity_favicons/'.$entity->company_id.'/'.$entity->entity_favicon) }}">
                                        </div>

                                        <div>
                                            <div class="erp-name">
                                                {{ $entity->entity_name }}
                                            </div>
                                            <small class="text-muted">
                                                Workspace
                                            </small>
                                        </div>

                                    </div>

                                    @if(Auth::user()->staff->entity_id == $entity->sno)
                                    <span class="erp-active-dot"></span>
                                    @endif

                                </div>
                                @endforeach

                            </div>

                        </div>

                        @endif

                    </li>
                    @endif
                    @endif
                    <!-- /Search -->
                    <!-- Notification -->
                    @if(auth()->user()->hasPermission($menuName))
                    <li class="nav-item me-2 me-xl-1">
                        <a href="{{ url('/settings/general_settings') }}" aria-expanded="false">
                            <i class="mdi mdi-cog-outline fs-3 text-black"></i>
                        </a>
                    </li>
                    @endif
                    <style>
                        .shadow-img {
                            filter: drop-shadow(0 6px 12px rgba(171, 43, 34, 0.35));
                            transition: all 0.3s ease;
                        }

                        .birthday-card {
                            background: #fff;
                            border-radius: 15px;
                            padding: 15px;
                            text-align: center;
                            transition: 0.3s;
                            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                        }

                        .birthday-card:hover {
                            transform: translateY(-5px);
                            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
                        }

                        .birthday-img {
                            width: 70px;
                            height: 70px;
                            border-radius: 50%;
                            object-fit: cover;
                            border: 3px solid #ff9800;
                            margin-bottom: 10px;
                        }




                        .birthday-card-modern {
                            background: #fff;
                            border-radius: 18px;
                            overflow: hidden;
                            min-height: 250px;
                            transition: 0.3s;
                            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
                            position: relative;
                        }

                        .birthday-card-modern:hover {
                            transform: translateY(-8px);
                            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
                        }

                        .top-bar {
                            padding: 6px;
                            text-align: center;
                            color: #fff;
                            font-size: 12px;
                            font-weight: 600;
                        }

                        .birthday-img-modern {
                            width: 75px;
                            height: 75px;
                            border-radius: 50%;
                            object-fit: fill;
                            margin-top: -30px;
                            border: 4px solid #fff;
                            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                        }

                        .birthday-date {
                            background: #f8f9fa;
                            padding: 5px;
                            border-radius: 10px;
                            font-size: 13px;
                        }

                        .birthday-loader {
                            position: absolute;
                            top: 0;
                            left: 0;
                            right: 0;
                            bottom: 0;
                            background: rgba(255, 255, 255, 0.85);
                            backdrop-filter: blur(6px);
                            z-index: 10;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border-radius: 12px;
                        }

                        .loader-content {
                            padding: 20px 30px;
                            background: #fff;
                            border-radius: 16px;
                            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                        }

                        .dot-loader span {
                            display: inline-block;
                            width: 8px;
                            height: 8px;
                            margin: 0 3px;
                            background: #ab2b22;
                            border-radius: 50%;
                            animation: bounce 1.4s infinite ease-in-out both;
                        }

                        .dot-loader span:nth-child(1) {
                            animation-delay: -0.32s;
                        }

                        .dot-loader span:nth-child(2) {
                            animation-delay: -0.16s;
                        }

                        @keyframes bounce {

                            0%,
                            80%,
                            100% {
                                transform: scale(0);
                            }

                            40% {
                                transform: scale(1);
                            }
                        }

                        .disabled-menu img {
                            filter: grayscale(100%);
                        }


                        /* COMING SOON BADGE */
                        .coming-soon-badge {
                            position: absolute;
                            top: 2px;
                            right: 2px;
                            background: linear-gradient(135deg, #f59e0b, #f97316);
                            color: #fff;
                            font-size: 9px;
                            padding: 2px 6px;
                            border-radius: 10px;
                            font-weight: 600;
                            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
                        }

                        /* Optional hover (still disabled but nice feel) */
                        .disabled-menu:hover {
                            transform: scale(0.98);

                        }
                    </style>
                    @if(auth()->user()->hasPermission('Magic Menu'))
                    <li class="nav-item dropdown-shortcuts navbar-dropdown dropdown me-1 me-xl-0">
                        <a class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                            <i class='mdi mdi-dots-grid mdi-24px'></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end py-0 min-w-450px max-w-450px">
                            <div class="dropdown-shortcuts-list scrollable-container">
                                <div class="row row-bordered overflow-visible g-0">
                                    @if(auth()->user()->hasPermission('Magic Menu',null, null,'Birthday Finder'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2" onclick="openBirthday()">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/birthday_calender.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_birthday">Birthday Finder</a>
                                    </div>
                                    @endif
                                    @if(auth()->user()->hasPermission('Magic Menu',null,null, 'Payroll Calculator'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2 " onclick="openCTCCalculator()">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/payroll_calculator.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                            <!-- <span class="coming-soon-badge">Coming Soon</span> -->
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_payrollcalculator">CTC Calculator</a>
                                    </div>
                                    @endif
                                    @if(auth()->user()->hasPermission('Magic Menu',null,null, 'Holiday Calendar'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2" onclick="openHoliday()">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/holiday_calender.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_holiday_list">Holiday Calendar</a>
                                    </div>
                                    @endif
                                    @if(auth()->user()->hasPermission('Magic Menu',null,null, 'Late Commers'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2 " onclick="openlatePreview()">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/late.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                            <!-- <span class="coming-soon-badge">Coming Soon</span> -->
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_late_preview">Late Commers</a>
                                    </div>
                                    @endif
                                    @if(auth()->user()->hasPermission('Magic Menu',null,null, 'Leave Preview'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2 " onclick="openLeavePreview()">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/leave.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                            <!-- <span class="coming-soon-badge">Coming Soon</span> -->
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_leave_preview">Leave Preview</a>
                                    </div>
                                    @endif
                                    @if(auth()->user()->hasPermission('Magic Menu',null,null, 'Ai Resume'))
                                    <div class="dropdown-shortcuts-item col-4 px-1 py-2 disabled-menu">
                                        <label class="mb-1">
                                            <img src="{{asset('assets/egc_images/magic_menu/aiResumeCheck.png') }}" class="auth-cover-illustration w-50px h-50px shadow-img" />
                                            <span class="coming-soon-badge">Coming Soon</span>
                                        </label>
                                        <a href="javascript:;" class="stretched-link fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_AIResume">AI Resume</a>
                                    </div>
                                    @endif

                                </div>
                            </div>
                        </div>
                    </li>
                    @endif
                    <!--/ Notification -->



                    <!-- Notification -->
                    <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
                        <a href="javascript:void(0);" aria-expanded="false" data-bs-toggle="offcanvas" data-bs-target="#notification_tab">
                            <!-- <img id="envelope" src="{{ url('assets/egc_images/notification/envelope.png') }}" alt="bell" class="bell" width="25" height="25" /> -->
                            <img id="envelope" src="{{ url('assets/egc_images/notification/unread_msg_1.gif') }}" alt="bell" class="bell" width="40" height="40" />
                        </a>
                    </li>
                    <!--/ Notification -->
                    <!-- Notification -->
                    <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
                        <a href="javascript:void(0);" aria-expanded="false" data-bs-toggle="offcanvas" data-bs-target="#chat_tab">
                            <span class="mdi mdi-chat-processing-outline fs-2 text-dark"></span>
                            <!-- <img id="chatbot" src="{{ url('assets/egc_images/notification/unread_msg_1.gif') }}" alt="bell" class="bell" width="40" height="40" />             -->
                        </a>
                    </li>
                    <!--/ Notification -->

                    <!-- User -->
                    <li class="nav-item navbar-dropdown dropdown-user dropdown">
                        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                            <div class="avatar avatar-online" style="width: 40px; height: 40px;">
                                @if(Auth::user()->staff->company_type==1)
                                <img src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                                @else
                                <img src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                    ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle" style="border: 2px solid #ab2b22ff;" />
                                @endif
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="javascript:;">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0 me-3">
                                            <div class="avatar avatar-online">
                                                @if(Auth::user()->staff->company_type==1)
                                                <img src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                                                @else
                                                <img src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                            ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                            : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="w-px-40 h-auto rounded-circle" />
                                                @endif
                                            </div>
                                        </div>
                                        <div class="flex-grow-1">
                                            <span class="fw-medium d-block">
                                                @if (Auth::check())
                                                {{ Auth::user()->name }}
                                                @else
                                                Super Admin
                                                @endif
                                            </span>
                                            <small class="text-muted">Admin</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <div class="dropdown-divider"></div>
                            </li>
                            <li>
                                <a class="dropdown-item" href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_profile">
                                    <!-- <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="Loading" style="width: 30px; height: auto;"> -->
                                    <i class="mdi mdi-account-circle-outline text-black fs-3"></i>
                                    <span class="align-middle">My Profile</span>
                                </a>
                            </li>

                            @if (Auth::check())
                            <li>
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class='mdi mdi-logout fs-3'></i>
                                    <span class="align-middle">Logout</span>
                                </a>
                            </li>
                            <form method="POST" id="logout-form" action="{{ route('logout') }}">
                                @csrf
                            </form>
                            @else
                            <li>
                                <a class="dropdown-item" href="{{ Route::has('login') ? route('login') : url('auth/login-basic') }}">
                                    <i class='mdi mdi-login me-2'></i>
                                    <span class="align-middle">Login</span>
                                </a>
                            </li>
                            @endif


                        </ul>
                    </li>
                    <!--/ User -->
                </ul>
            </div>
            @if(!isset($navbarDetached))
        </div>
        @endif
    </nav>
    <!-- / Navbar -->

<style>
    #salaryComponentsNav table{
        width:100%;
        table-layout:fixed;
    }

    #salaryComponentsNav th,
    #salaryComponentsNav td{
        vertical-align:middle;
    }

    #salaryComponentsNav td:first-child,
    #salaryComponentsNav th:first-child{
        width:46%;
        white-space:normal;
        word-break:break-word;
    }

    #salaryComponentsNav td:nth-child(2),
    #salaryComponentsNav td:nth-child(3),
    #salaryComponentsNav td:nth-child(4),
    #salaryComponentsNav th:nth-child(2),
    #salaryComponentsNav th:nth-child(3),
    #salaryComponentsNav th:nth-child(4){
        width:18%;
        text-align:right;
        white-space:nowrap;
    }

    #salaryComponentsNav .table-responsive{
        overflow-x:auto;
    }

    #salaryComponentsNav .card{
        height:100%;
    }
</style>
<div class="modal fade" id="kt_modal_payrollcalculator" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-scrollable" style="max-width:1500px;width:96%;">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="modal-title fs-3 fw-bold"><i class="mdi mdi-calculator fs-4 me-2"></i>CTC Calculator</span>
                </div>
                
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <div class="row">
                    <div class="col-lg-3">
                        <label>Entity</label>
                        <select id="ctc_entity" class="form-select select3" onchange="loadCTCStaff(this.value)">
                            <option value="">Choose Entity</option>
                            <option value="egc">Elysium Groups</option>
                            @if(isset($active_entity_list))
                            @foreach($active_entity_list as $entity)
                            <option value="{{$entity->sno}}">{{$entity->entity_name}}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <label>Employee</label>
                        <select id="ctc_staff" class="form-select select3" onchange="changeCTCStaff()">
                            <option value="">Select Employee</option>
                        </select>
                    </div>
                </div>
                <hr>
                <div id="ctcCalculatorBody">
                    <div class="text-center py-5">
                        <i class="mdi mdi-calculator fs-1 text-muted"></i>
                        <h5 class="mt-3">Choose Company & Employee</h5>
                    </div>
                </div>
                <div id="ctcLoading"></div>
                <div id="ctcResult" style="display:none;">
                    <!-- Salary Cards -->
                </div>
                

              
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



    <!-- Birthday Modal -->
    <div class="modal fade" id="kt_modal_birthday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 pt-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="">
                        <span class="text-black fs-3 fw-bold"> 🎂 Birthday Finder</span>
                    </div>
                    <div class=" mb-3">
                        <div class="row g-2">
                            <div class="col-md-10">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="birthday_date" name="birthday_date" placeholder="Select Date" class="form-control common_month_datepicker_birth" readonly value="{{date('M-Y')}}" onchange="loadBirthdays()" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Modal body-->
                <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                    <div id="birthdayLoader" class="birthday-loader d-none">
                        <div class="loader-content text-center">
                            <div class="dot-loader">
                                <span></span><span></span><span></span>
                            </div>
                            <div class="mt-2 fw-semibold text-muted">Fetching celebrations 🎉</div>
                        </div>
                    </div>
                    <div class="row g-3" id="birthdayList">

                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>



    <script>
        $('.common_month_datepicker_birth').datepicker({
            format: "M-yyyy", // ✅ Month-Year format (Apr-2026)
            startView: "months", // ✅ Open in months view
            minViewMode: "months", // ✅ Disable day selection
            autoclose: true,
            todayHighlight: true
        });

        function openBirthday() {
            loadBirthdays()
        }

        function hexToRGBA(hex, opacity) {
            let r = 0,
                g = 0,
                b = 0;

            if (hex.length == 7) {
                r = parseInt(hex.substring(1, 3), 16);
                g = parseInt(hex.substring(3, 5), 16);
                b = parseInt(hex.substring(5, 7), 16);
            }

            return `rgba(${r}, ${g}, ${b}, ${opacity})`;
        }

        function loadBirthdays() {
            let date = $('#birthday_date').val();
            $('#birthdayLoader').removeClass('d-none');
            $.ajax({
                url: "{{ route('birthdays.list') }}",
                type: "GET",
                data: {
                    date: date
                },
                success: function(res) {
                    $('#birthdayLoader').addClass('d-none');
                    let html = '';

                    if (res.length === 0) {
                        html = `<div class="text-center text-muted">No birthdays found 🎂</div>`;
                    }

                    res.forEach(emp => {
                        // html += `
                        // <div class="col-md-3">
                        //     <div class="birthday-card">
                        //         <img src="${emp.profile_image}" class="birthday-img">
                        //         <h6 class="fw-bold mb-0">${emp.name}</h6>
                        //         <small class="text-muted">${emp.job_role}</small>
                        //         <div class="text-warning mt-1">🎉 ${emp.date_of_birth}</div>
                        //     </div>
                        // </div>`;
                        html += `
                        <div class="col-md-3 ">
                          <div class="birthday-card-modern " style="border-top: 4px solid ${emp.company_color};${getTodayClass(emp.dob_raw)}">
                            
                            <div class="top-bar" style="background:${emp.company_color}">
                                <span class="company-name">${emp.company}</span>
                            </div>

                            <div class="card-body text-center pb-2">
                                <img src="${emp.profile_image}" class="birthday-img-modern" style="background-color: ${hexToRGBA(emp.company_color, 0.6)}">

                                <h6 class="fw-bold mt-2 mb-0">${emp.name}</h6>
                                <small class="text-muted">${emp.nickname ?? ''}</small>

                                <div class="mt-1 text-primary fw-semibold">
                                    ${emp.job_role}
                                </div>

                                <div class="text-muted small">
                                    ${emp.department}
                                </div>

                                <div class="birthday-date mt-2">
                                    🎉 ${emp.date_of_birth}
                                </div>

                                ${getTodayBadge(emp.dob_raw)}
                            </div>
                          </div>
                        </div>
                        `;
                    });


                    $('#birthdayList').html(html);
                },
                error: function(err) {
                    $('#birthdayLoader').addClass('d-none');
                }
            });
        }


        function getTodayClass(dob) {
            let today = new Date().toISOString().slice(5, 10);
            return dob === today ?
                `background-color: #4bff0052 !important;` :
                '';
        }

        function getTodayBadge(dob) {
            let today = new Date().toISOString().slice(5, 10);
            return dob === today ?
                `<span class="badge bg-danger mt-2">🎉 Today</span>` :
                '';
        }
    </script>



    <div class="modal fade" id="kt_modal_holiday_list" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 pt-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="">
                        <span class="text-black fs-3 fw-bold"> 📅 Holiday Calendar</span>
                    </div>
                    <div class=" mb-3">
                        <div class="row g-2">
                            <div class="col-md-10  w-150px">
                                <select id="holiday_year" class="form-select select3" onchange="loadHolidays()">
                                    <script>
                                        let yearSelect = document.currentScript.parentElement;
                                        let currentYear = new Date().getFullYear();
                                        for (let i = currentYear - 2; i <= currentYear + 2; i++) {
                                            yearSelect.innerHTML += `<option value="${i}" ${i===currentYear?'selected':''}>${i}</option>`;
                                        }
                                    </script>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Modal body-->
                <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                    <div id="holidayLoader" class="holiday-loader d-none">
                        <div class="loader-content text-center">
                            <div class="dot-loader">
                                <span></span><span></span><span></span>
                            </div>
                            <div class="mt-2 fw-semibold text-muted">Fetching Holidays 📅</div>
                        </div>
                    </div>
                    <div id="holidayList"></div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <style>
        .holiday-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding: 12px;
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: 0.3s;
        }

        .holiday-item:hover {
            transform: translateX(5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        .holiday-date-box {
            min-width: 60px;
            text-align: center;
            border-radius: 10px;
            padding: 8px;
            background: linear-gradient(135deg, #28a745, #20c997);
            color: #fff;
            font-weight: bold;
        }

        .holiday-details {
            margin-left: 15px;
        }

        .holiday-title {
            font-weight: 600;
            font-size: 15px;
        }

        .holiday-range {
            font-size: 12px;
            color: #888;
        }

        .month-section {
            margin-bottom: 20px;
        }

        .month-title {
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 10px;
            color: #28a745;
        }

        /* .holiday-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 12px;
            margin-bottom: 8px;
            background: #fff;
            box-shadow: 0 5px 10px rgba(0,0,0,0.05);
            transition: 0.3s;
        } */

        /* .holiday-item:hover {
            transform: translateX(5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.12);
        } */

        /* .holiday-date-box {
            width: 55px;
            text-align: center;
            background: #28a745;
            color: #fff;
            border-radius: 10px;
            padding: 6px;
            font-weight: bold;
        } */

        /* .holiday-details {
            margin-left: 12px;
        } */
    </style>

    <script>
        function openHoliday() {
            loadHolidays()
        }

        function loadHolidays() {
            let year = $('#holiday_year').val();
            $('#holidayLoader').removeClass('d-none');
            $('#holidayList').html('');
            $.ajax({
                url: "{{ route('holiday.list') }}",
                type: "GET",
                data: {
                    year: year
                },
                success: function(res) {
                    $('#holidayLoader').addClass('d-none');
                    let html = '';

                    if (Object.keys(res).length === 0) {
                        html = `<div class="text-center text-muted">No holidays found 📅</div>`;
                    }

                    for (let month in res) {

                        html += `<div class="month-section">
                              <div class="month-title">📅 ${month}</div>`;

                        res[month].forEach(hol => {
                            html += `
                      <div class="holiday-item">

                          <div class="holiday-date-box">
                              ${hol.day}
                          </div>

                          <div class="holiday-details">
                              <div class="fw-semibold">🎉 ${hol.reason}</div>
                              <div class="text-muted small">${hol.full_date}</div>
                          </div>

                      </div>`;
                        });

                        html += `</div>`;
                    }

                    $('#holidayList').html(html);
                },
                error: function(err) {
                    $('#holidayLoader').addClass('d-none');
                }
            });
        }
    </script>

    <style>
        .sticky_table_leave thead th:not(:first-child):not(:last-child) {
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
            line-height: 1.2;
        }

        .sticky_table_leave thead th:not(:first-child):not(:last-child) a {
            display: flex;
            flex-direction: column;
            text-decoration: none;
            color: inherit;
        }

        .sticky_table_leave thead th:not(:first-child):not(:last-child) a div:first-child {
            font-weight: 600;
            font-size: 14px;

        }

        .sticky_table_leave thead th:not(:first-child):not(:last-child) a div:last-child {
            font-size: 12px;
            color: #ccc;

        }

        .sticky_table_leave tbody td {
            vertical-align: middle;
        }

        .sticky_table_leave tbody td:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background: #fff;
        }

        .sticky_table_leave thead th:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background: #ab2b22;
        }







        /* .leave-history-scroll {
            max-height: 600px;
            overflow-y: auto;
            overflow-x: auto;
        }

        .leave-table-scroll {
            max-height: 600px;
            overflow-y: auto;
            overflow-x: auto;
        }

        .sticky_table_leave thead th,
        .sticky_table_history thead th {
            position: sticky;
            top: 0;
            z-index: 5;
            color: #fff;
        } */
    </style>

    <style>
        .leave-attendance-badge {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .leave-attendance-tooltip {
            position: absolute;
            top: 130%;
            left: 50%;
            transform: translateX(-50%);
            width: 260px;
            max-height: 260px;
            overflow-y: auto;
            background: #fff;
            border-radius: 12px;
            padding: 10px;
            font-size: 12px;
            opacity: 0;
            visibility: hidden;
            transition: all 0.2s ease;
            z-index: 99999;
            border: 1px solid #e5e5e5;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
        }

        .leave-attendance-tooltip::before {
            content: "";
            position: absolute;
            top: -6px;
            left: 50%;
            transform: translateX(-50%);
            border-width: 6px;
            border-style: solid;
            border-color: transparent transparent #fff transparent;
        }

        .leave-attendance-badge:hover .leave-attendance-tooltip {
            opacity: 1;
            visibility: visible;
            transform: translateX(-50%) translateY(4px);
        }

        .leave-tooltip-item {
            padding-bottom: 10px;
            margin-bottom: 10px;
            border-bottom: 1px dashed #ddd;
        }

        .leave-tooltip-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }

        .leave-tooltip-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            margin-bottom: 4px;
        }

        .leave-tooltip-date {
            font-weight: 700;
            color: #111;
            white-space: nowrap;
        }

        .leave-tooltip-type {
            font-size: 11px;
            background: #ffe5e5;
            color: #d00000;
            padding: 2px 8px;
            border-radius: 20px;
            font-weight: 600;
            white-space: nowrap;
        }

        .leave-tooltip-reason {
            color: #666;
            line-height: 1.4;
            word-break: break-word;
            white-space: normal;
        }

        .leave-attendance-tooltip::-webkit-scrollbar {
            width: 5px;
        }

        .leave-attendance-tooltip::-webkit-scrollbar-thumb {
            background: #ccc;
            border-radius: 10px;
        }
    </style>

    <div class="modal fade" id="kt_modal_leave_preview" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 pt-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="">
                        <span class="text-black fs-3 fw-bold"> Leave Preview</span>
                    </div>
                    <div class=" mb-3">
                        <div class="row g-2">
                            <div class="col-md-10  w-150px" style="z-index:9999999;">
                                <select id="leave_year" class="form-select select3" >
                                    <script>
                                        let yearLeaveSelect = document.currentScript.parentElement;
                                        let currentLeaveYear = new Date().getFullYear();
                                        for (let i = currentLeaveYear - 2; i <= currentLeaveYear + 2; i++) {
                                            yearLeaveSelect.innerHTML += `<option value="${i}" ${i===currentLeaveYear?'selected':''}>${i}</option>`;
                                        }
                                    </script>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Modal body-->
                <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                    <div id="holidayLoader" class="holiday-loader d-none">
                        <div class="loader-content text-center">
                            <div class="dot-loader">
                                <span></span><span></span><span></span>
                            </div>
                            <div class="mt-2 fw-semibold text-muted">Fetching Leave 📅</div>
                        </div>
                    </div>
                    <ul class="nav nav-tabs mb-3">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#leave_matrix_tab">Staff Leave Matrix</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#leave_history_tab" onclick="FetchLeaveHistory()">Leave History</a>
                        </li>
                    </ul>

                    <div class="tab-content">

                        <!-- TAB 1 -->
                        <div class="tab-pane fade show active"
                            id="leave_matrix_tab">

                            <div class="d-flex justify-content-between mb-3 sticky-top bg-white py-2 " style="z-index:999999;">
                                <div class="d-flex gap-2 ">
                                    <div>
                                        <input type="text"
                                            id="leave_search"
                                            class="form-control w-250px"
                                            placeholder="Search Staff..."
                                            onkeyup="searchLeaveStaff()">
                                    </div>
                                    <div class="w-250px ">
                                        <select id="leave_entity_filt" class="form-select select3" onchange="searchLeaveStaff()">
                                            <option value="">All</option>
                                            <option value="egc">Elysium Groups</option>
                                            @if(isset($active_entity_list))
                                            @foreach($active_entity_list as $entity)
                                            <option value="{{$entity->sno}}">{{$entity->entity_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>



                            </div>

                            <div class="table-responsive max-h-600px leave-table-scroll">

                                <table class="table sticky_table_leave align-middle table-row-dashed table-striped table-hover gy-0 gs-1">

                                    <thead class="sticky-top">

                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                            <th class="min-w-300px text-start ">Staff Details</th>
                                            <th class="">Jan</th>
                                            <th class="">Feb</th>
                                            <th class="">Mar</th>
                                            <th class="">Apr</th>
                                            <th class="">May</th>
                                            <th class="">Jun</th>
                                            <th class="">Jul</th>
                                            <th class="">Aug</th>
                                            <th class="">Sep</th>
                                            <th class="">Oct</th>
                                            <th class="">Nov</th>
                                            <th class="">Dec</th>
                                        </tr>

                                    </thead>

                                    <tbody id="leave_matrix_body"></tbody>

                                </table>

                            </div>

                            <!-- loader -->
                            <div id="leaveTableLoader"></div>

                        </div>

                        <!-- TAB 2 -->
                        <div class="tab-pane fade" id="leave_history_tab">
                            <div class="d-flex justify-content-between mb-3 sticky-top bg-white py-2 z-index-3">

                                <input type="text"
                                    id="leave_history_search"
                                    class="form-control w-250px"
                                    placeholder="Search Staff..."
                                    onkeyup="searchLeaveHistory()">

                            </div>

                            <div class="table-responsive max-h-600px leave-history-scroll">

                                <table class="table sticky_table_history align-middle table-row-dashed table-striped table-hover gy-0 gs-1">

                                    <thead class="sticky-top">

                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                            <th>Date</th>
                                            <th>Staff</th>
                                            <th>Type</th>
                                            <th>Reason</th>
                                        </tr>

                                    </thead>

                                    <tbody id="leave_history_body"></tbody>

                                </table>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <script>
        let leavePage = 1;
        let loadingLeave = false;
        let hasMoreLeave = true;
        let leaveSearch = '';
        let leaveEntitySearch = '';
        let abortLeaveController = new AbortController();



        function openLeavePreview() {

            resetLeaveMatrix();

            loadMatrix();
        }

        function resetLeaveMatrix() {
            leavePage = 1;
            hasMoreLeave = true;
            loadingLeave = false;

            $('#leave_matrix_body').html('');
        }

        function loadMatrix() {

            if (loadingLeave || !hasMoreLeave) return;

            loadingLeave = true;
            leaveEntitySearch = $('#leave_entity_filt').val();

            // showTableSkeleton();
            if (abortLeaveController.signal) abortLeaveController.abort();
            abortLeaveController = new AbortController();
            const url = `/leave-matrix?page=${leavePage}&search=${leaveSearch}&year=${$('#leave_year').val()}&entity_id=${leaveEntitySearch}`;

            fetch(url, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    signal: abortLeaveController.signal
                })
                .then(res => res.json())
                .then(res => {
                    renderMatrix(res.data);

                    if (res.next_page) {
                        leavePage++;
                    } else {
                        hasMoreLeave = false;
                    }
                    loadingLeave = false;
                    hideTableSkeleton();

                }).catch(err => {
                    if (err.name !== "AbortError") console.error(err);
                    loadingLeave = false;
                    hideTableSkeleton();
                });


        }

        function searchLeaveStaff() {

            leaveSearch = $('#leave_search').val();


            resetLeaveMatrix();

            loadMatrix();
        }


        $('.leave-table-scroll').on('scroll', function() {

            let div = $(this)[0];

            if (
                div.scrollTop + div.clientHeight >= div.scrollHeight - 150
            ) {
                loadMatrix();
            }
        });

        function showTableSkeleton() {

            let html = '';

            for (let i = 0; i < 5; i++) {

                html += `
                <tr class="leave-skeleton-row" >

                    <td >
                        <div class="d-flex align-items-center">

                            <div class="placeholder-glow me-3">
                                <span class="placeholder rounded-circle"
                                    style="width:45px;height:45px;"></span>
                            </div>

                            <div class="w-100">

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-6"></span>
                                </div>

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-4"></span>
                                </div>

                                <div class="placeholder-glow">
                                    <span class="placeholder col-8"></span>
                                </div>

                            </div>

                        </div>
                    </td>
                `;

                for (let j = 0; j < 12; j++) {

                    html += `
                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-8"></span>
                        </div>
                    </td>`;
                }

                html += `</tr>`;
            }

            $('#leaveTableLoader').html(`
                <table class="table">
                    <tbody>${html}</tbody>
                </table>
            `);
        }

        function hideTableSkeleton() {
            $('#leaveTableLoader').html('');
        }


        let leaveHistoryPage = 1;
        let loadingHistoryLeave = false;
        let hasMoreHistoryLeave = true;
        let leaveHistorySearch = '';
        let abortLeaveHistoryController = new AbortController();

        function resetLeaveHistory() {
            leaveHistoryPage = 1;
            hasMoreHistoryLeave = true;
            loadingHistoryLeave = false;

            $('#leave_history_body').html('');
        }



        function searchLeaveHistory() {

            leaveHistorySearch = $('#leave_history_search').val();

            resetLeaveHistory();

            loadHistory();
        }

        function showHistorySkeleton() {

            let html = '';

            for (let i = 0; i < 5; i++) {

                html += `
                <tr class="history-skeleton-row">

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-8"></span>
                        </div>
                    </td>

                    <td>
                        <div class="d-flex align-items-center">

                            <div class="placeholder-glow me-3">
                                <span class="placeholder rounded-circle"
                                    style="width:45px;height:45px;"></span>
                            </div>

                            <div class="w-100">

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-6"></span>
                                </div>

                                <div class="placeholder-glow">
                                    <span class="placeholder col-4"></span>
                                </div>

                            </div>

                        </div>
                    </td>

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-6"></span>
                        </div>
                    </td>

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-10"></span>
                        </div>
                    </td>

                </tr>`;
            }

            $('#leave_history_body').append(html);
        }

        function removeHistorySkeleton() {

            $('.history-skeleton-row').remove();
        }

        function formatDate(dateString) {
            const date = new Date(dateString);

            // Check if the date is valid
            if (isNaN(date.getTime())) {
                return '-'; // Return '-' if the date is invalid
            }

            // Get the day, month (abbreviated), and year
            const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
            const month = date.toLocaleString('default', {
                month: 'short'
            }); // Get abbreviated month
            const year = date.getFullYear(); // Get full year

            // Construct and return the formatted date string
            return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
        }

        function loadHistory() {

            if (loadingHistoryLeave || !hasMoreHistoryLeave) return;

            loadingHistoryLeave = true;

            showHistorySkeleton();

            if (abortLeaveHistoryController.signal) {
                abortLeaveHistoryController.abort();
            }

            abortLeaveHistoryController = new AbortController();

            const url =
                `/leave-history?page=${leaveHistoryPage}&search=${leaveHistorySearch}&year=${$('#leave_year').val()}`;

            fetch(url, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    signal: abortLeaveHistoryController.signal
                })

                .then(res => res.json())

                .then(res => {

                    removeHistorySkeleton();
                    renderHistory(res.data.data);
                    if (res.data.next_page_url) {

                        leaveHistoryPage++;

                    } else {

                        hasMoreHistoryLeave = false;
                    }
                })

                .catch(err => {

                    if (err.name !== "AbortError") {
                        console.error(err);
                    }
                })

                .finally(() => {

                    loadingHistoryLeave = false;
                });
        }



        function showSkeleton(target) {
            let html = `
            <div class="p-3">
                <div class="placeholder-glow">
                    <span class="placeholder col-12 mb-2"></span>
                    <span class="placeholder col-10 mb-2"></span>
                    <span class="placeholder col-8 mb-2"></span>
                </div>
            </div>`;
            $(target).html(html);
        }

        function renderMatrix(data) {

            let html = '';

            data.forEach(staff => {

                html += `
            <tr>

                <td class="text-start" style="">
                <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${staff.entity_base_color || ''};"></div>

                    <div class="d-flex align-items-center">

                        <img src="${staff.staff_image}"
                            class="w-45px h-45px rounded-circle me-3 border object-fit-fit">

                        <div>

                            <div class="fw-bold fs-6">
                                ${staff.staff_name}
                            </div>

                            <div class="text-muted fs-7">
                                ${staff.nick_name ?? ''}
                            </div>

                            <div class="text-primary fs-7 fw-semibold">
                                ${staff.employee_id ?? '-'}
                            </div>

                            <div class="fs-8 text-gray-700 badge" style="background-color:${staff.entity_base_color ?? ''}">
                                ${staff.entity_name ?? ''}
                            </div>

                            <div class="fs-8 text-gray-700">
                                ${staff.department_name ?? ''}
                            </div>

                            <div class="fs-8 text-warning fw-semibold">
                                ${staff.job_role_name ?? ''}
                            </div>

                        </div>

                    </div>

                </td>
            `;

                for (let i = 1; i <= 12; i++) {

                    let item = staff.months?.[i] ?? {};
                    let count = item.count ?? 0;
                    let leaves = item.leaves ?? [];
                    let tooltipHtml = '';
                    if (leaves.length > 0) {
                        leaves.forEach(leave => {
                            tooltipHtml += `
                                <div class="leave-tooltip-item">

                                    <div class="leave-tooltip-header">

                                        <div class="leave-tooltip-date">
                                            ${leave.date}
                                        </div>

                                        <div class="leave-tooltip-type">
                                            ${leave.leave_type}
                                        </div>

                                    </div>

                                    <div class="leave-tooltip-reason">
                                        ${leave.reason ?? '-'}
                                    </div>

                                </div>
                            `;
                        });
                    } else {
                        tooltipHtml = `
                            <div class="leave-tooltip-row text-center text-muted">
                                No Leave
                            </div>
                        `;
                    }

                    html += `
                <td>

                    
                    <span class="leave-attendance-badge  position-relative" >
                        <span class="badge ${count > 0 ? 'bg-danger' : 'bg-light text-dark'}" >
                            ${count}
                        </span>
                        <div class="leave-attendance-tooltip shadow-sm">
                                  ${tooltipHtml}
                        </div>

                    </span>

                </td>`;
                }

                html += `</tr>`;
            });

            $('#leave_matrix_body').append(html);

            $('[data-bs-toggle="tooltip"]').tooltip();
        }



        $('.leave-history-scroll').off('scroll').on('scroll', function() {

            let div = this;

            if (
                div.scrollTop + div.clientHeight >= div.scrollHeight - 100
            ) {

                console.log('history scroll called');

                loadHistory();
            }
        });

        function FetchLeaveHistory() {

            if ($('#leave_history_body').html().trim() == '') {

                resetLeaveHistory();

                loadHistory();
            }
        }

        function renderHistory(data) {



            let html = '';

            data.forEach(staff => {

                const LeaveType = staff.leave_type == 'first_half' ?
                    "First Half Leave" :
                    (staff.leave_type == 'second_half' ? "Second Half Leave" : 'Full Day');

                const resultToday = formatDateLeave(staff.date);


                html += `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${staff.entity_base_color || ''};"></div>
                    <div>${formatDate(staff.date)}</div>
                    <div>
                    ${resultToday.checked == 1 ?
                    `<span class="badge bg-${resultToday.bgColor} rounded" >${resultToday.name}</span>`
                     : ''}
                    
                    </div>
                
                </td>
                <td class="text-start">

                    <div class="d-flex align-items-center">

                        <img src="${staff.staff_image_url}"
                            class="w-45px h-45px rounded-circle me-3 border object-fit-fit">

                        <div>

                            <div class="fw-bold fs-6">
                                ${staff.staff_name}
                            </div>

                            <div class="text-muted fs-7">
                                ${staff.nick_name ?? ''}
                            </div>

                            <div class="text-primary fs-7 fw-semibold">
                                ${staff.employee_id ?? '-'}
                            </div>

                            <div class="fs-8 text-gray-700 badge" style="background-color:${staff.entity_base_color ?? ''}">
                                ${staff.entity_name ?? ''}
                            </div>

                            <div class="fs-8 text-gray-700">
                                ${staff.department_name ?? ''}
                            </div>

                            <div class="fs-8 text-warning fw-semibold">
                                ${staff.job_role_name ?? ''}
                            </div>

                        </div>

                    </div>

                </td>
                <td>${staff.attendance == 'A' ? 
                `<label class="badge bg-label-danger text-black border border-danger fw-bold px-3  py-1"><span>Absent</span></label>`
                 :`<label class="badge bg-label-warning text-black border border-warning fw-bold px-3  py-1"><span>${LeaveType}</span></label>`
                  }
                 </td>
                <td>
                    ${staff.attendance == 'A' ? '-' : `
                    <span class="d-block">${staff.reason_id ?
                    `${staff.reason_name ?? ''}`
                     : ''}</span>
                    <span>
                    ${staff.reason ?? ''}</span>
                    `}
                    
                </td>
            </tr>`;
            });

            $('#leave_history_body').append(html);

            $('[data-bs-toggle="tooltip"]').tooltip();
        }
    </script>

    <script>
        function formatDateLeave(date) {
            const inputDate = new Date(date);

            const today = new Date();
            const yesterday = new Date();
            yesterday.setDate(today.getDate() - 1);

            const input = inputDate.toDateString();
            const todayStr = today.toDateString();
            const yesterdayStr = yesterday.toDateString();

            if (input === todayStr) {
                return {
                    name: "Today",
                    checked: 1,
                    bgColor: "success"
                };
            } else if (input === yesterdayStr) {
                return {
                    name: "Yesterday",
                    checked: 1,
                    bgColor: "warning"
                };
            } else {
                return {
                    name: "",
                    checked: 0,
                    bgColor: ""
                };
            }
        }
    </script>


    <style>
        .sticky_table_late thead th:not(:first-child):not(:last-child) {
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
            line-height: 1.2;
        }

        .sticky_table_late thead th:not(:first-child):not(:last-child) a {
            display: flex;
            flex-direction: column;
            text-decoration: none;
            color: inherit;
        }

        .sticky_table_late thead th:not(:first-child):not(:last-child) a div:first-child {
            font-weight: 600;
            font-size: 14px;

        }

        .sticky_table_late thead th:not(:first-child):not(:last-child) a div:last-child {
            font-size: 12px;
            color: #ccc;

        }

        .sticky_table_late tbody td {
            vertical-align: middle;
        }

        .sticky_table_late tbody td:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background: #fff;
        }

        .sticky_table_late thead th:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background: #ab2b22;
        }
    </style>

    <style>
        .late-attendance-badge {
            display: inline-flex;
            cursor: pointer;
        }

        .late-attendance-tooltip {
            position: fixed;
            width: 290px;
            max-height: 320px;
            overflow-y: auto;
            background: #fff;
            border-radius: 14px;
            padding: 12px;
            font-size: 12px;
            z-index: 99999999;
            border: 1px solid #e8e8e8;
            box-shadow: 0 10px 30px rgba(0, 0, 0, .12);

            display: none;
        }

        .late-tooltip-item {
            border-bottom: 1px dashed #ddd;
            padding-bottom: 12px;
            margin-bottom: 12px;
        }

        .late-tooltip-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .late-tooltip-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            gap: 10px;
        }

        .late-tooltip-date {
            font-size: 13px;
            font-weight: 700;
            color: #111;
        }

        .late-tooltip-badge {
            background: #ffe7e7;
            color: #d10000;
            font-size: 11px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 30px;
            white-space: nowrap;
        }

        .late-tooltip-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }

        .late-grid-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 8px;
        }

        .late-label {
            display: block;
            font-size: 10px;
            color: #777;
            margin-bottom: 2px;
        }

        .late-value {
            font-size: 12px;
            font-weight: 600;
            word-break: break-word;
        }

        .late-attendance-tooltip::-webkit-scrollbar {
            width: 5px;
        }

        .late-attendance-tooltip::-webkit-scrollbar-thumb {
            background: #ccc;
            border-radius: 10px;
        }
    </style>

    <div class="modal fade" id="kt_modal_late_preview" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 pt-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="">
                        <span class="text-black fs-3 fw-bold"> Late Preview</span>
                    </div>
                    <div class=" mb-3">
                        <div class="row g-2">
                            <div class="col-md-10  w-150px" style="z-index:9999999;">
                                <select id="late_year" class="form-select select3">
                                    <script>
                                        let yearlateSelect = document.currentScript.parentElement;
                                        let currentlateYear = new Date().getFullYear();
                                        for (let i = currentlateYear - 2; i <= currentlateYear + 2; i++) {
                                            yearlateSelect.innerHTML += `<option value="${i}" ${i===currentlateYear?'selected':''}>${i}</option>`;
                                        }
                                    </script>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!--begin::Modal body-->
                <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                    <div id="holidayLoader" class="holiday-loader d-none">
                        <div class="loader-content text-center">
                            <div class="dot-loader">
                                <span></span><span></span><span></span>
                            </div>
                            <div class="mt-2 fw-semibold text-muted">Fetching Late 📅</div>
                        </div>
                    </div>
                    <ul class="nav nav-tabs mb-3">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#late_matrix_tab">Staff Late Matrix</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#late_history_tab" onclick="FetchlateHistory()">Late History</a>
                        </li>
                    </ul>

                    <div class="tab-content">

                        <!-- TAB 1 -->
                        <div class="tab-pane fade show active"
                            id="late_matrix_tab">

                            <div class="d-flex justify-content-between mb-3 sticky-top bg-white py-2 " style="z-index:999999;">
                                <div class="d-flex gap-2 ">
                                    <div>
                                        <input type="text"
                                            id="late_search"
                                            class="form-control w-250px"
                                            placeholder="Search Staff..."
                                            onkeyup="searchlateStaff()">
                                    </div>
                                    <div class="w-250px ">
                                        <select id="late_entity_filt" class="form-select select3" onchange="searchlateStaff()">
                                            <option value="">All</option>
                                            <option value="egc">Elysium Groups</option>
                                            @if(isset($active_entity_list))
                                            @foreach($active_entity_list as $entity)
                                            <option value="{{$entity->sno}}">{{$entity->entity_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>



                            </div>

                            <div class="table-responsive max-h-600px late-table-scroll">

                                <table class="table sticky_table_late align-middle table-row-dashed table-striped table-hover gy-0 gs-1">

                                    <thead class="sticky-top">

                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                            <th class="min-w-300px text-start ">Staff Details</th>
                                            <th class="">Jan</th>
                                            <th class="">Feb</th>
                                            <th class="">Mar</th>
                                            <th class="">Apr</th>
                                            <th class="">May</th>
                                            <th class="">Jun</th>
                                            <th class="">Jul</th>
                                            <th class="">Aug</th>
                                            <th class="">Sep</th>
                                            <th class="">Oct</th>
                                            <th class="">Nov</th>
                                            <th class="">Dec</th>
                                        </tr>

                                    </thead>

                                    <tbody id="late_matrix_body"></tbody>

                                </table>

                            </div>

                            <!-- loader -->
                            <div id="lateTableLoader"></div>

                        </div>

                        <!-- TAB 2 -->
                        <div class="tab-pane fade" id="late_history_tab">
                            <div class="row">

                                <div class="col-lg-3 mb-2">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                    <input type="text"
                                        id="late_history_search"
                                        class="form-control w-250px"
                                        placeholder="Search Staff..."
                                        onkeyup="searchlateHistory()">
                                </div>
                                <div class="col-lg-3 mb-2" style="z-index:9999999px !important;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Entity</label>
                                    <select id="daily_late_entity_filt" class="form-select select3" onchange="searchlateHistory()">
                                        <option value="">All</option>
                                        <option value="egc">Elysium Groups</option>
                                        @if(isset($active_entity_list))
                                        @foreach($active_entity_list as $entity)
                                        <option value="{{$entity->sno}}">{{$entity->entity_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                                <div class="col-lg-3 mb-2">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                    <select class="form-select select3 " name="dt_fill_nav_daily_late" id="dt_fill_nav_daily_late" onchange="date_fill_nav_daily_lt();">
                                        <option value="all">All</option>
                                        <option value="today">Today</option>
                                        <option value="week">This Week</option>
                                        <option value="monthly">This Month</option>
                                        <option value="custom_date">Custom Date</option>
                                    </select>
                                </div>
                                <div class="col-lg-3 mb-2" id="today_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2" id="week_from_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_lt_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2" id="week_to_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_lt_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2" id="monthly_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_lt_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2" id="from_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_lt_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2" id="to_dt_nav_daily_late" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="nav_daily_lt_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-2 mt-3" >
                                    <div class="d-flex align-items-end justify-content-start mt-4">
                                        <a href="javascript:;" class="btn btn-secondary btn-sm me-3" onclick="refreshlateHistory()">Reset</a>
                                        <a href="javascript:;" onclick="searchlateHistory()">
                                            <span class="btn btn-primary btn-sm"> Go</span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="table-responsive max-h-600px late-history-scroll">

                                <table class="table sticky_table_late_history align-middle table-row-dashed table-striped table-hover gy-0 gs-1">

                                    <thead class="sticky-top">

                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                            <th>Date</th>
                                            <th>Staff</th>
                                            <th>Shift</th>
                                            <th>In Time</th>
                                        </tr>

                                    </thead>

                                    <tbody id="late_history_body"></tbody>

                                </table>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <script>
        let latePage = 1;
        let loadinglate = false;
        let hasMorelate = true;
        let lateSearch = '';
        let lateEntitySearch = '';
        let abortlateController = new AbortController();



        function openlatePreview() {

            resetlateMatrix();

            loadlateMatrix();
        }

        function resetlateMatrix() {
            latePage = 1;
            hasMorelate = true;
            loadinglate = false;

            $('#late_matrix_body').html('');
        }

        function loadlateMatrix() {

            if (loadinglate || !hasMorelate) return;

            loadinglate = true;
            lateEntitySearch = $('#late_entity_filt').val();

            // showTableSkeleton();
            if (abortlateController.signal) abortlateController.abort();
            abortlateController = new AbortController();
            const url = `/late-matrix?page=${latePage}&search=${lateSearch}&year=${$('#late_year').val()}&entity_id=${lateEntitySearch}`;

            fetch(url, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    signal: abortlateController.signal
                })
                .then(res => res.json())
                .then(res => {
                    renderlateMatrix(res.data);

                    if (res.next_page) {
                        latePage++;
                    } else {
                        hasMorelate = false;
                    }
                    loadinglate = false;
                    hidelateTableSkeleton();

                }).catch(err => {
                    if (err.name !== "AbortError") console.error(err);
                    loadinglate = false;
                    hidelateTableSkeleton();
                });


        }

        function searchlateStaff() {

            lateSearch = $('#late_search').val();


            resetlateMatrix();

            loadlateMatrix();
        }


        $('.late-table-scroll').on('scroll', function() {

            let div = $(this)[0];

            if (
                div.scrollTop + div.clientHeight >= div.scrollHeight - 150
            ) {
                loadlateMatrix();
            }
        });

        function showlateTableSkeleton() {

            let html = '';

            for (let i = 0; i < 5; i++) {

                html += `
                <tr class="late-skeleton-row" >

                    <td >
                        <div class="d-flex align-items-center">

                            <div class="placeholder-glow me-3">
                                <span class="placeholder rounded-circle"
                                    style="width:45px;height:45px;"></span>
                            </div>

                            <div class="w-100">

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-6"></span>
                                </div>

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-4"></span>
                                </div>

                                <div class="placeholder-glow">
                                    <span class="placeholder col-8"></span>
                                </div>

                            </div>

                        </div>
                    </td>
                `;

                for (let j = 0; j < 12; j++) {

                    html += `
                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-8"></span>
                        </div>
                    </td>`;
                }

                html += `</tr>`;
            }

            $('#lateTableLoader').html(`
                <table class="table">
                    <tbody>${html}</tbody>
                </table>
            `);
        }

        function hidelateTableSkeleton() {
            $('#lateTableLoader').html('');
        }


        let lateHistoryPage = 1;
        let loadingHistorylate = false;
        let hasMoreHistorylate = true;
        let lateHistorySearch = '';
        let lateHistoryEntitySearch = '';
        
        
        let abortlateHistoryController = new AbortController();

        function resetlateHistory() {
            lateHistoryPage = 1;
            hasMoreHistorylate = true;
            loadingHistorylate = false;

            $('#late_history_body').html('');
        }

        function refreshlateHistory(){
            $('#late_history_search').val('');
            $('#daily_late_entity_filt').val('');
            $('#dt_fill_nav_daily_late').val('all').change();


            lateHistorySearch = '';

            resetlateHistory();

            loadlateHistory();
        }

        function searchlateHistory() {

            lateHistorySearch = $('#late_history_search').val();

            resetlateHistory();

            loadlateHistory();
        }

        function showlateHistorySkeleton() {

            let html = '';

            for (let i = 0; i < 5; i++) {

                html += `
                <tr class="late-history-skeleton-row">

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-8"></span>
                        </div>
                    </td>

                    <td>
                        <div class="d-flex align-items-center">

                            <div class="placeholder-glow me-3">
                                <span class="placeholder rounded-circle"
                                    style="width:45px;height:45px;"></span>
                            </div>

                            <div class="w-100">

                                <div class="placeholder-glow mb-2">
                                    <span class="placeholder col-6"></span>
                                </div>

                                <div class="placeholder-glow">
                                    <span class="placeholder col-4"></span>
                                </div>

                            </div>

                        </div>
                    </td>

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-6"></span>
                        </div>
                    </td>

                    <td>
                        <div class="placeholder-glow">
                            <span class="placeholder col-10"></span>
                        </div>
                    </td>

                </tr>`;
            }

            $('#late_history_body').append(html);
        }

        function removelateHistorySkeleton() {

            $('.late-history-skeleton-row').remove();
        }

        function formatDatelate(dateString) {
            const date = new Date(dateString);

            // Check if the date is valid
            if (isNaN(date.getTime())) {
                return '-'; // Return '-' if the date is invalid
            }

            // Get the day, month (abbreviated), and year
            const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
            const month = date.toLocaleString('default', {
                month: 'short'
            }); // Get abbreviated month
            const year = date.getFullYear(); // Get full year

            // Construct and return the formatted date string
            return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
        }

        function loadlateHistory() {

            if (loadingHistorylate || !hasMoreHistorylate) return;

            loadingHistorylate = true;
            lateHistoryEntitySearch = $('#daily_late_entity_filt').val();
            const to_dt_nav_daily_late = document.getElementById('nav_daily_lt_custom_to_dt_fill').value;
            const from_dt_nav_daily_late = document.getElementById('nav_daily_lt_custom_from_dt_fill').value;
            const dt_fill_nav_daily_late = document.getElementById('dt_fill_nav_daily_late').value;

            showlateHistorySkeleton();

            if (abortlateHistoryController.signal) {
                abortlateHistoryController.abort();
            }

            abortlateHistoryController = new AbortController();
            

            const url =
                `/late-history?page=${lateHistoryPage}&search=${lateHistorySearch}&year=${$('#late_year').val()}&entity_id=${lateHistoryEntitySearch}&dt_fill_issue_rpt=${dt_fill_nav_daily_late}&from_dt_iss_rpt=${from_dt_nav_daily_late}&to_dt_iss_rpt=${to_dt_nav_daily_late}`;

            fetch(url, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    },
                    signal: abortlateHistoryController.signal
                })

                .then(res => res.json())

                .then(res => {

                    removelateHistorySkeleton();
                    renderlateHistory(res.data.data);
                    if (res.data.next_page_url) {

                        lateHistoryPage++;

                    } else {

                        hasMoreHistorylate = false;
                    }
                })

                .catch(err => {

                    if (err.name !== "AbortError") {
                        console.error(err);
                    }
                })

                .finally(() => {

                    loadingHistorylate = false;
                });
        }



        function showlateSkeleton(target) {
            let html = `
            <div class="p-3">
                <div class="placeholder-glow">
                    <span class="placeholder col-12 mb-2"></span>
                    <span class="placeholder col-10 mb-2"></span>
                    <span class="placeholder col-8 mb-2"></span>
                </div>
            </div>`;
            $(target).html(html);
        }

        function renderlateMatrix(data) {

            let html = '';

            data.forEach(staff => {

                html += `
            <tr>

                <td class="text-start" style="">
                <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${staff.entity_base_color || ''};"></div>

                    <div class="d-flex align-items-center">

                        <img src="${staff.staff_image}"
                            class="w-45px h-45px rounded-circle me-3 border object-fit-fit">

                        <div>

                            <div class="fw-bold fs-6">
                                ${staff.staff_name}
                            </div>

                            <div class="text-muted fs-7">
                                ${staff.nick_name ?? ''}
                            </div>

                            <div class="text-primary fs-7 fw-semibold">
                                ${staff.employee_id ?? '-'}
                            </div>

                            <div class="fs-8 text-gray-700 badge" style="background-color:${staff.entity_base_color ?? ''}">
                                ${staff.entity_name ?? ''}
                            </div>

                            <div class="fs-8 text-gray-700">
                                ${staff.department_name ?? ''}
                            </div>

                            <div class="fs-8 text-warning fw-semibold">
                                ${staff.job_role_name ?? ''}
                            </div>

                        </div>

                    </div>

                </td>
            `;

                for (let i = 1; i <= 12; i++) {

                    let item = staff.months?.[i] ?? {};
                    let count = item.count ?? 0;
                    let lates = item.lates ?? [];
                    let tooltipHtml = '';
                    if (lates.length > 0) {

                        lates.forEach(late => {

                            tooltipHtml += `

                            <div class="late-tooltip-item">

                                <div class="late-tooltip-top">

                                    <div class="late-tooltip-date">
                                        ${late.date}
                                    </div>

                                    <div class="late-tooltip-badge">
                                        +${late.late_minutes} mins
                                    </div>

                                </div>

                                <div class="late-tooltip-grid">

                                    <div class="late-grid-item">
                                        <span class="late-label">Shift</span>
                                        <span class="late-value">
                                            ${late.shift_from} - ${late.shift_to}
                                        </span>
                                    </div>

                                    <div class="late-grid-item">
                                        <span class="late-label">In Time</span>
                                        <span class="late-value text-danger fw-bold">
                                            ${late.in_time}
                                        </span>
                                    </div>

                                    <div class="late-grid-item">
                                        <span class="late-label">Out Time</span>
                                        <span class="late-value text-success fw-bold">
                                            ${late.out_time}
                                        </span>
                                    </div>

                                    <div class="late-grid-item">
                                        <span class="late-label">Worked</span>
                                        <span class="late-value text-primary fw-bold">
                                            ${late.duration}
                                        </span>
                                    </div>

                                </div>

                            </div>
                            `;
                        });

                    } else {

                        tooltipHtml = `
                            <div class="text-center text-muted py-2">
                                No Late Records
                            </div>
                        `;
                    }

                    html += `
                <td>

                    
                    <span class="late-attendance-badge  position-relative" >
                        <span class="badge ${count > 0 ? 'bg-danger' : 'bg-light text-dark'}" >
                            ${count}
                        </span>
                        <div class="late-attendance-tooltip shadow-sm late-global-tooltip">
                                  ${tooltipHtml}
                        </div>

                    </span>

                </td>`;
                }

                html += `</tr>`;
            });

            $('#late_matrix_body').append(html);

            $('[data-bs-toggle="tooltip"]').tooltip();
        }


        let activeTooltip = null;

        $(document).on('mouseenter', '.late-attendance-badge', function() {

            $('.late-global-tooltip').hide();

            let tooltip = $(this).find('.late-global-tooltip');

            activeTooltip = tooltip;

            $('body').append(tooltip);

            tooltip.show();

            const badge = $(this);
            const offset = badge.offset();

            let top = offset.top + badge.outerHeight() + 12;
            let left = offset.left - (tooltip.outerWidth() / 2) + (badge.outerWidth() / 2);

            const winWidth = $(window).width();
            const winHeight = $(window).height();
            const scrollTop = $(window).scrollTop();

            // RIGHT OVERFLOW
            if (left + tooltip.outerWidth() > winWidth - 20) {
                left = winWidth - tooltip.outerWidth() - 20;
            }

            // LEFT OVERFLOW
            if (left < 10) {
                left = 10;
            }

            // BOTTOM OVERFLOW
            if ((top + tooltip.outerHeight()) > (scrollTop + winHeight - 20)) {

                top = offset.top - tooltip.outerHeight() - 12;
            }

            tooltip.css({
                top: top + 'px',
                left: left + 'px'
            });

        });


        $(document).on('mouseleave', '.late-attendance-badge', function() {

            const tooltip = activeTooltip;

            setTimeout(() => {

                if (!tooltip.is(':hover')) {

                    tooltip.hide();

                    $(this).append(tooltip);
                }

            }, 120);

        });


        $(document).on('mouseleave', '.late-global-tooltip', function() {

            $(this).hide();

        });



        $('.late-history-scroll').off('scroll').on('scroll', function() {

            let div = this;

            if (
                div.scrollTop + div.clientHeight >= div.scrollHeight - 100
            ) {

                console.log('history scroll called');

                loadlateHistory();
            }
        });

        function FetchlateHistory() {

            // if ($('#late_history_body').html().trim() == '') {

            resetlateHistory();

            loadlateHistory();
            // }
        }

        function renderlateHistory(data) {



            let html = '';

            data.forEach(staff => {

                const LeaveType = staff.leave_type == 'first_half' ?
                    "First Half Leave" :
                    (staff.leave_type == 'second_half' ? "Second Half Leave" : 'Full Day');


                const resultToday = formatDateLeave(staff.date);

                html += `
            <tr class="${staff.no_out_punch == 1 ? 'bg-label-danger' : ''}">
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${staff.entity_base_color || ''};"></div>
                    <div>${formatDate(staff.date)}</div>
                    <div>
                    ${resultToday.checked == 1 ?
                    `<span class="badge bg-${resultToday.bgColor} rounded" >${resultToday.name}</span>`
                     : ''}
                    
                    </div>
                
                </td>
                <td class="text-start">

                    <div class="d-flex align-items-center">

                        <img src="${staff.staff_image_url}"
                            class="w-45px h-45px rounded-circle me-3 border object-fit-fit">

                        <div>

                            <div class="fw-bold fs-6">
                                ${staff.staff_name}
                            </div>

                            <div class="text-muted fs-7">
                                ${staff.nick_name ?? ''}
                            </div>

                            <div class="text-primary fs-7 fw-semibold">
                                ${staff.employee_id ?? '-'}
                            </div>

                            <div class="fs-8 text-gray-700 badge" style="background-color:${staff.entity_base_color ?? ''}">
                                ${staff.entity_name ?? ''}
                            </div>

                            <div class="fs-8 text-gray-700">
                                ${staff.department_name ?? ''}
                            </div>

                            <div class="fs-8 text-warning fw-semibold">
                                ${staff.job_role_name ?? ''}
                            </div>

                        </div>

                    </div>

                </td>
                <td>
                    ${staff.shift_from} - ${staff.shift_to}
                 </td>
                <td>
                    <div>
                        <span>${staff.in_time} - ${staff.out_time}</span>
                    </div>
                    <div>
                        <span>${staff.duration}</span>
                    </div>
                </td>
            </tr>`;
            });

            $('#late_history_body').append(html);

            $('[data-bs-toggle="tooltip"]').tooltip();
        }
    </script>

    <!--begin::Modal - Profile Update -->
    <div class="modal fade" id="kt_modal_profile" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog">
            <!--begin::Modal content-->
            <div class="modal-content rounded-3 shadow-lg position-relative ">
                <form method="POST" action="{{ route('update_profile') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="card__img">
                        <img src="{{ url('assets/common/egc-image.jpg') }}" alt="background-image" class="bg-image" />
                        <div class="profile-wrapper text-center position-absolute translate-middle" style="top: 120px; left:70px;">
                            <div class="d-inline-block position-relative">
                                @if(Auth::user()->staff->company_type==1)
                                <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
                                @else
                                <img id="uploadedstaffimage" src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                : asset('assets/eapl_images/Super-Admin.png') }}" alt="Profile" class="profile-image" width="100" height="100" />
                                @endif
                                <div id="imagePreview" class="preview-box">
                                    <img id="previewImage" src="" alt="Preview" />
                                </div>
                                <label for="profileImageUpload"
                                    class="position-absolute bottom-0 end-0 bg-white p-2 rounded-circle "
                                    style="cursor: pointer;">
                                    <i class="fas fa-camera text-primary"></i>
                                </label>
                            </div>
                            <input type="file" name="staff_image" id="profileImageUpload" class="d-none upload_staff_image" />
                        </div>
                        <div class="d-flex align-items-start justify-content-center flex-column px-10 px-lg-20 mx-2">
                            <label class="card__title" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Name">Super Admin</label>
                            <label class="card__subtitle text-center mt-0 pt-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="User Role">Super Admin</label>
                        </div>
                    </div>
                    <div class="modal-body pt-0 mt-5 pb-4 px-10 px-xl-20 bg-white">
                        <div class="mb-4">
                            <label class="fw-bold text-black">Username</label>
                            <div class="form-control bg-light border-0">{{ Auth::user()->staff->user_name }}</div>
                            <label class="fw-bold text-muted">Password</label>
                            <div class="input-group">
                                <input type="password" name="staff_password" class="form-control" id="passwordInput" placeholder="Enter New Password" value="{{ Auth::user()->staff->password }}">
                                <span class="input-group-text toggle-password" style="cursor: pointer;">
                                    <i class="fas fa-eye-slash"></i>
                                </span>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary px-4" data-bs-dismiss="modal">Update Profile</button>
                        </div>
                        <!--end::Profile Form-->
                    </div>
                </form>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Profile Update -->


    <!--begin:: Notification Offcanvan-->
    <div class="offcanvas offcanvas-end" id="notification_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="offcanvas-header border-bottom d-block bg-label-white">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="d-flex align-items-center gap-1">
                    <h5 class="offcanvas-title text-dark fw-bold">Notifications</h5>
                    <span id="notificationCount" class="badge rounded-pill bg-danger text-white">0 New</span>
                </div>
                <button type="button" class="btn-close text-reset rounded-pill custom-bg-orange modal_close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

            </div>
            <div class="d-flex align-items-center justify-content-between">
                <label class="clear-all hover-badge">
                    <span class="fs-6 fw-semibold ">Clear All</span>
                </label>
                <label class="mark-all-read hover-badge">
                    <span class="fs-6 fw-semibold ">Mark all as read</span>
                </label>
            </div>

        </div>
        <div class="offcanvas-body flex-grow-1">
            <ul class="list-group list-group-flush list-unstyled scrollable-container notification-list">

            </ul>
        </div>
    </div>
    <div class="offcanvas offcanvas-end" id="chat_tab" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="offcanvas-header border-bottom d-block bg-label-white">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="d-flex align-items-center gap-1">
                    <h5 class="offcanvas-title fw-bold d-flex gap-2 align-items-center"><span class="mdi mdi-robot-happy text-primary fs-3 fw-semibold"></span> <span>Chat Bot</span> </h5>
                </div>
                <button type="button" class="btn-close text-reset rounded-pill custom-bg-orange modal_close" data-bs-dismiss="offcanvas" aria-label="Close"></button>

            </div>
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <input type="text" class="form-control" id="model_name" value="">
                </div>
                <div class="d-flex align-items-center justify-content-end">
                    <label class="clear-all-chat hover-badge-chat">
                        <span class="fs-6 fw-semibold ">Clear All</span>
                    </label>
                </div>
            </div>


        </div>
        <div class="offcanvas-body flex-grow-1">
            <div id="historyLoader" class="text-center text-muted small">
                Loading previous messages...
            </div>

            <div id="chatmessages" class="scrollable-container"></div>
        </div>
        <div class="chat-input d-flex gap-2 py-3 px-2 border border-top-1">
            <textarea id="inputchat" rows="1" class="form-control" placeholder="Type your message..." oninput="adjustTextareaHeight(this)"></textarea>
            <span class="mdi mdi-send-circle cursor-pointer text-success fs-1 align-self-center" id="sendchat"></span>

        </div>
    </div>
    <!--End:: Notification Offcanvan-->

    <style>
        .offcanvas-body {
            display: flex;
            flex-direction: column;
            padding: 0;
        }

        .hover-badge-chat {
            padding: 5px 10px;
            border-radius: 12px;
            transition: background-color 0.3s, color 0.3s;
        }

        /* Hover effect for the badge */
        .hover-badge-chat:hover {
            background-color: #f36f7c;
            /* or any preferred color */
            color: white;
            cursor: pointer;
        }

        .hover-badge-chat:hover span {
            color: white;
            /* Ensures text turns white on hover */
        }


        .message {
            max-width: 75%;
            margin-bottom: 16px;
            padding: 12px 16px;
            border-radius: 12px;
            line-height: 1.5;
            white-space: normal;
            word-break: break-word;
            white-space: pre-line;
        }

        #chatmessages {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            display: flex;
            flex-direction: column;
        }

        .message.user {
            background: #fba919;
            color: black;
            align-self: flex-end;
        }

        .message.ai {
            background: #ab2b22;
            color: white;
            align-self: flex-start;
        }

        /* .chat-input {
      border-top: 1px solid #1e293b;
      padding: 16px;
      display: flex;
      gap: 10px;
  } */

        /* .chat-input textarea {
      flex: 1;
      resize: none;
      border-radius: 8px;
      padding: 10px;
      border: none;
      outline: none;
      font-size: 14px;
  } */

        /* .chat-input button {
      background: #22c55e;
      border: none;
      color: #022c22;
      padding: 0 20px;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
  } */

        .chat-input #sendchat:disabled {
            background: #64748b;
            cursor: not-allowed;
        }

        .ai-chat-loader {
            font-size: 13px;
            opacity: 0.6;
            margin-bottom: 10px;
        }
    </style>

    <script>
        let auth_login_user_id = "{{ auth()->user()->user_id }}";
        let isFirstLoad = true;
        let isLoadingAiChat = false;
        let hasMoreAiChat = true;
        let lastIdAiChat = null;
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const sendBtn = document.getElementById('sendchat');
        const input = document.getElementById('inputchat');
        const messages = document.getElementById('chatmessages');
        let historyLoader = document.getElementById('historyLoader');

        function adjustTextareaHeight(textarea) {
            textarea.style.height = 'auto'; // Reset height to auto to calculate the new height
            textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px'; // Set new height but limit it to 200px
        }

        function trimMessages() {
            while (messages.children.length > 200) {
                messages.removeChild(messages.lastChild);
            }
        }

        function addMessage(text, type) {
            const div = document.createElement('div');
            div.className = `message ${type}`;
            text = escapeHTML(text);
            text = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
            text = text.replace(/\*(.*?)\*/g, '<b>$1</b>');
            div.innerHTML = text;
            messages.appendChild(div);
            messages.scrollTo({
                top: messages.scrollHeight,
                behavior: 'smooth'
            });
            trimMessages();
        }

        sendBtn.onclick = async () => {
            const text = input.value.trim();
            if (!text) return;
            const model_name = $('#model_name').val().trim();

            addMessage(text, 'user');
            input.value = '';
            sendBtn.disabled = true;

            const loader = document.createElement('div');
            loader.className = 'ai-chat-loader';
            loader.textContent = 'AI is thinking...';
            messages.appendChild(loader);

            try {
                const res = await fetch('{{ url(' / ai / chat ') }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        message: text,
                        model: model_name
                    })
                });

                const data = await res.json();
                loader.remove();

                if (!res.ok) {
                    addMessage(data.message || data.error || 'Error', 'ai');
                } else {
                    addMessage(data.reply, 'ai');
                }

            } catch (e) {
                loader.remove();
                addMessage('Network error. Try again.', 'ai');
            }

            sendBtn.disabled = false;
        };

        input.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendBtn.click();
            }
        });

        async function loadChatHistory() {
            if (isLoadingAiChat || !hasMoreAiChat) return;

            isLoadingAiChat = true;
            historyLoader.style.display = 'block';

            const res = await fetch(`/aichat/history?last_id=${lastIdAiChat ?? ''}`);
            const json = await res.json();

            historyLoader.style.display = 'none';

            if (json.data.length === 0) {
                hasMoreAiChat = false;
                isLoadingAiChat = false;
                return;
            }

            // Always work oldest -> newest
            const chats = json.data.reverse();

            if (isFirstLoad) {
                // FIRST LOAD → append & scroll to bottom
                chats.forEach(chat => {
                    if (chat.user_message) addMessage(chat.user_message, 'user');
                    if (chat.ai_reply) addMessage(chat.ai_reply, 'ai');
                    lastIdAiChat = chat.sno;
                });

                messages.scrollTo({
                    top: messages.scrollHeight,
                    behavior: 'smooth'
                });
                isFirstLoad = false;
            } else {
                // SCROLL UP → prepend & preserve scroll
                const previousScrollHeight = messages.scrollHeight;

                chats.forEach(chat => {
                    if (chat.user_message) prependMessage(chat.user_message, 'user');
                    if (chat.ai_reply) prependMessage(chat.ai_reply, 'ai');
                    lastIdAiChat = chat.sno;
                });

                messages.scrollTop = messages.scrollHeight - previousScrollHeight;
            }

            hasMoreAiChat = json.has_more;
            isLoadingAiChat = false;
        }



        // async function loadChatHistory() {
        //     if (isLoadingAiChat || !hasMoreAiChat) return;

        //     isLoadingAiChat = true;
        //    historyLoader.style.display = 'block';

        //     const res = await fetch(`/aichat/history?last_id=${lastIdAiChat ?? ''}`);
        //     const json = await res.json();

        //     historyLoader.style.display = 'none';
        //     if (json.data.length === 0) {
        //         hasMoreAiChat = false;
        //         return;
        //     }

        //     const previousScrollHeight = messages.scrollHeight;

        //     json.data.reverse().forEach(chat => {
        //       if (chat.user_message) prependMessage(chat.user_message, 'user');
        //       if (chat.ai_reply) prependMessage(chat.ai_reply, 'ai');
        //        lastIdAiChat = chat.sno;
        //   });


        //     messages.scrollTop = messages.scrollHeight - previousScrollHeight;

        //     hasMoreAiChat = json.has_more;
        //     isLoadingAiChat = false;
        // }

        function prependMessage(text, type) {
            const div = document.createElement('div');
            div.className = `message ${type}`;
            text = escapeHTML(text);

            text = text.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
            text = text.replace(/\*(.*?)\*/g, '<b>$1</b>');
            div.innerHTML = text;

            messages.prepend(div);
            trimMessages();
        }

        function escapeHTML(str) {
            return str.replace(/[&<>"']/g, m => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            } [m]));
        }


        document.getElementById('chat_tab').addEventListener('shown.bs.offcanvas', () => {
            if (!lastIdAiChat) {
                loadChatHistory();
            }
        });
        document.getElementById('chat_tab').addEventListener('hidden.bs.offcanvas', () => {
            messages.innerHTML = '';
            lastIdAiChat = null;
            hasMoreAiChat = true;
            isLoadingAiChat = false;
            isFirstLoad = true;
        });
        let scrollTimeout;
        messages.addEventListener('scroll', () => {
            if (scrollTimeout) return;
            scrollTimeout = setTimeout(() => {
                scrollTimeout = null;
                if (messages.scrollTop === 0) loadChatHistory();
            }, 200);
        });

        document.querySelector('.clear-all-chat').addEventListener('click', () => {
            fetch(`/aichat-clear-all/${auth_login_user_id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    }
                })
                .then(response => response.json())
                .then(data => {
                    toastr.success("All Chat Cleared");
                    messages.innerHTML = '';
                    lastIdAiChat = null;
                    hasMoreAiChat = true;
                    isLoadingAiChat = false;
                    isFirstLoad = true;
                    loadChatHistory();
                })
                .catch(error => {
                    console.error('Error clearing notifications:', error);
                    toastr.error('Error clearing notifications:', error);

                });
        });
    </script>

    <style>
        .preview-box {
            position: absolute;
            top: 50px;
            /* Moved higher */
            left: 100%;
            transform: translateX(-50%) scale(0.5);
            opacity: 0;
            transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
            background: #fed240;
            border-radius: 12px;
            padding: 8px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.25);
            z-index: 10;
        }

        .preview-box img {
            width: 100px;
            /* Increased size */
            height: 100px;
            /* Increased size */
            border-radius: 10px;
        }

        .profile-image {
            border: 8px solid white;
            /* sets border thickness and color */
            border-radius: 100% !important;
            /* keeps it circular */
            background-color: white;
            /* box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);  */
        }

        .profile-image:hover+.preview-box,
        .profile-image:focus+.preview-box {
            transform: translateX(-50%) scale(1);
            opacity: 1;
        }

        /*.card__img {*/
        /*  height: 192px;*/
        /*  width: 100%;*/
        /*  position: relative;*/
        /*  overflow: visible;*/
        /*}*/
        /* Remove border-radius from .card__img */
        .card__img {
            height: 192px;
            width: 100%;
            position: relative;
            overflow: visible;
            /* allow the image to extend beyond */
            /* border-radius removed here */
        }

        /* Glassmorphic background image for modal */
        .bg-image {
            width: 100%;
            height: 100px;
            /* Fixed height */
            object-fit: cover;
            /* Cover the container without stretching */
            display: block;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;

            /* Glassmorphism effect */
            backdrop-filter: blur(8px);
            /* Blur the background behind */
            background-color: rgba(255, 255, 255, 0.25);
            /* Semi-transparent overlay */
            border: 1px solid rgba(255, 255, 255, 0.18);
            /* Optional subtle border */
        }

        /* Apply full radius to modal content */
        .modal-content {
            border-radius: 12px !important;
            overflow: hidden;
            /* Ensures all modal contents respect the border radius */
        }


        .modal{
             z-index: 9999999 !important;
        }
        .light-style .datepicker-dropdown{
                z-index: 99999999 !important;
        }
        .flatpickr-calendar{
                z-index: 99999999 !important;
        }

        .card__title {
            margin-top: 50px;
            margin-bottom: 0px;
            font-weight: 600;
            font-size: 25px;
            color: black;
            padding: 0px 10px;
        }

        .card__subtitle {
            font-weight: 400;
            font-size: 18px;
            color: black;
            padding: 10px;
        }

        .profile-wrapper {
            z-index: 5;
            margin-top: -20px;
            /* pushes it up over SVG */

        }

        .card__icons {
            display: flex;
            justify-content: center;
            gap: 10px;
            /* Adds space between icons */
            margin-top: 10px;
        }

        .card__icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            /* Fixed width for consistent sizing */
            height: 40px;
            /* Fixed height */
            border-radius: 50%;
            /* Circular icons */
            background-color: #1877F2;
            /* Facebook blue, you can customize */
            transition: background-color 0.3s ease, transform 0.3s ease;
            /* Smooth transitions for color and scale */
        }

        .card__icons a:hover {
            background-color: #0e5bcf;
            /* Slightly darker shade on hover */
            transform: scale(1.1);
            /* Slightly larger on hover */
        }

        .card__icons i {
            font-size: 24px;
            /* Icon size */
        }

        .card__icons a[data-bs-toggle="tooltip"]:hover {
            text-decoration: none;
            /* Ensures no underlining on hover */
        }
    </style>
    <!-- Script -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let profileImage = document.getElementById('uploadedstaffimage');
            let previewBox = document.getElementById('imagePreview');
            let previewImage = document.getElementById('previewImage');

            profileImage.addEventListener("mouseenter", function() {
                previewImage.src = profileImage.src;
                previewBox.style.opacity = "1";
                previewBox.style.transform = "translateX(-50%) scale(1)";
            });

            profileImage.addEventListener("mouseleave", function() {
                previewBox.style.opacity = "0";
                previewBox.style.transform = "translateX(-50%) scale(0.5)";
            });
        });
        document.addEventListener('DOMContentLoaded', () => {
            let staff_add = document.getElementById('uploadedstaffimage');
            const staff_add_fileInput = document.querySelector('.upload_staff_image');
            if (staff_add) {
                const staff_add_resetImage = staff_add.src;
                staff_add_fileInput.onchange = () => {
                    if (staff_add_fileInput.files[0]) {
                        staff_add.src = window.URL.createObjectURL(staff_add_fileInput.files[0]);
                    }
                };
            }
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const passwordInput = document.getElementById("passwordInput");
            const togglePassword = document.querySelector(".toggle-password i");

            document.querySelector(".toggle-password").addEventListener("click", function() {
                if (passwordInput.type === "password") {
                    passwordInput.type = "text";
                    togglePassword.classList.remove("mdi-eye-off");
                    togglePassword.classList.add("mdi-eye");
                } else {
                    passwordInput.type = "password";
                    togglePassword.classList.remove("mdi-eye");
                    togglePassword.classList.add("mdi-eye-off");
                }
            });
        });
    </script>



    <style>
        #loader-text {
            position: relative;
            color: black;
            padding: 5px 0px;
            font-family: monospace;
            font-size: 1rem;
            text-align: center;
            z-index: 10000;
        }
    </style>


    <!-- Tunnel Overlay -->
    <div id="switch-animation" class="switch-animation" style="display:none; ">
        <div class="loading" id="loadingScreen" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999; ">
            <div class="loading-content" style="text-align: center; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);">
                <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; height:100%">
                <div id="loader-text"></div>
                <div class="d-block">
                    <div class="dot red"></div>
                    <div class="dot orange"></div>
                    <div class="dot yellow"></div>
                    <div class="dot green"></div>
                    <div class="dot teal"></div>
                    <div class="dot blue"></div>
                    <div class="dot violet"></div>
                </div>
            </div>
        </div>
    </div>



    <script>
        // ---------- Button Trigger ----------
        function switchErp(entity_id) {
            $('#switch_entity_id').val(entity_id);

            animation_2()
            setTimeout(() => {
                document.getElementById("switch-erp-form").submit();
            }, 4000);
            setTimeout(() => {
                document.getElementById("switch-animation").style.display = 'none';
            }, 120000);
        }
        // function switchErp(entity_id){

        //     $('#switch_entity_id').val(entity_id);

        //     const pill = document.querySelector('.erp-switch-pill');

        //     // click feedback
        //     pill.style.transform = 'scale(0.96)';
        //     pill.style.opacity = '0.7';

        //     // quick transition (feels fast)
        //     setTimeout(()=>{
        //         document.getElementById("switch-erp-form").submit();
        //     }, 400);
        //     setTimeout(()=>{ document.getElementById("switch-animation").style.display='none'; },120000);
        // }

        document.getElementById("switch-animation").style.display = 'none';
    </script>




    <script>
        function animation_2() {

            // Texte glitch dynamique
            const loaderText = document.getElementById('loader-text');
            // const messages = [
            //   "Initializing system . . .",
            //   "Loading core modules . . .",
            //   "Verifying user permissions . . . ",
            //   "Compiling source code . . .",
            //   "Running diagnostics . . .",
            //   "Establishing secure connection . . ."
            // ];
            const messages = [
                "Failure to maintain punctuality is considered disrespectful behavior.",
                "The value of the company is my value.",
                "The customer is our asset; I will satisfy their needs.",
                "I will not spend my time for the negative thoughts.",
                "I will respect other employees and work with them collaboratively.",
                "I won't Come up with my own likes and dislikes into the company.",
                "I won't interfere unnecessarily in the work of my colleagues.",
                "I will utilize my time for new innovations and knowledge development.",
                "I will obey to the laws and regulations of the company.",
                "I will devote my services to the development of the company.",
            ];

            let index = 0;

            // Immediately display the first message
            loaderText.textContent = messages[index];
            index++;

            // Set interval to display the rest of the messages every 1 second
            const interval = setInterval(() => {
                if (index < messages.length) {
                    loaderText.textContent = messages[index];
                    index++;
                } else {
                    clearInterval(interval); // Stop the interval once all messages are displayed
                }
            }, 1500); // 1 second interval for subsequent messages


            document.getElementById("switch-animation").style.display = 'block';
        }
    </script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
            z-index: 99999999 !important;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
            z-index: 99999999 !important;
        }
    </style>

    <script>
        // Display Toastr messages
        @if(Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
        @endif
    </script>

    <script>
        function date_fill_nav_daily_lt() {
            var dt_fill_nav_daily_late = document.getElementById('dt_fill_nav_daily_late').value;
            var today_dt_nav_daily_late = document.getElementById('today_dt_nav_daily_late');
            var week_from_dt_nav_daily_late = document.getElementById('week_from_dt_nav_daily_late');
            var week_to_dt_nav_daily_late = document.getElementById('week_to_dt_nav_daily_late');
            var monthly_dt_nav_daily_late = document.getElementById('monthly_dt_nav_daily_late');
            var from_dt_nav_daily_late = document.getElementById('from_dt_nav_daily_late');
            var to_dt_nav_daily_late = document.getElementById('to_dt_nav_daily_late');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_nav_daily_late == "today") {
                today_dt_nav_daily_late.style.display = "block";
                monthly_dt_nav_daily_late.style.display = "none";
                from_dt_nav_daily_late.style.display = "none";
                to_dt_nav_daily_late.style.display = "none";
                week_from_dt_nav_daily_late.style.display = "none";
                week_to_dt_nav_daily_late.style.display = "none";
            } else if (dt_fill_nav_daily_late == "week") {
                today_dt_nav_daily_late.style.display = "none";
                week_from_dt_nav_daily_late.style.display = "block";
                week_to_dt_nav_daily_late.style.display = "block";
                monthly_dt_nav_daily_late.style.display = "none";
                from_dt_nav_daily_late.style.display = "none";
                to_dt_nav_daily_late.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#nav_daily_lt_week_st_dt_fill').val(firstday);
                $('#nav_daily_lt_week_ed_dt_fill').val(lastday);

            } else if (dt_fill_nav_daily_late == "monthly") {
                today_dt_nav_daily_late.style.display = "none";
                monthly_dt_nav_daily_late.style.display = "block";
                from_dt_nav_daily_late.style.display = "none";
                to_dt_nav_daily_late.style.display = "none";
                week_from_dt_nav_daily_late.style.display = "none";
                week_to_dt_nav_daily_late.style.display = "none";
            } else if (dt_fill_nav_daily_late == "custom_date") {
                today_dt_nav_daily_late.style.display = "none";
                monthly_dt_nav_daily_late.style.display = "none";
                from_dt_nav_daily_late.style.display = "block";
                to_dt_nav_daily_late.style.display = "block";
                week_from_dt_nav_daily_late.style.display = "none";
                week_to_dt_nav_daily_late.style.display = "none";
            } else {
                today_dt_nav_daily_late.style.display = "none";
                monthly_dt_nav_daily_late.style.display = "none";
                from_dt_nav_daily_late.style.display = "none";
                to_dt_nav_daily_late.style.display = "none";
                week_from_dt_nav_daily_late.style.display = "none";
                week_to_dt_nav_daily_late.style.display = "none";
            }
        }
    </script>
    <script>
        function openCTCCalculator(){
            $("#kt_modal_payrollcalculator").modal("show");
            $("#ctc_entity").val("").trigger("change");
            $("#ctc_salary_company").html(
                '<option value="">Choose Salary Company</option>'
            );
           
            $("#ctc_staff").html(
                '<option value="">Select Employee</option>'
            );
            $("#ctcCalculatorBody").html(`
                <div class="text-center py-5">
                    <i class="mdi mdi-calculator fs-1 text-muted"></i>
                    <h5>Select Company & Employee</h5>
                </div>
            `);
        }

        function loadCTCStaff(entityId) {
            $('#ctc_staff').html(
                '<option value="">Loading Employees...</option>'
            );
            $('#ctcResult').hide();

            if(entityId==""){
                $('#ctc_staff').html(
                    '<option value="">Select Employee</option>'
                );
                return;
            }
            entityId = entityId == 'egc' ? 0 : entityId;
            $.ajax({
                url:'/staff_list_by_entity',
                type:'GET',
                data:{
                    entity_id:entityId
                },
                success:function(res){
                    let html='<option value="">Select Employee</option>';
                    res.data.forEach(function(emp){
                        html += `
                            <option value="${emp.sno}">
                                ${emp.staff_name}
                                (${emp.staff_id})
                            </option>
                        `;
                    });

                    $('#ctc_staff').html(html);

                },
                error:function(){
                    toastr.error("Unable to load employees.");
                }
            });

        }

        function showCTCLoader(){
            $('#ctcResult').hide();
            $('#ctcLoading').html(`
                <div class="text-center py-5">
                    <div class="spinner-border text-primary"
                        style="width:3rem;height:3rem">
                    </div>
                    <div class="mt-3 fw-semibold">
                        Preparing Salary Structure...
                    </div>
                    <small class="text-muted">
                        Please wait...
                    </small>
                </div>
            `);
        }

        function hideCTCLoader(){
            $('#ctcLoading').html('');
        }
        function loadCTCCalculator(staffId){
            showCTCLoader();
            $.ajax({
                url:'/payroll/ctc-calculator/'+staffId,
                type:'GET',
                success:function(res){

                    hideCTCLoader();

                    if(!res.status){

                        toastr.error(res.message);

                        return;

                    }

                    renderCTCModal(res);

                    $('#ctcResult').fadeIn();

                },

                error:function(){

                    hideCTCLoader();

                    toastr.error('Unable to load CTC.');

                }

            });
        }

        function changeCTCStaff() {
            let staffId = $('#ctc_staff').val();
            if(staffId == ''){
                $('#ctcCalculatorBody').html(`
                    <div class="text-center py-5">
                        <i class="mdi mdi-calculator fs-1 text-muted"></i>
                        <h5>Select Employee</h5>
                    </div>
                `);
                return;
            }
            loadCTCCalculator(staffId);

        }

        function renderCTCModal(res){
            let d = res.data;
            let html = `
            <div class="row">
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body text-center">
                            <img src="${d.profile_image_url}"
                                class="rounded-circle shadow"
                                style="width:95px;height:95px;object-fit:cover;">
                            <h4 class="mt-3 mb-0">
                                ${d.staff_name}
                            </h4>
                            <small class="text-muted">
                                ${d.staff_code}
                            </small>
                            <div class="mt-2">
                                <span class="badge bg-primary">
                                    ${d.department_name}
                                </span>
                                <span class="badge" style="background-color:${d.entity_base_color || '#ab2b22'}">
                                    ${d.entity_name}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <table class="table table-sm mb-0">
                                <tr>
                                    <td>Salary Company</td>
                                    <td class="text-end fw-bold">${d.salary_company}</td>
                                </tr>
                                <tr>
                                    <td>Salary Type</td>
                                    <td class="text-end fw-bold">${d.salary_type}</td>
                                </tr>
                                <tr>
                                    <td>DOJ</td>
                                    <td class="text-end fw-bold">${d.doj}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="card bg-label-primary  shadow">
                                <div class="card-body">
                                    <small>Monthly CTC</small>
                                    <h3 class="mt-2">
                                        ₹ ${numberFormatNav(d.monthly_ctc)}
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-label-success shadow">
                                <div class="card-body">
                                    <small>Annual CTC</small>
                                    <h3 class="mt-2">
                                        ₹ ${numberFormatNav(d.annual_ctc)}
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-label-warning shadow">
                                <div class="card-body">
                                    <small>Net Salary</small>
                                    <h3 class="mt-2">
                                        ₹ ${numberFormatNav(d.net_salary)}
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="salaryComponentsNav" class="mt-4"></div>
                </div>
            </div>
            `;

            $("#ctcCalculatorBody").html(html);
            rendersalaryComponentsNav(d.components);
        }

        function numberFormatNav(number){
            return Number(number).toLocaleString('en-IN',{
                minimumFractionDigits:0,
                maximumFractionDigits:0
            });
        }

        function rendersalaryComponentsNav(components){

            let earningRows='';
            let deductionRows='';
            let employerRows='';

            let totalEarning=0;
            let totalDeduction=0;
            let employerTotal=0;

            components.forEach(function(item){

                let row=`
                    <tr>
                        <td style="
                            white-space:normal;
                            word-break:break-word;
                        ">
                            ${item.component}
                        </td>
                        <td class="text-end text-nowrap">
                            ₹ ${numberFormatNav(item.monthly)}
                        </td>

                        <td class="text-end text-nowrap">
                            ₹ ${numberFormatNav(item.annual)}
                        </td>

                        <td class="text-end text-nowrap">
                            ${item.percentage}%
                        </td>
                    </tr>
                `;

                if(item.category=="earning"){

                    earningRows+=row;
                    totalEarning+=parseFloat(item.monthly);

                }

                if(item.category=="deduction"){

                    deductionRows+=row;
                    totalDeduction+=parseFloat(item.monthly);

                }

                if(item.category=="employer"){

                    employerRows+=row;
                    employerTotal+=parseFloat(item.monthly);

                }

            });

            if (earningRows === '') {
                earningRows = `
                    <tr>
                        <td colspan="4" class="text-center text-muted py-4">
                            <i class="mdi mdi-information-outline fs-3 d-block mb-2"></i>
                            No earning components found.
                        </td>
                    </tr>
                `;
            }

            // Deductions
            if (deductionRows === '') {
                deductionRows = `
                    <tr>
                        <td colspan="4" class="text-center text-muted py-4">
                            <i class="mdi mdi-information-outline fs-3 d-block mb-2"></i>
                            No deduction components found.
                        </td>
                    </tr>
                `;
            }

            // Employer Contribution
            if (employerRows === '') {
                employerRows = `
                    <tr>
                        <td colspan="4" class="text-center text-muted py-4">
                            <i class="mdi mdi-information-outline fs-3 d-block mb-2"></i>
                            No employer contribution components found.
                        </td>
                    </tr>
                `;
            }

            $("#salaryComponentsNav").html(`
                <div class="row g-4">
                    <div class="col-lg-6">
                        <div class="card shadow-sm border-success">
                            <div class="card-header bg-label-success ">
                                <h5 class="mb-0"><i class="mdi mdi-plus-circle"></i> Earnings</h5>
                            </div>
                            <div class="card-body p-2">
                                <div class="table-responsive-lg">
                                <table class="table table-sm align-middle table-striped table-hover mb-0" style="table-layout:fixed;width:100%;">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                            <th style="width:46%;">Component</th>
                                            <th class="text-end" style="width:18%;">Monthly</th>
                                            <th class="text-end" style="width:18%;">Annual</th>
                                            <th class="text-end" style="width:18%;">%</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${earningRows}
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-success text-black">
                                            <th class="text-black">Total</th>
                                            <th class="text-end text-success">
                                                ₹ ${numberFormatNav(totalEarning)}
                                            </th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card shadow-sm border-danger">
                            <div class="card-header bg-label-danger ">
                                <h5 class="mb-0"><i class="mdi mdi-minus-circle"></i> Deductions</h5>
                            </div>
                            <div class="card-body p-2">
                                <div class="table-responsive-lg">
                                    <table class="table table-sm align-middle table-striped table-hover mb-0" style="table-layout:fixed;width:100%;">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                                <th style="width:46%;">Component</th>
                                                <th class="text-end" style="width:18%;">Monthly</th>
                                                <th class="text-end" style="width:18%;">Annual</th>
                                                <th class="text-end" style="width:18%;">%</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${deductionRows}
                                        </tbody>
                                        <tfoot>
                                            <tr class="table-danger text-black">
                                                <th class="text-black">Total</th>
                                                <th class="text-end text-danger">
                                                    ₹ ${numberFormatNav(totalDeduction)}
                                                </th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>

                <div class="card shadow-sm h-100">
                    <div class="card-header bg-label-primary">
                        <h5 class="mb-0">Employer Contribution</h5>
                    </div>
                    <div class="card-body p-2">
                        <div class="table-responsive-lg">
                        <table class="table table-sm align-middle table-striped table-hover mb-0" style="table-layout:fixed;width:100%;">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                    <th style="width:46%;">Component</th>
                                    <th class="text-end" style="width:18%;">Monthly</th>
                                    <th class="text-end" style="width:18%;">Annual</th>
                                    <th class="text-end" style="width:18%;">%</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${employerRows}
                            </tbody>
                            <tfoot>
                                <tr class="table-primary text-black">
                                    <th class="text-black">Total Employer Cost</th>
                                    <th class="text-end text-primary">
                                    ₹ ${numberFormatNav(employerTotal)}
                                    </th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                        </div>
                    </div>
                </div>
            `);

        }

        function recalculateCTC(){

            let components=[];

            $('.componentRow').each(function(){

                components.push({

                    component:$(this).data('component'),

                    category:$(this).data('category'),

                    percentage:$(this).find('.percentage').val(),

                    monthly:$(this).find('.monthly').val()

                });

            });

            $.ajax({

                url:'/payroll/ctc-calculator/calculate',

                type:'POST',

                data:{
                    _token:$('meta[name="csrf-token"]').attr('content'),
                    components:components
                },

                success:function(res){

                    if(!res.status){
                        toastr.error(res.message);
                        return;
                    }

                    updateSummary(res.summary);

                }

            });

        }

        $('.componentAmount').on('keyup change', function () {
            recalculateCTC();
        });
    </script>