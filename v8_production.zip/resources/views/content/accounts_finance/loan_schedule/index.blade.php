@extends('layouts.layoutMaster')

@section('title', 'Loans & Schedules')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
<style>
    :root {
        --loan-red: #b52b22;
        --loan-red-dark: #8f211b;
        --loan-gold: #f6b51d;
        --loan-green: #16803b;
        --loan-blue: #0f6ea8;
        --loan-amber: #b7791f;
        --loan-page: #f5f6f8;
        --loan-border: #e2e5ea;
        --loan-text: #1f2937;
        --loan-muted: #6b7280;
    }

    .loan-page {
        color: var(--loan-text);
    }

    .loan-page .loan-header-card {
        background: #ffffff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .05);
    }

    .loan-page .loan-title {
        color: var(--loan-red);
        font-weight: 700;
        letter-spacing: -.2px;
    }

    .loan-page .loan-subtitle {
        color: var(--loan-muted);
        font-size: 13px;
    }

    .loan-page .loan-primary-btn {
        background: var(--loan-red);
        color: #fff;
        border: 1px solid var(--loan-red);
        font-weight: 700;
        box-shadow: 0 4px 10px rgba(181, 43, 34, .16);
    }

    .loan-page .loan-primary-btn:hover {
        background: var(--loan-red-dark);
        border-color: var(--loan-red-dark);
        color: #fff;
    }

    .loan-page .loan-gold-btn {
        background: var(--loan-gold);
        color: #171717;
        border-color: var(--loan-gold);
        font-weight: 700;
    }

    .loan-page .loan-outline-btn {
        background: #fff;
        border: 1px solid #d7dbe1;
        color: #4b5563;
        font-weight: 600;
    }

    .loan-page .loan-outline-btn:hover {
        background: #f9fafb;
        color: var(--loan-red);
        border-color: #c7ccd4;
    }

    .loan-page .loan-kpi {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 12px;
        padding: 16px;
        min-height: 108px;
        position: relative;
        overflow: hidden;
    }

    .loan-page .loan-kpi::after {
        content: "";
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: rgba(181, 43, 34, .05);
        position: absolute;
        right: -18px;
        top: -18px;
    }

    .loan-page .loan-kpi-label {
        color: #6b7280;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .4px;
    }

    .loan-page .loan-kpi-value {
        color: #1f3864;
        font-size: 24px;
        line-height: 1.1;
        font-weight: 800;
        margin-top: 5px;
    }

    .loan-page .loan-kpi-meta {
        color: #6b7280;
        font-size: 12px;
        margin-top: 5px;
    }

    .loan-page .loan-filter-card,
    .loan-page .loan-table-card {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .04);
    }

    .loan-page .loan-filter-card {
        padding: 14px;
    }

    .loan-page .loan-label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: #4b5563;
        margin-bottom: 6px;
    }

    .loan-page .loan-input,
    .loan-page .loan-select {
        min-height: 41px;
        border-color: #d9dde4;
        border-radius: 9px;
        font-size: 13px;
    }

    .loan-page .loan-input:focus,
    .loan-page .loan-select:focus {
        border-color: var(--loan-red);
        box-shadow: 0 0 0 .18rem rgba(181, 43, 34, .10);
    }

    .loan-page .loan-chip-row {
        display: flex;
        flex-wrap: wrap;
        gap: 7px;
    }

    .loan-page .loan-filter-chip {
        border: 1px solid #dfe3e8;
        background: #fff;
        color: #4b5563;
        border-radius: 999px;
        padding: 7px 13px;
        font-size: 12px;
        font-weight: 700;
        transition: .15s ease;
    }

    .loan-page .loan-filter-chip:hover {
        border-color: var(--loan-red);
        color: var(--loan-red);
    }

    .loan-page .loan-filter-chip.active {
        color: #fff;
        background: var(--loan-red);
        border-color: var(--loan-red);
    }

    .loan-page .loan-table-wrap {
        overflow-x: auto;
        /* border-radius: 14px; */
    }

    .loan-page table.loan-table {
        width: 100%;
        min-width: 1120px;
        border-collapse: separate;
        border-spacing: 0;
        margin: 0;
    }

    .loan-page .loan-table thead th {
        background: var(--loan-red);
        color: #fff;
        border: 0;
        padding: 12px 14px;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
        position: sticky;
        top: 0;
        z-index: 2;
    }

    .loan-page .loan-table thead th:first-child {
        /* border-top-left-radius: 12px; */
    }

    .loan-page .loan-table thead th:last-child {
        /* border-top-right-radius: 12px; */
    }

    .loan-page .loan-table tbody td {
        padding: 13px 14px;
        border-bottom: 1px solid #eef0f3;
        vertical-align: middle;
        font-size: 13px;
    }

    .loan-page .loan-table tbody tr:nth-child(even) {
        background: #fbfbfc;
    }

    .loan-page .loan-table tbody tr:hover {
        background: #fff8e7;
    }

    .loan-page .loan-account {
        color: #1f3864;
        font-weight: 800;
        font-size: 13px;
    }

    .loan-page .loan-name {
        font-weight: 700;
        color: #252c36;
    }

    .loan-page .loan-muted {
        color: #727985;
        font-size: 11px;
    }

    .loan-page .loan-type-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border-radius: 7px;
        background: #fff4d6;
        color: #805c00;
        font-weight: 700;
        font-size: 11px;
        white-space: nowrap;
    }

    .loan-page .loan-status {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        white-space: nowrap;
    }

    .loan-page .status-active { background: #e9f7ee; color: #16803b; }
    .loan-page .status-pending { background: #fff4df; color: #9a6300; }
    .loan-page .status-closed { background: #eef0f3; color: #6b7280; }
    .loan-page .status-returned { background: #fdeaea; color: #b3261e; }
    .loan-page .status-overdue { background: #fdeaea; color: #b3261e; }
    .loan-page .status-today { background: #fff4df; color: #b7791f; }
    .loan-page .status-upcoming { background: #edf4fa; color: #0f6ea8; }
    .loan-page .status-paid { background: #e9f7ee; color: #16803b; }

    .loan-page .loan-days-pill {
        font-size: 11px;
        font-weight: 800;
        border-radius: 999px;
        padding: 4px 8px;
    }

    .loan-page .loan-days-pill.danger { background: #fdeaea; color: #b3261e; }
    .loan-page .loan-days-pill.warn { background: #fff4df; color: #b7791f; }
    .loan-page .loan-days-pill.normal { background: #edf4fa; color: #0f6ea8; }

    .loan-page .loan-progress {
        min-width: 96px;
    }

    .loan-page .loan-progress-track {
        height: 6px;
        border-radius: 99px;
        background: #edf0f4;
        overflow: hidden;
    }

    .loan-page .loan-progress-bar {
        height: 100%;
        border-radius: 99px;
        background: var(--loan-green);
    }

    .loan-page .loan-action-btn {
        width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #dfe3e8;
        border-radius: 8px;
        color: #4b5563;
        background: #fff;
    }

    .loan-page .loan-action-btn:hover {
        color: var(--loan-red);
        border-color: #cfd4db;
        background: #fff9f8;
    }

    .loan-page .loan-loading {
        padding: 44px 20px;
        text-align: center;
        color: #7a818d;
    }

    .loan-page .loan-skeleton,
    .loan-skeleton {
        position: relative;
        display: block;
        overflow: hidden;
        background: #edf0f3;
        border-radius: 7px;
    }

    .loan-page .loan-skeleton::after,
    .loan-skeleton::after {
        content: '';
        position: absolute;
        inset: 0;
        transform: translateX(-100%);
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.72), transparent);
        animation: loanSkeletonShimmer 1.35s ease-in-out infinite;
    }

    @keyframes loanSkeletonShimmer {
        100% { transform: translateX(100%); }
    }

    .loan-skeleton-row td {
        padding-top: 14px !important;
        padding-bottom: 14px !important;
    }

    .loan-skeleton-group {
        display: flex;
        flex-direction: column;
        gap: 7px;
    }

    .loan-skeleton-pill { border-radius: 999px; }
    .loan-skeleton-actions { border-radius: 9px; }
    .loan-skeleton-line { margin-left: 0; margin-right: auto; }
    .loan-skeleton-line-sm { width: 120px; height: 9px; }
    .loan-skeleton-line-md { width: 210px; height: 11px; }
    .loan-skeleton-line-lg { width: 72%; height: 15px; }
    .loan-skeleton-circle { width: 52px; height: 52px; border-radius: 50%; margin: 0 auto; }
    .loan-skeleton-card { height: 72px; border-radius: 12px; }
    .loan-view-skeleton { text-align: left; }

    @media (prefers-reduced-motion: reduce) {
        .loan-skeleton::after { animation: none; }
    }

    .loan-page .loan-empty {
        padding: 60px 18px;
        text-align: center;
        color: #7a818d;
    }

    .loan-page .loan-empty-icon {
        width: 60px;
        height: 60px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 16px;
        background: #fff4d6;
        color: #9a6b00;
        font-size: 28px;
        margin-bottom: 12px;
    }

    .loan-page .loan-modal .modal-header {
        background: var(--loan-red);
        color: #fff;
        border-bottom: 0;
    }

    .loan-page .loan-modal .modal-title {
        font-weight: 700;
    }

    .loan-page .loan-modal .btn-close {
        filter: brightness(0) invert(1);
    }

    .loan-page .loan-type-card {
        border: 1px solid #e0e4e8;
        border-radius: 12px;
        padding: 13px;
        height: 100%;
        cursor: pointer;
        background: #fff;
        transition: .15s;
    }

    .loan-page .loan-type-card:hover {
        border-color: var(--loan-red);
    }

    .loan-page .loan-type-card.active {
        border-color: var(--loan-red);
        background: #fff8f7;
        box-shadow: 0 0 0 2px rgba(181, 43, 34, .08);
    }

    .loan-page .loan-type-icon {
        width: 38px;
        height: 38px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        background: #fff4d6;
        color: #7e5c00;
        font-size: 20px;
        margin-bottom: 7px;
    }

    .loan-page .loan-advanced {
        background: #fafbfc;
        border: 1px solid #e8ebef;
        border-radius: 10px;
        padding: 12px;
    }

    .loan-page .loan-error {
        color: #b3261e;
        font-size: 11px;
        min-height: 16px;
        margin-top: 4px;
    }

    .loan-page .loan-pagination .page-link {
        border-radius: 8px !important;
        margin: 0 2px;
        color: var(--loan-red);
    }

    .loan-page .loan-pagination .active .page-link {
        background: var(--loan-red);
        border-color: var(--loan-red);
        color: #fff;
    }

    @media (max-width: 991.98px) {
        .loan-page .loan-title {
            font-size: 20px;
        }
    }

    @media (max-width: 767.98px) {
        .loan-page .loan-header-card {
            border-radius: 10px;
        }

        .loan-page .loan-kpi-value {
            font-size: 20px;
        }

        .loan-page .loan-filter-chip {
            padding: 6px 10px;
        }

        .loan-page .loan-modal .modal-dialog {
            margin: 10px;
        }
    }
</style>

<style>
    #loanSchedulePage,
    #loanFormModal,
    #loanViewModal,
    #loanReturnModal {
        --loan-ui-red: #b52b22;
        --loan-ui-red-dark: #8f211b;
        --loan-ui-gold: #f6b51d;
        --loan-ui-border: #e4e7ec;
        --loan-ui-soft: #f8fafc;
        --loan-ui-text: #1f2937;
        --loan-ui-muted: #6b7280;
    }

    /* Select3 / Select2 */
    #loanSchedulePage .select3 + .select2,
    #loanFormModal .select3 + .select2 {
        width: 100% !important;
    }

    #loanSchedulePage .select2-container--default .select2-selection--single,
    #loanFormModal .select2-container--default .select2-selection--single {
        min-height: 41px;
        height: 41px;
        display: flex;
        align-items: center;
        border: 1px solid #d9dde4;
        border-radius: 9px;
        background: #fff;
        transition: border-color .15s ease, box-shadow .15s ease;
    }

    #loanSchedulePage .select2-container--default.select2-container--open .select2-selection--single,
    #loanFormModal .select2-container--default.select2-container--open .select2-selection--single {
        border-color: var(--loan-ui-red);
        box-shadow: 0 0 0 .18rem rgba(181, 43, 34, .10);
    }

    #loanSchedulePage .select2-container--default .select2-selection--single .select2-selection__rendered,
    #loanFormModal .select2-container--default .select2-selection--single .select2-selection__rendered {
        width: 100%;
        padding: 0 38px 0 12px;
        color: #374151;
        font-size: 13px;
        line-height: 39px;
    }

    #loanSchedulePage .select2-container--default .select2-selection--single .select2-selection__placeholder,
    #loanFormModal .select2-container--default .select2-selection--single .select2-selection__placeholder {
        color: #9ca3af;
    }

    #loanSchedulePage .select2-container--default .select2-selection--single .select2-selection__arrow,
    #loanFormModal .select2-container--default .select2-selection--single .select2-selection__arrow {
        top: 50%;
        right: 8px;
        width: 26px;
        height: 26px;
        transform: translateY(-50%);
    }

    #loanSchedulePage .select2-container--default .select2-selection--single .select2-selection__arrow b,
    #loanFormModal .select2-container--default .select2-selection--single .select2-selection__arrow b {
        margin-top: -4px;
        margin-left: -4px;
        border-color: #6b7280 transparent transparent transparent;
    }

    .loan-select3-dropdown {
        border: 1px solid #dfe3e8;
        border-radius: 11px;
        overflow: hidden;
        box-shadow: 0 16px 40px rgba(15, 23, 42, .16);
    }

    .loan-select3-dropdown .select2-search--dropdown {
        padding: 9px;
        background: #fff;
        border-bottom: 1px solid #eef0f3;
    }

    .loan-select3-dropdown .select2-search__field {
        min-height: 37px;
        border: 1px solid #d9dde4;
        border-radius: 8px;
        outline: 0;
        padding: 6px 10px;
        font-size: 13px;
    }

    .loan-select3-dropdown .select2-results__option {
        padding: 9px 11px;
        font-size: 13px;
    }

    .loan-select3-dropdown .select2-results__option--highlighted[aria-selected] {
        background: var(--loan-ui-red);
    }

    .loan-select3-dropdown .select2-results__option[aria-selected="true"] {
        background: #fff3f1;
        color: var(--loan-ui-red);
        font-weight: 700;
    }

    /* Form modal */
    #loanFormModal .modal-content,
    #loanViewModal .modal-content,
    #loanReturnModal .modal-content {
        border-radius: 18px;
        overflow: hidden;
        border: 0;
    }

    #loanFormModal .modal-header {
        padding: 18px 22px;
        /* background:
            radial-gradient(circle at 88% 15%, rgba(255,255,255,.20), transparent 34%),
            linear-gradient(135deg, #9b241d 0%, #b52b22 55%, #c84034 100%); */
        box-shadow: 0 7px 24px rgba(181, 43, 34, .18);
    }

    #loanFormModal .modal-header .modal-title {
        font-size: 18px;
        letter-spacing: -.15px;
    }

    #loanFormModal .modal-body {
        background: #f8fafc;
        padding: 20px;
    }

    #loanFormModal .card.bg-light,
    #loanFormModal .loan-advanced {
        border-radius: 14px;
        border-color: var(--loan-ui-border) !important;
        box-shadow: 0 3px 12px rgba(15, 23, 42, .025);
    }

    #loanFormModal .card.bg-light {
        background: linear-gradient(180deg, #ffffff 0%, #fbfcfd 100%) !important;
    }

    #loanFormModal .loan-type-card {
        min-height: 138px;
        padding: 15px;
        border: 1px solid #e1e5ea;
        border-radius: 13px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(15, 23, 42, .025);
        transition: transform .16s ease, border-color .16s ease, box-shadow .16s ease, background .16s ease;
    }

    #loanFormModal .loan-type-card:hover {
        transform: translateY(-2px);
        border-color: rgba(181, 43, 34, .45);
        box-shadow: 0 9px 22px rgba(15, 23, 42, .08);
    }

    #loanFormModal .loan-type-card.active {
        transform: translateY(-1px);
        border-color: var(--loan-ui-red);
        background: linear-gradient(135deg, #fff 0%, #fff6f4 100%);
        box-shadow:
            0 0 0 2px rgba(181, 43, 34, .08),
            0 10px 24px rgba(181, 43, 34, .10);
    }

    #loanFormModal .loan-type-icon {
        width: 42px;
        height: 42px;
        margin-bottom: 10px;
        border-radius: 12px;
        background: linear-gradient(135deg, #fff4d6, #fff9ec);
        border: 1px solid #f7e5a9;
        display:flex;
        justify-content:center;
        align-items:center;
    }

    #loanFormModal .loan-input,
    #loanFormModal .loan-select {
        min-height: 41px;
    }

    #loanFormModal textarea.loan-input {
        min-height: 92px;
        resize: vertical;
    }

    #loanFormModal .loan-label {
        color: #374151;
        letter-spacing: .05px;
    }

    #loanFormModal .loan-error:empty {
        display: none;
    }

    #loanFormModal .loan-error:not(:empty) {
        margin-top: 5px;
        line-height: 1.4;
    }

    #loanFormModal .modal-footer {
        position: sticky;
        bottom: 0;
        z-index: 5;
        padding: 12px 20px;
        border-top: 1px solid #e5e7eb;
        box-shadow: 0 -8px 20px rgba(15, 23, 42, .05);
    }

    #loanFormModal #loanSaveBtn {
        min-width: 185px;
        min-height: 40px;
        border-radius: 9px;
    }

    /* View modal */
    #loanViewModal .modal-body {
        background: #f8fafc;
        padding: 20px;
    }

    #loanViewModal .card {
        border-color: #e5e8ed !important;
        border-radius: 14px;
        box-shadow: 0 3px 12px rgba(15, 23, 42, .035);
    }

    #loanReturnModal .modal-body {
        background: #fbfcfd;
    }

    @media (max-width: 767.98px) {
        #loanFormModal .modal-body,
        #loanViewModal .modal-body {
            padding: 14px;
        }

        /* Legacy multi-step layout removed; form is intentionally single-page. */
        #loanFormModal .loan-step {
            min-height: auto;
        }

        #loanFormModal .modal-footer {
            padding: 10px 14px;
        }

        #loanFormModal #loanSaveBtn {
            min-width: 0;
            flex: 1;
        }
    }
    .loan-form-section-intro { border:1px solid #e9edf2; background:#fff; border-radius:13px; padding:12px 14px; }
    .loan-section-head { display:flex; align-items:center; gap:10px; }
    .loan-section-head-compact { padding:0; }
    .loan-section-number { width:30px; height:30px; border-radius:10px; display:inline-flex; align-items:center; justify-content:center; background:#fff1ef; color:var(--loan-red); font-size:12px; font-weight:900; flex:0 0 30px; }
    .loan-section-title { font-size:13px; font-weight:850; color:#1f2937; }
    .loan-section-copy { font-size:11px; color:#7b8491; margin-top:1px; }
    #loanTypeCards .loan-type-card { height:100%; cursor:pointer; transition:.18s ease; }
    #loanTypeCards .loan-type-card:hover { transform:translateY(-1px); border-color:#d9b6b2; }
    #loanTypeCards .loan-type-card.active { border-color:var(--loan-red); box-shadow:0 5px 18px rgba(181,43,34,.10); background:#fff9f8; }
    .loan-view-hero { border-radius:16px; padding:18px; color:#fff; background:linear-gradient(135deg,#b52b22 0%,#8f211b 100%); position:relative; overflow:hidden; }
    .loan-view-hero:after { content:""; width:180px; height:180px; border:28px solid rgba(246,181,29,.13); border-radius:50%; position:absolute; right:-65px; top:-95px; }
    .loan-view-money { font-size:25px; line-height:1.1; font-weight:900; }
    .loan-view-meta { font-size:11px; opacity:.82; }
    .loan-view-tabs { display:flex; gap:0; overflow:auto; border-bottom:1px solid #e8ecf1; background:#fff; }
    .loan-view-tab { flex:0 0 auto; border:0; background:#fff; color:#717b88; padding:11px 15px; font-size:11px; font-weight:800; border-bottom:2px solid transparent; }
    .loan-view-tab.active { color:var(--loan-red); border-bottom-color:var(--loan-red); }
    .loan-info-card { background:#fff; border:1px solid #e8edf2; border-radius:12px; padding:12px; height:100%; }
    .loan-info-label { font-size:10px; font-weight:800; color:#88919d; text-transform:uppercase; letter-spacing:.04em; }
    .loan-info-value { margin-top:3px; font-size:13px; font-weight:800; color:#27303a; word-break:break-word; }
    .loan-view-table { width:100%; min-width:850px; border-collapse:separate; border-spacing:0; }
    .loan-view-table th { background:#b52b22; color:#fff; padding:9px 10px; font-size:10px; white-space:nowrap; }
    .loan-view-table td { padding:9px 10px; border-bottom:1px solid #edf0f3; font-size:11px; vertical-align:middle; }
    .loan-view-table tbody tr:nth-child(even) { background:#fbfcfd; }
    .loan-view-scroll { overflow:auto; border:1px solid #e8edf2; border-radius:12px; }
    .loan-action-menu .dropdown-menu { min-width:205px; border:1px solid #e6e9ee; box-shadow:0 12px 35px rgba(15,23,42,.13); }
    .loan-action-menu .dropdown-item { font-size:12px; padding:9px 12px; }
    .loan-action-menu .dropdown-item i { width:18px; }
    .loan-modal .modal-content { border:0; border-radius:18px; overflow:hidden; box-shadow:0 28px 90px rgba(15,23,42,.18); }
    .loan-modal .modal-header { border-bottom:1px solid #edf0f3; padding:16px 18px; }
    .loan-modal .modal-footer { border-top:1px solid #edf0f3; }
    .loan-lender-form { background:#f8fafc; border:1px solid #e6ebf1; border-radius:14px; padding:14px; }
    .loan-lender-table th { font-size:10px; text-transform:uppercase; letter-spacing:.05em; white-space:nowrap; }
    .loan-lender-table td { font-size:12px; vertical-align:middle; }
    .loan-toggle { width:2.25rem!important; height:1.15rem!important; cursor:pointer; }
    .loan-confirm-icon { width:44px; height:44px; border-radius:14px; display:flex; align-items:center; justify-content:center; background:#fff4df; color:#9a6300; font-size:21px; }
    @media(max-width:767.98px){ .loan-view-money{font-size:21px}.loan-form-section-intro{padding:10px 11px} }

</style>

<div
    class="container-fluid loan-page py-3"
    id="loanSchedulePage"
    data-loan-module="1"
>
    <div class="loan-header-card p-3 p-lg-4 mb-3">
        <div class="d-flex flex-column flex-xl-row align-items-xl-center justify-content-between gap-3">
            <div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <h4 class="loan-title mb-0">Loans &amp; Schedules</h4>
                    <span class="badge bg-light-danger text-danger fw-semibold">
                        Accounts &amp; Finance
                    </span>
                </div>

                <!-- <div class="loan-subtitle mt-1">
                    Central register, repayment schedule, calendar, payments and finance actions.
                </div> -->

                <div class="mt-2 small text-muted">
                    <i class="mdi mdi-home-outline me-1"></i>
                    Home
                    <span class="mx-1">/</span>
                    Accounts &amp; Finance
                    <span class="mx-1">/</span>
                    <span class="text-dark fw-semibold">Loans &amp; Schedules</span>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2 flex-wrap">
                <a
                    href="{{ route('accounts-finance-loans-calendar') }}"
                    class="btn loan-outline-btn"
                >
                    <i class="mdi mdi-calendar-month-outline me-1"></i>
                    Calendar
                </a>

                <button
                    type="button"
                    class="btn loan-outline-btn"
                    id="loanManageLendersBtn"
                >
                    <i class="mdi mdi-cog-outline me-1"></i>
                    Manage Lenders
                </button>

                <button
                    type="button"
                    class="btn loan-primary-btn"
                    id="loanAddBtn"
                >
                    <i class="mdi mdi-plus me-1"></i>
                    Add Loan
                </button>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Total Outstanding</div>
                <div class="loan-kpi-value" id="loanKpiOutstanding">₹0</div>
                <div class="loan-kpi-meta" id="loanKpiOutstandingMeta">Active exposure</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Due This Week</div>
                <div class="loan-kpi-value" id="loanKpiDue">0</div>
                <div class="loan-kpi-meta" id="loanKpiDueMeta">₹0</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Overdue</div>
                <div class="loan-kpi-value text-danger" id="loanKpiOverdue">0</div>
                <div class="loan-kpi-meta" id="loanKpiOverdueMeta">₹0 outstanding dues</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="loan-kpi">
                <div class="loan-kpi-label">Watchlist</div>
                <div class="loan-kpi-value" id="loanKpiWatch">0</div>
                <div class="loan-kpi-meta" id="loanKpiWatchMeta">Renewals + redemptions</div>
            </div>
        </div>
    </div>

    <div class="loan-filter-card mb-3">
        <div class="row g-3">
            <div class="col-12">
                <div class="loan-chip-row">
                    <button type="button" class="loan-filter-chip active" data-loan-type="">
                        All
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="vehicle">
                        <i class="mdi mdi-car-outline me-1"></i> Vehicle
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="term">
                        <i class="mdi mdi-file-document-outline me-1"></i> Term
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="jewel">
                        <i class="mdi mdi-diamond-stone me-1"></i> Jewel
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="cc">
                        <i class="mdi mdi-bank-outline me-1"></i> CC
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-type="third_party">
                        <i class="mdi mdi-account-multiple-outline me-1"></i> Third Party
                    </button>
                </div>
            </div>

            <div class="col-12">
                <div class="loan-chip-row">
                    <button type="button" class="loan-filter-chip active" data-loan-status="">
                        All Status
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="active">
                        Active
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="pending_approval">
                        Pending Approval
                    </button>
                    <button type="button" class="loan-filter-chip" data-loan-status="closed">
                        Closed
                    </button>
                </div>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Rows</label>
                <select class="form-select loan-select select3" id="loanPerPage">
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="75">75</option>
                    <option value="100">100</option>
                </select>
            </div>
            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Company</label>
                <select class="form-select loan-select select3" id="loanCompanyFilter">
                    <option value="">All Companies</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Lender</label>
                <select class="form-select loan-select select3" id="loanLenderFilter">
                    <option value="">All Lenders</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-4">
                <label class="loan-label">Search</label>
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input
                        type="search"
                        class="form-control loan-input"
                        id="loanSearch"
                        placeholder="Account no., lender or loan name..."
                        autocomplete="off"
                    >
                    <button
                        class="btn btn-label-dark bg-white border border-light text-dark"
                        type="button"
                        id="loanClearSearch"
                        title="Clear search"
                    >
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="loan-table-card">
        <div class="p-3 mb-2">
            <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap">
                <div>
                    <div class="fw-bold text-dark">Loan Register</div>
                    <div class="small text-muted">
                        Complete group-wise loan and credit facility register.
                    </div>
                </div>

                <div id="loanResultMeta"><span class="loan-skeleton" style="width:118px;height:10px"></span></div>
            </div>
        </div>

        <div class="loan-table-wrap px-5">
            <table class="loan-table">
                <thead>
                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                        <th>Loan / Account</th>
                        <th>Type</th>
                        <th>Company</th>
                        <th>Lender</th>
                        <th class="text-end">Outstanding</th>
                        <th class="text-end">EMI / Obligation</th>
                        <th>Next Due</th>
                        <th>Tenure</th>
                        <th>Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>

                <tbody id="loanTableBody">
                    <tr class="loan-skeleton-row">
                        <td><span class="loan-skeleton" style="width:46px;height:11px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:92px;height:22px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton" style="width:110px;height:14px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:86px;height:30px"></span></td>
                        <td><span class="loan-skeleton" style="width:95px;height:18px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:78px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:74px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-actions" style="width:105px;height:32px"></span></td>
                    </tr>
                    <tr class="loan-skeleton-row">
                        <td><span class="loan-skeleton" style="width:46px;height:11px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:92px;height:22px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton" style="width:110px;height:14px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:86px;height:30px"></span></td>
                        <td><span class="loan-skeleton" style="width:95px;height:18px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:78px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:74px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-actions" style="width:105px;height:32px"></span></td>
                    </tr>
                    <tr class="loan-skeleton-row">
                        <td><span class="loan-skeleton" style="width:46px;height:11px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:92px;height:22px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton" style="width:110px;height:14px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:86px;height:30px"></span></td>
                        <td><span class="loan-skeleton" style="width:95px;height:18px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:78px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:74px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-actions" style="width:105px;height:32px"></span></td>
                    </tr>
                    <tr class="loan-skeleton-row">
                        <td><span class="loan-skeleton" style="width:46px;height:11px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:92px;height:22px"></span></td>
                        <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                        <td><span class="loan-skeleton" style="width:110px;height:14px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:86px;height:30px"></span></td>
                        <td><span class="loan-skeleton" style="width:95px;height:18px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:78px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-pill" style="width:74px;height:22px"></span></td>
                        <td><span class="loan-skeleton loan-skeleton-actions" style="width:105px;height:32px"></span></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="text-center my-3 px-5" id="pagination-container">
            <!-- Pagination buttons will appear here -->
        </div>
        <!-- <div class="p-3 border-top">
            <div class="d-flex flex-column flex-md-row align-items-center justify-content-between gap-2">
                <div class="small text-muted" id="loanPaginationMeta"></div>
                <nav class="loan-pagination" aria-label="Loan pagination">
                    <ul class="pagination pagination-sm mb-0" id="loanPagination"></ul>
                </nav>
            </div>
        </div> -->
    </div>
</div>

{{-- Add / Edit Loan Modal --}}
<div  class="modal fade loan-modal" id="loanFormModal" tabindex="-1" aria-labelledby="loanFormModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-bottom">
                <div class="d-flex align-items-center">
                    <div class="avatar avatar-md bg-label-primary me-3 d-flex align-items-center justify-content-center rounded">
                        <i class="mdi mdi-account-cash-outline fs-4"></i>
                    </div>
                    <div>
                        <h5 class="modal-title mb-1" id="loanFormModalTitle">
                             Add Loan
                        </h5>
                        <small class="text-muted">
                            Fill the common details first, then complete the type-specific section.
                        </small>
                    </div>
                </div>
                <button  type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- FORM --}}
            <form  id="loanForm"  method="POST" autocomplete="off">
                @csrf
               
                <div class="modal-body">
                    <input type="hidden" id="loanId" name="loan_id">

                    <div id="loanFormAlert" class="alert alert-danger d-none"></div>

                    <div class="loan-form-section-intro mb-3">
                        <div class="loan-section-head">
                            <span class="loan-section-number">1</span>
                            <div>
                                <div class="loan-section-title">Basic Details</div>
                                <div class="loan-section-copy">Company, lender, account and loan type</div>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 bg-light mb-3">
                        <div class="card-body">
                            <div class="fw-bold text-dark mb-3">
                                Loan Type
                            </div>

                            <div class="row g-3" id="loanTypeCards"></div>

                            <input type="hidden" id="loanTypeId" name="loan_type_id">
                            <div class="small text-danger loan-error" data-error="loan_type_id"></div>
                        </div>
                    </div>

                    <div class="row g-3 px-5">
                        <div class="col-lg-4">
                            <label class="loan-label">
                                Company
                            </label>
                            <select class="form-select loan-select select3" id="loanCompanyId" name="company_id">
                                <option value="">Select Company</option>
                            </select>
                            <div class="loan-error" data-error="company_id"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Lender <span class="text-danger">*</span>
                            </label>
                            <select class="form-select loan-select select3" id="loanLenderId" name="lender_id">
                                <option value="">Select Lender</option>
                            </select>
                            <div class="loan-error" data-error="lender_id"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Loan Account Number <span class="text-danger">*</span>
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanAccountNo"
                                name="account_no"
                                maxlength="120"
                                placeholder="Enter loan / facility account number"
                            >
                            <div class="loan-error" data-error="account_no"></div>
                        </div>

                        <div class="col-lg-8">
                            <label class="loan-label">
                                Loan Title
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanTitle"
                                name="title"
                                maxlength="220"
                                placeholder="Example: Bolero Vehicle Loan"
                            >
                            <div class="loan-error" data-error="title"></div>
                        </div>
                    </div>

                    <div class="loan-form-section-intro mt-3 mb-2 px-5">
                        <div class="loan-section-head loan-section-head-compact">
                            <span class="loan-section-number">2</span>
                            <div>
                                <div class="loan-section-title">Amounts &amp; Schedule</div>
                                <div class="loan-section-copy">Finance values, interest and repayment dates</div>
                            </div>
                        </div>
                    </div>

                    <div class="row g-3 px-5">
                        <div class="col-lg-4">
                            <label class="loan-label">
                                Interest Type
                            </label>
                            <select class="form-select select3 loan-select" id="loanInterestType" name="interest_type">
                                <option value="reducing">Reducing Balance</option>
                                <option value="flat">Flat Rate</option>
                                <option value="simple">Simple Interest</option>
                            </select>
                            <div class="loan-error" data-error="interest_type"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Sanctioned / Limit Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanSanctioned"
                                name="sanctioned_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="sanctioned_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Disbursed Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanDisbursed"
                                name="disbursed_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="disbursed_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Outstanding Amount <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanOutstanding"
                                name="outstanding_amount"
                                placeholder="0.00"
                            >
                            <div class="loan-error" data-error="outstanding_amount"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Interest Rate % <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                step="0.0001"
                                min="0"
                                max="100"
                                class="form-control loan-input"
                                id="loanRate"
                                name="interest_rate"
                                placeholder="Example: 9.50"
                            >
                            <div class="loan-error" data-error="interest_rate"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Start Date <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control loan-input common_datepicker_cust" id="loanStartDate" name="start_date" placeholder="Select Start Date">
                            <div class="loan-error" data-error="start_date"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                First Due Date
                            </label>
                            <input type="text" class="form-control loan-input common_datepicker_cust" id="loanFirstDueDate" name="first_due_date" placeholder="Select First Due">
                            <div class="loan-error" data-error="first_due_date"></div>
                        </div>

                        <div class="col-lg-3">
                            <label class="loan-label">
                                Tenure (Months)
                            </label>
                            <input
                                type="number"
                                class="form-control loan-input"
                                id="loanTenure"
                                name="tenure_months"
                                min="1"
                                max="360"
                                placeholder="60"
                            >
                            <div class="loan-error" data-error="tenure_months"></div>
                        </div>

                        <!-- <div class="col-lg-3">
                            <label class="loan-label">
                                EMI / Instalment
                            </label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                class="form-control loan-input"
                                id="loanEmi"
                                name="emi_amount"
                                placeholder="Auto / manual"
                            >
                            <div class="loan-error" data-error="emi_amount"></div>
                        </div> -->

                        <input  type="hidden" id="loanEmi" name="emi_amount"  >
                        <input  type="hidden" id="loanMaturityDate" name="maturity_date"  >

                        <!-- <div class="col-lg-4">
                            <label class="loan-label">
                                Maturity Date
                            </label>
                            <input type="text" class="form-control loan-input common_datepicker_cust" id="loanMaturityDate" name="maturity_date"  placeholder="Select Maturity Date">
                            <div class="loan-error" data-error="maturity_date"></div>
                        </div> -->

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Moratorium (Months)
                            </label>
                            <input
                                type="number"
                                class="form-control loan-input"
                                id="loanMoratorium"
                                name="moratorium_months"
                                min="0"
                                max="120"
                                value="0"
                            >
                            <div class="loan-error" data-error="moratorium_months"></div>
                        </div>

                        <div class="col-lg-4">
                            <label class="loan-label">
                                Security Details
                            </label>
                            <input
                                type="text"
                                class="form-control loan-input"
                                id="loanSecurity"
                                name="security_details"
                                maxlength="5000"
                                placeholder="Vehicle / property / pledge / other"
                            >
                            <div class="loan-error" data-error="security_details"></div>
                        </div>
                    </div>

                    <div class="loan-form-section-intro mt-4 mb-2 px-5">
                        <div class="loan-section-head loan-section-head-compact">
                            <span class="loan-section-number">3</span>
                            <div>
                                <div class="loan-section-title">Type Specific</div>
                                <div class="loan-section-copy">Only the fields relevant to the selected loan type are shown</div>
                            </div>
                        </div>
                    </div>

                    <div class="loan-advanced mt-2 px-5">
                        <div class="fw-bold text-dark mb-3">
                            Type Specific Details
                        </div>

                        <div id="loanVehiclePanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-3">
                                    <label class="loan-label">Registration No. <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleReg" name="registration_no" maxlength="60" placeholder="Enter Registration No.">
                                    <div class="loan-error" data-error="registration_no"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Make / Model</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleMake" name="make_model" maxlength="160" placeholder="Enter Make / Model">
                                    <div class="loan-error" data-error="make_model"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Chassis No.</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleChassis" name="chassis_no" maxlength="120" placeholder="Enter Chassis No.">
                                    <div class="loan-error" data-error="chassis_no"></div>
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Engine No.</label>
                                    <input type="text" class="form-control loan-input" id="loanVehicleEngine" name="engine_no" maxlength="120" placeholder="Enter Engine No">
                                    <div class="loan-error" data-error="engine_no"></div>
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Insurance Renewal</label>
                                    <input type="text" class="form-control loan-input common_datepicker_cust" id="loanVehicleInsurance" name="insurance_renewal_date" placeholder="Select Insurance Renewal Date">
                                    <div class="loan-error" data-error="insurance_renewal_date"></div>
                                </div>
                                <div class="col-lg-4 d-flex align-items-end">
                                    <div class="form-check form-switch pb-2">
                                        <input class="form-check-input" type="checkbox" id="loanVehicleHypothecated" name="hypothecated_flag" value="1" checked>
                                        <label class="form-check-label fw-semibold" for="loanVehicleHypothecated">
                                            Hypothecated to lender
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="loanTermPanel" class="d-none">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <div class="small text-muted">
                                    Add actual disbursement tranches when the term loan is released in stages.
                                </div>
                                <button type="button" class="btn ptn-primary btn-sm loan-outline-btn" id="loanAddTrancheBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Tranche
                                </button>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                            <th style="width:60px;">#</th>
                                            <th>Disbursed Date</th>
                                            <th>Amount</th>
                                            <th>Remarks</th>
                                            <th style="width:60px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="loanTrancheRows"></tbody>
                                </table>
                            </div>
                        </div>

                        <div id="loanJewelPanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-4">
                                    <label class="loan-label">Pledge Receipt No.</label>
                                    <input type="text" class="form-control loan-input" id="loanPledgeReceipt" name="pledge_receipt_no" maxlength="120">
                                    <div class="loan-error" data-error="pledge_receipt_no"></div>
                                </div>

                                <div class="col-lg-4">
                                    <label class="loan-label">Interest Pattern</label>
                                    <select class="form-select loan-select select3" id="loanJewelInterestPattern" name="interest_pattern">
                                        <option value="monthly">Monthly Servicing</option>
                                        <option value="at_redemption">At Redemption</option>
                                    </select>
                                </div>

                                <div class="col-lg-4">
                                    <label class="loan-label">Redemption Due Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control loan-input common_datepicker_cust" id="loanRedemptionDate" name="redemption_due_date" placeholder=" Select Redemption Due Date">
                                    <div class="loan-error" data-error="redemption_due_date"></div>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-between mt-3 mb-2">
                                <div class="small fw-semibold text-dark">Pledged Items</div>
                                <button type="button" class="btn btn-primary btn-sm loan-outline-btn" id="loanAddJewelBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Item
                                </button>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                            <th style="width:55px;">#</th>
                                            <th>Description</th>
                                            <th>Gross Wt.</th>
                                            <th>Net Wt.</th>
                                            <th>Purity</th>
                                            <th style="width:60px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="loanJewelRows"></tbody>
                                </table>
                            </div>
                        </div>

                        <div id="loanCcPanel" class="d-none">
                            <div class="row g-3">
                                <div class="col-lg-3">
                                    <label class="loan-label">Sanctioned Limit</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcLimit" name="sanctioned_limit" placeholder="Enter Sanctioned Limit">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Margin %</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcMargin" name="margin_percent" placeholder="Enter Margin %">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">Drawing Power</label>
                                    <input type="number" step="0.01" class="form-control loan-input" id="loanCcDrawingPower" name="drawing_power" placeholder="Enter Drawing Power">
                                </div>
                                <div class="col-lg-3">
                                    <label class="loan-label">CC Interest Rate %</label>
                                    <input type="number" step="0.0001" class="form-control loan-input" id="loanCcRate" name="cc_interest_rate" placeholder="Enter CC Interest Rate %">
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Renewal Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control loan-input common_datepicker_cust" id="loanCcRenewalDate" name="renewal_date" placeholder="Renewal Date">
                                    <div class="loan-error" data-error="renewal_date"></div>
                                </div>
                                <div class="col-lg-4">
                                    <label class="loan-label">Stock Statement Day</label>
                                    <input type="number" min="1" max="31" class="form-control loan-input" id="loanCcStockDay" name="stock_statement_day"  placeholder="Enter Stock Statement Day">
                                </div>
                            </div>
                        </div>

                        <div id="loanThirdPartyPanel" class="d-none">
                            <div class="border rounded-3 bg-white p-3">
                                <div class="d-flex align-items-start gap-2">
                                    <div class="loan-type-icon flex-shrink-0"><i class="mdi mdi-account-multiple-outline"></i></div>
                                    <div>
                                        <div class="fw-bold text-dark">Third Party Loan</div>
                                        <div class="small text-muted mt-1">
                                            Use the common finance fields above for third-party borrowing. Capture the counterparty, guarantee and security context in Security Details and Remarks; no unrelated type-specific fields are forced on the user.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="loanNoTypePanel" class="text-muted small">
                            Select a loan type above to continue.
                        </div>
                    </div>

                    <div class="row g-3 mt-1 px-5">
                        <div class="col-12">
                            <label class="loan-label">Remarks</label>
                            <textarea
                                class="form-control loan-input"
                                id="loanRemarks"
                                name="remarks"
                                rows="3"
                                maxlength="5000"
                                placeholder="Add relevant notes, exceptions or business context..."
                            ></textarea>
                            <div class="loan-error" data-error="remarks"></div>
                        </div>
                    </div>
                </div>

                {{-- FOOTER --}}
                <div class="modal-footer bg-light">
                    <button type="button"  class="btn btn-label-secondary loan-outline-btn" data-bs-dismiss="modal" >
                        Cancel
                    </button>
                    <button  type="submit" class="btn btn-primary loan-primary-btn"  id="loanSaveBtn">
                        <span class="loan-save-text">
                            <i class="mdi mdi-content-save-outline me-1"></i>
                            Submit for Approval
                        </span>
                        <span class="loan-save-loading d-none">
                            <span class="spinner-border spinner-border-sm me-1"></span>
                            Saving...
                        </span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>


            
      
   


{{-- View Loan Modal --}}
<div class="modal fade loan-modal" id="loanViewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div class="min-w-0">
                    <h5 class="modal-title mb-1" id="loanViewTitle">Loan Details</h5>
                    <div class="small text-muted text-truncate" id="loanViewSubtitle"></div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <div id="loanViewActions" class="d-flex align-items-center gap-1 flex-wrap"></div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>
            <div class="modal-body p-0" id="loanViewBody">
                <div class="loan-loading loan-view-skeleton"><div class="loan-skeleton loan-skeleton-line loan-skeleton-line-lg"></div><div class="loan-skeleton loan-skeleton-line loan-skeleton-line-md mt-3"></div><div class="row g-3 mt-2"><div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div><div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div><div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div><div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div></div></div>
            </div>
        </div>
    </div>
</div>

{{-- Manage Lenders Modal --}}
<div class="modal fade loan-modal" id="loanLenderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1">Manage Lenders</h5>
                    <div class="small text-muted">Maintain active lender masters without leaving Loans &amp; Schedules.</div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <button type="button" class="btn btn-sm loan-primary-btn btn-primary" id="loanAddLenderBtn"><i class="mdi mdi-plus me-1"></i>Add Lender</button>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>
            <div class="modal-body">
                <div id="loanLenderFormPanel" class="loan-lender-form d-none mb-3">
                    <form id="loanLenderForm" autocomplete="off">
                        @csrf
                        <input type="hidden" id="loanLenderMasterId" name="lender_id">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div>
                                <div class="fw-bold text-dark" id="loanLenderFormTitle">Add Lender</div>
                                <div class="small text-muted">Lender name and branch identify the master record.</div>
                            </div>
                            <button type="button" class="btn btn-sm loan-outline-btn" id="loanCancelLenderBtn">Cancel</button>
                        </div>
                        <div id="loanLenderFormAlert" class="alert alert-danger d-none"></div>
                        <div class="row g-3">
                            <div class="col-lg-4">
                                <label class="loan-label">Lender Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control loan-input" name="lender_name" id="loanLenderName" maxlength="255">
                                <div class="loan-error" data-lender-error="lender_name"></div>
                            </div>
                            <div class="col-lg-4">
                                <label class="loan-label">Lender Type</label>
                                <input type="text" class="form-control loan-input" name="lender_type" id="loanLenderType" maxlength="100" placeholder="Bank / NBFC / Society / Other">
                                <div class="loan-error" data-lender-error="lender_type"></div>
                            </div>
                            <div class="col-lg-4">
                                <label class="loan-label">Branch</label>
                                <input type="text" class="form-control loan-input" name="branch_name" id="loanLenderBranch" maxlength="255">
                                <div class="loan-error" data-lender-error="branch_name"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="loan-label">Contact Person</label>
                                <input type="text" class="form-control loan-input" name="contact_person" id="loanLenderContact" maxlength="150">
                                <div class="loan-error" data-lender-error="contact_person"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="loan-label">Phone</label>
                                <input type="text" class="form-control loan-input" name="phone" id="loanLenderPhone" maxlength="50">
                                <div class="loan-error" data-lender-error="phone"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="loan-label">Email</label>
                                <input type="email" class="form-control loan-input" name="email" id="loanLenderEmail" maxlength="190">
                                <div class="loan-error" data-lender-error="email"></div>
                            </div>
                            <!-- <div class="col-lg-3">
                                <label class="loan-label">Status</label>
                                <select class="form-select loan-select select3" name="status" id="loanLenderStatus">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                                <div class="loan-error" data-lender-error="status"></div>
                            </div> -->
                            <div class="col-12">
                                <label class="loan-label">Address</label>
                                <textarea class="form-control loan-input" name="address" id="loanLenderAddress" rows="2" maxlength="1000"></textarea>
                                <div class="loan-error" data-lender-error="address"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end gap-2 mt-3">
                            <button type="submit" class="btn loan-primary-btn btn-secondary" id="loanSaveLenderBtn">
                                <span class="loan-save-text"><i class="mdi mdi-content-save-outline me-1"></i>Save Lender</span>
                                <span class="loan-save-loading d-none"><span class="spinner-border spinner-border-sm me-1"></span>Saving...</span>
                            </button>
                        </div>
                    </form>
                </div>

                <div class="row g-3 align-items-end mb-3">
                    <div class="col-lg-5">
                        <label class="loan-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                            <input type="search" class="form-control loan-input" id="loanLenderSearch" placeholder="Lender, branch, contact or phone..." autocomplete="off">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <label class="loan-label">Status</label>
                        <select class="form-select loan-select select3" id="loanLenderListStatus">
                            <option value="">All Status</option>
                            <option value="0">Active</option>
                            <option value="1">Inactive</option>
                        </select>
                    </div>
                    <div class="col-lg-2">
                        <label class="loan-label">Rows</label>
                        <select class="form-select loan-select select3" id="loanLenderPerPage">
                            <option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option>
                        </select>
                    </div>
                    <div class="col-lg-3 d-flex justify-content-lg-end">
                        <button type="button" class="btn loan-outline-btn btn-secondary" id="loanResetLenderFilter"><i class="mdi mdi-refresh me-1"></i>Reset</button>
                    </div>
                </div>

                <div class="loan-table-wrap border rounded-3">
                    <table class="table table-hover mb-0 loan-lender-table align-middle">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="ps-3">Lender</th>
                                <th>Type</th>
                                <th>Contact</th>
                                <th>Loans</th>
                                <th>Status</th>
                                <th class="text-center pe-3">Action</th>
                            </tr>
                        </thead>
                        <tbody id="loanLenderTableBody"></tbody>
                    </table>
                </div>
                <div class="d-flex flex-column flex-md-row align-items-center justify-content-between gap-2 mt-3">
                    <div class="small text-muted" id="loanLenderPaginationMeta"></div>
                    <nav aria-label="Lender pagination"><ul class="pagination pagination-sm mb-0" id="loanLenderPagination"></ul></nav>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Payment Modal --}}
<div class="modal fade loan-modal" id="loanPaymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header"><div><h5 class="modal-title">Record Payment</h5><div class="small text-muted" id="loanPaymentSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form id="loanPaymentForm">
                @csrf
                <div class="modal-body">
                    <div id="loanPaymentAlert" class="alert alert-danger d-none"></div>
                    <div class="row g-3">
                        <div class="col-lg-4"><label class="loan-label">Payment Date <span class="text-danger">*</span></label><input type="text" class="form-control loan-input common_datepicker_cust" id="loanPaymentDate" name="payment_date"><div class="loan-error" data-payment-error="payment_date"></div></div>
                        <div class="col-lg-4"><label class="loan-label">Amount <span class="text-danger">*</span></label><input type="number" step="0.01" min="0.01" class="form-control loan-input" id="loanPaymentAmount" name="amount"><div class="loan-error" data-payment-error="amount"></div></div>
                        <div class="col-lg-4"><label class="loan-label">Payment Type</label><select class="form-select loan-select select3" id="loanPaymentType" name="payment_type"><option value="regular">Regular</option><option value="principal">Principal Only</option><option value="interest">Interest Only</option></select></div>
                        <div class="col-lg-4"><label class="loan-label">Payment Mode</label><select class="form-select loan-select select3" id="loanPaymentMode" name="mode"><option value="NACH">NACH</option><option value="NEFT">NEFT</option><option value="RTGS">RTGS</option><option value="Cash">Cash</option><option value="Cheque">Cheque</option><option value="UPI">UPI</option><option value="Other">Other</option></select></div>
                        <div class="col-lg-4"><label class="loan-label">Reference No.</label><input type="text" class="form-control loan-input" id="loanPaymentReference" name="reference_no" maxlength="120"></div>
                        <div class="col-lg-4"><label class="loan-label">Pay From Account</label><input type="text" class="form-control loan-input" id="loanPaymentAccount" name="pay_from_account" maxlength="120"></div>
                        <div class="col-lg-4"><label class="loan-label">Principal Amount</label><input type="number" step="0.01" min="0" class="form-control loan-input" id="loanPaymentPrincipal" name="principal_amount"></div>
                        <div class="col-lg-4"><label class="loan-label">Interest Amount</label><input type="number" step="0.01" min="0" class="form-control loan-input" id="loanPaymentInterest" name="interest_amount"></div>
                        <div class="col-lg-4"><label class="loan-label">Penal Interest</label><input type="number" step="0.01" min="0" class="form-control loan-input" id="loanPaymentPenal" name="penal_interest"></div>
                        <div class="col-lg-4"><label class="loan-label">Bounce Charge</label><input type="number" step="0.01" min="0" class="form-control loan-input" id="loanPaymentBounce" name="bounce_charge"></div>
                        <div class="col-12"><label class="loan-label">Notes</label><textarea class="form-control loan-input" id="loanPaymentNotes" name="notes" rows="2" maxlength="1000"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn loan-primary-btn" id="loanSavePaymentBtn"><span class="loan-save-text">Save Payment</span><span class="loan-save-loading d-none"><span class="spinner-border spinner-border-sm me-1"></span>Saving...</span></button></div>
            </form>
        </div>
    </div>
</div>

{{-- Action Modal --}}
<div class="modal fade loan-modal" id="loanActionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header"><div><h5 class="modal-title" id="loanActionTitle">Loan Action</h5><div class="small text-muted" id="loanActionSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form id="loanActionForm">
                @csrf
                <div class="modal-body" id="loanActionBody"></div>
                <div class="modal-footer"><button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn loan-primary-btn" id="loanActionSubmitBtn">Continue</button></div>
            </form>
        </div>
    </div>
</div>

{{-- Confirm Modal --}}
<div class="modal fade loan-modal" id="loanConfirmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content border-0 shadow-lg"><div class="modal-body p-4 text-center"><div class="loan-confirm-icon mx-auto mb-3"><i class="mdi mdi-help-circle-outline"></i></div><h6 class="fw-bold mb-2" id="loanConfirmTitle">Confirm action</h6><div class="small text-muted" id="loanConfirmMessage"></div><div class="d-flex justify-content-center gap-2 mt-4"><button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-danger" id="loanConfirmBtn">Confirm</button></div></div></div></div>
</div>

{{-- Approval Return Modal --}}
<div class="modal fade loan-modal" id="loanReturnModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header"><h5 class="modal-title">Return Loan to Maker</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form id="loanReturnForm">
                <div class="modal-body">
                    <input type="hidden" id="loanReturnId">
                    <label class="loan-label">Remarks <span class="text-danger">*</span></label>
                    <textarea class="form-control loan-input" id="loanReturnRemarks" rows="4" maxlength="1000" placeholder="Explain what needs correction..."></textarea>
                    <div class="loan-error" id="loanReturnError"></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-danger">Return to Maker</button></div>
            </form>
        </div>
    </div>
</div>

{{-- Toast --}}
<div
    class="position-fixed bottom-0 start-50 translate-middle-x p-3"
    style="z-index:1095;"
>
    <div
        id="loanToast"
        class="toast align-items-center border-0 shadow"
        role="status"
        aria-live="polite"
        aria-atomic="true"
    >
        <div class="d-flex">
            <div class="toast-body" id="loanToastBody"></div>
            <button
                type="button"
                class="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
            ></button>
        </div>
    </div>
</div>

<script>
    window.LoanScheduleRoutes = {
        data: @json(route('accounts_finance.loans.data')),
        lookups: @json(route('accounts_finance.loans.lookups')),
        store: @json(route('accounts_finance.loans.store')),
        show: @json(route('accounts_finance.loans.data.show', ['loan' => '__ID__'])),
        update: @json(route('accounts_finance.loans.update', ['loan' => '__ID__'])),
        approve: @json(route('accounts_finance.loans.approve', ['loan' => '__ID__'])),
        return: @json(route('accounts_finance.loans.return', ['loan' => '__ID__'])),
        payment: @json(route('accounts_finance.loans.payments.store', ['loan' => '__ID__'])),
        prepayPreview: @json(route('accounts_finance.loans.prepay.preview', ['loan' => '__ID__'])),
        prepay: @json(route('accounts_finance.loans.prepay', ['loan' => '__ID__'])),
        approvePrepay: @json(route('accounts_finance.loans.prepay.approve', ['loan' => '__ID__'])),
        restructurePreview: @json(route('accounts_finance.loans.restructure.preview', ['loan' => '__ID__'])),
        restructure: @json(route('accounts_finance.loans.restructure', ['loan' => '__ID__'])),
        approveRestructure: @json(route('accounts_finance.loans.restructure.approve', ['loan' => '__ID__'])),
        close: @json(route('accounts_finance.loans.close', ['loan' => '__ID__'])),
        renewal: @json(route('accounts_finance.loans.renewal', ['loan' => '__ID__'])),
        utilisation: @json(route('accounts_finance.loans.utilisation', ['loan' => '__ID__'])),
        snooze: @json(route('accounts_finance.loans.obligations.snooze', ['obligation' => '__ID__'])),
        lenders: @json(route('accounts_finance.loans.lenders')),
        lenderStore: @json(route('accounts_finance.loans.lenders.store')),
        lenderUpdate: @json(route('accounts_finance.loans.lenders.update', ['lender' => '__ID__'])),
        lenderToggle: @json(route('accounts_finance.loans.lenders.toggle', ['lender' => '__ID__'])),
        lenderDelete: @json(route('accounts_finance.loans.lenders.delete', ['lender' => '__ID__'])),
    };

    window.LoanSchedulePageConfig = {
        csrf: @json(csrf_token()),
        initialPerPage: 25
    };
</script>

<script >
(function ($) {
    'use strict';

    const config = window.LoanSchedulePageConfig || {};
    const routes = window.LoanScheduleRoutes || {};

    if (!routes.data || document.getElementById('loanSchedulePage') === null) {
        return;
    }

    let loanModal = null;
    let viewModal = null;
    let returnModal = null;

    // Local to the list-module IIFE because refreshList() runs in this scope.
    // The later view/lender IIFE has its own scope and cannot expose this helper here.
    function loanTableSkeletonRows(count = 6) {
        let html = '';
        for (let i = 0; i < count; i++) {
            html += `<tr class="loan-skeleton-row">
                <td><span class="loan-skeleton" style="width:46px;height:11px"></span></td>
                <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                <td><span class="loan-skeleton loan-skeleton-pill" style="width:92px;height:22px"></span></td>
                <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                <td><span class="loan-skeleton" style="width:110px;height:14px"></span></td>
                <td><span class="loan-skeleton loan-skeleton-pill" style="width:86px;height:30px"></span></td>
                <td><span class="loan-skeleton" style="width:95px;height:18px"></span></td>
                <td><span class="loan-skeleton loan-skeleton-pill" style="width:78px;height:22px"></span></td>
                <td><span class="loan-skeleton loan-skeleton-pill" style="width:74px;height:22px"></span></td>
                <td><span class="loan-skeleton loan-skeleton-actions" style="width:105px;height:32px"></span></td>
            </tr>`;
        }
        return html;
    }

    const state = {
        page: 1,
        perPage: Number(config.initialPerPage || 25),
        type: '',
        status: '',
        companyId: '',
        lenderId: '',
        search: '',
        loanTypeId: '',
        lookupsLoaded: false,
        currentLoanId: null,
        currentRequest: null,
        currentViewLoan: null,
        currentViewTab: 'overview',
        lenderPage: 1,
        lenderPerPage: 25,
        lenderSearch: '',
        lenderStatus: '',
        currentLenderId: null,
        currentLenderRequest: null,
        trancheIndex: 0,
        jewelIndex: 0,
    };

    function safeModal(selector) {
        const el = document.querySelector(selector);

        if (!el || !window.bootstrap || !bootstrap.Modal) {
            return null;
        }

        return bootstrap.Modal.getOrCreateInstance(el);
    }

    function esc(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function url(template, id) {
        return String(template || '').replace(
            '__ID__',
            encodeURIComponent(String(id))
        );
    }

    function money(value) {
        const number = Number(value || 0);

        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2,
        }).format(number);
    }

    function date(value) {
        if (!value) {
            return '-';
        }

        const parts = String(value).split('-');

        if (parts.length !== 3) {
            return value;
        }

        return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }

    function toast(message, type = 'success') {
        const toastEl = document.getElementById('loanToast');
        const bodyEl = document.getElementById('loanToastBody');

        if (!toastEl || !bodyEl) {
            return;
        }

        toastEl.classList.remove(
            'text-bg-success',
            'text-bg-danger',
            'text-bg-warning',
            'text-bg-info'
        );

        const classMap = {
            success: 'text-bg-success',
            error: 'text-bg-danger',
            danger: 'text-bg-danger',
            warning: 'text-bg-warning',
            info: 'text-bg-info',
        };

        toastEl.classList.add(
            classMap[type] || classMap.success
        );

        bodyEl.textContent = message || 'Completed.';

        if (window.bootstrap && bootstrap.Toast) {
            bootstrap.Toast.getOrCreateInstance(toastEl, {
                delay: 3500
            }).show();
        }
    }

    function setLoading(button, loading) {
        const $button = $(button);

        $button.prop('disabled', loading);

        $button
            .find('.loan-save-text')
            .toggleClass('d-none', loading);

        $button
            .find('.loan-save-loading')
            .toggleClass('d-none', !loading);
    }

    function clearErrors() {
        $('.loan-error[data-error]').text('');
        $('#loanFormAlert').addClass('d-none').empty();
    }

    function applyErrors(errors) {
        clearErrors();

        if (!errors || typeof errors !== 'object') {
            return;
        }

        Object.keys(errors).forEach(function (field) {
            const message = Array.isArray(errors[field])
                ? errors[field][0]
                : errors[field];

            $(`.loan-error[data-error="${CSS.escape(field)}"]`)
                .text(message || 'Invalid value.');
        });

        const firstField = Object.keys(errors)[0];

        if (firstField) {
            const input = document.getElementById(
                firstField === 'loan_type_id'
                    ? 'loanTypeId'
                    : firstField
            );

            if (input) {
                input.focus();
            }
        }
    }

    function handleAjaxError(xhr, fallback) {
        let message = fallback || 'Unable to complete the request.';
        let payload = null;

        try {
            payload = xhr.responseJSON
                || JSON.parse(xhr.responseText || '{}');
        } catch (e) {
            payload = null;
        }

        if (payload && payload.message) {
            message = payload.message;
        }

        if (payload && payload.errors) {
            applyErrors(payload.errors);
        }

        toast(message, 'error');
    }

    function loadLookups() {
        if (state.lookupsLoaded) {
            return $.Deferred().resolve().promise();
        }

        return $.ajax({
            url: routes.lookups,
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        }).done(function (response) {
            if (!response || Number(response.status) !== 200) {
                return;
            }

            const data = response.data || {};

            renderCompanies(data.companies || data.entities || []);
            renderLenders(data.lenders || []);

            const types = data.types || [];

            $('#loanTypeId').data('types', types);
            renderLoanTypeCards(types);
            if (typeof window.LoanScheduleInitSelect3 === 'function') {
                window.LoanScheduleInitSelect3();
            }
            state.lookupsLoaded = true;
        }).fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to load company, lender and loan type masters.'
            );
        });
    }

    function renderCompanies(items) {
        const $filter = $('#loanCompanyFilter');
        const $form = $('#loanCompanyId');

        let filterHtml = '<option value="">All Companies</option>';
        let formHtml = '<option value="">Select Company</option>';

        items.forEach(function (item) {
            const id = item.id ?? item.sno;
            const name = item.name ?? item.company_name ?? item.entity_name ?? '-';

            filterHtml += `
                <option value="${esc(id)}">${esc(name)}</option>
            `;

            formHtml += `
                <option value="${esc(id)}">${esc(name)}</option>
            `;
        });

        $filter.html(filterHtml);
        $form.html(formHtml);

        $filter.val(state.companyId || '');
        $form.val($('#loanCompanyId').val() || '');
    }

    function renderLenders(items) {
        const $filter = $('#loanLenderFilter');
        const $form = $('#loanLenderId');

        let filterHtml = '<option value="">All Lenders</option>';
        let formHtml = '<option value="">Select Lender</option>';

        items.forEach(function (item) {
            const id = item.id ?? item.sno;
            const name = item.lender_name ?? item.name ?? '-';
            const branch = item.branch_name
                ? ` — ${item.branch_name}`
                : '';

            filterHtml += `
                <option value="${esc(id)}">${esc(name)}${esc(branch)}</option>
            `;

            formHtml += `
                <option value="${esc(id)}">${esc(name)}${esc(branch)}</option>
            `;
        });

        $filter.html(filterHtml);
        $form.html(formHtml);
        $filter.val(state.lenderId || '');

        if (typeof window.LoanScheduleInitSelect3 === 'function') {
            window.LoanScheduleInitSelect3();
        }
    }

    function renderLoanTypeCards(types) {
        const $container = $('#loanTypeCards');
        if (!$container.length) return;

        if (!types.length) {
            $container.html('<div class="col-12"><div class="loan-empty-block border rounded-3 bg-white">No active loan types are configured.</div></div>');
            return;
        }

        const fallbackIcons = {
            vehicle: 'mdi-car-outline',
            term: 'mdi-file-document-outline',
            jewel: 'mdi-diamond-stone',
            cc: 'mdi-bank-outline',
            third_party: 'mdi-account-multiple-outline',
        };

        const fallbackDescriptions = {
            vehicle: 'EMI loan against a vehicle.',
            term: 'Business or project term borrowing.',
            jewel: 'Pledge with redemption deadline.',
            cc: 'Working capital facility and renewal.',
            third_party: 'Borrowing or facility arranged through a third party.',
        };

        $container.html(types.map(function (type) {
            const code = String(type.type_code || '');
            const icon = type.icon || fallbackIcons[code] || 'mdi-bank-outline';
            const description = type.description || fallbackDescriptions[code] || 'Loan / finance facility.';
            return `
                <div class="col-12 col-sm-6 col-xl-3">
                    <button type="button" class="loan-type-card w-100 text-start" data-loan-type-card="${esc(code)}">
                        <div class="loan-type-icon"><i class="mdi ${esc(icon)}"></i></div>
                        <div class="fw-bold">${esc(type.type_name || code)}</div>
                        <div class="small text-muted">${esc(description)}</div>
                    </button>
                </div>
            `;
        }).join(''));
    }

    function refreshList(page = 1) {
        state.page = page;

        const params = {
            page: state.page,
            per_page: state.perPage,
            type: state.type,
            status: state.status,
            company_id: state.companyId,
            lender_id: state.lenderId,
            search: state.search,
        };

        $('#loanTableBody').html(loanTableSkeletonRows(6));

        $('#loanResultMeta').html('<span class="loan-skeleton" style="width:118px;height:10px"></span>');
        $('#loanPaginationMeta').text('');
        $('#loanPagination').empty();

        if (state.currentRequest && state.currentRequest.readyState !== 4) {
            state.currentRequest.abort();
        }

        state.currentRequest = $.ajax({
            url: routes.data,
            type: 'GET',
            data: params,
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response || Number(response.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to load loans.'
                );
            }
                renderSummary(response.summary || {});
            renderTable(response.data || []);
            // renderPagination(response.pagination || {});
            let paginateResponse = response.pagination || {} ;
            if(paginateResponse){
                renderPagination(paginateResponse.current_page, paginateResponse.last_page, paginateResponse.total, paginateResponse.per_page);
            }
            
        })
        .fail(function (xhr, statusText) {
            if (statusText === 'abort') {
                return;
            }

            $('#loanTableBody').html(`
                <tr>
                    <td colspan="10">
                        <div class="loan-empty">
                            <div class="loan-empty-icon">
                                <i class="mdi mdi-alert-circle-outline"></i>
                            </div>
                            <div class="fw-bold text-dark">
                                Unable to load loans
                            </div>
                            <div class="small mt-1">
                                Please try again.
                            </div>
                            <button
                                type="button"
                                class="btn loan-primary-btn btn-sm mt-3"
                                onclick="window.LoanScheduleReload()"
                            >
                                Retry
                            </button>
                        </div>
                    </td>
                </tr>
            `);

            handleAjaxError(
                xhr,
                'Unable to load loan register.'
            );
        });
    }

    function renderSummary(summary) {
        $('#loanKpiOutstanding').text(
            money(summary.total_outstanding || 0)
        );

        $('#loanKpiOutstandingMeta').text(
            `${Number(summary.active_loans || 0)} active loan(s)`
        );

        $('#loanKpiDue').text(
            Number(summary.due_this_week_count || 0)
        );

        $('#loanKpiDueMeta').text(
            `${money(summary.due_this_week_amount || 0)} due this week`
        );

        $('#loanKpiOverdue').text(
            Number(summary.overdue_count || 0)
        );

        $('#loanKpiOverdueMeta').text(
            `${money(summary.overdue_amount || 0)} overdue balance`
        );

        const watch =
            Number(summary.renewals_60_days || 0)
            + Number(summary.redemptions_30_days || 0);

        $('#loanKpiWatch').text(watch);

        $('#loanKpiWatchMeta').text(
            `${Number(summary.renewals_60_days || 0)} renewals · ` +
            `${Number(summary.redemptions_30_days || 0)} redemptions`
        );
    }

    function statusBadge(status) {
        const map = {
            active: ['Active', 'status-active'],
            pending_approval: ['Pending Approval', 'status-pending'],
            returned: ['Returned', 'status-returned'],
            closed: ['Closed', 'status-closed'],
            foreclosed: ['Foreclosed', 'status-closed'],
            restructured: ['Restructured', 'status-active'],
            overdue: ['Overdue', 'status-overdue'],
            today: ['Due Today', 'status-today'],
            upcoming: ['Upcoming', 'status-upcoming'],
            paid: ['Paid', 'status-paid'],
        };

        const item = map[status] || [status || '-', 'status-closed'];

        return `
            <span class="loan-status ${item[1]}">
                <span>●</span>
                ${esc(item[0])}
            </span>
        `;
    }

    function dueBadge(item) {
        if (!item.next_due) {
            return '<span class="text-muted">No pending due</span>';
        }

        let days = Number(item.days_to_due);

        let cls = 'normal';
        let label = `${days} day(s)`;

        if (Number.isFinite(days)) {
            if (days < 0) {
                cls = 'danger';
                label = `${Math.abs(days)} day(s) overdue`;
            } else if (days === 0) {
                cls = 'warn';
                label = 'Due today';
            } else if (days <= 7) {
                cls = 'warn';
            }
        }

        return `
            <div class="d-flex flex-column align-items-start gap-1">
                <span class="fw-semibold">${esc(date(item.next_due))}</span>
                <span class="loan-days-pill ${cls}">
                    ${esc(label)}
                </span>
            </div>
        `;
    }

    function renderTable(items) {
        if (!items.length) {
            $('#loanTableBody').html(`
                <tr>
                    <td colspan="10">
                        <div class="loan-empty">
                            <div class="loan-empty-icon">
                                <i class="mdi mdi-bank-outline"></i>
                            </div>
                            <div class="fw-bold text-dark">
                                No loans found
                            </div>
                            <div class="small mt-1">
                                Try changing your filters or add a new loan.
                            </div>
                            <button
                                type="button"
                                class="btn loan-primary-btn btn-sm mt-3"
                                id="loanEmptyAddBtn"
                            >
                                <i class="mdi mdi-plus me-1"></i>
                                Add Loan
                            </button>
                        </div>
                    </td>
                </tr>
            `);

            $('#loanEmptyAddBtn').off('click').on('click', openCreateModal);
            return;
        }

        let html = '';

        items.forEach(function (item) {
            const tenure = item.tenure_total
                ? `
                    <div class="loan-progress">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>${esc(item.tenure_paid)} / ${esc(item.tenure_total)}</span>
                            <span>${esc(item.tenure_percent)}%</span>
                        </div>
                        <div class="loan-progress-track">
                            <div
                                class="loan-progress-bar"
                                style="width:${Math.max(0, Math.min(100, Number(item.tenure_percent || 0)))}%"
                            ></div>
                        </div>
                    </div>
                `
                : '<span class="text-muted">-</span>';

            const companyText = (item.company_id ?? item.entity_id) !== null && (item.company_id ?? item.entity_id) !== undefined
                ? getCompanyName(item.company_id ?? item.entity_id)
                : '-';

            let actions = `
                <div class="d-flex justify-content-center gap-1">
                    <button
                        type="button"
                        class="loan-action-btn"
                        title="View loan details"
                        data-loan-view="${esc(item.id)}"
                    >
                        <i class="mdi mdi-eye-outline"></i>
                    </button>
            `;

            if (
                ['draft', 'returned'].includes(item.status)
                || (item.status === 'pending_approval' && !item.pending_change_type)
            ) {
                actions += `
                    <button
                        type="button"
                        class="loan-action-btn"
                        title="Edit loan"
                        data-loan-edit="${esc(item.id)}"
                    >
                        <i class="mdi mdi-pencil-outline"></i>
                    </button>
                `;
            }

            if (item.status === 'pending_approval') {
                const pendingChange = item.pending_change_type;
                if (pendingChange === 'prepay') {
                    actions += `
                        <button type="button" class="loan-action-btn text-success" title="Approve part-prepay" data-loan-approve-prepay="${esc(item.id)}">
                            <i class="mdi mdi-check-circle-outline"></i>
                        </button>
                    `;
                } else if (pendingChange === 'restructure') {
                    actions += `
                        <button type="button" class="loan-action-btn text-success" title="Approve restructure" data-loan-approve-restructure="${esc(item.id)}">
                            <i class="mdi mdi-check-circle-outline"></i>
                        </button>
                    `;
                } else {
                    actions += `
                        <button type="button" class="loan-action-btn text-success" title="Approve loan" data-loan-approve="${esc(item.id)}">
                            <i class="mdi mdi-check-circle-outline"></i>
                        </button>
                    `;
                }

                actions += `
                    <button type="button" class="loan-action-btn text-danger" title="Return to maker" data-loan-return="${esc(item.id)}">
                        <i class="mdi mdi-undo-variant"></i>
                    </button>
                `;
            }

            actions += '</div>';

            html += `
                <tr data-loan-row="${esc(item.id)}">
                    <td>
                        <div class="loan-account">
                            ${esc(item.account_no || '-')}
                        </div>
                        <div class="loan-name">
                            ${esc(item.title || '-')}
                        </div>
                    </td>

                    <td>
                        <span class="loan-type-badge">
                            <i class="mdi ${esc(item.loan_type_icon || 'mdi-bank-outline')}"></i>
                            ${esc(item.loan_type_name || item.loan_type || '-')}
                        </span>
                    </td>

                    <td>
                        <div class="fw-semibold">
                            ${esc(companyText)}
                        </div>
                    </td>

                    <td>
                        <div class="fw-semibold">
                            ${esc(item.lender_name || '-')}
                        </div>
                        <div class="loan-muted">
                            ${esc(item.branch_name || '')}
                        </div>
                    </td>

                    <td class="text-end">
                        <span class="fw-bold">
                            ${money(item.outstanding_amount || 0)}
                        </span>
                    </td>

                    <td class="text-end">
                        <span class="fw-semibold">
                            ${money(item.next_due_amount || item.emi_amount || 0)}
                        </span>
                    </td>

                    <td>
                        ${dueBadge(item)}
                    </td>

                    <td>
                        ${tenure}
                    </td>

                    <td>
                        ${statusBadge(item.status)}
                    </td>

                    <td>
                        ${actions}
                    </td>
                </tr>
            `;
        });

        $('#loanTableBody').html(html);
    }

    function renderPagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="refreshList(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="refreshList(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="refreshList(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="refreshList(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="refreshList(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);
        $('#loanResultMeta').text(
            `${total} loan(s)`
        );
        // Update perpage dropdown if changed
        document.getElementById('loanPerPage').value = perpage;
    }
    function renderPaginationOld(meta) {
        const current = Number(meta.current_page || 1);
        const last = Number(meta.last_page || 1);
        const total = Number(meta.total || 0);
        const perPage = Number(meta.per_page || state.perPage);

        const from = total === 0
            ? 0
            : ((current - 1) * perPage) + 1;

        const to = Math.min(current * perPage, total);

        $('#loanResultMeta').text(
            `${total} loan(s)`
        );

        $('#loanPaginationMeta').text(
            total ? `Showing ${from}–${to} of ${total}` : 'No results'
        );

        let html = '';

        if (last <= 1) {
            $('#loanPagination').html('');
            return;
        }

        html += `
            <li class="page-item ${current <= 1 ? 'disabled' : ''}">
                <button
                    class="page-link"
                    type="button"
                    data-loan-page="${current - 1}"
                    ${current <= 1 ? 'disabled' : ''}
                >
                    Previous
                </button>
            </li>
        `;

        const start = Math.max(1, current - 2);
        const end = Math.min(last, current + 2);

        if (start > 1) {
            html += `
                <li class="page-item">
                    <button class="page-link" data-loan-page="1">1</button>
                </li>
            `;

            if (start > 2) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }
        }

        for (let page = start; page <= end; page++) {
            html += `
                <li class="page-item ${page === current ? 'active' : ''}">
                    <button
                        type="button"
                        class="page-link"
                        data-loan-page="${page}"
                    >
                        ${page}
                    </button>
                </li>
            `;
        }

        if (end < last) {
            if (end < last - 1) {
                html += `
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `;
            }

            html += `
                <li class="page-item">
                    <button
                        type="button"
                        class="page-link"
                        data-loan-page="${last}"
                    >
                        ${last}
                    </button>
                </li>
            `;
        }

        html += `
            <li class="page-item ${current >= last ? 'disabled' : ''}">
                <button
                    class="page-link"
                    type="button"
                    data-loan-page="${current + 1}"
                    ${current >= last ? 'disabled' : ''}
                >
                    Next
                </button>
            </li>
        `;

        $('#loanPagination').html(html);
    }

    function getCompanyName(id) {
        const value = String(id || '');
        const option = $('#loanCompanyFilter option[value="' + CSS.escape(value) + '"]');

        return option.length
            ? option.text()
            : '-';
    }

    function getTypeById(id) {
        const types = $('#loanTypeId').data('types') || [];

        return types.find(function (item) {
            return String(item.id) === String(id);
        });
    }

    function resetForm() {
        const form = document.getElementById('loanForm');

        if (form) {
            form.reset();
        }

        $('#loanId').val('');
        $('#loanTypeId').val('');
        $('#loanCompanyId').val('');
        $('#loanLenderId').val('');
        $('#loanInterestType').val('reducing');
        $('#loanMoratorium').val('0');
        $('#loanVehicleHypothecated').prop('checked', true);

        $('#loanTypeCards [data-loan-type-card]')
            .removeClass('active');

        $('#loanVehiclePanel, #loanTermPanel, #loanJewelPanel, #loanCcPanel, #loanThirdPartyPanel')
            .addClass('d-none');

        $('#loanNoTypePanel').removeClass('d-none');

        $('#loanTrancheRows').empty();
        $('#loanJewelRows').empty();

        state.trancheIndex = 0;
        state.jewelIndex = 0;

        clearErrors();

        addTrancheRow();
        addJewelRow();
    }

    function openCreateModal() {
        resetForm();

        $('#loanFormModalTitle').text('Add Loan');

        loanModal = loanModal || safeModal('#loanFormModal');

        if (loanModal) {
            loanModal.show();
        }
    }

    function activateType(typeCode, typeId) {
        $('#loanTypeId').val(typeId || '');

        $('#loanTypeCards [data-loan-type-card]')
            .removeClass('active');

        $(`[data-loan-type-card="${CSS.escape(typeCode)}"]`)
            .addClass('active');

        $('#loanVehiclePanel, #loanTermPanel, #loanJewelPanel, #loanCcPanel, #loanThirdPartyPanel, #loanNoTypePanel')
            .addClass('d-none');

        if (typeCode === 'vehicle') {
            $('#loanVehiclePanel').removeClass('d-none');
        } else if (typeCode === 'term') {
            $('#loanTermPanel').removeClass('d-none');
        } else if (typeCode === 'jewel') {
            $('#loanJewelPanel').removeClass('d-none');
        } else if (typeCode === 'cc') {
            $('#loanCcPanel').removeClass('d-none');
        } else if (typeCode === 'third_party') {
            $('#loanThirdPartyPanel').removeClass('d-none');
        } else {
            $('#loanNoTypePanel').removeClass('d-none');
        }
    }

    function addTrancheRow(data = {}) {
        const index = state.trancheIndex++;

        $('#loanTrancheRows').append(`
            <tr data-tranche-row="${index}">
                <td class="fw-bold">
                    ${index + 1}
                </td>

                <td>
                    <input
                        type="text"
                        class="form-control form-control-sm common_datepicker_cust"
                        name="tranches[${index}][disbursed_date]"
                        value="${esc(data.disbursed_date || '')}" placeholder="select Disbursed Date"
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        class="form-control form-control-sm"
                        name="tranches[${index}][amount]"
                        value="${esc(data.amount || '')}"
                        placeholder="0.00"
                    >
                </td>

                <td>
                    <input
                        type="text"
                        maxlength="500"
                        class="form-control form-control-sm"
                        name="tranches[${index}][remarks]"
                        value="${esc(data.remarks || '')}"
                        placeholder="Optional"
                    >
                </td>

                <td class="text-center">
                    <button
                        type="button"
                        class="btn btn-sm btn-light text-danger"
                        data-remove-tranche="${index}"
                        title="Remove"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </td>
            </tr>
        `);
    }

    function addJewelRow(data = {}) {
        const index = state.jewelIndex++;

        $('#loanJewelRows').append(`
            <tr data-jewel-row="${index}">
                <td class="fw-bold">
                    ${index + 1}
                </td>

                <td>
                    <input
                        type="text"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][description]"
                        value="${esc(data.description || '')}"
                        placeholder="Chain / Ring / Bangle..."
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.001"
                        min="0"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][gross_weight]"
                        value="${esc(data.gross_weight || '')}"
                        placeholder="0.000"
                    >
                </td>

                <td>
                    <input
                        type="number"
                        step="0.001"
                        min="0"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][net_weight]"
                        value="${esc(data.net_weight || '')}"
                        placeholder="0.000"
                    >
                </td>

                <td>
                    <input
                        type="text"
                        maxlength="30"
                        class="form-control form-control-sm"
                        name="jewel_items[${index}][purity]"
                        value="${esc(data.purity || '')}"
                        placeholder="22K"
                    >
                </td>

                <td class="text-center">
                    <button
                        type="button"
                        class="btn btn-sm btn-light text-danger"
                        data-remove-jewel="${index}"
                        title="Remove"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </td>
            </tr>
        `);
    }

    function fillForm(loan) {
        resetForm();

        $('#loanId').val(loan.id || '');
        $('#loanFormModalTitle').text('Edit Loan');

        $('#loanCompanyId').val(loan.company_id ?? loan.entity_id ?? '').trigger('change');
        $('#loanLenderId').val(loan.lender_id || '').change();
        $('#loanAccountNo').val(loan.account_no || '');
        $('#loanTitle').val(loan.title || '');
        $('#loanInterestType').val(loan.interest_type || 'reducing');
        $('#loanSanctioned').val(loan.sanctioned_amount || '');
        $('#loanDisbursed').val(loan.disbursed_amount || '');
        $('#loanOutstanding').val(loan.outstanding_amount || '');
        $('#loanRate').val(loan.interest_rate || '');
        $('#loanStartDate').val(
            loan.start_date ? String(loan.start_date).slice(0, 10) : ''
        );
        $('#loanFirstDueDate').val(
            loan.first_due_date ? String(loan.first_due_date).slice(0, 10) : ''
        );
        $('#loanTenure').val(loan.tenure_months || '');
        $('#loanEmi').val(loan.emi_amount || '');
        $('#loanMaturityDate').val(
            loan.maturity_date ? String(loan.maturity_date).slice(0, 10) : ''
        );
        $('#loanMoratorium').val(loan.moratorium_months || 0);
        $('#loanSecurity').val(loan.security_details || '');
        $('#loanRemarks').val(loan.remarks || '');

        const type = loan.loan_type || loan.type?.type_code || '';

        activateType(type, loan.loan_type_id);

        if (loan.vehicle) {
            $('#loanVehicleReg').val(
                loan.vehicle.registration_no || ''
            );
            $('#loanVehicleMake').val(
                loan.vehicle.make_model || ''
            );
            $('#loanVehicleChassis').val(
                loan.vehicle.chassis_no || ''
            );
            $('#loanVehicleEngine').val(
                loan.vehicle.engine_no || ''
            );
            $('#loanVehicleInsurance').val(
                loan.vehicle.insurance_renewal_date
                    ? String(loan.vehicle.insurance_renewal_date).slice(0, 10)
                    : ''
            );
            $('#loanVehicleHypothecated').prop(
                'checked',
                !!loan.vehicle.hypothecated_flag
            );
        }

        $('#loanTrancheRows').empty();
        state.trancheIndex = 0;

        (loan.tranches || []).forEach(addTrancheRow);

        if (!loan.tranches || !loan.tranches.length) {
            addTrancheRow();
        }

        if (loan.jewel_pledge) {
            $('#loanPledgeReceipt').val(
                loan.jewel_pledge.pledge_receipt_no || ''
            );
            $('#loanJewelInterestPattern').val(
                loan.jewel_pledge.interest_pattern || 'monthly'
            );
            $('#loanRedemptionDate').val(
                loan.jewel_pledge.redemption_due_date
                    ? String(loan.jewel_pledge.redemption_due_date).slice(0, 10)
                    : ''
            );

            $('#loanJewelRows').empty();
            state.jewelIndex = 0;

            (loan.jewel_pledge.items || []).forEach(addJewelRow);

            if (!loan.jewel_pledge.items?.length) {
                addJewelRow();
            }
        }

        if (loan.cc_facility) {
            $('#loanCcLimit').val(
                loan.cc_facility.sanctioned_limit || ''
            );
            $('#loanCcMargin').val(
                loan.cc_facility.margin_percent || ''
            );
            $('#loanCcDrawingPower').val(
                loan.cc_facility.drawing_power || ''
            );
            $('#loanCcRate').val(
                loan.cc_facility.interest_rate || ''
            );
            $('#loanCcRenewalDate').val(
                loan.cc_facility.renewal_date
                    ? String(loan.cc_facility.renewal_date).slice(0, 10)
                    : ''
            );
            $('#loanCcStockDay').val(
                loan.cc_facility.stock_statement_day || ''
            );
        }
    }

    function openEditModal(id) {
        $.ajax({
            url: url(routes.show, id),
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response?.data?.loan) {
                throw new Error('Loan information was not returned.');
            }

            fillForm(response.data.loan);

            loanModal = loanModal || safeModal('#loanFormModal');

            if (loanModal) {
                loanModal.show();
            }
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to load loan details.'
            );
        });
    }

    function submitLoanForm(event) {
        event.preventDefault();

        const form = document.getElementById('loanForm');

        if (!form) {
            return;
        }

        clearErrors();

        const typeId = $('#loanTypeId').val();

        if (!typeId) {
            applyErrors({
                loan_type_id: ['Please select a loan type.']
            });

            return;
        }

        const id = $('#loanId').val();
        const isEdit = Boolean(id);

        const formData = new FormData(form);

        if (isEdit) {
            formData.append('_method', 'PUT');
        }

        setLoading('#loanSaveBtn', true);

        $.ajax({
            url: isEdit
                ? url(routes.update, id)
                : routes.store,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response || Number(response.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to save loan.'
                );
            }

            toast(
                response.message || 'Loan saved successfully.',
                'success'
            );

            if (loanModal) {
                loanModal.hide();
            }

            refreshList(state.page);
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                isEdit
                    ? 'Unable to update loan.'
                    : 'Unable to create loan.'
            );
        })
        .always(function () {
            setLoading('#loanSaveBtn', false);
        });
    }

    function renderLoanView(loan) {
        const type = loan.loan_type_name
            || loan.loan_type
            || '-';

        const nextDue = loan.obligations?.[0];

        const html = `
            <div class="row g-3">
                <div class="col-lg-8">
                    <div class="card border h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-start justify-content-between gap-3">
                                <div>
                                    <div class="text-muted small">
                                        ${esc(type)}
                                    </div>
                                    <h5 class="fw-bold text-dark mb-1">
                                        ${esc(loan.account_no || '-')}
                                    </h5>
                                    <div class="fw-semibold">
                                        ${esc(loan.title || '-')}
                                    </div>
                                </div>
                                <div>
                                    ${statusBadge(loan.status)}
                                </div>
                            </div>

                            <hr>

                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="small text-muted">Lender</div>
                                    <div class="fw-bold">${esc(loan.lender?.lender_name || '-')}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Start Date</div>
                                    <div class="fw-bold">${esc(date(loan.start_date))}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Maturity</div>
                                    <div class="fw-bold">${esc(date(loan.maturity_date))}</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Outstanding</div>
                                    <div class="fw-bold text-danger">
                                        ${money(loan.outstanding_amount)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Rate</div>
                                    <div class="fw-bold">${esc(loan.interest_rate)}%</div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">Tenure</div>
                                    <div class="fw-bold">
                                        ${esc(loan.tenure_months || 0)} months
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card border h-100 bg-light">
                        <div class="card-body">
                            <div class="small text-muted mb-1">
                                Next Due
                            </div>

                            <div class="fw-bold fs-5 text-dark">
                                ${esc(nextDue?.title || 'No pending due')}
                            </div>

                            <div class="mt-2 fw-semibold">
                                ${nextDue ? date(nextDue.due_date) : '-'}
                            </div>

                            <div class="mt-1 text-danger fw-bold">
                                ${nextDue ? money(nextDue.balance_amount) : ''}
                            </div>

                            <div class="mt-3">
                                ${nextDue ? statusBadge(nextDue.status_key) : ''}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border">
                        <div class="card-body">
                            <div class="fw-bold mb-3">
                                Schedule Versions
                            </div>

                            <div id="loanViewScheduleVersions">
                                ${(loan.schedules || []).length
                                    ? loan.schedules.map(function (schedule) {
                                        return `
                                            <div class="border rounded p-3 mb-2">
                                                <div class="d-flex justify-content-between gap-2">
                                                    <div>
                                                        <div class="fw-bold">
                                                            ${esc(schedule.schedule_label || '-')}
                                                        </div>
                                                        <div class="small text-muted">
                                                            ${esc(schedule.method || '-')}
                                                            · Effective ${esc(date(schedule.effective_from))}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        ${schedule.is_active
                                                            ? '<span class="badge bg-success">Active</span>'
                                                            : '<span class="badge bg-secondary">Superseded</span>'}
                                                    </div>
                                                </div>
                                            </div>
                                        `;
                                    }).join('')
                                    : '<div class="text-muted">No schedule versions yet. Finance approval generates the first schedule.</div>'
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('#loanViewTitle').text(
            loan.account_no || 'Loan Details'
        );

        $('#loanViewSubtitle').text(
            `${loan.lender?.lender_name || ''} · ${type}`
        );

        $('#loanViewBody').html(html);
    }

    function openViewModal(id) {
        $('#loanViewBody').html(`
            <div class="loan-loading loan-view-skeleton">
                <div class="loan-skeleton loan-skeleton-line loan-skeleton-line-lg mx-auto"></div>
                <div class="loan-skeleton loan-skeleton-line loan-skeleton-line-md mx-auto mt-3"></div>
                <div class="row g-3 mt-3">
                    <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                    <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                    <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                    <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                </div>
            </div>
        `);

        viewModal = viewModal || safeModal('#loanViewModal');

        if (viewModal) {
            viewModal.show();
        }

        $.ajax({
            url: url(routes.show, id),
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (!response?.data?.loan_raw && !response?.data?.loan) {
                throw new Error('Loan details were not returned.');
            }

            const loan = response.data.loan_raw || response.data.loan;

            renderLoanView({
                ...loan,
                schedules: response.data.schedule_versions || [],
                obligations: loan.obligations || [],
            });
        })
        .fail(function (xhr) {
            $('#loanViewBody').html(`
                <div class="loan-empty">
                    Unable to load this loan.
                </div>
            `);

            handleAjaxError(
                xhr,
                'Unable to load loan details.'
            );
        });
    }

    function approveLoan(id) {
        $.ajax({
            url: url(routes.approve, id),
            type: 'POST',
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Loan approved.',
                'success'
            );

            refreshList(state.page);
        })
        .fail(function (xhr) {
            handleAjaxError(
                xhr,
                'Unable to approve loan.'
            );
        });
    }

    function openReturnModal(id) {
        $('#loanReturnId').val(id);
        $('#loanReturnRemarks').val('');
        $('#loanReturnError').text('');

        returnModal = returnModal || safeModal('#loanReturnModal');

        if (returnModal) {
            returnModal.show();
        }
    }

    function submitReturn(event) {
        event.preventDefault();

        const id = $('#loanReturnId').val();
        const remarks = $.trim(
            $('#loanReturnRemarks').val()
        );

        if (!remarks) {
            $('#loanReturnError').text(
                'Please enter the return remarks.'
            );

            return;
        }

        $.ajax({
            url: url(routes.return, id),
            type: 'POST',
            data: {
                remarks: remarks,
                _token: config.csrf || '',
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Loan returned.',
                'success'
            );

            if (returnModal) {
                returnModal.hide();
            }

            refreshList(state.page);
        })
        .fail(function (xhr) {
            $('#loanReturnError').text(
                xhr.responseJSON?.message
                || 'Unable to return the loan.'
            );

            handleAjaxError(
                xhr,
                'Unable to return the loan.'
            );
        });
    }

    function bindEvents() {
        $('#loanAddBtn').on('click', openCreateModal);

        $('#loanForm').on('submit', submitLoanForm);

        $('#loanAddTrancheBtn').on(
            'click',
            function () {
                addTrancheRow();
            }
        );

        $('#loanAddJewelBtn').on(
            'click',
            function () {
                addJewelRow();
            }
        );

        $(document).on('click', '[data-loan-type-card]', function () {
            const code = $(this).data('loan-type-card');
            const type = ($('#loanTypeId').data('types') || []).find(function (item) {
                return String(item.type_code) === String(code);
            });

            if (type) {
                activateType(type.type_code, type.id);
            }
        });

        window.jQuery(document).off('change.loanCompanyFilter', '#loanCompanyFilter').on('change.loanCompanyFilter', '#loanCompanyFilter', function () {
            state.companyId = $(this).val();
            refreshList(1);
        });

       window.jQuery(document).on('change', '#loanLenderFilter', function () {
            state.lenderId = $(this).val();
            refreshList(1);
        });

        


        window.jQuery(document).on('change', '#loanPerPage', function () {
             state.perPage = Number($(this).val()) || 25;
            refreshList(1);
        });

        

        $('#loanClearSearch').on(
            'click',
            function () {
                $('#loanSearch').val('');
                state.search = '';
                refreshList(1);
            }
        );

        let searchTimer = null;

        $('#loanSearch').on(
            'input',
            function () {
                clearTimeout(searchTimer);

                state.search = $.trim($(this).val());

                searchTimer = setTimeout(
                    function () {
                        refreshList(1);
                    },
                    350
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-type]',
            function () {
                state.type = $(this).data('loan-type') || '';

                $('[data-loan-type]')
                    .removeClass('active');

                $(this).addClass('active');

                refreshList(1);
            }
        );

        $(document).on(
            'click',
            '[data-loan-status]',
            function () {
                state.status = $(this).data('loan-status') || '';

                $('[data-loan-status]')
                    .removeClass('active');

                $(this).addClass('active');

                refreshList(1);
            }
        );

        $(document).on(
            'click',
            '[data-loan-page]',
            function () {
                const page = Number(
                    $(this).data('loan-page')
                );

                if (page >= 1) {
                    refreshList(page);
                }
            }
        );

        

        $(document).on(
            'click',
            '[data-loan-edit]',
            function () {
                openEditModal(
                    $(this).data('loan-edit')
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-approve]',
            function () {
                approveLoan(
                    $(this).data('loan-approve')
                );
            }
        );

        $(document).on(
            'click',
            '[data-loan-return]',
            function () {
                openReturnModal(
                    $(this).data('loan-return')
                );
            }
        );

        $('#loanReturnForm').on(
            'submit',
            submitReturn
        );

        $(document).on(
            'click',
            '[data-remove-tranche]',
            function () {
                $(this)
                    .closest('[data-tranche-row]')
                    .remove();
            }
        );

        $(document).on(
            'click',
            '[data-remove-jewel]',
            function () {
                $(this)
                    .closest('[data-jewel-row]')
                    .remove();
            }
        );
    }

    function init() {
        loanModal = safeModal('#loanFormModal');
        viewModal = safeModal('#loanViewModal');
        returnModal = safeModal('#loanReturnModal');

        loadLookups()
            .always(function () {
                bindEvents();
                refreshList(1);
            });
    }

    window.LoanScheduleReload = function () {
        refreshList(state.page || 1);
    };

    $(function () {
        init();
    });

})(window.jQuery);

</script>
<script>
    (function ($) {
        'use strict';

        if (!$ || !$.fn) {
            return;
        }

        const SELECT3_SELECTOR = '.select3';

        function getSelect3Parent($select) {
            const $modal = $select.closest('.modal');

            return $modal.length
                ? $modal
                : $('#loanSchedulePage');
        }

        function initOneSelect3($select) {
            if (!$select.length || typeof $.fn.select2 !== 'function') {
                return;
            }

            // Mark explicitly as select3 without changing the existing field IDs.
            $select.addClass('select3');

            // Safe re-init after lookup options are rebuilt.
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }

            const isSearchable = !$select.is('#loanPerPage');
            const isClearable = !$select.is('#loanPerPage')
                && !$select.is('#loanInterestType')
                && !$select.is('#loanJewelInterestPattern');

            $select.select2({
                width: '100%',
                dropdownParent: getSelect3Parent($select),
                minimumResultsForSearch: isSearchable ? 0 : Infinity,
                placeholder: $select.find('option:first').text() || 'Select',
                allowClear: isClearable,
                dropdownCssClass: 'loan-select3-dropdown'
            });

            // Select2 already triggers the native/jQuery change event.
            // No duplicate onchange callback is attached here.
            $select.off('.loanSelect3Sync').on('change.loanSelect3Sync', function () {
                $(this).triggerHandler('loan:select3-change');
            });
        }

        function initLoanSelect3() {
            $(SELECT3_SELECTOR).each(function () {
                initOneSelect3($(this));
            });
        }

        // Public helper for functions which rebuild <option> elements.
        window.LoanScheduleInitSelect3 = initLoanSelect3;

        // Initial page load.
        $(function () {
            initLoanSelect3();
        });

        // Lookup functions in loan_index.blade.php can call this helper
        // immediately after replacing their <option> markup.


    })(window.jQuery);
</script>
<script>
    $('.common_datepicker_cust').datepicker({
        todayHighlight: true,
        autoclose: true,
        format: 'dd-M-yyyy'
    });
</script>
<script>
(function ($) {
    'use strict';

    const routes = window.LoanScheduleRoutes || {};
    const config = window.LoanSchedulePageConfig || {};

    if (!routes.show || !document.getElementById('loanViewModal')) {
        return;
    }

    const state = {
        viewLoan: null,
        viewTab: 'overview',
        actionType: null,
        actionLoanId: null,
        actionMode: 'direct',
        lenderPage: 1,
        lenderPerPage: 25,
        lenderSearch: '',
        lenderStatus: '',
        lenderId: null,
        confirmCallback: null,
        lenderRows: {},
    };

    const modal = (selector) => {
        const el = document.querySelector(selector);
        return el && window.bootstrap?.Modal
            ? bootstrap.Modal.getOrCreateInstance(el)
            : null;
    };

    const viewModal = () => modal('#loanViewModal');
    const lenderModal = () => modal('#loanLenderModal');
    const paymentModal = () => modal('#loanPaymentModal');
    const actionModal = () => modal('#loanActionModal');
    const confirmModal = () => modal('#loanConfirmModal');

    function esc(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function money(value) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2,
        }).format(Number(value || 0));
    }

    function date(value) {
        if (!value) return '-';
        const raw = String(value).slice(0, 10);
        const p = raw.split('-');
        return p.length === 3 ? `${p[2]}-${p[1]}-${p[0]}` : raw;
    }

    function url(template, id) {
        return String(template || '').replace('__ID__', encodeURIComponent(String(id)));
    }

    function toast(message, type = 'success') {
        const toastEl = document.getElementById('loanToast');
        const bodyEl = document.getElementById('loanToastBody');
        if (!toastEl || !bodyEl) return;
        toastEl.classList.remove('text-bg-success', 'text-bg-danger', 'text-bg-warning', 'text-bg-info');
        const cls = {success:'text-bg-success',error:'text-bg-danger',danger:'text-bg-danger',warning:'text-bg-warning',info:'text-bg-info'}[type] || 'text-bg-success';
        toastEl.classList.add(cls);
        bodyEl.textContent = message || 'Completed.';
        if (window.bootstrap?.Toast) bootstrap.Toast.getOrCreateInstance(toastEl, {delay: 3500}).show();
    }

    function handleError(xhr, fallback) {
        let payload = xhr?.responseJSON || null;
        if (!payload) {
            try { payload = JSON.parse(xhr?.responseText || '{}'); } catch (e) { payload = null; }
        }
        let message = payload?.message || fallback || 'Unable to complete the request.';
        if (payload?.errors) {
            const first = Object.values(payload.errors)[0];
            if (Array.isArray(first) && first[0]) message = first[0];
        }
        toast(message, 'error');
        return payload;
    }

    function ajaxPost(target, data, method = 'POST') {
        return $.ajax({
            url: target,
            type: method,
            data: data || {},
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        });
    }

    function statusBadge(status) {
        const map = {
            active: ['Active', 'bg-success-subtle text-success'],
            pending_approval: ['Pending Approval', 'bg-warning-subtle text-black'],
            returned: ['Returned', 'bg-danger-subtle text-danger'],
            closed: ['Closed', 'bg-secondary-subtle text-secondary'],
            foreclosed: ['Foreclosed', 'bg-secondary-subtle text-secondary'],
            restructured: ['Restructured', 'bg-success-subtle text-success'],
            overdue: ['Overdue', 'bg-danger-subtle text-danger'],
            paid: ['Paid', 'bg-success-subtle text-success'],
            partial: ['Partial', 'bg-warning-subtle text-black'],
            snoozed: ['Snoozed', 'bg-info-subtle text-info'],
            today: ['Due Today', 'bg-warning-subtle text-black'],
            upcoming: ['Upcoming', 'bg-info-subtle text-info'],
        };
        const item = map[status] || [status || '-', 'bg-light text-secondary'];
        return `<span class="badge rounded-pill ${item[1]}">${esc(item[0])}</span>`;
    }

    function infoCard(label, value, extra = '') {
        return `<div class="loan-info-card"><div class="loan-info-label">${esc(label)}</div><div class="loan-info-value ${extra}">${value}</div></div>`;
    }

    function companyName(id) {
        const $opt = $('#loanCompanyFilter option').filter(function () { return String(this.value) === String(id); }).first();
        return $opt.length ? $opt.text() : '-';
    }

    function getPendingChange(loan) {
        return (loan?.change_requests || []).filter((x) => x.status === 'pending').sort((a,b) => Number(b.id || 0) - Number(a.id || 0))[0] || null;
    }

    function renderViewActions(loan) {
        const pendingChange = getPendingChange(loan);
        let html = '';
        if (loan.status === 'pending_approval') {
            if (pendingChange?.change_type === 'prepay') {
                html += `<button type="button" class="btn btn-sm btn-success" data-view-approve-prepay="${esc(loan.id)}"><i class="mdi mdi-check-circle-outline me-1"></i>Approve Prepay</button>`;
            } else if (pendingChange?.change_type === 'restructure') {
                html += `<button type="button" class="btn btn-sm btn-success" data-view-approve-restructure="${esc(loan.id)}"><i class="mdi mdi-check-circle-outline me-1"></i>Approve Restructure</button>`;
            } else {
                html += `<button type="button" class="btn btn-sm btn-success" data-view-approve-loan="${esc(loan.id)}"><i class="mdi mdi-check-circle-outline me-1"></i>Approve</button>`;
            }
            html += `<button type="button" class="btn btn-sm btn-label-danger" data-view-return-loan="${esc(loan.id)}"><i class="mdi mdi-undo-variant me-1"></i>Return</button>`;
        }
        if (['active','restructured'].includes(loan.status)) {
            html += `<button type="button" class="btn btn-sm btn-warning" data-view-payment="${esc(loan.id)}"><i class="mdi mdi-cash-plus me-1"></i>Payment</button>`;
            html += `<div class="dropdown loan-action-menu">\n                <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal me-1"></i>Actions</button>\n                <ul class="dropdown-menu dropdown-menu-end">\n                    <li><button type="button" class="dropdown-item" data-view-action="prepay" data-view-action-id="${esc(loan.id)}"><i class="mdi mdi-cash-minus"></i>Part Prepayment</button></li>\n                    <li><button type="button" class="dropdown-item" data-view-action="restructure" data-view-action-id="${esc(loan.id)}"><i class="mdi mdi-file-edit-outline"></i>Restructure</button></li>\n                    ${loan.loan_type === 'cc' ? `<li><button type="button" class="dropdown-item" data-view-action="renewal" data-view-action-id="${esc(loan.id)}"><i class="mdi mdi-calendar-refresh-outline"></i>CC Renewal</button></li><li><button type="button" class="dropdown-item" data-view-action="utilisation" data-view-action-id="${esc(loan.id)}"><i class="mdi mdi-chart-donut"></i>CC Utilisation</button></li>` : ''}\n                    <li><hr class="dropdown-divider"></li>\n                    <li><button type="button" class="dropdown-item text-danger" data-view-action="close" data-view-action-id="${esc(loan.id)}"><i class="mdi mdi-close-circle-outline"></i>Close / Foreclose</button></li>\n                </ul>\n            </div>`;
        }
        return html;
    }

    function renderLoanView(loan, activeTab = 'overview') {
        state.viewLoan = loan;
        state.viewTab = activeTab;
        const type = loan.type?.type_name || loan.loan_type || '-';
        const next = (loan.obligations || []).filter((o) => !['paid','superseded','waived'].includes(o.status)).sort((a,b) => String(a.due_date).localeCompare(String(b.due_date)))[0];
        const lastUtil = loan.cc_facility?.utilisations?.[0];
        $('#loanViewTitle').text(`${loan.account_no || 'Loan'} · ${loan.title || ''}`.trim());
        $('#loanViewSubtitle').text(`${loan.lender?.lender_name || '-'}${loan.lender?.branch_name ? ' · ' + loan.lender.branch_name : ''} · ${type}`);
        $('#loanViewActions').html(renderViewActions(loan));

        const tabs = ['overview','schedule','payments','documents','audit'];
        const tabLabels = {overview:'Overview',schedule:'Schedule',payments:'Payments',documents:'Documents',audit:'Audit'};
        const tabNav = `<div class="loan-view-tabs px-3">${tabs.map((tab) => `<button type="button" class="loan-view-tab ${tab===activeTab?'active':''}" data-loan-view-tab="${tab}">${tabLabels[tab]}</button>`).join('')}</div>`;
        const hero = `<div class="loan-view-hero m-3 mb-0"><div class="row g-3 align-items-center position-relative"><div class="col-lg-7"><div class="loan-view-meta">${esc(type)} · ${esc(loan.account_no || '-')}</div><div class="fs-5 fw-bold mt-1">${esc(loan.title || loan.account_no || 'Loan')}</div><div class="d-flex align-items-center gap-2 mt-2 flex-wrap">${statusBadge(loan.status)}${loan.pending_change_type ? `<span class="badge rounded-pill bg-white text-dark">Pending ${esc(loan.pending_change_type)}</span>` : ''}</div></div><div class="col-lg-5 text-lg-end"><div class="loan-view-meta">Outstanding</div><div class="loan-view-money">${money(loan.outstanding_amount)}</div><div class="loan-view-meta mt-1">EMI ${money(loan.emi_amount)} · Maturity ${esc(date(loan.maturity_date))}</div></div></div></div>`;
        let tabContent = '';
        if (activeTab === 'schedule') tabContent = renderScheduleTab(loan);
        else if (activeTab === 'payments') tabContent = renderPaymentsTab(loan);
        else if (activeTab === 'documents') tabContent = renderDocumentsTab(loan);
        else if (activeTab === 'audit') tabContent = renderAuditTab(loan);
        else tabContent = renderOverviewTab(loan, next, lastUtil);
        $('#loanViewBody').html(hero + tabNav + `<div class="p-3" id="loanViewTabContent">${tabContent}</div>`);
    }

    function renderOverviewTab(loan, next, lastUtil) {
        let html = `<div class="row g-3">\n            <div class="col-12 col-lg-8"><div class="row g-3">\n                <div class="col-6 col-xl-3">${infoCard('Company', companyName(loan.company_id ?? loan.entity_id))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Lender', esc(loan.lender?.lender_name || '-'))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Loan Type', esc(loan.type?.type_name || loan.loan_type || '-'))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Interest Rate', `${esc(loan.interest_rate || 0)}%`)}</div>\n                <div class="col-6 col-xl-3">${infoCard('Sanctioned', money(loan.sanctioned_amount))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Disbursed', money(loan.disbursed_amount))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Interest Type', esc(loan.interest_type || '-'))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Tenure', `${esc(loan.tenure_months || 0)} months`)}</div>\n                <div class="col-6 col-xl-3">${infoCard('Start Date', esc(date(loan.start_date)))}</div>\n                <div class="col-6 col-xl-3">${infoCard('First Due', esc(date(loan.first_due_date)))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Maturity', esc(date(loan.maturity_date)))}</div>\n                <div class="col-6 col-xl-3">${infoCard('Moratorium', `${esc(loan.moratorium_months || 0)} months`)}</div>\n            </div></div>\n            <div class="col-12 col-lg-4"><div class="loan-info-card h-100 bg-label-light">\n                <div class="loan-info-label">Next Due</div><div class="fw-bold fs-6 mt-1">${esc(next?.title || 'No pending obligation')}</div>\n                <div class="small text-muted mt-1">${next ? date(next.due_date) : '-'}</div>\n                <div class="fw-bold text-danger fs-5 mt-2">${next ? money(next.balance_amount) : ''}</div>\n                <div class="mt-2">${next ? statusBadge(next.status) : ''}</div>\n                ${next ? `<div class="d-flex gap-1 flex-wrap mt-3"><button type="button" class="btn btn-sm btn-light border" data-view-snooze="${esc(next.id)}" data-days="1"><i class="mdi mdi-clock-outline me-1"></i>1 Day</button><button type="button" class="btn btn-sm btn-light border" data-view-snooze="${esc(next.id)}" data-days="7">7 Days</button></div>` : ''}\n                ${lastUtil ? `<div class="border-top mt-3 pt-3"><div class="loan-info-label">Latest CC Utilisation</div><div class="fw-bold mt-1">${money(lastUtil.utilised_amount)}</div><div class="small text-muted">${date(lastUtil.as_of_date)}</div></div>` : ''}\n            </div></div>\n            <div class="col-12">${renderTypeSpecific(loan)}</div>\n            <div class="col-12"><div class="row g-3"><div class="col-lg-6">${infoCard('Security Details', esc(loan.security_details || 'Not specified'))}</div><div class="col-lg-6">${infoCard('Remarks', esc(loan.remarks || 'No remarks'))}</div></div></div>\n        </div>`;
        return html;
    }

    function renderTypeSpecific(loan) {
        const type = loan.loan_type;
        if (type === 'vehicle') {
            const v = loan.vehicle || {};
            return `<div class="loan-info-card"><div class="fw-bold mb-3">Vehicle Details</div><div class="row g-3"><div class="col-6 col-lg-3">${infoCard('Registration No.', esc(v.registration_no || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Make / Model', esc(v.make_model || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Chassis No.', esc(v.chassis_no || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Engine No.', esc(v.engine_no || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Hypothecated', v.hypothecated_flag ? 'Yes' : 'No')}</div><div class="col-6 col-lg-3">${infoCard('Insurance Renewal', esc(date(v.insurance_renewal_date)))}</div></div></div>`;
        }
        if (type === 'jewel') {
            const j = loan.jewel_pledge || {};
            const rows = (j.items || []).map((item) => `<tr><td>${esc(item.item_no ?? '-')}</td><td>${esc(item.description || '-')}</td><td>${esc(item.gross_weight ?? '-')}</td><td>${esc(item.net_weight ?? '-')}</td><td>${esc(item.purity ?? '-')}</td><td>${statusBadge(item.release_status)}</td></tr>`).join('');
            return `<div class="loan-info-card"><div class="fw-bold mb-3">Jewel Pledge</div><div class="row g-3 mb-3"><div class="col-6 col-lg-3">${infoCard('Receipt No.', esc(j.pledge_receipt_no || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Interest Pattern', esc(j.interest_pattern || '-'))}</div><div class="col-6 col-lg-3">${infoCard('Redemption Due', esc(date(j.redemption_due_date)))}</div><div class="col-6 col-lg-3">${infoCard('Status', statusBadge(j.status))}</div></div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>#</th><th>Description</th><th>Gross Wt.</th><th>Net Wt.</th><th>Purity</th><th>Release</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="text-muted">No pledge items recorded.</td></tr>'}</tbody></table></div></div>`;
        }
        if (type === 'cc') {
            const c = loan.cc_facility || {};
            return `<div class="loan-info-card"><div class="fw-bold mb-3">CC Facility</div><div class="row g-3"><div class="col-6 col-lg-3">${infoCard('Sanctioned Limit', money(c.sanctioned_limit))}</div><div class="col-6 col-lg-3">${infoCard('Margin', `${esc(c.margin_percent ?? 0)}%`)}</div><div class="col-6 col-lg-3">${infoCard('Drawing Power', money(c.drawing_power))}</div><div class="col-6 col-lg-3">${infoCard('CC Rate', `${esc(c.interest_rate ?? loan.interest_rate ?? 0)}%`)}</div><div class="col-6 col-lg-3">${infoCard('Renewal Date', esc(date(c.renewal_date)))}</div><div class="col-6 col-lg-3">${infoCard('Stock Statement Day', esc(c.stock_statement_day ?? '-'))}</div></div></div>`;
        }
        if (type === 'term') {
            const rows = (loan.tranches || []).map((t, i) => `<tr><td>${i+1}</td><td>${esc(date(t.disbursal_date))}</td><td>${money(t.amount)}</td><td>${esc(t.reference_no || '-')}</td><td>${esc(t.status || '-')}</td></tr>`).join('');
            return `<div class="loan-info-card"><div class="fw-bold mb-3">Term Loan Tranches</div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>#</th><th>Disbursal Date</th><th>Amount</th><th>Reference</th><th>Status</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="text-muted">No tranche details recorded.</td></tr>'}</tbody></table></div></div>`;
        }
        if (type === 'third_party') {
            return `<div class="loan-info-card bg-light"><div class="fw-bold">Third Party Loan</div><div class="small text-muted mt-1">This facility uses the common finance data model. Third-party/guarantee context is captured through Security Details and Remarks so the form remains one-page and type-aware.</div></div>`;
        }
        return `<div class="loan-info-card"><div class="fw-bold">Type Specific Details</div><div class="small text-muted mt-1">No additional details are configured for this loan type.</div></div>`;
    }

    function renderScheduleTab(loan) {
        const schedules = (loan.schedules || []).slice().sort((a,b) => Number(b.version_no||0)-Number(a.version_no||0));
        if (!schedules.length) return `<div class="loan-empty-block"><i class="mdi mdi-calendar-blank-outline fs-2"></i><div class="fw-bold mt-2">No schedule versions</div><div class="small mt-1">Finance approval or a subsequent loan action will create the active schedule.</div></div>`;
        return schedules.map((schedule) => {
            const lines = (schedule.lines || []).slice().sort((a,b) => Number(a.installment_no||0)-Number(b.installment_no||0));
            return `<div class="loan-info-card mb-3"><div class="d-flex justify-content-between align-items-start gap-2 mb-3"><div><div class="fw-bold">${esc(schedule.schedule_label || `Schedule v${schedule.version_no || '-'}`)}</div><div class="small text-muted">${esc(schedule.method || '-')} · Effective ${esc(date(schedule.effective_from))} · ${esc(schedule.tenure_months || lines.length)} months</div></div>${schedule.is_active ? '<span class="badge bg-success-subtle text-success">Active</span>' : '<span class="badge bg-secondary-subtle text-secondary">Superseded</span>'}</div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>#</th><th>Due Date</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Closing</th><th>Status</th></tr></thead><tbody>${lines.map((line) => `<tr class="${line.status === 'paid' ? 'table-success' : ''}"><td>${esc(line.installment_no)}</td><td>${esc(date(line.due_date))}</td><td>${money(line.emi_amount)}</td><td>${money(line.principal_amount)}</td><td>${money(line.interest_amount)}</td><td>${money(line.closing_balance)}</td><td>${statusBadge(line.status)}</td></tr>`).join('') || '<tr><td colspan="7" class="text-muted">No lines available.</td></tr>'}</tbody></table></div></div>`;
        }).join('');
    }

    function renderPaymentsTab(loan) {
        const rows = (loan.payments || []).slice().sort((a,b) => String(b.payment_date || '').localeCompare(String(a.payment_date || ''))).map((p) => `<tr><td>${esc(date(p.payment_date))}</td><td>${esc(p.payment_type || '-')}</td><td class="fw-bold">${money(p.amount)}</td><td>${money(p.principal_amount)}</td><td>${money(p.interest_amount)}</td><td>${esc(p.mode || '-')}</td><td>${esc(p.reference_no || '-')}</td><td>${esc(p.pay_from_account || '-')}</td></tr>`).join('');
        return `<div class="loan-info-card"><div class="d-flex justify-content-between align-items-center mb-3"><div><div class="fw-bold">Payment Register</div><div class="small text-muted">All recorded payments and principal/interest allocation.</div></div><button type="button" class="btn btn-sm btn-warning" data-view-payment="${esc(loan.id)}"><i class="mdi mdi-cash-plus me-1"></i>Record Payment</button></div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>Date</th><th>Type</th><th>Amount</th><th>Principal</th><th>Interest</th><th>Mode</th><th>Reference</th><th>Pay From</th></tr></thead><tbody>${rows || '<tr><td colspan="8" class="text-muted">No payments recorded.</td></tr>'}</tbody></table></div></div>`;
    }

    function renderDocumentsTab(loan) {
        const rows = (loan.documents || []).map((d) => `<tr><td><i class="mdi mdi-file-document-outline me-1"></i>${esc(d.document_name || '-')}</td><td>${esc(d.document_type || '-')}</td><td>${esc(d.mime_type || '-')}</td><td>${d.size_bytes ? `${(Number(d.size_bytes)/1024).toFixed(1)} KB` : '-'}</td><td>${esc(date(d.created_at || d.uploaded_at))}</td></tr>`).join('');
        return `<div class="loan-info-card"><div class="fw-bold mb-3">Documents</div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>Document</th><th>Type</th><th>Mime</th><th>Size</th><th>Uploaded</th></tr></thead><tbody>${rows || '<tr><td colspan="5" class="text-muted">No documents linked to this loan.</td></tr>'}</tbody></table></div><div class="small text-muted mt-2">Document storage/download routes are not exposed by the current loan controller, so this view does not invent a download URL.</div></div>`;
    }

    function renderAuditTab(loan) {
        const audits = (loan.audit_logs || []).slice().sort((a,b) => String(b.created_at||'').localeCompare(String(a.created_at||'')));
        const changes = (loan.change_requests || []).slice().sort((a,b) => Number(b.id||0)-Number(a.id||0));
        const auditRows = audits.map((a) => `<tr><td>${esc(date(a.created_at))}</td><td>${esc(a.action || '-')}</td><td>${esc(a.actor_name || '-')}</td><td>${esc(a.actor_role || '-')}</td><td>${esc(a.summary || '-')}</td></tr>`).join('');
        const changeRows = changes.map((c) => `<tr><td>${esc(c.change_type || '-')}</td><td>${statusBadge(c.status)}</td><td>${esc(c.effective_date ? date(c.effective_date) : '-')}</td><td>${esc(c.remarks || '-')}</td></tr>`).join('');
        return `<div class="row g-3"><div class="col-12"><div class="loan-info-card"><div class="fw-bold mb-3">Audit Trail</div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>Time</th><th>Action</th><th>Actor</th><th>Role</th><th>Summary</th></tr></thead><tbody>${auditRows || '<tr><td colspan="5" class="text-muted">No audit entries found.</td></tr>'}</tbody></table></div></div></div><div class="col-12"><div class="loan-info-card"><div class="fw-bold mb-3">Change Requests</div><div class="loan-view-scroll"><table class="loan-view-table"><thead><tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary"><th>Type</th><th>Status</th><th>Effective</th><th>Remarks</th></tr></thead><tbody>${changeRows || '<tr><td colspan="4" class="text-muted">No change requests found.</td></tr>'}</tbody></table></div></div></div></div>`;
    }

    function openView(id, tab = 'overview') {
        $('#loanViewBody').html(loanDetailSkeleton());
        $('#loanViewActions').empty();
        viewModal()?.show();
        $.ajax({url:url(routes.show,id),type:'GET',dataType:'json',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}})
            .done((response) => {
                const raw = response?.data?.loan_raw || response?.data?.loan;
                if (!raw) throw new Error('Loan details were not returned.');
                const combined = {...raw};
                if (response?.data?.schedule_versions?.length && !combined.schedules?.length) combined.schedules = response.data.schedule_versions;
                renderLoanView(combined, tab);
            })
            .fail((xhr) => {
                $('#loanViewBody').html('<div class="loan-empty-block text-danger">Unable to load this loan.</div>');
                handleError(xhr, 'Unable to load loan details.');
            });
    }

    function refreshView() {
        if (state.viewLoan?.id) openView(state.viewLoan.id, state.viewTab || 'overview');
    }

    function openPayment(id) {
        const loan = state.viewLoan?.id == id ? state.viewLoan : null;
        $('#loanPaymentForm')[0]?.reset();
        $('#loanPaymentAlert').addClass('d-none').empty();
        $('#loanPaymentDate').val(new Date().toISOString().slice(0,10));
        $('#loanPaymentSubtitle').text(loan ? `${loan.account_no || ''} · Outstanding ${money(loan.outstanding_amount)}` : `Loan #${id}`);
        const next = (loan?.obligations || []).filter((o) => !['paid','superseded','waived'].includes(o.status)).sort((a,b) => String(a.due_date).localeCompare(String(b.due_date)))[0];
        $('#loanPaymentAmount').val(next?.balance_amount ? Number(next.balance_amount).toFixed(2) : '');
        $('#loanPaymentForm').data('loan-id', id).data('obligation-id', next?.id || '');
        if (window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
        paymentModal()?.show();
    }

    function actionShell(title, subtitle, body, mode = 'direct', button = 'Save') {
        state.actionMode = mode;
        $('#loanActionTitle').text(title);
        $('#loanActionSubtitle').text(subtitle || '');
        $('#loanActionBody').html(body);
        $('#loanActionSubmitBtn').text(button).data('action-mode', mode);
        if (window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
        if ($.fn.datepicker) $('#loanActionModal .common_datepicker_cust').datepicker({todayHighlight:true,autoclose:true,format:'dd-M-yyyy'});
        actionModal()?.show();
    }

    function openAction(type, id) {
        state.actionType = type;
        state.actionLoanId = id;
        const loan = state.viewLoan || {};
        if (type === 'prepay') {
            return actionShell('Part Prepayment', `${loan.account_no || ''} · Current outstanding ${money(loan.outstanding_amount)}`, `
                <div class="alert alert-light border"><i class="mdi mdi-information-outline me-1"></i>Preview the revised EMI/tenure before submitting the change for Finance approval.</div>
                <div class="row g-3"><div class="col-md-4"><label class="loan-label">Prepay Amount <span class="text-danger">*</span></label><input type="number" step="0.01" min="0.01" class="form-control loan-input" name="amount" required></div><div class="col-md-4"><label class="loan-label">Effective Date <span class="text-danger">*</span></label><input type="text" class="form-control loan-input common_datepicker_cust" name="effective_date" value="${esc(new Date().toISOString().slice(0,10))}" required></div><div class="col-md-4"><label class="loan-label">Mode <span class="text-danger">*</span></label><select class="form-select loan-select select3" name="mode" required><option value="reduce_emi">Reduce EMI</option><option value="reduce_tenure">Reduce Tenure</option></select></div><div class="col-12"><label class="loan-label">Reason <span class="text-danger">*</span></label><textarea class="form-control loan-input" name="reason" rows="3" maxlength="1000" required></textarea></div></div><div id="loanActionPreview" class="mt-3"></div>`, 'preview', 'Calculate Preview');
        }
        if (type === 'restructure') {
            return actionShell('Restructure Loan', `${loan.account_no || ''} · Current rate ${loan.interest_rate || 0}%`, `
                <div class="alert alert-light border"><i class="mdi mdi-information-outline me-1"></i>Preview the new EMI and total interest before submitting the restructure for approval.</div>
                <div class="row g-3"><div class="col-md-4"><label class="loan-label">New Rate % <span class="text-danger">*</span></label><input type="number" step="0.0001" min="0" max="100" class="form-control loan-input" name="new_rate" value="${esc(loan.interest_rate || '')}" required></div><div class="col-md-4"><label class="loan-label">New Months <span class="text-danger">*</span></label><input type="number" min="1" max="360" class="form-control loan-input" name="new_months" value="${esc(loan.tenure_months || '')}" required></div><div class="col-md-4"><label class="loan-label">Effective Date <span class="text-danger">*</span></label><input type="text" class="form-control loan-input common_datepicker_cust" name="effective_date" value="${esc(new Date().toISOString().slice(0,10))}" required></div><div class="col-12"><label class="loan-label">Reason <span class="text-danger">*</span></label><textarea class="form-control loan-input" name="reason" rows="3" maxlength="1000" required></textarea></div></div><div id="loanActionPreview" class="mt-3"></div>`, 'preview', 'Calculate Preview');
        }
        if (type === 'close') {
            return actionShell('Close / Foreclose Loan', `${loan.account_no || ''} · This action supersedes pending obligations.`, `
                <div class="alert alert-warning"><i class="mdi mdi-alert-outline me-1"></i>NOC and security release are required before the backend will close the loan.</div>
                <div class="row g-3"><div class="col-md-5"><label class="loan-label">Closure Type <span class="text-danger">*</span></label><select class="form-select loan-select select3" name="closure_type" required><option value="closed">Closed</option><option value="foreclosed">Foreclosed</option></select></div><div class="col-md-6"><label class="loan-label">Remarks</label><input type="text" class="form-control loan-input" name="remarks" maxlength="1000"></div><div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" name="noc_received" value="1" id="loanCloseNoc"><label class="form-check-label fw-semibold" for="loanCloseNoc">NOC received</label></div><div class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" name="security_released" value="1" id="loanCloseSecurity"><label class="form-check-label fw-semibold" for="loanCloseSecurity">Security released</label></div></div></div>`, 'direct', 'Close Loan');
        }
        if (type === 'renewal') {
            const c = loan.cc_facility || {};
            return actionShell('CC Renewal', `${loan.account_no || ''} · Existing renewal ${date(c.renewal_date)}`, `<div class="row g-3"><div class="col-md-4"><label class="loan-label">Renewal Date <span class="text-danger">*</span></label><input type="text" class="form-control loan-input common_datepicker_cust" name="renewal_date" value="${esc(c.renewal_date ? String(c.renewal_date).slice(0,10) : '')}" required></div><div class="col-md-4"><label class="loan-label">Sanctioned Limit</label><input type="number" step="0.01" min="0" class="form-control loan-input" name="limit" value="${esc(c.sanctioned_limit || '')}"></div><div class="col-md-4"><label class="loan-label">Interest Rate %</label><input type="number" step="0.0001" min="0" max="100" class="form-control loan-input" name="rate" value="${esc(c.interest_rate || loan.interest_rate || '')}"></div></div>`, 'direct', 'Save Renewal');
        }
        if (type === 'utilisation') {
            const c = loan.cc_facility || {}; const u = c.utilisations?.[0] || {};
            return actionShell('CC Utilisation', `${loan.account_no || ''} · Latest utilisation ${money(u.utilised_amount || 0)}`, `<div class="row g-3"><div class="col-md-3"><label class="loan-label">As of Date <span class="text-danger">*</span></label><input type="text" class="form-control loan-input common_datepicker_cust" name="as_of_date" value="${esc(u.as_of_date ? String(u.as_of_date).slice(0,10) : new Date().toISOString().slice(0,10))}" required></div><div class="col-md-3"><label class="loan-label">Utilised Amount <span class="text-danger">*</span></label><input type="number" step="0.01" min="0" class="form-control loan-input" name="utilised_amount" value="${esc(u.utilised_amount || '')}" required></div><div class="col-md-3"><label class="loan-label">Interest Debit</label><input type="number" step="0.01" min="0" class="form-control loan-input" name="interest_debit" value="${esc(u.interest_debit || '')}"></div><div class="col-md-3"><label class="loan-label">Drawing Power</label><input type="number" step="0.01" min="0" class="form-control loan-input" name="drawing_power" value="${esc(u.drawing_power || c.drawing_power || '')}"></div><div class="col-12"><label class="loan-label">Remarks</label><textarea class="form-control loan-input" name="remarks" rows="2" maxlength="500">${esc(u.remarks || '')}</textarea></div></div>`, 'direct', 'Save Utilisation');
        }
    }

    function renderPreview(data, type) {
        if (!data) return;
        const current = data.current || data;
        const next = data.new || data;
        const extra = type === 'prepay'
            ? `<div class="col-6 col-lg-3">${infoCard('Prepay', money(data.prepay_amount))}</div><div class="col-6 col-lg-3">${infoCard('Interest Saving', money(data.interest_saved_preview))}</div>`
            : `<div class="col-6 col-lg-3">${infoCard('Rate', `${esc($('#loanActionForm [name="new_rate"]').val() || '')}%`)}</div>`;
        $('#loanActionPreview').html(`<div class="border rounded-3 p-3 bg-light"><div class="fw-bold mb-3">Preview</div><div class="row g-3"><div class="col-6 col-lg-3">${infoCard('Current EMI', money(current.current_emi ?? current.emi))}</div><div class="col-6 col-lg-3">${infoCard('New EMI', money(next.new_emi ?? next.emi))}</div><div class="col-6 col-lg-3">${infoCard('Current Installments', esc(current.current_installments ?? current.installments))}</div><div class="col-6 col-lg-3">${infoCard('New Installments', esc(next.new_installments ?? next.installments))}</div>${extra}<div class="col-6 col-lg-3">${infoCard('New End Date', esc(date(data.new_end_date || next.end_date)))}</div>${type === 'restructure' ? `<div class="col-6 col-lg-3">${infoCard('Current Interest', money(current.interest))}</div><div class="col-6 col-lg-3">${infoCard('New Interest', money(next.interest))}</div>` : ''}</div></div>`);
    }

    function submitAction(event) {
        event.preventDefault();
        const type = state.actionType, id = state.actionLoanId;
        const form = document.getElementById('loanActionForm');
        const data = Object.fromEntries(new FormData(form).entries());
        const mode = $('#loanActionSubmitBtn').data('action-mode') || state.actionMode;
        let target = null, direct = true;
        if (type === 'prepay') { target = mode === 'preview' ? url(routes.prepayPreview,id) : url(routes.prepay,id); direct = false; }
        if (type === 'restructure') { target = mode === 'preview' ? url(routes.restructurePreview,id) : url(routes.restructure,id); direct = false; }
        if (type === 'close') target = url(routes.close,id);
        if (type === 'renewal') target = url(routes.renewal,id);
        if (type === 'utilisation') target = url(routes.utilisation,id);
        if (!target) return;
        if (type === 'close') { data.noc_received = $('#loanCloseNoc').is(':checked') ? 1 : 0; data.security_released = $('#loanCloseSecurity').is(':checked') ? 1 : 0; }
        const $btn = $('#loanActionSubmitBtn'); $btn.prop('disabled',true).prepend('<span class="spinner-border spinner-border-sm me-1"></span>');
        ajaxPost(target,data).done((response) => {
            if (mode === 'preview') {
                renderPreview(response?.data || {}, type);
                $btn.text(type === 'prepay' ? 'Submit Prepayment' : 'Submit Restructure').data('action-mode','submit');
                state.actionMode = 'submit';
                toast('Preview calculated. Review it and submit for approval.', 'info');
                return;
            }
            toast(response?.message || 'Action completed successfully.','success');
            actionModal()?.hide();
            if (window.LoanScheduleReload) window.LoanScheduleReload();
            refreshView();
        }).fail((xhr) => handleError(xhr,'Unable to complete the loan action.')).always(() => { $btn.prop('disabled',false).find('.spinner-border').remove(); });
    }

    function submitPayment(event) {
        event.preventDefault();
        const id = $('#loanPaymentForm').data('loan-id');
        const obligationId = $('#loanPaymentForm').data('obligation-id');
        const form = document.getElementById('loanPaymentForm');
        const data = Object.fromEntries(new FormData(form).entries());
        if (obligationId) data.obligation_id = obligationId;
        const $btn = $('#loanSavePaymentBtn');
        $btn.prop('disabled',true).prepend('<span class="spinner-border spinner-border-sm me-1"></span>');
        ajaxPost(url(routes.payment,id),data).done((response) => {
            toast(response?.message || 'Payment recorded successfully.','success');
            paymentModal()?.hide();
            if (window.LoanScheduleReload) window.LoanScheduleReload();
            refreshView();
        }).fail((xhr) => handleError(xhr,'Unable to record the payment.')).always(() => { $btn.prop('disabled',false).find('.spinner-border').remove(); });
    }

    function approveSpecific(id, kind) {
        const target = kind === 'prepay' ? url(routes.approvePrepay,id) : url(routes.approveRestructure,id);
        ajaxPost(target,{}).done((response) => { toast(response?.message || 'Change approved.','success'); if(window.LoanScheduleReload) window.LoanScheduleReload(); openView(id,state.viewTab||'overview'); }).fail((xhr)=>handleError(xhr,'Unable to approve the change.'));
    }

    function approveLoanDirect(id) {
        ajaxPost(url(routes.approve,id),{}).done((response)=>{toast(response?.message || 'Loan approved successfully.','success');if(window.LoanScheduleReload)window.LoanScheduleReload();openView(id,state.viewTab||'overview');}).fail((xhr)=>handleError(xhr,'Unable to approve the loan.'));
    }

    function openReturnFromView(id) {
const $btn = $(document).find(`[data-loan-return="${CSS.escape(String(id))}"]`).first();
        if ($btn.length) { $btn.trigger('click'); return; }
        $('#loanReturnId').val(id); $('#loanReturnRemarks').val(''); $('#loanReturnError').text(''); modal('#loanReturnModal')?.show();
    }

    function snooze(obligationId, days) {
        const d = new Date(); d.setDate(d.getDate() + Number(days || 1));
        const y = d.getFullYear(), m = String(d.getMonth()+1).padStart(2,'0'), day=String(d.getDate()).padStart(2,'0');
        ajaxPost(url(routes.snooze, obligationId), {snoozed_until:`${y}-${m}-${day} 18:00:00`}).done((response)=>{toast(response?.message || 'Reminder snoozed.','success'); if(window.LoanScheduleReload) window.LoanScheduleReload(); refreshView();}).fail((xhr)=>handleError(xhr,'Unable to snooze the reminder.'));
    }

    function setLenderForm(row) {
        $('#loanLenderMasterId').val(row?.id || '');
        $('#loanLenderName').val(row?.lender_name || '');
        $('#loanLenderType').val(row?.lender_type || '');
        $('#loanLenderBranch').val(row?.branch_name || '');
        $('#loanLenderContact').val(row?.contact_person || '');
        $('#loanLenderPhone').val(row?.phone || '');
        $('#loanLenderEmail').val(row?.email || '');
        $('#loanLenderAddress').val(row?.address || '');
        // $('#loanLenderStatus').val(String(row?.status ?? 1));
        $('#loanLenderFormTitle').text(row?.id ? 'Update Lender' : 'Add Lender');
        $('#loanLenderFormPanel').removeClass('d-none');
        if (window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
    }

    function resetLenderForm() {
        document.getElementById('loanLenderForm')?.reset();
        $('#loanLenderMasterId').val('');
        //  $('#loanLenderStatus').val('1');
        $('[data-lender-error]').text(''); $('#loanLenderFormAlert').addClass('d-none').empty();
    }

    function skeletonBlock(width = '100%', height = 12, extra = '') {
        return `<span class="loan-skeleton ${extra}" style="width:${width};height:${height}px"></span>`;
    }

    function loanTableSkeletonRows(count = 6) {
        let html = '';
        for (let i = 0; i < count; i++) {
            html += `<tr class="loan-skeleton-row">
                <td>${skeletonBlock('46px', 11)}</td>
                <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:92px;height:12px"></span><span class="loan-skeleton" style="width:130px;height:8px"></span></div></td>
                <td>${skeletonBlock('92px', 22, 'loan-skeleton-pill')}</td>
                <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:115px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                <td>${skeletonBlock('110px', 14)}</td>
                <td>${skeletonBlock('86px', 30, 'loan-skeleton-pill')}</td>
                <td>${skeletonBlock('95px', 18)}</td>
                <td>${skeletonBlock('78px', 22, 'loan-skeleton-pill')}</td>
                <td>${skeletonBlock('74px', 22, 'loan-skeleton-pill')}</td>
                <td>${skeletonBlock('105px', 32, 'loan-skeleton-actions')}</td>
            </tr>`;
        }
        return html;
    }

    function lenderTableSkeletonRows(count = 5) {
        let html = '';
        for (let i = 0; i < count; i++) {
            html += `<tr class="loan-skeleton-row">
                <td class="ps-3"><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:118px;height:12px"></span><span class="loan-skeleton" style="width:78px;height:8px"></span></div></td>
                <td>${skeletonBlock('78px', 20, 'loan-skeleton-pill')}</td>
                <td><div class="loan-skeleton-group"><span class="loan-skeleton" style="width:94px;height:11px"></span><span class="loan-skeleton" style="width:72px;height:8px"></span></div></td>
                <td>${skeletonBlock('28px', 22, 'loan-skeleton-pill')}</td>
                <td>${skeletonBlock('70px', 20, 'loan-skeleton-pill')}</td>
                <td>${skeletonBlock('114px', 30, 'loan-skeleton-actions')}</td>
            </tr>`;
        }
        return html;
    }

    function loanDetailSkeleton() {
        return `<div class="loan-loading loan-view-skeleton">
            <div class="loan-skeleton loan-skeleton-line loan-skeleton-line-lg"></div>
            <div class="loan-skeleton loan-skeleton-line loan-skeleton-line-md mt-3"></div>
            <div class="row g-3 mt-2">
                <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
                <div class="col-6"><div class="loan-skeleton loan-skeleton-card"></div></div>
            </div>
        </div>`;
    }

    function lenderStatus(status) { return Number(status) === 0 ? '<span class="badge rounded-pill bg-success-subtle text-success">Active</span>' : '<span class="badge rounded-pill bg-secondary-subtle text-secondary">Inactive</span>'; }

    function loadLenders(page = 1) {
        state.lenderPage = page;
        $('#loanLenderTableBody').html(lenderTableSkeletonRows(5));
        $.ajax({url:routes.lenders,type:'GET',data:{page,per_page:state.lenderPerPage,search:state.lenderSearch,status:state.lenderStatus},dataType:'json',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}})
        .done((response)=>{
            const items=response?.data||[]; state.lenderRows={}; items.forEach((row)=>state.lenderRows[row.id]=row);
            if (!items.length) { $('#loanLenderTableBody').html('<tr><td colspan="6"><div class="loan-empty-block"><i class="mdi mdi-account-cash-outline fs-2"></i><div class="fw-bold mt-2">No lenders found</div><div class="small mt-1">Add a lender or change the filters.</div></div></td></tr>'); }
            else $('#loanLenderTableBody').html(items.map((row)=>`<tr><td class="ps-3"><div class="fw-bold">${esc(row.lender_name||'-')}</div><div class="small text-muted">${esc(row.branch_name||'-')}</div></td><td>${esc(row.lender_type||'-')}</td><td><div>${esc(row.contact_person||'-')}</div><div class="small text-muted">${esc(row.phone||row.email||'-')}</div></td><td><span class="badge bg-light text-dark border">${esc(row.loans_count||0)}</span></td><td>${lenderStatus(row.status)}</td><td class="text-center pe-3"><div class="d-flex justify-content-center align-items-center gap-1"><button type="button" class="btn btn-sm btn-white fw-bold text-black shadow-none" data-lender-edit="${esc(row.id)}" title="Edit"><i class="mdi mdi-pencil-outline"></i></button><div class="form-check form-switch mb-0"><input class="form-check-input loan-toggle" type="checkbox" ${Number(row.status)===0?'checked':''} data-lender-toggle="${esc(row.id)}" title="Toggle status"></div><button type="button" class="btn btn-sm btn-white fw-bold text-danger shadow-none " data-lender-delete="${esc(row.id)}" title="Delete"><i class="mdi mdi-delete-outline"></i></button></div></td></tr>`).join(''));
            renderLenderPagination(response?.pagination||{});
        }).fail((xhr)=>handleError(xhr,'Unable to load lender master.'));
    }

    function renderLenderPagination(meta) {
        const current=Number(meta.current_page||1), last=Number(meta.last_page||1), total=Number(meta.total||0), per=Number(meta.per_page||state.lenderPerPage);
        const from=total?((current-1)*per)+1:0, to=total?Math.min(current*per,total):0;
        $('#loanLenderPaginationMeta').text(total?`Showing ${from} to ${to} of ${total} lenders`:'No lenders');
        if(last<=1){$('#loanLenderPagination').empty();return;}
        let html=`<li class="page-item ${current<=1?'disabled':''}"><button type="button" class="page-link" data-lender-page="${Math.max(1,current-1)}">‹</button></li>`;
        const start=Math.max(1,current-2), end=Math.min(last,current+2);
        for(let i=start;i<=end;i++) html+=`<li class="page-item ${i===current?'active':''}"><button type="button" class="page-link" data-lender-page="${i}">${i}</button></li>`;
        html+=`<li class="page-item ${current>=last?'disabled':''}"><button type="button" class="page-link" data-lender-page="${Math.min(last,current+1)}">›</button></li>`;
        $('#loanLenderPagination').html(html);
    }

    function refreshLenderLookups() {
        $.ajax({url:routes.lookups,type:'GET',dataType:'json',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}}).done((response)=>{
            const lenders=response?.data?.lenders||[];
            const currentFilter=state.lenderFilterValue || $('#loanLenderFilter').val() || '';
            const currentForm=$('#loanLenderId').val() || '';
            let filter='<option value="">All Lenders</option>', form='<option value="">Select Lender</option>';
            lenders.forEach((row)=>{const label=row.lender_name+(row.branch_name?' — '+row.branch_name:''); filter+=`<option value="${esc(row.id)}">${esc(label)}</option>`; form+=`<option value="${esc(row.id)}">${esc(label)}</option>`;});
            $('#loanLenderFilter').html(filter).val(currentFilter);
            $('#loanLenderId').html(form).val(currentForm);
            if(window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
        });
    }

    function openLenderManager() {
        resetLenderForm(); $('#loanLenderFormPanel').addClass('d-none'); lenderModal()?.show(); if(window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3(); loadLenders(1);
    }

    function confirmAction(title, message, callback) {
        state.confirmCallback = callback;
        $('#loanConfirmTitle').text(title); $('#loanConfirmMessage').text(message); confirmModal()?.show();
    }

    function submitLenderForm(event) {
        event.preventDefault();
        const id=$('#loanLenderMasterId').val(); const target=id?url(routes.lenderUpdate,id):routes.lenderStore; const method=id?'PUT':'POST';
        const data=Object.fromEntries(new FormData(document.getElementById('loanLenderForm')).entries());
        const $btn=$('#loanSaveLenderBtn'); $btn.prop('disabled',true).find('.loan-save-text').addClass('d-none'); $btn.find('.loan-save-loading').removeClass('d-none'); $('[data-lender-error]').text('');
        ajaxPost(target,data,method).done((response)=>{toast(response?.message||'Lender saved.','success'); resetLenderForm(); $('#loanLenderFormPanel').addClass('d-none'); loadLenders(state.lenderPage); refreshLenderLookups();}).fail((xhr)=>{const payload=handleError(xhr,'Unable to save lender.'); Object.keys(payload?.errors||{}).forEach((field)=>{$(`[data-lender-error="${CSS.escape(field)}"]`).text(Array.isArray(payload.errors[field])?payload.errors[field][0]:payload.errors[field]);});}).always(()=>{$btn.prop('disabled',false).find('.loan-save-text').removeClass('d-none'); $btn.find('.loan-save-loading').addClass('d-none');});
    }

    function toggleLender(id, checkbox) {
        checkbox.disabled=true;
        ajaxPost(url(routes.lenderToggle,id),{},'PATCH').done((response)=>{toast(response?.message||'Lender status updated.','success');loadLenders(state.lenderPage);refreshLenderLookups();}).fail((xhr)=>{checkbox.checked=!checkbox.checked;handleError(xhr,'Unable to change lender status.');}).always(()=>{checkbox.disabled=false;});
    }

    function deleteLender(id) {
        const row=state.lenderRows[id];
        confirmAction('Delete Lender',`Delete ${row?.lender_name || 'this lender'}? Linked lenders are protected and should be deactivated instead.`,function(){
            ajaxPost(url(routes.lenderDelete,id),{},'DELETE').done((response)=>{toast(response?.message||'Lender deleted.','success');loadLenders(state.lenderPage);refreshLenderLookups();}).fail((xhr)=>handleError(xhr,'Unable to delete lender.'));
        });
    }

    $(document).on('click','[data-loan-view]',function(){openView($(this).data('loan-view'),'overview');});
    $(document).on('click','[data-loan-view-tab]',function(){ if(state.viewLoan) renderLoanView(state.viewLoan,$(this).data('loan-view-tab')); });
    $(document).on('click','[data-view-payment]',function(){openPayment($(this).data('view-payment'));});
    $(document).on('click','[data-view-action]',function(){openAction($(this).data('view-action'),$(this).data('view-action-id'));});
    $(document).on('click','[data-view-approve-prepay]',function(){approveSpecific($(this).data('view-approve-prepay'),'prepay');});
    $(document).on('click','[data-view-approve-restructure]',function(){approveSpecific($(this).data('view-approve-restructure'),'restructure');});
    $(document).on('click','[data-view-approve-loan]',function(){ approveLoanDirect($(this).data('view-approve-loan')); });
    $(document).on('click','[data-view-return-loan]',function(){openReturnFromView($(this).data('view-return-loan'));});
    $(document).on('click','[data-view-snooze]',function(){snooze($(this).data('view-snooze'),$(this).data('days'));});
    $('#loanActionForm').on('submit',submitAction);
    $('#loanPaymentForm').on('submit',submitPayment);

    $('#loanManageLendersBtn').on('click',openLenderManager);
    $('#loanAddLenderBtn').on('click',function(){resetLenderForm();setLenderForm(null);});
    $('#loanCancelLenderBtn').on('click',function(){$('#loanLenderFormPanel').addClass('d-none');resetLenderForm();});
    $('#loanLenderForm').on('submit',submitLenderForm);
    $(document).on('click','[data-lender-edit]',function(){setLenderForm(state.lenderRows[$(this).data('lender-edit')]);});
    $(document).on('change','[data-lender-toggle]',function(){toggleLender($(this).data('lender-toggle'),this);});
    $(document).on('click','[data-lender-delete]',function(){deleteLender($(this).data('lender-delete'));});
    $(document).on('click','[data-lender-page]',function(){const p=Number($(this).data('lender-page')); if(p>0) loadLenders(p);});
    // Delegated handlers survive Select3/Select2 rebuilds inside the lender modal.
    $(document).off('change.loanLenderManager', '#loanLenderListStatus').on('change.loanLenderManager', '#loanLenderListStatus', function(){
        state.lenderStatus = $(this).val() || '';
        loadLenders(1);
    });
    $(document).off('change.loanLenderManager', '#loanLenderPerPage').on('change.loanLenderManager', '#loanLenderPerPage', function(){
        state.lenderPerPage = Number($(this).val()) || 25;
        loadLenders(1);
    });
    $(document).off('click.loanLenderManager', '#loanResetLenderFilter').on('click.loanLenderManager', '#loanResetLenderFilter', function(){
        state.lenderSearch = '';
        state.lenderStatus = '';
        $('#loanLenderSearch').val('');
        $('#loanLenderListStatus').val('').trigger('change');
        if(window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
    });
    let lenderTimer=null;
    $(document).off('input.loanLenderManager', '#loanLenderSearch').on('input.loanLenderManager', '#loanLenderSearch', function(){clearTimeout(lenderTimer);state.lenderSearch=$.trim($(this).val());lenderTimer=setTimeout(()=>loadLenders(1),300);});
    $('#loanConfirmBtn').on('click',function(){const cb=state.confirmCallback;state.confirmCallback=null;confirmModal()?.hide();if(typeof cb==='function') cb();});

    // Keep select3 behaviour consistent for dynamically-created action controls.
    $(function(){
        if(window.LoanScheduleInitSelect3) window.LoanScheduleInitSelect3();
        $('.common_datepicker_cust').datepicker?.({todayHighlight:true,autoclose:true,format:'dd-M-yyyy'});
    });
})(window.jQuery);
</script>

@endsection
