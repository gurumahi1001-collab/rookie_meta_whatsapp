@extends('layouts.layoutMaster')

@section('title', 'Loan Schedule Calendar')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
<style>
    :root {
        --loan-red: #b52b22;
        --loan-red-dark: #8f211b;
        --loan-gold: #f6b51d;
        --loan-green: #16803b;
        --loan-blue: #2e5fa3;
        --loan-amber: #b7791f;
        --loan-page: #f5f6f8;
        --loan-border: #e2e5ea;
        --loan-text: #1f2937;
        --loan-muted: #6b7280;
    }

    .loan-calendar-page {
        color: var(--loan-text);
    }

    .loan-card {
        background: #fff;
        border: 1px solid var(--loan-border);
        border-radius: 14px;
        box-shadow: 0 4px 18px rgba(31, 41, 55, .04);
    }

    .loan-title {
        color: var(--loan-red);
        font-weight: 700;
    }

    .loan-subtitle {
        color: var(--loan-muted);
        font-size: 13px;
    }

    .loan-primary-btn {
        background: var(--loan-red);
        color: #fff;
        border-color: var(--loan-red);
        font-weight: 700;
    }

    .loan-primary-btn:hover {
        background: var(--loan-red-dark);
        border-color: var(--loan-red-dark);
        color: #fff;
    }

    .loan-outline-btn {
        background: #fff;
        color: #4b5563;
        border: 1px solid #d7dbe1;
        font-weight: 600;
    }

    .loan-outline-btn:hover {
        border-color: #c8cdd4;
        color: var(--loan-red);
        background: #fafafa;
    }

    .calendar-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
    }

    .calendar-nav {
        display: flex;
        align-items: center;
        gap: 7px;
    }

    .calendar-month-title {
        min-width: 210px;
        text-align: center;
        font-weight: 800;
        color: #1f3864;
        font-size: 18px;
    }

    .calendar-view-toggle {
        display: inline-flex;
        overflow: hidden;
        border: 1px solid #d9dde4;
        border-radius: 9px;
        background: #fff;
    }

    .calendar-view-toggle button {
        border: 0;
        border-right: 1px solid #e7e9ec;
        background: #fff;
        color: #5e6671;
        padding: 8px 15px;
        font-size: 12px;
        font-weight: 700;
    }

    .calendar-view-toggle button:last-child {
        border-right: 0;
    }

    .calendar-view-toggle button.active {
        background: var(--loan-red);
        color: #fff;
    }

    .calendar-filter {
        padding: 12px;
    }

    .calendar-filter .form-select,
    .calendar-filter .form-control {
        min-height: 40px;
        border-radius: 9px;
        font-size: 13px;
    }

    .calendar-stat {
        padding: 13px;
        border-radius: 12px;
        border: 1px solid #e9ebee;
        background: #fff;
    }

    .calendar-stat .label {
        color: #737a84;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .35px;
    }

    .calendar-stat .value {
        font-size: 22px;
        font-weight: 800;
        color: #1f3864;
        line-height: 1.15;
        margin-top: 4px;
    }

    .calendar-grid-wrap {
        overflow-x: auto;
    }

    .calendar-month-grid {
        min-width: 950px;
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border-top: 1px solid var(--loan-border);
        border-left: 1px solid var(--loan-border);
    }

    .calendar-weekday {
        background: var(--loan-red);
        color: #fff;
        text-align: center;
        padding: 10px 6px;
        font-size: 11px;
        font-weight: 800;
        border-right: 1px solid rgba(255,255,255,.18);
    }

    .calendar-day {
        min-height: 145px;
        padding: 8px;
        background: #fff;
        border-right: 1px solid var(--loan-border);
        border-bottom: 1px solid var(--loan-border);
        position: relative;
    }

    .calendar-day.other-month {
        background: #f9fafb;
        color: #adb4be;
    }

    .calendar-day.today {
        background: #fffdf6;
        box-shadow: inset 0 3px 0 var(--loan-gold);
    }

    .calendar-day-number {
        width: 28px;
        height: 28px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 12px;
        font-weight: 800;
        color: #555d68;
        margin-bottom: 5px;
    }

    .calendar-day.today .calendar-day-number {
        background: var(--loan-red);
        color: #fff;
    }

    .calendar-event {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        width: 100%;
        border: 0;
        text-align: left;
        border-radius: 7px;
        padding: 6px 7px;
        margin-bottom: 5px;
        font-size: 10px;
        line-height: 1.25;
        font-weight: 700;
        cursor: pointer;
        overflow: hidden;
    }

    .calendar-event:hover {
        filter: brightness(.97);
        transform: translateY(-1px);
    }

    .calendar-event .event-icon {
        flex: 0 0 auto;
        font-size: 12px;
    }

    .calendar-event .event-content {
        min-width: 0;
        flex: 1;
    }

    .calendar-event .event-title,
    .calendar-event .event-meta {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .event-upcoming {
        background: #eaf1f9;
        color: #245786;
    }

    .event-today {
        background: #fff2d9;
        color: #8b5c00;
    }

    .event-overdue {
        background: #fdeaea;
        color: #a72720;
    }

    .event-paid {
        background: #e9f7ee;
        color: #16803b;
    }

    .event-snoozed {
        background: #f0edfa;
        color: #6552a8;
    }

    .event-more {
        border: 0;
        background: transparent;
        color: var(--loan-red);
        font-size: 11px;
        font-weight: 800;
        padding: 2px 4px;
    }

    .calendar-week-grid {
        min-width: 950px;
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border-top: 1px solid var(--loan-border);
        border-left: 1px solid var(--loan-border);
    }

    .calendar-week-column {
        min-height: 550px;
        background: #fff;
        border-right: 1px solid var(--loan-border);
        border-bottom: 1px solid var(--loan-border);
        padding: 8px;
    }

    .calendar-week-head {
        padding: 8px;
        margin: -8px -8px 8px;
        border-bottom: 1px solid #edf0f2;
        font-size: 12px;
        font-weight: 800;
    }

    .calendar-agenda-wrap {
        overflow-x: auto;
    }

    .calendar-agenda-table {
        min-width: 1050px;
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
    }

    .calendar-agenda-table thead th {
        background: var(--loan-red);
        color: #fff;
        padding: 11px 12px;
        font-size: 11px;
        font-weight: 800;
        white-space: nowrap;
    }

    .calendar-agenda-table tbody td {
        padding: 11px 12px;
        border-bottom: 1px solid #eef0f2;
        vertical-align: middle;
        font-size: 12px;
    }

    .calendar-agenda-table tbody tr:nth-child(even) {
        background: #fbfbfc;
    }

    .calendar-agenda-table tbody tr:hover {
        background: #fff9eb;
    }

    .agenda-date {
        font-weight: 800;
        color: #1f3864;
    }

    .agenda-type {
        display: inline-flex;
        gap: 5px;
        align-items: center;
        border-radius: 7px;
        padding: 5px 8px;
        background: #fff4d6;
        color: #805c00;
        font-size: 10px;
        font-weight: 800;
    }

    .calendar-loading,
    .calendar-empty {
        min-height: 260px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: #79818d;
        text-align: center;
    }

    .calendar-skeleton {
        position: relative;
        overflow: hidden;
        display: block;
        background: #edf0f3;
        border-radius: 8px;
    }

    .calendar-skeleton::after {
        content: '';
        position: absolute;
        inset: 0;
        transform: translateX(-100%);
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.72), transparent);
        animation: calendarSkeletonShimmer 1.35s ease-in-out infinite;
    }

    @keyframes calendarSkeletonShimmer {
        100% { transform: translateX(100%); }
    }

    .calendar-skeleton-grid {
        width: 100%;
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        gap: 1px;
        background: #e4e8ec;
        border: 1px solid #e4e8ec;
        min-height: 500px;
    }

    .calendar-skeleton-head { min-height: 42px; border-radius: 0; }
    .calendar-skeleton-cell { min-height: 118px; border-radius: 0; padding: 12px; background: #f5f7f9; }
    .calendar-skeleton-cell span,
    .calendar-skeleton-cell i { display:block; background:#e4e8ec; border-radius:6px; height:10px; margin-bottom:9px; }
    .calendar-skeleton-cell span { width:28px; height:24px; border-radius:50%; }
    .calendar-skeleton-cell i:nth-of-type(1) { width:78%; }
    .calendar-skeleton-cell i:nth-of-type(2) { width:56%; }
    .calendar-skeleton-toolbar { display:flex; justify-content:space-between; gap:10px; align-items:center; width:100%; }
    .calendar-skeleton-title { width:220px; height:18px; }
    .calendar-skeleton-button { width:84px; height:36px; border-radius:9px; }

    .calendar-list-skeleton { width:100%; align-items:stretch; justify-content:flex-start; padding:0; min-height:420px; }
    .calendar-skeleton-row { display:grid; grid-template-columns:repeat(8,minmax(70px,1fr)); gap:12px; align-items:center; width:100%; padding:13px 14px; background:#fff; border-bottom:1px solid #edf0f2; }
    .calendar-skeleton-row span { height:12px; border-radius:6px; }
    .calendar-skeleton-row-head { min-height:43px; background:#f5f7f9; }
    .calendar-skeleton-row-head span { height:10px; }

    @media (prefers-reduced-motion: reduce) {
        .calendar-skeleton::after { animation: none; }
    }

    .calendar-empty-icon {
        width: 58px;
        height: 58px;
        border-radius: 15px;
        background: #fff4d6;
        color: #926b00;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        margin-bottom: 12px;
    }

    .calendar-legend {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        font-size: 11px;
        color: #606873;
    }

    .calendar-legend-item {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-weight: 600;
    }

    .calendar-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        display: inline-block;
    }

    .loan-detail-modal .modal-header {
        background: var(--loan-red);
        color: #fff;
    }

    .loan-detail-modal .btn-close {
        filter: brightness(0) invert(1);
    }

    .detail-stat {
        border: 1px solid #e6e9ed;
        border-radius: 10px;
        padding: 12px;
        background: #fff;
    }

    .detail-stat-label {
        color: #747b85;
        font-size: 11px;
        font-weight: 700;
    }

    .detail-stat-value {
        color: #1f3864;
        font-size: 16px;
        font-weight: 800;
        margin-top: 3px;
    }

    @media (max-width: 767.98px) {
        .calendar-month-title {
            min-width: 150px;
            font-size: 15px;
        }

        .calendar-day {
            min-height: 105px;
        }

        .calendar-event {
            padding: 5px;
            font-size: 9px;
        }

        .calendar-toolbar {
            align-items: stretch;
        }
    }
</style>

<div
    class="container-fluid loan-calendar-page py-3"
    id="loanCalendarPage"
>
    <div class="loan-card p-3 p-lg-4 mb-3">
        <div class="calendar-toolbar">
            <div>
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <h4 class="loan-title mb-0">
                        Schedule Calendar
                    </h4>
                    <span class="badge bg-light-danger text-danger">
                        Repayment &amp; Renewal Watch
                    </span>
                </div>

                <!-- <div class="loan-subtitle mt-1">
                    See EMIs, interest dues, CC renewals, stock statements and jewel redemption deadlines in one place.
                </div> -->

                <div class="small text-muted mt-2">
                    <i class="mdi mdi-home-outline me-1"></i>
                    Home
                    <span class="mx-1">/</span>
                    Accounts &amp; Finance
                    <span class="mx-1">/</span>
                    Loans &amp; Schedules
                    <span class="mx-1">/</span>
                    <span class="text-dark fw-semibold">Calendar</span>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2 flex-wrap">
                <button
                    type="button"
                    class="btn loan-outline-btn"
                    id="calendarTodayBtn"
                >
                    Today
                </button>

                <a
                    href="{{ route('accounts-finance-loans') }}"
                    class="btn loan-outline-btn"
                >
                    <i class="mdi mdi-format-list-bulleted me-1"></i>
                    Manage Loan
                </a>
            </div>
        </div>
    </div>

    <div class="loan-card calendar-filter mb-3">
        <div class="row g-3 align-items-end">
            <div class="col-xl-3 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Company
                </label>
                <select class="form-select select3" id="calendarCompanyFilter">
                    <option value="">All Companies</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Loan Type
                </label>
                <select class="form-select select3" id="calendarTypeFilter">
                    <option value="">All Types</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Lender
                </label>
                <select class="form-select select3" id="calendarLenderFilter">
                    <option value="">All Lenders</option>
                </select>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
                <label class="small fw-bold text-muted mb-1">
                    Status
                </label>
                <select class="form-select select3" id="calendarStatusFilter">
                    <option value="">All</option>
                    <option value="upcoming">Upcoming</option>
                    <option value="today">Due Today</option>
                    <option value="overdue">Overdue</option>
                    <option value="paid">Paid</option>
                </select>
            </div>

            <div class="col-xl-3 col-lg-8 col-md-12">
                <label class="small fw-bold text-muted mb-1">
                    Search
                </label>
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="mdi mdi-magnify"></i>
                    </span>
                    <input
                        type="search"
                        id="calendarSearch"
                        class="form-control"
                        placeholder="Account, lender or obligation..."
                        autocomplete="off"
                    >
                    <button
                        type="button"
                        class="btn btn-light border"
                        id="calendarClearSearch"
                        title="Clear"
                    >
                        <i class="mdi mdi-close"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Calendar Items</div>
                <div class="value" id="calendarStatItems">0</div>
                <div class="small text-muted mt-1">Visible in current range</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Due Value</div>
                <div class="value" id="calendarStatAmount">₹0</div>
                <div class="small text-muted mt-1">Outstanding calendar balance</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Due Today</div>
                <div class="value text-warning" id="calendarStatToday">0</div>
                <div class="small text-muted mt-1">Items requiring attention</div>
            </div>
        </div>

        <div class="col-6 col-xl-3">
            <div class="calendar-stat">
                <div class="label">Overdue</div>
                <div class="value text-danger" id="calendarStatOverdue">0</div>
                <div class="small text-muted mt-1">Past due and not fully paid</div>
            </div>
        </div>
    </div>

    <div class="loan-card">
        <div class="p-3 border-bottom">
            <div class="calendar-toolbar">
                <div class="calendar-nav">
                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        id="calendarPrevBtn"
                        aria-label="Previous"
                    >
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <div class="calendar-month-title" id="calendarMonthTitle">
                        Loading...
                    </div>

                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        id="calendarNextBtn"
                        aria-label="Next"
                    >
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>

                <div class="calendar-view-toggle">
                    <button type="button" data-calendar-view="month" class="active">
                        Month
                    </button>
                    <button type="button" data-calendar-view="week">
                        Week
                    </button>
                    <button type="button" data-calendar-view="list">
                        List
                    </button>
                </div>
            </div>
        </div>

        <div
            id="calendarContent"
            class="calendar-grid-wrap"
        >
            <div class="calendar-loading">
                <div class="calendar-skeleton-grid">
                    <div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div><div class="calendar-skeleton calendar-skeleton-head"></div>
                    <div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div><div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div>
                </div>
            </div>
        </div>

        <div class="p-3 border-top">
            <div class="calendar-legend">
                <span class="fw-bold text-dark">Legend:</span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#2e5fa3;"></span>
                    Upcoming
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#b7791f;"></span>
                    Due Today
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#b3261e;"></span>
                    Overdue
                </span>

                <span class="calendar-legend-item">
                    <span class="calendar-dot" style="background:#16803b;"></span>
                    Paid
                </span>

                <span class="ms-auto text-muted">
                    <i class="mdi mdi-information-outline me-1"></i>
                    Click any item for payment, snooze and loan actions.
                </span>
            </div>
        </div>
    </div>
</div>

{{-- Calendar Detail --}}
<div
    class="modal fade loan-detail-modal"
    id="calendarDetailModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="calendarDetailTitle">
                        Obligation Details
                    </h5>
                    <div class="small opacity-75" id="calendarDetailSubtitle"></div>
                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>
            </div>

            <div class="modal-body" id="calendarDetailBody"></div>

            <div class="modal-footer">
                <button
                    type="button"
                    class="btn loan-outline-btn"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>

                <button
                    type="button"
                    class="btn loan-outline-btn"
                    id="calendarSnoozeBtn"
                >
                    <i class="mdi mdi-clock-outline me-1"></i>
                    Snooze
                </button>

                <button
                    type="button"
                    class="btn loan-primary-btn"
                    id="calendarPaymentBtn"
                >
                    <i class="mdi mdi-cash-check me-1"></i>
                    Record Payment
                </button>

                <button
                    type="button"
                    class="btn loan-gold-btn"
                    id="calendarOpenLoanBtn"
                >
                    <i class="mdi mdi-open-in-new me-1"></i>
                    Open Loan
                </button>
            </div>
        </div>
    </div>
</div>

{{-- Payment --}}
<div
    class="modal fade"
    id="calendarPaymentModal"
    tabindex="-1"
    aria-hidden="true"
>
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header text-white" style="background:#b52b22;">
                <div>
                    <h5 class="modal-title">
                        Record Payment
                    </h5>
                    <div class="small opacity-75">
                        Save the actual payment made through the bank or other payment channel.
                    </div>
                </div>

                <button
                    type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal"
                ></button>
            </div>

            <form id="calendarPaymentForm">
                <div class="modal-body">
                    <input type="hidden" id="calendarPaymentObligationId">
                    <input type="hidden" id="calendarPaymentLoanId">

                    <div class="alert alert-light border d-flex align-items-center gap-2">
                        <i class="mdi mdi-information-outline text-primary fs-4"></i>
                        <div>
                            <div class="fw-bold" id="calendarPaymentObligationTitle">
                                -
                            </div>
                            <div class="small text-muted" id="calendarPaymentObligationMeta">
                                -
                            </div>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Amount Paid <span class="text-danger">*</span>
                            </label>
                            <input
                                type="number"
                                min="0.01"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentAmount"
                                required
                            >
                            <div class="small text-muted mt-1" id="calendarPaymentBalanceHelp"></div>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Payment Date <span class="text-danger">*</span>
                            </label>
                            <input
                                type="date"
                                class="form-control"
                                id="calendarPaymentDate"
                                required
                            >
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">
                                Mode <span class="text-danger">*</span>
                            </label>
                            <select class="form-select select3" id="calendarPaymentMode">
                                <option value="NACH">NACH</option>
                                <option value="NEFT">NEFT</option>
                                <option value="RTGS">RTGS</option>
                                <option value="Cash">Cash</option>
                                <option value="Cheque">Cheque</option>
                                <option value="UPI">UPI</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Reference No.
                            </label>
                            <input
                                type="text"
                                maxlength="150"
                                class="form-control"
                                id="calendarPaymentReference"
                                placeholder="UTR / cheque no. / transaction reference"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Pay From Account
                            </label>
                            <input
                                type="text"
                                maxlength="180"
                                class="form-control"
                                id="calendarPaymentAccount"
                                placeholder="Bank / account reference"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Principal Component
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentPrincipal"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Interest Component
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentInterest"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Penal Interest
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentPenal"
                                value="0"
                            >
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Bounce Charge
                            </label>
                            <input
                                type="number"
                                min="0"
                                step="0.01"
                                class="form-control"
                                id="calendarPaymentBounce"
                                value="0"
                            >
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">
                                Notes
                            </label>
                            <textarea
                                class="form-control"
                                id="calendarPaymentNotes"
                                rows="3"
                                maxlength="1000"
                                placeholder="Optional payment notes..."
                            ></textarea>
                        </div>

                        <div
                            class="small text-danger"
                            id="calendarPaymentError"
                        ></div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn loan-outline-btn"
                        data-bs-dismiss="modal"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="btn loan-primary-btn"
                        id="calendarPaymentSaveBtn"
                    >
                        <span class="payment-save-text">
                            <i class="mdi mdi-content-save-outline me-1"></i>
                            Save Payment
                        </span>
                        <span class="payment-save-loading d-none">
                            <span class="spinner-border spinner-border-sm me-1"></span>
                            Saving...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Snooze --}}
<div class="modal fade" id="calendarSnoozeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header text-white" style="background:#b52b22;">
                <h5 class="modal-title">Snooze Reminder</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form id="calendarSnoozeForm">
                <div class="modal-body">
                    <label class="form-label fw-semibold">
                        Remind me again at
                    </label>
                    <input
                        type="datetime-local"
                        class="form-control"
                        id="calendarSnoozeUntil"
                        required
                    >
                    <div class="small text-muted mt-2">
                        Snoozing changes only the reminder state; the due date remains unchanged.
                    </div>
                    <div class="small text-danger mt-2" id="calendarSnoozeError"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn loan-outline-btn" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn loan-primary-btn">Snooze</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div
    class="position-fixed bottom-0 start-50 translate-middle-x p-3"
    style="z-index:1095;"
>
    <div
        id="calendarToast"
        class="toast align-items-center text-bg-success border-0 shadow"
        role="status"
        aria-live="polite"
    >
        <div class="d-flex">
            <div class="toast-body" id="calendarToastBody"></div>
            <button
                type="button"
                class="btn-close btn-close-white me-2 m-auto"
                data-bs-dismiss="toast"
            ></button>
        </div>
    </div>
</div>

<script>
    window.LoanCalendarRoutes = {
        calendar: @json(route('accounts_finance.loans.calendar.data')),
        lookups: @json(route('accounts_finance.loans.lookups')),
        show: @json(route('accounts_finance.loans.data.show', ['loan' => '__ID__'])),
        payment: @json(route('accounts_finance.loans.payments.store', ['loan' => '__ID__'])),
        snooze: @json(route('accounts_finance.loans.obligations.snooze', ['obligation' => '__ID__'])),
    };

    window.LoanCalendarConfig = {
        csrf: @json(csrf_token()),
        today: @json(now()->format('Y-m-d')),
    };
</script>

<script >
    (function ($) {
    'use strict';

    const routes = window.LoanCalendarRoutes || {};
    const config = window.LoanCalendarConfig || {};

    if (!routes.calendar || !document.getElementById('loanCalendarPage')) {
        return;
    }

    function initCalendarSelect3() {
        $('.select3').each(function () {
            const $select = $(this);
            if (!$select.length || !$.fn.select2) return;
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }
            const $parent = $select.closest('.calendar-filter, .modal');
            $select.select2({
                width: '100%',
                dropdownParent: $parent.length ? $parent : $('body'),
                minimumResultsForSearch: 0,
                allowClear: true,
                placeholder: $select.find('option:first').text() || 'Select'
            });
        });
    }

    const state = {
        view: 'month',
        cursor: new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            1
        ),
        weekDate: config.today || new Date().toISOString().slice(0, 10),
        companyId: '',
        typeId: '',
        lenderId: '',
        status: '',
        search: '',
        items: [],
        activeItem: null,
        request: null,
    };

    let detailModal = null;
    let paymentModal = null;
    let snoozeModal = null;

    function safeModal(selector) {
        const element = document.querySelector(selector);

        if (!element || !window.bootstrap || !bootstrap.Modal) {
            return null;
        }

        return bootstrap.Modal.getOrCreateInstance(element);
    }

    function esc(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function url(template, id) {
        return String(template || '').replace(
            '__ID__',
            encodeURIComponent(String(id))
        );
    }

    function money(value) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2,
        }).format(Number(value || 0));
    }

    function date(value) {
        if (!value) {
            return '-';
        }

        const parts = String(value).slice(0, 10).split('-');

        return parts.length === 3
            ? `${parts[2]}-${parts[1]}-${parts[0]}`
            : String(value);
    }

    function isoDate(dateObject) {
        const year = dateObject.getFullYear();
        const month = String(dateObject.getMonth() + 1).padStart(2, '0');
        const day = String(dateObject.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }

    function parseLocalDate(value) {
        const parts = String(value).split('-').map(Number);

        return new Date(
            parts[0],
            parts[1] - 1,
            parts[2]
        );
    }

    function monthLabel(dateObject) {
        return dateObject.toLocaleString('en-GB', {
            month: 'long',
            year: 'numeric',
        });
    }

    function escapeSelector(value) {
        return window.CSS && CSS.escape
            ? CSS.escape(String(value))
            : String(value).replace(/["\\]/g, '\\$&');
    }

    function toast(message, type = 'success') {
        const el = document.getElementById('calendarToast');
        const body = document.getElementById('calendarToastBody');

        if (!el || !body) {
            return;
        }

        el.classList.remove(
            'text-bg-success',
            'text-bg-danger',
            'text-bg-warning',
            'text-bg-info'
        );

        const map = {
            success: 'text-bg-success',
            error: 'text-bg-danger',
            warning: 'text-bg-warning',
            info: 'text-bg-info',
        };

        el.classList.add(map[type] || map.success);
        body.textContent = message || 'Completed.';

        if (window.bootstrap && bootstrap.Toast) {
            bootstrap.Toast.getOrCreateInstance(el, {
                delay: 3500
            }).show();
        }
    }

    function statusBadge(status) {
        const map = {
            upcoming: ['Upcoming', 'event-upcoming'],
            today: ['Due Today', 'event-today'],
            overdue: ['Overdue', 'event-overdue'],
            paid: ['Paid', 'event-paid'],
            snoozed: ['Snoozed', 'event-snoozed'],
            pending: ['Pending', 'event-upcoming'],
            partial: ['Partial', 'event-today'],
        };

        const item = map[status] || ['Pending', 'event-upcoming'];

        return `
            <span class="badge rounded-pill ${item[1]}">
                ${esc(item[0])}
            </span>
        `;
    }

    function typeIcon(item) {
        const icon = item.loan?.loan_type_icon
            || 'mdi-calendar-check-outline';

        return `<i class="mdi ${esc(icon)}"></i>`;
    }

    function fetchLookups() {
        if (!routes.lookups) {
            return $.Deferred().resolve().promise();
        }

        return $.ajax({
            url: routes.lookups,
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        }).done(function (response) {
            if (Number(response?.status) !== 200) {
                return;
            }

            const data = response.data || {};

            populateSelect(
                '#calendarCompanyFilter',
                data.companies || data.entities || [],
                'All Companies',
                'id',
                'name'
            );

            populateSelect(
                '#calendarTypeFilter',
                data.types || [],
                'All Types',
                'id',
                'type_name'
            );

            populateSelect(
                '#calendarLenderFilter',
                data.lenders || [],
                'All Lenders',
                'id',
                'lender_name'
            );

            initCalendarSelect3();
        }).fail(function (xhr) {
            console.error('Loan calendar lookup error', xhr);
        });
    }

    function populateSelect(
        selector,
        items,
        placeholder,
        idField,
        nameField
    ) {
        const select = $(selector);
        let html = `<option value="">${esc(placeholder)}</option>`;

        items.forEach(function (item) {
            html += `
                <option value="${esc(item[idField])}">
                    ${esc(item[nameField] || '-')}
                </option>
            `;
        });

        select.html(html);
    }

    function buildRequest() {
        const year = state.cursor.getFullYear();
        const month = state.cursor.getMonth() + 1;

        return {
            year: year,
            month: month,
            view: state.view === 'week' ? 'week' : 'month',
            date: state.weekDate,
            company_id: state.companyId,
            type_id: state.typeId,
            lender_id: state.lenderId,
            status: state.status,
            search: state.search,
        };
    }

    function calendarSkeletonMarkup() {
        if (state.view === 'list') {
            return `<div class="calendar-loading calendar-list-skeleton">
                <div class="calendar-skeleton-row calendar-skeleton-row-head">
                    ${Array.from({length: 8}).map(() => `<span class="calendar-skeleton"></span>`).join('')}
                </div>
                ${Array.from({length: 6}).map(() => `<div class="calendar-skeleton-row">
                    ${Array.from({length: 8}).map(() => `<span class="calendar-skeleton"></span>`).join('')}
                </div>`).join('')}
            </div>`;
        }

        return `<div class="calendar-loading">
            <div class="calendar-skeleton-toolbar mb-3">
                <span class="calendar-skeleton calendar-skeleton-title"></span>
                <span class="calendar-skeleton calendar-skeleton-button"></span>
                <span class="calendar-skeleton calendar-skeleton-button"></span>
            </div>
            <div class="calendar-skeleton-grid">
                ${Array.from({length: 7}).map(() => `<div class="calendar-skeleton calendar-skeleton-head"></div>`).join('')}
                ${Array.from({length: 21}).map(() => `<div class="calendar-skeleton calendar-skeleton-cell"><span></span><i></i><i></i></div>`).join('')}
            </div>
        </div>`;
    }

    function loadCalendar() {
        $('#calendarMonthTitle').text(
            state.view === 'week'
                ? 'Loading week...'
                : monthLabel(state.cursor)
        );

        $('#calendarContent').html(calendarSkeletonMarkup());

        if (state.request && state.request.readyState !== 4) {
            state.request.abort();
        }

        state.request = $.ajax({
            url: routes.calendar,
            type: 'GET',
            data: buildRequest(),
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            if (Number(response?.status) !== 200) {
                throw new Error(
                    response?.message || 'Unable to load calendar.'
                );
            }

            state.items = response.data || [];

            renderSummary(response.summary || {});
            renderHeader(response.range || {});

            if (state.view === 'month') {
                renderMonth();
            } else if (state.view === 'week') {
                renderWeek();
            } else {
                renderList();
            }
        })
        .fail(function (xhr, statusText) {
            if (statusText === 'abort') {
                return;
            }

            $('#calendarContent').html(`
                <div class="calendar-empty">
                    <div class="calendar-empty-icon">
                        <i class="mdi mdi-alert-circle-outline"></i>
                    </div>
                    <div class="fw-bold text-dark">
                        Unable to load schedule
                    </div>
                    <div class="small mt-1">
                        Please try again.
                    </div>
                    <button
                        type="button"
                        class="btn btn-danger btn-sm mt-3"
                        id="calendarRetryBtn"
                    >
                        Retry
                    </button>
                </div>
            `);

            $('#calendarRetryBtn').on(
                'click',
                loadCalendar
            );

            const message = xhr.responseJSON?.message
                || 'Unable to load schedule calendar.';

            toast(message, 'error');
        });
    }

    function renderSummary(summary) {
        $('#calendarStatItems').text(
            Number(summary.items || 0)
        );

        $('#calendarStatAmount').text(
            money(summary.amount || 0)
        );

        $('#calendarStatToday').text(
            Number(summary.today || 0)
        );

        $('#calendarStatOverdue').text(
            Number(summary.overdue || 0)
        );
    }

    function renderHeader(range) {
        if (state.view === 'week') {
            const start = range.start
                ? parseLocalDate(range.start)
                : parseLocalDate(state.weekDate);

            const end = range.end
                ? parseLocalDate(range.end)
                : parseLocalDate(state.weekDate);

            $('#calendarMonthTitle').text(
                `${date(isoDate(start))} – ${date(isoDate(end))}`
            );

            return;
        }

        $('#calendarMonthTitle').text(
            monthLabel(state.cursor)
        );
    }

    function itemsForDate(iso) {
        return state.items.filter(function (item) {
            return item.due_date === iso;
        });
    }

    function renderMonth() {
        const year = state.cursor.getFullYear();
        const month = state.cursor.getMonth();

        const first = new Date(year, month, 1);
        const last = new Date(year, month + 1, 0);

        const startOffset = (
            first.getDay() + 6
        ) % 7;

        const totalDays = last.getDate();

        const previousMonthDays = new Date(
            year,
            month,
            0
        ).getDate();

        const cells = [];

        for (let i = startOffset - 1; i >= 0; i--) {
            cells.push({
                date: new Date(
                    year,
                    month - 1,
                    previousMonthDays - i
                ),
                other: true,
            });
        }

        for (let day = 1; day <= totalDays; day++) {
            cells.push({
                date: new Date(year, month, day),
                other: false,
            });
        }

        while (cells.length < 42) {
            const day = cells.length - (
                startOffset + totalDays
            ) + 1;

            cells.push({
                date: new Date(
                    year,
                    month + 1,
                    day
                ),
                other: true,
            });
        }

        const today = config.today
            || isoDate(new Date());

        let html = `
            <div class="calendar-month-grid">
                ${[
                    'Monday',
                    'Tuesday',
                    'Wednesday',
                    'Thursday',
                    'Friday',
                    'Saturday',
                    'Sunday'
                ].map(function (day) {
                    return `
                        <div class="calendar-weekday">
                            ${day}
                        </div>
                    `;
                }).join('')}
        `;

        cells.forEach(function (cell) {
            const iso = isoDate(cell.date);
            const items = itemsForDate(iso);
            const isToday = iso === today;

            let eventsHtml = '';

            items.slice(0, 3).forEach(function (item) {
                eventsHtml += eventHtml(item);
            });

            if (items.length > 3) {
                eventsHtml += `
                    <button
                        type="button"
                        class="event-more"
                        data-calendar-date="${esc(iso)}"
                    >
                        +${items.length - 3} more
                    </button>
                `;
            }

            html += `
                <div class="calendar-day
                    ${cell.other ? 'other-month' : ''}
                    ${isToday ? 'today' : ''}
                ">
                    <div class="calendar-day-number">
                        ${cell.date.getDate()}
                    </div>
                    ${eventsHtml || ''}
                </div>
            `;
        });

        html += '</div>';

        $('#calendarContent').html(html);
    }

    function eventHtml(item) {
        const status = item.status_key || 'upcoming';

        return `
            <button
                type="button"
                class="calendar-event event-${esc(status)}"
                data-calendar-item="${esc(item.id)}"
                title="${esc(item.title || '')}"
            >
                <span class="event-icon">
                    ${typeIcon(item)}
                </span>

                <span class="event-content">
                    <span class="event-title">
                        ${esc(item.title || '-')}
                    </span>

                    <span class="event-meta">
                        ${esc(item.loan?.account_no || '')}
                        ${item.balance_amount
                            ? ` · ${esc(money(item.balance_amount))}`
                            : ''}
                    </span>
                </span>
            </button>
        `;
    }

    function renderWeek() {
        const anchor = parseLocalDate(
            state.weekDate
        );

        const monday = new Date(anchor);

        monday.setDate(
            anchor.getDate()
            - ((anchor.getDay() + 6) % 7)
        );

        let html = `
            <div class="calendar-week-grid">
        `;

        for (let index = 0; index < 7; index++) {
            const current = new Date(monday);

            current.setDate(
                monday.getDate() + index
            );

            const iso = isoDate(current);
            const items = itemsForDate(iso);
            const isToday = iso === (
                config.today || isoDate(new Date())
            );

            html += `
                <div class="calendar-week-column">
                    <div class="calendar-week-head ${isToday ? 'text-danger' : ''}">
                        ${current.toLocaleString(
                            'en-GB',
                            { weekday: 'long' }
                        )}
                        <span class="text-muted ms-1">
                            ${date(iso)}
                        </span>
                    </div>

                    ${
                        items.length
                            ? items.map(eventHtml).join('')
                            : `
                                <div class="small text-muted text-center pt-5">
                                    No dues
                                </div>
                            `
                    }
                </div>
            `;
        }

        html += '</div>';

        $('#calendarContent').html(html);
    }

    function renderList() {
        if (!state.items.length) {
            $('#calendarContent').html(`
                <div class="calendar-empty">
                    <div class="calendar-empty-icon">
                        <i class="mdi mdi-calendar-blank-outline"></i>
                    </div>
                    <div class="fw-bold text-dark">
                        No schedule items found
                    </div>
                    <div class="small mt-1">
                        There are no obligations in the selected range with these filters.
                    </div>
                </div>
            `);

            return;
        }

        let html = `
            <div class="calendar-agenda-wrap">
                <table class="calendar-agenda-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Obligation</th>
                            <th>Loan / Account</th>
                            <th>Lender</th>
                            <th class="text-end">Amount</th>
                            <th>Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        state.items.forEach(function (item) {
            html += `
                <tr>
                    <td>
                        <div class="agenda-date">
                            ${esc(date(item.due_date))}
                        </div>

                        ${
                            item.installment_no
                                ? `<div class="small text-muted">
                                    EMI #${esc(item.installment_no)}
                                </div>`
                                : ''
                        }
                    </td>

                    <td>
                        <span class="agenda-type">
                            ${typeIcon(item)}
                            ${esc(item.loan?.loan_type_name || item.obligation_type || '-')}
                        </span>
                    </td>

                    <td>
                        <div class="fw-bold">
                            ${esc(item.title || '-')}
                        </div>
                    </td>

                    <td>
                        <div class="fw-bold text-dark">
                            ${esc(item.loan?.account_no || '-')}
                        </div>
                        <div class="small text-muted">
                            ${esc(item.loan?.title || '')}
                        </div>
                    </td>

                    <td>
                        ${esc(item.loan?.lender_name || '-')}
                    </td>

                    <td class="text-end fw-bold">
                        ${money(item.balance_amount || 0)}
                    </td>

                    <td>
                        ${statusBadge(item.status_key)}
                    </td>

                    <td class="text-center">
                        <button
                            type="button"
                            class="btn btn-sm btn-outline-danger"
                            data-calendar-item="${esc(item.id)}"
                        >
                            Details
                        </button>
                    </td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        $('#calendarContent').html(html);
    }

    function findItem(id) {
        return state.items.find(function (item) {
            return String(item.id) === String(id);
        });
    }

    function openDetail(id) {
        const item = findItem(id);

        if (!item) {
            return;
        }

        state.activeItem = item;

        $('#calendarDetailTitle').text(
            item.title || 'Obligation Details'
        );

        $('#calendarDetailSubtitle').text(
            [
                item.loan?.lender_name,
                item.loan?.account_no,
                date(item.due_date)
            ].filter(Boolean).join(' · ')
        );

        $('#calendarDetailBody').html(`
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Due Date
                        </div>
                        <div class="detail-stat-value">
                            ${esc(date(item.due_date))}
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Amount Due
                        </div>
                        <div class="detail-stat-value">
                            ${money(item.balance_amount || 0)}
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="detail-stat">
                        <div class="detail-stat-label">
                            Status
                        </div>
                        <div class="mt-2">
                            ${statusBadge(item.status_key)}
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card border">
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Loan / Account
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.loan?.account_no || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Lender
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.loan?.lender_name || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Obligation Type
                                    </div>
                                    <div class="fw-bold">
                                        ${esc(item.obligation_type || '-')}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Principal
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.principal_amount || 0)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Interest
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.interest_amount || 0)}
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="small text-muted">
                                        Closing Balance
                                    </div>
                                    <div class="fw-bold">
                                        ${money(item.closing_balance || 0)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);

        toggleDetailActions(item);

        detailModal = detailModal || safeModal('#calendarDetailModal');

        if (detailModal) {
            detailModal.show();
        }
    }

    function toggleDetailActions(item) {
        const canPay = (
            Number(item.balance_amount || 0) > 0
            && !['paid'].includes(item.status_key)
        );

        $('#calendarPaymentBtn').prop(
            'disabled',
            !canPay
        );

        $('#calendarPaymentBtn').toggle(
            canPay
        );

        $('#calendarSnoozeBtn').toggle(
            !['paid', 'overdue'].includes(item.status_key)
        );

        $('#calendarOpenLoanBtn').prop(
            'disabled',
            !item.loan?.id
        );
    }

    function openPayment() {
        const item = state.activeItem;

        if (!item || !item.loan?.id) {
            return;
        }

        $('#calendarPaymentObligationId').val(
            item.id
        );

        $('#calendarPaymentLoanId').val(
            item.loan.id
        );

        $('#calendarPaymentObligationTitle').text(
            item.title || '-'
        );

        $('#calendarPaymentObligationMeta').text(
            `${item.loan.account_no || ''} · ${item.loan.lender_name || ''} · Due ${date(item.due_date)}`
        );

        $('#calendarPaymentAmount').val(
            Number(item.balance_amount || 0).toFixed(2)
        );

        $('#calendarPaymentBalanceHelp').text(
            `Outstanding against this item: ${money(item.balance_amount || 0)}`
        );

        $('#calendarPaymentDate').val(
            config.today || isoDate(new Date())
        );

        $('#calendarPaymentMode').val('NACH');
        $('#calendarPaymentReference').val('');
        $('#calendarPaymentAccount').val('');
        $('#calendarPaymentPrincipal').val(
            Number(item.principal_amount || 0).toFixed(2)
        );
        $('#calendarPaymentInterest').val(
            Number(item.interest_amount || 0).toFixed(2)
        );
        $('#calendarPaymentPenal').val('0');
        $('#calendarPaymentBounce').val('0');
        $('#calendarPaymentNotes').val('');
        $('#calendarPaymentError').text('');

        paymentModal = paymentModal || safeModal('#calendarPaymentModal');

        if (detailModal) {
            detailModal.hide();
        }

        setTimeout(function () {
            if (paymentModal) {
                paymentModal.show();
            }
        }, 180);
    }

    function submitPayment(event) {
        event.preventDefault();

        const item = state.activeItem;

        if (!item || !item.loan?.id) {
            return;
        }

        const saveButton = $('#calendarPaymentSaveBtn');

        saveButton.prop('disabled', true);

        $('.payment-save-text').addClass('d-none');
        $('.payment-save-loading').removeClass('d-none');
        $('#calendarPaymentError').text('');

        $.ajax({
            url: url(routes.payment, item.loan.id),
            type: 'POST',
            data: {
                _token: config.csrf || '',
                obligation_id: $('#calendarPaymentObligationId').val(),
                payment_type: 'regular',
                payment_date: $('#calendarPaymentDate').val(),
                amount: $('#calendarPaymentAmount').val(),
                principal_amount: $('#calendarPaymentPrincipal').val(),
                interest_amount: $('#calendarPaymentInterest').val(),
                penal_interest: $('#calendarPaymentPenal').val(),
                bounce_charge: $('#calendarPaymentBounce').val(),
                mode: $('#calendarPaymentMode').val(),
                reference_no: $('#calendarPaymentReference').val(),
                pay_from_account: $('#calendarPaymentAccount').val(),
                notes: $('#calendarPaymentNotes').val(),
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Payment recorded successfully.',
                'success'
            );

            if (paymentModal) {
                paymentModal.hide();
            }

            setTimeout(
                loadCalendar,
                250
            );
        })
        .fail(function (xhr) {
            const response = xhr.responseJSON || {};

            $('#calendarPaymentError').text(
                response.message
                || 'Unable to save payment.'
            );

            toast(
                response.message
                || 'Unable to save payment.',
                'error'
            );
        })
        .always(function () {
            saveButton.prop(
                'disabled',
                false
            );

            $('.payment-save-text').removeClass('d-none');
            $('.payment-save-loading').addClass('d-none');
        });
    }

    function openSnooze() {
        if (!state.activeItem) {
            return;
        }

        const base = new Date();

        base.setMinutes(
            base.getMinutes() + 60
        );

        const local = new Date(
            base.getTime()
            - base.getTimezoneOffset() * 60000
        );

        $('#calendarSnoozeUntil').val(
            local.toISOString().slice(0, 16)
        );

        $('#calendarSnoozeError').text('');

        snoozeModal = snoozeModal || safeModal('#calendarSnoozeModal');

        if (detailModal) {
            detailModal.hide();
        }

        setTimeout(function () {
            if (snoozeModal) {
                snoozeModal.show();
            }
        }, 180);
    }

    function submitSnooze(event) {
        event.preventDefault();

        if (!state.activeItem) {
            return;
        }

        const until = $('#calendarSnoozeUntil').val();

        $.ajax({
            url: url(
                routes.snooze,
                state.activeItem.id
            ),
            type: 'POST',
            data: {
                _token: config.csrf || '',
                snoozed_until: until,
            },
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': config.csrf || '',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            },
        })
        .done(function (response) {
            toast(
                response?.message || 'Reminder snoozed.',
                'success'
            );

            if (snoozeModal) {
                snoozeModal.hide();
            }

            setTimeout(
                loadCalendar,
                250
            );
        })
        .fail(function (xhr) {
            const response = xhr.responseJSON || {};

            $('#calendarSnoozeError').text(
                response.message
                || 'Unable to snooze reminder.'
            );
        });
    }

    function navigate(direction) {
        if (state.view === 'week') {
            const dateValue = parseLocalDate(
                state.weekDate
            );

            dateValue.setDate(
                dateValue.getDate() + (
                    direction * 7
                )
            );

            state.weekDate = isoDate(dateValue);
            state.cursor = new Date(
                dateValue.getFullYear(),
                dateValue.getMonth(),
                1
            );
        } else {
            state.cursor = new Date(
                state.cursor.getFullYear(),
                state.cursor.getMonth() + direction,
                1
            );

            state.weekDate = isoDate(
                state.cursor
            );
        }

        loadCalendar();
    }

    function goToday() {
        const now = new Date();

        state.cursor = new Date(
            now.getFullYear(),
            now.getMonth(),
            1
        );

        state.weekDate = isoDate(now);

        loadCalendar();
    }

    function bindEvents() {
        $('#calendarPrevBtn').on(
            'click',
            function () {
                navigate(-1);
            }
        );

        $('#calendarNextBtn').on(
            'click',
            function () {
                navigate(1);
            }
        );

        $('#calendarTodayBtn').on(
            'click',
            goToday
        );

        $('[data-calendar-view]').on(
            'click',
            function () {
                state.view = $(this).data('calendar-view');

                $('[data-calendar-view]')
                    .removeClass('active');

                $(this).addClass('active');

                loadCalendar();
            }
        );

        $(document).off('change.loanCalendarCompany', '#calendarCompanyFilter').on(
            'change.loanCalendarCompany',
            '#calendarCompanyFilter',
            function () {
                state.companyId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarTypeFilter').on(
            'change',
            function () {
                state.typeId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarLenderFilter').on(
            'change',
            function () {
                state.lenderId = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarStatusFilter').on(
            'change',
            function () {
                state.status = $(this).val();
                loadCalendar();
            }
        );

        $('#calendarClearSearch').on(
            'click',
            function () {
                $('#calendarSearch').val('');
                state.search = '';
                loadCalendar();
            }
        );

        let searchTimer = null;

        $('#calendarSearch').on(
            'input',
            function () {
                clearTimeout(searchTimer);

                state.search = $.trim(
                    $(this).val()
                );

                searchTimer = setTimeout(
                    loadCalendar,
                    350
                );
            }
        );

        $(document).on(
            'click',
            '[data-calendar-item]',
            function () {
                openDetail(
                    $(this).data('calendar-item')
                );
            }
        );

        $(document).on(
            'click',
            '[data-calendar-date]',
            function () {
                const iso = $(this).data('calendar-date');
                const items = itemsForDate(iso);

                if (items.length) {
                    openDetail(items[0].id);
                }
            }
        );

        $('#calendarPaymentBtn').on(
            'click',
            openPayment
        );

        $('#calendarPaymentForm').on(
            'submit',
            submitPayment
        );

        $('#calendarSnoozeBtn').on(
            'click',
            openSnooze
        );

        $('#calendarSnoozeForm').on(
            'submit',
            submitSnooze
        );

        $('#calendarOpenLoanBtn').on(
            'click',
            function () {
                if (state.activeItem?.loan?.id) {
                    let viewUrl=`${state.activeItem.loan.id}`
                    window.location.href = viewUrl;
                }
            }
        );
    }

    function init() {
        detailModal = safeModal(
            '#calendarDetailModal'
        );

        paymentModal = safeModal(
            '#calendarPaymentModal'
        );

        snoozeModal = safeModal(
            '#calendarSnoozeModal'
        );

        bindEvents();
        initCalendarSelect3();

        fetchLookups().always(
            loadCalendar
        );
    }

    $(function () {
        init();
    });

})(jQuery);

</script>
@endsection
