{{-- ============================================================
    EXPENSE CATEGORY MODAL
    Table: egc_acc_expense_categories
    Icon system: Material Design Icons (mdi)
============================================================ --}}

<div
    class="modal fade expense-category-modal"
    id="categoryModal"
    tabindex="-1"
    aria-labelledby="categoryModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            {{-- =================================================
                HEADER
            ================================================== --}}

            <div class="modal-header">

                <div class="d-flex align-items-center">

                    <div class="avatar avatar-md bg-label-primary me-3">

                        <i
                            class="mdi mdi-shape-outline fs-4"
                            id="categoryModalIcon">
                        </i>

                    </div>

                    <div>

                        <h5 class="modal-title mb-1" id="categoryModalLabel">
                            Manage Expense Category
                        </h5>

                        <small class="text-muted">

                            Create and manage expense classifications

                        </small>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================== --}}

            <form
                id="categoryForm"
                method="POST"
                autocomplete="off">

                @csrf

                <input
                    type="hidden"
                    id="category_id"
                    name="category_id"
                    value="">

                <input
                    type="hidden"
                    id="categoryFormMode"
                    name="form_mode"
                    value="create">


                {{-- =================================================
                    BODY
                ================================================== --}}

                <div class="modal-body">


                    {{-- =============================================
                        CATEGORY PREVIEW
                    ============================================== --}}
                    <div class="fw-bold mb-2 fs-7" id="categoryModelTitleLabel"> Add Expense Category</div>
                    <div
                        class="category-preview mb-4"
                        id="categoryPreview">

                        <div class="category-preview-icon">

                            <i
                                class="mdi mdi-shape-outline"
                                id="categoryPreviewIcon">
                            </i>

                        </div>

                        <div class="category-preview-content">

                            <span class="category-preview-label">

                                Category Preview

                            </span>

                            <strong id="categoryPreviewName">

                                New Expense Category

                            </strong>

                            <small id="categoryPreviewCode">
                                CODE
                            </small> 

                        </div>

                    </div>


                    {{-- =============================================
                        CATEGORY CODE
                    ============================================== --}}

                    <!-- <div class="mb-4">

                        <label
                            for="category_code"
                            class="form-label required">

                            Category Code

                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="mdi mdi-pound"></i>

                            </span>

                            <input
                                type="text"
                                class="form-control text-uppercase"
                                id="category_code"
                                name="category_code"
                                maxlength="200"
                                placeholder="e.g. TRAVEL"
                                autocomplete="off">

                        </div>

                        <div class="form-text">

                            Use a short unique code for this expense category.

                        </div>

                        <div
                            class="invalid-feedback category_code_error">
                        </div>

                    </div> -->


                    {{-- =============================================
                        CATEGORY NAME
                    ============================================== --}}

                    <div class="mb-4">

                        <label
                            for="category_name"
                            class="form-label required">

                            Category Name

                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="mdi mdi-tag-outline"></i>

                            </span>

                            <input
                                type="text"
                                class="form-control"
                                id="category_name"
                                name="category_name"
                                maxlength="250"
                                placeholder="Enter category name"
                                autocomplete="off">

                        </div>

                        <div
                            class="invalid-feedback category_name_error">
                        </div>

                    </div>


                    {{-- =============================================
                        CATEGORY ICON
                    ============================================== --}}

                    <div class="mb-2">

                        <label
                            for="category_icon"
                            class="form-label required">

                            Category Icon

                        </label>

                        <div class="category-icon-selector">

                            {{-- Selected icon --}}

                            <div
                                class="category-selected-icon"
                                id="categorySelectedIcon">

                                <i
                                    class="mdi mdi-shape-outline"
                                    id="categoryIconPreview">
                                </i>

                            </div>


                            {{-- Icon select --}}

                            <div class="flex-grow-1">

                                <select class="form-select select3 categoryIcon" id="category_icon" name="icon" onchange="icon_chnage_func(this)">

                                    <option
                                        value="mdi-shape-outline">

                                        General

                                    </option>

                                    <option
                                        value="mdi-office-building-outline">

                                        Office

                                    </option>

                                    <option
                                        value="mdi-car-outline">

                                        Travel

                                    </option>

                                    <option
                                        value="mdi-airplane">

                                        Travel & Flight

                                    </option>

                                    <option
                                        value="mdi-gas-station-outline">

                                        Fuel

                                    </option>

                                    <option
                                        value="mdi-tools">

                                        Maintenance

                                    </option>

                                    <option
                                        value="mdi-laptop">

                                        Technology

                                    </option>

                                    <option
                                        value="mdi-phone-outline">

                                        Telephone

                                    </option>

                                    <option
                                        value="mdi-flash-outline">

                                        Electricity

                                    </option>

                                    <option
                                        value="mdi-water-outline">

                                        Water

                                    </option>

                                    <option
                                        value="mdi-home-outline">

                                        Rent / Property

                                    </option>

                                    <option
                                        value="mdi-account-group-outline">

                                        Employee

                                    </option>

                                    <option
                                        value="mdi-heart-outline">

                                        Welfare

                                    </option>

                                    <option
                                        value="mdi-cart-outline">

                                        Purchase

                                    </option>

                                    <option
                                        value="mdi-package-variant-closed">

                                        Inventory

                                    </option>

                                    <option
                                        value="mdi-file-document-outline">

                                        Invoice

                                    </option>

                                    <option
                                        value="mdi-receipt-text-outline">

                                        Receipt

                                    </option>

                                    <option
                                        value="mdi-credit-card-outline">

                                        Credit Card

                                    </option>

                                    <option
                                        value="mdi-wallet-outline">

                                        Finance

                                    </option>

                                    <option
                                        value="mdi-chart-line">

                                        Business

                                    </option>

                                    <option
                                        value="mdi-shield-check-outline">

                                        Insurance

                                    </option>

                                    <option
                                        value="mdi-school-outline">

                                        Training

                                    </option>

                                    <option
                                        value="mdi-bullhorn-outline">

                                        Marketing

                                    </option>

                                    <option
                                        value="mdi-web">

                                        Website / Domain

                                    </option>

                                    <option
                                        value="mdi-dots-horizontal">

                                        Other

                                    </option>

                                </select>

                            </div>

                        </div>


                        <div class="form-text">

                            Select the icon that best represents this category.

                        </div>

                        <div
                            class="invalid-feedback d-block category_icon_error">
                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER  https://chatgpt.com/share/6a7737b8-2da0-83ee-9507-015cdc5e5179
                ================================================== --}} 

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        <i class="mdi mdi-close me-1"></i>

                        Cancel

                    </button>


                    <button
                        type="reset"
                        class="btn btn-label-warning"
                        id="btnResetCategory">

                        <i class="mdi mdi-refresh me-1"></i>

                        Reset

                    </button>


                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnSaveCategory">

                        <span
                            class="spinner-border spinner-border-sm me-2 d-none"
                            id="categoryLoader">
                        </span>

                        <i
                            class="mdi mdi-content-save-outline me-1"
                            id="categorySaveIcon">
                        </i>

                        <span id="categorySaveText">

                            Save Category

                        </span>

                    </button>

                </div>

                <div class="modal-body">
                    <div class="category-list-panel mt-4">
                        <div class="category-list-header">

                            <div>
                                <div class="category-list-title">
                                    <i class="mdi mdi-format-list-bulleted me-1"></i>
                                    Existing Categories
                                </div>

                                <div class="category-list-subtitle">
                                    Recently added expense categories
                                </div>
                            </div>

                            <span class="category-list-count"
                                id="categoryListCount">
                                0
                            </span>

                        </div>
                        {{-- Search --}}
                        <div class="category-list-search">
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <input
                                    type="text"
                                    class="form-control"
                                    id="categoryListSearch"
                                    placeholder="Search Categories..."
                                    autocomplete="off">

                                <button
                                    type="button"
                                    class="btn btn-light d-none"
                                    id="categorySearchClear"
                                    aria-label="Clear search">

                                    <i class="mdi mdi-close"></i>

                                </button>

                            </div>

                        </div>
                        {{-- Loading --}}
                        <div id="categoryListLoading" class="category-list-loading">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <span>Loading categories...</span>
                        </div>


                        {{-- Empty --}}
                        <div id="categoryListEmpty" class="category-list-empty d-none">
                            <div class="category-list-empty-icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <div>
                                <strong>No category found</strong>
                                <small>
                                    Add your first expense category above.
                                </small>
                            </div>
                        </div>
                        {{-- Categories --}}
                        <div id="categoryList" class="category-list"></div>


                        {{-- Load more --}}

                        <div id="categoryListMore" class="category-list-more d-none">
                            <button type="button" class="btn btn-sm btn-label-secondary"
                                id="btnLoadMoreCategory">
                                <i class="mdi mdi-chevron-down me-1"></i>
                                Load More
                            </button>
                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>

</div>
<style>
    /* ============================================================
   EXPENSE CATEGORY MODAL
   File:
   expenditure/css/expenditure.css
============================================================ */


/* ============================================================
   MODAL
============================================================ */

.expense-category-modal .modal-dialog {
    max-width: 560px;
}

.expense-category-modal .modal-content {
    border: 0;
    border-radius: 0.75rem;
    overflow: hidden;
    box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.12);
}

.expense-category-modal .modal-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}

.expense-category-modal .modal-body {
    padding: 1.5rem;
    background-color: var(--bs-body-bg);
}

.expense-category-modal .modal-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}


/* ============================================================
   HEADER AVATAR
============================================================ */

.expense-category-modal .avatar {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.5rem;
}

.expense-category-modal .avatar i {
    line-height: 1;
}


/* ============================================================
   CATEGORY PREVIEW
============================================================ */

.expense-category-modal .category-preview {
    display: flex;
    align-items: center;
    gap: 1rem;

    padding: 1rem;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.625rem;

    background-color: var(--bs-tertiary-bg);

    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        background-color 0.2s ease;
}

.expense-category-modal .category-preview:hover {
    border-color: rgba(
        var(--bs-primary-rgb),
        0.35
    );

    box-shadow: 0 0.25rem 0.75rem rgba(
        var(--bs-primary-rgb),
        0.06
    );
}


/* ============================================================
   PREVIEW ICON
============================================================ */

.expense-category-modal .category-preview-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.625rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.12
    );

    font-size: 1.5rem;

    transition:
        transform 0.2s ease,
        background-color 0.2s ease;
}

.expense-category-modal .category-preview:hover
.category-preview-icon {
    transform: translateY(-1px);
}

.expense-category-modal .category-preview-icon i {
    line-height: 1;
}


/* ============================================================
   PREVIEW CONTENT
============================================================ */

.expense-category-modal .category-preview-content {
    min-width: 0;

    display: flex;
    flex-direction: column;
}

.expense-category-modal .category-preview-label {
    margin-bottom: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    font-weight: 600;

    letter-spacing: 0.04em;
    text-transform: uppercase;
}

.expense-category-modal .category-preview-content strong {
    overflow: hidden;

    color: var(--bs-body-color);

    font-size: 0.9375rem;
    font-weight: 600;

    line-height: 1.4;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.expense-category-modal .category-preview-content small {
    margin-top: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.75rem;
    font-weight: 500;

    letter-spacing: 0.04em;
    text-transform: uppercase;
}


/* ============================================================
   FORM LABEL
============================================================ */

.expense-category-modal .form-label {
    margin-bottom: 0.5rem;

    color: var(--bs-body-color);

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-category-modal .form-label.required::after {
    content: '*';

    margin-left: 0.25rem;

    color: var(--bs-danger);
}


/* ============================================================
   INPUT GROUP
============================================================ */

.expense-category-modal .input-group-text {
    min-width: 42px;

    justify-content: center;

    color: var(--bs-secondary-color);
    background-color: var(--bs-tertiary-bg);

    border-color: var(--bs-border-color);
}

.expense-category-modal .input-group-text i {
    font-size: 1.125rem;
}


/* ============================================================
   FORM CONTROLS
============================================================ */

.expense-category-modal .form-control,
.expense-category-modal .form-select {
    min-height: 42px;

    border-color: var(--bs-border-color);

    font-size: 0.8125rem;
}

.expense-category-modal .form-control:focus,
.expense-category-modal .form-select:focus {
    border-color: var(--bs-primary);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-primary-rgb),
        0.12
    );
}

.expense-category-modal .form-control::placeholder {
    color: var(--bs-secondary-color);
    opacity: 0.7;
}


/* ============================================================
   CATEGORY CODE
============================================================ */

.expense-category-modal #category_code {
    letter-spacing: 0.04em;
    font-weight: 500;
}


/* ============================================================
   ICON SELECTOR
============================================================ */

.expense-category-modal .category-icon-selector {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}


/* ============================================================
   SELECTED ICON
============================================================ */

.expense-category-modal .category-selected-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.5rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.375rem;

    transition:
        color 0.2s ease,
        background-color 0.2s ease,
        border-color 0.2s ease;
}

.expense-category-modal .category-selected-icon i {
    line-height: 1;
}


/* ============================================================
   ICON SELECT
============================================================ */

.expense-category-modal #category_icon {
    cursor: pointer;
}

.expense-category-modal #category_icon option {
    font-size: 0.8125rem;
}


/* ============================================================
   HELP TEXT
============================================================ */

.expense-category-modal .form-text {
    margin-top: 0.375rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    line-height: 1.5;
}


/* ============================================================
   VALIDATION
============================================================ */

.expense-category-modal .is-invalid {
    border-color: var(--bs-danger);
}

.expense-category-modal .is-invalid:focus {
    border-color: var(--bs-danger);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-danger-rgb),
        0.12
    );
}

.expense-category-modal .input-group
.is-invalid {
    z-index: 2;
}

.expense-category-modal
.category_code_error,
.expense-category-modal
.category_name_error,
.expense-category-modal
.category_icon_error {
    font-size: 0.6875rem;
}


/* ============================================================
   FOOTER BUTTONS
============================================================ */

.expense-category-modal .modal-footer .btn {
    min-height: 38px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-category-modal .modal-footer .btn i {
    font-size: 1rem;
}


/* ============================================================
   SAVE BUTTON
============================================================ */

.expense-category-modal #btnSaveCategory {
    min-width: 145px;
}

.expense-category-modal #categoryLoader {
    width: 0.875rem;
    height: 0.875rem;

    border-width: 0.12rem;
}


/* ============================================================
   DISABLED STATE
============================================================ */

.expense-category-modal .form-control:disabled,
.expense-category-modal .form-select:disabled {
    cursor: not-allowed;

    background-color: var(--bs-secondary-bg);
}


/* ============================================================
   LOADING STATE
============================================================ */

.expense-category-modal.is-loading {
    pointer-events: none;
}

.expense-category-modal.is-loading .modal-content {
    opacity: 0.72;
}


/* ============================================================
   DARK MODE
   Uses Bootstrap / ERP variables.
   No separate brand color required.
============================================================ */

[data-bs-theme='dark']
.expense-category-modal .category-preview {
    background-color: var(--bs-tertiary-bg);
}

[data-bs-theme='dark']
.expense-category-modal .category-preview-icon,
[data-bs-theme='dark']
.expense-category-modal .category-selected-icon {
    background-color: rgba(
        var(--bs-primary-rgb),
        0.16
    );
}


/* ============================================================
   RESPONSIVE
============================================================ */

@media (max-width: 575.98px) {

    .expense-category-modal .modal-dialog {
        margin: 0.75rem;
    }

    .expense-category-modal .modal-header {
        padding: 1rem;
    }

    .expense-category-modal .modal-body {
        padding: 1rem;
    }

    .expense-category-modal .modal-footer {
        padding: 0.875rem 1rem;

        flex-wrap: wrap;
    }

    .expense-category-modal .modal-footer .btn {
        flex: 1 1 auto;
    }

    .expense-category-modal .category-preview {
        padding: 0.875rem;
    }

}


/* ============================================================
   VERY SMALL DEVICES
============================================================ */

@media (max-width: 375px) {

    .expense-category-modal .category-icon-selector {
        align-items: stretch;
    }

    .expense-category-modal .category-selected-icon {
        width: 40px;
        min-width: 40px;
    }

    .expense-category-modal .modal-footer {
        gap: 0.5rem;
    }

    .expense-category-modal .modal-footer .btn {
        width: 100%;
        flex: 1 1 100%;
    }

}

/* ============================================================
   PRODUCT LIST
============================================================ */

.expense-category-modal .category-list-panel {
    border: 1px solid var(--bs-border-color);
    border-radius: 12px;
    background: var(--bs-body-bg);
    overflow: hidden;
}


/* ============================================================
   LIST HEADER
============================================================ */

.expense-category-modal .category-list-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 12px 14px;

    border-bottom: 1px solid var(--bs-border-color);

    background: var(--bs-tertiary-bg);
}

.expense-category-modal .category-list-title {
    color: var(--bs-body-color);
    font-size: 13px;
    font-weight: 600;
}

.expense-category-modal .category-list-title i {
    color: var(--bs-primary);
    font-size: 15px;
}

.expense-category-modal .category-list-subtitle {
    margin-top: 2px;

    color: var(--bs-secondary-color);
    font-size: 11px;
}

.expense-category-modal .category-list-count {
    min-width: 28px;
    height: 24px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 0 8px;

    border-radius: 20px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 11px;
    font-weight: 600;
}


/* ============================================================
   SEARCH
============================================================ */

.expense-category-modal .category-list-search {
    padding: 10px 12px;

    border-bottom: 1px solid var(--bs-border-color);
}

.expense-category-modal .category-list-search .input-group-text {
    min-width: 38px;

    background: var(--bs-body-bg);
    border-right: 0;
}

.expense-category-modal .category-list-search .form-control {
    min-height: 36px;

    border-left: 0;

    font-size: 12px;
}

.expense-category-modal .category-list-search .form-control:focus {
    box-shadow: none;
}

.expense-category-modal .category-list-search .btn {
    min-width: 38px;
}


/* ============================================================
   LIST SCROLL AREA
============================================================ */

.expense-category-modal .category-list {
    max-height: 235px;

    overflow-y: auto;
    overflow-x: hidden;

    padding: 4px 8px;
}

.expense-category-modal .category-list::-webkit-scrollbar {
    width: 5px;
}

.expense-category-modal .category-list::-webkit-scrollbar-track {
    background: transparent;
}

.expense-category-modal .category-list::-webkit-scrollbar-thumb {
    background: #d7dbe4;
    border-radius: 20px;
}


/* ============================================================
   category ROW
============================================================ */

.expense-category-modal .category-list-item {
    display: flex;

    align-items: center;

    gap: 10px;

    padding: 9px 7px;

    border-bottom: 1px solid
        rgba(
            var(--bs-border-color-rgb),
            0.55
        );

    transition:
        background-color 0.15s ease,
        transform 0.15s ease;
}

.expense-category-modal .category-list-item:last-child {
    border-bottom: 0;
}

.expense-category-modal .category-list-item:hover {
    background: var(--bs-tertiary-bg);
    border-radius: 8px;
}


/* ============================================================
   category ICON
============================================================ */

.expense-category-modal .category-list-icon {
    width: 34px;
    height: 34px;

    min-width: 34px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 17px;
}


/* ============================================================
   category CONTENT
============================================================ */

.expense-category-modal .category-list-content {
    flex: 1;

    min-width: 0;
}

.expense-category-modal .category-list-name {
    color: var(--bs-body-color);

    font-size: 12px;
    font-weight: 600;

    line-height: 17px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;
}

.expense-category-modal .category-list-meta {
    display: flex;

    align-items: center;

    gap: 6px;

    margin-top: 2px;

    min-width: 0;
}

.expense-category-modal .category-list-category {
    max-width: 150px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;

    color: var(--bs-secondary-color);

    font-size: 10px;
}

.expense-category-modal .category-list-code {
    color: var(--bs-secondary-color);

    font-size: 9px;
}

.expense-category-modal .category-list-dot {
    color: var(--bs-secondary-color);

    opacity: 0.5;
}


/* ============================================================
   ACTIONS
============================================================ */

.expense-category-modal .category-list-actions {
    display: flex;

    align-items: center;

    gap: 3px;

    flex-shrink: 0;
}

.expense-category-modal .category-list-action {
    width: 30px;
    height: 30px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 0;

    border: 0;

    border-radius: 7px;

    background: transparent;

    color: var(--bs-secondary-color);

    transition:
        background-color 0.15s ease,
        color 0.15s ease;
}

.expense-category-modal .category-list-action:hover {
    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);
}

.expense-category-modal .category-list-action.delete:hover {
    background: rgba(
        var(--bs-danger-rgb),
        0.10
    );

    color: var(--bs-danger);
}

.expense-category-modal .category-list-action i {
    font-size: 16px;
}


/* ============================================================
   EMPTY STATE
============================================================ */

.expense-category-modal .category-list-empty {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    padding: 25px 15px;

    text-align: left;
}

.expense-category-modal .category-list-empty-icon {
    width: 38px;
    height: 38px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: var(--bs-tertiary-bg);

    color: var(--bs-secondary-color);

    font-size: 18px;
}

.expense-category-modal .category-list-empty strong {
    display: block;

    color: var(--bs-body-color);

    font-size: 12px;
}

.expense-category-modal .category-list-empty small {
    display: block;

    margin-top: 2px;

    color: var(--bs-secondary-color);

    font-size: 10px;
}


/* ============================================================
   LOADING
============================================================ */

.expense-category-modal .category-list-loading {
    display: flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    padding: 25px;

    color: var(--bs-secondary-color);

    font-size: 11px;
}


/* ============================================================
   LOAD MORE
============================================================ */

.expense-category-modal .category-list-more {
    padding: 8px;

    text-align: center;

    border-top: 1px solid var(--bs-border-color);
}

.expense-category-modal .category-list-more .btn {
    font-size: 11px;
}


/* ============================================================
   MOBILE
============================================================ */

@media (max-width: 575.98px) {

    .expense-category-modal .category-list {
        max-height: 210px;
    }

    .expense-category-modal .category-list-category {
        max-width: 90px;
    }

    .expense-category-modal .category-list-item {
        padding: 8px 5px;
    }

    .expense-category-modal .category-list-icon {
        width: 32px;
        height: 32px;
        min-width: 32px;
    }

    .expense-category-modal .category-list-action {
        width: 28px;
        height: 28px;
    }

}


</style>

<script>
    /* ============================================================
   EXPENSE CATEGORY MODAL
   File:
   resources/views/content/accounts_finance/expenditure/js/modal.js
============================================================ */
(function ($) {

    'use strict';

    const CategoryModal = {

        modal: null,

        form: null,

        mode: 'create',

        categories: [],


        /* ============================================================
           INIT
        ============================================================ */

        init: function () {

            this.modal = $('#categoryModal');

            this.form = $('#categoryForm');

            if (
                !this.modal.length ||
                !this.form.length
            ) {
                return;
            }

            this.bindEvents();

            this.resetForm();

            this.loadCategories();

        },


        /* ============================================================
           EVENTS
        ============================================================ */

        bindEvents: function () {

            const self = this;


            /*
            |--------------------------------------------------------------------------
            | ADD
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '[data-bs-target="#categoryModal"], #btnAddCategory, .btn-add-category',
                function () {

                    self.openCreate();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | ICON CHANGE
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'change',
                '#category_icon',
                function () {

                    self.updateIconPreview();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | CATEGORY NAME
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'input',
                '#category_name',
                function () {

                    self.updatePreview();

                    self.clearFieldError('#category_name');

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SUBMIT
            |--------------------------------------------------------------------------
            */

            this.form.on(
                'submit',
                function (event) {

                    event.preventDefault();

                    self.submit();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | RESET
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '#btnResetCategory',
                function () {

                    self.resetForm();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SEARCH
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'input',
                '#categoryListSearch',
                function () {

                    self.filterCategoryList();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | CLEAR SEARCH
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '#categorySearchClear',
                function () {

                    $('#categoryListSearch')
                        .val('');

                    self.filterCategoryList();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EDIT
            |--------------------------------------------------------------------------
            */

            // $(document).on(
            //     'click',
            //     '.btn-edit-category',
            //     function (event) {

            //         event.preventDefault();

            //         const id = $(this).data('id');

            //         if (!id) {
            //             return;
            //         }

            //         self.openEdit(id);

            //     }
            // );

            $(document).on(
                'click',
                '[data-category-edit]',
                function () {

                    const id =
                        $(this).data('category-edit');

                    if (id) {

                        self.openEdit(
                            id
                        );

                    }

                }
            );

            $(document).on(
                'click',
                '[data-category-delete]',
                function () {

                    const id =
                        $(this).data('category-delete');

                    if (!id) {
                        return;
                    }


                    if (
                        typeof Swal === 'undefined'
                    ) {

                        if (
                            confirm(
                                'Delete this expense category?'
                            )
                        ) {

                            self.delete(
                                id
                            );

                        }

                        return;
                    }


                    Swal.fire({

                        title: 'Delete Category?',

                        text:
                            'This category will no longer be available for new expenses.',

                        icon: 'warning',

                        showCancelButton: true,

                        confirmButtonText: 'Delete',

                        cancelButtonText: 'Cancel',

                        reverseButtons: true

                    }).then(
                        function (result) {

                            if (result.isConfirmed) {

                                self.delete(
                                    id
                                );

                            }

                        }
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | DELETE
            |--------------------------------------------------------------------------
            */

            // $(document).on(
            //     'click',
            //     '.btn-delete-category',
            //     function (event) {

            //         event.preventDefault();

            //         const id = $(this).data('id');

            //         if (!id) {
            //             return;
            //         }

            //         self.delete(id);

            //     }
            // );


            /*
            |--------------------------------------------------------------------------
            | MODAL OPEN
            |--------------------------------------------------------------------------
            */

            this.modal.on(
                'shown.bs.modal',
                function () {

                    self.loadCategories();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | MODAL CLOSED
            |--------------------------------------------------------------------------
            */

            this.modal.on(
                'hidden.bs.modal',
                function () {

                    self.resetForm();

                }
            );

        },


        /* ============================================================
           CREATE
        ============================================================ */

        openCreate: function () {

            this.mode = 'create';

            this.resetForm();

            $('#categoryFormMode')
                .val('create');

            $('#categoryModalLabel').text('Manage Expense Category');
            $('#categoryModelTitleLabel').text('Add Expense Category');

            $('#categorySaveText')
                .text('Save Category');

            $('#categorySaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-outline me-1'
                );

                  console.log(' before loadcate')

            this.showModal();
            this.loadCategories();

        },


        /* ============================================================
           EDIT
        ============================================================ */

        openEdit: function (id) {

            const self = this;

            this.mode = 'edit';

            this.clearValidation();

            this.setLoading(true);

            $('#categoryFormMode')
                .val('edit');

            $('#category_id')
                .val(id);

            $('#categoryModalLabel').text('Manage Expense Category');
            $('#categoryModelTitleLabel').text('Edit Expense Category');

            $('#categorySaveText')
                .text('Update Category');

            $('#categorySaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-edit-outline me-1'
                );

            this.showModal();


            const url = this.getShowUrl(id);

            if (!url) {

                this.setLoading(false);

                this.showError(
                    'Category URL is not configured.'
                );

                return;

            }


            $.ajax({

                url: url,

                type: 'GET',

                dataType: 'json',

                success: function (response) {

                    if (
                        !response ||
                        response.success !== true ||
                        !response.data
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to load category.'
                        );

                        return;

                    }

                    self.fillForm(
                        response.data
                    );

                },

                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to load category.'
                    );

                },

                complete: function () {

                    self.setLoading(false);

                }

            });

        },


        /* ============================================================
           FILL FORM
        ============================================================ */

        fillForm: function (data) {

            $('#category_id')
                .val(
                    data.sno ||
                    data.id ||
                    ''
                );


            $('#category_name')
                .val(
                    data.category_name ||
                    ''
                );


            $('#category_icon')
                .val(
                    data.icon ||
                    'mdi-shape-outline'
                )
                .trigger('change');


            this.updateIconPreview();

            this.updatePreview();

        },


        /* ============================================================
           SUBMIT
        ============================================================ */

        submit: function () {

            const self = this;

            this.clearValidation();


            if (!this.validateClientSide()) {
                return;
            }


            const id =
                $('#category_id').val();


            let url;

            if (
                this.mode === 'edit' &&
                id
            ) {

                url =
                    this.getUpdateUrl(id);

            } else {

                url =
                    this.getStoreUrl();

            }


            if (!url) {

                this.showError(
                    'Category URL is not configured.'
                );

                return;

            }


            this.setLoading(true);


            $.ajax({

                url: url,

                type: 'POST',

                data: this.form.serialize(),

                dataType: 'json',


                success: function (response) {

                    if (
                        !response ||
                        response.success !== true
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to save category.'
                        );

                        return;

                    }


                    const isEdit =
                        self.mode === 'edit';


                    self.showSuccess(
                        response.message ||
                        (
                            isEdit
                                ? 'Category updated successfully.'
                                : 'Category created successfully.'
                        )
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT
                    | Do NOT close modal after success.
                    |--------------------------------------------------------------------------
                    */

                    self.loadCategories();


                    /*
                    |--------------------------------------------------------------------------
                    | Reset for next entry
                    |--------------------------------------------------------------------------
                    */

                    self.resetForm();


                    /*
                    |--------------------------------------------------------------------------
                    | Keep modal in CREATE mode
                    |--------------------------------------------------------------------------
                    */

                    self.mode = 'create';


                    $('#categoryFormMode')
                        .val('create');


                    $('#categoryModalLabel').text('Manage Expense Category');
                    $('#categoryModelTitleLabel').text('Add Expense Category');


                    $('#categorySaveText')
                        .text('Save Category');


                    $('#categorySaveIcon')
                        .attr(
                            'class',
                            'mdi mdi-content-save-outline me-1'
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | Refresh main expense category select
                    |--------------------------------------------------------------------------
                    */

                    self.refreshExpenseCategories();

                },


                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to save category.'
                    );

                },


                complete: function () {

                    self.setLoading(false);

                }

            });

        },


        /* ============================================================
           VALIDATION
        ============================================================ */

        validateClientSide: function () {

            let valid = true;


            const name =
                $.trim(
                    $('#category_name').val()
                );


            const icon =
                $.trim(
                    $('#category_icon').val()
                );


            if (!name) {

                this.setFieldError(
                    '#category_name',
                    'Category name is required.'
                );

                valid = false;

            } else if (
                name.length > 250
            ) {

                this.setFieldError(
                    '#category_name',
                    'Category name cannot exceed 250 characters.'
                );

                valid = false;

            }


            if (!icon) {

                this.setFieldError(
                    '#category_icon',
                    'Please select a category icon.'
                );

                valid = false;

            }


            return valid;

        },


        /* ============================================================
           FIELD ERROR
        ============================================================ */

        setFieldError: function (
            selector,
            message
        ) {

            const field =
                $(selector);

            field.addClass(
                'is-invalid'
            );


            let errorElement =
                $();


            if (
                selector === '#category_name'
            ) {

                errorElement =
                    $('.category_name_error');

            } else if (
                selector === '#category_icon'
            ) {

                errorElement =
                    $('.category_icon_error');

            }


            if (
                errorElement.length
            ) {

                errorElement
                    .text(message)
                    .addClass('d-block');

            }

        },


        clearFieldError: function (
            selector
        ) {

            $(selector)
                .removeClass('is-invalid');


            if (
                selector === '#category_name'
            ) {

                $('.category_name_error')
                    .text('');

            }

            if (
                selector === '#category_icon'
            ) {

                $('.category_icon_error')
                    .text('');

            }

        },


        /* ============================================================
           CLEAR VALIDATION
        ============================================================ */

        clearValidation: function () {

            this.form
                .find('.is-invalid')
                .removeClass('is-invalid');


            $('.category_name_error')
                .text('');


            $('.category_icon_error')
                .text('');

        },


        /* ============================================================
           AJAX ERROR
        ============================================================ */

        handleAjaxError: function (
            xhr,
            fallbackMessage
        ) {

            if (
                xhr.status === 422 &&
                xhr.responseJSON &&
                xhr.responseJSON.errors
            ) {

                this.showValidationErrors(
                    xhr.responseJSON.errors
                );


                if (
                    xhr.responseJSON.message
                ) {

                    this.showError(
                        xhr.responseJSON.message
                    );

                }

                return;

            }


            this.showError(
                xhr.responseJSON?.message ||
                fallbackMessage
            );

        },


        /* ============================================================
           SERVER VALIDATION
        ============================================================ */

        showValidationErrors: function (
            errors
        ) {

            const self = this;


            $.each(
                errors,
                function (
                    field,
                    messages
                ) {

                    if (
                        !Array.isArray(messages)
                    ) {

                        messages = [
                            messages
                        ];

                    }


                    const selector =
                        '#' + field;


                    if (
                        $(selector).length
                    ) {

                        self.setFieldError(
                            selector,
                            messages[0]
                        );

                    }

                }
            );

        },


        /* ============================================================
           ICON PREVIEW
        ============================================================ */

        updateIconPreview: function () {

            const icon =
                $('#category_icon').val() ||
                'mdi-shape-outline';


            $('#categoryIconPreview')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            $('#categoryPreviewIcon')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            $('#categoryModalIcon')
                .attr(
                    'class',
                    'mdi ' +
                    icon
                );


            $('#categorySelectedIcon')
                .attr(
                    'title',
                    icon
                );

        },


        /* ============================================================
           PREVIEW
        ============================================================ */

        updatePreview: function () {

            const name =
                $.trim(
                    $('#category_name').val()
                );


            $('#categoryPreviewName')
                .text(
                    name ||
                    'New Expense Category'
                );


            /*
            |--------------------------------------------------------------------------
            | Preview only.
            | Backend remains authoritative for actual category_code.
            |--------------------------------------------------------------------------
            */

            const previewCode =
                this.generatePreviewCode(
                    name
                );


            $('#categoryPreviewCode')
                .text(
                    previewCode ||
                    'AUTO GENERATED'
                );

        },


        generatePreviewCode: function (
            name
        ) {

            if (!name) {
                return '';
            }


            return name
                .trim()
                .toUpperCase()
                .replace(/[^A-Z0-9]+/g, '_')
                .replace(/^_+|_+$/g, '')
                .substring(0, 200);

        },


        /* ============================================================
           RESET
        ============================================================ */

        resetForm: function () {

            if (
                !this.form ||
                !this.form.length
            ) {
                return;
            }


            this.form[0].reset();


            $('#category_id')
                .val('');


            $('#categoryFormMode')
                .val('create');


            $('#category_name')
                .val('');


            $('#category_icon')
                .val(
                    'mdi-shape-outline'
                )
                .trigger('change');


            this.mode =
                'create';


            this.clearValidation();


            this.updateIconPreview();

            this.updatePreview();


            $('#categoryModalLabel').text('Manage Expense Category');
            $('#categoryModelTitleLabel').text('Add Expense Category');


            $('#categorySaveText')
                .text(
                    'Save Category'
                );


            $('#categorySaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-outline me-1'
                );


            this.setLoading(false);

        },


        /* ============================================================
           LOADING
        ============================================================ */

        setLoading: function (
            loading
        ) {

            if (loading) {

                this.modal
                    .addClass('is-loading');


                $('#btnSaveCategory')
                    .prop(
                        'disabled',
                        true
                    );


                $('#btnResetCategory')
                    .prop(
                        'disabled',
                        true
                    );


                $('#categoryLoader')
                    .removeClass('d-none');


                $('#categorySaveIcon')
                    .addClass('d-none');

            } else {

                this.modal
                    .removeClass('is-loading');


                $('#btnSaveCategory')
                    .prop(
                        'disabled',
                        false
                    );


                $('#btnResetCategory')
                    .prop(
                        'disabled',
                        false
                    );


                $('#categoryLoader')
                    .addClass('d-none');


                $('#categorySaveIcon')
                    .removeClass('d-none');

            }

        },


        /* ============================================================
           SHOW MODAL
        ============================================================ */

        showModal: function () {

            const element =
                document.getElementById(
                    'categoryModal'
                );


            if (!element) {
                return;
            }


            bootstrap.Modal
                .getOrCreateInstance(
                    element
                )
                .show();

        },


        /* ============================================================
           LOAD CATEGORY LIST
        ============================================================ */

        loadCategories: function () {
            

            const self = this;

            const $loading = $('#categoryListLoading');
            const $empty = $('#categoryListEmpty');
            const $list = $('#categoryList');
            const $more = $('#categoryListMore');

            $loading.removeClass('d-none');
            $empty.addClass('d-none');
            $more.addClass('d-none');

            $list.empty();


            /*
            |--------------------------------------------------------------------------
            | Use dedicated category list endpoint
            |--------------------------------------------------------------------------
            */

            if (
                !window.expenseRoutes ||
                !window.expenseRoutes.categories
            ) {

                $loading.addClass('d-none');

                $empty
                    .removeClass('d-none')
                    .find('strong')
                    .text('Category list unavailable.');

                return;
            }

            
            $.ajax({
                url: window.expenseRoutes.categories,
                type: 'GET',
                dataType: 'json',
                success: function (response) {

                    const categories =
                        response &&
                        response.success &&
                        Array.isArray(response.data)
                            ? response.data
                            : [];

                    self.productListData =
                        categories;

                    self.renderCategoryList(
                        categories
                    );

                },

                error: function (xhr) {

                    console.error(
                        'Category list error:',
                        xhr.responseText
                    );

                    $empty.removeClass('d-none');

                    $empty.find('strong')
                        .text('Unable to load categories.');

                    $empty.find('small')
                        .text('Please try again.');

                },

                complete: function () {

                    $loading.addClass('d-none');

                }

            });

        },

        /* ============================================================
        RENDER PRODUCT LIST
        ============================================================ */

        renderCategoryList: function (
            categories
        ) {
            console.log('categories render')

            const $list =
                $('#categoryList');

            const $empty =
                $('#categoryListEmpty');

            const search =
                $.trim(
                    $('#categoryListSearch').val()
                ).toLowerCase();


            let filtered = categories.filter(function (category) {

                    if (!search) {
                        return true;
                    }

                    const name =
                        String(
                            category.category_name || ''
                        ).toLowerCase();

                  

                    const code =
                        String(
                            category.category_code || ''
                        ).toLowerCase();

                    return (
                        name.includes(search) ||
                        code.includes(search)
                    );

                });


            $('#categoryListCount')
                .text(filtered.length);


            if (!filtered.length) {

                $list.empty();

                $empty.removeClass('d-none');

                return;
            }


            $empty.addClass('d-none');

            let html = '';

            filtered.forEach(
                function (category) {

                    const id =
                        Number(category.sno || 0);

                    if (!id) {
                        return;
                    }

                    


                    const name =
                        self.escapeHtml(
                            category.category_name ||
                            'Unnamed Category'
                        );


                    const code =
                        self.escapeHtml(
                            category.category_code ||
                            'AUTO'
                        );


                    let icon =
                        category.icon ||
                        'mdi-package-variant-closed';


                    if (
                        !icon.includes('mdi ')
                    ) {

                        if (
                            icon.indexOf('mdi-') === 0
                        ) {

                            icon =
                                'mdi ' + icon;

                        }

                    }


                    icon =
                        CategoryModal.escapeHtml(
                            icon
                        );


                   



                    html += `

                        <div class="category-list-item" data-category-id="${id}">
                            <div class="category-list-icon">
                                <i class="${icon}"></i>
                            </div>
                            <div class="category-list-content">
                                <div class="category-list-name" title="${name}">
                                    ${name}
                                </div>
                                <div class="category-list-meta">
                                    <span class="category-list-code">
                                        ${code}
                                    </span>
                                </div>
                            </div>
                            <div class="category-list-actions">
                                <button
                                    type="button"
                                    class="category-list-action btn-edit-category"
                                    data-category-edit="${id}"
                                    title="Edit Category">

                                    <i class="mdi mdi-pencil-outline"></i>

                                </button>


                                <button
                                    type="button"
                                    class="category-list-action delete btn-delete-category"
                                    data-category-delete="${id}"
                                    title="Delete Category">

                                    <i class="mdi mdi-delete-outline"></i>

                                </button>

                            </div>

                        </div>

                    `;

                }
            );


            $list.html(html);

        },

       


        /* ============================================================
           RENDER CATEGORY LIST
        ============================================================ */



        /* ============================================================
           SEARCH CATEGORY LIST
        ============================================================ */

        filterCategoryList: function () {

            const search =
                $.trim(
                    $('#categoryListSearch')
                        .val()
                ).toLowerCase();


            const $items =
                $('#expenseCategoryList')
                    .find('.category-list-item');


            $('#categorySearchClear')
                .toggleClass(
                    'd-none',
                    !search
                );


            let visible = 0;


            $items.each(
                function () {

                    const name =
                        String(
                            $(this)
                                .data(
                                    'category-name'
                                ) ||
                            ''
                        ).toLowerCase();


                    const match =
                        !search ||
                        name.includes(search);


                    $(this)
                        .toggle(match);


                    if (match) {
                        visible++;
                    }

                }
            );


            if (
                search &&
                visible === 0
            ) {

                $('#expenseCategoryList')
                    .find('.category-search-empty')
                    .remove();


                $('#expenseCategoryList')
                    .append(`
                        <div class="category-list-empty category-search-empty">
                            <i class="mdi mdi-magnify-close"></i>
                            <span>No matching category found.</span>
                        </div>
                    `);

            } else {

                $('#expenseCategoryList')
                    .find('.category-search-empty')
                    .remove();

            }

        },


        /* ============================================================
           DELETE
        ============================================================ */

        delete: function (id) {

            const self = this;


            if (
                !window.confirm(
                    'Are you sure you want to delete this expense category?'
                )
            ) {
                return;
            }


            const url =
                this.getDeleteUrl(id);


            if (!url) {

                this.showError(
                    'Delete URL is not configured.'
                );

                return;

            }


            $.ajax({

                url: url,

                type: 'DELETE',

                data: {
                    _token:
                        this.getCsrfToken()
                },

                dataType: 'json',


                success: function (response) {

                    if (
                        !response ||
                        response.success !== true
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to delete category.'
                        );

                        return;

                    }


                    self.showSuccess(
                        response.message ||
                        'Category deleted successfully.'
                    );


                    self.loadCategories();

                    self.refreshExpenseCategories();

                },


                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to delete category.'
                    );

                }

            });

        },


        /* ============================================================
           REFRESH EXPENSE CATEGORY SELECT
        ============================================================ */

        refreshExpenseCategories: function () {

            /*
            |--------------------------------------------------------------------------
            | Existing ExpenseModal loader
            |--------------------------------------------------------------------------
            */

            if (
                window.expenseModal &&
                typeof window.expenseModal.loadCategories ===
                    'function'
            ) {

                window.expenseModal
                    .loadCategories();

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | Fallback: directly refresh #category_id
            |--------------------------------------------------------------------------
            */

            const url =
                window.expenseRoutes &&
                window.expenseRoutes.categories;


            if (!url) {
                return;
            }


            $.get(
                url,
                function (response) {

                    if (
                        !response ||
                        !Array.isArray(
                            response.data
                        )
                    ) {
                        return;
                    }


                    let html =
                        '<option value="">Select Category</option>';


                    response.data.forEach(
                        function (category) {

                            html += `
                                <option value="${category.sno}">
                                    ${CategoryModal.escapeHtml(
                                        category.category_name
                                    )}
                                </option>
                            `;

                        }
                    );


                    $('#category_id')
                        .html(html)
                        .trigger('change.select2');

                }
            );

        },


        /* ============================================================
           URL HELPERS
        ============================================================ */

        getStoreUrl: function () {

            return (
                window.expenseRoutes &&
                window.expenseRoutes.categoryStore
            ) || '';

        },


        getShowUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.categoryShow
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        getUpdateUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.categoryUpdate
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        getDeleteUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.categoryDelete
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        /* ============================================================
           CSRF
        ============================================================ */

        getCsrfToken: function () {

            return (
                $('meta[name="csrf-token"]')
                    .attr('content')
            ) ||
            $('#categoryForm input[name="_token"]')
                .val();

        },


        /* ============================================================
           SAFE ICON
        ============================================================ */

        safeIcon: function (icon) {

            if (
                typeof icon !== 'string' ||
                !/^mdi-[a-z0-9-]+$/i.test(icon)
            ) {

                return 'mdi-shape-outline';

            }

            return icon;

        },


        /* ============================================================
           HTML ESCAPE
        ============================================================ */

        escapeHtml: function (value) {

            return $('<div>')
                .text(
                    value == null
                        ? ''
                        : String(value)
                )
                .html();

        },


        escapeHtmlAttribute: function (value) {

            return this
                .escapeHtml(value)
                .replace(/"/g, '&quot;');

        },


        /* ============================================================
           SUCCESS
        ============================================================ */

        showSuccess: function (
            message
        ) {

            if (
                typeof window.showToast ===
                'function'
            ) {

                window.showToast(
                    'success',
                    message
                );

                return;

            }


            if (
                typeof window.toastr !==
                'undefined'
            ) {

                window.toastr.success(
                    message
                );

                return;

            }

        },


        /* ============================================================
           ERROR
        ============================================================ */

        showError: function (
            message
        ) {

            if (
                typeof window.showToast ===
                'function'
            ) {

                window.showToast(
                    'error',
                    message
                );

                return;

            }


            if (
                typeof window.toastr !==
                'undefined'
            ) {

                window.toastr.error(
                    message
                );

                return;

            }


            console.error(message);

        }

    };


    /*
    |--------------------------------------------------------------------------
    | GLOBAL
    |--------------------------------------------------------------------------
    */

    window.CategoryModal =
        CategoryModal;


    /*
    |--------------------------------------------------------------------------
    | READY
    |--------------------------------------------------------------------------
    */

    $(function () {

        CategoryModal.init();

    });


})(jQuery);
</script>

<script>
    function icon_chnage_func () {

            const icon =
                $('#category_icon').val() ||
                'mdi-shape-outline';


            $('#categoryIconPreview')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            $('#categoryPreviewIcon')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            $('#categoryModalIcon')
                .attr(
                    'class',
                    'mdi ' + icon + ' fs-4'
                );


            $('#categorySelectedIcon')
                .attr(
                    'title',
                    icon
                );

    }
</script>
