{{-- ============================================================
    CREDIT CARD MODAL
    Table: egc_acc_tiderc_drac

    Purpose:
    - Create Credit Card
    - Edit Credit Card
    - Securely enter card reference parts
    - Company -> Entity dependency
============================================================ --}}

<div
    class="modal fade expense-credit-card-modal"
    id="creditCardModal"
    tabindex="-1"
    aria-labelledby="creditCardModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">

        <div class="modal-content">

            {{-- =================================================
                HEADER
            ================================================== --}}

            <div class="modal-header border-bottom">

                <div class="d-flex align-items-center">

                    <div class="avatar avatar-md bg-label-primary me-3">

                        <i class="mdi mdi-credit-card-outline fs-4"></i>

                    </div>

                    <div>

                        <h5
                            class="modal-title mb-1"
                            id="creditCardModalLabel">

                            Add Credit Card

                        </h5>

                        <small class="text-muted">

                            Securely manage company credit card details

                        </small>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================== --}}

            <form
                id="creditCardForm"
                method="POST"
                autocomplete="off">

                @csrf

                <input
                    type="hidden"
                    name="credit_card_id"
                    id="credit_card_id"
                    value="">

                <input
                    type="hidden"
                    name="form_mode"
                    id="creditCardFormMode"
                    value="create">


                <div class="modal-body">

                    {{-- =========================================
                        CARD CONFIGURATION
                    ========================================== --}}

                    <div class="card shadow-none border mb-4">

                        <div class="card-header bg-white">

                            <div class="d-flex align-items-center">

                                <div class="avatar avatar-sm bg-label-primary me-3">

                                    <i class="mdi mdi-bank-outline"></i>

                                </div>

                                <div>

                                    <h6 class="mb-0 fw-semibold">

                                        Card Configuration

                                    </h6>

                                    <small class="text-muted">

                                        Select the company and entity where
                                        this card belongs

                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="card-body">

                            <div class="row g-4">

                                {{-- Company --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_company_id"
                                        class="form-label required">

                                        Company

                                    </label>

                                    <select
                                        class="form-select select2 expense-modal-select"
                                        id="credit_card_company_id"
                                        name="company_id"
                                        data-placeholder="Select Company">

                                        <option value="">

                                            Select Company

                                        </option>

                                    </select>

                                    <div
                                        class="invalid-feedback company_id_error">
                                    </div>

                                </div>


                                {{-- Entity --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_entity_id"
                                        class="form-label required">

                                        Entity

                                    </label>

                                    <select
                                        class="form-select select2 expense-modal-select"
                                        id="credit_card_entity_id"
                                        name="entity_id"
                                        data-placeholder="Select Entity"
                                        disabled>

                                        <option value="">

                                            Select Entity

                                        </option>

                                    </select>

                                    <div
                                        class="invalid-feedback entity_id_error">
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =========================================
                        BANK & CARD INFORMATION
                    ========================================== --}}

                    <div class="card shadow-none border mb-4">

                        <div class="card-header bg-white">

                            <div class="d-flex align-items-center">

                                <div class="avatar avatar-sm bg-label-info me-3">

                                    <i class="mdi mdi-bank-outline"></i>

                                </div>

                                <div>

                                    <h6 class="mb-0 fw-semibold">

                                        Bank & Card Information

                                    </h6>

                                    <small class="text-muted">

                                        Enter the basic card information

                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="card-body">

                            <div class="row g-4">

                                {{-- Bank Name --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_bank_name"
                                        class="form-label required">

                                        Bank Name

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">

                                            <i class="mdi mdi-bank-outline"></i>

                                        </span>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="credit_card_bank_name"
                                            name="b_name"
                                            maxlength="150"
                                            placeholder="Enter bank name">

                                    </div>

                                    <div
                                        class="invalid-feedback b_name_error">
                                    </div>

                                </div>


                                {{-- Card Holder --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_holder"
                                        class="form-label required">

                                        Card Holder Name

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">

                                            <i class="mdi mdi-account-outline"></i>

                                        </span>

                                        <input
                                            type="text"
                                            class="form-control text-uppercase"
                                            id="credit_card_holder"
                                            name="rd_prsn_name"
                                            maxlength="150"
                                            placeholder="Name on card">

                                    </div>

                                    <div
                                        class="invalid-feedback rd_prsn_name_error">
                                    </div>

                                </div>


                                {{-- Card Name --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_name"
                                        class="form-label">

                                        Card Name

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">

                                            <i class="mdi mdi-credit-card-outline"></i>

                                        </span>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="credit_card_name"
                                            name="rd_name"
                                            maxlength="150"
                                            placeholder="e.g. Corporate Card">

                                    </div>

                                    <div
                                        class="invalid-feedback rd_name_error">
                                    </div>

                                </div>


                                {{-- Card Type --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_type"
                                        class="form-label required">

                                        Card Type

                                    </label>

                                    <div class="card-type-select" id="cardTypeSelect">

                                        <button type="button" class="card-type-selected">
                                            <span class="card-type-placeholder">
                                                Select Card Type
                                            </span>

                                            <i class="mdi mdi-chevron-down"></i>
                                        </button>

                                        <div class="card-type-dropdown">

                                            <div class="card-type-option"
                                                data-value="Visa"
                                                data-image="/assets/social_media/visa.png">

                                                <img src="/assets/social_media/visa.png"
                                                    alt="Visa">

                                                <span>Visa</span>
                                            </div>

                                            <div class="card-type-option"
                                                data-value="Mastercard"
                                                data-image="/assets/social_media/mastercard.png">

                                                <img src="/assets/social_media/mastercard.png"
                                                    alt="Mastercard">

                                                <span>Mastercard</span>
                                            </div>

                                            <div class="card-type-option"
                                                data-value="RuPay"
                                                data-image="/assets/social_media/rupay.png">

                                                <img src="/assets/social_media/rupay.png"
                                                    alt="RuPay">

                                                <span>RuPay</span>
                                            </div>

                                            <div class="card-type-option"
                                                data-value="American Express"
                                                data-image="/assets/social_media/american-express.png">

                                                <img src="/assets/social_media/american-express.png"
                                                    alt="American Express">

                                                <span>American Express</span>
                                            </div>

                                            <div class="card-type-option"
                                                data-value="Other">

                                                <span class="card-type-other-icon">
                                                    <i class="mdi mdi-credit-card-outline"></i>
                                                </span>

                                                <span>Other</span>
                                            </div>

                                        </div>

                                        <!-- Actual form value -->
                                        <input type="hidden"
                                            name="type"
                                            id="credit_card_type"
                                            value="">

                                    </div>

                                    <div
                                        class="invalid-feedback type_error">
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =========================================
                        SECURE CARD REFERENCE
                    ========================================== --}}

                    <div class="card shadow-none border mb-4">

                        <div class="card-header bg-white">

                            <div class="d-flex align-items-center">

                                <div class="avatar avatar-sm bg-label-warning me-3">

                                    <i class="mdi mdi-lock-outline"></i>

                                </div>

                                <div>

                                    <h6 class="mb-0 fw-semibold">

                                        Secure Card Reference

                                    </h6>

                                    <small class="text-muted">

                                        Enter the card reference as five
                                        separate secure parts

                                    </small>

                                </div>

                                <div class="ms-auto">

                                    <span class="badge bg-label-success">

                                        <i class="mdi mdi-shield-check-outline me-1"></i>

                                        Secure Entry

                                    </span>

                                </div>

                            </div>

                        </div>


                        <div class="card-body">

                            <div class="secure-card-entry">

                                <div class="secure-card-entry-label">

                                    <i class="mdi mdi-credit-card-outline me-2"></i>

                                    Card Reference

                                </div>


                                <div class="secure-card-parts">

                                    {{-- Part 1 --}}

                                    <div class="secure-card-part">

                                        <label
                                            for="rd_prt1"
                                            class="visually-hidden">

                                            Card Part 1

                                        </label>

                                        <input
                                            type="password"
                                            inputmode="numeric"
                                            pattern="[0-9]*"
                                            maxlength="4"
                                            class="form-control credit-card-part-input"
                                            id="rd_prt1"
                                            name="rd_prt1"
                                            autocomplete="off"
                                            placeholder="0000">

                                    </div>


                                    <span class="secure-card-separator">

                                        ••••

                                    </span>


                                    {{-- Part 2 --}}

                                    <div class="secure-card-part">

                                        <label
                                            for="rd_prt2"
                                            class="visually-hidden">

                                            Card Part 2

                                        </label>

                                        <input
                                            type="password"
                                            inputmode="numeric"
                                            pattern="[0-9]*"
                                            maxlength="4"
                                            class="form-control credit-card-part-input"
                                            id="rd_prt2"
                                            name="rd_prt2"
                                            autocomplete="off"
                                            placeholder="0000">

                                    </div>


                                    <span class="secure-card-separator">

                                        ••••

                                    </span>


                                    {{-- Part 3 --}}

                                    <div class="secure-card-part">

                                        <label
                                            for="rd_prt3"
                                            class="visually-hidden">

                                            Card Part 3

                                        </label>

                                        <input
                                            type="password"
                                            inputmode="numeric"
                                            pattern="[0-9]*"
                                            maxlength="4"
                                            class="form-control credit-card-part-input"
                                            id="rd_prt3"
                                            name="rd_prt3"
                                            autocomplete="off"
                                            placeholder="0000">

                                    </div>


                                    <span class="secure-card-separator">

                                        ••••

                                    </span>


                                    {{-- Part 4 --}}

                                    <div class="secure-card-part">

                                        <label
                                            for="rd_prt4"
                                            class="visually-hidden">

                                            Card Part 4

                                        </label>

                                        <input
                                            type="password"
                                            inputmode="numeric"
                                            pattern="[0-9]*"
                                            maxlength="4"
                                            class="form-control credit-card-part-input"
                                            id="rd_prt4"
                                            name="rd_prt4"
                                            autocomplete="off"
                                            placeholder="0000">

                                    </div>


                                    <span class="secure-card-separator">

                                        ••••

                                    </span>


                                    {{-- Part 5 --}}

                                    <div class="secure-card-part">

                                        <label
                                            for="rd_prt5"
                                            class="visually-hidden">

                                            Card Part 5

                                        </label>

                                        <input
                                            type="password"
                                            inputmode="numeric"
                                            pattern="[0-9]*"
                                            maxlength="4"
                                            class="form-control credit-card-part-input"
                                            id="rd_prt5"
                                            name="rd_prt5"
                                            autocomplete="off"
                                            placeholder="0000">

                                    </div>

                                </div>


                                <div class="secure-card-helper mt-3">

                                    <div>

                                        <i class="mdi mdi-information-outline me-1"></i>

                                        Each section accepts numbers only.

                                    </div>

                                    <div>

                                        <i class="mdi mdi-lock-outline me-1"></i>

                                        Values are handled separately.

                                    </div>

                                </div>

                            </div>


                            <div
                                class="invalid-feedback d-block rd_prt_error"
                                id="creditCardPartsError">
                            </div>

                        </div>

                    </div>


                    {{-- =========================================
                        BILLING / REFERENCE
                    ========================================== --}}

                    <div class="card shadow-none border mb-0">

                        <div class="card-header bg-white">

                            <div class="d-flex align-items-center">

                                <div class="avatar avatar-sm bg-label-success me-3">

                                    <i class="mdi mdi-calendar-currency-usd"></i>

                                </div>

                                <div>

                                    <h6 class="mb-0 fw-semibold">

                                        Billing & Reference

                                    </h6>

                                    <small class="text-muted">

                                        Payment due information and
                                        internal reference

                                    </small>

                                </div>

                            </div>

                        </div>


                        <div class="card-body">

                            <div class="row g-4">

                                {{-- Due Date --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_due_date"
                                        class="form-label">

                                        Due Date

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">

                                            <i class="mdi mdi-calendar-outline"></i>

                                        </span>

                                        <input
                                            type="text"
                                            class="form-control expense-flatpickr"
                                            id="credit_card_due_date"
                                            name="due"
                                            placeholder="Select due date">

                                    </div>

                                    <div
                                        class="invalid-feedback due_error">
                                    </div>

                                </div>


                                {{-- Reference Number --}}

                                <div class="col-md-6">

                                    <label
                                        for="credit_card_reference"
                                        class="form-label">

                                        Reference Number

                                    </label>

                                    <div class="input-group">

                                        <span class="input-group-text">

                                            <i class="mdi mdi-pound"></i>

                                        </span>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="credit_card_reference"
                                            name="vv_no"
                                            maxlength="50"
                                            placeholder="Internal reference">

                                    </div>

                                    <div
                                        class="invalid-feedback vv_no_error">
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER
                ================================================== --}}

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        <i class="mdi mdi-close me-1"></i>

                        Cancel

                    </button>


                    <button
                        type="reset"
                        class="btn btn-label-warning"
                        id="btnResetCreditCard">

                        <i class="mdi mdi-refresh me-1"></i>

                        Reset

                    </button>


                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnSaveCreditCard">

                        <span
                            class="spinner-border spinner-border-sm me-2 d-none"
                            id="creditCardLoader">
                        </span>
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        <span id="creditCardSaveText">
                            Save Credit Card
                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>