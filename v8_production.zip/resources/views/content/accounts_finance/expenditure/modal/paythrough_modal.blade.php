

<div class="modal fade expense-paythrough-modal"  id="payThroughModal"  tabindex="-1"  aria-labelledby="payThroughModalLabel"  aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            {{-- =================================================
                HEADER
            ================================================== --}}
            <div class="modal-header">
                <div class="d-flex align-items-center">
                    <div class="avatar avatar-md bg-label-primary me-3">
                        <i  class="mdi mdi-shape-outline fs-4"
                            id="payThroughModalIcon">
                        </i>
                    </div>
                    <div>
                        <h5 class="modal-title mb-1" id="payThroughModalLabel">
                            Manage Expense Pay Through
                        </h5>
                        <small class="text-muted">
                            Create and manage expense Pay Through
                        </small>
                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================== --}}

            <form id="paythroughForm" method="POST" autocomplete="off">
                @csrf
                <input type="hidden" id="pay_through_id" name="pay_through_id" value="">
                <input type="hidden" id="paythroughFormMode" name="form_mode" value="create">
                <div class="modal-body">
                    <div class="fw-bold mb-2 fs-7" id="payThroughModelTitleLabel"> Add Expense Pay Through</div>
                    <!-- <div class="paythrough-preview mb-4"  id="payThroughPreview">

                        <div class="paythrough-preview-icon">

                            <i
                                class="mdi mdi-shape-outline"
                                id="payThroughPreviewIcon">
                            </i>

                        </div>

                        <div class="paythrough-preview-content">

                            <span class="paythrough-preview-label">

                                Pay Through Preview

                            </span>

                            

                            <small id="payThroughPreviewCode">
                                CODE
                            </small> 

                        </div>

                    </div> -->


        


                    {{-- =============================================
                        Pay Through NAME
                    ============================================== --}}

                    <div class="mb-4">
                        <label for="pay_through_name" class="form-label required">
                            Pay Through Name
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="mdi mdi-tag-outline"></i>
                            </span>
                            <input
                                type="text"
                                class="form-control"
                                id="pay_through_name"
                                name="pay_through_name"
                                maxlength="250"
                                placeholder="Enter Pay Through name"
                                autocomplete="off">

                        </div>

                        <div
                            class="invalid-feedback pay_through_name_error">
                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER  https://chatgpt.com/share/6a7737b8-2da0-83ee-9507-015cdc5e5179
                ================================================== --}} 

                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        <i class="mdi mdi-close me-1"></i>

                        Cancel

                    </button>


                    <button
                        type="reset"
                        class="btn btn-label-warning"
                        id="btnResetPayThrough">

                        <i class="mdi mdi-refresh me-1"></i>

                        Reset

                    </button>


                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnSavePayThrough">

                        <span
                            class="spinner-border spinner-border-sm me-2 d-none"
                            id="payThroughLoader">
                        </span>

                        <i
                            class="mdi mdi-content-save-outline me-1"
                            id="payThroughSaveIcon">
                        </i>

                        <span id="payThroughSaveText">

                            Save Pay Through

                        </span>

                    </button>

                </div>

                <div class="modal-body">
                    <div class="paythrough-list-panel mt-4">
                        <div class="paythrough-list-header">

                            <div>
                                <div class="paythrough-list-title">
                                    <i class="mdi mdi-format-list-bulleted me-1"></i>
                                    Existing Pay Through
                                </div>

                                <div class="paythrough-list-subtitle">
                                    Recently added expense Pay Through
                                </div>
                            </div>

                            <span class="paythrough-list-count"
                                id="payThroughListCount">
                                0
                            </span>

                        </div>
                        {{-- Search --}}
                        <div class="paythrough-list-search">
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <input
                                    type="text"
                                    class="form-control"
                                    id="payThroughListSearch"
                                    placeholder="Search Pay Through..."
                                    autocomplete="off">

                                <button
                                    type="button"
                                    class="btn btn-light d-none"
                                    id="payThroughSearchClear"
                                    aria-label="Clear search">

                                    <i class="mdi mdi-close"></i>

                                </button>

                            </div>

                        </div>
                        {{-- Loading --}}
                        <div id="payThroughListLoading" class="pay-through-list-loading">
                            <div class="spinner-border spinner-border-sm text-primary"></div>
                            <span>Loading Pay Through...</span>
                        </div>


                        {{-- Empty --}}
                        <div id="payThroughListEmpty" class="paythrough-list-empty d-none">
                            <div class="paythrough-list-empty-icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <div>
                                <strong>No Pay Through found</strong>
                                <small>
                                    Add your first expense Pay Through above.
                                </small>
                            </div>
                        </div>
                        {{-- Pay Through --}}
                        <div id="payThroughList" class="pay-through-list"></div>


                        {{-- Load more --}}

                        <div id="payThroughListMore" class="pay-through-list-more d-none">
                            <button type="button" class="btn btn-sm btn-label-secondary"
                                id="btnLoadMorePayThrough">
                                <i class="mdi mdi-chevron-down me-1"></i>
                                Load More
                            </button>
                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>

</div>
<style>
    /* ============================================================
   EXPENSE Pay Through MODAL
   File:
   expenditure/css/expenditure.css
============================================================ */


/* ============================================================
   MODAL
============================================================ */

.expense-paythrough-modal .modal-dialog {
    max-width: 560px;
}

.expense-paythrough-modal .modal-content {
    border: 0;
    border-radius: 0.75rem;
    overflow: hidden;
    box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.12);
}

.expense-paythrough-modal .modal-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}

.expense-paythrough-modal .modal-body {
    padding: 1.5rem;
    background-color: var(--bs-body-bg);
}

.expense-paythrough-modal .modal-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}


/* ============================================================
   HEADER AVATAR
============================================================ */

.expense-paythrough-modal .avatar {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.5rem;
}

.expense-paythrough-modal .avatar i {
    line-height: 1;
}


/* ============================================================
   Pay Through PREVIEW
============================================================ */

.expense-paythrough-modal .paythrough-preview {
    display: flex;
    align-items: center;
    gap: 1rem;

    padding: 1rem;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.625rem;

    background-color: var(--bs-tertiary-bg);

    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease,
        background-color 0.2s ease;
}

.expense-paythrough-modal .paythrough-preview:hover {
    border-color: rgba(
        var(--bs-primary-rgb),
        0.35
    );

    box-shadow: 0 0.25rem 0.75rem rgba(
        var(--bs-primary-rgb),
        0.06
    );
}


/* ============================================================
   PREVIEW ICON
============================================================ */

.expense-paythrough-modal .paythrough-preview-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.625rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.12
    );

    font-size: 1.5rem;

    transition:
        transform 0.2s ease,
        background-color 0.2s ease;
}

.expense-paythrough-modal .paythrough-preview:hover
.paythrough-preview-icon {
    transform: translateY(-1px);
}

.expense-paythrough-modal .paythrough-preview-icon i {
    line-height: 1;
}


/* ============================================================
   PREVIEW CONTENT
============================================================ */

.expense-paythrough-modal .paythrough-preview-content {
    min-width: 0;

    display: flex;
    flex-direction: column;
}

.expense-paythrough-modal .paythrough-preview-label {
    margin-bottom: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    font-weight: 600;

    letter-spacing: 0.04em;
    text-transform: uppercase;
}

.expense-paythrough-modal .paythrough-preview-content strong {
    overflow: hidden;

    color: var(--bs-body-color);

    font-size: 0.9375rem;
    font-weight: 600;

    line-height: 1.4;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.expense-paythrough-modal .paythrough-preview-content small {
    margin-top: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.75rem;
    font-weight: 500;

    letter-spacing: 0.04em;
    text-transform: uppercase;
}


/* ============================================================
   FORM LABEL
============================================================ */

.expense-paythrough-modal .form-label {
    margin-bottom: 0.5rem;

    color: var(--bs-body-color);

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-paythrough-modal .form-label.required::after {
    content: '*';

    margin-left: 0.25rem;

    color: var(--bs-danger);
}


/* ============================================================
   INPUT GROUP
============================================================ */

.expense-paythrough-modal .input-group-text {
    min-width: 42px;

    justify-content: center;

    color: var(--bs-secondary-color);
    background-color: var(--bs-tertiary-bg);

    border-color: var(--bs-border-color);
}

.expense-paythrough-modal .input-group-text i {
    font-size: 1.125rem;
}


/* ============================================================
   FORM CONTROLS
============================================================ */

.expense-paythrough-modal .form-control,
.expense-paythrough-modal .form-select {
    min-height: 42px;

    border-color: var(--bs-border-color);

    font-size: 0.8125rem;
}

.expense-paythrough-modal .form-control:focus,
.expense-paythrough-modal .form-select:focus {
    border-color: var(--bs-primary);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-primary-rgb),
        0.12
    );
}

.expense-paythrough-modal .form-control::placeholder {
    color: var(--bs-secondary-color);
    opacity: 0.7;
}





/* ============================================================
   ICON SELECTOR
============================================================ */

.expense-paythrough-modal .pay-through-icon-selector {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}


/* ============================================================
   SELECTED ICON
============================================================ */

.expense-paythrough-modal .pay-through-selected-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.5rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.375rem;

    transition:
        color 0.2s ease,
        background-color 0.2s ease,
        border-color 0.2s ease;
}

.expense-paythrough-modal .pay-through-selected-icon i {
    line-height: 1;
}


/* ============================================================
   ICON SELECT
============================================================ */

.expense-paythrough-modal #paythrough_icon {
    cursor: pointer;
}

.expense-paythrough-modal #paythrough_icon option {
    font-size: 0.8125rem;
}


/* ============================================================
   HELP TEXT
============================================================ */

.expense-paythrough-modal .form-text {
    margin-top: 0.375rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    line-height: 1.5;
}


/* ============================================================
   VALIDATION
============================================================ */

.expense-paythrough-modal .is-invalid {
    border-color: var(--bs-danger);
}

.expense-paythrough-modal .is-invalid:focus {
    border-color: var(--bs-danger);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-danger-rgb),
        0.12
    );
}

.expense-paythrough-modal .input-group
.is-invalid {
    z-index: 2;
}

.expense-paythrough-modal
.category_code_error,
.expense-paythrough-modal
.pay_through_name_error,
.expense-paythrough-modal
.paythrough_icon_error {
    font-size: 0.6875rem;
}


/* ============================================================
   FOOTER BUTTONS
============================================================ */

.expense-paythrough-modal .modal-footer .btn {
    min-height: 38px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-paythrough-modal .modal-footer .btn i {
    font-size: 1rem;
}


/* ============================================================
   SAVE BUTTON
============================================================ */

.expense-paythrough-modal #btnSavePayThrough {
    min-width: 145px;
}

.expense-paythrough-modal #payThroughLoader {
    width: 0.875rem;
    height: 0.875rem;

    border-width: 0.12rem;
}


/* ============================================================
   DISABLED STATE
============================================================ */

.expense-paythrough-modal .form-control:disabled,
.expense-paythrough-modal .form-select:disabled {
    cursor: not-allowed;

    background-color: var(--bs-secondary-bg);
}


/* ============================================================
   LOADING STATE
============================================================ */

.expense-paythrough-modal.is-loading {
    pointer-events: none;
}

.expense-paythrough-modal.is-loading .modal-content {
    opacity: 0.72;
}


/* ============================================================
   DARK MODE
   Uses Bootstrap / ERP variables.
   No separate brand color required.
============================================================ */

[data-bs-theme='dark']
.expense-paythrough-modal .paythrough-preview {
    background-color: var(--bs-tertiary-bg);
}

[data-bs-theme='dark']
.expense-paythrough-modal .paythrough-preview-icon,
[data-bs-theme='dark']
.expense-paythrough-modal .pay-through-selected-icon {
    background-color: rgba(
        var(--bs-primary-rgb),
        0.16
    );
}


/* ============================================================
   RESPONSIVE
============================================================ */

@media (max-width: 575.98px) {

    .expense-paythrough-modal .modal-dialog {
        margin: 0.75rem;
    }

    .expense-paythrough-modal .modal-header {
        padding: 1rem;
    }

    .expense-paythrough-modal .modal-body {
        padding: 1rem;
    }

    .expense-paythrough-modal .modal-footer {
        padding: 0.875rem 1rem;

        flex-wrap: wrap;
    }

    .expense-paythrough-modal .modal-footer .btn {
        flex: 1 1 auto;
    }

    .expense-paythrough-modal .paythrough-preview {
        padding: 0.875rem;
    }

}


/* ============================================================
   VERY SMALL DEVICES
============================================================ */

@media (max-width: 375px) {

    .expense-paythrough-modal .pay-through-icon-selector {
        align-items: stretch;
    }

    .expense-paythrough-modal .pay-through-selected-icon {
        width: 40px;
        min-width: 40px;
    }

    .expense-paythrough-modal .modal-footer {
        gap: 0.5rem;
    }

    .expense-paythrough-modal .modal-footer .btn {
        width: 100%;
        flex: 1 1 100%;
    }

}

/* ============================================================
   PRODUCT LIST
============================================================ */

.expense-paythrough-modal .paythrough-list-panel {
    border: 1px solid var(--bs-border-color);
    border-radius: 12px;
    background: var(--bs-body-bg);
    overflow: hidden;
}


/* ============================================================
   LIST HEADER
============================================================ */

.expense-paythrough-modal .paythrough-list-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 12px 14px;

    border-bottom: 1px solid var(--bs-border-color);

    background: var(--bs-tertiary-bg);
}

.expense-paythrough-modal .paythrough-list-title {
    color: var(--bs-body-color);
    font-size: 13px;
    font-weight: 600;
}

.expense-paythrough-modal .paythrough-list-title i {
    color: var(--bs-primary);
    font-size: 15px;
}

.expense-paythrough-modal .paythrough-list-subtitle {
    margin-top: 2px;

    color: var(--bs-secondary-color);
    font-size: 11px;
}

.expense-paythrough-modal .paythrough-list-count {
    min-width: 28px;
    height: 24px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 0 8px;

    border-radius: 20px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 11px;
    font-weight: 600;
}


/* ============================================================
   SEARCH
============================================================ */

.expense-paythrough-modal .paythrough-list-search {
    padding: 10px 12px;

    border-bottom: 1px solid var(--bs-border-color);
}

.expense-paythrough-modal .paythrough-list-search .input-group-text {
    min-width: 38px;

    background: var(--bs-body-bg);
    border-right: 0;
}

.expense-paythrough-modal .paythrough-list-search .form-control {
    min-height: 36px;

    border-left: 0;

    font-size: 12px;
}

.expense-paythrough-modal .paythrough-list-search .form-control:focus {
    box-shadow: none;
}

.expense-paythrough-modal .paythrough-list-search .btn {
    min-width: 38px;
}


/* ============================================================
   LIST SCROLL AREA
============================================================ */

.expense-paythrough-modal .pay-through-list {
    max-height: 235px;

    overflow-y: auto;
    overflow-x: hidden;

    padding: 4px 8px;
}

.expense-paythrough-modal .pay-through-list::-webkit-scrollbar {
    width: 5px;
}

.expense-paythrough-modal .pay-through-list::-webkit-scrollbar-track {
    background: transparent;
}

.expense-paythrough-modal .pay-through-list::-webkit-scrollbar-thumb {
    background: #d7dbe4;
    border-radius: 20px;
}


/* ============================================================
   Pay Through ROW
============================================================ */

.expense-paythrough-modal .pay-through-list-item {
    display: flex;

    align-items: center;

    gap: 10px;

    padding: 9px 7px;

    border-bottom: 1px solid
        rgba(
            var(--bs-border-color-rgb),
            0.55
        );

    transition:
        background-color 0.15s ease,
        transform 0.15s ease;
}

.expense-paythrough-modal .pay-through-list-item:last-child {
    border-bottom: 0;
}

.expense-paythrough-modal .pay-through-list-item:hover {
    background: var(--bs-tertiary-bg);
    border-radius: 8px;
}


/* ============================================================
   Pay Through Icon
============================================================ */

.expense-paythrough-modal .pay-through-list-icon {
    width: 34px;
    height: 34px;

    min-width: 34px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 17px;
}


/* ============================================================
   Pay Through CONTENT
============================================================ */

.expense-paythrough-modal .pay-through-list-content {
    flex: 1;

    min-width: 0;
}

.expense-paythrough-modal .pay-through-list-name {
    color: var(--bs-body-color);

    font-size: 12px;
    font-weight: 600;

    line-height: 17px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;
}

.expense-paythrough-modal .pay-through-list-meta {
    display: flex;

    align-items: center;

    gap: 6px;

    margin-top: 2px;

    min-width: 0;
}

.expense-paythrough-modal .pay-through-list-pay-through {
    max-width: 150px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;

    color: var(--bs-secondary-color);

    font-size: 10px;
}

.expense-paythrough-modal .pay-through-list-code {
    color: var(--bs-secondary-color);

    font-size: 9px;
}

.expense-paythrough-modal .pay-through-list-dot {
    color: var(--bs-secondary-color);

    opacity: 0.5;
}


/* ============================================================
   ACTIONS
============================================================ */

.expense-paythrough-modal .pay-through-list-actions {
    display: flex;

    align-items: center;

    gap: 3px;

    flex-shrink: 0;
}

.expense-paythrough-modal .pay-through-list-action {
    width: 30px;
    height: 30px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 0;

    border: 0;

    border-radius: 7px;

    background: transparent;

    color: var(--bs-secondary-color);

    transition:
        background-color 0.15s ease,
        color 0.15s ease;
}

.expense-paythrough-modal .pay-through-list-action:hover {
    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);
}

.expense-paythrough-modal .pay-through-list-action.delete:hover {
    background: rgba(
        var(--bs-danger-rgb),
        0.10
    );

    color: var(--bs-danger);
}

.expense-paythrough-modal .pay-through-list-action i {
    font-size: 16px;
}


/* ============================================================
   EMPTY STATE
============================================================ */

.expense-paythrough-modal .paythrough-list-empty {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    padding: 25px 15px;

    text-align: left;
}

.expense-paythrough-modal .paythrough-list-empty-icon {
    width: 38px;
    height: 38px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: var(--bs-tertiary-bg);

    color: var(--bs-secondary-color);

    font-size: 18px;
}

.expense-paythrough-modal .paythrough-list-empty strong {
    display: block;

    color: var(--bs-body-color);

    font-size: 12px;
}

.expense-paythrough-modal .paythrough-list-empty small {
    display: block;

    margin-top: 2px;

    color: var(--bs-secondary-color);

    font-size: 10px;
}


/* ============================================================
   LOADING
============================================================ */

.expense-paythrough-modal .pay-through-list-loading {
    display: flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    padding: 25px;

    color: var(--bs-secondary-color);

    font-size: 11px;
}


/* ============================================================
   LOAD MORE
============================================================ */

.expense-paythrough-modal .pay-through-list-more {
    padding: 8px;

    text-align: center;

    border-top: 1px solid var(--bs-border-color);
}

.expense-paythrough-modal .pay-through-list-more .btn {
    font-size: 11px;
}


/* ============================================================
   MOBILE
============================================================ */

@media (max-width: 575.98px) {

    .expense-paythrough-modal .pay-through-list {
        max-height: 210px;
    }

    .expense-paythrough-modal .pay-through-list-pay-through {
        max-width: 90px;
    }

    .expense-paythrough-modal .pay-through-list-item {
        padding: 8px 5px;
    }

    .expense-paythrough-modal .pay-through-list-icon {
        width: 32px;
        height: 32px;
        min-width: 32px;
    }

    .expense-paythrough-modal .pay-through-list-action {
        width: 28px;
        height: 28px;
    }

}


</style>

<script>
    /* ============================================================
   EXPENSE CATEGORY MODAL
   File:
   resources/views/content/accounts_finance/expenditure/js/modal.js
============================================================ */
(function ($) {

    'use strict';

    const payThroughModal = {

        modal: null,

        form: null,

        mode: 'create',

        categories: [],


        /* ============================================================
           INIT
        ============================================================ */

        init: function () {

            this.modal = $('#payThroughModal');

            this.form = $('#paythroughForm');

            if (
                !this.modal.length ||
                !this.form.length
            ) {
                return;
            }

            this.bindEvents();

            this.resetForm();

            this.loadPayThrough();

        },


        /* ============================================================
           EVENTS
        ============================================================ */

        bindEvents: function () {

            const self = this;


            /*
            |--------------------------------------------------------------------------
            | ADD
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '[data-bs-target="#payThroughModal"], #btnAddPayThrough, .btn-add-pay-through',
                function () {

                    self.openCreate();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | ICON CHANGE
            |--------------------------------------------------------------------------
            */

            // $(document).on(
            //     'change',
            //     '#paythrough_icon',
            //     function () {

            //         self.updateIconPreview();

            //     }
            // );


            /*
            |--------------------------------------------------------------------------
            | CATEGORY NAME
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'input',
                '#pay_through_name',
                function () {

                    // self.updatePreview();

                    self.clearFieldError('#pay_through_name');

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SUBMIT
            |--------------------------------------------------------------------------
            */

            this.form.on(
                'submit',
                function (event) {

                    event.preventDefault();

                    self.submit();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | RESET
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '#btnResetPayThrough',
                function () {

                    self.resetForm();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | SEARCH
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'input',
                '#payThroughListSearch',
                function () {

                    self.filterpayThroughList();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | CLEAR SEARCH
            |--------------------------------------------------------------------------
            */

            $(document).on(
                'click',
                '#payThroughSearchClear',
                function () {

                    $('#payThroughListSearch')
                        .val('');

                    self.filterpayThroughList();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | EDIT
            |--------------------------------------------------------------------------
            */

            

            $(document).on(
                'click',
                '[data-pay-through-edit]',
                function () {

                    const id =
                        $(this).data('pay-through-edit');

                    if (id) {

                        self.openEdit(
                            id
                        );

                    }

                }
            );

            $(document).on(
                'click',
                '[data-pay-through-delete]',
                function () {

                    const id =
                        $(this).data('pay-through-delete');

                    if (!id) {
                        return;
                    }


                    if (
                        typeof Swal === 'undefined'
                    ) {

                        if (
                            confirm(
                                'Delete this expense Pay Through?'
                            )
                        ) {

                            self.delete(
                                id
                            );

                        }

                        return;
                    }


                    Swal.fire({

                        title: 'Delete Pay Through?',

                        text:
                            'This Pay Through will no longer be available for new expenses.',

                        icon: 'warning',

                        showCancelButton: true,

                        confirmButtonText: 'Delete',

                        cancelButtonText: 'Cancel',

                        reverseButtons: true

                    }).then(
                        function (result) {

                            if (result.isConfirmed) {

                                self.delete(
                                    id
                                );

                            }

                        }
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | DELETE
            |--------------------------------------------------------------------------
            */

            // $(document).on(
            //     'click',
            //     '.btn-delete-category',
            //     function (event) {

            //         event.preventDefault();

            //         const id = $(this).data('id');

            //         if (!id) {
            //             return;
            //         }

            //         self.delete(id);

            //     }
            // );


            /*
            |--------------------------------------------------------------------------
            | MODAL OPEN
            |--------------------------------------------------------------------------
            */

            this.modal.on(
                'shown.bs.modal',
                function () {

                    self.loadPayThrough();

                }
            );


            /*
            |--------------------------------------------------------------------------
            | MODAL CLOSED
            |--------------------------------------------------------------------------
            */

            this.modal.on(
                'hidden.bs.modal',
                function () {

                    self.resetForm();

                }
            );

        },


        /* ============================================================
           CREATE
        ============================================================ */

        openCreate: function () {

            this.mode = 'create';

            this.resetForm();

            $('#paythroughFormMode')
                .val('create');

            $('#payThroughModalLabel').text('Manage Expense Pay Through');
            $('#payThroughModelTitleLabel').text('Add Expense Pay Through');

            $('#payThroughSaveText')
                .text('Save Pay Through');

            $('#payThroughSaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-outline me-1'
                );

                  console.log(' before loadcate')

            this.showModal();
            this.loadPayThrough();

        },


        /* ============================================================
           EDIT
        ============================================================ */

        openEdit: function (id) {

            const self = this;

            this.mode = 'edit';

            this.clearValidation();

            this.setLoading(true);

            $('#paythroughFormMode')
                .val('edit');

            $('#pay_through_id')
                .val(id);

            $('#payThroughModalLabel').text('Manage Expense Pay Through');
            $('#payThroughModelTitleLabel').text('Edit Expense Pay Through');

            $('#payThroughSaveText')
                .text('Update Pay Through');

            $('#payThroughSaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-edit-outline me-1'
                );

            this.showModal();


            const url = this.getShowUrl(id);

            if (!url) {

                this.setLoading(false);

                this.showError(
                    'Pay Through URL is not configured.'
                );

                return;

            }


            $.ajax({

                url: url,

                type: 'GET',

                dataType: 'json',

                success: function (response) {

                    if (
                        !response ||
                        response.success !== true ||
                        !response.data
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to load Pay Through.'
                        );

                        return;

                    }

                    self.fillForm(
                        response.data
                    );

                },

                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to load Pay Through.'
                    );

                },

                complete: function () {

                    self.setLoading(false);

                }

            });

        },


        /* ============================================================
           FILL FORM
        ============================================================ */

        fillForm: function (data) {

            $('#pay_through_id')
                .val(
                    data.sno ||
                    data.id ||
                    ''
                );


            $('#pay_through_name')
                .val(
                    data.pay_through_name ||
                    ''
                );


            // $('#paythrough_icon')
            //     .val(
            //         data.icon ||
            //         'mdi-shape-outline'
            //     )
            //     .trigger('change');


            this.updateIconPreview();

            // this.updatePreview();

        },


        /* ============================================================
           SUBMIT
        ============================================================ */

        submit: function () {

            const self = this;

            this.clearValidation();


            if (!this.validateClientSide()) {
                return;
            }


            const id =
                $('#pay_through_id').val();


            let url;

            if (
                this.mode === 'edit' &&
                id
            ) {

                url =
                    this.getUpdateUrl(id);

            } else {

                url =
                    this.getStoreUrl();

            }


            if (!url) {

                this.showError(
                    'Pay Through URL is not configured.'
                );

                return;

            }


            this.setLoading(true);


            $.ajax({

                url: url,

                type: 'POST',

                data: this.form.serialize(),

                dataType: 'json',


                success: function (response) {

                    if (
                        !response ||
                        response.success !== true
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to Save Pay Through.'
                        );

                        return;

                    }


                    const isEdit =
                        self.mode === 'edit';


                    self.showSuccess(
                        response.message ||
                        (
                            isEdit
                                ? 'Pay Through updated successfully.'
                                : 'Pay Through created successfully.'
                        )
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT
                    | Do NOT close modal after success.
                    |--------------------------------------------------------------------------
                    */

                    self.loadPayThrough();


                    /*
                    |--------------------------------------------------------------------------
                    | Reset for next entry
                    |--------------------------------------------------------------------------
                    */

                    self.resetForm();


                    /*
                    |--------------------------------------------------------------------------
                    | Keep modal in CREATE mode
                    |--------------------------------------------------------------------------
                    */

                    self.mode = 'create';


                    $('#paythroughFormMode')
                        .val('create');


                    $('#payThroughModalLabel').text('Manage Expense Pay Through');
                    $('#payThroughModelTitleLabel').text('Add Expense Pay Through');


                    $('#payThroughSaveText')
                        .text('Save Pay Through');


                    $('#payThroughSaveIcon')
                        .attr(
                            'class',
                            'mdi mdi-content-save-outline me-1'
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | Refresh main expense category select
                    |--------------------------------------------------------------------------
                    */

                    self.refreshExpensePayThrough();

                },


                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to Save Pay Through.'
                    );

                },


                complete: function () {

                    self.setLoading(false);

                }

            });

        },


        /* ============================================================
           VALIDATION
        ============================================================ */

        validateClientSide: function () {

            let valid = true;


            const name =
                $.trim(
                    $('#pay_through_name').val()
                );


            const icon =
                $.trim(
                    $('#paythrough_icon').val()
                );


            if (!name) {

                this.setFieldError(
                    '#pay_through_name',
                    'Pay Through name is required.'
                );

                valid = false;

            } else if (
                name.length > 250
            ) {

                this.setFieldError(
                    '#pay_through_name',
                    'Pay Through name cannot exceed 250 characters.'
                );

                valid = false;

            }


            if (!icon) {

                this.setFieldError(
                    '#paythrough_icon',
                    'Please select a Pay Through Icon.'
                );

                valid = false;

            }


            return valid;

        },


        /* ============================================================
           FIELD ERROR
        ============================================================ */

        setFieldError: function (
            selector,
            message
        ) {

            const field =
                $(selector);

            field.addClass(
                'is-invalid'
            );


            let errorElement =
                $();


            if (
                selector === '#pay_through_name'
            ) {

                errorElement =
                    $('.pay_through_name_error');

            } 
            // else if (
            //     selector === '#paythrough_icon'
            // ) {

            //     errorElement =
            //         $('.paythrough_icon_error');

            // }


            if (
                errorElement.length
            ) {

                errorElement
                    .text(message)
                    .addClass('d-block');

            }

        },


        clearFieldError: function (
            selector
        ) {

            $(selector)
                .removeClass('is-invalid');


            if (
                selector === '#pay_through_name'
            ) {

                $('.pay_through_name_error')
                    .text('');

            }

            // if (
            //     selector === '#paythrough_icon'
            // ) {

            //     $('.paythrough_icon_error')
            //         .text('');

            // }

        },


        /* ============================================================
           CLEAR VALIDATION
        ============================================================ */

        clearValidation: function () {

            this.form
                .find('.is-invalid')
                .removeClass('is-invalid');


            $('.pay_through_name_error')
                .text('');


            // $('.paythrough_icon_error')
            //     .text('');

        },


        /* ============================================================
           AJAX ERROR
        ============================================================ */

        handleAjaxError: function (
            xhr,
            fallbackMessage
        ) {

            if (
                xhr.status === 422 &&
                xhr.responseJSON &&
                xhr.responseJSON.errors
            ) {

                this.showValidationErrors(
                    xhr.responseJSON.errors
                );


                if (
                    xhr.responseJSON.message
                ) {

                    this.showError(
                        xhr.responseJSON.message
                    );

                }

                return;

            }


            this.showError(
                xhr.responseJSON?.message ||
                fallbackMessage
            );

        },


        /* ============================================================
           SERVER VALIDATION
        ============================================================ */

        showValidationErrors: function (
            errors
        ) {

            const self = this;


            $.each(
                errors,
                function (
                    field,
                    messages
                ) {

                    if (
                        !Array.isArray(messages)
                    ) {

                        messages = [
                            messages
                        ];

                    }


                    const selector =
                        '#' + field;


                    if (
                        $(selector).length
                    ) {

                        self.setFieldError(
                            selector,
                            messages[0]
                        );

                    }

                }
            );

        },


        /* ============================================================
           ICON PREVIEW
        ============================================================ */

        updateIconPreview: function () {

            const icon =
                $('#paythrough_icon').val() ||
                'mdi-shape-outline';


            $('#payThroughIconPreview')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            // $('#payThroughPreviewIcon')
            //     .attr(
            //         'class',
            //         'mdi ' + icon
            //     );


            $('#payThroughModalIcon')
                .attr(
                    'class',
                    'mdi ' +
                    icon
                );


            // $('#payThroughSelectedIcon')
            //     .attr(
            //         'title',
            //         icon
            //     );

        },


        /* ============================================================
           PREVIEW
        ============================================================ */

        updatePreview: function () {

            const name =
                $.trim(
                    $('#pay_through_name').val()
                );


            


            /*
            |--------------------------------------------------------------------------
            | Preview only.
            | Backend remains authoritative for actual .
            |--------------------------------------------------------------------------
            */

            const previewCode =
                this.generatePreviewCode(
                    name
                );


            // $('#payThroughPreviewCode')
            //     .text(
            //         previewCode ||
            //         'AUTO GENERATED'
            //     );

        },


        generatePreviewCode: function (
            name
        ) {

            if (!name) {
                return '';
            }


            return name
                .trim()
                .toUpperCase()
                .replace(/[^A-Z0-9]+/g, '_')
                .replace(/^_+|_+$/g, '')
                .substring(0, 200);

        },


        /* ============================================================
           RESET
        ============================================================ */

        resetForm: function () {

            if (
                !this.form ||
                !this.form.length
            ) {
                return;
            }


            this.form[0].reset();


            $('#pay_through_id')
                .val('');


            $('#paythroughFormMode')
                .val('create');


            $('#pay_through_name')
                .val('');


            // $('#paythrough_icon')
            //     .val(
            //         'mdi-shape-outline'
            //     )
            //     .trigger('change');


            this.mode =
                'create';


            this.clearValidation();


            this.updateIconPreview();

            // this.updatePreview();


            $('#payThroughModalLabel').text('Manage Expense Pay Through');
            $('#payThroughModelTitleLabel').text('Add Expense Pay Through');


            $('#payThroughSaveText')
                .text(
                    'Save Pay Through'
                );


            $('#payThroughSaveIcon')
                .attr(
                    'class',
                    'mdi mdi-content-save-outline me-1'
                );


            this.setLoading(false);

        },


        /* ============================================================
           LOADING
        ============================================================ */

        setLoading: function (
            loading
        ) {

            if (loading) {

                this.modal
                    .addClass('is-loading');


                $('#btnSavePayThrough')
                    .prop(
                        'disabled',
                        true
                    );


                $('#btnResetPayThrough')
                    .prop(
                        'disabled',
                        true
                    );


                $('#payThroughLoader')
                    .removeClass('d-none');


                $('#payThroughSaveIcon')
                    .addClass('d-none');

            } else {

                this.modal
                    .removeClass('is-loading');


                $('#btnSavePayThrough')
                    .prop(
                        'disabled',
                        false
                    );


                $('#btnResetPayThrough')
                    .prop(
                        'disabled',
                        false
                    );


                $('#payThroughLoader')
                    .addClass('d-none');


                $('#payThroughSaveIcon')
                    .removeClass('d-none');

            }

        },


        /* ============================================================
           SHOW MODAL
        ============================================================ */

        showModal: function () {

            const element =
                document.getElementById(
                    'payThroughModal'
                );


            if (!element) {
                return;
            }


            bootstrap.Modal
                .getOrCreateInstance(
                    element
                )
                .show();

        },


        /* ============================================================
           LOAD CATEGORY LIST
        ============================================================ */

        loadPayThrough: function () {
            

            const self = this;

            const $loading = $('#payThroughListLoading');
            const $empty = $('#payThroughListEmpty');
            const $list = $('#payThroughList');
            const $more = $('#payThroughListMore');

            $loading.removeClass('d-none');
            $empty.addClass('d-none');
            $more.addClass('d-none');

            $list.empty();


            /*
            |--------------------------------------------------------------------------
            | Use dedicated category list endpoint
            |--------------------------------------------------------------------------
            */

            if (
                !window.expenseRoutes ||
                !window.expenseRoutes.payThrough
            ) {

                $loading.addClass('d-none');

                $empty
                    .removeClass('d-none')
                    .find('strong')
                    .text('Pay Through list unavailable.');

                return;
            }

            
            $.ajax({
                url: window.expenseRoutes.payThrough,
                type: 'GET',
                dataType: 'json',
                success: function (response) {

                    const categories =
                        response &&
                        response.success &&
                        Array.isArray(response.data)
                            ? response.data
                            : [];

                    self.productListData =
                        categories;

                    self.renderpayThroughList(
                        categories
                    );

                },

                error: function (xhr) {

                    console.error(
                        'Pay Through list error:',
                        xhr.responseText
                    );

                    $empty.removeClass('d-none');

                    $empty.find('strong')
                        .text('Unable to load Pay Through.');

                    $empty.find('small')
                        .text('Please try again.');

                },

                complete: function () {

                    $loading.addClass('d-none');

                }

            });

        },

        /* ============================================================
        RENDER PRODUCT LIST
        ============================================================ */

        renderpayThroughList: function (
            categories
        ) {
            console.log('categories render')

            const $list =
                $('#payThroughList');

            const $empty =
                $('#payThroughListEmpty');

            const search =
                $.trim(
                    $('#payThroughListSearch').val()
                ).toLowerCase();


            let filtered = categories.filter(function (category) {

                    if (!search) {
                        return true;
                    }

                    const name =
                        String(
                            category.pay_through_name || ''
                        ).toLowerCase();

                  

                    const code =
                        String(
                            category.pay_through_code || ''
                        ).toLowerCase();

                    return (
                        name.includes(search) ||
                        code.includes(search)
                    );

                });


            $('#payThroughListCount')
                .text(filtered.length);


            if (!filtered.length) {

                $list.empty();

                $empty.removeClass('d-none');

                return;
            }


            $empty.addClass('d-none');

            let html = '';

            filtered.forEach(
                function (category) {

                    const id =
                        Number(category.sno || 0);

                    if (!id) {
                        return;
                    }

                    


                    const name =
                        self.escapeHtml(
                            category.pay_through_name ||
                            'Unnamed Category'
                        );


                    const code =
                        self.escapeHtml(
                            category.pay_through_code ||
                            'AUTO'
                        );


                    let icon =
                        category.icon ||
                        'mdi-package-variant-closed';


                    if (
                        !icon.includes('mdi ')
                    ) {

                        if (
                            icon.indexOf('mdi-') === 0
                        ) {

                            icon =
                                'mdi ' + icon;

                        }

                    }


                    icon =
                        payThroughModal.escapeHtml(
                            icon
                        );


                   



                    html += `

                        <div class="pay-through-list-item" data-pay-through-id="${id}">
                            <div class="pay-through-list-icon">
                                <i class="${icon}"></i>
                            </div>
                            <div class="pay-through-list-content">
                                <div class="pay-through-list-name" title="${name}">
                                    ${name}
                                </div>
                                <div class="pay-through-list-meta">
                                    <span class="pay-through-list-code">
                                        ${code}
                                    </span>
                                </div>
                            </div>
                            <div class="pay-through-list-actions">
                                <button
                                    type="button"
                                    class="pay-through-list-action btn-edit-pay-through"
                                    data-pay-through-edit="${id}"
                                    title="Edit Pay Through">

                                    <i class="mdi mdi-pencil-outline"></i>

                                </button>


                                <button
                                    type="button"
                                    class="pay-through-list-action delete btn-delete-pay-through"
                                    data-pay-through-delete="${id}"
                                    title="Delete Pay Through">

                                    <i class="mdi mdi-delete-outline"></i>

                                </button>

                            </div>

                        </div>

                    `;

                }
            );


            $list.html(html);

        },

       


        /* ============================================================
           RENDER CATEGORY LIST
        ============================================================ */



        /* ============================================================
           SEARCH CATEGORY LIST
        ============================================================ */

        filterpayThroughList: function () {

            const search =
                $.trim(
                    $('#payThroughListSearch')
                        .val()
                ).toLowerCase();


            const $items =
                $('#expensepayThroughList')
                    .find('.pay-through-list-item');


            $('#payThroughSearchClear')
                .toggleClass(
                    'd-none',
                    !search
                );


            let visible = 0;


            $items.each(
                function () {

                    const name =
                        String(
                            $(this)
                                .data(
                                    'pay-through-name'
                                ) ||
                            ''
                        ).toLowerCase();


                    const match =
                        !search ||
                        name.includes(search);


                    $(this)
                        .toggle(match);


                    if (match) {
                        visible++;
                    }

                }
            );


            if (
                search &&
                visible === 0
            ) {

                $('#expensepayThroughList')
                    .find('.pay-through-search-empty')
                    .remove();


                $('#expensepayThroughList')
                    .append(`
                        <div class="paythrough-list-empty pay-through-search-empty">
                            <i class="mdi mdi-magnify-close"></i>
                            <span>No matching Pay Through found.</span>
                        </div>
                    `);

            } else {

                $('#expensepayThroughList')
                    .find('.pay-through-search-empty')
                    .remove();

            }

        },


        /* ============================================================
           DELETE
        ============================================================ */

        delete: function (id) {

            const self = this;


            if (
                !window.confirm(
                    'Are you sure you want to delete this expense Pay Through?'
                )
            ) {
                return;
            }


            const url =
                this.getDeleteUrl(id);


            if (!url) {

                this.showError(
                    'Delete URL is not configured.'
                );

                return;

            }


            $.ajax({

                url: url,

                type: 'DELETE',

                data: {
                    _token:
                        this.getCsrfToken()
                },

                dataType: 'json',


                success: function (response) {

                    if (
                        !response ||
                        response.success !== true
                    ) {

                        self.showError(
                            response?.message ||
                            'Unable to delete Pay Through.'
                        );

                        return;

                    }


                    self.showSuccess(
                        response.message ||
                        'Pay Through deleted successfully.'
                    );


                    self.loadPayThrough();

                    self.refreshExpensePayThrough();

                },


                error: function (xhr) {

                    self.handleAjaxError(
                        xhr,
                        'Unable to delete Pay Through.'
                    );

                }

            });

        },


        /* ============================================================
           REFRESH EXPENSE Pay Through SELECT
        ============================================================ */

        refreshExpensePayThrough: function () {

            /*
            |--------------------------------------------------------------------------
            | Existing ExpenseModal loader
            |--------------------------------------------------------------------------
            */

            if (
                window.expenseModal &&
                typeof window.expenseModal.loadPayThrough ===
                    'function'
            ) {

                window.expenseModal
                    .loadPayThrough();

                return;

            }


            /*
            |--------------------------------------------------------------------------
            | Fallback: directly refresh #pay_through_id
            |--------------------------------------------------------------------------
            */

            const url =
                window.expenseRoutes &&
                window.expenseRoutes.payThrough;


            if (!url) {
                return;
            }


            $.get(
                url,
                function (response) {

                    if (
                        !response ||
                        !Array.isArray(
                            response.data
                        )
                    ) {
                        return;
                    }


                    let html =
                        '<option value="">Select Pay Through</option>';


                    response.data.forEach(
                        function (paythrough) {

                            html += `
                                <option value="${paythrough.sno}">
                                    ${payThroughModal.escapeHtml(
                                        paythrough.pay_through_name
                                    )}
                                </option>
                            `;

                        }
                    );


                    $('#pay_through_id')
                        .html(html)
                        .trigger('change.select2');

                }
            );

        },


        /* ============================================================
           URL HELPERS
        ============================================================ */

        getStoreUrl: function () {

            return (
                window.expenseRoutes &&
                window.expenseRoutes.payThroughStore
            ) || '';

        },


        getShowUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.payThroughShow
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        getUpdateUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.payThroughUpdate
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        getDeleteUrl: function (id) {

            const url =
                (
                    window.expenseRoutes &&
                    window.expenseRoutes.payThroughDelete
                ) || '';


            return url.replace(
                ':id',
                encodeURIComponent(id)
            );

        },


        /* ============================================================
           CSRF
        ============================================================ */

        getCsrfToken: function () {

            return (
                $('meta[name="csrf-token"]')
                    .attr('content')
            ) ||
            $('#paythroughForm input[name="_token"]')
                .val();

        },


        /* ============================================================
           SAFE ICON
        ============================================================ */

        safeIcon: function (icon) {

            if (
                typeof icon !== 'string' ||
                !/^mdi-[a-z0-9-]+$/i.test(icon)
            ) {

                return 'mdi-shape-outline';

            }

            return icon;

        },


        /* ============================================================
           HTML ESCAPE
        ============================================================ */

        escapeHtml: function (value) {

            return $('<div>')
                .text(
                    value == null
                        ? ''
                        : String(value)
                )
                .html();

        },


        escapeHtmlAttribute: function (value) {

            return this
                .escapeHtml(value)
                .replace(/"/g, '&quot;');

        },


        /* ============================================================
           SUCCESS
        ============================================================ */

        showSuccess: function (
            message
        ) {

            if (
                typeof window.showToast ===
                'function'
            ) {

                window.showToast(
                    'success',
                    message
                );

                return;

            }


            if (
                typeof window.toastr !==
                'undefined'
            ) {

                window.toastr.success(
                    message
                );

                return;

            }

        },


        /* ============================================================
           ERROR
        ============================================================ */

        showError: function (
            message
        ) {

            if (
                typeof window.showToast ===
                'function'
            ) {

                window.showToast(
                    'error',
                    message
                );

                return;

            }


            if (
                typeof window.toastr !==
                'undefined'
            ) {

                window.toastr.error(
                    message
                );

                return;

            }


            console.error(message);

        }

    };


    /*
    |--------------------------------------------------------------------------
    | GLOBAL
    |--------------------------------------------------------------------------
    */

    window.payThroughModal =
        payThroughModal;


    /*
    |--------------------------------------------------------------------------
    | READY
    |--------------------------------------------------------------------------
    */

    $(function () {

        payThroughModal.init();

    });


})(jQuery);
</script>

<script>
    function icon_chnage_func () {

            const icon =
                $('#paythrough_icon').val() ||
                'mdi-shape-outline';


            $('#payThroughIconPreview')
                .attr(
                    'class',
                    'mdi ' + icon
                );


            // $('#payThroughPreviewIcon')
            //     .attr(
            //         'class',
            //         'mdi ' + icon
            //     );


            $('#payThroughModalIcon')
                .attr(
                    'class',
                    'mdi ' + icon + ' fs-4'
                );


            // $('#payThroughSelectedIcon')
            //     .attr(
            //         'title',
            //         icon
            //     );

    }
</script>
