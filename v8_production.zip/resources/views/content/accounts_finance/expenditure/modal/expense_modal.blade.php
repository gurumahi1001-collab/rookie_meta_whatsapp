{{-- ===========================================================
| Expenditure Management
| Credit Expense Modal
=========================================================== --}}

<div class="modal fade"  id="expenseModal" tabindex="-1" aria-labelledby="expenseModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content expense-modal">
            {{-- ==== Header ===== --}}
            <div class="modal-header border-bottom">
                <div>
                    <h4 class="modal-title fw-bold mb-1" id="expenseModalLabel">
                        <i class="mdi mdi-receipt-text-outline me-2 text-danger"></i>
                        Add Credit Expense
                    </h4>
                    <small class="text-muted">
                        Create a company credit expense entry
                    </small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- ===== Form ==== --}}
            <form id="expenseForm" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <input type="hidden" id="expense_id" name="expense_id">
                <input type="hidden" id="formMode" value="create">
                <div class="modal-body">
                    {{-- =====  Expense Information ==== --}}
                    <div class="card shadow-none border mb-4">
                        <div class="card-header bg-white">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm bg-label-danger me-3 d-flex align-items-center justify-content-center">
                                    <i class="mdi mdi-bank-outline"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-semibold">
                                        Expense Information
                                    </h6>
                                    <small class="text-muted">
                                        Company, Entity and Credit Card Details
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                {{-- Company --}}
                                <div class="col-xl-6">
                                    <label class="form-label required">Company</label>
                                    <select id="company_id" name="company_id" class="form-select select3">
                                        <option value="">Select Company</option>
                                        
                                    </select>
                                    <div class="invalid-feedback company_id_error"></div>
                                </div>
                                {{-- Entity --}}
                                <div class="col-xl-6">
                                    <label for="entity_id" class="form-label" id="entityLabel">Entity</label>
                                    <select id="entity_id" name="entity_id" class="form-select select3">
                                        <option value="">Select Entity</option>
                                    </select>
                                    <div class="invalid-feedback entity_id_error"></div>
                                </div>
                                {{-- Credit Card --}}
                                <div class="col-xl-6">
                                    <label class="form-label required">Credit Card</label>
                                    <select id="tiderc_id" name="tiderc_id" class="form-select select3">
                                        <option value="">Select Credit Card</option>
                                    </select>
                                    <div class="invalid-feedback tiderc_id_error"></div>
                                </div>
                                {{-- Expense Date --}}
                                <div class="col-xl-6">
                                    <label class="form-label required">Expense Date</label>
                                    <input type="text" id="expense_date" name="date" class="form-control flatpickr-date" placeholder="DD-MM-YYYY">
                                    <div class="invalid-feedback date_error"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- =====  Expense Details ===== --}}
                    <div class="card shadow-none border mb-4">
                        <div class="card-header bg-white">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm bg-label-primary me-3 d-flex align-items-center justify-content-center">
                                    <i class="mdi mdi-receipt-text-outline"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-semibold">Expense Details</h6>
                                    <small class="text-muted">
                                        Expense category and transaction details
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                {{-- Expense Category --}}
                                <div class="col-xl-6">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <label class="form-label required">Expense Category</label>
                                        <!-- <span class="text-primary cursor-pointer badge bg-label-primary border border-primary" id="btnAddCategory" data-bs-toggle="modal"  data-bs-target="#categoryModal"><i class="mdi mdi-plus"></i></span>  -->
                            
                                    </div>
                                    
                                    <div class="">
                                        <select class="form-select select3" id="category_id" name="category_id">
                                            <option value="">Select Category</option>
                                        </select>
                                    </div>
                                    <div class="invalid-feedback category_id_error"></div>
                                </div>
                                
                                {{-- Expense Product --}}
                                <div class="col-xl-6">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <label class="form-label required"> Expense Product</label>
                                        <!-- <span class="text-primary cursor-pointer badge bg-label-primary border border-primary"id="btnAddProduct" data-bs-toggle="modal" data-bs-target="#productModal"><i class="mdi mdi-plus"></i></span>    -->
                                    </div>
                                    <div class="">
                                        <select class="form-select select3" id="product_id" name="product_id">
                                            <option value="">Select Product</option>
                                        </select>
                                    </div>
                                    <div class="invalid-feedback product_id_error"></div>
                                </div>
                                {{-- Reference No --}}
                                <div class="col-xl-12">
                                    <label class="form-label required">Transaction Name</label>
                                    <input type="text" id="reference_no" name="reference_no" class="form-control" placeholder="Enter Transaction Name">
                                    <div class="invalid-feedback reference_no_error"></div>
                                </div>
                                {{-- Amount --}}
                                <div class="col-xl-6">
                                    <label
                                        class="form-label required"
                                        id="expenseAmountLabel"
                                    >
                                        Expense Amount (INR)
                                    </label>

                                    <div class="input-group input-group-lg">
                                        <span
                                            class="input-group-text"
                                            id="expenseAmountSymbol"
                                        >
                                            ₹
                                        </span>

                                        <input
                                            type="text"
                                            class="form-control"
                                            id="amount"
                                            name="amount"
                                            inputmode="decimal"
                                            maxlength="20"
                                            placeholder="0.00"
                                            autocomplete="off"
                                            oninput="
                                                this.value = this.value
                                                    .replace(/[^0-9.]/g, '')
                                                    .replace(/(\..*)\./g, '$1');
                                            "
                                        >
                                    </div>

                                    <div class="invalid-feedback amount_error"></div>

                                    <div
                                        class="form-text"
                                        id="expenseAmountHelp"
                                    >
                                        Enter the actual expense amount in INR.
                                    </div>
                                </div>

                                <div class="col-xl-6 d-none" id="gstAmountWrapper" >
                                    <div class="row">
                                        <div class="col-xl-4">
                                            <label class="form-label required" for="gst_amount" >
                                                SGST Amount
                                            </label>
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-text">
                                                    ₹
                                                </span>
                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    id="gst_amount"
                                                    name="gst_amount"
                                                    inputmode="decimal"
                                                    maxlength="20"
                                                    placeholder="0.00"
                                                    autocomplete="off"
                                                    oninput="
                                                        this.value = this.value
                                                            .replace(/[^0-9.]/g, '')
                                                            .replace(/(\..*)\./g, '$1');
                                                    "
                                                >
                                            </div>

                                            <div class="invalid-feedback gst_amount_error"></div>
                                        </div>
                                        <div class="col-xl-4">
                                            <label class="form-label required" for="cgst_amount" >
                                                CGST Amount
                                            </label>
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-text">
                                                    ₹
                                                </span>
                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    id="cgst_amount"
                                                    name="cgst_amount"
                                                    inputmode="decimal"
                                                    maxlength="20"
                                                    placeholder="0.00"
                                                    autocomplete="off"
                                                    oninput="
                                                        this.value = this.value
                                                            .replace(/[^0-9.]/g, '')
                                                            .replace(/(\..*)\./g, '$1');
                                                    "
                                                >
                                            </div>

                                            <div class="invalid-feedback cgst_amount_error"></div>
                                        </div>
                                        <div class="col-xl-4">
                                            <label class="form-label required" for="igst_amount" >
                                                IGST Amount
                                            </label>
                                            <div class="input-group input-group-lg">
                                                <span class="input-group-text">
                                                    ₹
                                                </span>
                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    id="igst_amount"
                                                    name="igst_amount"
                                                    inputmode="decimal"
                                                    maxlength="20"
                                                    placeholder="0.00"
                                                    autocomplete="off"
                                                    oninput="
                                                        this.value = this.value
                                                            .replace(/[^0-9.]/g, '')
                                                            .replace(/(\..*)\./g, '$1');
                                                    "
                                                >
                                            </div>

                                            <div class="invalid-feedback igst_amount_error"></div>
                                        </div>
                                    </div>

                                    <div class="form-text">
                                        Enter the GST amount applicable to this transaction.
                                    </div>
                                </div>
                                <div class="col-xl-6 d-none" id="foriegnConversionWrapper" >

                                    <label class="form-label required" for="fcy_conversion_fee" >
                                        FCY Conversion Markup Fee
                                    </label>
                                    <div class="input-group input-group-lg">
                                        <span class="input-group-text">
                                            ₹
                                        </span>
                                        <input
                                            type="text"
                                            class="form-control"
                                            id="fcy_conversion_fee"
                                            name="fcy_conversion_fee"
                                            inputmode="decimal"
                                            maxlength="20"
                                            placeholder="0.00"
                                            autocomplete="off"
                                            oninput="
                                                this.value = this.value
                                                    .replace(/[^0-9.]/g, '')
                                                    .replace(/(\..*)\./g, '$1');
                                            "
                                        >
                                    </div>
                                    <div class="invalid-feedback fcy_conversion_fee_error"></div>
                                    
                                </div>
                                <div class="col-xl-6">
                                    <label class="form-label required" id="otherTransactionLabel" >
                                        Other Transaction Fee (INR)
                                    </label>
                                    <div class="input-group input-group-lg">
                                        <span class="input-group-text" >
                                            ₹
                                        </span>
                                        <input
                                            type="text"
                                            class="form-control"
                                            id="other_transaction_fee"
                                            name="other_transaction_fee"
                                            inputmode="decimal"
                                            maxlength="20"
                                            placeholder="0.00"
                                            autocomplete="off"
                                            oninput="
                                                this.value = this.value
                                                    .replace(/[^0-9.]/g, '')
                                                    .replace(/(\..*)\./g, '$1');
                                            ">
                                    </div>

                                    <div class="invalid-feedback other_transaction_fee_error"></div>
                                </div>

                                {{-- Expense Product --}}
                                <div class="col-xl-12">
                                    {{-- =====================================================
                                        SELECTED PRODUCT DETAILS
                                    ====================================================== --}}
                                    <div id="selectedProductDetails" class="selected-product-details d-none mt-3">
                                        <div class="selected-product-header">

                                            <div class="selected-product-icon">

                                                <i class="mdi mdi-package-variant"></i>

                                            </div>

                                            <div class="selected-product-title">

                                                <div
                                                    id="selectedProductName"
                                                    class="selected-product-name">
                                                    -
                                                </div>

                                                <div
                                                    id="selectedProductCategory"
                                                    class="selected-product-category">
                                                    -
                                                </div>

                                            </div>

                                            <span
                                                id="selectedProductRecurring"
                                                class="product-status-badge">
                                                -
                                            </span>

                                        </div>


                                        <div class="selected-product-body">

                                            {{-- EMAIL --}}
                                            <div
                                                class="product-detail-item"
                                                id="selectedProductEmailWrapper">

                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-email-outline"></i>
                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Email
                                                    </div>

                                                    <div
                                                        id="selectedProductEmail"
                                                        class="product-detail-value">
                                                        -
                                                    </div>

                                                </div>

                                            </div>


                                            {{-- MOBILE --}}
                                            <div
                                                class="product-detail-item"
                                                id="selectedProductMobileWrapper">

                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-phone-outline"></i>
                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Mobile
                                                    </div>

                                                    <div
                                                        id="selectedProductMobile"
                                                        class="product-detail-value">
                                                        -
                                                    </div>

                                                </div>

                                            </div>


                                            {{-- WEBSITE --}}
                                            <div
                                                class="product-detail-item"
                                                id="selectedProductWebsiteWrapper">

                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-web"></i>
                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Website
                                                    </div>

                                                    <a
                                                        href="#"
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        id="selectedProductWebsite"
                                                        class="product-detail-value product-detail-link">
                                                        -
                                                    </a>

                                                </div>

                                            </div>


                                            {{-- FREQUENCY --}}
                                            <div class="product-detail-item">

                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-calendar-sync-outline"></i>
                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Frequency
                                                    </div>

                                                    <div
                                                        id="selectedProductFrequency"
                                                        class="product-detail-value">
                                                        -
                                                    </div>

                                                </div>

                                            </div>


                                            {{-- AMOUNT --}}
                                            <div class="product-detail-item">

                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-cash-multiple"></i>
                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Amount
                                                    </div>

                                                    <div
                                                        id="selectedProductAmount"
                                                        class="product-detail-value fw-bold">
                                                        -
                                                    </div>

                                                </div>

                                            </div>

                                            <div
                                                class="product-detail-item"
                                                id="selectedProductGstWrapper"
                                            >
                                                <div class="product-detail-icon">
                                                    <i class="mdi mdi-percent-outline"></i>
                                                </div>

                                                <div class="product-detail-content">
                                                    <div class="product-detail-label">
                                                        GST
                                                    </div>

                                                    <div
                                                        id="selectedProductGst"
                                                        class="product-detail-value"
                                                    >
                                                        -
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- BILLING DATE --}}
                                            <div
                                                class="product-detail-item"
                                                id="selectedProductBillingWrapper">

                                                <div class="product-detail-icon">

                                                    <i class="mdi mdi-calendar-clock-outline"></i>

                                                </div>

                                                <div class="product-detail-content">

                                                    <div class="product-detail-label">
                                                        Billing Date
                                                    </div>

                                                    <div
                                                        id="selectedProductBillingDate"
                                                        class="product-detail-value">
                                                        -
                                                    </div>

                                                </div>

                                            </div>


                                            {{-- REMARKS --}}
                                            <div
                                                class="product-detail-remarks d-none"
                                                id="selectedProductRemarksWrapper">

                                                <div class="product-detail-label">
                                                    Remarks
                                                </div>

                                                <div
                                                    id="selectedProductRemarks"
                                                    class="product-remarks-text">
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                                {{-- ===  PAYMENT FREQUENCY == --}}

                                <!-- <div class="col-xl-6">

                                    <label class="form-label required">
                                        Payment Frequency
                                    </label>

                                    <select
                                        class="form-select select3"
                                        id="expense_frequency"
                                        name="expense_frequency" onchange="expense_frequency_chnage()">

                                        <option value="one_time">
                                            One Time
                                        </option>

                                        <option value="daily">
                                            Daily
                                        </option>

                                        <option value="weekly">
                                            Weekly
                                        </option>

                                        <option value="monthly">
                                            Monthly
                                        </option>

                                        <option value="quarterly">
                                            Quarterly
                                        </option>

                                        <option value="yearly">
                                            Yearly
                                        </option>

                                        <option value="custom">
                                            Custom Schedule
                                        </option>

                                    </select>

                                    <div class="invalid-feedback expense_frequency_error"></div>

                                    <small class="form-text text-muted">
                                        Next payment is calculated automatically.
                                    </small>

                                </div> -->
                                {{-- =====================================================
                                    NEXT PAYMENT
                                ====================================================== --}}
                                <!-- <div class="col-xl-6">

                                    <label class="form-label">
                                        Next Payment
                                    </label>

                                    <div class="next-payment-box">

                                        <div class="next-payment-icon">

                                            <i class="mdi mdi-calendar-clock-outline"></i>

                                        </div>

                                        <div class="next-payment-content">

                                            

                                            <div
                                                class="next-payment-date"
                                                id="nextPaymentPreview">

                                                No future payment

                                            </div>

                                        </div>

                                    </div>

                                    <input
                                        type="hidden"
                                        id="next_payment_date"
                                        name="next_payment_date">

                                </div> -->
                                {{-- =====================================================
                                    CUSTOM SCHEDULE
                                ====================================================== --}}
                                <!-- <div
                                    class="col-12 custom-schedule-wrapper d-none"
                                    id="customScheduleWrapper">

                                    <div class="custom-schedule-card">

                                        <div class="custom-schedule-header">

                                            <div class="custom-schedule-icon">

                                                <i class="mdi mdi-calendar-range-outline"></i>

                                            </div>

                                            <div>

                                                <div class="fw-semibold">
                                                    Custom Payment Schedule
                                                </div>

                                                <small class="text-muted">
                                                    Define when the custom recurring payment starts and ends.
                                                </small>

                                            </div>

                                        </div>


                                        <div class="row g-3 mt-1">

                                            {{-- Start --}}
                                            <div class="col-md-4">

                                                <label class="form-label required">
                                                    Start Date
                                                </label>

                                                <input
                                                    type="text"
                                                    id="custom_start_date"
                                                    name="custom_start_date"
                                                    class="form-control flatpickr-date"
                                                    placeholder="DD-MM-YYYY">

                                                <div class="invalid-feedback custom_start_date_error"></div>

                                            </div>


                                            {{-- End --}}
                                            <div class="col-md-4">

                                                <label class="form-label required">
                                                    End Date
                                                </label>

                                                <input
                                                    type="text"
                                                    id="custom_end_date"
                                                    name="custom_end_date"
                                                    class="form-control flatpickr-date"
                                                    placeholder="DD-MM-YYYY">

                                                <div class="invalid-feedback custom_end_date_error"></div>

                                            </div>

                                        </div>

                                    </div>

                                </div> -->
                                

                            </div>
                        </div>
                    </div>

                    <div class="card shadow-none border mb-0">
                        <div class="card-header bg-white">
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm bg-label-success me-3 d-flex align-items-center justify-content-center">
                                    <i class="mdi mdi-note-text-outline"></i>
                                </div>
                                <div>
                                    <h6 class="mb-0 fw-semibold">Additional Information</h6>
                                    <small class="text-muted">
                                        Expenditure Details
                                    </small>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row g-4">
                                {{-- Remarks --}}
                                <div class="col-xl-12">
                                    <label class="form-label">Details</label>
                                    <textarea
                                        class="form-control"
                                        rows="4"
                                        id="remarks"
                                        name="remarks"
                                        maxlength="500"
                                        placeholder="Enter expense Details..."></textarea>
                                    <div class="d-flex justify-content-between mt-2">
                                        <small class="text-muted">Optional</small>
                                        <small id="remarksCount">0 / 500</small>
                                    </div>
                                    <div class="invalid-feedback remarks_error"></div>
                                </div>
                                <div class="col-xl-12">
                                    <label class="form-label">
                                        Attachments
                                        <span class="text-muted fw-normal">(Optional)</span>
                                    </label>
                                    <div id="expenseUploadBox" class="expense-upload-box"
                                        tabindex="0"
                                        role="button"
                                        aria-label="Upload expense attachments">
                                        <input
                                            type="file"
                                            id="attachment"
                                            name="attachments[]"
                                            hidden
                                            multiple
                                            accept=".jpg,.jpeg,.png,.pdf,.xls,.xlsx">
                                        <div id="expenseUploadArea">
                                            <div class="expense-upload-icon">
                                                <i class="mdi mdi-cloud-upload-outline"></i>
                                            </div>
                                            <h6 class="mb-1">
                                                Drag & Drop files here
                                            </h6>
                                            <small class="text-muted d-block">
                                                or click to browse
                                            </small>
                                            <small class="text-muted d-block mt-1">
                                                You can also paste files/images with
                                                <kbd>Ctrl</kbd> + <kbd>V</kbd>
                                            </small>
                                            <div class="expense-upload-types mt-3">
                                                JPG • JPEG • PNG • PDF • XLS • XLSX
                                            </div>
                                            <div class="expense-upload-limit mt-2">
                                                Maximum 10 files • Maximum 10 MB per file
                                            </div>
                                        </div>
                                    </div>

                                    <div
                                        id="attachmentPreview"
                                        class="expense-attachment-list mt-3 d-none"
                                    ></div>

                                    <div class="invalid-feedback attachment_error"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>
                        Cancel
                    </button>
                    <button type="reset" class="btn btn-label-warning" id="btnResetExpense">
                        <i class="mdi mdi-refresh me-1"></i>
                        Reset
                    </button>
                    <button type="submit" class="btn btn-primary" id="btnSaveExpense">
                        <span class="spinner-border spinner-border-sm me-2 d-none" id="expenseLoader"></span>
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        Save Expense
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    
    /*=====================================================
    Expense Modal
    =====================================================*/

    .expense-modal {
    border: 0;

    border-radius: 18px;

    overflow: hidden;
    }

    .expense-modal .modal-header {
    background: #fff;

    padding: 20px 24px;
    }

    .expense-modal .modal-body {
    background: #fafbfc;

    padding: 24px;
    }

    .expense-modal .modal-footer {
    background: #fff;

    border-top: 1px solid #ececec;

    padding: 18px 24px;
    }
    /*=====================================================
    Expense Modal Cards
    =====================================================*/

    .expense-modal .card {
    border-radius: 14px;

    border: 1px solid #ebeef2;

    box-shadow: none;
    }

    .expense-modal .card-header {
    padding: 18px 22px;

    border-bottom: 1px solid #eef1f4;
    }

    .expense-modal .card-body {
    padding: 22px;
    }

    .required::after {
    content: ' *';

    color: #dc3545;
    }

    .expense-modal .form-label {
    font-weight: 600;

    color: #495057;
    }

    .expense-modal .select2-container {
    width: 100% !important;
    }
    /*=====================================================
    Expense Input Group
    =====================================================*/

    .expense-modal .input-group > .btn {
    min-width: 44px;
    }

    .expense-modal .input-group-text {
    background: #f8f9fa;

    font-weight: 600;
    }

    #amount {
    font-size: 16px;

    font-weight: 600;

    letter-spacing: 0.3px;
    }

    #amount:focus {
    color: var(--expense-primary);
    }
   /* =====================================================
   EXPENSE ATTACHMENTS
===================================================== */

.expense-upload-box {
    position: relative;
    border: 2px dashed #d7dbe5;
    border-radius: 16px;
    background: #fafafa;
    cursor: pointer;
    transition:
        border-color .2s ease,
        background-color .2s ease,
        box-shadow .2s ease;
    outline: none;
}

.expense-upload-box:hover,
.expense-upload-box:focus {
    border-color: var(--expense-primary, #dc3545);
    background: #fff7f6;
}

.expense-upload-box.is-dragging {
    border-color: var(--expense-primary, #dc3545);
    background: #fff3f1;
    box-shadow: 0 0 0 4px rgba(220, 53, 69, .08);
}

#expenseUploadArea {
    padding: 42px 24px;
    text-align: center;
    pointer-events: none;
}

.expense-upload-icon {
    width: 58px;
    height: 58px;
    margin: 0 auto 14px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff0ef;
    color: var(--expense-primary, #dc3545);
}

.expense-upload-icon i {
    font-size: 30px;
}

.expense-upload-types {
    font-size: 12px;
    font-weight: 600;
    color: #697386;
}

.expense-upload-limit {
    font-size: 11px;
    color: #98a0ae;
}

/* Attachment list */

.expense-attachment-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.expense-attachment-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 11px 13px;
    border: 1px solid #e8ebf0;
    border-radius: 11px;
    background: #fff;
    transition: .2s ease;
}

.expense-attachment-item:hover {
    border-color: #d7dce5;
    box-shadow: 0 3px 12px rgba(30, 42, 60, .05);
}

.expense-attachment-icon {
    width: 38px;
    height: 38px;
    min-width: 38px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f5f6f8;
    color: #697386;
}

.expense-attachment-icon i {
    font-size: 20px;
}

.expense-attachment-content {
    min-width: 0;
    flex: 1;
}

.expense-attachment-name {
    display: block;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #343a40;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
}

a.expense-attachment-name:hover {
    color: #0d6efd;
    text-decoration: underline;
}

.expense-attachment-meta {
    font-size: 11px;
    color: #98a0ae;
    margin-top: 2px;
}

.expense-attachment-remove {
    width: 32px;
    height: 32px;
    border: 0;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    color: #dc3545;
    cursor: pointer;
}

.expense-attachment-remove:hover {
    background: #fff0ef;
}

.expense-attachment-existing {
    background: #fbfcfe;
}

@media (max-width: 576px) {
    #expenseUploadArea {
        padding: 32px 15px;
    }

    .expense-attachment-item {
        padding: 9px;
    }
}

    .preview-file {
    display: flex;

    justify-content: space-between;

    align-items: center;
    }

    .preview-file-name {
    font-weight: 600;

    color: #495057;
    }

    .preview-remove {
    cursor: pointer;

    color: #dc3545;
    }

    .modal-footer {
    padding: 18px 24px;
    }

    /* =====================================================
   PAYMENT SCHEDULE
===================================================== */

.next-payment-box {

    display: flex;

    align-items: center;

    gap: 12px;

    min-height: 58px;

    padding: 10px 14px;

    border: 1px solid #e8ebf0;

    border-radius: 10px;

    background: #fafbfc;

    transition: all .2s ease;
}

.next-payment-icon {

    width: 38px;

    height: 38px;

    flex: 0 0 38px;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #fff0ef;

    color: var(--expense-primary, #dc3545);

}

.next-payment-icon i {

    font-size: 19px;

}

.next-payment-content {

    min-width: 0;

}

.next-payment-label {

    font-size: 11px;

    color: #98a0ae;

    margin-bottom: 1px;

}

.next-payment-date {

    font-size: 14px;

    font-weight: 700;

    color: #202633;

}

.next-payment-date.is-empty {

    color: #9ca3af;

    font-weight: 500;

}


/* =====================================================
   CUSTOM SCHEDULE
===================================================== */

.custom-schedule-card {

    border: 1px solid #e7eaf0;

    border-radius: 12px;

    padding: 16px;

    background: #fbfcfe;

}

.custom-schedule-header {

    display: flex;

    align-items: center;

    gap: 11px;

    padding-bottom: 13px;

    border-bottom: 1px solid #edf0f4;

}

.custom-schedule-icon {

    width: 36px;

    height: 36px;

    border-radius: 9px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #eef4ff;

    color: #4776e6;

    flex-shrink: 0;

}

.custom-schedule-icon i {

    font-size: 18px;

}


/* =====================================================
   FREQUENCY SELECT
===================================================== */

#expense_frequency {

    font-weight: 600;

}

#expense_frequency:focus {

    border-color: var(--expense-primary, #dc3545);

    box-shadow: 0 0 0 .15rem rgba(220, 53, 69, .08);

}


/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 576px) {

    .next-payment-box {

        min-height: 54px;

    }

    .custom-schedule-card {

        padding: 13px;

    }

}

/* =====================================================
   SELECTED PRODUCT DETAILS
===================================================== */

.selected-product-details {

    border: 1px solid #e7eaf0;

    border-radius: 14px;

    background: #ffffff;

    overflow: hidden;

    box-shadow: 0 4px 14px rgba(30, 42, 60, 0.05);

    transition: all .2s ease;
}


/* =====================================================
   HEADER
===================================================== */

.selected-product-header {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 13px 15px;

    background: linear-gradient(
        135deg,
        #f7f9ff,
        #ffffff
    );

    border-bottom: 1px solid #edf0f4;
}


.selected-product-icon {

    width: 38px;

    height: 38px;

    min-width: 38px;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #eef2ff;

    color: #6366f1;

}


.selected-product-icon i {

    font-size: 19px;

}


.selected-product-title {

    min-width: 0;

    flex: 1;

}


.selected-product-name {

    font-size: 14px;

    font-weight: 700;

    color: #202633;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;

}


.selected-product-category {

    font-size: 11px;

    color: #8a94a6;

    margin-top: 2px;

}


.product-status-badge {

    flex-shrink: 0;

    font-size: 10px;

    font-weight: 700;

    padding: 5px 9px;

    border-radius: 20px;

    background: #eefbf3;

    color: #198754;

}


/* =====================================================
   BODY
===================================================== */

.selected-product-body {

    display: grid;

    grid-template-columns: repeat(2, minmax(0, 1fr));

    gap: 1px;

    background: #edf0f4;

}


.product-detail-item {

    display: flex;

    align-items: center;

    gap: 9px;

    min-width: 0;

    padding: 10px 12px;

    background: #fff;

}


.product-detail-icon {

    width: 30px;

    height: 30px;

    min-width: 30px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 8px;

    background: #f5f6f8;

    color: #697386;

}


.product-detail-icon i {

    font-size: 15px;

}


.product-detail-content {

    min-width: 0;

    flex: 1;

}


.product-detail-label {

    font-size: 10px;

    color: #9aa3b2;

    text-transform: uppercase;

    letter-spacing: .35px;

    margin-bottom: 2px;

}


.product-detail-value {

    font-size: 12px;

    font-weight: 600;

    color: #343a40;

    white-space: nowrap;

    overflow: hidden;

    text-overflow: ellipsis;

}


.product-detail-link {

    color: #0d6efd;

    text-decoration: none;

}


.product-detail-link:hover {

    text-decoration: underline;

}


/* =====================================================
   REMARKS
===================================================== */

.product-detail-remarks {

    grid-column: 1 / -1;

    padding: 11px 13px;

    background: #fff;

    border-top: 1px solid #edf0f4;

}


.product-remarks-text {

    margin-top: 4px;

    padding: 8px 10px;

    border-radius: 8px;

    background: #f8f9fb;

    color: #596273;

    font-size: 12px;

    line-height: 1.5;

    word-break: break-word;

}


/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 576px) {

    .selected-product-body {

        grid-template-columns: 1fr;

    }

    .selected-product-header {

        padding: 11px;

    }

}
</style>
<script>
    ('use strict');

class ExpenseModal {
  constructor() {
    this.modal = null;

    this.form = null;

    this.mode = 'create';

    this.currentId = 0;
    this.productCache = {};

     // Attachment state
    this.attachments = [];
    this.existingAttachments = [];
    this.maxAttachments = 10;
    this.maxFileSize = 10 * 1024 * 1024; // 10 MB

    this.allowedExtensions = [
        'jpg',
        'jpeg',
        'png',
        'pdf',
        'xls',
        'xlsx'
    ];
  }

  init() {
    this.modal = new bootstrap.Modal(
      document.getElementById('expenseModal'),

      {
        backdrop: 'static',
        keyboard: false
      }
    );

    this.form = $('#expenseForm');

    this.initializePlugins();
    this.initializePaymentSchedule();

    this.registerEvents();
  }

  initializePlugins() {
    $('.select2').select2({
      dropdownParent: $('#expenseModal'),

      width: '100%'
    });

    $('.flatpickr-date').flatpickr({
      dateFormat: 'Y-m-d',

      allowInput: true,

      defaultDate: 'today'
    });
  }

  registerEvents() {
    const self = this;

    /*
        |--------------------------------------------------------------------------
        | Add Expense
        |--------------------------------------------------------------------------
        */

    $('#btnAddExpense').on('click', function () {
      self.openCreate();
    });

    /*
        |--------------------------------------------------------------------------
        | Form Submit
        |--------------------------------------------------------------------------
        */

    $('#expenseForm').on('submit', function (e) {
      e.preventDefault();

      self.save();
    });

    $(document).on(
        'click.expenseAttachments',
        '.expense-attachment-remove',
        function (e) {

            e.preventDefault();
            e.stopPropagation();

            const newIndex =
                $(this).data('new-index');

            const existingIndex =
                $(this).data('existing-index');

            if (
                newIndex !== undefined
            ) {
                self.removeAttachment(
                    Number(newIndex)
                );

                return;
            }

            if (
                existingIndex !== undefined
            ) {
                self.removeExistingAttachment(
                    Number(existingIndex)
                );
            }
        }
    );

    /*
        |--------------------------------------------------------------------------
        | Reset
        |--------------------------------------------------------------------------
        */

    $('#btnResetExpense').on('click', function () {
      self.reset();
    });

    /*
        |--------------------------------------------------------------------------
        | Company Change
        |--------------------------------------------------------------------------
        */

    $('#company_id').on('change', function () {
      const companyId = $(this).val();
      self.loadEntities();

      self.loadCreditCards();
      // self.updateEntityRequirement(companyId);
    });

    /*
        |--------------------------------------------------------------------------
        | Entity Change
        |--------------------------------------------------------------------------
        */

    $('#entity_id').on('change', function () {
    //   self.loadCreditCards();
    });

    /*
        |--------------------------------------------------------------------------
        | Category Change
        |--------------------------------------------------------------------------
        */

    $('#category_id').on('change', function () {
      self.loadProducts();
    });

    /*
|--------------------------------------------------------------------------
| Attachment Upload
|--------------------------------------------------------------------------
*/

const uploadBox = $('#expenseUploadBox');
const attachmentInput = $('#attachment');

/*
|--------------------------------------------------------------------------
| Click upload box
|--------------------------------------------------------------------------
|
| IMPORTANT:
| The file input is inside #expenseUploadBox.
| Do NOT allow the input click to bubble back to this handler.
|--------------------------------------------------------------------------
*/

uploadBox.on('click.expenseAttachments', function (e) {

    // Ignore clicks coming directly from the file input.
    if ($(e.target).is('#attachment')) {
        return;
    }

    // Ignore attachment action buttons.
    if ($(e.target).closest('.expense-attachment-remove').length) {
        return;
    }

    const input = attachmentInput[0];

    if (!input) {
        return;
    }

    /*
     * Allow selecting the same file again.
     *
     * Existing files are already maintained in
     * this.attachments, so clearing the native input
     * does not remove our selected files.
     */
    input.value = '';

    /*
     * Native click is preferable here.
     * It avoids jQuery trigger recursion.
     */
    input.click();
});


/*
|--------------------------------------------------------------------------
| IMPORTANT:
| Prevent the native input click from bubbling back
| to #expenseUploadBox.
|--------------------------------------------------------------------------
*/

attachmentInput.on(
    'click.expenseAttachments',
    function (e) {
        e.stopPropagation();
    }
);


/*
|--------------------------------------------------------------------------
| File selection
|--------------------------------------------------------------------------
*/

attachmentInput.on(
    'change.expenseAttachments',
    function () {

        const files =
            Array.from(this.files || []);

        if (!files.length) {
            return;
        }

        self.addFiles(files);
    }
);


/*
|--------------------------------------------------------------------------
| Keyboard accessibility
|--------------------------------------------------------------------------
*/

uploadBox.on(
    'keydown.expenseAttachments',
    function (e) {

        if (
            e.key !== 'Enter' &&
            e.key !== ' '
        ) {
            return;
        }

        e.preventDefault();

        const input = attachmentInput[0];

        if (!input) {
            return;
        }

        input.value = '';
        input.click();
    }
);


/*
|--------------------------------------------------------------------------
| Drag & Drop
|--------------------------------------------------------------------------
*/

uploadBox.on(
    'dragenter.expenseAttachments dragover.expenseAttachments',
    function (e) {

        e.preventDefault();
        e.stopPropagation();

        uploadBox.addClass('is-dragging');
    }
);


uploadBox.on(
    'dragleave.expenseAttachments',
    function (e) {

        e.preventDefault();
        e.stopPropagation();

        /*
         * Do not remove dragging state when moving
         * between children inside the upload box.
         */
        const relatedTarget =
            e.originalEvent?.relatedTarget;

        if (
            relatedTarget &&
            uploadBox[0].contains(relatedTarget)
        ) {
            return;
        }

        uploadBox.removeClass('is-dragging');
    }
);


uploadBox.on(
    'drop.expenseAttachments',
    function (e) {

        e.preventDefault();
        e.stopPropagation();

        uploadBox.removeClass('is-dragging');

        const dataTransfer =
            e.originalEvent?.dataTransfer;

        if (!dataTransfer) {
            return;
        }

        const files =
            Array.from(dataTransfer.files || []);

        if (!files.length) {
            return;
        }

        self.addFiles(files);
    }
);


/*
|--------------------------------------------------------------------------
| Clipboard Paste
|--------------------------------------------------------------------------
*/

$(document).on(
    'paste.expenseAttachments',
    function (e) {

        /*
         * Only process paste while expense modal
         * is actually open.
         */
        if (!$('#expenseModal').hasClass('show')) {
            return;
        }

        const clipboard =
            e.originalEvent?.clipboardData;

        if (!clipboard) {
            return;
        }

        const files = [];

        Array.from(
            clipboard.items || []
        ).forEach(item => {

            if (item.kind !== 'file') {
                return;
            }

            const file =
                item.getAsFile();

            if (file) {
                files.push(file);
            }
        });

        if (!files.length) {
            return;
        }

        e.preventDefault();

        self.addFiles(files);
    }
);

    /*
        |--------------------------------------------------------------------------
        | Remarks Counter
        |--------------------------------------------------------------------------
        */

    $('#remarks').on('keyup', function () {
      $('#remarksCount').html($(this).val().length + ' / 500');
    });

    $('#product_id').on('change', function () {

        const productId = $(this).val();

        if (!productId) {

            self.hideProductDetails();

            $('#amount').val('');

            return;
        }

        const product =
            self.productCache[String(productId)];

        if (!product) {

            self.hideProductDetails();

            return;
        }

        self.showProductDetails(product);

        /*
        |--------------------------------------------------------------------------
        | Automatically use INR amount for expense entry
        |--------------------------------------------------------------------------
        */

        let expenseAmount = 0;

        const currency = String(product.currency_type || 'INR')
                .toUpperCase();

        const defaultAmount = Number(product.default_amount || 0);

        if (currency === 'USD') {
           
            $('#expenseAmountLabel').text('Expense Amount (INR)');
            $('#expenseAmountSymbol').text('₹');
            $('#expenseAmountHelp').text('Enter the INR value paid for this USD product.');
            $('#foriegnConversionWrapper').removeClass('d-none');
             expenseAmount = 0;

        } else {

            $('#expenseAmountLabel').text('Expense Amount (INR)');
            $('#expenseAmountSymbol').text('₹');
            $('#foriegnConversionWrapper').addClass('d-none');
            $('#expenseAmountHelp').text('You can edit the product default amount for this transaction.');
            
            expenseAmount = defaultAmount || 0;
        }
      
      

        if (expenseAmount > 0) {
            $('#amount').val(expenseAmount);
        } else {
            $('#amount').val('');
        }

        const gstApplicable = Number(product.is_gst_applicable) === 1;

        if (gstApplicable) {
            $('#gstAmountWrapper').removeClass('d-none');
            $('#gst_amount').val('');

        } else {
            $('#gstAmountWrapper').addClass('d-none');
            $('#gst_amount').val('');
            $('.gst_amount_error').text('');
        }

    });
  }


  removeAttachment(index) {
    if (
        index < 0 ||
        index >= this.attachments.length
    ) {
        return;
    }

    this.attachments.splice(index, 1);

    this.syncAttachmentInput();
    this.renderAttachments();
}

removeExistingAttachment(index) {
    if (
        index < 0 ||
        index >= this.existingAttachments.length
    ) {
        return;
    }

    const attachment =
        this.existingAttachments[index];

    if (attachment.path) {
        /*
         * Tell backend to delete this existing file
         * during update.
         */
        if (!this.removedExistingAttachments) {
            this.removedExistingAttachments = [];
        }

        this.removedExistingAttachments.push(
            attachment.path
        );
    }

    this.existingAttachments.splice(index, 1);

    this.renderAttachments();
}

getAttachmentIcon(filename) {
    const extension =
        String(filename)
            .split('.')
            .pop()
            .toLowerCase();

    switch (extension) {
        case 'pdf':
            return 'mdi mdi-file-pdf-box';

        case 'xls':
        case 'xlsx':
            return 'mdi mdi-file-excel-box';

        case 'jpg':
        case 'jpeg':
        case 'png':
            return 'mdi mdi-file-image-outline';

        default:
            return 'mdi mdi-file-outline';
    }
}

formatFileSize(bytes) {
    if (!bytes) {
        return '0 KB';
    }

    const units = [
        'B',
        'KB',
        'MB',
        'GB'
    ];

    let size = bytes;
    let unitIndex = 0;

    while (
        size >= 1024 &&
        unitIndex < units.length - 1
    ) {
        size /= 1024;
        unitIndex++;
    }

    return `${size.toFixed(
        unitIndex === 0 ? 0 : 1
    )} ${units[unitIndex]}`;
}

escapeHtml(value) {
    return $('<div>')
        .text(value ?? '')
        .html();
}

escapeAttribute(value) {
    return this.escapeHtml(value)
        .replace(/"/g, '&quot;');
}

  showProductDetails(product) {

    if (!product) {

        this.hideProductDetails();

        return;
    }


    const $box =
        $('#selectedProductDetails');


    /*
    |--------------------------------------------------------------------------
    | BASIC
    |--------------------------------------------------------------------------
    */

    $('#selectedProductName')
        .text(product.product_name || '-');


    $('#selectedProductCategory')
        .text(product.category_name || 'No Category');


    /*
    |--------------------------------------------------------------------------
    | RECURRING STATUS
    |--------------------------------------------------------------------------
    */

    const isRecurring =
        Number(product.is_recurring) === 1 ||
        product.is_recurring === true;


    $('#selectedProductRecurring')
        .text(
            isRecurring
                ? 'Recurring'
                : 'One Time'
        );


    /*
    |--------------------------------------------------------------------------
    | EMAIL
    |--------------------------------------------------------------------------
    */

    const email =
        $.trim(product.email_id || '');


    if (email) {

        $('#selectedProductEmail')
            .text(email);

        $('#selectedProductEmailWrapper')
            .removeClass('d-none');

    } else {

        $('#selectedProductEmailWrapper')
            .addClass('d-none');

    }


    /*
    |--------------------------------------------------------------------------
    | MOBILE
    |--------------------------------------------------------------------------
    */

    const mobile =
        $.trim(product.mobile_no || '');


    if (mobile) {

        $('#selectedProductMobile')
            .text(mobile);

        $('#selectedProductMobileWrapper')
            .removeClass('d-none');

    } else {

        $('#selectedProductMobileWrapper')
            .addClass('d-none');

    }


    /*
    |--------------------------------------------------------------------------
    | WEBSITE
    |--------------------------------------------------------------------------
    */

    const website =
        $.trim(product.website || '');


    if (website) {

        let websiteUrl = website;

        if (
            !/^https?:\/\//i.test(
                websiteUrl
            )
        ) {

            websiteUrl =
                'https://' + websiteUrl;

        }

        $('#selectedProductWebsite')
            .text(website)
            .attr('href', websiteUrl);

        $('#selectedProductWebsiteWrapper')
            .removeClass('d-none');

    } else {

        $('#selectedProductWebsiteWrapper')
            .addClass('d-none');

    }


    /*
    |--------------------------------------------------------------------------
    | FREQUENCY
    |--------------------------------------------------------------------------
    */

    const frequency =
        product.frequency_type || 'One Time';


    $('#selectedProductFrequency')
        .text(
            this.formatFrequency(frequency)
        );


    /*
    |--------------------------------------------------------------------------
    | AMOUNT
    |--------------------------------------------------------------------------
    */

    const currency =
        String(
            product.currency_type || 'INR'
        ).toUpperCase();


    const defaultAmount =
        parseFloat(
            product.default_amount || 0
        );
        
    

    const amountInr =
        parseFloat(
            product.amount_inr || 0
        );


    let amountText = '-';


    if (currency === 'USD') {

        amountText =
            '$ ' +
            defaultAmount.toFixed(2);

    } else {

        amountText =
            '₹ ' +
            defaultAmount.toFixed(2);

    }


    $('#selectedProductAmount')
        .text(amountText);

    
    
    /*
    |--------------------------------------------------------------------------
    | BILLING DATE
    |--------------------------------------------------------------------------
    */

    const billingDate =
        $.trim(product.billing_date || '');


    if (billingDate) {

        $('#selectedProductBillingDate')
            .text(
                this.formatProductDate(
                    billingDate
                )
            );

        $('#selectedProductBillingWrapper')
            .removeClass('d-none');

    } else {

        $('#selectedProductBillingWrapper')
            .addClass('d-none');

    }

    const gstApplicable =
        Number(product.is_gst_applicable) === 1;

    $('#selectedProductGst')
        .text(
            gstApplicable
                ? 'Applicable'
                : 'Not Applicable'
        );


    /*
    |--------------------------------------------------------------------------
    | REMARKS
    |--------------------------------------------------------------------------
    */

    const remarks =
        $.trim(product.remarks || '');


    if (remarks) {

        $('#selectedProductRemarks')
            .text(remarks);

        $('#selectedProductRemarksWrapper')
            .removeClass('d-none');

    } else {

        $('#selectedProductRemarksWrapper')
            .addClass('d-none');

    }


    /*
    |--------------------------------------------------------------------------
    | SHOW
    |--------------------------------------------------------------------------
    */

    $box.removeClass('d-none');

}


hideProductDetails() {

    $('#selectedProductDetails')
        .addClass('d-none');

    $('#selectedProductName')
        .text('-');

    $('#selectedProductCategory')
        .text('-');

    $('#selectedProductEmail')
        .text('-');

    $('#selectedProductMobile')
        .text('-');

    $('#selectedProductWebsite')
        .text('-')
        .attr('href', '#');

    $('#selectedProductFrequency')
        .text('-');

    $('#selectedProductAmount')
        .text('-');

    $('#selectedProductBillingDate')
        .text('-');

    $('#selectedProductRemarks')
        .text('');

    $('#selectedProductRemarksWrapper')
        .addClass('d-none');

}


formatFrequency(frequency) {

    if (!frequency) {

        return 'One Time';

    }

    return String(frequency)
        .replace(/_/g, ' ')
        .replace(/\b\w/g, char =>
            char.toUpperCase()
        );

}


formatProductDate(date) {

    if (!date) {

        return '-';

    }

    const parsed =
        new Date(
            date + 'T00:00:00'
        );


    if (
        Number.isNaN(
            parsed.getTime()
        )
    ) {

        return date;

    }


    return parsed.toLocaleDateString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }
    );

}

  initializePaymentSchedule() {

    const self = this;

   


    $('#expense_date').on('change', function () {

        self.calculateNextPayment();

    });


    $('#custom_start_date').on('change', function () {

        self.calculateNextPayment();

    });


    $('#custom_end_date').on('change', function () {

        self.calculateNextPayment();

    });


 


   


    this.toggleCustomSchedule();

}

updateEntityRequirement(companyId) {

    const entityRequired = String(companyId) !== '0';

    const label = $('label[for="entity_id"]');

    if (entityRequired) {

        // $('#entity_id').attr('required', true);

        // label.addClass('required');

    } else {

        $('#entity_id')
            .removeAttr('required')
            .val('')
            .trigger('change');

        label.removeClass('required');

        this.clearFieldError('entity_id');
    }
}

clearFieldError(field) {

    const input = $('[name="' + field + '"]');

    input.removeClass('is-invalid');

    $('.' + field + '_error')
        .text('')
        .hide();

    input
        .next('.select2-container')
        .find('.select2-selection')
        .removeClass('is-invalid');
}

toggleCustomSchedule() {

    const frequency = $('#expense_frequency').val();

    if (frequency === 'custom') {

        $('#customScheduleWrapper')
            .removeClass('d-none');

    } else {

        $('#customScheduleWrapper')
            .addClass('d-none');

    }

}
calculateNextPayment() {

    const frequency = $('#expense_frequency').val();

    const expenseDate = $('#expense_date').val();

    if (!expenseDate) {

        this.setNextPaymentPreview(null);

        return;

    }


    let nextDate = null;


    /*
    |--------------------------------------------------------------------------
    | One Time
    |--------------------------------------------------------------------------
    */

    if (frequency === 'one_time') {

        this.setNextPaymentPreview(null);

        return;

    }


    /*
    |--------------------------------------------------------------------------
    | Standard Frequencies
    |--------------------------------------------------------------------------
    */

    if (frequency === 'daily') {

        nextDate = this.addDate(expenseDate, 1, 'day');

    }

    else if (frequency === 'weekly') {

        nextDate = this.addDate(expenseDate, 1, 'week');

    }

    else if (frequency === 'monthly') {

        nextDate = this.addDate(expenseDate, 1, 'month');

    }

    else if (frequency === 'quarterly') {

        nextDate = this.addDate(expenseDate, 3, 'month');

    }

    else if (frequency === 'yearly') {

        nextDate = this.addDate(expenseDate, 1, 'year');

    }


    /*
    |--------------------------------------------------------------------------
    | Custom
    |--------------------------------------------------------------------------
    */

    else if (frequency === 'custom') {

      const start = $('#custom_start_date').val();
      const end   = $('#custom_end_date').val();

      // No custom start date = no next payment
      if (!start) {
          this.setNextPaymentPreview(null);
          return;
      }

      // Start date must be valid
      if (!this.isValidDate(start)) {
          this.setNextPaymentPreview(null);
          return;
      }

      // End date must be valid when supplied
      if (end && !this.isValidDate(end)) {
          this.setNextPaymentPreview(null);
          return;
      }

      // End date cannot be before start date
      if (
          end &&
          new Date(end + 'T00:00:00') <
          new Date(start + 'T00:00:00')
      ) {
          this.setNextPaymentPreview(null);
          return;
      }

      /*
      * Custom frequency:
      *
      * The start date itself is the next payment date
      * when it is after the expense date.
      */
      let nextDate = start;

      /*
      * If the custom start date is on/before the expense date,
      * there is no interval to calculate.
      *
      * We cannot generate another custom occurrence because
      * custom frequency has only explicit start/end dates.
      *
      * Therefore there is no upcoming payment date.
      */
      if (
          expenseDate &&
          new Date(start + 'T00:00:00') <=
          new Date(expenseDate + 'T00:00:00')
      ) {
          this.setNextPaymentPreview(null);
          return;
      }

      /*
      * Do not allow a payment outside the custom end date.
      */
      if (
          end &&
          new Date(nextDate + 'T00:00:00') >
          new Date(end + 'T00:00:00')
      ) {
          this.setNextPaymentPreview(null);
          return;
      }

      this.setNextPaymentPreview(nextDate);
  }


    this.setNextPaymentPreview(nextDate);

}

isValidDate(dateString) {

    if (!dateString) {
        return false;
    }

    const date = new Date(dateString + 'T00:00:00');

    return !Number.isNaN(date.getTime());
}

addDate(dateString, amount, unit) {

    if (!dateString) {
        return null;
    }

    const date = new Date(dateString + 'T00:00:00');

    if (Number.isNaN(date.getTime())) {
        return null;
    }


    switch (unit) {

        case 'day':

            date.setDate(
                date.getDate() + amount
            );

            break;


        case 'week':

            date.setDate(
                date.getDate() + (amount * 7)
            );

            break;


        case 'month':

            date.setMonth(
                date.getMonth() + amount
            );

            break;


        case 'year':

            date.setFullYear(
                date.getFullYear() + amount
            );

            break;

    }


    return this.formatDate(date);

}

formatDate(date) {

    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, '0');

    const day = String(
        date.getDate()
    ).padStart(2, '0');


    return `${year}-${month}-${day}`;

}

setNextPaymentPreview(date) {

    const preview = $('#nextPaymentPreview');

    const hidden = $('#next_payment_date');


    if (!date) {

        preview
            .text('No future payment')
            .addClass('is-empty');

        hidden.val('');

        return;

    }


    const formatted =
        this.formatDisplayDate(date);


    preview
        .text(formatted)
        .removeClass('is-empty');


    hidden.val(date);

}

formatDisplayDate(dateString) {

    if (!dateString) {
        return '';
    }

    const date =
        new Date(dateString + 'T00:00:00');


    return date.toLocaleDateString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }
    );

}

  loadCreditCards(company = '', entity = '', selected = '') {
    $.get(
      window.expenseRoutes.creditCards,

      {
        company_id: company || $('#company_id').val(),

        entity_id: entity || $('#entity_id').val()
      },

      response => {
        let html = '<option value="">Select Credit Card</option>';

        response.data.forEach(card => {
          html += `

                <option

                value="${card.sno}"

                ${selected == card.sno ? 'selected' : ''}>

                ${card.b_name}

                •••• ${card.rd_prt4}

                </option>

                `;
        });

        $('#tiderc_id')
          .html(html)

          .trigger('change.select2');
      }
    );
  }

  addFiles(files) {
    if (!Array.isArray(files) || !files.length) {
        return;
    }

    const accepted = [];
    const errors = [];

    files.forEach(file => {
        const validation = this.validateAttachment(file);

        if (!validation.valid) {
            errors.push(`${file.name}: ${validation.message}`);
            return;
        }

        const duplicate = this.attachments.some(existing =>
            existing.name === file.name &&
            existing.size === file.size &&
            existing.lastModified === file.lastModified
        );

        if (duplicate) {
            return;
        }

        if (
            this.attachments.length +
            accepted.length +
            this.existingAttachments.length >=
            this.maxAttachments
        ) {
            errors.push(
                `Maximum ${this.maxAttachments} attachments are allowed.`
            );

            return;
        }

        accepted.push(file);
    });

    this.attachments.push(...accepted);

    this.syncAttachmentInput();
    this.renderAttachments();

    if (errors.length) {
        toastr.warning(
            errors.slice(0, 3).join('<br>')
        );
    }
}

validateAttachment(file) {
    if (!(file instanceof File)) {
        return {
            valid: false,
            message: 'Invalid file.'
        };
    }

    if (file.size <= 0) {
        return {
            valid: false,
            message: 'File is empty.'
        };
    }

    if (file.size > this.maxFileSize) {
        return {
            valid: false,
            message: 'Maximum file size is 10 MB.'
        };
    }

    const extension =
        file.name
            .split('.')
            .pop()
            .toLowerCase();

    if (
        !this.allowedExtensions.includes(extension)
    ) {
        return {
            valid: false,
            message:
                'Allowed formats: JPG, JPEG, PNG, PDF, XLS and XLSX.'
        };
    }

    return {
        valid: true
    };
}

syncAttachmentInput() {
    const input =
        document.getElementById('attachment');

    if (!input) {
        return;
    }

    const dataTransfer =
        new DataTransfer();

    this.attachments.forEach(file => {
        dataTransfer.items.add(file);
    });

    input.files = dataTransfer.files;
}

renderAttachments() {
    const container =
        $('#attachmentPreview');

    const total =
        this.existingAttachments.length +
        this.attachments.length;

    if (!total) {
        container
            .addClass('d-none')
            .empty();

        return;
    }

    let html = '';

    /*
    |--------------------------------------------------------------------------
    | Existing server attachments
    |--------------------------------------------------------------------------
    */

    this.existingAttachments.forEach(
        (attachment, index) => {

            const name =
                attachment.original_name ||
                attachment.name ||
                'Attachment';

            const url =
                attachment.url ||
                '#';

            html += `
                <div class="expense-attachment-item expense-attachment-existing">

                    <div class="expense-attachment-icon">
                        <i class="${this.getAttachmentIcon(name)}"></i>
                    </div>

                    <div class="expense-attachment-content">
                        <a
                            href="${this.escapeAttribute(url)}"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="expense-attachment-name"
                            title="${this.escapeAttribute(name)}"
                        >
                            ${this.escapeHtml(name)}
                        </a>

                        <div class="expense-attachment-meta">
                            Existing attachment
                        </div>
                    </div>

                    <button
                        type="button"
                        class="expense-attachment-remove"
                        data-existing-index="${index}"
                        title="Remove attachment"
                    >
                        <i class="mdi mdi-delete-outline"></i>
                    </button>

                </div>
            `;
        }
    );

    /*
    |--------------------------------------------------------------------------
    | New attachments
    |--------------------------------------------------------------------------
    */

    this.attachments.forEach((file, index) => {

        const objectUrl =
            URL.createObjectURL(file);

        html += `
            <div class="expense-attachment-item">

                <div class="expense-attachment-icon">
                    <i class="${this.getAttachmentIcon(file.name)}"></i>
                </div>

                <div class="expense-attachment-content">

                    <a
                        href="${objectUrl}"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="expense-attachment-name"
                        title="${this.escapeAttribute(file.name)}"
                    >
                        ${this.escapeHtml(file.name)}
                    </a>

                    <div class="expense-attachment-meta">
                        ${this.formatFileSize(file.size)}
                    </div>

                </div>

                <button
                    type="button"
                    class="expense-attachment-remove"
                    data-new-index="${index}"
                    title="Remove attachment"
                >
                    <i class="mdi mdi-delete-outline"></i>
                </button>

            </div>
        `;
    });

    container
        .removeClass('d-none')
        .html(html);
}

  
  openCreate() {
    this.mode = 'create';

    this.currentId = 0;

    $('#expenseModalLabel').html(`
        <i class="mdi mdi-receipt-text-outline me-2 text-danger"></i>
        Add Credit Expense
    `);

    $('#btnSaveExpense').html('<i class="mdi mdi-content-save-outline me-1"></i> Save Expense');

    $('#formMode').val('create');

    this.reset();

    this.loadCompanies();

    this.loadCategories();

    this.modal.show();
  }

  view(data) {
    this.openEdit(data);

    $('#expenseForm')
      .find('input,textarea,select')

      .prop('disabled', true);

    $('#btnSaveExpense').hide();
  }
  openEdit(data) {
    this.mode = 'edit';

    this.currentId = data.sno;

    $('#expenseModalLabel').html(`
        <i class="mdi mdi-pencil-outline me-2 text-warning"></i>
        Edit Credit Expense
    `);

    $('#btnSaveExpense').html('<i class="mdi mdi-content-save-outline me-1"></i> Update Expense');

    $('#formMode').val('edit');

    this.reset();

    $('#expense_id').val(data.sno);

    $('#company_id').val(data.company_id).trigger('change');

    this.loadEntities(data.company_id, data.entity_id);

    this.loadCreditCards(data.company_id, data.entity_id, data.tiderc_id);

    this.loadCategories(data.category_id);

    this.loadProducts(data.category_id, data.product_id);

    $('#expense_date').val(data.date);

    $('#reference_no').val(data.reference_no);

    $('#amount').val(data.amount);

    $('#remarks').val(data.remarks);

    $('#remarksCount').html((data.remarks ?? '').length + ' / 500');

    this.modal.show();
  }
  reset() {

    $('#expenseForm')[0].reset();

    $('.select2')
        .val(null)
        .trigger('change');

    this.attachments = [];
    this.existingAttachments = [];
    this.removedExistingAttachments = [];

    const input =
        document.getElementById('attachment');

    if (input) {
        input.value = '';
    }

    $('#attachmentPreview')
        .addClass('d-none')
        .empty();


    $('#remarksCount')
        .html('0 / 500');


    /*
    |--------------------------------------------------------------------------
    | Payment Schedule
    |--------------------------------------------------------------------------
    */

    $('#expense_frequency')
        .val('one_time');

    $('#custom_start_date')
        .val('');

    $('#custom_end_date')
        .val('');

 


    $('#customScheduleWrapper')
        .addClass('d-none');


    $('#next_payment_date')
        .val('');


    $('#nextPaymentPreview')
        .text('No future payment')
        .addClass('is-empty');


    $('#expenseForm')
        .find('input,textarea,select')
        .prop('disabled', false);


    $('#btnSaveExpense').show();


    this.clearValidation();

}

  history(data) {
    console.log(data);
  }

  clearValidation() {

    $('#expenseForm')
        .find('.is-invalid')
        .removeClass('is-invalid');

    $('#expenseForm')
        .find('.invalid-feedback')
        .text('')
        .hide();

    $('#expenseForm')
        .find('.select2-selection')
        .removeClass('is-invalid');
}
  showLoading() {
    $('#expenseLoader').removeClass('d-none');

    $('#btnSaveExpense').prop('disabled', true);
  }
  hideLoading() {
    $('#expenseLoader').addClass('d-none');

    $('#btnSaveExpense').prop('disabled', false);
  }
  save() {
    if (this.mode === 'edit') {
      this.update();

      return;
    }

    const self = this;

    self.showLoading();

    self.clearValidation();

    $.ajax({
      url: window.expenseRoutes.store,

      type: 'POST',

      data: new FormData($('#expenseForm')[0]),

      processData: false,

      contentType: false,

      success(response) {
        toastr.success(response.message);

        self.modal.hide();

        self.hideLoading();

        if (
            window.expenseTable &&
            typeof window.expenseTable.reload === 'function'
        ) {
            window.expenseTable.reload();
        } else if (
            $.fn.DataTable &&
            $.fn.DataTable.isDataTable('#expenseTable')
        ) {
            $('#expenseTable')
                .DataTable()
                .ajax
                .reload(null, false);
        }

        if (window.expenseChart) {
          expenseChart.init();
        }
      },

      error(xhr) {
        self.hideLoading();

        self.validation(xhr);
      }
    });
  }

  update() {
    const self = this;

    self.showLoading();

    let formData = new FormData($('#expenseForm')[0]);

    formData.append('_method', 'PUT');

    $.ajax({
      url: window.expenseRoutes.update.replace(':id', this.currentId),

      type: 'POST',

      data: formData,

      processData: false,

      contentType: false,

      success(response) {
        toastr.success(response.message);

        self.modal.hide();

        self.hideLoading();

        if (
            window.expenseTable &&
            typeof window.expenseTable.reload === 'function'
        ) {
            window.expenseTable.reload();
        } else if (
            $.fn.DataTable &&
            $.fn.DataTable.isDataTable('#expenseTable')
        ) {
            $('#expenseTable')
                .DataTable()
                .ajax
                .reload(null, false);
        }

        if (window.expenseChart) {
          expenseChart.init();
        }
      },

      error(xhr) {
        self.hideLoading();

        self.validation(xhr);
      }
    });
  }
  validation(xhr) {

    this.clearValidation();
    
    if (xhr.status !== 422) {

        toastr.error(
            xhr.responseJSON?.message ||
            'Something went wrong. Please try again.'
        );

        return;
    }

    const errors = xhr.responseJSON?.errors || {};

    Object.keys(errors).forEach(field => {

        const messages = errors[field];

        const message = Array.isArray(messages)
            ? messages[0]
            : messages;

        const input = $('[name="' + field + '"]');

        input.addClass('is-invalid');

        /*
         * Normal error container
         */
        const errorBox = $('.' + field + '_error');

        if (errorBox.length) {
            errorBox
                .text(message)
                .show();
        }

        /*
         * Select2
         */
        if (input.hasClass('select3')) {

            input
                .next('.select2-container')
                .find('.select2-selection')
                .addClass('is-invalid');
        }

        /*
         * Scroll to first error
         */
        if (
            Object.keys(errors)[0] === field
        ) {

            setTimeout(() => {

                const target = input.hasClass('select3')
                    ? input.next('.select2-container')
                    : input;

                if (target.length) {

                    target[0].scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });
                }

            }, 100);
        }
    });

    toastr.error(
        xhr.responseJSON?.message ||
        'Please correct the highlighted fields.'
    );
  }
  loadCompanies(selected = '') {
    $.get(
      window.expenseRoutes.companies,

      response => {
        let html = '<option value="">Select Company</option><option value="0">Elysium Groups</option>';

        response.data.forEach(company => {
          html += `

                <option

                    value="${company.sno}"

                    ${selected == company.sno ? 'selected' : ''}>

                    ${company.company_name}

                </option>

                `;
        });

        $('#company_id')
          .html(html)

          .trigger('change.select2');
      }
    );
  }
  loadEntities(company = '', selected = '') {
    $('#entity_id').html('<option>Loading...</option>');

    $.get(
      window.expenseRoutes.entities,

      {
        company_id: company || $('#company_id').val()
      },

      response => {
        let html = '<option value="">Select Entity</option>';

        response.data.forEach(entity => {
          html += `

                <option

                    value="${entity.sno}"

                    ${selected == entity.sno ? 'selected' : ''}>

                    ${entity.entity_name}

                </option>

                `;
        });

        $('#entity_id')
          .html(html)

          .trigger('change.select2');
      }
    );
  }
  loadCategories(selected = '') {
    $.get(
      window.expenseRoutes.categories,

      response => {
        let html = '<option value="">Select Category</option>';

        response.data.forEach(category => {
          html += `

                <option

                    value="${category.sno}"

                    ${selected == category.sno ? 'selected' : ''}>

                    ${category.category_name}

                </option>

                `;
        });

        $('#category_id')
          .html(html)

          .trigger('change.select2');
      }
    );
  }

  loadProducts(category = '', selected = '') {

    const self = this;

    const categoryId =
        category || $('#category_id').val();


    /*
    |--------------------------------------------------------------------------
    | Clear previous product
    |--------------------------------------------------------------------------
    */

    self.productCache = {};

    self.hideProductDetails();


    $('#product_id')
        .html(
            '<option value="">Loading products...</option>'
        )
        .trigger('change.select2');


    if (!categoryId) {

        $('#product_id')
            .html(
                '<option value="">Select Product</option>'
            )
            .trigger('change.select2');

        return;
    }


    $.get(

        window.expenseRoutes.products,

        {
            category_id: categoryId
        },

        function (response) {

            let html =
                '<option value="">Select Product</option>';


            if (
                response &&
                Array.isArray(response.data)
            ) {

                response.data.forEach(
                    function (product) {

                        /*
                        |--------------------------------------------------------------------------
                        | Cache COMPLETE product
                        |--------------------------------------------------------------------------
                        */

                        self.productCache[
                            String(product.sno)
                        ] = product;


                        html += `

                            <option
                                value="${product.sno}"
                                ${String(selected) === String(product.sno)
                                    ? 'selected'
                                    : ''}>

                                ${product.product_name + ' - ' +  product.category_name }

                            </option>

                        `;

                    }
                );

            }


            $('#product_id')
                .html(html)
                .trigger('change.select2');


            /*
            |--------------------------------------------------------------------------
            | EDIT MODE
            |--------------------------------------------------------------------------
            |
            | trigger('change.select2') only refreshes Select2 UI.
            | It does NOT trigger our normal change event.
            |
            | Therefore explicitly show selected product.
            |--------------------------------------------------------------------------
            */

            if (selected) {

                const product =
                    self.productCache[
                        String(selected)
                    ];


                if (product) {

                    self.showProductDetails(
                        product
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | Set expense amount
                    |--------------------------------------------------------------------------
                    */

                    const currency =
                        String(
                            product.currency_type || 'INR'
                        ).toUpperCase();


                    let amount = 0;

                    if (currency === 'USD') {
                        amount = parseFloat(product.amount_inr || 0  );
                    } else {
                        amount = parseFloat( product.default_amount || 0);
                    }
                    if (amount > 0) {
                        $('#amount').val(amount.toFixed(2));
                    }
                }
            }
        }

    ).fail(
        function () {
            $('#product_id').html('<option value="">Unable to load products</option>').trigger('change.select2');

            self.hideProductDetails();
            toastr.error('Unable to load expense products.');

        }

    );

}

//   loadProducts(category = '', selected = '') {
//     $('#product_id').html('<option>Loading...</option>');

//      self.productCache = {};

//     self.hideProductDetails();

//     $.get(
//       window.expenseRoutes.products,

//       {
//         category_id: category || $('#category_id').val()
//       },

//       response => {
//         let html = '<option value="">Select Product</option>';

//         response.data.forEach(product => {
//           html += `

//                 <option

//                     value="${product.sno}"

//                     data-default="${product.default_amount}"

//                     ${selected == product.sno ? 'selected' : ''}>

//                     ${product.product_name} - ${product.category_name}

//                 </option>

//                 `;
//         });

//         $('#product_id')
//           .html(html)

//           .trigger('change.select2');
//       }
//     );
//   }
}
$(function () {
  window.expenseModal = new ExpenseModal();

  expenseModal.init();
});

</script>

<script>
 function expense_frequency_chnage() {

        toggleCustomScheduleGlobal();

        calculateNextPaymentGlobal();

    }

  function toggleCustomScheduleGlobal() {

      const frequency = $('#expense_frequency').val();

      if (frequency === 'custom') {

          $('#customScheduleWrapper')
              .removeClass('d-none');

      } else {

          $('#customScheduleWrapper')
              .addClass('d-none');

      }

  }
function calculateNextPaymentGlobal() {

    const frequency = $('#expense_frequency').val();

    const expenseDate = $('#expense_date').val();

    if (!expenseDate) {

        setNextPaymentPreviewGlobal(null);

        return;

    }


    let nextDate = null;


    /*
    |--------------------------------------------------------------------------
    | One Time
    |--------------------------------------------------------------------------
    */

    if (frequency === 'one_time') {

       setNextPaymentPreviewGlobal(null);

        return;

    }


    /*
    |--------------------------------------------------------------------------
    | Standard Frequencies
    |--------------------------------------------------------------------------
    */

    if (frequency === 'daily') {

        nextDate = addDateGlobal(expenseDate, 1, 'day');

    }

    else if (frequency === 'weekly') {

        nextDate = addDateGlobal(expenseDate, 1, 'week');

    }

    else if (frequency === 'monthly') {

        nextDate = addDateGlobal(expenseDate, 1, 'month');

    }

    else if (frequency === 'quarterly') {

        nextDate = addDateGlobal(expenseDate, 3, 'month');

    }

    else if (frequency === 'yearly') {

        nextDate = addDateGlobal(expenseDate, 1, 'year');

    }


    /*
    |--------------------------------------------------------------------------
    | Custom
    |--------------------------------------------------------------------------
    */

    else if (frequency === 'custom') {

      const start = $('#custom_start_date').val();
      const end   = $('#custom_end_date').val();

      // No custom start date = no next payment
      if (!start) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      // Start date must be valid
      if (!isValidDateGlobal(start)) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      // End date must be valid when supplied
      if (end && !isValidDateGlobal(end)) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      // End date cannot be before start date
      if (
          end &&
          new Date(end + 'T00:00:00') <
          new Date(start + 'T00:00:00')
      ) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      /*
      * Custom frequency:
      *
      * The start date itself is the next payment date
      * when it is after the expense date.
      */
      let nextDate = start;

      if (
          expenseDate &&
          new Date(start + 'T00:00:00') <=
          new Date(expenseDate + 'T00:00:00')
      ) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      /*
      * Do not allow a payment outside the custom end date.
      */
      if (
          end &&
          new Date(nextDate + 'T00:00:00') >
          new Date(end + 'T00:00:00')
      ) {
          setNextPaymentPreviewGlobal(null);
          return;
      }

      setNextPaymentPreviewGlobal(nextDate);
  }


    setNextPaymentPreviewGlobal(nextDate);

}


function isValidDateGlobal(dateString) {

    if (!dateString) {
        return false;
    }

    const date = new Date(dateString + 'T00:00:00');

    return !Number.isNaN(date.getTime());
}

function addDateGlobal(dateString, amount, unit) {

    if (!dateString) {
        return null;
    }

    const date = new Date(dateString + 'T00:00:00');

    if (Number.isNaN(date.getTime())) {
        return null;
    }


    switch (unit) {

        case 'day':

            date.setDate(
                date.getDate() + amount
            );

            break;


        case 'week':

            date.setDate(
                date.getDate() + (amount * 7)
            );

            break;


        case 'month':

            date.setMonth(
                date.getMonth() + amount
            );

            break;


        case 'year':

            date.setFullYear(
                date.getFullYear() + amount
            );

            break;

    }


    return formatDateGlobal(date);

}

function formatDateGlobal(date) {

    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, '0');

    const day = String(
        date.getDate()
    ).padStart(2, '0');


    return `${year}-${month}-${day}`;

}

function setNextPaymentPreviewGlobal(date) {

    const preview = $('#nextPaymentPreview');

    const hidden = $('#next_payment_date');


    if (!date) {

        preview
            .text('No future payment')
            .addClass('is-empty');

        hidden.val('');

        return;

    }


    const formatted =
        formatDisplayDateGlobal(date);


    preview
        .text(formatted)
        .removeClass('is-empty');


    hidden.val(date);

}

function formatDisplayDateGlobal(dateString) {

    if (!dateString) {
        return '';
    }

    const date =
        new Date(dateString + 'T00:00:00');


    return date.toLocaleDateString(
        'en-IN',
        {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }
    );

}
</script>