
<div class="modal fade expense-product-modal"  id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div class="d-flex align-items-center">
                    <div class="avatar avatar-md bg-label-primary me-3">
                        <i class="mdi mdi-package-variant-closed fs-4" id="productModalIcon"></i>
                    </div>
                    <div>
                        <h5 class="modal-title mb-1" id="productModalLabel">
                            Manage Expense Product
                        </h5>
                        <small class="text-muted">
                            Create and manage expense products
                        </small>
                    </div>
                </div>
                <button  type="button"  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    {{-- ==== Left Side ==== --}}
                    <div class="col-lg-8 col-xl-8">
                        <form id="productForm" method="POST" autocomplete="off">
                            @csrf
                            <input type="hidden" name="product_id" id="expense_product_edit_id" value="">
                            <input type="hidden"  name="form_mode" id="productFormMode"  value="create">
                            <div class="modal-body px-0 pt-0 ">
                                 
                                {{-- === PRODUCT INFORMATION === --}}
                                <div class="card shadow-none border mb-4">
                                    <div class="card-header bg-white">
                                        <div class="fw-bold mb-2 fs-6" id="productModelTitleLabel"> Add Expense Product</div>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm bg-label-primary me-3">
                                                <i class="mdi mdi-package-variant"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-semibold">Product Information</h6>
                                                <small class="text-muted"> Define the expense product and category.</small>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <div class="row g-4">
                                            {{-- CATEGORY --}}
                                            <div class="col-md-6">
                                                <label for="product_category_id" class="form-label required"> Expense Category</label>
                                                <div class="product-category-icon-selector">
                                                    {{-- Selected icon --}}
                                                    <div class="product-category-selected-icon" id="productCategorySelectedIcon">
                                                        <span id="productCategoryInfoIcon"><i class="mdi mdi-shape-outline"></i></span> 
                                                    </div>
                                                    {{-- Icon Category  --}}
                                                    <div class="flex-grow-1">
                                                        <select  class="form-select select3 productCategoryIcon"  id="product_category_id" name="category_id"  onchange="category_icon_chnage_func(this)">
                                                            <option value="">
                                                                Select Category
                                                            </option>
                                                            
                                                        </select>
                                                    </div>

                                                </div>
                                                <div class="invalid-feedback product_category_error"></div>
                                            </div>

                                            {{-- PRODUCT NAME --}}
                                            <div class="col-md-6">
                                                <label for="product_name" class="form-label required">
                                                    Product Name
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">
                                                        <i class="mdi mdi-package-variant"></i>
                                                    </span>
                                                    <input type="text" class="form-control" id="product_name" name="product_name" maxlength="250" placeholder="Enter product name" autocomplete="off">
                                                </div>
                                                <div class="invalid-feedback product_name_error"></div>
                                            </div>

                                            {{-- FREQUENCY --}}
                                            <div class="col-md-6">
                                                <label for="frequency_type" class="form-label">Frequency Type</label>
                                                <div class="product-frequency-icon-selector">
                                                    {{-- Selected icon --}}
                                                    <div class="product-frequency-selected-icon" >
                                                        <i class="mdi mdi-calendar-sync-outline"></i>
                                                    </div>
                                                    {{-- Icon Category  --}}
                                                    <div class="flex-grow-1">
                                                        <select class="form-select select3" id="frequency_type" name="frequency_type">
                                                            <option value="">Select Frequency</option>
                                                            <option value="One Time">One Time</option>
                                                            <option value="Life Time">Life Time</option>
                                                            <!-- <option value="Daily">Daily</option> -->
                                                            <!-- <option value="Weekly">Weekly</option> -->
                                                            <option value="Monthly">Monthly</option>
                                                            <option value="Quarterly"> Quarterly</option>
                                                            <option value="Half Yearly"> Half Yearly</option>
                                                            <option value="Yearly"> Yearly</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="invalid-feedback frequency_type_error"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {{-- ==== CONTACT INFORMATION ===== --}}
                                <div class="card shadow-none border mb-4">
                                    <div class="card-header bg-white">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm bg-label-info me-3">
                                                <i class="mdi mdi-card-account-details-outline"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-semibold">Contact Information</h6>
                                                <small class="text-muted">
                                                    Optional supplier or service contact details.
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-4">
                                            {{-- EMAIL --}}
                                            <div class="col-md-4">
                                                <label for="product_email" class="form-label">
                                                    Email ID
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">
                                                        <i class="mdi mdi-email-outline"></i>
                                                    </span>
                                                    <input type="text" class="form-control" id="product_email" name="email_id" maxlength="255" placeholder="example@company.com" autocomplete="off" oninput="this.value=this.value.toLowerCase();" >
                                                </div>
                                                <div class="invalid-feedback email_id_error"></div>
                                            </div>
                                            {{-- MOBILE --}}
                                            <div class="col-md-4">
                                                <label for="product_mobile" class="form-label">
                                                    Mobile Number
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">
                                                        <i class="mdi mdi-phone-outline"></i>
                                                    </span>
                                                    <input type="text" class="form-control" id="product_mobile" name="mobile_no" maxlength="30" inputmode="tel" placeholder="+91 9099999000" autocomplete="off" oninput="this.value=this.value.replace(/[^0-9]/g,'');" >
                                                </div>
                                                <div class="invalid-feedback mobile_no_error"></div>
                                            </div>
                                            {{-- WEBSITE --}}
                                            <div class="col-md-4">
                                                <label for="product_website" class="form-label">
                                                    Website
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">
                                                        <i class="mdi mdi-web"></i>
                                                    </span>
                                                    <input type="text" class="form-control" id="product_website" name="website" maxlength="500" placeholder="https://example.com" autocomplete="off">
                                                </div>
                                                <div class="invalid-feedback website_error"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card shadow-none border mb-4">
                                    <div class="card-header bg-white">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm bg-label-success me-3">
                                                <i class="mdi mdi-currency-inr"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-semibold">
                                                    Amount & Billing
                                                </h6>
                                                <small class="text-muted">
                                                    Configure the default product amount.
                                                </small>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-body">
                                        <div class="row g-4">
                                            {{-- AMOUNT TYPE --}}
                                            <div class="col-md-6">
                                                <label for="currency_type" class="form-label required">Amount Type</label>
                                                <div class="product-currency-icon-selector">
                                                    {{-- Selected icon --}}
                                                    <div class="product-currency-selected-icon" >
                                                        <i class="mdi mdi-cash-multiple"></i>
                                                    </div>
                                                    {{-- Icon Category  --}}
                                                    <div class="flex-grow-1">
                                                        <select  class="form-select select3" id="currency_type" name="currency_type" onchange="updateProductCurrencyUIGlobal()">
                                                            <option value="INR"> INR - Indian Rupee</option>
                                                            <option value="USD">USD - US Dollar</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="invalid-feedback currency_type_error"></div>
                                            </div>

                                            {{-- DEFAULT AMOUNT --}}
                                            <div class="col-md-6">
                                                <label for="default_amount" class="form-label required" id="defaultAmountLabel">
                                                    Default Amount (INR)
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="defaultAmountSymbol">₹</span>
                                                    <input type="text" class="form-control" id="default_amount" name="default_amount" inputmode="decimal" maxlength="15" placeholder="0.00" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                </div>
                                                <div class="invalid-feedback default_amount_error"></div>
                                            </div>
                                            {{-- INR CONVERSION --}}
                                            <!-- <div class="col-md-6"  id="amountInrWrapper"  style="display:none;">
                                                <label for="amount_inr" class="form-label required">
                                                    Amount in INR
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text"> ₹</span>
                                                    <input type="text" class="form-control" id="amount_inr" name="amount_inr" inputmode="decimal" maxlength="15"  placeholder="0.00" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                </div>
                                                <div class="invalid-feedback amount_inr_error"></div>
                                                <div class="form-text">
                                                    Enter the INR equivalent of the USD amount.
                                                </div>
                                            </div> -->
                                            <div class="col-md-6">
                                                <div class="form-check form-switch mt-4 pt-2">
                                                    <input class="form-check-input" type="checkbox" id="is_recurring" name="is_recurring" value="1">
                                                    <label class="form-check-label fw-semibold" for="is_recurring">
                                                        Recurring Expense
                                                    </label>
                                                </div>
                                                <div class="form-text">
                                                    Enable this if the product repeats automatically.
                                                </div>
                                            </div>
                                            <div class="col-md-6"  id="billingDateWrapper"  style="display:none;">
                                                <label for="billing_date" class="form-label required">
                                                    Billing Date
                                                </label>
                                                <div class="input-group">
                                                    <span class="input-group-text">
                                                        <i class="mdi mdi-calendar-outline"></i>
                                                    </span>
                                                    <input  type="text" class="form-control flatpickr-date" id="billing_date"  name="billing_date" placeholder="Select billing date" autocomplete="off">
                                                </div>
                                                <div class="invalid-feedback billing_date_error"></div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-check form-switch mt-4 pt-2">
                                                    <input
                                                        class="form-check-input"
                                                        type="checkbox"
                                                        id="is_gst_applicable"
                                                        name="is_gst_applicable"
                                                        value="1" >

                                                    <label class="form-check-label fw-semibold" for="is_gst_applicable">
                                                        GST Applicable
                                                    </label>
                                                </div>

                                                <div class="form-text">
                                                    Enable GST when this product normally requires GST.
                                                    GST amount is entered during the actual expense transaction.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card shadow-none border">
                                    <div class="card-header bg-white">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm bg-label-secondary me-3">
                                                <i class="mdi mdi-note-text-outline"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-semibold">
                                                    Additional Information
                                                </h6>
                                                <small class="text-muted">
                                                    Optional product notes.
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <label for="product_remarks" class="form-label">
                                            Remarks
                                        </label>
                                        <textarea class="form-control" id="product_remarks"  name="remarks"  rows="4"  maxlength="2000"  placeholder="Enter product remarks..."></textarea>
                                        <div class="invalid-feedback remarks_error"></div>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="modal-footer px-0">
                                <button type="button"class="btn btn-label-secondary" data-bs-dismiss="modal">
                                    <i class="mdi mdi-close me-1"></i>
                                    Cancel
                                </button>
                                <button type="reset" class="btn btn-label-warning" id="btnResetExpenseProduct">
                                    <i class="mdi mdi-refresh me-1"></i>
                                    Reset
                                </button>
                                <button type="submit"  class="btn btn-primary" id="btnSaveProduct">
                                    <span class="spinner-border spinner-border-sm me-2 d-none" id="productLoader">
                                    </span>
                                    <i class="mdi mdi-content-save-outline me-1" id="productSaveIcon"></i>
                                    <span id="productSaveText">Save Product</span>
                                </button>
                            </div>
                        </form>
                    </div>
                    {{-- ==== Right Side ==== --}}
                    <div class="col-lg-4 col-xl-4">
                       
                        {{-- ==== EXISTING PRODUCT LIST ==== --}}
                        <div class="product-list-panel">

                            <div class="product-list-header">

                                <div>
                                    <div class="product-list-title">
                                        <i class="mdi mdi-format-list-bulleted me-1"></i>
                                        Existing Products
                                    </div>

                                    <div class="product-list-subtitle">
                                        Recently added expense products
                                    </div>
                                </div>

                                <span
                                    class="product-list-count"
                                    id="productListCount">
                                    0
                                </span>

                            </div>


                            {{-- Search --}}

                            <div class="product-list-search">

                                <div class="input-group">

                                    <span class="input-group-text">
                                        <i class="mdi mdi-magnify"></i>
                                    </span>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="productListSearch"
                                        placeholder="Search products..."
                                        autocomplete="off">

                                    <button
                                        type="button"
                                        class="btn btn-light d-none"
                                        id="btnClearProductSearch"
                                        aria-label="Clear search">

                                        <i class="mdi mdi-close"></i>

                                    </button>

                                </div>

                            </div>

                            <div class="product-list-category-search">
                               <select  class="form-select select3"  id="filter_product_category_id"  onchange="filter_category_func()">
                                    <option value="">All Category</option>
                                </select>
                            </div>


                            {{-- Loading --}}

                            <div
                                id="productListLoading"
                                class="product-list-loading">

                                <div class="spinner-border spinner-border-sm text-primary"></div>

                                <span>Loading products...</span>

                            </div>


                            {{-- Empty --}}

                            <div
                                id="productListEmpty"
                                class="product-list-empty d-none">

                                <div class="product-list-empty-icon">
                                    <i class="mdi mdi-package-variant-closed"></i>
                                </div>

                                <div>
                                    <strong>No products found</strong>

                                    <small>
                                        Add your first expense product above.
                                    </small>
                                </div>

                            </div>


                            {{-- Products --}}

                            <div
                                id="productList"
                                class="product-list">
                            </div>


                            {{-- Load more --}}

                            <div
                                id="productListMore"
                                class="product-list-more d-none">

                                <button
                                    type="button"
                                    class="btn btn-sm btn-label-secondary"
                                    id="btnLoadMoreProducts">

                                    <i class="mdi mdi-chevron-down me-1"></i>
                                    Load More

                                </button>

                            </div>

                        </div>                                   
                    </div>
                </div>
            
                
            </div> 
        
        </div>
    </div>
</div>


<style>

/* === MODAL === */

.expense-product-modal .modal-dialog {
    /* max-width: 680px;  */
}

.expense-product-modal .modal-content {
    border: 0;
    border-radius: 0.75rem;
    overflow: hidden;
    background-color: var(--bs-body-bg);
    box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.12);
}

.expense-product-modal .modal-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}

.expense-product-modal .modal-body {
    padding: 1.5rem;
    background-color: var(--bs-body-bg);
}

.expense-product-modal .modal-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--bs-border-color);
    background-color: var(--bs-body-bg);
}

/* ====HEADER AVATAR ==== */
.expense-product-modal .avatar {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.5rem;
}

.expense-product-modal .avatar i {
    line-height: 1;
}


/* ==== PRODUCT PREVIEW ===== */

.expense-product-modal .product-preview {
    display: flex;
    align-items: center;
    gap: 1rem;

    min-height: 72px;
    padding: 1rem;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.625rem;

    background-color: var(--bs-tertiary-bg);

    transition:
        border-color 0.2s ease,
        box-shadow 0.2s ease;
}

.expense-product-modal .product-preview:hover {
    border-color: rgba(
        var(--bs-primary-rgb),
        0.35
    );

    box-shadow: 0 0.25rem 0.75rem rgba(
        var(--bs-primary-rgb),
        0.06
    );
}


/* ==== PRODUCT PREVIEW ICON ==== */
.expense-product-modal .product-preview-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.625rem;

    color: var(--bs-primary);

    background-color: rgba(
        var(--bs-primary-rgb),
        0.12
    );

    font-size: 1.5rem;

    transition:
        transform 0.2s ease,
        background-color 0.2s ease;
}

.expense-product-modal .product-preview:hover
.product-preview-icon {
    transform: translateY(-1px);
}

.expense-product-modal .product-preview-icon i {
    line-height: 1;
}


/* ==== PREVIEW CONTENT ====== */

.expense-product-modal .product-preview-content {
    min-width: 0;

    flex: 1;

    display: flex;
    flex-direction: column;
}

.expense-product-modal .product-preview-label {
    margin-bottom: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    font-weight: 600;

    letter-spacing: 0.04em;
    text-transform: uppercase;
}


.expense-product-modal .product-category-icon-selector {
    display: flex;
    align-items: center;
    gap: 0.45rem;
}

.expense-product-modal .product-category-selected-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.5rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.375rem;

    transition:
        color 0.2s ease,
        background-color 0.2s ease,
        border-color 0.2s ease;
}

.expense-product-modal .product-frequency-icon-selector {
    display: flex;
    align-items: center;
    gap: 0.45rem;
}

.expense-product-modal .product-frequency-selected-icon{
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.5rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.375rem;

    transition:
        color 0.2s ease,
        background-color 0.2s ease,
        border-color 0.2s ease;
}


.expense-product-modal .product-currency-icon-selector {
    display: flex;
    align-items: center;
    gap: 0.45rem;
}

.expense-product-modal .product-currency-selected-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.5rem;

    color: var(--bs-primary);
    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.375rem;

    transition:
        color 0.2s ease,
        background-color 0.2s ease,
        border-color 0.2s ease;
}

.expense-product-modal .product-preview-content strong {
    overflow: hidden;

    color: var(--bs-body-color);

    font-size: 0.9375rem;
    font-weight: 600;

    line-height: 1.4;

    text-overflow: ellipsis;
    white-space: nowrap;
}


/* ====== PREVIEW META ======= */

.expense-product-modal .product-preview-meta {
    display: flex;
    align-items: center;
    gap: 0.4rem;

    margin-top: 0.125rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    font-weight: 500;

    line-height: 1.4;
}

.expense-product-modal .product-preview-meta
.product-preview-separator {
    opacity: 0.5;
}


/* ======= PREVIEW AMOUNT ======== */

.expense-product-modal .product-preview-amount {
    min-width: 100px;

    display: flex;
    flex-direction: column;
    align-items: flex-end;

    text-align: right;
}

.expense-product-modal .product-preview-amount span {
    color: var(--bs-secondary-color);

    font-size: 0.625rem;
    font-weight: 500;

    letter-spacing: 0.03em;
    text-transform: uppercase;
}

.expense-product-modal .product-preview-amount strong {
    margin-top: 0.125rem;

    color: var(--bs-body-color);

    font-size: 0.9375rem;
    font-weight: 600;
}


/* ===== FORM LABEL ====== */

.expense-product-modal .form-label {
    margin-bottom: 0.5rem;

    color: var(--bs-body-color);

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-product-modal .form-label.required::after {
    content: '*';

    margin-left: 0.25rem;

    color: var(--bs-danger);
}


/* ===== INPUT GROUP ======== */

.expense-product-modal .input-group-text {
    min-width: 42px;

    display: flex;
    align-items: center;
    justify-content: center;

    color: var(--bs-secondary-color);

    background-color: var(--bs-tertiary-bg);

    border-color: var(--bs-border-color);
}

.expense-product-modal .input-group-text i {
    font-size: 1.125rem;
    line-height: 1;
}


/* ===== FORM CONTROLS =========== */

.expense-product-modal .form-control,
.expense-product-modal .form-select {
    min-height: 42px;

    border-color: var(--bs-border-color);

    font-size: 0.8125rem;
}

.expense-product-modal .form-control:focus,
.expense-product-modal .form-select:focus {
    border-color: var(--bs-primary);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-primary-rgb),
        0.12
    );
}

.expense-product-modal .form-control::placeholder {
    color: var(--bs-secondary-color);
    opacity: 0.7;
}


/* ===== UPPERCASE PRODUCT CODE ===== */

.expense-product-modal #product_code {
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 500;
}


/* === DEFAULT AMOUNT === */

.expense-product-modal #default_amount {
    font-variant-numeric: tabular-nums;
}


/* ======== HELP TEXT ============ */

.expense-product-modal .form-text {
    margin-top: 0.375rem;

    color: var(--bs-secondary-color);

    font-size: 0.6875rem;
    line-height: 1.5;
}


/* =======  CATEGORY INFO ====== */

.expense-product-modal .product-category-info {
    padding: 0.875rem 1rem;

    border: 1px solid var(--bs-border-color);
    border-radius: 0.625rem;

    background-color: var(--bs-tertiary-bg);
}

.expense-product-modal .product-category-info-icon {
    width: 38px;
    height: 38px;
    min-width: 38px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 0.5rem;

    color: var(--bs-primary);

    background-color: rgba(
        var(--bs-primary-rgb),
        0.1
    );

    font-size: 1.25rem;
}

.expense-product-modal .product-category-info-icon i {
    line-height: 1;
}

.expense-product-modal .product-category-info
small {
    font-size: 0.6875rem;
}

.expense-product-modal .product-category-info
strong {
    color: var(--bs-body-color);

    font-size: 0.8125rem;
    font-weight: 600;
}


/* ============================================================
   VALIDATION
============================================================ */

.expense-product-modal .is-invalid {
    border-color: var(--bs-danger);
}

.expense-product-modal .is-invalid:focus {
    border-color: var(--bs-danger);

    box-shadow: 0 0 0 0.15rem rgba(
        var(--bs-danger-rgb),
        0.12
    );
}

.expense-product-modal
.product_code_error,
.expense-product-modal
.product_name_error,
.expense-product-modal
.product_category_error,
.expense-product-modal
.default_amount_error {
    font-size: 0.6875rem;
}


/* ============================================================
   FOOTER BUTTONS
============================================================ */

.expense-product-modal .modal-footer .btn {
    min-height: 38px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    font-size: 0.8125rem;
    font-weight: 500;
}

.expense-product-modal .modal-footer .btn i {
    font-size: 1rem;
    line-height: 1;
}


/* ============================================================
   SAVE BUTTON
============================================================ */

.expense-product-modal #btnSaveProduct {
    min-width: 145px;
}

.expense-product-modal #productLoader {
    width: 0.875rem;
    height: 0.875rem;

    border-width: 0.12rem;
}


/* ============================================================
   DISABLED STATE
============================================================ */

.expense-product-modal .form-control:disabled,
.expense-product-modal .form-select:disabled {
    cursor: not-allowed;

    background-color: var(--bs-secondary-bg);
}


/* ============================================================
   LOADING STATE
============================================================ */

.expense-product-modal.is-loading {
    pointer-events: none;
}

.expense-product-modal.is-loading .modal-content {
    opacity: 0.72;
}


/* ============================================================
   DARK MODE
============================================================ */

[data-bs-theme='dark']
.expense-product-modal .product-preview,
[data-bs-theme='dark']
.expense-product-modal .product-category-info {
    background-color: var(--bs-tertiary-bg);
}

[data-bs-theme='dark']
.expense-product-modal .product-preview-icon,
[data-bs-theme='dark']
.expense-product-modal .product-category-info-icon {
    background-color: rgba(
        var(--bs-primary-rgb),
        0.16
    );
}


/* ============================================================
   RESPONSIVE
============================================================ */

@media (max-width: 767.98px) {

    .expense-product-modal .modal-dialog {
        margin: 0.75rem;
    }

    .expense-product-modal .modal-header {
        padding: 1rem;
    }

    .expense-product-modal .modal-body {
        padding: 1rem;
    }

    .expense-product-modal .modal-footer {
        padding: 0.875rem 1rem;
    }

}


@media (max-width: 575.98px) {

    .expense-product-modal .product-preview {
        align-items: flex-start;

        flex-wrap: wrap;
    }

    .expense-product-modal .product-preview-content {
        width: calc(100% - 64px);
    }

    .expense-product-modal .product-preview-amount {
        width: 100%;

        padding-top: 0.75rem;

        border-top: 1px solid var(--bs-border-color);

        align-items: flex-start;

        text-align: left;
    }

    .expense-product-modal .modal-footer {
        gap: 0.5rem;

        flex-wrap: wrap;
    }

    .expense-product-modal .modal-footer .btn {
        flex: 1 1 auto;
    }

}


@media (max-width: 375px) {

    .expense-product-modal .modal-footer .btn {
        width: 100%;

        flex: 1 1 100%;
    }

}
/* ============================================================
   PRODUCT LIST
============================================================ */

.expense-product-modal .product-list-panel {
    border: 1px solid var(--bs-border-color);
    border-radius: 12px;
    background: var(--bs-body-bg);
    /* overflow: hidden; */
}


/* ============================================================
   LIST HEADER
============================================================ */

.expense-product-modal .product-list-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 12px 14px;

    border-bottom: 1px solid var(--bs-border-color);

    background: var(--bs-tertiary-bg);
}

.expense-product-modal .product-list-title {
    color: var(--bs-body-color);
    font-size: 13px;
    font-weight: 600;
}

.expense-product-modal .product-list-title i {
    color: var(--bs-primary);
    font-size: 15px;
}

.expense-product-modal .product-list-subtitle {
    margin-top: 2px;

    color: var(--bs-secondary-color);
    font-size: 11px;
}

.expense-product-modal .product-list-count {
    min-width: 28px;
    height: 24px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 0 8px;

    border-radius: 20px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 11px;
    font-weight: 600;
}


/* ============================================================
   SEARCH
============================================================ */

.expense-product-modal .product-list-search {
    padding: 10px 12px;
    border-bottom: 1px solid var(--bs-border-color);
}

.expense-product-modal .product-list-category-search {
    padding: 10px 12px;
    border-bottom: 1px solid var(--bs-border-color);
}

.expense-product-modal .product-list-search .input-group-text {
    min-width: 38px;

    background: var(--bs-body-bg);
    border-right: 0;
}

.expense-product-modal .product-list-search .form-control {
    min-height: 36px;

    border-left: 0;

    font-size: 12px;
}

.expense-product-modal .product-list-search .form-control:focus {
    box-shadow: none;
}

.expense-product-modal .product-list-search .btn {
    min-width: 38px;
}


/* ============================================================
   LIST SCROLL AREA
============================================================ */

.expense-product-modal .product-list {
    /* max-height: 235px; */

    overflow-y: auto;
    overflow-x: hidden;

    padding: 4px 8px;
}

.expense-product-modal .product-list::-webkit-scrollbar {
    width: 5px;
}

.expense-product-modal .product-list::-webkit-scrollbar-track {
    background: transparent;
}

.expense-product-modal .product-list::-webkit-scrollbar-thumb {
    background: #d7dbe4;
    border-radius: 20px;
}


/* ============================================================
   PRODUCT ROW
============================================================ */

.expense-product-modal .product-list-item {
    display: flex;

    align-items: center;

    gap: 10px;

    padding: 9px 7px;

    border-bottom: 1px solid
        rgba(
            var(--bs-border-color-rgb),
            0.55
        );

    transition:
        background-color 0.15s ease,
        transform 0.15s ease;
}

.expense-product-modal .product-list-item:last-child {
    border-bottom: 0;
}

.expense-product-modal .product-list-item:hover {
    background: var(--bs-tertiary-bg);
    border-radius: 8px;
}


/* ============================================================
   PRODUCT ICON
============================================================ */

.expense-product-modal .product-list-icon {
    width: 34px;
    height: 34px;

    min-width: 34px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);

    font-size: 17px;
}


/* ============================================================
   PRODUCT CONTENT
============================================================ */

.expense-product-modal .product-list-content {
    flex: 1;

    min-width: 0;
}

.expense-product-modal .product-list-name {
    color: var(--bs-body-color);

    font-size: 12px;
    font-weight: 600;

    line-height: 17px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;
}

.expense-product-modal .product-list-meta {
    display: flex;

    align-items: center;

    gap: 6px;

    margin-top: 2px;

    min-width: 0;
}

.expense-product-modal .product-list-category {
    max-width: 150px;

    overflow: hidden;

    white-space: nowrap;

    text-overflow: ellipsis;

    color: var(--bs-secondary-color);

    font-size: 10px;
}

.expense-product-modal .product-list-code {
    color: var(--bs-secondary-color);

    font-size: 9px;
}

.expense-product-modal .product-list-dot {
    color: var(--bs-secondary-color);

    opacity: 0.5;
}


/* ============================================================
   ACTIONS
============================================================ */

.expense-product-modal .product-list-actions {
    display: flex;

    align-items: center;

    gap: 3px;

    flex-shrink: 0;
}

.expense-product-modal .product-list-action {
    width: 30px;
    height: 30px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 0;

    border: 0;

    border-radius: 7px;

    background: transparent;

    color: var(--bs-secondary-color);

    transition:
        background-color 0.15s ease,
        color 0.15s ease;
}

.expense-product-modal .product-list-action:hover {
    background: rgba(
        var(--bs-primary-rgb),
        0.10
    );

    color: var(--bs-primary);
}

.expense-product-modal .product-list-action.delete:hover {
    background: rgba(
        var(--bs-danger-rgb),
        0.10
    );

    color: var(--bs-danger);
}

.expense-product-modal .product-list-action i {
    font-size: 16px;
}


/* ============================================================
   EMPTY STATE
============================================================ */

.expense-product-modal .product-list-empty {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    padding: 25px 15px;

    text-align: left;
}

.expense-product-modal .product-list-empty-icon {
    width: 38px;
    height: 38px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: var(--bs-tertiary-bg);

    color: var(--bs-secondary-color);

    font-size: 18px;
}

.expense-product-modal .product-list-empty strong {
    display: block;

    color: var(--bs-body-color);

    font-size: 12px;
}

.expense-product-modal .product-list-empty small {
    display: block;

    margin-top: 2px;

    color: var(--bs-secondary-color);

    font-size: 10px;
}


/* ============================================================
   LOADING
============================================================ */

.expense-product-modal .product-list-loading {
    display: flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    padding: 25px;

    color: var(--bs-secondary-color);

    font-size: 11px;
}


/* ============================================================
   LOAD MORE
============================================================ */

.expense-product-modal .product-list-more {
    padding: 8px;

    text-align: center;

    border-top: 1px solid var(--bs-border-color);
}

.expense-product-modal .product-list-more .btn {
    font-size: 11px;
}


/* ============================================================
   MOBILE
============================================================ */

@media (max-width: 575.98px) {

    .expense-product-modal .product-list {
        max-height: 210px;
    }

    .expense-product-modal .product-list-category {
        max-width: 90px;
    }

    .expense-product-modal .product-list-item {
        padding: 8px 5px;
    }

    .expense-product-modal .product-list-icon {
        width: 32px;
        height: 32px;
        min-width: 32px;
    }

    .expense-product-modal .product-list-action {
        width: 28px;
        height: 28px;
    }

}
</style>
<script>

    let modalProduct =null ;
    let formProduct =null ;
    let productListDataGlobal =[] ;

    function initProduct() {
        modalProduct = document.getElementById('productModal');
        formProduct = document.getElementById('productForm');
        if (!modalProduct || !formProduct) {
            return;
        }
        bindProductEvents();
        resetProductForm();
    }

    function bindProductEvents() {
        const self = this;
        $(formProduct).on('submit',
            function (event) {
                event.preventDefault();
                submitProduct();
            }
        );


        /* RESET  */

        $('#btnResetProduct').on('click',
            function () {
                resetProductForm();
            }
        );

        $(document).on('click','[data-bs-target="#productModal"], #btnAddProduct',
            function () {
                openProductCreate();
            }
        );


        $('#productListSearch').on('input',
            function () {
                const value = $.trim($(this).val());
                if (value) {
                    $('#btnClearProductSearch').removeClass('d-none');
                } else {
                    $('#btnClearProductSearch').addClass('d-none');
                }
                renderProductList(productListDataGlobal || []);
            }
        );
       

        $('#btnClearProductSearch').on('click',
            function () {
                $('#productListSearch').val('').trigger('input');
            }
        );

        $(document).on('click','[data-product-edit]',
            function () {
                const id = $(this).data('product-edit');
                if (id) {
                    openProductEdit(id);
                }
            }
        );

        $(document).on('click','[data-product-delete]',
            function () {
                const id = $(this).data('product-delete');
                if (!id) {
                    return;
                }

                if (typeof Swal === 'undefined' ) {
                    if (confirm('Delete this expense product?' ) ) {
                       deleteProduct(id);
                    }
                    return;
                }

                Swal.fire({
                    title: 'Delete Product?',
                    text: 'This product will no longer be available for new expenses.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then(
                    function (result) {
                        if (result.isConfirmed) {
                            deleteProduct(id );
                        }
                    }
                );
                
            }
        );

        /*  PRODUCT NAME  */
        $('#product_name').on('input',
            function () {
                updateProductPreview();
            }
        );

        /* CATEGORY  */
        $('#product_category_id').on('change',
            function () {
                updateProductCategoryPreview();
                updateProductPreview();
                clearProductFieldError('product_category_id');
            }
        );

        /* DEFAULT AMOUNT */

        $('#default_amount').on('input',
            function () {
                updateProductAmountPreview();
                clearProductFieldError('default_amount' );
            }
        );


        /* MODAL HIDDEN  */
        $(modalProduct).on( 'hidden.bs.modal',
            function () {
                resetProductForm();
            }
        );

    }

    /*  DELETE PRODUCT  */
    function deleteProduct(id) {

        const self = this;
        const url =buildProductUrl( window.expenseRoutes.productDelete, id );

        if (!url) {
            showProductError('Product delete endpoint is not configured.' );
            return;
        }
        $.ajax({
            url: url,
            type: 'POST',
            data: {
                _token:$('meta[name="csrf-token"]').attr('content'),
                _method: 'DELETE'
            },
            dataType: 'json',
            success: function (response) {
                if (response && response.success ) {
                    showProductSuccess( response.message || 'Expense product deleted successfully.' );
                    loadProductList();
                    $(document).trigger('expense:product:deleted',[id]);
                } else {
                    showProductError(response.message || 'Unable to delete product.');
                }
            },
            error: function (xhr) {
                handleProductAjaxError(xhr,'Unable to delete expense product.');
            }
        });

    }

    /* OPEN CREATE  */
    function openProductCreate() {
        
            resetForNextProduct();
        $('#productFormMode').val('create');
        $('#productModelTitleLabel').text('Add Expense Product');
        $('#productSaveText').text('Save Product');
        $('#productListSearch').val('');
        $('#btnClearProductSearch').addClass('d-none');
        updateProductPreview();
        showProductModal();
        loadProductCategories();
        loadFilterProductCategories();
        loadProductList();
    }

    function loadProductCategories(selected = '') {
        $.get(
        window.expenseRoutes.categories,
        response => {
            let html = '<option value="">Select Category</option>';
            response.data.forEach(category => {
            html += `
                    <option value="${category.sno}" data-icon="${category.icon}">
                        ${category.category_name}
                    </option>
                    `;
            });
            $('#product_category_id').html(html);
        }
        );
    }
    function loadFilterProductCategories(selected = '') {
         $('#filter_product_category_id').val('');
         $('#filter_product_category_id').val('').change();
        $.get(
        window.expenseRoutes.categories,
        response => {
            let html = '<option value="">All Category</option>';
            response.data.forEach(category => {
            html += `
                    <option value="${category.sno}" ">
                        ${category.category_name}
                    </option>
                    `;
            });
            $('#filter_product_category_id').html(html);
        }
        );
    }

     
    function filter_category_func() {
        
        renderProductList(productListDataGlobal || []);
    }
        

    /* OPEN EDIT */
    function openProductEdit(id) {
        const self = this;
        if (!id) {
            return;
        }

        resetProductForm();

        $('#productFormMode').val('edit');
        $('#expense_product_edit_id').val(id);
        $('#productModelTitleLabel').text('Edit Expense Product' );
        $('#productSaveText').text( 'Update Product' );


        showProductModal();

        setProductLoading(true);

        const url = buildProductUrl( window.expenseRoutes.productShow,  id );

        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                if (response && response.success && response.data ) {
                   fillProductForm(response.data);
                } else {
                    showProductError( response.message || 'Unable to load product.');
                }
            },
            error: function (xhr) {
                handleProductAjaxError( xhr,'Unable to load expense product.' );
            },
            complete: function () {
                setProductLoading(false);
            }
        });
    }

    /* FILL FORM */
    function fillProductForm(data) {
        
        $('#expense_product_edit_id').val(data.sno || '');

        $('#product_name').val( data.product_name || '');
        $('#product_category_id').val(data.category_id || '').trigger('change');
        

        // $('#productFormMode').val('edit');

        $('#product_email').val(data.email_id || '');
        $('#product_mobile').val(data.mobile_no || '');
        $('#product_website').val(data.website || '');
        $('#frequency_type').val(data.frequency_type || '').trigger('change');
        $('#currency_type').val(data.currency_type || 'INR').trigger('change');
        $('#default_amount').val(data.default_amount ?? '');
        // $('#amount_inr').val(data.amount_inr && Number(data.amount_inr) > 0 ? data.amount_inr : '');
        $('#is_recurring').prop('checked',Number(data.is_recurring) === 1);
        $('#billing_date').val(data.billing_date || '');
        $('#product_remarks').val(data.remarks || '');
        $('#is_gst_applicable').prop('checked', Number(data.is_gst_applicable) === 1 );

        updateProductCurrencyUI();
        updateRecurringUI();

        updateProductCategoryPreview();
        updateProductPreview();
        
    }

    function updateProductCurrencyUI() {

        const currency = $('#currency_type').val();

        if (currency === 'USD') {
            $('#defaultAmountLabel').text('Default Amount (USD)');
            $('#defaultAmountSymbol').text('$');
            // $('#amountInrWrapper').stop(true, true).slideDown(150);
        } else {
            $('#defaultAmountLabel').text('Default Amount (INR)');
            $('#defaultAmountSymbol').text('₹');
            // $('#amountInrWrapper').stop(true, true).slideUp(150);
            // $('#amount_inr').val('').removeClass('is-invalid');
            // $('.amount_inr_error').text('');
        }
    }

    function updateRecurringUI() {

        const recurring = $('#is_recurring').is(':checked');

        if (recurring) {
            $('#billingDateWrapper').stop(true, true).slideDown(150);
        } else {
            $('#billingDateWrapper').stop(true, true).slideUp(150);
            $('#billing_date').val('').removeClass('is-invalid');
            $('.billing_date_error').text('');
        }
    }
        
    /* SUBMIT  */
    function submitProduct() {
        const mode = $('#productFormMode').val();
        const id = $('#expense_product_edit_id').val();
    
        clearProductErrors();

        if (!validateProduct()) {
            return;
        }

        if (mode === 'edit' && !id ) {
            showProductError('Invalid product ID.');
            return;
        }


        let url;
        let method;

        if (mode === 'edit') {
            url = buildProductUrl(window.expenseRoutes.productUpdate,id);
            method = 'POST';
        } else {
            url = window.expenseRoutes.productStore;
            method = 'POST';
        }


        const self = this;

        const formData = new FormData(formProduct);

        if (method === 'PUT') {
            formData.append('_method', 'PUT');
        }

        setProductSaving(true);
        
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function (response) {
                if (response && response.success) {
                    showProductSuccess( response.message ||
                        ( mode === 'edit' ? 'Expense product updated successfully.' : 'Expense product created successfully.')
                    );

                    /* UPDATE*/
                    if (mode === 'edit') {
                        refreshProductList();
                        closeProductModal();
                        return;
                    }

                    /*CREATE */
                    refreshProductList();
                    resetForNextProduct();

                    setTimeout(function () {
                        $('#product_name').trigger('focus');
                    }, 150);

                } else {
                    showProductError(response.message ||'Unable to save product.');
                }
            },
            error: function (xhr) {
                handleProductAjaxError(xhr,'Unable to save expense product.' );

            },
            complete: function () {
                setProductSaving(false);
            }

        });
    }

    function resetForNextProduct() {

        if (!formProduct) {
            return;
        }

        formProduct.reset();

        $('#expense_product_edit_id').val('');

        $('#productFormMode').val('create');


        $('#productModelTitleLabel').text('Add Expense Product');

        $('#productSaveText').text('Save Product');

        clearProductErrors();

        const $category = $('#product_category_id');
        $category.val('').trigger('change');

        const $frequency = $('#frequency_type');
        $frequency.val('').trigger('change');

        const $currency = $('#currency_type');
        $currency.val('INR').trigger('change');

        $('#productCategoryInfo').addClass('d-none');

        $('#productCategoryInfoName').text('-');

        $('#productCategoryInfoIcon').html('<i class="mdi mdi-shape-outline"></i>');

        $('#productPreviewName').text('New Expense Product');
        $('#productPreviewCode').text('AUTO');
        $('#productPreviewCategory').text('No Category');
        $('#productPreviewIcon').attr('class', 'mdi mdi-package-variant-closed');

        setProductSaving(false);

    }

    /*VALIDATION*/
    function validateProduct() {

        clearProductErrors();

        let valid = true;

        const category = $.trim($('#product_category_id').val());
        // const code = $.trim($('#product_code').val());
        const name = $.trim($('#product_name').val());
        const email = $.trim($('#product_email').val());
        const mobile = $.trim($('#product_mobile').val());
        const website = $.trim($('#product_website').val());
        const frequency =$.trim($('#frequency_type').val());
        const currency = $.trim($('#currency_type').val());
        const defaultAmount = $.trim($('#default_amount').val());
        // const amountInr = $.trim($('#amount_inr').val());
        const recurring = $('#is_recurring').is(':checked');
        const billingDate = $.trim($('#billing_date').val());

        /* === CATEGORY === */
        if (!category) {
            setProductFieldError('product_category_id', 'Please select an expense category.');
            valid = false;
        }

        /* === PRODUCT NAME === */
        if (!name) {
            setProductFieldError('product_name', 'Product name is required.' );
            valid = false;
        } else if (name.length > 250) {
            setProductFieldError('product_name','Product name cannot exceed 250 characters.' );
            valid = false;
        }


        /* ==== EMAIL ===== */
        if (email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                setProductFieldError('email_id','Please enter a valid email address.');
                toastr.error('Please enter a valid email address.');
                valid = false;
                    console.log("email error" )
            }
        }

        /* === MOBILE === */
        if (mobile) {
            const mobileRegex = /^[0-9+\-\s()]{7,30}$/;
            if (!mobileRegex.test(mobile)) {
                setProductFieldError( 'mobile_no', 'Please enter a valid mobile number.');
                valid = false;
                toastr.error('Please enter a valid mobile number.')
            }
        }

        /* ==== WEBSITE ==== */
        // if (website) {
        //     try {
        //         new URL(website);
        //     } catch (e) {
        //         setProductFieldError('website','Please enter a valid website URL.');
        //         valid = false;
        //             toastr.error('Please enter a valid website URL.')
        //     }
        // }

        /* === FREQUENCY === */
        if (!frequency) {
            setProductFieldError('frequency_type','Please select a frequency type.' );
            valid = false;
        }
        /* === CURRENCY ===== */
        if (!currency) {
            setProductFieldError( 'currency_type','Please select the amount type.' );
            valid = false;
        }

        /* ====DEFAULT AMOUNT====== */
        if (!defaultAmount) {
            setProductFieldError('default_amount','Default amount is required.');
            valid = false;
        } else if (!/^\d+(\.\d{1,2})?$/.test(defaultAmount) || Number(defaultAmount) < 0) {

            setProductFieldError('default_amount','Please enter a valid amount.');
            valid = false;
        }


        /* ==  USD -> INR ====== */
        // if (currency === 'USD') {
        //     if (!amountInr) {
        //         setProductFieldError('amount_inr','INR equivalent amount is required for USD.');
        //         valid = false;
        //     } else if (!/^\d+(\.\d{1,2})?$/.test(amountInr) || Number(amountInr) < 0) {
        //         setProductFieldError('amount_inr','Please enter a valid INR amount.');
        //         valid = false;
        //     }
        // }

        /* ===== RECURRING ====== */
        if (recurring && !billingDate) {
            setProductFieldError('billing_date', 'Billing date is required for recurring products.');
            valid = false;
        }

        return valid;

    }

    /* FIELD ERROR */
    function setProductFieldError(field, message) {

        const $form = $('#productForm');

        const $field = $form.find('#' + field);

        if (!$field.length) {
            console.warn('Validation field not found:', field);
            return;
        }

        // Add invalid state
        $field.addClass('is-invalid');

        // Find the error belonging to this field
        let $error = $form.find('.' + field + '_error');

        // Special case for category if required
        if (field === 'product_category_id') {
            $error = $form.find('.product_category_error');
        }

        if ($error.length) {
            $error.text(message).css('display', 'block');
        } else {
            console.warn('Validation error element not found:',field + '_error');
        }
    }

    /* CLEAR FIELD ERROR */
    function clearProductFieldError(field) {

        const $form = $('#productForm');

        const $field = $form.find('#' + field);

        if (!$field.length) {
            return;
        }

        $field.removeClass('is-invalid');

        let $error = $form.find('.' + field + '_error');

        if (field === 'product_category_id') {
            $error = $form.find('.product_category_error');
        }

        $error.text('').css('display', 'none');
    }

    /* CLEAR ALL ERRORS */
    function clearProductErrors() {
        const $form = $('#productForm');
        $form.find('.is-invalid').removeClass('is-invalid');
        $form.find('.invalid-feedback').text('').css('display', 'none');
    }

    /* UPDATE PREVIEW */
    function updateProductPreview() {
        const name = $.trim($('#product_name').val());

        // const code = $.trim(
        //     $('#product_code').val()
        // );
        const categoryText = $('#product_category_id option:selected').text();
        $('#productPreviewName').text( name || 'New Expense Product');
        $('#productPreviewCode').text('CODE');

        if (!categoryText || categoryText === 'Select Category') {
            $('#productPreviewCategory').text('No Category');
        } else {
            $('#productPreviewCategory').text($.trim(categoryText));
        }
        updateProductAmountPreview();
    }

    /*  UPDATE AMOUNT  */
    function updateProductAmountPreview() {
        const value = parseFloat($('#default_amount').val());
        const amount = !isNaN(value) && value >= 0 ? value : 0;
        $('#productPreviewAmount').text(formatProductCurrency(amount) );
    }

    /* UPDATE CATEGORY PREVIEW  */
    function updateProductCategoryPreview() {
        const select = $('#product_category_id' );
        const option = select.find('option:selected');
        const categoryId = select.val();

        if (!categoryId) {
            $('#productCategoryInfo').addClass('d-none');
            return;
        }
        const categoryName =  $.trim(option.text());
        const icon = option.attr('data-icon');

        $('#productCategoryInfo').removeClass('d-none');
        $('#productCategoryInfoName').text(categoryName);

        const iconElement = $('#productCategoryInfoIcon' );

        if (icon) {
            
            let iconClass = icon;

            if (iconClass.indexOf('mdi ') === -1 ) {
                if (iconClass.indexOf('mdi-') === 0) {
                    iconClass = 'mdi ' + iconClass;
                }
            }

            iconElement.html('<i class="' + escapeProductHtml(iconClass) + '"></i>');
        } else {
            iconElement.html('<i class="mdi mdi-shape-outline"></i>');
        }
    }

    /* RESET FORM */
    function resetProductForm() {
        if (!formProduct) {
            return;
        }


        formProduct.reset();
            console.log('Reset Form')
        $('#expense_product_edit_id').val('');

        $('#productFormMode').val('create');
        $('#productModelTitleLabel').text('Add Expense Product');
        $('#productSaveText').text('Save Product');

        clearProductErrors();

        $('#productCategoryInfo').addClass('d-none');
        $('#productPreviewName').text('New Expense Product');
        $('#productPreviewCode').text('CODE');
        $('#productPreviewCategory').text('No Category');

        $('#productPreviewAmount').text('₹0.00');

        $('#productPreviewIcon').attr('class','mdi mdi-package-variant-closed');

        $('#productCategoryInfoIcon').html('<i class="mdi mdi-shape-outline"></i>');

        setProductSaving(false);

    }

    /* SHOW MODAL  */
    function showProductModal() {
        const element = document.getElementById('productModal');

        if (!element) {
            return;
        }

        if (typeof bootstrap !== 'undefined' ) {
            const modal = bootstrap.Modal.getOrCreateInstance(element );
            modal.show();
        }

    }

    /*  CLOSE MODAL  */
    function closeProductModal() {
        const element = document.getElementById('productModal');

        if (!element) {
            return;
        }

        if (typeof bootstrap !== 'undefined' ) {
            const modal = bootstrap.Modal.getInstance(element);
            if (modal) {
                modal.hide();
            }
        }
    }

    /* LOADING */
    function setProductLoading(loading ) {

        const form =$('#productForm');

        form.find('input, select, button').prop('disabled',loading);

        if (loading) {
            $('#productModal').addClass('is-loading');
        } else {
            $('#productModal').removeClass('is-loading');
        }

    }

    /* SAVING */
    function setProductSaving(saving) {

        const button = $('#btnSaveProduct');

        if (saving) {
            button.prop('disabled',true);
            $('#productLoader').removeClass('d-none');
            $('#productSaveIcon').addClass('d-none');
        } else {
            button.prop('disabled',false );
            $('#productLoader').addClass('d-none');
            $('#productSaveIcon').removeClass('d-none');
        }
    }

    /* BUILD URL  */
    function buildProductUrl(template, id ) {
        if (!template) {
            return '';
        }

        return template.replace( ':id',encodeURIComponent(id));
    }

    /* REFRESH PRODUCT LIST */
    function refreshProductList() {

        loadProductList();
        $(document).trigger('expense:product:saved');

    }

    /*  LOAD PRODUCT LIST */
    function loadProductList() {
        const self = this;
        const $loading = $('#productListLoading');
        const $empty = $('#productListEmpty');
        const $list = $('#productList');
        const $more = $('#productListMore');

        $loading.removeClass('d-none');
        $empty.addClass('d-none');
        $more.addClass('d-none');

        $list.empty();


        if ( !window.expenseRoutes || !window.expenseRoutes.productList ) {
            $loading.addClass('d-none');
            $empty.removeClass('d-none').find('strong').text('Product list unavailable.');
            return;
        }

        $.ajax({
            url: window.expenseRoutes.productList,
            type: 'GET',
            dataType: 'json',
            success: function (response) {
                const products = response && response.success && Array.isArray(response.data) ? response.data : [];
                productListDataGlobal = products;
                renderProductList(products);
            },
            error: function (xhr) {
                console.error('Product list error:', xhr.responseText);

                $empty.removeClass('d-none');
                $empty.find('strong').text('Unable to load products.');
                $empty.find('small').text('Please try again.');
            },
            complete: function () {
                $loading.addClass('d-none');
            }
        });

    }

    /* RENDER PRODUCT LIST */
    function renderProductList(products) {

        const $list = $('#productList');
        const $empty =$('#productListEmpty');
        const search =$.trim( $('#productListSearch').val()).toLowerCase();
        const categoryFilter = $('#filter_product_category_id').val();
       
                                                            
        let filtered =
            products.filter(function (product) {

                if (!search && categoryFilter =='') {
                    return true;
                }

                const name = String(product.product_name || '').toLowerCase();
                const category =String(product.category_name || '').toLowerCase();
               const categoryId = String(product.category_id || '').trim();
                const code =String(product.product_code || '').toLowerCase();

                const matchesSearch =
                        !search ||
                        name.includes(search) ||
                        category.includes(search) ||
                        code.includes(search);

                 const matchesCategory =
                    !categoryFilter ||
                    categoryId === categoryFilter;
                 return matchesSearch && matchesCategory;

            });

            


        $('#productListCount').text(filtered.length);

        if (!filtered.length) {
            $list.empty();
            $empty.removeClass('d-none');
            return;
        }

        $empty.addClass('d-none');

        let html = '';


        filtered.forEach(
            function (product) {
                const id = Number(product.sno || 0);
                if (!id) {
                    return;
                }

                const name = escapeProductHtml(product.product_name || 'Unnamed Product');
                const category =escapeProductHtml( product.category_name ||'No Category' );
                const code = escapeProductHtml( product.product_code || 'AUTO' );

                let icon = product.icon || 'mdi-package-variant-closed';

                if (!icon.includes('mdi ')) {
                    if (icon.indexOf('mdi-') === 0 ) {
                        icon = 'mdi ' + icon;
                    }
                }

                icon =escapeProductHtml(icon);

                html += `
                    <div class="product-list-item" data-product-id="${id}">
                        <div class="product-list-icon">
                            <i class="${icon}"></i>
                        </div>
                        <div class="product-list-content">
                            <div class="product-list-name" title="${name}">
                                ${name}
                            </div>
                            <div class="product-list-meta">
                                <span class="product-list-category" title="${category}">
                                    ${category}
                                </span>
                                <span class="product-list-dot">
                                    •
                                </span>
                                <span class="product-list-code">
                                    ${code}
                                </span>
                            </div>
                        </div>
                        <div class="product-list-actions">
                            <button type="button"
                                class="product-list-action"
                                data-product-edit="${id}"
                                title="Edit product">
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>
                            <button type="button"
                                class="product-list-action delete"
                                data-product-delete="${id}"
                                title="Delete product">
                                <i class="mdi mdi-delete-outline"></i>
                            </button>
                        </div>
                    </div>
                `;
            }
        );

        $list.html(html);

    }

    /* AJAX ERROR*/
    function handleProductAjaxError(xhr,fallbackMessage ) {
        if (
            xhr &&
            xhr.status === 422 &&
            xhr.responseJSON &&
            xhr.responseJSON.errors
        ) {

            const errors = xhr.responseJSON.errors;

            Object.keys(errors).forEach(
                function (field) {
                    if (errors[field] && errors[field][0]) {
                        setProductFieldError(field,errors[field][0]);
                    }

                }
            );

            showProductError( xhr.responseJSON.message || 'Please correct the highlighted fields.');
            return;
        }


        if (xhr && xhr.status === 419) {
            showProductError('Your session has expired. Please refresh the page and try again.');
            return;
        }


        if (xhr &&  xhr.status === 404) {
            showProductError('Product endpoint was not found.');
            return;

        }

        showProductError(
            (
                xhr &&
                xhr.responseJSON &&
                xhr.responseJSON.message
            ) || fallbackMessage );

    }

    /* SUCCESS MESSAGE  */
    function showProductSuccess(message ) {
        if (typeof window.showToast ==='function') {
            window.showToast( 'success', message);
            return;
        }
        toastr.success(message)
    }

    /* ERROR MESSAGE */
    function showProductError(message) {

        if (typeof window.showToast === 'function') {
            window.showToast('error',message);
            return;
        }

        toastr.error(message)
    }

    /* CURRENCY */
    function formatProductCurrency(amount) {

        const number = Number(amount) || 0;

        return '₹' +
            number.toLocaleString(
                'en-IN',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );
    }

    /* ESCAPE HTML */
    function escapeProductHtml(value) {
        return String(value)
            .replace(/&/g,'&amp;' )
            .replace(/</g,'&lt;' )
            .replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;')
            .replace(/'/g,'&#039;');
    }

    $(document).on('click', '[data-action="add-product"]',

        function (event) {
            event.preventDefault();
            openProductCreate();
        }
    );

    $(document).on( 'click','[data-action="edit-product"]',
        function (event) {
            event.preventDefault();
            const id = $(this).data('id');
            if (id) {
                openProductEdit(id);
            }
        }
    );

</script>

<script>
    function category_icon_chnage_func () {

            const select = $('#product_category_id');
            const option = select.find('option:selected');
            const categoryId = select.val();

            if (!categoryId) {
                $('#productCategoryInfo').addClass('d-none');
                return;
            }

            const categoryName = $.trim(option.text());
            const icon = option.attr('data-icon');

            $('#productCategoryInfo').removeClass('d-none');
            $('#productCategoryInfoName').text( categoryName);
            const iconElement = $('#productCategoryInfoIcon' );
              console.log("icon",icon)                                          
            if (icon) {
                let iconClass = icon;

                if (iconClass.indexOf( 'mdi ' ) === -1) {
                    if (iconClass.indexOf('mdi-') === 0) {
                        iconClass ='mdi ' +iconClass;
                    }
                }
                iconElement.html('<i class="' + escapeHtml(iconClass) +'"></i>');
            } else {
                iconElement.html('<i class="mdi mdi-shape-outline"></i>');
            }


             const name = $.trim($('#product_name').val());


            // const code = $.trim(
            //     $('#product_code').val()
            // );

            const categoryText = $('#product_category_id option:selected').text();
            $('#productPreviewName').text(name || 'New Expense Product' );

            $('#productPreviewCode').text('CODE' );
            if (!categoryText || categoryText === 'Select Category' ) {
                $('#productPreviewCategory').text('No Category');
            } else {
                $('#productPreviewCategory').text($.trim(categoryText));

            }

    }

    function escapeHtml(value) {
        return String(value).replace( /&/g,'&amp;')
            .replace(/</g,'&lt;')
            .replace(/>/g,'&gt;')
            .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }
</script>

<script>
    function updateProductCurrencyUIGlobal() {

        const currency =
            $('#currency_type').val();

        if (currency === 'USD') {

            $('#defaultAmountLabel')
                .text('Default Amount (USD)');

            $('#defaultAmountSymbol')
                .text('$');

            // $('#amountInrWrapper')
            //     .stop(true, true)
            //     .slideDown(150);

        } else {

            $('#defaultAmountLabel')
                .text('Default Amount (INR)');

            $('#defaultAmountSymbol')
                .text('₹');

            // $('#amountInrWrapper')
            //     .stop(true, true)
            //     .slideUp(150);

            // $('#amount_inr')
            //     .val('')
            //     .removeClass('is-invalid');

            // $('.amount_inr_error')
            //     .text('');
        }
    }

    function updateRecurringUIGlobal() {

        const recurring = $('#is_recurring').is(':checked');

        if (recurring) {
            $('#billingDateWrapper')
                .stop(true, true)
                .slideDown(150);

        } else {
            $('#billingDateWrapper')
                .stop(true, true)
                .slideUp(150);

            $('#billing_date')
                .val('')
                .removeClass('is-invalid');

            $('.billing_date_error')
                .text('');
        }
    }

    $(document).on('change','#is_recurring',
        function () {
            updateRecurringUIGlobal();
        }
    );

    initProduct();
</script>