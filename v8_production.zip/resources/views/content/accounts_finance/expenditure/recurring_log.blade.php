@extends('layouts/layoutMaster')

@section('title', 'Manage Recurring')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss', 
'resources/assets/vendor/libs/apex-charts/apex-charts.scss',

'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/dropzone/dropzone.js', 
])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp



<style>
  
  :root {
    /* Primary Brand */
    --expense-primary: #b12a1f;
    --expense-primary-hover: #8f1f16;
    --expense-secondary: #f5a623;

    /* Status */
    --expense-success: #22c55e;
    --expense-danger: #dc2626;
    --expense-warning: #f59e0b;
    --expense-info: #0ea5e9;
    --expense-purple: #7c3aed;
    --expense-muted: #6b7280;
   
   

    /* Background */
    --expense-bg: #f5f5f9;
    --expense-card: #ffffff;

    /* Text */
    --expense-text: #1f2937;
    --expense-text-light: #6b7280;

    /* Borders */
    --expense-border: #e5e7eb;
    --expense-border-light: #f1f3f5;

    /* Brand Accent */
    --expense-accent: #f5a623;
    --expense-accent-light: #fff4de;

    /* Radius */
    --expense-radius-sm: 10px;
    --expense-radius: 14px;
    --expense-radius-lg: 18px;

    /* Shadow */
    --expense-shadow-sm: 0 2px 6px rgba(0, 0, 0, 0.05);

    --expense-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);

    --expense-shadow-hover: 0 12px 28px rgba(177, 42, 31, 0.15);

    /* Animation */
    --expense-transition: 0.28s ease;
  }

.recurring-status-badge.lifetime {
    background: #ede9fe;
    color: #6d28d9;
}

.recurring-row.status-lifetime {
    background: linear-gradient(
        90deg,
        rgba(124,58,237,.2),
        transparent 45%
    );
}

.recurring-row .statusbar-lifetime {
    background: #7c3aed;
}
</style>

<style>
  /* =========================================================
   RECURRING MASTER
   ========================================================= */

.recurring-page {
   
   
   
}


.recurring-header {
    padding: 16px;

    border: 1px solid var(--expense-border);
    border-radius: 16px;

    background: #fff;

    box-shadow: 0 3px 15px rgba(0,0,0,.04);
}


/* Header icon */

.recurring-page-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #fff0ee;
    color: var(--expense-primary);

    font-size: 22px;
}


/* Stats */

.recurring-stat-card {
    position: relative;

    display: flex;
    align-items: center;
    gap: 15px;

    min-height: 118px;

    padding: 20px;

    border: 1px solid var(--expense-border);
    border-radius: 16px;

    background: #fff;

    box-shadow: 0 3px 15px rgba(0,0,0,.04);

    transition: .25s ease;
}

.recurring-stat-card:hover {
    transform: translateY(-3px);
    box-shadow: var(--expense-shadow);
}

.recurring-stat-card .stat-icon {
    width: 48px;
    height: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 14px;

    font-size: 22px;
}

.stat-total .stat-icon {
    background: #fff0ee;
    color: var(--expense-primary);
}

.stat-today .stat-icon {
    background: #fff7df;
    color: var(--expense-warning);
}

.stat-overdue .stat-icon {
    background: #fee2e2;
    color: var(--expense-danger);
}

.stat-paid .stat-icon {
    background: #dcfce7;
    color: var(--expense-success);
}

.recurring-stat-card small {
    display: block;
    color: var(--expense-muted);
    font-size: 12px;
}

.recurring-stat-card strong {
    display: block;
    margin-top: 2px;

    font-size: 27px;
    line-height: 1.1;
}

.recurring-stat-card span {
    font-size: 11px;
    color: #9ca3af;
}


/* =========================================================
   TABS
   ========================================================= */

.recurring-tab-card {
    padding: 7px;

    border: 1px solid var(--expense-border);
    border-radius: 16px;

    background: #fff;

    box-shadow: 0 3px 15px rgba(0,0,0,.04);
}

.recurring-tabs {
    display: flex;
    gap: 6px;
    overflow-x: auto;
}

.recurring-tab {
    flex: 1;

    min-width: 170px;

    display: flex;
    align-items: center;
    gap: 10px;

    padding: 12px 14px;

    border: 0;
    border-radius: 12px;

    background: transparent;

    text-align: left;

    transition: .2s ease;
}

.recurring-tab:hover {
    background: #fafafa;
}

.recurring-tab.active {
    background: #fff0ee;
    color: var(--expense-primary);
}

.recurring-tab .tab-icon {
    width: 36px;
    height: 36px;

    flex: 0 0 36px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: #f4f5f7;

    font-size: 18px;
}

.recurring-tab.active .tab-icon {
    background: #fff;
    color: var(--expense-primary);
}

.recurring-tab strong {
    display: block;
    font-size: 12px;
}

.recurring-tab small {
    display: block;
    margin-top: 2px;
    color: #9ca3af;
    font-size: 10px;
}

.recurring-tab b {
    margin-left: auto;

    min-width: 28px;
    height: 28px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: #f3f4f6;

    font-size: 11px;
}

.recurring-tab.active b {
    background: var(--expense-primary);
    color: #fff;
}


/* =========================================================
   FILTER
   ========================================================= */

.recurring-filter-card {
    border: 1px solid var(--expense-border);
    border-radius: 16px;

    box-shadow: 0 3px 15px rgba(0,0,0,.04);
}


/* =========================================================
   TABLE
   ========================================================= */

.recurring-master-card {
    /* overflow: hidden;  */

    border: 1px solid var(--expense-border);
    border-radius: 18px;

    box-shadow: var(--expense-shadow);
}

.recurring-table-header {
    padding: 20px 22px;
    background: #fff;
}

.recurring-master-table thead th {
    padding: 13px 16px;

    /* background: #fafbfc; */

    border-bottom: 1px solid var(--expense-border);

    /* color: #6b7280; */

    font-size: 11px;
    font-weight: 700;

    text-transform: uppercase;
    letter-spacing: .3px;
}
/* 
.recurring-master-table tbody td {
    padding: 15px 16px;

    vertical-align: middle;

    border-bottom: 1px solid #f1f2f5;
} */

.recurring-master-table tbody tr {
    transition: .2s ease;
}

.recurring-master-table tbody tr:hover {
    background: #fcfcfd;
}


/* =========================================================
   ROW STATUS
   ========================================================= */

.recurring-row {
    position: relative;
}

/* .recurring-row::before {
    content: '';
    position: absolute;
    left: 0;
    top: 8px;
    bottom: 8px;
    width: 3px;
    border-radius: 5px;
} */

.recurring-row.status-paid::before {
    background: var(--expense-success);
}

.recurring-row .statusbar-paid {
    background: var(--expense-success);
}

.recurring-row.status-tomorrow::before {
    background: var(--expense-warning);
}

.recurring-row .statusbar-tomorrow {
    background: var(--expense-warning);
}

.recurring-row.status-today::before {
    background: #f97316;
}

.recurring-row .statusbar-today {
    background: #f97316;
}

.recurring-row.status-overdue::before {
    background: var(--expense-danger);
}

.recurring-row .statusbar-overdue {
    background: var(--expense-danger);
}

.recurring-row.status-upcoming::before {
    background: var(--expense-info);
}

.recurring-row .statusbar-upcoming{
    background: var(--expense-info);
}

.recurring-row.status-dropped::before {
    background: #9ca3af;
}

.recurring-row.statusbar-dropped {
    background: #9ca3af;
}


/* Today */

.recurring-row.status-today {
    background:
        linear-gradient(
            90deg,
            rgba(249,115,22,.2),
            transparent 45%
        );
}


/* Tomorrow */

.recurring-row.status-tomorrow {
    background:
        linear-gradient(
            90deg,
            rgba(245,158,11,.2),
            transparent 45%
        );
}


/* Overdue */

.recurring-row.status-overdue {
    background:
        linear-gradient(
            90deg,
            rgba(220,38,38,.2),
            transparent 45%
        );
}


/* Dropped */

.recurring-row.status-dropped {
    opacity: .68;
}


/* Product */

.recurring-product {
    display: flex;
    align-items: center;
    gap: 11px;

    min-width: 220px;
}

.recurring-product-icon {
    width: 40px;
    height: 40px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 11px;

    background: #f5f6f8;

    color: var(--expense-primary);

    font-size: 18px;
}

.recurring-product-name {
    font-size: 13px;
    font-weight: 700;
}

.recurring-product-code {
    display: block;

    margin-top: 2px;

    color: #9ca3af;

    font-size: 10px;
}


/* Date */

.recurring-next-date {
    min-width: 135px;
}

.recurring-next-date strong {
    display: block;
    font-size: 13px;
}

.recurring-next-date small {
    display: block;
    margin-top: 3px;
    font-size: 10px;
}


/* Status badge */

.recurring-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;

    padding: 6px 9px;

    border-radius: 8px;

    font-size: 10px;
    font-weight: 700;
}

.recurring-status-badge.today {
    background: #fff0e0;
    color: #ea580c;
}

.recurring-status-badge.tomorrow {
    background: #fff7df;
    color: #b45309;
}

.recurring-status-badge.overdue {
    background: #fee2e2;
    color: #b91c1c;
}

.recurring-status-badge.upcoming {
    background: #e0f2fe;
    color: #0369a1;
}

.recurring-status-badge.paid {
    background: #dcfce7;
    color: #15803d;
}

.recurring-status-badge.dropped {
    background: #f3f4f6;
    color: #6b7280;
}

.recurring-history-item.upcoming { 
    /* background: #e0f2fe; */
    color: #0369a1;
}

.recurring-history-item.paid {
    /* background: #dcfce7; */
    color: #15803d;
}

.recurring-history-item.overdue {
    /* background: #fee2e2; */
    color: #b91c1c;
}
/* Live dot */

.recurring-live-dot {
    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;

    box-shadow: 0 0 0 4px #dcfce7;
}


/* Loading */

.recurring-loading,
.recurring-detail-loading {
    min-height: 220px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    gap: 10px;

    color: #8b93a3;
}


/* =========================================================
   DETAIL MODAL
   ========================================================= */

.recurring-detail-modal {
    overflow: hidden;
    border: 0;
    border-radius: 20px;
}

.recurring-modal-icon {
    width: 46px;
    height: 46px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background: #fff0ee;

    color: var(--expense-primary);

    font-size: 22px;
}

.recurring-status-hero {
    display: flex;
    align-items: center;
    gap: 14px;

    margin-bottom: 20px;
    padding: 17px;

    border-radius: 15px;

    background: #f8fafc;
}

.recurring-status-hero.upcoming { 
    background: #e0f2fe;
    color: #0369a1;
}

.recurring-status-hero.overdue {
    background: #fee2e2;
    color: #b91c1c;
}

.recurring-status-hero.today {
    background: #fff0e0;
    color: #ea580c;
}

.recurring-status-hero.tomorrow {
    background: #fff7df;
    color: #b45309;
}

.status-hero-icon {
    width: 46px;
    height: 46px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 13px;

    background: #fff;

    font-size: 22px;
}

.status-hero-label {
    display: block;

    margin-bottom: 2px;

    color: #8b93a3;

    font-size: 10px;
    font-weight: 700;

    text-transform: uppercase;
}

.status-hero-text {
    display: block;
    font-size: 15px;
}


/* Detail info */

.detail-info-card {
    height: 100%;

    padding: 14px;

    border: 1px solid var(--expense-border);
    border-radius: 12px;

    background: #fff;
}

.detail-info-card small {
    display: block;

    margin-bottom: 5px;

    color: #9ca3af;

    font-size: 10px;
}

.detail-info-card strong {
    font-size: 14px;
}


/* History summary */

.history-summary {
    display: flex;
    align-items: center;
    gap: 11px;

    padding: 14px;

    border-radius: 13px;
}

.history-summary i {
    font-size: 22px;
}

.history-summary small {
    display: block;
    font-size: 10px;
}

.history-summary strong {
    display: block;
    font-size: 17px;
}

.history-summary.paid {
    background: #ecfdf5;
    color: #15803d;
}

.history-summary.pending {
    background: #fff7ed;
    color: #c2410c;
}

.history-summary.overdue {
    background: #fef2f2;
    color: #b91c1c;
}

.history-summary.dropped {
    background: #f3f4f6;
    color: #6b7280;
}


/* Timeline */

.recurring-history-list {
    position: relative;
}

.recurring-history-item {
    position: relative;

    display: flex;
    gap: 14px;

    padding: 0 0 18px;
}

.recurring-history-line {
    width: 34px;
    flex: 0 0 34px;

    position: relative;

    display: flex;
    justify-content: center;
}

.recurring-history-line::after {
    content: '';

    position: absolute;

    top: 30px;
    bottom: -3px;

    width: 1px;

    background: #e5e7eb;
}

.recurring-history-item:last-child
.recurring-history-line::after {
    display: none;
}

.recurring-history-dot {
    position: relative;
    z-index: 2;

    width: 30px;
    height: 30px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: #f3f4f6;

    font-size: 15px;
}

.recurring-history-item.paid
.recurring-history-dot {
    background: #dcfce7;
    color: #15803d;
}

.recurring-history-item.today
.recurring-history-dot {
    background: #ffedd5;
    color: #ea580c;
}

.recurring-history-item.tomorrow
.recurring-history-dot {
    background: #fef3c7;
    color: #b45309;
}

.recurring-history-item.overdue
.recurring-history-dot {
    background: #fee2e2;
    color: #b91c1c;
}

.recurring-history-item.dropped
.recurring-history-dot {
    background: #f3f4f6;
    color: #6b7280;
}

.recurring-history-content {
    flex: 1;
}

.recurring-history-top {
    display: flex;
    justify-content: space-between;
    gap: 15px;
}

.recurring-history-date {
    font-size: 13px;
    font-weight: 700;
}

.recurring-history-meta {
    margin-top: 4px;

    color: #8b93a3;

    font-size: 10px;
}

.recurring-history-amount {
    font-size: 13px;
    font-weight: 800;
}

@media(max-width:768px) {

    .recurring-tabs {
        padding-bottom: 4px;
    }

    .recurring-tab {
        min-width: 155px;
    }

    .recurring-master-table {
        min-width: 950px;
    }
}
</style>

<div class="recurring-page">

    <!-- HEADER -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4 recurring-header">

        <div>
            <div class="d-flex align-items-center gap-2 mb-1">

                <div class="recurring-page-icon">
                    <i class="mdi mdi-calendar-sync-outline"></i>
                </div>

                <div>
                    <h4 class="mb-0 fw-bold">
                        Manage Recurring
                    </h4>

                    <small class="text-muted">
                        Monitor upcoming payments, reminders and recurring history.
                    </small>
                </div>

            </div>
        </div>

        <button
            type="button"
            class="btn btn-expense-primary btn-primary"
            id="refreshRecurring">

            <i class="mdi mdi-refresh me-1"></i>
            Refresh
        </button>

    </div>


    <!-- SUMMARY -->
    <!-- <div class="row g-3 mb-4">

        <div class="col-xl-3 col-md-6">

            <div class="recurring-stat-card stat-total">

                <div class="stat-icon">
                    <i class="mdi mdi-calendar-sync-outline"></i>
                </div>

                <div class="stat-content">

                    <small>Active Recurring</small>

                    <strong id="recurringTotal">
                        0
                    </strong>

                    <span>
                        subscriptions
                    </span>

                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="recurring-stat-card stat-today">

                <div class="stat-icon">
                    <i class="mdi mdi-bell-alert"></i>
                </div>

                <div class="stat-content">

                    <small>Due Today</small>

                    <strong id="recurringToday">
                        0
                    </strong>

                    <span>
                        payment reminders
                    </span>

                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="recurring-stat-card stat-overdue">

                <div class="stat-icon">
                    <i class="mdi mdi-alert-circle-outline"></i>
                </div>

                <div class="stat-content">

                    <small>Overdue</small>

                    <strong id="recurringOverdue">
                        0
                    </strong>

                    <span>
                        needs attention
                    </span>

                </div>

            </div>

        </div>


        <div class="col-xl-3 col-md-6">

            <div class="recurring-stat-card stat-paid">

                <div class="stat-icon">
                    <i class="mdi mdi-check-circle-outline"></i>
                </div>

                <div class="stat-content">

                    <small>Last Paid</small>

                    <strong id="recurringPaid">
                        0
                    </strong>

                    <span>
                        recently completed
                    </span>

                </div>

            </div>

        </div>

    </div> -->


    <!-- REMINDER TABS -->
    <div class="recurring-tab-card mb-4">
        <div class="recurring-tabs">
            <button type="button" class="recurring-tab active" data-recurring-tab="7_days">
                <span class="tab-icon">
                    <i class="mdi mdi-bell-ring-outline"></i>
                </span>
                <span>
                    <strong>Next 7 Days</strong>
                    <small>Reminder</small>
                </span>
                <b id="tabCount7">0</b>
            </button>
            <button type="button" class="recurring-tab" data-recurring-tab="current_month">
                <span class="tab-icon">
                    <i class="mdi mdi-calendar-month-outline"></i>
                </span>
                <span>
                    <strong>Current Month</strong>
                    <small>This month</small>
                </span>
                <b id="tabCountCurrent">
                    0
                </b>
            </button>
            <button type="button" class="recurring-tab" data-recurring-tab="next_month">
                <span class="tab-icon">
                    <i class="mdi mdi-calendar-arrow-right"></i>
                </span>
                <span>
                    <strong>Next Month</strong>
                    <small>Upcoming</small>
                </span>
                <b id="tabCountNext">
                    0
                </b>
            </button>
            <button type="button" class="recurring-tab" data-recurring-tab="6_months">
                <span class="tab-icon">
                    <i class="mdi mdi-calendar-range-outline"></i>
                </span>
                <span>
                    <strong>Next 6 Months</strong>
                    <small>Planning</small>
                </span>
                <b id="tabCount6">
                    0
                </b>
            </button>
            <button type="button" class="recurring-tab" data-recurring-tab="next_year">
                <span class="tab-icon">
                    <i class="mdi mdi-calendar-star-outline"></i>
                </span>
                <span>
                    <strong>Next Year</strong>
                    <small>Annual view</small>
                </span>
                <b id="tabCountYear">
                    0
                </b>
            </button>
            <button type="button"
                class="recurring-tab"
                data-recurring-tab="lifetime">

                <span class="tab-icon">
                    <i class="mdi mdi-infinity"></i>
                </span>

                <span>
                    <strong>Lifetime</strong>
                    <small>Lifetime</small>
                </span>

                <b id="tabCountLifetime">0</b>
            </button>

            <button type="button"
                    class="recurring-tab"
                    data-recurring-tab="all">

                <span class="tab-icon">
                    <i class="mdi mdi-view-list-outline"></i>
                </span>

                <span>
                    <strong>All</strong>
                    <small>Recurring + Lifetime</small>
                </span>

                <b id="tabCountAll">0</b>
            </button>
        </div>
    </div>

    <!-- MASTER TABLE -->
    <div class="card recurring-master-card">

        <div class="card-header recurring-table-header ">

            <div class="d-flex justify-content-between">

              <h5 class="mb-1">
                  Recurring Products
              </h5>

              <div class="d-flex align-items-center gap-2">

                  <span
                      class="recurring-live-dot">
                  </span>

                  <span
                      class="badge bg-label-primary"
                      id="recurringResultCount">

                      0 Records

                  </span>

              </div>
            </div>

        </div>


        <div class="row g-3 align-items-end px-4 pb-2">
            
            <div class="col-xl-4 col-lg-4">
                <div class="d-flex gap-2">
                    <div>
                        <label class="form-label"> Search</label>
                        <select class="form-select select3  w-75px" id="perpage" onchange="load(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                       
                    </div>
                    <div>
                        <label class="form-label">
                            Search
                        </label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="mdi mdi-magnify"></i>
                            </span>
                            <input
                                type="text"
                                class="form-control"
                                id="recurringSearch"
                                placeholder="Product, code or category...">
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="col-xl-3 col-lg-3">
                <label class="form-label">Category</label>
                <select class="form-select select3" id="recurringCategoryFilter" onchange="change_category_filter()">
                    <option value="">All Categories</option>
                    @foreach($expenseCategories as $category)
                        <option value="{{ $category->sno }}">
                            {{ $category->category_name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-xl-3 col-lg-3">
                <label class="form-label">
                    Payment Status
                </label>
                <select class="form-select select3" id="recurringStatusFilter" onchange="change_status_filter()">
                    <option value="">All Status</option>
                    <option value="today"> Due Today</option>
                    <option value="tomorrow">Due Tomorrow</option>
                    <option value="overdue">Overdue</option>
                    <option value="upcoming">Upcoming</option>
                    <option value="paid">Last Payment Paid</option>
                    <option value="dropped">Stopped</option>
                </select>
            </div>
            <div class="col-xl-2 col-lg-2">
                <button type="button"  class="btn btn-warning w-100" id="clearRecurringFilters" onclick="clearAllFilter()">
                    <i class="mdi mdi-filter-remove-outline me-1"></i>
                    Clear
                </button>
            </div>
        </div>
        <div class=" px-2 pb-2">
            <table class="table recurring-master-table mb-0">
                <thead>
                    <tr class="text-start fw-bold fs-7 gs-0 bg-primary text-white">
                        <th>Recurring</th>
                        <th>Frequency</th>
                        <th>Next Payment</th>
                        <th>Last Paid</th>
                        <th class="text-end">Amount</th>
                        <th>Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody id="recurringMasterBody">
                    <tr>
                        <td colspan="7">
                            <div class="recurring-loading">
                                <div class="spinner-border"></div>
                                <span>
                                    Loading recurring subscriptions...
                                </span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<!-- DETAIL MODAL -->




<div class="modal fade"  id="recurringDetailModal" tabindex="-1" aria-labelledby="recurringDetailModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content expense-modal">
            {{-- ==== Header ===== --}}
            <div class="modal-header border-bottom">
                <div>
                    
                    <div class="d-flex align-items-center gap-3">
                        <div class="recurring-modal-icon" id="modalProductIcon">
                            <i class="mdi mdi-calendar-sync-outline"></i>
                        </div>

                        <div>
                            <h5 class="modal-title mb-1" id="modalProductName">
                                Recurring Details
                            </h5>
                            <small class="text-muted" id="modalProductCode"></small>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="recurringDetailLoading" class="recurring-detail-loading">
                    <div class="spinner-border"></div>
                    <span>
                        Loading recurring history...
                    </span>
                </div>

                <div id="recurringDetailContent" class="d-none">
                    <!-- STATUS HERO -->
                    <div class="recurring-status-hero" id="detailStatusHero">
                        <div class="status-hero-icon" id="detailStatusIcon">
                            <i class="mdi"></i>
                        </div>
                        <div>
                            <span class="status-hero-label" id="detailStatusLabel"></span>
                            <strong id="detailStatusText"></strong>
                        </div>
                    </div>
                    <!-- MASTER INFO -->
                    <div class="row g-3 mb-4">
                        <div class="col-md-3">
                            <div class="detail-info-card">
                                <small>Frequency</small>
                                <strong id="detailFrequency">
                                </strong>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="detail-info-card">
                                <small>Next Payment</small>
                                <strong id="detailNextDate"></strong>
                            </div>
                        </div>

                        <div class="col-md-3">

                            <div class="detail-info-card">

                                <small>Last Paid</small>

                                <strong id="detailLastPaid">
                                </strong>

                            </div>

                        </div>

                        <div class="col-md-3">

                            <div class="detail-info-card">

                                <small>Amount</small>

                                <strong id="detailAmount">
                                </strong>

                            </div>

                        </div>

                    </div>


                    <!-- HISTORY SUMMARY -->

                    <div class="row g-3 mb-4">

                        <div class="col-md-3">

                            <div class="history-summary paid">

                                <i class="mdi mdi-check-circle-outline"></i>

                                <div>

                                    <small>Paid</small>

                                    <strong id="detailPaidCount">
                                        0
                                    </strong>

                                </div>

                            </div>

                        </div>


                        <div class="col-md-3">

                            <div class="history-summary pending">

                                <i class="mdi mdi-clock-alert-outline"></i>

                                <div>

                                    <small>Pending</small>

                                    <strong id="detailPendingCount">
                                        0
                                    </strong>

                                </div>

                            </div>

                        </div>


                        <div class="col-md-3">

                            <div class="history-summary overdue">

                                <i class="mdi mdi-alert-circle-outline"></i>

                                <div>

                                    <small>Overdue</small>

                                    <strong id="detailOverdueCount">
                                        0
                                    </strong>

                                </div>

                            </div>

                        </div>


                        <div class="col-md-3">

                            <div class="history-summary dropped">

                                <i class="mdi mdi-close-circle-outline"></i>

                                <div>

                                    <small>Dropped</small>

                                    <strong id="detailDroppedCount">
                                        0
                                    </strong>

                                </div>

                            </div>

                        </div>

                    </div>


                    <!-- PAYMENT HISTORY -->

                    <div class="recurring-history-wrapper">

                        <div
                            class="d-flex justify-content-between align-items-center mb-3">

                            <div>

                                <h6 class="mb-1">
                                    Payment History
                                </h6>

                                <small class="text-muted">
                                    Complete recurring payment timeline
                                </small>

                            </div>

                        </div>

                        <div
                            id="recurringHistoryList"
                            class="recurring-history-list">
                        </div>

                    </div>

                </div>
               

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>

    window.recurringRoutes = {
        listRecurring:"{{ route('accounts.recurringlist') }}",
        showRecurring: "{{ route('accounts-finance-recurring.show', ':id') }}",
        dropRecurring:"{{ route('accounts-finance-recurring.drop', ':id') }}",
        stopRecurring: "{{ route('accounts.products.recurring.stop', ':id') }}"
    };

   let filterTab = '7_days';
   let loadingRecuring = false;
   let $bodyRecuring = $('#recurringMasterBody');

    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    let tableState = {
        currentPage: 1
    };

    function initRecuring () {
        bindEvents();
        load();
    }

    function bindEvents() {
        $('#refreshRecurring').on('click',() => load() );
        $('.recurring-tab')
        .on('click',
            (e) => {
                $('.recurring-tab').removeClass('active');
                const $button = $(e.currentTarget);
                $button.addClass('active');
                filterTab = $button.data('recurring-tab');
                load();
            }
        );

     
       

        let searchTimer;
        $('#recurringSearch')
            .on('input',
                function () {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(
                        () => load(),
                        350
                    );
                }
            );

       

        $(document)
            .on('click','[data-recurring-view]',
                (e) => {
                    const id = $(e.currentTarget).data('recurring-view');
                    viewRecuring(id);
                }
            );

        $(document)
            .on('click','[data-recurring-drop]',
                (e) => {
                    const id = $(e.currentTarget) .data( 'recurring-drop' );
                    drop(id);
                }
            );

        $(document)
            .on('click','[data-recurring-stop]',
                (e) => {
                    const id = $(e.currentTarget).data( 'recurring-stop' );
                    stop(id);
                }
            );
    }

       

    

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function load(page = 1) {

        tableState.currentPage = page;

        const perpage = document.getElementById('perpage').value;
       

        if (loadingRecuring) {
            return;
        }

        loadingRecuring = true;

        showLoading();
        loadRecurringTabCounts();

        if (abortController.signal) {
                abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        const params = new URLSearchParams({
            page: page,
            sorting_filter: perpage,
            search:  $('#recurringSearch').val(),
            category:  $('#recurringCategoryFilter').val(),
            status: $('#recurringStatusFilter').val(),
            tab: filterTab
        });

        const url = `/accounts_finance/recurring?${params.toString()}`;

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
                .then(res => res.json())
                .then(response => {

                    if (!response || !response.success) {
                        showEmpty('Unable to load recurring records.');
                        return;
                    }
               
                        render(response.data || []);
                    

                    // renderSummary( response.summary || {}  ); 

                    $('[data-bs-toggle="tooltip"]').tooltip();
                    // Hide skeleton loader after data is fetched
                   loadingRecuring = false;
                    updatePagination(response.current_page, response.last_page, response.total, perpage);
                })
                .catch(error => {
                    if (error.name !== 'AbortError') { // Only handle abort error
                        console.error('Error loading data:', error);
                    }
                    showEmpty( xhr.responseJSON?.message || 'Unable to load recurring records.' );
                    toastr.error( 'Unable to load recurring subscriptions.' );
                    loadingRecuring = false;
                });
       
    }

    function loadRecurringTabCounts() {

        const params = new URLSearchParams({
            search: $('#recurringSearch').val(),
            category: $('#recurringCategoryFilter').val(),
            status: $('#recurringStatusFilter').val()
        });

        fetch(`/recurring_tab_counts?${params.toString()}`, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(response => {

            if (!response || !response.success) {
                return;
            }

            const counts = response.counts || {};

            $('#tabCount7').text(counts['7_days'] ?? 0);
            $('#tabCountCurrent').text(counts['current_month'] ?? 0);
            $('#tabCountNext').text(counts['next_month'] ?? 0);
            $('#tabCount6').text(counts['6_months'] ?? 0);
            $('#tabCountYear').text(counts['next_year'] ?? 0);

            $('#tabCountLifetime').text(counts['lifetime'] ?? 0);
            $('#tabCountAll').text(counts['all'] ?? 0);
        })
        .catch(error => {
            console.error(
                'Error loading recurring tab counts:',
                error
            );
        });
    }

    function showLoading() {
        $bodyRecuring.html(`
            <tr>
                <td colspan="7">
                    <div class="recurring-loading">
                        <div
                            class="spinner-border text-primary">
                        </div>
                        <span>
                            Loading recurring subscriptions...
                        </span>
                    </div>
                </td>
            </tr>
        `);
    }

    function showEmpty(message) {
        $bodyRecuring.html(`
            <tr>
                <td colspan="7">
                    <div class="recurring-loading">
                        <i class="mdi mdi-calendar-remove-outline"
                            style="font-size:40px;">
                        </i>
                        <strong>
                            ${escape(message)}
                        </strong>
                        <small>
                            Try changing the selected filters.
                        </small>
                    </div>
                </td>
            </tr>
        `);

        $('#recurringResultCount').text('0 Records');

    }


    function renderSummary(summary) {

        $('#recurringTotal')
            .text(summary.active || 0);

        $('#recurringToday')
            .text(summary.today || 0);

        $('#recurringOverdue')
            .text(summary.overdue || 0);

        $('#recurringPaid')
            .text(summary.paid || 0);

    }

    function render(rows) {

        $('#recurringResultCount').text(`${rows.length} Records`);
        if (!rows.length) {
            showEmpty('No recurring subscriptions found.');
            return;
        }

        $bodyRecuring.html(
            rows.map(row => rowHtml(row)).join('')
        );

    }


    function rowHtml(row) {

        const status = statusInfo(row);
        const isLifetime = row.record_type === 'lifetime';
        return `
            <tr class="recurring-row status-${status.key}">
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px;" class="statusbar-${status.key}"></div>
                    <div class="recurring-product">
                        <div class="recurring-product-icon">
                            <i class="mdi ${escape(row.category_icon || 'mdi mdi-calendar-sync-outline' )}"></i>
                        </div>
                        <div>
                            <div class="recurring-product-name">
                                ${escape( row.product_name )}
                            </div>
                            <span class="recurring-product-code">
                                ${escape( row.product_code || '' )}
                                ${ row.category_name ? ` • ${escape(row.category_name )}` : '' }
                            </span>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge bg-label-info">
                        ${escape( row.frequency_type || '-')}
                    </span>
                </td>
                <td>
                    ${
                        isLifetime
                            ? `
                                <div class="recurring-next-date">
                                    <strong>—</strong>
                                    <small class="text-muted">
                                        No recurring schedule
                                    </small>
                                </div>
                            `
                            : `
                                <div class="recurring-next-date">
                                    <strong>
                                        ${formatDate(row.next_pay_date)}
                                    </strong>
                                    <small class="${status.textClass}">
                                        ${escape(row.reminder_text || '')}
                                    </small>
                                </div>
                            `
                    }
                </td>
                <td>
                    ${
                        isLifetime
                            ? `
                                <span class="text-muted">
                                    Not applicable
                                </span>
                            `
                            : (
                                row.last_paid_date
                                    ? `
                                        <span class="recurring-status-badge paid">
                                            <i class="mdi mdi-check"></i>
                                            ${formatDate(row.last_paid_date)}
                                        </span>
                                    `
                                    : `
                                        <span class="text-muted">
                                            No payment yet
                                        </span>
                                    `
                            )
                    }
                </td>
                <td class="text-end">
                    <div class="fw-bold">
                        ${formatAmount(row)}
                    </div>
                    ${ Number(row.is_gst) === 1
                        ? `
                            <small class="text-success">
                                GST included
                            </small>
                        `
                        : ''
                    }
                </td>
                <td>
                    <span class="recurring-status-badge ${status.key}">
                        <i class="mdi ${status.icon}"></i>
                        ${status.label}
                    </span>
                </td>
                <td class="text-end">
                    ${actionMenu(row)}
                </td>
            </tr>
        `;
    }


    // function statusInfo(row) {
    //     if ( Number(row.recurring_status) === 2 ) {
    //         return {
    //             key: 'dropped',
    //             label: 'Stopped',
    //             icon: 'mdi-stop-circle-outline',
    //             textClass: 'text-muted'
    //         };
    //     }

    //     switch (row.display_status) {
    //         case 'overdue':
    //             return {
    //                 key: 'overdue',
    //                 label: `Overdue`,
    //                 icon:'mdi-alert-circle-outline',
    //                 textClass: 'text-danger'
    //             };
    //         case 'today':
    //             return {
    //                 key: 'today',
    //                 label: 'Due Today',
    //                 icon:'mdi-bell-alert',
    //                 textClass:'text-warning'
    //             };
    //         case 'tomorrow':
    //             return {
    //                 key: 'tomorrow',
    //                 label:'Due Tomorrow',
    //                 icon: 'mdi-clock-alert-outline',
    //                 textClass: 'text-warning'
    //             };
    //         case 'upcoming':
    //             return {
    //                 key: 'upcoming',
    //                 label: 'Upcoming',
    //                 icon: 'mdi-calendar-clock-outline',
    //                 textClass: 'text-info'
    //             };
    //         default:
    //             return {
    //                 key: 'upcoming',
    //                 label: 'Upcoming',
    //                 icon: 'mdi-calendar-clock-outline',
    //                 textClass:'text-info'
    //             };
    //     }
    // }

    function statusInfo(row) {

        if (Number(row.recurring_status) === 2) {
            return {
                key: 'dropped',
                label: 'Stopped',
                icon: 'mdi-stop-circle-outline',
                textClass: 'text-muted'
            };
        }

        if (row.record_type === 'lifetime') {
            return {
                key: 'lifetime',
                label: 'Lifetime',
                icon: 'mdi-infinity',
                textClass: 'text-primary'
            };
        }

        switch (row.display_status) {

            case 'paid':
                return {
                    key: 'paid',
                    label: 'Paid',
                    icon: 'mdi-check-circle-outline',
                    textClass: 'text-success'
                };

            case 'overdue':
                return {
                    key: 'overdue',
                    label: 'Overdue',
                    icon: 'mdi-alert-circle-outline',
                    textClass: 'text-danger'
                };

            case 'today':
                return {
                    key: 'today',
                    label: 'Due Today',
                    icon: 'mdi-bell-alert',
                    textClass: 'text-warning'
                };

            case 'tomorrow':
                return {
                    key: 'tomorrow',
                    label: 'Due Tomorrow',
                    icon: 'mdi-clock-alert-outline',
                    textClass: 'text-warning'
                };

            case 'upcoming':
                return {
                    key: 'upcoming',
                    label: 'Upcoming',
                    icon: 'mdi-calendar-clock-outline',
                    textClass: 'text-info'
                };

            default:
                return {
                    key: 'upcoming',
                    label: 'Upcoming',
                    icon: 'mdi-calendar-clock-outline',
                    textClass: 'text-info'
                };
        }
    }

    function actionMenu(row) {

            if (row.record_type === 'lifetime') {
                return `
                    <span class="badge bg-label-primary">
                        <i class="mdi mdi-infinity me-1"></i>
                        Lifetime
                    </span>
                `;
            }

        let html = `
            <button
                type="button"
                class="btn btn-sm btn-icon"
                data-recurring-view="${row.id}"
                title="View recurring details">
                <i class="mdi mdi-eye-outline"></i>
            </button>
        `;


        if ( Number(row.recurring_status) === 0 ) {

            html += `
                <div class="dropdown d-inline-block">
                    <button
                        type="button"
                        class="btn btn-sm btn-icon"
                        data-bs-toggle="dropdown">
                        <i class="mdi mdi-dots-vertical"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        {{--
                        ${ row.current_log_id
                            ? `
                                <li>
                                    <a href="javascript:void(0)"
                                        class="dropdown-item text-danger"
                                        data-recurring-drop="${row.current_log_id}">
                                        <i class="mdi mdi-close-circle-outline me-2"></i>
                                        Drop This Payment
                                    </a>
                                </li>
                            `
                            : ''
                        } 
                            --}}
                        <li>
                            <a href="javascript:void(0)"
                                class="dropdown-item text-danger" data-recurring-stop="${row.product_id}">
                                <i class="mdi mdi-stop-circle-outline me-2"></i>
                                Stop Recurring
                            </a>
                        </li>
                    </ul>
                </div>
            `;

        }

        return html;

    }


    function viewRecuring(id) {

        const modalElement =  document.getElementById( 'recurringDetailModal' );
        const modal = bootstrap.Modal.getOrCreateInstance( modalElement);

        $('#recurringDetailContent').addClass('d-none');

        $('#recurringDetailLoading').removeClass('d-none');

        modal.show();

        $.get( window.recurringRoutes.showRecurring.replace(':id', id))
        .done((response) => {
            if (!response || !response.success ) {
                toastr.error( response?.message || 'Unable to load details.');
                modal.hide();
                return;
            }
            renderDetails( response.data );
        })
        .fail(() => {
            toastr.error( 'Unable to load recurring details.' );
            modal.hide();
        });
    }


    function renderDetails(data) {
        const master = data.master;
        const logs = data.logs || [];
        $('#modalProductName').text( master.product_name || 'Recurring Details');
        $('#modalProductCode').text( master.product_code || '' );
        $('#detailFrequency').text( master.frequency_type || '-' );
        $('#detailNextDate').text(formatDate(master.next_pay_date) );
        $('#detailLastPaid').text(master.last_paid_date ? formatDate(master.last_paid_date) : 'Never');
        $('#detailAmount').html( formatAmount(master) );

        const summary = data.summary || {};

        $('#detailPaidCount').text(summary.paid || 0);
        $('#detailPendingCount').text(summary.unpaid || 0);
        $('#detailOverdueCount').text(summary.overdue || 0);
        $('#detailDroppedCount').text(summary.dropped || 0);

        renderDetailStatus( master, logs );

        $('#recurringHistoryList')
            .html(logs.length
                    ? logs.map(log => historyHtml(log)).join('')
                    : `
                        <div class="text-center py-5">
                            <i class="mdi mdi-history fs-1 text-muted"></i>
                            <div class="fw-semibold mt-2">
                                No payment history
                            </div>
                        </div>
                    `
        );

        $('#recurringDetailLoading').addClass('d-none');
        $('#recurringDetailContent').removeClass('d-none');
    }

    function renderDetailStatus(master, logs) {

        const latest = logs.length ? logs[0] : null;

        let key = 'upcoming';
        let label = 'Upcoming';
        let text =`Next payment on ${ formatDate( master.next_pay_date ) }`;
        let icon = 'mdi-calendar-clock-outline';

        if ( Number(master.status) === 2 ) {
            key = 'dropped';
            label = 'Stopped';
            text = 'This recurring subscription is stopped.';
            icon = 'mdi-stop-circle-outline';
        } else if (latest && Number(latest.status) === 1) {
            key = 'paid';
            label = 'Last Payment Paid';
            text = `Paid on ${formatDate( latest.paid_date) }`;
            icon ='mdi-check-circle-outline';
        } else if (master.next_pay_date ) {

            const today = new Date();
            const next = new Date(`${master.next_pay_date}T00:00:00` );

            today.setHours(0,0,0,0);
            next.setHours(0,0,0,0);

            const diff =  Math.round( ( next - today ) / 86400000);

            if (diff < 0) {
                key = 'overdue';
                label = 'Payment Overdue';
                text = `${Math.abs(diff)} day(s) overdue`;
                icon = 'mdi-alert-circle-outline';
            } else if (diff === 0) {
                key = 'today';
                label = 'Due Today';
                text = 'Payment requires attention today.';
                icon ='mdi-bell-alert';
            } else if (diff === 1) {
                key = 'tomorrow';
                label = 'Due Tomorrow';
                text =  'Prepare payment for tomorrow.';
                icon = 'mdi-clock-alert-outline';
            }
        }

        const hero =  $('#detailStatusHero');
        hero.removeClass('paid today tomorrow overdue upcoming dropped').addClass(key);
        $('#detailStatusIcon').html( `<i class="mdi ${icon}"></i>`);
        $('#detailStatusLabel').text(label);
        $('#detailStatusText').text(text);

    }

    function historyHtml(log) {

        let key = log.display_status || 'upcoming';
        let icon = log.status_icon || 'mdi-calendar-clock-outline';

        return `
            <div class="recurring-history-item ${key}">
                <div class="recurring-history-line">
                    <div class="recurring-history-dot">
                        <i class="mdi ${escape(icon)}"></i>
                    </div>
                </div>
                <div class="recurring-history-content">
                    <div class="recurring-history-top">
                        <div>
                            <div class="recurring-history-date">
                                ${formatDate( log.date )}
                            </div>
                            <div class="recurring-history-meta">
                                ${escape( log.status_label || ''  )}
                                ${ log.paid_date ? ` • Paid ${formatDate( log.paid_date )}` : '' }
                            </div>
                        </div>
                        <div class="recurring-history-amount">
                            ${formatAmount(log)}
                        </div>
                    </div>
                    ${ log.reference_no
                        ? `
                            <div class="mt-2">
                                <span class="badge bg-label-secondary">
                                    Ref: ${escape( log.reference_no)}
                                </span>
                            </div>
                        `
                        : ''
                    }
                  {{--  
                  ${ log.updated_by
                        ? `
                            <small class="text-muted d-block mt-2">
                                Updated by ${escape(log.updated_by )}
                            </small>
                        `
                        : ''
                    } 
                    --}}
                </div>
            </div>
        `;

    }

    function formatAmount(row) {

        if (String(row.currency_type).toUpperCase() === 'USD') {

            return `
                $ ${Number(row.currency_amount || 0 ).toLocaleString(
                    'en-US',
                    {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }
                )}
            `;
        }

        return ` ₹ ${Number( row.amount || 0 ).toLocaleString(
                'en-IN',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            )}
        `;

    }

    function formatDate(date) {

        if (!date) {
            return '-';
        }

        return new Date(`${date}T00:00:00`).toLocaleDateString(
            'en-IN',
            {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            }
        );

    }

    function escape(value) {

        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

    }

    function drop(id) {

        Swal.fire({
            title: 'Drop this payment?',
            html: `
                <div class="text-muted">
                    This will mark only this payment
                    occurrence as dropped.
                    <br>
                    The recurring subscription will remain active.
                </div>
            `,

            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Drop Payment',
            cancelButtonText: 'Keep Payment',
            reverseButtons: true

        }).then(result => {
            if (!result.isConfirmed) {
                return;
            }
            $.ajax({
                url: window.recurringRoutes.dropRecurring.replace(':id', id),
                type: 'POST',
                data: {
                    _token:$('meta[name="csrf-token"]').attr('content')
                },
                success: (response) => {
                    if (response.success) {
                        toastr.success(response.message);
                        load();
                    } else {
                        toastr.error( response.message);
                    }
                },
                error: (xhr) => {
                    toastr.error( xhr.responseJSON?.message || 'Unable to drop payment.');
                }
            });
        });
    }

    function stop(id) {

        Swal.fire({
            title: 'Stop recurring subscription?',
            html: `
                <div class="text-muted">
                    Future recurring payments will stop.
                    Existing paid expense records will remain.
                </div>
            `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Stop Recurring',
            cancelButtonText: 'Keep Active',
            reverseButtons: true
        }).then(result => {
            if (!result.isConfirmed) {
                return;
            }
            $.ajax({
                url: window.recurringRoutes.stopRecurring.replace(':id', id),
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: (response) => {
                    if (response.success) {
                        toastr.success(response.message );
                        load();
                    } else {
                        toastr.error( response.message);
                    }
                },
                error: (xhr) => {
                    toastr.error(xhr.responseJSON?.message || 'Unable to stop recurring subscription.' );
                }
            });
        });
    }

    function change_category_filter() {
        load()
    }
    function change_status_filter() {
        load()
    }

    function clearAllFilter() {
        $('#recurringSearch').val('');
        $('#recurringCategoryFilter').val('')
         $('#recurringStatusFilter').val('')
        $('#recurringCategoryFilter').val('').change();
        $('#recurringStatusFilter').val('').change();
        load()
    }

    

initRecuring ();

</script>

@endsection