@extends('layouts/layoutMaster')

@section('title', 'Manage Credit Card')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
   <style>
        /* ==== CREDIT CARD MODAL ==== */

        .expense-credit-card-modal {
            --credit-card-primary: var(--expense-primary, #dc3545);
            --credit-card-border: #e7e9ee;
            --credit-card-muted: #6f7682;
            --credit-card-surface: #f8f9fb;
        }


        /*  Modal */

        .expense-credit-card-modal .modal-dialog {
            max-width: 920px;
        }

        .expense-credit-card-modal .modal-content {
            border: 0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 24px 70px rgba(18, 38, 63, .18);
        }

        .expense-credit-card-modal .modal-header {
            padding: 20px 24px;
            background: #fff;
        }

        .expense-credit-card-modal .modal-body {
            padding: 24px;
            background: #f8f9fb;
        }

        .expense-credit-card-modal .modal-footer {
            padding: 18px 24px;
            background: #fff;
            border-top: 1px solid var(--credit-card-border);
        }


        /* ============================================================
        Section Cards
        ============================================================ */

        .expense-credit-card-modal .card {
            border-color: var(--credit-card-border) !important;
            border-radius: 14px;
            background: #fff;
        }

        .expense-credit-card-modal .card-header {
            padding: 18px 20px;
            border-bottom: 1px solid var(--credit-card-border);
        }

        .expense-credit-card-modal .card-body {
            padding: 20px;
        }

        .expense-credit-card-modal .avatar {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
        }

        .expense-credit-card-modal .form-label {
            margin-bottom: 7px;
            font-size: .8125rem;
            font-weight: 600;
        }

        .expense-credit-card-modal .form-label.required::after {
            content: " *";
            color: var(--credit-card-primary);
        }


        /* ============================================================
        Inputs
        ============================================================ */

        .expense-credit-card-modal .form-control,
        .expense-credit-card-modal .form-select,
        .expense-credit-card-modal .input-group-text {
            min-height: 42px;
        }

        .expense-credit-card-modal .form-control,
        .expense-credit-card-modal .form-select {
            border-color: var(--credit-card-border);
        }

        .expense-credit-card-modal .form-control:focus,
        .expense-credit-card-modal .form-select:focus {
            border-color: var(--credit-card-primary);
            box-shadow: 0 0 0 .2rem rgba(220, 53, 69, .08);
        }

        .expense-credit-card-modal .input-group-text {
            min-width: 43px;
            justify-content: center;
            color: var(--credit-card-muted);
            background: #f8f9fb;
            border-color: var(--credit-card-border);
        }


        /* ============================================================
        Select2
        ============================================================ */

        .expense-credit-card-modal .select2-container {
            width: 100% !important;
        }

        .expense-credit-card-modal
        .select2-container--default
        .select2-selection--single {
            height: 42px;
            display: flex;
            align-items: center;
            border: 1px solid var(--credit-card-border);
            border-radius: .375rem;
        }

        .expense-credit-card-modal
        .select2-container--default
        .select2-selection--single
        .select2-selection__rendered {
            padding-left: 12px;
            line-height: 40px;
        }

        .expense-credit-card-modal
        .select2-container--default
        .select2-selection--single
        .select2-selection__arrow {
            height: 40px;
        }


        /* ============================================================
        Secure Card Reference
        ============================================================ */

        .secure-card-entry {
            padding: 20px;
            border: 1px solid var(--credit-card-border);
            border-radius: 14px;
            background:
                linear-gradient(
                    135deg,
                    rgba(255,255,255,1),
                    rgba(248,249,251,1)
                );
        }

        .secure-card-entry-label {
            display: flex;
            align-items: center;
            margin-bottom: 16px;
            color: #343a40;
            font-size: .8125rem;
            font-weight: 700;
        }

        .secure-card-parts {
            display: flex;
            align-items: center;
            gap: 9px;
        }

        .secure-card-part {
            flex: 1 1 0;
            min-width: 0;
        }

        .credit-card-part-input {
            width: 100%;
            height: 50px !important;
            padding: 0 8px !important;
            border-radius: 10px !important;
            text-align: center;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
            font-size: 17px;
            font-weight: 700;
            letter-spacing: 2px;
            color: #343a40;
            background: #fff;
        }

        .credit-card-part-input::placeholder {
            color: #adb5bd;
            opacity: 1;
            letter-spacing: 1px;
        }

        .credit-card-part-input:focus {
            border-color: var(--credit-card-primary);
            background: #fff;
            box-shadow:
                0 0 0 .2rem rgba(220, 53, 69, .08),
                0 5px 18px rgba(18, 38, 63, .06);
            transform: translateY(-1px);
        }

        .secure-card-separator {
            flex: 0 0 auto;
            color: #adb5bd;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 1px;
        }


        /* ============================================================
        Secure Helper
        ============================================================ */

        .secure-card-helper {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            color: var(--credit-card-muted);
            font-size: .75rem;
        }

        .secure-card-helper > div {
            display: flex;
            align-items: center;
        }

        .secure-card-helper i {
            color: var(--credit-card-primary);
        }


        /* ============================================================
        Secure Badge
        ============================================================ */

        .expense-credit-card-modal .badge {
            font-weight: 600;
            padding: 6px 9px;
            border-radius: 7px;
        }


        /* ============================================================
        Validation
        ============================================================ */

        .expense-credit-card-modal
        .form-control.is-invalid,
        .expense-credit-card-modal
        .form-select.is-invalid {
            border-color: #dc3545;
        }

        .expense-credit-card-modal
        .form-control.is-invalid:focus,
        .expense-credit-card-modal
        .form-select.is-invalid:focus {
            border-color: #dc3545;
            box-shadow: 0 0 0 .2rem rgba(220, 53, 69, .08);
        }

        .expense-credit-card-modal
        .credit-card-part-input.is-invalid {
            background: rgba(220, 53, 69, .025);
        }

        .expense-credit-card-modal .invalid-feedback {
            font-size: .75rem;
        }


        /* ============================================================
        Disabled Entity
        ============================================================ */

        .expense-credit-card-modal
        #credit_card_entity_id:disabled {
            cursor: not-allowed;
            background-color: #f1f3f5;
        }


        /* ============================================================
        Footer Buttons
        ============================================================ */

        .expense-credit-card-modal .modal-footer .btn {
            min-height: 40px;
            border-radius: 8px;
            font-weight: 600;
        }

        .expense-credit-card-modal #btnSaveCreditCard {
            min-width: 160px;
        }


        /* ============================================================
        Loading State
        ============================================================ */

        .expense-credit-card-modal.is-loading {
            pointer-events: none;
        }

        .expense-credit-card-modal.is-loading .modal-content {
            opacity: .82;
        }

        .expense-credit-card-modal #creditCardLoader {
            vertical-align: middle;
        }


        /* ============================================================
        Responsive
        ============================================================ */

        @media (max-width: 767.98px) {

            .expense-credit-card-modal .modal-dialog {
                margin: .75rem;
            }

            .expense-credit-card-modal .modal-header {
                padding: 16px;
            }

            .expense-credit-card-modal .modal-body {
                padding: 16px;
            }

            .expense-credit-card-modal .modal-footer {
                padding: 14px 16px;
                gap: 8px;
            }

            .expense-credit-card-modal .card-header,
            .expense-credit-card-modal .card-body {
                padding: 16px;
            }

            .secure-card-parts {
                gap: 5px;
            }

            .secure-card-separator {
                display: none;
            }

            .credit-card-part-input {
                height: 46px !important;
                font-size: 14px;
                letter-spacing: 1px;
            }

            .secure-card-helper {
                flex-direction: column;
                align-items: flex-start;
            }

            .expense-credit-card-modal .modal-footer {
                flex-wrap: wrap;
            }

            .expense-credit-card-modal .modal-footer .btn {
                flex: 1 1 auto;
            }
        }


        /* ============================================================
        Very Small Screens
        ============================================================ */

        @media (max-width: 420px) {

            .secure-card-parts {
                display: grid;
                grid-template-columns: repeat(5, minmax(0, 1fr));
                gap: 5px;
            }

            .credit-card-part-input {
                padding-left: 2px !important;
                padding-right: 2px !important;
                font-size: 12px;
            }

            .expense-credit-card-modal .avatar {
                display: none;
            }

        }

        .credit-card-network {
            width: 44px;
            height: 30px;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 4px 6px;
            flex-shrink: 0;
        }

        .credit-card-network img {
            max-width: 100%;
            max-height: 22px;
            width: auto;
            height: auto;
            object-fit: contain;
        }

        .credit-card-network-fallback {
            font-size: 18px;
        }
   </style>
   <style>
    /* Credit Card Expiry Reminder */
        .card-expiry-reminder {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 6px;
            padding: 4px 9px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            line-height: 1;
            letter-spacing: .1px;
            white-space: nowrap;
            border: 1px solid transparent;
        }

        .card-expiry-reminder i {
            font-size: 14px;
        }

        /* Expiring soon */
        .card-expiry-warning {
            color: #a15c00;
            background: #fff7e6;
            border-color: #ffe1a8;
        }

        /* Expiring very soon */
        .card-expiry-critical {
            color: #b42318;
            background: #fff1f0;
            border-color: #ffc9c5;
        }

        /* Expired */
        .card-expiry-expired {
            color: #b42318;
            background: #fdecec;
            border-color: #f5b7b1;
        }

        /* Safe / future expiry */
        .card-expiry-safe {
            color: #2563eb;
            background: #eff6ff;
            border-color: #bfdbfe;
        }

        /* Small pulsing dot */
        .card-expiry-reminder .expiry-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: currentColor;
            display: inline-block;
        }

        .card-expiry-critical .expiry-dot {
            animation: expiryPulse 1.5s infinite;
        }

        @keyframes expiryPulse {
            0%, 100% {
                opacity: 1;
                transform: scale(1);
            }
            50% {
                opacity: .35;
                transform: scale(.75);
            }
        }
   

        /* ============================================================
        | MONTHLY CREDIT CARD PAYMENT
        ============================================================ */

        .credit-card-payment-modal .modal-dialog {
            max-width: 760px;
        }

        .credit-card-payment-modal .modal-content {
            border: 0;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 24px 70px rgba(18, 38, 63, .18);
        }

        .credit-card-payment-modal .modal-header {
            padding: 18px 22px;
            background: #fff;
            border-bottom: 1px solid #e7e9ee;
        }

        .credit-card-payment-modal .modal-body {
            padding: 20px;
            background: #f8f9fb;
        }

        .payment-card-summary {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            background: linear-gradient(135deg, #ffffff, #f8fafc);
        }

        .payment-card-summary-icon {
            width: 44px;
            height: 44px;
            flex: 0 0 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            background: #eef2ff;
            color: #4f46e5;
            font-size: 21px;
        }

        .payment-summary-title {
            font-size: .9rem;
            font-weight: 700;
            color: #212529;
        }

        .payment-summary-meta {
            margin-top: 3px;
            color: #6f7682;
            font-size: .75rem;
        }

        .payment-stat-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
            margin: 14px 0 18px;
        }

        .payment-stat {
            padding: 12px 13px;
            border: 1px solid #e7e9ee;
            border-radius: 12px;
            background: #fff;
        }

        .payment-stat-label {
            color: #7b8190;
            font-size: .69rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .35px;
        }

        .payment-stat-value {
            margin-top: 4px;
            color: #212529;
            font-size: .9rem;
            font-weight: 700;
        }

        .payment-history-card {
            margin-top: 18px;
            border: 1px solid #e7e9ee;
            border-radius: 14px;
            background: #fff;
            overflow: hidden;
        }

        .payment-history-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 13px 15px;
            border-bottom: 1px solid #e7e9ee;
        }

        .payment-history-title {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #212529;
            font-size: .82rem;
            font-weight: 700;
        }

        .payment-history-total {
            color: #087443;
            font-size: .75rem;
            font-weight: 700;
        }

        .payment-history-scroll {
            max-height: 260px;
            overflow-y: auto;
        }

        .payment-history-table {
            margin-bottom: 0;
        }

        .payment-history-table th {
            padding: 10px 14px;
            background: #fbfcfe;
            color: #7b8190;
            font-size: .68rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .35px;
            border-bottom: 1px solid #edf0f3;
        }

        .payment-history-table td {
            padding: 10px 14px;
            color: #343a40;
            font-size: .78rem;
            border-bottom: 1px solid #f0f2f5;
        }

        .payment-history-table tbody tr:last-child td {
            border-bottom: 0;
        }

        .payment-empty-state {
            padding: 28px 15px;
            text-align: center;
            color: #8a919d;
        }

        .payment-empty-state i {
            display: block;
            margin-bottom: 6px;
            font-size: 25px;
        }

        .payment-error {
            min-height: 18px;
            margin-top: 5px;
            color: #b42318;
            font-size: .73rem;
            font-weight: 600;
        }

        .monthly-due-line {
            display: flex;
            align-items: center;
            gap: 5px;
            margin-top: 4px;
            color: #6f7682;
            font-size: .72rem;
            font-weight: 600;
        }

        .monthly-due-line i {
            font-size: 14px;
        }

        .monthly-due-day {
            color: #343a40;
            font-weight: 700;
        }

        .monthly-payment-reminder {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 6px;
            padding: 4px 9px;
            border-radius: 999px;
            border: 1px solid transparent;
            font-size: 10.5px;
            line-height: 1;
            font-weight: 700;
            white-space: nowrap;
        }

        .monthly-payment-reminder i {
            font-size: 13px;
        }

        .monthly-payment-safe {
            color: #2563eb;
            background: #eff6ff;
            border-color: #bfdbfe;
        }

        .monthly-payment-warning {
            color: #a15c00;
            background: #fff7e6;
            border-color: #ffe1a8;
        }

        .monthly-payment-critical,
        .monthly-payment-overdue {
            color: #b42318;
            background: #fff1f0;
            border-color: #ffc9c5;
        }

        .monthly-payment-paid {
            color: #087443;
            background: #ecfdf3;
            border-color: #b7ebc6;
        }

        @media (max-width: 575.98px) {
            .payment-stat-grid {
                grid-template-columns: 1fr;
            }

            .credit-card-payment-modal .modal-body {
                padding: 16px;
            }
        }
</style>
    @php

        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ;
        $auth_id = auth()->user()->id ;
        $auth_role_id = auth()->user()->role_id ;
    @endphp
    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Credit Card</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-cash-multiple"></i> Accounts & Finance
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Manage Credit Card
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;"
                        class="btn btn-sm fw-bold btn-primary text-white"
                        onclick="openCreate()">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Credit Card
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [6,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Credit..."
                                    value=""/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-180px"> Bank / Card </th> 
                                <th class="min-w-180px"> Card Reference </th> 
                                <th class="min-w-180px"> Card Holder </th> 
                                <th class="min-w-150px"> Type / Due Date </th> 
                                <th class="min-w-80px"> Status </th> 
                                <th class="min-w-100px text-center"> Action </th>
                            </tr>
                        </thead>
                        <tbody id="company-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>

    <div  class="modal fade expense-credit-card-modal" id="creditCardModal" tabindex="-1" aria-labelledby="creditCardModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header border-bottom">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-md bg-label-primary me-3">
                            <i class="mdi mdi-credit-card-outline fs-4"></i>
                        </div>
                        <div>
                            <h5 class="modal-title mb-1" id="creditCardModalLabel">
                                Add Credit Card
                            </h5>
                            <small class="text-muted">
                                Securely manage company credit card details
                            </small>
                        </div>
                    </div>
                    <button  type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                {{-- =================================================
                    FORM
                ================================================== --}}
                <form  id="creditCardForm"  method="POST" autocomplete="off">
                    @csrf
                    <input type="hidden"  name="credit_card_id"  id="credit_card_id"  value="">
                    <input  type="hidden"  name="form_mode" id="creditCardFormMode"  value="create">
                    <div class="modal-body">
                        {{-- ======== CARD CONFIGURATION  ======= --}}
                        <!-- <div class="card shadow-none border mb-4">
                            <div class="card-header bg-white">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-sm bg-label-primary me-3">
                                        <i class="mdi mdi-bank-outline"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-semibold">Card Configuration</h6>
                                        <small class="text-muted">
                                            Select the company and entity where
                                            this card belongs
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row g-4">
                                    {{-- Company --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_company_id" class="form-label required">
                                            Company
                                        </label>
                                        <select class="form-select select3 expense-modal-select" id="credit_card_company_id" name="company_id"data-placeholder="Select Company">
                                            <option value="">Select Company</option>
                                        </select>
                                        <div class="invalid-feedback company_id_error"></div>
                                    </div>
                                    {{-- Entity --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_entity_id" class="form-label required">
                                            Entity
                                        </label>
                                        <select class="form-select select2 expense-modal-select"  id="credit_card_entity_id" name="entity_id"  data-placeholder="Select Entity" disabled>
                                            <option value="">Select Entity</option>
                                        </select>
                                        <div class="invalid-feedback entity_id_error"></div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        {{-- =========================================
                            BANK & CARD INFORMATION
                        ========================================== --}}
                        <div class="card shadow-none border mb-4">
                            <div class="card-header bg-white">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-sm bg-label-info me-3">
                                        <i class="mdi mdi-bank-outline"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-semibold">
                                            Bank & Card Information
                                        </h6>
                                        <small class="text-muted">
                                            Enter the basic card information
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="row g-4">
                                    {{-- Bank Name --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_bank_name"  class="form-label required">
                                            Bank Name
                                        </label>
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-bank-outline"></i>
                                            </span>
                                            <input type="text" class="form-control" id="credit_card_bank_name" name="b_name" maxlength="150" placeholder="Enter bank name" >
                                        </div>
                                        <div class="invalid-feedback b_name_error">
                                        </div>

                                    </div>
                                    {{-- Card Holder --}}
                                    <div class="col-md-6">
                                        <label  for="credit_card_holder" class="form-label required">
                                            Card Holder Name
                                        </label>
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-account-outline"></i>
                                            </span>
                                            <input type="text"  class="form-control text-uppercase" id="credit_card_holder" name="rd_prsn_name" maxlength="150" placeholder="Name on card">
                                        </div>
                                        <div class="invalid-feedback rd_prsn_name_error"></div>
                                    </div>
                                    {{-- Card Name --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_name" class="form-label">
                                            Card Name
                                        </label>
                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-credit-card-outline"></i>
                                            </span>
                                            <input type="text" class="form-control" id="credit_card_name" name="rd_name" maxlength="150" placeholder="e.g. Corporate Card"  >
                                        </div>
                                        <div class="invalid-feedback rd_name_error"></div>
                                    </div>
                                    {{-- Card Type --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_type" class="form-label required">
                                            Card Type
                                        </label>
                                        <select class="form-select select3" id="credit_card_type" name="type">
                                            <option value=""> Select Card Type</option>
                                            <option value="Visa">Visa</option>
                                            <option value="Mastercard">Mastercard</option>
                                            <option value="RuPay">RuPay</option>
                                            <option value="American Express"> American Express</option>
                                            <option value="Other">Other</option>
                                        </select>
                                        <div class="invalid-feedback type_error"></div>
                                    </div>
                                    {{-- Credit Card Limit --}} 
                                    <div class="col-md-6"> 
                                        <label for="credit_card_limit" class="form-label required" > Credit Card Limit </label> 
                                        <div class="input-group"> 
                                            <span class="input-group-text"> 
                                                <i class="mdi mdi-currency-inr"></i> 
                                            </span> 
                                            <input type="text" class="form-control" id="credit_card_limit" name="credit_limit" inputmode="decimal" maxlength="15" placeholder="Enter credit card limit" autocomplete="off" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"> 
                                        </div> 
                                        <div class="invalid-feedback credit_limit_error"></div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                        {{-- ====== SECURE CARD REFERENCE ======= --}}
                        <div class="card shadow-none border mb-4">
                            <div class="card-header bg-white">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-sm bg-label-warning me-3">
                                        <i class="mdi mdi-lock-outline"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-semibold">
                                            Secure Card Reference
                                        </h6>
                                        <small class="text-muted">
                                            Enter the card reference as five
                                            separate secure parts
                                        </small>
                                    </div>

                                    <div class="ms-auto">
                                        <span class="badge bg-label-success">
                                            <i class="mdi mdi-shield-check-outline me-1"></i>
                                            Secure Entry
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="secure-card-entry">
                                    <div class="secure-card-entry-label d-flex align-items-center"> 
                                        <div> 
                                            <i class="mdi mdi-credit-card-outline me-2"></i> 
                                            Card Reference 
                                        </div> 
                                        <button type="button" class="btn btn-sm btn-outline-secondary ms-auto secure-card-toggle" id="toggleCreditCardNumber" aria-label="Show card number" aria-pressed="false" > 
                                            <i class="mdi mdi-eye-outline me-1"></i> 
                                            <span>Show</span> 
                                        </button> 
                                    </div>
                                    <div class="secure-card-parts">
                                        {{-- Part 1 --}}
                                        <div class="secure-card-part">
                                            <label for="rd_prt1" class="visually-hidden">Card Part 1</label>
                                            <input
                                                type="password"
                                                inputmode="numeric"
                                                pattern="[0-9]*"
                                                maxlength="4"
                                                class="form-control credit-card-part-input"
                                                id="rd_prt1"
                                                name="rd_prt1"
                                                autocomplete="off"
                                                placeholder="0000">
                                        </div>
                                        <span class="secure-card-separator">
                                            ••••
                                        </span>
                                        {{-- Part 2 --}}
                                        <div class="secure-card-part">
                                            <label for="rd_prt2" class="visually-hidden">Card Part 2</label>
                                            <input
                                                type="password"
                                                inputmode="numeric"
                                                pattern="[0-9]*"
                                                maxlength="4"
                                                class="form-control credit-card-part-input"
                                                id="rd_prt2"
                                                name="rd_prt2"
                                                autocomplete="off"
                                                placeholder="0000">
                                        </div>
                                        <span class="secure-card-separator">
                                            ••••
                                        </span>
                                        {{-- Part 3 --}}
                                        <div class="secure-card-part">

                                            <label for="rd_prt3" class="visually-hidden">Card Part 3</label>
                                            <input
                                                type="password"
                                                inputmode="numeric"
                                                pattern="[0-9]*"
                                                maxlength="4"
                                                class="form-control credit-card-part-input"
                                                id="rd_prt3"
                                                name="rd_prt3"
                                                autocomplete="off"
                                                placeholder="0000">
                                        </div>
                                        <span class="secure-card-separator">
                                            ••••
                                        </span>
                                        {{-- Part 4 --}}
                                        <div class="secure-card-part">

                                            <label
                                                for="rd_prt4"
                                                class="visually-hidden">

                                                Card Part 4

                                            </label>

                                            <input
                                                type="password"
                                                inputmode="numeric"
                                                pattern="[0-9]*"
                                                maxlength="4"
                                                class="form-control credit-card-part-input"
                                                id="rd_prt4"
                                                name="rd_prt4"
                                                autocomplete="off"
                                                placeholder="0000">

                                        </div>
                                        <!-- <span class="secure-card-separator">
                                            ••••
                                        </span> -->
                                        {{-- Part 5 --}}
                                        <!-- <div class="secure-card-part">

                                            <label
                                                for="rd_prt5"
                                                class="visually-hidden">

                                                Card Part 5

                                            </label>

                                            <input
                                                type="password"
                                                inputmode="numeric"
                                                pattern="[0-9]*"
                                                maxlength="4"
                                                class="form-control credit-card-part-input"
                                                id="rd_prt5"
                                                name="rd_prt5"
                                                autocomplete="off"
                                                placeholder="0000">

                                        </div> -->

                                    </div>


                                    <div class="secure-card-helper mt-3">

                                        <div>

                                            <i class="mdi mdi-information-outline me-1"></i>

                                            Each section accepts numbers only.

                                        </div>

                                        <div>

                                            <i class="mdi mdi-lock-outline me-1"></i>

                                            Values are handled separately.

                                        </div>

                                    </div>

                                </div>


                                <div class="invalid-feedback d-block rd_prt_error" id="creditCardPartsError"></div>

                                <div class="row g-4">
                                    {{-- Due Date --}}
                                    <div class="col-md-6"> 
                                        <label for="credit_card_due_date" class="form-label" > Card Expiry Date </label> 
                                        <div class="input-group"> 
                                            <span class="input-group-text"> 
                                                <i class="mdi mdi-calendar-month-outline"></i> 
                                            </span> 
                                            <input type="text" class="form-control" id="credit_card_due_date" name="due" placeholder="MM/YY" inputmode="numeric" autocomplete="cc-exp" maxlength="5" aria-describedby="creditCardExpiryHelp" > 
                                        </div> 
                                        <small id="creditCardExpiryHelp" class="form-text text-muted" > Enter the card expiry date (MM/YY). </small> 
                                        <div class="invalid-feedback due_error"></div> 
                                    </div>
                                    {{-- cvv Number --}}
                                    <div class="col-md-6"> 
                                        <label for="credit_card_cvv" class="form-label"> CVV / CVC </label> 
                                        <div class="input-group"> 
                                            <span class="input-group-text"> 
                                                <i class="mdi mdi-shield-lock-outline"></i> </span> 
                                                <input type="password" class="form-control" id="credit_card_cvv" name="vv_no" inputmode="numeric" pattern="[0-9]{3,4}" minlength="3" maxlength="4" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="•••" aria-describedby="creditCardCvvHelp" > 
                                                <button type="button" class="btn btn-outline-secondary" id="toggleCreditCardCvv" tabindex="-1" aria-label="Show CVV" > 
                                                    <i class="mdi mdi-eye-outline"></i> 
                                                </button> 
                                            </div> 
                                            <small id="creditCardCvvHelp" class="form-text text-muted" > Enter the 3 or 4 digit security code. </small> 
                                            <div class="invalid-feedback vv_no_error"></div> 
                                        </div>

                                    {{-- Monthly Payment Due Day --}}
                                    <div class="col-md-6">
                                        <label for="credit_card_payment_due_day"
                                               class="form-label required">
                                            Monthly Payment Due Day
                                        </label>

                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-calendar-today-outline"></i>
                                            </span>

                                            <select class="form-select select3"
                                                    id="credit_card_payment_due_day"
                                                    name="payment_due_day"
                                                    aria-describedby="creditCardPaymentDueDayHelp">
                                                <option value="">Select Day</option>
                                                @for ($day = 1; $day <= 31; $day++)
                                                    <option value="{{ $day }}">
                                                        {{ $day }}{{ in_array($day % 100, [11, 12, 13]) ? 'th' : ($day % 10 === 1 ? 'st' : ($day % 10 === 2 ? 'nd' : ($day % 10 === 3 ? 'rd' : 'th'))) }}
                                                    </option>
                                                @endfor
                                            </select>
                                        </div>

                                        <small id="creditCardPaymentDueDayHelp"
                                               class="form-text text-muted">
                                            Reminder repeats automatically every month.
                                        </small>

                                        <div class="invalid-feedback payment_due_day_error"></div>
                                    </div>
                                </div>

                            </div>

                        </div>


                    

                    </div>


                    {{-- =================================================
                        FOOTER
                    ================================================== --}}

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn btn-label-secondary"
                            data-bs-dismiss="modal">

                            <i class="mdi mdi-close me-1"></i>

                            Cancel

                        </button>


                        <button
                            type="reset"
                            class="btn btn-label-warning"
                            id="btnResetCreditCard">

                            <i class="mdi mdi-refresh me-1"></i>

                            Reset

                        </button>


                        <button
                            type="submit"
                            class="btn btn-primary"
                            id="btnSaveCreditCard">

                            <span
                                class="spinner-border spinner-border-sm me-2 d-none"
                                id="creditCardLoader">
                            </span>

                            <i class="mdi mdi-content-save-outline me-1"></i>

                            <span id="creditCardSaveText">

                                Save Credit Card

                            </span>

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>



    <!-- ================================================================
         Monthly Credit Card Payment Modal
    ================================================================= -->
    <div class="modal fade credit-card-payment-modal" id="creditCardPaymentModal"
         tabindex="-1" aria-labelledby="creditCardPaymentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered ">
            <div class="modal-content">

                <div class="modal-header">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-sm bg-label-success me-3 d-flex justify-content-center align-items-center">
                            <i class="mdi mdi-cash-plus"></i>
                        </div>
                        <div>
                            <h5 class="modal-title mb-1" id="creditCardPaymentModalLabel">
                                Record Credit Card Payment
                            </h5>
                            <small class="text-muted">
                                Record a payment for the current month
                            </small>
                        </div>
                    </div>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"></button>
                </div>

                <form id="creditCardPaymentForm" autocomplete="off">
                    <input type="hidden"
                           id="credit_card_payment_card_id"
                           name="credit_card_id">

                    <div class="modal-body">

                        <div class="payment-card-summary">
                            <div class="payment-card-summary-icon">
                                <i class="mdi mdi-credit-card-outline"></i>
                            </div>

                            <div class="min-w-0">
                                <div class="payment-summary-title text-truncate"
                                     id="creditCardPaymentBank">
                                    Credit Card
                                </div>

                                <div class="payment-summary-meta"
                                     id="creditCardPaymentReference">
                                    •••• •••• •••• ••••
                                </div>
                            </div>
                        </div>

                        <div class="payment-stat-grid">

                            <div class="payment-stat">
                                <div class="payment-stat-label">
                                    Monthly Due
                                </div>

                                <div class="payment-stat-value"
                                     id="creditCardPaymentDueDay">
                                    —
                                </div>
                            </div>

                            <div class="payment-stat">
                                <div class="payment-stat-label">
                                    Paid This Month
                                </div>

                                <div class="payment-stat-value"
                                     id="creditCardPaymentMonthTotal">
                                    ₹ 0.00
                                </div>
                            </div>

                            <div class="payment-stat">
                                <div class="payment-stat-label">
                                    Payment Cycle
                                </div>

                                <div class="payment-stat-value"
                                     id="creditCardPaymentCycle">
                                    —
                                </div>
                            </div>

                        </div>

                        <div class="card shadow-none border mb-0">
                            <div class="card-body p-3">

                                <div class="row g-3">

                                    <div class="col-md-7">
                                        <label for="credit_card_payment_amount"
                                               class="form-label required">
                                            Amount Paid
                                        </label>

                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-currency-inr"></i>
                                            </span>

                                            <input type="text"
                                                   class="form-control"
                                                   id="credit_card_payment_amount"
                                                   name="amount_paid"
                                                   inputmode="decimal"
                                                   maxlength="15"
                                                   placeholder="Enter amount paid">
                                        </div>

                                        <div class="payment-error"
                                             id="creditCardPaymentAmountError"></div>
                                    </div>

                                    <div class="col-md-5">
                                        <label for="credit_card_payment_date"
                                               class="form-label required">
                                            Payment Date
                                        </label>

                                        <div class="input-group">
                                            <span class="input-group-text">
                                                <i class="mdi mdi-calendar-outline"></i>
                                            </span>

                                            <input type="text"
                                                   class="form-control paid_date"
                                                   id="credit_card_payment_date"
                                                   name="paid_date"
                                                   autocomplete="off">
                                        </div>

                                        <div class="payment-error"
                                             id="creditCardPaymentDateError"></div>
                                    </div>

                                </div>

                            </div>
                        </div>

                        <div class="payment-history-card">

                            <div class="payment-history-header">

                                <div class="payment-history-title">
                                    <i class="mdi mdi-history"></i>
                                    Payment History
                                </div>

                                <div class="payment-history-total"
                                     id="creditCardPaymentHistoryTotal">
                                    0 payments
                                </div>

                            </div>

                            <div class="payment-history-scroll">

                                <table class="table payment-history-table">

                                    <thead>
                                        <tr>
                                            <th>Paid Date</th>
                                            <th class="text-end">Amount Paid</th>
                                        </tr>
                                    </thead>

                                    <tbody id="creditCardPaymentHistoryBody">
                                        <tr>
                                            <td colspan="2">
                                                <div class="payment-empty-state">
                                                    <i class="mdi mdi-loading mdi-spin"></i>
                                                    Loading payment history...
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>

                            </div>
                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="button"
                                class="btn btn-label-secondary"
                                data-bs-dismiss="modal">
                            <i class="mdi mdi-close me-1"></i>
                            Close
                        </button>

                        <button type="submit"
                                class="btn btn-success"
                                id="btnSaveCreditCardPayment">

                            <span class="spinner-border spinner-border-sm me-2 d-none"
                                  id="creditCardPaymentLoader"></span>

                            <i class="mdi mdi-check-circle-outline me-1"></i>

                            <span id="creditCardPaymentSaveText">
                                Record Payment
                            </span>

                        </button>

                    </div>
                </form>

            </div>
        </div>
    </div>

    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_credit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Elysian
                            Intelligence Business Solution </b>
                        Credit Card ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deleteDepartmentCategory()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->





<link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>




    <script>
        document.addEventListener('DOMContentLoaded', () => {
            function previewImage(input, imageId) {
                const image = document.getElementById(imageId);
                if (input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => image.src = e.target.result;
                reader.readAsDataURL(input.files[0]);
                }
            }

            // Logo reset
            const logoResetButton = document.querySelector('.file-reset');
            const logoFileInput = document.querySelector('.file-in');
            logoResetButton?.addEventListener('click', () => {
                const logoImage = document.getElementById('logo_update');
                logoImage.src = '/assets/common/logo_small.png';
                logoFileInput.value = null;
            });
            logoFileInput?.addEventListener('change', () => previewImage(logoFileInput, 'logo_update'));

            // Logo reset
            const favlogoResetButton = document.querySelector('.file-reset-com-edit');
            const favlogoFileInput = document.querySelector('.file-in-com-edit');
            favlogoResetButton?.addEventListener('click', () => {
                const logoImage = document.getElementById('favicon_update');
                logoImage.src = '/assets/common/logo_small.png';
                favlogoFileInput.value = null;
            });
            favlogoFileInput?.addEventListener('change', () => previewImage(favlogoFileInput, 'favicon_update'));

            // Entity reset
            
            const entityReset = document.querySelector('.file-reset-entity');
            const entityFileInput = document.querySelector('.file-in-entity');
            entityReset?.addEventListener('click', () => {
                const entityImage = document.getElementById('logo_entity');
                entityImage.src = "{{ asset('assets/eapl_images/default_entity.png') }}";
                entityFileInput.value = null;
            });
            entityFileInput?.addEventListener('change', () => previewImage(entityFileInput, 'logo_entity'));

            const faventityReset = document.querySelector('.file-reset-entity-fav');
            const faventityFileInput = document.querySelector('.file-in-entity-fav');
            faventityReset?.addEventListener('click', () => {
                const entityImage = document.getElementById('favicon_entity');
                entityImage.src = "{{ asset('assets/eapl_images/default_entity.png') }}";
                faventityFileInput.value = null;
            });
            faventityFileInput?.addEventListener('change', () => previewImage(faventityFileInput, 'favicon_entity'));

            // Favicon reset
            const faviconResetButton = document.querySelector('.fav_file-reset');
            const compfaviconResetButton = document.querySelector('.fav_file-reset-comp');
            const faviconFileInput = document.querySelector('.fav_file-in');
            const compfaviconFileInput = document.querySelector('.fav_file-in-comp');
            faviconResetButton?.addEventListener('click', () => {
                const faviconImage = document.getElementById('logo_create');
                faviconImage.src = "{{ asset('assets/common/logo_small.png') }}";
                faviconFileInput.value = null;
            });
            faviconFileInput?.addEventListener('change', () => previewImage(faviconFileInput, 'logo_create'));

            compfaviconResetButton?.addEventListener('click', () => {
                const faviconImage = document.getElementById('fav_icon_create');
                faviconImage.src = "{{ asset('assets/common/logo_small.png') }}";
                compfaviconFileInput.value = null;
            });
            compfaviconFileInput?.addEventListener('change', () => previewImage(compfaviconFileInput, 'fav_icon_create'));

            // Logo edit reset
            const logoResetButtonEdit = document.querySelector('.file-reset-edit');
            const logoFileInputEdit = document.querySelector('.file-in-edit');
            logoResetButtonEdit?.addEventListener('click', () => {
                const logoImage = document.getElementById('enity_logo_update');
                const oldImage = document.getElementById('old_entity_image_path');
                logoImage.src = oldImage.value || '/assets/common/logo_small.png';
                logoFileInputEdit.value = null;
            });
            logoFileInputEdit?.addEventListener('change', () => previewImage(logoFileInputEdit, 'enity_logo_update'));

            const favlogoResetButtonEdit = document.querySelector('.file-reset-edit-entity');
            const favlogoFileInputEdit = document.querySelector('.file-in-edit-entity');
            favlogoResetButtonEdit?.addEventListener('click', () => {
                const logoImage = document.getElementById('enity_favicon_update');
                const oldImage = document.getElementById('old_entity_favicon_path');
                logoImage.src = oldImage.value || '/assets/common/logo_small.png';
                favlogoFileInputEdit.value = null;
            });
            favlogoFileInputEdit?.addEventListener('change', () => previewImage(favlogoFileInputEdit, 'enity_favicon_update'));
        });
        
    </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
      let auth_user_id = @json($user_id);
    let creditCardRows = {};

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }


    function escapeHtml(value) {
        if (value === null || value === undefined) {
            return '';
        }
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function getExpiryReminder(expiryDateString) {

        const value = String(expiryDateString || '').trim();

        if (!value) {
            return '';
        }

        const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);

        if (!match) {
            return '';
        }

        const year = Number(match[1]);
        const month = Number(match[2]);
        const day = Number(match[3]);

        const expiryDate = new Date(year, month - 1, day);
        const today = new Date();

        // Remove time part
        expiryDate.setHours(0, 0, 0, 0);
        today.setHours(0, 0, 0, 0);

        // Invalid date protection
        if (
            Number.isNaN(expiryDate.getTime()) ||
            expiryDate.getFullYear() !== year ||
            expiryDate.getMonth() !== month - 1 ||
            expiryDate.getDate() !== day
        ) {
            return '';
        }

        const MS_PER_DAY = 24 * 60 * 60 * 1000;

        const daysRemaining = Math.round(
            (expiryDate.getTime() - today.getTime()) / MS_PER_DAY
        );

        /*
        |--------------------------------------------------------------------------
        | EXPIRED
        |--------------------------------------------------------------------------
        */
        if (daysRemaining < 0) {

            const expiredDays = Math.abs(daysRemaining);

            return `
                <span class="card-expiry-reminder card-expiry-expired"
                    title="This credit card has expired">

                    <i class="mdi mdi-alert-circle-outline"></i>

                    Expired ${expiredDays}
                    day${expiredDays === 1 ? '' : 's'} ago
                </span>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | EXPIRES TODAY
        |--------------------------------------------------------------------------
        */
        if (daysRemaining === 0) {

            return `
                <span class="card-expiry-reminder card-expiry-critical"
                    title="Credit card expires today">

                    <i class="mdi mdi-alert-outline"></i>

                    Expires Today
                </span>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | HELPER
        | Calculate calendar months + remaining days
        |--------------------------------------------------------------------------
        */
        function addMonths(date, months) {

            const result = new Date(date);

            const originalDay = result.getDate();

            result.setDate(1);

            result.setMonth(result.getMonth() + months);

            const lastDayOfMonth = new Date(
                result.getFullYear(),
                result.getMonth() + 1,
                0
            ).getDate();

            result.setDate(
                Math.min(originalDay, lastDayOfMonth)
            );

            result.setHours(0, 0, 0, 0);

            return result;
        }


        function getCalendarDifference(startDate, endDate) {

            let totalMonths = (
                (endDate.getFullYear() - startDate.getFullYear()) * 12
            ) + (
                endDate.getMonth() - startDate.getMonth()
            );

            // Never allow the calculated month count to exceed expiry
            while (
                totalMonths > 0 &&
                addMonths(startDate, totalMonths) > endDate
            ) {
                totalMonths--;
            }

            const afterMonths = addMonths(startDate, totalMonths);

            const remainingDays = Math.round(
                (endDate.getTime() - afterMonths.getTime()) / MS_PER_DAY
            );

            const years = Math.floor(totalMonths / 12);
            const months = totalMonths % 12;

            return {
                years,
                months,
                days: remainingDays
            };
        }


        const difference = getCalendarDifference(
            today,
            expiryDate
        );

        const years = difference.years;
        const months = difference.months;
        const remainingDays = difference.days;


        /*
        |--------------------------------------------------------------------------
        | DISPLAY TEXT
        |--------------------------------------------------------------------------
        */

        const parts = [];

        if (years > 0) {
            parts.push(
                `${years} year${years === 1 ? '' : 's'}`
            );
        }

        if (months > 0) {
            parts.push(
                `${months} month${months === 1 ? '' : 's'}`
            );
        }

        if (remainingDays > 0) {
            parts.push(
                `${remainingDays} day${remainingDays === 1 ? '' : 's'}`
            );
        }

        const remainingText = parts.join(' ');


        /*
        |--------------------------------------------------------------------------
        | 1 - 7 DAYS : CRITICAL
        |--------------------------------------------------------------------------
        */
        if (daysRemaining <= 7) {

            return `
                <span class="card-expiry-reminder card-expiry-critical"
                    title="Credit card expires very soon">

                    <i class="mdi mdi-clock-alert-outline"></i>

                    Expires in ${daysRemaining}
                    day${daysRemaining === 1 ? '' : 's'}
                </span>
            `;
        }


        /*
        |--------------------------------------------------------------------------
        | 8 - 30 DAYS : WARNING
        |--------------------------------------------------------------------------
        */
        if (daysRemaining <= 30) {

            return `
                <span class="card-expiry-reminder card-expiry-warning"
                    title="Credit card expires within 30 days">

                    <i class="mdi mdi-calendar-alert-outline"></i>

                    Expires in ${daysRemaining}
                    days
                </span>
            `;
        }


        /*
        |--------------------------------------------------------------------------
        | DEFAULT : ALWAYS SHOW
        |--------------------------------------------------------------------------
        */
        return `
            <span class="card-expiry-reminder card-expiry-safe"
                title="Credit card expiry is ${remainingText} away">

                <i class="mdi mdi-calendar-check-outline"></i>

                Expires in ${remainingText}
            </span>
        `;
    }



    function formatOrdinalDay(day) {

        const value = Number(day);

        if (!Number.isInteger(value) || value < 1 || value > 31) {
            return '—';
        }

        const mod100 = value % 100;

        if (mod100 >= 11 && mod100 <= 13) {
            return `${value}th`;
        }

        switch (value % 10) {
            case 1:
                return `${value}st`;
            case 2:
                return `${value}nd`;
            case 3:
                return `${value}rd`;
            default:
                return `${value}th`;
        }
    }


    function createMonthlyDueDate(year, monthIndex, dueDay) {

        const lastDayOfMonth = new Date(
            year,
            monthIndex + 1,
            0
        ).getDate();

        return new Date(
            year,
            monthIndex,
            Math.min(Number(dueDay), lastDayOfMonth)
        );
    }


    function getLocalToday() {

        const today = new Date();

        today.setHours(0, 0, 0, 0);

        return today;
    }


    function getDaysBetween(startDate, endDate) {

        const MS_PER_DAY = 24 * 60 * 60 * 1000;

        const start = new Date(startDate);
        const end = new Date(endDate);

        start.setHours(0, 0, 0, 0);
        end.setHours(0, 0, 0, 0);

        return Math.round(
            (end.getTime() - start.getTime()) / MS_PER_DAY
        );
    }


    function formatInr(amount) {

        return Number(amount || 0).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }


    function getMonthlyDueReminder(paymentDueDay, monthlyPaid = 0) {

        const dueDay = Number(paymentDueDay);

        if (!Number.isInteger(dueDay) || dueDay < 1 || dueDay > 31) {

            return `
                <span class="monthly-payment-reminder monthly-payment-warning"
                      title="Set the monthly payment due day to enable reminders">

                    <i class="mdi mdi-calendar-alert-outline"></i>
                    Set monthly due day
                </span>
            `;
        }

        const today = getLocalToday();

        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth();

        const currentDueDate = createMonthlyDueDate(
            currentYear,
            currentMonth,
            dueDay
        );

        const paidThisMonth = Number(monthlyPaid || 0) > 0;

        /*
        |--------------------------------------------------------------------------
        | Payment recorded this month
        |--------------------------------------------------------------------------
        */
        if (paidThisMonth) {

            const nextMonth = new Date(
                currentYear,
                currentMonth + 1,
                1
            );

            const nextDueDate = createMonthlyDueDate(
                nextMonth.getFullYear(),
                nextMonth.getMonth(),
                dueDay
            );

            const daysToNextDue = getDaysBetween(
                today,
                nextDueDate
            );

            return `
                <span class="monthly-payment-reminder monthly-payment-paid"
                      title="Payment recorded for the current month">

                    <i class="mdi mdi-check-circle-outline"></i>

                   Last Paid ₹ ${formatInr(monthlyPaid)} 
                    -> Next due in ${daysToNextDue}
                    day${daysToNextDue === 1 ? '' : 's'}
                </span>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | Due today
        |--------------------------------------------------------------------------
        */
        if (today.getTime() === currentDueDate.getTime()) {

            return `
                <span class="monthly-payment-reminder monthly-payment-critical"
                      title="Monthly payment is due today">

                    <i class="mdi mdi-alert-outline"></i>
                    Payment due Today
                </span>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | Due date is still ahead
        |--------------------------------------------------------------------------
        */
        if (today < currentDueDate) {

            const daysRemaining = getDaysBetween(
                today,
                currentDueDate
            );

            if (daysRemaining <= 7) {

                return `
                    <span class="monthly-payment-reminder monthly-payment-critical"
                          title="Monthly payment is due very soon">

                        <i class="mdi mdi-clock-alert-outline"></i>
                        Due in ${daysRemaining}
                        day${daysRemaining === 1 ? '' : 's'}
                    </span>
                `;
            }

            if (daysRemaining <= 30) {

                return `
                    <span class="monthly-payment-reminder monthly-payment-warning"
                          title="Monthly payment is due within 30 days">

                        <i class="mdi mdi-calendar-alert-outline"></i>
                        Due in ${daysRemaining} days
                    </span>
                `;
            }

            return `
                <span class="monthly-payment-reminder monthly-payment-safe"
                      title="Monthly payment due on ${formatOrdinalDay(dueDay)}">

                    <i class="mdi mdi-calendar-check-outline"></i>
                    Due in ${daysRemaining} days
                </span>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | Due date passed and no current-month payment
        |--------------------------------------------------------------------------
        */
        const overdueDays = getDaysBetween(
            currentDueDate,
            today
        );

        return `
            <span class="monthly-payment-reminder monthly-payment-overdue"
                  title="Monthly payment is overdue">

                <i class="mdi mdi-alert-circle-outline"></i>
                Overdue by ${overdueDays}
                day${overdueDays === 1 ? '' : 's'}
            </span>
        `;
    }


    function buildRow(item, index) {

        const bankName = escapeHtml(item.bank_name || '—');
        const cardHolder = escapeHtml(item.card_holder || '—');
        const referenceName =escapeHtml(item.reference_name || '');
        const cardType = escapeHtml(item.card_type || '—');
        const maskedCard =escapeHtml( item.masked_card || '•••• •••• •••• ••••');
        const rawDueDate = item.due_date || '';
        const expiryDate = item.expiry_date || '';

        const dueDate = escapeHtml(rawDueDate || '—');
        const expiryReminder = getExpiryReminder(expiryDate);

        const paymentDueDay = Number(item.payment_due_day || 0);
        const monthlyPaid = Number(item.monthly_paid || 0);

        const monthlyDueReminder = getMonthlyDueReminder(
            paymentDueDay,
            monthlyPaid
        );

        creditCardRows[String(item.sno)] = item;

        /*
        |--------------------------------------------------------------------------
        | Status
        |--------------------------------------------------------------------------
        */

        const isActive = Number(item.status) === 0;

        const statusBadge = isActive ? `
                <span class="badge bg-label-success">
                    <i class="mdi mdi-check-circle-outline me-1"></i>
                    Active
                </span>
            `
            : `
                <span class="badge bg-label-secondary">
                    <i class="mdi mdi-close-circle-outline me-1"></i>
                    Inactive
                </span>
            `;

        /*
        |--------------------------------------------------------------------------
        | Status switch
        |--------------------------------------------------------------------------
        */
        const statusSwitch = `
            <label class="switch switch-square" data-bs-toggle="tooltip" data-bs-placement="top"  title="${isActive ? 'Deactivate' : 'Activate'}">
                <input
                    type="checkbox"
                    class="switch-input credit-card-status-toggle"
                    data-id="${escapeHtml(item.sno)}"
                    ${isActive ? 'checked' : ''}/ onchange="updatelevelStatus('${item.sno}', this.checked)">

                <span class="switch-toggle-slider">
                    <span class="switch-on"></span>
                    <span class="switch-off"></span>
                </span>

            </label>
        `;


        /*
        |--------------------------------------------------------------------------
        | Reference
        |--------------------------------------------------------------------------
        */

        const referenceHtml = referenceName
            ? `
                <div class="text-muted fs-8 mt-1">
                    <i class="mdi mdi-tag-outline me-1"></i>
                    ${referenceName}
                </div>
            `
            : '';

        const cardLimit = item.value ?? 0;

        const formattedLimit = Number(cardLimit).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        const cardTypeImage = getCreditCardImage(item.card_type);


        /*
        |--------------------------------------------------------------------------
        | Row
        |--------------------------------------------------------------------------
        */

        return `
            <tr id="credit_card_row_${escapeHtml(item.sno)}">

                {{-- Bank / Card --}}
                <td>

                    <div class="d-flex align-items-center">

                        <div
                            class="avatar avatar-sm bg-label-primary me-3 d-flex align-items-center justify-content-center rounded" >
                            <i class="mdi mdi-bank-outline fs-4"></i>
                        </div>

                        <div>

                            <div class="fw-semibold">
                                ${bankName}
                            </div>

                            ${referenceHtml}

                        </div>

                    </div>

                </td>


                {{-- Card Reference --}}
                <td>

                    <div class="d-flex flex-column gap-2">

                        <div class="d-flex align-items-center gap-2">

                            <span
                                class="badge bg-label-dark px-3 py-2"
                                style="letter-spacing: 1.5px;"
                            >
                                <i class="mdi mdi-credit-card-outline me-1"></i>
                                ${maskedCard}
                            </span>

                        </div>

                        <div>

                            <div class="fw-semibold text-dark text-center" data-bs-toggle="tooltip" data-bs-placement="top"  title="Credit Limit">
                                ₹ ${formattedLimit}
                            </div>

                        </div>

                    </div>

                </td>


                {{-- Card Holder --}}
                <td>

                    <div class="fw-semibold">
                        ${cardHolder}
                    </div>

                    <div class="text-muted fs-8 mt-1">
                        <i class="mdi mdi-account-outline me-1"></i>
                        Card Holder
                    </div>

                </td>


                {{-- Type / Due --}}
                <td>

                    <div class="d-flex align-items-center gap-2">

                        ${
                            cardTypeImage
                                ? `
                                    <div class="credit-card-network">
                                        ${cardTypeImage}
                                    </div>
                                `
                                : `
                                    <div class="credit-card-network credit-card-network-fallback">
                                        <i class="mdi mdi-credit-card-outline"></i>
                                    </div>
                                `
                        }

                        <div class="fw-semibold text-capitalize">
                            ${cardType}
                        </div>

                        

                    </div>
                    <div>

                        

                        <div>
                            <div class="text-muted fs-8 mt-1">
                                <i class="mdi mdi-calendar-month-outline me-1"></i>
                                Card Expiry: ${dueDate}
                            </div>

                            <div class="monthly-due-line">
                                <i class="mdi mdi-calendar-repeat-outline"></i>
                                Due:
                                <span class="monthly-due-day">
                                    ${formatOrdinalDay(paymentDueDay)}
                                </span>
                            </div>

                            <!-- <div>
                                ${expiryReminder}
                            </div> -->

                            <div>
                                ${monthlyDueReminder}
                            </div>
                        </div>

                    </div>
                    

                </td>


                {{-- Status --}}
                <td>

                
                    <div class="mb-2">
                        ${statusSwitch}
                    </div>
                    <div>
                        ${statusBadge}
                    </div>
                  

                </td>


                {{-- Action --}}
                <td class="text-center">

                    <div class="dropdown">

                        <button
                            type="button"
                            class="btn btn-icon btn-sm"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            aria-label="Credit card actions"
                        >
                            <i class="mdi mdi-dots-vertical fs-4"></i>
                        </button>


                        <div
                            class="dropdown-menu dropdown-menu-end"
                            style="width: 190px;"
                        >
                       
                            <a
                                href="javascript:;"
                                class="dropdown-item text-success"
                                onclick="openPayment('${escapeHtml(item.sno)}')"
                            >
                                <i class="mdi mdi-cash-plus me-2"></i>
                                Credit Payment
                            </a>

                            <a
                                href="javascript:;"
                                class="dropdown-item"
                                onclick="openEdit('${escapeHtml(item.sno)}')"
                            >
                                <i class="mdi mdi-square-edit-outline me-2"></i>
                                Edit
                            </a>


                            <div class="dropdown-divider"></div>


                            <a
                                href="javascript:;"
                                class="dropdown-item text-danger"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_delete_credit"
                                onclick="confirmCreditCardDelete(
                                    '${escapeHtml(item.sno)}',
                                    '${escapeHtml(item.bank_name)}'
                                )"
                            >
                                <i class="mdi mdi-delete-outline me-2"></i>
                                Delete
                            </a>

                        </div>

                    </div>

                </td>

            </tr>
        `;
    }


    function getCreditCardImage(cardType) {

        const type = String(cardType || '')
            .trim()
            .toLowerCase();

        const imageMap = {
            'visa': 'visa.png',
            'mastercard': 'mastercard.png',
            'master card': 'mastercard.png',
            'american express': 'americanexpress.png',
            'americanexpress': 'americanexpress.png',
            'amex': 'americanexpress.png',
            'rupay': 'rupay.png',
            'rupay card': 'rupay.png',
            'discover': 'discover.png',
            'jcb': 'jcb.png',
            'diners club': 'dinersclub.png',
            'diners': 'dinersclub.png'
        };

        const image = imageMap[type];

        if (!image) {
            return '';
        }

        return `
            <img
                src="/assets/egc_images/social_media/${image}"
                alt="${escapeHtml(cardType)}"
                class="credit-card-type-logo"
                loading="lazy"
                onerror="this.style.display='none';"
            >
        `;
    }
   
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/accounts_finance/credit_card?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        const tableBody = document.getElementById('company-table-body');

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('company-table-body').innerHTML = ''; // Clear old data
        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', buildRow(item, index));
                    });

                }else{
                    document.getElementById('company-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;

                tableBody.innerHTML = ` <tr> <td colspan="6" class="text-center py-5" > <div class="text-danger"> <i class="mdi mdi-alert-circle-outline fs-1" ></i> <div class="fw-semibold mt-2"> Unable to load credit cards. </div> <button type="button" class="btn btn-sm btn-primary mt-3" onclick="loadCreditCards(1)" > <i class="mdi mdi-refresh me-1"></i> Try Again </button> </div> </td> </tr> `;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="6" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
    function updatelevelStatus(id, isChecked) {
        const status = isChecked ? 0 : 1; // Set status based on checkbox state

        fetch(`/creadit_card_update_status/${id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Credit Card status Updated successfully!');
                    loadThemes(1);
                } else {
                    toastr.error('Error updating Credit Card ');
                }
            })
            .catch(error => {
                console.error('Error updating Credit Card status:', error);
            });
    }
</script>
<script>
    function confirmCreditCardDelete(sno, name) {
        document.querySelector('#kt_modal_delete_credit .btn-danger').setAttribute(
            'data-id', sno);
        $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
            '</b> Credit Card ?');
    }

    function deleteDepartmentCategory() {

        var universityId = document.querySelector('#kt_modal_delete_credit .btn-danger').getAttribute('data-id');

        fetch('/creadit_card_delete/' + universityId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Company Deleted successfully!');
                    location.reload();

                } else if(data.status === 302) {
                    toastr.error(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/plugins/monthSelect/style.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/plugins/monthSelect/index.js"></script>
    
   <script>
    /* ============================================================
    | CREDIT CARD MODAL
    | Table: egc_acc_tiderc_drac
    ============================================================ */



           let creditCardModal = null;
           let formModel= null;
           let modalMode= 'create';
           let initializedModal= false;
           let creditCardDueDatePicker;

            /* INIT  */

            function initCredit() {

                if (initializedModal) {
                    return;
                }

                creditCardModal = $('#creditCardModal');
                formModel = $('#creditCardForm');

                if (!creditCardModal.length || !formModel.length) {
                    return;
                }

                initializeSelect2();
                initializeDatePicker();
                bindEvents();

                initializedModal = true;

            }

            /* SELECT2 */
            function initializeSelect2() {
                // $('#credit_card_company_id').select2({
                //     width: '100%',
                //     dropdownParent: modal,
                //     placeholder: 'Select Company',
                //     allowClear: true
                // });

                // $('#credit_card_entity_id').select2({
                //     width: '100%',
                //     dropdownParent: modal,
                //     placeholder: 'Select Entity',
                //     allowClear: true
                // });
            }

            /* DATE PICKER */
            function initializeDatePicker() {

                const element = document.getElementById('credit_card_due_date');

                if (element && typeof flatpickr !== 'undefined') {
                    creditCardDueDatePicker = flatpickr(element, {
                        dateFormat: 'm/y',
                        altInput: false,
                        allowInput: false,
                        disableMobile: true,
                        plugins: [
                            new monthSelectPlugin({
                                shorthand: true,
                                dateFormat: 'm/y',
                                altFormat: 'm/y'
                            })
                        ]
                    });
                }


                $('.paid_date').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'dd-M-yyyy'
                });

                    

            }

            /* EVENTS */
            function bindEvents() {
                
                /*Company */
                $('#credit_card_company_id')
                    .off('change.creditCard')
                    .on('change.creditCard', function () {
                        const companyId = $(this).val();
                        loadEntities(companyId);
                    });


                /* Form Submit */
                formModel.off('submit.creditCard')
                    .on('submit.creditCard', function (event) {
                        event.preventDefault();
                        submitCredit();
                    });

                /* Reset */
                $('#btnResetCreditCard')
                    .off('click.creditCard')
                    .on('click.creditCard', function () {
                        resetCredit();
                    });

                /* Card Part Input  */
                $('.credit-card-part-input')
                    .off('input.creditCard')
                    .on('input.creditCard', function () {
                        handleCardPartInput(this);

                    });

                /*  Prevent Non Numeric Paste */
                $('.credit-card-part-input')
                    .off('paste.creditCard')
                    .on('paste.creditCard', function (event) {
                        const clipboard =
                            event.originalEvent.clipboardData ||
                            window.clipboardData;
                        const value = clipboard
                            ? clipboard.getData('text')
                            : '';

                        if (!/^\d+$/.test(value)) {
                            event.preventDefault();
                        }
                    });

                /* Modal Hidden  */
                creditCardModal
                    .off('hidden.bs.modal.creditCard')
                    .on('hidden.bs.modal.creditCard',
                        function () {
                            resetCredit();
                        }
                    );
            }

            /* CARD PART INPUT  */
            function handleCardPartInput(input) {
                const $input = $(input);
                let value = $input.val();

                value = value
                    .replace(/\D/g, '')
                    .substring(0, 4);

                $input.val(value);
                clearCardPartError();

                /*Automatically move to next field */
                if (value.length === 4) {

                    const $inputs =$('.credit-card-part-input');

                    const index = $inputs.index($input);

                    if (index < $inputs.length - 1) {
                        $inputs.eq(index + 1)
                            .trigger('focus');
                    }

                }

            }

            /* LOAD COMPANIES */
            function loadCompanies(selectedId = '') {

                if (!window.expenseRoutes || !window.expenseRoutes.companies ) {
                    return;
                }

                const $company = $('#credit_card_company_id');

                $company.prop('disabled', true);

                $.ajax({
                    url: window.expenseRoutes.companies,
                    type: 'GET',
                    dataType: 'json',
                    success: function (response) {

                        let html = '<option value="">Select Company</option>';
                        const rows = Array.isArray(response?.data) ? response.data : [];

                        rows.forEach(function (item) {
                            const id = item.company_id ?? item.sno ?? '';
                            const name = item.company_name ?? '';
                            if (!id || !name) {
                                return;
                            }
                            html += `
                                <option
                                    value="${escapeHtml(id)}"
                                    ${String(id) === String(selectedId)
                                        ? 'selected'
                                        : ''}>
                                    ${escapeHtml(name)}
                                </option>
                            `;
                        });

                        $company.html(html)
                            .trigger('change.select2');
                    },
                    error: function () {
                        $company.html('<option value="">Unable to load companies</option>')
                            .trigger('change.select2');

                    },
                    complete: function () {
                        $company.prop('disabled', false);
                    }

                });

            }

            /*  LOAD ENTITIES  */
            function loadEntities(
                companyId,
                selectedId = '',
                callback = null
            ) {

                const $entity = $('#credit_card_entity_id');
                $entity.prop('disabled', true).html('<option value="">Loading entities...</option>')
                    .trigger('change.select2');

                if (!companyId) {
                    $entity.html(
                            '<option value="">Select Entity</option>')
                        .trigger('change.select2');
                    return;
                }


                if (!window.expenseRoutes || !window.expenseRoutes.entities ) {
                    $entity
                        .html(
                            '<option value="">Entity route unavailable</option>'
                        )
                        .trigger('change.select2');
                    return;
                }
                
                $.ajax({
                    url: window.expenseRoutes.entities,
                    type: 'GET',
                    dataType: 'json',
                    data: {
                        company_id: companyId
                    },

                    success: function (response) {
                        let html ='<option value="">Select Entity</option>';
                        const rows = Array.isArray(response?.data)
                                ? response.data
                                : [];

                        rows.forEach(function (item) {

                            const id =
                                item.sno ??
                                item.entity_id ??
                                '';

                            const name =
                                item.entity_name ??
                                '';

                            if (!id || !name) {
                                return;
                            }

                            html += `
                                <option
                                    value="${escapeHtml(id)}"
                                    ${String(id) === String(selectedId)
                                        ? 'selected'
                                        : ''}>
                                    ${escapeHtml(name)}
                                </option>
                            `;

                        });

                        $entity
                            .html(html)
                            .prop('disabled', false)
                            .trigger('change.select2');

                        if (typeof callback === 'function') {
                            callback();
                        }

                    },
                    error: function () {
                        $entity
                            .html(
                                '<option value="">Unable to load entities</option>'
                            )
                            .prop('disabled', true)
                            .trigger('change.select2');

                    }

                });

            }

            /*OPEN CREATE */
            function openCreate() {

                resetCredit(false);

                modalMode = 'create';

                $('#creditCardFormMode').val('create');
                $('#credit_card_id').val('');

                $('#creditCardModalLabel').text('Add Credit Card');
                $('#creditCardSaveText').text('Save Credit Card');

                loadCompanies();

                show();
            }

            /* OPEN EDIT  */
            function openEdit(id) {

                if (!id) {
                    return;
                }

                resetCredit(false);

                modalMode = 'edit';

                

                $('#creditCardFormMode').val('edit');
                $('#credit_card_id').val(id);

                $('#creditCardModalLabel').text('Edit Credit Card');
                $('#creditCardSaveText').text('Update Credit Card');

                show();

                setLoading(true);


                if (
                    !window.expenseRoutes ||
                    !window.expenseRoutes.creditCardShow
                ) {

                    setLoading(false);
                    return;

                }

                const url = window.expenseRoutes.creditCardShow.replace(':id', encodeURIComponent(id));

                $.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'json',
                    success: function (response) {
                        const data = response?.data ?? response;
                        populate(data);
                    },
                    error: function () {
                        showError(
                            'Unable to load credit card details.'
                        );
                    },
                    complete: function () {
                        setLoading(false);
                    }

                });

            }

            /*  POPULATE EDIT DATA  */
            function populate(data) {

                if (!data) {
                    return;
                }

                const companyId = data.company_id ?? '';
                const entityId =  data.entity_id ?? '';

                $('#credit_card_company_id')
                    .val(companyId)
                    .trigger('change.select2');

                loadEntities(companyId,entityId);

                $('#credit_card_bank_name').val(data.b_name ?? '');

                $('#credit_card_holder').val(data.rd_prsn_name ?? '');

                $('#credit_card_name').val(data.rd_name ?? '');

                $('#credit_card_type').val(data.type ?? '').trigger('change');

                if (data.due && creditCardDueDatePicker) {
                    creditCardDueDatePicker.setDate(data.due, true, 'Y-m-d');
                }

                // $('#credit_card_due_date').val(data.due ?? '');

                $('#credit_card_cvv').val(data.vv_no ?? '');

                $('#credit_card_payment_due_day')
                    .val(data.payment_due_day ?? '').trigger('change');

                $('#credit_card_limit').val(data.value ?? '');



                $('#rd_prt1').val(data.rd_prt1 ?? '');
                $('#rd_prt2').val(data.rd_prt2 ?? '');
                $('#rd_prt3').val(data.rd_prt3 ?? '');
                $('#rd_prt4').val(data.rd_prt4 ?? '');
                // $('#rd_prt5').val('');

            }

            /* SUBMIT */
            function submitCredit() {
                 console.log("Before Submit")

                if (!validate()) {
                    console.log("validate() t-" ,validate())
                    return;
                }

                console.log("after Submit")



                const form =formModel[0];

                const formData = new FormData(form);

                let url = window.expenseRoutes?.creditCardStore ?? '';

                let method = 'POST';

                if (modalMode === 'edit') {
                    const id = $('#credit_card_id').val();
                    if (!id) {
                        showError('Credit card ID is missing.');
                        return;
                    }
                    url = window.expenseRoutes?.creditCardUpdate || '';
                    // Replace :id with actual ID
                    url = url.replace(':id', encodeURIComponent(id));
                    method = 'POST';
                    // Laravel method spoofing
                    formData.append('_method', 'POST');
                }

               
                console.log("url before Credit card")

                if (!url) {
                    showError('Credit card save route is not configured.');
                    return;
                }
                console.log("url pass Credit card")

                setSaving(true);

                $.ajax({
                    url: url,
                    type: method,
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },

                    success: function (response) {
                         loadThemes(1)
                        handleSaveSuccess(response);
                       
                    },
                    error: function (xhr) {
                        handleSaveError(xhr);
                    },
                    complete: function () {
                        setSaving(false);
                    }
                });

            }

            /* VALIDATION */
            function validate() {

                clearErrors();

                let valid = true;

                const company =  $('#credit_card_company_id').val();
                const entity = $('#credit_card_entity_id').val();
                const bank = $.trim($('#credit_card_bank_name').val());
                const holder = $.trim($('#credit_card_holder').val());

                const type = $('#credit_card_type').val();
                const credit_limit =$.trim($('#credit_card_limit').val());

                const due_date = $.trim($('#credit_card_due_date').val());
                const card_cvv = $.trim($('#credit_card_cvv').val());
                const payment_due_day = $.trim($('#credit_card_payment_due_day').val());

                // if (!company) {

                //    fieldError(
                //         '#credit_card_company_id',
                //         'Company is required.'
                //     );

                //     valid = false;

                // }

                // if (!entity) {

                //    fieldError(
                //         '#credit_card_entity_id',
                //         'Entity is required.'
                //     );

                //     valid = false;

                // }
                if (!bank) {
                    fieldError('#credit_card_bank_name','Bank name is required.');
                    valid = false;
                }


                if (!holder) {
                    fieldError( '#credit_card_holder','Card holder name is required.');
                    valid = false;
                }
                if (!credit_limit) {

                    fieldError(
                        '#credit_card_limit',
                        'Credit card limit is required.'
                    );

                    valid = false;

                } else if (
                    !/^\d+(?:\.\d{1,2})?$/.test(credit_limit)
                ) {

                    fieldError(
                        '#credit_card_limit',
                        'Enter a valid credit card limit.'
                    );

                    valid = false;

                } else if (Number(credit_limit) <= 0) {

                    fieldError(
                        '#credit_card_limit',
                        'Credit card limit must be greater than zero.'
                    );

                    valid = false;
                }
                if (!type) {
                    fieldError( '#credit_card_type','Card type is required.' );
                    valid = false;
                }

                /*
                |--------------------------------------------------------------------------
                | Card Expiry Date
                | Format: MM/YY
                |--------------------------------------------------------------------------
                */

                if (!due_date) {

                    fieldError(
                        '#credit_card_due_date',
                        'Card expiry date is required.'
                    );

                    valid = false;

                } else if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(due_date)) {

                    fieldError(
                        '#credit_card_due_date',
                        'Enter a valid expiry date in MM/YY format.'
                    );

                    valid = false;

                } else {

                    const [month, year] =  due_date.split('/').map(Number);
                    const currentDate = new Date();
                    const currentMonth = currentDate.getMonth() + 1;
                    const currentYear = currentDate.getFullYear() % 100;

                    /*
                    |--------------------------------------------------------------------------
                    | Expiry is valid through the end of the selected month.
                    |--------------------------------------------------------------------------
                    */

                    if (
                        year < currentYear ||
                        (
                            year === currentYear &&
                            month < currentMonth
                        )
                    ) {

                        fieldError(
                            '#credit_card_due_date',
                            'Card expiry date has already expired.'
                        );

                        valid = false;
                    }
                }
                /* |------------- | CVV / CVC |-------------- */ 
                if (!card_cvv) { 
                    fieldError( '#credit_card_cvv', 'CVV / CVC is required.' ); 
                    valid = false; 
                } else if (!/^\d{3,4}$/.test(card_cvv)) { 
                    fieldError( '#credit_card_cvv', 'CVV / CVC must contain 3 or 4 digits.' ); 
                    valid = false; 
                }

                /*
                |--------------------------------------------------------------------------
                | Monthly Payment Due Day
                |--------------------------------------------------------------------------
                */

                if (!payment_due_day) {

                    fieldError(
                        '#credit_card_payment_due_day',
                        'Monthly payment due day is required.'
                    );

                    valid = false;

                } else if (!/^\d{1,2}$/.test(payment_due_day)) {

                    fieldError(
                        '#credit_card_payment_due_day',
                        'Select a valid day between 1 and 31.'
                    );

                    valid = false;

                } else {

                    const paymentDay = Number(payment_due_day);

                    if (paymentDay < 1 || paymentDay > 31) {

                        fieldError(
                            '#credit_card_payment_due_day',
                            'Select a valid day between 1 and 31.'
                        );

                        valid = false;
                    }
                }


                /* |----------- | Card Parts |----------- */ 
                const cardParts = [ 
                    $('#rd_prt1').val(), 
                    $('#rd_prt2').val(), 
                    $('#rd_prt3').val(), 
                    $('#rd_prt4').val() 
                ]; 
                const cardPartsEntered = cardParts.some(function (part) { 
                    return String(part).trim().length > 0; 
                }); 
                /* |--------- | Create: | All card parts required. | | Edit: | Empty parts = keep existing card reference. | If any part is entered, all four must be valid. |----------- */ 
                if ( modalMode === 'create' || cardPartsEntered ) { 
                    cardParts.forEach(function (part, index) { 
                        const value = String(part).trim(); if (!/^\d{4}$/.test(value)) { 
                            $('#rd_prt' + (index + 1)) .addClass('is-invalid'); valid = false; 
                        } 
                    }); 
                    if (!cardPartsEntered) { 
                        $('#creditCardPartsError') .text( 'All four card reference parts are required.' ); 
                    } else { 
                        const hasInvalidPart = cardParts.some(function (part) { 
                            return !/^\d{4}$/.test( String(part).trim() ); 
                        }); 
                        if (hasInvalidPart) { 
                            $('#creditCardPartsError') .text( 'Each card reference part must contain 4 digits.' ); 
                        } 
                    } 
                }

                return valid;

            }

            /* CLEAR VALIDATION */
            function clearErrors() {

                formModel
                    .find('.is-invalid')
                    .removeClass('is-invalid');

                formModel
                    .find('.invalid-feedback')
                    .not('.d-block')
                    .text('');

                $('#creditCardPartsError')
                    .text('');

            }

            function clearCardPartError() {

                $('.credit-card-part-input')
                    .removeClass('is-invalid');

                $('#creditCardPartsError')
                    .text('');

            }

            function fieldError(
                selector,
                message
            ) {

                const $field = $(selector);

                $field.addClass('is-invalid');

                const name = $field.attr('name');

                if (name) {

                    const $error = $('.' + name + '_error');

                    $error
                        .text(message)
                        .addClass('d-block');
                }
            }


            /*  RESET  */
            function resetCredit(hideModal = false) {

                if (!formModel || !formModel.length) {
                    return;
                }

                // Reset native form
                formModel[0].reset();

                // Reset hidden fields
                $('#credit_card_id').val('');
                $('#creditCardFormMode').val('create');

                // Reset UI
                $('#creditCardModalLabel').text('Add Credit Card');
                $('#creditCardSaveText').text('Save Credit Card');

                // Reset entity
                $('#credit_card_entity_id')
                    .html('<option value="">Select Entity</option>')
                    .prop('disabled', true)
                    .trigger('change');

                // Reset company
                $('#credit_card_company_id')
                    .val('')
                    .trigger('change');

                // Reset card type
                $('#credit_card_type')
                    .val('')
                    .trigger('change');

                $('#credit_card_payment_due_day')
                    .val('').trigger('change');

                // Reset card reference
                $('.credit-card-part-input')
                    .val('')
                    .removeClass('is-invalid');

                $('#creditCardPartsError').text('');

                // Clear validation
                clearErrors();

                // Reset Flatpickr
                const dateElement =
                    document.getElementById('credit_card_due_date');

                if (
                    dateElement &&
                    dateElement._flatpickr
                ) {
                    dateElement._flatpickr.clear();
                }

                // Reset loading/saving state
                setLoading(false);
                setSaving(false);

                if (hideModal) {
                    hide();
                }
            }


            /* SHOW */
            function show() {

                const element =
                    document.getElementById(
                        'creditCardModal'
                    );

                if (!element) {
                    return;
                }

                const instance =
                    bootstrap.Modal.getOrCreateInstance(
                        element
                    );

                instance.show();

            }

            /* HIDE */
            function hide() {
                const element =
                    document.getElementById(
                        'creditCardModal'
                    );

                if (!element) {
                    return;
                }

                const instance =
                    bootstrap.Modal.getInstance(element);

                if (instance) {

                    instance.hide();

                }

            }

            /* LOADING  */
            function setLoading(loading) {

                const modal =
                    $('.expense-credit-card-modal');

                modal.toggleClass(
                    'is-loading',
                    loading
                );

            }

            /* SAVING*/
            function setSaving(saving) {
                const $button = $('#btnSaveCreditCard');

                const $loader = $('#creditCardLoader');

                const $text = $('#creditCardSaveText');

                $button.prop(
                    'disabled',
                    saving
                );


                $loader.toggleClass(
                    'd-none',
                    !saving
                );


                if (saving) {

                    $text.text(
                        modalMode === 'edit'
                            ? 'Updating...'
                            : 'Saving...'
                    );

                } else {

                    $text.text(
                        modalMode === 'edit'
                            ? 'Update Credit Card'
                            : 'Save Credit Card'
                    );

                }

            }


            /*SAVE SUCCESS */
            function handleSaveSuccess(response) {

                const message =
                    response?.message ||
                    (
                        modalMode === 'edit'
                            ? 'Credit card updated successfully.'
                            : 'Credit card created successfully.'
                    );


                showSuccess(message);

                /*Refresh credit card dropdown*/

                if (
                    window.expenseModal &&
                    typeof window.expenseModal.loadCreditCards === 'function'
                ) {

                    window.expenseModal.loadCreditCards();

                }


                /*
                | Refresh DataTable
                */

                if (
                    window.expenseTable &&
                    typeof window.expenseTable.reload === 'function'
                ) {

                    window.expenseTable.reload();

                }


                /*
                | Close modal
                */

                hide();

            }

            /* SAVE ERROR */
            function handleSaveError(xhr) {

                if (xhr.status === 422) {

                    const errors = xhr.responseJSON?.errors || {};
                    const errorMessage = xhr.responseJSON?.message || 'Something is Wrong. Try Again Later';
                    
                    toastr.error(errorMessage)

                    Object.keys(errors).forEach(function (field) {

                        const message =
                            Array.isArray(errors[field])
                                ? errors[field][0]
                                : errors[field];

                        const $field =
                            $('[name="' + field + '"]');

                        $field.addClass('is-invalid');

                        $('.' + field + '_error').text(message);
                        

                    });


                    return;

                }


                showError(
                    xhr.responseJSON?.message ||
                    'Unable to save credit card.'
                );

            }


            /* ALERTS */
            function showSuccess(message) {

                toastr.success(message);
                console.log(message);

            }

            function showError(message) {
                 toastr.error(message);
                console.error(message);
            }

            /* HTML ESCAPE*/
            function escapeHtml(value) {

                return $('<div>')
                    .text(value ?? '')
                    .html();

            }

    initCredit();
</script>

<script>
    const cvvInput = document.getElementById('credit_card_cvv');
    const toggleCvv = document.getElementById('toggleCreditCardCvv');

if (cvvInput) {

    // Allow numbers only
    cvvInput.addEventListener('input', function () {
        this.value = this.value.replace(/\D/g, '').slice(0, 4);
    });

    // Show / hide CVV
    if (toggleCvv) {
        toggleCvv.addEventListener('click', function () {

            const isPassword = cvvInput.type === 'password';

            cvvInput.type = isPassword ? 'text' : 'password';

            this.setAttribute(
                'aria-label',
                isPassword ? 'Hide CVV' : 'Show CVV'
            );

            const icon = this.querySelector('i');

            if (icon) {
                icon.classList.toggle(
                    'mdi-eye-outline',
                    !isPassword
                );

                icon.classList.toggle(
                    'mdi-eye-off-outline',
                    isPassword
                );
            }
        });
    }
}
</script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {

    const cardToggle = document.getElementById('toggleCreditCardNumber');

    if (!cardToggle) {
        return;
    }

    const cardInputs = document.querySelectorAll(
        '.credit-card-part-input'
    );

    cardToggle.addEventListener('click', function () {

        const isHidden = cardInputs.length &&
            cardInputs[0].type === 'password';

        cardInputs.forEach(function (input) {
            input.type = isHidden ? 'text' : 'password';
        });

        const icon = this.querySelector('i');
        const text = this.querySelector('span');

        if (isHidden) {

            icon.classList.remove('mdi-eye-outline');
            icon.classList.add('mdi-eye-off-outline');

            text.textContent = 'Hide';

            this.setAttribute('aria-label', 'Hide card number');
            this.setAttribute('aria-pressed', 'true');

        } else {

            icon.classList.remove('mdi-eye-off-outline');
            icon.classList.add('mdi-eye-outline');

            text.textContent = 'Show';

            this.setAttribute('aria-label', 'Show card number');
            this.setAttribute('aria-pressed', 'false');
        }
    });
});
</script>
<script>
    window.expenseRoutes = window.expenseRoutes || {};

    window.expenseRoutes.companies =
        @json(route('accounts.creditcard.companies'));

    window.expenseRoutes.entities =
        @json(route('accounts.creditcard.entities'));

    window.expenseRoutes.creditCardStore =
        @json(route('accounts.creditcard.store'));

    window.expenseRoutes.creditCardShow =
        @json(route('accounts.creditcard.show', ['id' => ':id']));

    window.expenseRoutes.creditCardUpdate =
        @json(route('accounts.creditcard.update', ['id' => ':id']));

    window.expenseRoutes.creditCardDelete =
        @json(route('accounts.creditcard.destroy', ['id' => ':id']));

    window.expenseRoutes.creditCardPaymentStore =
        @json(route('accounts.creditcard.payments.store', ['id' => ':id']));

    window.expenseRoutes.creditCardPaymentHistory =
        @json(route('accounts.creditcard.payments.history', ['id' => ':id']));
</script>

<script>
    /* ============================================================
    | CREDIT CARD PAYMENT MODAL
    ============================================================ */

    let creditCardPaymentSaving = false;


    function todayForDateInput() {

        const today = new Date();

        return [
            today.getFullYear(),
            String(today.getMonth() + 1).padStart(2, '0'),
            String(today.getDate()).padStart(2, '0')
        ].join('-');
    }


    function formatPaymentDateOnly(dateString) {

        const value = String(dateString || '').trim();
        const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);

        if (!match) {
            return '—';
        }

        const year = Number(match[1]);
        const month = Number(match[2]);
        const day = Number(match[3]);

        const date = new Date(year, month - 1, day);

        if (
            Number.isNaN(date.getTime()) ||
            date.getFullYear() !== year ||
            date.getMonth() !== month - 1 ||
            date.getDate() !== day
        ) {
            return '—';
        }

        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    }


    function formatPaymentInr(amount) {

        return Number(amount || 0).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }


    function clearPaymentErrors() {

        $('#creditCardPaymentAmountError').text('');
        $('#creditCardPaymentDateError').text('');

        $('#credit_card_payment_amount')
            .removeClass('is-invalid');

        $('#credit_card_payment_date')
            .removeClass('is-invalid');
    }


    function setPaymentSaving(saving) {

        creditCardPaymentSaving = saving;

        const $button =
            $('#btnSaveCreditCardPayment');

        const $loader =
            $('#creditCardPaymentLoader');

        const $text =
            $('#creditCardPaymentSaveText');

        $button.prop('disabled', saving);

        $loader.toggleClass(
            'd-none',
            !saving
        );

        $text.text(
            saving
                ? 'Saving...'
                : 'Record Payment'
        );
    }


    function openPayment(id) {

        const item =
            creditCardRows[String(id)];

        if (!item) {

            toastr.error(
                'Credit card details are unavailable. Please refresh the list.'
            );

            return;
        }

        clearPaymentErrors();

        $('#credit_card_payment_card_id')
            .val(id);

        $('#creditCardPaymentBank')
            .text(
                item.bank_name ||
                'Credit Card'
            );

        $('#creditCardPaymentReference')
            .text(
                item.masked_card ||
                '•••• •••• ••••'
            );

        $('#creditCardPaymentDueDay')
            .text(
                item.payment_due_day
                    ? formatOrdinalDay(item.payment_due_day)
                    : 'Not set'
            );

        $('#creditCardPaymentMonthTotal')
            .text(
                `₹ ${formatPaymentInr(
                    item.monthly_paid || 0
                )}`
            );

        const now = new Date();

        $('#creditCardPaymentCycle')
            .text(
                now.toLocaleDateString('en-GB', {
                    month: 'short',
                    year: 'numeric'
                })
            );

        $('#credit_card_payment_amount')
            .val('');

        const today =
            todayForDateInput();

        $('#credit_card_payment_date')
            .val(today)
            .attr('max', today);

        $('#creditCardPaymentHistoryTotal')
            .text('Loading...');

        $('#creditCardPaymentHistoryBody')
            .html(`
                <tr>
                    <td colspan="2">
                        <div class="payment-empty-state">
                            <i class="mdi mdi-loading mdi-spin"></i>
                            Loading payment history...
                        </div>
                    </td>
                </tr>
            `);

        const element =
            document.getElementById(
                'creditCardPaymentModal'
            );

        if (!element) {
            return;
        }

        bootstrap.Modal
            .getOrCreateInstance(element)
            .show();

        loadPaymentHistory(id);
    }


    function loadPaymentHistory(id) {

        const routeTemplate =
            window.expenseRoutes?.creditCardPaymentHistory ||
            '';

        if (!routeTemplate) {

            renderPaymentHistory([]);

            return;
        }

        const url =
            routeTemplate.replace(
                ':id',
                encodeURIComponent(id)
            );

        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            success: function (response) {

                const rows =
                    Array.isArray(response?.data)
                        ? response.data
                        : [];

                const currentMonthTotal =
                    Number(
                        response?.current_month_total || 0
                    );

                renderPaymentHistory(rows);

                $('#creditCardPaymentMonthTotal')
                    .text(
                        `₹ ${formatPaymentInr(
                            currentMonthTotal
                        )}`
                    );
            },
            error: function () {

                $('#creditCardPaymentHistoryTotal')
                    .text('Unable to load');

                $('#creditCardPaymentHistoryBody')
                    .html(`
                        <tr>
                            <td colspan="2">
                                <div class="payment-empty-state text-danger">
                                    <i class="mdi mdi-alert-circle-outline"></i>
                                    Unable to load payment history.
                                </div>
                            </td>
                        </tr>
                    `);
            }
        });
    }


    function renderPaymentHistory(rows) {

        const $body =
            $('#creditCardPaymentHistoryBody');

        const $count =
            $('#creditCardPaymentHistoryTotal');

        if (!rows.length) {

            $count.text('0 payments');

            $body.html(`
                <tr>
                    <td colspan="2">
                        <div class="payment-empty-state">
                            <i class="mdi mdi-receipt-text-outline"></i>
                            No payment has been recorded yet.
                        </div>
                    </td>
                </tr>
            `);

            return;
        }

        $count.text(
            `${rows.length} payment${rows.length === 1 ? '' : 's'}`
        );

        let html = '';

        rows.forEach(function (row) {

            html += `
                <tr>
                    <td>
                        ${escapeHtml(
                            formatPaymentDateOnly(
                                row.paid_date
                            )
                        )}
                    </td>

                    <td class="text-end fw-semibold">
                        ₹ ${formatPaymentInr(
                            row.amount_paid
                        )}
                    </td>
                </tr>
            `;
        });

        $body.html(html);
    }


    function validateCreditCardPayment() {

        clearPaymentErrors();

        let valid = true;

        const amount =
            $.trim(
                $('#credit_card_payment_amount').val()
            );

        const paidDate =
            $.trim(
                $('#credit_card_payment_date').val()
            );

        if (!amount) {

            $('#credit_card_payment_amount')
                .addClass('is-invalid');

            $('#creditCardPaymentAmountError')
                .text(
                    'Payment amount is required.'
                );

            valid = false;

        } else if (
            !/^\d+(?:\.\d{1,2})?$/.test(amount)
        ) {

            $('#credit_card_payment_amount')
                .addClass('is-invalid');

            $('#creditCardPaymentAmountError')
                .text(
                    'Enter a valid amount with up to 2 decimals.'
                );

            valid = false;

        } else if (Number(amount) <= 0) {

            $('#credit_card_payment_amount')
                .addClass('is-invalid');

            $('#creditCardPaymentAmountError')
                .text(
                    'Payment amount must be greater than zero.'
                );

            valid = false;
        }

        if (!paidDate) {

            $('#credit_card_payment_date')
                .addClass('is-invalid');

            $('#creditCardPaymentDateError')
                .text(
                    'Payment date is required.'
                );

            valid = false;

        } else if (
            paidDate > todayForDateInput()
        ) {

            $('#credit_card_payment_date')
                .addClass('is-invalid');

            $('#creditCardPaymentDateError')
                .text(
                    'Payment date cannot be in the future.'
                );

            valid = false;
        }

        return valid;
    }


    function submitCreditCardPayment() {

        if (creditCardPaymentSaving) {
            return;
        }

        if (!validateCreditCardPayment()) {
            return;
        }

        const id =
            $('#credit_card_payment_card_id')
                .val();

        if (!id) {

            toastr.error(
                'Credit card ID is missing.'
            );

            return;
        }

        const routeTemplate =
            window.expenseRoutes?.creditCardPaymentStore ||
            '';

        if (!routeTemplate) {

            toastr.error(
                'Payment save route is not configured.'
            );

            return;
        }

        const url =
            routeTemplate.replace(
                ':id',
                encodeURIComponent(id)
            );

        const form =
            document.getElementById(
                'creditCardPaymentForm'
            );

        const formData =
            new FormData(form);

        setPaymentSaving(true);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN':
                    $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {

                toastr.success(
                    response?.message ||
                    'Payment recorded successfully.'
                );

                $('#credit_card_payment_amount')
                    .val('');

                loadPaymentHistory(id);

                // Refresh list so the monthly reminder changes immediately.
                loadThemes(currentPage);
            },
            error: function (xhr) {

                if (xhr.status === 422) {

                    const errors =
                        xhr.responseJSON?.errors || {};

                    Object.keys(errors).forEach(
                        function (field) {

                            const message =
                                Array.isArray(errors[field])
                                    ? errors[field][0]
                                    : errors[field];

                            if (field === 'amount_paid') {

                                $('#credit_card_payment_amount')
                                    .addClass('is-invalid');

                                $('#creditCardPaymentAmountError')
                                    .text(message);
                            }

                            if (field === 'paid_date') {

                                $('#credit_card_payment_date')
                                    .addClass('is-invalid');

                                $('#creditCardPaymentDateError')
                                    .text(message);
                            }
                        }
                    );

                    toastr.error(
                        xhr.responseJSON?.message ||
                        'Please correct the payment details.'
                    );

                    return;
                }

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Unable to record payment.'
                );
            },
            complete: function () {

                setPaymentSaving(false);
            }
        });
    }


    document.addEventListener(
        'DOMContentLoaded',
        function () {

            $('#creditCardPaymentForm')
                .off('submit.creditCardPayment')
                .on(
                    'submit.creditCardPayment',
                    function (event) {
                        event.preventDefault();
                        submitCreditCardPayment();
                    }
                );

            $('#credit_card_payment_amount')
                .off('input.creditCardPayment')
                .on(
                    'input.creditCardPayment',
                    function () {

                        this.value =
                            this.value
                                .replace(/[^0-9.]/g, '')
                                .replace(/(\..*)\./g, '$1');
                    }
                );
        }
    );
</script>

<script>
     function formatName(input) {

            let value = input.value;
            // Allow only letters, space, dot, apostrophe and hyphen
            value = value.replace(/[^A-Za-z\s.'-]/g, '');
            // Remove leading spaces
            value = value.replace(/^\s+/, '');
            // Replace multiple spaces with single space
            value = value.replace(/\s{2,}/g, ' ');
            // Capitalize every word
            value = value.toLowerCase().replace(/\b[a-z]/g, function(char) {
                return char.toUpperCase();
            });
            input.value = value;
        }
</script>
@endsection
