@extends('layouts/layoutMaster')

@section('content')

<div class="container-fluid py-4">

    <!-- 🔷 TOP KPI CARDS -->
    <div class="row g-4 mb-4">

        @foreach([
            ['title'=>'Total Staff','value'=>$totalStaff,'icon'=>'mdi-account-group','color'=>'#4e73df'],
            ['title'=>'Today Present','value'=>$presentCount,'icon'=>'mdi-check-circle','color'=>'#1cc88a'],
            ['title'=>'Candidates','value'=>$candidateCount,'icon'=>'mdi-account-search','color'=>'#36b9cc'],
            ['title'=>'Payroll','value'=>'₹'.$payrollTotal,'icon'=>'mdi-currency-inr','color'=>'#f6c23e']
        ] as $card)

        <div class="col-md-3">
            <div class="card shadow-sm border-0 rounded-4 p-3 h-100">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small">{{ $card['title'] }}</div>
                        <h4 class="fw-bold mb-0">{{ $card['value'] }}</h4>
                    </div>
                    <div class="icon-box" style="background: {{ $card['color'] }}">
                        <i class="mdi {{ $card['icon'] }}"></i>
                    </div>
                </div>
            </div>
        </div>

        @endforeach

    </div>

    <!-- 🔷 MAIN CONTENT -->
    <div class="row g-4">

        <!-- 📊 ATTENDANCE OVERVIEW -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h5 class="fw-bold mb-3">Attendance Overview</h5>
                <canvas id="attendanceChart" height="120"></canvas>
            </div>
        </div>

        <!-- 🎂 BIRTHDAYS -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h5 class="fw-bold mb-3">Today's Birthdays 🎂</h5>

                @forelse($birthdays as $emp)
                    <div class="d-flex align-items-center mb-3">
                        <img src="{{ $emp['profile_image'] }}" class="rounded-circle me-2" width="45" height="45">
                        <div>
                            <div class="fw-semibold">{{ $emp['name'] }}</div>
                            <small class="text-muted">{{ $emp['job_role'] }}</small>
                        </div>
                    </div>
                @empty
                    <div class="text-muted text-center">No birthdays today</div>
                @endforelse

            </div>
        </div>

        <!-- 🏢 COMPANY / ENTITY -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h5 class="fw-bold mb-3">Company Overview</h5>

                @foreach($companies as $company)
                    <div class="mb-3">
                        <div class="fw-semibold">{{ $company->company_name }}</div>
                        <div class="progress mt-1" style="height:6px;">
                            <div class="progress-bar" style="width: {{ $company->staff_percent }}%"></div>
                        </div>
                        <small class="text-muted">{{ $company->staff_count }} Staff</small>
                    </div>
                @endforeach

            </div>
        </div>

        <!-- 📥 RECENT CANDIDATES -->
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h5 class="fw-bold mb-3">Recent Candidates</h5>

                @foreach($recentCandidates as $c)
                    <div class="d-flex justify-content-between border-bottom py-2">
                        <div>
                            <div class="fw-semibold">{{ $c->candidate_name }}</div>
                            <small class="text-muted">{{ $c->candidate_email }}</small>
                        </div>
                        <span class="badge bg-primary">{{ $c->status }}</span>
                    </div>
                @endforeach

            </div>
        </div>

        <!-- ⚡ QUICK ACTIONS -->
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h5 class="fw-bold mb-3">Quick Actions</h5>

                <div class="row text-center">

                    <div class="col-md-2">
                        <a href="# class="quick-card">
                            <i class="mdi mdi-account"></i>
                            <span>Staff</span>
                        </a>
                    </div>

                    <div class="col-md-2">
                        <a href="#" class="quick-card">
                            <i class="mdi mdi-calendar-check"></i>
                            <span>Attendance</span>
                        </a>
                    </div>

                    <div class="col-md-2">
                        <a href="#" class="quick-card">
                            <i class="mdi mdi-account-search"></i>
                            <span>Recruitment</span>
                        </a>
                    </div>

                    <div class="col-md-2">
                        <a href="#" class="quick-card">
                            <i class="mdi mdi-school"></i>
                            <span>Training</span>
                        </a>
                    </div>

                    <div class="col-md-2">
                        <a href="#" class="quick-card">
                            <i class="mdi mdi-cash"></i>
                            <span>Payroll</span>
                        </a>
                    </div>

                </div>
            </div>
        </div>

    </div>

</div>
<style>
    .icon-box {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 22px;
}

.quick-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    border-radius: 12px;
    transition: 0.3s;
    background: #f8f9fc;
}

.quick-card:hover {
    background: #4e73df;
    color: #fff;
    transform: translateY(-5px);
}

.quick-card i {
    font-size: 26px;
    margin-bottom: 5px;
}
</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const ctx = document.getElementById('attendanceChart');

new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: ['Present', 'Absent', 'Late'],
        datasets: [{
            data: [{{ $present }}, {{ $absent }}, {{ $late }}],
        }]
    }
});
</script>


<div class="premium-header p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
        
        <div>
            <h4 class="fw-bold mb-1">👋 Welcome back, {{ auth()->user()->name }}</h4>
            <div class="text-muted">Here’s what’s happening in your organization today</div>
        </div>

        <div class="d-flex gap-3 mt-3 mt-md-0">
            <div class="mini-stat">
                <span>Total Staff</span>
                <strong>{{ $totalStaff }}</strong>
            </div>
            <div class="mini-stat">
                <span>Today Attendance</span>
                <strong>{{ $presentCount }}</strong>
            </div>
            <div class="mini-stat">
                <span>Open Hiring</span>
                <strong>{{ $candidateCount }}</strong>
            </div>
        </div>

    </div>
</div>

<div class="row g-4 mb-4">

@foreach([
    ['title'=>'Total Staff','value'=>$totalStaff,'icon'=>'mdi-account-group','color'=>'linear-gradient(135deg,#667eea,#764ba2)'],
    ['title'=>'Present Today','value'=>$presentCount,'icon'=>'mdi-check-circle','color'=>'linear-gradient(135deg,#1cc88a,#17a673)'],
    ['title'=>'Recruitment','value'=>$candidateCount,'icon'=>'mdi-account-search','color'=>'linear-gradient(135deg,#36b9cc,#258391)'],
    ['title'=>'Payroll','value'=>'₹'.$payrollTotal,'icon'=>'mdi-currency-inr','color'=>'linear-gradient(135deg,#f6c23e,#dda20a)']
] as $card)

<div class="col-md-3">
    <div class="premium-card">
        <div class="d-flex justify-content-between">
            <div>
                <div class="small text-light opacity-75">{{ $card['title'] }}</div>
                <h3 class="fw-bold text-white">{{ $card['value'] }}</h3>
            </div>
            <div class="premium-icon">
                <i class="mdi {{ $card['icon'] }}"></i>
            </div>
        </div>
        <div class="card-bg" style="background: {{ $card['color'] }}"></div>
    </div>
</div>

@endforeach
</div>

<div class="card premium-glass p-4 mb-4">
    <h5 class="fw-bold mb-3">📊 Smart Insights</h5>

    <ul class="insight-list">
        <li>🔥 {{ $late }} employees are late today</li>
        <li>📉 Attendance dropped {{ $attendanceDrop }}% from yesterday</li>
        <li>🎯 {{ $candidateCount }} candidates in pipeline</li>
        <li>🎂 {{ count($birthdays) }} birthdays this month</li>
    </ul>
</div>

<div class="card premium-glass p-4 mb-4">
    <h5 class="fw-bold mb-3">📊 Smart Insights</h5>

    <ul class="insight-list">
        <li>🔥 {{ $late }} employees are late today</li>
        <li>📉 Attendance dropped {{ $attendanceDrop }}% from yesterday</li>
        <li>🎯 {{ $candidateCount }} candidates in pipeline</li>
        <li>🎂 {{ count($birthdays) }} birthdays this month</li>
    </ul>
</div>
<div class="card premium-glass p-4 mb-4">
    <h5 class="fw-bold mb-3">🏢 Organization Structure</h5>

    @foreach($companies as $company)
        <div class="company-block mb-3">
            <div class="d-flex justify-content-between">
                <strong>{{ $company->company_name }}</strong>
                <span>{{ $company->staff_count }} Staff</span>
            </div>

            <div class="progress mt-2">
                <div class="progress-bar" style="width: {{ $company->staff_percent }}%"></div>
            </div>
        </div>
    @endforeach

</div>
<div class="card premium-glass p-4">
    <h5 class="fw-bold mb-3">🎂 Birthdays</h5>

    <div class="d-flex overflow-auto gap-3">

        @foreach($birthdays as $emp)
            <div class="birthday-premium text-center">
                <img src="{{ $emp['profile_image'] }}">
                <div class="fw-semibold mt-2">{{ $emp['name'] }}</div>
                <small>{{ $emp['date_of_birth'] }}</small>
            </div>
        @endforeach

    </div>
</div>
<style>
    .premium-header {
    background: linear-gradient(135deg,#667eea,#764ba2);
    color: #fff;
    border-radius: 16px;
}

.mini-stat {
    background: rgba(255,255,255,0.15);
    padding: 10px 15px;
    border-radius: 10px;
    text-align: center;
}

.premium-card {
    position: relative;
    overflow: hidden;
    border-radius: 18px;
    padding: 20px;
    color: #fff;
    height: 120px;
    transition: 0.3s;
}

.premium-card:hover {
    transform: translateY(-6px);
}

.card-bg {
    position: absolute;
    inset: 0;
    z-index: -1;
    opacity: 0.9;
}

.premium-icon {
    font-size: 28px;
    opacity: 0.8;
}

.premium-glass {
    background: rgba(255,255,255,0.7);
    backdrop-filter: blur(10px);
    border-radius: 16px;
}

.birthday-premium img {
    width: 60px;
    height: 60px;
    border-radius: 50%;
}

.insight-list li {
    margin-bottom: 8px;
}
</style>

<!-- ultra  -->
 <div class="ultra-header mb-4 p-4">

    <div class="d-flex justify-content-between flex-wrap">
        <div>
            <h3 class="fw-bold text-white">HR Command Center 🚀</h3>
            <p class="text-light opacity-75 mb-0">
                Monitor workforce, hiring & payroll in real-time
            </p>
        </div>

        <div class="live-badge">
            <span class="dot"></span> Live
        </div>
    </div>

    <div class="row mt-4 g-3">

        <div class="col-md-3">
            <div class="ultra-stat">
                <h2>{{ $totalStaff }}</h2>
                <span>Total Employees</span>
                <small class="trend up">+5% this month</small>
            </div>
        </div>

        <div class="col-md-3">
            <div class="ultra-stat">
                <h2>{{ $present }}</h2>
                <span>Present Today</span>
                <small class="trend up">+2% today</small>
            </div>
        </div>

        <div class="col-md-3">
            <div class="ultra-stat">
                <h2>{{ $candidateCount }}</h2>
                <span>Hiring Pipeline</span>
                <small class="trend down">-1% drop</small>
            </div>
        </div>

        <div class="col-md-3">
            <div class="ultra-stat">
                <h2>₹{{ $payrollTotal }}</h2>
                <span>Monthly Payroll</span>
                <small class="trend up">Stable</small>
            </div>
        </div>

    </div>

</div>
<div class="row g-4 mb-4">

    <!-- Attendance Trend -->
    <div class="col-md-8">
        <div class="ultra-card p-4">
            <h5 class="fw-bold mb-3">📈 Attendance Trend</h5>
            <canvas id="attendanceTrend"></canvas>
        </div>
    </div>

    <!-- Department Distribution -->
    <div class="col-md-4">
        <div class="ultra-card p-4">
            <h5 class="fw-bold mb-3">🏢 Department Split</h5>
            <canvas id="deptChart"></canvas>
        </div>
    </div>

</div>
<div class="ultra-card p-4 mb-4">
    <h5 class="fw-bold mb-3">🧠 AI Workforce Insights</h5>

    <div class="row g-3">

        <div class="col-md-4">
            <div class="insight-box danger">
                ⚠️ High absenteeism in Production Dept
            </div>
        </div>

        <div class="col-md-4">
            <div class="insight-box success">
                ✅ Sales team performance improved
            </div>
        </div>

        <div class="col-md-4">
            <div class="insight-box warning">
                📌 5 candidates pending review
            </div>
        </div>

    </div>
</div>

<div class="ultra-card p-4 mb-4">
    <h5 class="fw-bold mb-3">🏢 Organization Overview</h5>

    @foreach($companies as $company)
    <div class="org-row">
        <div class="d-flex justify-content-between">
            <strong>{{ $company->company_name }}</strong>
            <span>{{ $company->staff_count }} Staff</span>
        </div>

        <div class="progress mt-2">
            <div class="progress-bar" style="width: {{ $company->staff_percent }}%"></div>
        </div>
    </div>
    @endforeach

</div>

<div class="ultra-card p-4 mb-4">
    <h5 class="fw-bold mb-3">🎉 Events & Birthdays</h5>

    <div class="d-flex gap-3 overflow-auto">

        @foreach($birthdays as $emp)
        <div class="event-card text-center">
            <img src="{{ $emp['profile_image'] }}">
            <div>{{ $emp['name'] }}</div>
            <small>{{ $emp['date_of_birth'] }}</small>
        </div>
        @endforeach

    </div>
</div>

<div class="ultra-card p-4">
    <h5 class="fw-bold mb-3">⚡ Quick Actions</h5>

    <div class="quick-grid">

        <a href="#">👨‍💼 Staff</a>
        <a href="#">📅 Attendance</a>
        <a href="#">📥 Hiring</a>
        <a href="#">🎓 Training</a>
        <a href="#">💰 Payroll</a>

    </div>
</div>
<style>
    .ultra-header {
    background: linear-gradient(135deg,#1e3c72,#2a5298);
    border-radius: 20px;
    color: #fff;
}

.live-badge {
    background: rgba(255,255,255,0.2);
    padding: 6px 12px;
    border-radius: 20px;
}

.dot {
    width: 8px;
    height: 8px;
    background: #00ff9f;
    display: inline-block;
    border-radius: 50%;
    margin-right: 5px;
    animation: blink 1s infinite;
}

@keyframes blink {
    50% { opacity: 0.3; }
}

.ultra-stat {
    background: rgba(255,255,255,0.1);
    padding: 20px;
    border-radius: 14px;
    text-align: center;
}

.trend.up { color: #00ff9f; }
.trend.down { color: #ff6b6b; }

.ultra-card {
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
}

.insight-box {
    padding: 12px;
    border-radius: 10px;
}

.insight-box.danger { background: #ffe5e5; }
.insight-box.success { background: #e6fff5; }
.insight-box.warning { background: #fff4e5; }

.event-card img {
    width: 60px;
    height: 60px;
    border-radius: 50%;
}

.quick-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(120px,1fr));
    gap: 15px;
}

.quick-grid a {
    background: #f5f7fa;
    padding: 15px;
    border-radius: 12px;
    text-align: center;
    transition: 0.3s;
}

.quick-grid a:hover {
    background: #1e3c72;
    color: #fff;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
new Chart(document.getElementById('attendanceTrend'), {
    type: 'line',
    data: {
        labels: {!! json_encode($days) !!},
        datasets: [{
            label: 'Attendance',
            data: {!! json_encode($attendanceData) !!}
        }]
    }
});

new Chart(document.getElementById('deptChart'), {
    type: 'doughnut',
    data: {
        labels: {!! json_encode($deptLabels) !!},
        datasets: [{
            data: {!! json_encode($deptCounts) !!}
        }]
    }
});
</script>
@endsection