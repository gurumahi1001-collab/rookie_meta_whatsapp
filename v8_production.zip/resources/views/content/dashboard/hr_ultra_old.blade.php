@extends('layouts/layoutMaster')

@section('title', 'Dashboard')

@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/apex-charts/apex-charts.scss',
  'resources/assets/vendor/libs/swiper/swiper.scss',
  'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('page-style')
<!-- Page -->
@vite([
  'resources/assets/vendor/scss/pages/cards-statistics.scss',
  'resources/assets/vendor/scss/pages/cards-analytics.scss'
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/apex-charts/apexcharts.js',
  'resources/assets/vendor/libs/swiper/swiper.js'
])
@endsection

@section('page-script')
@vite('resources/assets/js/dashboards-crm.js')
@endsection
@section('content')
 @php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
    $userData =$helper->get_staff_data($user_id);
    $lastLogin =$helper->get_user_last_login($auth_id);
    $welcome_status = $userData->welcome_status ?? '1';
  @endphp

    <div class="container-fluid py-4" >

    <div class="loading-custom" id="loadingScreenCustomize"  style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999; display:none;">
        <div class="loading-content" style="text-align: center; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);">
            <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; margin-bottom: 20px;height:100%">
            <div class="d-block">
            <div class="dot-custom red"></div>
            <div class="dot-custom orange"></div>
            <div class="dot-custom yellow"></div>
            <div class="dot-custom green"></div>
            <div class="dot-custom teal"></div>
            <div class="dot-custom blue"></div>
            <div class="dot-custom violet"></div>
            </div>
        </div>
    </div>

        <!-- TOP GREETING -->
        <div class="grid">
            <!-- User Profile Card -->
            <div class="card profile-card animate-fade-in position-relative overflow-hidden"
                style="background: linear-gradient(135deg, rgb(171 43 34),rgb(171 43 34), rgb(251 169 25)); color: white;">

                <!-- BACKGROUND IMAGE (Right Side Decoration) -->
                <img src="/assets/common/egc-CRM-login-png.png"
                    class="profile-bg-img"
                    alt="Decorative BG">

                <div class="d-flex position-relative justify-content-start w-100">
                    <!-- LEFT SIDE — 70% -->
                    <div class="flex-grow-1" >
                        <div class="profile-image-container mb-2">
                            <div class="profile-image-wrapper">
                                <div class="profile-border"></div>

                                @if(Auth::user()->staff->company_type==1)
                                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Management/' . Auth::user()->staff->staff_image))
                                                    ? asset('staff_images/Management/' . Auth::user()->staff->staff_image)
                                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle profile-img" />
                                @else
                                <img  src="{{ Auth::user() && Auth::user()->staff && Auth::user()->staff->staff_image && file_exists(public_path('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image))
                                                    ? asset('staff_images/Buisness/'.Auth::user()->staff->company_id.'/'.Auth::user()->staff->entity_id.'/' . Auth::user()->staff->staff_image)
                                                    : asset('assets/egc_images/auth/user_1.png') }}" alt="Profile" class="rounded-circle profile-img" />
                                @endif
                            </div>
                        </div>

                        <div class="profile-info">
                            <h2 class="text-white">
                                Welcome,
                                @if(Auth::check())
                                    {{ Auth::user()->staff ? Auth::user()->staff->staff_name : 'Super Admin' }}
                                @else
                                    John Doe
                                @endif
                                !
                            </h2>
                            @php
                                $loginAt = \Carbon\Carbon::parse($lastLogin->login_at);

                                if($loginAt->isToday()) {
                                    $lastlogindate = 'Today, ' . $loginAt->format('h:i A');
                                } elseif($loginAt->isYesterday()) {
                                    $lastlogindate = 'Yesterday, ' . $loginAt->format('h:i A');
                                } else {
                                    $lastlogindate = $loginAt ? $loginAt->format('d-M-Y') : '-';
                                }
                            @endphp

                            <p>{{$userData->job_role_name ?? ''}} | Last login: {{$lastlogindate}}</p>

                            <!-- <div class="profile-stats d-flex">
                                <div class="stat me-4">
                                    <div class="stat-value">24</div>
                                    <div class="stat-label">Projects</div>
                                </div>
                                <div class="stat me-4">
                                    <div class="stat-value">89%</div>
                                    <div class="stat-label">Efficiency</div>
                                </div>
                                <div class="stat">
                                    <div class="stat-value">126</div>
                                    <div class="stat-label">Tasks Done</div>
                                </div>
                            </div> -->
                        </div>
                    </div>

                    <!-- RIGHT SIDE CONTENT (optional) -->
                </div>
            </div>



            <!-- Date + Quote Card -->
            <div class="card date-card animate-fade-in delay-1" style="background: linear-gradient(135deg, rgb(171 43 34),rgb(171 43 34), rgb(251 169 25)); color: white;">
                <div class="date-info">
                    <h3 class="text-white"><i class="far fa-calendar-alt text-white"></i> Today</h3>
                    <div class="current-date" id="today-date">19 Nov 2025</div>
                    <div class="weather" id="weather">
                        <i class="fas fa-cloud-sun"></i>
                        <span>Loading weather...</span>
                    </div>
                </div>
                <div class="quote-container">
                    <div class="quote" id="positive-quote">"Stay motivated and positive!"</div>
                    <div class="author" id="quote-author"></div>
                </div>
            </div>
        </div>

        <div class="card ultra-filter mb-4 p-3">
            <div class="row">

                <div class="col-md-3">
                    <select class="form-select select3" id="companyFilter">
                        <option value="">All Companies</option>
                        @foreach($companies ?? [] as $c)
                        <option>{{ $c->company_name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <select class="form-select select3" id="entityFilter">
                        <option value="">All Entities</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <select class="form-select select3" id="departmentFilter">
                        <option value="">All Departments</option>
                    </select>
                </div>

                <div class="col-md-3 text-end">
                    <span class="live-dot"></span> Live Data
                </div>

            </div>
        </div>
        <div class="row g-4 mb-4">
            <div class="col-md-2">
                <div class="kpi-live">
                    <h6>Total Staff</h6>
                    <h2 id="totalStaff">00</h2>
                </div>
            </div>

            <div class="col-md-2">
                <div class="kpi-live green">
                    <h6>Present</h6>
                    <h2 id="present">00</h2>
                </div>
            </div>

            <div class="col-md-2">
                <div class="kpi-live orange">
                    <h6>Late</h6>
                    <h2 id="late">00</h2>
                </div>
            </div>

            <div class="col-md-2">
                <div class="kpi-live red">
                    <h6>Absent</h6>
                    <h2 id="absent">00</h2>
                </div>
            </div>

            <div class="col-md-2">
                <div class="kpi-live blue">
                    <h6>Candidates</h6>
                    <h2 id="candidates">00</h2>
                </div>
            </div>

            <div class="col-md-2">
                <div class="kpi-live purple">
                    <h6>Trainings</h6>
                    <h2 id="trainings">00</h2>
                </div>
            </div>

        </div>

        <div class="row mb-4">

            <div class="col-lg-6">
                <div class="card ultra-card p-4">
                    <h5>🚨 Alerts</h5>

                    @foreach($alerts ?? [] as $a)
                    <div class="alert-item">
                        <strong>{{ $a['title'] }}</strong>
                        <small>{{ $a['time'] }}</small>
                    </div>
                    @endforeach
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card ultra-card p-4">
                    <h5>📡 Live Activity</h5>

                    @foreach($activities ?? [] as $act)
                    <div class="activity-item">
                        {{ $act }}
                    </div>
                    @endforeach
                </div>
            </div>

        </div>

        <div class="row mb-4">

            <div class="col-lg-8">
                <div class="card ultra-card p-4">
                    <h5>Attendance Analytics</h5>
                    <canvas id="attendanceChart"></canvas>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card ultra-card p-4">
                    <h5>Live Status</h5>

                    <p>🟢 In Office: <span id="today_present">00</span></p>
                    <p>🔴 Absent: <span id="today_absent">00</span></p>
                    <p>🟡 Late: <span id="today_late">00</span></p>
                    <p>🔵 Permission: <span id="today_permission">00</span></p>
                </div>
            </div>

        </div>

        <div class="card ultra-card p-4 mb-4">
            <h5>Recruitment Pipeline</h5>

            <div class="pipeline">
                <div>Applied <span id="applied">00</span></div>
                <div>Screening <span id="screening">00</span></div>
                <div>Interview <span id="interview">00</span></div>
                <div>Hired <span id="hired">00</span></div>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-6">
                <div class="card ultra-card p-4">
                    <h5>Training Progress</h5>
                    <p>Completed: <span id="trainingCompleted">00</span></p>
                    <p>Ongoing: <span id="trainingOngoing">00</span></p>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card ultra-card p-4">
                    <h5>Payroll</h5>
                    <p>Total: <span id="payroll">₹ 0</span></p>
                    <p>Pending: <span id="pending">₹ 0</span></p>
                    <p>Processed: <span id="processed">₹ 0</span></p>
                </div>
            </div>
            
            
        </div>
        <div class="card ultra-card p-4 mb-4">
            <h5>🧠 AI Insights</h5>
            <div id="aiInsights"></div>
        </div>
    </div>

<style>
    .grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 24px;
          margin-bottom: 24px;
      }
      
      /* Card Styles */
      .card {
          background: var(--card-bg);
          backdrop-filter: blur(10px);
          border-radius: 20px;
          padding: 24px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
          border: 1px solid var(--card-border);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          position: relative;
          overflow: hidden;
      }

      .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
      }

     


      /* Profile Card */
      .profile-card {
          grid-column: span 2;
          display: flex;
          align-items: center;
          background: linear-gradient(135deg, var(--primary), var(--primary-dark));
          padding: 30px;
          position: relative;
          overflow: hidden;
      }

      .profile-card::before {
          content: '';
          position: absolute;
          top: -50%;
          left: -50%;
          width: 200%;
          height: 200%;
          background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
          animation: pulse 8s infinite linear;
      }

      .profile-image-container {
          position: relative;
          margin-right: 24px;
          z-index: 2;
      }

      .profile-img {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          object-fit: cover;
          border: 4px solid rgba(255, 255, 255, 0.3);
          box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.1);
          position: relative;
          z-index: 2;
      }
      .profile-image-wrapper {
          position: relative;
          width: 120px;
          height: 120px;
          flex-shrink: 0; /* prevent distortion */
      }
      .profile-bg-img {
          position: absolute;
          right: -16px;
          bottom: 0;
          width: 734px;
          opacity: 0.65;            /* faded background */
          pointer-events: none;     /* prevent any clicking issues */
      }
      .profile-image-container {
        margin-left: -18px; /* adjust */
      }



      .profile-border {
          position: absolute;
          top: -1px;
          left: -1px;
          right: -1px;
          bottom: -1px;
          border-radius: 50%;
          background: conic-gradient(from 0deg, #ff0080, #ff8c00, #40e0d0, #ff0080);
          animation: rotate 3s linear infinite;
          z-index: 1;
      }

      .profile-border::after {
          content: '';
          position: absolute;
          inset: 6px;
          background: linear-gradient(135deg, var(--primary), var(--primary-dark));
          border-radius: 50%;
          z-index: 1;
      }

      .profile-info {
          z-index: 2;
          position: relative;
      }

      .profile-info h2 {
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 8px;
      }

      .profile-info p {
          font-size: 16px;
          opacity: 0.9;
          margin-bottom: 16px;
      }

      .profile-stats {
          display: flex;
          gap: 20px;
      }

      .stat {
          text-align: center;
      }

      .stat-value {
          font-size: 20px;
          font-weight: 700;
          padding: 6px 14px;
          border: 2px solid rgba(255, 255, 255, 0.4);
          border-radius: 12px;
          display: inline-block;
          backdrop-filter: blur(4px);
      }


      .stat-label {
          font-size: 14px;
          opacity: 0.8;
      }

      /* Date Card */
      .date-card {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          background: linear-gradient(135deg, var(--secondary), #059669);
      }

      .date-info h3 {
          font-size: 18px;
          margin-bottom: 8px;
          display: flex;
          align-items: center;
          gap: 8px;
      }

      .date-info h3 i {
          font-size: 20px;
      }

      .current-date {
          font-size: 32px;
          font-weight: 700;
          margin: 16px 0;
      }

      .quote-container {
          margin-top: 16px;
      }

      .quote {
          font-style: italic;
          margin-bottom: 12px;
          line-height: 1.5;
      }

      .weather {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
      }

      /* Stats Cards */
      .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-bottom: 24px;
      }

      .stat-card {
          text-align: center;
          padding: 20px;
      }

      .stat-icon {
          font-size: 32px;
          margin-bottom: 12px;
          height: 70px;
          width: 70px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          margin: 0 auto 16px;
          background: rgba(255, 255, 255, 0.1);
      }

      .stat-card .value {
          font-size: 32px;
          font-weight: 700;
          margin-bottom: 8px;
      }

      .stat-card .label {
          font-size: 14px;
          opacity: 0.8;
      }




      /* Animations */
      @keyframes rotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
      }

      @keyframes pulse {
          0% { transform: translate(-30%, -30%) scale(0.8); opacity: 0.8; }
          50% { transform: translate(-20%, -20%) scale(1); opacity: 0.4; }
          100% { transform: translate(-30%, -30%) scale(0.8); opacity: 0.8; }
      }

      @keyframes fadeInUp {
          from {
              opacity: 0;
              transform: translateY(40px);
          }
          to {
              opacity: 1;
              transform: translateY(0);
          }
      }

      .animate-fade-in {
          animation: fadeInUp 0.8s ease forwards;
      }

      .delay-1 { animation-delay: 0.2s; opacity: 0; }
      .delay-2 { animation-delay: 0.4s; opacity: 0; }
      .delay-3 { animation-delay: 0.6s; opacity: 0; }

      /* Responsive */
      @media (max-width: 900px) {
          .profile-card {
              grid-column: span 1;
              flex-direction: column;
              text-align: center;
          }

          .profile-image-container {
              margin-right: 0;
              margin-bottom: 20px;
          }

          .profile-stats {
              justify-content: center;
          }

          .content-card {
              grid-column: span 1;
          }
      }

      @media (max-width: 600px) {
          .grid {
              grid-template-columns: 1fr;
          }

          .profile-stats {
              flex-direction: column;
              gap: 10px;
          }

          .stats-grid {
              grid-template-columns: 1fr;
          }
      }

      
.ultra-filter {
    background: rgba(255,255,255,0.9);
    border-radius: 15px;
    backdrop-filter: blur(10px);
}

.live-dot {
    width: 10px;
    height: 10px;
    background: #28a745;
    border-radius: 50%;
    display: inline-block;
    animation: pulse 1s infinite;
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.3; }
    100% { opacity: 1; }
}

.kpi-live {
    background: linear-gradient(135deg, #ab2b22, #fba919);
    color: #fff;
    padding: 15px;
    border-radius: 15px;
}

.kpi-live.green { background: linear-gradient(135deg,#28a745,#5ddf85); }
.kpi-live.orange { background: linear-gradient(135deg,#ff9800,#ffc107); }
.kpi-live.red { background: linear-gradient(135deg,#dc3545,#ff6b6b); }
.kpi-live.blue { background: linear-gradient(135deg,#007bff,#5bc0de); }
.kpi-live.purple { background: linear-gradient(135deg,#6f42c1,#b197fc); }

.alert-item, .activity-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
}

.pipeline {
    display: flex;
    justify-content: space-between;
}
.pipeline div {
    background: #fff;
    padding: 10px;
    border-radius: 10px;
}
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
function loadDashboard() {

    let company = $('#companyFilter').val();
    let entity = $('#entityFilter').val();
    let department = $('#departmentFilter').val();
    const loader = document.getElementById('loadingScreenCustomize');
    
    $.ajax({
        url: "{{ route('hr.dashboard.data') }}",
        type: "GET",
        data: {
            company_id: company,
            entity_id: entity,
            department_id: department
        },
        beforeSend: function() {
           loader.style.display = 'flex';
        },
        success: function(res) {

            if(res.status) {

                let d = res.data;

                // 🔥 KPI UPDATE
                $('#totalStaff').text(d.totalStaff);
                $('#present').text(d.present);
                $('#late').text(d.late);
                $('#leave').text(d.leave);
                $('#permission').text(d.permission);
                $('#absent').text(d.absent);

                // 📊 RECRUITMENT
                $('#candidates').text(d.candidates);
                $('#shortlisted').text(d.shortlisted);
                $('#hired').text(d.hired);

                // 🎓 TRAINING
                $('#trainings').text(d.trainings);
                $('#ongoingTraining').text(d.ongoingTraining);

                // 💰 PAYROLL
                $('#payroll').text('₹ ' + d.payroll);

                 updateCharts(d);
                generateAIInsights(d);

             

               
            }
        },
        complete: function() {
          loader.style.display = 'none';
        }
    });
}

// 🔄 AUTO LOAD
loadDashboard();
$('#companyFilter, #entityFilter, #departmentFilter').on('change', loadDashboard);

function generateAIInsights(d) {

    let insights = '';

    if(d.absent > (d.totalStaff * 0.2)) {
        insights += `<p>⚠️ High absenteeism detected today (${d.absent})</p>`;
    }

    if(d.late > 10) {
        insights += `<p>⏰ Many employees are late today (${d.late})</p>`;
    }

    if(d.hired > d.shortlisted) {
        insights += `<p>🚀 Hiring efficiency improved this week</p>`;
    }

    if(d.payroll > 1000000) {
        insights += `<p>💰 Payroll cost is high this month</p>`;
    }

    if(insights === '') {
        insights = `<p>✅ Everything looks normal today</p>`;
    }

    $('#aiInsights').html(insights);
}

// 🔄 AUTO REFRESH EVERY 30 SEC (REAL-TIME FEEL)
// setInterval(loadDashboard, 30000);
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
let attendanceChart;

function updateCharts(d) {

    let chartData = [
        d.present,
        d.absent,
        d.late,
        d.permission
    ];

    if(attendanceChart) {
        attendanceChart.destroy();
    }

    attendanceChart = new Chart(document.getElementById('attendanceChart'), {
        type: 'bar',
        data: {
            labels: ['Present','Absent','Late','Permission'],
            datasets: [{
                label: 'Today Status',
                data: chartData,
                borderWidth: 1
            }]
        }
    });
}
</script>
@endsection