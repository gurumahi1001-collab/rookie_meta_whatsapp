@extends('layouts/blankLayout')

@section('title', 'Elysium One')

@section('content')
@php
    $user_id = auth()->user()->user_id ?? 0;
@endphp

<!--
|--------------------------------------------------------------------------
| Elysium One Mobile Launch Experience
|--------------------------------------------------------------------------
| Production asset folder:
| public/assets/elysiumone/
|
| logo-dark.png
| logo-mark.png
| elysium-groups.png
| mobile-splash.png
| mobile-dashboard.png
| mobile-attendance.png
|--------------------------------------------------------------------------
-->

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">
<meta name="csrf-token" content="{{ csrf_token() }}">

<style>
    :root {
        --eo-navy: #1f2335;
        --eo-navy-2: #171a29;
        --eo-blue: #30489f;
        --eo-blue-2: #3c55b6;
        --eo-orange: #f7a009;
        --eo-red: #b32d2a;
        --eo-green: #159b72;
        --eo-white: #ffffff;
        --eo-muted: #687086;
        --eo-bg: #f6f7fb;
        --eo-card: rgba(255,255,255,.92);
        --eo-border: rgba(31,35,53,.09);
        --eo-shadow: 0 22px 70px rgba(20,25,45,.12);
    }

    #elysium-one-launch,
    #elysium-one-launch * {
        box-sizing: border-box;
    }

    #elysium-one-launch {
        min-height: 100vh;
        margin: 0;
        background: var(--eo-bg);
        color: var(--eo-navy);
        font-family: 'Inter', sans-serif;
        overflow-x: hidden;
    }

    body.eo-launch-locked {
        overflow: hidden !important;
    }

    .eo-page {
        min-height: 100vh;
        position: relative;
        overflow: hidden;
    }

    /* =========================================================
       FIRST SCREEN — LAUNCH PAGE
       ========================================================= */
    .eo-hero {
        min-height: 100vh;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 48px 22px;
        overflow: hidden;
        background:
            radial-gradient(circle at 15% 15%, rgba(247,160,9,.15), transparent 30%),
            radial-gradient(circle at 90% 80%, rgba(48,72,159,.18), transparent 34%),
            linear-gradient(135deg, #f9fafc 0%, #ffffff 48%, #f4f5fa 100%);
    }

    .eo-hero::before,
    .eo-hero::after {
        content: "";
        position: absolute;
        border-radius: 50%;
        filter: blur(2px);
        pointer-events: none;
    }

    .eo-hero::before {
        width: 420px;
        height: 420px;
        right: -170px;
        top: -170px;
        border: 1px solid rgba(247,160,9,.20);
        box-shadow: 0 0 0 70px rgba(247,160,9,.035), 0 0 0 140px rgba(247,160,9,.02);
    }

    .eo-hero::after {
        width: 360px;
        height: 360px;
        left: -180px;
        bottom: -180px;
        border: 1px solid rgba(48,72,159,.16);
        box-shadow: 0 0 0 65px rgba(48,72,159,.035), 0 0 0 130px rgba(48,72,159,.02);
    }

    .eo-hero-inner {
        width: min(1160px, 100%);
        display: grid;
        grid-template-columns: minmax(0, 1.05fr) minmax(360px, .95fr);
        align-items: center;
        gap: 70px;
        position: relative;
        z-index: 2;
    }

    .eo-brand-row {
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 28px;
    }

    .eo-brand-row img {
        width: 58px;
        height: 58px;
        object-fit: contain;
    }

    .eo-brand-row span {
        font-size: 13px;
        font-weight: 800;
        letter-spacing: .18em;
        text-transform: uppercase;
        color: var(--eo-muted);
    }

    .eo-hero h1 {
        margin: 0;
        font-size: clamp(48px, 7vw, 88px);
        line-height: .92;
        letter-spacing: -.065em;
        font-weight: 900;
        color: var(--eo-navy);
    }

    .eo-hero h1 span {
        display: block;
        background: linear-gradient(110deg, var(--eo-blue), var(--eo-navy));
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
    }

    .eo-hero-copy {
        max-width: 620px;
        margin: 26px 0 0;
        color: #5c6478;
        font-size: 18px;
        line-height: 1.75;
    }

    .eo-hero-copy strong {
        color: var(--eo-navy);
    }

    .eo-launch-btn {
        margin-top: 34px;
        border: 0;
        cursor: pointer;
        color: #fff;
        background: linear-gradient(135deg, var(--eo-blue), #253b8c);
        border-radius: 18px;
        min-height: 62px;
        padding: 0 28px;
        display: inline-flex;
        align-items: center;
        gap: 13px;
        font-size: 16px;
        font-weight: 800;
        letter-spacing: -.01em;
        box-shadow: 0 16px 36px rgba(48,72,159,.28);
        transition: transform .25s ease, box-shadow .25s ease;
    }

    .eo-launch-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 20px 44px rgba(48,72,159,.34);
    }

    .eo-launch-btn:active {
        transform: translateY(0);
    }

    .eo-launch-btn .mdi {
        font-size: 23px;
    }

    .eo-launch-meta {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-top: 20px;
        color: #8a91a3;
        font-size: 12px;
        font-weight: 600;
    }

    .eo-launch-meta span {
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .eo-launch-meta .mdi {
        color: var(--eo-green);
        font-size: 16px;
    }

    /* Phone artwork */
    .eo-phone-stage {
        position: relative;
        min-height: 620px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .eo-phone-glow {
        position: absolute;
        width: 390px;
        height: 390px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(48,72,159,.18), rgba(247,160,9,.07) 45%, transparent 70%);
        filter: blur(10px);
    }

    .eo-phone {
        position: relative;
        width: min(330px, 72vw);
        aspect-ratio: 383 / 800;
        border-radius: 42px;
        padding: 8px;
        background: #10121c;
        box-shadow: 0 38px 90px rgba(23,26,41,.32);
        transform: rotate(3deg);
        z-index: 2;
    }

    .eo-phone::before {
        content: "";
        position: absolute;
        top: 13px;
        left: 50%;
        width: 92px;
        height: 22px;
        transform: translateX(-50%);
        border-radius: 0 0 15px 15px;
        background: #0c0e16;
        z-index: 4;
    }

    .eo-phone img {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
        border-radius: 35px;
    }

    .eo-phone-badge {
        position: absolute;
        z-index: 5;
        right: -44px;
        bottom: 90px;
        width: 165px;
        padding: 17px 18px;
        border-radius: 18px;
        background: rgba(255,255,255,.94);
        border: 1px solid rgba(31,35,53,.08);
        box-shadow: 0 18px 45px rgba(20,25,45,.14);
        transform: rotate(-3deg);
    }

    .eo-phone-badge small {
        display: block;
        color: #8b92a3;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .12em;
    }

    .eo-phone-badge strong {
        display: block;
        margin-top: 4px;
        font-size: 17px;
        color: var(--eo-navy);
    }

    .eo-phone-badge .mdi {
        color: var(--eo-orange);
        font-size: 20px;
        float: right;
        margin-top: -22px;
    }

    /* =========================================================
       LAUNCH OVERLAY / WELCOME
       ========================================================= */
    .eo-launch-overlay {
        position: fixed;
        inset: 0;
        z-index: 100000;
        display: none;
        align-items: center;
        justify-content: center;
        background: #171a29;
        overflow: hidden;
    }

    .eo-launch-overlay.is-active {
        display: flex;
    }

    .eo-panel {
        position: absolute;
        top: 0;
        width: 50%;
        height: 100%;
        background: #fff;
        z-index: 2;
        transition: transform 1.35s cubic-bezier(.77,0,.18,1);
    }

    .eo-panel.left {
        left: 0;
        transform: translateX(-100%);
    }

    .eo-panel.right {
        right: 0;
        transform: translateX(100%);
    }

    .eo-launch-overlay.panels-open .eo-panel.left {
        transform: translateX(0);
    }

    .eo-launch-overlay.panels-open .eo-panel.right {
        transform: translateX(0);
    }

    .eo-welcome {
        position: relative;
        z-index: 4;
        width: min(620px, calc(100% - 34px));
        padding: 42px 34px 36px;
        text-align: center;
        color: var(--eo-navy);
        background: rgba(255,255,255,.98);
        border: 1px solid rgba(255,255,255,.82);
        border-radius: 34px;
        box-shadow: 0 35px 110px rgba(0,0,0,.34), 0 0 0 1px rgba(48,72,159,.06);
        opacity: 0;
        transform: translateY(18px) scale(.96);
    }

    .eo-launch-overlay.welcome-visible .eo-welcome {
        animation: eoWelcomeIn .9s cubic-bezier(.2,.8,.2,1) forwards;
    }

    .eo-welcome::before {
        content: "";
        position: absolute;
        inset: 8px;
        border-radius: 27px;
        border: 1px solid rgba(48,72,159,.08);
        pointer-events: none;
    }

    .eo-welcome-logo {
        display: block;
        width: min(320px, 70vw);
        max-height: 180px;
        object-fit: contain;
        margin: 0 auto 20px;
        filter: drop-shadow(0 14px 24px rgba(31,35,53,.14));
    }

    .eo-welcome-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 13px;
        border-radius: 999px;
        background: #f3f5ff;
        border: 1px solid rgba(48,72,159,.10);
        color: var(--eo-blue);
        font-size: 10px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: .14em;
    }

    .eo-welcome h2 {
        margin: 17px 0 9px;
        font-size: clamp(30px, 5vw, 48px);
        line-height: 1;
        letter-spacing: -.055em;
        font-weight: 900;
    }

    .eo-welcome p {
        margin: 0 auto;
        max-width: 500px;
        color: #697186;
        font-size: 14px;
        line-height: 1.65;
    }

    .eo-countdown-wrap {
        margin: 24px auto 0;
        width: 94px;
        height: 94px;
        position: relative;
        display: grid;
        place-items: center;
    }

    .eo-countdown-ring {
        position: absolute;
        inset: 0;
        border-radius: 50%;
        background: conic-gradient(var(--eo-orange) var(--eo-countdown-progress, 0%), #e9ecf5 0);
        padding: 6px;
        box-shadow: 0 10px 28px rgba(48,72,159,.12);
    }

    .eo-countdown-ring::after {
        content: "";
        display: block;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: #fff;
    }

    .eo-countdown-number {
        position: relative;
        z-index: 2;
        font-size: 35px;
        line-height: 1;
        font-weight: 900;
        letter-spacing: -.06em;
        color: var(--eo-navy);
    }

    .eo-countdown-label {
        margin-top: 9px;
        color: #8a91a3;
        font-size: 9px;
        font-weight: 900;
        letter-spacing: .14em;
        text-transform: uppercase;
    }

    .eo-welcome-progress {
        width: min(300px, 78vw);
        height: 5px;
        margin: 16px auto 0;
        border-radius: 99px;
        background: #e9ecf5;
        overflow: hidden;
    }

    .eo-welcome-progress span {
        display: block;
        width: 0;
        height: 100%;
        border-radius: inherit;
        background: linear-gradient(90deg, var(--eo-orange), var(--eo-blue-2));
    }

    .eo-launch-overlay.welcome-visible .eo-welcome-progress span {
        animation: eoProgress 5s linear forwards;
    }

    /* Fireworks are intentionally attached to Screen 3 only. */
    #eoFireworksStage {
        position: fixed;
        inset: 0;
        width: 100vw;
        height: 100vh;
        z-index: 20;
        pointer-events: none;
        opacity: 0;
        visibility: hidden;
        transition: opacity .45s ease, visibility .45s ease;
    }

    .eo-showcase.is-celebrating #eoFireworksStage {
        opacity: 1;
        visibility: visible;
    }

    .eo-showcase-celebration {
        position: relative;
        z-index: 5;
        width: fit-content;
        max-width: 100%;
        margin: 0 auto 25px;
        padding: 10px 16px;
        border-radius: 999px;
        background: rgba(255,255,255,.88);
        border: 1px solid rgba(48,72,159,.10);
        box-shadow: 0 12px 35px rgba(31,35,53,.08);
        color: var(--eo-blue);
        font-size: 10px;
        font-weight: 900;
        letter-spacing: .14em;
        text-transform: uppercase;
        backdrop-filter: blur(12px);
    }

    .eo-skip {
        position: absolute;
        z-index: 10;
        right: 24px;
        top: 22px;
        border: 1px solid rgba(255,255,255,.18);
        background: rgba(0,0,0,.18);
        color: rgba(255,255,255,.78);
        border-radius: 999px;
        padding: 9px 14px;
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
        backdrop-filter: blur(12px);
    }

    /* =========================================================
       PRODUCT SHOWCASE
       ========================================================= */
    .eo-showcase {
        min-height: 100vh;
        display: none;
        position: relative;
        padding: 60px 22px 80px;
        background:
            radial-gradient(circle at 85% 12%, rgba(247,160,9,.11), transparent 26%),
            linear-gradient(180deg, #fff 0%, #f7f8fc 100%);
    }

    .eo-showcase.is-visible {
        display: block;
        animation: eoPageIn .9s ease forwards;
    }

    .eo-showcase-inner {
        width: min(1180px, 100%);
        margin: 0 auto;
    }

    .eo-showcase-head {
        text-align: center;
        max-width: 750px;
        margin: 0 auto 44px;
    }

    .eo-showcase-kicker {
        color: var(--eo-blue);
        font-size: 11px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: .18em;
    }

    .eo-showcase h2 {
        margin: 11px 0 13px;
        font-size: clamp(34px, 5vw, 54px);
        letter-spacing: -.055em;
        line-height: 1.02;
        font-weight: 900;
    }

    .eo-showcase-head p {
        margin: 0;
        color: #697186;
        line-height: 1.7;
    }

    .eo-feature-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 22px;
    }

    .eo-feature {
        background: rgba(255,255,255,.9);
        border: 1px solid var(--eo-border);
        border-radius: 28px;
        padding: 20px;
        box-shadow: 0 20px 55px rgba(31,35,53,.08);
        overflow: hidden;
        opacity: 0;
        transform: translateY(30px);
    }

    .eo-feature.is-in {
        animation: eoFeatureIn .75s cubic-bezier(.2,.8,.2,1) forwards;
    }

    .eo-feature:nth-child(2).is-in { animation-delay: .12s; }
    .eo-feature:nth-child(3).is-in { animation-delay: .24s; }

    .eo-feature-image {
        height: 470px;
        border-radius: 21px;
        overflow: hidden;
        background: #eef0f7;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .eo-feature-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: top center;
    }

    .eo-feature-body {
        padding: 20px 4px 4px;
    }

    .eo-feature-number {
        width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 11px;
        background: #eef1ff;
        color: var(--eo-blue);
        font-size: 12px;
        font-weight: 900;
        margin-bottom: 12px;
    }

    .eo-feature h3 {
        margin: 0 0 7px;
        font-size: 19px;
        letter-spacing: -.025em;
    }

    .eo-feature p {
        margin: 0;
        color: #72798b;
        font-size: 13px;
        line-height: 1.65;
    }

    .eo-capability-strip {
        margin-top: 30px;
        padding: 24px;
        border-radius: 24px;
        background: var(--eo-navy);
        color: #fff;
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 10px;
        box-shadow: 0 25px 65px rgba(31,35,53,.18);
    }

    .eo-capability {
        text-align: center;
        padding: 8px 6px;
    }

    .eo-capability .mdi {
        display: block;
        font-size: 25px;
        color: var(--eo-orange);
        margin-bottom: 7px;
    }

    .eo-capability strong {
        display: block;
        font-size: 12px;
    }

    .eo-capability small {
        display: block;
        margin-top: 4px;
        color: rgba(255,255,255,.55);
        font-size: 10px;
    }

    /* =========================================================
       ANIMATIONS / RESPONSIVE
       ========================================================= */
    @keyframes eoWelcomeIn {
        from { opacity: 0; transform: translateY(18px) scale(.97); }
        to { opacity: 1; transform: translateY(0) scale(1); }
    }

    @keyframes eoProgress {
        from { width: 0; }
        to { width: 100%; }
    }

    @keyframes eoPageIn {
        from { opacity: 0; transform: translateY(14px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes eoFeatureIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 980px) {
        .eo-hero-inner {
            grid-template-columns: 1fr;
            gap: 20px;
            text-align: center;
        }

        .eo-brand-row,
        .eo-launch-meta {
            justify-content: center;
        }

        .eo-hero-copy {
            margin-left: auto;
            margin-right: auto;
        }

        .eo-phone-stage {
            min-height: 490px;
        }

        .eo-phone {
            width: 270px;
        }

        .eo-phone-badge {
            right: 8%;
        }

        .eo-feature-grid {
            grid-template-columns: 1fr;
            max-width: 540px;
            margin: 0 auto;
        }

        .eo-feature-image {
            height: auto;
            aspect-ratio: 383 / 800;
        }

        .eo-capability-strip {
            grid-template-columns: repeat(3, 1fr);
        }

        .eo-dashboard {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 650px) {
        .eo-hero {
            padding: 34px 18px 50px;
        }

        .eo-hero h1 {
            font-size: clamp(45px, 15vw, 70px);
        }

        .eo-hero-copy {
            font-size: 15px;
        }

        .eo-phone-stage {
            min-height: 400px;
        }

        .eo-phone {
            width: 215px;
            border-radius: 30px;
        }

        .eo-phone img {
            border-radius: 25px;
        }

        .eo-phone-badge {
            right: 0;
            bottom: 55px;
            width: 135px;
            padding: 12px;
        }

        .eo-showcase {
            padding: 42px 15px 60px;
        }

        .eo-feature-image {
            max-height: 620px;
        }

        .eo-capability-strip {
            grid-template-columns: repeat(2, 1fr);
            padding: 18px;
        }

        .eo-welcome {
            padding: 30px 18px 28px;
            border-radius: 28px;
        }

        .eo-welcome-logo {
            width: min(260px, 76vw);
        }

        .eo-countdown-wrap {
            width: 82px;
            height: 82px;
        }

        .eo-countdown-number {
            font-size: 31px;
        }
    }

    @media (prefers-reduced-motion: reduce) {
        *,
        *::before,
        *::after {
            scroll-behavior: auto !important;
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: .01ms !important;
        }
    }
</style>

<div id="elysium-one-launch">
    <div class="eo-page">

        <!-- =====================================================
             SCREEN 1 — LAUNCH BUTTON PAGE
             ===================================================== -->
        <section class="eo-hero" id="eoHero">
            <div class="eo-hero-inner">
                <div>
                    <div class="eo-brand-row">
                        <img src="{{ asset('assets/elysiumone/light_dark_logo.png') }}" alt="Elysium One">
                        <span>Elysium Groups · Employee Experience</span>
                    </div>

                    <h1>
                        One place.
                        <span>One Mate.</span>
                        One Elysium.
                    </h1>

                    <p class="eo-hero-copy">
                        Meet <strong>Elysium One</strong> — the mobile experience created for
                        Elysium Mates to manage everyday work essentials from one simple,
                        modern and connected app.
                    </p>

                    <button type="button" class="eo-launch-btn" id="eoLaunchButton">
                        <span class="mdi mdi-rocket-launch-outline"></span>
                        Launch Elysium One
                        <span class="mdi mdi-arrow-right"></span>
                    </button>

                    <div class="eo-launch-meta">
                        <span><i class="mdi mdi-check-decagram"></i> Built for Elysium Mates</span>
                        <span><i class="mdi mdi-shield-check-outline"></i> Secure employee access</span>
                    </div>
                </div>

                <div class="eo-phone-stage" aria-hidden="true">
                    <div class="eo-phone-glow"></div>

                    <div class="eo-phone">
                        <img src="{{ asset('assets/elysiumone/mobile_splash_1.png') }}"
                             alt="Elysium One mobile app preview">
                    </div>

                    <div class="eo-phone-badge">
                        <small>Employee app</small>
                        <strong>Elysium One</strong>
                        <span class="mdi mdi-cellphone-check"></span>
                    </div>
                </div>
            </div>
        </section>

        <!-- =====================================================
             SCREEN 2 — WELCOME / CENTER LOGO / 5-SECOND COUNTDOWN
             ===================================================== -->
        <div class="eo-launch-overlay" id="eoLaunchOverlay" aria-hidden="true">
            <button type="button" class="eo-skip" id="eoSkipLaunch">Skip intro</button>

            <div class="eo-panel left"></div>
            <div class="eo-panel right"></div>

            <div class="eo-welcome" id="eoWelcome">
                <div class="eo-welcome-eyebrow">
                    <span class="mdi mdi-star-four-points"></span>
                    A new Elysium experience
                </div>

                <img class="eo-welcome-logo"
                     src="{{ asset('assets/elysiumone/logo-dark.png') }}"
                     alt="Elysium One">

                <h2>Welcome to Elysium One</h2>

                <p>
                    Built for Elysium Mates — attendance, check-in, check-out, payslips
                    and everyday employee essentials in one mobile experience.
                </p>

                <div class="eo-countdown-wrap" aria-live="polite" aria-label="Launching in 5 seconds">
                    <div class="eo-countdown-ring" id="eoCountdownRing"></div>
                    <span class="eo-countdown-number" id="eoCountdownNumber">5</span>
                </div>
                <div class="eo-countdown-label">Launching in</div>

                <div class="eo-welcome-progress" aria-hidden="true">
                    <span></span>
                </div>
            </div>
        </div>

        <!-- =====================================================
             SCREEN 3 — MOBILE PRODUCT SHOWCASE
             ===================================================== -->
        <section class="eo-showcase" id="eoShowcase">
            <canvas id="eoFireworksStage" aria-hidden="true"></canvas>
            <div class="eo-showcase-inner">
                <div class="eo-showcase-celebration">
                    <span class="mdi mdi-party-popper"></span> Elysium One Mobile is here
                </div>

                <div class="eo-showcase-head">
                    <div class="eo-showcase-kicker">Introducing Elysium One Mobile</div>
                    <h2>Everything your Elysium Mate needs, in one place.</h2>
                    <p>
                        A simple mobile companion for attendance, daily work actions,
                        payslips and important employee information — designed to make
                        everyday work easier.
                    </p>
                </div>

                <div class="eo-feature-grid">
                    <article class="eo-feature">
                        <div class="eo-feature-image">
                            <img src="{{ asset('assets/elysiumone/mobile-splash.png') }}"
                                 alt="Elysium One mobile launch screen"
                                 loading="eager">
                        </div>
                        <div class="eo-feature-body">
                            <div class="eo-feature-number">01</div>
                            <h3>Your Elysium, on mobile</h3>
                            <p>
                                A focused employee-first experience that keeps essential
                                workplace actions close at hand.
                            </p>
                        </div>
                    </article>

                    <article class="eo-feature">
                        <div class="eo-feature-image">
                            <img src="{{ asset('assets/elysiumone/mobile-dashboard.png') }}"
                                 alt="Elysium One employee dashboard"
                                 loading="lazy">
                        </div>
                        <div class="eo-feature-body">
                            <div class="eo-feature-number">02</div>
                            <h3>Your day at a glance</h3>
                            <p>
                                Check your work status, points, attendance, quick actions,
                                incentives and employee updates from the dashboard.
                            </p>
                        </div>
                    </article>

                    <article class="eo-feature">
                        <div class="eo-feature-image">
                            <img src="{{ asset('assets/elysiumone/mobile-attendance.png') }}"
                                 alt="Elysium One attendance calendar"
                                 loading="lazy">
                        </div>
                        <div class="eo-feature-body">
                            <div class="eo-feature-number">03</div>
                            <h3>Attendance made simple</h3>
                            <p>
                                View your attendance calendar, daily status and upcoming
                                holiday information without leaving the app.
                            </p>
                        </div>
                    </article>
                </div>

                <div class="eo-capability-strip">
                    <div class="eo-capability">
                        <span class="mdi mdi-login-variant"></span>
                        <strong>Check In</strong>
                        <small>Start your day</small>
                    </div>
                    <div class="eo-capability">
                        <span class="mdi mdi-logout-variant"></span>
                        <strong>Check Out</strong>
                        <small>End your day</small>
                    </div>
                    <div class="eo-capability">
                        <span class="mdi mdi-calendar-check-outline"></span>
                        <strong>Attendance</strong>
                        <small>Track your days</small>
                    </div>
                    <div class="eo-capability">
                        <span class="mdi mdi-file-document-outline"></span>
                        <strong>Payslip</strong>
                        <small>View salary details</small>
                    </div>
                    <div class="eo-capability">
                        <span class="mdi mdi-view-dashboard-outline"></span>
                        <strong>More</strong>
                        <small>Employee essentials</small>
                    </div>
                </div>

            </div>
        </section>

    </div>
</div>

<!-- Existing Laravel status endpoint is retained. -->
<script src="https://cdn.jsdelivr.net/npm/@tsparticles/confetti@3.0.3/tsparticles.confetti.bundle.min.js"></script>

<script>
(function () {
    'use strict';

    const launchButton = document.getElementById('eoLaunchButton');
    const overlay = document.getElementById('eoLaunchOverlay');
    const skipButton = document.getElementById('eoSkipLaunch');
    const showcase = document.getElementById('eoShowcase');
    const hero = document.getElementById('eoHero');
    const welcome = document.getElementById('eoWelcome');
    const countdownNumber = document.getElementById('eoCountdownNumber');
    const countdownRing = document.getElementById('eoCountdownRing');
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
    const userId = @json($user_id);

    const INTRO_SECONDS = 5;
    const SHOWCASE_FIREWORKS_MS = 18000;

    let countdownTimer = null;
    let launchTimer = null;
    let fireworksFrame = null;
    let fireworksStopTimer = null;
    let fireworksStarted = false;

    function setBodyLocked(locked) {
        document.body.classList.toggle('eo-launch-locked', locked);
    }

    function resetCountdown() {
        if (countdownTimer) {
            clearInterval(countdownTimer);
            countdownTimer = null;
        }

        if (countdownNumber) countdownNumber.textContent = String(INTRO_SECONDS);
        if (countdownRing) countdownRing.style.setProperty('--eo-countdown-progress', '0%');
    }

    function startCountdown() {
        resetCountdown();

        let remaining = INTRO_SECONDS;
        let elapsed = 0;

        countdownTimer = setInterval(function () {
            elapsed += 1;
            remaining -= 1;

            if (countdownNumber) {
                countdownNumber.textContent = String(Math.max(remaining, 0));
            }

            if (countdownRing) {
                countdownRing.style.setProperty(
                    '--eo-countdown-progress',
                    ((elapsed / INTRO_SECONDS) * 100) + '%'
                );
            }

            if (remaining <= 0) {
                clearInterval(countdownTimer);
                countdownTimer = null;
                finishLaunch();
            }
        }, 1000);
    }

    function showShowcase() {
        if (!showcase) return;

        overlay.classList.remove('is-active');
        overlay.setAttribute('aria-hidden', 'true');
        setBodyLocked(false);

        if (hero) {
            hero.style.display = 'none';
        }

        showcase.classList.add('is-visible');

        document.querySelectorAll('.eo-feature').forEach(function (card, index) {
            setTimeout(function () {
                card.classList.add('is-in');
            }, index * 130);
        });

        window.scrollTo({ top: 0, behavior: 'smooth' });
        startShowcaseCelebration();
    }

    function stopFireworks() {
        if (fireworksFrame) {
            cancelAnimationFrame(fireworksFrame);
            fireworksFrame = null;
        }

        if (fireworksStopTimer) {
            clearTimeout(fireworksStopTimer);
            fireworksStopTimer = null;
        }

        const canvas = document.getElementById('eoFireworksStage');
        if (canvas) {
            const ctx = canvas.getContext('2d');
            if (ctx) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }

        if (showcase) {
            showcase.classList.remove('is-celebrating');
        }

        fireworksStarted = false;
    }

    function startFireworks() {
        if (fireworksStarted) return;

        const canvas = document.getElementById('eoFireworksStage');
        if (!canvas) return;

        fireworksStarted = true;
        showcase.classList.add('is-celebrating');

        const ctx = canvas.getContext('2d');
        let width = canvas.width = window.innerWidth;
        let height = canvas.height = window.innerHeight;

        const fireworks = [];
        const particles = [];
        const palette = ['#f7a009', '#30489f', '#ffffff', '#b32d2a', '#44d59b'];

        function resize() {
            width = canvas.width = window.innerWidth;
            height = canvas.height = window.innerHeight;
        }

        window.addEventListener('resize', resize, { passive: true });

        function random(min, max) {
            return Math.random() * (max - min) + min;
        }

        function createFirework() {
            const x = random(width * .08, width * .92);
            const targetY = random(height * .10, height * .58);

            fireworks.push({
                x: random(width * .35, width * .65),
                y: height + 12,
                tx: x,
                ty: targetY,
                speed: random(7, 11),
                color: palette[Math.floor(random(0, palette.length))]
            });
        }

        function burst(x, y, color) {
            for (let i = 0; i < 95; i++) {
                const angle = Math.random() * Math.PI * 2;
                const speed = random(1.4, 6.8);

                particles.push({
                    x: x,
                    y: y,
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    gravity: .055,
                    friction: .986,
                    alpha: 1,
                    decay: random(.007, .016),
                    size: random(1.1, 2.8),
                    color: color
                });
            }
        }

        let lastLaunch = 0;

        function loop(time) {
            ctx.clearRect(0, 0, width, height);

            if (time - lastLaunch > 560) {
                createFirework();
                lastLaunch = time;
            }

            fireworks.forEach(function (fw, index) {
                const dx = fw.tx - fw.x;
                const dy = fw.ty - fw.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                ctx.beginPath();
                ctx.moveTo(fw.x, fw.y);
                ctx.lineTo(fw.x - dx / 7, fw.y - dy / 7);
                ctx.strokeStyle = fw.color;
                ctx.globalAlpha = .82;
                ctx.lineWidth = 2.2;
                ctx.stroke();

                if (distance < 13) {
                    burst(fw.x, fw.y, fw.color);
                    fireworks.splice(index, 1);
                    return;
                }

                fw.x += dx / distance * fw.speed;
                fw.y += dy / distance * fw.speed;
            });

            particles.forEach(function (p, index) {
                p.vx *= p.friction;
                p.vy *= p.friction;
                p.vy += p.gravity;
                p.x += p.vx;
                p.y += p.vy;
                p.alpha -= p.decay;

                if (p.alpha <= 0) {
                    particles.splice(index, 1);
                    return;
                }

                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fillStyle = p.color;
                ctx.globalAlpha = p.alpha;
                ctx.fill();
            });

            ctx.globalAlpha = 1;
            fireworksFrame = requestAnimationFrame(loop);
        }

        createFirework();
        fireworksFrame = requestAnimationFrame(loop);
    }

    function startShowcaseCelebration() {
        startFireworks();

        if (typeof window.confetti === 'function') {
            setTimeout(function () {
                window.confetti({
                    particleCount: 180,
                    spread: 105,
                    startVelocity: 42,
                    origin: { x: .15, y: .72 },
                    scalar: .95
                });
                window.confetti({
                    particleCount: 180,
                    spread: 105,
                    startVelocity: 42,
                    origin: { x: .85, y: .72 },
                    scalar: .95
                });
            }, 220);
        }

        fireworksStopTimer = setTimeout(function () {
            stopFireworks();
        }, SHOWCASE_FIREWORKS_MS);
    }

    function updateWelcomeStatus() {
        if (typeof window.jQuery === 'undefined') return;

        if (userId !== null && userId !== undefined) {
            window.jQuery.ajax({
                url: "{{ route('update_welcome_status') }}",
                type: "POST",
                data: {
                    staff_id: userId,
                    _token: csrfToken
                }
            }).fail(function (error) {
                console.warn('Unable to update Elysium One welcome status.', error);
            });
        }
    }

    function launchElysiumOne() {
        if (!overlay || overlay.classList.contains('is-active')) return;

        resetCountdown();
        overlay.classList.add('is-active');
        overlay.setAttribute('aria-hidden', 'false');
        setBodyLocked(true);

        requestAnimationFrame(function () {
            overlay.classList.add('panels-open');

            setTimeout(function () {
                overlay.classList.add('welcome-visible');
                startCountdown();
            }, 1250);
        });

        // Safety fallback: the normal countdown finishes in exactly 5 seconds.
        launchTimer = setTimeout(function () {
            finishLaunch();
        }, 7000);
    }

    function finishLaunch() {
        if (launchTimer) {
            clearTimeout(launchTimer);
            launchTimer = null;
        }

        if (countdownTimer) {
            clearInterval(countdownTimer);
            countdownTimer = null;
        }

        overlay.classList.remove('welcome-visible', 'panels-open');

        setTimeout(function () {
            showShowcase();
            updateWelcomeStatus();
        }, 350);
    }

    if (launchButton) {
        launchButton.addEventListener('click', launchElysiumOne);
    }

    if (skipButton) {
        skipButton.addEventListener('click', finishLaunch);
    }

})();
</script>
@endsection
