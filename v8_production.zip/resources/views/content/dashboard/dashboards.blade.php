@php
$configData = Helper::appClasses();
@endphp
@extends('layouts/layoutMaster')

@section('title', 'HR General')
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/apex-charts/apex-charts.scss',
'resources/assets/vendor/libs/swiper/swiper.scss'
])
@endsection

@section('page-style')
<!-- Page -->
@vite([
'resources/assets/vendor/scss/pages/cards-statistics.scss',
'resources/assets/vendor/scss/pages/cards-analytics.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
'resources/assets/vendor/libs/swiper/swiper.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/dashboards-analytics.js'])
@endsection

@section('content')
<style>
  .staff-card {
    position: relative;
    overflow: hidden;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    background-color: #fff;
    background-image:
      radial-gradient(circle at right center,
        rgba(255, 255, 255, 0.67),
        rgba(255, 255, 255, 1)),
      url('assets/egc_images/heart-shape.png');

    background-repeat: no-repeat;
    background-position: right center;
    background-size: 140px;
    box-shadow: 0 0px 0px rgba(0, 0, 0, 0.08);
  }

  .staff-card:hover {
    box-shadow: 0 6px 14px rgba(0, 0, 0, 0.10);
  }

  .staff-card:active {
    transform: translateY(3px) scale(0.98);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.08);
  }

  .attend-card {
    transition: all 0.15s ease;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 0px 0px rgba(0, 0, 0, 0.08);
  }

  .attend-card:hover {
    box-shadow: 0 6px 14px rgba(0, 0, 0, 0.10);
  }

  .attend-card:active {
    transform: translateY(3px) scale(0.98);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.08);
  }

  .press-card {
    position: relative;
    overflow: hidden;
    border-radius: 16px;
    border: none;
    transition: all 0.25s ease;
    color: #111827;
    backdrop-filter: blur(6px);
  }

  /* Base hover */
  .press-card:hover {
    transform: translateY(-6px);
  }

  .press-card::after {
    content: "";
    position: absolute;
    width: 260px;
    height: 260px;
    bottom: -120px;
    right: -120px;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.06);
    pointer-events: none;
    box-shadow: inset 0 0 40px rgba(0, 0, 0, 0.05);
  }

  .card-blue {
    background: linear-gradient(135deg, #e0f2fe, #bfdbfe);
  }

  .card-blue::after {
    background: rgba(37, 99, 235, 0.12);
  }

  .card-blue:hover {
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.35);
  }


  /* Purple Card */
  .card-purple {
    background: linear-gradient(135deg, #f3e8ff, #e9d5ff);
  }

  .card-purple:hover {
    box-shadow: 0 10px 25px rgba(168, 85, 247, 0.35);
  }

  .card-purple::after {
    background: rgba(147, 51, 234, 0.12);
  }

  /* Indigo Card */
  .card-indigo {
    background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
  }

  .card-indigo:hover {
    box-shadow: 0 10px 25px rgba(99, 102, 241, 0.35);
  }

  .card-indigo::after {
    background: rgba(79, 70, 229, 0.12);
  }

  /* Icon circle */
  .icon-box {
    width: 52px;
    height: 52px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* Icon colors */
  .icon-blue {
    background: #3b82f6;
  }

  .icon-purple {
    background: #9333ea;
  }

  .icon-indigo {
    background: #6366f1;
  }

  .icon-box i {
    color: #fff;
    font-size: 20px;
  }
</style>
@php
$dateRangeLabel = $startOfWeek->format('d-M-Y') . ' - ' . $endOfWeek->format('d-M-Y');
@endphp
<div class="container" id="dashboard-content">
  <div class="loading-custom" id="loadingScreenCustomize" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999; display:none;">
    <div class="loading-content" style="text-align: center; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);">
      <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; margin-bottom: 20px;height:100%">
      <div class="d-block">
        <div class="dot-custom red"></div>
        <div class="dot-custom orange"></div>
        <div class="dot-custom yellow"></div>
        <div class="dot-custom green"></div>
        <div class="dot-custom teal"></div>
        <div class="dot-custom blue"></div>
        <div class="dot-custom violet"></div>
      </div>
    </div>
  </div>
  <div class="row g-2 mb-2">
    <div class="col-md-4">
      <div class="press-card card-blue p-4 h-100">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Gross Pay</div>
            <h3 class="fw-bold">₹ <span id="total_grosspay">0</span></h3>
            <small>Total payroll before deductions</small>
          </div>
          <div class="icon-box icon-blue">
            <i class="mdi mdi-trending-up"></i>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span id="grossChange" class="badge">0%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="press-card card-purple p-4 h-100">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Net Pay</div>
            <h3 class="fw-bold">₹ <span id="total_netpay">0</span></h3>
            <small>Total take-home after deductions</small>
          </div>
          <div class="icon-box icon-purple">
            <i class="mdi mdi-currency-usd"></i>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span id="netChange" class="badge">0%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="press-card card-indigo p-4 h-100">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Total Employees</div>
            <h3 class="fw-bold"><span id="totalStaff">0</span></h3>
            <small>Active workforce strength</small>
          </div>
          <div class="icon-box icon-indigo">
            <i class="mdi mdi-account-group"></i>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span id="staffChange" class="badge">0%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
  </div>
  <div class="row g-2 mb-2">
    <div class="col-md-6 col-lg-6 col-xl-6">
      <div class="card p-4 h-100 border" style="box-shadow: none;">
        <div class="d-flex flex-column">
          <label class="fs-5 text-dark fw-semibold">Salary Variation</label>
          <small>Gross Pay Vs Net Pay trends (Last 6 Month)</small>
        </div>
        <div>
          <div id="salar_variation"></div>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6">
      <div class="card p-4 h-100 border" style="box-shadow: none;">
        <div class="d-flex flex-column">
          <label class="fs-5 text-dark fw-semibold">Attendance Overview</label>
          <small>Weekly Present and Absent trends <span class="text-primary">({{$dateRangeLabel}})</span></small>
        </div>
        <div>
          <div id="attend_track"></div>
        </div>
      </div>
    </div>
  </div>
  <div class="row g-2 mb-2">
    <div class="col-md-4">
      <div class="card px-3 py-3 bg-white rounded border staff-card active">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Total Present</div>
            <h3 class="fw-bold" id="totalpresent">0</h3>
          </div>
          <div>
            <span class="badge bg-label-success rounded p-2">
              <i class="mdi mdi-account-check-outline"></i>
            </span>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span class="text-success"><i class="mdi mdi-arrow-up"></i> 1.2%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card px-3 py-3 bg-white rounded border staff-card active">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Total Absent</div>
            <h3 class="fw-bold" id="totalabsent">0</h3>
          </div>
          <div>
            <span class="badge bg-label-danger rounded p-2">
              <i class="mdi mdi-account-minus-outline"></i>
            </span>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span class="text-danger"><i class="mdi mdi-arrow-down"></i> 0.8%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card px-3 py-3 bg-white rounded border staff-card active">
        <div class="d-flex justify-content-between">
          <div>
            <div class="text-dark small">Attendance Rate</div>
            <h3 class="fw-bold"><span id="attendance_rate">0</span>%</h3>
          </div>
          <div>
            <span class="badge bg-label-success rounded p-2">
              <i class="mdi mdi-trending-up"></i>
            </span>
          </div>
        </div>
        <div class="mt-3 d-flex align-items-center gap-2">
          <span class="text-success"><i class="mdi mdi-arrow-up"></i> 1.5%</span>
          <small>vs last month</small>
        </div>
      </div>
    </div>
  </div>
  <div class="row g-2 mb-2">
    <div class="col-md-6 col-lg-6 col-xl-6">
      <div class="row g-2">
        <div class="col-md-6 col-lg-6 col-xl-6">
          <div class="card px-3 py-3 bg-white rounded border attend-card active">
            <div class="d-flex justify-content-between">
              <div>
                <div class="text-dark small">Active Onboarding</div>
                <h3 class="fw-bold">0</h3>
              </div>
              <div>
                <span class="badge bg-label-info rounded p-2">
                  <i class="mdi mdi-account-plus-outline"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6">
          <div class="card px-3 py-3 bg-white rounded border attend-card active">
            <div class="d-flex justify-content-between">
              <div>
                <div class="text-dark small">Onboarding Queue</div>
                <h3 class="fw-bold">0</h3>
              </div>
              <div>
                <span class="badge bg-label-warning rounded p-2">
                  <i class="mdi mdi-clock-outline"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-12 col-lg-12 col-xl-12">
          <div class="card px-3 py-3 bg-white rounded border attend-card active">
            <div class="d-flex justify-content-between">
              <div class="text-dark fs-5 fw-semibold mb-2">Onboarding Progress</div>
              <label class="fs-5 text-black fw-medium">0%</label>
            </div>
            <div class="d-flex flex-column mb-3">
              <div class="d-flex justify-content-between align-items-end">
                <div class="d-flex justify-content-start gap-2 align-items-center mb-2">
                  <span class="badge bg-label-success rounded">
                    <i class="mdi mdi-check text-black"></i>
                  </span>
                  <label class="text-black fw-medium fs-7">Completed</label>
                </div>
                <label class="text-black fw-medium fs-7">12/15</label>
              </div>
              <div>
                <div class="progress bg-gray-100 w-100% rounded">
                  <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="80">00%</div>
                </div>
              </div>
            </div>
            <div class="d-flex flex-column mb-3">
              <div class="d-flex justify-content-between align-items-end">
                <div class="d-flex justify-content-start gap-2 align-items-center mb-2">
                  <span class="badge bg-label-indigo rounded">
                    <i class="mdi mdi-clock-outline text-black"></i>
                  </span>
                  <label class="text-black fw-medium fs-7">In Progress</label>
                </div>
                <label class="text-black fw-medium fs-7">03/15</label>
              </div>
              <div>
                <div class="progress bg-gray-100 w-100% rounded">
                  <div class="progress-bar bg-indigo" role="progressbar" style="width: 00%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="20">00%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6">
          <div class="card px-3 py-3 bg-white rounded border attend-card active">
            <div class="d-flex justify-content-between">
              <div>
                <div class="text-dark small">Enroll (<?php echo date('M-Y'); ?>)</div>
                <h3 class="fw-bold" id="currentStaff">0</h3>
              </div>
              <div>
                <span class="badge bg-label-warning rounded p-2">
                  <i class="mdi mdi-account-edit-outline"></i>
                </span>
              </div>
            </div>
            <div class="mt-3 d-flex align-items-center gap-2">
              <!-- <span class="text-success"><i class="mdi mdi-arrow-up"></i> 12%</span> -->
              <span id="currentStaffChange" class="">0%</span>
              <small>vs last month</small>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-6 col-xl-6">
          <div class="card px-3 py-3 bg-white rounded border attend-card active">
            <div class="d-flex justify-content-between">
              <div>
                <div class="text-dark small">Exits Staffs</div>
                <h3 class="fw-bold" id="currentExit">0</h3>
              </div>
              <div>
                <span class="badge bg-label-primary rounded p-2">
                  <i class="mdi mdi-account-cancel-outline"></i>
                </span>
              </div>
            </div>
            <div class="mt-3 d-flex align-items-center gap-2">
              <!-- <span class="text-danger"><i class="mdi mdi-arrow-down"></i> 2%</span> -->
              <span id="exitStaffChange" class="">0%</span>
              <small>vs last month</small>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6">
      <div class="card p-4 h-100 border" style="box-shadow: none;">
        <div class="d-flex flex-column">
          <label class="fs-5 text-dark fw-semibold">Enrollment Trend</label>
          <small>Monthly enrollment variation</small>
        </div>
        <div>
          <div id="enroll_variation"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Salary Variation Graph -->
<script>
  // // ✅ Month Setup
  // const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // let currentMonth = new Date().getMonth(); // 0 = Jan
  // let last6Months = [];

  // for (let i = 1; i <= 6; i++) {
  //   let index = (currentMonth - i + 12) % 12;
  //   last6Months.push(monthNames[index]);
  // }

  // // ✅ Make it chronological (old → new)
  // last6Months.reverse();

  // // ✅ Sample Data (match 6 months)
  // let grossData = [50000, 52000, 51000, 53000, 54000, 55000];
  // let netData = [42000, 43000, 42500, 44000, 45000, 46000];

  // // ✅ Chart
  // var options = {
  //   series: [{
  //       name: 'Gross Pay',
  //       data: grossData
  //     },
  //     {
  //       name: 'Net Pay',
  //       data: netData
  //     }
  //   ],

  //   chart: {
  //     type: 'bar',
  //     height: 350,
  //     toolbar: {
  //       show: false
  //     }
  //   },

  //   grid: {
  //     show: false
  //   },

  //   plotOptions: {
  //     bar: {
  //       horizontal: false,
  //       columnWidth: '50%',
  //       borderRadius: 6,
  //       borderRadiusApplication: 'end'
  //     }
  //   },

  //   dataLabels: {
  //     enabled: false
  //   },

  //   stroke: {
  //     show: true,
  //     width: 2,
  //     colors: ['transparent']
  //   },

  //   xaxis: {
  //     categories: last6Months,
  //     axisBorder: {
  //       show: true,
  //       color: '#ccc'
  //     },
  //     axisTicks: {
  //       show: true,
  //       color: '#ccc'
  //     }
  //   },

  //   yaxis: {
  //     title: {
  //       text: '₹ Amount'
  //     },
  //     axisBorder: {
  //       show: true,
  //       color: '#ccc'
  //     },
  //     axisTicks: {
  //       show: true,
  //       color: '#ccc'
  //     }
  //   },

  //   fill: {
  //     opacity: 1
  //   },

  //   colors: ['#0d6efd', '#20c997'],

  //   tooltip: {
  //     y: {
  //       formatter: function(val) {
  //         return "₹ " + val.toLocaleString();
  //       }
  //     }
  //   },

  //   legend: {
  //     position: 'top'
  //   }
  // };

  // var chart = new ApexCharts(document.querySelector("#salar_variation"), options);
  // chart.render();

  let salaryChart;

  function renderSalaryChart(months, gross, net) {

    if (salaryChart) {
      salaryChart.destroy();
    }

    var options = {
      series: [{
          name: 'Gross Pay',
          data: gross
        },
        {
          name: 'Net Pay',
          data: net
        }
      ],

      chart: {
        type: 'bar',
        height: 350,
        toolbar: {
          show: false
        }
      },

      plotOptions: {
        bar: {
          columnWidth: '50%',
          borderRadius: 6
        }
      },

      dataLabels: {
        enabled: false
      },

      xaxis: {
        categories: months
      },

      yaxis: {
        title: {
          text: '₹ Amount'
        }
      },

      colors: ['#0d6efd', '#20c997'],

      tooltip: {
        y: {
          formatter: function(val) {
            return "₹ " + val.toLocaleString();
          }
        }
      }
    };

    salaryChart = new ApexCharts(document.querySelector("#salar_variation"), options);
    salaryChart.render();
  }
</script>

<script>
  // var presentData = [232, 240, 238, 245, 236, 242];
  // var absentData = [18, 10, 12, 5, 14, 8];

  function renderAttendanceChart(categories, presentData, absentData, presentRatio) {

    var options = {
      series: [{
          name: 'Present',
          type: 'area',
          data: presentData
        },
        {
          name: 'Absent',
          type: 'area',
          data: absentData
        },
        {
          name: 'Present %',
          type: 'column',
          data: presentRatio
        }
      ],

      chart: {
        height: 320,
        type: 'line',
        stacked: false,
        toolbar: {
          show: false
        }
      },

      stroke: {
        curve: 'smooth',
        width: [3, 3, 0]
      },

      fill: {
        type: ['gradient', 'gradient', 'solid'],
        gradient: {
          opacityFrom: 0.35,
          opacityTo: 0.05
        }
      },

      colors: ['#22c55e', '#ef4444', '#FBA919'],

      xaxis: {
        categories: categories
      },

      yaxis: [{},
        {
          opposite: true,
          min: 0,
          max: 100,
          labels: {
            formatter: val => val + "%"
          }
        }
      ],

      tooltip: {
        shared: true,
        y: [{
            formatter: val => val + " emp"
          },
          {
            formatter: val => val + " emp"
          },
          {
            formatter: val => val + "%"
          }
        ]
      }
    };

    // 🔁 Destroy old chart before re-render
    if (window.attendanceChart) {
      window.attendanceChart.destroy();
    }

    window.attendanceChart = new ApexCharts(
      document.querySelector("#attend_track"),
      options
    );

    window.attendanceChart.render();
  }

  // var presentRatio = presentData.map((p, i) => {
  //   let a = absentData[i];
  //   return ((p / (p + a)) * 100).toFixed(1);
  // });

  // var options = {
  //   series: [{
  //       name: 'Present',
  //       type: 'area',
  //       data: presentData
  //     },
  //     {
  //       name: 'Absent',
  //       type: 'area',
  //       data: absentData
  //     },
  //     {
  //       name: 'Present %',
  //       type: 'column',
  //       data: presentRatio
  //     }
  //   ],

  //   chart: {
  //     height: 320,
  //     type: 'line',
  //     stacked: false,
  //     toolbar: {
  //       show: false
  //     },
  //     fontFamily: 'Inter, sans-serif'
  //   },

  //   stroke: {
  //     curve: 'smooth',
  //     width: [3, 3, 0]
  //   },

  //   fill: {
  //     type: ['gradient', 'gradient', 'solid'],
  //     gradient: {
  //       shadeIntensity: 1,
  //       opacityFrom: 0.35,
  //       opacityTo: 0.05,
  //       stops: [0, 100]
  //     }
  //   },

  //   colors: ['#22c55e', '#ef4444', '#FBA919'],

  //   markers: {
  //     size: 4,
  //     strokeWidth: 2,
  //     hover: {
  //       size: 6
  //     }
  //   },

  //   plotOptions: {
  //     bar: {
  //       columnWidth: '40%',
  //       borderRadius: 6
  //     }
  //   },
  //   grid: {
  //     show: false,
  //   },
  //   xaxis: {
  //     categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  //     axisBorder: {
  //       show: false
  //     },
  //     axisTicks: {
  //       show: false
  //     }
  //   },

  //   yaxis: [{
  //       title: {
  //         text: ''
  //       }
  //     },
  //     {
  //       opposite: true,
  //       min: 0,
  //       max: 100,
  //       tickAmount: 5,
  //       labels: {
  //         formatter: val => val + "%"
  //       }
  //     }
  //   ],

  //   dataLabels: {
  //     enabled: false
  //   },

  //   tooltip: {
  //     shared: true,
  //     intersect: false,
  //     theme: 'light',
  //     y: [{
  //         formatter: val => val + " emp"
  //       },
  //       {
  //         formatter: val => val + " emp"
  //       },
  //       {
  //         formatter: val => val + "%"
  //       }
  //     ]
  //   },

  //   legend: {
  //     position: 'top',
  //     horizontalAlign: 'left'
  //   }
  // };

  // var chart = new ApexCharts(document.querySelector("#attend_track"), options);
  // chart.render();
</script>

<!-- Staff Enrollment Variation -->
<script>
  currentYear = new Date().getFullYear();

  // var options = {
  //   series: [{
  //     name: "Enrollments",
  //     data: [25, 32, 28, 40, 35, 50, 48, 55, 60, 58, 65, 70] // Jan → Dec
  //   }],

  //   chart: {
  //     height: 245,
  //     type: 'line',
  //     zoom: {
  //       enabled: false
  //     },
  //     toolbar: {
  //       show: false
  //     }
  //   },
  //   markers: {
  //     size: 5, // dot size
  //     colors: ['#0d6efd'], // same as line color
  //     strokeColors: '#fff',
  //     strokeWidth: 2,
  //     hover: {
  //       size: 7 // bigger on hover
  //     }
  //   },
  //   dataLabels: {
  //     enabled: false
  //   },

  //   stroke: {
  //     curve: 'smooth',
  //     width: 3
  //   },

  //   // ❌ Remove grid (clean look)
  //   grid: {
  //     show: false
  //   },

  //   xaxis: {
  //     categories: [
  //       'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  //       'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  //     ],
  //     axisBorder: {
  //       show: true,
  //       color: '#ccc'
  //     },
  //     axisTicks: {
  //       show: true,
  //       color: '#ccc'
  //     }
  //   },

  //   yaxis: {
  //     title: {
  //       text: 'No. of Enrollments'
  //     },
  //     axisBorder: {
  //       show: true,
  //       color: '#ccc'
  //     },
  //     axisTicks: {
  //       show: true,
  //       color: '#ccc'
  //     }
  //   },

  //   colors: ['#0d6efd'],

  //   tooltip: {
  //     y: {
  //       formatter: function(val) {
  //         return val + " enrollments";
  //       }
  //     }
  //   }
  // };

  // var chart = new ApexCharts(document.querySelector("#enroll_variation"), options);
  // chart.render();
  function renderEnrollmentChart(categories, data) {

    var options = {
      series: [{
        name: "Enrollments",
        data: data
      }],

      chart: {
        height: 245,
        type: 'line',
        toolbar: {
          show: false
        }
      },

      stroke: {
        curve: 'smooth',
        width: 3
      },

      markers: {
        size: 5,
        strokeWidth: 2,
        hover: {
          size: 7
        }
      },

      grid: {
        show: false
      },

      xaxis: {
        categories: categories
      },

      yaxis: {
        title: {
          text: 'No. of Enrollments'
        }
      },

      tooltip: {
        y: {
          formatter: function(val) {
            return val + " enrollments";
          }
        }
      },

      colors: ['#0d6efd']
    };

    if (window.enrollChart) {
      window.enrollChart.destroy();
    }

    window.enrollChart = new ApexCharts(
      document.querySelector("#enroll_variation"),
      options
    );

    window.enrollChart.render();
  }
</script>

<script>
  function loadDashboard() {

    let company = $('#companyFilter').val();
    let entity = $('#entityFilter').val();
    let department = $('#departmentFilter').val();
    const loader = document.getElementById('loadingScreenCustomize');

    $.ajax({
      url: "{{ route('hr.dashboard.data') }}",
      type: "GET",
      data: {
        company_id: company,
        entity_id: entity,
        department_id: department
      },
      beforeSend: function() {
        loader.style.display = 'flex';
      },
      success: function(res) {

        if (res.status) {

          let d = res.data;

          //  KPI UPDATE
          $('#totalStaff').text(d.totalStaff);
          $('#total_netpay').text(d.totalNetSalary ? new Intl.NumberFormat('en-IN').format(d.totalNetSalary) : '0');
          $('#total_grosspay').text(d.totalGrossSalary ? new Intl.NumberFormat('en-IN').format(d.totalGrossSalary) : '0');
          $('#totalpresent').text(d.present);
          // $('#late').text(d.late);
          // $('#permission').text(d.permission);
          $('#totalabsent').text(d.absent);
          $('#currentStaff').text(d.currentStaff);
          $('#currentExit').text(d.currentExit);
          $('#attendance_rate').text(d.attendance_rate);



          let change = d.changes;

          // Gross
          let gross = formatChange(change.gross);
          $('#grossChange')
            .removeClass('bg-success bg-danger')
            .addClass(gross.className)
            .text(gross.text);

          // Net
          let net = formatChange(change.net);
          $('#netChange')
            .removeClass('bg-success bg-danger')
            .addClass(net.className)
            .text(net.text);

          // Staff
          let staff = formatChange(change.staff);
          $('#staffChange')
            .removeClass('bg-success bg-danger')
            .addClass(staff.className)
            .text(staff.text);

          let currentStaff = formatTextChange(change.staff);
          $('#currentStaffChange')
            .removeClass('text-success text-danger')
            .addClass(currentStaff.className)
            .text(currentStaff.text);

          let exitStaff = formatTextChange(change.exitStaff);
          $('#exitStaffChange')
            .removeClass('text-success text-danger')
            .addClass(exitStaff.className)
            .text(exitStaff.text);

          let chartData = d.chart;

          renderAttendanceChart(
            chartData.categories,
            chartData.present,
            chartData.absent,
            chartData.ratio
          );


          if (d.enrollment_chart) {
            renderEnrollmentChart(
              d.enrollment_chart.categories || [],
              d.enrollment_chart.data || []
            );
          }

          if (d.salary_variation) {
            renderSalaryChart(
              d.salary_variation.months,
              d.salary_variation.gross,
              d.salary_variation.net
            );
          }


        }
      },
      complete: function() {
        loader.style.display = 'none';
      }
    });
  }
  loadDashboard();

  function formatChange(value) {
    let arrow = value >= 0 ? '↑' : '↓';
    let className = value >= 0 ? 'bg-success' : 'bg-danger';

    return {
      text: `${arrow} ${Math.abs(value)}%`,
      className: className
    };
  }

  function formatTextChange(value) {
    let arrow = value >= 0 ? '↑' : '↓';
    let className = value >= 0 ? 'text-success' : 'text-danger';

    return {
      text: `${arrow} ${Math.abs(value)}%`,
      className: className
    };
  }
</script>
@endsection