@if(isset($ListTable) && count($ListTable))
    @foreach($ListTable as $i => $list)
        @php
            $mode = $list->traning_mode;
        
            // Background colors
            $bgColors = [
                1 => '#F5F3FF',
                2 => '#ECFDF5',
                3 => '#ECFEFF',
                4 => '#FFF7ED',
                5 => '#FFF7ED',
                6 => '#FFF7ED',
            ];
            $bgColor = $bgColors[$mode] ?? '#ECFEFF';
        
            // Images
            $modeImages = [
                1 => 'play.png',
                2 => 'pdf.png',
                3 => 'link.png',
                4 => 'audio_doc.png',
                5 => 'image_doc.png',
                6 => 'ppt_doc.png',
            ];
            $imgSrc = $modeImages[$mode] ?? 'reading.png';
        
            // Modal targets
            $modals = [
                1 => '#kt_modal_training_video',
                2 => '#kt_modal_preview_pdf',
                3 => '#kt_modal_training_link',
                4 => '#kt_modal_training_audio',
                5 => '#kt_modal_preview_image',
                6 => '#kt_modal_preview_ppt',
            ];
            $modalTarget = $modals[$mode] ?? '#kt_modal_training_text_learn';
        
            // Button text
            $buttonTexts = [
                1 => 'View Video',
                2 => 'View PDF',
                3 => 'View Link',
                4 => 'Play Audio',
                5 => 'View Image',
                6 => 'View PPT',
            ];
            $buttonText = $buttonTexts[$mode] ?? 'View Document';
        
            // Icon classes
            $iconClasses = [
                1 => 'mdi-video-check-outline',
                2 => 'mdi-file-pdf-box',
                3 => 'mdi-web',
                4 => 'mdi-headphones',
                5 => 'mdi-file-image-outline',
                6 => 'mdi-file-powerpoint-outline',
            ];
            $iconClass = $iconClasses[$mode] ?? 'mdi-book-open-blank-variant-outline';
        @endphp

        
        
        <div class="col-lg-12 cont_indv_tbox mb-4">
            <div class="card h-100 border px-2 py-1 shadow-none">
                <div class="card-body px-2  pt-2 pb-0">
                    <div class="row">
                        <div class="col-lg-1 border-end mb-2 d-flex align-items-center justify-content-center">
                            <div data-kt-image-input="true">
                                <img src="{{ asset('assets/egc_images/' . $imgSrc) }}" alt="user-avatar"
                                    class=" w-60px h-60px" id="Training" />
                            </div>
                        </div>
                        <div class="col-lg-9 border-end mb-2">
                            <h5 class="mb-1">{{ $list->traning_name ?? '-' }}</h5>
                            <div class="d-block mt-2">
                                <label
                                    class="badge bg-label-info border border-info rounded fw-semibold text-black fs-8 py-1 px-1 text-truncate fw-semibold max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Category : {{ $list->category_name ?? '-' }}">{{ $list->category_name ?? '-' }}</label>
                                <label class="fw-semibold fs-6 ms-1 me-1 text-truncate">|</label>
                                <label
                                    class="badge bg-label-warning border border-warning rounded fw-semibold text-black fs-8 py-1 px-1 text-truncate fw-semibold max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Sub Category : {{ $list->sub_cat_name ?? '-' }}">{{ $list->sub_cat_name ?? '-' }}</label>
                                @if($list->view_count == 0)
                                <label class="fw-semibold fs-6 ms-1 me-1 text-truncate">|</label>
                                <label
                                    class="badge bg-label-danger border border-danger rounded fw-semibold text-black fs-8 py-1 px-1 text-truncate"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    data-bs-original-title="Status">Not Viewed</label>
                                @else
                                <label class="fw-semibold fs-6 ms-1 me-1 text-truncate">|</label>
                                <label
                                    class="badge bg-label-success border border-success rounded fw-semibold text-black fs-8 py-1 px-1 text-truncate"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    data-bs-original-title="Status">Viewed</label>
                                @endif
                            </div>

                        </div>
                        <div class="col-lg-2 d-flex align-items-center justify-content-center mb-2">
                            @if($mode == 3)
                            <a href="{{$list->link}}" target="_blank" class="badge bg-label-color border border-primary rounded-pill fw-semibold text-black fs-7 py-1 px-2" >
                                <span>
                                    <i class="mdi {{ $iconClass }} fs-4 me-1"> </i>
                                </span class="text-black">
                                {{ $buttonText }}
                            </a>
                            @else
                            <a href="javascript:;"
                                class="badge bg-label-color border border-primary rounded-pill fw-semibold text-black fs-7 py-1 px-2"
                                data-bs-toggle="modal" data-bs-target="{{ $modalTarget }}" onclick="ViewAll('{{ $list->sno }}', '{{ $list->traning_mode }}')">
                                <span>
                                    <i class="mdi {{ $iconClass }} fs-4 me-1">
                                    </i>
                                </span class="text-black">{{ $buttonText }}
                            </a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@else
    <div class="col-12 text-center py-5">
        <h5 class="text-muted">No training documents found.</h5>
    </div>
@endif
