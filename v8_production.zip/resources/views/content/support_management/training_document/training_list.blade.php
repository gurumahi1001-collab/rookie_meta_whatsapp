@extends('layouts/layoutMaster')

@section('title', 'Manage Training')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@endsection
@section('content')
<style>
.menu_1_body {
    transition: all 0.3s ease;
}
.dataTables_scroll {
    max-height: 200px;
}


.icon-wrapper {
    display: inline-flex;
    align-items: center;
    flex-direction: row-reverse;
    gap: 8px;
    transition: transform 0.5s ease;
    transform: translateX(0);
}



.txt_hov:hover {
    text-decoration: underline !important;
}

#sidebar_tbox {
    transition: opacity 0.5s ease, width 0.5s ease;
    opacity: 1;
}

#sidebar_tbox.fade-out {
    opacity: 0;
    width: 0;
    overflow: hidden;
    pointer-events: none;
}


.w_99 {
    width: 99% !important;
}

.vart_menu_clr:hover,
.vart_menu_clr.active {
    border: 1px solid rgb(189, 188, 188) !important;
    background-color: #f5f5f5 !important;
    border-radius: 10px !important;
    cursor: pointer !important;
}

.vart_menu_sz:hover,
.vart_menu_sz.active {
    border: 1px solid rgb(189, 188, 188) !important;
    background-color: #f5f5f5 !important;
    border-radius: 10px !important;
    cursor: pointer !important;
}

.hover-emboss-color {
    transition: all 0.3s ease;
    cursor: pointer;
}

.hover-emboss-color.active {
    border: 1px solid #00246b;
    border-radius: 6px;
    padding: 3px;
    background-color: #00246b !important;
    color: #ffffff;
    text-shadow: none;
}

.bg-label-color {
    background-color: #daf0f9 !important;
}
</style>
<div class="row px-1 py-1">
    <div class="card">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-3 border border-end min-h-700px" id="sidebar_tbox" style="display: block;">
                    <div class="mb-4">
                        <div class="border-bottom pt-3 pb-2 px-2 d-flex justify-content-between">
                            <h5 class="card-title mb-2 text-black">Find Your Training</h5>
                            <div class="d-flex align-items-center mb-1">
                                <label class="badge fw-semibold fs-7 rounded-pill" style="background-color:#5f2c70;">{{ $categories ? str_pad(count($categories), 2, '0',STR_PAD_LEFT) :0; }}
                                    Category</label>
                            </div>
                        </div>
                        <div class="card-body pt-0 pb-2 px-1">
                            @forelse ($categories as $clist)
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="card-action">
                                            <div class="card-header align-items-center bg-transparent px-2 py-2 menu_1_hd">
                                                <div class="card-action-title text-dark fs-6 fw-semibold cursor-pointer">
                                                    {{ $clist->category_name ?? '-' }}
                                                </div>
                                                <div class="card-action-element">
                                                    <ul class="list-inline mb-0">
                                                        <li class="list-inline-item">
                                                            <a href="javascript:;" class="menu_1_icon text-black">
                                                                <i class="mdi mdi-chevron-up fs-3"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="collapse menu_1_body show">
                                            <div class="card-body px-2 ps-3 pt-1 pb-2">
                                                <div class="row">
                                                    @forelse ($clist->subcategories as $sub)
                                                        <div class="col-lg-12 mb-2">
                                                            <div class="form-check-label px-1 hover-emboss-color row" onclick="updateSelectedSubcategories({{$sub->sno}})">
                                                                <div class="col-10">
                                                                <label class="mb-1 fs-7 fw-semibold me-1 ">{{ $sub->sub_cat_name }}</label>
                                                                </div>
                                                                <div class="col-2 d-flex align-items-center justify-content-center">
                                                                <label class="badge bg-label-success text-black fw-bold rounded fs-7 px-2">{{ $sub->document_count ? str_pad($sub->document_count, 2, '0',STR_PAD_LEFT) :0; }}</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @empty
                                                        <div class="col-lg-12 text-muted fs-7">No subcategories available.</div>
                                                    @endforelse
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="border-dashed border-1 border-bottom border-gray-700"></div>
                            @empty
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="card-action">
                                            <div class="card-header align-items-center bg-transparent px-2 py-2 ">
                                                <div class="card-action-title text-dark fs-6 fw-semibold cursor-pointer">
                                                    No categories available For Your Role.
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            @endforelse

                        </div>
                    </div>
                </div>
                <div class="col-lg-9 min-h-700px" id="cont_tbox">
                    <div class="card-action mb-4">
                        <div class="card-header border-bottom pb-0 flex-wrap">
                            <div class="card-action-title text-black fs-5 fw-bold mb-1">
                                <div class="d-flex align-items-center">
                                    <div class="pe-2 me-2 border-end">
                                        <div class="avatar mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Results Menu" onclick="sidebar_func();">
                                            <div class="avatar-initial bg-primary rounded">
                                                <i class="mdi mdi-menu text-white fs-3"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex-column">
                                        <h5 class="card-title mb-1">Manage Training</h5>
                                        <nav aria-label="breadcrumb">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item">
                                                    <a href="{{url('/dashboards')}}"
                                                        class="d-flex align-items-center"><i
                                                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                                                </li>
                                                <span class="text-dark opacity-75 me-1 ms-1">
                                                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                                                </span>
                                                <li class="breadcrumb-item">
                                                    <a href="javascript:;"
                                                        class="d-flex align-items-center fw-semibold">Support
                                                        Management</a>
                                                </li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div id="training-loader" class="text-center my-3 d-none">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>

                    <div class="row" id="document_row">
                        <img src="{{ asset('assets/egc_images/training_doc_bg.jpg') }}" alt="icon"  />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Training Learn-->
<div class="modal fade" id="kt_modal_training_text_learn" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg modal-dialog modal-dialog-scrollable">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-between border-0 pb-0 mb-3">
                <h3 class="modal-title text-black" id="docTitle_text">-</h3>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">

                <div class="row" id="Text_Content_view"></div>

            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Training Learn-->


<!--begin::Modal - VIDEO-->
<div class="modal fade" id="kt_modal_training_video" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-fullscreen modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" onclick="pauseVideo()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black" id="docTitle_video">-</h3>
                </div>
                <div class="row mb-6">
                   <video id="video_player" width="640" height="700" controls controlsList="nodownload">
                        <source id="video_source" src="" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - VIDEO-->


<!--begin::Modal - AUDIO-->
<div class="modal fade" id="kt_modal_training_audio" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" onclick="pauseVideo()">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black"><span id="docTitle_audio"></span> - Audio View</h3>
                </div>
                <div class="row mb-6">
                    <audio id="audio_player" controls controlsList="nodownload">
                        <source id="audio_source" src="your-audio-file.mp3" type="audio/mpeg">
                        Your browser does not support the audio tag.
                    </audio>

                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - AUDIO-->

<!--end::Modal - Preview  -->
<!--begin::Modal - Preview  -->
<div class="modal fade" id="kt_modal_training_link" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static"> 
  <div class="modal-dialog modal-fullscreen modal-xl"> <!-- Optional: larger width -->
    <div class="modal-content rounded">
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"/>
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor">
            </svg>
          </span>
        </div>
      </div>
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-4">
          <h3 class="mb-4 text-black text-center"><span id="docTitle_link"></span>  View</h3>
        </div>
        <div class="row">
          <div class="col-lg-12" >
            <iframe id="link_sourse" src="javascript:;" width="100%" height="800px" style="border:none;"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--begin::Modal - Preview  -->
<div class="modal fade" id="kt_modal_preview_pdf" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static"> 
  <div class="modal-dialog modal-fullscreen modal-xl"> <!-- Optional: larger width -->
    <div class="modal-content rounded">
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"/>
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"/>
            </svg>
          </span>
        </div>
      </div>
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-4">
          <h3 class="mb-4 text-black text-center"><span id="docTitle_pdf"></span> PDF View</h3>
        </div>
        <div class="row">
          <div class="col-lg-12" >
            <div id="pdfPagesContainer"></div> <!-- container for all canvases -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--begin::Modal - Preview  -->
<div class="modal fade" id="kt_modal_preview_image" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static"> 
  <div class="modal-dialog modal-fullscreen modal-xl"> <!-- Optional: larger width -->
    <div class="modal-content rounded">
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"/>
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"/>
            </svg>
          </span>
        </div>
      </div>
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-4">
          <h3 class="mb-4 text-black text-center"><span id="docTitle_img"></span> Image View</h3>
        </div>
        <div class="row">
          <div class="col-lg-12" >
            <div id="image-container">
                <img id="Image_view" src="javascript" alt="Image">
            </div>
            <div class="d-flex justify-content-end align-items-end mt-4">
              <button id="zoomIn" class="btn btn-sm btn-primary">Zoom In +</button>
              <button id="zoomOut" class="btn btn-sm btn-primary ms-3">Zoom Out -</button>
              <button id="reset" class="btn btn-sm btn-primary ms-3">Reset</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!--begin::Modal - Preview  -->
<!-- PPT Preview Modal -->
<div class="modal fade" id="kt_modal_preview_ppt" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static"> 
  <div class="modal-dialog modal-fullscreen modal-xl">
    <div class="modal-content rounded">
      
      <!-- Modal Header (Close Button) -->
      <div class="modal-header justify-content-end border-0 pb-0">
        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"/>
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"/>
            </svg>
          </span>
        </button>
      </div>
      
      <!-- Modal Body -->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        
        <!-- Title -->
        <div class="mb-4 text-center">
          <h3 class="mb-4 text-black"><span id="docTitle_ppt"></span> PPT View</h3>
        </div>
        
        <!-- PPT Viewer -->
        <div class="row">
          <div class="col-12">
            <iframe id="pptViewer" width="100%" height="600" frameborder="0"></iframe>
          </div>
        </div>
        
      </div>
      
    </div>
  </div>
</div>




<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>

<script>
function updateSelectedSubcategories(val) {

    $('#training-loader').removeClass('d-none');

    $.ajax({
        url: "{{ route('support.training_document_table') }}",
        method: "GET",
        data: {
            subcategory_ids: val,
            search_fill: $('input[name="search_fill"]').val() || ''
        },
        success: function (response) {
            $('#training-loader').addClass('d-none');
            $('#document_row').html(response);
            $('[data-bs-toggle="tooltip"]').tooltip();
        },
        error: function (xhr) {
            $('#training-loader').addClass('d-none');
            console.error(xhr.responseText);
        }
    });
}

</script>




<style>

#image-container {
    overflow: hidden;
    border: 2px solid #ccc;
    border-radius: 10px;
    /*width: 600px;*/
    /*height: 400px;*/
    display: flex;
    justify-content: center;
    align-items: center;
    background: white;
  }

  #Image_view {
    width: 100%;
    height: 100%;
    /*object-fit: contain;*/
    transition: transform 0.3s ease;
    /*cursor: grab;*/
  }
  
#pdfPagesContainer {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px; /* space between pages */
}

#pdfPagesContainer canvas {
    user-select: none;
    -web-user-drag: none;
    pointer-events: none;
    background-color: white;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.2); /* PDF-style shadow */
    border: 1px solid #ccc; /* optional border */
    padding: 10px;
    margin-bottom: 10px;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const labels = document.querySelectorAll('#sidebar_tbox');

    function isMobile() {
        return window.innerWidth < 992;
    }
    const sidebar = document.getElementById('sidebar_tbox');

    labels.forEach(label => {
        label.addEventListener('click', function() {
            if (isMobile()) {
                sidebar.style.display = 'none';
            }
        });
    });
});
</script>

<script>
  const img = document.getElementById('Image_view');
  let scale = 1;
  const zoomFactor = 0.2;

  document.getElementById('zoomIn').addEventListener('click', () => {
    scale += zoomFactor;
    img.style.transform = `scale(${scale})`;
  });

  document.getElementById('zoomOut').addEventListener('click', () => {
    if (scale > zoomFactor) {
      scale -= zoomFactor;
      img.style.transform = `scale(${scale})`;
    }
  });

  document.getElementById('reset').addEventListener('click', () => {
    scale = 1;
    img.style.transform = `scale(${scale})`;
  });
</script>
<script>
 



  // Main function
  function ViewAll(id, mode) {
    if (!id) {
      console.error("ID is required");
      return;
    }

    fetch(`/training-document_view/${id}`)
      .then(response => {
        if (!response.ok) throw new Error('Document not found');
        return response.json();
      })
      .then(data => {
        console.log('Document data:', data);

        if (mode == 0) {
          // Text mode
          document.getElementById('docTitle_text').innerText = data.traning_name || 'No Title';
          document.getElementById('Text_Content_view').innerHTML = data.text_content || 'No Content';
        }
        if(mode == 2){
            document.getElementById('docTitle_pdf').innerText = data.traning_name || 'No Title';
            var pdf_id = data.pdf_id;
            var url = "{{ asset('training_document/') }}/" + pdf_id;
            // $('#thumb_img_edit').attr('src', imgUrl);
            // const url = "{{ asset('requirement_documents/requirement_doc_1.pdf') }}";
            const container = document.getElementById('pdfPagesContainer');
            
        
            let pdfInstance = null;
            
            container.innerHTML = ''; // Clear previous pages

            pdfjsLib.getDocument(url).promise.then(pdf => {
                pdfInstance = pdf;
    
                for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                    pdf.getPage(pageNum).then(page => {
                        const viewport = page.getViewport({ scale: 1.5 });
    
                        const canvas = document.createElement('canvas');
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;
                        const context = canvas.getContext('2d');
    
                        const renderContext = {
                            canvasContext: context,
                            viewport: viewport
                        };
    
                        page.render(renderContext);
                        container.appendChild(canvas);
                    });
                }
            });
            
        }
        if (mode == 1) {
           // Video mode
           document.getElementById('docTitle_video').innerText = data.traning_name || 'No Title';
           var video_id = data.video_link;
            var url = "{{ asset('training_document/videos') }}/" + video_id;
            
            // Set the video source and reload
            $('#video_source').attr('src', url);
            $('#video_player')[0].load(); // Important to reload the video after changing source

        }
        
        if (mode == 3) {
           // Link mode
           document.getElementById('docTitle_link').innerText = data.traning_name || 'No Title';
           var link = data.link;
            var linkurl =  link;
            // Set the video source and reload
            $('#link_sourse').attr('src', linkurl);

        }
        if (mode == 5) {
          // Image mode
            document.getElementById('docTitle_img').innerText = data.traning_name || 'No Title';
            var image_id = data.image_id;
            var url = "{{ asset('training_document/image') }}/" + image_id;
            // alert(url);
            // Set the video source and reload
            $('#Image_view').attr('src', url);

        }
        if (mode == 4) {
            // Set the audio title
            document.getElementById('docTitle_audio').innerText = data.traning_name || 'No Title';
            
            // Build the audio URL
            var audio_id = data.audio_id;
            var url = "{{ asset('training_document/audios') }}/" + audio_id;
            console.log("Audio URL:", url); // Better than alert for debugging
            
            // Set the source and reload the player
            $('#audio_source').attr('src', url);
            $('#audio_player')[0].load(); // Reload to apply new source
            $('#audio_player')[0].play(); // Optional: autoplay

        }
        if (mode == 6) {
            document.getElementById('docTitle_ppt').innerText = data.traning_name || 'No Title';
            pptFile = "{{ asset('training_document/ppt') }}/" + data.ppt_id;
            const pptIframe = document.getElementById('pptViewer'); 
            pptIframe.src = "https://view.officeapps.live.com/op/embed.aspx?src=" + encodeURIComponent(pptFile);

        }
      })
      .catch(error => {
        console.error('Error fetching document:', error.message);
      });
  }


</script>
<script>
    // Stop audio when modal closes
    const audioPlayer = document.getElementById('audio_player');
    const audioModal = document.getElementById('kt_modal_training_audio');

    // Bootstrap modal hidden event
    audioModal.addEventListener('hidden.bs.modal', function () {
        audioPlayer.pause();
        audioPlayer.currentTime = 0; // Reset to beginning
    });
</script>
<script>
// document.addEventListener('DOMContentLoaded', function () {
//     const modal = document.getElementById('kt_modal_preview_pdf');
//     const container = document.getElementById('pdfPagesContainer');
//     const url = "{{ asset('requirement_documents/requirement_doc_1.pdf') }}";

//     let pdfInstance = null;

//     modal.addEventListener('shown.bs.modal', function () {
        
//     });

//     modal.addEventListener('hidden.bs.modal', function () {
//         container.innerHTML = ''; // Clear on close
//     });
// });
</script>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById('kt_modal_preview_pdf');

    modal.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });

    modal.addEventListener('keydown', function (e) {
        if (
            (e.ctrlKey && ['c', 'u', 's', 'p'].includes(e.key.toLowerCase())) ||
            (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'i') ||
            e.key === 'F12'
        ) {
            e.preventDefault();
        }
    });

    modal.addEventListener('copy', e => e.preventDefault());
    modal.addEventListener('selectstart', e => e.preventDefault());
    
    
});
// Prevent dragstart from allowing dragging that opens new window/tab
document.addEventListener('dragstart', function(event) {
  if (event.target.tagName === 'IMG') {
    event.preventDefault();
  }
});

// Additionally, prevent default drop behavior anywhere on the page
document.addEventListener('drop', function(event) {
  event.preventDefault();
});

// Also prevent dragover default behavior so drop event fires properly
document.addEventListener('dragover', function(event) {
  event.preventDefault();
});
// (function() {
//   const threshold = 160;  // threshold for detection (can adjust)

//   function detectDevTools() {
//     const widthThreshold = window.outerWidth - window.innerWidth > threshold;
//     const heightThreshold = window.outerHeight - window.innerHeight > threshold;
//     return widthThreshold || heightThreshold;
//   }

//   function handleDevTools() {
//     if (detectDevTools()) {
//       alert("Developer tools detected! Access to this page is restricted.");
//       // Clear page content
//       document.body.innerHTML = "";
//       // Or redirect to another page, e.g.,
//       // window.location.href = "about:blank";
//     }
//   }

//   // Run check every 1 second (you can adjust timing)
//   setInterval(handleDevTools, 1000);
// })();

</script>

<script>
    
    let lastClickTime = 0;
  document.addEventListener('click', function(event) {
    const now = Date.now();
    if (now - lastClickTime < 500) { // less than 500ms between clicks
      event.preventDefault();
      event.stopImmediatePropagation();
      return false;
    }
    lastClickTime = now;
  }, true);
  
 

    
    // Disable right-click
    document.addEventListener('contextmenu', e => e.preventDefault());
    
        // Disable copy, cut, paste
        ['copy', 'cut', 'paste'].forEach(evt =>
          document.addEventListener(evt, e => e.preventDefault())
        );
        
      document.addEventListener('keydown', e => {
          if (
            e.key === 'F12' ||
            (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key)) ||
            (e.ctrlKey && ['u', 'p'].includes(e.key.toLowerCase())) ||
            e.keyCode === 44 // try detect PrintScreen via keyCode
          ) {
            e.preventDefault();
        
            if (e.keyCode === 44) {
              alert('Screenshots are disabled on this page.');
              document.body.style.filter = 'blur(8px)';
              setTimeout(() => {
                document.body.style.filter = '';
              }, 3000);
            }
          }
        });

</script>

<!-- begin::  Add To Cart Color Varient Active -->
<script>
$(document).on('click', '.vart_menu_clr', function() {
    $('.vart_menu_clr').removeClass('active');
    $(this).addClass('active');
});
$(document).on('click', '.vart_menu_sz', function() {
    $('.vart_menu_sz').removeClass('active');
    $(this).addClass('active');
});
</script>
<!-- end::  Add To Cart Color Varient Active -->



<!-- begin::  List Max Text Size Tooltip -->
<script>
'use strict';
document.addEventListener('DOMContentLoaded', () => {
    const maxChars = 55;
    const elements = document.querySelectorAll('.mk_name');

    elements.forEach(el => {
        const fullText = el.textContent.trim();
        el.setAttribute('title', fullText);
        if (fullText.length > maxChars) {
            el.textContent = fullText.slice(0, maxChars) + '...';
        }
        bootstrap.Tooltip.getOrCreateInstance(el);
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const maxChars = 90;
    const elements = document.querySelectorAll('.mk_cart_name');

    elements.forEach(el => {
        const fullText = el.textContent.trim();
        el.setAttribute('title', fullText);
        if (fullText.length > maxChars) {
            el.textContent = fullText.slice(0, maxChars) + '...';
        }
        bootstrap.Tooltip.getOrCreateInstance(el);
    });
});
</script>
<!-- end::  List Max Text Size Tooltip -->

<!-- begin::  Refine Results Show & Hide -->
<script>
function sidebar_func() {
    const sidebar = document.getElementById("sidebar_tbox");
    const content = document.getElementById("cont_tbox");
    var cont_indv_tbox = document.querySelectorAll('.cont_indv_tbox');


    if (sidebar.style.display === "block") {
        sidebar.classList.add("fade-out");
        content.classList.remove("col-lg-9");
        content.classList.add("col-lg-12");
        cont_indv_tbox.forEach(el => {
            el.classList.remove("col-lg-4");
            el.classList.add("col-lg-3");
        });
        setTimeout(() => {
            sidebar.style.display = "none";
            sidebar.classList.remove("fade-out");
        }, 500);
    } else {
        sidebar.style.display = "block";
        sidebar.classList.remove("fade-out");
        content.classList.remove("col-lg-12");
        content.classList.add("col-lg-9");
        cont_indv_tbox.forEach(el => {
            el.classList.remove("col-lg-3");
            el.classList.add("col-lg-4");
        });
    }
}
</script>
<!-- end::  Refine Results Show & Hide -->

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const toggleIcons = document.querySelectorAll('.menu_1_icon');

        toggleIcons.forEach(function (iconLink) {
            iconLink.addEventListener('click', function () {
                const cardHeader = this.closest('.card-header');
                const cardContainer = cardHeader.closest('.col-lg-12');
                const menuBody = cardContainer.querySelector('.menu_1_body');
                const icon = this.querySelector('i');

                // Toggle collapse
                if (menuBody.classList.contains('show')) {
                    menuBody.classList.remove('show');
                    menuBody.style.display = 'none';

                    // Toggle icon to down
                    icon.classList.remove('mdi-chevron-up');
                    icon.classList.add('mdi-chevron-down');
                } else {
                    menuBody.classList.add('show');
                    menuBody.style.display = 'block';

                    // Toggle icon to up
                    icon.classList.remove('mdi-chevron-down');
                    icon.classList.add('mdi-chevron-up');
                }
            });
        });
    });
</script>
<script>
document.querySelectorAll('.hover-emboss-color').forEach(item => {
    item.addEventListener('click', function() {
        // Remove active class from all items
        document.querySelectorAll('.hover-emboss-color').forEach(el => {
            el.classList.remove('active');
        });

        // Add active class to the clicked one
        this.classList.add('active');
    });
});
</script>
<script>
  function pauseVideo() {
    const video = document.getElementById('video_player');
    if (video && !video.paused) {
      video.pause();
    }
  }
</script>
@endsection