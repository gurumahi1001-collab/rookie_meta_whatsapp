@extends('layouts/layoutMaster')

@section('title', 'Manage Training Document')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite('resources/assets/js/forms_file_upload.js')
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 300px;
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }
</style>

<!-- Add this CSS to your stylesheet -->
<style>
    /* Upload Preview Styles */
    .file-preview {
        display: none;
        margin-top: 1rem;
        padding: 0.75rem;
        background: #f8f9fa;
        border-radius: 6px;
        border: 1px solid #e9ecef;
    }

    .file-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .file-icon {
        color: #4299e1;
        font-size: 1.5rem;
    }

    .file-details {
        flex: 1;
        overflow: hidden;
    }

    .file-name {
        font-weight: 500;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 0.875rem;
    }

    .file-size {
        font-size: 0.75rem;
        color: #6c757d;
    }

    .mini-progress {
        height: 3px;
        background: #e9ecef;
        border-radius: 3px;
        margin-top: 0.5rem;
        overflow: hidden;
    }

    .mini-progress-bar {
        height: 100%;
        width: 0%;
        background: #4299e1;
        transition: width 0.3s ease;
    }

    /* Centered Upload Loader */
    .upload-loader {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(255,255,255,0.9);
        z-index: 9999;
        display: none;
    }

    .loader-content {
        text-align: center;
        max-width: 300px;
        padding: 2rem;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .modal-open .upload-loader {
        z-index: 99999;
    }

    .loader-spinner {
        width: 50px;
        height: 50px;
        border: 4px solid rgba(66, 153, 225, 0.2);
        border-radius: 50%;
        border-top-color: #4299e1;
        animation: spin 1s linear infinite;
        margin: 0 auto 1.5rem;
    }

    .loader-text {
        font-size: 1rem;
        margin-bottom: 0.5rem;
        color: #2d3748;
    }

    .loader-percent {
        font-weight: 600;
        color: #4299e1;
        font-size: 0.875rem;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Button loading state */
    .btn-loading {
        position: relative;
        pointer-events: none;
    }

    .btn-loading:after {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        width: 20px;
        height: 20px;
        margin: -10px 0 0 -10px;
        border: 2px solid rgba(255, 255, 255, 0.5);
        border-top-color: white;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    .upload-loader .spinner-border {
        width: 3rem;
        height: 3rem;
        animation: spin 0.8s linear infinite;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Training Document</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Support Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_add_align_document">
                    <span class="me-2"><i class="mdi mdi-arrow-all "></i></span>Align Document
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_add_training_document">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Training Document
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        
        <div class="row mb-4">
            @php $perpage_count = $perpage ? $perpage : 10; @endphp
            <div class="col-lg-2">
                <span>Show</span>
                <br>
                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                    onchange="sort_filter(this.value);">
                    @php
                    $options = [10, 25, 100, 500]; // Define available options
                    @endphp
                    @php foreach ($options as $option): @endphp
                    <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                        @php echo $option; @endphp
                    </option>
                    @php endforeach; @endphp
                </select>
            </div>
            <div class="col-lg-10 d-flex align-items-end justify-content-end">
                <form id="search_form" method="POST" action="/support/manage_training_document">
                    @csrf
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div>
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                value="@php echo $perpage ? $perpage : 10; @endphp" />
                            <input type="text" class="form-control" id="search_fill" name="search_fill"
                                value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                            onclick="search_filter_func()">Search</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Training Name</th>
                            <th class="min-w-100px">Category</th>
                            <th class="min-w-100px">Sub Category</th>
                            <th class="min-w-100px text-center">Training Mode</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @if (isset($ListTable))
                        @foreach ($ListTable as $i=> $list)
                        <tr>
                            <td>
                                <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list->traning_name }}">{{ $list->traning_name
                                    }}</div>
                            </td>
                            <td>
                                <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list->category_name }}">{{
                                    $list->category_name }}</div>
                            </td>
                            <td>
                                <div class="text-truncate max-w-260px" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="{{ $list->sub_cat_name }}">{{ $list->sub_cat_name
                                    }}</div>
                            </td>

                            <td class="text-center">
                                @if($list->traning_mode == 0)
                                <label
                                    class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">Text</label>
                                @elseif($list->traning_mode == 1)
                                <label
                                    class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">Video</label>
                                @elseif($list->traning_mode == 2)
                                <label class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">PDF</label>
                                @elseif($list->traning_mode == 4)
                                <label class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">Audio</label>
                                @elseif($list->traning_mode == 5)
                                <label class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">Image</label>
                                @elseif($list->traning_mode == 6)
                                <label class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">PPT</label>
                                @elseif($list->traning_mode == 3)
                                <label class="badge bg-label-info rounded border border-info fw-semibold text-info fs-7 px-2 py-1">Link</label>
                                @endif

                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" {{ $list->status == 0 ? 'checked' : ''
                                    }} onchange="SwitchStatus('{{ $list->sno }}', this.checked)" />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <span class="text-center">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                        onclick="openEditModal('{{ $list->sno }}')"
                                        data-bs-target="#kt_modal_edit_training_document" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Edit">
                                        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                    </a>
                                    <a href="javascript:;"
                                        onclick="confirmDelete('{{ $list->sno }}','{{ $list->traning_name }}','{{ $list->category_name??'' }}')"
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_delete_training_document">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                        </span>
                                    </a>
                                </span>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Training Document-->
<div class="modal fade" id="kt_modal_add_training_document" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-6 text-black">Create Training Document</h3>
                </div>
                <form action="{{ route('create_manage_training_document') }}" method="POST" id="add_training_form"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="cat_id" name="cat_id"
                                onchange="CatChange(this.value)">
                                <option value="">Select Training Category</option>
                                @if (isset($categories))
                                @foreach ($categories as $cat_list)
                                <option value="{{ $cat_list->sno }}">{{ $cat_list->category_name }}</option>
                                @endforeach
                                @endif
                            </select>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Sub Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="sub_cat_id" name="sub_cat_id">
                                <option value="">Select Training Sub Category</option>
                            </select>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Training Name" id="training_name"
                                name="training_name" maxlength="70" />
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Mode<span
                                    class="text-danger">*</span></label>
                            <div class="d-flex mt-4">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="text_mode"
                                        value="0" checked onclick="showSection('text')">
                                    <label class="form-check-label fs-6 fw-semibold" for="text_mode">Text</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="video_mode"
                                        value="1" onclick="showSection('video')">
                                    <label class="form-check-label fs-6 fw-semibold" for="video">Video</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="pdf_mode"
                                        value="2" onclick="showSection('pdf')">
                                    <label class="form-check-label fs-6 fw-semibold" for="pdf">PDF</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="link_mode"
                                        value="3" onclick="showSection('link')">
                                    <label class="form-check-label fs-6 fw-semibold">Link</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="audio_mode"
                                        value="4" onclick="showSection('audio')">
                                    <label class="form-check-label fs-6 fw-semibold">Audio</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="image_mode"
                                        value="5" onclick="showSection('image')">
                                    <label class="form-check-label fs-6 fw-semibold">Image</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode" id="ppt_mode"
                                        value="6" onclick="showSection('ppt')">
                                    <label class="form-check-label fs-6 fw-semibold">PPT</label>
                                </div>

                            </div>
                        </div>

                        <div class="form-repeater_jorn_bklt_create">
                            <div data-repeater-list="group-a_jorn_bklt">
                                <div data-repeater-item>
                                    <div class="row booklet_row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                                    class="text-danger">*</span></label>
                                            <select class="select3 form-select dept-select" id="dept_id_0"
                                                name="dept_id[]">
                                                <option value="">Select Training Department</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Role<span
                                                    class="text-danger">*</span></label>
                                            <select class="select3 form-select" id="role_id_0" name="role_id[0][]" data-placeholder="Select Role" multiple>
                                                <!-- Options will be populated by JavaScript -->
                                            </select>
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;"
                                                class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del"
                                                style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="bookletContainer"></div>

                        <div class="mb-4 mt-2">
                            <button type="button" class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1"
                                id="jorn_bklt_create_add">
                                <i class="mdi mdi-plus me-1"></i> Add More
                            </button>
                        </div>

                    </div>                    
                    
                    <div class="row px-2 py-2" id="show_video">
                    <div class="col-lg-12">
                        <div class="row">
                            <label class="text-black mb-2 fs-6 fw-semibold">Upload Video <span class="text-danger">*</span></label>
                            <div class="d-flex flex-column">
                                <label for="videoUploadInput" class="btn btn-primary mb-2 align-self-start">
                                    <i class="mdi mdi-file-video me-1"></i> Select Video
                                </label>
                                <input type="file" id="videoUploadInput" name="video_upload" class="d-none"
                                    accept="video/mp4,video/webm,video/ogg">
                                <p class="small text-muted">Supports MP4, WebM, OGG • Max 100MB</p>
                
                                <div class="file-preview" id="filePreview">
                                    <div class="file-info">
                                        <div class="file-icon">
                                            <i class="mdi mdi-file-video"></i>
                                        </div>
                                        <div class="file-details">
                                            <div class="file-name" id="fileName"></div>
                                            <div class="file-size" id="fileSize"></div>
                                        </div>
                                    </div>
                                    <div class="mini-progress">
                                        <div class="mini-progress-bar" id="miniProgressBar"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="text-danger mt-1" id="video_upload_err"></div>
                        </div>
                    </div>
                </div>
                
                    <!-- Centered Upload Loader -->
                    <div class="upload-loader" id="uploadLoader" style="display: none;">
                        <div class="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                            <div class="bg-white rounded p-4 shadow-lg text-center" style="width: 320px;">
                                <div class="spinner-border text-primary mb-3" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <h5 class="mb-2">Uploading...</h5>
                                <div class="progress mb-2" style="height: 6px;">
                                    <div id="loaderProgressBar" class="progress-bar" role="progressbar" style="width: 0%"></div>
                                </div>
                                <small class="text-muted" id="loaderPercent">0% completed</small>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row px-2 py-2" id="show_audio">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-black mb-2 fs-6 fw-semibold">Upload Audio <span
                                        class="text-danger">*</span></label>
                                <div class="d-flex flex-column">
                                    <label for="audioUploadInput" class="btn btn-primary mb-2 align-self-start">
                                        <i class="mdi mdi-file-video me-1"></i> Select Audio
                                    </label>
                                    <input type="file" id="audioUploadInput" name="audio_upload" class="d-none"
                                        accept="audio/*">
                                    <p class="small text-muted">Supports MP4, WebM, OGG • Max 100MB</p>

                                    <div class="file-preview" id="audioFilePreview">
                                        <div class="file-info">
                                            <div class="file-icon">
                                                <i class="mdi mdi-file-music"></i>
                                            </div>
                                            <div class="file-details">
                                                <div class="file-name" id="audioFileName"></div>
                                                <div class="file-size" id="audioFileSize"></div>
                                            </div>
                                        </div>
                                        <div class="mini-progress">
                                            <div class="mini-progress-bar" id="audioMiniProgressBar"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-danger mt-1" id="audio_upload_err"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Centered Upload Loader Audio -->
                    <div class="upload-loader" id="uploadLoader" style="display: none;">
                        <div
                            class="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                            <div class="bg-white rounded p-4 shadow-lg text-center" style="width: 320px;">
                                <div class="spinner-border text-primary mb-3" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <h5 class="mb-2">Uploading...</h5>
                                <div class="progress mb-2" style="height: 6px;">
                                    <div id="loaderProgressBar" class="progress-bar" role="progressbar"
                                        style="width: 0%"></div>
                                </div>
                                <small class="text-muted" id="loaderPercent">0% completed</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- PDF PPT -->
                    <div class="row px-2 py-2" id="show_ppt">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Upload PPT <span
                                        class="text-danger">*</span></label>
                                <div class="row">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{ asset('assets/egc_images/def_ppt.png') }}" alt="Attachment"
                                            class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                            id="ppt_attach_upload_img" />
                                        <div class="fs-7 text-success mt-2" id="ppt_attach_upload_name"></div>
                                        <div class="button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label  class="btn btn-sm btn-primary me-2" tabindex="0"
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="Upload File">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" id="ppt_upload" name="attachment_ppt"
                                                       class="ppt_attach_upload_cls" hidden
                                                       accept=".ppt,.pptx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation" />

                                                </label>
                                                <button type="button"
                                                    class="btn btn-sm btn-outline-danger ppt_attach_upload-reset"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small">Allowed PDF file only. Max size of 25MB</div>
                                        </div>
                                    </div>
                                    <div class="text-danger" id="fav_upload_err"></div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    
                    <!-- PDF Image -->
                    <div class="row px-2 py-2" id="show_image">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Upload Image <span
                                        class="text-danger">*</span></label>
                                <div class="row">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{ asset('assets/egc_images/def_img.png') }}" alt="Attachment"
                                            class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                            id="img_attach_upload_img" />
                                        <div class="fs-7 text-success mt-2" id="img_attach_upload_name"></div>
                                        <div class="button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label for="img_upload" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="Upload File">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" id="img_upload" name="attachment_img"
                                                        class="img_attach_upload_cls" hidden accept="image/png, image/jpeg" />
                                                </label>
                                                <button type="button"
                                                    class="btn btn-sm btn-outline-danger img_attach_upload-reset"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small">Allowed PDF file only. Max size of 25MB</div>
                                        </div>
                                    </div>
                                    <div class="text-danger" id="fav_upload_err"></div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    
                    <!-- PDF Show -->
                    <div class="row px-2 py-2" id="show_pdf">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Upload PDF <span
                                        class="text-danger">*</span></label>
                                <div class="row">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{ asset('assets/egc_images/def_pdf.png') }}" alt="Attachment"
                                            class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                            id="attach_upload" />
                                        <div class="fs-7 text-success mt-2" id="attach_upload_name"></div>
                                        <div class="button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                    data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="Upload File">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" id="fav_upload" name="attachment"
                                                        class="attach_upload_cls" hidden accept="application/pdf" />
                                                </label>
                                                <button type="button"
                                                    class="btn btn-sm btn-outline-danger attach_upload-reset"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small">Allowed PDF file only. Max size of 25MB</div>
                                        </div>
                                    </div>
                                    <div class="text-danger" id="fav_upload_err"></div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    
                    <!-- Text Show -->
                    <div class="row px-2 py-2 " id="show_text">
                        <input type="hidden" name="add_text" id="add_text">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Content <span
                                        class="text-danger">*</span></label>
                                <div id="create_training_content" class="scroll-y max-h-300px">
                                    <div class="ql-editor" data-gramm="false" contenteditable="true"
                                        data-placeholder="Type Something...">
                                    </div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    <!-- Link Show -->
                    <div class="row px-2 py-2 " id="show_link">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Link <span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="2" name="link" id="link" placeholder="Enter Link"></textarea>
                            </div>
                            <div class="link_err text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="create_training">Create Training
                            Document</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Training Document-->

<!--begin::Modal - Add Training Document-->
<div class="modal fade" id="kt_modal_add_align_document" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-6 text-black">Align Training Document</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Training Category</label>
                        <select class="select3 form-select" id="cat_id_alg" name="cat_id_alg" onchange="CatChange_align(this.value)">
                            <option value="">Select Training Category</option>
                            @if (isset($categories))
                            @foreach ($categories as $cat_list)
                            <option value="{{ $cat_list->sno }}">{{ $cat_list->category_name }}</option>
                            @endforeach
                            @endif
                        </select>
                        <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Training Sub Category</label>
                        <select class="select3 form-select" id="sub_cat_id_alg" name="sub_cat_id_alg" onchange="SubChange_align(this.value)">
                            <option value="">Select Training Sub Category</option>
                        </select>
                        <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                    </div>
                    <div class="col-lg-12 mb-3" id="traning_align_div">
                        
                    </div>
                </div>   
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Training Document-->

<!--begin::Modal - Edit Training Document-->
<div class="modal fade" id="kt_modal_edit_training_document" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-6 text-black">Update Training Document</h3>
                </div>
                <form action="{{ route('update_manage_training_document') }}" method="POST" id="edit_training_form"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="edit_cat_id" name="edit_cat_id"
                                onchange="EditCatChange(this.value)">
                                <option value="">Select Category</option>
                                @if (isset($categories))
                                @foreach ($categories as $cat_list)
                                <option value="{{ $cat_list->sno }}">{{ $cat_list->category_name }}</option>
                                @endforeach
                                @endif
                            </select>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <input type="hidden" name="edit_id" id="edit_id">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Sub Category<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="edit_sub_cat_id" name="edit_sub_cat_id">
                            </select>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Training Name"
                                id="edit_training_name" name="edit_training_name" />
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Training Mode<span
                                    class="text-danger">*</span></label>
                            <div class="d-flex mt-4">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode_edit" value="0"
                                        onclick="showSection_edit('text_edit')" checked>
                                    <label class="form-check-label fs-6 fw-semibold" for="text">Text</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode_edit" value="1"
                                        onclick="showSection_edit('video_edit')">
                                    <label class="form-check-label fs-6 fw-semibold" for="video">Video</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode_edit" value="2"
                                        onclick="showSection_edit('pdf_edit')">
                                    <label class="form-check-label fs-6 fw-semibold" for="pdf">PDF</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="training_mode_edit" value="3"
                                        onclick="showSection_edit('link_edit')" checked>
                                    <label class="form-check-label fs-6 fw-semibold" for="text">Link</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-repeater_jorn_bklt_edit">
                            <div data-repeater-list="group-a_jorn_bklt_edit">
                                <div data-repeater-item>
                                    <div class="row booklet_row_edit">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                            <select class="select3 form-select dept-select-edit" id="edit_dept_id_0" name="dept_id[]">
                                                <option value="">Select Training Department</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                                            <select class="select3 form-select" id="edit_role_id_0" name="role_id[0][]"
                                                data-placeholder="Select Role" multiple>
                                                <!-- Options will be populated by JavaScript -->
                                            </select>
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_edit_del"
                                                style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="bookletEditContainer"></div>
                        
                        <div class="mb-4 mt-2">
                            <button type="button" class="btn btn-sm btn-primary jorn_bklt_edit_add fs-8 px-2 py-1" id="jorn_bklt_edit_add">
                                <i class="mdi mdi-plus me-1"></i> Add More
                            </button>
                        </div>

                        <div class="row px-2 py-2" id="show_video_edit">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-black mb-2 fs-6 fw-semibold">Update Video <span class="text-danger">*</span></label>
                                <div class="d-flex flex-column">
                                    <!-- Current video display -->
                                    <div class="current-video mb-3" id="currentVideoContainer" style="display: none;">
                                        <div class="alert alert-info d-flex align-items-center">
                                            <i class="mdi mdi-information-outline me-2"></i>
                                            <div>
                                                <span>Current Video: </span>
                                                <a href="#" id="currentVideoLink" target="_blank" class="text-primary"></a>
                                                <button type="button" class="btn btn-sm btn-outline-danger ms-2" id="deleteCurrentVideo">
                                                    <i class="mdi mdi-delete"></i> Remove
                                                </button>
                                                <input type="hidden" id="existingVideoName" name="existing_video_name">
                                            </div>
                                        </div>
                                    </div>
                    
                                    <!-- Upload new video -->
                                    <label for="videoUploadInputEdit" class="btn btn-primary mb-2 align-self-start">
                                        <i class="mdi mdi-file-video me-1"></i> Select New Video
                                    </label>
                                    <input type="file" id="videoUploadInputEdit" name="video_upload_edit" class="d-none"
                                        accept="video/mp4,video/webm,video/ogg">
                                    <p class="small text-muted">Supports MP4, WebM, OGG • Max 400MB</p>
                    
                                    <div class="file-preview" id="filePreviewEdit">
                                        <div class="file-info">
                                            <div class="file-icon">
                                                <i class="mdi mdi-file-video"></i>
                                            </div>
                                            <div class="file-details">
                                                <div class="file-name" id="fileNameEdit"></div>
                                                <div class="file-size" id="fileSizeEdit"></div>
                                            </div>
                                        </div>
                                        <div class="mini-progress">
                                            <div class="mini-progress-bar" id="miniProgressBarEdit"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-danger mt-1" id="video_upload_err_edit"></div>
                            </div>
                        </div>
                    </div>
                    
                        <!-- Shared Upload Loader (same as your add form) -->
                        <div class="upload-loader" id="uploadLoaderEdit" style="display: none;">
                            <div class="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                                <div class="bg-white rounded p-4 shadow-lg text-center" style="width: 320px;">
                                    <div class="spinner-border text-primary mb-3" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <h5 class="mb-2">Uploading...</h5>
                                    <div class="progress mb-2" style="height: 6px;">
                                        <div id="loaderProgressBarEdit" class="progress-bar" role="progressbar" style="width: 0%"></div>
                                    </div>
                                    <small class="text-muted" id="loaderPercentEdit">0% completed</small>
                                </div>
                            </div>
                        </div>

                        <div class="row px-2 py-2" id="show_pdf_edit">
                        <div class="col-lg-12">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Upload PDF <span
                                        class="text-danger">*</span></label>
                                <div class="row">
                                    <img src="{{ asset('assets/egc_images/def_pdf.png') }}" alt="Attachment"
                                        class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                        id="attach_upload_edit" />
                                    <div class="fs-7 text-success mt-2" id="attach_upload_name_edit"></div>
                                    <div class="button-wrapper">
                                        <div class="d-flex align-items-start mt-2 mb-2">
                                            <label for="fav_upload_edit" class="btn btn-sm btn-primary me-2"
                                                tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top"
                                                title="Upload File">
                                                <i class="mdi mdi-tray-arrow-up"></i>
                                                <input type="file" id="fav_upload_edit" name="attachment_edit"
                                                    class="attach_upload_cls_edit" hidden accept="application/pdf" />
                                            </label>
                                            <button type="button"
                                                class="btn btn-sm btn-outline-danger attach_upload_reset_edit"
                                                data-bs-toggle="tooltip" data-bs-placement="top" title="Reset File">
                                                <i class="mdi mdi-reload"></i>
                                            </button>
                                        </div>
                                        <div class="small">Allowed PDF file only. Max size of 25MB</div>
                                    </div>
                                    <div class="text-danger" id="fav_upload_err_edit"></div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>

                        <div class="row px-2 py-2 " id="show_text_edit">
                        <div class="col-lg-12">
                            <input type="hidden" name="edit_text" id="edit_text">
                            <div class="row">
                                <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Content</label>
                                <div id="create_training_content_edit" class="scroll-y max-h-300px">
                                    <div class="ql-editor" data-gramm="false" contenteditable="true"
                                        data-placeholder="Type Something...">
                                    </div>
                                </div>
                            </div>
                            <div class="error_msg text-danger fw-semibold mt-1 fs-7"></div>
                        </div>
                    </div>
                    
                        <!-- Link Show -->
                        <div class="row px-2 py-2 " id="show_link_edit">
                            <div class="col-lg-12">
                                <div class="row">
                                    <label class="text-danger fs-5 fw-semibold mt-1 mb-2">Link <span class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="2" name="link_edit" id="link_edit" placeholder="Enter Link"></textarea>
                                </div>
                                <div class="link_edit_err text-danger fw-semibold mt-1 fs-7"></div>
                            </div>
                        </div>
                    
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="update_training">Update Training
                            Document</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Training Document-->


<!--begin::Modal - Delete Training Document-->
<div class=" modal fade" id="kt_modal_delete_training_document" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Training Document?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label id="del_product">-</label>
                    <span class="ms-2 me-2">-</span>
                    <label id="del_category">-</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" onclick="delete_confirm()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Branch-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
</style>

<script>
    // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
</script>

<!-- Edit Video Uploading -->
<script>
    function initSortable() {
        var el = document.querySelector('.task-container');
        if (!el) return;
    
        new Sortable(el, {
            animation: 150,
            onEnd: function (evt) {
                // After drag/drop finished, get the new order
                let order = [];
                $('.task-container li').each(function(index){
                    order.push({
                        id: $(this).data('id'),
                        order_id: index + 1 // or index, depending on your logic
                    });
                });
    
                // Send order to server
                saveNewOrder(order);
            },
        });
    }
    function saveNewOrder(order) {
        $.ajax({
            url: "{{ route('save_document_order') }}",  // You need to create this route & controller
            type: "POST",
            data: {
                order: order,
                _token: '{{ csrf_token() }}'  // CSRF token for POST
            },
            success: function(response) {
                if(response.status === 200){
                    toastr.success('Training Document Aligned successfully');
                } else {
                    toastr.error('Failed to save document order');
                }
            },
            error: function(error) {
                console.error('Error saving order:', error);
            }
        });
    }



    function showCurrentVideo(videoPath) {
            if (videoPath) {
                const videoUrl = `{{ asset('training_document/videos') }}/${videoPath}`;
                $('#currentVideoLink').attr('href', videoUrl).text(videoPath);
                $('#existingVideoName').val(videoPath);
                $('#currentVideoContainer').show();
            } else {
                $('#currentVideoContainer').hide();
            }
        }

    $(document).ready(function() {
        // Edit form elements
        const fileInputEdit = $('#videoUploadInputEdit');
        const filePreviewEdit = $('#filePreviewEdit');
        const fileNameEdit = $('#fileNameEdit');
        const fileSizeEdit = $('#fileSizeEdit');
        const miniProgressBarEdit = $('#miniProgressBarEdit');
        const uploadLoaderEdit = $('#uploadLoaderEdit');
        const loaderPercentEdit = $('#loaderPercentEdit');
        const submitBtnEdit = $('#update_training'); // Update button ID
        const videoUploadErrEdit = $('#video_upload_err_edit');
        const currentVideoContainer = $('#currentVideoContainer');
        const currentVideoLink = $('#currentVideoLink');
        const deleteCurrentVideoBtn = $('#deleteCurrentVideo');
        const existingVideoName = $('#existingVideoName');

        // Delete current video handler
        deleteCurrentVideoBtn.on('click', function() {
            existingVideoName.val(''); // This will signal backend to delete the file
            currentVideoContainer.hide();
            filePreviewEdit.hide();
            fileInputEdit.val('');
        });

        // File selection handler for edit
        fileInputEdit.on('change', function() {
            const file = fileInputEdit[0].files[0];
            if (!file) return;
            
            // Validate file
            const validTypes = ['video/mp4', 'video/webm', 'video/ogg'];
            const maxSize = 400 * 1024 * 1024; // 100MB
            
            if (!validTypes.includes(file.type)) {
                videoUploadErrEdit.text('Please select a valid video file (MP4, WebM, or OGG)');
                return;
            }
            
            if (file.size > maxSize) {
                videoUploadErrEdit.text('File size must be less than 400MB');
                return;
            }
            
            // Clear errors
            videoUploadErrEdit.text('');
            
            // Show file preview
            fileNameEdit.text(file.name);
            fileSizeEdit.text(formatFileSize(file.size));
            filePreviewEdit.show();
            
            // Simulate quick local processing progress
            let progress = 0;
            const interval = setInterval(() => {
                progress += 10;
                if (progress >= 100) {
                    clearInterval(interval);
                    miniProgressBarEdit.css('width', '100%');
                } else {
                    miniProgressBarEdit.css('width', progress + '%');
                }
            }, 30);
        });

        // Edit form submission handler
        $('#edit_training_form').on('submit', function(e) {
            let isValid = true;

            const requiredFields = [
                { id: '#edit_cat_id', msg: 'Select Category.' },
                { id: '#edit_sub_cat_id', msg: 'Select Sub Category.' },
                { id: '#edit_training_name', msg: 'Training Name is Required.' }
            ];

            $('.error_msg').hide().text('');
            $('#fav_upload_err_edit').text('');

            requiredFields.forEach(field => {
                const value = $(field.id).val();
                if (!value || value.trim() === '') {
                    isValid = false;
                    $(field.id).closest('.mb-3').find('.error_msg').text(field.msg).show();
                }
            });

            const editBookletRows = $('.booklet_row_edit');
            $('#bookletEditContainer .bk_edit_err').remove();

            let hasValidRow = false;

            editBookletRows.each(function() {
                const $deptSelect = $(this).find('select[name="dept_id[]"]');
                const $roleSelect = $(this).find('select[id^="edit_role_id_"]');
                let rowIsValid = true;

                $(this).find('.bk_edit_err').remove();

                if (!$deptSelect.val()) {
                    rowIsValid = false;
                    $deptSelect.closest('.mb-1').append('<div class="error_msg bk_edit_err text-danger fw-semibold mt-1 fs-7">Department is required.</div>');
                }

                if (!$roleSelect.val() || $roleSelect.val().length === 0) {
                    rowIsValid = false;
                    $roleSelect.closest('.mb-1').append('<div class="error_msg bk_edit_err text-danger fw-semibold mt-1 fs-7">At least one role is required.</div>');
                }

                if (rowIsValid) {
                    hasValidRow = true;
                }
            });

            if (!hasValidRow) {
                isValid = false;
                if (editBookletRows.length === 0) {
                    $('#bookletContainer').append('<div class="error_msg bk_edit_err text-danger fw-semibold mt-1 fs-7">At least one department and role must be selected.</div>');
                }
            }

            // Validate video is selected if video mode
            const editSelectedMode = $('input[name="training_mode_edit"]:checked').val();

            if (editSelectedMode === '1' && !fileInputEdit[0].files.length && !existingVideoName.val()) {
                videoUploadErrEdit.text('Please select a video file or keep the existing one');
                uploadLoaderEdit.hide();
                isValid = false;
            } else if (editSelectedMode === '0') {
                // Text mode
                const quillEditor = $('#create_training_content_edit .ql-editor');
                const contentText = quillEditor.text().trim();

                if (!contentText) {
                    isValid = false;
                    $('#show_text_edit').find('.error_msg').text('Content is required.').show();
                } else {
                    $('#edit_text').val(quillEditor.html());
                }
            } else if (editSelectedMode === '2') {
                const fileInput = $('#fav_upload_edit')[0];
                const errorContainer = $('#show_pdf_edit').find('.error_msg');

                if (!fileInput.files || fileInput.files.length === 0) {
                    if (!$('#attach_upload_name_edit').text().trim()) {
                        isValid = false;
                        errorContainer.text('Please upload a PDF file.').show();
                    }
                } else {
                    const file = fileInput.files[0];
                    if (file.type !== 'application/pdf') {
                        isValid = false;
                        errorContainer.text('Only PDF files are allowed.').show();
                    } else if (file.size > 25 * 1024 * 1024) {
                        isValid = false;
                        errorContainer.text('File size should not exceed 25MB.').show();
                    }
                }
            }
            else if (editSelectedMode === '3') {
                const link = $('#link_edit').val();
                if (link == '') {
                    isValid = false;
                    $('.link_edit_err').html('Link is required.');
                }
            }

            if (!isValid) {
                e.preventDefault();
            } else {
                uploadLoaderEdit.show();
                loaderPercentEdit.text('0% completed');
                $('#loaderProgressBarEdit').css('width', '0%');
                
                // Disable submit button
                submitBtnEdit.prop('disabled', true).addClass('btn-loading');
                
                // Create FormData
                const formData = new FormData(this);
                
                // AJAX request with progress tracking
                $.ajax({
                    url: $(this).attr('action'),
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    xhr: function() {
                        const xhr = new window.XMLHttpRequest();
                        
                        xhr.upload.addEventListener('progress', function(e) {
                            if (e.lengthComputable) {
                                const percent = Math.round((e.loaded / e.total) * 100);
                                $('#loaderProgressBarEdit').css('width', percent + '%');
                                $('#loaderPercentEdit').text(percent + '% completed');
                            }
                        }, false);

                        return xhr;
                    },
                    beforeSend: function() {
                        // Ensure loader is visible before request starts
                        uploadLoaderEdit.show();
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            location.reload();
                            toastr.success(response.message);

                        } else {
                            toastr.error(response.message || 'Update failed');
                        }
                    },
                    error: function(xhr) {
                        let errorMessage = 'Upload failed. Please try again.';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMessage = xhr.responseJSON.message;
                        }
                        toastr.error(errorMessage);
                    },
                    complete: function() {
                        // Hide loader only after everything is done
                        setTimeout(() => {
                            uploadLoaderEdit.hide();
                            submitBtnEdit.prop('disabled', false).removeClass('btn-loading');
                        }, 500);
                    }
                });
            }  
        });

        function formatFileSize(bytes) {
            if (bytes < 1024) return bytes + ' Bytes';
            if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
            return (bytes/1048576).toFixed(1) + ' MB';
        }
    });
</script>

<!-- Edit Data Fetch -->
<script>
    // Define all variables and functions at the top to avoid reference errors
    let editTrainingCounter = 0;
    let allDepartmentsEdit = [];
    let allRolesEdit = [];

    // Department Fetch - moved to top to ensure data is loaded early
    fetch(`/department`)
    .then(res => res.json())
    .then(data => {
        allDepartmentsEdit = Array.isArray(data) ? data : data.data || [];
        updateAllEditDepartmentDropdowns();
    })
    .catch(err => console.error('Failed to fetch departments:', err));

    // Role Fetch
    fetch('/user_role')
    .then(res => res.json())
    .then(data => {
        allRolesEdit = Array.isArray(data) ? data : data.data || [];
        // Initialize the first role select after roles are loaded
        if (document.getElementById('edit_role_id_0')) {
            document.getElementById('edit_role_id_0').innerHTML = generateRoleOptionsEdit([]);
        }
    })
    .catch(err => console.error('Failed to fetch roles:', err));

    // Helper functions
    function getSelectedEditDepartmentIds() {
        const selected = [];
        document.querySelectorAll('.dept-select-edit').forEach(select => {
            if (select.value) {
                selected.push(select.value);
            }
        });
        return selected;
    }

    function generateDepartmentOptionsEdit(excludeIds = []) {
        if (!allDepartmentsEdit.length) return '';
        return allDepartmentsEdit
            .filter(dept => !excludeIds.includes(dept.sno.toString()))
            .map(dept => `<option value="${dept.sno}">${dept.department_name}</option>`)
            .join('');
    }

    function generateRoleOptionsEdit(selectedIds = []) {
        if (!allRolesEdit.length) return '<option value="">No roles available</option>';
        return allRolesEdit.map(role => {
            const selected = selectedIds.includes(role.sno.toString()) ? 'selected' : '';
            return `<option value="${role.sno}" ${selected}>${role.role_name}</option>`;
        }).join('');
    }

    function updateAllEditDepartmentDropdowns() {
        const selectedIds = getSelectedEditDepartmentIds();
        document.querySelectorAll('.dept-select-edit').forEach(select => {
            const currentVal = select.value;
            const options = `<option value="">Select Department</option>` + 
                generateDepartmentOptionsEdit(selectedIds.filter(id => id !== currentVal));
            
            select.innerHTML = options;
            select.value = currentVal;
        });
    }

    // Main edit modal function
    window.openEditModal = function(id) {
        editTrainingCounter = 0; // Reset counter
        $('#bookletEditContainer').empty(); // Clear existing rows
        
        $.ajax({
            url: `/training_document_edit/${id}`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status === 200) {
                    const data = response.data;
                    
                    // Handle main form fields
                    $('#edit_id').val(data.sno);
                    $('#edit_cat_id').val(data.training_category_id).trigger('change');
                    setTimeout(() => $('#edit_sub_cat_id').val(data.training_sub_category_id).trigger('change'), 2000);
                    $('#edit_training_name').val(data.traning_name);
                    
                    // Handle training mode specific fields
                    if(data.traning_mode == 0) {
                        showSection_edit("text_edit");
                        $('input[name="training_mode_edit"][value="0"]').prop('checked', true);
                        window.training_edit.root.innerHTML = data.text_content || '';
                    } 
                    else if(data.traning_mode == 1) {
                        showSection_edit("video_edit");
                        $('input[name="training_mode_edit"][value="1"]').prop('checked', true);
                        
                        // Show current video if exists
                        if(data.video_link) {
                            showCurrentVideo(data.video_link);
                        } else {
                            currentVideoContainer.hide();
                        }
                    }
                    else if(data.traning_mode == 3) {
                        showSection_edit("link_edit");
                        $('input[name="training_mode_edit"][value="3"]').prop('checked', true);
                        
                        // Show current video if exists
                        $('#link_edit').val(data.link);
                    }
                    else {
                        showSection_edit("pdf_edit");
                        $('input[name="training_mode_edit"][value="2"]').prop('checked', true);
                        if(data.pdf_id) {
                            const pdfUrl = `{{ asset('training_document') }}/${data.pdf_id};`;
                            $('#attach_upload_edit').attr('src', "{{ asset('assets/egc_images/Document_verified.jpg') }}");
                            $('#attach_upload_name_edit').html(`
                                <a href="${pdfUrl}" target="_blank" style="color: #198754; text-decoration: underline;">
                                    ${data.pdf_id}
                                </a>
                            `);
                        }
                    }
                    
                    // Handle department/role data
                    try {
                        const deptIds = JSON.parse(data.dept_id);
                        const roleIds = JSON.parse(data.role_ids);
                        
                        if (deptIds.length > 0) {
                            const firstDeptId = deptIds[0];
                            const firstRoleIds = roleIds[0] || [];
                            
                            $('#edit_dept_id_0').val(firstDeptId).trigger('change');
                            
                            setTimeout(() => {
                                $('#edit_role_id_0').val(firstRoleIds).trigger('change');
                            }, 300);
                            
                            // Additional rows
                            for (let i = 1; i < deptIds.length; i++) {
                                editTrainingCounter++;
                                const currentDeptId = deptIds[i];
                                const currentRoleIds = roleIds[i] || [];
                                
                                const selectedDeptIds = deptIds.slice(0, i);
                                const deptOptions = generateDepartmentOptionsEdit(selectedDeptIds);
                                
                                const newRow = `
                                    <div class="row booklet_row_edit mt-1">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                            <select class="select3 form-select dept-select-edit" id="edit_dept_id_${editTrainingCounter}" name="dept_id[]">
                                                <option value="">Select Training Department</option>
                                                ${deptOptions}
                                            </select>
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                                            <select class="select3 form-select" id="edit_role_id_${editTrainingCounter}" name="role_id[${editTrainingCounter}][]" multiple>
                                                ${generateRoleOptionsEdit(currentRoleIds)}
                                            </select>
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_edit_del">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>`;
                                
                                $('#bookletEditContainer').append(newRow);
                                
                                // Initialize and set values for new selects
                                $(`#edit_dept_id_${editTrainingCounter}`).val(currentDeptId).trigger('change');
                                
                                setTimeout(() => {
                                    $(`#edit_role_id_${editTrainingCounter}`).val(currentRoleIds).trigger('change');
                                }, 300);
                                
                                // Initialize Select2 for new elements
                                $(`#edit_dept_id_${editTrainingCounter}, #edit_role_id_${editTrainingCounter}`).each(function() {
                                    $(this).wrap('<div class="position-relative"></div>').select2({
                                        dropdownParent: $(this).parent()
                                    });
                                });
                            }
                        }
                    } catch (e) {
                        console.error('Error parsing department/role data:', e);
                    }
                    
                    // Initialize all select2 elements in the modal
                    $('.select3').each(function() {
                        if (!$(this).hasClass('select2-hidden-accessible')) {
                            $(this).wrap('<div class="position-relative"></div>').select2({
                                dropdownParent: $(this).parent()
                            });
                        }
                    });
                }
            },
            error: function(error) {
                console.error('Error fetching data:', error);
            }
        });
    };

    // Event handlers
    $(document).ready(function() {
        // Add more button
        $('#jorn_bklt_edit_add').on('click', function() {
            editTrainingCounter++;
            const selectedDeptIds = getSelectedEditDepartmentIds();
            const deptOptions = generateDepartmentOptionsEdit(selectedDeptIds);
            const roleOptions = generateRoleOptionsEdit([]);

            const newRow = `
                <div class="row booklet_row_edit mt-1">
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                        <select class="select3 form-select dept-select-edit" id="edit_dept_id_${editTrainingCounter}" name="dept_id[]">
                            <option value="">Select Training Department</option>
                            ${deptOptions}
                        </select>
                    </div>
                    <div class="col-lg-5 mb-1">
                        <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="edit_role_id_${editTrainingCounter}" name="role_id[${editTrainingCounter}][]" multiple>
                            ${roleOptions}
                        </select>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_edit_del">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>`;

            $('#bookletEditContainer').append(newRow);
            
            // Initialize Select2 for new elements
            $(`#edit_dept_id_${editTrainingCounter}, #edit_role_id_${editTrainingCounter}`).each(function() {
                $(this).wrap('<div class="position-relative"></div>').select2({
                    dropdownParent: $(this).parent()
                });
            });

            updateAllEditDepartmentDropdowns();
        });

        // Delete button
        $(document).on('click', '.jorn_bklt_edit_del', function() {
            $(this).closest('.booklet_row_edit').remove();
            updateAllEditDepartmentDropdowns();
        });

        // Department change handler
        $(document).on('change', '.dept-select-edit', function() {
            updateAllEditDepartmentDropdowns();
        });

        // Initialize modal on show
        $('#editModal').on('shown.bs.modal', function() {
            $('.select3').each(function() {
                if (!$(this).hasClass('select2-hidden-accessible')) {
                    $(this).wrap('<div class="position-relative"></div>').select2({
                        dropdownParent: $(this).parent()
                    });
                }
            });
        });
    });
</script>

<!-- Sort Filter -->
<script>
    function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
            }
        }
</script>

<!-- Data Table -->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<!-- Add Video Handling and Animation and Validation -->
<script>
    $(document).ready(function() {
    const fileInput = $('#videoUploadInput');
    const filePreview = $('#filePreview');
    const fileName = $('#fileName');
    const fileSize = $('#fileSize');
    const miniProgressBar = $('#miniProgressBar');
    const uploadLoader = $('#uploadLoader');
    const loaderPercent = $('#loaderPercent');
    const submitBtn = $('#create_training');
    const videoUploadErr = $('#video_upload_err');
    const form = $('#add_training_form');
    
    // Audio Logic
    const audioInput = $('#audioUploadInput');
    const audioFilePreview = $('#audioFilePreview');
    const audioFileName = $('#audioFileName');
    const audioFileSize = $('#audioFileSize');
    const audioMiniProgressBar = $('#audioMiniProgressBar');
    const audioUploadErr = $('#audio_upload_err');

    // File selection handler
    fileInput.on('change', function() {
        const file = fileInput[0].files[0];
        if (!file) return;
        
        // Validate file
        const validTypes = ['video/mp4', 'video/webm', 'video/ogg'];
        const maxSize = 400 * 1024 * 1024; // 100MB
        
        if (!validTypes.includes(file.type)) {
            videoUploadErr.text('Please select a valid video file (MP4, WebM, or OGG)');
            return;
        }
        
        if (file.size > maxSize) {
            videoUploadErr.text('File size must be less than 400MB');
            return;
        }
        
        // Clear errors
        videoUploadErr.text('');
        
        // Show file preview
        fileName.text(file.name);
        fileSize.text(formatFileSize(file.size));
        filePreview.show();
        
        // Simulate quick local processing progress
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            if (progress >= 100) {
                clearInterval(interval);
                miniProgressBar.css('width', '100%');
            } else {
                miniProgressBar.css('width', progress + '%');
            }
        }, 30);
    });
    
    audioInput.on('change', function() {
        const file = audioInput[0].files[0];
        if (!file) return;

        // Allowed audio types
        const validTypes = ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4']; // add types you want
        const maxSize = 100 * 1024 * 1024; // 100MB

        if (!validTypes.includes(file.type)) {
            audioUploadErr.text('Please select a valid audio file (MP3, WAV, OGG, MP4)');
            return;
        }

        if (file.size > maxSize) {
            audioUploadErr.text('File size must be less than 100MB');
            return;
        }

        // Clear error
        audioUploadErr.text('');

        // Show preview
        audioFileName.text(file.name);
        audioFileSize.text(formatFileSize(file.size));
        audioFilePreview.show();

        // Simulate progress bar
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            if (progress >= 100) {
                clearInterval(interval);
                audioMiniProgressBar.css('width', '100%');
            } else {
                audioMiniProgressBar.css('width', progress + '%');
            }
        }, 30);
    });

    // Form submission handler
    form.on('submit', function(e) {            
        e.preventDefault(); // Prevent default form submission
        
        let isValid = true;

        // Clear all error messages first
        $('.error_msg').remove();

        // Validate basic required fields
        const requiredFields = [
            { id: '#cat_id', msg: 'Select Category.' },
            { id: '#sub_cat_id', msg: 'Select Sub Category.' },
            { id: '#training_name', msg: 'Training Name is Required.' }
        ];

        requiredFields.forEach(field => {
            const value = $(field.id).val();
            if (!value || value.trim() === '') {
                isValid = false;
                $(field.id).closest('.mb-3').append(`<div class="error_msg text-danger fw-semibold mt-1 fs-7">${field.msg}</div>`);
            }
        });

        // Validate department and roles
        const bookletRows = $('.booklet_row');
        let hasValidRow = false;

        bookletRows.each(function(index) {
            const $deptSelect = $(this).find('select[name="dept_id[]"]');
            const $roleSelect = $(this).find(`select[name="role_id[${index}][]"]`);
            let rowIsValid = true;

            if (!$deptSelect.val()) {
                rowIsValid = false;
                $deptSelect.closest('.mb-1').append('<div class="error_msg text-danger fw-semibold mt-1 fs-7">Department is required.</div>');
            }

            if (!$roleSelect.val() || $roleSelect.val().length === 0) {
                rowIsValid = false;
                $roleSelect.closest('.mb-1').append('<div class="error_msg text-danger fw-semibold mt-1 fs-7">At least one role is required.</div>');
            }

            if (rowIsValid) {
                hasValidRow = true;
            }
        });

        if (!hasValidRow) {
            isValid = false;
            $('#bookletContainer').append('<div class="error_msg text-danger fw-semibold mt-1 fs-7">At least one department and role must be selected.</div>');
        }
        
        // Validate content based on training mode
        const selectedMode = $('input[name="training_mode"]:checked').val();

        if (selectedMode === '1' && !fileInput[0].files.length) {
            videoUploadErr.text('Please select a video file');
            isValid = false;
        } else if (selectedMode === '0') {
            const contentHtml = $('#create_training_content .ql-editor').html().trim();
            if (!contentHtml || contentHtml === '<p><br></p>') {
                isValid = false;
                $('#show_text').append('<div class="error_msg text-danger fw-semibold mt-1 fs-7">Content is required.</div>');
            } else {
                $('#add_text').val(contentHtml);
            }
        } else if (selectedMode === '2') {
            const pdfInput = $('#fav_upload')[0];
            if (!pdfInput.files || pdfInput.files.length === 0) {
                isValid = false;
                $('#show_pdf').append('<div class="error_msg text-danger fw-semibold mt-1 fs-7">Please upload a PDF file.</div>');
            }
        }
        else if (selectedMode === '3') {
            const link = $('#link').val();
            if (link == '') {
                isValid = false;
                $('.link_err').html('Link is required.');
            }
        }
        else if(selectedMode === '4' && !audioInput[0].files.length) {
            audioUploadErr.text('Select an audio file.');
            isValid = false;
        }

        if (!isValid) {
            return false;
        }

        // Disable submit button and show loading state
        submitBtn.prop('disabled', true).addClass('btn-loading');
        
        // Show loader
        uploadLoader.show();
        
        // Create FormData
        const formData = new FormData(form[0]);
        
        // AJAX request with progress tracking
        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        $('#loaderProgressBar').css('width', percent + '%');
                        loaderPercent.text(percent + '% completed');
                    }
                }, false);

                return xhr;
            },
            success: function(response) {
                if (response.toastr) {
                    toastr[response.toastr.type](response.toastr.message);
                }
                
                if (response.status === 200) {
                    // Close modal after delay
                    setTimeout(function() {
                        $('#kt_modal_add_training_document').modal('hide');
                    }, 1500);
                    
                    location.reload();
                }
            },
            error: function(xhr) {
                let errorMessage = 'Failed to create training document';
                if (xhr.responseJSON && xhr.responseJSON.toastr) {
                    toastr[xhr.responseJSON.toastr.type](xhr.responseJSON.toastr.message);
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    toastr.error(xhr.responseJSON.message);
                } else {
                    toastr.error(errorMessage);
                }
            },
            complete: function() {
                // Re-enable submit button and hide loader
                submitBtn.prop('disabled', false).removeClass('btn-loading');
                uploadLoader.hide();
            }
        });
    });

    // Helper function to format file size
    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' Bytes';
        if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
        return (bytes/1048576).toFixed(1) + ' MB';
    }
});
</script>

<!-- Add Department -->
<script>
    let trainingCounter = 0;
    let allDepartments = [];
    let allRoles = [];

    // Department Fetch
    fetch(`/department`)
    .then(res => res.json())
    .then(data => {
        allDepartments = Array.isArray(data) ? data : data.data || [];
        updateAllDepartmentDropdowns();
        populateInitialRoleSelect(); // Populate initial role select after departments load
    })
    .catch(err => console.error('Failed to fetch departments:', err));

    // Role Fetch
    fetch('/user_role')
    .then(res => res.json())
    .then(data => {
        allRoles = Array.isArray(data) ? data : data.data || [];
        populateInitialRoleSelect(); // Populate role selects when roles are loaded
    })
    .catch(err => console.error('Failed to fetch roles:', err));

    function getSelectedDepartmentIds() {
        const selected = [];
        document.querySelectorAll('select[name="dept_id[]"]').forEach(select => {
            if (select.value) {
                selected.push(select.value);
            }
        });
        return selected;
    }

    function generateDepartmentOptions(excludeIds = []) {
        return allDepartments
            .filter(dept => !excludeIds.includes(dept.sno.toString()))
            .map(dept => `<option value="${dept.sno}">${dept.department_name}</option>`)
            .join('');
    }

    function generateRoleOptions(selectedIds = []) {
        if (!allRoles.length) return '<option value="">No roles available</option>';
        return allRoles.map(role => {
            const selected = selectedIds.includes(role.sno.toString()) ? 'selected' : '';
            return `<option value="${role.sno}" ${selected}>${role.role_name}</option>`;
        }).join('');
    }

    // New function to populate initial role select
    function populateInitialRoleSelect() {
        if (!allRoles.length || !document.getElementById('role_id_0')) return;
        const roleSelect = document.getElementById('role_id_0');
        roleSelect.innerHTML = generateRoleOptions([]);
        
        // Reinitialize Select2 if it exists
        if ($(roleSelect).hasClass('select2-hidden-accessible')) {
            $(roleSelect).select2('destroy');
        }
        $(roleSelect).select2({
            dropdownParent: $(roleSelect).parent()
        });
    }

    document.getElementById('jorn_bklt_create_add').addEventListener('click', function () {
        trainingCounter++;
        const selectedDeptIds = getSelectedDepartmentIds();
        const deptOptions = generateDepartmentOptions(selectedDeptIds);

        const newBookleteDetails = `
            <div class="row booklet_row mt-1">
                <div class="col-lg-5 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                    <select class="select3 form-select dept-select" id="dept_id_${trainingCounter}" name="dept_id[]">
                        <option value="">Select Training Department</option>
                        ${deptOptions}
                    </select>
                </div>
                <div class="col-lg-5 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Role<span class="text-danger">*</span></label>
                    <select class="select3 form-select" id="role_id_${trainingCounter}" name="role_id[${trainingCounter}][]" data-placeholder="Select Role" multiple>
                        ${generateRoleOptions([])}
                    </select>
                </div>
                <div class="col-lg-2 mb-1">
                    <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
            </div>`;

        document.getElementById('bookletContainer').insertAdjacentHTML('beforeend', newBookleteDetails);

        // Initialize Select2 for new elements
        $(`#dept_id_${trainingCounter}, #role_id_${trainingCounter}`).each(function() {
            $(this).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(this).parent()
            });
        });

        updateAllDepartmentDropdowns();
    });

    $(document).on('click', '.jorn_bklt_create_del', function () {
        $(this).closest('.booklet_row').remove();
        updateAllDepartmentDropdowns();
    });

    $(document).on('change', '.dept-select', function () {
        updateAllDepartmentDropdowns();
    });

    function updateAllDepartmentDropdowns() {
        const selectedIds = getSelectedDepartmentIds();
        $('select.dept-select').each(function () {
            const currentVal = this.value;
            const $select = $(this);
            const options = `<option value="">Select Department</option>` + 
                generateDepartmentOptions(selectedIds.filter(id => id !== currentVal));
            
            $select.html(options).val(currentVal);
        });
    }

    // Initialize existing selects on page load
    $(document).ready(function() {
        $('.select3').each(function() {
            $(this).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(this).parent()
            });
        });
    });
</script>

<!-- Delete -->
<script>
    function CatChange(val){
        if(val){
            $.ajax({
                url: "{{ route('traning_subcat_list') }}",
                type: "GET",
                data: { cat_id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        console.log(response.data)
                        var entityDropdown = $('#sub_cat_id');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Training Sub Category</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.sub_cat_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       }else{
           var entityDropdown = $('#sub_cat_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Training Sub Category</option>');
       }
    }
    function CatChange_align(val){
        if(val){
            $.ajax({
                url: "{{ route('traning_subcat_list') }}",
                type: "GET",
                data: { cat_id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        console.log(response.data)
                        var entityDropdown = $('#sub_cat_id_alg');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Training Sub Category</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.sub_cat_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       }else{
           var entityDropdown = $('#sub_cat_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Training Sub Category</option>');
       }
    }
    
    function SubChange_align(val){
        if(val){
            $.ajax({
                url: "{{ route('traning_subcat_document_list') }}",
                type: "GET",
                data: { cat_id: val },
                success: function(response) {
                    if (response.status === 200 && response.html) {
                        // Append or replace the content inside #traning_align_div
                        $('#traning_align_div').html(response.html);
                        initSortable();
                        const containers = document.querySelectorAll('.task-container');
                        containers.forEach(container => {
                            new Sortable(container, {
                                group: 'shared', // allow drag between containers
                                animation: 150,
                                ghostClass: 'sortable-ghost',
                                fallbackOnBody: true,
                                swapThreshold: 0.65
                            });
                        });
                
                        new Sortable(document.getElementById('sort_card'), {
                            animation: 150,
                            ghostClass: 'sortable-ghost'
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
       } else {
           // Optionally clear or handle empty value here
           $('#traning_align_div').html('');
       }
    }

    
    

    function EditCatChange(val){
        if(val){
            $.ajax({
                url: "{{ route('traning_subcat_list') }}",
                type: "GET",
                data: { cat_id: val },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        console.log(response.data)
                        var entityDropdown = $('#edit_sub_cat_id');
                        entityDropdown.empty();
                        entityDropdown.append('<option value="">Select Training Sub Category</option>');
                        response.data.forEach(function(Data) {
                            entityDropdown.append($('<option></option>').attr('value', Data.sno).text(Data.sub_cat_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching states:', error);
                }
            });
        }else{
            var entityDropdown = $('#edit_sub_cat_id');
            entityDropdown.empty();
            entityDropdown.append('<option value="">Select Training Sub Category</option>');
        }
    }
    
    function confirmDelete(sno, name,cat) {
        document.querySelector('#kt_modal_delete_training_document .btn-danger').setAttribute('data-id', sno);
        $('#del_product').html(name);
        $('#del_category').html(cat);
    }
    function delete_confirm() {
    
        var delete_id = document.querySelector('#kt_modal_delete_training_document .btn-danger').getAttribute('data-id');
    
        fetch('/training_document_delete/' + delete_id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Training Document Deleted successfully!');
                    location.reload();
    
                } else {
    
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
        
        
</script>

<!-- Status Change -->
<script>
    function SwitchStatus(UniversityId, isChecked) {
      const status = isChecked ? 0 : 1; // Set status based on checkbox state

      fetch(`/manage_training_document_status/${UniversityId}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
              },
              body: JSON.stringify({
                  status: status
              })
          })
          .then(response => response.json())
          .then(data => {
              if (data.status === 200) {
                  console.log('Training Document Status updated successfully:', data.message);
                  toastr.success('Training Document Status Updated successfully!');
              } else {
                  console.error('Error updating Training Document Status:', data.message);
                  toastr.error('Error updating Training Document Status');
              }
          })
          .catch(error => {
              console.error('Error updating Training Document status:', error);
          });
    }
</script>

<!-- Add Hide / Show -->
<script>
    function showSection(type) {
        // Hide all sections
        document.getElementById("show_video").style.display = "none";
        document.getElementById("show_pdf").style.display = "none";
        document.getElementById("show_text").style.display = "none";
        document.getElementById("show_link").style.display = "none";
        document.getElementById("show_audio").style.display = "none";
        document.getElementById("show_image").style.display = "none";
        document.getElementById("show_ppt").style.display = "none";

        // Show the selected one
        if (type === "video") {
            document.getElementById("show_video").style.display = "block";
        } else if (type === "pdf") {
            document.getElementById("show_pdf").style.display = "block";
        } else if (type === "text") {
            document.getElementById("show_text").style.display = "block";
        } else if(type === "link") {
            document.getElementById("show_link").style.display = "block";
        } else if(type === "audio") {
            document.getElementById("show_audio").style.display = "block";
        } else if(type === "image") {
            document.getElementById("show_image").style.display = "block";
        } else if(type === "ppt") {
            document.getElementById("show_ppt").style.display = "block";
        }
    }

    // Optional: hide all on page load
    document.addEventListener("DOMContentLoaded", function() {
        showSection("text"); // Hide all by default
    });
</script>

<!--Add PPT Upload-->
<script>
    const pptAttachUpload = document.getElementById('ppt_upload');
    const pptAttachUploadFileInput = document.querySelector('.ppt_attach_upload_cls');
    const pptAttachUploadResetBtn = document.querySelector('.ppt_attach_upload-reset');

    if (pptAttachUpload) {
        const defaultImage = "{{ asset('assets/egc_images/def_ppt.png') }}";
        const verifiedImage = "{{ asset('assets/egc_images/ver_ppt.png') }}";

        pptAttachUploadFileInput.onchange = () => {
            // alert('changed')
            if (pptAttachUploadFileInput.files[0]) {
                // Show verified document image
                $('#ppt_attach_upload_img').attr('src', verifiedImage);
                $('#ppt_attach_upload_name').html(pptAttachUploadFileInput.files[0].name);
            }
        };

        pptAttachUploadResetBtn.onclick = () => {
            pptAttachUploadFileInput.value = '';
            // Reset back to default image
            $('#ppt_attach_upload_img').attr('src', defaultImage);
            $('#ppt_attach_upload_name').html('');
        };
    }
</script>

<script>
    let logofile_edit = document.getElementById('img_attach_upload_img');
    const imgAttachUpload = document.getElementById('img_upload');
    const imgAttachUploadFileInput = document.querySelector('.img_attach_upload_cls');
    const imgAttachUploadResetBtn = document.querySelector('.img_attach_upload-reset');

    if (imgAttachUpload) {
        const defaultImage = "{{ asset('assets/egc_images/Document.jpg') }}";
        const verifiedImage = "{{ asset('assets/egc_images/Document_verified.jpg') }}";

        imgAttachUploadFileInput.onchange = () => {
            // alert('changed image')
            if (imgAttachUploadFileInput.files[0]) {
                // Show verified document image
                logofile_edit.src = window.URL.createObjectURL(imgAttachUploadFileInput.files[0]);
                // $('#img_attach_upload_img').attr('src', verifiedImage);
                // $('#img_attach_upload_name').html(imgAttachUploadFileInput.files[0].name);
            }
        };

        imgAttachUploadResetBtn.onclick = () => {
            imgAttachUploadFileInput.value = '';
            // Reset back to default image
            $('#img_attach_upload_img').attr('src', defaultImage);
            $('#img_attach_upload_name').html('');
        };
    }
</script>

<!-- Add PDF Uploading -->
<script>
    let attach_upload = document.getElementById('attach_upload');
    const attach_upload_fileInput = document.querySelector('.attach_upload_cls'),
        attach_upload_resetFileInput = document.querySelector('.attach_upload-reset');

    if (attach_upload) {
        const fav_resetImage = attach_upload.src;
        attach_upload_fileInput.onchange = () => {
            if (attach_upload_fileInput.files[0]) {
                // attach_upload.src = window.URL.createObjectURL(attach_upload_fileInput.files[0]);
                const imgUrl = "{{ asset('assets/egc_images/Document_verified.jpg') }}";
                $('#attach_upload').attr('src', imgUrl);
                $('#attach_upload_name').html(attach_upload_fileInput.files[0].name);
            }
        };
        attach_upload_resetFileInput.onclick = () => {
            attach_upload_fileInput.value = '';
            // attach_upload.src = fav_resetImage;
            const imgUrl = "{{ asset('assets/egc_images/Document.jpg') }}";
            $('#attach_upload').attr('src', imgUrl);
            $('#attach_upload_name').html('');
        };
    }
</script>



<!-- Edit Hide / Show -->
<script>
    function showSection_edit(type) {
        // Hide all sections
        document.getElementById("show_video_edit").style.display = "none";
        document.getElementById("show_pdf_edit").style.display = "none";
        document.getElementById("show_text_edit").style.display = "none";
        document.getElementById("show_link_edit").style.display = "none";

        // Show the selected section
        if (type === "video_edit") {
            document.getElementById("show_video_edit").style.display = "block";
        } else if (type === "pdf_edit") {
            document.getElementById("show_pdf_edit").style.display = "block";
        } else if (type === "text_edit") {
            document.getElementById("show_text_edit").style.display = "block";
        }else if(type === "link_edit"){
            document.getElementById("show_link_edit").style.display = "block";
        }
    }
</script>

<!-- Edit PDF Uploading -->
<script>
    let attach_upload_edit = document.getElementById('attach_upload_edit');
  const attach_upload_fileInput_edit = document.querySelector('.attach_upload_cls_edit'),
        attach_upload_resetFileInput_edit = document.querySelector('.attach_upload_reset_edit');

  if (attach_upload_edit) {
    const fav_resetImage_edit = attach_upload_edit.src;

    attach_upload_fileInput_edit.onchange = () => {
      if (attach_upload_fileInput_edit.files[0]) {
        const imgUrl_edit = "{{ asset('assets/egc_images/Document_verified.jpg') }}";
        $('#attach_upload_edit').attr('src', imgUrl_edit);
        $('#attach_upload_name_edit').html(attach_upload_fileInput_edit.files[0].name);
      }
    };

    attach_upload_resetFileInput_edit.onclick = () => {
      attach_upload_fileInput_edit.value = '';
      const imgUrl_edit = "{{ asset('assets/egc_images/Document.jpg') }}";
      $('#attach_upload_edit').attr('src', imgUrl_edit);
      $('#attach_upload_name_edit').html('');
    };
  }
</script>

<!-- Clear Error -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const modals = document.querySelectorAll('.modal');

        modals.forEach(modal => {
            modal.addEventListener('hidden.bs.modal', function () {
            // Reset all forms inside the modal
            modal.querySelectorAll('form').forEach(form => form.reset());

            // Clear all error messages
            modal.querySelectorAll('.text-danger').forEach(el => {
                if (el.textContent.trim() === '*') return;
                el.textContent = '';
            });

            // Clear hidden inputs (optional)
            modal.querySelectorAll('input[type="hidden"]').forEach(input => {
                input.value = '';
            });

            // Reset all selects
            modal.querySelectorAll('select').forEach(select => {
                select.selectedIndex = 0;

                // If using Select2 or similar, trigger update
                if ($(select).hasClass('select3')) {
                $(select).val('').trigger('change');  // reset to empty or default value
                }
            });
            });
        });
    });
</script>


@endsection