@extends('layouts/layoutMaster')

@section('title', 'Support Ticket')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn{
        width: 100%;
        height: 100%;
        display:none;
        color:black;
        background-color:rgba(0,0,0,0.2);
    }

    .document-thumbnail:hover .view-btn{
        display:flex;
        justify-content:center;
        align-items:center;
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */

     .hover-zoom {
        transition: .25s;
    }
    .hover-zoom:hover {
        transform: scale(1.05);
    }
</style>

<style>
    .flow-preview-box{
        display:flex;
        align-items:center;
        flex-wrap:wrap;
        gap:10px;
        min-height:60px;
    }

    .flow-node{
        padding:8px 14px;
        border-radius:999px;
        background:#eef2ff;
        font-weight:600;
        position:relative;
    }

    .flow-node.start{ background:#dcfce7; }
    .flow-node.hr{ background:#fee2e2; }
    .flow-node.manager{ background:#fef3c7; }

    .flow-arrow{
        font-size:18px;
        color:#9ca3af;
    }
</style>
<style>
    /* ===== MODERN HR LEAVE UI ===== */

    /* Card sections */
    .leave-card{
        background:#f9fafb;
        border-radius:16px;
        padding:18px;
        border:1px solid #e5e7eb;
        margin-bottom:18px;
    }

    /* request selector */
    .request-type-box{
        display:flex;
        gap:20px;
    }

    .type-card{
        flex:1;
        border:2px solid #e5e7eb;
        border-radius:14px;
        padding:10px;
        text-align:center;
        cursor:pointer;
        transition:.25s;
    }

    .type-card:hover{
        transform:translateY(-3px);
        box-shadow:0 12px 30px rgba(0,0,0,.08);
    }

    .type-card.active{
        border-color:#ab2b22;
        background:#fba91936;
    }

    .type-icon{
        font-size:32px;
        margin-bottom:10px;
    }

    /* date planner */
    .leave-date-input{
        background:#ffffff;
        border-radius:14px !important;
        border:1px solid #e5e7eb !important;
        transition:.2s;
    }

    .leave-date-input:hover{
        border-color:#ab2b22 !important;
    }

    /* summary */
    .leave-summary{
        background:#fba91952;
        color:#000000cc;
        border-radius:16px;
        padding:18px;
    }

</style>
<style>
    /* whole modal drop style */
    .drop-zone {
        min-height: 220px;
        border: 2px dashed #d3d3d3;
        border-radius: 12px;
        background: #f8f9fa;
        padding: 30px;
        cursor: pointer;
        transition: 0.25s ease;
    }

    .drop-zone:hover {
        background: #fff1f099;
    }

    .drop-zone.dragover {
        border-color: #ab2b22;
        background: #fff1f099;
    }

    /* preview thumbnails */
    .preview-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
    }

    .preview-item {
        position: relative;
    }

    .preview-item img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 8px;
        border: 1px solid #ddd;
    }

    /* remove button */
    .remove-btn {
        position: absolute;
        top: -6px;
        right: -6px;
        background: #dc3545;
        color: white;
        border: none;
        width: 22px;
        height: 22px;
        font-size: 12px;
        border-radius: 50%;
        cursor: pointer;
    }
</style>
<style>


    /* ================= WRAPPER ================= */
    .chat-wrapper{
        height:600px;
        display:flex;
        flex-direction:column;
        border-radius:18px;
        overflow:hidden;
        background:#fff;
        box-shadow:0 10px 30px rgba(0,0,0,.08);
    }

    /* ================= HEADER ================= */
    .chat-header{
        background:#b22222; /* your sidebar red */
        color:#fff;
        padding:14px 20px;
        display:flex;
        justify-content:space-between;
        align-items:center;
    }

    .chat-header small{
        color:#ffe5e5;
    }

    /* ================= BODY ================= */
    .chat-body{
        flex:1;
        overflow-y:auto;
        padding:20px;
        background:#f4f6fa;
        display:flex;
        flex-direction:column;
        gap:14px;
    }

    /* ================= MESSAGE BASE ================= */
    .msg{
        max-width:68%;
        padding:10px 14px;
        border-radius:16px;
        font-size:14px;
        position:relative;
        line-height:1.5;
        animation:fadeIn .15s ease;
    }

    /* animation */
    @keyframes fadeIn{
        from{opacity:0; transform:translateY(5px)}
        to{opacity:1; transform:translateY(0)}
    }

    /* ================= STAFF (RIGHT) ================= */
    .msg.staff{
        align-self:flex-end;
        background:#b22222;
        color:#fff;
        border-bottom-right-radius:4px;
        box-shadow:0 3px 8px rgba(178,34,34,.25);
    }

    /* ================= IT (LEFT) ================= */
    .msg.it{
        align-self:flex-start;
        background:#ffffff;
        border:1px solid #e2e6ea;
        border-bottom-left-radius:4px;
        box-shadow:0 3px 6px rgba(0,0,0,.05);
    }

    /* ================= TIME + STATUS ================= */
    .msg small{
        display:flex;
        justify-content:flex-end;
        align-items:center;
        font-size:11px;
        margin-top:5px;
        gap:6px;
        opacity:.8;
    }

    /* ticks */
    .tick{
        font-size:13px;
    }

    .tick.read{
        color:#0d6efd;
    }

    /* ================= IMAGES ================= */
    .msg img{
        max-width:180px;
        border-radius:10px;
        margin-top:6px;
        cursor:pointer;
        transition:.2s;
    }
    .msg img:hover{
        transform:scale(1.05);
    }

    /* ================= INPUT ================= */
    .chat-input{
        display:flex;
        align-items:center;
        padding:12px;
        gap:10px;
        background:#fff;
        border-top:1px solid #eee;
    }

    .chat-input input[type=text]{
        flex:1;
        border:1px solid #ddd;
        border-radius:30px;
        padding:10px 15px;
        outline:none;
    }

    .chat-input input[type=text]:focus{
        border-color:#b22222;
    }

    /* buttons */
    .icon-btn{
        background:#f2f2f2;
        border:none;
        width:40px;
        height:40px;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
        transition:.2s;
    }
    .icon-btn:hover{
        background:#e0e0e0;
    }

    .send-btn{
        background:#b22222;
        color:#fff;
        border:none;
        width:42px;
        height:42px;
        border-radius:50%;
        display:flex;
        align-items:center;
        justify-content:center;
    }
    .send-btn:hover{
        opacity:.9;
    }

    /* ================= FILE PREVIEW ================= */
    .file-preview{
        display:flex;
        align-items:center;
        gap:10px;
        padding:8px 15px;
        background:#fff3f3;
        border-top:1px solid #f1d0d0;
    }

    .file-preview img{
        width:40px;
        height:40px;
        border-radius:8px;
        object-fit:cover;
    }

    .remove-file{
        cursor:pointer;
        color:#b22222;
        font-size:20px;
    }

    /* scroll */
    .chat-body::-webkit-scrollbar{
        width:6px;
    }
    .chat-body::-webkit-scrollbar-thumb{
        background:#ccc;
        border-radius:10px;
    }





</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Support Ticket</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> Myself
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                               Support Ticket
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                 <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-end">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_add_ticket_request">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Ticket
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="add_support_ticket" data-bs-toggle="modal" data-bs-target="#addSupportTicketModal">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Support Ticket
                </a>
               
            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
            
            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Status</option>
                        <option value="0">Pending</option>
                        <option value="1">Approved</option>
                        <option value="3">Rejected</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;"  class="filterSubmit" id="filterSubmit" >
                    <span class="btn btn-primary btn-sm" > Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value=""/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                 <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th>Ticket No</th>
                                <th>Subject</th>
                                <th>Department / Category</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Assigned To</th>
                                <th>Created</th>
                                <th>Last Activity</th>
                                <th width="120">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3"  onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->




<div class="modal fade" id="addSupportTicketModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body">
                <div class="text-center">
                    <h5 class="text-black mb-0">
                        <i class="mdi mdi-lifebuoy"></i>
                        Create Support Ticket
                    </h5>
                </div>
                <form id="supportTicketForm" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <!-- Department -->
                        <div class="col-lg-6 mb-3">
                            <label class="fw-semibold">Department<span class="text-danger">*</span></label>
                            <select id="department_id" name="department_id" class="form-select select3" onchange="change_support_department()">
                                <option value="">Select Department</option>
                                @foreach($departmentList as $d)
                                    <option value="{{$d->sno}}">{{$d->department_name}}</option>
                                @endforeach
                            </select>
                            <div class="text-danger" id="department_err"></div>
                        </div>
                        <!-- Category -->
                        <div class="col-lg-6 mb-3">
                            <label class="fw-semibold">Category<span class="text-danger">*</span></label>
                            <select id="category_id" name="category_id" class="form-select select3">
                                <option value="">Select Category</option>
                            </select>
                            <div class="text-danger"id="category_err"></div>
                        </div>
                        <!-- Subject -->
                        <div class="col-lg-12 mb-3">
                            <label class="fw-semibold">Subject<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" maxlength="150"  id="subject" name="subject" placeholder="Short Summary">
                            <div class="text-danger" id="subject_err"></div>
                        </div>
                        <!-- Priority -->
                        <div class="col-lg-4 mb-3">
                            <label class="fw-semibold">Priority<span class="text-danger">*</span></label>
                            <select name="priority" id="priority" class="form-select select3">
                                <option value="Low">Low</option>
                                <option value="Medium" selected>Medium</option>
                                <option value="High">High</option>
                                <option value="Critical">Critical</option>
                            </select>
                        </div>
                        <!-- Attachment -->
                        <div class="col-lg-8 mb-3">
                            <label class="fw-semibold">Attachment</label>
                            <input type="file" class="form-control" id="attachment" name="attachment" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.xls,.xlsx,.zip">
                            <small class="text-muted">Maximum 10 MB</small>
                            <div class="text-danger" id="attachment_err"></div>
                        </div>
                        <!-- Description -->
                        <div class="col-lg-12">
                            <label class="fw-semibold">Description<span class="text-danger">*</span></label>
                            <textarea rows="7" class="form-control" id="description" name="description" placeholder="Explain your issue in detail..."></textarea>
                            <div class="text-danger" id="description_err"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-success" onclick="submitSupportTicket()">
                    <i class="mdi mdi-send"></i>Submit Ticket
                </button>
            </div>
            
        </div>
    </div>
</div>

<!--begin::Modal Filter--->



<div class="modal fade" id="kt_modal_view_ticket" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>

            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black" id="request_title_name">View Ticket</h3>
                </div>
                <div id="ticketDetailBody" class="row g-4"></div>
                <div class="mt-4">
                    <h6 class="fw-bold mb-3 text-muted">
                        <i class="mdi mdi-paperclip me-1"></i> Attachments
                    </h6>

                    <div id="attachmentGallery" class="row g-3"></div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- <div class="modal fade"
     id="ticketViewModal"
     tabindex="-1">

<div class="modal-dialog modal-xl modal-dialog-scrollable">

<div class="modal-content border-0 shadow">

<div class="modal-header bg-label-primary">

<h4 class="mb-0">

<i class="mdi mdi-ticket-confirmation-outline me-2"></i>

Support Ticket

</h4>

<button class="btn-close"
data-bs-dismiss="modal"></button>

</div>

<div class="modal-body p-0"
id="ticketModalBody">

</div>

</div>

</div>

</div> -->


<div class="modal fade" id="kt_modal_chatModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
        
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1 mb-2">
                <div>
                    <h5 class="mb-0">Ticket Chat</h5>
                    <small id="chatTicketNo" class="text-muted"></small>
                </div>
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <div class="chat-wrapper">
                    <!-- BODY -->
                    <div id="chatBody" class="chat-body"></div>

                    <!-- ATTACH PREVIEW -->
                    <div id="filePreview" class="file-preview d-none">
                        <img id="previewImg">
                        <span id="previewName"></span>
                        <i class="mdi mdi-close-circle remove-file" onclick="removeFile()"></i>
                    </div>

                    <!-- INPUT -->
                    <div class="chat-input">

                        <input type="file" id="chatFile" hidden accept="image/*">

                        <button class="icon-btn" onclick="$('#chatFile').click()">
                            <i class="mdi mdi-paperclip mdi-20px"></i>
                        </button>

                        <input type="text" id="chatText"
                            placeholder="Type a message..."
                            onkeydown="if(event.key==='Enter') sendMessage()">

                        <button class="send-btn" onclick="sendMessage()">
                            <i class="mdi mdi-send"></i>
                        </button>

                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>


<!--end::Modal - Filter-->
  


<div class="modal fade" id="assignTicketModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white pb-4">
                <span class="modal-title fs-5 fw">
                    <i class="mdi mdi-account-switch me-2"></i>Assign Ticket
                </span>
                <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="assign_ticket_id">
                <div class="row">
                    <div class="col-lg-12 mb-4">
                        <label class="fw-bold">Assign To<span class="text-danger">*</span></label>
                        <select class="form-select select3" id="assign_staff">

                        </select>
                        <div class="text-danger" id="assign_staff_error"></div>
                    </div>
                    <div class="col-lg-12">
                        <label class="fw-bold">Remarks</label>
                        <textarea class="form-control" rows="4" id="assign_remarks" placeholder="Optional remarks"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" onclick="submitAssignTicket()">
                    <i class="mdi mdi-check-circle"></i>
                    Assign Ticket
                </button>
            </div>
        </div>
    </div>
</div> 

 <div class="modal fade" id="viewTicketModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="text-white mb-0">
                    <i class="mdi mdi-ticket-confirmation"></i>
                    Ticket Details
                </h4>
                <button
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body p-0" id="ticketViewBody">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary"></div>
                    <h6 class="mt-3">
                        Loading Ticket...
                    </h6>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
    function formatTimeCommon(time) {
        if (!time) {
            return '';
        }
        
        const [hours, minutes, seconds] = time.split(':');

        const date = new Date(0); 
        date.setHours(parseInt(hours)); 
        date.setMinutes(parseInt(minutes)); 
        date.setSeconds(parseInt(seconds)); 

        const options = {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true 
        };

        return date.toLocaleTimeString([], options);  
    }
   
    // function buildRow(item,index) {    
        
    //     var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
    //     var category = typeof item.category === 'string' ? JSON.parse(item.category) : item.category;
  
    //     const priorityColor = {
    //         Low: 'secondary',
    //         Normal: 'info',
    //         Urgent: 'danger'
    //     }[item.priority] || 'secondary';

    //     const statusColor = {
    //         0: 'warning',
    //         1: 'primary',
    //         3: 'success'
    //     }[item.status] || 'secondary';
         
    //     return `
    //         <tr>
    //             <td style="position:relative;">
    //                 <span class="fw-bold text-primary fs-7 text-nowrap">
    //                     ${item.ticket_no}
    //                 </span>
    //             </td>
    //             <td>
    //                 <div class="fw-semibold text-dark text-truncate" style="max-width:200px" data-bs-toggle="tooltip" data-bs-placement="bottom"
    //                     title="${item.subject}">
    //                     ${item.subject}
    //                 </div>
                  
    //             </td>
    //             <td>
    //                 <span class="badge bg-light-primary text-primary">
    //                     ${category.category_name}
    //                 </span>
    //             </td>
    //             <td>
    //                 <span class="badge bg-${priorityColor}">
    //                     ${item.priority}
    //                 </span>
    //             </td>
    //             <td>
    //                 <span class="badge bg-${statusColor}">
    //                     ${item.status == 0 ? 'Open' : (item.status == 1 ? 'In progress' : 'Closed')}
    //                 </span>
    //             </td>
    //             <td class="text-muted fs-8 text-nowrap">
    //                 ${data.created_at ? formatDateCommon(data.created_at): '-'}
    //             </td>
    //             <td>
    //               <a href="javascript:;" class="fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_view_ticket" onclick="viewTicket('${item.encrypted_id}')">
    //                     <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"> <i class="mdi mdi-eye fs-3 text-dark "></i></span>
    //                 </a>
                    
    //                 <a href="javascript:;" onclick="openChat(${item.sno},'${item.ticket_no}')" class="text-success position-relative">
    //                     <i class="mdi mdi-message-text-outline fs-5"></i>

    //                     ${item.unread_count > 0 ? `
    //                         <span class="badge bg-danger position-absolute top-0 start-100 translate-middle rounded-circle" style="font-size:8px;">
    //                             ${item.unread_count}
    //                         </span>
    //                     `:''}
    //                 </a>

    //             </td>
    //         </tr>
    //     `;
    // }

    function buildRow(item,index){

const priorityColor={

Low:'secondary',

Medium:'info',

High:'warning',

Urgent:'danger',

Critical:'dark'

};

const statusColor={

Open:'warning',

Assigned:'primary',

'In Progress':'info',

'Waiting Staff':'secondary',

'Waiting Third Party':'dark',

Resolved:'success',

Closed:'success',

Reopened:'danger',

Cancelled:'secondary'

};

return `

<tr>

<td>

<div class="fw-bold text-primary">

${item.ticket_no}

</div>

${item.unread_count>0?`

<span class="badge bg-danger mt-1">

${item.unread_count} New

</span>

`:''}

</td>

<td>

<div class="fw-semibold">

${item.staff_name}

</div>

</td>

<td>

<div class="fw-semibold">

${item.subject}

</div>

<small class="text-muted">

${item.department_name}

/

${item.category_name}

</small>

</td>

<td>

<span class="badge bg-${priorityColor[item.priority]}">

${item.priority}

</span>

</td>

<td>

<span class="badge bg-${statusColor[item.status]}">

${item.status}

</span>

</td>

<td>

${item.assigned_staff?

`<span class="fw-semibold">${item.assigned_staff}</span>`

:

`<span class="badge bg-light-warning text-warning">

Unassigned

</span>`

}

</td>

<td>

${item.created_at?

formatDateCommon(item.created_at)

:''}

</td>

<td>

${item.last_activity?

formatDateCommon(item.last_activity)

:''}

</td>

<td>

${item.sla==1?

`<span class="badge bg-danger">

SLA Breached

</span>`

:

`<span class="badge bg-success">

Within SLA

</span>`

}

</td>

<td>

<div class="dropdown">

<button
class="btn btn-light btn-sm"

data-bs-toggle="dropdown">

<i class="mdi mdi-dots-vertical"></i>

</button>

<ul class="dropdown-menu dropdown-menu-end">

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="viewTicket('${item.encrypted_id}')">

<i class="mdi mdi-eye me-2"></i>

View

</a>

</li>

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="assignTicket('${item.encrypted_id}')">

<i class="mdi mdi-account-arrow-right me-2"></i>

Assign

</a>

</li>

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="replyTicket('${item.encrypted_id}')">

<i class="mdi mdi-reply me-2"></i>

Reply

</a>

</li>

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="changeStatus('${item.encrypted_id}')">

<i class="mdi mdi-progress-check me-2"></i>

Update Status

</a>

</li>

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="resolveTicket('${item.encrypted_id}')">

<i class="mdi mdi-check-circle me-2 text-success"></i>

Resolve

</a>

</li>

<li>

<a
class="dropdown-item"

href="javascript:void(0)"

onclick="closeTicket('${item.encrypted_id}')">

<i class="mdi mdi-lock me-2 text-danger"></i>

Close

</a>

</li>

<li>

<hr class="dropdown-divider">

</li>

<li>

<a
class="dropdown-item text-danger"

href="javascript:void(0)"

onclick="deleteTicket('${item.encrypted_id}')">

<i class="mdi mdi-delete me-2"></i>

Delete

</a>

</li>

</ul>

</div>

</td>

</tr>

`;

}
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = "";
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;

        const url = `/my_self/it_support?page=${page}&sorting_filter=${perpage}&search_filter=${search}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
 
 
 
</script>

<script>
    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>


 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>



<script>
    function validateTicketForm() {

        let isValid = true;

        // clear old errors
        $('.text-danger.small').text('');

        let ip = $('#system_ip').val().trim();
        let category = $('#category_id').val();
        let priority = $('#priority').val();
        let subject = $('#subject').val().trim();
        let description = $('#description').val().trim();

        // IP
        if (!ip) {
            showError('system_ip', 'IP is required');
            isValid = false;
        }

        // Category
        if (!category) {
            showError('category_id', 'Please select category');
            isValid = false;
        }
        // priority
        if (!priority) {
            showError('priority', 'Please select priority');
            isValid = false;
        }

        // Subject
        if (!subject) {
            showError('subject', 'Subject is required');
            isValid = false;
        }

        // Description
        if (!description) {
            showError('description', 'Description is required');
            isValid = false;
        }

        // attachments image validation (optional but safe)
        for (let file of filesArray) {
            if (!file.type.startsWith('image/')) {
                alert('Only image files allowed');
                isValid = false;
            }
        }

        return isValid;
    }
    /* helper */
    function showError(id, message) {
        $(`#${id}`)
            .closest('.col-12, .col-md-6')
            .find('.error-'+id)
            .text(message);
    }
    // On Submit
    $('#submitStaffBtn').click(function() {
        
        if (!validateTicketForm()) {
            // toastr.warning('Please fill all required fields.');
            return;
        }


        const form = document.getElementById("staff_form");
        const formData = new FormData(form);

      
        // Disable submit button and show loader
        $('#submitStaffBtn').prop('disabled', true);
        $('#submitLoader').show();
        $('#submitText').hide();
        let levels = [];
        let leaveData = [];
        let staff_id = $('#staff_hidden_id').val();
        // Collect Leave/Permission details
      

        // AJAX to submit the data
        $.ajax({
            url: form.action,
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                // toastr.success('Leave/Permission request submitted successfully.');
                // $('#kt_modal_add_ticket_request').modal('hide'); // Close the modal
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
                //  location.reload();
            },
            error: function(error) {
                toastr.error('Error while submitting request.');
                console.error('Error:', error);
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
            }
        });
    });
</script>

<script>
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const previewContainer = document.getElementById('previewContainer');

    let filesArray = [];

    /* click anywhere */
    dropZone.addEventListener('click', () => fileInput.click());

    /* drag full area */
    ['dragenter','dragover'].forEach(event =>
        dropZone.addEventListener(event, e => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        })
    );

    ['dragleave','drop'].forEach(event =>
        dropZone.addEventListener(event, e => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        })
    );

    /* drop files */
    dropZone.addEventListener('drop', e => {
        handleFiles(e.dataTransfer.files);
    });

    /* input select */
    fileInput.addEventListener('change', () => {
        handleFiles(fileInput.files);
    });

    /* handle files */
    function handleFiles(files) {
        [...files].forEach(file => {

            if (!file.type.startsWith('image/')) {
                toastr.warning('Only images allowed');
                return;
            }

            filesArray.push(file);
            previewFile(file);
        });

        updateInputFiles();
    }

    /* preview */
    function previewFile(file) {
        const reader = new FileReader();

        reader.onload = function(e) {

            const div = document.createElement('div');
            div.className = 'preview-item';

            div.innerHTML = `
                <img src="${e.target.result}">
                <button type="button" class="remove-btn">&times;</button>
            `;

            div.querySelector('button').onclick = (event) => {
                event.stopPropagation();   // ⭐ important fix

                const index = [...previewContainer.children].indexOf(div);
                filesArray.splice(index, 1);
                div.remove();
                updateInputFiles();
            };
            previewContainer.appendChild(div);
        };

        reader.readAsDataURL(file);
    }
    previewContainer.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    /* update real input */
    function updateInputFiles() {
        const dt = new DataTransfer();
        filesArray.forEach(f => dt.items.add(f));
        fileInput.files = dt.files;
    }
</script>

<script>
    function viewTicketOld(id) {

        $.get('/it-support/view/' + id, function(res){

            if(!res.status) return;

            const t = res.data;

            /* ---------- Attachments Gallery ---------- */

            let gallery = '';

            if (t.attachments.length) {

                t.attachments.forEach(img => {
                    gallery += `
                        <div class="col-md-3 col-6">
                            <a href="/storage/${img}" target="_blank">
                                <img src="/storage/${img}"
                                    class="img-fluid rounded-3 shadow-sm hover-zoom"
                                    style="height:120px;object-fit:cover;">
                            </a>
                        </div>
                    `;
                });

            } else {
                gallery = '<small class="text-muted">No attachments uploaded</small>';
            }

            $('#attachmentGallery').html(gallery);


            /* ---------- Ticket Info Card ---------- */

            $('#ticketDetailBody').html(`
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">

                            <div class="mb-3">
                                <small class="text-muted">Ticket No</small>
                                <div class="fw-bold fs-5 text-primary">${t.ticket_no}</div>
                            </div>

                            <div class="mb-3">
                                <small class="text-muted">Subject</small>
                                <div class="fw-semibold">${t.subject}</div>
                            </div>

                            <div>
                                <small class="text-muted">Description</small>
                                <div class="mt-1">${t.description}</div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">

                            <div class="d-flex justify-content-between mb-3">
                                <span>Category</span>
                                <span class="fw-semibold">${t.category}</span>
                            </div>

                            <div class="d-flex justify-content-between mb-3">
                                <span>Priority</span>
                                ${getPriorityBadge(t.priority)}
                            </div>

                            <div class="d-flex justify-content-between">
                                <span>Status</span>
                                ${getStatusBadge(t.status)}
                            </div>

                        </div>
                    </div>
                </div>
            `);

            $('#kt_modal_view_ticket').modal('show');
        });
    }

    function getStatusBadge(status) {
        switch (parseInt(status)) {
            case 0:
                return '<span class="badge bg-warning text-dark">Open</span>';
            case 1:
                return '<span class="badge bg-info">In Progress</span>';
            case 3:
                return '<span class="badge bg-success">Closed</span>';
            default:
                return '<span class="badge bg-secondary">Unknown</span>';
        }
    }

    function getPriorityBadge(priority) {
        const p = priority.toLowerCase();

        if (p === 'urgent')
            return '<span class="badge bg-danger">Urgent</span>';

        if (p === 'low')
            return '<span class="badge bg-secondary">Low</span>';

        return '<span class="badge bg-primary">Normal</span>';
    }
</script>
  <script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script>
    let currentTicket = null;

    function openChat(id,ticket_no)
    {
        currentTicket = id;

        $('#chatTicketNo').text(ticket_no);

        $('#kt_modal_chatModal').modal('show');

        loadMessages();
    }


    function loadMessages()
    {
        $.get('/it-support/chat/'+currentTicket+'?receiver_type=it',function(res){

           


            let html='';

            res.messages.forEach(m=>{

                let side = m.sender_type=='staff'?'staff':'it';

                let tick = '';

                if(side==='staff'){
                    if(m.is_read==0)
                        tick='<span class="tick">✓</span>';
                    else
                        tick='<span class="tick read">✓✓</span>';
                }

                html += `
                    <div class="msg ${side}">
                        ${m.message ?? ''}

                        ${m.attachment ?
                            `<br><img src="/storage/${m.attachment}" width="120">`
                        :''}

                        <small class="d-flex justify-content-end gap-1">
                            ${moment(m.created_at).format('hh:mm A')}
                            ${tick}
                        </small>
                    </div>
                `;
            });

            $('#chatBody').html(html);

            $('#chatBody').animate({
                scrollTop: $('#chatBody')[0].scrollHeight
            },200);
        });
    }

  

    $('#chatFile').on('change',function(e){

        let file = e.target.files[0];
        if(!file) return;

        $('#previewName').text(file.name);

        let reader = new FileReader();

        reader.onload = function(ev){
            $('#previewImg').attr('src',ev.target.result);
        };

        reader.readAsDataURL(file);

        $('#filePreview').removeClass('d-none');
    });

    function removeFile()
    {
        $('#chatFile').val('');
        $('#filePreview').addClass('d-none');
    }



    function sendMessage()
    {
        let text = $('#chatText').val();
        let file = $('#chatFile')[0].files[0];

        let fd = new FormData();
        fd.append('ticket_id',currentTicket);
        fd.append('message',text);
        fd.append('type','staff');
        if(file) fd.append('attachment',file);

        $.ajax({
            url:'/it-support/chat/send',
            method:'POST',
            data:fd,
            processData:false,
            contentType:false,
            headers:{'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')},
            success:function(){
                $('#chatText').val('');
                $('#chatFile').val('');
                loadMessages();
            }
        });
    }

    // setInterval(()=>{
    //     if($('#kt_modal_chatModal').hasClass('show')){
    //         loadMessages();
    //     }
    // },4000);

</script>
<script>
    function change_support_department(){

        let id=$('#department_id').val();

        $('#category_id').html('<option>Loading...</option>');

        $.get('/support/category/'+id,function(res){

            let option='<option value="">Select Category</option>';

            $.each(res.data,function(i,v){

                option+=`
                <option value="${v.sno}">
                    ${v.category_name}
                </option>`;
            });

            $('#category_id').html(option);

        });

    }
</script>
<script>
    function submitSupportTicket(){
        $('.text-danger').html('');
        let form=new FormData(document.getElementById('supportTicketForm'));
        $.ajax({
            url:'/support/store',
            type:'POST',
            data:form,
            processData:false,
            contentType:false,
            beforeSend:function(){
                $('.btn-success').prop('disabled',true);
            },
            success:function(res){
                $('.btn-success').prop('disabled',false);
                if(res.status){
                    toastr.success(res.message);
                    $('#supportTicketForm')[0].reset();
                    $('#department_id').trigger('change');
                    $('#category_id').html('<option>Select Category</option>');
                    $('#addSupportTicketModal').modal('hide');
                }else{
                    toastr.error(res.message);
                }
            },
            error:function(xhr){
                $('.btn-success').prop('disabled',false);
                if(xhr.status==422){
                    $.each(xhr.responseJSON.errors,function(k,v){
                        $('#'+k+'_err').html(v[0]);
                    });
                }
            }
        });
    }
</script>
<script>
    // function viewTicket(id){
    //     $('#ticketViewModal').modal('show');
    //     $('#ticketModalBody').html(`
    //         <div class="text-center py-5">
    //             <div class="spinner-border text-primary"></div>
    //             <div class="mt-2">Loading Ticket...</div>
    //         </div>
    //     `);

    //     $.ajax({
    //         url:'/my_self/support/view/'+id,
    //         type:'GET',
    //         dataType:'json',
    //         success:function(res){
    //             if(!res.status){
    //                 toastr.error(res.message);
    //                 return;
    //             }
    //             renderTicketModal(res.data);
    //         },
    //         error:function(){
    //             toastr.error('Unable to load ticket.');
    //         }

    //     });
    // }
</script>
<script>
    function renderTicketModal(t){

let priorityColor={

Low:'secondary',

Medium:'info',

High:'warning',

Urgent:'danger',

Critical:'dark'

};

let statusColor={

Open:'warning',

Assigned:'primary',

'In Progress':'info',

'Waiting Staff':'secondary',

'Waiting Third Party':'dark',

Resolved:'success',

Closed:'success',

Reopened:'danger',

Cancelled:'secondary'

};

let html=`

<div class="p-4">

<div class="row">

<div class="col-lg-8">

<h3 class="fw-bold text-primary">

${t.ticket_no}

</h3>

<h5 class="mt-2">

${t.subject}

</h5>

<p class="text-muted mt-3">

${t.description}

</p>

</div>

<div class="col-lg-4">

<div class="card shadow-sm">

<div class="card-body">

<div class="mb-3">

<label class="fw-bold">

Priority

</label>

<br>

<span class="badge bg-${priorityColor[t.priority]}">

${t.priority}

</span>

</div>

<div class="mb-3">

<label class="fw-bold">

Status

</label>

<br>

<span class="badge bg-${statusColor[t.status]}">

${t.status}

</span>

</div>

<div class="mb-3">

<label class="fw-bold">

Department

</label>

<div>

${t.department.department_name}

</div>

</div>

<div class="mb-3">

<label class="fw-bold">

Category

</label>

<div>

${t.category.category_name}

</div>

</div>

<div class="mb-3">

<label class="fw-bold">

Assigned To

</label>

<div>

${t.assigned_staff ??

'<span class="text-muted">Not Assigned</span>'}

</div>

</div>

<div>

<label class="fw-bold">

Created

</label>

<div>

${formatDateCommon(t.created_at)}

</div>

</div>

</div>

</div>

</div>

</div>

<hr>

<h5>

Attachments

</h5>

<div id="ticketAttachments">

${renderAttachments(t.attachments)}

</div>

<hr>

<h5>

Conversation

</h5>

<div id="ticketMessages">

Loading...

</div>

</div>

`;

$('#ticketModalBody').html(html);

loadTicketMessages(t.sno);

}
</script>
<script>
    function renderAttachmentsOld(attachments) {

    if (!attachments || attachments.length === 0) {
        return `
            <div class="alert alert-light text-center mb-0">
                <i class="mdi mdi-paperclip-off fs-3 d-block mb-2"></i>
                No Attachments
            </div>
        `;
    }

    let html = `<div class="row g-3">`;

    attachments.forEach(file => {

        let fileName = file.split('/').pop();
        let extension = fileName.split('.').pop().toLowerCase();

        let icon = 'mdi-file';
        let badge = 'secondary';

        if (['jpg','jpeg','png','gif','webp','bmp'].includes(extension)) {
            icon = 'mdi-file-image';
            badge = 'success';
        }
        else if (extension === 'pdf') {
            icon = 'mdi-file-pdf-box';
            badge = 'danger';
        }
        else if (['doc','docx'].includes(extension)) {
            icon = 'mdi-file-word';
            badge = 'primary';
        }
        else if (['xls','xlsx','csv'].includes(extension)) {
            icon = 'mdi-file-excel';
            badge = 'success';
        }
        else if (['zip','rar','7z'].includes(extension)) {
            icon = 'mdi-folder-zip';
            badge = 'warning';
        }

        html += `

        <div class="col-md-4">

            <div class="card shadow-sm border h-100">

                <div class="card-body text-center">

                    ${
                        ['jpg','jpeg','png','gif','webp','bmp'].includes(extension)
                        ?
                        `
                        <img src="${file}"
                             class="img-fluid rounded mb-3"
                             style="height:150px;object-fit:cover;cursor:pointer"
                             onclick="window.open('${file}','_blank')">
                        `
                        :
                        `
                        <i class="mdi ${icon} text-${badge}" style="font-size:70px;"></i>
                        `
                    }

                    <div class="fw-semibold text-truncate mt-2"
                         title="${fileName}">
                        ${fileName}
                    </div>

                    <span class="badge bg-${badge} mt-2">
                        ${extension.toUpperCase()}
                    </span>

                    <div class="mt-3">

                        <a href="${file}"
                           target="_blank"
                           class="btn btn-sm btn-primary">

                            <i class="mdi mdi-eye"></i>
                            View

                        </a>

                        <a href="${file}"
                           download
                           class="btn btn-sm btn-outline-secondary">

                            <i class="mdi mdi-download"></i>

                        </a>

                    </div>

                </div>

            </div>

        </div>

        `;

    });

    html += `</div>`;

    return html;

}
</script>

<script>
    function loadTicketMessages(ticketId) {

    $('#ticketMessages').html(`
        <div class="text-center py-4">
            <div class="spinner-border spinner-border-sm text-primary"></div>
            <div class="mt-2">Loading conversation...</div>
        </div>
    `);

    $.ajax({
        url: '/my_self/support/messages/' + ticketId,
        type: 'GET',
        dataType: 'json',

        success: function(res){

            if(!res.status){

                $('#ticketMessages').html(`
                    <div class="alert alert-danger">
                        ${res.message}
                    </div>
                `);

                return;
            }

            renderTicketMessages(res.data);

        },

        error:function(){

            $('#ticketMessages').html(`
                <div class="alert alert-danger">
                    Unable to load messages.
                </div>
            `);

        }

    });

}

function renderTicketMessages(messages){

    if(messages.length==0){

        $('#ticketMessages').html(`
            <div class="alert alert-light text-center mb-0">
                No Conversation Yet
            </div>
        `);

        return;

    }

    let html='';

    messages.forEach(function(msg){

        let isStaff = msg.message_type=='Staff';

        html+=`

        <div class="d-flex ${isStaff?'justify-content-end':'justify-content-start'} mb-3">

            <div class="card shadow-sm ${isStaff?'bg-primary text-white':'bg-light'}"
                 style="max-width:75%;">

                <div class="card-body">

                    <div class="fw-bold mb-1">
                        ${msg.sender_name}
                    </div>

                    <div>
                        ${msg.message}
                    </div>

                    ${
                        msg.attachment
                        ?
                        `
                        <div class="mt-3">

                            <a href="${msg.attachment}"
                               target="_blank"
                               class="btn btn-sm btn-outline-primary">

                                Attachment

                            </a>

                        </div>
                        `
                        :
                        ''
                    }

                    <div class="small mt-2 opacity-75">

                        ${formatDateCommon(msg.created_at)}

                    </div>

                </div>

            </div>

        </div>

        `;

    });

    $('#ticketMessages').html(html);

}
</script>
<script>
    function assignTicket(id){
        $('#assign_staff').html('');
        $('#assign_ticket_id').val(id);
        $('#assignTicketModal').modal('show');

        $.get('/support/ticket/'+id+'/assign',function(res){

            let html='<option value="">Select Staff</option>';

            res.staffs.forEach(function(item){
                html+=`
                    <option value="${item.sno}">
                        ${item.staff_name}
                    </option>
                `;
            });

            $('#assign_staff').html(html);
            $('#assign_staff').trigger('change');

        });

    }

    function submitAssignTicket(){

        $('#assign_staff_error').html('');

        let fd=new FormData();
        fd.append('_token',$('meta[name="csrf-token"]').attr('content'));
        fd.append('ticket_id',$('#assign_ticket_id').val());
        fd.append('assigned_to',$('#assign_staff').val());
        fd.append('remarks',$('#assign_remarks').val());

        $.ajax({
            url:'/support/ticket/assign',
            type:'POST',
            data:fd,
            processData:false,
            contentType:false,
            success:function(res){
                if(res.status){
                    toastr.success(res.message);
                    $('#assignTicketModal').modal('hide');
                    loadThemes(currentPage);
                }
                else{
                    toastr.error(res.message);
                }
            },
            error:function(xhr){
                let errors=xhr.responseJSON.errors;
                if(errors.assigned_to){
                    $('#assign_staff_error').html(errors.assigned_to[0]);
                }
            }
        });

    }
</script>
<script>
    let currentTicketId = 0;

    function viewTicket(id){
        currentTicketId=id;
        $('#viewTicketModal').modal('show');
        $('#ticketViewBody').html(`
            <div class="text-center py-5">
                <div class="spinner-border text-primary"></div>
                <h6 class="mt-3">
                    Loading Ticket...
                </h6>
            </div>
        `);
        $.ajax({
            url:'/support/view-ticket/'+id,
            type:'GET',
            dataType:'json',
            success:function(res){
                if(!res.status){
                    toastr.error(res.message);
                    return;
                }
                renderTicket(res.data);
            },
            error:function(){
                toastr.error('Unable to load ticket.');

            }
        });
    }

    function renderTicket(res){

        let t=res.ticket;

        $('#ticketViewBody').html(`
            <div class="container-fluid p-4">
                <div class="row">
                    <div class="col-lg-8">
                        <div id="ticketHeader"></div>
                        <div id="ticketConversation"></div>
                        <div id="replySection"></div>
                    </div>
                    <div class="col-lg-4">
                        <div id="ticketSummary"></div>
                        <div id="ticketAttachments"></div>
                        <div id="ticketHistory"></div>
                        <div id="internalNotes"></div>
                    </div>
                </div>
            </div>

        `);

            renderTicketHeader(t);

            renderTicketSummary(t);

            renderAttachments(res.attachments);

            renderConversation(res.messages);

            renderHistory(res.history);

            renderInternalNotes(res.notes);

            renderReplyBox(t);

    }

    function renderTicketHeader(ticket){

        const priorityColor = {
            Low:'secondary',
            Medium:'info',
            High:'warning',
            Urgent:'danger',
            Critical:'dark'
        };

        const statusColor = {
            Open:'warning',
            Assigned:'primary',
            'In Progress':'info',
            'Waiting Staff':'secondary',
            'Waiting Third Party':'dark',
            Resolved:'success',
            Closed:'success',
            Reopened:'danger',
            Cancelled:'secondary'
        };

        let html=`
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h3 class="fw-bold text-primary mb-1">
                                ${ticket.ticket_no}
                            </h3>
                            <h5 class="mb-2">
                                ${ticket.subject}
                            </h5>
                            <div class="text-muted">
                                ${ticket.description ?? ''}
                            </div>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-${priorityColor[ticket.priority]} fs-7">
                                ${ticket.priority}
                            </span>
                                <br><br>
                            <span class="badge bg-${statusColor[ticket.status]} fs-7">
                                ${ticket.status}
                            </span>
                        </div>
                    </div>
                    <hr>
                    <div class="row g-3 mt-2">
                        <div class="col-lg-3">
                            <div class="small text-muted">
                            Department
                            </div>
                            <div class="fw-bold">
                                <i class="mdi mdi-office-building text-primary"></i>
                                ${ticket.department_name}
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="small text-muted">
                                Category
                            </div>
                            <div class="fw-bold">
                                <i class="mdi mdi-shape"></i>
                                ${ticket.category_name}
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="small text-muted">
                                Created
                            </div>
                            <div class="fw-bold">
                                ${formatDateCommon(ticket.created_at)}
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="small text-muted">
                                Last Activity
                            </div>
                            <div class="fw-bold">
                                ${ticket.last_activity_at
                                ?formatDateCommon(ticket.last_activity_at)
                                :'-'}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $("#ticketHeader").html(html);

    }

    function renderTicketSummary(ticket){

        let image = ticket.profile_image
            ? `/storage/${ticket.profile_image}`
            : '/assets/media/avatars/blank.png';

        let created = moment(ticket.created_at);

        let now = moment();

        let age = moment.duration(now.diff(created));

        let ticketAge =
            age.days() + " Days " +
            age.hours() + " Hrs";

        let html = `

            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">
                    <i class="mdi mdi-account-circle text-primary"></i>
                    Staff & Ticket Summary
                    </h5>
                </div>
            <div class="card-body">
                <div class="text-center">
                    <imgsrc="${image}" class="rounded-circle shadow" style="width:90px;height:90px;object-fit:cover;">
                    <h5 class="mt-3 mb-1">${ticket.staff_name}/h5>
                    <div class="text-muted">${ticket.staff_code}</div>
                </div>
                <hr>
                <div class="row gy-3">
                    <div class="col-12">
                        <i class="mdi mdi-phone text-success"></i>
                        <strong> Mobile</strong>
                        <div>${ticket.mobile_no ?? '-'}</div>
                    </div>
                    <div class="col-12">
                        <i class="mdi mdi-email text-danger"></i>
                        <strong> Email</strong>
                        <div class="text-break">${ticket.email_id ?? '-'}</div>
                    </div>
                    <div class="col-12">
                        <i class="mdi mdi-account-tie text-primary"></i>
                        <strong> Assigned Engineer</strong>
                        <div>
                            ${ticket.assigned_staff ?? '<span class="text-muted">Not Assigned</span>'}
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="small text-muted">
                            Response SLA
                        </div>
                        <div class="fw-bold">
                            ${ticket.sla_response_hours} Hrs
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="small text-muted">
                            Resolution SLA
                        </div>
                        <div class="fw-bold">
                            ${ticket.sla_resolution_hours} Hrs
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="small text-muted">
                            Ticket Age
                        </div>
                        <div class="fw-bold text-primary">
                            ${ticketAge}
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="small text-muted">
                            SLA Status
                        </div>
                    <div>

                    ${
                        ticket.is_sla_breached==1
                        ?'<span class="badge bg-danger">Breached</span>'
                        :'<span class="badge bg-success">Within SLA</span>'
                    }
                </div>
            </div>

            <div class="col-12">
                <div class="small text-muted">
                    First Response
                </div>
                <div>
                    ${ticket.first_response_at
                    ?formatDateCommon(ticket.first_response_at)
                    :'-'}
                </div>
            </div>

            <div class="col-12">
                <div class="small text-muted">
                    Resolved
                </div>
                <div>
                    ${ticket.resolved_at
                    ?formatDateCommon(ticket.resolved_at)
                    :'-'}
                </div>
            </div>

            <div class="col-12">
                <div class="small text-muted">
                    Staff Rating
                </div>
                <div>
                    ${renderRating(ticket.staff_rating)}
                </div>
            </div>

            ${
            ticket.staff_feedback
            ?

            `

            <div class="col-12">

            <div class="alert alert-light-warning mb-0">

            <strong>

            Feedback

            </strong>

            <hr>

            ${ticket.staff_feedback}

            </div>

            </div>

            `

            :''

            }

            </div>

            </div>

            </div>

        `;

        $("#ticketSummary").html(html);

    }
</script>
@endsection