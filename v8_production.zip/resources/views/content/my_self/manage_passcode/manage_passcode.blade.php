@extends('layouts/layoutMaster')

@section('title', 'Manage Passcode')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp



<style>

    /* =========================================================
    MANAGE PASSCODE
    ========================================================= */

    .passcode-page {
        --pc-primary: #b52b25;
        --pc-primary-dark: #7f1d1d;
        --pc-success: #16a34a;
        --pc-danger: #dc2626;
        --pc-warning: #f5a623;
        --pc-text: #172033;
        --pc-muted: #64748b;
        --pc-border: #e7eaf0;
        --pc-soft: #f8fafc;
        --pc-radius: 14px;

        padding: 22px;

        --brand-dark: #7f1d1d;
        --brand: #b52b25;
        --brand-light: #dc4a2f;
        --brand-accent: #f5a623;

        --bg: #f5f7fb;
        --surface: #ffffff;

        --text-primary: #172033;
        --text-secondary: #667085;
        --text-muted: #98a2b3;

        --border: #e7eaf0;

        --success: #16a34a;
        --success-bg: #ecfdf3;
        --success-border: #bbf7d0;

        --warning: #d97706;
        --danger: #dc2626;
    }


    /* HEADER */

    .passcode-header {
        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 20px;

        margin-bottom: 20px;
    }

    .passcode-title-wrap {
        min-width: 0;
    }

    .passcode-title {
        margin: 0;

        color: var(--pc-text);

        font-size: 24px;
        font-weight: 700;
        letter-spacing: -0.4px;
    }

    .passcode-subtitle {
        margin: 5px 0 0;

        color: var(--pc-muted);

        font-size: 13px;
    }

    .passcode-header-actions {
        display: flex;
        align-items: center;

        gap: 8px;
    }


    /* BUTTONS */

    .pc-btn {
        display: inline-flex;

        align-items: center;
        justify-content: center;

        gap: 7px;

        min-height: 38px;

        padding: 0 14px;

        border-radius: 9px;

        font-size: 13px;
        font-weight: 600;

        border: 1px solid transparent;

        transition: .2s ease;
    }

    .pc-btn-primary {
        color: #fff;

        background: var(--pc-primary);
    }

    .pc-btn-primary:hover {
        color: #fff;

        background: var(--pc-primary-dark);

        transform: translateY(-1px);
    }

    .pc-btn-light {
        color: #475569;

        background: #fff;

        border-color: var(--pc-border);
    }

    .pc-btn-light:hover {
        background: #f8fafc;
    }


    /* DASHBOARD */

    .passcode-stats {
        display: grid;

        grid-template-columns:
            repeat(4, minmax(0, 1fr));

        gap: 14px;

        margin-bottom: 18px;
    }

    .passcode-stat {
        position: relative;

        padding: 17px;

        background: #fff;

        border: 1px solid var(--pc-border);

        border-radius: var(--pc-radius);

        overflow: hidden;
    }

    .passcode-stat::after {
        content: "";

        position: absolute;

        width: 70px;
        height: 70px;

        right: -22px;
        bottom: -25px;

        border-radius: 50%;

        background: rgba(229, 70, 70, .06);
    }

    .passcode-stat-icon {
        width: 38px;
        height: 38px;

        display: flex;
        align-items: center;
        justify-content: center;

        margin-bottom: 12px;

        border-radius: 10px;

        color: var(--pc-primary);

        background: #ffeeee;

        font-size: 19px;
    }

    .passcode-stat-label {
        color: var(--pc-muted);

        font-size: 11px;
        font-weight: 600;

        text-transform: uppercase;
        letter-spacing: .5px;
    }

    .passcode-stat-value {
        margin-top: 3px;

        color: var(--pc-text);

        font-size: 23px;
        font-weight: 700;
    }


    /* FILTER CARD */

    .passcode-filter-card {
        padding: 13px;

        margin-bottom: 15px;

        background: #fff;

        border: 1px solid var(--pc-border);

        border-radius: var(--pc-radius);
    }

    .passcode-filter-row {
        display: grid;

        grid-template-columns:
            minmax(250px, 1fr)
            190px
            150px
            auto;

        gap: 9px;

        align-items: center;
    }

    .pc-search {
        position: relative;
    }

    .pc-search i {
        position: absolute;

        top: 50%;
        left: 12px;

        transform: translateY(-50%);

        color: #94a3b8;
    }

    .pc-search input {
        padding-left: 37px;
    }

    /* .pc-control {
        height: 39px;

        border-color: var(--pc-border);

        border-radius: 9px;

        font-size: 13px;

        box-shadow: none !important;
    } */

    .pc-control:focus {
        border-color: #a5b4fc;
    }


    /* TABLE */

    .passcode-table-card {
        position: relative;
        background: #fff;
        border: 1px solid var(--pc-border);

        border-radius: var(--pc-radius);

        overflow: hidden;
    }

    .passcode-table-header {
        min-height: 55px;

        padding: 0 16px;

        display: flex;
        align-items: center;
        justify-content: space-between;

        border-bottom: 1px solid var(--pc-border);
    }

    .passcode-table-title {
        display: flex;
        align-items: center;

        gap: 8px;

        color: var(--pc-text);

        font-size: 14px;
        font-weight: 700;
    }

    .passcode-count {
        min-width: 25px;

        padding: 3px 7px;

        border-radius: 20px;

        color: var(--pc-primary);

        background: #ffeeee;

        font-size: 10px;
    }

    .passcode-table-wrap {
        width: 100%;

        overflow-x: auto;
    }

    .passcode-table {
        width: 100%;

        min-width: 850px;

        margin: 0;
    }

    .passcode-table thead th {
        padding: 11px 13px;

        /* color: #64748b; */

        /* background: #f8fafc; */

        border-bottom: 1px solid var(--pc-border);

        font-size: 10px;
        font-weight: 700;

        text-transform: uppercase;
        letter-spacing: .45px;

        white-space: nowrap;
    }

    .passcode-table tbody td {
        padding: 12px 13px;

        color: #334155;

        border-bottom: 1px solid #f0f2f5;

        font-size: 12px;

        vertical-align: middle;
    }

    .passcode-table tbody tr {
        transition: .15s ease;
    }

    .passcode-table tbody tr:hover {
        background: #fafbff;
    }

    .passcode-account {
        display: flex;
        align-items: center;

        gap: 10px;

        min-width: 190px;
    }

    .passcode-account-icon {
        width: 36px;
        height: 36px;

        min-width: 36px;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 10px;

        color: var(--pc-primary);

        background: #ffeeee;

        font-size: 17px;
    }

    .passcode-account-name {
        color: #172033;

        font-weight: 700;
    }

    .passcode-account-url {
        max-width: 230px;

        margin-top: 2px;

        color: #94a3b8;

        font-size: 10px;

        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .pc-category {
        display: inline-flex;

        align-items: center;

        gap: 5px;

        padding: 5px 8px;

        border-radius: 7px;

        color: #475569;

        background: #f1f5f9;

        font-size: 10px;
        font-weight: 600;

        white-space: nowrap;
    }

    .pc-status {
        display: inline-flex;

        align-items: center;

        gap: 5px;

        padding: 5px 8px;

        border-radius: 20px;

        font-size: 10px;
        font-weight: 700;
    }

    .pc-status-active {
        color: #15803d;

        background: #dcfce7;
    }

    .pc-status-inactive {
        color: #b45309;

        background: #fef3c7;
    }

    .pc-status-archived {
        color: #64748b;

        background: #f1f5f9;
    }

    .pc-action-group {
        display: flex;

        justify-content: flex-end;

        gap: 4px;
    }

    .pc-action {
        width: 31px;
        height: 31px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border: 1px solid transparent;

        border-radius: 8px;

        color: #64748b;

        background: transparent;

        transition: .15s ease;
    }

    .pc-action:hover {
        color: var(--pc-primary);

        background: #ffeeee;
    }

    .pc-action-danger:hover {
        color: var(--pc-danger);

        background: #fef2f2;
    }


    /* SKELETON */

    .pc-skeleton {
        height: 13px;

        border-radius: 5px;

        background:
            linear-gradient(
                90deg,
                #f1f5f9 25%,
                #e2e8f0 37%,
                #f1f5f9 63%
            );

        background-size: 400% 100%;

        animation: pcSkeleton 1.3s ease infinite;
    }

    @keyframes pcSkeleton {
        0% {
            background-position: 100% 0;
        }

        100% {
            background-position: -100% 0;
        }
    }

    .pc-skeleton-row td {
        padding: 16px 13px;
    }


    /* EMPTY */

    .pc-empty {
        padding: 55px 20px;

        text-align: center;
    }

    .pc-empty-icon {
        width: 60px;
        height: 60px;

        display: flex;
        align-items: center;
        justify-content: center;

        margin: 0 auto 13px;

        border-radius: 18px;

        color: #6366f1;

        background: #ffeeee;

        font-size: 28px;
    }

    .pc-empty-title {
        color: #334155;

        font-size: 15px;
        font-weight: 700;
    }

    .pc-empty-text {
        max-width: 430px;

        margin: 5px auto 0;

        color: #94a3b8;

        font-size: 12px;
    }


    /* PAGINATION */

    .passcode-pagination {
        padding: 12px 15px;

        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 12px;

        border-top: 1px solid var(--pc-border);
    }

    .pc-pagination-info {
        color: #94a3b8;

        font-size: 11px;
    }

    .pc-pagination-buttons {
        display: flex;

        align-items: center;

        gap: 4px;
    }

    .pc-page {
        min-width: 30px;
        height: 30px;

        padding: 0 8px;

        border: 1px solid var(--pc-border);

        border-radius: 7px;

        color: #64748b;

        background: #fff;

        font-size: 11px;
    }

    .pc-page:hover,
    .pc-page.active {
        color: #fff;

        border-color: var(--pc-primary);

        background: var(--pc-primary);
    }

    .pc-page:disabled {
        opacity: .45;
    }


    /* MODAL */

    /* .passcode-modal .modal-content {
        border: 0;

        border-radius: 17px;

        overflow: hidden;

        box-shadow:
            0 25px 60px rgba(15, 23, 42, .18);
    } */

    .passcode-modal .modal-header {
        padding: 17px 20px;

        border-bottom: 1px solid #eef0f4;

        background: #fff;
    }

    .pc-modal-title {
        display: flex;
        align-items: center;

        gap: 10px;
    }

    .pc-modal-icon {
        width: 38px;
        height: 38px;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 10px;

        color: #fff;

        background:linear-gradient(135deg, #ff594d, #da3f34);
    }

    .passcode-modal .modal-body {
        padding: 20px;
    }

    .pc-section {
        margin-bottom: 19px;
    }

    .pc-section:last-child {
        margin-bottom: 0;
    }

    .pc-section-heading {
        display: flex;
        align-items: center;

        gap: 7px;

        margin-bottom: 11px;

        color: #334155;

        font-size: 12px;
        font-weight: 700;
    }

    .pc-section-heading i {
        color: var(--pc-primary);
    }

    .pc-label {
        margin-bottom: 5px;

        color: #475569;

        font-size: 11px;
        font-weight: 600;
    }

    .pc-required {
        color: #dc2626;
    }

    .pc-error {
        display: block;

        min-height: 16px;

        margin-top: 3px;

        color: #dc2626;

        font-size: 10px;
    }

    .pc-input-group .form-control {
        border-right: 0;
    }

    .pc-input-action {
        border: 1px solid #cbcbcb !important;

        background: #fff;
    }

    .pc-input-action:hover {
        background: #f8fafc;
    }

    .pc-security-note {
        padding: 10px 12px;

        display: flex;

        gap: 8px;

        border-radius: 9px;

        color: #475569;

        background: #f8fafc;

        font-size: 10px;
    }

    .pc-security-note i {
        color: #16a34a;
    }


    /* TOAST */

    .pc-toast {
        position: fixed;

        right: 22px;
        bottom: 22px;

        z-index: 99999;

        min-width: 280px;

        padding: 12px 14px;

        display: flex;

        align-items: center;

        gap: 9px;

        color: #fff;

        background: #172033;

        border-radius: 10px;

        box-shadow:
            0 15px 35px rgba(15,23,42,.2);

        transform:
            translateY(25px);

        opacity: 0;

        pointer-events: none;

        transition: .25s ease;
    }

    .pc-toast.show {
        transform: translateY(0);

        opacity: 1;
    }

    .pc-toast.success i {
        color: #4ade80;
    }

    .pc-toast.error i {
        color: #f87171;
    }


    /* RESPONSIVE */

    @media (max-width: 1100px) {

        .passcode-stats {
            grid-template-columns:
                repeat(2, minmax(0, 1fr));
        }

        .passcode-filter-row {
            grid-template-columns:
                1fr
                180px
                140px
                auto;
        }
    }

    @media (max-width: 768px) {

        .passcode-page {
            padding: 12px;
        }

        .passcode-header {
            align-items: flex-start;

            flex-direction: column;
        }

        .passcode-header-actions {
            width: 100%;
        }

        .passcode-header-actions .pc-btn-primary {
            flex: 1;
        }

        .passcode-filter-row {
            grid-template-columns: 1fr;
        }

        .passcode-stats {
            grid-template-columns:
                repeat(2, minmax(0, 1fr));

            gap: 8px;
        }

        .passcode-stat {
            padding: 13px;
        }

        .passcode-stat-value {
            font-size: 20px;
        }

        .passcode-pagination {
            align-items: flex-start;

            flex-direction: column;
        }
    }

    @media (max-width: 480px) {

        .passcode-stats {
            grid-template-columns: 1fr 1fr;
        }

        .passcode-title {
            font-size: 20px;
        }
    }

    /* =========================================================
   PORTAL ACCESS BUTTON
========================================================= */

.pc-portal-btn {
    display: inline-flex;
    align-items: center;
    gap: 5px;

    height: 31px;
    padding: 0 9px;

    border: 1px solid #dbeafe;
    border-radius: 8px;

    color: var(--pc-warning);;
    background: #fffcef;

    font-size: 10px;
    font-weight: 700;

    text-decoration: none;

    transition: all .18s ease;
}

.pc-portal-btn:hover {
    color: var(--pc-warning);
    background: #fef2db;
    border-color: #feeabf;

    transform: translateY(-1px);
}

.pc-portal-btn i {
    font-size: 15px;
}


/* Disabled portal */

.pc-portal-btn.disabled {
    color: #94a3b8;
    background: #f8fafc;
    border-color: #e5e7eb;

    cursor: not-allowed;
    pointer-events: none;
}


/* Account URL */

.passcode-account-url {
    display: flex;
    align-items: center;
    gap: 4px;

    max-width: 230px;

    margin-top: 3px;

    color: #94a3b8;

    font-size: 10px;

    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.passcode-account-url i {
    color: #64748b;
    font-size: 11px;
}


/* Quick action */

.pc-quick-actions {
    display: flex;
    align-items: center;
    gap: 5px;
}

</style>


<div class="passcode-page">

    {{-- =====================================================
         HEADER
    ====================================================== --}}

    <div class="passcode-header">

        <div class="passcode-title-wrap">

            <h4 class="passcode-title">
                <i class="mdi mdi-shield-key-outline text-primary me-1"></i>
                Manage Pass Code
            </h4>

            <p class="passcode-subtitle">
                Securely manage portal, email, server and application credentials.
            </p>

        </div>


        <div class="passcode-header-actions">

            <button
                type="button"
                class="pc-btn pc-btn-light"
                id="btnRefreshPasscodes"
            >
                <i class="mdi mdi-refresh"></i>
                Refresh
            </button>

            <button
                type="button"
                class="pc-btn pc-btn-primary"
                id="btnAddPasscode"
            >
                <i class="mdi mdi-plus"></i>
                Add Credential
            </button>

        </div>

    </div>


    {{-- =====================================================
         STATISTICS
    ====================================================== --}}

    <div class="passcode-stats">

        <div class="passcode-stat">

            <div class="passcode-stat-icon">
                <i class="mdi mdi-key-chain"></i>
            </div>

            <div class="passcode-stat-label">
                Total Credentials
            </div>

            <div
                class="passcode-stat-value"
                id="pcTotalCount"
            >
                —
            </div>

        </div>


        <div class="passcode-stat">

            <div class="passcode-stat-icon">
                <i class="mdi mdi-check-circle-outline"></i>
            </div>

            <div class="passcode-stat-label">
                Active
            </div>

            <div
                class="passcode-stat-value text-success"
                id="pcActiveCount"
            >
                —
            </div>

        </div>


        <div class="passcode-stat">

            <div class="passcode-stat-icon">
                <i class="mdi mdi-pause-circle-outline"></i>
            </div>

            <div class="passcode-stat-label">
                Inactive
            </div>

            <div
                class="passcode-stat-value text-warning"
                id="pcInactiveCount"
            >
                —
            </div>

        </div>


        <div class="passcode-stat">

            <div class="passcode-stat-icon">
                <i class="mdi mdi-shield-lock-outline"></i>
            </div>

            <div class="passcode-stat-label">
                Protected
            </div>

            <div class="passcode-stat-value">
                AES / APP
            </div>

        </div>

    </div>


    {{-- =====================================================
         FILTER
    ====================================================== --}}

    <div class="passcode-filter-card">

        <div class="passcode-filter-row">

            <div class="pc-search">

                <i class="mdi mdi-magnify"></i>

                <input
                    type="text"
                    id="pcSearch"
                    class="form-control pc-control"
                    placeholder="Search portal, account or category..."
                    autocomplete="off"
                >

            </div>


            <select
                id="pcCategory"
                class="form-select pc-control"
            >

                <option value="">
                    All Categories
                </option>

                @foreach($categories as $category)

                    <option value="{{ $category->sno }}">
                        {{ $category->category_name }}
                    </option>

                @endforeach

            </select>


            <select
                id="pcStatus"
                class="form-select pc-control"
            >

                <option value="all">
                    All Status
                </option>

                <option value="0">
                    Active
                </option>

                <option value="1">
                    Inactive
                </option>

            </select>


            <button
                type="button"
                class="pc-btn pc-btn-light"
                id="btnClearPcFilters"
            >
                <i class="mdi mdi-filter-remove-outline"></i>
                Clear
            </button>

        </div>

    </div>


    {{-- =====================================================
         TABLE
    ====================================================== --}}

    <div class="passcode-table-card">

        <div class="passcode-table-header">

            <div class="passcode-table-title">

                <i class="mdi mdi-format-list-bulleted"></i>

                Credential List

                <span
                    class="passcode-count"
                    id="pcResultCount"
                >
                    0
                </span>

            </div>

        </div>


        <div class="passcode-table-wrap">

            <table class="table passcode-table">
                <thead>
                    <tr class="text-start fw-bold fs-7 gs-0 bg-primary text-white">
                        <th width="35"> #</th>
                        <th>Account</th>
                        <th>Category</th>
                        <!-- <th>Credential</th> -->
                        <th> Status</th>
                        <th>Updated</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody id="passcodeTableBody"></tbody>
            </table>
        </div>
        <div  class="passcode-pagination" id="passcodePagination"></div>
    </div>

</div>


{{-- =========================================================
     ADD / EDIT MODAL
========================================================= --}}

<div class="modal fade passcode-modal"  id="passcodeModal" tabindex="-1" aria-labelledby="passcodeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content">
            <div class="modal-header">
                <div class="pc-modal-title">
                    <div class="pc-modal-icon">
                        <i class="mdi mdi-shield-key-outline"></i>
                    </div>
                    <div>
                        <h5 class="modal-title mb-1" id="passcodeModalTitle">
                           Add Credential
                        </h5>
                        <small class="text-muted">
                             Store credentials securely
                        </small>
                    </div>
                </div>
                <button  type="button"  class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-0">
                <div class="row">
                  
                    <form id="passcodeForm" method="POST" autocomplete="off">
                        @csrf
                        <input type="hidden" name="product_id" id="expense_product_edit_id" value="">
                        <input type="hidden"  name="form_mode" id="productFormMode"  value="create">
                        <div class="modal-body">
                            {{-- SECURITY NOTE --}}
                            <div class="pc-security-note mb-3">
                                <i class="mdi mdi-shield-check-outline fs-5"></i>
                                <div>
                                    Passwords, login identifiers and access PINs
                                    are encrypted before being stored.
                                </div>
                            </div>

                            {{-- BASIC INFORMATION --}}
                            <div class="pc-section">
                                <div class="pc-section-heading">
                                    <i class="mdi mdi-information-outline"></i>
                                    Basic Information
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="pc-label">
                                            Category
                                            <span class="pc-required">*</span>
                                        </label>
                                        <select name="category_sno" id="pcCategoryInput" class="form-select pc-control select3" >
                                            <option value=""> Select category</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->sno }}">
                                                    {{ $category->category_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <small class="pc-error" data-error="category_sno"></small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="pc-label">
                                            Account / Portal Name
                                            <span class="pc-required">*</span>
                                        </label>
                                        <input type="text" name="account_name" id="pcAccountName"  class="form-control pc-control"  placeholder="Example: AWS Production" >
                                        <small class="pc-error" data-error="account_name" ></small>
                                    </div>
                                    <div class="col-12">
                                        <label class="pc-label">
                                            Login URL
                                        </label>
                                        <input type="url" name="login_url" id="pcLoginUrl"  class="form-control pc-control" placeholder="https://example.com/login">
                                        <small class="pc-error" data-error="login_url" ></small>
                                    </div>
                                </div>
                            </div>

                            {{-- LOGIN CREDENTIALS --}}
                            <div class="pc-section">
                                <div class="pc-section-heading">
                                    <i class="mdi mdi-account-lock-outline"></i>
                                    Login Credentials
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="pc-label">
                                            Username / Email / Mobile
                                        </label>
                                        <input type="text" name="login_identifier" id="pcLoginIdentifier" class="form-control pc-control" placeholder="Username, email or mobile" autocomplete="off">
                                        <small class="pc-error" data-error="login_identifier"></small>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="pc-label">
                                            Password
                                        </label>
                                        <div class="input-group pc-input-group">
                                            <input
                                                type="password"
                                                name="login_password"
                                                id="pcLoginPassword"
                                                class="form-control pc-control"
                                                placeholder="Enter password"
                                                autocomplete="new-password"
                                            >
                                            <span type="button" class="btn pc-input-action input-group-text" id="btnGeneratePassword" title="Generate password">
                                                <i class="mdi mdi-auto-fix"></i>
                                            </span>
                                            <span
                                                type="button"
                                                class="btn pc-input-action input-group-text"
                                                id="btnTogglePassword"
                                                title="Show password"
                                            >
                                                <i class="mdi mdi-eye-outline"></i>
                                            </span>
                                        </div>
                                        <small
                                            class="pc-error"
                                            data-error="login_password"
                                        ></small>
                                        <!-- <small class="text-muted">
                                            Leave blank while editing to keep the existing password.
                                        </small> -->
                                    </div>
                                    <!-- <div class="col-md-6">
                                        <label class="pc-label">
                                            Secondary ID / Account ID
                                        </label>
                                        <input
                                            type="text"
                                            name="secondary_identifier"
                                            id="pcSecondaryIdentifier"
                                            class="form-control pc-control"
                                            placeholder="Customer ID / Account ID"
                                        >
                                        <small
                                            class="pc-error"
                                            data-error="secondary_identifier"
                                        ></small>
                                    </div> -->
                                    <!-- <div class="col-md-6">
                                        <label class="pc-label">
                                            PIN / Access Code
                                        </label>
                                        <input
                                            type="password"
                                            name="access_pin"
                                            id="pcAccessPin"
                                            class="form-control pc-control"
                                            placeholder="Optional access PIN"
                                            autocomplete="off"
                                        >
                                        <small
                                            class="pc-error"
                                            data-error="access_pin"
                                        ></small>
                                    </div> -->
                                </div>
                            </div>

                            {{-- ADDITIONAL --}}
                            <div class="pc-section">
                                <div class="pc-section-heading">
                                    <i class="mdi mdi-office-building-outline"></i>
                                    Additional Information
                                </div>
                                <div class="row g-3">
                                    <!-- <div class="col-md-6">
                                        <label class="pc-label">
                                            Company
                                        </label>
                                        <input type="number" name="company_sno" id="pcCompanySno"  class="form-control pc-control" placeholder="Company ID" >
                                    </div>
                                    <div class="col-md-6">
                                        <label class="pc-label">
                                            Entity
                                        </label>
                                        <input
                                            type="number"
                                            name="entity_sno"
                                            id="pcEntitySno"
                                            class="form-control pc-control"
                                            placeholder="Entity ID"
                                        >
                                    </div> -->
                                    <div class="col-12">
                                        <label class="pc-label">
                                            Notes
                                        </label>
                                        <textarea
                                            name="notes"
                                            id="pcNotes"
                                            class="form-control pc-control"
                                            rows="3"
                                            placeholder="Additional information..."
                                        ></textarea>
                                        <small
                                            class="pc-error"
                                            data-error="notes"
                                        ></small>
                                    </div>
                                    <!-- <div class="col-md-6">
                                        <label class="pc-label">
                                            Status
                                        </label>
                                        <select
                                            name="status"
                                            id="pcStatusInput"
                                            class="form-select pc-control"
                                        >
                                            <option value="0">
                                                Active
                                            </option>
                                            <option value="1">
                                                Inactive
                                            </option>
                                        </select>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal" >Cancel</button>
                            <button type="submit" class="btn btn-primary" id="btnSavePasscode">
                                <span class="pc-save-text">Save Credential</span>
                                <span class="spinner-border spinner-border-sm d-none" id="pcSaveLoader"></span>
                            </button>
                        </div>
                    </form>
               
                </div>
            
                
            </div> 
        
        </div>
    </div>
</div>








       

            


            


            

     






{{-- =========================================================
     VIEW CREDENTIAL MODAL
========================================================= --}}

<div
    class="modal fade passcode-modal"
    id="viewPasscodeModal"
    tabindex="-1"
>

    <div class="modal-dialog modal-md modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <div class="pc-modal-title">

                    <div class="pc-modal-icon">
                        <i class="mdi mdi-shield-lock-outline"></i>
                    </div>

                    <div>

                        <h5
                            class="modal-title mb-0"
                            id="viewPcTitle"
                        >
                            Credential
                        </h5>

                        <small class="text-muted">
                            Protected credential
                        </small>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>


            <div class="modal-body">

                <div id="viewPcContent"></div>

            </div>

        </div>

    </div>

</div>


{{-- custoise TOAST --}}

<!-- <div class="pc-toast" id="pcToast">
    <i class="mdi mdi-check-circle-outline"></i>
    <span id="pcToastMessage"></span>
</div> -->




<script>

   let page  = 1;
   let perPage = 10;
   let loading = false;
   let editMode = false;
   let modalPassCode = null;
//    let viewModal = null;

    const routes = {
        list:"{{ route('myself.manage.passcode.list') }}",
        store: "{{ route('myself.manage.passcode.store') }}",
        edit: "{{ url('myself/manage-passcode/edit') }}",
        update: "{{ url('myself/manage-passcode/update') }}",
        reveal: "{{ url('myself/manage-passcode/reveal') }}",
        status: "{{ url('myself/manage-passcode/status') }}",
        delete: "{{ url('myself/manage-passcode/delete') }}"
    }

    function init() {
       
        

        registerEvents();
        load();
    }

    /* EVENTS */

    function registerEvents() {

        $('#btnAddPasscode').on(
            'click',
            () => openAdd()
        );


        $('#btnRefreshPasscodes').on(
            'click',
            () => refresh()
        );


        $('#btnClearPcFilters').on(
            'click',
            () => {
                $('#pcSearch').val('');
                $('#pcCategory').val('');
                $('#pcStatus').val('all');

                page = 1;

                load();
            }
        );


        $('#pcCategory, #pcStatus').on(
            'change',
            () => {

                page = 1;

                load();
            }
        );


        let searchTimer;

        $('#pcSearch').on(
            'input',
            () => {

                clearTimeout(searchTimer);

                searchTimer = setTimeout(
                    () => {

                        page = 1;

                        load();

                    },
                    350
                );
            }
        );


        $('#passcodeForm').on(
            'submit',
            (e) => {

                e.preventDefault();

                save();

            }
        );


        $('#btnTogglePassword').on(
            'click',
            () => {

                const input =
                    $('#pcLoginPassword');

                const icon =
                    $('#btnTogglePassword i');

                if (input.attr('type') === 'password') {

                    input.attr('type', 'text');

                    icon
                        .removeClass('mdi-eye-outline')
                        .addClass('mdi-eye-off-outline');

                } else {

                    input.attr('type', 'password');

                    icon
                        .removeClass('mdi-eye-off-outline')
                        .addClass('mdi-eye-outline');
                }
            }
        );


        $('#btnGeneratePassword').on(
            'click',
            () => {

                $('#pcLoginPassword')
                    .val(
                        generatePassword()
                    )
                    .attr('type', 'text');

            }
        );

    }


    /* LOAD */
    function load() {

        if (loading) {
            return;
        }

        loading = true;

        showSkeleton();

        $.ajax({
            url: routes.list,
            type: 'GET',
            data: {
                page: page,
                per_page: perPage,
                search:  $('#pcSearch').val(),
                category: $('#pcCategory').val(),
                status: $('#pcStatus').val()
            },
            success: (response) => {
                if (!response.status) {
                    showEmpty( 'Unable to load credentials.' );
                    return;
                }
                render(response);
            },
            error: () => {
                showEmpty('Unable to load credentials. Please try again.' );
                toast('Unable to load credential list.', 'error');
            },
            complete: () => {
                loading = false;
            }
        });
    }


    /* =====================================================
       SKELETON
    ===================================================== */

    function showSkeleton() {

        let html = '';

        for (let i = 0; i < 7; i++) {

            html += `
                <tr class="pc-skeleton-row">

                    <td>
                        <div class="pc-skeleton" style="width:20px"></div>
                    </td>

                    <td>
                        <div class="pc-skeleton" style="width:180px"></div>
                    </td>

                    <td>
                        <div class="pc-skeleton" style="width:100px"></div>
                    </td>

                    <!-- <td>
                        <div class="pc-skeleton" style="width:120px"></div>
                    </td> -->

                    <td>
                        <div class="pc-skeleton" style="width:65px"></div>
                    </td>

                    <td>
                        <div class="pc-skeleton" style="width:110px"></div>
                    </td>

                    <td>
                        <div class="pc-skeleton ms-auto" style="width:90px"></div>
                    </td>

                </tr>
            `;
        }

        $('#passcodeTableBody').html(html);

    }


    /* RENDER */

    function render(response) {
        const rows = response.data || [];

        $('#pcResultCount')
            .text(
                response.pagination.total
            );

        $('#pcTotalCount')
            .text(
                response.pagination.total
            );

        renderRows(rows);

        renderPagination(
            response.pagination
        );

    }


    /* ROWS */

    function renderRows(rows) {

        if (!rows.length) {

            showEmpty(
                'No credentials found.',
                'Try changing your search or filters.'
            );

            return;
        }


        let html = '';

        rows.forEach((row, index) => {

            const serial =
                (
                    (page - 1) *
                    perPage
                ) +
                index +
                1;


            let statusHtml = '';

            if (row.status == 0) {

                statusHtml = `
                    <span class="pc-status pc-status-active">
                        <i class="mdi mdi-check-circle"></i>
                        Active
                    </span>
                `;

            } else if (row.status == 1) {

                statusHtml = `
                    <span class="pc-status pc-status-inactive">
                        <i class="mdi mdi-pause-circle-outline"></i>
                        Inactive
                    </span>
                `;

            } else {

                statusHtml = `
                    <span class="pc-status pc-status-archived">
                        Archived
                    </span>
                `;
            }


            const portalUrl = row.login_url
                ? escapeAttribute(row.login_url)
                : '';

            const url = row.login_url
                ? `
                    <div
                        class="passcode-account-url"
                        title="${portalUrl}"
                    >
                        <i class="mdi mdi-link-variant"></i>

                        <span>
                            ${escape(row.login_url)}
                        </span>
                    </div>
                `
                : `
                    <div class="passcode-account-url">
                        <i class="mdi mdi-link-off"></i>
                        No portal URL
                    </div>
                `;

                let favIcon = '';

                const fallbackIcon = escape(
                    row.category_icon || 'mdi-key-outline'
                );

                if (row.favicon) {
                    favIcon = `
                        <img
                            src="${escape(row.favicon)}"
                            alt=""
                            width="32"
                            height="32"
                            class="portal-favicon"
                            onerror="
                                this.style.display='none';
                                this.nextElementSibling.style.display='inline-flex';
                            "
                        >

                        <i
                            class="mdi ${fallbackIcon}"
                            style="display:none;"
                            aria-hidden="true"
                        ></i>
                    `;
                } else {
                    favIcon = `
                        <i
                            class="mdi ${fallbackIcon}"
                            aria-hidden="true"
                        ></i>
                    `;
                }
                


            html += `

                <tr>

                    <td class="text-muted">
                        ${serial}
                    </td>


                    <td>

                        <div class="passcode-account">

                        

                            <div class="passcode-account-icon">

                                ${favIcon}

                            </div>

                            <div class="min-w-0">

                                <div class="passcode-account-name">

                                    ${
                                        row.login_url
                                        ? `
                                            <a
                                                href="${escapeAttribute(row.login_url)}"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                class="text-decoration-none text-dark"
                                                title="Open portal"
                                            >
                                                ${escape(row.account_name)}

                                                <i
                                                    class="mdi mdi-open-in-new ms-1 text-primary"
                                                    style="font-size:11px;"
                                                ></i>
                                            </a>
                                        `
                                        : `
                                            ${escape(row.account_name)}
                                        `
                                    }

                                </div>

                                ${url}

                            </div>

                        </div>

                    </td>


                    <td>

                        <span class="pc-category">

                            <i class="mdi ${escape(
                                row.category_icon
                                || 'mdi-key-outline'
                            )}"></i>

                            ${escape(
                                row.category_name
                            )}

                        </span>

                    </td>


                    <!-- <td>

                        <div class="d-flex align-items-center gap-2">

                            <span
                                class="badge rounded-pill bg-label-success"
                                style="font-size:10px;"
                            >
                                <i class="mdi mdi-shield-lock-outline me-1"></i>
                                Protected
                            </span>

                        </div>

                    </td> -->


                    <td>
                        ${statusHtml}
                    </td>


                    <td class="text-muted">

                        ${escape(
                            row.updated_at || '-'
                        )}

                    </td>


                    <td>

                        <div class="pc-action-group">

                            ${
                                row.login_url
                                ? `
                                    <a
                                        href="${escapeAttribute(row.login_url)}"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        class="pc-portal-btn"
                                        title="Open ${escapeAttribute(row.account_name)} portal"
                                    >
                                        <i class="mdi mdi-open-in-new"></i>
                                        Open
                                    </a>
                                `
                                : `
                                    <span
                                        class="pc-portal-btn disabled"
                                        title="No portal URL configured"
                                    >
                                        <i class="mdi mdi-link-off"></i>
                                        Open
                                    </span>
                                `
                            }


                            <button
                                type="button"
                                class="pc-action"
                                title="View credentials"
                                onclick="view(
                                    ${row.sno},
                                    '${escapeJs(row.account_name)}'
                                )"
                            >
                                <i class="mdi mdi-eye-outline"></i>
                            </button>


                            <button
                                type="button"
                                class="pc-action"
                                title="Edit credential"
                                onclick="edit(${row.sno})"
                            >
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>


                            <button
                                type="button"
                                class="pc-action"
                                title="Change status"
                                onclick="toggleStatus(${row.sno})"
                            >
                                <i class="mdi mdi-toggle-switch-outline"></i>
                            </button>


                            <button
                                type="button"
                                class="pc-action pc-action-danger"
                                title="Archive credential"
                                onclick="remove(${row.sno})"
                            >
                                <i class="mdi mdi-archive-outline"></i>
                            </button>

                        </div>

                    </td>

                </tr>

            `;

        });


        $('#passcodeTableBody')
            .html(html);

    }


    /* =====================================================
       EMPTY
    ===================================================== */

    function showEmpty(
        title = 'No credentials found.',
        message = 'No matching records are available.'
    ) {

        $('#passcodeTableBody').html(`

            <tr>

                <td colspan="7">

                    <div class="pc-empty">

                        <div class="pc-empty-icon">

                            <i class="mdi mdi-shield-key-outline"></i>

                        </div>

                        <div class="pc-empty-title">
                            ${title}
                        </div>

                        <div class="pc-empty-text">
                            ${message}
                        </div>

                    </div>

                </td>

            </tr>

        `);

        $('#passcodePagination')
            .empty();

    }


    /* PAGINATION */

    function renderPagination(pagination) {

        if (pagination.last_page <= 1) {

            $('#passcodePagination')
                .html(`
                    <div class="pc-pagination-info">
                        Showing ${pagination.total} record(s)
                    </div>
                `);

            return;
        }


        let buttons = '';


        buttons += `
            <button
                class="pc-page"
                ${pagination.current_page <= 1 ? 'disabled' : ''}
                onclick="goTo(${pagination.current_page - 1})"
            >
                <i class="mdi mdi-chevron-left"></i>
            </button>
        `;


        for (
            let i = 1;
            i <= pagination.last_page;
            i++
        ) {

            if (
                i === 1 ||
                i === pagination.last_page ||
                Math.abs(
                    i - pagination.current_page
                ) <= 2
            ) {

                buttons += `
                    <button
                        class="pc-page ${
                            i === pagination.current_page
                                ? 'active'
                                : ''
                        }"
                        onclick="goTo(${i})"
                    >
                        ${i}
                    </button>
                `;

            } else if (
                i === pagination.current_page - 3 ||
                i === pagination.current_page + 3
            ) {

                buttons += `
                    <span class="px-1 text-muted">
                        ...
                    </span>
                `;
            }
        }


        buttons += `
            <button
                class="pc-page"
                ${
                    pagination.current_page >= pagination.last_page
                        ? 'disabled'
                        : ''
                }
                onclick="goTo(${pagination.current_page + 1})"
            >
                <i class="mdi mdi-chevron-right"></i>
            </button>
        `;


        $('#passcodePagination').html(`

            <div class="pc-pagination-info">

                Showing
                ${pagination.from || 0}
                -
                ${pagination.to || 0}
                of
                ${pagination.total}

            </div>

            <div class="pc-pagination-buttons">

                ${buttons}

            </div>

        `);

    }


    function goTo(page) {

        if (
            page < 1 ||
            loading
        ) {
            return;
        }

        page = page;

        load();

    }


    /* =====================================================
       ADD
    ===================================================== */

    function openAdd() {

       let addModal = new bootstrap.Modal(document.getElementById('passcodeModal'))

        editMode = false;

        resetForm();

        $('#passcodeModalTitle')
            .text('Add Credential');

        $('#btnSavePasscode .pc-save-text')
            .text('Save Credential');

        addModal.show();

    }


    /* =====================================================
       EDIT
    ===================================================== */

    function edit(id) {
          let addModal = new bootstrap.Modal(document.getElementById('passcodeModal'))

        resetForm();

        $('#passcodeModalTitle')
            .text('Edit Credential');

        $('#btnSavePasscode .pc-save-text')
            .text('Update Credential');


        $.ajax({

            url:
                routes.edit +
                '/' +
                id,

            type: 'GET',

            beforeSend: () => {
                setModalLoading(true);
                addModal.show();

            },

            success: (response) => {
                if (!response.status) {
                    toast(response.message, 'error' );
                    addModal.hide();
                    return;
                }

                const data = response.data;

                $('#pcRecordId').val(data.sno);
                $('#pcCategoryInput').val(data.category_sno).change();
                $('#pcAccountName').val(data.account_name);
                $('#pcLoginUrl').val(data.login_url);
                $('#pcLoginIdentifier').val(data.login_identifier);
                // $('#pcSecondaryIdentifier').val(data.secondary_identifier);
                $('#pcCompanySno').val(data.company_sno);
                $('#pcEntitySno').val(data.entity_sno);
                $('#pcNotes').val(data.notes);
                $('#pcStatusInput').val(data.status);

            },

            error: () => {

                toast(
                    'Unable to load credential.',
                    'error'
                );

                addModal.hide();

            },

            complete: () => {

                setModalLoading(false);

            }

        });

    }


    /* =====================================================
       SAVE
    ===================================================== */

    function save() {

         let addModal = new bootstrap.Modal(document.getElementById('passcodeModal'))
        if (
            $('#btnSavePasscode')
                .prop('disabled')
        ) {
            return;
        }


        clearErrors();


        const id =
            $('#pcRecordId').val();


        const isEdit =
            !!id;


        const url =
            isEdit
                ? routes.update + '/' + id
                : routes.store;


        const method =
            isEdit
                ? 'PUT'
                : 'POST';


        const form =
            $('#passcodeForm');


        const button =
            $('#btnSavePasscode');


        button.prop(
            'disabled',
            true
        );


        $('#pcSaveLoader')
            .removeClass('d-none');


        $('.pc-save-text')
            .text(
                isEdit
                    ? 'Updating...'
                    : 'Saving...'
            );


        $.ajax({

            url: url,

            type: method,

            data:
                form.serialize(),

            success: (response) => {

                if (!response.status) {

                    toast(
                        response.message,
                        'error'
                    );

                    return;
                }


                addModal.hide();

                toast(
                    response.message,
                    'success'
                );


                page = 1;

                load();

            },


            error: (xhr) => {

                if (
                    xhr.status === 422 &&
                    xhr.responseJSON &&
                    xhr.responseJSON.errors
                ) {

                    showErrors(
                        xhr.responseJSON.errors
                    );

                    return;
                }


                toast(
                    xhr.responseJSON?.message
                    ||
                    'Something went wrong.',
                    'error'
                );

            },


            complete: () => {

                button.prop(
                    'disabled',
                    false
                );

                $('#pcSaveLoader')
                    .addClass('d-none');

                $('.pc-save-text')
                    .text(
                        isEdit
                            ? 'Update Credential'
                            : 'Save Credential'
                    );

            }

        });

    }


    /* =====================================================
       VIEW
    ===================================================== */

    function view(id, title) {
         let viewModal = new bootstrap.Modal(document.getElementById('viewPasscodeModal'))

        $('#viewPcTitle')
            .text(title);


        $('#viewPcContent').html(`

            <div class="text-center py-4">

                <div
                    class="spinner-border text-primary"
                ></div>

                <div class="small text-muted mt-2">
                    Loading protected credential...
                </div>

            </div>

        `);


        viewModal.show();


        $.when(

            revealValue(
                id,
                'username'
            ),

            revealValue(
                id,
                'password'
            )

        ).done((username, password) => {

            const userValue =
                username[0]?.value || '';

            const passwordValue =
                password[0]?.value || '';


            $('#viewPcContent').html(`

                <div class="mb-3">

                    <label class="pc-label">
                        Username / Email / Mobile
                    </label>

                    <div class="input-group">

                        <input
                            type="text"
                            class="form-control pc-control"
                            value="${escapeAttribute(userValue)}"
                            readonly
                        >

                        <button
                            class="btn pc-input-action"
                            type="button"
                            onclick="copyValue(this)"
                            data-value="${escapeAttribute(userValue)}"
                        >
                            <i class="mdi mdi-content-copy"></i>
                        </button>

                    </div>

                </div>


                <div>

                    <label class="pc-label">
                        Password
                    </label>

                    <div class="input-group">

                        <input
                            type="password"
                            class="form-control pc-control"
                            value="${escapeAttribute(passwordValue)}"
                            readonly
                        >

                        <button
                            class="btn pc-input-action"
                            type="button"
                            onclick="toggleViewPassword(this)"
                        >
                            <i class="mdi mdi-eye-outline"></i>
                        </button>

                        <button
                            class="btn pc-input-action"
                            type="button"
                            onclick="copyValue(this)"
                            data-value="${escapeAttribute(passwordValue)}"
                        >
                            <i class="mdi mdi-content-copy"></i>
                        </button>

                    </div>

                </div>


                <div class="pc-security-note mt-3">

                    <i class="mdi mdi-shield-alert-outline fs-5"></i>

                    <div>
                        Credential access has been recorded
                        in the security activity log.
                    </div>

                </div>

            `);

        }).fail(() => {

            $('#viewPcContent').html(`

                <div class="alert alert-danger">
                    Unable to retrieve protected credential.
                </div>

            `);

        });

    }


    /* =====================================================
       REVEAL REQUEST
    ===================================================== */

    function revealValue(id, type) {

        return $.ajax({

            url:
                routes.reveal +
                '/' +
                id,

            type: 'POST',

            data: {

                _token:
                    $('meta[name="csrf-token"]').attr('content'),

                type: type

            }

        });

    }


    /* =====================================================
       STATUS
    ===================================================== */

    function toggleStatus(id) {

        if (
            !confirm(
                'Change credential status?'
            )
        ) {
            return;
        }


        $.ajax({

            url:
                routes.status +
                '/' +
                id,

            type: 'POST',

            data: {

                _token:
                    $('meta[name="csrf-token"]').attr('content')

            },

            success: (response) => {

                if (!response.status) {

                    toast(
                        response.message,
                        'error'
                    );

                    return;
                }

                toastr.success(response.message);
                // toast(response.message, 'success' );

                load();
            },
            error: () => {
                toastr.error('Unable to change status.');
                // toast('Unable to change status.','error');
            }

        });

    }


    /* =====================================================
       DELETE / ARCHIVE
    ===================================================== */

    function remove(id) {

        if (
            !confirm(
                'Archive this credential?\n\nThe credential will no longer appear as active.'
            )
        ) {
            return;
        }


        $.ajax({
            url:routes.delete + '/' + id,
            type: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                _method: 'DELETE'
            },
            success: (response) => {
                if (!response.status) {
                    toastr.error(response.message);

                    // toast( response.message, 'error');
                    return;
                }
                toastr.success(response.message);
                // toast(response.message,'success');

                load();

            },
            error: () => {
                toastr.error('Unable to archive credential.')
                // toast('Unable to archive credential.','error');
            }
        });
    }


    /* =====================================================
       RESET
    ===================================================== */

    function resetForm() {

        $('#passcodeForm')[0]
            .reset();

        $('#pcRecordId')
            .val('');

        $('#pcStatusInput')
            .val('0');

        $('#pcLoginPassword')
            .attr('type', 'password');

        $('#btnTogglePassword i')
            .removeClass(
                'mdi-eye-off-outline'
            )
            .addClass(
                'mdi-eye-outline'
            );

        clearErrors();

        setModalLoading(false);

    }


    function clearErrors() {

        $('.pc-error')
            .text('');

        $('.pc-control')
            .removeClass(
                'is-invalid'
            );

    }


    function showErrors(errors) {

        Object.keys(errors)
            .forEach(field => {

                const message =
                    errors[field][0]
                    || 'Invalid value.';

                $(
                    `.pc-error[data-error="${field}"]`
                ).text(message);

                $(
                    `[name="${field}"]`
                ).addClass(
                    'is-invalid'
                );

            });


        const firstError =
            $('.is-invalid')
                .first();

        if (firstError.length) {

            firstError[0]
                .scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });

        }

    }


    function setModalLoading(state) {

        $('#passcodeForm input, #passcodeForm select, #passcodeForm textarea')
            .prop(
                'disabled',
                state
            );

    }


    /* =====================================================
       PASSWORD GENERATOR
    ===================================================== */

    function generatePassword() {

        const chars =
            'ABCDEFGHJKLMNPQRSTUVWXYZ' +
            'abcdefghijkmnopqrstuvwxyz' +
            '23456789' +
            '!@#$%&*';

        let password = '';

        for (
            let i = 0;
            i < 18;
            i++
        ) {

            password +=
                chars.charAt(
                    Math.floor(
                        Math.random() *
                        chars.length
                    )
                );
        }

        return password;

    }


    /* =====================================================
       COPY
    ===================================================== */

    function copyValue(button) {

        const value =
            $(button)
                .attr('data-value');


        if (!value) {
            return;
        }


        navigator.clipboard
            .writeText(value)
            .then(() => {
                toastr.success('Copied to clipboard.')
                // toast('Copied to clipboard.','success');
            });

    }


    function toggleViewPassword(button) {

        const input =
            $(button)
                .closest('.input-group')
                .find('input');

        const icon =
            $(button).find('i');


        if (
            input.attr('type') === 'password'
        ) {

            input.attr(
                'type',
                'text'
            );

            icon
                .removeClass(
                    'mdi-eye-outline'
                )
                .addClass(
                    'mdi-eye-off-outline'
                );

        } else {

            input.attr(
                'type',
                'password'
            );

            icon
                .removeClass(
                    'mdi-eye-off-outline'
                )
                .addClass(
                    'mdi-eye-outline'
                );
        }

    }


    /* =====================================================
       REFRESH
    ===================================================== */

    function refresh() {

        page = 1;

        load();

    }


    /* Custom TOAST  */
    function toast(message, type = 'success') {
        const toast = $('#pcToast');
        const icon = toast.find('i');

        toast.removeClass('success error').addClass(type);
        icon.attr('class', type === 'success' ? 'mdi mdi-check-circle-outline' : 'mdi mdi-alert-circle-outline');

        $('#pcToastMessage').text(message);

        toast.addClass('show');


        setTimeout(
            () => {
                toast.removeClass('show');
            },
            3000
        );
    }


    /* =====================================================
       ESCAPE
    ===================================================== */

    function escape(value) {

        if (
            value === null ||
            value === undefined
        ) {
            return '';
        }

        return $('<div>')
            .text(value)
            .html();

    }


    function escapeAttribute(value) {

        return escape(value)
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

    }


    function escapeJs(value) {

        if (!value) {
            return '';
        }

        return String(value)
            .replace(/\\/g, '\\\\')
            .replace(/'/g, "\\'")
            .replace(/"/g, '&quot;')
            .replace(/\n/g, '\\n')
            .replace(/\r/g, '\\r');

    }


    /* START */

    init();

</script>

<!-- https://chatgpt.com/share/6a88ad14-c840-83e9-b424-f074168e0e3e -->
@endsection