@extends('layouts/layoutMaster')

@section('title', 'Manage Training')

@section('vendor-style')
@vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">

<style>
    :root {
        --tp-border: #e9edf3;
        --tp-muted: #6b7280;
    }

    .tp-page {
        background: #f8fafc;
    }

    .tp-kpi {
        height: 100%;
        padding: 16px;
        border: 1px solid var(--tp-border);
        border-radius: 14px;
        background: #fff;
    }

    .tp-kpi-icon {
        width: 42px;
        height: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        background: rgba(241 , 99, 99, .10);
        border: 1px solid #ab2b22;
    }

    /* .tp-status-scheduled {
        color: #fab845;
        
        border: 1px solid #fab845;
    } */

    /* .tp-status-rescheduled {
        color: #c2410c;
        
    } */

    /* .tp-status-completed {
        color: #15803d;
       
    } */

    /* .tp-status-cancelled {
        color: #b91c1c;
        
    } */

    .dashboard-label-Total{
        color:  #ab2b22;
    }

    .dashboard-label-Scheduled{
        color:  #fab845;
    }

    .dashboard-label-Rescheduled{
        color: #c2410c;
    }
    .dashboard-label-Completed{
         color:  #15803d;
    }
    .dashboard-label-Upcoming{
        color: #1d4ed8;
    }
    .dashboard-label-Cancelled{
        color:  #b91c1c;
    }

    .tp-kpi-icon.Scheduled{
        background: #fffae8;
        border: 1px solid #fab845;
    }
    .tp-kpi-icon.Rescheduled{
        background: #fff7ed;
        border: 1px solid #c2410c;
    }
    .tp-kpi-icon.Completed{
         background: #dcfce7;
         border: 1px solid #15803d;
    }
    .tp-kpi-icon.Upcoming{
        /* color: #1d4ed8; */
        border: 1px solid #1d4ed8;
        background: #dbeafe;
    }
    .tp-kpi-icon.Cancelled{
        background: #fee2e2;
        border: 1px solid #b91c1c;
    }

    .tp-toolbar,
    .tp-card {
        border: 1px solid var(--tp-border);
        border-radius: 14px;
        background: #fff;
    }

    .tp-toolbar {
        padding: 14px;
    }

    .tp-table-wrap {
        overflow-x: auto;
        border: 1px solid var(--tp-border);
        /* border-radius: 14px; */
    }

    .tp-table {
        min-width: 1200px;
        margin-bottom: 0;
    }

    .tp-table thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        padding-top: 12px;
        padding-bottom: 12px;
        /* background: #f8fafc; */
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .04em;
        text-transform: uppercase;
    }

    .tp-table tbody td {
        padding-top: 13px;
        padding-bottom: 13px;
        vertical-align: middle;
    }

    .tp-table tbody tr:hover {
        background: #fbfdff;
    }

    .tp-status {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 5px 9px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 800;
    }

    .tp-status-scheduled {
        color: black;
        background: #fab845;
        border: 1px solid #fab845;
    }

    .tp-status-rescheduled {
        color: white;
        background: #c2410c;
    }

    .tp-status-completed {
        color: white;
        background: #15803d;
    }

    .tp-status-cancelled {
        color: white;
        background: #b91c1c;
    }

    .tp-pill {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 7px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 800;
    }

    .tp-pill-blue {
        color: #1d4ed8;
        background: #dbeafe;
    }

    .tp-pill-green {
        color: #15803d;
        background: #dcfce7;
    }

    .tp-pill-gray {
        color: #475569;
        background: #f1f5f9;
    }

    .tp-schedule-summary {
        min-width: 235px;
    }

    .tp-schedule-line {
        display: flex;
        align-items: flex-start;
        gap: 7px;
        margin-bottom: 3px;
    }

    .tp-schedule-date {
        font-weight: 800;
        white-space: nowrap;
    }

    .tp-session-chip {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        margin: 2px 2px 0 0;
        padding: 4px 7px;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        background: #f8fafc;
        font-size: 10px;
        font-weight: 700;
    }

    .tp-more-sessions {
        margin-top: 4px;
        /* color: #64748b; */
        font-size: 10px;
        font-weight: 700;
    }

    .tp-staff-history-btn {
        white-space: nowrap;
    }

    .tp-modal .flatpickr-calendar.static {
        z-index: 1065;
    }

    .tp-modal .modal-content {
        overflow: hidden;
        border: 0;
        border-radius: 18px;
    }

    .tp-modal .modal-header {
        border-bottom: 1px solid var(--tp-border);
        background: linear-gradient(135deg, #f8fbff, #fff);
    }

    .tp-section {
        margin-bottom: 14px;
        padding: 15px;
        border: 1px solid var(--tp-border);
        border-radius: 14px;
        background: #fff;
    }

    .tp-section-title {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 12px;
        font-size: 13px;
        font-weight: 800;
    }

    .tp-required::after {
        content: ' *';
        color: #dc2626;
    }

    .tp-help {
        margin-top: 4px;
        color: var(--tp-muted);
        font-size: 11px;
        line-height: 1.4;
    }

    .tp-schedule-mode-card {
        height: 100%;
        padding: 12px;
        border: 1px solid var(--tp-border);
        border-radius: 12px;
        cursor: pointer;
        background: #fff;
    }

    .tp-schedule-mode-card:has(input:checked) {
        border-color: rgba(99, 102, 241, .55);
        background: #f8faff;
        box-shadow: inset 0 0 0 1px rgba(99, 102, 241, .18);
    }

    .tp-attendee-wrap {
        overflow: hidden;
        border: 1px solid var(--tp-border);
        border-radius: 14px;
    }

    .tp-attendee-head {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 12px;
        background: #f8fafc;
    }

    .tp-attendee-scroll {
        max-height: 330px;
        overflow-y: auto;
    }

    .tp-attendee-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        border-top: 1px solid #f1f5f9;
    }

    .tp-attendee-row.tp-busy {
        background: #fff7f7;
    }

    .tp-avatar {
        width: 40px;
        height: 40px;
        display: flex;
        flex: 0 0 auto;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #ffeeee;
        font-size: 12px;
        font-weight: 800;
    }

    .tp-busy-badge,
    .tp-ok-badge {
        padding: 3px 7px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 800;
    }

    .tp-busy-badge {
        color: #b91c1c;
        background: #fee2e2;
    }

    .tp-ok-badge {
        color: #15803d;
        background: #dcfce7;
    }

    .tp-calendar {
        overflow: hidden;
        border: 1px solid var(--tp-border);
        border-radius: 14px;
        background: #fff;
    }

    .tp-cal-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 14px;
        border-bottom: 1px solid var(--tp-border);
    }

    .tp-cal-grid {
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
    }

    .tp-cal-week {
        padding: 9px;
        border-right: 1px solid var(--tp-border);
        border-bottom: 1px solid var(--tp-border);
        background: #f8fafc;
        color: #64748b;
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
    }

    .tp-cal-day {
        min-height: 135px;
        padding: 7px;
        border-right: 1px solid var(--tp-border);
        border-bottom: 1px solid var(--tp-border);
        background: #fff;
    }

    .tp-cal-day.is-other {
        background: #fbfcfe;
        color: #94a3b8;
    }

    .tp-cal-day.is-today {
        box-shadow: inset 0 0 0 2px rgba(99, 102, 241, .35);
    }

    .tp-cal-num {
        margin-bottom: 6px;
        font-size: 11px;
        font-weight: 800;
    }

    .tp-event {
        display: block;
        width: 100%;
        margin-bottom: 5px;
        padding: 5px 6px;
        overflow: hidden;
        border: 0;
        border-radius: 8px;
        text-align: left;
        font-size: 10px;
        font-weight: 700;
        text-overflow: ellipsis;
        white-space: nowrap;
        cursor: pointer;
    }

    .tp-event-scheduled { color: #1d4ed8; background: #e8f1ff; }
    .tp-event-rescheduled { color: #c2410c; background: #fff7ed; }
    .tp-event-completed { color: #15803d; background: #dcfce7; }
    .tp-event-cancelled { color: #b91c1c; background: #fee2e2; }

    .tp-empty,
    .tp-loader {
        padding: 28px;
        color: #94a3b8;
        text-align: center;
    }

    .tp-info-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 10px;
    }

    .tp-info {
        padding: 11px;
        border: 1px solid var(--tp-border);
        border-radius: 12px;
    }

    .tp-info small {
        display: block;
        color: #64748b;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .tp-info strong {
        display: block;
        margin-top: 3px;
        font-size: 13px;
    }

    .tp-toast {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 1100;
        display: none;
        min-width: 280px;
        max-width: 420px;
        padding: 12px 14px;
        border-radius: 12px;
        background: #ab2b22;
        color: #fff;
        box-shadow: 0 10px 30px rgba(15, 23, 42, .2);
    }

    .tp-toast.success { background: #166534; }
    .tp-toast.error { background: #b91c1c; }
    .tp-toast.info { background: #1d4ed8; }

    .tp-custom-date-badge{

    }

    /* STATUS CHANGE MODAL */
    .tp-status-current {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border: 1px solid #e5eaf0;
        border-radius: 12px;
        background: #fbfcfe;
    }

    .tp-status-current-label {
        color: #64748b;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: .05em;
        text-transform: uppercase;
    }

    .tp-status-current-value {
        margin-top: 3px;
        font-size: 13px;
        font-weight: 800;
        color: #0f172a;
    }

    .tp-status-choice-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }

    .tp-status-choice {
        position: relative;
        display: block;
        height: 100%;
        padding: 13px;
        border: 1px solid #e5eaf0;
        border-radius: 12px;
        background: #fff;
        cursor: pointer;
        transition: .15s ease;
    }

    .tp-status-choice:hover {
        border-color: #cbd5e1;
        background: #fbfdff;
    }

    .tp-status-choice:has(input:checked) {
        border-color: rgba(99, 102, 241, .65);
        background: #f8faff;
        box-shadow: inset 0 0 0 1px rgba(99, 102, 241, .14);
    }

    .tp-status-choice input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
    }

    .tp-status-choice-icon {
        width: 34px;
        height: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 8px;
        border-radius: 9px;
        font-size: 18px;
    }

    .tp-status-choice.scheduled .tp-status-choice-icon { background: #fffae8; color: #a16207; }
    .tp-status-choice.rescheduled .tp-status-choice-icon { background: #fff7ed; color: #c2410c; }
    .tp-status-choice.cancelled .tp-status-choice-icon { background: #fee2e2; color: #b91c1c; }

    .tp-status-choice-title {
        color: #0f172a;
        font-size: 12px;
        font-weight: 800;
    }

    .tp-status-choice-text {
        margin-top: 3px;
        color: #64748b;
        font-size: 10px;
        line-height: 1.45;
    }

    .tp-status-schedule-switch {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
    }

    .tp-status-schedule-option {
        position: relative;
        display: block;
        padding: 9px 11px;
        border: 1px solid #e5eaf0;
        border-radius: 10px;
        background: #fff;
        cursor: pointer;
    }

    .tp-status-schedule-option:has(input:checked) {
        border-color: rgba(99, 102, 241, .55);
        background: #f8faff;
    }

    .tp-status-schedule-option input {
        margin-right: 6px;
    }

    .tp-status-note {
        padding: 10px 12px;
        border-radius: 10px;
        font-size: 11px;
        line-height: 1.5;
    }

    .tp-status-note.info { background: #eff6ff; color: #1e40af; }
    .tp-status-note.warning { background: #fff7ed; color: #9a3412; }

    .tp-status-error {
        margin-top: 5px;
        color: #dc2626;
        font-size: 10px;
    }

    @media (max-width: 767px) {
        .tp-status-choice-grid { grid-template-columns: 1fr; }
        .tp-status-current { align-items: flex-start; flex-direction: column; }
    }

    @media (max-width: 1199px) {
        .tp-info-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    }

    @media (max-width: 767px) {
        .tp-info-grid { grid-template-columns: 1fr; }
        .tp-cal-day { min-height: 105px; }
        .tp-cal-head { align-items: flex-start; flex-direction: column; }
        .tp-table { min-width: 1050px; }
    }
</style>
<style>
    /* TRAINING VIEW MODAL */

.tp-view-modal-content {
    border: 0;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 24px 70px rgba(15, 23, 42, .20);
}

.tp-view-header {
    padding: 20px 24px;
    background:
        linear-gradient(
            135deg,
            #f8fbff 0%,
            #ffffff 65%
        );
    border-bottom: 1px solid #e9edf3;
}

.tp-view-title-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffeeee;
    color: #ab2b22;
    font-size: 25px;
    flex: 0 0 auto;
}

.tp-view-id {
    display: inline-flex;
    align-items: center;
    min-height: 24px;
    padding: 3px 8px;
    border-radius: 7px;
    background: #f1f5f9;
    color: #64748b;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .04em;
}

.tp-view-header-actions {
    flex-wrap: wrap;
}

.tp-view-body {
    padding: 20px 24px;
    background: #f8fafc;
}

/* Hero */

.tp-view-hero {
    min-height: 105px;
    padding: 20px;
    border: 1px solid #e5eaf0;
    border-radius: 16px;
    background: linear-gradient(
        135deg,
        #ffffff 0%,
        #f8fbff 100%
    );
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.tp-view-hero-main {
    display: flex;
    align-items: center;
    gap: 15px;
}

.tp-view-hero-icon {
    width: 50px;
    height: 50px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e0f2fe;
    color: #0369a1;
    font-size: 25px;
}

.tp-view-eyebrow {
    color: #94a3b8;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .08em;
    text-transform: uppercase;
}

.tp-view-hero-title {
    margin-top: 3px;
    font-size: 17px;
    font-weight: 800;
    color: #0f172a;
}

.tp-view-hero-subtitle {
    margin-top: 3px;
    color: #64748b;
    font-size: 12px;
}

.tp-view-duration {
    min-width: 125px;
    text-align: right;
}

.tp-view-duration-value {
    margin-top: 3px;
    font-size: 19px;
    font-weight: 800;
    color: #0f172a;
}

/* Info */

.tp-view-info-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
}

.tp-view-info-item {
    min-height: 78px;
    padding: 13px 14px;
    border: 1px solid #e9edf3;
    border-radius: 13px;
    background: #ffffff;
}

.tp-view-info-label {
    color: #94a3b8;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.tp-view-info-value {
    margin-top: 5px;
    color: #0f172a;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.4;
}

/* Cards */

.tp-view-card {
    border: 1px solid #e5eaf0;
    border-radius: 16px;
    background: #ffffff;
    overflow: hidden;
}

.tp-view-card-header {
    padding: 15px 17px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 12px;
    border-bottom: 1px solid #edf1f5;
}

.tp-view-card-title {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #ab2b22;
    font-size: 13px;
    font-weight: 800;
}

.tp-view-card-title i {
    color: #ab2b22;
    font-size: 19px;
}

.tp-view-card-subtitle {
    margin-top: 3px;
    color: #94a3b8;
    font-size: 11px;
}

/* Schedule */

.tp-view-session-count {
    padding: 4px 9px;
    border-radius: 999px;
    background: #ffeeee;
    color: #ab2b22;
    font-size: 10px;
    font-weight: 800;
}

.tp-view-schedule-list {
    max-height: 280px;
    overflow: auto;
    padding: 5px 0;
}

.tp-view-schedule-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 11px 17px;
    border-bottom: 1px solid #f1f5f9;
}

.tp-view-schedule-row:last-child {
    border-bottom: 0;
}

.tp-view-date-tile {
    width: 54px;
    height: 56px;
    border-radius: 12px;
    background: #f8fafc;
    border: 1px solid #e7ebf0;
    text-align: center;
    flex: 0 0 auto;
    overflow: hidden;
}

.tp-view-date-month {
    padding: 3px 4px;
    background: #ffeeee;
    color: #ab2b22;
    font-size: 8px;
    font-weight: 900;
    text-transform: uppercase;
}

.tp-view-date-day {
    margin-top: 4px;
    color: #ab2b22;
    font-size: 18px;
    font-weight: 900;
    line-height: 1;
}

.tp-view-date-week {
    margin-top: 3px;
    color: #94a3b8;
    font-size: 8px;
    font-weight: 700;
    text-transform: uppercase;
}

.tp-view-schedule-title {
    color: #ab2b22;
    font-size: 12px;
    font-weight: 700;
}

.tp-view-schedule-time {
    margin-top: 3px;
    color: #64748b;
    font-size: 11px;
}

/* Trainer */

.tp-view-trainer {
    padding: 17px;
}

.tp-view-trainer-profile {
    display: flex;
    align-items: center;
    gap: 12px;
}

.tp-view-trainer-avatar {
    width: 46px;
    height: 46px;
    border-radius: 50%;
    background: #ffeeee;
    color: #ab2b22;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    font-weight: 900;
}

.tp-view-trainer-name {
    color: #ab2b22;
    font-size: 14px;
    font-weight: 800;
}

.tp-view-trainer-type {
    margin-top: 3px;
    color: #94a3b8;
    font-size: 11px;
}

/* Scope */

.tp-view-scope-item {
    padding: 11px 12px;
    border: 1px solid #edf1f5;
    border-radius: 11px;
    background: #fbfcfe;
}

.tp-view-scope-label {
    color: #94a3b8;
    font-size: 9px;
    font-weight: 900;
    text-transform: uppercase;
}

.tp-view-scope-value {
    margin-top: 3px;
    color: #334155;
    font-size: 11px;
    line-height: 1.5;
    font-weight: 600;
}

/* Description */

.tp-view-description {
    padding: 16px 17px;
    color: #475569;
    font-size: 12px;
    line-height: 1.75;
    white-space: pre-line;
}

/* Requirements */

.tp-view-requirements {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 15px 17px;
}

.tp-view-requirement {
    min-width: 205px;
    flex: 1;
    padding: 12px;
    border-radius: 12px;
    border: 1px solid #edf1f5;
    background: #fbfcfe;
}

.tp-view-requirement-icon {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 8px;
}

.tp-view-requirement-icon.green {
    background: #dcfce7;
    color: #15803d;
}

.tp-view-requirement-icon.blue {
    background: #dbeafe;
    color: #1d4ed8;
}

.tp-view-requirement-icon.gray {
    background: #f1f5f9;
    color: #64748b;
}

.tp-view-requirement-title {
    color: #ab2b22;
    font-size: 12px;
    font-weight: 800;
}

.tp-view-requirement-text {
    margin-top: 3px;
    color: #64748b;
    font-size: 10px;
}

/* Attendance */

.tp-view-attendance-summary {
    color: #64748b;
    font-size: 11px;
    font-weight: 700;
}

.tp-attendance-progress-wrap {
    padding: 15px 17px 0;
}

.tp-attendance-progress {
    height: 7px;
    border-radius: 99px;
    background: #eef2f7;
}

.tp-attendance-progress .progress-bar {
    border-radius: 99px;
}

.tp-view-attendee-list {
    max-height: 390px;
    overflow: auto;
}

.tp-view-attendee {
    padding: 11px 17px;
    display: flex;
    align-items: center;
    gap: 10px;
    border-top: 1px solid #f1f5f9;
}

.tp-view-attendee:last-child {
    border-bottom: 0;
}

.tp-view-attendee-avatar {
    width: 35px;
    height: 35px;
    flex: 0 0 auto;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f1f5f9;
    color: #475569;
    font-size: 10px;
    font-weight: 900;
}

.tp-view-attendee-name {
    color: #ab2b22;
    font-size: 12px;
    font-weight: 700;
}

.tp-view-attendee-meta {
    margin-top: 2px;
    color: #94a3b8;
    font-size: 10px;
}

/* Footer */

.tp-view-footer {
    padding: 13px 20px;
    border-top: 1px solid #e9edf3;
    background: #ffffff;
}

@media (max-width: 991px) {
    .tp-view-info-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .tp-view-hero {
        align-items: flex-start;
        flex-direction: column;
    }

    .tp-view-duration {
        text-align: left;
    }
}

@media (max-width: 575px) {
    .tp-view-header {
        padding: 16px;
    }

    .tp-view-body {
        padding: 14px;
    }

    .tp-view-info-grid {
        grid-template-columns: 1fr;
    }

    .tp-view-header-actions {
        width: 100%;
    }

    .tp-view-header-actions .btn {
        flex: 1;
    }

    .tp-view-footer {
        flex-wrap: wrap;
    }
}
</style>

<style>
.tp-feature-row { border:1px solid #edf1f5; border-radius:12px; padding:11px 12px; background:#fff; margin-bottom:8px; }
.tp-feature-row:hover { background:#fbfdff; }
.tp-feature-row .tp-feature-meta { color:#64748b; font-size:11px; }
.tp-session-card { border:1px solid #e5eaf0; border-radius:14px; background:#fff; padding:14px; margin-bottom:10px; }
.tp-session-card.is-completed { border-left:4px solid #15803d; }
.tp-session-card.is-progress { border-left:4px solid #c2410c; }
.tp-session-card.is-cancelled { border-left:4px solid #b91c1c; }
.tp-session-date { width:58px; min-width:58px; height:58px; border-radius:12px; background:#ffeeee; color:#ab2b22; display:flex; flex-direction:column; align-items:center; justify-content:center; }
.tp-session-date strong { font-size:19px; line-height:1; }
.tp-session-date span { font-size:9px; font-weight:800; text-transform:uppercase; }
.tp-action-btn { border:1px solid #e5e7eb; border-radius:8px; background:#fff; }
.tp-action-btn:hover { background:#f8fafc; }


/* Training attendance workflow */
.tp-attendance-workflow {
    padding: 12px 14px;
    border: 1px solid #e7ecf2;
    border-radius: 14px;
    background: linear-gradient(135deg, #fbfdff, #f8fafc);
}
.tp-attendance-workflow-badge {
    display:inline-flex;
    align-items:center;
    gap:6px;
    padding:5px 9px;
    border-radius:999px;
    font-size:10px;
    font-weight:800;
    background:#eef2ff;
    color:#4338ca;
}
.tp-attendance-workflow-note { margin-top:4px; color:#64748b; font-size:11px; line-height:1.5; }
.tp-attendance-stat-grid { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:10px; }
.tp-attendance-stat-card { padding:11px 12px; border:1px solid #e8edf3; border-radius:13px; background:#fff; }
.tp-attendance-stat-card .label { color:#64748b; font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.03em; }
.tp-attendance-stat-card .value { margin-top:3px; font-size:20px; font-weight:900; line-height:1; }
.tp-attendance-grid-head,
.tp-attendance-row { display:grid; grid-template-columns:minmax(220px,1.4fr) 125px minmax(110px,.55fr) minmax(220px,1fr); align-items:center; gap:12px; }
.tp-attendance-grid-head { padding:9px 12px; border-bottom:1px solid #e8edf3; background:#f8fafc; color:#64748b; font-size:10px; font-weight:800; text-transform:uppercase; letter-spacing:.04em; }
.tp-attendance-row { padding:12px; border-top:1px solid #f1f5f9; background:#fff; }
.tp-attendance-row:hover { background:#fbfdff; }
.tp-attendance-person { display:flex; align-items:center; gap:10px; min-width:0; }
.tp-attendance-person .name { color:#1e293b; font-size:12px; font-weight:800; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.tp-attendance-person .meta { margin-top:2px; color:#94a3b8; font-size:10px; }
.tp-readonly-score { min-height:34px; display:flex; align-items:center; padding:0 10px; border:1px dashed #dbe2ea; border-radius:9px; color:#64748b; background:#f8fafc; font-size:10px; font-weight:700; }
.tp-attendance-status-select { min-width:0; }
.tp-complete-modal .modal-content { border-radius:20px; box-shadow:0 28px 80px rgba(15,23,42,.22); }
.tp-complete-modal .modal-header { padding:18px 22px; background:linear-gradient(135deg,#f8fbff 0%,#ffffff 70%); }
.tp-complete-modal .modal-body { background:#f8fafc; }
.tp-complete-modal .tp-info { min-height:74px; background:#fff; }
.tp-complete-modal .tp-attendance-workflow { box-shadow:0 4px 18px rgba(15,23,42,.035); }
.tp-complete-modal .tp-attendance-stat-card { box-shadow:0 4px 14px rgba(15,23,42,.035); }
.tp-complete-modal .tp-attendee-wrap { background:#fff; box-shadow:0 8px 25px rgba(15,23,42,.04); }
.tp-complete-modal .tp-attendee-head { background:#fff; border-bottom:1px solid #e8edf3; padding:12px 14px; }
.tp-complete-modal .tp-attendance-row { min-height:70px; padding:10px 12px; }
.tp-complete-modal .tp-attendance-row:first-child { border-top:0; }
.tp-complete-modal .tp-attendance-row:hover { background:#fbfdff; }
.tp-complete-modal .tp-staff-avatar { width:42px; height:42px; min-width:42px; max-width:42px; max-height:42px; overflow:hidden; display:flex; align-items:center; justify-content:center; border-radius:12px; background:#ffeeee; color:#ab2b22; font-size:12px; font-weight:900; flex:0 0 42px; }
.tp-complete-modal .tp-staff-avatar img { width:100%; height:100%; max-width:100%; max-height:100%; object-fit:cover; display:block; border-radius:inherit; }
.tp-complete-modal .tp-attendance-person { min-width:0; }
.tp-complete-modal .tp-attendance-person .name { font-size:12px; font-weight:900; color:#172033; }
.tp-complete-modal .tp-attendance-person .meta { font-size:10px; color:#94a3b8; margin-top:2px; }
.tp-complete-modal .tp-attendance-row .form-select,
.tp-complete-modal .tp-attendance-row .form-control { border-radius:9px; min-height:34px; }
.tp-complete-modal .tp-readonly-score { justify-content:center; font-size:10px; }
.tp-complete-modal .tp-outcome-column { min-width:0; }
.tp-complete-modal .tp-completion-hint { padding:10px 12px; border:1px solid #dbeafe; border-radius:12px; background:#eff6ff; color:#1e3a8a; font-size:10px; line-height:1.5; }
.tp-complete-modal .tp-completion-hint.success { border-color:#bbf7d0; background:#f0fdf4; color:#166534; }
@media(max-width:991px){.tp-complete-modal .tp-attendance-grid-head{display:none;}.tp-complete-modal .tp-attendance-row{grid-template-columns:1fr;}.tp-complete-modal .tp-outcome-column{width:100%;}.tp-complete-modal .tp-staff-avatar{width:40px;height:40px;min-width:40px;max-width:40px;max-height:40px;flex-basis:40px;}}
@media(max-width:991px){ .tp-attendance-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.tp-attendance-grid-head{display:none;}.tp-attendance-row{grid-template-columns:1fr;gap:8px;}.tp-attendance-row .tp-attendance-status-select,.tp-attendance-row .tp-score-column,.tp-attendance-row .tp-outcome-column{width:100%;}.tp-attendance-row .form-select,.tp-attendance-row .form-control{width:100%!important;} }
@media(max-width:575px){ .tp-attendance-stat-grid{grid-template-columns:1fr 1fr;} }

/* Trainer management */
.tp-trainer-modal .modal-content { border:0; border-radius:20px; overflow:hidden; }
.tp-trainer-modal .modal-header { border-bottom:1px solid #edf1f5; background:linear-gradient(135deg,#fbfdff,#fff); }
.tp-trainer-toolbar { border:1px solid #e9edf3; border-radius:14px; background:#fff; padding:12px; }
.tp-trainer-pane { height:520px; min-height:520px; border:1px solid #e8edf3; border-radius:16px; background:#f8fafc; overflow:hidden; display:flex; flex-direction:column; }
.tp-trainer-pane-header { padding:12px 14px; border-bottom:1px solid #e8edf3; background:#fff; }
.tp-trainer-list { flex:1; overflow:auto; padding:10px; }
.tp-trainer-person { display:flex; align-items:center; gap:10px; padding:11px; margin-bottom:8px; border:1px solid #e7ecf2; border-radius:12px; background:#fff; transition:.18s ease; }
.tp-trainer-person:hover { transform:translateY(-1px); box-shadow:0 6px 18px rgba(15,23,42,.06); border-color:#cfd8e3; }
.tp-trainer-person:last-child { margin-bottom:0; }
.tp-trainer-avatar { width:42px; height:42px; flex:0 0 42px; border-radius:50%; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#ffeeee; color:#ab2b22; font-size:12px; font-weight:900; }
.tp-trainer-avatar img { width:100%; height:100%; object-fit:cover; }
.tp-trainer-card-title { font-size:12px; font-weight:800; color:#1e293b; }
.tp-trainer-card-meta { margin-top:2px; font-size:10px; color:#64748b; line-height:1.45; }
.tp-trainer-badge { display:inline-flex; align-items:center; gap:4px; padding:4px 7px; border-radius:999px; font-size:9px; font-weight:800; }
.tp-trainer-badge.active { background:#dcfce7; color:#166534; }
.tp-trainer-badge.inactive { background:#f1f5f9; color:#64748b; }
.tp-trainer-stat { min-width:92px; padding:8px 10px; border:1px solid #e9edf3; border-radius:12px; background:#fff; }
.tp-trainer-stat strong { display:block; font-size:17px; line-height:1.1; }
.tp-trainer-stat span { display:block; margin-top:3px; font-size:9px; color:#64748b; font-weight:800; text-transform:uppercase; letter-spacing:.04em; }
.tp-trainer-editor { border:1px solid #e8edf3; border-radius:16px; background:#fff; overflow:hidden; }
.tp-trainer-editor-top { padding:15px; border-bottom:1px solid #edf1f5; background:linear-gradient(135deg,#fbfdff,#fff); }
.tp-trainer-selected { display:flex; align-items:center; gap:12px; padding:12px; border:1px solid #e8edf3; border-radius:14px; background:#f8fafc; }
.tp-trainer-selected .tp-trainer-avatar { width:48px; height:48px; flex-basis:48px; }
.tp-trainer-helper { font-size:10px; color:#94a3b8; }
.tp-trainer-pagination { padding:10px 12px; border-top:1px solid #e8edf3; background:#fff; display:flex; justify-content:space-between; align-items:center; gap:10px; }
.tp-trainer-pagination .pagination { margin:0; }
.tp-trainer-empty { min-height:250px; display:flex; align-items:center; justify-content:center; text-align:center; padding:30px; color:#94a3b8; font-size:11px; }
.tp-trainer-loading { min-height:250px; display:flex; align-items:center; justify-content:center; gap:8px; color:#64748b; font-size:11px; }
.tp-trainer-select2 .select2-container { width:100% !important; }
.tp-trainer-modal .select2-container--default .select2-selection--single { min-height:38px; border-color:#dfe5ec; }
 .tp-scope-loading { color:#64748b; font-size:10px; }
.tp-trainer-no-entity { min-height:250px; display:flex; align-items:center; justify-content:center; text-align:center; padding:28px; color:#64748b; }
.tp-trainer-add-btn { min-width:74px; }
.tp-session-attendance-toolbar { padding:12px; border:1px solid #e8edf3; border-radius:14px; background:linear-gradient(135deg,#fbfdff,#f8fafc); }
.tp-session-attendance-kpis { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px; }
.tp-session-attendance-kpi { padding:9px 10px; border:1px solid #e8edf3; border-radius:11px; background:#fff; }
.tp-session-attendance-kpi .label { color:#64748b; font-size:9px; font-weight:800; text-transform:uppercase; letter-spacing:.04em; }
.tp-session-attendance-kpi .value { margin-top:2px; font-size:17px; font-weight:900; }
.tp-session-attendance-row { display:grid; grid-template-columns:minmax(220px,1fr) minmax(330px,1fr); align-items:center; gap:14px; padding:11px 12px; border-top:1px solid #edf1f5; background:#fff; }
.tp-session-attendance-row:hover { background:#fbfdff; }
.tp-session-attendance-person { display:flex; align-items:center; gap:10px; min-width:0; }
.tp-session-attendance-person .name { font-size:12px; font-weight:800; color:#172033; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.tp-session-attendance-person .meta { margin-top:2px; font-size:10px; color:#64748b; }
.tp-attendance-choice { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:7px; }
.tp-attendance-choice button { border:1px solid #e2e8f0; background:#fff; color:#64748b; border-radius:10px; padding:8px 9px; font-size:10px; font-weight:800; transition:.15s ease; }
.tp-attendance-choice button:hover { transform:translateY(-1px); border-color:#cbd5e1; }
.tp-attendance-choice button.is-present { border-color:#86efac; background:#f0fdf4; color:#166534; }
.tp-attendance-choice button.is-absent { border-color:#fca5a5; background:#fef2f2; color:#991b1b; }
.tp-attendance-choice button.is-pending { border-color:#cbd5e1; background:#f8fafc; color:#475569; }
.tp-session-attendance-search { max-width:320px; }
@media(max-width:991px){ .tp-session-attendance-kpis{grid-template-columns:repeat(2,minmax(0,1fr));}.tp-session-attendance-row{grid-template-columns:1fr;gap:9px}.tp-session-attendance-search{max-width:none;width:100%} }
.tp-trainer-step-card { border:1px solid #e8edf3; border-radius:16px; background:linear-gradient(180deg,#fbfdff 0,#fff 100%); padding:14px; }
.tp-trainer-step-kicker { color:#ab2b22; font-size:9px; font-weight:900; letter-spacing:.08em; text-transform:uppercase; }
.tp-trainer-step-title { margin-top:2px; color:#172033; font-size:15px; font-weight:900; }
.tp-trainer-step-text { margin-top:3px; color:#64748b; font-size:11px; line-height:1.5; max-width:720px; }
.tp-trainer-selection-state { display:inline-flex; align-items:center; gap:5px; padding:7px 10px; border:1px solid #e8edf3; border-radius:999px; background:#fff; color:#64748b; font-size:10px; font-weight:800; white-space:nowrap; }
.tp-trainer-selection-state.is-selected { border-color:#bbf7d0; background:#f0fdf4; color:#166534; }
.tp-trainer-editor-filter { padding:11px; border:1px solid #e8edf3; border-radius:13px; background:#f8fafc; }
.tp-trainer-filter-hint { color:#64748b; font-size:10px; line-height:1.4; }
.tp-trainer-editor-staff-panel { overflow:hidden; border:1px solid #e8edf3; border-radius:14px; background:#fff; }
.tp-trainer-editor-staff-list { padding:10px; }
.tp-trainer-editor-staff-item { display:flex; align-items:center; gap:11px; width:100%; margin-bottom:8px; padding:10px; border:1px solid #e7ecf2; border-radius:12px; background:#fff; cursor:pointer; text-align:left; transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease,background .15s ease; }
.tp-trainer-editor-staff-item:last-child { margin-bottom:0; }
.tp-trainer-editor-staff-item:hover { transform:translateY(-1px); border-color:#cbd5e1; box-shadow:0 7px 20px rgba(15,23,42,.06); }
.tp-trainer-editor-staff-item.is-selected { border-color:#bbf7d0; background:#f0fdf4; box-shadow:inset 0 0 0 1px rgba(34,197,94,.08); }
.tp-trainer-editor-staff-item .staff-main { min-width:0; flex:1 1 auto; }
.tp-trainer-editor-staff-item .staff-name { color:#172033; font-size:12px; font-weight:900; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.tp-trainer-editor-staff-item .staff-meta { margin-top:2px; color:#64748b; font-size:10px; line-height:1.45; }
.tp-trainer-editor-staff-item .staff-action { flex:0 0 auto; }
.tp-trainer-editor-staff-footer { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:9px 11px; border-top:1px solid #e8edf3; background:#fbfcfe; }
.tp-trainer-editor-staff-footer > div { display:flex; gap:4px; align-items:center; }
.tp-trainer-selected-header { margin-bottom:7px; }
.tp-trainer-selected { border-color:#bbf7d0; background:#f0fdf4; }
.tp-trainer-selected .tp-trainer-avatar { background:#dcfce7; color:#166534; }
@media(max-width:991px){ .tp-trainer-pane{height:auto;min-height:420px}.tp-trainer-stat{min-width:82px} }
@media(max-width:575px){ .tp-trainer-person{align-items:flex-start}.tp-trainer-person .btn{padding:.3rem .55rem}.tp-trainer-pagination{flex-direction:column;align-items:stretch}.tp-trainer-pagination > div:last-child{justify-content:center} }
@media(max-width:767px){ .tp-feature-row{padding:10px}.tp-session-date{width:50px;min-width:50px} }
</style>

<div class="tp-page">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div>
            <h4 class="mb-1">Manage Training</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Training
                        </a>
                    </li>
                </ol>
            </nav>
            <!-- <div class="text-muted small">
                Plan training, reserve trainers and attendees, manage custom schedules, attendance and outcomes.
            </div> -->
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <button type="button" class="btn btn-outline-primary" id="tpManageTrainerBtn">
                <i class="mdi mdi-account-tie-outline me-1"></i>Manage Trainers
            </button>
            <button type="button" class="btn btn-primary" id="tpAddBtn">
                <i class="mdi mdi-plus me-1"></i>Add Training
            </button>
        </div>
    </div>

    <div class="row g-3 mb-3" id="tpStats"></div>

    <div class="tp-toolbar mb-3">
        <div class="row g-2 align-items-end">
            <div class="col-xl-3 col-lg-4 col-md-6">
                <label class="form-label small fw-semibold">Search</label>
                <input type="text" id="tpSearch" class="form-control" placeholder="Training, ID, trainer or description">
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6">
                <label class="form-label small fw-semibold">Status</label>
                <select id="tpFilterStatus" class="form-select select3">
                    <option value="">All statuses</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="rescheduled">Rescheduled</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6">
                <label class="form-label small fw-semibold">Mode</label>
                <select id="tpFilterMode" class="form-select select3">
                    <option value="">All modes</option>
                    <option value="1">Online</option>
                    <option value="2">Offline</option>
                    <option value="3">Video</option>
                </select>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6">
                <label class="form-label small fw-semibold">From date</label>
                <input type="text" id="tpFilterFrom" class="form-control" placeholder="YYYY-MM-DD">
            </div>
            <div class="col-xl-2 col-lg-3 col-md-6">
                <label class="form-label small fw-semibold">To date</label>
                <input type="text" id="tpFilterTo" class="form-control" placeholder="YYYY-MM-DD">
            </div>
            <div class="col-xl-1 col-lg-3 col-md-6">
                <button type="button" class="btn btn-outline-secondary w-100" id="tpResetFilter" title="Reset filters">
                    <i class="mdi mdi-refresh"></i>
                </button>
            </div>
        </div>
    </div>

    <div class="tp-card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between px-5 pt-5">
                        <div>
                            <span>Show</span>
                            <select id="tpPerPage" class="select3 form-select form-select-sm w-75px" >
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                <option value="{{ $option }}" >
                                    {{ $option }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <!-- <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Job Role Name..."
                                    value="" />

                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                            <span class="mdi mdi-magnify fs-4 fw-bold text-primary"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                            <span class="mdi mdi-refresh fs-4 fw-bold text-primary"></span>
                                        </a>
                                    </div>
                                </div>
                            </div> -->
                            <ul class="nav nav-pills" id="tpViewTabs" role="tablist">
                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tpTablePane" type="button">
                                        <i class="mdi mdi-table me-1"></i>Table
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#tpCalendarPane" type="button">
                                        <i class="mdi mdi-calendar-month-outline me-1"></i>Calendar
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>     
            </div>

            <div class="tab-content">
                <div class="tab-pane fade show active" id="tpTablePane">
                    
                    <div class="tp-table-wrap">
                        <table class="table tp-table align-middle">
                            <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th>Training</th>
                                <th>Trainer</th>
                                <th>Schedule</th>
                                <!-- <th>Scope</th> -->
                                <th>Attendees</th>
                                <!-- <th>Sessions</th> -->
                                <!-- <th>Requirements</th> -->
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                            </thead>
                            <tbody id="tpTableBody">
                                <tr class="skeleton-loader" id="skeleton-loader" >
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <!-- <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td> -->
                                    <!-- <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td> -->
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-center my-3" id="pagination-container">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>

                <div class="tab-pane fade" id="tpCalendarPane">
                    <div class="tp-calendar">
                        <div class="tp-cal-head">
                            <div class="d-flex align-items-center gap-2">
                                <button class="btn btn-sm btn-outline-secondary" id="tpCalPrev">
                                    <i class="mdi mdi-chevron-left"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-secondary" id="tpCalToday">Today</button>
                                <button class="btn btn-sm btn-outline-secondary" id="tpCalNext">
                                    <i class="mdi mdi-chevron-right"></i>
                                </button>
                                <h5 class="mb-0 ms-1" id="tpCalTitle"></h5>
                            </div>
                            <!-- <div class="small text-muted">Custom sessions appear on their individual dates.</div> -->
                        </div>
                        <div class="tp-cal-grid" id="tpCalendarGrid"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Create / Edit -->
<div class="modal fade tp-modal"  id="tpPlannerModal" tabindex="-1" aria-labelledby="expenseModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1" id="tpPlannerModalTitle">Create Training</h5>
                    <div class="small text-muted" id="tpPlannerModalSub">
                        The schedule and availability are checked on the server before saving.
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="tpPlannerForm">
                    <input type="hidden" id="tpId">
                    <input type="hidden" id="tpModeEdit" value="create">

                    <div class="tp-section">
                        <div class="tp-section-title">
                            <i class="mdi mdi-domain"></i>
                            Business scope
                        </div>

                        <div class="row g-3">
                            <div class="col-lg-4">
                                <label class="form-label fw-semibold tp-required">Company</label>
                                <select id="tpCompany" class="form-select select3" multiple></select>
                                <div class="tp-help">Choose Elysium Groups or the relevant business company.</div>
                                <div class="text-danger small" id="tpErrCompany"></div>
                            </div>

                            <div class="col-lg-4" id="tpEntityWrap">
                                <label class="form-label fw-semibold tp-required">Entity</label>
                                <select id="tpEntity" class="select3 form-select" multiple></select>
                                <div class="text-danger small" id="tpErrEntity"></div>
                            </div>

                            <div class="col-lg-4" id="tpBranchWrap">
                                <label class="form-label fw-semibold tp-required">Branch</label>
                                <select id="tpBranch" class="select3 form-select" multiple></select>
                                <div class="text-danger small" id="tpErrBranch"></div>
                            </div>
                        </div>
                    </div>

                    <div class="tp-section">
                        <div class="tp-section-title">
                            <i class="mdi mdi-school-outline"></i>
                            Training details
                        </div>

                        <div class="row g-3">
                            <div class="col-lg-5">
                                <label class="form-label fw-semibold tp-required">Training planner name</label>
                                <input id="tpName" class="form-control" maxlength="255" placeholder="e.g. React Advanced Patterns">
                                <div class="text-danger small" id="tpErrName"></div>
                            </div>

                            <div class="col-lg-3">
                                <label class="form-label fw-semibold tp-required">Training mode</label>
                                <select id="tpMode" class="form-select select3">
                                    <option value="">Select mode</option>
                                    <option value="1">Online</option>
                                    <option value="2">Offline</option>
                                    <option value="3">Video</option>
                                </select>
                                <div class="text-danger small" id="tpErrMode"></div>
                            </div>
                            <input type="hidden" name="tpPlannerStatus" id="tpPlannerStatus" value="scheduled">

                            <!-- <div class="col-lg-3">
                                <label class="form-label fw-semibold">Lifecycle status</label>
                                <select id="tpPlannerStatus" class="select3 form-select">
                                    <option value="scheduled">Scheduled</option>
                                    <option value="rescheduled">Rescheduled</option>
                                </select>
                            </div> -->

                            <div class="col-lg-4">
                                <label class="form-label fw-semibold tp-required">Trainer</label>
                                <select id="tpTrainer" class="form-select select3" disabled></select>
                                <div class="text-danger small" id="tpErrTrainer"></div>
                            </div>

                            <div class="col-lg-4 d-none" id="tpExternalTrainerWrap">
                                <label class="form-label fw-semibold tp-required">External trainer name</label>
                                <input id="tpTrainerName" class="form-control" maxlength="255" placeholder="Enter trainer name">
                                <div class="text-danger small" id="tpErrTrainerName"></div>
                            </div>

                            <div class="col-lg-4">
                                <label class="form-label fw-semibold">Trainer score</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="mdi mdi-account-star-outline"></i></span>
                                    <input id="tpTrainerScore" type="number" min="0" max="100" step="0.01" class="form-control" placeholder="0 – 100">
                                    <span class="input-group-text">Pts</span>
                                </div>
                                <div class="tp-help">Optional final score/rating recorded for the trainer.</div>
                                <div class="text-danger small" id="tpErrTrainerScore"></div>
                            </div>

                            <div class="col-lg-4">
                                <label class="form-label fw-semibold">Default attendee score</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="mdi mdi-account-school-outline"></i></span>
                                    <input id="tpAttendeeScoreDefault" type="number" min="0" max="100" step="0.01" class="form-control" placeholder="0 – 100">
                                    <span class="input-group-text">Pts</span>
                                </div>
                                <div class="tp-help">Optional default. Individual attendee scores can be changed during completion.</div>
                                <div class="text-danger small" id="tpErrAttendeeScoreDefault"></div>
                            </div>
                        </div>
                    </div>

                    <div class="tp-section">
                        <div class="tp-section-title">
                            <i class="mdi mdi-calendar-clock-outline"></i>
                            Schedule
                        </div>

                        <div class="row g-3 mb-2">
                            <div class="col-lg-6">
                                <label class="tp-schedule-mode-card d-block">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tpScheduleType" id="tpScheduleCustom" value="custom" checked>
                                        <label class="form-check-label fw-semibold" for="tpScheduleCustom">
                                            Custom Dates
                                        </label>
                                    </div>
                                    <div class="tp-help ms-4">Select multiple training dates from one calendar. The same time window applies to every selected date.</div>
                                </label>
                            </div>

                            <div class="col-lg-6">
                                <label class="tp-schedule-mode-card d-block">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="tpScheduleType" id="tpScheduleRange" value="range">
                                        <label class="form-check-label fw-semibold" for="tpScheduleRange">
                                            From / To Date
                                        </label>
                                    </div>
                                    <div class="tp-help ms-4">Use one continuous date range with one common time window.</div>
                                </label>
                            </div>
                        </div>

                        <div id="tpCustomSchedule" class="mt-3">
                            <div class="row g-3">
                                <div class="col-lg-7">
                                    <label class="form-label fw-semibold tp-required">Training dates</label>
                                    <div class="tp-custom-date-picker-wrap">
                                        <input type="text" id="tpCustomDates" class="form-control" placeholder="Select one or more dates" readonly>
                                        <!-- <span class="position-absolute top-50 end-0 translate-middle-y me-3 text-muted">
                                            <i class="mdi mdi-calendar-multiple-check"></i>
                                        </span> -->
                                    </div>
                                    <div id="tpCustomDateBadges" class="tp-custom-date-badges"></div>
                                    <div class="tp-help">Click any dates you need. Click a selected date again to remove it.</div>
                                    <div class="text-danger small" id="tpErrCustomDates"></div>
                                </div>

                                <div class="col-lg-2">
                                    <label class="form-label fw-semibold tp-required">Start time</label>
                                    <input id="tpFromTime" class="form-control" placeholder="09:00 AM">
                                    <div class="text-danger small" id="tpErrFromTime"></div>
                                </div>

                                <div class="col-lg-2">
                                    <label class="form-label fw-semibold tp-required">End time</label>
                                    <input id="tpToTime" class="form-control" placeholder="05:00 PM">
                                    <div class="text-danger small" id="tpErrToTime"></div>
                                </div>

                                <div class="col-lg-1 d-flex align-items-end">
                                    <button type="button" class="btn bg-label-danger btn-outline-danger w-100" id="tpClearCustomDates" title="Clear selected dates">
                                        <i class="mdi mdi-calendar-remove-outline"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="tp-schedule-preview mt-3">
                                <div class="small fw-semibold mb-1">Selected schedule</div>
                                <div class="small text-muted" id="tpCustomSchedulePreview">Select dates and a common time window.</div>
                            </div>
                        </div>

                        <div id="tpRangeSchedule" class="row g-3 mt-1 d-none">
                            <div class="col-lg-3">
                                <label class="form-label fw-semibold tp-required">From date</label>
                                <input id="tpFromDate" class="form-control" placeholder="YYYY-MM-DD">
                                <div class="text-danger small" id="tpErrFromDate"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label fw-semibold tp-required">To date</label>
                                <input id="tpToDate" class="form-control" placeholder="YYYY-MM-DD">
                                <div class="text-danger small" id="tpErrToDate"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label fw-semibold tp-required">Start time</label>
                                <input id="tpRangeFromTime" class="form-control" placeholder="09:00 AM">
                                <div class="text-danger small" id="tpErrRangeFromTime"></div>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label fw-semibold tp-required">End time</label>
                                <input id="tpRangeToTime" class="form-control" placeholder="05:00 PM">
                                <div class="text-danger small" id="tpErrRangeToTime"></div>
                            </div>
                        </div>

                        <div class="mt-3" id="tpConflictSummary"></div>
                    </div>

                    <div class="tp-section">
                        <div class="tp-section-title">
                            <i class="mdi mdi-account-multiple-outline"></i>
                            Attendees <span class="badge bg-light text-primary ms-1">Optional</span>
                        </div>

                        <div class="tp-attendee-wrap">
                            <div class="tp-attendee-head flex-wrap">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="tpSelectAll">
                                    <label class="form-check-label fw-semibold" for="tpSelectAll">Select all available</label>
                                </div>
                                <span class="badge bg-primary ms-auto">Selected: <span id="tpSelectedCount">0</span></span>
                                <div class="input-group" style="max-width:290px">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input id="tpStaffSearch" class="form-control" placeholder="Search attendee">
                                </div>
                            </div>
                            <div class="tp-attendee-scroll" id="tpAttendeeList">
                                <div class="tp-loader">Select scope and schedule first…</div>
                            </div>
                        </div>
                        <div class="tp-help mt-2"><i class="mdi mdi-information-outline me-1"></i>Attendees are optional during creation. You can add them later from <strong>Actions → Manage attendees</strong>.</div><div class="text-danger small mt-1" id="tpErrStaff"></div>
                    </div>

                    <div class="tp-section">
                        <div class="tp-section-title">
                            <i class="mdi mdi-certificate-outline"></i>
                            Completion requirements
                        </div>

                        <div class="row g-3">
                            <div class="col-lg-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="tpCertificate">
                                    <label class="form-check-label fw-semibold" for="tpCertificate">Certificate available</label>
                                </div>
                                <div class="tp-help">Enable certificate issuance for eligible attendees.</div>
                            </div>

                            <div class="col-lg-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="tpAssessment">
                                    <label class="form-check-label fw-semibold" for="tpAssessment">Assessment required</label>
                                </div>
                                <div class="tp-help">Attendees can be marked Passed/Failed with a score.</div>
                            </div>

                            <!-- <div class="col-lg-4">
                                <label class="form-label fw-semibold">Certificate name</label>
                                <input id="tpCertificateName" class="form-control" maxlength="255" placeholder="Training Completion Certificate">
                                <div class="text-danger small" id="tpErrCertificateName"></div>
                            </div> -->

                            <!-- <div class="col-lg-4">
                                <label class="form-label fw-semibold">Assessment pass Pts</label>
                                <input id="tpAssessmentPass" type="number" class="form-control" min="0" max="100" step="0.01" placeholder="e.g. 70">
                                <div class="text-danger small" id="tpErrAssessmentPass"></div>
                            </div> -->
                        </div>
                    </div>

                    <div class="tp-section mb-0">
                        <div class="tp-section-title">
                            <i class="mdi mdi-text-box-outline"></i>
                            Description
                        </div>
                        <textarea id="tpDescription" class="form-control" rows="4" maxlength="10000" placeholder="Objectives, agenda, location/link, preparation notes and instructions…"></textarea>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="tpSaveBtn">
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    <span>Save Training</span>
                </button>
            </div>
        </div>
    </div>
</div>



<!-- View -->
<div class="modal fade tp-modal"  id="tpViewModal" tabindex="-1" aria-labelledby="expenseModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content tp-view-modal-content">
            <!-- Header -->
            <div class="modal-header tp-view-header">
                <div class="w-100">
                    <div class="d-flex flex-wrap align-items-start justify-content-between gap-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="tp-view-title-icon">
                                <i class="mdi mdi-school-outline"></i>
                            </div>
                            <div>
                                <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                                    <h4 class="modal-title mb-0"  id="tpViewTitle">
                                        Training Details
                                    </h4>
                                    <span class="tp-view-id"  id="tpViewPlannerId">
                                        --
                                    </span>
                                </div>
                                <div class="d-flex gap-2 align-items-center mb-2">
                                    <div class="small text-muted" id="tpViewSubtitle">
                                        Training planner
                                    </div>
                                    <div class="mt-2"id="tpViewStatus"></div>
                                </div>
                                
                            </div>
                        </div>

                        <div class="tp-view-header-actions d-flex align-items-center gap-2">
                            <button
                                type="button"
                                class="btn btn-outline-primary btn-sm"
                                id="tpViewEditBtn"
                            >
                                <i class="mdi mdi-square-edit-outline me-1"></i>
                                Edit
                            </button>

                            <button
                                type="button"
                                class="btn btn-success btn-sm"
                                id="tpViewCompleteBtn"
                            >
                                <i class="mdi mdi-check-circle-outline me-1"></i>
                                Complete
                            </button>

                            <button
                                type="button"
                                class="btn-close ms-1"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>

                    </div>

                </div>
            </div>
            <!-- Body -->
            <div class="modal-body tp-view-body">
                <!-- Hero schedule -->
                <div class="tp-view-hero mb-3">
                    <div class="tp-view-hero-main">
                        <div class="tp-view-hero-icon">
                            <i class="mdi mdi-calendar-clock-outline"></i>
                        </div>
                        <div>
                            <div class="tp-view-eyebrow">
                                TRAINING SCHEDULE
                            </div>
                            <div class="tp-view-hero-title" id="tpViewScheduleSummary">
                                --
                            </div>
                            <div class="tp-view-hero-subtitle" id="tpViewScheduleMeta">
                                --
                            </div>
                        </div>
                    </div>

                    <div class="tp-view-duration">
                        <div class="tp-view-eyebrow">
                            TOTAL DURATION
                        </div>

                        <div
                            class="tp-view-duration-value"
                            id="tpViewDuration"
                        >
                            --
                        </div>
                    </div>

                </div>

                <!-- KPI / basic information -->
                <div
                    class="tp-view-info-grid mb-3"
                    id="tpViewInfo"
                ></div>

                <!-- Schedule -->
                <div class="tp-view-card mb-3">

                    <div class="tp-view-card-header">
                        <div>
                            <div class="tp-view-card-title">
                                <i class="mdi mdi-calendar-multiple-outline"></i>
                                Schedule
                            </div>

                            <div class="tp-view-card-subtitle">
                                Training dates and common session timing
                            </div>
                        </div>

                        <span
                            class="tp-view-session-count"
                            id="tpViewSessionCount"
                        >
                            0 sessions
                        </span>
                    </div>

                    <div
                        class="tp-view-schedule-list"
                        id="tpViewSchedule"
                    ></div>

                </div>

                <!-- Trainer + Business scope -->
                <div class="row g-3 mb-3">

                    <!-- Trainer -->
                    <div class="col-lg-5">

                        <div class="tp-view-card h-100">

                            <div class="tp-view-card-header">
                                <div>
                                    <div class="tp-view-card-title">
                                        <i class="mdi mdi-account-tie-outline"></i>
                                        Trainer
                                    </div>

                                    <div class="tp-view-card-subtitle">
                                        Assigned training facilitator
                                    </div>
                                </div>
                            </div>

                            <div
                                id="tpViewTrainer"
                                class="tp-view-trainer"
                            ></div>

                        </div>

                    </div>

                    <!-- Scope -->
                    <div class="col-lg-7">

                        <div class="tp-view-card h-100">

                            <div class="tp-view-card-header">
                                <div>
                                    <div class="tp-view-card-title">
                                        <i class="mdi mdi-domain"></i>
                                        Business Scope
                                    </div>

                                    <div class="tp-view-card-subtitle">
                                        Companies, entities and branches covered
                                    </div>
                                </div>
                            </div>

                            <div
                                class="row g-2"
                                id="tpViewScope"
                            ></div>

                        </div>

                    </div>

                </div>

                <!-- Description -->
                <div class="tp-view-card mb-3">

                    <div class="tp-view-card-header">
                        <div>
                            <div class="tp-view-card-title">
                                <i class="mdi mdi-text-box-outline"></i>
                                Training Description
                            </div>

                            <div class="tp-view-card-subtitle">
                                Objectives, notes and instructions
                            </div>
                        </div>
                    </div>

                    <div
                        class="tp-view-description"
                        id="tpViewDescription"
                    >
                        No description provided.
                    </div>

                </div>

                <!-- Requirements -->
                <div class="tp-view-card mb-3">

                    <div class="tp-view-card-header">
                        <div>
                            <div class="tp-view-card-title">
                                <i class="mdi mdi-shield-check-outline"></i>
                                Completion Requirements
                            </div>

                            <div class="tp-view-card-subtitle">
                                Certificate and assessment configuration
                            </div>
                        </div>
                    </div>

                    <div
                        class="tp-view-requirements"
                        id="tpViewRequirements"
                    ></div>

                </div>

                <!-- Attendance -->
                <div class="tp-view-card mb-0">

                    <div class="tp-view-card-header">

                        <div>
                            <div class="tp-view-card-title">
                                <i class="mdi mdi-account-group-outline"></i>
                                Attendees & Attendance
                            </div>

                            <div class="tp-view-card-subtitle">
                                Participant list and completion status
                            </div>
                        </div>

                        <div
                            class="tp-view-attendance-summary"
                            id="tpViewAttendanceSummary"
                        >
                            --
                        </div>

                    </div>

                    <!-- Progress -->
                    <div class="tp-attendance-progress-wrap mb-3">

                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="small fw-semibold">
                                Attendance completion
                            </span>

                            <span
                                class="small fw-bold"
                                id="tpViewAttendancePercent"
                            >
                                0%
                            </span>
                        </div>

                        <div class="progress tp-attendance-progress ">
                            <div
                                class="progress-bar bg-primary"
                                id="tpViewAttendanceProgress"
                                role="progressbar"
                                style="width:0%"
                            ></div>
                        </div>

                    </div>

                    <div
                        class="tp-view-attendee-list"
                        id="tpViewAttendees"
                    ></div>

                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer tp-view-footer">
                <div class="small text-muted me-auto">
                    <i class="mdi mdi-information-outline me-1"></i>
                    Training planner details
                </div>
                <button
                    type="button"
                    class="btn btn-light"
                    data-bs-dismiss="modal"
                >
                    Close
                </button>

                

                <button
                    type="button"
                    class="btn btn-success"
                    id="tpViewCompleteBtnFooter"
                >
                    <i class="mdi mdi-check-circle-outline me-1"></i>
                    Complete Training
                </button>

            </div>

        </div>
    </div>
</div>


<!-- Status -->
<div class="modal fade tp-modal" id="tpStatusModal" tabindex="-1" aria-labelledby="tpStatusModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title" id="tpStatusModalLabel">Change Training Status</h5>
                    <div class="small text-muted" id="tpStatusTrainingName"></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="tpStatusId">

                <div class="tp-status-current mb-3">
                    <div>
                        <div class="tp-status-current-label">Current status</div>
                        <div class="tp-status-current-value" id="tpStatusCurrentValue">-</div>
                    </div>
                    <div class="text-end">
                        <div class="tp-status-current-label">Current schedule</div>
                        <div class="tp-status-current-value" id="tpStatusCurrentSchedule">-</div>
                    </div>
                </div>

                <div id="tpStatusTransitionNote" class="tp-status-note info mb-3">
                    <i class="mdi mdi-information-outline me-1"></i>Choose what should happen to this training.
                </div>

                <div class="tp-section mb-3">
                    <div class="tp-section-title"><i class="mdi mdi-swap-horizontal"></i>Choose new status</div>
                    <div class="tp-status-choice-grid">
                        <label class="tp-status-choice scheduled">
                            <input type="radio" name="tpStatusValue" value="scheduled">
                            <span class="tp-status-choice-icon"><i class="mdi mdi-calendar-check-outline"></i></span>
                            <div class="tp-status-choice-title">Scheduled</div>
                            <div class="tp-status-choice-text">Keep the training active on its current schedule.</div>
                        </label>
                        <label class="tp-status-choice rescheduled">
                            <input type="radio" name="tpStatusValue" value="rescheduled">
                            <span class="tp-status-choice-icon"><i class="mdi mdi-calendar-edit"></i></span>
                            <div class="tp-status-choice-title">Rescheduled</div>
                            <div class="tp-status-choice-text">Move the training to a new date and/or time after conflict checking.</div>
                        </label>
                        <label class="tp-status-choice cancelled">
                            <input type="radio" name="tpStatusValue" value="cancelled">
                            <span class="tp-status-choice-icon"><i class="mdi mdi-calendar-remove-outline"></i></span>
                            <div class="tp-status-choice-title">Cancelled</div>
                            <div class="tp-status-choice-text">Cancel the training and record the reason for audit/history.</div>
                        </label>
                    </div>
                </div>

                <div id="tpRescheduleFields" class="tp-section d-none">
                    <div class="tp-section-title"><i class="mdi mdi-calendar-edit"></i>New schedule</div>
                    <div class="small text-muted mb-3">The trainer and existing attendees stay unchanged. Availability and conflicts are checked before the status is saved.</div>

                    <div class="tp-status-schedule-switch mb-3">
                        <label class="tp-status-schedule-option">
                            <input type="radio" name="tpRsScheduleType" value="range">
                            <span class="fw-semibold small">Date range</span>
                            <div class="small text-muted">Same time window for each day in the range.</div>
                        </label>
                        <label class="tp-status-schedule-option">
                            <input type="radio" name="tpRsScheduleType" value="custom">
                            <span class="fw-semibold small">Custom dates</span>
                            <div class="small text-muted">Choose one or more specific training dates.</div>
                        </label>
                    </div>

                    <div id="tpRsRangeFields">
                        <div class="row g-3">
                            <div class="col-md-3"><label class="form-label tp-required">From date</label><input type="text" id="tpRsFromDate" class="form-control" autocomplete="off"></div>
                            <div class="col-md-3"><label class="form-label tp-required">To date</label><input type="text" id="tpRsToDate" class="form-control" autocomplete="off"></div>
                            <div class="col-md-3"><label class="form-label tp-required">Start time</label><input type="text" id="tpRsFromTime" class="form-control" autocomplete="off"></div>
                            <div class="col-md-3"><label class="form-label tp-required">End time</label><input type="text" id="tpRsToTime" class="form-control" autocomplete="off"></div>
                        </div>
                    </div>

                    <div id="tpRsCustomFields" class="d-none">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label tp-required">Training dates</label>
                                <input type="text" id="tpRsCustomDates" class="form-control" autocomplete="off" placeholder="Select one or more dates">
                                <div class="tp-help">Select every date that should contain this training. Up to 366 dates are supported.</div>
                                <div id="tpRsCustomDateBadges" class="d-flex flex-wrap gap-1 mt-2"></div>
                                <div class="tp-status-error" id="tpErrRsDates"></div>
                            </div>
                            <div class="col-md-6"><label class="form-label tp-required">Start time</label><input type="text" id="tpRsFromTimeCustom" class="form-control" autocomplete="off"></div>
                            <div class="col-md-6"><label class="form-label tp-required">End time</label><input type="text" id="tpRsToTimeCustom" class="form-control" autocomplete="off"></div>
                        </div>
                    </div>
                </div>

                <div id="tpStatusReasonWrap">
                    <label class="form-label fw-semibold" id="tpStatusReasonLabel">Reason</label>
                    <textarea id="tpStatusReason" class="form-control" rows="3" maxlength="1000" placeholder="Add an optional reason for this status change"></textarea>
                    <div class="tp-help" id="tpStatusReasonHelp">A short reason helps other HR users understand why the training status was changed.</div>
                    <div class="tp-status-error" id="tpErrStatusReason"></div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="tpStatusSave"><i class="mdi mdi-check-circle-outline me-1"></i><span>Update Status</span></button>
            </div>
        </div>
    </div>
</div>


<!-- Training Attendance / Completion -->
<div class="modal fade tp-modal tp-complete-modal" id="tpCompleteModal" tabindex="-1" aria-labelledby="tpAttendanceModalTitle" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
                        <h5 class="modal-title mb-0" id="tpAttendanceModalTitle">Training Attendance</h5>
                        <span class="tp-attendance-workflow-badge" id="tpAttendanceWorkflowBadge">
                            <i class="mdi mdi-clipboard-check-outline"></i>Training attendance
                        </span>
                        <span class="badge bg-success d-none" id="tpAttendanceCompletionBadge">Final completion</span>
                    </div>
                    <div class="small text-muted" id="tpCompleteSub"></div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="tpCompleteId">

                <div class="tp-attendance-workflow mb-3">
                    <div class="fw-bold" id="tpAttendanceWorkflowTitle">Mark training participation without changing outcome points.</div>
                    <div class="tp-attendance-workflow-note" id="tpAttendanceWorkflowNote">
                        This is training-specific attendance. It does not update the staff daily attendance table.
                    </div>
                    <div class="tp-completion-hint mt-3" id="tpCompleteWorkflowHint"><i class="mdi mdi-shield-check-outline me-1"></i>Complete only after every attendee has a Present or Absent status. Final points are locked until completion.</div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-xl-8">
                        <div class="tp-info-grid h-100" id="tpCompleteInfo"></div>
                    </div>
                    <div class="col-xl-4" id="tpCompleteTrainerScoreWrap">
                        <div class="tp-section h-100 mb-0">
                            <div class="tp-section-title"><i class="mdi mdi-account-star-outline"></i>Trainer outcome score</div>
                            <div class="input-group">
                                <span class="input-group-text"><i class="mdi mdi-star-outline"></i></span>
                                <input id="tpCompleteTrainerScore" type="number" min="0" max="100" step="0.01" class="form-control" placeholder="0 – 100">
                                <span class="input-group-text">Pts</span>
                            </div>
                            <div class="tp-help">Saved only when the overall training is explicitly completed.</div>
                        </div>
                    </div>
                </div>

                <div class="tp-attendance-stat-grid mb-3" id="tpCompleteAttendanceStats"></div>

                <div class="tp-section mb-3">
                    <div class="d-flex justify-content-between align-items-center gap-2 mb-2">
                        <div class="small fw-bold">Attendance completion</div>
                        <strong class="small" id="tpCompleteAttendancePercent">0%</strong>
                    </div>
                    <div class="progress" style="height:8px; border-radius:999px; background:#eef2f7;">
                        <div class="progress-bar bg-primary" id="tpCompleteAttendanceProgress" style="width:0%; border-radius:999px;" role="progressbar"></div>
                    </div>
                    <div class="small text-muted mt-2" id="tpCompleteAttendeeSub">0 present · 0 absent · 0 pending</div>
                </div>

                <div class="tp-attendee-wrap">
                    <div class="tp-attendee-head">
                        <strong id="tpCompleteAttendeeHeaderTitle">Training Attendance</strong>
                        <span class="small text-muted ms-auto" id="tpCompleteAttendeeHeaderNote">Present / Absent · score locked</span>
                    </div>
                    <div class="tp-attendance-grid-head">
                        <div>Attendee</div>
                        <div>Attendance</div>
                        <div>Points</div>
                        <div>Final outcomes</div>
                    </div>
                    <div class="tp-attendee-scroll" id="tpCompleteAttendees"></div>
                </div>
            </div>

            <div class="modal-footer">
                <div class="small text-muted me-auto" id="tpCompleteFooterNote">
                    Attendance is separate from daily HR attendance.
                </div>
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="tpCompleteSave">
                    <i class="mdi mdi-content-save-outline me-1"></i><span id="tpCompleteSaveText">Save Attendance</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Attendee Management -->
<div class="modal fade tp-modal" id="tpAttendeeModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl "><div class="modal-content">
        <div class="modal-header">
            <div><h5 class="modal-title mb-1">Manage Attendees</h5><div class="small text-muted" id="tpAttendeeTrainingName"></div></div>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="tp-section h-100 mb-0">
                        <div class="tp-section-title"><i class="mdi mdi-account-check-outline"></i>Assigned attendees <span class="badge bg-primary ms-auto" id="tpAssignedCount">0</span></div>
                        <div class="input-group mb-2"><span class="input-group-text"><i class="mdi mdi-magnify"></i></span><input id="tpAssignedSearch" class="form-control" placeholder="Search assigned attendee"></div>
                        <div class="tp-attendee-scroll" id="tpAssignedList"><div class="tp-loader">Loading attendees…</div></div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="tp-section mb-0">
                        <div class="tp-section-title"><i class="mdi mdi-account-multiple-plus-outline"></i>Add attendees <span class="badge bg-info ms-auto">Selected: <span id="tpNewAttendeeCount">0</span></span></div>
                        <div class="alert alert-light border small mb-2"><i class="mdi mdi-shield-check-outline me-1"></i>Only staff without a schedule conflict can be selected. The server checks conflicts again when saving.</div>
                        <div class="input-group mb-2"><span class="input-group-text"><i class="mdi mdi-magnify"></i></span><input id="tpAvailableSearch" class="form-control" placeholder="Search available staff"></div>
                        <div class="tp-attendee-scroll" id="tpAvailableList"><div class="tp-loader">Checking availability…</div></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button><button type="button" class="btn btn-primary" id="tpAddAttendeeSave"><i class="mdi mdi-account-plus-outline me-1"></i>Add selected attendees</button></div>
    </div></div>
</div>

<!-- Session Management -->
<div class="modal fade tp-modal" id="tpSessionsModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl "><div class="modal-content">
        <div class="modal-header"><div><h5 class="modal-title mb-1">Training Sessions & Syllabus</h5><div class="small text-muted" id="tpSessionsTrainingName"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body"><div class="d-flex flex-wrap gap-2 align-items-center mb-3"><span class="badge bg-primary" id="tpSessionsCount">0 sessions</span><span class="small text-muted" id="tpSessionsProgress"></span></div><div id="tpSessionList"><div class="tp-loader">Loading sessions…</div></div></div>
        <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button></div>
    </div></div>
</div>

<!-- Session Edit / Syllabus -->
<div class="modal fade tp-modal" id="tpSessionEditModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg "><div class="modal-content">
        <div class="modal-header"><div><h5 class="modal-title mb-1">Update Session & Syllabus</h5><div class="small text-muted" id="tpSessionEditSub"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <input type="hidden" id="tpSessionEditTrainingId"><input type="hidden" id="tpSessionEditId">
            <div class="tp-info-grid mb-3" id="tpSessionEditInfo"></div>
            <div class="tp-section"><div class="tp-section-title"><i class="mdi mdi-book-open-page-variant-outline"></i>Session syllabus</div><div class="row g-3"><div class="col-12"><label class="form-label fw-semibold">Session title</label><input id="tpSessionTitle" class="form-control" maxlength="255"></div><div class="col-12"><label class="form-label fw-semibold">Syllabus / topics covered</label><textarea id="tpSessionSyllabus" class="form-control" rows="6" maxlength="10000" placeholder="Topics, objectives, modules, exercises and completion notes…"></textarea></div><div class="col-12"><label class="form-label fw-semibold">Trainer notes</label><textarea id="tpSessionTrainerNotes" class="form-control" rows="4" maxlength="10000" placeholder="Trainer remarks, observations or follow-up notes…"></textarea></div><div class="col-md-6"><label class="form-label fw-semibold">Session status</label><select id="tpSessionStatus" class="select3 form-select"><option value="scheduled">Scheduled</option><option value="in_progress">In progress</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div><div class="col-md-6 d-flex align-items-end"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="tpSessionSyllabusCompleted"><label class="form-check-label fw-semibold" for="tpSessionSyllabusCompleted">Syllabus completed</label></div></div></div></div>
            <div id="tpSessionEditError" class="alert alert-danger d-none mb-0"></div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="button" class="btn btn-primary" id="tpSessionEditSave"><i class="mdi mdi-content-save-outline me-1"></i>Save session</button></div>
    </div></div>
</div>

<!-- Session-wise Attendance -->
<div class="modal fade tp-modal" id="tpSessionAttendanceModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header">
            <div>
                <h5 class="modal-title mb-1"><i class="mdi mdi-calendar-check-outline me-1"></i>Mark Session Attendance</h5>
                <div class="small text-muted" id="tpSessionAttendanceSub"></div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="tpSessionAttendanceTrainingId"><input type="hidden" id="tpSessionAttendanceSessionId">
            <div class="tp-info-grid mb-3" id="tpSessionAttendanceInfo"></div>
            <div class="tp-session-attendance-toolbar mb-3">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <div><div class="fw-bold">Attendance controls</div><div class="small text-muted mt-1">Click Present, Absent, or Pending for each attendee.</div></div>
                    <div class="input-group tp-session-attendance-search"><span class="input-group-text"><i class="mdi mdi-magnify"></i></span><input type="text" class="form-control" id="tpSessionAttendanceSearch" placeholder="Search attendee…" autocomplete="off"></div>
                </div>
                <div class="d-flex flex-wrap gap-2 align-items-center">
                    <button type="button" class="btn btn-sm btn-outline-success" id="tpSessionMarkAllPresent"><i class="mdi mdi-check-all me-1"></i>Mark all Present</button>
                    <button type="button" class="btn btn-sm btn-outline-danger" id="tpSessionMarkAllAbsent"><i class="mdi mdi-close-circle-outline me-1"></i>Mark all Absent</button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="tpSessionMarkAllPending"><i class="mdi mdi-clock-outline me-1"></i>Reset Pending</button>
                </div>
                <div class="tp-session-attendance-kpis mt-3" id="tpSessionAttendanceKpis"></div>
            </div>
            <div class="tp-attendee-wrap">
                <div class="tp-attendee-head"><strong>Session attendees</strong><span class="small text-muted ms-auto" id="tpSessionAttendanceCount"></span></div>
                <div class="tp-session-attendance-list" id="tpSessionAttendanceList"><div class="tp-loader">Loading attendance…</div></div>
            </div>
        </div>
        <div class="modal-footer">
            <div class="small text-muted me-auto">Session attendance is training-specific and does not update daily HR attendance.</div>
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-primary" id="tpSessionAttendanceSave"><i class="mdi mdi-content-save-outline me-1"></i>Save Attendance</button>
        </div>
    </div></div>
</div>

<!-- Remove Attendee Confirmation -->
<div class="modal fade tp-modal" id="tpRemoveAttendeeModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-sm"><div class="modal-content">
        <div class="modal-body p-4 text-center">
            <div class="mx-auto mb-3" style="width:54px;height:54px;border-radius:50%;background:#fff7ed;color:#c2410c;display:flex;align-items:center;justify-content:center;font-size:26px"><i class="mdi mdi-account-minus-outline"></i></div>
            <h5>Remove attendee?</h5>
            <p class="text-muted mb-3" id="tpRemoveAttendeeMessage">This attendee will be removed from all unmarked sessions.</p>
            <input type="hidden" id="tpRemoveAttendeeId">
            <div class="d-flex justify-content-center gap-2">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="tpRemoveAttendeeConfirm">Remove</button>
            </div>
        </div>
    </div></div>
</div>

<!-- Delete -->

<div class="modal fade tp-modal" id="tpDeleteModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body p-4 text-center">
                <div class="mx-auto mb-3" style="width:54px;height:54px;border-radius:50%;background:#fee2e2;color:#b91c1c;display:flex;align-items:center;justify-content:center;font-size:26px">
                    <i class="mdi mdi-delete-outline"></i>
                </div>
                <h5>Delete training planner?</h5>
                <p class="text-muted mb-4" id="tpDeleteMessage"></p>
                <input type="hidden" id="tpDeleteId">
                <div class="d-flex justify-content-center gap-2">
                    <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" id="tpDeleteConfirm">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Staff Training History -->
<div class="modal fade tp-modal" id="tpStaffTrainingHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1"><i class="mdi mdi-history me-1"></i>Staff Training History</h5>
                    <div class="small text-muted" id="tpStaffHistorySub">Training history</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Training</th>
                                <th>Trainer</th>
                                <th>Attendance</th>
                                <th class="text-end">Attendee Score</th>
                                <th class="text-end">Trainer Score</th>
                                <th>Assessment</th>
                                <th>Certificate</th>
                            </tr>
                        </thead>
                        <tbody id="tpStaffHistoryBody">
                            <tr><td colspan="8"><div class="tp-loader"><span class="spinner-border spinner-border-sm me-1"></span>Loading…</div></td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3 small text-muted">
                    <span id="tpStaffHistoryCount"></span>
                    <div id="tpStaffHistoryPagination" class="d-flex gap-1"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Trainer Management -->
<div class="modal fade tp-modal tp-trainer-modal" id="tpTrainerManageModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl ">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <h5 class="modal-title mb-1" id="tpTrainerManageTitle">Trainer Management</h5>
                    <div class="small text-muted" id="tpTrainerManageSub">
                        Assign existing staff as trainers for the Training Planner.
                    </div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <button type="button" class="btn btn-sm btn-outline-secondary d-none" id="tpTrainerBackBtn">
                        <i class="mdi mdi-arrow-left me-1"></i>Back
                    </button>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>

            <div class="modal-body p-3 p-lg-4">
                <!-- Manager view -->
                <div id="tpTrainerManagerView">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                        <div class="d-flex flex-wrap gap-2" id="tpTrainerStats">
                            <div class="tp-trainer-stat"><strong id="tpTrainerStatTotal">0</strong><span>Total trainers</span></div>
                            <div class="tp-trainer-stat"><strong id="tpTrainerStatActive">0</strong><span>Active</span></div>
                            <div class="tp-trainer-stat"><strong id="tpTrainerStatInactive">0</strong><span>Inactive</span></div>
                        </div>
                        <!-- <div class="small text-muted d-flex align-items-center gap-1">
                            <i class="mdi mdi-hand-pointer-outline"></i>
                            Click <strong>+ Add</strong> on Available Staff to add a trainer.
                        </div> -->
                    </div>

                    <div class="tp-trainer-toolbar mb-3">
                        <div class="row g-2 align-items-end">
                            <div class="col-xl-4 col-lg-4 col-md-6">
                                <label class="form-label small fw-semibold">Search staff / trainer</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                    <input type="text" class="form-control" id="tpTrainerSearch" placeholder="Name, staff ID, email, role…" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-6">
                                <label class="form-label small fw-semibold">Entity</label>
                                <select class="select3 form-select" id="tpTrainerEntityFilter">
                                    <option value="">All entities</option>
                                </select>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-6">
                                <label class="form-label small fw-semibold">Department</label>
                                <select class="select3 form-select" id="tpTrainerDepartmentFilter">
                                    <option value="">All departments</option>
                                </select>
                            </div>
                            <div class="col-xl-2 col-lg-2 col-md-6">
                                <div class="d-flex gap-2">
                                    <div class="flex-grow-1">
                                        <label class="form-label small fw-semibold">Trainer status</label>
                                        <select class="select3 form-select" id="tpTrainerStatusFilter">
                                            <option value="all">All</option>
                                            <option value="active">Active</option>
                                            <option value="inactive">Inactive</option>
                                        </select>
                                    </div>
                                    <button type="button" class="btn btn-outline-secondary" id="tpTrainerRefreshBtn" title="Refresh">
                                        <i class="mdi mdi-refresh"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="tp-trainer-helper mt-2">
                            Staff already configured as trainers are hidden from the available staff pane. Deactivating a trainer is blocked while upcoming training still uses that staff member.
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-lg-6">
                            <div class="tp-trainer-pane">
                                <div class="tp-trainer-pane-header d-flex justify-content-between align-items-center gap-2">
                                    <div>
                                        <div class="fw-bold small">Available staff</div>
                                        <div class="small text-muted">Select an Entity first, then choose a Department</div>
                                    </div>
                                    <span class="badge bg-label-primary" id="tpTrainerStaffCount">0</span>
                                </div>
                                <div class="tp-trainer-list" id="tpAvailableTrainerStaff">
                                    <div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading staff…</div>
                                </div>
                                <div class="tp-trainer-pagination">
                                    <span class="small text-muted" id="tpTrainerStaffMeta"></span>
                                    <div class="d-flex gap-1" id="tpTrainerStaffPagination"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="tp-trainer-pane">
                                <div class="tp-trainer-pane-header d-flex justify-content-between align-items-center gap-2">
                                    <div>
                                        <div class="fw-bold small">Trainer staff</div>
                                        <div class="small text-muted">Configured trainers available in Add Training</div>
                                    </div>
                                    <span class="badge bg-label-success" id="tpTrainerConfiguredCount">0</span>
                                </div>
                                <div class="tp-trainer-list" id="tpConfiguredTrainerList">
                                    <div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading trainers…</div>
                                </div>
                                <div class="tp-trainer-pagination">
                                    <span class="small text-muted" id="tpTrainerListMeta"></span>
                                    <div class="d-flex gap-1" id="tpTrainerPagination"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Editor view -->
                <div id="tpTrainerEditorView" class="d-none">
                    <form id="tpTrainerForm" novalidate>
                        <input type="hidden" id="tpTrainerRecordId">
                        <input type="hidden" id="tpTrainerSelectedStaffId" value="">

                        <div class="tp-trainer-editor">
                            <div class="tp-trainer-editor-top">
                                <div class="fw-bold" id="tpTrainerEditorTitle">Change Trainer Staff</div>
                                <div class="small text-muted" id="tpTrainerEditorSub">Select a different active staff member. Trainer status remains active.</div>
                            </div>

                            <div class="p-3 p-lg-4">
                                <div class="tp-trainer-step-card mb-3">
                                    <div class="d-flex align-items-start justify-content-between gap-3 flex-wrap">
                                        <div>
                                            <div class="tp-trainer-step-kicker">Step 1</div>
                                            <div class="tp-trainer-step-title">Change trainer staff</div>
                                            <div class="tp-trainer-step-text">Filter by Entity and Department, then click a staff member to change this trainer assignment.</div>
                                        </div>
                                        <div class="tp-trainer-selection-state" id="tpTrainerSelectionState">
                                            <i class="mdi mdi-account-outline"></i>
                                            No staff selected
                                        </div>
                                    </div>

                                    <div class="tp-trainer-editor-filter mt-3">
                                        <div class="row g-2 align-items-end">
                                            <div class="col-xl-4 col-lg-4 col-md-6">
                                                <label class="form-label small fw-semibold mb-1" for="tpTrainerEditorEntityFilter">Entity</label>
                                                <select class="select3 form-select" id="tpTrainerEditorEntityFilter">
                                                    <option value="">All entities</option>
                                                </select>
                                            </div>
                                            <div class="col-xl-4 col-lg-4 col-md-6">
                                                <label class="form-label small fw-semibold mb-1" for="tpTrainerEditorDepartmentFilter">Department</label>
                                                <select class="select3 form-select" id="tpTrainerEditorDepartmentFilter">
                                                    <option value="">All departments</option>
                                                </select>
                                            </div>
                                            <div class="col-xl-4 col-lg-4 col-md-12">
                                                <label class="form-label small fw-semibold mb-1" for="tpTrainerEditorStaffSearch">Search staff</label>
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                                    <input type="text" class="form-control" id="tpTrainerEditorStaffSearch" maxlength="100" placeholder="Name, staff ID, email or role…" autocomplete="off">
                                                    <button type="button" class="btn btn-outline-secondary" id="tpTrainerEditorFilterReset" title="Reset filters">
                                                        <i class="mdi mdi-filter-remove-outline"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between gap-2 mt-2 flex-wrap">
                                            <div class="tp-trainer-filter-hint"><i class="mdi mdi-information-outline me-1"></i>Only active staff who are not already configured as trainers are listed.</div>
                                            <span class="badge bg-label-primary" id="tpTrainerEditorStaffCount">0 available</span>
                                        </div>
                                    </div>

                                    <div class="tp-trainer-editor-staff-panel mt-3">
                                        <div id="tpTrainerEditorStaffList">
                                            <div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading staff…</div>
                                        </div>
                                        <div class="tp-trainer-editor-staff-footer">
                                            <span class="small text-muted" id="tpTrainerEditorStaffMeta"></span>
                                            <div class="d-flex gap-1" id="tpTrainerEditorStaffPagination"></div>
                                        </div>
                                    </div>

                                    <div class="small text-danger mt-2" id="tpTrainerErrStaff"></div>
                                </div>

                                <div id="tpTrainerSelectedStaffWrap" class="mb-3 d-none">
                                    <div class="tp-trainer-selected-header d-flex align-items-center justify-content-between gap-2">
                                        <div>
                                            <div class="fw-bold small">Selected trainer staff</div>
                                            <div class="small text-muted">This existing staff record will be marked as a trainer.</div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" id="tpTrainerChangeStaffBtn">Change</button>
                                    </div>
                                    <div class="tp-trainer-selected" id="tpTrainerSelectedStaff"></div>
                                </div>

                                <div class="tp-trainer-ready-card mt-3" id="tpTrainerReadyCard">
                                    <div class="tp-trainer-ready-icon">
                                        <i class="mdi mdi-account-star-outline"></i>
                                    </div>
                                    <div class="min-w-0">
                                        <div class="fw-bold text-dark">Change trainer assignment</div>
                                        <div class="small text-muted mt-1">Trainer status is active by default. Select another active staff member and save. Trainer status remains active.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="modal-footer" id="tpTrainerManagerFooter">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
            </div>

            <div class="modal-footer d-none" id="tpTrainerEditorFooter">
                <button type="button" class="btn btn-light" id="tpTrainerEditorCancel">Cancel</button>
                <button type="button" class="btn btn-primary" id="tpTrainerSaveBtn">
                    <i class="mdi mdi-account-sync-outline me-1"></i>Update Trainer
                </button>
            </div>
        </div>
    </div>
</div>

<div class="tp-toast" id="tpToast"></div>

<script>
(() => {
    const baseUrl = @json(url('/training-planner'));

    const urls = {
        data: `${baseUrl}/data`,
        lookups: `${baseUrl}/lookups`,
        entities: `${baseUrl}/entities`,
        branches: `${baseUrl}/branches`,
        staff: `${baseUrl}/staff`,
        trainerLookups: `${baseUrl}/trainer-lookups`,
        trainerStaff: `${baseUrl}/trainer-staff`,
        trainers: `${baseUrl}/trainers`,
        trainer: id => `${baseUrl}/trainers/${id}`,
        trainerStatus: id => `${baseUrl}/trainers/${id}/status`,
        conflicts: `${baseUrl}/conflicts`,
        store: baseUrl,
        show: id => `${baseUrl}/${id}`,
        update: id => `${baseUrl}/${id}`,
        status: id => `${baseUrl}/${id}/status`,
        attendance: id => `${baseUrl}/${id}/attendance`,
        complete: id => `${baseUrl}/${id}/complete`,
        remove: id => `${baseUrl}/${id}`,
        attendees: id => `${baseUrl}/${id}/attendees`,
        staffTrainingLogs: staffId => `${baseUrl}/staff/${staffId}/training-logs`,
        sessions: id => `${baseUrl}/${id}/sessions`,
        session: (id, sessionId) => `${baseUrl}/${id}/sessions/${sessionId}`,
        sessionAttendance: (id, sessionId) => `${baseUrl}/${id}/sessions/${sessionId}/attendance`,
    };

    const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    const state = {
        page: 1,
        perPage: 25,
        month: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        currentTraining: null,
        staff: [],
        attendanceMode: 'complete',
        scopeEntityRows: [],
        scopeBranchRows: [],
    };

    let plannerModal;
    let viewModal;
    let statusModal;
    let completeModal;
    let deleteModal;
    let staffTrainingHistoryModal;
    let trainerManageModal;
    const datePickers = {};
    let statusTraining = null;

    const trainerUi = {
        view: 'manager',
        staffPage: 1,
        trainerPage: 1,
        staffPerPage: 10,
        trainerPerPage: 10,
        search: '',
        entityId: '',
        departmentId: '',
        status: 'all',
        editingId: null,
        selectedStaff: null,
        staffRows: [],
        entities: [],
        departments: [],
        lookupLoaded: false,
        editorEntityId: '',
        editorDepartmentId: '',
        editorSearch: '',
        editorStaffPage: 1,
        editorStaffPerPage: 12,
        editorStaffRows: [],
        editorRequestSeq: 0,
    };

    const $ = selector => document.querySelector(selector);
    const $$ = selector => Array.from(document.querySelectorAll(selector));

    function esc(value) {
        return String(value ?? '').replace(/[&<>\'"]/g, character => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            "'": '&#039;',
            '"': '&quot;',
        }[character]));
    }

    function initials(value) {
        return String(value || '-')
            .split(' ')
            .filter(Boolean)
            .slice(0, 2)
            .map(part => part[0])
            .join('')
            .toUpperCase();
    }

    function fmtDate(value) {
        if (!value) return '-';
        const date = new Date(`${value}T00:00:00`);
        return date.toLocaleDateString(undefined, {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
        });
    }

    function fmtTime(value) {
        if (!value) return '-';
        return value.substring(0, 5);
    }

    function statusBadge(status) {
        const value = status || 'scheduled';
        const label = value.charAt(0).toUpperCase() + value.slice(1);
        return `<span class="tp-status tp-status-${esc(value)}">${esc(label)}</span>`;
    }

    // function customtoast(message, type = 'success') {
    //     const element = $('#tpToast');
    //     element.textContent = message;
    //     element.className = `tp-toast ${type}`;
    //     element.style.display = 'block';
    //     clearTimeout(toast.timer);
    //     toast.timer = setTimeout(() => {
    //         element.style.display = 'none';
    //     }, 3500);
    // }
    function toast(message, type = 'success') {

        if(type == 'success'){
            toastr.success(message);
        }else{
            toastr.error(message);
        }
    }

    function getJson(url, params = {}) {
        const search = new URLSearchParams();

        Object.entries(params).forEach(([key, value]) => {
            if (value === null || value === undefined || value === '') return;
            if (Array.isArray(value)) {
                value.forEach(item => search.append(`${key}[]`, item));
            } else {
                search.append(key, value);
            }
        });

        const query = search.toString();

        return fetch(`${url}${query ? `?${query}` : ''}`, {
            headers: {
                Accept: 'application/json',
            },
        }).then(async response => {
            const data = await response.json().catch(() => ({ message: 'Invalid server response.' }));
            if (!response.ok) throw data;
            return data;
        });
    }

    function postJson(url, method, body) {
        return fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
                'X-CSRF-TOKEN': csrf,
            },
            body: JSON.stringify(body),
        }).then(async response => {
            const data = await response.json().catch(() => ({ message: 'Invalid server response.' }));
            if (!response.ok) throw data;
            return data;
        });
    }

    function initSelect(selector, options = {}) {
        const element = $(selector);
        if (!element || !window.jQuery?.fn?.select2) return;
        if (element.dataset.select2Init === '1') return;

        const modal = element.closest('.modal');
        const dropdownParent = modal
            ? window.jQuery(modal)
            : window.jQuery('body');

        element.dataset.select2Init = '1';
        window.jQuery(element).select2({
            width: '100%',
            dropdownParent,
            ...options,
        });
    }

    function destroySelect(selector) {
        try {
            if (window.jQuery?.fn?.select2) {
                window.jQuery(selector).select2('destroy');
            }
        } catch (error) {
            // Select2 may already be destroyed.
        }
        $(selector).dataset.select2Init = '';
    }

    function multiValues(selector) {
        const element = $(selector);
        if (!element) return [];

        let rawValues;
        if (window.jQuery?.fn?.select2 && window.jQuery(element).hasClass('select2-hidden-accessible')) {
            rawValues = window.jQuery(element).val();
        } else {
            rawValues = Array.from(element.selectedOptions || []).map(option => option.value);
        }

        const values = Array.isArray(rawValues)
            ? rawValues
            : (rawValues === null || rawValues === undefined || rawValues === '' ? [] : [rawValues]);

        return values
            .map(value => Number(value))
            .filter(Number.isFinite);
    }

    function setMulti(selector, values = [], trigger = true) {
        const normalized = values.map(String);

        if (window.jQuery?.fn?.select2) {
            window.jQuery(selector).val(normalized);
            if (trigger) window.jQuery(selector).trigger('change');
            return;
        }

        Array.from($(selector).options).forEach(option => {
            option.selected = normalized.includes(String(option.value));
        });
    }

    // function renderOptions(selector, options, placeholder = 'Select') {
    //     const element = $(selector);
    //     const isMultiple = element.multiple;

    //     element.innerHTML = '';

    //     if (!isMultiple) {
    //         const placeholderOption = document.createElement('option');
    //         placeholderOption.value = '';
    //         placeholderOption.textContent = placeholder;
    //         element.appendChild(placeholderOption);
    //     }

    //     options.forEach(option => {
    //         const item = document.createElement('option');
    //         item.value = option.id;
    //         item.textContent = option.text;
    //         item.disabled = Boolean(option.disabled);
    //         element.appendChild(item);
    //     });
    // }
    function renderOptions(selector, options, placeholder = 'Select', triggerChange = true) {
        const element = $(selector);

        if (!element) {
            return;
        }

        const isMultiple = element.multiple;

        // Destroy Select2 before rebuilding options
        if (window.jQuery?.fn?.select2 && window.jQuery(element).hasClass('select2-hidden-accessible')) {
            window.jQuery(element).select2('destroy');
            element.dataset.select2Init = '';
        }

        element.innerHTML = '';

        if (!isMultiple) {
            const placeholderOption = document.createElement('option');

            placeholderOption.value = '';
            placeholderOption.textContent = placeholder;

            element.appendChild(placeholderOption);
        }

        options.forEach(option => {
            const item = document.createElement('option');

            item.value = option.id;
            item.textContent = option.text;
            item.disabled = Boolean(option.disabled);

            element.appendChild(item);
        });

        // Re-initialize Select2
        initSelect(selector, {
            placeholder: placeholder,
        });

        // Notify Select2 / dependent listeners
        if (triggerChange && window.jQuery) {
            window.jQuery(element).trigger('change');
        }
    }

    function scheduleType() {
        return document.querySelector('input[name="tpScheduleType"]:checked')?.value || 'custom';
    }

    function normalizeTimeTo24(value) {
        if (!value) return '';
        const text = String(value).trim().toUpperCase();
        const match = text.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
        if (match) {
            let hour = Number(match[1]);
            const minute = Number(match[2]);
            const meridiem = match[3];
            if (hour < 1 || hour > 12 || minute > 59) return '';
            if (meridiem === 'AM') hour = hour === 12 ? 0 : hour;
            if (meridiem === 'PM') hour = hour === 12 ? 12 : hour + 12;
            return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        }
        const legacy = text.match(/^(\d{1,2}):(\d{2})$/);
        if (legacy) return `${String(Number(legacy[1])).padStart(2, '0')}:${legacy[2]}`;
        return '';
    }

    function formatTime12(value) {
        const normalized = normalizeTimeTo24(value);
        if (!normalized) return '';
        const [h, m] = normalized.split(':').map(Number);
        const meridiem = h >= 12 ? 'PM' : 'AM';
        const hour = h % 12 || 12;
        return `${String(hour).padStart(2, '0')}:${String(m).padStart(2, '0')} ${meridiem}`;
    }

    function getCustomDates() {
        const picker = datePickers.customDates;
        if (!picker || !picker.selectedDates) return [];

        return picker.selectedDates
            .map(date => picker.formatDate(date, 'Y-m-d'))
            .sort();
    }

    function renderCustomDateBadges() {
        const dates = getCustomDates();
        $('#tpCustomDateBadges').innerHTML = dates.length
            ? dates.map(date => `
                <span class="tp-custom-date-badge badge bg-info text-black ms-auto fs-8 my-1">
                    <i class="mdi mdi-calendar-check-outline"></i>
                    ${esc(fmtDate(date))}
                    <span type="button" class="tp-date-remove cursor-pointer badge bg-label-info rounded" data-date="${esc(date)}" title="Remove date">
                        <i class="mdi mdi-close"></i>
                    </span>
                </span>
            `).join('')
            : '<span class="small text-muted">No dates selected.</span>';

        updateCustomSchedulePreview();
    }

    function updateCustomSchedulePreview() {
        const dates = getCustomDates();
        const from = normalizeTimeTo24($('#tpFromTime').value);
        const to = normalizeTimeTo24($('#tpToTime').value);

        if (!dates.length) {
            $('#tpCustomSchedulePreview').textContent = 'Select one or more dates and a common time window.';
            return;
        }

        if (!from || !to) {
            $('#tpCustomSchedulePreview').textContent = `${dates.length} date(s) selected. Choose the common start and end time.`;
            return;
        }

        const range = `${formatTime12(from)} – ${formatTime12(to)}`;
        $('#tpCustomSchedulePreview').textContent = `${dates.length} date(s) · ${range} on every selected date.`;
    }

    function removeCustomDate(dateValue) {
        const picker = datePickers.customDates;
        if (!picker) return;

        const remaining = picker.selectedDates.filter(
            date => picker.formatDate(date, 'Y-m-d') !== dateValue
        );

        picker.setDate(remaining, false);
        renderCustomDateBadges();
        refreshStaff();
    }

    /**
     * Toggle the schedule input UI between:
     * - custom: one multi-date picker + common AM/PM time range
     * - range:  from/to date + common AM/PM time range
     */
    function toggleScheduleUi() {
        const type = scheduleType();
        const customMode = type === 'custom';
        const rangeMode = type === 'range';

        $('#tpCustomSchedule').classList.toggle('d-none', !customMode);
        $('#tpRangeSchedule').classList.toggle('d-none', !rangeMode);

        // Keep labels/visual state synchronized with the selected radio.
        $$('.tp-schedule-mode-card').forEach(card => {
            const radio = card.querySelector('input[name="tpScheduleType"]');
            card.classList.toggle('is-active', Boolean(radio?.checked));
        });

        // Custom dates use the common custom time inputs.
        // Range mode uses the range-specific time inputs.
        updateCustomSchedulePreview();

        if (customMode) {
            // The common custom-date time pickers are only meaningful in custom mode.
            if (datePickers.customDates) {
                renderCustomDateBadges();
            }
        }

        // Clear schedule-specific validation messages from the inactive mode.
        if (customMode) {
            $('#tpErrFromDate').textContent = '';
            $('#tpErrToDate').textContent = '';
            $('#tpErrRangeFromTime').textContent = '';
            $('#tpErrRangeToTime').textContent = '';
        } else {
            $('#tpErrCustomDates').textContent = '';
            $('#tpErrFromTime').textContent = '';
            $('#tpErrToTime').textContent = '';
        }
    }

    function schedulePayload() {
        const type = scheduleType();

        if (type === 'custom') {
            const dates = getCustomDates();
            const fromTime = normalizeTimeTo24($('#tpFromTime').value);
            const toTime = normalizeTimeTo24($('#tpToTime').value);

            return {
                schedule_type: 'custom',
                custom_dates: dates,
                from_date: dates[0] || '',
                to_date: dates[dates.length - 1] || '',
                from_time: fromTime,
                to_time: toTime,
            };
        }

        const fromTime = normalizeTimeTo24($('#tpRangeFromTime').value);
        const toTime = normalizeTimeTo24($('#tpRangeToTime').value);

        return {
            schedule_type: 'range',
            custom_dates: [],
            custom_sessions: [],
            from_date: $('#tpFromDate').value,
            to_date: $('#tpToDate').value,
            from_time: fromTime,
            to_time: toTime,
        };
    }

    function scopePayload() {
        const companyIds = multiValues('#tpCompany');
        const isElysiumOnly = companyIds.length === 1 && companyIds.includes(0);

        return {
            company_ids: companyIds,
            // Elysium-only has no entity/branch dependency. Mixed Elysium + business companies
            // still use the entity/branch selections for the business companies, while staff
            // from company_id = 0 is included by the backend.
            entity_ids: isElysiumOnly ? [] : multiValues('#tpEntity'),
            branch_ids: isElysiumOnly ? [0] : multiValues('#tpBranch'),
        };
    }

    function selectedStaff() {
        return $$('#tpAttendeeList .tp-attendee-check:checked')
            .map(input => Number(input.value))
            .filter(Number.isFinite);
    }

    function clearErrors() {
        $$('.text-danger.small').forEach(element => {
            element.textContent = '';
        });
        $('#tpConflictSummary').innerHTML = '';
    }

    async function loadLookups() {
        const response = await getJson(urls.lookups);
        const data = response.data || {};

        renderOptions('#tpCompany', [
            { id: Number(data.main_company?.id ?? 0), text: data.main_company?.title || 'Main Company' },
            ...(data.companies || []).map(item => ({ id: item.sno, text: item.company_name })),
        ], 'Select company', false);
    }

    let scopeRequestToken = 0;
    let scopeCascadeTimer = null;

    function scheduleScopeReload(callback) {
        clearTimeout(scopeCascadeTimer);
        scopeCascadeTimer = setTimeout(callback, 40);
    }

    function syncScopeSelect2(selector) {
        if (!window.jQuery?.fn?.select2) return;
        const $element = window.jQuery(selector);
        if ($element.hasClass('select2-hidden-accessible')) {
            $element.trigger('change.select2');
        }
    }

    function bindScopeSelectEvents() {
        if (!window.jQuery) return;

        // Select2 emits the normal jQuery change event itself. Binding only to change
        // avoids duplicate AJAX requests from select2:select + change firing together.
        window.jQuery('#tpCompany').off('.trainingScope').on('change.trainingScope', () => {
            scheduleScopeReload(() => loadEntities());
        });
        window.jQuery('#tpEntity').off('.trainingScope').on('change.trainingScope', () => {
            scheduleScopeReload(() => loadBranches());
        });
        window.jQuery('#tpBranch').off('.trainingScope').on('change.trainingScope', () => {
            scheduleScopeReload(() => refreshStaff());
        });
        window.jQuery('#tpTrainer').off('.trainingScope').on('change.trainingScope', () => {
            toggleExternalTrainer();
            renderStaff(state.staff);
            updateSelectedCount();
        });
    }

    function scopeEntityStillValid(entityId, selectedCompanies) {
        const row = (state.scopeEntityRows || []).find(item => String(item.sno) === String(entityId));
        return !row || selectedCompanies.includes(Number(row.company_id));
    }

    function scopeBranchStillValid(branchId, selectedEntities, selectedCompanies) {
        const row = (state.scopeBranchRows || []).find(item => String(item.sno) === String(branchId));
        if (!row) return true;
        const entityOk = !selectedEntities.length || selectedEntities.includes(Number(row.entity_id));
        const companyOk = !Number(row.company_id) || !selectedCompanies.length || selectedCompanies.includes(Number(row.company_id));
        return entityOk && companyOk;
    }

    async function loadEntities() {
        const token = ++scopeRequestToken;
        const companies = multiValues('#tpCompany');
        const previousEntities = multiValues('#tpEntity').map(String);
        const previousBranches = multiValues('#tpBranch').map(String);
        const hasMainCompany = companies.includes(0);
        const businessCompanies = companies.filter(id => id !== 0);

        if (!companies.length) {
            setMulti('#tpEntity', [], false);
            setMulti('#tpBranch', [], false);
            state.scopeEntityRows = [];
            state.scopeBranchRows = [];
            $('#tpEntityWrap').classList.add('d-none');
            $('#tpBranchWrap').classList.add('d-none');
            renderOptions('#tpEntity', [], 'Select entity', false);
            renderOptions('#tpBranch', [], 'Select entity first', false);
            syncScopeSelect2('#tpEntity');
            syncScopeSelect2('#tpBranch');
            return;
        }

        if (!businessCompanies.length && hasMainCompany) {
            setMulti('#tpEntity', [], false);
            setMulti('#tpBranch', [], false);
            state.scopeEntityRows = [];
            state.scopeBranchRows = [];
            $('#tpEntityWrap').classList.add('d-none');
            $('#tpBranchWrap').classList.add('d-none');
            renderOptions('#tpEntity', [], 'Select entity', false);
            renderOptions('#tpBranch', [], 'Select entity first', false);
            syncScopeSelect2('#tpEntity');
            syncScopeSelect2('#tpBranch');
            refreshStaff();
            return;
        }

        const keepEntityIds = previousEntities.filter(id => scopeEntityStillValid(id, businessCompanies));
        const keepBranchIds = previousBranches.filter(id => scopeBranchStillValid(id, keepEntityIds.map(Number), businessCompanies));

        $('#tpEntityWrap').classList.remove('d-none');
        $('#tpBranchWrap').classList.remove('d-none');
        $('#tpEntity').disabled = true;
        $('#tpBranch').disabled = true;
        if (window.jQuery?.fn?.select2) {
            window.jQuery('#tpEntity').prop('disabled', true);
            window.jQuery('#tpBranch').prop('disabled', true);
        }

        try {
            const response = await getJson(urls.entities, {
                company_ids: businessCompanies,
                preserve_entity_ids: keepEntityIds.map(Number),
            });
            if (token !== scopeRequestToken) return;

            const entityRows = response.data || [];
            state.scopeEntityRows = entityRows;
            const entityOptions = entityRows.map(item => ({ id: item.sno, text: item.entity_name }));
            const entityIds = entityOptions.map(item => String(item.id));
            const preserved = keepEntityIds.filter(id => entityIds.includes(id));
            const selectedEntityIds = preserved.length ? preserved : (entityIds.length === 1 ? entityIds : []);

            renderOptions('#tpEntity', entityOptions, 'Select entity', false);
            setMulti('#tpEntity', selectedEntityIds, false);
            syncScopeSelect2('#tpEntity');

            if (!selectedEntityIds.length) {
                renderOptions('#tpBranch', [], entityOptions.length ? 'Select entity to load branches' : 'No entity available', false);
                setMulti('#tpBranch', [], false);
                state.scopeBranchRows = [];
                syncScopeSelect2('#tpBranch');
                return;
            }

            await loadBranches(new Set(keepBranchIds), token);
        } catch (error) {
            if (token !== scopeRequestToken) return;
            toast(error.message || 'Unable to load entities.', 'error');
        } finally {
            if (token === scopeRequestToken) {
                $('#tpEntity').disabled = false;
                $('#tpBranch').disabled = false;
                if (window.jQuery?.fn?.select2) {
                    window.jQuery('#tpEntity').prop('disabled', false);
                    window.jQuery('#tpBranch').prop('disabled', false);
                }
            }
        }
    }

    async function loadBranches(previousBranchSet = null, parentToken = null) {
        const token = parentToken ?? ++scopeRequestToken;
        const companies = multiValues('#tpCompany');
        const entities = multiValues('#tpEntity');
        const businessCompanies = companies.filter(id => id !== 0);
        const previousBranches = previousBranchSet || new Set(multiValues('#tpBranch').map(String));

        if (!companies.length || !businessCompanies.length || !entities.length) {
            setMulti('#tpBranch', [], false);
            state.scopeBranchRows = [];
            $('#tpBranchWrap').classList.toggle('d-none', !entities.length);
            renderOptions('#tpBranch', [], 'Select entity first', false);
            syncScopeSelect2('#tpBranch');
            refreshStaff();
            return;
        }

        $('#tpBranchWrap').classList.remove('d-none');
        $('#tpBranch').disabled = true;
        if (window.jQuery?.fn?.select2) window.jQuery('#tpBranch').prop('disabled', true);

        try {
            const response = await getJson(urls.branches, {
                company_ids: businessCompanies,
                entity_ids: entities,
                preserve_branch_ids: [...previousBranches].map(Number),
            });
            if (token !== scopeRequestToken) return;

            const branchRows = response.data || [];
            state.scopeBranchRows = branchRows;
            const branchOptions = branchRows.map(item => ({
                id: item.sno,
                text: item.branch_type == 2 ? (item.franchise_name || item.branch_name) : item.branch_name,
            }));
            const branchIds = branchOptions.map(item => String(item.id));
            const preserved = [...previousBranches].filter(id => branchIds.includes(id));
            const selectedBranchIds = preserved.length ? preserved : (branchIds.length === 1 ? branchIds : []);

            renderOptions('#tpBranch', branchOptions, 'Select branch', false);
            setMulti('#tpBranch', selectedBranchIds, false);
            syncScopeSelect2('#tpBranch');
            refreshStaff();
        } catch (error) {
            if (token !== scopeRequestToken) return;
            toast(error.message || 'Unable to load branches.', 'error');
        } finally {
            if (token === scopeRequestToken) {
                $('#tpBranch').disabled = false;
                if (window.jQuery?.fn?.select2) window.jQuery('#tpBranch').prop('disabled', false);
            }
        }
    }

    async function refreshStaff() {
        const scope = scopePayload();
        const schedule = schedulePayload();

        if (!scope.company_ids.length) return;
        if (!schedule.from_date || !schedule.to_date || !schedule.from_time || !schedule.to_time) return;
        if (schedule.schedule_type === 'custom' && (!schedule.custom_dates || !schedule.custom_dates.length)) return;

        $('#tpAttendeeList').innerHTML = `
            <div class="tp-loader">
                <span class="spinner-border spinner-border-sm"></span>
                Checking trainer and attendee availability…
            </div>
        `;

        try {
            const response = await getJson(urls.staff, {
                ...scope,
                ...schedule,
                selected_trainer: $('#tpTrainer').value || 0,
                exclude_training_id: $('#tpId').value || 0,
            });

            state.staff = response.data || [];
            renderStaff(state.staff);
            await populateTrainer(state.staff);
        } catch (error) {
            $('#tpAttendeeList').innerHTML = '<div class="tp-empty text-danger">Unable to load staff availability.</div>';
            toast(error.message || 'Unable to check availability.', 'error');
        }
    }

    let trainerOptionsRequest = null;
    let trainerOptionsRequestSeq = 0;

    async function loadGlobalActiveTrainerOptions() {
        if (!trainerOptionsRequest) {
            trainerOptionsRequest = getJson(urls.trainerStaff, { mode: 'trainer_options' })
                .then(response => Array.isArray(response.data) ? response.data : [])
                .finally(() => {
                    trainerOptionsRequest = null;
                });
        }

        return trainerOptionsRequest;
    }

    async function populateTrainer(staff, selectedTrainer = null) {
        const requestSeq = ++trainerOptionsRequestSeq;
        const current = selectedTrainer !== null ? String(selectedTrainer) : String($('#tpTrainer').value || '');

        try {
            const trainerStaff = await loadGlobalActiveTrainerOptions();
            if (requestSeq !== trainerOptionsRequestSeq) return;

            const options = [
                { id: 0, text: 'External / Other' },
                ...trainerStaff.map(person => ({
                    id: person.sno,
                    text: `${person.staff_name} - ${person.entity_name || 'Entity'}`,
                    title: `${person.staff_name} - ${person.entity_name || 'Entity'}`,
                    entity_color: person.entity_base_color || '#ab2b22',
                })),
            ];

            destroySelect('#tpTrainer');
            renderOptions('#tpTrainer', options, 'Select trainer');
            initSelect('#tpTrainer', { placeholder: 'Select active trainer' });
            $('#tpTrainer').disabled = false;

            if (current !== '' && options.some(option => String(option.id) === current)) {
                if (window.jQuery?.fn?.select2) {
                    window.jQuery('#tpTrainer').val(current).trigger('change');
                } else {
                    $('#tpTrainer').value = current;
                }
            }

            toggleExternalTrainer();
        } catch (error) {
            if (requestSeq !== trainerOptionsRequestSeq) return;
            destroySelect('#tpTrainer');
            renderOptions('#tpTrainer', [{ id: 0, text: 'External / Other' }], 'Select trainer');
            initSelect('#tpTrainer', { placeholder: 'Select active trainer' });
            $('#tpTrainer').disabled = false;
            toggleExternalTrainer();
            toast(error.message || 'Unable to load active trainers.', 'error');
        }
    }

    function renderStaff(staff) {
        const trainerId = Number($('#tpTrainer').value || 0);
        const selected = new Set(state.currentTraining?.staff_ids?.map(Number) || selectedStaff());
        if (trainerId > 0) {
            selected.delete(trainerId);
        }

        const query = $('#tpStaffSearch').value.toLowerCase().trim();
        const filtered = staff.filter(person => {
            if (trainerId > 0 && Number(person.sno) === trainerId) return false;
            const text = `${person.staff_name} ${person.department_name || ''} ${person.job_role_name || ''}`.toLowerCase();
            return !query || text.includes(query);
        });

        if (!filtered.length) {
            $('#tpAttendeeList').innerHTML = '<div class="tp-empty">No matching staff found.</div>';
            updateSelectedCount();
            return;
        }

        $('#tpAttendeeList').innerHTML = filtered.map(person => {
            const isSelected = selected.has(Number(person.sno));
            const disabled = !person.available && !isSelected;
            const conflict = (person.conflicts || [])[0];

            return `
                <div class="tp-attendee-row ${person.available ? '' : 'tp-busy'}">
                    <div class="form-check">
                        <input class="form-check-input tp-attendee-check" type="checkbox" value="${person.sno}" ${isSelected ? 'checked' : ''} ${disabled ? 'disabled' : ''}>
                    </div>
                    <div class="tp-avatar">
                        ${person.staff_image_url ? 
                        `<img src="${person.staff_image_url}" 
                                                alt="user-avatar"  
                                                class="rounded-circle"
                                                style="width:40px; height:40px; object-fit:fill;"/>` : `${esc(initials(person.staff_name))}`}

                    
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold">${esc(person.staff_name)}</div>
                        <div class="small text-muted"> <span class="badge text-white" style="background-color:${person.entity_base_color}">${esc(person.entity_name || '-')} . </span> ${esc(person.department_name || '-')} · ${esc(person.job_role_name || '-')}</div>
                    </div>
                    ${person.available
                        ? '<span class="tp-ok-badge">Available</span>'
                        : `<span class="tp-busy-badge" title="${esc(conflict?.training_name || 'Already booked')}">Busy</span>`}
                </div>
            `;
        }).join('');

        updateSelectedCount();
        syncSelectAll();
    }

    function updateSelectedCount() {
        $('#tpSelectedCount').textContent = String(selectedStaff().length);
    }

    function syncSelectAll() {
        const available = $$('#tpAttendeeList .tp-attendee-check:not(:disabled)');
        const selected = available.filter(input => input.checked);
        $('#tpSelectAll').checked = available.length > 0 && available.length === selected.length;
    }

    function toggleExternalTrainer() {
        const external = $('#tpTrainer').value === '0';
        $('#tpExternalTrainerWrap').classList.toggle('d-none', !external);
    }

    function collectPlanner() {
        return {
            ...scopePayload(),
            ...schedulePayload(),
            training_planner_name: $('#tpName').value.trim(),
            training_mode: Number($('#tpMode').value),
            trainer: Number($('#tpTrainer').value || 0),
            trainer_name: $('#tpTrainerName').value.trim(),
            trainer_score: $('#tpTrainerScore').value === '' ? null : Number($('#tpTrainerScore').value),
            attendee_score_default: $('#tpAttendeeScoreDefault').value === '' ? null : Number($('#tpAttendeeScoreDefault').value),
            staff_ids: selectedStaff(),
            all_attendees: $('#tpSelectAll').checked ? 1 : 0,
            certificate_available: $('#tpCertificate').checked ? 1 : 0,
            assessment_required: $('#tpAssessment').checked ? 1 : 0,
            // certificate_name: $('#tpCertificateName').value.trim() || null,
            // assessment_pass_percentage: $('#tpAssessmentPass').value === ''
            //     ? null
            //     : Number($('#tpAssessmentPass').value),
            training_desc: $('#tpDescription').value.trim() || null,
            planner_status: $('#tpPlannerStatus').value,
        };
    }

    function validatePlanner(payload) {
        clearErrors();
        let valid = true;

        const setError = (selector, message) => {
            if (message) {
                $(selector).textContent = message;
                valid = false;
            }
        };

        if (!payload.company_ids.length) {
            setError('#tpErrCompany', 'Company is required.');
        }

        if (!payload.company_ids.includes(0) && !payload.entity_ids.length) {
            setError('#tpErrEntity', 'Select at least one entity.');
        }

        if (!payload.company_ids.includes(0) && !payload.branch_ids.length) {
            setError('#tpErrBranch', 'Select at least one branch.');
        }

        if (!payload.training_planner_name) {
            setError('#tpErrName', 'Training planner name is required.');
        }

        if (!payload.training_mode) {
            setError('#tpErrMode', 'Training mode is required.');
        }

        if ($('#tpTrainer').value === '') {
            setError('#tpErrTrainer', 'Trainer is required.');
        }

        if (payload.trainer === 0 && !payload.trainer_name) {
            setError('#tpErrTrainerName', 'External trainer name is required.');
        }

        if (payload.schedule_type === 'custom') {
            const dates = payload.custom_dates || [];

            if (!dates.length) {
                setError('#tpErrCustomDates', 'Select at least one training date.');
            }

            if (!payload.from_time) {
                setError('#tpErrFromTime', 'Start time is required.');
            }

            if (!payload.to_time) {
                setError('#tpErrToTime', 'End time is required.');
            }

            if (payload.from_time && payload.to_time && payload.from_time >= payload.to_time) {
                setError('#tpErrToTime', 'End time must be after Start time.');
            }
        } else {
            if (!payload.from_date) setError('#tpErrFromDate', 'From date is required.');
            if (!payload.to_date) setError('#tpErrToDate', 'To date is required.');
            if (!payload.from_time) setError('#tpErrRangeFromTime', 'Start time is required.');
            if (!payload.to_time) setError('#tpErrRangeToTime', 'End time is required.');

            if (payload.from_date && payload.to_date && payload.from_date > payload.to_date) {
                setError('#tpErrToDate', 'To date cannot be before From date.');
            }

            if (
                payload.from_date === payload.to_date &&
                payload.from_time &&
                payload.to_time &&
                payload.from_time >= payload.to_time
            ) {
                setError('#tpErrRangeToTime', 'End time must be after Start time.');
            }
        }

        if (
            payload.assessment_required &&
            (payload.assessment_pass_percentage === null ||
                payload.assessment_pass_percentage < 0 ||
                payload.assessment_pass_percentage > 100)
        ) {
            setError('#tpErrAssessmentPass', 'Enter a pass percentage between 0 and 100.');
        }

        if (payload.trainer_score !== null && (payload.trainer_score < 0 || payload.trainer_score > 100)) {
            setError('#tpErrTrainerScore', 'Trainer score must be between 0 and 100.');
        }

        if (payload.attendee_score_default !== null && (payload.attendee_score_default < 0 || payload.attendee_score_default > 100)) {
            setError('#tpErrAttendeeScoreDefault', 'Attendee score must be between 0 and 100.');
        }

        return valid;
    }

    function renderConflicts(error) {
        const trainerConflicts = error.conflicts?.trainer || [];
        const attendeeConflicts = error.conflicts?.attendees || [];

        if (!trainerConflicts.length && !attendeeConflicts.length) return;

        const items = [];

        trainerConflicts.forEach(conflict => {
            items.push(`Trainer conflict: <strong>${esc(conflict.training_name)}</strong> (${esc(fmtDateTime(conflict.from))} – ${esc(fmtDateTime(conflict.to))})`);
        });

        attendeeConflicts.forEach(conflict => {
            items.push(`Attendee conflict with <strong>${esc(conflict.training?.training_planner_id || '')}</strong>: staff ${esc((conflict.staff_ids || []).join(', '))}`);
        });

        $('#tpConflictSummary').innerHTML = `
            <div class="alert alert-danger mb-0">
                <div class="fw-bold mb-1">Schedule conflict detected</div>
                <ul class="mb-0 ps-3">${items.map(item => `<li>${item}</li>`).join('')}</ul>
            </div>
        `;
    }

    function fmtDateTime(value) {
        if (!value) return '-';
        return new Date(value).toLocaleString(undefined, {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        });
    }

    function resetPlanner() {
        clearErrors();
        state.currentTraining = null;

        $('#tpId').value = '';
        $('#tpModeEdit').value = 'create';
        $('#tpPlannerModalTitle').textContent = 'Create Training';
        $('#tpName').value = '';
        $('#tpMode').value = '';
        $('#tpTrainer').innerHTML = '<option value="">Select schedule first</option>';
        $('#tpTrainer').disabled = true;
        $('#tpTrainerName').value = '';
        $('#tpTrainerScore').value = '';
        $('#tpAttendeeScoreDefault').value = '';
        $('#tpDescription').value = '';
        $('#tpPlannerStatus').value = 'scheduled';
        $('#tpCertificate').checked = false;
        $('#tpAssessment').checked = false;
        // $('#tpCertificateName').value = '';
        // $('#tpAssessmentPass').value = '';
        $('#tpCustomDateBadges').innerHTML = '<span class="small text-muted">No dates selected.</span>';
        $('#tpAttendeeList').innerHTML = '<div class="tp-loader">Select scope and schedule first…</div>';
        document.querySelector('#tpScheduleCustom').checked = true;

        setMulti('#tpCompany', [], false);
        setMulti('#tpEntity', [], false);
        setMulti('#tpBranch', [], false);
        $('#tpEntityWrap').classList.add('d-none');
        $('#tpBranchWrap').classList.add('d-none');

        datePickers.customDates.clear();
        datePickers.fromDate.clear();
        datePickers.toDate.clear();
        datePickers.rangeFromTime.clear();
        datePickers.rangeToTime.clear();
        datePickers.fromTime.clear();
        datePickers.toTime.clear();

        toggleScheduleUi();
        toggleExternalTrainer();
        renderCustomDateBadges();
        updateSelectedCount();
    }

    async function openEdit(id) {
        try {
            const response = await getJson(urls.show(id));
            fillPlanner(response.data);
            plannerModal.show();
        } catch (error) {
            toast(error.message || 'Unable to load training.', 'error');
        }
    }

    function renderScheduleForView(training) {
        const sessions = training.custom_sessions || [];

        if (training.schedule_type === 'custom' && sessions.length) {
            return `
                <div class="mb-2"><span class="tp-pill tp-pill-blue">Custom dates</span></div>
                ${sessions.map((session, index) => `
                    <div class="tp-schedule-chip me-1 mb-1">
                        <span>${index + 1}.</span>
                        <span>${esc(fmtDate(session.date))}</span>
                        <span>·</span>
                        <span>${esc(fmtTime(session.from_time))}–${esc(fmtTime(session.to_time))}</span>
                    </div>
                `).join('')}
            `;
        }

        return `
            <div class="tp-schedule-chip">
                <i class="mdi mdi-calendar-range"></i>
                ${esc(fmtDate(training.from_date))} – ${esc(fmtDate(training.to_date))}
                · ${esc(fmtTime(training.from_time))}–${esc(fmtTime(training.to_time))}
            </div>
        `;
    }

    // function renderView(training) {
    //     state.currentTraining = training;

    //     $('#tpViewTitle').textContent = training.training_planner_name;
    //     $('#tpViewStatus').innerHTML = statusBadge(training.planner_status);

    //     const info = [
    //         ['Planner ID', training.training_planner_id],
    //         ['Mode', training.training_mode_label],
    //         ['Trainer', training.trainer_name],
    //         ['Duration', `${training.training_duration} hrs`],
    //         ['Company', (training.scope_names?.companies || []).join(', ') || '-'],
    //         ['Entity', (training.scope_names?.entities || []).join(', ') || '-'],
    //         ['Branch', (training.scope_names?.branches || []).join(', ') || '-'],
    //         ['Sessions', training.schedule_type === 'custom' ? String((training.custom_sessions || []).length) : 'Date range'],
    //     ];

    //     $('#tpViewInfo').innerHTML = info.map(item => `
    //         <div class="tp-info">
    //             <small>${esc(item[0])}</small>
    //             <strong>${esc(item[1])}</strong>
    //         </div>
    //     `).join('');

    //     $('#tpViewSchedule').innerHTML = renderScheduleForView(training);
    //     $('#tpViewDescription').textContent = training.training_desc || 'No description provided.';

    //     $('#tpViewRequirements').innerHTML = `
    //         <span class="tp-pill ${training.certificate_available ? 'tp-pill-green' : 'tp-pill-gray'}">
    //             <i class="mdi mdi-certificate-outline"></i>
    //             Certificate ${training.certificate_available ? 'Available' : 'Not enabled'}
    //         </span>
    //         <span class="tp-pill ${training.assessment_required ? 'tp-pill-blue' : 'tp-pill-gray'}">
    //             <i class="mdi mdi-clipboard-check-outline"></i>
    //             Assessment ${training.assessment_required ? 'Required' : 'Not required'}
    //         </span>
    //     `;

    //     const attendees = training.attendees || [];
    //     const summary = training.attendance_summary || {};

    //     $('#tpViewAttendanceSummary').textContent = `${attendees.length} attendee(s) · ${summary.present || 0} present · ${summary.absent || 0} absent · ${summary.pending || 0} pending`;

    //     $('#tpViewAttendees').innerHTML = attendees.length
    //         ? attendees.map(attendee => `
    //             <div class="tp-attendee-row">
    //                 <div class="tp-avatar">${esc(initials(attendee.staff_name))}</div>
    //                 <div class="flex-grow-1">
    //                     <div class="fw-semibold">${esc(attendee.staff_name)}</div>
    //                     <div class="small text-muted">Staff ID: ${esc(attendee.staff_id)}</div>
    //                 </div>
    //                 <span class="tp-pill ${attendee.attendance_status === 1 ? 'tp-pill-green' : attendee.attendance_status === 0 ? 'tp-pill-gray' : 'tp-pill-gray'}">
    //                     ${attendee.attendance_status === 1 ? 'Present' : attendee.attendance_status === 0 ? 'Absent' : 'Pending'}
    //                 </span>
    //             </div>
    //         `).join('')
    //         : '<div class="tp-empty">No attendees found.</div>';

    //     const locked = ['completed', 'cancelled'].includes(training.planner_status);
    //     const canComplete = !locked && new Date(training.end) <= new Date();

    //     $('#tpViewEditBtn').disabled = locked;
    //     $('#tpViewCompleteBtn').classList.toggle('d-none', !canComplete);

    //     $('#tpViewEditBtn').onclick = () => {
    //         viewModal.hide();
    //         openEdit(training.sno);
    //     };

    //     $('#tpViewCompleteBtn').onclick = () => {
    //         viewModal.hide();
    //         openComplete(training.sno);
    //     };
    // }

    function renderView(training) {

        state.currentTraining = training;

        /* BASIC HEADER */

        $('#tpViewTitle').textContent =
            training.training_planner_name || 'Training Details';

        $('#tpViewPlannerId').textContent =
            training.training_planner_id || '--';

        $('#tpViewSubtitle').textContent =
            `${training.training_mode_label || 'Training'} · Training Planner`;

        $('#tpViewStatus').innerHTML =
            statusBadge(training.planner_status);

        /* SCHEDULE DATA */

        const sessions = Array.isArray(training.custom_sessions)
            ? training.custom_sessions
            : [];

        const isCustom =
            training.schedule_type === 'custom' &&
            sessions.length > 0;

        const scheduleCount = isCustom
            ? sessions.length
            : 1;

        $('#tpViewSessionCount').textContent =
            `${scheduleCount} ${scheduleCount === 1 ? 'session' : 'sessions'}`;

        $('#tpViewDuration').textContent =
            `${training.training_duration || 0} hrs`;

        /* Schedule hero */

        if (isCustom) {
            $('#tpViewScheduleSummary').textContent =
                `${sessions.length} custom training dates`;

            $('#tpViewScheduleMeta').textContent =
                `${formatTime12(training.from_time)} – ${formatTime12(training.to_time)} · Common session time`;

        } else {
            $('#tpViewScheduleSummary').textContent =
                `${fmtDate(training.from_date)} → ${fmtDate(training.to_date)}`;

            $('#tpViewScheduleMeta').textContent =
                `${formatTime12(training.from_time)} – ${formatTime12(training.to_time)} · Date range`;
        }

        /*
        * ----------------------------------------
        * INFO GRID
        * ----------------------------------------
        */

        const info = [
            {
                label: 'Training ID',
                value: training.training_planner_id || '-',
            },
            {
                label: 'Training Mode',
                value: training.training_mode_label || '-',
            },
            {
                label: 'Trainer',
                value: training.trainer_name || 'External Trainer',
            },
            {
                label: 'Duration',
                value: `${training.training_duration || 0} hrs`,
            },
            {
                label: 'Trainer Score',
                value: training.trainer_score === null || training.trainer_score === undefined ? '-' : `${training.trainer_score} Pts`,
            },
            {
                label: 'Default Attendee Score',
                value: training.attendee_score_default === null || training.attendee_score_default === undefined ? '-' : `${training.attendee_score_default} Pts`,
            },
        ];

        $('#tpViewInfo').innerHTML =
            info.map(item => `
                <div class="tp-view-info-item">
                    <div class="tp-view-info-label">
                        ${esc(item.label)}
                    </div>

                    <div class="tp-view-info-value">
                        ${esc(item.value)}
                    </div>
                </div>
            `).join('');

        /* SCHEDULE LIST */

        if (isCustom) {

            $('#tpViewSchedule').innerHTML = sessions
                .map((session, index) => {

                    const dateValue =
                        session.date || session.from?.slice(0, 10);

                    const date =
                        new Date(`${dateValue}T00:00:00`);

                    const month =
                        date.toLocaleDateString(undefined, {
                            month: 'short',
                        });

                    const day =
                        date.toLocaleDateString(undefined, {
                            day: '2-digit',
                        });

                    const weekday =
                        date.toLocaleDateString(undefined, {
                            weekday: 'short',
                        });

                    const fromTime =
                        formatTime12(
                            session.from_time || training.from_time
                        );

                    const toTime =
                        formatTime12(
                            session.to_time || training.to_time
                        );

                    return `
                        <div class="tp-view-schedule-row">

                            <div class="tp-view-date-tile">

                                <div class="tp-view-date-month">
                                    ${esc(month)}
                                </div>

                                <div class="tp-view-date-day">
                                    ${esc(day)}
                                </div>

                                <div class="tp-view-date-week">
                                    ${esc(weekday)}
                                </div>

                            </div>

                            <div class="flex-grow-1">

                                <div class="tp-view-schedule-title">
                                    Session ${index + 1}
                                </div>

                                <div class="tp-view-schedule-time">
                                    <i class="mdi mdi-clock-outline me-1"></i>
                                    ${esc(fromTime)}
                                    –
                                    ${esc(toTime)}
                                </div>

                            </div>

                            <span class="tp-pill tp-pill-blue">
                                ${esc(training.training_mode_label || 'Training')}
                            </span>

                        </div>
                    `;
                })
                .join('');

        } else {

            $('#tpViewSchedule').innerHTML = `
                <div class="tp-view-schedule-row">

                    <div class="tp-view-date-tile">

                        <div class="tp-view-date-month">
                            ${esc(
                                new Date(
                                    `${training.from_date}T00:00:00`
                                ).toLocaleDateString(undefined, {
                                    month: 'short'
                                })
                            )}
                        </div>

                        <div class="tp-view-date-day">
                            ${esc(
                                new Date(
                                    `${training.from_date}T00:00:00`
                                ).toLocaleDateString(undefined, {
                                    day: '2-digit'
                                })
                            )}
                        </div>

                        <div class="tp-view-date-week">
                            ${esc(
                                new Date(
                                    `${training.from_date}T00:00:00`
                                ).toLocaleDateString(undefined, {
                                    weekday: 'short'
                                })
                            )}
                        </div>

                    </div>

                    <div class="flex-grow-1">

                        <div class="tp-view-schedule-title">
                            ${esc(
                                fmtDate(training.from_date)
                            )}
                            →
                            ${esc(
                                fmtDate(training.to_date)
                            )}
                        </div>

                        <div class="tp-view-schedule-time">
                            <i class="mdi mdi-clock-outline me-1"></i>
                            ${esc(formatTime12(training.from_time))}
                            –
                            ${esc(formatTime12(training.to_time))}
                        </div>

                    </div>

                    <span class="tp-pill tp-pill-gray">
                        Date Range
                    </span>

                </div>
            `;
        }

        /* TRAINER */

        const trainerName =
            training.trainer_name ||
            'External Trainer';

        const trainerType =
            Number(training.trainer) > 0
                ? 'Internal Staff Trainer'
                : 'External Trainer';

        $('#tpViewTrainer').innerHTML = `
            <div class="tp-view-trainer-profile">

                <div class="tp-view-trainer-avatar">
                ${training.trainer_imge_url ? 
                        `<img src="${training.trainer_imge_url}" 
                                                alt="user-avatar"  
                                                class="rounded-circle"
                                                style="width:40px; height:40px; object-fit:fill;"/>` : `${esc(initials(trainerName))}`}
                    
                </div>

                <div>

                    <div class="tp-view-trainer-name">
                        ${esc(trainerName)}
                    </div>

                    <div class="tp-view-trainer-type">
                        ${esc(trainerType)}
                    </div>

                </div>

            </div>
        `;

        /* BUSINESS SCOPE */

        const scopeItems = [
            {
                label: 'Company',
                value:
                    (training.scope_names?.companies || []).join(', ')
                    || '-',
            },
            {
                label: 'Entity',
                value:
                    (training.scope_names?.entities || []).join(', ')
                    || 'All / Not applicable',
            },
            {
                label: 'Branch',
                value:
                    (training.scope_names?.branches || []).join(', ')
                    || 'All / Not applicable',
            },
        ];

        $('#tpViewScope').innerHTML =
            scopeItems.map(item => `
                <div class="col-md-4">

                    <div class="tp-view-scope-item">

                        <div class="tp-view-scope-label">
                            ${esc(item.label)}
                        </div>

                        <div class="tp-view-scope-value">
                            ${esc(item.value)}
                        </div>

                    </div>

                </div>
            `).join('');

        /* DESCRIPTION */

        $('#tpViewDescription').textContent =
            training.training_desc ||
            'No description provided for this training.';

        /*REQUIREMENTS */

        const requirements = [];

        requirements.push(`
            <div class="tp-view-requirement">

                <div class="tp-view-requirement-icon ${
                    training.certificate_available
                        ? 'green'
                        : 'gray'
                }">

                    <i class="mdi mdi-certificate-outline"></i>

                </div>

                <div class="tp-view-requirement-title">
                    Certificate
                </div>

                <div class="tp-view-requirement-text">
                    ${
                        training.certificate_available
                            ? (
                                training.certificate_name
                                    ? esc(training.certificate_name)
                                    : 'Certificate issuance enabled'
                            )
                            : 'Certificate is not enabled'
                    }
                </div>

            </div>
        `);

        requirements.push(`
            <div class="tp-view-requirement">

                <div class="tp-view-requirement-icon ${
                    training.assessment_required
                        ? 'blue'
                        : 'gray'
                }">

                    <i class="mdi mdi-clipboard-check-outline"></i>

                </div>

                <div class="tp-view-requirement-title">
                    Assessment
                </div>

                <div class="tp-view-requirement-text">
                    ${
                        training.assessment_required
                            ? `Assessment required${
                                training.assessment_pass_percentage !== null &&
                                training.assessment_pass_percentage !== undefined
                                    ? ` · Pass ${esc(training.assessment_pass_percentage)}%`
                                    : ''
                            }`
                            : 'No assessment required'
                    }
                </div>

            </div>
        `);

        $('#tpViewRequirements').innerHTML =
            requirements.join('');

        /*
        * ----------------------------------------
        * ATTENDANCE
        * ----------------------------------------
        */

        const attendees =
            Array.isArray(training.attendees)
                ? training.attendees
                : [];

        const summary =
            training.attendance_summary || {};

        const total =
            Number(summary.total ?? attendees.length);

        const present =
            Number(summary.present ?? 0);

        const absent =
            Number(summary.absent ?? 0);

        const pending =
            Number(summary.pending ?? Math.max(
                0,
                total - present - absent
            ));

        const attendancePercent =
            total > 0
                ? Math.round(
                    ((present + absent) / total) * 100
                )
                : 0;

        $('#tpViewAttendanceSummary').textContent =
            `${total} attendees · ${present} present · ${absent} absent · ${pending} pending`;

        $('#tpViewAttendancePercent').textContent =
            `${attendancePercent}%`;

        $('#tpViewAttendanceProgress').style.width =
            `${attendancePercent}%`;

        $('#tpViewAttendees').innerHTML =
            attendees.length
                ? attendees.map(attendee => {

                    const attendanceText =
                        attendee.attendance_status === 1
                            ? 'Present'
                            : attendee.attendance_status === 0
                                ? 'Absent'
                                : 'Pending';

                    const attendanceClass =
                        attendee.attendance_status === 1
                            ? 'tp-pill-green'
                            : attendee.attendance_status === 0
                                ? 'tp-pill-red'
                                : 'tp-pill-gray';

                    return `
                        <div class="tp-view-attendee">

                            <div class="tp-view-attendee-avatar">
                            ${attendee.attendee_image_url ? 
                                `<img src="${attendee.attendee_image_url}" 
                                                        alt="user-avatar"  
                                                        class="rounded-circle"
                                                        style="width:40px; height:40px; object-fit:fill;"/>` : `${esc(initials(attendee.staff_name))}`}
                               
                            </div>

                            <div class="flex-grow-1">

                                <div class="tp-view-attendee-name">
                                    ${esc(attendee.staff_name)}
                                </div>

                                <!-- <div class="tp-view-attendee-meta">
                                    Staff ID:
                                    ${esc(attendee.staff_id)}
                                </div> -->

                            </div>

                            <span class="tp-pill ${attendanceClass}">
                                ${esc(attendanceText)}
                            </span>

                            ${
                                attendee.attendee_score !== null && attendee.attendee_score !== undefined
                                    ? `<span class="tp-pill tp-pill-blue"><i class="mdi mdi-star-outline"></i> ${esc(attendee.attendee_score)} Pts</span>`
                                    : ''
                            }

                            ${
                                training.assessment_required
                                    ? `
                                        <span class="tp-pill ${
                                            attendee.assessment_status === 1
                                                ? 'tp-pill-green'
                                                : attendee.assessment_status === 0
                                                    ? 'tp-pill-red'
                                                    : 'tp-pill-gray'
                                        }">
                                            ${
                                                attendee.assessment_status === 1
                                                    ? 'Passed'
                                                    : attendee.assessment_status === 0
                                                        ? 'Failed'
                                                        : 'Assessment Pending'
                                            }
                                        </span>
                                    `
                                    : ''
                            }

                            ${
                                training.certificate_available
                                    ? `
                                        <span class="tp-pill ${
                                            attendee.certificate_issued
                                                ? 'tp-pill-blue'
                                                : 'tp-pill-gray'
                                        }">
                                            ${
                                                attendee.certificate_issued
                                                    ? 'Certificate Issued'
                                                    : 'Certificate Pending'
                                            }
                                        </span>
                                    `
                                    : ''
                            }

                            <button
                                type="button"
                                class="btn btn-sm btn-outline-secondary tp-staff-history-btn"
                                data-staff-id="${esc(attendee.staff_id)}"
                                data-staff-name="${esc(attendee.staff_name)}"
                                title="Training history"
                            >
                                <i class="mdi mdi-history"></i>
                                <span class="d-none d-xl-inline">History</span>
                            </button>

                        </div>
                    `;
                }).join('')
                : `
                    <div class="tp-empty">
                        <i class="mdi mdi-account-group-outline fs-1 d-block mb-2"></i>
                        No attendees have been assigned.
                    </div>
                `;

        /* ACTIONS */

        const locked =
            ['completed', 'cancelled']
                .includes(training.planner_status);

        const canComplete =
            !locked &&
            training.end &&
            new Date(training.end) <= new Date();

        const editButtons = [
            $('#tpViewEditBtn'),
            // $('#tpViewEditBtnFooter'),
        ];

        const completeButtons = [
            $('#tpViewCompleteBtn'),
            $('#tpViewCompleteBtnFooter'),
        ];

        editButtons.forEach(button => {
            if (!button) return;

            button.disabled = locked;

            button.onclick = () => {
                viewModal.hide();
                openEdit(training.sno);
            };
        });

        completeButtons.forEach(button => {
            if (!button) return;

            button.classList.toggle(
                'd-none',
                !canComplete
            );

            button.onclick = () => {
                viewModal.hide();
                openComplete(training.sno);
            };
        });
    }

    async function openView(id) {
        try {
            const response = await getJson(urls.show(id));
            renderView(response.data);
            viewModal.show();
        } catch (error) {
            toast(error.message || 'Unable to load training.', 'error');
        }
    }

    function setDateValue(picker, value) {
        if (picker && picker._flatpickr) picker._flatpickr.setDate(value || null, false);
    }

    function formatTime(timeString) {
        if (!timeString) return "-";

        const parts = timeString.split(":");
        if (parts.length < 2) return "-";

        let hours = parseInt(parts[0]);
        let minutes = parts[1];
        let seconds = parts[2] || "00";

        let ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12;

        return `${hours.toString().padStart(2,"0")}:${minutes} ${ampm}`;
    }

    async function fillPlanner(training) {
        state.currentTraining = training;

        $('#tpId').value = training.sno;
        $('#tpModeEdit').value = 'edit';
        $('#tpPlannerModalTitle').textContent = 'Edit Training';
        $('#tpName').value = training.training_planner_name || '';
       
        window.jQuery('#tpMode').val(String(training.training_mode || '')).trigger('change');
        $('#tpTrainerName').value = training.trainer === 0 ? (training.trainer_name || '') : '';
        $('#tpDescription').value = training.training_desc || '';
        $('#tpTrainerScore').value = training.trainer_score ?? '';
        $('#tpAttendeeScoreDefault').value = training.attendee_score_default ?? '';
        $('#tpPlannerStatus').value = training.planner_status === 'rescheduled' ? 'rescheduled' : 'scheduled';
        $('#tpCertificate').checked = Boolean(training.certificate_available);
        $('#tpAssessment').checked = Boolean(training.assessment_required);
        // $('#tpCertificateName').value = training.certificate_name || '';
        // $('#tpAssessmentPass').value = training.assessment_pass_percentage ?? '';

        if (training.schedule_type === 'custom' && (training.custom_sessions || []).length) {
            $('#tpScheduleCustom').checked = true;

            const dates = (training.custom_sessions || [])
                .map(session => session.date)
                .filter(Boolean);

            datePickers.customDates.setDate(dates, false);

            const firstSession = training.custom_sessions[0] || {};
            setDateValue(datePickers.fromTime, formatTime12(firstSession.from_time || training.from_time));
            setDateValue(datePickers.toTime, formatTime12(firstSession.to_time || training.to_time));

            renderCustomDateBadges();
        } else {
            $('#tpScheduleRange').checked = true;
            setDateValue(datePickers.fromDate, training.from_date);
            setDateValue(datePickers.toDate, training.to_date);
            setDateValue(datePickers.rangeFromTime, formatTime12(training.from_time));
            setDateValue(datePickers.rangeToTime, formatTime12(training.to_time));
            $('#tpCustomDateBadges').innerHTML = '<span class="small text-muted">No dates selected.</span>';
        }

        setMulti('#tpCompany', training.company_ids || [], false);
        await loadEntities();
        setMulti('#tpEntity', training.entity_ids || [], false);
        await loadBranches();
        setMulti('#tpBranch', training.branch_ids || [], false);

        toggleScheduleUi();
        await refreshStaff();
        await populateTrainer(state.staff, training.trainer);
        renderStaff(state.staff);
        toggleExternalTrainer();
    }

    function renderRow(training) {
        const summary = training.attendee_counts || training.attendance_summary || {
            total: (training.staff_ids || []).length,
            present: 0,
            absent: 0,
            pending: (training.staff_ids || []).length,
        };

        const sessionSummary = training.session_summary || {
            total: (training.custom_sessions || []).length || 0,
            completed: 0,
            in_progress: 0,
            scheduled: 0,
            cancelled: 0,
            attendance_marked: 0,
            attendance_present: 0,
            attendance_absent: 0,
            attendance_pending: 0,
        };

        const requirements = `
            <div class="d-flex flex-wrap gap-1">
                ${training.certificate_available ? '<span class="tp-pill tp-pill-green">Certificate</span>' : ''}
                ${training.assessment_required ? '<span class="tp-pill tp-pill-blue">Assessment</span>' : ''}
                ${!training.certificate_available && !training.assessment_required ? '<span class="tp-pill tp-pill-gray">Standard</span>' : ''}
            </div>
        `;

        const requirementsIcons = `
            <div class="d-flex flex-wrap gap-1">
                ${training.certificate_available ? '<span class="tp-pill tp-pill-green" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Certificate"><span class="mdi mdi-certificate-outline"></span></span>' : ''}
                ${training.assessment_required ? '<span class="tp-pill tp-pill-blue" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assessment"><span class="mdi mdi-clipboard-edit-outline"></span></span>' : ''}
                ${!training.certificate_available && !training.assessment_required ? '' : ''}
            </div>
        `;

        const locked = ['completed', 'cancelled'].includes(training.planner_status);
        const canComplete = !locked && training.end && new Date(training.end) <= new Date();

        let schedule = '';
        if (training.schedule_type === 'custom' && (training.custom_sessions || []).length) {
            const sessions = training.custom_sessions;
            schedule = `
                <div class="tp-schedule-summary d-flex gap-2">
                    
                    ${sessions.slice(0, 1).map(session => `
                        <div class="tp-schedule-line d-flex align-items-center">
                            <span class="text-primary badge bg-label-primary">
                                <i class="mdi mdi-calendar-outline "></i>
                            </span>
                            <div>
                                <div class="tp-schedule-date">${esc(fmtDate(session.date))}</div>
                                <div class="small text-muted">${esc(formatTime12(session.from_time))} – ${esc(formatTime12(session.to_time))}</div>
                            </div>
                        </div>
                    `).join('')}
                    ${sessions.length > 2 ? `<div class="">
                    <span class="tp-more-sessions badge bg-info">+${sessions.length - 1} more</span>
                    </div>` : ''}
                </div>
                <div class="mt-1 d-flex justify-content-start">
                    <span class="cursor-pointer  text-decoration-none text-start tp-pill tp-pill-blue" data-act="sessions" data-id="${training.sno}">
                        <span class="">${sessionSummary.completed}/${sessionSummary.total} Session${sessions.length > 1 ? 's' : ''}</span>
                    </span>
                </div>
            `;
        } else {
            schedule = `
                <div class="tp-schedule-summary">
                    <div class="fw-semibold">${esc(fmtDate(training.from_date))}</div>
                    <div class="small text-muted">${esc(formatTime12(training.from_time))} – ${esc(formatTime12(training.to_time))}</div>
                    ${training.from_date !== training.to_date ? `<div class="small text-muted">through ${esc(fmtDate(training.to_date))}</div>` : ''}
                    <span class="badge bg-light text-dark mt-1">${esc(training.training_duration)} hrs</span>
                </div>
            `;
        }

        return `
            <tr>
                <td>
                    <div class="fw-bold">${esc(training.training_planner_name)}</div>
                    <div class="d-flex gap-2">
                        <span class="small text-muted">${esc(training.training_planner_id)}</span>
                        ${requirementsIcons}
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <div class="tp-avatar">
                            ${training.trainer_imge_url
                                ? `<img src="${esc(training.trainer_imge_url)}" alt="Trainer" class="rounded-circle" style="width:40px;height:40px;object-fit:fill;">`
                                : esc(initials(training.trainer_name))}
                        </div>
                        <div>
                            <div class="fw-semibold">${esc(training.trainer_name)}</div>
                            <span class="badge bg-light text-dark">${esc(training.training_mode_label)}</span>
                        </div>
                    </div>
                </td>
                <td>${schedule}</td>
                <td>
                    <span class="cursor-pointer p-0 text-decoration-none text-center d-inline-block" data-act="attendees" data-id="${training.sno}" title="Open attendee attendance">
                        <div class="fw-bold"><span class="badge bg-primary">${summary.total}</span></div>
                        <div class="small mt-1 text-nowrap">
                            <span class="text-success fw-semibold">P ${summary.present || 0}</span>
                            <span class="text-danger fw-semibold ms-1">A ${summary.absent || 0}</span>
                            <span class="text-muted fw-semibold ms-1">Q ${summary.pending || 0}</span>
                        </div>
                    </span>
                </td>
                <!-- <td>
                    <span  class="cursor-pointer p-0 text-decoration-none text-start" data-act="sessions" data-id="${training.sno}">
                        <div class="fw-bold"><span class="badge bg-primary-subtle text-primary">${sessionSummary.completed}/${sessionSummary.total}</span> completed</div>
                        <div class="small text-muted">${sessionSummary.in_progress} in progress · ${sessionSummary.scheduled} scheduled</div>
                    </span>
                </td> -->
                <!--<td>${requirements}</td> -->
                <td><span  class="cursor-pointer p-0 text-decoration-none" data-act="status" data-id="${training.sno}">${statusBadge(training.planner_status)}</span></td>
                <td class="text-end">
                    <div class="dropdown">
                        <button type="button" class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-expanded="false" title="Actions">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" style="min-width:220px;">
                            <a href="javascript:;" class="dropdown-item" data-act="view" data-id="${training.sno}"><i class="mdi mdi-eye-outline me-2"></i>View details</a>
                            ${!locked ? `<a href="javascript:;" class="dropdown-item" data-act="edit" data-id="${training.sno}"><i class="mdi mdi-square-edit-outline me-2"></i>Edit training</a>` : ''}
                            ${!locked ? `<a href="javascript:;" class="dropdown-item" data-act="attendees" data-id="${training.sno}"><i class="mdi mdi-account-multiple-plus-outline me-2"></i>Manage attendees</a>` : ''}
                            ${!locked ? `<a href="javascript:;" class="dropdown-item" data-act="sessions" data-id="${training.sno}"><i class="mdi mdi-book-open-page-variant-outline me-2"></i>Manage sessions & syllabus</a>` : `<a href="javascript:;" class="dropdown-item" data-act="sessions" data-id="${training.sno}"><i class="mdi mdi-book-open-page-variant-outline me-2"></i>View sessions & syllabus</a>`}
                            <a href="javascript:;" class="dropdown-item" data-act="session-attendance" data-id="${training.sno}"><i class="mdi mdi-calendar-check-outline me-2"></i>Session attendance</a>
                            ${canComplete ? `<a href="javascript:;" class="dropdown-item text-success" data-act="complete" data-id="${training.sno}"><i class="mdi mdi-check-circle-outline me-2"></i>Complete training</a>` : ''}
                            <div class="dropdown-divider"></div>
                            <a href="javascript:;" class="dropdown-item text-danger" data-act="delete" data-id="${training.sno}"><i class="mdi mdi-delete-outline me-2"></i>Delete</a>
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }

    function buildListQuery() {
        return {
            mode: 'list',
            page: state.page,
            per_page: state.perPage,
            search: $('#tpSearch').value.trim(),
            planner_status: $('#tpFilterStatus').value,
            training_mode: $('#tpFilterMode').value,
            from_date: $('#tpFilterFrom').value,
            to_date: $('#tpFilterTo').value,
        };
    }

    async function loadTable(page = state.page) {
        state.page = Number(page) || 1;

        $('#tpTableBody').innerHTML = `
                <tr class="skeleton-loader" >
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                </tr>
        `;

        try {
            const response = await getJson(urls.data, buildListQuery());
            const pageData = response.data;
            const rows = pageData?.data || [];

            renderStats(response.stats || {});

            $('#tpTableBody').innerHTML = rows.length
                ? rows.map(renderRow).join('')
                : '<tr><td colspan="6"><div class="tp-empty">No training planners match your filters.</div></td></tr>';
                

            renderPagination(
                pageData.current_page,
                pageData.last_page,
                pageData.total,
                pageData.per_page
            );

          

        } catch (error) {
            $('#tpTableBody').innerHTML = `
                <tr>
                    <td colspan="6">
                        <div class="tp-empty text-danger">
                            Unable to load training planners.
                        </div>
                    </td>
                </tr>
            `;

            toast(error.message || 'Unable to load training planners.', 'error');
        }
    }

    

    function renderStats(stats) {
        const cards = [
            ['Total', stats.total, 'mdi-school-outline'],
            ['Scheduled', stats.scheduled, 'mdi-calendar-clock-outline'],
            ['Rescheduled', stats.rescheduled, 'mdi-calendar-edit'],
            ['Completed', stats.completed, 'mdi-check-decagram-outline'],
            ['Upcoming', stats.upcoming, 'mdi-calendar-arrow-right'],
            ['Cancelled', stats.cancelled, 'mdi-calendar-remove-outline'],
        ];

        $('#tpStats').innerHTML = cards.map(([label, value, icon]) => `
            <div class="col-6 col-xl-2 col-md-4">
                <div class="tp-kpi">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="tp-kpi-icon ${label}"><i class="mdi ${icon} fs-4"></i></div>
                        <span class="small dashboard-label-${label}" >${label}</span>
                    </div>
                    <h3 class="mb-0">${esc(value ?? 0)}</h3>
                    <!-- <div class="small text-muted mt-1">Training planners</div> -->
                </div>
            </div>
        `).join('');
    }

    function renderPagination(currentPage, lastPage, total, perPage) {
        const paginationContainer = document.getElementById('pagination-container');

        if (!paginationContainer) return;

        currentPage = Number(currentPage) || 1;
        lastPage = Number(lastPage) || 1;
        total = Number(total) || 0;
        perPage = Number(perPage) || state.perPage;

        paginationContainer.innerHTML = '';

        if (total === 0) {
            paginationContainer.style.display = 'none';
            return;
        }

        paginationContainer.style.display = 'flex';
        paginationContainer.style.justifyContent = 'space-between';
        paginationContainer.style.alignItems = 'center';
        paginationContainer.style.width = '100%';

        const start = ((currentPage - 1) * perPage) + 1;
        const end = Math.min(currentPage * perPage, total);

        const showingInfo = `
            <div class="small text-muted">
                Showing ${start} to ${end} of ${total} results
            </div>
        `;

        const firstPage = 1;
        const previousPage = Math.max(1, currentPage - 1);
        const nextPage = Math.min(lastPage, currentPage + 1);
        const lastPageNumber = lastPage;

        const firstButton = `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <button
                    type="button"
                    class="page-link"
                    data-page="${firstPage}"
                    ${currentPage === 1 ? 'disabled' : ''}
                    title="First Page"
                >
                    «
                </button>
            </li>
        `;

        const previousButton = `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <button
                    type="button"
                    class="page-link"
                    data-page="${previousPage}"
                    ${currentPage === 1 ? 'disabled' : ''}
                    title="Previous"
                >
                    ‹
                </button>
            </li>
        `;

        const nextButton = `
            <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                <button
                    type="button"
                    class="page-link"
                    data-page="${nextPage}"
                    ${currentPage === lastPage ? 'disabled' : ''}
                    title="Next"
                >
                    ›
                </button>
            </li>
        `;

        const lastButton = `
            <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}">
                <button
                    type="button"
                    class="page-link"
                    data-page="${lastPageNumber}"
                    ${currentPage === lastPage ? 'disabled' : ''}
                    title="Last Page"
                >
                    »
                </button>
            </li>
        `;

        // Show 2 pages before and after current page
        const range = 2;

        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Keep 5 pages visible where possible
        if (currentPage <= range + 1) {
            endPage = Math.min(lastPage, 5);
        }

        if (currentPage >= lastPage - range) {
            startPage = Math.max(1, lastPage - 4);
        }

        let pageButtons = '';

        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `
                <li class="page-item ${i === currentPage ? 'active' : ''}">
                    <button
                        type="button"
                        class="page-link"
                        data-page="${i}"
                        ${i === currentPage ? 'aria-current="page"' : ''}
                    >
                        ${i}
                    </button>
                </li>
            `;
        }

        paginationContainer.innerHTML = `
            ${showingInfo}

            <nav aria-label="Training planner pagination">
                <ul class="pagination mb-0">
                    ${firstButton}
                    ${previousButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `;

        // Handle all pagination buttons through one event listener
        paginationContainer.querySelectorAll('[data-page]').forEach(button => {
            button.addEventListener('click', async function () {
                if (this.disabled) return;

                const page = Number(this.dataset.page);

                if (!page || page === state.page) return;

                state.page = page;

                await loadTable(page);
            });
        });

        // Keep your per-page dropdown synchronized
        const perPageElement = document.getElementById('perpage');

        if (perPageElement) {
            perPageElement.value = perPage;
        }
    }


   

    async function loadCalendar() {
        const year = state.month.getFullYear();
        const month = state.month.getMonth();
        const first = new Date(year, month, 1);
        const last = new Date(year, month + 1, 0);

        $('#tpCalTitle').textContent = state.month.toLocaleDateString(undefined, {
            month: 'long',
            year: 'numeric',
        });

        try {
            const response = await getJson(urls.data, {
                mode: 'calendar',
                start: toIsoDate(first),
                end: toIsoDate(last),
                search: $('#tpSearch').value.trim(),
                planner_status: $('#tpFilterStatus').value,
                training_mode: $('#tpFilterMode').value,
            });

            renderCalendar(response.data || []);
        } catch (error) {
            toast(error.message || 'Unable to load calendar.', 'error');
        }
    }

    function toIsoDate(date) {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    function calendarEventDates(training) {
        if (training.schedule_type === 'custom' && (training.custom_sessions || []).length) {
            return (training.custom_sessions || []).map(session => ({
                date: session.date,
                from_time: session.from_time,
                to_time: session.to_time,
            }));
        }

        const items = [];
        const start = new Date(`${training.from_date}T00:00:00`);
        const end = new Date(`${training.to_date}T00:00:00`);

        while (start <= end) {
            items.push({
                date: toIsoDate(start),
                from_time: training.from_time,
                to_time: training.to_time,
            });
            start.setDate(start.getDate() + 1);
        }

        return items;
    }

    function renderCalendar(trainings) {
        const year = state.month.getFullYear();
        const month = state.month.getMonth();
        const firstDay = new Date(year, month, 1);
        const totalDays = new Date(year, month + 1, 0).getDate();
        const offset = firstDay.getDay();
        const previousMonthDays = new Date(year, month, 0).getDate();
        const cells = [];

        for (let index = 0; index < 42; index += 1) {
            const day = index - offset + 1;
            let date;
            let isOther = false;

            if (day < 1) {
                date = new Date(year, month - 1, previousMonthDays + day);
                isOther = true;
            } else if (day > totalDays) {
                date = new Date(year, month + 1, day - totalDays);
                isOther = true;
            } else {
                date = new Date(year, month, day);
            }

            cells.push({ date, isOther });
        }

        let html = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
            .map(day => `<div class="tp-cal-week">${day}</div>`)
            .join('');

        cells.forEach(cell => {
            const key = toIsoDate(cell.date);
            const today = key === toIsoDate(new Date());
            const events = [];

            trainings.forEach(training => {
                calendarEventDates(training).forEach(session => {
                    if (session.date === key) {
                        events.push({ ...training, session });
                    }
                });
            });

            html += `
                <div class="tp-cal-day ${cell.isOther ? 'is-other' : ''} ${today ? 'is-today' : ''}">
                    <div class="tp-cal-num">${cell.date.getDate()}</div>
                    ${events.slice(0, 4).map(event => `
                        <button class="tp-event tp-event-${esc(event.planner_status)}" data-cal-id="${event.sno}">
                            ${esc(fmtTime(event.session.from_time))} · ${esc(event.training_planner_name)}
                        </button>
                    `).join('')}
                    ${events.length > 4 ? `<div class="small text-muted">+${events.length - 4} more</div>` : ''}
                </div>
            `;
        });

        $('#tpCalendarGrid').innerHTML = html;
    }

    function statusLabel(status) {
        return ({
            scheduled: 'Scheduled',
            rescheduled: 'Rescheduled',
            completed: 'Completed',
            cancelled: 'Cancelled',
        })[status] || 'Unknown';
    }

    function statusScheduleText(training) {
        if (!training) return '-';

        const dates = training.schedule_type === 'custom'
            ? (training.custom_sessions || []).length
            : null;

        if (dates !== null) {
            return `${dates} custom date(s) · ${formatTime12(training.from_time)} – ${formatTime12(training.to_time)}`;
        }

        if (!training.from_date || !training.to_date) return '-';
        const dateRange = training.from_date === training.to_date
            ? fmtDate(training.from_date)
            : `${fmtDate(training.from_date)} – ${fmtDate(training.to_date)}`;
        return `${dateRange} · ${formatTime12(training.from_time)} – ${formatTime12(training.to_time)}`;
    }

    function getStatusValue() {
        return document.querySelector('input[name="tpStatusValue"]:checked')?.value || '';
    }

    function getStatusScheduleType() {
        return document.querySelector('input[name="tpRsScheduleType"]:checked')?.value || 'range';
    }

    function getStatusCustomDates() {
        return (datePickers.rsCustomDates?.selectedDates || [])
            .map(date => datePickers.rsCustomDates.formatDate(date, 'Y-m-d'))
            .sort();
    }

    function renderStatusCustomDateBadges() {
        const dates = getStatusCustomDates();
        $('#tpRsCustomDateBadges').innerHTML = dates.length
            ? dates.map(date => `<span class="tp-pill tp-pill-blue">${esc(fmtDate(date))}</span>`).join('')
            : '<span class="small text-muted">No dates selected.</span>';
    }

    function populateStatusSchedule(training) {
        const type = training?.schedule_type === 'custom' && (training.custom_sessions || []).length ? 'custom' : 'range';
        const rangeRadio = document.querySelector('input[name="tpRsScheduleType"][value="range"]');
        const customRadio = document.querySelector('input[name="tpRsScheduleType"][value="custom"]');
        if (type === 'custom') customRadio.checked = true;
        else rangeRadio.checked = true;

        setDateValue(datePickers.rsFromDate, training?.from_date);
        setDateValue(datePickers.rsToDate, training?.to_date);
        setDateValue(datePickers.rsFromTime, formatTime12(training?.from_time));
        setDateValue(datePickers.rsToTime, formatTime12(training?.to_time));

        const customDates = (training?.custom_sessions || []).map(session => session.date).filter(Boolean);
        if (datePickers.rsCustomDates) {
            datePickers.rsCustomDates.setDate(customDates, false);
            renderStatusCustomDateBadges();
        }

        const firstCustom = training?.custom_sessions?.[0] || {};
        setDateValue(datePickers.rsFromTimeCustom, formatTime12(firstCustom.from_time || training?.from_time));
        setDateValue(datePickers.rsToTimeCustom, formatTime12(firstCustom.to_time || training?.to_time));
        toggleStatusScheduleFields();
    }

    function toggleStatusScheduleFields() {
        const type = getStatusScheduleType();
        $('#tpRsRangeFields').classList.toggle('d-none', type !== 'range');
        $('#tpRsCustomFields').classList.toggle('d-none', type !== 'custom');

        if (type === 'custom') {
            renderStatusCustomDateBadges();
        }
    }

    function toggleStatusFields() {
        const value = getStatusValue();
        const rescheduled = value === 'rescheduled';
        const cancelled = value === 'cancelled';

        $('#tpRescheduleFields').classList.toggle('d-none', !rescheduled);
        $('#tpStatusReasonLabel').innerHTML = cancelled
            ? 'Cancellation reason <span class="text-danger">*</span>'
            : 'Reason';
        $('#tpStatusReason').placeholder = cancelled
            ? 'Explain why this training is being cancelled…'
            : rescheduled
                ? 'Explain why the training is being rescheduled…'
                : 'Add an optional reason for this status change';
        $('#tpStatusReasonHelp').textContent = cancelled
            ? 'A cancellation reason is required for audit/history.'
            : rescheduled
                ? 'The reason is optional, but recommended for scheduling history.'
                : 'A short reason helps other HR users understand why the status was changed.';

        if (cancelled) {
            $('#tpStatusTransitionNote').className = 'tp-status-note warning mb-3';
            $('#tpStatusTransitionNote').innerHTML = '<i class="mdi mdi-alert-outline me-1"></i>This will cancel the training. Existing attendees remain linked to the planner, but future edits to the training are locked until it is restored.';
        } else if (rescheduled) {
            $('#tpStatusTransitionNote').className = 'tp-status-note info mb-3';
            $('#tpStatusTransitionNote').innerHTML = '<i class="mdi mdi-information-outline me-1"></i>The trainer and attendees stay unchanged. The new schedule is checked for conflicts before saving.';
        } else {
            $('#tpStatusTransitionNote').className = 'tp-status-note info mb-3';
            $('#tpStatusTransitionNote').innerHTML = '<i class="mdi mdi-information-outline me-1"></i>The training will remain active on its current schedule.';
        }

        $('#tpStatusSave').classList.toggle('btn-danger', cancelled);
        $('#tpStatusSave').classList.toggle('btn-primary', !cancelled);
        $('#tpStatusSave span').textContent = cancelled ? 'Cancel Training' : (rescheduled ? 'Reschedule Training' : 'Update Status');

        if (!rescheduled) {
            $('#tpErrRsDates').textContent = '';
        }
    }

    async function openStatus(training) {
        if (!training) return;

        if (training.planner_status === 'completed') {
            toast('Completed training status cannot be changed.', 'info');
            return;
        }

        statusTraining = training;
        $('#tpStatusId').value = training.sno;
        $('#tpStatusTrainingName').textContent = `${training.training_planner_id} · ${training.training_planner_name}`;
        $('#tpStatusCurrentValue').textContent = statusLabel(training.planner_status);
        $('#tpStatusCurrentSchedule').textContent = statusScheduleText(training);
        $('#tpStatusReason').value = '';
        $('#tpErrStatusReason').textContent = '';
        $('#tpErrRsDates').textContent = '';

        const next = training.planner_status === 'cancelled' ? 'scheduled' : 'scheduled';
        document.querySelectorAll('input[name="tpStatusValue"]').forEach(input => {
            input.checked = input.value === next;
        });

        populateStatusSchedule(training);
        toggleStatusFields();
        statusModal.show();
    }

    async function saveTraining() {
        const payload = collectPlanner();

        if (!validatePlanner(payload)) return;

        const isEdit = Boolean($('#tpId').value);
        $('#tpSaveBtn').disabled = true;
        $('#tpSaveBtn').innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Checking & saving…';

        try {
            const response = await postJson(
                isEdit ? urls.update($('#tpId').value) : urls.store,
                isEdit ? 'PUT' : 'POST',
                payload,
            );

            toast(response.message || 'Training saved successfully.');
            plannerModal.hide();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            renderConflicts(error);
            toast(error.message || 'Unable to save training.', 'error');
        } finally {
            $('#tpSaveBtn').disabled = false;
            $('#tpSaveBtn').innerHTML = '<i class="mdi mdi-content-save-outline me-1"></i><span>Save Training</span>';
        }
    }

    async function saveStatus() {
        const id = $('#tpStatusId').value;
        const plannerStatus = getStatusValue();
        const reason = $('#tpStatusReason').value.trim();

        $('#tpErrStatusReason').textContent = '';
        $('#tpErrRsDates').textContent = '';

        if (!plannerStatus) {
            toast('Please select a new training status.', 'error');
            return;
        }

        if (plannerStatus === 'cancelled' && !reason) {
            $('#tpErrStatusReason').textContent = 'Cancellation reason is required.';
            $('#tpStatusReason').focus();
            return;
        }

        const body = {
            planner_status: plannerStatus,
            reason,
        };

        if (plannerStatus === 'rescheduled') {
            const scheduleType = getStatusScheduleType();
            const fromTimePicker = scheduleType === 'custom' ? datePickers.rsFromTimeCustom : datePickers.rsFromTime;
            const toTimePicker = scheduleType === 'custom' ? datePickers.rsToTimeCustom : datePickers.rsToTime;
            const fromTime = normalizeTimeTo24(fromTimePicker?.input?.value || '');
            const toTime = normalizeTimeTo24(toTimePicker?.input?.value || '');

            body.schedule_type = scheduleType;
            body.from_time = fromTime;
            body.to_time = toTime;

            if (scheduleType === 'custom') {
                const dates = getStatusCustomDates();
                if (!dates.length) {
                    $('#tpErrRsDates').textContent = 'Select at least one rescheduled training date.';
                    return;
                }
                body.custom_dates = dates;
                body.from_date = dates[0];
                body.to_date = dates[dates.length - 1];
            } else {
                body.custom_dates = [];
                body.from_date = datePickers.rsFromDate?.input?.value || '';
                body.to_date = datePickers.rsToDate?.input?.value || '';
            }

            if (!body.from_time || !body.to_time) {
                toast('Start time and end time are required for rescheduling.', 'error');
                return;
            }
        }

        $('#tpStatusSave').disabled = true;
        $('#tpStatusSave').querySelector('i').className = 'spinner-border spinner-border-sm me-1';

        try {
            const response = await postJson(urls.status(id), 'POST', body);
            toast(response.message || 'Training status updated.');
            statusTraining = null;
            statusModal.hide();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            renderConflicts(error);
            toast(error.message || 'Unable to update status.', 'error');
        } finally {
            $('#tpStatusSave').disabled = false;
            $('#tpStatusSave').querySelector('i').className = 'mdi mdi-check-circle-outline me-1';
            toggleStatusFields();
        }
    }

    function normaliseClientAttendanceStatus(status) {
        const value = String(status ?? '').trim().toLowerCase();
        if (['1', 'present', 'p', 'true'].includes(value)) return 1;
        if (['0', 'absent', 'a', 'false'].includes(value)) return 0;
        return null;
    }

    function updateAttendanceModalStats() {
        const rows = $$('#tpCompleteAttendees .tp-attendance-row');
        const total = rows.length;
        let present = 0;
        let absent = 0;
        let pending = 0;

        rows.forEach(row => {
            const status = normaliseClientAttendanceStatus(row.querySelector('.tp-att-status')?.value);
            if (status === 1) present++;
            else if (status === 0) absent++;
            else pending++;
        });

        const marked = present + absent;
        const percent = total > 0 ? Math.round((marked / total) * 100) : 0;
        const cards = [
            ['Assigned', total, 'mdi-account-group-outline', 'primary'],
            ['Present', present, 'mdi-account-check-outline', 'success'],
            ['Absent', absent, 'mdi-account-remove-outline', 'danger'],
            ['Pending', pending, 'mdi-clock-outline', 'secondary'],
        ];

        $('#tpCompleteAttendanceStats').innerHTML = cards.map(([label, value, icon, tone]) => `
            <div class="tp-attendance-stat-card">
                <div class="d-flex align-items-center justify-content-between gap-2">
                    <span class="label">${esc(label)}</span>
                    <span class="text-${tone}"><i class="mdi ${icon}"></i></span>
                </div>
                <div class="value text-${tone}">${esc(value)}</div>
            </div>
        `).join('');

        $('#tpCompleteAttendanceProgress').style.width = `${percent}%`;
        $('#tpCompleteAttendancePercent').textContent = `${percent}%`;
        $('#tpCompleteAttendeeSub').textContent = `${present} present · ${absent} absent · ${pending} pending`;

        const isAttendanceOnly = state.attendanceMode === 'attendance';
        const completeButton = $('#tpCompleteSave');
        if (completeButton) {
            completeButton.disabled = !isAttendanceOnly && (total === 0 || pending > 0);
            completeButton.title = !isAttendanceOnly && pending > 0
                ? `Mark ${pending} pending attendee${pending === 1 ? '' : 's'} before completing the training.`
                : '';
        }
        const hint = $('#tpCompleteWorkflowHint');
        if (hint) {
            hint.className = `tp-completion-hint mt-3 ${pending === 0 ? 'success' : ''}`;
            hint.innerHTML = pending === 0
                ? '<i class="mdi mdi-check-decagram-outline me-1"></i>Saved attendance will be used for completion. No need to mark the same attendance again.'
                : `<i class="mdi mdi-information-outline me-1"></i>${pending} attendee${pending === 1 ? '' : 's'} still need${pending === 1 ? 's' : ''} an attendance outcome before final completion.`;
        }
    }

    async function openAttendanceModal(id, mode = 'attendance') {
        state.attendanceMode = mode;

        try {
            const response = await getJson(urls.show(id));
            const training = response.data;
            state.currentTraining = training;

            const isAttendanceOnly = mode === 'attendance';
            $('#tpAttendanceModalTitle').textContent = isAttendanceOnly ? 'Training Attendance' : 'Complete Training';
            $('#tpCompleteSaveText').textContent = isAttendanceOnly ? 'Save Attendance' : 'Complete Training';
            $('#tpCompleteSave').classList.toggle('btn-primary', isAttendanceOnly);
            $('#tpCompleteSave').classList.toggle('btn-success', !isAttendanceOnly);
            $('#tpCompleteId').value = training.sno;

            $('#tpAttendanceWorkflowBadge').innerHTML = isAttendanceOnly
                ? '<i class="mdi mdi-clipboard-check-outline"></i>Training attendance'
                : '<i class="mdi mdi-check-decagram-outline"></i>Final completion';
            $('#tpAttendanceCompletionBadge').classList.toggle('d-none', isAttendanceOnly);
            $('#tpAttendanceWorkflowTitle').textContent = isAttendanceOnly
                ? 'Mark training participation without changing outcome points.'
                : 'Finalize attendance, attendee scores and training outcomes.';
            $('#tpAttendanceWorkflowNote').textContent = isAttendanceOnly
                ? 'This action stores training attendance only. It never updates daily HR attendance and never changes points.'
                : 'Completion is the only workflow that commits attendee/trainer points, assessments, certificates and training history.';
            $('#tpCompleteFooterNote').textContent = isAttendanceOnly
                ? 'Attendance only · points remain locked until completion.'
                : 'Final completion · previously saved attendance is reused; only final outcomes are committed here.';
            $('#tpCompleteTrainerScoreWrap').classList.toggle('d-none', isAttendanceOnly);
            $('#tpCompleteTrainerScore').value = training.trainer_score ?? '';

            $('#tpCompleteInfo').innerHTML = [
                ['Training', training.training_planner_name || '-'],
                ['Trainer', training.trainer_name || 'External Trainer'],
                ['Mode', training.training_mode_label || '-'],
                ['Schedule', training.schedule_type === 'custom'
                    ? `${training.custom_sessions?.length || 0} custom date(s)`
                    : `${fmtDate(training.from_date)} – ${fmtDate(training.to_date)}`],
            ].map(item => `<div class="tp-info"><small>${esc(item[0])}</small><strong>${esc(item[1])}</strong></div>`).join('');

            $('#tpCompleteAttendeeHeaderTitle').textContent = isAttendanceOnly ? 'Training Attendance' : 'Attendance & Final Outcomes';
            $('#tpCompleteAttendeeHeaderNote').textContent = isAttendanceOnly
                ? 'Present / Absent · points locked'
                : 'Saved attendance · final score / assessment / certificate';

            $('#tpCompleteAttendees').innerHTML = (training.attendees || []).map(attendee => {
                const status = normaliseClientAttendanceStatus(attendee.attendance_status);
                const attendanceValue = status === null ? '' : String(status);
                const score = attendee.attendee_score ?? training.attendee_score_default;

                const finalOutcome = isAttendanceOnly
                    ? `<div class="d-flex flex-wrap gap-1">
                            ${training.assessment_required
                                ? `<span class="tp-pill ${attendee.assessment_status === 1 ? 'tp-pill-green' : attendee.assessment_status === 0 ? 'tp-pill-red' : 'tp-pill-gray'}">${attendee.assessment_status === 1 ? 'Passed' : attendee.assessment_status === 0 ? 'Failed' : 'Assessment pending'}</span>`
                                : '<span class="tp-pill tp-pill-gray">No assessment</span>'}
                            ${training.certificate_available
                                ? `<span class="tp-pill ${attendee.certificate_issued ? 'tp-pill-blue' : 'tp-pill-gray'}">${attendee.certificate_issued ? 'Certificate issued' : 'Certificate pending'}</span>`
                                : ''}
                       </div>`
                    : `<div class="d-flex flex-wrap gap-1 align-items-center">
                            ${training.assessment_required ? `<select class="select3 form-select form-select-sm tp-assess-status" style="width:120px">
                                <option value="" ${attendee.assessment_status == null ? 'selected' : ''}>Assessment</option>
                                <option value="1" ${attendee.assessment_status === 1 ? 'selected' : ''}>Passed</option>
                                <option value="0" ${attendee.assessment_status === 0 ? 'selected' : ''}>Failed</option>
                            </select>
                            <input class="form-control form-control-sm tp-assess-score" type="number" min="0" max="100" step="0.01" value="${esc(attendee.assessment_score ?? '')}" placeholder="Assess pts" style="width:105px">` : ''}
                            ${training.certificate_available ? `<div class="form-check ms-1"><input class="form-check-input tp-cert-check" type="checkbox" ${attendee.certificate_issued ? 'checked' : ''}><label class="form-check-label small">Cert.</label></div>` : ''}
                       </div>`;

                const attendanceLocked = !isAttendanceOnly && status !== null;
                return `<div class="tp-attendance-row" data-staff="${esc(attendee.staff_id)}">
                    <div class="tp-attendance-person">
                        <div class="tp-staff-avatar">
                            ${attendee.attendee_image_url ? `<img src="${esc(attendee.attendee_image_url)}" alt="${esc(attendee.staff_name)}" loading="lazy">` : esc(initials(attendee.staff_name))}
                        </div>
                        <div class="min-w-0">
                            <div class="name">${esc(attendee.staff_name)}</div>
                            <div class="meta">Staff ID: ${esc(attendee.staff_id)}</div>
                        </div>
                    </div>

                    <div class="tp-attendance-status-select">
                        <select class="select3 form-select form-select-sm tp-att-status" ${attendanceLocked ? 'disabled' : ''} title="${attendanceLocked ? 'Attendance already saved; update it from Training Attendance if needed.' : 'Select attendance'}">
                            <option value="" ${attendanceValue === '' ? 'selected' : ''}>Pending</option>
                            <option value="1" ${attendanceValue === '1' ? 'selected' : ''}>Present</option>
                            <option value="0" ${attendanceValue === '0' ? 'selected' : ''}>Absent</option>
                        </select>
                    </div>

                    <div class="tp-score-column">
                        ${isAttendanceOnly
                            ? `<div class="tp-readonly-score">${score !== null && score !== undefined ? `${esc(score)} Pts` : 'Locked'}</div>`
                            : `<input class="form-control form-control-sm tp-attendee-score" type="number" min="0" max="100" step="0.01" value="${esc(attendee.attendee_score ?? training.attendee_score_default ?? '')}" placeholder="Score Pts">`}
                    </div>

                    <div class="tp-outcome-column">${finalOutcome}</div>
                </div>`;
            }).join('') || '<div class="tp-empty">No attendees are assigned to this training.</div>';

            $$('#tpCompleteAttendees .tp-att-status').forEach(select => select.addEventListener('change', updateAttendanceModalStats));
            updateAttendanceModalStats();
            completeModal.show();
        } catch (error) {
            toast(error.message || 'Unable to load training attendance.', 'error');
        }
    }


    async function openAttendance(id) {
        await openAttendanceModal(id, 'attendance');
    }

    async function openComplete(id) {
        await openAttendanceModal(id, 'complete');
    }


    async function openStaffTrainingHistory(staffId, staffName) {
        $('#tpStaffHistorySub').textContent = `${staffName} · Training history`;
        $('#tpStaffHistoryBody').innerHTML = `
            <tr>
                <td colspan="8">
                    <div class="tp-loader"><span class="spinner-border spinner-border-sm me-1"></span>Loading training history…</div>
                </td>
            </tr>
        `;
        $('#tpStaffHistoryCount').textContent = '';
        $('#tpStaffHistoryPagination').innerHTML = '';
        staffTrainingHistoryModal.show();

        try {
            const response = await getJson(urls.staffTrainingLogs(staffId), { per_page: 25 });
            const page = response.data || {};
            const rows = page.data || [];

            $('#tpStaffHistoryBody').innerHTML = rows.length
                ? rows.map(log => `
                    <tr>
                        <td class="text-nowrap fw-semibold">${esc(fmtDate(log.training_date))}</td>
                        <td>
                            <div class="fw-semibold">${esc(log.training_name || '-')}</div>
                            <div class="small text-muted">${esc(log.training_planner_code || '-')}</div>
                        </td>
                        <td>${esc(log.trainer_name || '-')}</td>
                        <td>
                            <span class="tp-pill ${log.attendance_status === 1 ? 'tp-pill-green' : log.attendance_status === 0 ? 'tp-pill-red' : 'tp-pill-gray'}">
                                ${log.attendance_status === 1 ? 'Present' : log.attendance_status === 0 ? 'Absent' : 'Pending'}
                            </span>
                        </td>
                        <td class="text-end fw-semibold">${log.attendee_score !== null && log.attendee_score !== undefined ? `${esc(log.attendee_score)} Pts` : '-'}</td>
                        <td class="text-end fw-semibold">${log.trainer_score !== null && log.trainer_score !== undefined ? `${esc(log.trainer_score)} Pts` : '-'}</td>
                        <td>
                            ${log.assessment_status === 1 ? '<span class="tp-pill tp-pill-green">Passed</span>' : log.assessment_status === 0 ? '<span class="tp-pill tp-pill-red">Failed</span>' : '<span class="tp-pill tp-pill-gray">Not attempted</span>'}
                        </td>
                        <td>
                            ${log.certificate_issued ? '<span class="tp-pill tp-pill-blue">Issued</span>' : '<span class="tp-pill tp-pill-gray">No</span>'}
                        </td>
                    </tr>
                `).join('')
                : '<tr><td colspan="8"><div class="tp-empty">No completed training history found for this staff member.</div></td></tr>';

            $('#tpStaffHistoryCount').textContent = `${page.total || rows.length} record(s)`;
        } catch (error) {
            $('#tpStaffHistoryBody').innerHTML = `<tr><td colspan="8"><div class="tp-empty text-danger">${esc(error.message || 'Unable to load staff training history.')}</div></td></tr>`;
            toast(error.message || 'Unable to load staff training history.', 'error');
        }
    }

    async function saveComplete() {
        const id = $('#tpCompleteId').value;
        const isAttendanceOnly = state.attendanceMode === 'attendance';
        const rows = $$('#tpCompleteAttendees .tp-attendance-row');

        if (!isAttendanceOnly && rows.some(row => row.querySelector('.tp-att-status')?.value === '')) {
            toast('Mark Present or Absent for every attendee before completing the training.', 'error');
            return;
        }

        const attendance = rows.map(row => {
            const rawStatus = row.querySelector('.tp-att-status')?.value ?? '';
            const item = {
                staff_id: Number(row.dataset.staff),
                attendance_status: rawStatus === '' ? null : Number(rawStatus),
            };

            // Scores/outcomes are intentionally sent only from the final completion mode.
            if (!isAttendanceOnly) {
                const certificate = row.querySelector('.tp-cert-check');
                const assessmentStatus = row.querySelector('.tp-assess-status');
                const assessmentScore = row.querySelector('.tp-assess-score');
                const attendeeScore = row.querySelector('.tp-attendee-score');

                if (attendeeScore && attendeeScore.value !== '') item.attendee_score = Number(attendeeScore.value);
                if (certificate) item.certificate_issued = certificate.checked ? 1 : 0;
                if (assessmentStatus) item.assessment_status = assessmentStatus.value === '' ? null : Number(assessmentStatus.value);
                if (assessmentScore && assessmentScore.value !== '') item.assessment_score = Number(assessmentScore.value);
            }

            return item;
        });

        const invalidScore = attendance.find(item => item.attendee_score !== undefined && (item.attendee_score < 0 || item.attendee_score > 100));
        if (invalidScore) {
            toast('Attendee score must be between 0 and 100.', 'error');
            return;
        }

        const trainerScoreValue = $('#tpCompleteTrainerScore').value;
        if (!isAttendanceOnly && trainerScoreValue !== '' && (Number(trainerScoreValue) < 0 || Number(trainerScoreValue) > 100)) {
            toast('Trainer score must be between 0 and 100.', 'error');
            return;
        }

        const button = $('#tpCompleteSave');
        button.disabled = true;
        try {
            const body = { attendance };
            if (!isAttendanceOnly && trainerScoreValue !== '') {
                body.trainer_score = Number(trainerScoreValue);
            }

            const endpoint = isAttendanceOnly ? urls.attendance(id) : urls.complete(id);
            const response = await postJson(endpoint, 'POST', body);
            toast(response.message || (isAttendanceOnly ? 'Training attendance saved successfully.' : 'Training completed successfully.'));
            completeModal.hide();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            toast(error.message || (isAttendanceOnly ? 'Unable to save training attendance.' : 'Unable to complete training.'), 'error');
        } finally {
            button.disabled = false;
        }
    }


    /* ------------------------------------------------------------------
       Advanced attendee/session management
       ------------------------------------------------------------------ */
    const tpFeature = {
        trainingId: null,
        sessions: [],
        attendees: [],
    };

    function tpFeatureGet(url, params = {}) {
        const qs = new URLSearchParams();
        Object.entries(params).forEach(([key, value]) => {
            if (value === null || value === undefined || value === '') return;
            if (Array.isArray(value)) value.forEach(item => qs.append(`${key}[]`, item));
            else qs.append(key, value);
        });
        return fetch(`${url}${qs.toString() ? `?${qs.toString()}` : ''}`, {
            headers: { Accept: 'application/json' },
        }).then(async response => {
            const data = await response.json().catch(() => ({ message: 'Invalid server response.' }));
            if (!response.ok) throw data;
            return data;
        });
    }

    function tpFeaturePost(url, method, body) {
        return fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
                Accept: 'application/json',
                'X-CSRF-TOKEN': csrf,
            },
            body: JSON.stringify(body),
        }).then(async response => {
            const data = await response.json().catch(() => ({ message: 'Invalid server response.' }));
            if (!response.ok) throw data;
            return data;
        });
    }

    function trainingScheduleParams(training) {
        const custom = training.schedule_type === 'custom' && (training.custom_sessions || []).length;
        return {
            company_ids: training.company_ids || [],
            entity_ids: training.entity_ids || [],
            branch_ids: training.branch_ids || [],
            schedule_type: custom ? 'custom' : 'range',
            custom_dates: custom ? training.custom_sessions.map(s => s.date) : [],
            from_date: training.from_date,
            to_date: training.to_date,
            from_time: training.from_time,
            to_time: training.to_time,
            selected_trainer: training.trainer || 0,
            exclude_training_id: training.sno,
        };
    }

    async function openAttendeeManager(id) {
        try {
            const response = await tpFeatureGet(`${baseUrl}/${id}`);
            const training = response.data;
            tpFeature.trainingId = id;
            $('#tpAttendeeTrainingName').textContent = `${training.training_planner_id} · ${training.training_planner_name}`;
            $('#tpAssignedList').innerHTML = '<div class="tp-loader"><span class="spinner-border spinner-border-sm"></span>Loading assigned attendees…</div>';
            $('#tpAvailableList').innerHTML = '<div class="tp-loader"><span class="spinner-border spinner-border-sm"></span>Checking availability…</div>';
            window.tpAttendeeModal.show();

            const [assignedResponse, staffResponse] = await Promise.all([
                tpFeatureGet(`${baseUrl}/${id}/attendees`),
                tpFeatureGet(`${baseUrl}/staff`, trainingScheduleParams(training)),
            ]);

            tpFeature.attendees = assignedResponse.data?.assigned || [];
            const assignedIds = new Set((assignedResponse.data?.assigned_ids || []).map(Number));
            const available = (staffResponse.data || []).filter(person => !assignedIds.has(Number(person.sno)) && Number(person.sno) !== Number(training.trainer));

            renderAssignedAttendees();
            renderAvailableAttendees(available);
            $('#tpAssignedCount').textContent = String(tpFeature.attendees.length);
        } catch (error) {
            window.tpAttendeeModal.hide();
            toast(error.message || 'Unable to load attendee management.', 'error');
        }
    }

    function renderAssignedAttendees() {
        const q = $('#tpAssignedSearch').value.toLowerCase().trim();
        const list = tpFeature.attendees.filter(person =>
            !q || `${person.staff_name} ${person.staff_id}`.toLowerCase().includes(q)
        );
        $('#tpAssignedList').innerHTML = list.length ? list.map(person => `
            <div class="tp-feature-row d-flex align-items-center gap-2" data-name="${esc(person.staff_name)}">
                <div class="tp-avatar">
                ${person.staff_image_url ? 
                        `<img src="${person.staff_image_url}" 
                                                alt="user-avatar"  
                                                class="rounded-circle"
                                                style="width:40px; height:40px; object-fit:fill;"/>` : `${esc(initials(person.staff_name))}`}
               
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">${esc(person.staff_name)}</div>
                    <!-- <div class="tp-feature-meta">Staff ID: ${esc(person.staff_id)}</div> -->
                </div>
                <button type="button" class="btn btn-sm btn-outline-danger tp-action-btn" data-attendee-remove="${person.staff_id}" title="Remove attendee"><i class="mdi mdi-account-minus-outline"></i></button>
            </div>
        `).join('') : '<div class="tp-empty">No assigned attendees.</div>';
    }

    function renderAvailableAttendees(list) {
        const assigned = new Set(tpFeature.attendees.map(person => Number(person.staff_id)));
        const q = $('#tpAvailableSearch').value.toLowerCase().trim();
        const filtered = list.filter(person => {
            if (assigned.has(Number(person.sno))) return false;
            return !q || `${person.staff_name} ${person.department_name || ''} ${person.job_role_name || ''}`.toLowerCase().includes(q);
        });
        $('#tpAvailableList').dataset.all = JSON.stringify(list);
        $('#tpAvailableList').innerHTML = filtered.length ? filtered.map(person => `
            <label class="tp-feature-row d-flex align-items-center gap-2">
                <input class="form-check-input tp-new-attendee-check" type="checkbox" value="${person.sno}">
                <div class="tp-avatar">
                ${person.staff_image_url ? 
                        `<img src="${person.staff_image_url}" 
                                                alt="user-avatar"  
                                                class="rounded-circle"
                                                style="width:40px; height:40px; object-fit:fill;"/>` : `${esc(initials(person.staff_name))}`}
               
                </div>
                <div class="flex-grow-1">
                    <div class="fw-semibold">${esc(person.staff_name)}</div>
                    <div class="tp-feature-meta">${esc(person.department_name || '-')} · ${esc(person.job_role_name || '-')}</div>
                </div>
                <span class="tp-ok-badge">Available</span>
            </label>
        `).join('') : '<div class="tp-empty">No additional available staff found.</div>';
        updateNewAttendeeCount();
    }

    function updateNewAttendeeCount() {
        $('#tpNewAttendeeCount').textContent = String($$('#tpAvailableList .tp-new-attendee-check:checked').length);
    }

    async function saveNewAttendees() {
        const ids = $$('#tpAvailableList .tp-new-attendee-check:checked').map(input => Number(input.value));
        if (!ids.length) {
            toast('Select at least one attendee.', 'error');
            return;
        }
        $('#tpAddAttendeeSave').disabled = true;
        try {
            const response = await tpFeaturePost(`${baseUrl}/${tpFeature.trainingId}/attendees`, 'POST', { staff_ids: ids });
            toast(response.message || 'Attendees added successfully.');
            window.tpAttendeeModal.hide();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            if (error.conflicts) renderConflicts(error);
            toast(error.message || 'Unable to add attendees.', 'error');
        } finally {
            $('#tpAddAttendeeSave').disabled = false;
        }
    }

    function removeAssignedAttendee(staffId) {
        const person = tpFeature.attendees.find(item => Number(item.staff_id) === Number(staffId));
        $('#tpRemoveAttendeeId').value = staffId;
        $('#tpRemoveAttendeeMessage').textContent = person
            ? `${person.staff_name} will be removed from the training. Attendance already recorded for this attendee cannot be removed.`
            : 'The attendee will be removed from the training.';
        window.tpRemoveAttendeeModal.show();
    }

    async function confirmRemoveAssignedAttendee() {
        const staffId = $('#tpRemoveAttendeeId').value;
        const trainingId = tpFeature.trainingId;
        $('#tpRemoveAttendeeConfirm').disabled = true;
        try {
            const response = await fetch(`${baseUrl}/${trainingId}/attendees/${staffId}`, {
                method: 'DELETE',
                headers: { Accept: 'application/json', 'X-CSRF-TOKEN': csrf },
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw data;
            window.tpRemoveAttendeeModal.hide();
            toast(data.message || 'Attendee removed successfully.');
            await openAttendeeManager(trainingId);
            await loadTable();
        } catch (error) {
            toast(error.message || 'Unable to remove attendee.', 'error');
        } finally {
            $('#tpRemoveAttendeeConfirm').disabled = false;
        }
    }

    async function openSessionManager(id) {
        try {
            const response = await tpFeatureGet(`${baseUrl}/${id}/sessions`);
            const data = response.data || {};
            const training = data.training || {};
            tpFeature.trainingId = id;
            tpFeature.sessions = data.sessions || [];
            $('#tpSessionsTrainingName').textContent = `${training.training_planner_id || ''} · ${training.training_planner_name || ''}`;
            renderSessionManager();
            window.tpSessionsModal.show();
        } catch (error) {
            toast(error.message || 'Unable to load sessions.', 'error');
        }
    }

    function sessionStatusBadge(status) {
        const labels = { scheduled: 'Scheduled', in_progress: 'In progress', completed: 'Completed', cancelled: 'Cancelled' };
        const map = { scheduled: 'gray', in_progress: 'blue', completed: 'green', cancelled: 'red' };
        return `<span class="tp-pill tp-pill-${map[status] || 'gray'}">${esc(labels[status] || status || 'Scheduled')}</span>`;
    }

    function renderSessionManager() {
        const sessions = tpFeature.sessions;
        const completed = sessions.filter(s => s.session_status === 'completed' && s.syllabus_completed).length;
        $('#tpSessionsCount').textContent = `${sessions.length} session${sessions.length === 1 ? '' : 's'}`;
        $('#tpSessionsProgress').textContent = sessions.length ? `${completed}/${sessions.length} session${completed === 1 ? '' : 's'} fully completed` : 'No sessions available';
        $('#tpSessionList').innerHTML = sessions.length ? sessions.map(session => `
            <div class="tp-session-card ${session.session_status === 'completed' ? 'is-completed' : session.session_status === 'in_progress' ? 'is-progress' : session.session_status === 'cancelled' ? 'is-cancelled' : ''}">
                <div class="d-flex align-items-start gap-3">
                    <div class="tp-session-date"><strong>${esc(new Date(`${session.session_date}T00:00:00`).getDate())}</strong><span>${esc(new Date(`${session.session_date}T00:00:00`).toLocaleDateString(undefined,{month:'short'}))}</span></div>
                    <div class="flex-grow-1">
                        <div class="d-flex flex-wrap align-items-center gap-2 mb-1"><strong>Session ${esc(session.session_no)} · ${esc(session.session_title || 'Training Session')}</strong>${sessionStatusBadge(session.session_status)}${session.syllabus_completed ? '<span class="tp-pill tp-pill-green">Syllabus completed</span>' : '<span class="tp-pill tp-pill-gray">Syllabus pending</span>'}</div>
                        <div class="small text-muted mb-2"><i class="mdi mdi-clock-outline me-1"></i>${esc(formatTime12(session.start_time))} – ${esc(formatTime12(session.end_time))}</div>
                        <div class="small text-muted mb-2">${esc(session.syllabus_details || 'No syllabus details recorded yet.')}</div>
                        <div class="d-flex flex-wrap gap-2"><span class="badge bg-light text-dark">Attendance: ${esc(session.attendance_marked || 0)}/${esc(session.attendance_total || 0)}</span><span class="badge bg-success-subtle text-success">Present ${esc(session.attendance_present || 0)}</span><span class="badge bg-danger-subtle text-danger">Absent ${esc(session.attendance_absent || 0)}</span></div>
                    </div>
                    <div class="d-flex flex-column gap-1"><button type="button" class="btn btn-sm btn-outline-primary tp-session-edit-action" data-session-id="${session.sno}"><i class="mdi mdi-pencil-outline me-1"></i>Syllabus</button><button type="button" class="btn btn-sm btn-outline-secondary tp-session-attendance-action" data-session-id="${session.sno}"><i class="mdi mdi-clipboard-account-outline me-1"></i>Attendance</button></div>
                </div>
            </div>
        `).join('') : '<div class="tp-empty">No training sessions have been generated.</div>';
    }

    async function openSessionEditor(sessionId) {
        const session = tpFeature.sessions.find(item => Number(item.sno) === Number(sessionId));
        if (!session) return;
        $('#tpSessionEditTrainingId').value = tpFeature.trainingId;
        $('#tpSessionEditId').value = session.sno;
        $('#tpSessionEditSub').textContent = `Session ${session.session_no} · ${fmtDate(session.session_date)}`;
        $('#tpSessionEditInfo').innerHTML = [
            ['Date', fmtDate(session.session_date)],
            ['Time', `${formatTime12(session.start_time)} – ${formatTime12(session.end_time)}`],
            ['Attendance', `${session.attendance_marked || 0}/${session.attendance_total || 0} marked`],
            ['Status', session.session_status || 'scheduled'],
        ].map(item => `<div class="tp-info"><small>${esc(item[0])}</small><strong>${esc(item[1])}</strong></div>`).join('');
        $('#tpSessionTitle').value = session.session_title || '';
        $('#tpSessionSyllabus').value = session.syllabus_details || '';
        $('#tpSessionTrainerNotes').value = session.trainer_notes || '';
        $('#tpSessionStatus').value = session.session_status || 'scheduled';
        $('#tpSessionSyllabusCompleted').checked = Boolean(session.syllabus_completed);
        $('#tpSessionEditError').classList.add('d-none');
        window.tpSessionEditModal.show();
    }

    async function saveSessionEditor() {
        const trainingId = $('#tpSessionEditTrainingId').value;
        const sessionId = $('#tpSessionEditId').value;
        const body = {
            session_title: $('#tpSessionTitle').value.trim() || null,
            syllabus_details: $('#tpSessionSyllabus').value.trim() || null,
            trainer_notes: $('#tpSessionTrainerNotes').value.trim() || null,
            session_status: $('#tpSessionStatus').value,
            syllabus_completed: $('#tpSessionSyllabusCompleted').checked ? 1 : 0,
        };
        $('#tpSessionEditSave').disabled = true;
        try {
            await tpFeaturePost(`${baseUrl}/${trainingId}/sessions/${sessionId}`, 'PUT', body);
            toast('Session and syllabus updated successfully.');
            window.tpSessionEditModal.hide();
            await openSessionManager(trainingId);
            await loadTable();
            await loadCalendar();
        } catch (error) {
            $('#tpSessionEditError').textContent = error.message || 'Unable to update session.';
            $('#tpSessionEditError').classList.remove('d-none');
        } finally {
            $('#tpSessionEditSave').disabled = false;
        }
    }

    function sessionAttendanceChoiceHtml(status) {
        const normalized = normaliseClientAttendanceStatus(status);
        return `<div class="tp-attendance-choice">
            <button type="button" data-session-status="1" class="${normalized === 1 ? 'is-present' : ''}"><i class="mdi mdi-check-circle-outline me-1"></i>Present</button>
            <button type="button" data-session-status="0" class="${normalized === 0 ? 'is-absent' : ''}"><i class="mdi mdi-close-circle-outline me-1"></i>Absent</button>
            <button type="button" data-session-status="" class="${normalized === null ? 'is-pending' : ''}"><i class="mdi mdi-clock-outline me-1"></i>Pending</button>
        </div>`;
    }

    function updateSessionAttendanceUi() {
        const rows = $$('#tpSessionAttendanceList [data-session-staff]');
        const total = rows.length;
        let present = 0, absent = 0, pending = 0;
        rows.forEach(row => {
            const status = normaliseClientAttendanceStatus(row.dataset.attendanceStatus || '');
            if (status === 1) present++;
            else if (status === 0) absent++;
            else pending++;
        });
        const marked = present + absent;
        $('#tpSessionAttendanceCount').textContent = `${marked}/${total} marked · ${present} present · ${absent} absent · ${pending} pending`;
        $('#tpSessionAttendanceKpis').innerHTML = [
            ['Assigned', total, 'mdi-account-group-outline', 'primary'],
            ['Present', present, 'mdi-account-check-outline', 'success'],
            ['Absent', absent, 'mdi-account-remove-outline', 'danger'],
            ['Pending', pending, 'mdi-clock-outline', 'secondary'],
        ].map(([label,value,icon,tone]) => `<div class="tp-session-attendance-kpi"><div class="d-flex justify-content-between align-items-center"><span class="label">${esc(label)}</span><span class="text-${tone}"><i class="mdi ${icon}"></i></span></div><div class="value text-${tone}">${value}</div></div>`).join('');
    }

    function setSessionAttendanceStatus(row, value) {
        row.dataset.attendanceStatus = value === '' ? '' : String(value);
        row.querySelector('.tp-attendance-choice').outerHTML = sessionAttendanceChoiceHtml(row.dataset.attendanceStatus);
        updateSessionAttendanceUi();
    }

    async function openSessionAttendance(trainingId, sessionId) {
        try {
            const response = await tpFeatureGet(`${baseUrl}/${trainingId}/sessions/${sessionId}/attendance`);
            const data = response.data || {};
            $('#tpSessionAttendanceTrainingId').value = trainingId;
            $('#tpSessionAttendanceSessionId').value = sessionId;
            $('#tpSessionAttendanceSub').textContent = `${data.training?.training_planner_id || ''} · ${data.session?.session_title || `Session ${data.session?.session_no || ''}`}`;
            $('#tpSessionAttendanceSearch').value = '';
            $('#tpSessionAttendanceInfo').innerHTML = [
                ['Date', fmtDate(data.session?.session_date)],
                ['Time', `${formatTime12(data.session?.start_time)} – ${formatTime12(data.session?.end_time)}`],
                ['Session', `#${data.session?.session_no || '-'}`],
                ['Status', data.session?.session_status || 'scheduled'],
            ].map(item => `<div class="tp-info"><small>${esc(item[0])}</small><strong>${esc(item[1])}</strong></div>`).join('');

            const attendees = data.attendees || [];
            const normalized = attendees.map(x => ({...x, attendance_status: normaliseClientAttendanceStatus(x.attendance_status)}));
            $('#tpSessionAttendanceList').innerHTML = normalized.length ? normalized.map(person => `
                <div class="tp-session-attendance-row" data-session-staff="${esc(person.staff_id)}" data-attendance-status="${person.attendance_status === null ? '' : person.attendance_status}">
                    <div class="tp-session-attendance-person"><div class="tp-avatar">${person.staff_image_url ? `<img src="${esc(person.staff_image_url)}" alt="${esc(person.staff_name)}" class="rounded-circle" style="width:42px;height:42px;object-fit:cover;">` : esc(initials(person.staff_name))}</div><div class="min-w-0"><div class="name">${esc(person.staff_name)}</div><div class="meta">${esc(person.staff_id || '-')} · ${esc(person.department_name || '-')} · ${esc(person.job_role_name || '-')}</div></div></div>
                    ${sessionAttendanceChoiceHtml(person.attendance_status)}
                </div>`).join('') : '<div class="tp-empty">No attendees are assigned to this training.</div>';
            updateSessionAttendanceUi();
            window.tpSessionAttendanceModal.show();
        } catch (error) { toast(error.message || 'Unable to load session attendance.', 'error'); }
    }

    async function saveSessionAttendance() {
        const trainingId = $('#tpSessionAttendanceTrainingId').value;
        const sessionId = $('#tpSessionAttendanceSessionId').value;
        const attendance = $$('#tpSessionAttendanceList [data-session-staff]').map(row => ({
            staff_id: Number(row.dataset.sessionStaff),
            attendance_status: row.dataset.attendanceStatus === '' ? null : Number(row.dataset.attendanceStatus),
        }));
        $('#tpSessionAttendanceSave').disabled = true;
        try {
            await tpFeaturePost(`${baseUrl}/${trainingId}/sessions/${sessionId}/attendance`, 'POST', { attendance });
            toast('Session attendance saved successfully.');
            window.tpSessionAttendanceModal.hide();
            await openSessionManager(trainingId);
            await loadTable();
        } catch (error) { toast(error.message || 'Unable to save session attendance.', 'error'); }
        finally { $('#tpSessionAttendanceSave').disabled = false; }
    }

    async function openFirstPendingSessionAttendance(id) {
        try {
            const response = await tpFeatureGet(`${baseUrl}/${id}/sessions`);
            const sessions = response.data?.sessions || [];
            const target = sessions.find(session => session.session_status !== 'cancelled' && Number(session.attendance_marked || 0) < Number(session.attendance_total || 0)) || sessions.find(session => session.session_status !== 'cancelled');
            if (!target) {
                toast('No active training session is available for attendance.', 'info');
                return;
            }
            await openSessionAttendance(id, target.sno);
        } catch (error) {
            toast(error.message || 'Unable to load session attendance.', 'error');
        }
    }

    function askDelete(training) {
        $('#tpDeleteId').value = training.sno;
        $('#tpDeleteMessage').textContent = `${training.training_planner_id} · ${training.training_planner_name} will be removed from the planner.`;
        deleteModal.show();
    }

    async function confirmDelete() {
        const id = $('#tpDeleteId').value;
        $('#tpDeleteConfirm').disabled = true;

        try {
            const response = await fetch(urls.remove(id), {
                method: 'DELETE',
                headers: {
                    Accept: 'application/json',
                    'X-CSRF-TOKEN': csrf,
                },
            });

            const data = await response.json();
            if (!response.ok) throw data;

            toast(data.message || 'Training deleted successfully.');
            deleteModal.hide();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            toast(error.message || 'Unable to delete training.', 'error');
        } finally {
            $('#tpDeleteConfirm').disabled = false;
        }
    }

    async function resetFilters() {
        $('#tpSearch').value = '';
        $('#tpFilterStatus').value = '';
        $('#tpFilterMode').value = '';
        datePickers.filterFrom.clear();
        datePickers.filterTo.clear();
        state.page = 1;
        await loadTable();
        await loadCalendar();
    }

    function debounce(callback, delay) {
        let timer;
        return (...args) => {
            clearTimeout(timer);
            timer = setTimeout(() => callback(...args), delay);
        };
    }

    function trainerStatusBadge(status) {
        return Number(status) === 0
            ? '<span class="tp-trainer-badge active"><i class="mdi mdi-check-circle-outline"></i>Active</span>'
            : '<span class="tp-trainer-badge inactive"><i class="mdi mdi-pause-circle-outline"></i>Inactive</span>';
    }

    function trainerAvatarHtml(person, sizeClass = '') {
        const image = person.staff_image_url
            ? `<img src="${esc(person.staff_image_url)}" alt="${esc(person.staff_name || 'Staff')}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.classList.remove('d-none');">`
            : '';
        const color = esc(person.entity_base_color || '#ab2b22');
        return `<div class="tp-trainer-avatar ${sizeClass}" style="border:2px solid ${color}; box-shadow:0 0 0 3px color-mix(in srgb, ${color} 10%, transparent);">${image}<span class="${image ? 'd-none' : ''}">${esc(initials(person.staff_name))}</span></div>`;
    }

    function trainerPaginationHtml(meta, kind) {
        if (!meta || Number(meta.total) === 0 || Number(meta.last_page) <= 1) return '';

        const current = Number(meta.current_page) || 1;
        const last = Number(meta.last_page) || 1;
        const start = Math.max(1, current - 2);
        const end = Math.min(last, current + 2);
        const pages = [];

        for (let page = start; page <= end; page++) {
            pages.push(`
                <button type="button" class="btn btn-sm ${page === current ? 'btn-primary' : 'btn-outline-secondary'}" data-trainer-page="${page}" data-trainer-page-kind="${kind}">
                    ${page}
                </button>
            `);
        }

        return `
            <div class="d-flex gap-1 align-items-center">
                <button type="button" class="btn btn-sm btn-outline-secondary" data-trainer-page="${Math.max(1, current - 1)}" data-trainer-page-kind="${kind}" ${current === 1 ? 'disabled' : ''} aria-label="Previous page"><i class="mdi mdi-chevron-left"></i></button>
                ${current > 3 ? '<span class="small text-muted px-1">…</span>' : ''}
                ${pages.join('')}
                ${current < last - 2 ? '<span class="small text-muted px-1">…</span>' : ''}
                <button type="button" class="btn btn-sm btn-outline-secondary" data-trainer-page="${Math.min(last, current + 1)}" data-trainer-page-kind="${kind}" ${current === last ? 'disabled' : ''} aria-label="Next page"><i class="mdi mdi-chevron-right"></i></button>
            </div>
        `;
    }

    function trainerManagerFilters() {
        return {
            search: trainerUi.search,
            entity_id: trainerUi.entityId,
            department_id: trainerUi.departmentId,
        };
    }

    async function loadTrainerLookups(entityId = null) {
        const params = {};
        if (entityId !== null && entityId !== '') {
            params.entity_id = Number(entityId);
        }

        const response = await getJson(urls.trainerLookups, params);
        const entities = response.data?.entities || [];
        const departments = response.data?.departments || [];

        trainerUi.entities = entities;
        trainerUi.departments = departments;

        renderOptions(
            '#tpTrainerEntityFilter',
            entities.map(item => ({ id: item.sno, text: item.entity_name })),
            'All entities',
            false
        );

        renderOptions(
            '#tpTrainerEditorEntityFilter',
            entities.map(item => ({ id: item.sno, text: item.entity_name })),
            'All entities',
            false
        );

        const hasEntity = entityId !== null && entityId !== '';
        const departmentOptions = departments.map(item => ({
            id: item.sno,
            text: item.department_name,
        }));

        renderOptions(
            '#tpTrainerDepartmentFilter',
            departmentOptions,
            'All departments',
            false
        );

        renderOptions(
            '#tpTrainerEditorDepartmentFilter',
            departmentOptions,
            'All departments',
            false
        );

        $('#tpTrainerDepartmentFilter').disabled = false;
        $('#tpTrainerEditorDepartmentFilter').disabled = false;

        if (window.jQuery?.fn?.select2) {
            window.jQuery('#tpTrainerDepartmentFilter').prop('disabled', false);
            window.jQuery('#tpTrainerEditorDepartmentFilter').prop('disabled', false);
        }

        $('#tpTrainerEntityFilter').value = trainerUi.entityId || '';
        $('#tpTrainerEditorEntityFilter').value = trainerUi.editorEntityId || '';
        $('#tpTrainerDepartmentFilter').value = hasEntity ? (trainerUi.departmentId || '') : '';
        $('#tpTrainerEditorDepartmentFilter').value = hasEntity ? (trainerUi.editorDepartmentId || '') : '';

        if (window.jQuery?.fn?.select2) {
            window.jQuery('#tpTrainerEntityFilter').trigger('change.select2');
            window.jQuery('#tpTrainerEditorEntityFilter').trigger('change.select2');
            window.jQuery('#tpTrainerDepartmentFilter').trigger('change.select2');
            window.jQuery('#tpTrainerEditorDepartmentFilter').trigger('change.select2');
        }

        trainerUi.lookupLoaded = true;
    }

    function resetTrainerManagerFilters() {
        trainerUi.staffPage = 1;
        trainerUi.trainerPage = 1;
        trainerUi.search = '';
        trainerUi.entityId = '';
        trainerUi.departmentId = '';
        trainerUi.status = 'all';

        $('#tpTrainerSearch').value = '';
        $('#tpTrainerEntityFilter').value = '';
        $('#tpTrainerDepartmentFilter').value = '';
        $('#tpTrainerDepartmentFilter').disabled = false;
        $('#tpTrainerStatusFilter').value = 'all';
        if (window.jQuery?.fn?.select2) {
            window.jQuery('#tpTrainerEntityFilter').val(null).trigger('change.select2');
            window.jQuery('#tpTrainerDepartmentFilter').val(null).trigger('change.select2');
        }
    }

    async function loadTrainerStaffDirectory() {
        $('#tpAvailableTrainerStaff').innerHTML = '<div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading available staff…</div>';

        try {
            const response = await getJson(urls.trainerStaff, {
                ...trainerManagerFilters(),
                page: trainerUi.staffPage,
                per_page: trainerUi.staffPerPage,
            });

            const page = response.data || {};
            const rows = page.data || [];
            trainerUi.staffRows = rows;
            $('#tpTrainerStaffCount').textContent = Number(page.total || 0);
            $('#tpTrainerStaffMeta').textContent = rows.length
                ? `Showing ${page.from}–${page.to} of ${page.total}`
                : 'No available staff';

            if (!rows.length) {
                $('#tpAvailableTrainerStaff').innerHTML = `
                    <div class="tp-trainer-empty">
                        <div>
                            <div class="mb-2"><i class="mdi mdi-account-search-outline fs-1"></i></div>
                            <div class="fw-semibold text-dark">No eligible staff found</div>
                            <div class="mt-1">Try another entity, department, or search term.</div>
                        </div>
                    </div>
                `;
            } else {
                $('#tpAvailableTrainerStaff').innerHTML = rows.map(person => `
                    <div class="tp-trainer-person" style="--entity-color:${esc(person.entity_base_color || '#ab2b22')};">
                        ${trainerAvatarHtml(person)}
                        <div class="flex-grow-1 min-w-0">
                            <div class="tp-trainer-card-title text-truncate">${esc(person.staff_name)}</div>
                            <div class="tp-trainer-card-meta">${esc(person.staff_id || '-')} · ${esc(person.job_role_name || 'Role not set')}</div>
                            <div class="d-flex flex-wrap gap-1 mt-1">
                                <span class="tp-trainer-entity-pill" style="--entity-color:${esc(person.entity_base_color || '#ab2b22')};"><span class="tp-trainer-entity-dot"></span>${esc(person.entity_name || 'No entity')}</span>
                                <span class="tp-pill tp-pill-gray">${esc(person.department_name || 'No department')}</span>
                            </div>
                            ${person.email_id ? `<div class="tp-trainer-card-meta text-truncate mt-1">${esc(person.email_id)}</div>` : ''}
                        </div>
                        <button type="button" class="btn btn-sm btn-primary tp-trainer-add-btn flex-shrink-0" data-trainer-add-staff="${esc(person.sno)}" title="Add as trainer">
                            <i class="mdi mdi-account-plus-outline me-1"></i>Add
                        </button>
                    </div>
                `).join('');
            }

            $('#tpTrainerStaffPagination').innerHTML = trainerPaginationHtml(page, 'staff');
        } catch (error) {
            $('#tpAvailableTrainerStaff').innerHTML = '<div class="tp-trainer-empty text-danger">Unable to load available staff.</div>';
            $('#tpTrainerStaffPagination').innerHTML = '';
            toast(error.message || 'Unable to load staff.', 'error');
        }
    }

    async function loadConfiguredTrainers() {
        $('#tpConfiguredTrainerList').innerHTML = '<div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading trainers…</div>';

        try {
            const response = await getJson(urls.trainers, {
                ...trainerManagerFilters(),
                status: trainerUi.status,
                page: trainerUi.trainerPage,
                per_page: trainerUi.trainerPerPage,
            });

            const page = response.data || {};
            const rows = page.data || [];
            const stats = response.stats || {};

            $('#tpTrainerStatTotal').textContent = Number(stats.total || 0);
            $('#tpTrainerStatActive').textContent = Number(stats.active || 0);
            $('#tpTrainerStatInactive').textContent = Number(stats.inactive || 0);
            $('#tpTrainerConfiguredCount').textContent = Number(page.total || 0);
            $('#tpTrainerListMeta').textContent = rows.length
                ? `Showing ${page.from}–${page.to} of ${page.total}`
                : 'No trainers found';

            if (!rows.length) {
                $('#tpConfiguredTrainerList').innerHTML = `
                    <div class="tp-trainer-empty">
                        <div>
                            <div class="mb-2"><i class="mdi mdi-account-tie-outline fs-1"></i></div>
                            <div class="fw-semibold text-dark">No trainer staff configured</div>
                            <div class="mt-1">Choose a staff member from the left and configure them as a trainer.</div>
                        </div>
                    </div>
                `;
            } else {
                $('#tpConfiguredTrainerList').innerHTML = rows.map(trainer => {
                    const disabledStaff = Number(trainer.staff_status) !== 0;
                    return `
                        <div class="tp-trainer-person" style="--entity-color:${esc(trainer.entity_base_color || '#ab2b22')};">
                            ${trainerAvatarHtml(trainer)}
                            <div class="flex-grow-1 min-w-0">
                                <div class="d-flex align-items-center gap-2 flex-wrap">
                                    <div class="tp-trainer-card-title">${esc(trainer.staff_name)}</div>
                                    ${trainerStatusBadge(trainer.status)}
                                    ${disabledStaff ? '<span class="tp-trainer-badge inactive"><i class="mdi mdi-alert-outline"></i>Staff inactive</span>' : ''}
                                </div>
                                <div class="tp-trainer-card-meta">${esc(trainer.staff_code || trainer.staff_id)} · ${esc(trainer.job_role_name || 'Role not set')}</div>
                                <div class="d-flex flex-wrap gap-1 mt-1">
                                    <span class="tp-trainer-entity-pill" style="--entity-color:${esc(trainer.entity_base_color || '#ab2b22')};"><span class="tp-trainer-entity-dot"></span>${esc(trainer.entity_name || 'No entity')}</span>
                                    <span class="tp-pill tp-pill-gray">${esc(trainer.department_name || 'No department')}</span>
                                </div>
                                <div class="tp-trainer-card-meta mt-1">
                                    <span class="badge bg-label-primary me-1">${esc(trainer.training_count || 0)} training(s)</span>
                                </div>
                            </div>
                            <div class="d-flex flex-column gap-1 flex-shrink-0">
                                <button type="button" class="btn btn-sm btn-outline-primary" data-trainer-edit="${esc(trainer.sno)}" title="Edit trainer">
                                    <i class="mdi mdi-pencil-outline"></i>
                                </button>
                                <button type="button" class="btn btn-sm ${Number(trainer.status) === 0 ? 'btn-outline-danger' : 'btn-outline-success'}" data-trainer-toggle="${esc(trainer.sno)}" data-next-status="${Number(trainer.status) === 0 ? 1 : 0}" title="${Number(trainer.status) === 0 ? 'Deactivate' : 'Activate'} trainer">
                                    <i class="mdi ${Number(trainer.status) === 0 ? 'mdi-pause-circle-outline' : 'mdi-play-circle-outline'}"></i>
                                </button>
                            </div>
                        </div>
                    `;
                }).join('');
            }

            $('#tpTrainerPagination').innerHTML = trainerPaginationHtml(page, 'trainer');
        } catch (error) {
            $('#tpConfiguredTrainerList').innerHTML = '<div class="tp-trainer-empty text-danger">Unable to load trainer records.</div>';
            $('#tpTrainerPagination').innerHTML = '';
            toast(error.message || 'Unable to load trainers.', 'error');
        }
    }

    async function loadTrainerManager() {
        await Promise.all([loadTrainerStaffDirectory(), loadConfiguredTrainers()]);
    }

    function showTrainerManagerView() {
        trainerUi.view = 'manager';
        trainerUi.editingId = null;
        trainerUi.selectedStaff = null;

        $('#tpTrainerManagerView').classList.remove('d-none');
        $('#tpTrainerEditorView').classList.add('d-none');
        $('#tpTrainerManagerFooter').classList.remove('d-none');
        $('#tpTrainerEditorFooter').classList.add('d-none');
        $('#tpTrainerBackBtn').classList.add('d-none');
        $('#tpTrainerManageTitle').textContent = 'Trainer Management';
        $('#tpTrainerManageSub').textContent = 'Assign existing staff as trainers for the Training Planner.';
    }

    function showTrainerEditorView() {
        trainerUi.view = 'editor';
        $('#tpTrainerManagerView').classList.add('d-none');
        $('#tpTrainerEditorView').classList.remove('d-none');
        $('#tpTrainerManagerFooter').classList.add('d-none');
        $('#tpTrainerEditorFooter').classList.remove('d-none');
        $('#tpTrainerBackBtn').classList.remove('d-none');
    }

    function clearTrainerEditorErrors() {
        ['Staff'].forEach(name => {
            const element = $(`#tpTrainerErr${name}`);
            if (element) element.textContent = '';
        });
    }

    function trainerEditorFilters() {
        return {
            search: trainerUi.editorSearch || '',
            entity_id: trainerUi.editorEntityId || '',
            department_id: trainerUi.editorDepartmentId || '',
            page: trainerUi.editorStaffPage || 1,
            per_page: trainerUi.editorStaffPerPage || 12,
        };
    }

    function resetTrainerEditorFilters(person = null) {
        trainerUi.editorEntityId = person && person.entity_id !== null && person.entity_id !== undefined
            ? String(person.entity_id)
            : '';
        trainerUi.editorDepartmentId = person && person.department_id !== null && person.department_id !== undefined
            ? String(person.department_id)
            : '';
        trainerUi.editorSearch = '';
        trainerUi.editorStaffPage = 1;
        $('#tpTrainerEditorEntityFilter').value = trainerUi.editorEntityId;
        $('#tpTrainerEditorDepartmentFilter').value = trainerUi.editorDepartmentId;
        $('#tpTrainerEditorDepartmentFilter').disabled = !trainerUi.editorEntityId;
        $('#tpTrainerEditorStaffSearch').value = '';
    }

    function selectTrainerEditorStaff(person) {
        if (!person || !person.sno) return;
        trainerUi.selectedStaff = person;
        $('#tpTrainerSelectedStaffId').value = String(person.sno);
        renderTrainerSelectedStaff(person);
        $('#tpTrainerErrStaff').textContent = '';
        $('#tpTrainerSaveBtn').disabled = false;
        $('#tpTrainerSelectionState').classList.add('is-selected');
        $('#tpTrainerSelectionState').innerHTML = '<i class="mdi mdi-check-circle-outline"></i> Staff selected';
    }

    async function loadTrainerEditorStaff() {
        const requestId = ++trainerUi.editorRequestSeq;
        const list = $('#tpTrainerEditorStaffList');
        const meta = $('#tpTrainerEditorStaffMeta');
        const count = $('#tpTrainerEditorStaffCount');
        const pagination = $('#tpTrainerEditorStaffPagination');
        if (!list) return;

        if (trainerUi.editorEntityId === '' || trainerUi.editorEntityId === null || trainerUi.editorEntityId === undefined) {
            list.innerHTML = `
                <div class="tp-trainer-empty">
                    <div>
                        <div class="mb-2"><i class="mdi mdi-office-building-outline fs-1"></i></div>
                        <div class="fw-semibold text-dark">Select an entity first</div>
                        <div class="mt-1">Choose the Entity above. The Department list will then load from that entity and the matching staff will appear here.</div>
                    </div>
                </div>
            `;
            meta.textContent = 'Entity required';
            count.textContent = 'Select entity';
            pagination.innerHTML = '';
            return;
        }

        list.innerHTML = '<div class="tp-trainer-loading"><span class="spinner-border spinner-border-sm"></span>Loading matching staff…</div>';
        pagination.innerHTML = '';

        try {
            const response = await getJson(urls.trainerStaff, trainerEditorFilters());
            if (requestId !== trainerUi.editorRequestSeq) return;

            const page = response.data || {};
            const rows = Array.isArray(page.data) ? page.data : [];
            trainerUi.editorStaffRows = rows;
            const selectedId = Number(trainerUi.selectedStaff?.sno || $('#tpTrainerSelectedStaffId').value || 0);

            count.textContent = `${Number(page.total || 0)} available`;
            meta.textContent = rows.length ? `Showing ${page.from}–${page.to} of ${page.total}` : 'No matching staff';

            if (!rows.length) {
                list.innerHTML = `
                    <div class="tp-trainer-empty">
                        <div>
                            <div class="mb-2"><i class="mdi mdi-account-search-outline fs-1"></i></div>
                            <div class="fw-semibold text-dark">No staff found</div>
                            <div class="mt-1">Try another entity, department, or search term.</div>
                        </div>
                    </div>
                `;
                return;
            }

            list.innerHTML = `<div class="tp-trainer-editor-staff-list">${rows.map(person => {
                const selected = Number(person.sno) === selectedId;
                return `
                    <button type="button" class="tp-trainer-editor-staff-item ${selected ? 'is-selected' : ''}" style="--entity-color:${esc(person.entity_base_color || '#ab2b22')};" data-trainer-editor-select="${esc(person.sno)}" aria-pressed="${selected ? 'true' : 'false'}">
                        ${trainerAvatarHtml(person)}
                        <div class="staff-main">
                            <div class="staff-name">${esc(person.staff_name)}</div>
                            <div class="staff-meta">${esc(person.staff_id || '-')} · ${esc(person.job_role_name || 'Role not set')}</div>
                            <div class="d-flex flex-wrap gap-1 mt-1">
                                <span class="tp-trainer-entity-pill" style="--entity-color:${esc(person.entity_base_color || '#ab2b22')};"><span class="tp-trainer-entity-dot"></span>${esc(person.entity_name || 'No entity')}</span>
                                <span class="tp-pill tp-pill-gray">${esc(person.department_name || 'No department')}</span>
                            </div>
                            ${person.email_id ? `<div class="staff-meta text-truncate mt-1">${esc(person.email_id)}</div>` : ''}
                        </div>
                        <div class="staff-action">
                            ${selected ? '<span class="btn btn-sm btn-success"><i class="mdi mdi-check me-1"></i>Selected</span>' : '<span class="btn btn-sm btn-outline-primary"><i class="mdi mdi-account-plus-outline me-1"></i>Select</span>'}
                        </div>
                    </button>
                `;
            }).join('')}</div>`;

            pagination.innerHTML = trainerPaginationHtml(page, 'editor');
        } catch (error) {
            if (requestId !== trainerUi.editorRequestSeq) return;
            list.innerHTML = '<div class="tp-trainer-empty text-danger">Unable to load staff. Please refresh and try again.</div>';
            meta.textContent = '';
            pagination.innerHTML = '';
            toast(error.message || 'Unable to load staff.', 'error');
        }
    }

    function renderTrainerSelectedStaff(person) {
        const wrap = $('#tpTrainerSelectedStaffWrap');
        const target = $('#tpTrainerSelectedStaff');

        if (!person) {
            wrap.classList.add('d-none');
            target.innerHTML = '';
            return;
        }

        wrap.classList.remove('d-none');
        const entityColor = esc(person.entity_base_color || '#ab2b22');
        target.innerHTML = `
            ${trainerAvatarHtml(person)}
            <div class="min-w-0 flex-grow-1">
                <div class="fw-bold text-dark">${esc(person.staff_name)}</div>
                <div class="small text-muted">${esc(person.staff_id || '-')} · ${esc(person.job_role_name || 'Role not set')}</div>
                <div class="d-flex flex-wrap gap-1 mt-1">
                    <span class="tp-trainer-entity-pill" style="--entity-color:${entityColor};"><span class="tp-trainer-entity-dot"></span>${esc(person.entity_name || 'No entity')}</span>
                    <span class="tp-pill tp-pill-gray">${esc(person.department_name || 'No department')}</span>
                </div>
            </div>
        `;
    }


    async function openTrainerEditor(trainerId = null, staffId = null, staff = null) {
        clearTrainerEditorErrors();
        trainerUi.editingId = trainerId;
        trainerUi.selectedStaff = null;
        trainerUi.editorRequestSeq++;

        $('#tpTrainerRecordId').value = trainerId || '';
        $('#tpTrainerSelectedStaffId').value = '';
        $('#tpTrainerSaveBtn').disabled = true;
        $('#tpTrainerSelectionState').classList.remove('is-selected');
        $('#tpTrainerSelectionState').innerHTML = '<i class="mdi mdi-account-outline"></i>No staff selected';

        if (trainerId) {
            $('#tpTrainerEditorTitle').textContent = 'Update Trainer';
            $('#tpTrainerEditorSub').textContent = 'Change the assigned staff member or update trainer-specific details. Staff master data remains unchanged.';
            showTrainerEditorView();

            try {
                const response = await getJson(urls.trainer(trainerId));
                const trainer = response.data;
                const selected = {
                    sno: trainer.staff_id,
                    staff_id: trainer.staff_code,
                    staff_name: trainer.staff_name,
                    email_id: trainer.email_id,
                    mobile_no: trainer.mobile_no,
                    entity_id: trainer.entity_id,
                    entity_name: trainer.entity_name,
                    entity_base_color: trainer.entity_base_color,
                    department_id: trainer.department_id,
                    department_name: trainer.department_name,
                    job_role_id: trainer.job_role_id,
                    job_role_name: trainer.job_role_name,
                    staff_image_url: trainer.staff_image_url,
                };

                trainerUi.selectedStaff = selected;
                $('#tpTrainerSelectedStaffId').value = String(selected.sno);
                resetTrainerEditorFilters(selected);
                await loadTrainerLookups(selected.entity_id ?? null);
                trainerUi.editorEntityId = selected.entity_id !== null && selected.entity_id !== undefined
                    ? String(selected.entity_id)
                    : '';
                trainerUi.editorDepartmentId = selected.department_id !== null && selected.department_id !== undefined
                    ? String(selected.department_id)
                    : '';
                $('#tpTrainerEditorEntityFilter').value = trainerUi.editorEntityId;
                $('#tpTrainerEditorDepartmentFilter').value = trainerUi.editorDepartmentId;
                renderTrainerSelectedStaff(selected);
                $('#tpTrainerSelectionState').classList.add('is-selected');
                $('#tpTrainerSelectionState').innerHTML = '<i class="mdi mdi-check-circle-outline"></i> Current staff selected';
                $('#tpTrainerSaveBtn').disabled = false;
                await loadTrainerEditorStaff();
            } catch (error) {
                toast(error.message || 'Unable to load trainer.', 'error');
                showTrainerManagerView();
                await loadTrainerManager();
            }
            return;
        }

        $('#tpTrainerEditorTitle').textContent = 'Change Trainer Staff';
        $('#tpTrainerEditorSub').textContent = 'Filter by entity and department, then choose the replacement staff member.';
        showTrainerEditorView();

        if (!trainerUi.lookupLoaded) await loadTrainerLookups();
        resetTrainerEditorFilters(staff);
        await loadTrainerLookups(trainerUi.editorEntityId === '' ? null : trainerUi.editorEntityId);

        if (staff && staffId) selectTrainerEditorStaff(staff);
        else renderTrainerSelectedStaff(null);

        await loadTrainerEditorStaff();
    }

    async function saveTrainer() {
        clearTrainerEditorErrors();

        const staffId = Number($('#tpTrainerSelectedStaffId').value || trainerUi.selectedStaff?.sno || 0);
        if (!staffId) {
            $('#tpTrainerErrStaff').textContent = 'Please select a staff member from the filtered staff list.';
            return;
        }

        const id = Number($('#tpTrainerRecordId').value || 0);
        const payload = {
            staff_id: staffId,
        };

        const button = $('#tpTrainerSaveBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving…';

        try {
            const response = await postJson(id ? urls.trainer(id) : urls.trainers, id ? 'PUT' : 'POST', payload);
            toast(response.message || 'Trainer saved successfully.');
            showTrainerManagerView();
            trainerUi.staffPage = 1;
            trainerUi.trainerPage = 1;
            await loadTrainerManager();

            if ($('#tpPlannerModal')?.classList.contains('show')) {
                refreshStaff().catch(() => {});
            }
        } catch (error) {
            if (error.errors?.staff_id) {
                $('#tpTrainerErrStaff').textContent = error.errors.staff_id[0] || 'Invalid staff selection.';
            }
            toast(error.message || 'Unable to save trainer.', 'error');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="mdi mdi-account-sync-outline me-1"></i>Update Trainer';
        }
    }

    async function toggleTrainerStatus(id, nextStatus) {
        const action = Number(nextStatus) === 0 ? 'activate' : 'deactivate';
        const confirmed = window.confirm(`Are you sure you want to ${action} this trainer?`);
        if (!confirmed) return;

        try {
            const response = await postJson(urls.trainerStatus(id), 'POST', { status: Number(nextStatus) });
            toast(response.message || 'Trainer status updated.');
            await loadConfiguredTrainers();

            if ($('#tpPlannerModal')?.classList.contains('show')) {
                refreshStaff().catch(() => {});
            }
        } catch (error) {
            toast(error.message || `Unable to ${action} trainer.`, 'error');
        }
    }

    async function openTrainerManager() {
        showTrainerManagerView();
        resetTrainerManagerFilters();
        trainerUi.entityId = '';
        trainerUi.departmentId = '';
        await loadTrainerLookups(null);
        trainerManageModal.show();
        await loadTrainerManager();
    }

    function bindEvents() {
        $('#tpManageTrainerBtn').addEventListener('click', openTrainerManager);
        $('#tpTrainerEditorCancel').addEventListener('click', showTrainerManagerView);
        $('#tpTrainerBackBtn').addEventListener('click', showTrainerManagerView);
        $('#tpTrainerSaveBtn').addEventListener('click', saveTrainer);
        $('#tpTrainerRefreshBtn').addEventListener('click', async () => {
            trainerUi.staffPage = 1;
            trainerUi.trainerPage = 1;
            await loadTrainerManager();
        });

        $('#tpTrainerSearch').addEventListener('input', debounce(() => {
            trainerUi.search = $('#tpTrainerSearch').value.trim();
            trainerUi.staffPage = 1;
            trainerUi.trainerPage = 1;
            loadTrainerManager();
        }, 250));

        window.jQuery('#tpTrainerEntityFilter').off('.trainerManager').on('change.trainerManager', async function () {
            trainerUi.entityId = $('#tpTrainerEntityFilter').value || '';
            trainerUi.departmentId = '';
            $('#tpTrainerDepartmentFilter').value = '';
            trainerUi.staffPage = 1;
            trainerUi.trainerPage = 1;
            await loadTrainerLookups(trainerUi.entityId === '' ? null : trainerUi.entityId);
            await loadTrainerManager();
        });

        window.jQuery('#tpTrainerDepartmentFilter').off('.trainerManager').on('change.trainerManager', function () {
            trainerUi.departmentId = $('#tpTrainerDepartmentFilter').value || '';
            trainerUi.staffPage = 1;
            trainerUi.trainerPage = 1;
            loadTrainerManager();
        });

        window.jQuery('#tpTrainerStatusFilter').off('.trainerManager').on('change.trainerManager', function () {
            trainerUi.status = $('#tpTrainerStatusFilter').value || 'all';
            trainerUi.trainerPage = 1;
            loadConfiguredTrainers();
        });

        window.jQuery('#tpTrainerEditorEntityFilter').off('.trainerManager').on('change.trainerManager', async function () {
            trainerUi.editorEntityId = $('#tpTrainerEditorEntityFilter').value || '';
            trainerUi.editorDepartmentId = '';
            $('#tpTrainerEditorDepartmentFilter').value = '';
            trainerUi.editorStaffPage = 1;
            await loadTrainerLookups(trainerUi.editorEntityId === '' ? null : trainerUi.editorEntityId);
            trainerUi.editorEntityId = $('#tpTrainerEditorEntityFilter').value || '';
            await loadTrainerEditorStaff();
        });

        window.jQuery('#tpTrainerEditorDepartmentFilter').off('.trainerManager').on('change.trainerManager', function () {
            trainerUi.editorDepartmentId = $('#tpTrainerEditorDepartmentFilter').value || '';
            trainerUi.editorStaffPage = 1;
            loadTrainerEditorStaff();
        });

        $('#tpTrainerEditorStaffSearch').addEventListener('input', debounce(() => {
            trainerUi.editorSearch = $('#tpTrainerEditorStaffSearch').value.trim();
            trainerUi.editorStaffPage = 1;
            loadTrainerEditorStaff();
        }, 250));

        $('#tpTrainerEditorFilterReset').addEventListener('click', async () => {
            resetTrainerEditorFilters();
            await loadTrainerLookups(trainerUi.editorEntityId === '' ? null : trainerUi.editorEntityId);
            await loadTrainerEditorStaff();
        });

        $('#tpTrainerChangeStaffBtn').addEventListener('click', () => {
            $('#tpTrainerSelectedStaffId').value = '';
            trainerUi.selectedStaff = null;
            renderTrainerSelectedStaff(null);
            $('#tpTrainerSaveBtn').disabled = true;
            $('#tpTrainerSelectionState').classList.remove('is-selected');
            $('#tpTrainerSelectionState').innerHTML = '<i class="mdi mdi-account-outline"></i>No staff selected';
            $('#tpTrainerEditorStaffList')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });

        $('#tpTrainerEditorStaffList').addEventListener('click', event => {
            const button = event.target.closest('[data-trainer-editor-select]');
            if (!button) return;
            const staffId = Number(button.dataset.trainerEditorSelect || 0);
            const person = trainerUi.editorStaffRows.find(item => Number(item.sno) === staffId);
            if (person) {
                selectTrainerEditorStaff(person);
                loadTrainerEditorStaff();
            }
        });

        $('#tpTrainerEditorStaffPagination').addEventListener('click', async event => {
            const button = event.target.closest('[data-trainer-page-kind="editor"]');
            if (!button || button.disabled) return;
            const page = Number(button.dataset.trainerPage || 1);
            if (!page || page === trainerUi.editorStaffPage) return;
            trainerUi.editorStaffPage = page;
            await loadTrainerEditorStaff();
        });

        $('#tpAvailableTrainerStaff').addEventListener('click', async event => {
            const button = event.target.closest('[data-trainer-add-staff]');
            if (!button || button.disabled) return;
            const staffId = Number(button.dataset.trainerAddStaff || 0);
            if (!staffId) return;

            const person = trainerUi.staffRows.find(item => Number(item.sno) === staffId);
            if (!person) {
                toast('The selected staff record is no longer available. Refresh the list and try again.', 'error');
                await loadTrainerStaffDirectory();
                return;
            }

            button.disabled = true;
            const originalHtml = button.innerHTML;
            button.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Adding…';
            try {
                const response = await postJson(urls.trainers, 'POST', { staff_id: staffId });
                toast(response.message || `${person.staff_name} added as trainer.`);
                trainerUi.staffPage = 1;
                trainerUi.trainerPage = 1;
                await loadTrainerManager();
                if ($('#tpPlannerModal')?.classList.contains('show')) refreshStaff().catch(() => {});
            } catch (error) {
                toast(error.message || 'Unable to add trainer.', 'error');
                button.disabled = false;
                button.innerHTML = originalHtml;
            }
        });

        $('#tpConfiguredTrainerList').addEventListener('click', async event => {
            const edit = event.target.closest('[data-trainer-edit]');
            if (edit) {
                await openTrainerEditor(Number(edit.dataset.trainerEdit || 0));
                return;
            }

            const toggle = event.target.closest('[data-trainer-toggle]');
            if (toggle) {
                await toggleTrainerStatus(Number(toggle.dataset.trainerToggle || 0), Number(toggle.dataset.nextStatus || 0));
            }
        });

        $('#tpTrainerStaffPagination').addEventListener('click', async event => {
            const button = event.target.closest('[data-trainer-page-kind="staff"]');
            if (!button || button.disabled) return;
            const page = Number(button.dataset.trainerPage || 1);
            if (!page || page === trainerUi.staffPage) return;
            trainerUi.staffPage = page;
            await loadTrainerStaffDirectory();
        });

        $('#tpTrainerPagination').addEventListener('click', async event => {
            const button = event.target.closest('[data-trainer-page-kind="trainer"]');
            if (!button || button.disabled) return;
            const page = Number(button.dataset.trainerPage || 1);
            if (!page || page === trainerUi.trainerPage) return;
            trainerUi.trainerPage = page;
            await loadConfiguredTrainers();
        });

        $('#tpAddBtn').addEventListener('click', () => {
            resetPlanner();
            plannerModal.show();
        });

        $('#tpSaveBtn').addEventListener('click', saveTraining);
        $('#tpStatusSave').addEventListener('click', saveStatus);
        $('#tpCompleteSave').addEventListener('click', saveComplete);
        $('#tpDeleteConfirm').addEventListener('click', confirmDelete);

        $$('#tpScheduleRange, #tpScheduleCustom').forEach(input => {
            input.addEventListener('change', toggleScheduleUi);
        });
        $('#tpCustomDateBadges').addEventListener('click', event => {
            const button = event.target.closest('.tp-date-remove');
            if (!button) return;
            removeCustomDate(button.dataset.date);
        });

        $('#tpClearCustomDates').addEventListener('click', () => {
            datePickers.customDates.clear();
            renderCustomDateBadges();
            refreshStaff();
        });

        bindScopeSelectEvents();

        ['#tpFromDate', '#tpToDate', '#tpRangeFromTime', '#tpRangeToTime', '#tpFromTime', '#tpToTime'].forEach(selector => {
            $(selector)?.addEventListener('change', () => {
                updateCustomSchedulePreview();
                refreshStaff();
            });
        });

        $('#tpStaffSearch').addEventListener('input', () => renderStaff(state.staff));

        $('#tpSelectAll').addEventListener('change', event => {
            $$('#tpAttendeeList .tp-attendee-check:not(:disabled)').forEach(input => {
                input.checked = event.target.checked;
            });
            updateSelectedCount();
        });

        $('#tpAttendeeList').addEventListener('change', event => {
            if (event.target.classList.contains('tp-attendee-check')) {
                updateSelectedCount();
                syncSelectAll();
            }
        });

        $('#tpSearch').addEventListener('input', debounce(async () => {
            state.page = 1;
            await loadTable();
            await loadCalendar();
        }, 450));

        

        window.jQuery(document).on('change', '#tpFilterStatus', function () {
            state.page = 1;
            loadTable();
            loadCalendar();
        });

        window.jQuery(document).on('change', '#tpFilterMode', function () {
           state.page = 1;
            loadTable();
            loadCalendar();
        });

     

        $('#tpFilterFrom').addEventListener('change', async () => {
            state.page = 1;
            await loadTable();
            await loadCalendar();
        });

        $('#tpFilterTo').addEventListener('change', async () => {
            state.page = 1;
            await loadTable();
            await loadCalendar();
        });

        $('#tpResetFilter').addEventListener('click', resetFilters);

        $('#tpPerPage').addEventListener('change', async () => {
            state.perPage = Number($('#tpPerPage').value);
            state.page = 1;
            await loadTable();
        });

       

        $('#pagination-container').addEventListener('click', async event => {
            const button = event.target.closest('[data-page]');

            if (!button || button.disabled) return;

            const page = Number(button.dataset.page);

            if (!page || page === state.page) return;

            state.page = page;

            await loadTable(page);
        });


        $('#tpTableBody').addEventListener('click', async event => {
            const button = event.target.closest('[data-act]');
            if (!button) return;

            const id = button.dataset.id;
            const response = await getJson(urls.show(id));
            const training = response.data;

            switch (button.dataset.act) {
                case 'view':
                    renderView(training);
                    viewModal.show();
                    break;
                case 'edit':
                    fillPlanner(training);
                    plannerModal.show();
                    break;
                case 'attendance':
                    openAttendance(id);
                    break;
                case 'complete':
                    openComplete(id);
                    break;
                case 'status':
                    openStatus(training);
                    break;
                case 'delete':
                    askDelete(training);
                    break;
                case 'attendees':
                    await openAttendeeManager(id);
                    break;
                case 'sessions':
                    await openSessionManager(id);
                    break;
                case 'session-attendance':
                    await openFirstPendingSessionAttendance(id);
                    break;
                default:
                    break;
            }
        });

        $('#tpViewAttendees').addEventListener('click', event => {
            const button = event.target.closest('.tp-staff-history-btn');
            if (!button) return;
            openStaffTrainingHistory(button.dataset.staffId, button.dataset.staffName || 'Staff');
        });

        $('#tpViewTabs').addEventListener('click', event => {
            if (event.target.closest('[data-bs-target="#tpCalendarPane"]')) {
                loadCalendar();
            }
        });

        $('#tpCalPrev').addEventListener('click', () => {
            state.month = new Date(state.month.getFullYear(), state.month.getMonth() - 1, 1);
            loadCalendar();
        });

        $('#tpCalNext').addEventListener('click', () => {
            state.month = new Date(state.month.getFullYear(), state.month.getMonth() + 1, 1);
            loadCalendar();
        });

        $('#tpCalToday').addEventListener('click', () => {
            const today = new Date();
            state.month = new Date(today.getFullYear(), today.getMonth(), 1);
            loadCalendar();
        });


        document.addEventListener('change', event => {
            if (event.target.matches('input[name="tpStatusValue"]')) {
                toggleStatusFields();
            }
            if (event.target.matches('input[name="tpRsScheduleType"]')) {
                toggleStatusScheduleFields();
            }
        });

        $('#tpStatusModal').addEventListener('hidden.bs.modal', () => {
            statusTraining = null;
            $('#tpErrStatusReason').textContent = '';
            $('#tpErrRsDates').textContent = '';
        });

        $('#tpCalendarGrid').addEventListener('click', event => {
            const button = event.target.closest('[data-cal-id]');
            if (button) openView(button.dataset.calId);
        });
    }

    function bindSessionAttendanceControls() {
        $('#tpSessionAttendanceList').addEventListener('click', event => {
            const button = event.target.closest('[data-session-status]');
            if (!button) return;
            const row = button.closest('[data-session-staff]');
            if (row) setSessionAttendanceStatus(row, button.dataset.sessionStatus || '');
        });
        $('#tpSessionAttendanceSearch').addEventListener('input', debounce(() => {
            const query = $('#tpSessionAttendanceSearch').value.trim().toLowerCase();
            $$('#tpSessionAttendanceList [data-session-staff]').forEach(row => row.classList.toggle('d-none', query !== '' && !row.textContent.toLowerCase().includes(query)));
        }, 120));
        const applyAll = value => $$('#tpSessionAttendanceList [data-session-staff]').forEach(row => setSessionAttendanceStatus(row, value));
        $('#tpSessionMarkAllPresent').addEventListener('click', () => applyAll('1'));
        $('#tpSessionMarkAllAbsent').addEventListener('click', () => applyAll('0'));
        $('#tpSessionMarkAllPending').addEventListener('click', () => applyAll(''));
    }

    function bindAdvancedTrainingFeatures() {
        $('#tpAddAttendeeSave').addEventListener('click', saveNewAttendees);
        $('#tpRemoveAttendeeConfirm').addEventListener('click', confirmRemoveAssignedAttendee);
        $('#tpSessionEditSave').addEventListener('click', saveSessionEditor);
        $('#tpSessionAttendanceSave').addEventListener('click', saveSessionAttendance);
        $('#tpAssignedSearch').addEventListener('input', renderAssignedAttendees);
        $('#tpAvailableSearch').addEventListener('input', () => {
            const list = JSON.parse($('#tpAvailableList').dataset.all || '[]');
            renderAvailableAttendees(list);
        });
        document.addEventListener('change', event => {
            if (event.target.classList.contains('tp-new-attendee-check')) updateNewAttendeeCount();
        });
        document.addEventListener('click', async event => {
            const remove = event.target.closest('[data-attendee-remove]');
            if (remove) {
                await removeAssignedAttendee(remove.dataset.attendeeRemove);
                return;
            }
            const edit = event.target.closest('[data-session-id].tp-session-edit-action');
            if (edit) {
                await openSessionEditor(edit.dataset.sessionId);
                return;
            }
            const attendance = event.target.closest('[data-session-id].tp-session-attendance-action');
            if (attendance) {
                await openSessionAttendance(tpFeature.trainingId, attendance.dataset.sessionId);
            }
        });
    }

    async function boot() {
        datePickers.customDates = flatpickr('#tpCustomDates', {
            mode: 'multiple',
            dateFormat: 'Y-m-d',
            conjunction: ', ',
            onChange: () => {
                renderCustomDateBadges();
                refreshStaff();
            },
        });

        datePickers.fromDate = flatpickr('#tpFromDate', {
            dateFormat: 'Y-m-d',
            onChange: refreshStaff,
        });

        datePickers.toDate = flatpickr('#tpToDate', {
            dateFormat: 'Y-m-d',
            onChange: refreshStaff,
        });

        const commonTimeOptions = {
            enableTime: true,
            noCalendar: true,
            enableSeconds: false,
            dateFormat: 'h:i K',
            time_24hr: false,
            minuteIncrement: 15,
            static: true,
            onChange: () => {
                updateCustomSchedulePreview();
                refreshStaff();
            },
        };

        datePickers.fromTime = flatpickr('#tpFromTime', commonTimeOptions);
        datePickers.toTime = flatpickr('#tpToTime', commonTimeOptions);
        datePickers.rangeFromTime = flatpickr('#tpRangeFromTime', commonTimeOptions);
        datePickers.rangeToTime = flatpickr('#tpRangeToTime', commonTimeOptions);
        datePickers.filterFrom = flatpickr('#tpFilterFrom', { dateFormat: 'Y-m-d' });
        datePickers.filterTo = flatpickr('#tpFilterTo', { dateFormat: 'Y-m-d' });
        datePickers.rsFromDate = flatpickr('#tpRsFromDate', { dateFormat: 'Y-m-d' });
        datePickers.rsToDate = flatpickr('#tpRsToDate', { dateFormat: 'Y-m-d' });
        datePickers.rsFromTime = flatpickr('#tpRsFromTime', { enableTime: true, noCalendar: true, dateFormat: 'h:i K', time_24hr: false, minuteIncrement: 15, static: true });
        datePickers.rsToTime = flatpickr('#tpRsToTime', { enableTime: true, noCalendar: true, dateFormat: 'h:i K', time_24hr: false, minuteIncrement: 15, static: true });
        datePickers.rsCustomDates = flatpickr('#tpRsCustomDates', { mode: 'multiple', dateFormat: 'Y-m-d', conjunction: ', ', onChange: renderStatusCustomDateBadges });
        datePickers.rsFromTimeCustom = flatpickr('#tpRsFromTimeCustom', { enableTime: true, noCalendar: true, dateFormat: 'h:i K', time_24hr: false, minuteIncrement: 15, static: true });
        datePickers.rsToTimeCustom = flatpickr('#tpRsToTimeCustom', { enableTime: true, noCalendar: true, dateFormat: 'h:i K', time_24hr: false, minuteIncrement: 15, static: true });

        plannerModal = new bootstrap.Modal('#tpPlannerModal');
        viewModal = new bootstrap.Modal('#tpViewModal');
        statusModal = new bootstrap.Modal('#tpStatusModal');
        completeModal = new bootstrap.Modal('#tpCompleteModal');
        deleteModal = new bootstrap.Modal('#tpDeleteModal');
        staffTrainingHistoryModal = new bootstrap.Modal('#tpStaffTrainingHistoryModal');
        trainerManageModal = new bootstrap.Modal('#tpTrainerManageModal');
        window.tpAttendeeModal = new bootstrap.Modal('#tpAttendeeModal');
        window.tpSessionsModal = new bootstrap.Modal('#tpSessionsModal');
        window.tpSessionEditModal = new bootstrap.Modal('#tpSessionEditModal');
        window.tpSessionAttendanceModal = new bootstrap.Modal('#tpSessionAttendanceModal');
        window.tpRemoveAttendeeModal = new bootstrap.Modal('#tpRemoveAttendeeModal');

        initSelect('#tpCompany', { placeholder: 'Select company' });
        initSelect('#tpEntity', { placeholder: 'Select entity' });
        initSelect('#tpBranch', { placeholder: 'Select branch' });
        initSelect('#tpTrainer', { placeholder: 'Select trainer' });

        document.querySelectorAll('select.select3').forEach(element => {
            initSelect(`#${element.id}`);
        });

        document.querySelector('#tpScheduleCustom').checked = true;
        toggleScheduleUi();
        renderCustomDateBadges();

        bindEvents();
        bindAdvancedTrainingFeatures();
        bindSessionAttendanceControls();

        try {
            await loadLookups();
            await loadTable();
            await loadCalendar();
        } catch (error) {
            toast(error.message || 'Unable to initialize Training Planner.', 'error');
        }
    }

    document.addEventListener('DOMContentLoaded', boot);
})();
</script>
@endsection
