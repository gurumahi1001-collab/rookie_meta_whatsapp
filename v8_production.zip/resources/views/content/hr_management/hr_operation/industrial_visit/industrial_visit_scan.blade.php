@extends('layouts/blankLayout')

@section('title', 'Industrial Visit Registration')

@section('vendor-style')
    @vite([
        'resources/assets/vendor/libs/dropzone/dropzone.scss',
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
        ])
@endsection

@section('vendor-script')
    @vite([
        'resources/assets/vendor/libs/dropzone/dropzone.js',
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
        ])
@endsection

@section('page-script')
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
@endsection



@section('content')
<style>
    :root{--iv-color:#ab2b22;--iv-ink:#0f172a;--iv-muted:#64748b;--iv-soft:#f8fafc}
    body{background:linear-gradient(135deg,#f8fafc 0%,#eef2f7 100%)}
    .iv-scan-page{min-height:100vh;padding:22px 12px 40px}
    .iv-scan-shell{max-width:760px;margin:0 auto}
    .iv-brand-card{background:#fff;border:1px solid #e7ecf2;border-radius:24px;padding:20px;box-shadow:0 15px 45px rgba(15,23,42,.07);position:relative;overflow:hidden}
    .iv-brand-card:after{content:"";position:absolute;right:-90px;top:-110px;width:260px;height:260px;border-radius:50%;background:var(--iv-color);opacity:.10}
    .iv-logo{width:68px;height:68px;border-radius:18px;background:#fff;object-fit:contain;padding:7px;border:1px solid #e7ecf2;box-shadow:0 8px 25px rgba(15,23,42,.08)}
    .iv-brand-title{font-size:24px;font-weight:850;letter-spacing:-.025em;color:var(--iv-ink)}
    .iv-brand-sub{font-size:12px;color:var(--iv-muted)}
    .iv-event-card{background:linear-gradient(135deg,var(--iv-color),#111827);color:#fff;border-radius:22px;padding:21px;box-shadow:0 15px 35px rgba(15,23,42,.15)}
    .iv-event-pill{display:inline-flex;gap:7px;align-items:center;background:rgba(255,255,255,.14);padding:7px 10px;border-radius:999px;font-size:11px;font-weight:800}
    .iv-event-college{font-size:21px;font-weight:850;line-height:1.2;margin-top:12px}
    .iv-event-meta{display:flex;flex-wrap:wrap;gap:10px;margin-top:13px;font-size:11px;color:rgba(255,255,255,.86)}
    .iv-form-card{margin-top:16px;background:#fff;border:1px solid #e7ecf2;border-radius:22px;padding:20px;box-shadow:0 15px 45px rgba(15,23,42,.07)}
    .iv-section-title{font-size:14px;font-weight:850;color:var(--iv-ink);margin-bottom:14px}
    .iv-label{font-size:11px;font-weight:850;color:#334155;margin-bottom:7px;text-transform:uppercase;letter-spacing:.045em}
    .iv-control{min-height:46px;border-radius:12px;border-color:#d8e0ea}
    .iv-control:focus{border-color:var(--iv-color);box-shadow:0 0 0 .2rem rgba(15,23,42,.08)}
    .iv-gender{display:flex;flex-wrap:wrap;gap:8px}
    .iv-gender-item{flex:1 1 110px}
    .iv-gender-item input{display:none}
    .iv-gender-item label{display:flex;align-items:center;justify-content:center;gap:7px;border:1px solid #dbe2ea;border-radius:12px;padding:12px;font-weight:750;color:#475569;cursor:pointer;background:#fff;transition:.2s}
    .iv-gender-item input:checked+label{background:var(--iv-color);color:#fff;border-color:var(--iv-color);box-shadow:0 8px 20px rgba(15,23,42,.12)}
    .iv-submit{min-height:48px;border:0;border-radius:13px;background:var(--iv-color);box-shadow:0 12px 28px rgba(15,23,42,.12);font-weight:850}
    .iv-submit:hover{transform:translateY(-1px)}
    .iv-locked{background:#f8fafc}
    .iv-note{font-size:11px;color:var(--iv-muted)}
    .iv-field-error{display:block;min-height:16px;margin-top:5px;font-size:11px;line-height:1.35;color:#dc3545}
    .iv-field-invalid{border-color:#dc3545!important}
    .iv-field-invalid:focus{border-color:#dc3545!important;box-shadow:0 0 0 .2rem rgba(220,53,69,.10)!important}
    .iv-gender-error{margin-top:4px}
    .iv-alert{border-radius:13px;font-size:12px}
    .iv-footer{text-align:center;margin-top:18px;font-size:10px;color:#94a3b8}
    @media(max-width:575px){.iv-brand-title{font-size:20px}.iv-event-college{font-size:18px}.iv-form-card,.iv-brand-card{padding:16px}}
</style>

<div class="iv-scan-page">
    <div class="iv-scan-shell">
        <div class="iv-brand-card">
            <div class="d-flex align-items-center gap-3 position-relative" style="z-index:2">
                <img id="ivBrandLogo" class="iv-logo" src="{{ asset('assets/common/logo_small.png') }}" alt="Entity logo">
                <div class="min-w-0">
                    <div class="iv-brand-sub">Welcome</div>
                    <div class="iv-brand-title" id="ivBrandName">Industrial Visit</div>
                    <div class="iv-brand-sub" id="ivBrandHint">Please complete your attendance registration.</div>
                </div>
            </div>
        </div>

        <div id="ivPageError" class="alert alert-danger iv-alert mt-3 d-none"></div>

        <div id="ivRegistrationArea" class="d-none">
            <div class="iv-event-card mt-3" id="ivEventCard">
                <span class="iv-event-pill"><i class="mdi mdi-office-building-outline"></i> Industrial Visit</span>
                <div class="iv-event-college" id="ivCollegeName">—</div>
                <div class="iv-event-meta">
                    <span><i class="mdi mdi-calendar-outline me-1"></i><span id="ivVisitDate">—</span></span>
                    <span><i class="mdi mdi-domain me-1"></i><span id="ivEntityName">—</span></span>
                </div>
            </div>

            <div class="iv-form-card">
                <div class="iv-section-title"><i class="mdi mdi-account-school-outline me-1"></i> Student details</div>
                <form id="ivAttendeeForm" autocomplete="off" novalidate>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="iv-label">College</label>
                            <input type="text" class="form-control iv-control iv-locked" id="ivCollegeLocked" readonly>
                        </div>
                        <div class="col-md-8">
                            <label class="iv-label">Student name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control iv-control" id="studentName" maxlength="255" placeholder="Enter your full name">
                            <div class="iv-field-error" id="studentNameError"></div>
                        </div>
                        <div class="col-md-4">
                            <label class="iv-label">Year of passing <span class="text-danger">*</span></label>
                            <input type="text" class="form-control iv-control" id="passingYear" placeholder="Select year" inputmode="numeric" readonly>
                            <div class="iv-field-error" id="passingYearError"></div>
                        </div>

                        <div class="col-12">
                            <label class="iv-label">Gender <span class="text-danger">*</span></label>
                            <div class="iv-gender">
                                <div class="iv-gender-item"><input id="genderMale" type="radio" name="gender" value="1"><label for="genderMale"><i class="mdi mdi-gender-male"></i> Male</label></div>
                                <div class="iv-gender-item"><input id="genderFemale" type="radio" name="gender" value="2"><label for="genderFemale"><i class="mdi mdi-gender-female"></i> Female</label></div>
                            </div>
                            <div class="iv-field-error iv-gender-error" id="genderError"></div>
                        </div>

                        <div class="col-md-6">
                            <label class="iv-label">Degree / Qualification <span class="text-danger">*</span></label>
                            <select id="qualification" class="form-select select3 iv-control">
                                <option value="">Select Degree / Qualification</option>
                            </select>
                            <div class="iv-field-error" id="qualificationError"></div>
                        </div>
                        <div class="col-md-6" id="majorFieldWrap">
                            <label class="iv-label">Major <span id="majorRequiredMark" class="text-danger">*</span></label>
                            <select id="major" class="form-select select3 iv-control">
                                <option value="">Select Major</option>
                            </select>
                            <div class="iv-field-error" id="majorError"></div>
                        </div>

                        <div class="col-md-6">
                            <label class="iv-label">State <span class="text-danger">*</span></label>
                            <select id="state" class="form-select select3 iv-control">
                                <option value="">Select State</option>
                            </select>
                            <div class="iv-field-error" id="stateError"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="iv-label">City <span class="text-danger">*</span></label>
                            <select id="city" class="form-select select3 iv-control" disabled>
                                <option value="">Select City</option>
                            </select>
                            <div class="iv-field-error" id="cityError"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="iv-label">Mobile number <span class="text-danger">*</span></label>
                            <input type="tel" class="form-control iv-control" id="mobile" maxlength="10" inputmode="numeric" placeholder="Enter 10-digit mobile number">
                            <div class="iv-field-error" id="mobileError"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="iv-label">Email <span class="iv-major-optional">(optional)</span></label>
                            <input type="email" class="form-control iv-control" id="email" maxlength="255" placeholder="Enter email address">
                            <div class="iv-field-error" id="emailError"></div>
                        </div>

                    </div>

                    <!-- <div class="iv-alert alert alert-light border mt-3 mb-3">
                        <i class="mdi mdi-shield-check-outline me-1"></i>
                        Your details are used for Industrial Visit attendance records.
                    </div> -->

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary iv-submit" id="ivSubmitBtn">
                            <span id="ivSubmitLabel"><i class="mdi mdi-check-decagram-outline me-1"></i> Register My Visit</span>
                            <span id="ivSubmitLoading" class="d-none"><span class="spinner-border spinner-border-sm me-2"></span> Submitting...</span>
                        </button>
                    </div>
                    <div id="ivFormError" class="alert alert-danger iv-alert d-none mt-3 mb-0"></div>
                </form>
            </div>
        </div>

        <div id="ivLoading" class="text-center py-5">
            <div class="spinner-border mb-3" style="color:var(--iv-color)"></div>
            <div class="fw-semibold text-dark">Loading your Industrial Visit...</div>
            <div class="iv-note mt-1">Preparing the registration form.</div>
        </div>

        <!-- <div class="iv-footer">Powered by EGC HR Operations</div> -->
    </div>
</div>



<script>

    $(function () {
        'use strict';

        const urls = {
            details: @json(route('hr-industrial-visit.scan.details', ['token' => $token])),
            register: @json(route('hr-industrial-visit.scan.register', ['token' => $token])),
            majors: @json(route('hr-industrial-visit.scan.majors', ['qualificationId' => '__QUALIFICATION__'])),
            cities: @json(route('hr-industrial-visit.scan.cities', ['stateId' => '__STATE__']))
        };
        const csrf = $('meta[name="csrf-token"]').attr('content') || '';
        let visit = null;

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': csrf,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        });

        function escapeHtml(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function initYearPicker() {
       
            $('#passingYear').datepicker({
                format: "yyyy",
                viewMode: "years",
                minViewMode: "years",
                autoclose: true
            });
        }

        function loadQualificationOptions(qualifications) {
            const $select = $('#qualification');
            const order = { UG: 1, PG: 2 };

            const sorted = (qualifications || [])
                .filter(function (q) {
                    return Object.prototype.hasOwnProperty.call(
                        order,
                        String(q.name || '').trim().toUpperCase()
                    );
                })
                .slice()
                .sort(function (a, b) {
                    const aName = String(a.name || '').trim().toUpperCase();
                    const bName = String(b.name || '').trim().toUpperCase();
                    return order[aName] - order[bName];
                });

            $select.empty().append('<option value="">Select Degree / Qualification</option>');
            sorted.forEach(function (q) {
                $select.append($('<option>', { value: q.id, text: q.name }));
            });
            $select.trigger('change');
        }

        function loadMajors(qualificationId) {
            const $major = $('#major');
            clearFieldError('major');

            if (!qualificationId) {
                $major.empty().append('<option value="">Select Major</option>').prop('disabled', true).trigger('change');
                return;
            }

            $major.empty().append('<option value="">Loading majors...</option>').prop('disabled', true).trigger('change');

            $.getJSON(urls.majors.replace('__QUALIFICATION__', encodeURIComponent(qualificationId)))
                .done(function (response) {
                    $major.empty().append('<option value="">Select Major</option>');
                    (response.data || []).forEach(function (m) {
                        $major.append($('<option>', { value: m.id, text: m.name }));
                    });
                    $major.prop('disabled', false).trigger('change');
                })
                .fail(function (xhr) {
                    $major.empty().append('<option value="">Unable to load majors</option>').prop('disabled', false).trigger('change');
                    showFieldError('major', xhr.responseJSON?.message || 'Could not load major list.');
                });
        }

        function loadStateOptions(states, defaultStateId) {
            const $state = $('#state');
            $state.empty().append('<option value="">Select State</option>');

            (states || []).forEach(function (item) {
                $state.append($('<option>', { value: item.id, text: item.name }));
            });

            const desired = defaultStateId ? String(defaultStateId) : '';
            if (desired && $state.find('option[value="' + desired + '"]').length) {
                $state.val(desired).trigger('change');
            } else {
                $('#city').empty().append('<option value="">Select City</option>').prop('disabled', true).trigger('change');
            }
        }

        function loadCities(stateId) {
            const $city = $('#city');
            clearFieldError('city');
            $city.empty().append('<option value="">Loading cities...</option>').prop('disabled', true).trigger('change');

            if (!stateId) {
                $city.empty().append('<option value="">Select City</option>').prop('disabled', true).trigger('change');
                return;
            }

            $.getJSON(urls.cities.replace('__STATE__', encodeURIComponent(stateId)))
                .done(function (response) {
                    $city.empty().append('<option value="">Select City</option>');
                    (response.data || []).forEach(function (item) {
                        $city.append($('<option>', { value: item.id, text: item.name }));
                    });
                    $city.prop('disabled', false).trigger('change');
                })
                .fail(function (xhr) {
                    $city.empty().append('<option value="">Unable to load cities</option>').prop('disabled', false).trigger('change');
                    showFieldError('city', xhr.responseJSON?.message || 'Could not load city list.');
                });
        }

        function showPageError(message) {
            $('#ivLoading').addClass('d-none');
            $('#ivRegistrationArea').addClass('d-none');
            $('#ivPageError').removeClass('d-none').html('<strong>Registration unavailable.</strong><br>' + escapeHtml(message));
        }

        function loadDetails() {
            $.ajax({ url: urls.details, method: 'GET', dataType: 'json' })
                .done(function (response) {
                    if (!response.success || !response.data) {
                        showPageError(response.message || 'The QR code could not be loaded.');
                        return;
                    }
                    visit = response.data;
                    document.documentElement.style.setProperty('--iv-color', visit.entity_base_color || '#ab2b22');
                    $('#ivBrandLogo').attr('src', visit.entity_logo || '{{ asset('assets/common/logo_small.png') }}');
                    $('#ivBrandName').text(visit.entity_name || 'Industrial Visit');
                    $('#ivBrandHint').text('Please complete your attendance registration.');
                    $('#ivCollegeName').text(visit.college_name || 'College');
                    $('#ivCollegeLocked').val(visit.college_name || '');
                    $('#ivVisitDate').text(visit.iv_date || '—');
                    $('#ivEntityName').text(visit.entity_name || '—');
                    loadQualificationOptions(response.data.qualifications || []);
                    loadStateOptions(response.data.states || [], response.data.default_state_id || null);
                    $('#ivLoading').addClass('d-none');
                    $('#ivRegistrationArea').removeClass('d-none');
                })
                .fail(function (xhr) {
                    showPageError(xhr.responseJSON?.message || 'The QR code is invalid or the visit is inactive.');
                });
        }

        $('#qualification').on('change', function () {
            clearFieldError('qualification');
            clearFieldError('major');
            loadMajors($(this).val());
        });

        $('#state').on('change', function () {
            clearFieldError('state');
            clearFieldError('city');
            loadCities($(this).val());
        });

        $('#city').on('change', function () {
            clearFieldError('city');
        });

        $('#studentName, #passingYear, #email').on('input change', function () {
            clearFieldError($(this).attr('id'));
        });

        $('#genderMale, #genderFemale').on('change', function () {
            clearFieldError('gender');
        });

        $('#major').on('change', function () {
            clearFieldError('major');
        });


        function clearFieldError(field) {
            $('#' + field + 'Error').text('');
            if (field === 'fieldOfInterest') {
                $('#fieldOfInterestGroup').removeClass('iv-interest-invalid');
                return;
            }

            const selectors = {
                studentName: '#studentName',
                passingYear: '#passingYear',
                qualification: '#qualification',
                major: '#major',
                state: '#state',
                city: '#city',
                mobile: '#mobile',
                email: '#email'
            };

            if (selectors[field]) {
                $(selectors[field]).removeClass('iv-field-invalid');
            }
        }

        function showFieldError(field, message) {
            $('#' + field + 'Error').text(message || '');
            if (field === 'fieldOfInterest') {
                $('#fieldOfInterestGroup').addClass('iv-interest-invalid');
                return;
            }

            const selectors = {
                studentName: '#studentName',
                passingYear: '#passingYear',
                qualification: '#qualification',
                major: '#major',
                state: '#state',
                city: '#city',
                mobile: '#mobile',
                email: '#email'
            };

            if (selectors[field]) {
                $(selectors[field]).addClass('iv-field-invalid');
            }
        }

        function clearAllFieldErrors() {
            [
                'studentName',
                'passingYear',
                'gender',
                'qualification',
                'major',
                'state',
                'city',
                'mobile',
                'email'
            ].forEach(clearFieldError);

            $('#ivFormError').addClass('d-none').empty();
        }

        function validateStudentForm() {
            clearAllFieldErrors();

            const studentName = $('#studentName').val().trim();
            const passingYear = $('#passingYear').val().trim();
            const gender = $('input[name="gender"]:checked').val() || '';
            const qualificationId = $('#qualification').val();
            const majorId = $('#major').val();
            const stateId = $('#state').val();
            const cityId = $('#city').val();
            const mobile = $('#mobile').val().replace(/\D/g, '');
            const email = $('#email').val().trim();

            let valid = true;

            if (!studentName) {
                showFieldError('studentName', 'Please enter your full name.');
                valid = false;
            }

            if (!passingYear) {
                showFieldError('passingYear', 'Please select your year of passing.');
                valid = false;
            }

            if (!gender) {
                showFieldError('gender', 'Please select your gender.');
                valid = false;
            }

            if (!qualificationId) {
                showFieldError('qualification', 'Please select your degree / qualification.');
                valid = false;
            }

            if (qualificationId && !majorId) {
                showFieldError('major', 'Please select your major.');
                valid = false;
            }

            if (!stateId) {
                showFieldError('state', 'Please select your state.');
                valid = false;
            }

            if (!cityId) {
                showFieldError('city', 'Please select your city.');
                valid = false;
            }

            if (!/^\d{10}$/.test(mobile)) {
                showFieldError('mobile', 'Please enter a valid 10-digit mobile number.');
                valid = false;
            }

            if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                showFieldError('email', 'Please enter a valid email address.');
                valid = false;
            }

            return {
                valid: valid,
                payload: {
                    student_name: studentName,
                    gender: Number(gender),
                    qualification_id: qualificationId,
                    major_id: majorId,
                    year_of_passing: passingYear,
                    state_id: stateId,
                    city_id: cityId,
                    mobile: mobile,
                    email: email
                }
            };
        }

        function applyServerErrors(errors) {
            const fieldMap = {
                student_name: 'studentName',
                gender: 'gender',
                qualification_id: 'qualification',
                major_id: 'major',
                year_of_passing: 'passingYear',
                state_id: 'state',
                city_id: 'city',
                mobile: 'mobile',
                email: 'email'
            };

            Object.keys(errors || {}).forEach(function (key) {
                const field = fieldMap[key];
                const message = Array.isArray(errors[key]) ? errors[key][0] : errors[key];

                if (field) {
                    showFieldError(field, message);
                }
            });
        }

        $('#ivAttendeeForm').on('submit', function (event) {
            event.preventDefault();

            const result = validateStudentForm();
            if (!result.valid) return;

            $('#ivSubmitBtn').prop('disabled', true);
            $('#ivSubmitLabel').addClass('d-none');
            $('#ivSubmitLoading').removeClass('d-none');

            $.ajax({
                url: urls.register,
                method: 'POST',
                data: result.payload,
                dataType: 'json'
            }).done(function (response) {

                if (response.data?.redirect) {
                    window.location.replace(response.data.redirect);
                } else {
                    window.location.reload();
                }
            }).fail(function (xhr) {
                const response = xhr.responseJSON || {};
                const errors = response.errors || {};

                applyServerErrors(errors);

                const messages = Object.values(errors).flat();
                if (!messages.length) {
                    $('#ivFormError').removeClass('d-none').text(
                        response.message || 'Unable to submit your registration.'
                    );
                }

                $('#ivSubmitBtn').prop('disabled', false);
                $('#ivSubmitLabel').removeClass('d-none');
                $('#ivSubmitLoading').addClass('d-none');
            });
        });
        $('#mobile').on('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 10);
            clearFieldError('mobile');
        });

        initYearPicker();
        // applyMajorVisibility();
        loadDetails();
    });

</script>
@endsection
