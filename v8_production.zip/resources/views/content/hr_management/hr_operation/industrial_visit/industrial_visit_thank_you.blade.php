@extends('layouts/blankLayout')

@section('title', 'Industrial Visit Registration Complete')

@section('page-script')
<script src="https://cdn.jsdelivr.net/npm/@tsparticles/confetti@3.0.3/tsparticles.confetti.bundle.min.js"></script>
@endsection

@section('content')
<style>
    :root{--iv-color:{{ $visit->entity_base_color ?: '#ab2b22' }};}
    body{background:linear-gradient(135deg,#f8fafc,#eef2f7)}
    .iv-thanks{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;overflow:hidden}
    .iv-thanks-card{width:min(680px,100%);background:#fff;border:1px solid #e7ecf2;border-radius:28px;padding:30px;box-shadow:0 25px 80px rgba(15,23,42,.12);text-align:center;position:relative;z-index:2}
    .iv-thanks-logo{width:82px;height:82px;object-fit:contain;border-radius:20px;padding:8px;background:#fff;border:1px solid #e7ecf2;box-shadow:0 12px 30px rgba(15,23,42,.08)}
    .iv-check{width:90px;height:90px;margin:18px auto;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.05);color:var(--iv-color);font-size:42px;box-shadow:0 15px 35px rgba(15,23,42,.08)}
    .iv-thanks h1{font-size:31px;font-weight:900;letter-spacing:-.03em;color:#0f172a;margin-bottom:8px}
    .iv-thanks p{font-size:14px;line-height:1.75;color:#64748b;margin-bottom:8px}
    .iv-summary{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:22px 0;text-align:left}
    .iv-summary-box{padding:13px;border-radius:14px;background:#f8fafc;border:1px solid #e8edf4}
    .iv-summary-label{font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;font-weight:850}
    .iv-summary-value{font-size:13px;font-weight:800;color:#1e293b;margin-top:4px}
    .iv-redirect-message{font-size:12px;color:var(--iv-color);font-weight:700;margin-top:14px}
    .iv-note{font-size:10px;color:#94a3b8;margin-top:18px}
    @media(max-width:575px){.iv-summary{grid-template-columns:1fr}.iv-thanks-card{padding:22px}.iv-thanks h1{font-size:26px}}
</style>

<div class="iv-thanks">
    <div class="iv-thanks-card">
        <img class="iv-thanks-logo" src="{{ $displayLogo ?? ($visit->entity_logo ?: asset('assets/common/logo_small.png')) }}" alt="Entity logo">
        <div class="small text-muted fw-semibold mt-3">{{ $visit->entity_name }}</div>
        <div class="iv-check bg-label-success"><i class="mdi mdi-check-decagram-outline fs-1 "></i></div>
        <h1>Thank You!</h1>
        <p>Thank you, <strong>{{ $attendee->student_name }}</strong>, for visiting {{ $visit->entity_name }}.</p>

        @if($visit->google_review_link)
            <div class="iv-redirect-message">Thank you for visiting us. You will be redirected to share your feedback in <strong id="ivRedirectCountdown">3</strong> seconds...</div>
        @endif

        <div class="iv-summary">
            <div class="iv-summary-box"><div class="iv-summary-label">College</div><div class="iv-summary-value">{{ $visit->college_name }}</div></div>
            <div class="iv-summary-box"><div class="iv-summary-label">Visit Date</div><div class="iv-summary-value">{{ \Carbon\Carbon::parse($visit->iv_date)->format('d-M-Y') }}</div></div>
        </div>


        <div class="iv-note">We appreciate your time and interest in our company.</div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Confetti is optional; it must never block the redirect timer.
    if (typeof confetti !== 'undefined') {
        const celebrationDuration = 5500;
        const celebrationEnd = Date.now() + celebrationDuration;

        function burst(originX, angle) {
            confetti({
                particleCount: 24,
                spread: 70,
                startVelocity: 40,
                angle: angle,
                origin: { x: originX, y: 0.62 },
                scalar: 0.9,
                ticks: 160
            });
        }

        burst(0.15, 60);
        burst(0.85, 120);

        (function frame() {
            confetti({
                particleCount: 4,
                spread: 85,
                origin: { x: Math.random(), y: Math.random() * 0.35 + 0.15 },
                scalar: 0.8,
                ticks: 120
            });
            if (Date.now() < celebrationEnd) requestAnimationFrame(frame);
        })();
    }

    const feedbackUrl = @json($visit->google_review_link);
    if (feedbackUrl && /^https?:\/\//i.test(feedbackUrl)) {
        let remaining = 3;
        const countdown = document.getElementById('ivRedirectCountdown');

        const timer = setInterval(function () {
            remaining -= 1;
            if (countdown) countdown.textContent = String(Math.max(remaining, 0));

            if (remaining <= 0) {
                clearInterval(timer);
                window.location.replace(feedbackUrl);
            }
        }, 1000);
    }
});
</script>
@endsection
