@extends('layouts/layoutMaster')

@section('title', 'Manage Industrial Visit')

@section('vendor-style')
@vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
@endsection

@section('content')
<style>
    .iv-page-card{border:0;border-radius:18px;overflow:hidden;box-shadow:0 10px 35px rgba(15,23,42,.07)}
    .iv-hero{
        background:#fff;
        /* background:linear-gradient(135deg,#ab2b22 0%,#6f1712 100%); */
        /* color:#fff; */
        border-radius:18px;
        padding:24px;
        position:relative;
        overflow:hidden
    }
    .iv-hero:after{content:"";position:absolute;width:280px;height:280px;border-radius:50%;right:-90px;top:-120px;background:rgba(255,255,255,.09)}
    .iv-stat{background:#fff;border:1px solid #e9eef5;border-radius:15px;padding:16px;box-shadow:0 8px 25px rgba(15,23,42,.05)}
    .iv-stat .label{font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:800;color:#64748b}
    .iv-stat .value{font-size:24px;font-weight:800;color:#0f172a;margin-top:4px}
    .iv-toolbar{
        /* background:#f8fafc;
        border:1px solid #e8edf4;
        border-radius:15px; */
        /* padding:13px */
    }
    .iv-table-wrap{
        /* border:1px solid #e7ecf2; */
        /* border-radius:15px; */
        /* overflow:hidden */
    }
    .iv-table thead th{
        font-size:11px;text-transform:uppercase;
        letter-spacing:.06em;font-weight:800;
        white-space:nowrap;
        border-bottom:1px solid #e7ecf2
    }
    .iv-table tbody td{vertical-align:middle;border-color:#edf1f5}
    .iv-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;color:#64748b}
    .iv-college{font-weight:750;color:#0f172a}
    .iv-entity{font-weight:650;color:#334155}
    .iv-date-pill{display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:999px;background:#fff7ed;color:#9a3412;font-size:11px;font-weight:800}
    .iv-count-pill{display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:999px;background:#eff6ff;color:#1d4ed8;font-size:11px;font-weight:800}
    .iv-action-btn{width:36px;height:36px;border-radius:10px;display:inline-flex;align-items:center;justify-content:center}
    .iv-form-control{min-height:44px;border-radius:11px;border-color:#d8e0ea}
    .iv-label{font-size:12px;font-weight:800;color:#334155;margin-bottom:7px}
    .iv-required{color:#dc2626}
    .iv-help{font-size:11px;color:#64748b;margin-top:5px}
    .iv-modal .modal-content{border:0;border-radius:20px;box-shadow:0 25px 70px rgba(15,23,42,.18)}
    .iv-modal .modal-header{border:0;padding:20px 22px 8px}
    .iv-modal .modal-footer{border:0;padding:8px 22px 20px}
    .iv-empty{padding:55px 20px;text-align:center;color:#64748b}
    .iv-spinner{width:1rem;height:1rem;border:.16em solid currentColor;border-right-color:transparent;border-radius:50%;display:inline-block;animation:ivspin .7s linear infinite}
    @keyframes ivspin{to{transform:rotate(360deg)}}

    .iv-attendee-modal .modal-content{border:0;border-radius:22px;overflow:hidden;box-shadow:0 28px 90px rgba(15,23,42,.22)}
    .iv-attendee-head{
        /* background:var(--iv-attendee-color,#ab2b22); */
        color:#fff;
        padding:20px 22px;
        position:relative;
        overflow:hidden
    }
    /* .iv-attendee-head:after{
        content:"";
        position:absolute;
        width:180px;
        height:180px;
        right:-70px;
        top:-95px;
        border-radius:50%;
        background:rgba(255,255,255,.09)
    } */
    .iv-attendee-logo{width:52px;height:52px;border-radius:14px;background:#fff;object-fit:contain;padding:5px;box-shadow:0 7px 18px rgba(0,0,0,.16)}
    .iv-attendee-title{font-size:20px;font-weight:850;letter-spacing:-.02em}
    .iv-attendee-meta{font-size:11px;color:rgba(255,255,255,.78)}
    .iv-attendee-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;padding:14px;background:#f8fafc;border-bottom:1px solid #e8edf4}
    .iv-attendee-summary-card{background:#fff;border:1px solid #e7ecf2;border-radius:14px;padding:12px 13px}
    .iv-attendee-summary-card .label{font-size:9px;text-transform:uppercase;letter-spacing:.08em;font-weight:800;color:#94a3b8}
    .iv-attendee-summary-card .value{font-size:18px;font-weight:850;color:#0f172a;margin-top:2px}
    .iv-attendee-toolbar{padding:13px 14px;border-bottom:1px solid #edf1f5;background:#fff}
    .iv-attendee-table thead th{font-size:10px;text-transform:uppercase;letter-spacing:.05em;font-weight:800;white-space:nowrap;border-bottom:1px solid #e8edf4}
    .iv-attendee-table tbody td{vertical-align:top;border-color:#edf1f5;font-size:12px}
    .iv-attendee-name{font-weight:800;color:#0f172a}
    .iv-attendee-sub{font-size:10px;color:#64748b;margin-top:2px}
    .iv-attendee-badge{display:inline-flex;align-items:center;padding:4px 7px;border-radius:999px;background:#f1f5f9;color:#334155;font-size:10px;font-weight:750}
    .iv-attendee-contact a{text-decoration:none}
    @media(max-width:767.98px){.iv-attendee-summary{grid-template-columns:1fr 1fr}.iv-attendee-table{min-width:980px}}

    .iv-college-modal .modal-content{border:0;border-radius:22px;overflow:hidden;box-shadow:0 28px 90px rgba(15,23,42,.20)}
    .iv-college-head{background:#f8fafc;border-bottom:1px solid #e8edf4;padding:18px 22px}
    .iv-college-form{background:#f8fafc;border:1px solid #e7ecf2;border-radius:15px;padding:15px}
    .iv-college-form-title{font-size:13px;font-weight:850;color:#0f172a}
    .iv-college-desc{font-size:12px;color:#64748b;line-height:1.55;max-width:460px;white-space:normal}
    .iv-college-status{display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border-radius:999px;font-size:10px;font-weight:850}
    .iv-college-status.active{background:#ecfdf5;color:#047857}
    .iv-college-status.inactive{background:#fef2f2;color:#b91c1c}
    .iv-college-toggle{width:2.25rem!important;height:1.15rem!important;cursor:pointer}
    .iv-copy-btn{min-height:42px;border-radius:11px}

    .iv-poster-shell{background:#e2e8f0;padding:22px;border-radius:18px;display:flex;justify-content:center}
    .iv-poster{width:390px;min-height:610px;background:#fff;border-radius:22px;overflow:hidden;position:relative;box-shadow:0 18px 50px rgba(15,23,42,.18)}
    .iv-poster-band{height:115px;background:var(--iv-color,#ab2b22);position:relative;padding:22px;color:#fff}
    .iv-poster-band:after{content:"";position:absolute;width:160px;height:160px;right:-55px;top:-70px;background:rgba(255,255,255,.08);border-radius:50%}
    .iv-poster-brand{display:flex;align-items:center;gap:10px;position:relative;z-index:2}
    .iv-poster-logo{width:52px;height:52px;border-radius:14px;background:#fff;object-fit:contain;padding:5px;box-shadow:0 6px 18px rgba(0,0,0,.15)}
    .iv-poster-title{font-size:22px;font-weight:850;letter-spacing:-.02em}
    .iv-poster-sub{font-size:10px;opacity:.82;text-transform:uppercase;letter-spacing:.11em;font-weight:800}
    .iv-poster-body{padding:24px}
    .iv-poster-label{font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;font-weight:800}
    .iv-poster-value{font-size:16px;font-weight:800;color:#0f172a;margin-top:3px}
    .iv-qr-card{margin:20px auto;padding:17px;width:235px;border:1px solid #e7ecf2;border-radius:20px;background:#fff;box-shadow:0 12px 30px rgba(15,23,42,.07);text-align:center}
    #ivQrCanvas{display:flex;justify-content:center;align-items:center;min-height:200px}
    #ivQrCanvas img,#ivQrCanvas canvas{max-width:200px!important;height:auto!important;margin:auto}
    .iv-scan-text{font-size:12px;font-weight:800;color:#334155;margin-top:12px}
    .iv-poster-footer{margin-top:10px;padding-top:17px;border-top:1px dashed #dbe2ea;font-size:10px;line-height:1.5;color:#64748b}
    .iv-poster-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10px;color:#94a3b8}

    @media(max-width:767.98px){
        .iv-hero{padding:18px}
        .iv-poster{width:100%;max-width:390px}
        .iv-poster-shell{padding:10px}
    }
</style>

<div class="container-xxl flex-grow-1 py-2">
    <div class="iv-hero mb-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 position-relative" style="z-index:2">
            <div>
                <div class="text-black-50 small fw-semibold mb-1">HR Operations</div>
                <h4 class="text-black mb-1 fw-bold">Manage Industrial Visit</h4>
                <!-- <div class="text-white-50 small">Create visit QR codes and capture student attendance digitally.</div> -->
            </div>
            <div class="d-flex flex-wrap gap-2">
                <button type="button" class="btn btn-outline-primary fw-bold" id="ivManageCollegeBtn">
                    <i class="mdi mdi-cog-outline me-1"></i> Manage College
                </button>
                <button type="button" class="btn btn-primary fw-bold" id="ivAddBtn">
                    <i class="mdi mdi-plus me-1"></i> Add Industrial Visit
                </button>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="iv-stat"><div class="label">Total Visits</div><div class="value" id="ivStatVisits">0</div></div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="iv-stat"><div class="label">Today Visits</div><div class="value" id="ivStatToday">0</div></div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="iv-stat"><div class="label">Students Registered</div><div class="value" id="ivStatAttendees">0</div></div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="iv-stat"><div class="label">Active Entities</div><div class="value" id="ivStatEntities">0</div></div>
        </div>
    </div>

    <div class="card iv-page-card">
        <div class="card-body p-3 p-lg-4">
            <div class="iv-toolbar mb-3 px-4 py-2">
                <div class="row g-2 align-items-end">
                    <div class="col-xl-1 col-lg-1">
                        <div>
                            <label class="iv-label">Show</label>
                            <select id="perpage" class="form-select form-select-sm w-75px select3"
                                onchange="loadData(1)">
                                @php $options = [25, 50, 100, 500]; @endphp
                                @foreach ($options as $option)
                                <option value="{{ $option }}">
                                    {{ $option }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3">
                        <label class="iv-label">Search</label>
                        <input type="text" class="form-control iv-form-control" id="ivSearch" placeholder="IV code, college or entity">
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6">
                        <label class="iv-label">College</label>
                        <select class="form-select select3 iv-form-control" id="ivCollegeFilter">
                            <option value="">All Colleges</option>
                        </select>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-6">
                        <label class="iv-label">Entity</label>
                        <select class="form-select select3 iv-form-control" id="ivEntityFilter">
                            <option value="">All Entities</option>
                        </select>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-6">
                        <label class="iv-label">IV Date</label>
                        <input type="text" class="form-control iv-form-control" id="ivDateFilter" placeholder="Select date">
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-6">
                        <button type="button" class="btn btn-secondary w-100" id="ivResetBtn" title="Reset filters">
                            <i class="mdi mdi-refresh"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="iv-table-wrap">
                <div class="table-responsive">
                    <table class="table iv-table mb-0">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <!-- <th>IV</th> -->
                                <th>College</th>
                                <th>Date</th>
                                <th>Entity</th>
                                <th class="text-center">Attendees</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="ivTableBody">
                            <tr><td colspan="5" class="iv-empty"><span class="iv-spinner me-2"></span> Loading Industrial Visits...</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- Create IV -->
<div class="modal fade iv-modal" id="ivCreateModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="small text-muted fw-semibold">HR Operations</div>
                    <h5 class="modal-title fw-bold">Create Industrial Visit</h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="ivCreateForm">
                <div class="modal-body px-4 pb-2">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="iv-label">Industrial Visit Date <span class="iv-required">*</span></label>
                            <input type="text" id="ivDate" name="iv_date" class="form-control iv-form-control" autocomplete="off" required>
                            <div class="iv-help">Defaults to today.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="iv-label">College <span class="iv-required">*</span></label>
                            <select id="ivCollege" name="college_id" class="form-select select3 iv-form-control" required>
                                <option value="">Select College</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="iv-label">Visit Entity <span class="iv-required">*</span></label>
                            <select id="ivEntity" name="entity_id" class="form-select select3 iv-form-control" required>
                                <option value="">Select Entity</option>
                            </select>
                            <!-- <div class="iv-help">Value <strong>0</strong> is the main company and uses the General Settings title/logo/review link.</div> -->
                        </div>
                    </div>

                    <div class="mt-4 p-3 rounded-4 bg-label-primary border rounded" id="ivEntityPreviewBox" style="display:none;">
                        <div class="d-flex align-items-center gap-3">
                            <img id="ivEntityPreviewLogo" src="{{ asset('assets/common/logo_small.png') }}" alt="Entity logo" style="width:54px;height:54px;object-fit:contain;border-radius:14px;background:#fff;padding:5px;border:1px solid #e7ecf2">
                            <div class="min-w-0">
                                <div class="small text-muted">Selected entity</div>
                                <div class="fw-bold text-dark" id="ivEntityPreviewName">—</div>
                                <div class="small text-muted" id="ivEntityPreviewReview">Google review link will be captured for the visit QR.</div>
                                <a id="ivEntityPreviewReviewLink" class="small fw-bold d-none" target="_blank" rel="noopener noreferrer">Open Google Review <i class="mdi mdi-open-in-new ms-1"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="alert alert-danger mt-3 d-none" id="ivCreateError"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary fw-bold" id="ivSaveBtn">
                        <span class="iv-save-label"><i class="mdi mdi-content-save-outline me-1"></i> Create Visit</span>
                        <span class="iv-save-loading d-none"><span class="iv-spinner me-2"></span> Creating...</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- College Management -->
<div class="modal fade iv-college-modal iv-modal" id="ivCollegeModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered ">
        <div class="modal-content">
            <div class="iv-college-head rounded-top">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div class="d-flex align-items-center gap-3">
                        <div class="btn btn-label-primary rounded-circle p-2 d-flex align-items-center justify-content-center" style="width:42px;height:42px">
                            <i class="mdi mdi-school-outline fs-5"></i>
                        </div>
                        <div>
                            <div class="small text-muted fw-semibold">HR Operations</div>
                            <h5 class="mb-0 fw-bold">Manage College</h5>
                            <div class="small text-muted mt-1">Add, update and activate or deactivate colleges used for Industrial Visits.</div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-primary fw-bold" id="ivAddCollegeBtn">
                        <i class="mdi mdi-plus me-1"></i> Add College
                    </button>
                </div>
            </div>

            <div class="modal-body px-3 px-lg-4 py-3">
                <div id="ivCollegeFormPanel" class="iv-college-form mb-3 d-none">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                        <div>
                            <div class="iv-college-form-title" id="ivCollegeFormTitle">Add College</div>
                            <div class="small text-muted">Only college name and description are required here.</div>
                        </div>
                        <button type="button" class="btn btn-sm btn-light" id="ivCollegeFormCloseBtn">Cancel</button>
                    </div>
                    <form id="ivCollegeForm" novalidate>
                        <input type="hidden" id="ivCollegeId">
                        <div class="row g-3 align-items-end">
                            <div class="col-lg-5">
                                <label class="iv-label">College Name <span class="iv-required">*</span></label>
                                <input type="text" id="ivCollegeNameInput" class="form-control iv-form-control" maxlength="255" autocomplete="off" placeholder="Enter college name" required>
                                <div class="small text-danger mt-1 d-none" id="ivCollegeNameError"></div>
                            </div>
                            <div class="col-lg-5">
                                <label class="iv-label">College Description</label>
                                <textarea id="ivCollegeDescInput" class="form-control iv-form-control" rows="2" maxlength="5000" placeholder="Enter college description"></textarea>
                                <div class="small text-danger mt-1 d-none" id="ivCollegeDescError"></div>
                            </div>
                            <div class="col-lg-2">
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary fw-bold" id="ivCollegeSaveBtn">
                                        <span id="ivCollegeSaveLabel"><i class="mdi mdi-content-save-outline me-1"></i> Save College</span>
                                        <span id="ivCollegeSaveLoading" class="d-none"><span class="iv-spinner me-2"></span> Saving...</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-danger iv-alert d-none mt-3 mb-0" id="ivCollegeFormError"></div>
                    </form>
                </div>

                <div class="iv-toolbar mb-3 px-3 py-2">
                    <div class="row g-2 align-items-end">
                        <div class="col-xl-2 col-lg-2 col-md-3">
                            <label class="iv-label">Show</label>
                            <select id="ivCollegePerpage" class="form-select form-select-sm select3">
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="500">500</option>
                            </select>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-5">
                            <label class="iv-label">Search</label>
                            <input type="text" id="ivCollegeSearch" class="form-control iv-form-control" placeholder="Search college name or description">
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-2">
                            <label class="iv-label">Status</label>
                            <select id="ivCollegeStatusFilter" class="form-select iv-form-control select3">
                                <option value="">All Status</option>
                                <option value="0">Active</option>
                                <option value="1">Inactive</option>
                            </select>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-2">
                            <button type="button" class="btn btn-secondary w-100" id="ivCollegeResetBtn" title="Reset college filters">
                                <i class="mdi mdi-refresh me-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>

                <div class="iv-table-wrap">
                    <div class="table-responsive">
                        <table class="table iv-table mb-0">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th>#</th>
                                    <th>College</th>
                                    <th>Description</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="ivCollegeTableBody">
                                <tr><td colspan="5" class="iv-empty"><span class="iv-spinner me-2"></span> Loading colleges...</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center my-3" id="ivCollegePaginationContainer">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- QR Poster -->
<div class="modal fade iv-modal" id="ivQrModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="small text-muted fw-semibold">Industrial Visit QR</div>
                    <h5 class="modal-title fw-bold">Scan & Register Poster</h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-2">
                <div class="row g-4 align-items-center">
                    <div class="col-lg-7">
                        <div class="iv-poster-shell">
                            <div class="iv-poster" id="ivPoster" style="--iv-color:#ab2b22;">
                                <div class="iv-poster-band">
                                    <div class="iv-poster-brand">
                                        <img id="ivPosterLogo" class="iv-poster-logo" src="{{ asset('assets/common/logo_small.png') }}" alt="Entity logo">
                                        <div>
                                            <div class="iv-poster-sub">You are invited to</div>
                                            <div class="iv-poster-title">Industrial Visit</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="iv-poster-body">
                                    <div class="iv-poster-label">College</div>
                                    <div class="iv-poster-value" id="ivPosterCollege">—</div>

                                    <div class="row mt-3 g-3">
                                        <div class="col-6">
                                            <div class="iv-poster-label">Visit Date</div>
                                            <div class="iv-poster-value" id="ivPosterDate">—</div>
                                        </div>
                                        <div class="col-6">
                                            <div class="iv-poster-label">Company</div>
                                            <div class="iv-poster-value" id="ivPosterEntity">—</div>
                                        </div>
                                    </div>

                                    <div class="iv-qr-card">
                                        <div id="ivQrCanvas"></div>
                                        <div class="iv-scan-text">Scan this QR to register your visit</div>
                                        <!-- <div class="iv-poster-code mt-2" id="ivPosterCode">—</div> -->
                                    </div>

                                    <div class="text-center small fw-semibold text-muted">Your details help us maintain an accurate Industrial Visit attendance record.</div>
                                    <div class="iv-poster-footer">Please scan using your phone camera. The registration form will open with your college and visit details already selected.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="p-3 rounded-4 bg-label-light border rounded">
                            <div class="small text-muted mb-1">Registration Link</div>
                            <button type="button" class="btn btn-outline-primary w-100 fw-bold iv-copy-btn" id="ivQrCopyUrlBtn">
                                <i class="mdi mdi-content-copy me-1"></i> Copy QR URL
                            </button>
                            <div class="small text-muted mt-2" id="ivQrCopyStatus">Copy the registration link to share it digitally.</div>
                        </div>
                        <div class="d-grid gap-2 mt-3">
                            <button type="button" class="btn btn-primary fw-bold" id="ivDownloadPosterBtn">
                                <i class="mdi mdi-download me-1"></i> Download
                            </button>
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        </div>
                        <!-- <div class="small text-muted mt-3">The downloaded QR contains the entity logo and QR code and can be printed or shared digitally.</div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Attendees Detail -->
<div class="modal fade iv-attendee-modal" id="ivAttendeesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content" id="ivAttendeesModalContent" style="--iv-attendee-color:#ab2b22;">
            <div class="iv-attendee-head bg-label-primary rounded-top">
                <div class="d-flex align-items-center gap-3 position-relative" style="z-index:2">
                    <img id="ivAttendeeLogo" class="iv-attendee-logo" src="{{ asset('assets/common/logo_small.png') }}" alt="Entity logo">
                    <div class="min-w-0">
                        <div class="small text-black fw-semibold">Industrial Visit Attendance</div>
                        <div class="iv-attendee-title" id="ivAttendeeModalTitle">Attendees</div>
                        <div class="iv-attendee-meta text-black" id="ivAttendeeModalMeta">—</div>
                    </div>
                </div>
                <button type="button" class="btn-close btn-close-dark position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close" style="z-index:3"></button>
            </div>
            <div class="iv-attendee-summary">
                <div class="iv-attendee-summary-card"><div class="label">Total Registered</div><div class="value" id="ivAttendeeTotal">0</div></div>
                <div class="iv-attendee-summary-card"><div class="label">Male</div><div class="value" id="ivAttendeeMale">0</div></div>
                <div class="iv-attendee-summary-card"><div class="label">Female</div><div class="value" id="ivAttendeeFemale">0</div></div>
                <div class="iv-attendee-summary-card"><div class="label">Others</div><div class="value" id="ivAttendeeOthers">0</div></div>
            </div>
            <div class="iv-attendee-toolbar px-5">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                    <div class="fw-bold text-dark"><i class="mdi mdi-account-group-outline me-1"></i> Student Details</div>
                    <div style="min-width:min(100%,360px)">
                        <div class="input-group">
                            <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                            <input type="text" id="ivAttendeeSearch" class="form-control" placeholder="Search name, mobile, email, degree or major">
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive px-5">
                <table class="table iv-attendee-table mb-0">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th>#</th>
                            <th>Student</th>
                            <th>Gender</th>
                            <th>Degree / Major</th>
                            <th>Passing Year</th>
                            <th>Mobile / Email</th>
                            <th>State / City</th>
                            <!-- <th>Registered At</th> -->
                        </tr>
                    </thead>
                    <tbody id="ivAttendeeTableBody">
                        <tr><td colspan="7" class="iv-empty"><span class="iv-spinner me-2"></span> Loading attendees...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="text-center my-2 px-5" id="ivAttendeePaginationContainer">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<script>
$(function () {
    'use strict';

    const csrf = $('meta[name="csrf-token"]').attr('content') || '';
    const urls = {
        lookups: @json(route('hr-industrial-visit.lookups')),
        majors: @json(route('hr-industrial-visit.majors', ['qualificationId' => '__QUALIFICATION__'])),
        data: @json(route('hr-industrial-visit.data')),
        store: @json(route('hr-industrial-visit.store')),
        attendees: @json(route('hr-industrial-visit.attendees', ['id' => '__ID__'])),
        colleges: @json(route('hr-industrial-visit.colleges')),
        collegeStore: @json(route('hr-industrial-visit.colleges.store')),
        collegeUpdate: @json(route('hr-industrial-visit.colleges.update', ['id' => '__ID__'])),
        collegeToggle: @json(route('hr-industrial-visit.colleges.toggle-status', ['id' => '__ID__']))
    };

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': csrf,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
        }
    });

    const state = {
        page: 1,
        perpage: 25,
        search: '',
        college_id: '',
        entity_id: '',
        date: '',
        rows: {}
    };

    let searchTimer = null;
    let attendeeSearchTimer = null;
    let activeQr = null;
    let activeAttendeeVisitId = null;
    let attendeePage = 1;
    let collegePage = 1;
    let collegeSearchTimer = null;

    const createModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('ivCreateModal'));
    const qrModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('ivQrModal'));
    const attendeesModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('ivAttendeesModal'));
    const collegeModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('ivCollegeModal'));

    function showError(message) {
        if (window.toastr) toastr.error(message);
        else console.error('[Industrial Visit]', message);
    }

    function populateSelect($select, items, placeholder, includeMainCompany) {
        $select.empty().append($('<option>', { value: '', text: placeholder }));
        (items || []).forEach(function (item) {
            $select.append($('<option>', { value: item.id, text: item.name }));
        });
        if ($select.hasClass('select2-hidden-accessible')) {
            $select.trigger('change.select2');
        }
    }

    function loadLookups() {
        return $.getJSON(urls.lookups).done(function (response) {
            if (!response.success) throw new Error(response.message || 'Lookup loading failed.');

            const d = response.data || {};
            const colleges = (d.colleges || []).map(function (c) {
                return { id: c.sno, name: c.college_name };
            });

            populateSelect($('#ivCollege'), colleges, 'Select College');
            populateSelect($('#ivCollegeFilter'), colleges, 'All Colleges');

            const entities = (d.entities || []).map(function (e) {
                return { id: e.id, name: e.name, logo: e.logo || '', review: !!e.google_review_link };
            });
            window.ivEntities = d.entities || [];

            populateSelect($('#ivEntity'), entities, 'Select Entity');
            populateSelect($('#ivEntityFilter'), entities, 'All Entities');

            const today = d.today || '{{ now()->format('Y-m-d') }}';
            if (!$('#ivDate').val()) $('#ivDate').val(today);
        }).fail(function (xhr) {
            showError(xhr.responseJSON?.message || 'Could not load Industrial Visit lookups.');
        });
    }

    function loadStats() {
        $.ajax({
            url: urls.data,
            method: 'GET',
            data: { page: 1, perpage: 500, search: '', college_id: '', entity_id: '', date: '' }
        }).done(function (response) {
            const items = response.data || [];
            const today = new Date().toISOString().slice(0, 10);
            $('#ivStatVisits').text(response.pagination?.total || 0);
            $('#ivStatToday').text(items.filter(x => x.iv_date_raw === today).length);
            $('#ivStatAttendees').text(items.reduce((sum, x) => sum + Number(x.attendee_count || 0), 0));
        });

        $.ajax({ url: urls.lookups, method: 'GET' }).done(function (response) {
            $('#ivStatEntities').text(Math.max(0, Number(response.data?.entities?.length || 1) - 1));
        });
    }

    function renderRows(items) {
        state.rows = {};
        const $body = $('#ivTableBody');

        if (!items.length) {
            $body.html('<tr><td colspan="5" class="iv-empty"><i class="mdi mdi-calendar-remove-outline fs-1 d-block mb-2"></i>No Industrial Visits found.</td></tr>');
            return;
        }

        items.forEach(function (row) { state.rows[row.id] = row; });

        $body.html(items.map(function (row) {
            return `
                <tr>
                    <!-- <td>
                        <div class="fw-bold text-dark">${escapeHtml(row.iv_code)}</div>
                        <div class="iv-code">#${row.id}</div>
                    </td> -->
                    <td><div class="iv-college">${escapeHtml(row.college_name)}</div></td>
                    <td><span class="iv-date-pill"><i class="mdi mdi-calendar-outline"></i>${escapeHtml(row.iv_date)}</span></td>
                    <td><div class="iv-entity">${escapeHtml(row.entity_name)}</div></td>
                    <td class="text-center">
                        <span  class="badge bg-success rounded  js-iv-attendees cursor-pointer " data-id="${row.id}" title="View attendees">
                            <i class="mdi mdi-account-group-outline"></i>${Number(row.attendee_count || 0).toLocaleString()}
                        </span>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-light-primary iv-action-btn js-iv-qr shadow-none text-black border border-rounded" data-id="${row.id}" title="Open QR poster">
                            <i class="mdi mdi-qrcode"></i>
                        </button>
                    </td>
                </tr>`;
        }).join(''));
    }

    function escapeHtml(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function renderPagination(p) {
        const current = Number(p.current_page || 1);
        const last = Number(p.last_page || 1);
        const total = Number(p.total || 0);
        const start = total ? ((current - 1) * Number(p.per_page || state.perpage)) + 1 : 0;
        const end = Math.min(current * Number(p.per_page || state.perpage), total);
        $('#ivPaginationInfo').text(total ? `Showing ${start}–${end} of ${total}` : 'Showing 0 records');

        let html = '';
        const from = Math.max(1, current - 2);
        const to = Math.min(last, current + 2);
        if (current > 1) html += `<button class="btn btn-sm btn-light js-iv-page" data-page="${current - 1}"><i class="mdi mdi-chevron-left"></i></button>`;
        for (let i = from; i <= to; i++) html += `<button class="btn btn-sm ${i === current ? 'btn-primary' : 'btn-light'} js-iv-page" data-page="${i}">${i}</button>`;
        if (current < last) html += `<button class="btn btn-sm btn-light js-iv-page" data-page="${current + 1}"><i class="mdi mdi-chevron-right"></i></button>`;
        $('#ivPagination').html(html);
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadData(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadData(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadData(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadData(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadData(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function loadData(page) {
        state.page = page || state.page || 1;
        let perPage =$('#perpage').val() || 25;
        $('#ivTableBody').html('<tr><td colspan="6" class="iv-empty"><span class="iv-spinner me-2"></span> Loading Industrial Visits...</td></tr>');
        $.ajax({
            url: urls.data,
            method: 'GET',
            data: {
                page: state.page,
                perpage: perPage,
                search: state.search,
                college_id: state.college_id || null,
                entity_id: state.entity_id === '' ? null : state.entity_id,
                date: state.date || null
            }
        }).done(function (response) {
            renderRows(response.data || []);
            // renderPagination(response.pagination || {});
            let paginate = response.pagination || {};
            if(paginate){
                updatePagination(paginate.current_page, paginate.last_page, paginate.total, paginate.per_page);
            }
            
            $('#ivStatVisits').text(response.pagination?.total || 0);
        }).fail(function (xhr) {
            showError(xhr.responseJSON?.message || 'Could not load Industrial Visits.');
            $('#ivTableBody').html('<tr><td colspan="6" class="iv-empty text-danger">Unable to load Industrial Visits.</td></tr>');
        });
    }

    function initDatePickers() {
        flatpickr('#ivDate', {
            dateFormat: 'Y-m-d',
            minDate: 'today',
            defaultDate: new Date(),
            allowInput: false
        });

        flatpickr('#ivDateFilter', {
            dateFormat: 'Y-m-d',
            allowInput: false,
            onChange: function (selectedDates, dateStr) {
                state.date = dateStr || '';
                state.page = 1;
                loadData(1);
            }
        });
    }

    function setCreateLoading(isLoading) {
        $('#ivSaveBtn').prop('disabled', isLoading);
        $('.iv-save-label').toggleClass('d-none', isLoading);
        $('.iv-save-loading').toggleClass('d-none', !isLoading);
    }

    function showSelectedEntity() {
        const id = $('#ivEntity').val();
        const selected = $('#ivEntity option:selected').text();
        if (id === '') {
            $('#ivEntityPreviewBox').hide();
            return;
        }

        const entity = (window.ivEntities || []).find(x => String(x.id) === String(id));
        $('#ivEntityPreviewName').text(selected || '—');
        $('#ivEntityPreviewLogo').attr('src', entity?.logo || '{{ asset('assets/common/logo_small.png') }}');
        $('#ivEntityPreviewReview').text(entity?.google_review_link ? 'Google review link configured for this entity.' : 'No Google review link is configured for this entity.');
        if (entity?.google_review_link) {
            $('#ivEntityPreviewReviewLink').attr('href', entity.google_review_link).removeClass('d-none');
        } else {
            $('#ivEntityPreviewReviewLink').attr('href', '#').addClass('d-none');
        }
        $('#ivEntityPreviewBox').show();
    }

    function openQr(row) {
        activeQr = row;
        $('#ivPoster').css('--iv-color', row.entity_base_color || '#ab2b22');
        $('#ivPosterCollege').text(row.college_name || '—');
        $('#ivPosterDate').text(row.iv_date || '—');
        $('#ivPosterEntity').text(row.entity_name || '—');
        // $('#ivPosterCode').text(row.iv_code || '—');
        $('#ivQrCopyUrlBtn').data('url', row.qr_url || '');
        $('#ivQrCopyStatus').text(row.qr_url ? 'Copy the registration link to share it digitally.' : 'Registration link is unavailable.');
        $('#ivPosterLogo').attr('src', row.entity_logo || '{{ asset('assets/common/logo_small.png') }}');
        $('#ivQrCanvas').empty();

        if (window.QRCode && row.qr_url) {
            new QRCode(document.getElementById('ivQrCanvas'), {
                text: row.qr_url,
                width: 200,
                height: 200,
                colorDark: '#111827',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.H
            });
        }

        qrModal.show();
    }

    $('#ivAddBtn').on('click', function () {
        $('#ivCreateError').addClass('d-none').empty();
        $('#ivCreateForm')[0].reset();
        $('#ivCollege').val('').trigger('change');
        $('#ivEntity').val('').trigger('change');
        $('#ivEntityPreviewBox').hide();
        $('#ivEntityPreviewReviewLink').addClass('d-none').attr('href', '#');
        $('#ivDate').val('{{ now()->format('Y-m-d') }}');
        createModal.show();
    });

    $('#ivEntity').on('change', showSelectedEntity);

    $('#ivSearch').on('input', function () {
        clearTimeout(searchTimer);
        state.search = $(this).val().trim();
        searchTimer = setTimeout(function () { loadData(1); }, 350);
    });

    $('#ivCollegeFilter').on('change', function () {
        state.college_id = $(this).val();
        loadData(1);
    });

    $('#ivEntityFilter').on('change', function () {
        state.entity_id = $(this).val();
        loadData(1);
    });

    $('#ivResetBtn').on('click', function () {
        $('#ivSearch').val('');
        $('#ivCollegeFilter').val('').trigger('change');
        $('#ivEntityFilter').val('').trigger('change');
        $('#ivDateFilter').val('');
        state.search = '';
        state.college_id = '';
        state.entity_id = '';
        state.date = '';
        loadData(1);
    });



    function collegeUrl(template, id) {
        return template.replace('__ID__', encodeURIComponent(id));
    }

    function resetCollegeForm() {
        $('#ivCollegeForm')[0].reset();
        $('#ivCollegeId').val('');
        $('#ivCollegeFormTitle').text('Add College');
        $('#ivCollegeNameError, #ivCollegeDescError').addClass('d-none').empty();
        $('#ivCollegeFormError').addClass('d-none').empty();
        $('#ivCollegeSaveLabel').html('<i class="mdi mdi-content-save-outline me-1"></i> Save College');
    }

    function showCollegeForm(mode, row) {
        resetCollegeForm();
        if (mode === 'edit' && row) {
            $('#ivCollegeFormTitle').text('Update College');
            $('#ivCollegeId').val(row.id);
            $('#ivCollegeNameInput').val(row.college_name || '');
            $('#ivCollegeDescInput').val(row.college_desc || '');
            $('#ivCollegeSaveLabel').html('<i class="mdi mdi-content-save-outline me-1"></i> Update College');
        }
        $('#ivCollegeFormPanel').removeClass('d-none');
        setTimeout(function () { $('#ivCollegeNameInput').trigger('focus'); }, 50);
    }

    function setCollegeSaveLoading(isLoading) {
        $('#ivCollegeSaveBtn').prop('disabled', isLoading);
        $('#ivCollegeSaveLabel').toggleClass('d-none', isLoading);
        $('#ivCollegeSaveLoading').toggleClass('d-none', !isLoading);
    }

    function updateCollegePagination(currentPage, lastPage, total, perpage) {
        const paginationContainer = document.getElementById('ivCollegePaginationContainer');
        if (!paginationContainer) return;

        paginationContainer.innerHTML = '';
        paginationContainer.style.display = 'flex';
        paginationContainer.style.justifyContent = 'space-between';
        paginationContainer.style.alignItems = 'center';

        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total === 0) start = 0;

        paginationContainer.insertAdjacentHTML('beforeend', `Showing ${start} to ${end} of ${total} results`);

        const firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class="page-link js-iv-college-page" type="button" data-page="1">«</button></li>`;
        const prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class="page-link js-iv-college-page" type="button" data-page="${Math.max(1, currentPage - 1)}">‹</button></li>`;
        const nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link js-iv-college-page" type="button" data-page="${Math.min(lastPage, currentPage + 1)}">›</button></li>`;
        const lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class="page-link js-iv-college-page" type="button" data-page="${Math.max(1, lastPage)}">»</button></li>`;

        let pageButtons = '';
        const range = 2;
        const startPage = Math.max(1, currentPage - range);
        const endPage = Math.min(lastPage, currentPage + range);

        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link js-iv-college-page" type="button" data-page="${i}">${i}</button></li>`;
        }

        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="College page navigation">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);
    }

    function renderColleges(items, pagination) {
        window.ivCollegeRows = items || [];
        const $body = $('#ivCollegeTableBody');
        if (!items.length) {
            $body.html('<tr><td colspan="5" class="iv-empty"><i class="mdi mdi-school-outline fs-1 d-block mb-2"></i>No colleges found.</td></tr>');
            updateCollegePagination(Number(pagination.current_page || 1), Number(pagination.last_page || 1), Number(pagination.total || 0), Number(pagination.per_page || 25));
            return;
        }

        $body.html(items.map(function (row, index) {
            const globalIndex = ((Number(pagination.current_page || 1) - 1) * Number(pagination.per_page || 25)) + index + 1;
            const isActive = Number(row.status) === 0;
            return `
                <tr>
                    <td class="text-muted fw-bold">${globalIndex}</td>
                    <td>
                        <div class="iv-college">${escapeHtml(row.college_name)}</div>
                        <!--<div class="iv-code">#${escapeHtml(row.id)}</div>-->
                    </td>
                    <td><div class="iv-college-desc">${escapeHtml(row.college_desc || '—')}</div></td>
                    <td class="text-center">
                        <span class="iv-college-status ${isActive ? 'active' : 'inactive'}">
                            <i class="mdi ${isActive ? 'mdi-check-circle-outline' : 'mdi-close-circle-outline'}"></i>${escapeHtml(row.status_label)}
                        </span>
                    </td>
                    <td class="text-center">
                        <div class="d-inline-flex align-items-center gap-2">
                            <button type="button" class="btn btn-light-primary iv-action-btn js-iv-college-edit shadow-none" data-id="${row.id}" title="Edit college">
                                <i class="mdi mdi-square-edit-outline"></i>
                            </button>
                            <div class="form-check form-switch m-0" title="${isActive ? 'Deactivate college' : 'Activate college'}">
                                <input class="form-check-input iv-college-toggle js-iv-college-toggle" type="checkbox" data-id="${row.id}" ${isActive ? 'checked' : ''}>
                            </div>
                        </div>
                    </td>
                </tr>`;
        }).join(''));

        updateCollegePagination(Number(pagination.current_page || 1), Number(pagination.last_page || 1), Number(pagination.total || 0), Number(pagination.per_page || 25));
    }

    function loadColleges(page = 1) {
        collegePage = page;
        $('#ivCollegeTableBody').html('<tr><td colspan="5" class="iv-empty"><span class="iv-spinner me-2"></span> Loading colleges...</td></tr>');

        $.ajax({
            url: urls.colleges,
            method: 'GET',
            data: {
                page: collegePage,
                perpage: $('#ivCollegePerpage').val() || 25,
                search: $('#ivCollegeSearch').val().trim(),
                status: $('#ivCollegeStatusFilter').val() || null
            }
        }).done(function (response) {
            renderColleges(response.data || [], response.pagination || {});
        }).fail(function (xhr) {
            showError(xhr.responseJSON?.message || 'Could not load colleges.');
            $('#ivCollegeTableBody').html('<tr><td colspan="5" class="iv-empty text-danger">Unable to load colleges.</td></tr>');
        });
    }

    function refreshCollegeLookups() {
        const selectedCreateCollege = $('#ivCollege').val();
        const selectedFilterCollege = $('#ivCollegeFilter').val();

        loadLookups().done(function () {
            if (selectedCreateCollege && $('#ivCollege option[value="' + selectedCreateCollege + '"]').length) {
                $('#ivCollege').val(selectedCreateCollege).trigger('change');
            }

            const filterOptionStillExists = selectedFilterCollege && $('#ivCollegeFilter option[value="' + selectedFilterCollege + '"]').length;
            if (filterOptionStillExists) {
                state.college_id = selectedFilterCollege;
                $('#ivCollegeFilter').val(selectedFilterCollege).trigger('change');
            } else if (selectedFilterCollege) {
                state.college_id = '';
                $('#ivCollegeFilter').val('').trigger('change');
            }
        });
    }

    function attendeeUrl(id) {
        return urls.attendees.replace('__ID__', encodeURIComponent(id));
    }

    function updateAttendeePagination(currentPage, lastPage, total, perpage) {
        const paginationContainer = document.getElementById('ivAttendeePaginationContainer');
        if (!paginationContainer) return;

        paginationContainer.innerHTML = '';
        paginationContainer.style.display = 'flex';
        paginationContainer.style.justifyContent = 'space-between';
        paginationContainer.style.alignItems = 'center';

        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total === 0) start = 0;

        const showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        const firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class="page-link js-iv-attendee-page" type="button" data-page="1">«</button></li>`;
        const prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class="page-link js-iv-attendee-page" type="button" data-page="${Math.max(1, currentPage - 1)}">‹</button></li>`;
        const nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link js-iv-attendee-page" type="button" data-page="${Math.min(lastPage, currentPage + 1)}">›</button></li>`;
        const lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class="page-link js-iv-attendee-page" type="button" data-page="${Math.max(1, lastPage)}">»</button></li>`;

        let pageButtons = '';
        const range = 2;
        const startPage = Math.max(1, currentPage - range);
        const endPage = Math.min(lastPage, currentPage + range);

        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link js-iv-attendee-page" type="button" data-page="${i}">${i}</button></li>`;
        }

        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Attendee page navigation">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);
    }

    function renderAttendees(items, pagination) {
        const $body = $('#ivAttendeeTableBody');
        if (!items.length) {
            $body.html('<tr><td colspan="7" class="iv-empty"><i class="mdi mdi-account-off-outline fs-1 d-block mb-2"></i>No attendees found.</td></tr>');
            updateAttendeePagination(Number(pagination.current_page || 1), Number(pagination.last_page || 1), Number(pagination.total || 0), Number(pagination.per_page || 50));
            return;
        }

        $body.html(items.map(function (item, index) {
            const globalIndex = ((Number(pagination.current_page || 1) - 1) * Number(pagination.per_page || 50)) + index + 1;
            return `
                <tr>
                    <td class="text-muted fw-bold">${globalIndex}</td>
                    <td>
                        <div class="iv-attendee-name">${escapeHtml(item.student_name)}</div>
                        <!--<div class="iv-attendee-sub">Attendee #${escapeHtml(item.id)}</div> -->
                    </td>
                    <td><span class="iv-attendee-badge">${escapeHtml(item.gender_label)}</span></td>
                    <td>
                        <div class="fw-semibold text-dark">${escapeHtml(item.qualification_name)}</div>
                        <div class="iv-attendee-sub">${escapeHtml(item.major_name)}</div>
                    </td>
                    <td><span class="iv-attendee-badge">${escapeHtml(item.year_of_passing)}</span></td>
                    <td class="iv-attendee-contact">
                        <div><span>${escapeHtml(item.mobile)}</span></div>
                        <div class="iv-attendee-sub text-truncate" style="max-width:210px"><span>${escapeHtml(item.email)}</span></div>
                    </td>
                    <td>
                        <div class="fw-semibold text-dark">${escapeHtml(item.state_name || '—')}</div>
                        <div class="iv-attendee-sub">${escapeHtml(item.city_name || '—')}</div>
                    </td>
                    <!-- <td class="text-muted" style="white-space:nowrap">${escapeHtml(item.registered_at || '—')}</td> -->
                </tr>`;
        }).join(''));

        updateAttendeePagination(Number(pagination.current_page || 1), Number(pagination.last_page || 1), Number(pagination.total || 0), Number(pagination.per_page || 50));
    }

    function updateAttendeeGenderSummary(items) {
        // The endpoint is paginated. Summary is therefore updated from the
        // current page only; total comes from server pagination below.
        const counts = { 1: 0, 2: 0, 3: 0 };
        items.forEach(function (item) { counts[Number(item.gender)] = (counts[Number(item.gender)] || 0) + 1; });
        $('#ivAttendeeMale').text(counts[1]);
        $('#ivAttendeeFemale').text(counts[2]);
        $('#ivAttendeeOthers').text(counts[3]);
    }

    function loadAttendees(page = 1) {
        if (!activeAttendeeVisitId) return;
        attendeePage = page;
        $('#ivAttendeeTableBody').html('<tr><td colspan="7" class="iv-empty"><span class="iv-spinner me-2"></span> Loading attendees...</td></tr>');

        $.ajax({
            url: attendeeUrl(activeAttendeeVisitId),
            method: 'GET',
            data: {
                page: attendeePage,
                perpage: 50,
                search: $('#ivAttendeeSearch').val().trim()
            }
        }).done(function (response) {
            const items = response.data || [];
            const pagination = response.pagination || {};
            const visit = response.visit || {};
            const genderSummary = response.gender_summary || {};
            $('#ivAttendeeModalTitle').text(`${visit.college_name || 'Industrial Visit'} — Attendees`);
            // $('#ivAttendeeModalMeta').text([visit.entity_name, visit.iv_date, visit.iv_code].filter(Boolean).join(' • '));
            $('#ivAttendeeModalMeta').text([visit.entity_name, visit.iv_date].filter(Boolean).join(' • '));
            $('#ivAttendeesModalContent').css('--iv-attendee-color', visit.entity_base_color || '#ab2b22');
            $('#ivAttendeeLogo').attr('src', visit.entity_logo || '{{ asset('assets/common/logo_small.png') }}');
            $('#ivAttendeeTotal').text(Number(pagination.total || 0).toLocaleString());
            $('#ivAttendeeMale').text(Number(genderSummary.male || 0).toLocaleString());
            $('#ivAttendeeFemale').text(Number(genderSummary.female || 0).toLocaleString());
            $('#ivAttendeeOthers').text(Number(genderSummary.others || 0).toLocaleString());
            renderAttendees(items, pagination);
        }).fail(function (xhr) {
            showError(xhr.responseJSON?.message || 'Could not load attendee details.');
            $('#ivAttendeeTableBody').html('<tr><td colspan="7" class="iv-empty text-danger">Unable to load attendee details.</td></tr>');
        });
    }


    $('#ivManageCollegeBtn').on('click', function () {
        resetCollegeForm();
        $('#ivCollegeFormPanel').addClass('d-none');
        collegeModal.show();
        loadColleges(1);
    });

    $('#ivAddCollegeBtn').on('click', function () {
        showCollegeForm('add');
    });

    $('#ivCollegeFormCloseBtn').on('click', function () {
        $('#ivCollegeFormPanel').addClass('d-none');
        resetCollegeForm();
    });

    $('#ivCollegePerpage').on('change', function () {
        loadColleges(1);
    });

    $('#ivCollegeSearch').on('input', function () {
        clearTimeout(collegeSearchTimer);
        collegeSearchTimer = setTimeout(function () { loadColleges(1); }, 350);
    });

    $('#ivCollegeStatusFilter').on('change', function () {
        loadColleges(1);
    });

    $('#ivCollegeResetBtn').on('click', function () {
        $('#ivCollegeSearch').val('');
        $('#ivCollegeStatusFilter').val('').trigger('change.select2');
        $('#ivCollegePerpage').val('25').trigger('change.select2');
        loadColleges(1);
    });

    $('#ivCollegeTableBody').on('click', '.js-iv-college-edit', function () {
        const rowId = Number($(this).data('id'));
        const row = (window.ivCollegeRows || []).find(function (item) { return Number(item.id) === rowId; });
        if (row) showCollegeForm('edit', row);
    });

    $('#ivCollegeTableBody').on('change', '.js-iv-college-toggle', function () {
        const checkbox = this;
        const id = Number($(checkbox).data('id')) || 0;
        if (!id) return;
        if (!checkbox.checked) {
            // Current state was active and user is deactivating; continue immediately.
        }
        checkbox.disabled = true;
        $.ajax({
            url: collegeUrl(urls.collegeToggle, id),
            method: 'PATCH'
        }).done(function (response) {
            if (window.toastr) toastr.success(response.message || 'College status updated.');
            loadColleges(collegePage);
            refreshCollegeLookups();
        }).fail(function (xhr) {
            checkbox.checked = !checkbox.checked;
            showError(xhr.responseJSON?.message || 'College status could not be updated.');
        }).always(function () {
            checkbox.disabled = false;
        });
    });

    $('#ivCollegePaginationContainer').on('click', '.js-iv-college-page', function () {
        const $button = $(this);
        if ($button.closest('.page-item').hasClass('disabled')) return;
        loadColleges(Number($button.data('page')) || 1);
    });

    $('#ivCollegeForm').on('submit', function (event) {
        event.preventDefault();
        $('#ivCollegeFormError').addClass('d-none').empty();
        $('#ivCollegeNameError, #ivCollegeDescError').addClass('d-none').empty();

        const name = $('#ivCollegeNameInput').val().trim();
        const desc = $('#ivCollegeDescInput').val().trim();
        let valid = true;

        if (!name) {
            $('#ivCollegeNameError').removeClass('d-none').text('College name is required.');
            valid = false;
        }
        if (!valid) return;

        const id = Number($('#ivCollegeId').val()) || 0;
        const isEdit = id > 0;
        setCollegeSaveLoading(true);

        $.ajax({
            url: isEdit ? collegeUrl(urls.collegeUpdate, id) : urls.collegeStore,
            method: isEdit ? 'PUT' : 'POST',
            data: {
                college_name: name,
                college_desc: desc || null
            }
        }).done(function (response) {
            if (window.toastr) toastr.success(response.message || (isEdit ? 'College updated successfully.' : 'College added successfully.'));
            $('#ivCollegeFormPanel').addClass('d-none');
            resetCollegeForm();
            loadColleges(1);
            refreshCollegeLookups();
        }).fail(function (xhr) {
            const message = xhr.responseJSON?.message || 'College could not be saved.';
            const errors = xhr.responseJSON?.errors || {};
            if (errors.college_name?.[0]) $('#ivCollegeNameError').removeClass('d-none').text(errors.college_name[0]);
            if (errors.college_desc?.[0]) $('#ivCollegeDescError').removeClass('d-none').text(errors.college_desc[0]);
            if (!errors.college_name && !errors.college_desc) $('#ivCollegeFormError').removeClass('d-none').text(message);
        }).always(function () {
            setCollegeSaveLoading(false);
        });
    });

    $('#ivQrCopyUrlBtn').on('click', async function () {
        const url = String($(this).data('url') || '');
        if (!url) {
            showError('QR registration URL is unavailable.');
            return;
        }

        const button = $(this);
        button.prop('disabled', true);
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(url);
            } else {
                const textarea = document.createElement('textarea');
                textarea.value = url;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                document.body.appendChild(textarea);
                textarea.focus();
                textarea.select();
                document.execCommand('copy');
                textarea.remove();
            }
            $('#ivQrCopyStatus').text('QR registration URL copied successfully.');
            button.html('<i class="mdi mdi-check me-1"></i> Copied');
            if (window.toastr) toastr.success('QR registration URL copied.');
            setTimeout(function () {
                button.html('<i class="mdi mdi-content-copy me-1"></i> Copy QR URL');
            }, 1800);
        } catch (error) {
            console.error(error);
            showError('Could not copy the QR registration URL.');
        } finally {
            button.prop('disabled', false);
        }
    });

    $('#ivTableBody').on('click', '.js-iv-attendees', function () {
        activeAttendeeVisitId = Number($(this).data('id')) || null;
        attendeePage = 1;
        $('#ivAttendeeSearch').val('');
        $('#ivAttendeeTableBody').html('<tr><td colspan="7" class="iv-empty"><span class="iv-spinner me-2"></span> Loading attendees...</td></tr>');
        attendeesModal.show();
        loadAttendees(1);
    });

    $('#ivAttendeePaginationContainer').on('click', '.js-iv-attendee-page', function () {
        const $button = $(this);
        const $item = $button.closest('.page-item');
        if ($item.hasClass('disabled')) return;
        loadAttendees(Number($button.data('page')) || 1);
    });

    $('#ivAttendeeSearch').on('input', function () {
        clearTimeout(attendeeSearchTimer);
        attendeeSearchTimer = setTimeout(function () { loadAttendees(1); }, 300);
    });


    $('#ivTableBody').on('click', '.js-iv-qr', function () {
        const row = state.rows[$(this).data('id')];
        if (row) openQr(row);
    });

    $('#ivPagination').on('click', '.js-iv-page', function () {
        loadData(Number($(this).data('page')));
    });

    $('#ivCreateForm').on('submit', function (event) {
        event.preventDefault();
        $('#ivCreateError').addClass('d-none').empty();
        setCreateLoading(true);

        $.ajax({
            url: urls.store,
            method: 'POST',
            data: {
                iv_date: $('#ivDate').val(),
                college_id: $('#ivCollege').val(),
                entity_id: $('#ivEntity').val()
            }
        }).done(function (response) {
            createModal.hide();
            loadData(1);
            loadStats();
            if (response.data) openQr(response.data);
            if (window.toastr) toastr.success(response.message || 'Industrial Visit created successfully.');
        }).fail(function (xhr) {
            const message = xhr.responseJSON?.message || 'Industrial Visit could not be created.';
            const errors = xhr.responseJSON?.errors || {};
            let html = '<div class="fw-bold mb-1">' + escapeHtml(message) + '</div>';
            Object.keys(errors).forEach(function (key) {
                html += '<div class="small">' + escapeHtml(errors[key][0] || '') + '</div>';
            });
            $('#ivCreateError').removeClass('d-none').html(html);
        }).always(function () {
            setCreateLoading(false);
        });
    });

    $('#ivDownloadPosterBtn').on('click', async function () {
        if (!activeQr) return;

        const button = $(this);
        const poster = document.getElementById('ivPoster');

        button.prop('disabled', true).html('<span class="iv-spinner me-2"></span> Preparing...');

        const originalBorderRadius = poster.style.borderRadius;
        const originalOverflow = poster.style.overflow;

        try {
            // Remove rounded corners only for downloaded image
            poster.style.borderRadius = '0';
            poster.style.overflow = 'hidden';

            const canvas = await html2canvas(poster, {
                scale: 2,
                useCORS: true,
                backgroundColor: '#ffffff'
            });

            const link = document.createElement('a');
            link.download = `${activeQr.iv_code || 'industrial-visit'}-qr-poster.png`;
            link.href = canvas.toDataURL('image/png');
            link.click();

        } catch (error) {
            console.error(error);
            showError('Poster download could not be prepared.');
        } finally {
            // Restore preview styling
            poster.style.borderRadius = originalBorderRadius;
            poster.style.overflow = originalOverflow;

            button.prop('disabled', false)
                .html('<i class="mdi mdi-download me-1"></i> Download');
        }
    });

    initDatePickers();
    loadLookups().always(function () {
        loadData(1);
        loadStats();
    });
});
</script>
@endsection
