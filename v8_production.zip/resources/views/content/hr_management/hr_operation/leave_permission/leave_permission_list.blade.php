@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn{
        width: 100%;
        height: 100%;
        display:none;
        color:black;
        background-color:rgba(0,0,0,0.2);
    }

    .document-thumbnail:hover .view-btn{
        display:flex;
        justify-content:center;
        align-items:center;
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }


    .approval-ui { border-radius:18px; }

.section-title{
    font-weight:600;
    color:#374151;
    margin-bottom:8px;
}

.employee-preview{
    max-height:300px;
    overflow:auto;
    background:#f8fafc;
    border-radius:12px;
    padding:10px;
}

.emp-item{
    display:flex;
    align-items:center;
    gap:10px;
    padding:6px 8px;
    border-radius:8px;
    transition:.2s;
}
.emp-item:hover{ background:#eef2ff; }

.emp-avatar{
    width:32px;height:32px;
    border-radius:50%;
    background:#6366f1;
    color:#fff;
    display:flex;align-items:center;justify-content:center;
    font-weight:600;
}

/* LEVEL CARDS */
.level-card{
    border-radius:14px;
    border:1px solid #e5e7eb;
    background:#fff;
    box-shadow:0 4px 14px rgba(0,0,0,.05);
    margin-bottom:14px;
}

.level-header{
    background:#f1f5f9;
    border-bottom:1px solid #e5e7eb;
    padding:10px 14px;
    border-top-left-radius:14px;
    border-top-right-radius:14px;
    font-weight:600;
}

.remove-level{ cursor:pointer;color:#ef4444 }
.emp-avatar-wrapper{
    width:38px;
    height:38px;
    border-radius:50%;
    overflow:hidden;
    flex-shrink:0;
}

.emp-avatar-img{
    width:100%;
    height:100%;
    border-radius:50%;
    /* object-fit:cover; */
    color:#fff;
    font-weight:600;
    font-size:14px;
}
.level-card{
    border:1px solid #e5e7eb;
    border-left:4px solid #ab2b22;
    transition:.25s;
    background:#fff;
}

.level-card:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 25px rgba(0,0,0,.08);
}

.level-header{
    background:#f8fafc;
    font-weight:600;
    padding:12px 16px;
}

.level-title{
    display:flex;
    align-items:center;
    font-size:14px;
}

.level-number{
    font-size:12px;
    padding:5px 8px;
}

.remove-level{
    cursor:pointer;
    color:#ef4444;
    font-size:18px;
}

.level-card .form-select{
    border-radius:10px;
}

#approvalLevels{
    min-height:150px;
    border:2px dashed #e5e7eb;
    padding:10px;
    border-radius:12px;
}

.workflow-preview{
    border:1px solid #e5e7eb;
    border-radius:14px;
    padding:14px;
    background:#fbfdff;
}

.preview-title{
    font-weight:600;
    margin-bottom:10px;
    color:#374151;
}

.flow-preview-box{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    min-height:60px;
}

.flow-node{
    padding:8px 14px;
    border-radius:999px;
    background:#eef2ff;
    font-weight:600;
    position:relative;
}

.flow-node.start{ background:#dcfce7; }
.flow-node.hr{ background:#fee2e2; }
.flow-node.manager{ background:#fef3c7; }

.flow-arrow{
    font-size:18px;
    color:#9ca3af;
}


</style>
<style>
    /* ===== MODERN HR LEAVE UI ===== */

.leave-steps{
    display:flex;
    justify-content:space-between;
    margin-bottom:25px;
    position:relative;
}

.leave-steps:before{
    content:'';
    position:absolute;
    top:18px;
    left:0;
    right:0;
    height:3px;
    background:#e5e7eb;
}

.step{
    position:relative;
    background:#fff;
    padding:8px 16px;
    border-radius:30px;
    font-weight:600;
    color:#6b7280;
    border:2px solid #e5e7eb;
    z-index:2;
    transition:.25s;
}



/* Card sections */
.leave-card{
    background:#f9fafb;
    border-radius:16px;
    padding:18px;
    border:1px solid #e5e7eb;
    margin-bottom:18px;
}

/* request selector */
.request-type-box{
    display:flex;
    gap:20px;
}

.type-card{
    flex:1;
    border:2px solid #e5e7eb;
    border-radius:16px;
    padding:20px;
    text-align:center;
    cursor:pointer;
    transition:.25s;
}

.type-card:hover{
    transform:translateY(-3px);
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}

.type-card.active{
    border-color:#ab2b22;
    background:#eef2ff;
}

.type-icon{
    font-size:32px;
    margin-bottom:10px;
}

/* date planner */
.leave-date-input{
    background:#ffffff;
    border-radius:14px !important;
    border:1px solid #e5e7eb !important;
    transition:.2s;
}

.leave-date-input:hover{
    border-color:#ab2b22 !important;
}

/* summary */
.leave-summary{
    background:#111827;
    color:#fff;
    border-radius:16px;
    padding:18px;
}

.flow-preview-box-req{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
    min-height:60px;
}

.flow-node-req{
    padding:8px 14px;
    border-radius:999px;
    background:#eef2ff;
    font-weight:600;
}

.flow-node-req.employee{ background:#dcfce7; }
.flow-node-req.manager{ background:#fef3c7; }
.flow-node-req.hr{ background:#fee2e2; }
.flow-node-req.director{ background:#e0f2fe; }

.flow-arrow-req{
    font-size:18px;
    color:#9ca3af;
}


</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Leave & Permission</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Operation
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-1" id="filter">
                 <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-end">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_add_leave_request">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Leave Request
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="" data-bs-toggle="modal" data-bs-target="#approvalMatrixModal">
                    Approval Hierarchy
                </a>
            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
            
            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;"  class="filterSubmit" id="filterSubmit" >
                    <span class="btn btn-primary btn-sm" > Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                    class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                 <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary" >
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-100px">Dept /Div /<br>Job Role</th>
                                <th class="min-w-100px">Request Type</th>
                                <th class="min-w-100px">Leave / Permission Details</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<!-- Modal for Status Update -->
<!-- <div class="modal fade" id="statusUpdateModal" tabindex="-1" aria-labelledby="statusUpdateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="statusUpdateModalLabel">Update Leave Request Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="leaveRequestDetails">
                    <div class="mb-3">
                        <h6>Staff Name:</h6>
                        <p id="staffName"></p>
                    </div>
                    <div class="mb-3">
                        <h6>Leave Reason:</h6>
                        <p id="leaveReason"></p>
                    </div>
                    <div class="mb-3">
                        <h6>Current Month Leave Count:</h6>
                        <p id="currentMonthLeaveCount"></p>
                    </div>
                    <div class="mb-3">
                        <h6>Current Month Permission Count:</h6>
                        <p id="currentMonthPermissionCount"></p>
                    </div>
                    <div class="mb-3">
                        <h6>Already Approved Leaves:</h6>
                        <p id="approvedLeaveCount"></p>
                    </div>
                </div>

                <form id="statusUpdateForm">
                    <div class="mb-3">
                        <label for="levelSelect" class="form-label">Approval Level</label>
                        <select id="levelSelect" class="form-select">
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="statusSelect" class="form-label">Select Status</label>
                        <select id="statusSelect" class="form-select">
                            <option value="1">Approve</option>
                            <option value="4">Reject</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="remarks" class="form-label">Remarks</label>
                        <textarea id="remarks" class="form-control" rows="3"></textarea>
                    </div>
                    <button type="button" class="btn btn-primary" onclick="updateStatus()">Update Status</button>
                </form>
            </div>
        </div>
    </div>
</div> -->


    <div class="modal fade" id="statusUpdateModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <h3 class="text-black" id="statusHeader">Update Leave Request Status - <span id="currentStatus">Pending</span></h3>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white">

                <!-- Leave Request Details Card -->
                <div class="card mb-4">
                    <div class="card-header text-white bg-light" >
                        <div class="d-flex justify-content-between">
                            <h5 class="mb-0">Leave Request Details</h5>
                            <span id="staffCompany" class="badge fs-7"></span>
                        </div>
                        
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <h6>Staff Name:</h6>
                                        <span id="staffName"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Leave Reason:</h6>
                                        <span id="leaveReason"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Current Month Leave Count:</h6>
                                        <span id="currentMonthLeaveCount"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Current Month Permission Count:</h6>
                                        <span id="currentMonthPermissionCount"></span>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <h6>Mobile No:</h6>
                                        <span id="staffMobileNo"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Email ID:</h6>
                                        <span id="staffEmailId"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Job Role:</h6>
                                        <span id="staffJobRole"></span>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h6>Department:</h6>
                                        <span id="staffDepartment"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>

              

                <!-- Approval Level Dropdown -->
                <div class="mb-3">
                    <label for="levelSelect" class="form-label">Approval Level</label>
                    <select id="levelSelect" class="form-select select3">
                        <!-- Options will be populated dynamically -->
                    </select>
                </div>

                <!-- Remarks -->
                <div class="mb-3">
                    <label for="remarks" class="form-label">Remarks</label>
                    <textarea id="remarks" class="form-control" rows="3"></textarea>
                </div>
                <input type="hidden" name="leave_status" id="leave_status">
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="updateStatus()">Update Status</button>
            </div>
        </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!-- <div class="modal fade" id="approvalMatrixModalold" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>

            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-8 text-center">
                    <h4 class="modal-title fw-bold text-primary">
                        <i class="mdi mdi-sitemap-outline me-2"></i>
                        Leave / Permission Approval Hierarchy
                    </h4>
                </div>

                <div class="modal-body pt-4 pb-5 px-4 px-xl-6">
                    <div class="row g-0">

                        <div class="col-lg-4 border-end pe-lg-4">

                            <h6 class="section-title">Requesting Employees</h6>

                            <label>Company</label>
                            <select id="company_id_approv" name="company_id_approv" class="form-select select3" required onchange="comapnyAproveChange()">
                                <option value="">Select Company Name</option>
                                <option value="egc">Elysium Groups</option>
                                @foreach($company_list as $clist)
                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                @endforeach
                            </select>
                            <div class="business_div_approv">
                                <label>Entity</label>
                                <select id="entity_id_aprov" name="entity_id_aprov" class="form-select select3" required onchange="entityAproveChange()">
                                    <option value="">Select Entity Name</option>
                                </select>
                            </div>
                            <label class="mt-3">Department</label>

                            <select id="department_id_aprov" class="form-select select3" onchange="departAproveChange()"></select>

                            <label class="mt-3">Role</label>
                            <select id="role_id_aprov" class="form-select select3" onchange="roleAproveChange()"></select>

                            <hr>

                            <h6 class="section-title">Staffs under this Role</h6>
                            <div id="roleEmployees" class="employee-preview"></div>

                        </div>

                        <div class="col-lg-8 ps-lg-4">

                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="section-title">Approval Hierarchy</h6>
                                <button class="btn btn-primary btn-sm" id="addLevelBtn">
                                    <i class="mdi mdi-plus"></i> Add Level
                                </button>
                            </div>
                            <div class="workflow-preview mb-3">
                                <div class="preview-title">
                                    <i class="mdi mdi-source-branch"></i> Hierarchy Preview
                                </div>

                                <div id="flowPreview" class="flow-preview-box">
                                    <div class="flow-node start">Staff</div>
                                </div>
                            </div>
                            <div id="approvalLevels" class="levels-container"></div>

                        </div>

                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary px-4" id="saveMatrixBtn">
                        <i class="mdi mdi-content-save-outline me-1"></i> Save Approve Hierarchy
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> -->

<div class="modal fade" id="approvalMatrixModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">

            <div class="modal-header border-0">
                <h4 class="modal-title fw-bold text-primary">
                        <i class="mdi mdi-sitemap-outline me-2"></i>
                        Leave / Permission Approval Hierarchy
                    </h4>
                <button class="btn btn-sm btn-icon " data-bs-dismiss="modal">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>

            <div class="modal-body px-6 pb-6">
            
                    <div class="row g-0">
                        <div class="col-lg-4 border-end pe-lg-4">

                            <h6 class="section-title">Requesting Employees</h6>

                            <label>Company</label>
                            <select id="company_id_approv" name="company_id_approv" class="form-select select3" required onchange="comapnyAproveChange()">
                                <option value="">Select Company Name</option>
                                <option value="egc">Elysium Groups</option>
                                @foreach($company_list as $clist)
                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                @endforeach
                            </select>
                            <div class="business_div_approv">
                                <label>Entity</label>
                                <select id="entity_id_aprov" name="entity_id_aprov" class="form-select select3" required onchange="entityAproveChange()">
                                    <option value="">Select Entity Name</option>
                                </select>
                            </div>
                            <label class="mt-3">Department</label>

                            <select id="department_id_aprov" class="form-select select3" onchange="departAproveChange()"></select>

                            <label class="mt-3">Role</label>
                            <select id="role_id_aprov" class="form-select select3" onchange="roleAproveChange()"></select>

                            <hr>

                            <h6 class="section-title">Staffs under this Role</h6>
                            <div id="roleEmployees" class="employee-preview"></div>

                        </div>

                        <div class="col-lg-8 ps-lg-4">

                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="section-title">Approval Hierarchy</h6>
                                <button class="btn btn-primary btn-sm" id="addLevelBtn">
                                    <i class="mdi mdi-plus"></i> Add Level
                                </button>
                            </div>
                            <div class="workflow-preview mb-3">
                                <div class="preview-title">
                                    <i class="mdi mdi-source-branch"></i> Hierarchy Preview
                                </div>

                                <div id="flowPreview" class="flow-preview-box">
                                    <div class="flow-node start">Staff</div>
                                </div>
                            </div>
                            <div id="approvalLevels" class="levels-container"></div>

                        </div>
                    </div>
            </div>

            <div class="modal-footer border-0">
                <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary px-4" id="saveMatrixBtn">
                    <i class="mdi mdi-content-save-outline me-1"></i> Save Approve Hierarchy
                </button>
            </div>

        </div>
    </div>
</div>

<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3"  onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->






<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_add_leave_request" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>

            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black" id="request_title_name">Leave Request</h3>
                </div>

                <div class="modal-body pt-4 pb-5 px-4 px-xl-6">
                   
                        <div class="row mb-3">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                                <select id="staff_company_name" name="staff_company_name" class="form-select select3" required>
                                    <option value="">Select Company Name</option>
                                    <option value="egc">Elysium Groups</option>
                                    @foreach($company_list as $clist)
                                    <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback">Please select a valid company name.</div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                                <select id="staff_entity_name" name="staff_entity_name" class="form-select select3" required>
                                    <option value="">Select Entity Name</option>
                                </select>
                                <div class="invalid-feedback">Please select a valid entity name.</div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                                <select id="staff_branch_name" name="staff_branch_name" class="form-select select3" required>
                                    <option value="">Select Branch Name</option>
                                </select>
                                <div class="invalid-feedback">Please select a valid branch name.</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                <select id="department_id" name="department_id" class="form-select select3" required>
                                    <option value="">Select Department</option>
                                </select>
                                <div class="invalid-feedback">Please select a valid department.</div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Staff<span class="text-danger">*</span></label>
                                <select id="staff_id" name="staff_id" class="form-select select3" required onchange="getStaffDetails()">
                                    <option value="">Select Staff</option>
                                </select>
                                <div class="invalid-feedback">Please select a staff member.</div>
                            </div>
                            
                        </div>

                        <div class="leave-card-title mb-3">
                            <label class="fw-semibold mb-2">Request Type</label>

                            <div class="request-type-box">
                                <div class="type-card" data-type="Leave">
                                    <div class="type-icon"></div>
                                    <h5>Leave</h5>
                                    <small>Full / Half day leave</small>
                                </div>

                                <div class="type-card" data-type="Permission">
                                    <div class="type-icon"></div>
                                    <h5>Permission</h5>
                                    <small>Short time permission</small>
                                </div>
                            </div>

                            <input type="hidden" name="request_type" id="request_type">
                        </div>
                        <div id="leave_dates_section">
                            <div class="leave-card mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="fw-semibold">Schedule Planner</label>
                                    <button type="button" class="btn btn-sm btn-primary" id="addRow">
                                        <i class="mdi mdi-plus"></i> Add
                                    </button>
                                </div>

                                <div id="plannerRows"></div>
                            </div>

                            <!-- <div class="leave-card mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="fw-semibold">Work Assigned</label>
                                    <button type="button" class="btn btn-sm btn-primary" id="addTaskRow">
                                        <i class="mdi mdi-plus"></i> Add
                                    </button>
                                </div>

                                <div id="plannerTaskRows"></div>
                            </div> -->

                            <div class="leave-card mt-3">
                                <div class="d-flex justify-content-between">
                                    <h5 class="mb-3">
                                        <i class="mdi mdi-sitemap-outline me-1"></i>
                                        Approval Preview
                                    </h5>
                                    <div id="liveSummary">No entries added</div>
                                </div>
                                <div id="approvalPreview" class="flow-preview-box">
                                    <div class="text-muted">Approval Hierarchy Not Set Yet</div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-end mt-4">
                                <button type="button" class="btn btn-primary" id="submitStaffBtn">
                                    <span id="submitText">Submit Request</span>
                                    <span id="submitLoader" style="display:none;" class="spinner-border spinner-border-sm"></span> <!-- Loader -->
                                </button>
                            </div>
                        </div>
                 
                </div>
            </div>
        </div>
    </div>
</div>

<!--end::Modal - Filter-->
  


   <script>
     function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    // window.location.href = '/hr_enroll/manage_staff';
                    submitBtn.disabled = false;
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
     function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {    
        
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
  
        let staff_image = '';
        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_2.png';
        }
        staff_image = `{{ asset('${staff_image}') }}`;
         
        let statusClass = 'bg-warning';
        let statusText = 'Pending'; // Default text if no status is found
        let statusDropdown = ''; // Initialize status dropdown visibility

        // Check if current user is the approver for this request
        const isApprover = (auth_user_id === item.next_approver_id); // Check if logged-in user is the approver

        if (data.status === 1) {
            statusClass = 'bg-success';
            statusText = `Approved by ${item.last_approver_name || '-'}`;
        } else if (data.status === 4) {
            statusClass = 'bg-danger';
            statusText = `Rejected by ${item.last_approver_name || '-'}`;
        } else {
            // Pending status - Check approvalLevels if defined
            statusText = `Pending (from ${item.next_approver_name || '-'})`;
        }

        // Show the dropdown only if the current user is the approver
        statusDropdown = `
            <span class="badge ${statusClass} cursor-pointer ${isApprover ? 'dropdown-toggle hide-arrow' : ''}" ${isApprover ? 'data-bs-toggle="dropdown" data-trigger="hover"' : ''}>
                ${statusText}
            </span>
        `;
        
        if (isApprover) {
            statusDropdown += `
                <div class="dropdown-menu dropdown-menu-end" style="width: 200px;">
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#statusUpdateModal" onclick="openStatusUpdateModal(${data.sno}, '${statusText}','1')">Accept</a>
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#statusUpdateModal" onclick="openStatusUpdateModal(${data.sno}, '${statusText}','4')">Reject</a>
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#statusUpdateModal" onclick="openStatusUpdateModal(${data.sno}, '${statusText}','3')">OnHold</a>
                </div>
            `;
        }

        

         
        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${data.company_base_color || ''};"></div>
                    <div class="d-flex">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle">
                                <img src="${staff_image}" 
                                    alt="user-avatar"  class="w-px-40 h-px-40 rounded-circle"
                                    id="uploadedlogo" onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}' ${(data.gender == 1 ? 'user_2.png' : 'user_2.png')}"/>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label class="d-flex gap-1 no-wrap">
                                <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${data.nick_name || '-'}">${data.staff_name}</span>
                                    ${data.gender == 1 ?
                                        `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                            class="mdi mdi-face-man text-info"></i></span>`
                                    : 
                                        `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i
                                            class="mdi mdi-face-woman text-info"></i></span>`
                                    }
                                <div class="">
                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                        data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9" style="color: ${data.company_base_color || ''} !important;"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Mob No</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.mobile_no || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Email ID</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.email_id || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">DOB</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                ${data.dob ? formatDateCommon(data.dob) : '-'}
                                                <span 
                                                    class="badge fs-8 bg-info" 
                                                    data-bs-toggle="tooltip" 
                                                    title="${data.dob ? getNextBDayDate(data.dob).full : '-'}">
                                                    ${data.dob ? getNextBDayDate(data.dob).short : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Educational</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">
                                            ${data.education && Array.isArray(data.education) && data.education.length > 0 ? data.education : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>        
                                
                            </label>
                            
                            <div class="d-flex  fs-8" >
                                ${data.company_type == 1 ?
                                    `<div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold fs-8 text-truncate badge bg-label-danger d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="${data.company_name || '-'}">
                                            ${data.company_name || '-'}
                                        </label>
                                    </div>`
                                    :
                                    `<div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-8 text-truncate d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="${data.company_name || '-'}">
                                            ${data.company_name || '-'}
                                        </label>

                                        <label class="fw-semibold fs-8 text-truncate badge  d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: ${item.company_base_color || ''};"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="${data.entity_name || '-'}" >
                                            ${data.entity_name || '-'}
                                        </label>
                                    </div>`
                                }
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                   <div class="d-flex align-items-start justify-content-center flex-column gap-1">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.department_name || '-'}">
                            ${data.department_name || '-'}
                        </label>
                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.division_name || '-'}">
                            ${data.division_name || '-'}
                        </label>
                        <label class="badge bg-label-primary fs-7 fw-bold mb-2" >
                            <span class="fs-7">${data.job_role_name || '-'}</span>
                        </label>
                    </div> 
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                       <span class="fs-7 me-1 text-black badge ${data.request_type == 'Leave' ? 'bg-warning ':'bg-info ' } text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${data.request_type || '-'}">${data.request_type}</span>
                       ${data.request_type =='Leave' ? 
                        ` <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                            ${data.from_date ? formatDateCommon(data.from_date) : '-'}
                        </label> `
                        :
                        `
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                            ${data.from_date ? formatDateCommon(data.from_date) : '-'}
                        </label>
                        <div class="d-flex no-wrap gap-1">
                            <label class="fw-semibold text-success fs-7 d-block text-nowrap">
                                ${data.from_date ? formatTimeCommon(data.from_time) : '-'}
                            </label>
                        -
                            <label class="fw-semibold text-success fs-7 d-block text-nowrap">
                                ${data.from_date ? formatTimeCommon(data.to_time) : '-'}
                            </label>
                        </div>
                        `
                        }
                    </div>
                </td>
                <td>
                    <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                        style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="${data.reason}">
                        ${data.reason}
                    </label>
                </td>
                <td>
                    ${statusDropdown}
                </td>
                
                <td >
                    
      
                    <a href="javascript:;" class="fs-7" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${data.sno})">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"> <i class="mdi mdi-eye fs-3 text-dark "></i></span>
                    </a>
                           
                          
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_operation/leave_permission?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="6" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

     document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
 
 
 
</script>

<script>
   

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>

<script>
    let levelCount = 0;
    let roleStaff = [];
    let editId = null;

    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
        }
    });

         function comapnyAproveChange() {
            var companyId = $('#company_id_approv').val();
            var entityDropdown = $('#entity_id_aprov');
          
            companyChangeAprove()
            // Reset dropdown
            entityDropdown.empty().append('<option value="">Select Entity</option>');

            if (companyId) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: { company_id: companyId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                entityDropdown.append(
                                    $('<option></option>')
                                        .attr('value', entity.sno)
                                        .text(entity.entity_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
        };
        // When entity changes staff_branch_name
        function entityAproveChange() {
            var entityId = $('#entity_id_aprov').val();
            var departmentDropdown = $('#department_id_aprov');
            departmentDropdown.empty().append('<option value="">Select Department</option>');

            if (entityId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entityId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                departmentDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                    .text(state.department_name));
                            });
                            
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }
            
        };

        function departAproveChange() {
            var department_id = $('#department_id_aprov').val();
            var staffDropdown = $('#role_id_aprov');
            staffDropdown.empty().append('<option value="">Select Job Role</option>');
            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_role_by_department') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                staffDropdown.append($('<option></option>').attr('value', state.sno).text(state.job_position_name));
                            });
                            
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Staff:', error);
                    }
                });
                    
            }
        };
       function roleAproveChange() {

            let id = $('#role_id_aprov').val();
            if (!id) return;

            $('#roleEmployees').html('<div class="p-3 text-muted">Loading Staffs...</div>');

            $.get("{{ route('get_staff_by_role') }}", { role_id: id }, function (response) {

                if (response.status === 200) {
                    roleStaff = response.data;   // ❌ you wrote res.data before
                    renderEmployeePreview();
                    refreshApproverDropdowns();
                }

            }).fail(() => {
                $('#roleEmployees').html('<div class="text-danger p-2">Failed to load staff</div>');
            });
        };

            function companyChangeAprove(){
                var company = $('#company_id_approv').val();
                if(company =='egc'){
                    $('.business_div_approv').hide();
                    var departmentDropdown = $('#department_id_aprov');
                    departmentDropdown.empty().append('<option value="">Select Department</option>');
                    var entityId = 0;
                        $.ajax({
                            url: "{{ route('department') }}",
                            type: "GET",
                            data: {
                                entity_id: entityId
                            },
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    response.data.forEach(function(state) {
                                        departmentDropdown.append($('<option></option>').attr(
                                            'value', state.sno)
                                            .text(state.department_name));
                                    });
                                    
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching Department:', error);
                            }
                        });
                }else{
                    $('.business_div_approv').show();
                }
            }

 
    function renderEmployeePreview(){

        let html='';

        roleStaff.forEach(emp=>{

        let staff_image = '';
        let img = 'no';
            if (emp.staff_image && emp.staff_image.trim() !== '') {
                img = 'yes';
                if (emp.company_type == 1) {
                    staff_image = `staff_images/Management/${emp.staff_image}`;
                } else {
                    staff_image = `staff_images/Buisness/${emp.company_id}/${emp.entity_id}/${emp.staff_image}`;
                }
            } else {
                img = 'no';
            }
            staff_image = `{{ asset('${staff_image}') }}`;
            html+=`
            <div class="emp-item">
                <div class="emp-avatar">
                     
                ${
                    img !== 'no'
                    ? `<img src="${staff_image}" class="emp-avatar-img" 
                            onerror="this.remove(); this.parentElement.innerHTML=getInitialAvatar('${escapeHtml(emp.staff_name)}')">`
                    : getInitialAvatar(emp.staff_name)
                }                       
                </div>
                <div>
                    <div class="fw-semibold">${emp.staff_name}</div>
                    <small class="text-muted">${emp.nick_name}</small>
                </div>
            </div>`;
        });

        $('#roleEmployees').html(html || '<div class="text-muted p-2">No Staffs</div>');
    }

    function refreshApproverDropdowns(){

        $('.approver-select').each(function(){

            let selected=$(this).val() || [];

            $(this).empty();

            roleStaff.forEach(emp=>{
                $(this).append(
                    new Option(emp.name,emp.id,false,selected.includes(String(emp.id)))
                );
            });

            $(this).trigger('change.select2');
        });
    }



    $('#addLevelBtn').click(()=>{
        if(roleStaff.length===0){
            toastr.error('Select role first');
            return;
        }
        addLevel();
    })
   function addLevel(){

        levelCount++;

        $('#approvalLevels').append(`
        <div class="level-card" data-level="${levelCount}">

        <div class="level-header d-flex justify-content-between align-items-center">
            <div class="level-title">
                <i class="mdi mdi-drag-vertical me-2 handle text-muted"></i>
                <span class="badge bg-primary level-number">${levelCount}</span>
                <span class="ms-2">Approval Level</span>
            </div>
            <span class="remove-level"><i class="mdi mdi-close"></i></span>
        </div>

        <div class="p-3 row g-2">

            <div class="col-md-3">
                <label>Company</label>
                <select class="form-select level-company select3" onchange="level_company_chnage(this)"></select>
            </div>

            <div class="col-md-3 level-entity-box">
                <label>Entity</label>
                <select class="form-select level-entity select3" onchange="level_entity_chnage(this)"></select>
            </div>

            <div class="col-md-3">
                <label>Department</label>
                <select class="form-select level-department select3" onchange="level_depart_chnage(this)"></select>
            </div>

            <div class="col-md-3">
                <label>Approver</label>
                <select class="form-select level-staff select3" onchange="level_staff_chnage(this)"></select>
            </div>

        </div>
        </div>`);

        loadLevelCompanies(levelCount);
        }

    let companyList = @json($company_list);
    companyList.unshift({sno:'egc',company_name:'Elysium Groups'})
   function loadLevelCompanies(level){

        let select=$(`[data-level="${level}"] .level-company`);

        fillSelect(select,companyList,'Select Company','company_name');
    }

    function updateFlowPreview(){

        let html='<div class="flow-node start">Staff</div>';

        let hasLevel=false;

        $('#approvalLevels .level-card').each(function(){

            let staffName=$(this).find('.level-staff option:selected').text();

            if(staffName && staffName!=='Select Staff'){
                hasLevel=true;

                html+=`<div class="flow-arrow"><i class="mdi mdi-arrow-right"></i></div>
                    <div class="flow-node manager">${staffName}</div>`;
            }
        });

        if(!hasLevel){
            html='<div class="flow-node start">Staff</div>';
        }

        $('#flowPreview').html(html);
    }



$(document).on('click','.remove-level',updateFlowPreview);


function level_staff_chnage(dom){
    updateFlowPreview();
}

function level_company_chnage (dom){
    console.log("cimsbh")
    let card=$(dom).closest('.level-card');
    let company=$(dom).val();

    if(company==='egc'){
        card.find('.level-entity-box').hide();

        $.get("{{ route('department') }}",{entity_id:0},res=>{
            fillSelect(card.find('.level-department'),res.data,'Select Department','department_name');
        });

    }else{

        card.find('.level-entity-box').show();

        $.get("{{ route('entity_list') }}",{company_id:company},res=>{
            fillSelect(card.find('.level-entity'),res.data,'Select Entity','entity_name');
        });
    }
   
};


function level_entity_chnage(dom){

    let card=$(dom).closest('.level-card');
    let entity=$(dom).val();

    $.get("{{ route('department') }}",{entity_id:entity},res=>{
        fillSelect(card.find('.level-department'),res.data,'Select Department','department_name');
    });
};

function level_depart_chnage(dom){

    let card=$(dom).closest('.level-card');
    let dept=$(dom).val();

    $.get("{{ route('get_staff_by_depart') }}",{department_id:dept},res=>{
        fillSelect(card.find('.level-staff'),res.data,'Select Approver','staff_name');
    });
};


    function loadApprovers(level,selected){
        let select=$(`[data-level="${level}"] .approver-select`);

        select.empty();
        roleStaff.forEach(emp=>{
            select.append(new Option(emp.name,emp.id,false,selected.includes(String(emp.id))));
        });

        select.select2({
            placeholder:'Select Approvers',
            width:'100%'
        });
    }

    $(document).on('click','.remove-level',function(){
        $(this).closest('.level-card').remove();
        reorderLevels();
        updateFlowPreview();
    });


    new Sortable(document.getElementById('approvalLevels'),{
        animation:150,
        onEnd: function () {
            console.log("fghfj")
            reorderLevels();
            updateFlowPreview();
        }
    });

    function reorderLevels(){

        $('#approvalLevels .level-card').each(function(index){

            let level=index+1;

            $(this).attr('data-level',level);

            $(this).find('.level-number').text(level);
        });

    }


    $('#saveMatrixBtn').click(function(){
           
            let levels=[];
            var company_id =$('#company_id_approv').val() == 'egc' ? 0 : $('#company_id_approv').val();
            var entity_id =$('#company_id_approv').val() == 'egc' ? 0 : $('#entity_id_aprov').val();

            $('.level-card').each(function(index){

                let staff=$(this).find('.level-staff').val();

                if(!staff){
                    toastr.error(`Select approver in Level ${index+1}`);
                    return false;
                }
                var level_company_id =$(this).find('.level-company').val() == 'egc' ? 0 : $(this).find('.level-company').val();
                var level_entity_id =$(this).find('.level-company').val() == 'egc' ? 0 : $(this).find('.level-entity').val();
                levels.push({
                    level:index+1,
                    company:level_company_id,
                    entity:level_entity_id,
                    department:$(this).find('.level-department').val(),
                    staff_id:staff
                });
            });
            $.ajax({
                url: "{{ route('approval_matrix_save') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    company_id: company_id,
                    entity_id: entity_id,
                    department_id: $('#department_id_aprov').val(),
                    role_id: $('#role_id_aprov').val(),
                    levels: levels
                },
                success: function(response) {
                    toastr.success('Workflow Saved');
                     location.reload();
                    
                },
                error: function(error) {
                    toastr.error('Error Save Leave Heirachy:', error);
                    console.error('Error Save Leave Heirachy:', error);
                }
            });
            
    });



    function editMatrix(id){
        editId=id;

        $.get('/api/approval-matrix/get/'+id,res=>{
            $('#company_id').val(res.company_id).trigger('change');

            setTimeout(()=>{
                $('#department_id').val(res.department_id).trigger('change');
            },400);

            setTimeout(()=>{
                $('#role_id').val(res.role_id).trigger('change');
            },800);

            setTimeout(()=>{
                $('#approvalLevels').html('');
                levelCount=0;
                res.workflow.levels.forEach(l=>addLevel(l.approvers));
            },1200);

            $('#approvalMatrixModal').modal('show');
        });
    }

    $('#approvalMatrixModal').on('hidden.bs.modal',function(){

        levelCount=0;
        editId=null;
        roleStaff=[];
        $('#approvalLevels').empty();
        $('#roleEmployees').empty();

        $(this).find('select').val('').trigger('change');
    });
  
    let sortableInstance=null;

$('#approvalMatrixModal').on('shown.bs.modal',function(){

    if(sortableInstance) sortableInstance.destroy();

    sortableInstance=new Sortable(document.getElementById('approvalLevels'),{
        animation:200,
        handle:'.handle',
        ghostClass:'bg-light',
        onEnd:function(){
             console.log("on end working")
            reorderLevels();
            updateFlowPreview();
        }
        
    });

});
function fillSelect($select, list, placeholder = 'Select', option_name) {

    // Destroy select2 safely (if already initialized)
    if ($select.hasClass("select2-hidden-accessible")) {
        $select.select2('destroy');
    }

    //Clear existing options
    $select.html('');
    $select.append(`<option value="">${placeholder}</option>`);

    //  Append new options safely
    list.forEach(item => {

        let text =item[option_name] ??
            item.department_name ??
            item.job_position_name ??
            item.role_name ??
            item.staff_name ??
            item.company_name ??
            item.entity_name ??
            'Unknown';

        let value =item.sno ?? '';

        $select.append(new Option(text, value));
    });

    // Reinitialize select2 (IMPORTANT for modal)
    $select.select2({
        placeholder: placeholder,
        width: '100%',
        dropdownParent: $('#approvalMatrixModal .modal-body'),
        allowClear: true
    });

    let company_id =$('#company_id_approv').val();
    let entity_id =$('#entity_id_aprov').val();

    //  Reset selection
    if(option_name == 'company_name'){
        $select.val(company_id).trigger('change');
    }else if(option_name == 'entity_name'){
        $select.val(entity_id).trigger('change');
    }else{
        $select.val('').trigger('change');
    }
    
    
}

</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
 <script>
   
    function companyChange(){
        var company = $('#staff_company_name').val();
        if(company =='egc'){
            $('.business_div').hide();
            var departmentDropdown = $('#department_id');
            departmentDropdown.empty().append('<option value="">Select Department</option>');
            var entityId = 0;
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entityId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                departmentDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                    .text(state.department_name));
                            });
                            
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
        }else{
            $('.business_div').show();
        }
    }
    $(document).ready(function() {

        // When company changes
        $('#staff_company_name').on('change', function() {
            var companyId = $(this).val();
            var entityDropdown = $('#staff_entity_name');
            companyChange()
            // Reset dropdown
            entityDropdown.empty().append('<option value="">Select Entity</option>');

            if (companyId) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: { company_id: companyId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                entityDropdown.append(
                                    $('<option></option>')
                                        .attr('value', entity.sno)
                                        .attr('data-baseurl', entity.entity_base_url)
                                        .text(entity.entity_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
        });

        // When entity changes staff_branch_name
        $('#staff_entity_name').on('change', function() {
            var entityId = $(this).val();
            var branchDropdown = $('#staff_branch_name');
            branchDropdown.empty().append('<option value="">Select Branch</option>');
            if (entityId) {
                $.ajax({
                    url: "{{ route('entity_branch_dropdown_list') }}",
                    type: "GET",
                    data: { entity_id: entityId},
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                branchDropdown.append(
                                    $('<option></option>')
                                        .attr('value', entity.sno)
                                        .text(entity.branch_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            } 
            var departmentDropdown = $('#department_id');
            departmentDropdown.empty().append('<option value="">Select Department</option>');

            if (entityId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entityId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                departmentDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                    .text(state.department_name));
                            });
                            
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }
            
        });

        $('#department_id').on('change', function() {
            var department_id = $(this).val();
            var staffDropdown = $('#staff_id');
            staffDropdown.empty().append('<option value="">Select Staff</option>');
            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_staff_by_branch') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                staffDropdown.append($('<option></option>').attr('value', state.sno).text(state.staff_name + '- ( '+state.job_role_name +' )' ));
                            });
                            
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Staff:', error);
                    }
                });
                    
            }
        });

       


    });
</script>


<script>
    let selectedDates = [];
    let totalLeaveDays = 0;
    let totalPermissionHours = 0;
</script>



 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }

    
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

            result = result.trim();

            // Add "In" or "Ago"
            if (isFuture) {
                result = `In ${result}`;
            } else if (result !== '0 days') {
                // result += ' ago';
                result += '';
            }

            return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }

</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
        $(document).ready(function() {
            // Business dropdown
            $('#company_fill').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_fill');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // depart list
            $('#entity_fill').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#department_fill');

                stateDropdown.empty().append('<option value="">Select Department</option>');

                if (entity_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }

                
            });

            // division dropdown
             $('#department_fill').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#division_fill');
                stateDropdown.empty().append('<option value="">Select Division</option>');

                let erp_depert = $(this).find(':selected').data('erpdepartmentid');
                $('#erp_department_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpdivisionid', state.erp_division_id)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
             });

              $('#division_fill').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#job_role_fill');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                let erp_depert = $(this).find(':selected').data('erpdivisionid');
                $('#erp_division_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpjobroleid', state.erp_job_role_id)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
             });

        })
</script>



<script>
    function getOrdinalSuffix(number) {
        const suffixes = ["th", "st", "nd", "rd"];
        const remainder = number % 100;
        return suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    }

    function getInitials(name) {
        if (!name) return '';
        const words = name.trim().split(' ');
        
        return (words[0][0]).toUpperCase();
    }

    function getInitialAvatar(name){
        if(!name) name='?';

        let initials = name.trim().charAt(0).toUpperCase();
        let colors = ['#6366f1','#22c55e','#06b6d4','#f59e0b','#ef4444','#ab2b22'];
        let color = colors[name.length % colors.length];

        return `
        <div class="emp-avatar-img d-flex align-items-center justify-content-center"
            style="background:${color}">
            ${initials}
        </div>`;
    }

    function getAvatarColor(name) {
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }
    function escapeHtml(text){
        if(!text) return '';
        return text.replace(/'/g,"&#39;").replace(/"/g,"&quot;");
    }
    function replaceWithInitials(img, name) {
        console.log(img,name)
        const initials = getInitials(name);
        const color = getAvatarColor(name);
        console.log(name ,initials)
        const div = document.createElement('div');
        div.className = `rounded-circle ${color} text-white d-flex align-items-center justify-content-center me-3 fw-bold`;
        div.style.width = '50px';
        div.style.height = '50px';
        div.innerText = initials;

        img.replaceWith(div);
    }
</script>

<script>
    const planner = {
        type: null,
        rows: [],
        totalDays: 0,
        totalHours: 0
    };
    // refreshSummary();
    $(document).on('click','.type-card',function(){
        $('.type-card').removeClass('active');
        $(this).addClass('active');

        planner.type = $(this).data('type');
        $('#request_type').val(planner.type);
        $('#request_title_name').text(planner.type == 'Leave' ? 'Leave Request' : 'Permission Request');

        $('#plannerRows').empty();
        planner.rows = [];
        refreshSummary();
        addLeaveSchudle();
        // addWorkSchudle();
        // changeleaveDiv()
    });


    $('#addRow').on('click',()=>{
        addLeaveSchudle();
    });

    function addLeaveSchudle (){

        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }

        const id = Date.now();

        let html = `
        <div class="planner-row border rounded p-3 mb-2" data-id="${id}">
            <div class="row g-2 align-items-center">

                <div class="col-md-3">
                    <label>Date<span class="text-danger">*</span></label>
                    <input type="text" class="form-control row-date common_datepicker_leave" required placeholder ="Date">
                    <div class="text-danger error-message" ></div>
                </div>
        `;

        if(planner.type === 'Leave'){
            html += `
                <div class="col-md-3">
                    <label>Leave Type<span class="text-danger">*</span></label>
                    <select class="form-select select3 row-leave" id="leave_type_${id}" onchange="leave_type_change()">
                        <option value="">Select Half/Full</option>
                        <option value="Full">Full Day</option>
                        <option value="Morning Half">Morning Half</option>
                        <option value="Afternoon Half">Afternoon Half</option>
                    </select>
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-5">
                    <label>Reason<span class="text-danger">*</span></label>
                    <textarea class="form-control row-reason"  placeholder ="Enter Leave Purpose" rows="1" ></textarea>
                    <div class="text-danger error-message" ></div>
                </div>
            `;
        }else{
            // refreshLeaveSelection()
            html += `
                <div class="col-md-2">
                    <label>From<span class="text-danger">*</span></label>
                    <input type="text" class="form-control time-from" placeholder ="From Time">
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-2">
                    <label>To<span class="text-danger">*</span></label>
                    <input type="text" class="form-control time-to" placeholder ="To Time">
                    <div class="text-danger error-message" ></div>
                </div>

                <div class="col-md-4">
                    <label>Reason<span class="text-danger">*</span></label>
                    <textarea class="form-control row-reason"  placeholder ="Enter Permission Purpose" rows="1" ></textarea>
                    <div class="text-danger error-message" ></div>
                </div>
            `;
        }

        html += `
                    <div class="col-md-1 text-end">
                            <button class="btn btn-danger btn-sm removeRow mt-4">✕</button>
                    </div>
                </div>
            </div>`;

        $('#plannerRows').append(html);
        
        $(".common_datepicker_leave").datepicker({
            format: "dd-M-yyyy",
            autoclose: true,
            beforeShowDay: function(date) {
                let options = { day: '2-digit', month: 'short', year: 'numeric' };
                let formattedDate = date.toLocaleDateString('en-GB', options).replace(/ /g, '-');
                return selectedDates.indexOf(formattedDate) === -1;
            },
            todayHighlight: true
        });

        $(".common_datepicker_leave").on('change', function() {
            var dateText = $(this).val();
            handleDateChange(dateText);
        });

        $(`#leave_type_${id}`).select2({
            width: '100%',
            dropdownParent: $(`#leave_type_${id}`).closest('.col-md-3'),
        });
        // $('.row-date').flatpickr({dateFormat:'d-M-Y'});
        $('.time-from,.time-to').flatpickr({enableTime:true,noCalendar:true,dateFormat:"h:i K"});
    }

    function leave_type_change(){
        refreshSummary();
    }
    $(document).on('change','.row-leave,.time-from,.time-to',refreshSummary);

    $(document).on('click','.removeRow',function(){
        $(this).closest('.planner-row').remove();
        refreshSummary();
    });


    function refreshSummary(){
        console.log("working")
        planner.totalDays = 0;
        planner.totalHours = 0;

        $('.planner-row').each(function(){

            if(planner.type === 'Leave'){
                let type=$(this).find('.row-leave').val();
                planner.totalDays += (type != '' ? (type==='Full'? 1:0.5) : 0);
            }
            else{
                let from=$(this).find('.time-from').val();
                let to=$(this).find('.time-to').val();
                if(from && to){
                    let diff=(new Date('1970-01-01 '+to)-new Date('1970-01-01 '+from))/3600000;
                    planner.totalHours+=diff;
                }
            }
        });

        let html = `<b>Type:</b> <span class="badge ${planner.type==='Leave' ? 'bg-danger':'bg-secondary'}">${planner.type || '-'}</span><br>`;

        if(planner.type==='Leave')
            html+=`<b>Total Days:</b> ${planner.totalDays} days`;
        else if(planner.type==='Permission')
            html+=`<b>Total Hours:</b> ${planner.totalHours.toFixed(2)} hrs`;

        $('#liveSummary').html(html);
    }

</script>

<script>
    $('#addTaskRow').on('click',()=>{
        addWorkSchudle();
    });
    
    function addWorkSchudle (){

        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }

        const id = Date.now();

        let html = `
        <div class="planner-task-row border rounded p-3 mb-2" data-id="${id}">
            <div class="row g-2 align-items-end">

                <div class="col-md-3">
                    <label>Task</label>
                    <textarea class="form-control work-task-name" placeholder="Enter Task name" rows="1"></textarea>
                </div>
                <div class="col-md-3">
                    <label>Assigned Staff</label>
                    <select class="form-select select3 work-leave" id="work_assigned_staff_${id}" >
                        <option value="">Select Staff</option>
                        
                    </select>
                </div>
        `;

        html += `
                    <div class="col-md-1 text-end">
                        <button class="btn btn-danger removeTaskRow">✕</button>
                    </div>
                </div>
            </div>`;

        $('#plannerTaskRows').append(html);
        
      

        $(`#work_assigned_staff_${id}`).select2({
            width: '100%',
            dropdownParent: $(`#work_assigned_staff_${id}`).closest('.col-md-3'),
        });
      
    }
    $(document).on('click','.removeTaskRow',function(){
        $(this).closest('.planner-task-row').remove();
    });
</script>

<script>
    let leveljson = '';
    let staffProfile = '';
    function getStaffDetails(){
        var id = $('#staff_id').val();
        if(id){
            $.ajax({
                url:"{{route('get_staff_leave_details')}}",
                type:"GET",
                data:{
                    staff_id:id,
                },
                success:function(res){
                    leveljson = res.approve_level;
                    staffProfile =res.staffProfile;
                        if(leveljson){
                            renderApprovalPreview(leveljson)
                        }
                },
                error:function(err){
                    console.error(err)
                }
            });      
        }
    }
   
    function renderApprovalPreview(levels){
       
        let html='';

        html+=`<div class="flow-node employee">${staffProfile.staff_name}</div>`;

        levels.forEach(level=>{
            console.log(level)
            html+=`<div class="flow-arrow"><i class="mdi mdi-arrow-right"></i></div>`;

            let roleClass='manager';

            if(level.role_type==='HR') roleClass='hr';
            if(level.role_type==='Director') roleClass='director';

            html+=`
            <div class="flow-node ${roleClass}">
                ${level.staff_name}
                <div class="small text-muted">${level.job_role_name}</div>
            </div>`;
        });

        $('#approvalPreview').html(html);
    }

    function handleDateChange(dateText) {
        if (selectedDates.indexOf(dateText) !== -1) {
            let index = selectedDates.indexOf(dateText);
            selectedDates.splice(index, 1);
        }
        selectedDates.push(dateText);
        
    }
</script>
<script>
    function validateLeaveSchedule() {
        let isValid = true;
        let company_id = $('#staff_company_name').val();
        let entity_id = $('#staff_entity_name').val();
        let branch_id = $('#staff_branch_name').val();
        let department_id = $('#department_id').val();
        let staff_id = $('#staff_id').val();
        if (company_id =='') { $('#staff_company_name_err').text('Company is required.'); isValid = false; }else{$('#staff_company_name_err').text('');}
        if (entity_id =='') { $('staff_entity_name_err').text('Entity is required.'); isValid = false; }else{$('staff_entity_name_err').text('');}
        if (branch_id =='') { $('staff_branch_name_err').text('Branch is required.'); isValid = false; }else{$('staff_branch_name_err').text('');}
        if (department_id =='') { $('department_id_err').text('Department is required.'); isValid = false; }else{$('department_id_err').text('');}
        if (staff_id =='') { $('staff_id_err').text('Staff is required.'); isValid = false; }else{$('staff_id_err').text('');}

        // Loop through each planner row and validate fields
        $('.planner-row').each(function() {
            let date = $(this).find('.row-date').val();
            let leaveType = $(this).find('.row-leave').val();
            let reason = $(this).find('.row-reason').val();
            let fromTime = $(this).find('.time-from').val();
            let toTime = $(this).find('.time-to').val();

            // Clear previous error messages
            $(this).find('.error-message').text('');

            // Validate required fields based on planner type
            if (!date) {
                $(this).find('.row-date').siblings('.error-message').text('Date is required').show();
                isValid = false;
            }
            console.log('planner.type ',planner.type ,'=',(planner.type == 'Leave' && leaveType ==''))
            console.log(leaveType)
            if (planner.type == 'Leave' && leaveType =='') {
                $(this).find('.row-leave').siblings('.error-message').text('Leave Type is required').show();
                isValid = false;
            }
            if (!reason) {
                $(this).find('.row-reason').siblings('.error-message').text('Reason is required').show();
                isValid = false;
            }
            if (planner.type === 'Permission' && (!fromTime || !toTime)) {
                if (!fromTime) {
                    $(this).find('.time-from').siblings('.error-message').text('Time is required').show();
                }
                if (!toTime) {
                    $(this).find('.time-to').siblings('.error-message').text('Time is required').show();
                }
                isValid = false;
            }
        });

        return isValid;
    }

    // On Submit
    $('#submitStaffBtn').click(function() {
        if(!planner.type){
            toastr.warning('Select request type first');
            return;
        }
        if (!validateLeaveSchedule()) {
            toastr.warning('Please fill all required fields.');
            return;
        }

        // Disable submit button and show loader
        $('#submitStaffBtn').prop('disabled', true);
        $('#submitLoader').show();
        $('#submitText').hide();
      
        let levels = [];
        let leaveData = [];
        let company_id = $('#staff_company_name').val();
        let entity_id = $('#staff_entity_name').val();
        let branch_id = $('#staff_branch_name').val();
        let department_id = $('#department_id').val();
        let staff_id = $('#staff_id').val();
        // Collect Leave/Permission details
        $('.planner-row').each(function() {
            let date = $(this).find('.row-date').val();
            let type = $(this).find('.row-leave').val();
            let reason = $(this).find('.row-reason').val();
            let fromTime = $(this).find('.time-from').val();
            let toTime = $(this).find('.time-to').val();

            leaveData.push({
                date: date,
                type: type,
                reason: reason,
                fromTime: fromTime,
                toTime: toTime
            });
        });

        // AJAX to submit the data
        $.ajax({
            url: "{{ route('add_leave_perm_request_my') }}",
            type: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                leaveData: leaveData,
                approvalLevels: levels,
                request_type: planner.type,
                staff_id: staff_id,
            },
            success: function(response) {
                // toastr.success('Leave/Permission request submitted successfully.');
                // $('#kt_modal_add_leave_request').modal('hide'); // Close the modal
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
                 location.reload();
            },
            error: function(error) {
                toastr.error('Error while submitting request.');
                console.error('Error:', error);
                $('#submitStaffBtn').prop('disabled', false);
                $('#submitLoader').hide();
                $('#submitText').show();
            }
        });
    });

</script>

<!-- <script>
 let currentRequestId = null; // Global variable to hold the current request id

function openStatusUpdateModal(requestId, currentStatus) {
    currentRequestId = requestId;

    // Fetch detailed data about the leave request
    $.ajax({
        url: '/hr_operation/leave_permission/get-approval-levels',
        type: 'GET',
        data: {
            request_id: requestId,
        },
        success: function(response) {
            // Populate the modal with detailed data
            $('#staffName').text(response.leaveRequest.staff.staff_name);
            $('#leaveReason').text(response.leaveRequest.reason);
            $('#currentMonthLeaveCount').text(response.currentMonthLeaveCount);
            $('#currentMonthPermissionCount').text(response.currentMonthPermissionCount);
            $('#approvedLeaveCount').text(response.approvedLeaveCount);

            // Set approval levels dynamically
            const levelSelect = document.getElementById('levelSelect');
            levelSelect.innerHTML = ''; // Clear existing options
            response.approvalLevels.forEach(level => {
                const option = document.createElement('option');
                option.value = level.level_no;
                option.textContent = `Level ${level.level_no} - ${level.staff_name}`;
                levelSelect.appendChild(option);
            });

            // Set the current status in the status dropdown
            const statusSelect = document.getElementById('statusSelect');
            statusSelect.value = (currentStatus === 'Approved') ? '1' : (currentStatus === 'Rejected') ? '4' : '0'; // Default to pending
        },
        error: function(xhr, status, error) {
            alert('Error fetching detailed data');
        }
    });
}

function updateStatus() {
    const status = document.getElementById('statusSelect').value;
    const remarks = document.getElementById('remarks').value;

    // Perform AJAX request to update the status
    $.ajax({
        url: '/hr_operation/leave_permission/update-status',
        type: 'POST',
        data: {
            request_id: currentRequestId,
            status: status,
            remarks: remarks,
            _token: '{{ csrf_token() }}' // Add CSRF token for Laravel
        },
        success: function(response) {
            // Close the modal
            $('#statusUpdateModal').modal('hide');

            // Update the UI with the new status
            const statusElement = document.querySelector(`#request-status-${currentRequestId}`);
            if (status === '1') {
                statusElement.classList.remove('bg-warning');
                statusElement.classList.add('bg-success');
                statusElement.innerHTML = 'Approved';
            } else if (status === '4') {
                statusElement.classList.remove('bg-warning');
                statusElement.classList.add('bg-danger');
                statusElement.innerHTML = 'Rejected';
            }
        },
        error: function(xhr, status, error) {
            alert('Error updating status');
        }
    });
}
</script> -->
<script>
  let currentRequestId = null; // Global variable to hold the current request id
 function openStatusUpdateModal(requestId, currentStatus, status) {
    currentRequestId = requestId; // Store request ID globally
    $('#leave_status').val(status); // Set status to modal
    $('#currentStatus').text(currentStatus); // Set current status in header

    // Fetch detailed data about the leave request
    $.ajax({
        url: '/hr_operation/leave_permission/get-approval-levels',
        type: 'GET',
        data: { request_id: requestId },
        success: function(response) {
            const leaveRequest = response.leaveRequest;

            // Update the modal with leave request details
            $('#staffName').text(leaveRequest.staff_name);
            $('#leaveReason').text(leaveRequest.reason);
            $('#currentMonthLeaveCount').text(response.currentMonthLeaveCount);
            $('#currentMonthPermissionCount').text(response.currentMonthPermissionCount);

            // Fill in staff details
            $('#staffMobileNo').text(leaveRequest.mobile_no);
            $('#staffEmailId').text(leaveRequest.email_id);
            $('#staffJobRole').text(leaveRequest.job_role_name);
            $('#staffDepartment').text(leaveRequest.department_name);
            $('#staffCompany').text(leaveRequest.company_name);
            document.getElementById('staffCompany').style.backgroundColor=leaveRequest.company_base_color

            // Populate approval levels dynamically
            const levelSelect = document.getElementById('levelSelect');
            levelSelect.innerHTML = ''; // Clear existing options
            response.approvalLevels.forEach(level => {
                const option = document.createElement('option');
                option.value = level.level_no;
                option.textContent = `Approver ${level.level_no} - ${level.staff_name}`;
                option.setAttribute('data-approver-id', level.approver_staff_id); // Set approver_staff_id
                levelSelect.appendChild(option);
            });
        },
        error: function(xhr, status, error) {
            toastr.error('Error fetching detailed data');
        }
    });
}

function updateStatus() {
    const status = document.getElementById('leave_status').value;
    const remarks = document.getElementById('remarks').value;
    
    // Get selected approver_staff_id from the dropdown
    const selectedOption = document.getElementById('levelSelect').selectedOptions[0];
    const approverStaffId = selectedOption.getAttribute('data-approver-id');
    
    // Perform AJAX request to update the status
    $.ajax({
        url: '/hr_operation/leave_permission/update-status',
        type: 'POST',
        data: {
            request_id: currentRequestId,
            status: status,
            remarks: remarks,
            approver_staff_id: approverStaffId, // Pass approver_staff_id from frontend
            _token: '{{ csrf_token() }}' // Add CSRF token for Laravel
        },
        success: function(response) {
            // Close the modal
            $('#statusUpdateModal').modal('hide');
            
            // Optionally, update the UI with the new status
            const statusElement = document.querySelector(`#request-status-${currentRequestId}`);
            if (status === '1') {
                statusElement.classList.remove('bg-warning');
                statusElement.classList.add('bg-success');
                statusElement.innerHTML = 'Approved';
            } else if (status === '4') {
                statusElement.classList.remove('bg-warning');
                statusElement.classList.add('bg-danger');
                statusElement.innerHTML = 'Rejected';
            }
        },
        error: function(xhr, status, error) {
            toastr.error('Error updating status');
        }
    });
}
</script>
@endsection