'use strict';

/**
 * =========================================================
 * CUG Management — Dashboard
 * =========================================================
 *
 * Responsibilities:
 *
 * - Load dashboard KPI data
 * - Apply current filters
 * - Animate counters
 * - Update utilization
 * - Update call statistics
 * - Update number-pool statistics
 * - Handle card filtering
 * - Prevent stale AJAX responses
 * - Refresh without page reload
 *
 * =========================================================
 */

class CugDashboard {
  constructor() {
    this.request = null;

    this.requestSequence = 0;

    this.initialized = false;
  }

  /* =====================================================
       INIT
    ===================================================== */

  init() {
    if (this.initialized) {
      return;
    }

    this.initialized = true;

    this.registerEvents();

    this.load();
  }

  /* =====================================================
       EVENTS
    ===================================================== */

  registerEvents() {
    const self = this;

    /*
        |--------------------------------------------------------------------------
        | Dashboard Card Click
        |--------------------------------------------------------------------------
        */

    $(document).on('click', '.cug-stat-card', function () {
      const filter = $(this).data('card-filter');

      if (!filter) {
        return;
      }

      self.handleCardFilter(filter);
    });
  }

  /* =====================================================
       LOAD
    ===================================================== */

  load() {
    const self = this;

    const url = CugHelper.route('dashboard');

    if (!url) {
      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Abort Previous Request
        |--------------------------------------------------------------------------
        */

    if (self.request) {
      self.request.abort();
    }

    const sequence = ++self.requestSequence;

    self.setLoading(true);

    self.request = CugHelper.get(
      url,

      self.getFilters()
    );

    self.request

      .done(function (response) {
        /*
                |--------------------------------------------------------------------------
                | Ignore stale response
                |--------------------------------------------------------------------------
                */

        if (sequence !== self.requestSequence) {
          return;
        }

        const data = self.normalizeResponse(response);

        self.render(data);
      })

      .fail(function (xhr, status) {
        /*
                |--------------------------------------------------------------------------
                | Ignore intentionally aborted requests
                |--------------------------------------------------------------------------
                */

        if (status === 'abort') {
          return;
        }

        CugHelper.handleError(xhr, 'Unable to load CUG dashboard.');
      })

      .always(function () {
        if (sequence === self.requestSequence) {
          self.setLoading(false);
        }
      });
  }

  /* =====================================================
       REFRESH
    ===================================================== */

  refresh() {
    this.load();
  }

  /* =====================================================
       FILTERS
    ===================================================== */

  getFilters() {
    return {
      search: $('#cugSearch').val() || '',

      company_id: $('#filterCugCompany').val() || '',

      entity_id: $('#filterCugEntity').val() || '',

      branch_id: $('#filterCugBranch').val() || '',

      status: $('#filterCugStatus').val() || '',

      provider: $('#filterCugProvider').val() || '',

      assignment_status: $('#filterCugAssignment').val() || '',

      staff_id: $('#filterCugStaff').val() || '',

      number_from: $('#filterCugNumberFrom').val() || '',

      number_to: $('#filterCugNumberTo').val() || '',

      assigned_from: $('#filterCugAssignedFrom').val() || '',

      assigned_to: $('#filterCugAssignedTo').val() || ''
    };
  }

  /* =====================================================
       RESPONSE NORMALIZATION
    ===================================================== */

  normalizeResponse(response) {
    let data = response?.data || response || {};

    /*
        |--------------------------------------------------------------------------
        | Support nested dashboard response
        |--------------------------------------------------------------------------
        */

    if (data.dashboard && typeof data.dashboard === 'object') {
      data = data.dashboard;
    }

    const total = this.toNumber(data.total_cug);

    const assigned = this.toNumber(data.assigned);

    const available = this.toNumber(data.available);

    const reserved = this.toNumber(data.reserved);

    const inactive = this.toNumber(data.inactive);

    let utilization = this.toNumber(data.utilization);

    /*
        |--------------------------------------------------------------------------
        | Calculate utilization if backend didn't provide it
        |--------------------------------------------------------------------------
        */

    if (!Object.prototype.hasOwnProperty.call(data, 'utilization')) {
      utilization = total > 0 ? (assigned / total) * 100 : 0;
    }

    return {
      total_cug: total,

      assigned: assigned,

      available: available,

      reserved: reserved,

      inactive: inactive,

      utilization: this.clamp(utilization, 0, 100),

      today_calls: this.toNumber(data.today_calls),

      received_calls: this.toNumber(data.received_calls),

      dialled_calls: this.toNumber(data.dialled_calls),

      missed_calls: this.toNumber(data.missed_calls)
    };
  }

  /* =====================================================
       RENDER
    ===================================================== */

  render(data) {
    /*
        |--------------------------------------------------------------------------
        | Main KPI Cards
        |--------------------------------------------------------------------------
        */

    this.animateCounter('#cugTotalCount', data.total_cug);

    this.animateCounter('#cugAssignedCount', data.assigned);

    this.animateCounter('#cugAvailableCount', data.available);

    this.animateCounter('#cugInactiveCount', data.reserved + data.inactive);

    /*
        |--------------------------------------------------------------------------
        | Utilization
        |--------------------------------------------------------------------------
        */

    this.animatePercentage('#cugUtilization', data.utilization);

    $('#cugUtilizationBar')
      .css('width', data.utilization + '%')

      .attr('aria-valuenow', data.utilization);

    this.animateCounter('#cugUtilizationAssigned', data.assigned);

    this.animateCounter('#cugUtilizationTotal', data.total_cug);

    /*
        |--------------------------------------------------------------------------
        | Calls
        |--------------------------------------------------------------------------
        */

    this.animateCounter('#cugTodayCalls', data.today_calls);

    this.animateCounter('#cugReceivedCalls', data.received_calls);

    this.animateCounter('#cugDialledCalls', data.dialled_calls);

    this.animateCounter('#cugMissedCalls', data.missed_calls);

    /*
        |--------------------------------------------------------------------------
        | Number Pool
        |--------------------------------------------------------------------------
        */

    this.animateCounter('#cugPoolAvailable', data.available);

    this.animateCounter('#cugPoolAssigned', data.assigned);

    this.animateCounter('#cugPoolReserved', data.reserved);

    this.animateCounter('#cugPoolInactive', data.inactive);
  }

  /* =====================================================
       COUNTER
    ===================================================== */

  animateCounter(selector, target, duration = 550) {
    const element = $(selector);

    if (!element.length) {
      return;
    }

    const finalValue = this.toNumber(target);

    const currentValue = this.toNumber(element.attr('data-cug-value'));

    const startTime = performance.now();

    const startValue = currentValue;

    const difference = finalValue - startValue;

    const easeOut = function (progress) {
      return 1 - Math.pow(1 - progress, 3);
    };

    const update = function (timestamp) {
      const elapsed = timestamp - startTime;

      const progress = Math.min(elapsed / duration, 1);

      const eased = easeOut(progress);

      const value = startValue + difference * eased;

      element.text(CugHelper.number(value, 0));

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        element

          .text(CugHelper.number(finalValue, 0))

          .attr('data-cug-value', finalValue);
      }
    };

    requestAnimationFrame(update);
  }

  /* =====================================================
       PERCENTAGE
    ===================================================== */

  animatePercentage(selector, target, duration = 550) {
    const element = $(selector);

    if (!element.length) {
      return;
    }

    const finalValue = this.clamp(this.toNumber(target), 0, 100);

    const currentValue = this.toNumber(element.attr('data-cug-percentage'));

    const startTime = performance.now();

    const difference = finalValue - currentValue;

    const update = function (timestamp) {
      const elapsed = timestamp - startTime;

      const progress = Math.min(elapsed / duration, 1);

      const eased = 1 - Math.pow(1 - progress, 3);

      const value = currentValue + difference * eased;

      element.text(value.toFixed(1) + '%');

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        element

          .text(finalValue.toFixed(1) + '%')

          .attr('data-cug-percentage', finalValue);
      }
    };

    requestAnimationFrame(update);
  }

  /* =====================================================
       LOADING
    ===================================================== */

  setLoading(show) {
    const cards = $('#cugDashboardCards').find('.cug-stat-card');

    cards.toggleClass('cug-dashboard-loading', show);

    $('#cugDashboardCards').toggleClass('cug-dashboard-fetching', show);
  }

  /* =====================================================
       CARD FILTER
    ===================================================== */

  handleCardFilter(filter) {
    /*
        |--------------------------------------------------------------------------
        | Remove Previous Active State
        |--------------------------------------------------------------------------
        */

    $('.cug-stat-card').removeClass('cug-stat-active');

    /*
        |--------------------------------------------------------------------------
        | All
        |--------------------------------------------------------------------------
        */

    if (filter === 'all') {
      $('#filterCugStatus')
        .val('')

        .trigger('change');

      $('#filterCugAssignment')
        .val('')

        .trigger('change');

      $('#cugCardTotal').addClass('cug-stat-active');

      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Assigned
        |--------------------------------------------------------------------------
        */

    if (filter === 'assigned') {
      $('#filterCugStatus')
        .val('1')

        .trigger('change');

      $('#filterCugAssignment')
        .val('assigned')

        .trigger('change');

      $('#cugCardAssigned').addClass('cug-stat-active');

      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Available
        |--------------------------------------------------------------------------
        */

    if (filter === 'available') {
      $('#filterCugStatus')
        .val('0')

        .trigger('change');

      $('#filterCugAssignment')
        .val('available')

        .trigger('change');

      $('#cugCardAvailable').addClass('cug-stat-active');

      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Inactive
        |--------------------------------------------------------------------------
        */

    if (filter === 'inactive') {
      $('#filterCugStatus')
        .val('3')

        .trigger('change');

      $('#filterCugAssignment')
        .val('')

        .trigger('change');

      $('#cugCardInactive').addClass('cug-stat-active');
    }
  }

  /* =====================================================
       NUMBER
    ===================================================== */

  toNumber(value) {
    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
  }

  /* =====================================================
       CLAMP
    ===================================================== */

  clamp(value, minimum, maximum) {
    return Math.min(
      Math.max(value, minimum),

      maximum
    );
  }
}

/* =========================================================
   GLOBAL INSTANCE
========================================================= */

$(function () {
  window.cugDashboard = new CugDashboard();

  cugDashboard.init();
});
