'use strict';

/**
 * =========================================================
 * CUG Management — Filters
 * =========================================================
 *
 * Responsibilities:
 *
 * - Search handling
 * - Company → Entity → Branch dependency
 * - Staff loading
 * - Advanced filters
 * - Date filters
 * - Filter count
 * - Active filter tags
 * - Reset
 * - Dashboard/DataTable synchronization
 * - Debounced refresh
 *
 * =========================================================
 */

class CugFilters {
  constructor() {
    this.initialized = false;

    this.refreshTimer = null;

    this.dependencyRequests = {};

    this.silentChange = false;

    this.refreshDelay = 350;
  }

  /* =====================================================
       INIT
    ===================================================== */

  init() {
    if (this.initialized) {
      return;
    }

    this.initialized = true;

    this.initSelects();

    this.initDates();

    this.registerEvents();

    this.updateSearchClear();

    this.updateFilterState();
  }

  /* =====================================================
       SELECT2
    ===================================================== */

  initSelects() {
    if (typeof $.fn.select2 !== 'function') {
      return;
    }

    const selects = [
      '#filterCugCompany',

      '#filterCugEntity',

      '#filterCugBranch',

      '#filterCugProvider',

      '#filterCugAssignment',

      '#filterCugStaff',

      '#filterCugStatus'
    ];

    selects.forEach(selector => {
      const element = $(selector);

      if (!element.length) {
        return;
      }

      if (element.hasClass('select2-hidden-accessible')) {
        return;
      }

      element.select2({
        width: '100%',

        allowClear: false,

        minimumResultsForSearch: 8,

        dropdownParent: element.closest('#cugManagementPage').length
          ? element.closest('#cugManagementPage')
          : $(document.body)
      });
    });
  }

  /* =====================================================
       DATE PICKERS
    ===================================================== */

  initDates() {
    if (typeof flatpickr === 'undefined') {
      return;
    }

    const self = this;

    $('.cug-date-filter').each(function () {
      const element = $(this);

      if (element.data('cug-flatpickr')) {
        return;
      }

      const picker = flatpickr(this, {
        dateFormat: 'Y-m-d',

        altInput: true,

        altFormat: 'd M Y',

        allowInput: false,

        disableMobile: true,

        onChange: function () {
          self.scheduleRefresh();
        }
      });

      element.data('cug-flatpickr', picker);
    });
  }

  /* =====================================================
       EVENTS
    ===================================================== */

  registerEvents() {
    const self = this;

    /* -------------------------------------------------
           Search
        ------------------------------------------------- */

    $(document).on(
      'input',
      '#cugSearch',
      CugHelper.debounce(function () {
        self.updateSearchClear();

        self.scheduleRefresh();
      }, 350)
    );

    /* -------------------------------------------------
           Search Clear
        ------------------------------------------------- */

    $(document).on('click', '#btnClearCugSearch', function () {
      $('#cugSearch').val('');

      self.updateSearchClear();

      self.scheduleRefresh();
    });

    /* -------------------------------------------------
           Company
        ------------------------------------------------- */

    $(document).on('change', '#filterCugCompany', function () {
      const companyId = $(this).val();

      self.loadEntities(companyId);

      self.scheduleRefresh();
    });

    /* -------------------------------------------------
           Entity
        ------------------------------------------------- */

    $(document).on('change', '#filterCugEntity', function () {
      const entityId = $(this).val();

      self.loadBranches(entityId);

      self.scheduleRefresh();
    });

    /* -------------------------------------------------
           Branch
        ------------------------------------------------- */

    $(document).on('change', '#filterCugBranch', function () {
      self.scheduleRefresh();
    });

    /* -------------------------------------------------
           Normal Select Filters
        ------------------------------------------------- */

    $(document).on(
      'change',
      ['#filterCugStatus', '#filterCugProvider', '#filterCugAssignment', '#filterCugStaff'].join(','),
      function () {
        self.scheduleRefresh();
      }
    );

    /* -------------------------------------------------
           Number Range
        ------------------------------------------------- */

    $(document).on(
      'input',
      '#filterCugNumberFrom, #filterCugNumberTo',
      CugHelper.debounce(function () {
        self.scheduleRefresh();
      }, 450)
    );

    /* -------------------------------------------------
           Date Filter
        ------------------------------------------------- */

    $(document).on('change', '#filterCugAssignedFrom, #filterCugAssignedTo', function () {
      self.scheduleRefresh();
    });

    /* -------------------------------------------------
           Reset
        ------------------------------------------------- */

    $(document).on('click', '#btnResetCugFilter', function () {
      self.reset();
    });

    /* -------------------------------------------------
           Clear Advanced
        ------------------------------------------------- */

    $(document).on('click', '#btnClearAdvancedCugFilters', function () {
      self.clearAdvanced();
    });

    /* -------------------------------------------------
           Advanced Collapse
        ------------------------------------------------- */

    $(document).on('shown.bs.collapse hidden.bs.collapse', '#cugAdvancedFilters', function () {
      self.updateFilterState();
    });
  }

  /* =====================================================
       COMPANY → ENTITY
    ===================================================== */

  loadEntities(companyId) {
    const self = this;

    self.clearSelect('#filterCugEntity', 'All Entities');

    self.clearSelect('#filterCugBranch', 'All Branches');

    $('#filterCugEntity').prop('disabled', !companyId).trigger('change.select2');

    $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

    if (!companyId) {
      return;
    }

    const url = CugHelper.route('entities');

    if (!url) {
      return;
    }

    self.abortDependency('entities');

    self.dependencyRequests.entities = CugHelper.get(url, {
      company_id: companyId
    })

      .done(function (response) {
        const records = self.extractRecords(response, 'entities');

        self.populateSelect('#filterCugEntity', records, 'All Entities');
      })

      .fail(function (xhr, status) {
        if (status === 'abort') {
          return;
        }

        CugHelper.handleError(xhr, 'Unable to load entities.');
      });
  }

  /* =====================================================
       ENTITY → BRANCH
    ===================================================== */

  loadBranches(entityId) {
    const self = this;

    self.clearSelect('#filterCugBranch', 'All Branches');

    $('#filterCugBranch').prop('disabled', !entityId).trigger('change.select2');

    if (!entityId) {
      return;
    }

    const url = CugHelper.route('branches');

    if (!url) {
      return;
    }

    self.abortDependency('branches');

    self.dependencyRequests.branches = CugHelper.get(url, {
      entity_id: entityId
    })

      .done(function (response) {
        const records = self.extractRecords(response, 'branches');

        self.populateSelect('#filterCugBranch', records, 'All Branches');
      })

      .fail(function (xhr, status) {
        if (status === 'abort') {
          return;
        }

        CugHelper.handleError(xhr, 'Unable to load branches.');
      });
  }

  /* =====================================================
       STAFF
    ===================================================== */

  loadStaff(params = {}) {
    const self = this;

    const url = CugHelper.route('staff');

    if (!url) {
      return;
    }

    const select = $('#filterCugStaff');

    if (!select.length) {
      return;
    }

    self.abortDependency('staff');

    self.dependencyRequests.staff = CugHelper.get(url, params)

      .done(function (response) {
        const records = self.extractRecords(response, 'staff');

        self.populateSelect('#filterCugStaff', records, 'All Staff');
      })

      .fail(function (xhr, status) {
        if (status === 'abort') {
          return;
        }

        CugHelper.handleError(xhr, 'Unable to load staff.');
      });
  }

  /* =====================================================
       POPULATE SELECT
    ===================================================== */

  populateSelect(selector, records, placeholder) {
    const select = $(selector);

    if (!select.length) {
      return;
    }

    const currentValue = select.val();

    select.empty();

    select.append(new Option(placeholder, '', false, false));

    records.forEach(record => {
      const id = record.id ?? record.sno ?? record.value;

      const text =
        record.name ??
        record.label ??
        record.text ??
        record.company_name ??
        record.entity_name ??
        record.branch_name ??
        record.staff_name;

      if (id === undefined || text === undefined) {
        return;
      }

      select.append(new Option(text, id, false, String(id) === String(currentValue)));
    });

    select.trigger('change.select2');
  }

  /* =====================================================
       CLEAR SELECT
    ===================================================== */

  clearSelect(selector, placeholder) {
    const select = $(selector);

    if (!select.length) {
      return;
    }

    select.empty();

    select.append(new Option(placeholder, '', false, false));

    select.val(null);

    select.trigger('change.select2');
  }

  /* =====================================================
       EXTRACT RECORDS
    ===================================================== */

  extractRecords(response, key = null) {
    if (!response) {
      return [];
    }

    let records = response.data ?? response;

    if (key && records && !Array.isArray(records) && Array.isArray(records[key])) {
      records = records[key];
    }

    if (records && records.data && Array.isArray(records.data)) {
      records = records.data;
    }

    return Array.isArray(records) ? records : [];
  }

  /* =====================================================
       ABORT DEPENDENCY
    ===================================================== */

  abortDependency(name) {
    if (this.dependencyRequests[name]) {
      this.dependencyRequests[name].abort();

      this.dependencyRequests[name] = null;
    }
  }

  /* =====================================================
       FILTER OBJECT
    ===================================================== */

  getFilters() {
    return {
      search: this.getValue('#cugSearch'),

      company_id: this.getValue('#filterCugCompany'),

      entity_id: this.getValue('#filterCugEntity'),

      branch_id: this.getValue('#filterCugBranch'),

      status: this.getValue('#filterCugStatus'),

      provider: this.getValue('#filterCugProvider'),

      assignment_status: this.getValue('#filterCugAssignment'),

      staff_id: this.getValue('#filterCugStaff'),

      number_from: this.getValue('#filterCugNumberFrom'),

      number_to: this.getValue('#filterCugNumberTo'),

      assigned_from: this.getValue('#filterCugAssignedFrom'),

      assigned_to: this.getValue('#filterCugAssignedTo')
    };
  }

  /* =====================================================
       GET VALUE
    ===================================================== */

  getValue(selector) {
    return $(selector).val() || '';
  }

  /* =====================================================
       SCHEDULE REFRESH
    ===================================================== */

  scheduleRefresh() {
    clearTimeout(this.refreshTimer);

    this.updateFilterState();

    this.refreshTimer = setTimeout(() => {
      this.refreshAll();
    }, this.refreshDelay);
  }

  /* =====================================================
       REFRESH ALL
    ===================================================== */

  refreshAll() {
    /*
        |--------------------------------------------------------------------------
        | Dashboard
        |--------------------------------------------------------------------------
        */

    if (window.cugDashboard && typeof window.cugDashboard.load === 'function') {
      window.cugDashboard.load();
    }

    /*
        |--------------------------------------------------------------------------
        | DataTable
        |--------------------------------------------------------------------------
        */

    if (window.cugDataTable && typeof window.cugDataTable.reload === 'function') {
      window.cugDataTable.reload();
    }

    /*
        |--------------------------------------------------------------------------
        | Timeline
        |--------------------------------------------------------------------------
        */

    if (window.cugTimeline && typeof window.cugTimeline.load === 'function') {
      window.cugTimeline.load();
    }
  }

  /* =====================================================
       RESET
    ===================================================== */

  reset() {
    const self = this;

    self.silentChange = true;

    clearTimeout(self.refreshTimer);

    /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

    $('#cugSearch').val('');

    self.updateSearchClear();

    /*
        |--------------------------------------------------------------------------
        | Main Filters
        |--------------------------------------------------------------------------
        */

    self.resetSelect('#filterCugCompany');

    self.clearSelect('#filterCugEntity', 'All Entities');

    self.clearSelect('#filterCugBranch', 'All Branches');

    $('#filterCugEntity').prop('disabled', true).trigger('change.select2');

    $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

    self.resetSelect('#filterCugStatus');

    self.resetSelect('#filterCugProvider');

    self.resetSelect('#filterCugAssignment');

    self.resetSelect('#filterCugStaff');

    /*
        |--------------------------------------------------------------------------
        | Number Range
        |--------------------------------------------------------------------------
        */

    $('#filterCugNumberFrom').val('');

    $('#filterCugNumberTo').val('');

    /*
        |--------------------------------------------------------------------------
        | Dates
        |--------------------------------------------------------------------------
        */

    self.clearDate('#filterCugAssignedFrom');

    self.clearDate('#filterCugAssignedTo');

    /*
        |--------------------------------------------------------------------------
        | Card State
        |--------------------------------------------------------------------------
        */

    $('.cug-stat-card').removeClass('cug-stat-active');

    /*
        |--------------------------------------------------------------------------
        | Advanced Filter Summary
        |--------------------------------------------------------------------------
        */

    self.silentChange = false;

    self.updateFilterState();

    self.refreshAll();
  }

  /* =====================================================
       RESET SELECT
    ===================================================== */

  resetSelect(selector) {
    const select = $(selector);

    if (!select.length) {
      return;
    }

    select.val('').trigger('change.select2');
  }

  /* =====================================================
       CLEAR DATE
    ===================================================== */

  clearDate(selector) {
    const input = $(selector);

    if (!input.length) {
      return;
    }

    const picker = input.data('cug-flatpickr');

    if (picker && typeof picker.clear === 'function') {
      picker.clear();
    } else {
      input.val('');
    }
  }

  /* =====================================================
       CLEAR ADVANCED
    ===================================================== */

  clearAdvanced() {
    const self = this;

    self.silentChange = true;

    self.resetSelect('#filterCugStatus');

    self.resetSelect('#filterCugProvider');

    self.resetSelect('#filterCugAssignment');

    self.resetSelect('#filterCugStaff');

    $('#filterCugNumberFrom').val('');

    $('#filterCugNumberTo').val('');

    self.clearDate('#filterCugAssignedFrom');

    self.clearDate('#filterCugAssignedTo');

    self.silentChange = false;

    self.updateFilterState();

    self.refreshAll();
  }

  /* =====================================================
       SEARCH CLEAR
    ===================================================== */

  updateSearchClear() {
    const search = $('#cugSearch');

    const clearButton = $('#btnClearCugSearch');

    if (!search.length || !clearButton.length) {
      return;
    }

    clearButton.toggleClass('d-none', !search.val());
  }

  /* =====================================================
       FILTER STATE
    ===================================================== */

  updateFilterState() {
    const filters = this.getFilters();

    const ignored = ['search'];

    let count = 0;

    Object.keys(filters).forEach(key => {
      if (ignored.includes(key)) {
        return;
      }

      if (filters[key] !== '') {
        count++;
      }
    });

    /*
        |--------------------------------------------------------------------------
        | Filter Count
        |--------------------------------------------------------------------------
        */

    const badge = $('#cugFilterCount');

    badge

      .text(count)

      .toggleClass('d-none', count === 0);

    /*
        |--------------------------------------------------------------------------
        | Summary
        |--------------------------------------------------------------------------
        */

    const summary = $('#cugFilterSummary');

    const tags = $('#cugActiveFilterTags');

    if (!summary.length || !tags.length) {
      return;
    }

    tags.empty();

    const labels = {
      company_id: 'Company',

      entity_id: 'Entity',

      branch_id: 'Branch',

      status: 'Status',

      provider: 'Provider',

      assignment_status: 'Assignment',

      staff_id: 'Staff',

      number_from: 'Number From',

      number_to: 'Number To',

      assigned_from: 'Assigned From',

      assigned_to: 'Assigned To'
    };

    Object.keys(filters).forEach(key => {
      if (ignored.includes(key) || filters[key] === '') {
        return;
      }

      const label = labels[key] || key;

      const display = this.getDisplayValue(key, filters[key]);

      const tag = $(`
                    <span
                        class="cug-filter-tag"
                        data-filter-key="${CugHelper.escapeHtml(key)}">

                        ${CugHelper.escapeHtml(label)}:
                        ${CugHelper.escapeHtml(display)}

                        <button
                            type="button"
                            class="cug-remove-filter"
                            data-filter-key="${CugHelper.escapeHtml(key)}"
                            aria-label="Remove ${CugHelper.escapeHtml(label)}">

                            <i class="ti ti-x"></i>

                        </button>

                    </span>
                `);

      tags.append(tag);
    });

    summary.toggleClass('d-none', count === 0);
  }

  /* =====================================================
       DISPLAY FILTER VALUE
    ===================================================== */

  getDisplayValue(key, value) {
    let selector = null;

    switch (key) {
      case 'company_id':
        selector = '#filterCugCompany';

        break;

      case 'entity_id':
        selector = '#filterCugEntity';

        break;

      case 'branch_id':
        selector = '#filterCugBranch';

        break;

      case 'status':
        selector = '#filterCugStatus';

        break;

      case 'provider':
        selector = '#filterCugProvider';

        break;

      case 'assignment_status':
        selector = '#filterCugAssignment';

        break;

      case 'staff_id':
        selector = '#filterCugStaff';

        break;
    }

    if (selector) {
      const selectedText = $(selector).find('option:selected').text();

      if (selectedText && selectedText.trim()) {
        return selectedText.trim();
      }
    }

    return String(value);
  }

  /* =====================================================
       REMOVE INDIVIDUAL FILTER
    ===================================================== */

  removeFilter(key) {
    switch (key) {
      case 'company_id':
        this.resetSelect('#filterCugCompany');

        this.clearSelect('#filterCugEntity', 'All Entities');

        this.clearSelect('#filterCugBranch', 'All Branches');

        $('#filterCugEntity').prop('disabled', true).trigger('change.select2');

        $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

        break;

      case 'entity_id':
        this.resetSelect('#filterCugEntity');

        this.clearSelect('#filterCugBranch', 'All Branches');

        $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

        break;

      case 'branch_id':
        this.resetSelect('#filterCugBranch');

        break;

      case 'status':
        this.resetSelect('#filterCugStatus');

        break;

      case 'provider':
        this.resetSelect('#filterCugProvider');

        break;

      case 'assignment_status':
        this.resetSelect('#filterCugAssignment');

        break;

      case 'staff_id':
        this.resetSelect('#filterCugStaff');

        break;

      case 'number_from':
        $('#filterCugNumberFrom').val('');

        break;

      case 'number_to':
        $('#filterCugNumberTo').val('');

        break;

      case 'assigned_from':
        this.clearDate('#filterCugAssignedFrom');

        break;

      case 'assigned_to':
        this.clearDate('#filterCugAssignedTo');

        break;
    }

    this.scheduleRefresh();
  }

  /* =====================================================
       FILTER TAG CLICK
    ===================================================== */

  bindRemoveFilter() {
    const self = this;

    $(document).on('click', '.cug-remove-filter', function () {
      const key = $(this).data('filter-key');

      if (!key) {
        return;
      }

      self.removeFilter(key);
    });
  }
}

/* =========================================================
   GLOBAL INSTANCE
========================================================= */

$(function () {
  window.cugFilters = new CugFilters();

  cugFilters.init();

  cugFilters.bindRemoveFilter();
});
