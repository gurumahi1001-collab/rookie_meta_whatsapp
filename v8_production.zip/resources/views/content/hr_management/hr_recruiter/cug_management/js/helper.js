'use strict';

/**
 * =========================================================
 * CUG Management — Helper
 * =========================================================
 *
 * Responsibilities:
 *
 * 1. AJAX defaults
 * 2. CSRF handling
 * 3. API request wrapper
 * 4. Error normalization
 * 5. Notifications
 * 6. Button loading
 * 7. Page loading
 * 8. Confirmation dialog
 * 9. Debounce
 * 10. Number/date formatting
 * 11. HTML escaping
 * 12. Route resolver
 * =========================================================
 */

window.CugHelper = {
  /* =====================================================
       CONFIG
    ===================================================== */

  config: {
    currency: '₹',

    locale: 'en-IN',

    dateFormat: 'DD MMM YYYY',

    animationDuration: 500
  },

  /* =====================================================
       INIT
    ===================================================== */

  init() {
    this.setupAjax();

    this.initTooltips();
  },

  /* =====================================================
       AJAX SETUP
    ===================================================== */

  setupAjax() {
    const token = document

      .querySelector('meta[name="csrf-token"]')

      ?.getAttribute('content');

    if (!token) {
      console.warn('CUG Management: CSRF token not found.');

      return;
    }

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': token,

        'X-Requested-With': 'XMLHttpRequest'
      }
    });
  },

  /* =====================================================
       AJAX REQUEST
    ===================================================== */

  request(options = {}) {
    const defaults = {
      type: 'GET',

      dataType: 'json',

      timeout: 30000,

      processData: true,

      contentType: 'application/x-www-form-urlencoded; charset=UTF-8'
    };

    const settings = $.extend(true, {}, defaults, options);

    return $.ajax(settings);
  },

  /* =====================================================
       GET
    ===================================================== */

  get(url, data = {}) {
    return this.request({
      url: url,

      type: 'GET',

      data: data
    });
  },

  /* =====================================================
       POST
    ===================================================== */

  post(url, data = {}) {
    return this.request({
      url: url,

      type: 'POST',

      data: data
    });
  },

  /* =====================================================
       FORM DATA POST
    ===================================================== */

  postForm(url, form) {
    const formElement = form instanceof HTMLFormElement ? form : $(form)[0];

    if (!formElement) {
      return $.Deferred()

        .reject({
          message: 'Form could not be found.'
        })

        .promise();
    }

    const formData = new FormData(formElement);

    return $.ajax({
      url: url,

      type: 'POST',

      data: formData,

      processData: false,

      contentType: false,

      dataType: 'json',

      timeout: 30000
    });
  },

  /* =====================================================
       PUT
    ===================================================== */

  put(url, data = {}) {
    return this.request({
      url: url,

      type: 'POST',

      data: $.extend({}, data, {
        _method: 'PUT'
      })
    });
  },

  /* =====================================================
       DELETE
    ===================================================== */

  delete(url, data = {}) {
    return this.request({
      url: url,

      type: 'POST',

      data: $.extend({}, data, {
        _method: 'DELETE'
      })
    });
  },

  /* =====================================================
       ERROR HANDLER
    ===================================================== */

  getError(xhr) {
    if (!xhr) {
      return {
        status: 0,

        message: 'Unknown server error.',

        errors: {}
      };
    }

    const response = xhr.responseJSON || {};

    let message = response.message || response.error || 'Something went wrong. Please try again.';

    if (xhr.status === 0) {
      message = 'Unable to connect to the server.';
    }

    if (xhr.status === 401) {
      message = 'Your session has expired. Please login again.';
    }

    if (xhr.status === 403) {
      message = 'You do not have permission to perform this action.';
    }

    if (xhr.status === 404) {
      message = 'The requested resource was not found.';
    }

    if (xhr.status === 419) {
      message = 'Your session has expired. Please refresh the page.';
    }

    if (xhr.status >= 500) {
      message = 'Server error. Please try again later.';
    }

    return {
      status: xhr.status || 0,

      message: message,

      errors: response.errors || {}
    };
  },

  /* =====================================================
       SHOW ERROR
    ===================================================== */

  handleError(xhr, fallback = null) {
    const error = this.getError(xhr);

    this.error(fallback || error.message);

    return error;
  },

  /* =====================================================
       SUCCESS NOTIFICATION
    ===================================================== */

  success(message) {
    if (typeof toastr !== 'undefined') {
      toastr.success(message || 'Operation completed successfully.');

      return;
    }

    console.info(message);
  },

  /* =====================================================
       ERROR NOTIFICATION
    ===================================================== */

  error(message) {
    if (typeof toastr !== 'undefined') {
      toastr.error(message || 'Something went wrong.');

      return;
    }

    console.error(message);
  },

  /* =====================================================
       WARNING
    ===================================================== */

  warning(message) {
    if (typeof toastr !== 'undefined') {
      toastr.warning(message);

      return;
    }

    console.warn(message);
  },

  /* =====================================================
       INFO
    ===================================================== */

  info(message) {
    if (typeof toastr !== 'undefined') {
      toastr.info(message);

      return;
    }

    console.info(message);
  },

  /* =====================================================
       BUTTON LOADING
    ===================================================== */

  buttonLoading(button, loading = true) {
    const element = $(button);

    if (!element.length) {
      return;
    }

    if (loading) {
      if (!element.data('original-html')) {
        element.data('original-html', element.html());
      }

      element

        .addClass('cug-btn-loading')

        .prop('disabled', true);
    } else {
      const original = element.data('original-html');

      if (original !== undefined) {
        element.html(original);
      }

      element

        .removeClass('cug-btn-loading')

        .prop('disabled', false);
    }
  },

  /* =====================================================
       PAGE LOADING
    ===================================================== */

  pageLoading(show = true) {
    const page = $('#cugManagementPage');

    if (!page.length) {
      return;
    }

    let overlay = page.find('.cug-page-loading-overlay');

    if (show) {
      if (!overlay.length) {
        overlay = $(`
                    <div class="cug-page-loading-overlay">
                        <div class="cug-loading-spinner"></div>
                    </div>
                `);

        page.css('position', 'relative');

        page.append(overlay);
      }

      overlay.removeClass('d-none');
    } else {
      overlay.addClass('d-none');
    }
  },

  /* =====================================================
       TABLE LOADING
    ===================================================== */

  tableLoading(show = true) {
    const tableCard = $('.cug-table-card');

    if (!tableCard.length) {
      return;
    }

    let overlay = tableCard.find('.cug-table-loading-overlay');

    if (show) {
      if (!overlay.length) {
        overlay = $(`
                    <div class="cug-table-loading-overlay">
                        <div class="cug-loading-spinner"></div>
                    </div>
                `);

        tableCard.css('position', 'relative');

        tableCard.append(overlay);
      }

      overlay.removeClass('d-none');
    } else {
      overlay.addClass('d-none');
    }
  },

  /* =====================================================
       MODAL LOADING
    ===================================================== */

  modalLoading(modal, show = true) {
    const element = $(modal);

    if (!element.length) {
      return;
    }

    let overlay = element.find('.cug-modal-loading-overlay');

    if (show) {
      if (!overlay.length) {
        overlay = $(`
                    <div class="cug-modal-loading-overlay">
                        <div class="cug-loading-spinner"></div>
                    </div>
                `);

        element

          .find('.modal-content')

          .css('position', 'relative')

          .append(overlay);
      }

      overlay.removeClass('d-none');
    } else {
      overlay.addClass('d-none');
    }
  },

  /* =====================================================
       CONFIRM
    ===================================================== */

  confirm(options = {}) {
    const defaults = {
      title: 'Are you sure?',

      text: 'This action cannot be undone.',

      confirmText: 'Confirm',

      cancelText: 'Cancel',

      type: 'warning'
    };

    const settings = $.extend({}, defaults, options);

    /*
        |--------------------------------------------------------------------------
        | SweetAlert2
        |--------------------------------------------------------------------------
        */

    if (typeof Swal !== 'undefined') {
      return Swal.fire({
        title: settings.title,

        text: settings.text,

        icon: settings.type,

        showCancelButton: true,

        confirmButtonText: settings.confirmText,

        cancelButtonText: settings.cancelText,

        reverseButtons: true,

        customClass: {
          confirmButton: 'btn btn-primary ms-2',

          cancelButton: 'btn btn-label-secondary'
        },

        buttonsStyling: false
      }).then(result => {
        return result.isConfirmed;
      });
    }

    /*
        |--------------------------------------------------------------------------
        | Native Fallback
        |--------------------------------------------------------------------------
        */

    return Promise.resolve(window.confirm(settings.title + '\n\n' + settings.text));
  },

  /* =====================================================
       DEBOUNCE
    ===================================================== */

  debounce(callback, delay = 400) {
    let timer = null;

    return function (...args) {
      clearTimeout(timer);

      timer = setTimeout(() => {
        callback.apply(this, args);
      }, delay);
    };
  },

  /* =====================================================
       THROTTLE
    ===================================================== */

  throttle(callback, delay = 300) {
    let waiting = false;

    return function (...args) {
      if (waiting) {
        return;
      }

      callback.apply(this, args);

      waiting = true;

      setTimeout(() => {
        waiting = false;
      }, delay);
    };
  },

  /* =====================================================
       NUMBER FORMAT
    ===================================================== */

  number(value, decimals = 0) {
    const number = Number(value || 0);

    return number.toLocaleString(
      this.config.locale,

      {
        minimumFractionDigits: decimals,

        maximumFractionDigits: decimals
      }
    );
  },

  /* =====================================================
       CURRENCY
    ===================================================== */

  currency(value, decimals = 2) {
    return this.config.currency + ' ' + this.number(value, decimals);
  },

  /* =====================================================
       PERCENTAGE
    ===================================================== */

  percentage(value, decimals = 1) {
    const number = Number(value || 0);

    return number.toFixed(decimals) + '%';
  },

  /* =====================================================
       ESCAPE HTML
    ===================================================== */

  escapeHtml(value) {
    if (value === null || value === undefined) {
      return '';
    }

    return String(value)
      .replace(/&/g, '&amp;')

      .replace(/</g, '&lt;')

      .replace(/>/g, '&gt;')

      .replace(/"/g, '&quot;')

      .replace(/'/g, '&#039;');
  },

  /* =====================================================
       INITIALS
    ===================================================== */

  initials(name) {
    if (!name) {
      return '?';
    }

    const parts = String(name)
      .trim()

      .split(/\s+/)

      .filter(Boolean);

    if (!parts.length) {
      return '?';
    }

    if (parts.length === 1) {
      return parts[0]

        .substring(0, 2)

        .toUpperCase();
    }

    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  },

  /* =====================================================
       EMPTY VALUE
    ===================================================== */

  value(value, fallback = '—') {
    if (value === null || value === undefined || value === '') {
      return fallback;
    }

    return value;
  },

  /* =====================================================
       ROUTE
    ===================================================== */

  route(name, id = null) {
    if (!window.cugRoutes || !window.cugRoutes[name]) {
      console.error(`CUG route "${name}" is not defined.`);

      return null;
    }

    let url = window.cugRoutes[name];

    if (id !== null) {
      url = url.replace(':id', encodeURIComponent(id));
    }

    return url;
  },

  /* =====================================================
       DATE
    ===================================================== */

  formatDate(value) {
    if (!value) {
      return '—';
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return date.toLocaleDateString(
      this.config.locale,

      {
        day: '2-digit',

        month: 'short',

        year: 'numeric'
      }
    );
  },

  /* =====================================================
       FORM RESET
    ===================================================== */

  resetForm(form) {
    const element = $(form);

    if (!element.length) {
      return;
    }

    const formNode = element[0];

    if (formNode instanceof HTMLFormElement) {
      formNode.reset();
    }

    element

      .find('.is-invalid')

      .removeClass('is-invalid');

    element

      .find('.invalid-feedback')

      .remove();

    element

      .find('select')

      .val(null)

      .trigger('change');
  },

  /* =====================================================
       VALIDATION
    ===================================================== */

  showValidationErrors(form, errors = {}) {
    const element = $(form);

    if (!element.length) {
      return;
    }

    element

      .find('.is-invalid')

      .removeClass('is-invalid');

    element

      .find('.invalid-feedback.cug-validation-error')

      .remove();

    Object.keys(errors)

      .forEach(field => {
        const messages = Array.isArray(errors[field]) ? errors[field] : [errors[field]];

        const input = element.find(`[name="${field}"]`);

        if (!input.length) {
          return;
        }

        input.addClass('is-invalid');

        const feedback = $(`
                    <div class="invalid-feedback cug-validation-error">
                        ${this.escapeHtml(messages[0])}
                    </div>
                `);

        if (input.next('.select2-container').length) {
          input

            .next('.select2-container')

            .after(feedback);
        } else {
          input.after(feedback);
        }
      });
  },

  /* =====================================================
       CLEAR VALIDATION
    ===================================================== */

  clearValidation(form) {
    const element = $(form);

    element

      .find('.is-invalid')

      .removeClass('is-invalid');

    element

      .find('.cug-validation-error')

      .remove();
  },

  /* =====================================================
       TOOLTIP
    ===================================================== */

  initTooltips() {
    if (typeof bootstrap === 'undefined') {
      return;
    }

    document

      .querySelectorAll('[data-bs-toggle="tooltip"]')

      .forEach(element => {
        bootstrap.Tooltip.getOrCreateInstance(element);
      });
  }
};

$(function () {
  CugHelper.init();
});

// CugHelper.get()
// CugHelper.post()
// CugHelper.postForm()

// CugHelper.success()
// CugHelper.error()
// CugHelper.warning()

// CugHelper.confirm()

// CugHelper.buttonLoading()
// CugHelper.pageLoading()
// CugHelper.tableLoading()
// CugHelper.modalLoading()

// CugHelper.debounce()
// CugHelper.throttle()

// CugHelper.number()
// CugHelper.percentage()

// CugHelper.escapeHtml()
// CugHelper.initials()

// CugHelper.route()

// CugHelper.showValidationErrors()
// CugHelper.clearValidation()
