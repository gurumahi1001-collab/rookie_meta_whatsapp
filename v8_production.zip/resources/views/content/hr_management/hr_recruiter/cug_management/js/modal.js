'use strict';

/**
 * =========================================================
 * CUG Management — Modal Controller
 * =========================================================
 *
 * Responsibilities
 *
 * 1. Add CUG
 * 2. Edit CUG
 * 3. Assign CUG to Staff
 * 4. Change / Transfer Staff
 * 5. Release CUG
 * 6. Deactivate CUG
 * 7. Delete CUG
 * 8. Assignment History
 * 9. Call History
 * 10. Company → Entity → Branch
 * 11. Staff AJAX search
 * 12. Modal state management
 *
 * =========================================================
 */

class CugModalController {
  constructor() {
    this.currentCugId = null;

    this.currentCug = null;

    this.currentModal = null;

    this.request = null;

    this.historyRequest = null;

    this.callHistoryRequest = null;

    this.callHistoryPage = 1;

    this.callHistoryPerPage = 25;

    this.initialized = false;

    this.staffSearchDelay = null;
  }

  /* =====================================================
       INIT
    ===================================================== */

  init() {
    if (this.initialized) {
      return;
    }

    this.initialized = true;

    this.registerEvents();

    this.initializeDatePickers();

    this.initializeSelects();

    this.initializeCounters();
  }

  /* =====================================================
       EVENTS
    ===================================================== */

  registerEvents() {
    const self = this;

    /* -------------------------------------------------
           Add CUG
        ------------------------------------------------- */

    $(document).on('click', '#btnAddCugNumber', function () {
      self.openAddNumber();
    });

    /* -------------------------------------------------
           DataTable → View
        ------------------------------------------------- */

    $(document).on('cug:view', function (event, cugId) {
      self.openView(cugId);
    });

    /* -------------------------------------------------
           DataTable → Edit
        ------------------------------------------------- */

    $(document).on('cug:edit', function (event, cugId) {
      self.openEditNumber(cugId);
    });

    /* -------------------------------------------------
           DataTable → Assign
        ------------------------------------------------- */

    $(document).on('cug:assign', function (event, cugId) {
      self.openAssign(cugId);
    });

    /* -------------------------------------------------
           DataTable → Change Staff
        ------------------------------------------------- */

    $(document).on('cug:change', function (event, cugId) {
      self.openChangeStaff(cugId);
    });

    /* -------------------------------------------------
           DataTable → Release
        ------------------------------------------------- */

    $(document).on('cug:release', function (event, cugId) {
      self.releaseCug(cugId);
    });

    /* -------------------------------------------------
           Call History
        ------------------------------------------------- */

    $(document).on('cug:call-history', function (event, cugId) {
      self.openHistory(cugId, 'calls');
    });

    /* -------------------------------------------------
           Assignment History
        ------------------------------------------------- */

    $(document).on('cug:assignment-history', function (event, cugId) {
      self.openHistory(cugId, 'assignments');
    });

    /* -------------------------------------------------
           Deactivate
        ------------------------------------------------- */

    $(document).on('cug:deactivate', function (event, cugId) {
      self.deactivateCug(cugId);
    });

    /* -------------------------------------------------
           Delete
        ------------------------------------------------- */

    $(document).on('cug:delete', function (event, cugId) {
      self.deleteCug(cugId);
    });

    /* -------------------------------------------------
           Add / Edit Form
        ------------------------------------------------- */

    $(document).on('submit', '#cugNumberForm', function (event) {
      event.preventDefault();

      self.submitNumberForm(this);
    });

    /* -------------------------------------------------
           Assign Form
        ------------------------------------------------- */

    $(document).on('submit', '#cugAssignForm', function (event) {
      event.preventDefault();

      self.submitAssignForm(this);
    });

    /* -------------------------------------------------
           Change Staff Form
        ------------------------------------------------- */

    $(document).on('submit', '#cugChangeStaffForm', function (event) {
      event.preventDefault();

      self.submitChangeStaffForm(this);
    });

    /* -------------------------------------------------
           Company Change
        ------------------------------------------------- */

    $(document).on('change', '#cugCompany', function () {
      self.loadEntities($(this).val());
    });

    /* -------------------------------------------------
           Entity Change
        ------------------------------------------------- */

    $(document).on('change', '#cugEntity', function () {
      self.loadBranches($(this).val());
    });

    /* -------------------------------------------------
           Assignment Staff
        ------------------------------------------------- */

    $(document).on('change', '#cugAssignStaff', function () {
      self.loadStaffPreview($(this).val(), 'assign');
    });

    /* -------------------------------------------------
           Replacement Staff
        ------------------------------------------------- */

    $(document).on('change', '#cugReplacementStaff', function () {
      self.loadStaffPreview($(this).val(), 'replacement');
    });

    /* -------------------------------------------------
           Call Filter
        ------------------------------------------------- */

    $(document).on('click', '#btnFilterCugCalls', function () {
      self.callHistoryPage = 1;

      self.loadCallHistory();
    });

    /* -------------------------------------------------
           Assignment Tab
        ------------------------------------------------- */

    $(document).on('shown.bs.tab', '#cugAssignmentHistoryTab', function () {
      if (self.currentCugId) {
        self.loadAssignmentHistory();
      }
    });

    /* -------------------------------------------------
           Call Tab
        ------------------------------------------------- */

    $(document).on('shown.bs.tab', '#cugCallHistoryTab', function () {
      if (self.currentCugId) {
        self.loadCallHistory();
      }
    });

    /* -------------------------------------------------
           Number input
        ------------------------------------------------- */

    $(document).on('input', '#cugNumber', function () {
      self.cleanNumberInput(this);
    });

    /* -------------------------------------------------
           Remarks counters
        ------------------------------------------------- */

    $(document).on('input', '#cugRemarks', function () {
      self.updateCounter(this, '#cugRemarksCounter', 500);
    });

    $(document).on('input', '#cugAssignRemarks', function () {
      self.updateCounter(this, '#cugAssignRemarksCounter', 500);
    });

    $(document).on('input', '#cugChangeRemarks', function () {
      self.updateCounter(this, '#cugChangeRemarksCounter', 500);
    });

    /* -------------------------------------------------
           Modal hidden
        ------------------------------------------------- */

    $(document).on('hidden.bs.modal', '#cugNumberModal', function () {
      self.resetNumberModal();
    });

    $(document).on('hidden.bs.modal', '#cugAssignModal', function () {
      self.resetAssignModal();
    });

    $(document).on('hidden.bs.modal', '#cugChangeStaffModal', function () {
      self.resetChangeStaffModal();
    });

    $(document).on('hidden.bs.modal', '#cugHistoryModal', function () {
      self.resetHistoryModal();
    });
  }

  /* =====================================================
       DATE PICKERS
    ===================================================== */

  initializeDatePickers() {
    const self = this;

    if (typeof flatpickr === 'function') {
      flatpickr('.cug-date-input', {
        dateFormat: 'Y-m-d',
        allowInput: true
      });

      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Native fallback
        |--------------------------------------------------------------------------
        */

    $('.cug-date-input').attr('type', 'date');
  }

  /* =====================================================
       SELECTS
    ===================================================== */

  initializeSelects() {
    /*
        |--------------------------------------------------------------------------
        | Staff Select2
        |--------------------------------------------------------------------------
        */

    this.initializeStaffSelect('#cugAssignStaff');

    this.initializeStaffSelect('#cugReplacementStaff');
  }

  initializeStaffSelect(selector) {
    const element = $(selector);

    if (!element.length) {
      return;
    }

    if (element.hasClass('select2-hidden-accessible')) {
      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Select2 available
        |--------------------------------------------------------------------------
        */

    if (typeof $.fn.select2 === 'function') {
      element.select2({
        width: '100%',

        dropdownParent: element.closest('.modal'),

        placeholder: 'Search Staff',

        allowClear: true,

        minimumInputLength: 2,

        ajax: {
          delay: 300,

          transport: (params, success, failure) => {
            const xhr = $.ajax({
              url: this.route('staffSearch'),

              type: 'GET',

              data: {
                q: params.data.q,

                page: params.data.page || 1
              }
            });

            xhr.done(success);

            xhr.fail(failure);

            return xhr;
          },

          processResults: function (response, params) {
            params.page = params.page || 1;

            const rows = response?.data || [];

            return {
              results: rows.map(function (staff) {
                return {
                  id: staff.id ?? staff.sno ?? staff.staff_id,

                  text: staff.staff_name,

                  staff: staff
                };
              }),

              pagination: {
                more: Boolean(response?.pagination?.more)
              }
            };
          }
        },

        templateResult: function (item) {
          if (!item.id) {
            return item.text;
          }

          const staff = item.staff || {};

          return `
                            <div class="cug-select-staff-option">

                                <div class="cug-select-staff-avatar">

                                    ${CugHelper.escapeHtml(CugHelper.initials(staff.staff_name || item.text))}

                                </div>

                                <div>

                                    <strong>
                                        ${CugHelper.escapeHtml(staff.staff_name || item.text)}
                                    </strong>

                                    <small>

                                        ${CugHelper.escapeHtml(staff.staff_id || '')}

                                        ${
                                          staff.department_name
                                            ? ` · ${CugHelper.escapeHtml(staff.department_name)}`
                                            : ''
                                        }

                                    </small>

                                </div>

                            </div>
                        `;
        },

        templateSelection: function (item) {
          return CugHelper.escapeHtml(item.text || '');
        },

        escapeMarkup: function (markup) {
          return markup;
        }
      });
    }
  }

  /* =====================================================
       ADD CUG
    ===================================================== */

  openAddNumber() {
    this.currentCugId = null;

    this.currentCug = null;

    this.resetNumberModal();

    $('#cugNumberModalLabel').text('Add CUG Number');

    $('#cugNumberModalSubtitle').text('Add a new CUG number to the managed number pool.');

    $('#cugNumberMethod').val('POST');

    $('#cugNumberId').val('');

    $('#cugSaveButtonText').text('Add CUG Number');

    $('#cugSaveButtonIcon').attr('class', 'ti ti-device-mobile-plus me-1');

    $('#cugNumberModal').modal('show');

    this.loadCompanies();
  }

  /* =====================================================
       EDIT CUG
    ===================================================== */

  openEditNumber(cugId) {
    if (!cugId) {
      return;
    }

    this.currentCugId = cugId;

    this.resetNumberModal();

    $('#cugNumberModalLabel').text('Edit CUG Number');

    $('#cugNumberModalSubtitle').text('Update the CUG number information.');

    $('#cugNumberMethod').val('PUT');

    $('#cugSaveButtonText').text('Update CUG Number');

    $('#cugSaveButtonIcon').attr('class', 'ti ti-device-mobile-check me-1');

    $('#cugNumberModal').modal('show');

    this.setButtonLoading('#btnSaveCugNumber', true, 'Loading...');

    this.loadCug(cugId)

      .done(response => {
        const data = this.extractData(response);

        this.currentCug = data;

        this.populateNumberForm(data);
      })

      .fail(xhr => {
        this.showModalError('#cugNumberFormAlert', '#cugNumberFormAlertMessage', xhr, 'Unable to load CUG number.');
      })

      .always(() => {
        this.setButtonLoading('#btnSaveCugNumber', false);
      });
  }

  /* =====================================================
       LOAD CUG
    ===================================================== */

  loadCug(cugId) {
    return $.ajax({
      url: this.route('show', cugId),

      type: 'GET',

      dataType: 'json'
    });
  }

  /* =====================================================
       POPULATE NUMBER FORM
    ===================================================== */

  populateNumberForm(data) {
    $('#cugNumberId').val(data.sno ?? data.id ?? '');

    $('#cugNumber').val(data.cug_number ?? '');

    $('#cugCode').val(data.cug_code ?? '');

    $('#cugProvider').val(data.provider ?? '');

    $('#cugStatus').val(String(data.status ?? 0));

    $('#cugRemarks').val(data.remarks ?? '');

    this.updateCounter(document.getElementById('cugRemarks'), '#cugRemarksCounter', 500);

    /*
        |--------------------------------------------------------------------------
        | Company
        |--------------------------------------------------------------------------
        */

    this.setSelectValue('#cugCompany', data.company_id, data.company_name);

    /*
        |--------------------------------------------------------------------------
        | Entity
        |--------------------------------------------------------------------------
        */

    this.loadEntities(data.company_id, data.entity_id, data.entity_name);

    /*
        |--------------------------------------------------------------------------
        | Branch
        |--------------------------------------------------------------------------
        */

    if (data.entity_id) {
      this.loadBranches(data.entity_id, data.branch_id, data.branch_name);
    }
  }

  /* =====================================================
       NUMBER FORM SUBMIT
    ===================================================== */

  submitNumberForm(form) {
    const self = this;

    this.clearModalError('#cugNumberFormAlert');

    if (!this.validateNumberForm(form)) {
      return;
    }

    const id = $('#cugNumberId').val();

    const method = $('#cugNumberMethod').val() || 'POST';

    const url = method === 'PUT' ? this.route('update', id) : this.route('store');

    const data = $(form).serialize();

    this.setButtonLoading('#btnSaveCugNumber', true, method === 'PUT' ? 'Updating...' : 'Saving...');

    $.ajax({
      url: url,

      type: 'POST',

      data: data,

      dataType: 'json'
    })

      .done(function (response) {
        self.handleSuccess(
          response,
          method === 'PUT' ? 'CUG number updated successfully.' : 'CUG number added successfully.'
        );

        self.closeModal('#cugNumberModal');

        self.refreshAfterChange();
      })

      .fail(function (xhr) {
        self.showModalError('#cugNumberFormAlert', '#cugNumberFormAlertMessage', xhr, 'Unable to save CUG number.');
      })

      .always(function () {
        self.setButtonLoading('#btnSaveCugNumber', false);
      });
  }

  /* =====================================================
       VALIDATE NUMBER
    ===================================================== */

  validateNumberForm(form) {
    const number = $.trim($('#cugNumber').val());

    const provider = $('#cugProvider').val();

    const company = $('#cugCompany').val();

    if (!number) {
      this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'CUG number is required.');

      $('#cugNumber').trigger('focus');

      return false;
    }

    if (!/^[0-9+\-\s]{7,20}$/.test(number)) {
      this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Enter a valid CUG number.');

      $('#cugNumber').trigger('focus');

      return false;
    }

    if (!provider) {
      this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Please select a provider.');

      $('#cugProvider').trigger('focus');

      return false;
    }

    if (!company) {
      this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Please select a company.');

      $('#cugCompany').trigger('focus');

      return false;
    }

    return true;
  }

  /* =====================================================
       COMPANIES
    ===================================================== */

  loadCompanies(selectedId = null, selectedName = null) {
    const select = $('#cugCompany');

    if (!select.length) {
      return;
    }

    this.setSelectLoading(select, 'Loading companies...');

    $.ajax({
      url: this.route('companies'),

      type: 'GET',

      dataType: 'json'
    })

      .done(response => {
        const rows = this.extractRows(response);

        this.populateSelect(select, rows, selectedId, selectedName, 'Select Company');
      })

      .fail(xhr => {
        this.setSelectError(select, 'Unable to load companies');
      });
  }

  /* =====================================================
       ENTITIES
    ===================================================== */

  loadEntities(companyId, selectedId = null, selectedName = null) {
    const entity = $('#cugEntity');

    const branch = $('#cugBranch');

    entity.prop('disabled', true);

    branch.prop('disabled', true);

    this.clearSelect(entity, 'Select Entity');

    this.clearSelect(branch, 'Select Branch');

    if (!companyId) {
      return;
    }

    this.setSelectLoading(entity, 'Loading entities...');

    $.ajax({
      url: this.route('entities'),

      type: 'GET',

      data: {
        company_id: companyId
      },

      dataType: 'json'
    })

      .done(response => {
        const rows = this.extractRows(response);

        this.populateSelect(entity, rows, selectedId, selectedName, 'Select Entity');

        entity.prop('disabled', false);
      })

      .fail(() => {
        this.setSelectError(entity, 'Unable to load entities');
      });
  }

  /* =====================================================
       BRANCHES
    ===================================================== */

  loadBranches(entityId, selectedId = null, selectedName = null) {
    const branch = $('#cugBranch');

    branch.prop('disabled', true);

    this.clearSelect(branch, 'Select Branch');

    if (!entityId) {
      return;
    }

    this.setSelectLoading(branch, 'Loading branches...');

    $.ajax({
      url: this.route('branches'),

      type: 'GET',

      data: {
        entity_id: entityId
      },

      dataType: 'json'
    })

      .done(response => {
        const rows = this.extractRows(response);

        this.populateSelect(branch, rows, selectedId, selectedName, 'Select Branch');

        branch.prop('disabled', false);
      })

      .fail(() => {
        this.setSelectError(branch, 'Unable to load branches');
      });
  }

  /* =====================================================
       STAFF PREVIEW
    ===================================================== */

  loadStaffPreview(staffId, type) {
    if (!staffId) {
      if (type === 'assign') {
        $('#cugAssignStaffPreview').addClass('d-none');

        $('#cugAssignStaffWarning').addClass('d-none');
      } else {
        $('#cugReplacementStaffPreview').addClass('d-none');

        $('#cugReplacementStaffWarning').addClass('d-none');
      }

      return;
    }

    $.ajax({
      url: this.route('staffShow', staffId),

      type: 'GET',

      dataType: 'json'
    })

      .done(response => {
        const staff = this.extractData(response);

        this.populateStaffPreview(staff, type);
      })

      .fail(xhr => {
        this.showToastError(xhr, 'Unable to load staff details.');
      });
  }

  /* =====================================================
       STAFF PREVIEW UI
    ===================================================== */

  populateStaffPreview(staff, type) {
    const name = staff.staff_name || staff.name || 'Unknown Staff';

    const staffCode = staff.staff_id || staff.staff_code || staff.id || '—';

    const department = staff.department_name || '—';

    const designation = staff.designation || staff.job_role_name || '—';

    const initials = CugHelper.initials(name);

    if (type === 'assign') {
      $('#cugAssignStaffInitials').text(initials);

      $('#cugAssignStaffName').text(name);

      $('#cugAssignStaffId').text(staffCode);

      $('#cugAssignStaffDepartment').text(department);

      $('#cugAssignStaffDesignation').text(designation);

      $('#cugAssignStaffPreview').removeClass('d-none');

      this.updateExistingCugWarning(staff, 'assign');
    } else {
      $('#cugReplacementStaffInitials').text(initials);

      $('#cugReplacementStaffName').text(name);

      $('#cugReplacementStaffId').text(staffCode);

      $('#cugReplacementStaffDepartment').text(department);

      $('#cugReplacementStaffDesignation').text(designation);

      $('#cugReplacementStaffPreview').removeClass('d-none');

      this.updateExistingCugWarning(staff, 'replacement');
    }
  }

  /* =====================================================
       EXISTING CUG WARNING
    ===================================================== */

  updateExistingCugWarning(staff, type) {
    const existing = staff.existing_cug_number || staff.current_cug_number || staff.cug_number || null;

    if (type === 'assign') {
      const warning = $('#cugAssignStaffWarning');

      if (existing) {
        $('#cugAssignExistingNumber').text(existing);

        $('#cugAssignStaffWarningText').text('This staff member already has an assigned CUG number.');

        warning.removeClass('d-none');
      } else {
        warning.addClass('d-none');
      }
    } else {
      const warning = $('#cugReplacementStaffWarning');

      if (existing) {
        $('#cugReplacementExistingNumber').text(existing);

        $('#cugReplacementStaffWarningText').text('This staff member already has an assigned CUG number.');

        warning.removeClass('d-none');
      } else {
        warning.addClass('d-none');
      }
    }
  }

  /* =====================================================
       OPEN ASSIGN
    ===================================================== */

  openAssign(cugId) {
    if (!cugId) {
      return;
    }

    this.currentCugId = cugId;

    this.resetAssignModal();

    $('#cugAssignNumberId').val(cugId);

    $('#cugAssignModal').modal('show');

    this.setButtonLoading('#btnAssignCug', true, 'Loading...');

    this.loadCug(cugId)

      .done(response => {
        const data = this.extractData(response);

        this.currentCug = data;

        this.populateAssignCug(data);
      })

      .fail(xhr => {
        this.showModalError('#cugAssignFormAlert', '#cugAssignFormAlertMessage', xhr, 'Unable to load CUG number.');
      })

      .always(() => {
        this.setButtonLoading('#btnAssignCug', false);
      });
  }

  /* =====================================================
       ASSIGN CUG SUMMARY
    ===================================================== */

  populateAssignCug(data) {
    $('#cugAssignNumber').text(data.cug_number || '—');

    $('#cugAssignProvider').text(data.provider || '—');

    $('#cugAssignCurrentStatus').html(this.renderStatus(data.status, data.status_label));

    /*
        |--------------------------------------------------------------------------
        | Default assignment date
        |--------------------------------------------------------------------------
        */

    if (!$('#cugAssignDate').val()) {
      $('#cugAssignDate').val(this.today());
    }

    /*
        |--------------------------------------------------------------------------
        | Assignment type
        |--------------------------------------------------------------------------
        */

    $('#cugAssignmentType').val('NEW');
  }

  /* =====================================================
       SUBMIT ASSIGN
    ===================================================== */

  submitAssignForm(form) {
    const self = this;

    this.clearModalError('#cugAssignFormAlert');

    if (!this.validateAssignForm(form)) {
      return;
    }

    const data = $(form).serialize();

    this.setButtonLoading('#btnAssignCug', true, 'Assigning...');

    $.ajax({
      url: this.route('assign'),

      type: 'POST',

      data: data,

      dataType: 'json'
    })

      .done(function (response) {
        self.handleSuccess(response, 'CUG number assigned successfully.');

        self.closeModal('#cugAssignModal');

        self.refreshAfterChange();
      })

      .fail(function (xhr) {
        self.showModalError('#cugAssignFormAlert', '#cugAssignFormAlertMessage', xhr, 'Unable to assign CUG number.');
      })

      .always(function () {
        self.setButtonLoading('#btnAssignCug', false);
      });
  }

  /* =====================================================
       VALIDATE ASSIGN
    ===================================================== */

  validateAssignForm(form) {
    const cugId = $('#cugAssignNumberId').val();

    const staffId = $('#cugAssignStaff').val();

    const date = $('#cugAssignDate').val();

    if (!cugId) {
      this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'CUG number was not selected.');

      return false;
    }

    if (!staffId) {
      this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'Please select a staff member.');

      $('#cugAssignStaff').trigger('focus');

      return false;
    }

    if (!date) {
      this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'Assignment date is required.');

      return false;
    }

    return true;
  }

  /* =====================================================
       OPEN CHANGE STAFF
    ===================================================== */

  openChangeStaff(cugId) {
    if (!cugId) {
      return;
    }

    this.currentCugId = cugId;

    this.resetChangeStaffModal();

    $('#cugChangeCugId').val(cugId);

    $('#cugChangeStaffModal').modal('show');

    this.setButtonLoading('#btnChangeCugStaff', true, 'Loading...');

    this.loadCug(cugId)

      .done(response => {
        const data = this.extractData(response);

        this.currentCug = data;

        this.populateChangeStaff(data);
      })

      .fail(xhr => {
        this.showModalError(
          '#cugChangeStaffFormAlert',
          '#cugChangeStaffFormAlertMessage',
          xhr,
          'Unable to load current CUG assignment.'
        );
      })

      .always(() => {
        this.setButtonLoading('#btnChangeCugStaff', false);
      });
  }

  /* =====================================================
       POPULATE CHANGE STAFF
    ===================================================== */

  populateChangeStaff(data) {
    $('#cugChangeCugNumber').text(data.cug_number || '—');

    $('#cugChangeCugProvider').text(data.provider || '—');

    const staff = data.current_staff || data.staff || {};

    const name = staff.staff_name || data.staff_name || 'Unassigned';

    const staffCode = staff.staff_id || data.staff_code || data.staff_id || '—';

    const department = staff.department_name || data.department_name || '—';

    const designation = staff.designation || staff.job_role_name || data.designation || '—';

    $('#cugCurrentStaffInitials').text(CugHelper.initials(name));

    $('#cugCurrentStaffName').text(name);

    $('#cugCurrentStaffId').text(staffCode);

    $('#cugCurrentStaffDepartment').text(department);

    $('#cugCurrentStaffDesignation').text(designation);

    /*
        |--------------------------------------------------------------------------
        | Effective date
        |--------------------------------------------------------------------------
        */

    $('#cugChangeEffectiveDate').val(this.today());
  }

  /* =====================================================
       SUBMIT CHANGE STAFF
    ===================================================== */

  submitChangeStaffForm(form) {
    const self = this;

    this.clearModalError('#cugChangeStaffFormAlert');

    if (!this.validateChangeStaffForm(form)) {
      return;
    }

    const confirmed = window.confirm(
      'Are you sure you want to transfer this CUG number to the selected staff member? The current assignment will be closed and preserved in history.'
    );

    if (!confirmed) {
      return;
    }

    this.setButtonLoading('#btnChangeCugStaff', true, 'Transferring...');

    $.ajax({
      url: this.route('changeStaff'),

      type: 'POST',

      data: $(form).serialize(),

      dataType: 'json'
    })

      .done(function (response) {
        self.handleSuccess(response, 'CUG staff changed successfully.');

        self.closeModal('#cugChangeStaffModal');

        self.refreshAfterChange();
      })

      .fail(function (xhr) {
        self.showModalError(
          '#cugChangeStaffFormAlert',
          '#cugChangeStaffFormAlertMessage',
          xhr,
          'Unable to change CUG staff.'
        );
      })

      .always(function () {
        self.setButtonLoading('#btnChangeCugStaff', false);
      });
  }

  /* =====================================================
       VALIDATE CHANGE STAFF
    ===================================================== */

  validateChangeStaffForm(form) {
    const cugId = $('#cugChangeCugId').val();

    const staffId = $('#cugReplacementStaff').val();

    const date = $('#cugChangeEffectiveDate').val();

    const reason = $('#cugTransferReason').val();

    const remarks = $.trim($('#cugChangeRemarks').val());

    if (!cugId) {
      this.showModalMessage(
        '#cugChangeStaffFormAlert',
        '#cugChangeStaffFormAlertMessage',
        'CUG number was not selected.'
      );

      return false;
    }

    if (!staffId) {
      this.showModalMessage(
        '#cugChangeStaffFormAlert',
        '#cugChangeStaffFormAlertMessage',
        'Please select the replacement staff.'
      );

      return false;
    }

    if (!date) {
      this.showModalMessage(
        '#cugChangeStaffFormAlert',
        '#cugChangeStaffFormAlertMessage',
        'Effective date is required.'
      );

      return false;
    }

    if (!reason) {
      this.showModalMessage(
        '#cugChangeStaffFormAlert',
        '#cugChangeStaffFormAlertMessage',
        'Please select a transfer reason.'
      );

      return false;
    }

    if (!remarks) {
      this.showModalMessage(
        '#cugChangeStaffFormAlert',
        '#cugChangeStaffFormAlertMessage',
        'Please enter transfer remarks.'
      );

      return false;
    }

    return true;
  }

  /* =====================================================
       RELEASE CUG
    ===================================================== */

  releaseCug(cugId) {
    if (!cugId) {
      return;
    }

    const confirmed = window.confirm(
      'Release this CUG number from the current staff member? The assignment will be closed and preserved in history.'
    );

    if (!confirmed) {
      return;
    }

    this.performAction('release', cugId, 'CUG number released successfully.', 'Unable to release CUG number.');
  }

  /* =====================================================
       DEACTIVATE CUG
    ===================================================== */

  deactivateCug(cugId) {
    if (!cugId) {
      return;
    }

    const confirmed = window.confirm('Deactivate this CUG number? It will no longer be available for assignment.');

    if (!confirmed) {
      return;
    }

    this.performAction('deactivate', cugId, 'CUG number deactivated successfully.', 'Unable to deactivate CUG number.');
  }

  /* =====================================================
       DELETE CUG
    ===================================================== */

  deleteCug(cugId) {
    if (!cugId) {
      return;
    }

    const confirmed = window.confirm(
      'Delete this CUG number? This action should only be used when the number was entered incorrectly. Historical assignment and call records must not be removed.'
    );

    if (!confirmed) {
      return;
    }

    this.performAction('delete', cugId, 'CUG number deleted successfully.', 'Unable to delete CUG number.');
  }

  /* =====================================================
       ACTION REQUEST
    ===================================================== */

  performAction(action, cugId, successMessage, errorMessage) {
    const self = this;

    $.ajax({
      url: this.route(action, cugId),

      type: 'POST',

      data: {
        _token: this.csrf(),

        cug_id: cugId
      },

      dataType: 'json'
    })

      .done(function (response) {
        self.handleSuccess(response, successMessage);

        self.refreshAfterChange();
      })

      .fail(function (xhr) {
        self.showToastError(xhr, errorMessage);
      });
  }

  /* =====================================================
       HISTORY
    ===================================================== */

  openHistory(cugId, tab = 'assignments') {
    if (!cugId) {
      return;
    }

    this.currentCugId = cugId;

    this.resetHistoryModal();

    $('#cugHistoryModal').modal('show');

    this.loadHistorySummary(cugId);

    if (tab === 'calls') {
      const callTab = document.querySelector('#cugCallHistoryTab');

      if (callTab && typeof bootstrap !== 'undefined') {
        bootstrap.Tab.getOrCreateInstance(callTab).show();
      } else {
        $('#cugCallHistoryTab').tab('show');
      }
    } else {
      const assignmentTab = document.querySelector('#cugAssignmentHistoryTab');

      if (assignmentTab && typeof bootstrap !== 'undefined') {
        bootstrap.Tab.getOrCreateInstance(assignmentTab).show();
      } else {
        $('#cugAssignmentHistoryTab').tab('show');
      }
    }
  }

  /* =====================================================
       HISTORY SUMMARY
    ===================================================== */

  loadHistorySummary(cugId) {
    $.ajax({
      url: this.route('show', cugId),

      type: 'GET',

      dataType: 'json'
    })

      .done(response => {
        const data = this.extractData(response);

        $('#cugHistoryNumber').text(data.cug_number || '—');

        $('#cugHistoryProvider').text(data.provider || '—');

        $('#cugHistoryCurrentStaff').text(data.staff_name || data.current_staff?.staff_name || 'Unassigned');

        $('#cugHistoryTotalCalls').text(CugHelper.number(data.call_count || data.total_calls || 0));

        $('#cugHistoryStatus').html(this.renderStatus(data.status, data.status_label));
      });
  }

  /* =====================================================
       ASSIGNMENT HISTORY
    ===================================================== */

  loadAssignmentHistory() {
    const cugId = this.currentCugId;

    if (!cugId) {
      return;
    }

    const loading = $('#cugAssignmentHistoryLoading');

    const timeline = $('#cugAssignmentTimeline');

    const empty = $('#cugAssignmentHistoryEmpty');

    loading.removeClass('d-none');

    timeline.empty();

    empty.addClass('d-none');

    if (this.historyRequest) {
      this.historyRequest.abort();
    }

    this.historyRequest = $.ajax({
      url: this.route('assignmentHistory', cugId),

      type: 'GET',

      dataType: 'json'
    });

    this.historyRequest

      .done(response => {
        const data = this.extractData(response);

        const rows = data.assignments || data.history || [];

        $('#cugAssignmentHistoryCount').text(rows.length);

        if (!rows.length) {
          empty.removeClass('d-none');

          return;
        }

        timeline.html(rows.map(row => this.renderAssignmentHistory(row)).join(''));
      })

      .fail((xhr, status) => {
        if (status === 'abort') {
          return;
        }

        timeline.html(this.renderHistoryError('Unable to load assignment history.'));
      })

      .always(() => {
        loading.addClass('d-none');

        this.historyRequest = null;
      });
  }

  /* =====================================================
       RENDER ASSIGNMENT HISTORY
    ===================================================== */

  renderAssignmentHistory(row) {
    const action = String(row.action || row.type || '').toUpperCase();

    let icon = 'ti-user';

    let className = '';

    let title = 'Assignment';

    switch (action) {
      case 'ASSIGNED':
        icon = 'ti-user-plus';

        className = 'assigned';

        title = 'CUG Assigned';

        break;

      case 'RELEASED':
        icon = 'ti-user-minus';

        className = 'released';

        title = 'CUG Released';

        break;

      case 'TRANSFERRED':
        icon = 'ti-user-shared';

        className = 'transferred';

        title = 'CUG Transferred';

        break;

      case 'CHANGED':
        icon = 'ti-user-shared';

        className = 'transferred';

        title = 'Staff Changed';

        break;

      default:
        icon = 'ti-history';

        break;
    }

    if (row.is_current) {
      icon = 'ti-user-check';

      className = 'current';

      title = 'Current Assignment';
    }

    const staffName = row.staff_name || 'Unassigned';

    const staffCode = row.staff_code || row.staff_id || '—';

    const startDate = row.start_date ? CugHelper.formatDate(row.start_date) : '—';

    const endDate = row.end_date ? CugHelper.formatDate(row.end_date) : null;

    const reason = row.reason || row.transfer_reason || null;

    const remarks = row.remarks || '';

    return `
            <div class="cug-assignment-history-item">

                <div class="cug-assignment-history-icon ${className}">

                    <i class="ti ${icon}"></i>

                </div>

                <div class="cug-assignment-history-content">

                    <div class="cug-assignment-history-top">

                        <div>

                            <span class="cug-assignment-history-title">

                                ${CugHelper.escapeHtml(title)}

                            </span>

                        </div>

                        <span class="cug-assignment-history-date">

                            ${CugHelper.escapeHtml(startDate)}

                            ${endDate ? ` — ${CugHelper.escapeHtml(endDate)}` : ''}

                        </span>

                    </div>

                    <div class="cug-assignment-history-description">

                        <strong>

                            ${CugHelper.escapeHtml(staffName)}

                        </strong>

                        ${staffCode !== '—' ? ` (${CugHelper.escapeHtml(staffCode)})` : ''}

                        ${row.department_name ? ` · ${CugHelper.escapeHtml(row.department_name)}` : ''}

                    </div>

                    <div class="cug-assignment-history-meta">

                        ${
                          reason
                            ? `
                                    <span class="cug-assignment-history-tag reason">

                                        <i class="ti ti-info-circle"></i>

                                        ${CugHelper.escapeHtml(this.formatReason(reason))}

                                    </span>
                                  `
                            : ''
                        }

                        ${
                          row.created_at
                            ? `
                                    <span class="cug-assignment-history-tag">

                                        <i class="ti ti-clock"></i>

                                        ${CugHelper.escapeHtml(CugHelper.formatDateTime(row.created_at))}

                                    </span>
                                  `
                            : ''
                        }

                        ${
                          remarks
                            ? `
                                    <span
                                        class="cug-assignment-history-tag"
                                        title="${CugHelper.escapeHtml(remarks)}">

                                        <i class="ti ti-message"></i>

                                        Remarks

                                    </span>
                                  `
                            : ''
                        }

                    </div>

                </div>

            </div>
        `;
  }

  /* =====================================================
       CALL HISTORY
    ===================================================== */

  loadCallHistory() {
    const cugId = this.currentCugId;

    if (!cugId) {
      return;
    }

    const loading = $('#cugCallHistoryLoading');

    const wrapper = $('#cugCallHistoryTableWrapper');

    const empty = $('#cugCallHistoryEmpty');

    loading.removeClass('d-none');

    wrapper.removeClass('d-none');

    empty.addClass('d-none');

    if (this.callHistoryRequest) {
      this.callHistoryRequest.abort();
    }

    this.callHistoryRequest = $.ajax({
      url: this.route('callHistory', cugId),

      type: 'GET',

      data: {
        page: this.callHistoryPage,

        per_page: this.callHistoryPerPage,

        from: $('#cugCallHistoryFrom').val(),

        to: $('#cugCallHistoryTo').val()
      },

      dataType: 'json'
    });

    this.callHistoryRequest

      .done(response => {
        const data = this.extractData(response);

        const rows = data.records || data.data || [];

        $('#cugCallHistoryCount').text(data.total ?? rows.length);

        if (!rows.length) {
          $('#cugCallHistoryBody').empty();

          wrapper.addClass('d-none');

          empty.removeClass('d-none');

          $('#cugCallHistoryPagination').empty();

          return;
        }

        $('#cugCallHistoryBody').html(rows.map(row => this.renderCallRow(row)).join(''));

        this.renderCallPagination(data);
      })

      .fail((xhr, status) => {
        if (status === 'abort') {
          return;
        }

        $('#cugCallHistoryBody').html(this.renderTableError('Unable to load call history.'));
      })

      .always(() => {
        loading.addClass('d-none');

        this.callHistoryRequest = null;
      });
  }

  /* =====================================================
       CALL ROW
    ===================================================== */

  renderCallRow(row) {
    const dateTime = row.call_datetime || row.datetime || row.created_at;

    const date = dateTime ? CugHelper.formatDate(dateTime) : '—';

    const time = dateTime ? CugHelper.formatTime(dateTime) : '—';

    const type = String(row.type || row.call_type || '').toUpperCase();

    let typeClass = 'incoming';

    let typeIcon = 'ti-phone-incoming';

    let typeLabel = 'Incoming';

    if (type === 'OUTGOING') {
      typeClass = 'outgoing';

      typeIcon = 'ti-phone-outgoing';

      typeLabel = 'Outgoing';
    }

    if (type === 'MISSED') {
      typeClass = 'missed';

      typeIcon = 'ti-phone-off';

      typeLabel = 'Missed';
    }

    const status = String(row.status || 'ANSWERED').toUpperCase();

    let statusClass = 'text-success';

    if (status === 'MISSED' || status === 'FAILED') {
      statusClass = 'text-danger';
    }

    return `
            <tr>

                <td>

                    <div class="cug-call-datetime">

                        <strong>

                            ${CugHelper.escapeHtml(date)}

                        </strong>

                        <span>

                            ${CugHelper.escapeHtml(time)}

                        </span>

                    </div>

                </td>

                <td>

                    <span class="cug-call-type ${typeClass}">

                        <i class="ti ${typeIcon}"></i>

                        ${typeLabel}

                    </span>

                </td>

                <td>

                    <span class="cug-call-number">

                        ${CugHelper.escapeHtml(row.caller_number || row.phone_number || row.number || '—')}

                    </span>

                </td>

                <td>

                    <span class="cug-call-duration">

                        ${CugHelper.escapeHtml(row.duration || '—')}

                    </span>

                </td>

                <td>

                    <span class="cug-call-staff">

                        ${CugHelper.escapeHtml(row.staff_name || '—')}

                    </span>

                </td>

                <td>

                    <span class="cug-call-status ${statusClass}">

                        <span class="cug-call-status-dot"></span>

                        ${CugHelper.escapeHtml(this.formatReason(status))}

                    </span>

                </td>

            </tr>
        `;
  }

  /* =====================================================
       CALL PAGINATION
    ===================================================== */

  renderCallPagination(data) {
    const current = Number(data.current_page || data.currentPage || 1);

    const last = Number(data.last_page || data.lastPage || 1);

    if (last <= 1) {
      $('#cugCallHistoryPagination').empty();

      return;
    }

    let html = `
            <nav aria-label="CUG call history pagination">

                <ul class="pagination pagination-sm">
        `;

    html += `
            <li class="page-item ${current <= 1 ? 'disabled' : ''}">

                <button
                    type="button"
                    class="page-link"
                    data-cug-call-page="${current - 1}">

                    <i class="ti ti-chevron-left"></i>

                </button>

            </li>
        `;

    const start = Math.max(1, current - 2);

    const end = Math.min(last, current + 2);

    for (let page = start; page <= end; page++) {
      html += `
                <li class="page-item ${page === current ? 'active' : ''}">

                    <button
                        type="button"
                        class="page-link"
                        data-cug-call-page="${page}">

                        ${page}

                    </button>

                </li>
            `;
    }

    html += `
            <li class="page-item ${current >= last ? 'disabled' : ''}">

                <button
                    type="button"
                    class="page-link"
                    data-cug-call-page="${current + 1}">

                    <i class="ti ti-chevron-right"></i>

                </button>

            </li>
        `;

    html += `
                </ul>

            </nav>
        `;

    $('#cugCallHistoryPagination').html(html);
  }

  /* =====================================================
       PAGINATION EVENT
    ===================================================== */

  initializePaginationEvents() {
    const self = this;

    $(document).on('click', '[data-cug-call-page]', function () {
      const button = $(this);

      if (button.closest('.disabled').length) {
        return;
      }

      self.callHistoryPage = Number(button.data('cug-call-page'));

      self.loadCallHistory();
    });
  }

  /* =====================================================
       OPEN VIEW
    ===================================================== */

  openView(cugId) {
    this.openHistory(cugId, 'assignments');
  }

  /* =====================================================
       STATUS HTML
    ===================================================== */

  renderStatus(status, label) {
    const value = String(status ?? '');

    let className = 'cug-status-inactive';

    let text = label || 'Unknown';

    switch (value) {
      case '0':
        className = 'cug-status-available';

        text = label || 'Available';

        break;

      case '1':
        className = 'cug-status-assigned';

        text = label || 'Assigned';

        break;

      case '2':
        className = 'cug-status-reserved';

        text = label || 'Reserved';

        break;

      case '3':
        className = 'cug-status-inactive';

        text = label || 'Inactive';

        break;
    }

    return `
            <span class="cug-status-badge ${className}">

                <span class="cug-status-dot"></span>

                ${CugHelper.escapeHtml(text)}

            </span>
        `;
  }

  /* =====================================================
       REFRESH AFTER CHANGE
    ===================================================== */

  refreshAfterChange() {
    /*
        |--------------------------------------------------------------------------
        | DataTable
        |--------------------------------------------------------------------------
        */

    if (window.cugDataTable && typeof window.cugDataTable.reload === 'function') {
      window.cugDataTable.reload(false);
    }

    /*
        |--------------------------------------------------------------------------
        | Dashboard
        |--------------------------------------------------------------------------
        */

    if (window.cugDashboard && typeof window.cugDashboard.refresh === 'function') {
      window.cugDashboard.refresh();
    }

    /*
        |--------------------------------------------------------------------------
        | Timeline
        |--------------------------------------------------------------------------
        */

    $(document).trigger('cug:data-changed');
  }

  /* =====================================================
       SUCCESS
    ===================================================== */

  handleSuccess(response, fallbackMessage) {
    const message = response?.message || fallbackMessage;

    if (typeof CugHelper.toastSuccess === 'function') {
      CugHelper.toastSuccess(message);

      return;
    }

    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: 'success',

        title: 'Success',

        text: message,

        timer: 1800,

        showConfirmButton: false
      });

      return;
    }

    console.info(message);
  }

  /* =====================================================
       MODAL ERROR
    ===================================================== */

  showModalError(alertSelector, messageSelector, xhr, fallback) {
    let message = fallback;

    const response = xhr?.responseJSON;

    if (response?.message) {
      message = response.message;
    }

    /*
        |--------------------------------------------------------------------------
        | Laravel validation errors
        |--------------------------------------------------------------------------
        */

    if (response?.errors) {
      const errors = [];

      Object.keys(response.errors).forEach(key => {
        const values = response.errors[key];

        if (Array.isArray(values)) {
          values.forEach(value => {
            errors.push(value);
          });
        }
      });

      if (errors.length) {
        message = errors.join('<br>');
      }
    }

    $(messageSelector).html(this.escapeHtmlMessage(message));

    $(alertSelector).removeClass('d-none');
  }

  /* =====================================================
       SIMPLE MODAL MESSAGE
    ===================================================== */

  showModalMessage(alertSelector, messageSelector, message) {
    $(messageSelector).text(message);

    $(alertSelector).removeClass('d-none');
  }

  clearModalError(selector) {
    $(selector).addClass('d-none');
  }

  /* =====================================================
       TOAST ERROR
    ===================================================== */

  showToastError(xhr, fallback) {
    const message = xhr?.responseJSON?.message || fallback;

    if (typeof CugHelper.toastError === 'function') {
      CugHelper.toastError(message);

      return;
    }

    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: 'error',

        title: 'Unable to complete',

        text: message
      });

      return;
    }

    console.error(message);
  }

  /* =====================================================
       BUTTON LOADING
    ===================================================== */

  setButtonLoading(selector, loading, text = null) {
    const button = $(selector);

    if (!button.length) {
      return;
    }

    if (loading) {
      if (!button.data('original-html')) {
        button.data('original-html', button.html());
      }

      button.prop('disabled', true).html(`
                    <span
                        class="spinner-border spinner-border-sm me-1"
                        role="status"
                        aria-hidden="true">
                    </span>

                    ${CugHelper.escapeHtml(text || 'Processing...')}
                `);

      return;
    }

    const original = button.data('original-html');

    if (original) {
      button.html(original);
    }

    button.prop('disabled', false);
  }

  /* =====================================================
       SELECT HELPERS
    ===================================================== */

  setSelectLoading(select, text) {
    select.prop('disabled', true).html(`<option value="">${text}</option>`);
  }

  setSelectError(select, text) {
    select.prop('disabled', true).html(`<option value="">${text}</option>`);
  }

  clearSelect(select, placeholder) {
    select.html(`<option value="">${placeholder}</option>`);
  }

  populateSelect(select, rows, selectedId, selectedName, placeholder) {
    let html = `<option value="">${placeholder}</option>`;

    rows.forEach(row => {
      const id = row.id ?? row.sno ?? row.company_id ?? row.entity_id ?? row.branch_id;

      const name = row.name ?? row.company_name ?? row.entity_name ?? row.branch_name ?? row.label ?? 'Unnamed';

      const selected = selectedId !== null && String(id) === String(selectedId) ? 'selected' : '';

      html += `
                    <option
                        value="${CugHelper.escapeHtml(id)}"
                        ${selected}>

                        ${CugHelper.escapeHtml(name)}

                    </option>
                `;
    });

    if (selectedId && !rows.some(row => String(row.id ?? row.sno) === String(selectedId)) && selectedName) {
      html += `
                <option
                    value="${CugHelper.escapeHtml(selectedId)}"
                    selected>

                    ${CugHelper.escapeHtml(selectedName)}

                </option>
            `;
    }

    select.html(html);
  }

  setSelectValue(selector, value, text = null) {
    const select = $(selector);

    if (!select.length) {
      return;
    }

    if (value === null || typeof value === 'undefined' || value === '') {
      select.val('').trigger('change.select2');

      return;
    }

    if (!select.find(`option[value="${value}"]`).length) {
      select.append(
        $('<option>', {
          value: value,

          text: text || value
        })
      );
    }

    select.val(value).trigger('change.select2');
  }

  /* =====================================================
       DATA HELPERS
    ===================================================== */

  extractData(response) {
    if (response?.data && typeof response.data === 'object') {
      return response.data;
    }

    return response || {};
  }

  extractRows(response) {
    const data = response?.data;

    if (Array.isArray(data)) {
      return data;
    }

    if (Array.isArray(data?.data)) {
      return data.data;
    }

    if (Array.isArray(response?.rows)) {
      return response.rows;
    }

    return [];
  }

  /* =====================================================
       COUNTERS
    ===================================================== */

  initializeCounters() {
    this.updateCounter(document.getElementById('cugRemarks'), '#cugRemarksCounter', 500);

    this.updateCounter(document.getElementById('cugAssignRemarks'), '#cugAssignRemarksCounter', 500);

    this.updateCounter(document.getElementById('cugChangeRemarks'), '#cugChangeRemarksCounter', 500);
  }

  updateCounter(element, counterSelector, max) {
    if (!element) {
      return;
    }

    const length = $(element).val().length;

    $(counterSelector).text(`${length} / ${max}`);
  }

  /* =====================================================
       NUMBER CLEANING
    ===================================================== */

  cleanNumberInput(element) {
    let value = $(element).val();

    value = value.replace(/[^0-9+\-\s]/g, '');

    $(element).val(value);
  }

  /* =====================================================
       RESET NUMBER MODAL
    ===================================================== */

  resetNumberModal() {
    const form = document.getElementById('cugNumberForm');

    if (form) {
      form.reset();
    }

    $('#cugNumberId').val('');

    $('#cugNumberMethod').val('POST');

    this.clearModalError('#cugNumberFormAlert');

    this.clearSelect($('#cugCompany'), 'Select Company');

    this.clearSelect($('#cugEntity'), 'Select Entity');

    this.clearSelect($('#cugBranch'), 'Select Branch');

    $('#cugEntity').prop('disabled', true);

    $('#cugBranch').prop('disabled', true);

    $('#cugRemarksCounter').text('0 / 500');
  }

  /* =====================================================
       RESET ASSIGN
    ===================================================== */

  resetAssignModal() {
    const form = document.getElementById('cugAssignForm');

    if (form) {
      form.reset();
    }

    $('#cugAssignNumberId').val('');

    $('#cugAssignNumber').text('—');

    $('#cugAssignProvider').text('—');

    $('#cugAssignStaffPreview').addClass('d-none');

    $('#cugAssignStaffWarning').addClass('d-none');

    $('#cugAssignRemarksCounter').text('0 / 500');

    this.clearModalError('#cugAssignFormAlert');

    /*
        |--------------------------------------------------------------------------
        | Reset Select2
        |--------------------------------------------------------------------------
        */

    this.resetSelect2('#cugAssignStaff');

    /*
        |--------------------------------------------------------------------------
        | Default date
        |--------------------------------------------------------------------------
        */

    $('#cugAssignDate').val(this.today());
  }

  /* =====================================================
       RESET CHANGE STAFF
    ===================================================== */

  resetChangeStaffModal() {
    const form = document.getElementById('cugChangeStaffForm');

    if (form) {
      form.reset();
    }

    $('#cugChangeCugId').val('');

    $('#cugChangeCugNumber').text('—');

    $('#cugChangeCugProvider').text('—');

    $('#cugCurrentStaffInitials').text('?');

    $('#cugCurrentStaffName').text('—');

    $('#cugCurrentStaffId').text('—');

    $('#cugCurrentStaffDepartment').text('—');

    $('#cugCurrentStaffDesignation').text('—');

    $('#cugReplacementStaffPreview').addClass('d-none');

    $('#cugReplacementStaffWarning').addClass('d-none');

    $('#cugChangeEffectiveDate').val(this.today());

    $('#cugChangeRemarksCounter').text('0 / 500');

    this.clearModalError('#cugChangeStaffFormAlert');

    this.resetSelect2('#cugReplacementStaff');
  }

  /* =====================================================
       RESET HISTORY
    ===================================================== */

  resetHistoryModal() {
    this.currentCugId = null;

    this.currentCug = null;

    if (this.historyRequest) {
      this.historyRequest.abort();

      this.historyRequest = null;
    }

    if (this.callHistoryRequest) {
      this.callHistoryRequest.abort();

      this.callHistoryRequest = null;
    }

    $('#cugHistoryNumber').text('—');

    $('#cugHistoryProvider').text('—');

    $('#cugHistoryCurrentStaff').text('—');

    $('#cugHistoryTotalCalls').text('0');

    $('#cugHistoryStatus').text('—');

    $('#cugAssignmentTimeline').empty();

    $('#cugCallHistoryBody').empty();

    $('#cugCallHistoryPagination').empty();

    $('#cugAssignmentHistoryEmpty').addClass('d-none');

    $('#cugCallHistoryEmpty').addClass('d-none');

    $('#cugAssignmentHistoryLoading').addClass('d-none');

    $('#cugCallHistoryLoading').addClass('d-none');
  }

  /* =====================================================
       RESET SELECT2
    ===================================================== */

  resetSelect2(selector) {
    const element = $(selector);

    if (!element.length) {
      return;
    }

    if (element.hasClass('select2-hidden-accessible')) {
      element.val(null).trigger('change');
    } else {
      element.val('');
    }
  }

  /* =====================================================
       CLOSE MODAL
    ===================================================== */

  closeModal(selector) {
    const element = document.querySelector(selector);

    if (!element) {
      return;
    }

    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
      const instance = bootstrap.Modal.getInstance(element);

      if (instance) {
        instance.hide();

        return;
      }
    }

    $(selector).modal('hide');
  }

  /* =====================================================
       ROUTES
    ===================================================== */

  route(name, id = null) {
    if (window.cugRoutes && window.cugRoutes[name]) {
      let url = window.cugRoutes[name];

      if (id !== null) {
        url = url.replace('__ID__', encodeURIComponent(id));
      }

      return url;
    }

    if (window.CugHelper && typeof CugHelper.route === 'function') {
      return CugHelper.route(name, id);
    }

    console.error(`CUG route "${name}" is not configured.`);

    return '#';
  }

  /* =====================================================
       CSRF
    ===================================================== */

  csrf() {
    const token = $('meta[name="csrf-token"]').attr('content');

    if (token) {
      return token;
    }

    return (
      $('#cugNumberForm input[name="_token"]').val() ||
      $('#cugAssignForm input[name="_token"]').val() ||
      $('#cugChangeStaffForm input[name="_token"]').val() ||
      ''
    );
  }

  /* =====================================================
       TODAY
    ===================================================== */

  today() {
    const date = new Date();

    const year = date.getFullYear();

    const month = String(date.getMonth() + 1).padStart(2, '0');

    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  /* =====================================================
       FORMAT REASON
    ===================================================== */

  formatReason(value) {
    if (!value) {
      return '—';
    }

    return String(value)
      .replace(/_/g, ' ')

      .toLowerCase()

      .replace(/\b\w/g, char => char.toUpperCase());
  }

  /* =====================================================
       HISTORY ERROR
    ===================================================== */

  renderHistoryError(message) {
    return `
            <div class="cug-history-empty">

                <div class="cug-history-empty-icon">

                    <i class="ti ti-alert-circle"></i>

                </div>

                <strong>
                    Unable to load history
                </strong>

                <span>
                    ${CugHelper.escapeHtml(message)}
                </span>

            </div>
        `;
  }

  /* =====================================================
       TABLE ERROR
    ===================================================== */

  renderTableError(message) {
    return `
            <tr>

                <td
                    colspan="6"
                    class="text-center py-4">

                    <span class="text-danger">

                        <i class="ti ti-alert-circle me-1"></i>

                        ${CugHelper.escapeHtml(message)}

                    </span>

                </td>

            </tr>
        `;
  }

  /* =====================================================
       ESCAPE HTML MESSAGE
    ===================================================== */

  escapeHtmlMessage(message) {
    if (typeof message !== 'string') {
      return '';
    }

    /*
        |--------------------------------------------------------------------------
        | Validation errors intentionally use <br>
        |--------------------------------------------------------------------------
        */

    return message
      .split('<br>')
      .map(part => CugHelper.escapeHtml(part))
      .join('<br>');
  }
}

/* =========================================================
   INITIALIZE
========================================================= */

$(function () {
  window.cugModal = new CugModalController();

  cugModal.init();

  cugModal.initializePaginationEvents();
});
