'use strict';

/**
 * =========================================================
 * CUG Management — DataTable
 * =========================================================
 *
 * Responsibilities:
 *
 * - Server-side DataTable
 * - CUG inventory listing
 * - Filtering
 * - Sorting
 * - Pagination
 * - Row selection
 * - Bulk selection
 * - Row action menu
 * - Empty state
 * - Reload without destroying DataTable
 *
 * =========================================================
 */

class CugDataTable {
  constructor() {
    this.table = null;

    this.initialized = false;

    this.selectedRows = new Set();

    this.currentRequest = null;

    this.ajaxSequence = 0;
  }

  /* =====================================================
       INIT
    ===================================================== */

  init() {
    if (this.initialized) {
      return;
    }

    if (typeof $.fn.DataTable !== 'function') {
      console.error('CUG Management: DataTables is not loaded.');

      return;
    }

    this.initialized = true;

    this.registerEvents();

    this.initTable();
  }

  /* =====================================================
       DATATABLE
    ===================================================== */

  initTable() {
    const self = this;

    const table = $('#cugDataTable');

    if (!table.length) {
      return;
    }

    this.table = table.DataTable({
      processing: true,

      serverSide: true,

      searching: false,

      ordering: true,

      responsive: false,

      autoWidth: false,

      pageLength: 25,

      lengthMenu: [
        [10, 25, 50, 100],
        [10, 25, 50, 100]
      ],

      order: [[1, 'asc']],

      ajax: function (request, callback) {
        self.loadData(request, callback);
      },

      columns: [
        {
          data: null,

          name: 'selection',

          orderable: false,

          searchable: false,

          className: 'cug-checkbox-column',

          render: function (data, type, row) {
            return self.renderCheckbox(row);
          }
        },

        {
          data: 'cug_number',

          name: 'cug_number',

          render: function (data, type, row) {
            return self.renderNumber(data, row);
          }
        },

        {
          data: 'provider',

          name: 'provider',

          defaultContent: '—',

          render: function (data) {
            return self.renderProvider(data);
          }
        },

        {
          data: 'company_name',

          name: 'company_name',

          defaultContent: '—',

          render: function (data) {
            return CugHelper.escapeHtml(CugHelper.value(data));
          }
        },

        {
          data: 'entity_name',

          name: 'entity_name',

          defaultContent: '—',

          render: function (data) {
            return CugHelper.escapeHtml(CugHelper.value(data));
          }
        },

        {
          data: 'staff_name',

          name: 'staff_name',

          orderable: false,

          render: function (data, type, row) {
            return self.renderStaff(data, row);
          }
        },

        {
          data: 'assigned_date',

          name: 'assigned_date',

          render: function (data, type, row) {
            return self.renderAssignment(data, row);
          }
        },

        {
          data: 'call_count',

          name: 'call_count',

          orderable: false,

          className: 'text-center',

          render: function (data, type, row) {
            return self.renderCalls(data, row);
          }
        },

        {
          data: 'status',

          name: 'status',

          render: function (data, type, row) {
            return self.renderStatus(data, row);
          }
        },

        {
          data: null,

          name: 'actions',

          orderable: false,

          searchable: false,

          className: 'cug-action-column',

          render: function (data, type, row) {
            return self.renderActions(row);
          }
        }
      ],

      language: {
        processing: 'Loading CUG numbers...',

        emptyTable: '',

        zeroRecords: '',

        lengthMenu: '_MENU_ per page',

        info: 'Showing _START_ to _END_ of _TOTAL_ CUG numbers',

        infoEmpty: 'No CUG numbers',

        paginate: {
          first: '<i class="ti ti-chevrons-left"></i>',

          previous: '<i class="ti ti-chevron-left"></i>',

          next: '<i class="ti ti-chevron-right"></i>',

          last: '<i class="ti ti-chevrons-right"></i>'
        }
      },

      drawCallback: function () {
        self.restoreSelection();

        self.updateSelectionUI();

        self.updateEmptyState();

        CugHelper.initTooltips();
      }
    });
  }

  /* =====================================================
       AJAX
    ===================================================== */

  loadData(request, callback) {
    const self = this;

    const url = CugHelper.route('datatable');

    if (!url) {
      callback({
        draw: request.draw,

        recordsTotal: 0,

        recordsFiltered: 0,

        data: []
      });

      return;
    }

    /*
        |--------------------------------------------------------------------------
        | Abort previous request
        |--------------------------------------------------------------------------
        */

    if (self.currentRequest) {
      self.currentRequest.abort();
    }

    const sequence = ++self.ajaxSequence;

    /*
        |--------------------------------------------------------------------------
        | Build Request
        |--------------------------------------------------------------------------
        */

    const filters =
      window.cugFilters && typeof window.cugFilters.getFilters === 'function' ? window.cugFilters.getFilters() : {};

    const payload = $.extend(true, {}, request, filters);

    /*
        |--------------------------------------------------------------------------
        | Request
        |--------------------------------------------------------------------------
        */

    self.currentRequest = CugHelper.get(url, payload);

    self.currentRequest

      .done(function (response) {
        /*
                |--------------------------------------------------------------------------
                | Ignore stale request
                |--------------------------------------------------------------------------
                */

        if (sequence !== self.ajaxSequence) {
          return;
        }

        callback(self.normalizeResponse(response, request.draw));
      })

      .fail(function (xhr, status) {
        if (status === 'abort') {
          return;
        }

        CugHelper.handleError(xhr, 'Unable to load CUG numbers.');

        callback({
          draw: request.draw,

          recordsTotal: 0,

          recordsFiltered: 0,

          data: []
        });
      })

      .always(function () {
        if (sequence === self.ajaxSequence) {
          self.currentRequest = null;
        }
      });
  }

  /* =====================================================
       NORMALIZE RESPONSE
    ===================================================== */

  normalizeResponse(response, draw) {
    if (response && typeof response.draw !== 'undefined') {
      return response;
    }

    const data = response?.data || {};

    return {
      draw: response?.draw ?? draw,

      recordsTotal: response?.recordsTotal ?? data.recordsTotal ?? 0,

      recordsFiltered: response?.recordsFiltered ?? data.recordsFiltered ?? 0,

      data: response?.data?.data ?? data.data ?? []
    };
  }

  /* =====================================================
       NUMBER
    ===================================================== */

  renderNumber(number, row) {
    const safeNumber = CugHelper.escapeHtml(CugHelper.value(number));

    const code = CugHelper.escapeHtml(CugHelper.value(row.cug_code));

    return `
            <div class="cug-number-cell">

                <div class="cug-number-icon">

                    <i class="ti ti-device-mobile"></i>

                </div>

                <div>

                    <span class="cug-number-value">

                        ${safeNumber}

                    </span>

                    ${
                      code !== '—'
                        ? `
                                <span class="cug-number-id">
                                    ${code}
                                </span>
                              `
                        : ''
                    }

                </div>

            </div>
        `;
  }

  /* =====================================================
       PROVIDER
    ===================================================== */

  renderProvider(provider) {
    const value = CugHelper.value(provider);

    if (value === '—') {
      return `
                <span class="text-muted">
                    —
                </span>
            `;
    }

    return `
            <span class="cug-badge cug-badge-primary">
                ${CugHelper.escapeHtml(value)}
            </span>
        `;
  }

  /* =====================================================
       STAFF
    ===================================================== */

  renderStaff(staffName, row) {
    if (!row.staff_id) {
      return `
                <div class="cug-unassigned">

                    <i class="ti ti-user-off me-1"></i>

                    Unassigned

                </div>
            `;
    }

    const name = CugHelper.value(staffName, 'Unknown Staff');

    const staffId = CugHelper.value(row.staff_code ?? row.staff_id);

    return `
            <div class="cug-staff-cell">

                <div class="cug-staff-avatar">

                    ${CugHelper.escapeHtml(CugHelper.initials(name))}

                </div>

                <div>

                    <span class="cug-staff-name">

                        ${CugHelper.escapeHtml(name)}

                    </span>

                    <span class="cug-staff-id">

                        ${CugHelper.escapeHtml(staffId)}

                    </span>

                </div>

            </div>
        `;
  }

  /* =====================================================
       ASSIGNMENT
    ===================================================== */

  renderAssignment(date, row) {
    if (!row.staff_id) {
      return `
                <span class="cug-unassigned">
                    Not assigned
                </span>
            `;
    }

    const formattedDate = date ? CugHelper.formatDate(date) : '—';

    const duration = row.assignment_duration ? CugHelper.escapeHtml(row.assignment_duration) : '';

    return `
            <div>

                <span class="cug-assignment-date">

                    ${CugHelper.escapeHtml(formattedDate)}

                </span>

                ${
                  duration
                    ? `
                            <span class="cug-assignment-duration">
                                ${duration}
                            </span>
                          `
                    : ''
                }

            </div>
        `;
  }

  /* =====================================================
       CALLS
    ===================================================== */

  renderCalls(count, row) {
    const total = this.toNumber(count);

    return `
            <button
                type="button"
                class="cug-call-count btn-reset-cug-call"
                data-cug-id="${this.escapeAttribute(row.sno)}"
                title="View call history">

                <i class="ti ti-phone-call"></i>

                <span>
                    ${CugHelper.number(total)}
                </span>

            </button>
        `;
  }

  /* =====================================================
       STATUS
    ===================================================== */

  renderStatus(status, row) {
    const normalized = String(status ?? row.status ?? '');

    let label = 'Unknown';

    let className = 'cug-status-inactive';

    switch (normalized) {
      case '0':
        label = 'Available';

        className = 'cug-status-available';

        break;

      case '1':
        label = 'Assigned';

        className = 'cug-status-assigned';

        break;

      case '2':
        label = 'Reserved';

        className = 'cug-status-reserved';

        break;

      case '3':
        label = 'Inactive';

        className = 'cug-status-inactive';

        break;

      default:
        if (row.status_label) {
          label = row.status_label;
        }

        break;
    }

    return `
            <span class="cug-status-badge ${className}">

                <span class="cug-status-dot"></span>

                ${CugHelper.escapeHtml(label)}

            </span>
        `;
  }

  /* =====================================================
       CHECKBOX
    ===================================================== */

  renderCheckbox(row) {
    const id = row.sno ?? row.id;

    const checked = this.selectedRows.has(String(id));

    return `
            <input
                type="checkbox"
                class="form-check-input cug-row-checkbox"
                value="${this.escapeAttribute(id)}"
                ${checked ? 'checked' : ''}
                aria-label="Select CUG number">
        `;
  }

  /* =====================================================
       ACTIONS
    ===================================================== */

  renderActions(row) {
    const id = row.sno ?? row.id;

    const status = String(row.status ?? '');

    const assigned = Boolean(row.staff_id);

    const safeId = this.escapeAttribute(id);

    return `
            <div class="dropdown">

                <button
                    type="button"
                    class="cug-row-action"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    aria-label="CUG actions">

                    <i class="ti ti-dots-vertical"></i>

                </button>

                <ul class="dropdown-menu dropdown-menu-end">

                    <li>

                        <button
                            type="button"
                            class="dropdown-item cug-action-view"
                            data-cug-id="${safeId}">

                            <i class="ti ti-eye me-2"></i>

                            View

                        </button>

                    </li>

                    ${
                      !assigned && status === '0'
                        ? `
                                <li>
                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-assign"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-user-plus me-2"></i>

                                        Assign Staff

                                    </button>
                                </li>
                              `
                        : ''
                    }

                    ${
                      assigned && status === '1'
                        ? `
                                <li>
                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-change"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-user-shared me-2"></i>

                                        Change Staff

                                    </button>
                                </li>

                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-release"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-user-minus me-2"></i>

                                        Release CUG

                                    </button>

                                </li>
                              `
                        : ''
                    }

                    <li>

                        <button
                            type="button"
                            class="dropdown-item cug-action-call-history"
                            data-cug-id="${safeId}">

                            <i class="ti ti-phone-call me-2"></i>

                            Call History

                        </button>

                    </li>

                    <li>

                        <button
                            type="button"
                            class="dropdown-item cug-action-assignment-history"
                            data-cug-id="${safeId}">

                            <i class="ti ti-history me-2"></i>

                            Assignment History

                        </button>

                    </li>

                    <li>

                        <hr class="dropdown-divider">

                    </li>

                    <li>

                        <button
                            type="button"
                            class="dropdown-item cug-action-edit"
                            data-cug-id="${safeId}">

                            <i class="ti ti-edit me-2"></i>

                            Edit Number

                        </button>

                    </li>

                    ${
                      status !== '3'
                        ? `
                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item text-danger cug-action-deactivate"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-device-mobile-off me-2"></i>

                                        Deactivate

                                    </button>

                                </li>
                              `
                        : ''
                    }

                    <li>

                        <button
                            type="button"
                            class="dropdown-item text-danger cug-action-delete"
                            data-cug-id="${safeId}">

                            <i class="ti ti-trash me-2"></i>

                            Delete

                        </button>

                    </li>

                </ul>

            </div>
        `;
  }

  /* =====================================================
       EVENTS
    ===================================================== */

  registerEvents() {
    const self = this;

    /* -------------------------------------------------
           Select Row
        ------------------------------------------------- */

    $(document).on('change', '.cug-row-checkbox', function () {
      const id = String($(this).val());

      if ($(this).is(':checked')) {
        self.selectedRows.add(id);
      } else {
        self.selectedRows.delete(id);
      }

      self.updateSelectionUI();
    });

    /* -------------------------------------------------
           Select All
        ------------------------------------------------- */

    $(document).on('change', '#cugSelectAll', function () {
      const checked = $(this).is(':checked');

      self.selectCurrentPage(checked);
    });

    /* -------------------------------------------------
           View
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-view', function () {
      self.emitAction('view', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Assign
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-assign', function () {
      self.emitAction('assign', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Change Staff
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-change', function () {
      self.emitAction('change', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Release
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-release', function () {
      self.emitAction('release', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Call History
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-call-history, .btn-reset-cug-call', function () {
      self.emitAction('call-history', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Assignment History
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-assignment-history', function () {
      self.emitAction('assignment-history', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Edit
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-edit', function () {
      self.emitAction('edit', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Deactivate
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-deactivate', function () {
      self.emitAction('deactivate', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Delete
        ------------------------------------------------- */

    $(document).on('click', '.cug-action-delete', function () {
      self.emitAction('delete', $(this).data('cug-id'));
    });

    /* -------------------------------------------------
           Bulk Export
        ------------------------------------------------- */

    $(document).on('click', '#btnBulkExportCug', function () {
      self.emitAction('bulk-export', self.getSelectedIds());
    });

    /* -------------------------------------------------
           Bulk Deactivate
        ------------------------------------------------- */

    $(document).on('click', '#btnBulkDeactivateCug', function () {
      self.emitAction('bulk-deactivate', self.getSelectedIds());
    });
  }

  /* =====================================================
       ACTION EVENT
    ===================================================== */

  emitAction(action, id) {
    $(document).trigger(`cug:${action}`, [id]);
  }

  /* =====================================================
       SELECT CURRENT PAGE
    ===================================================== */

  selectCurrentPage(checked) {
    if (!this.table) {
      return;
    }

    const rows = this.table
      .rows({
        page: 'current'
      })
      .data();

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];

      const id = String(row.sno ?? row.id);

      if (checked) {
        this.selectedRows.add(id);
      } else {
        this.selectedRows.delete(id);
      }
    }

    this.table
      .rows({
        page: 'current'
      })
      .nodes()
      .to$()
      .find('.cug-row-checkbox')
      .prop('checked', checked);

    this.updateSelectionUI();
  }

  /* =====================================================
       RESTORE SELECTION
    ===================================================== */

  restoreSelection() {
    if (!this.table) {
      return;
    }

    this.table
      .rows({
        page: 'current'
      })
      .nodes()
      .to$()
      .find('.cug-row-checkbox')
      .each((index, element) => {
        const id = String($(element).val());

        $(element).prop('checked', this.selectedRows.has(id));
      });
  }

  /* =====================================================
       SELECTION UI
    ===================================================== */

  updateSelectionUI() {
    const count = this.selectedRows.size;

    $('#cugSelectedNumber').text(count);

    $('#cugSelectedCount').toggleClass('d-none', count === 0);

    $('#cugBulkActions').toggleClass('d-none', count === 0);

    this.updateSelectAllState();
  }

  /* =====================================================
       SELECT ALL STATE
    ===================================================== */

  updateSelectAllState() {
    const checkbox = $('#cugSelectAll');

    if (!checkbox.length) {
      return;
    }

    if (!this.table) {
      checkbox

        .prop('checked', false)

        .prop('indeterminate', false);

      return;
    }

    const rows = this.table
      .rows({
        page: 'current'
      })
      .data();

    const total = rows.length;

    if (total === 0) {
      checkbox

        .prop('checked', false)

        .prop('indeterminate', false);

      return;
    }

    let selected = 0;

    for (let i = 0; i < rows.length; i++) {
      const id = String(rows[i].sno ?? rows[i].id);

      if (this.selectedRows.has(id)) {
        selected++;
      }
    }

    checkbox

      .prop('checked', selected === total)

      .prop('indeterminate', selected > 0 && selected < total);
  }

  /* =====================================================
       GET SELECTED
    ===================================================== */

  getSelectedIds() {
    return Array.from(this.selectedRows);
  }

  /* =====================================================
       CLEAR SELECTION
    ===================================================== */

  clearSelection() {
    this.selectedRows.clear();

    this.updateSelectionUI();

    if (this.table) {
      this.table

        .rows()

        .nodes()

        .to$()

        .find('.cug-row-checkbox')
        .prop('checked', false);
    }
  }

  /* =====================================================
       RELOAD
    ===================================================== */

  reload(resetPaging = false) {
    if (!this.table) {
      return;
    }

    this.table.ajax.reload(
      () => {
        this.updateSelectionUI();
      },

      resetPaging
    );
  }

  /* =====================================================
       EMPTY STATE
    ===================================================== */

  updateEmptyState() {
    if (!this.table) {
      return;
    }

    const info = this.table.page.info();

    const empty = info.recordsDisplay === 0;

    $('#cugTableEmpty').toggleClass('d-none', !empty);

    $('.cug-data-table').toggleClass('d-none', empty);
  }

  /* =====================================================
       ESCAPE ATTRIBUTE
    ===================================================== */

  escapeAttribute(value) {
    return CugHelper.escapeHtml(value);
  }

  /* =====================================================
       NUMBER
    ===================================================== */

  toNumber(value) {
    const number = Number(value);

    return Number.isFinite(number) ? number : 0;
  }
}

/* =========================================================
   GLOBAL INSTANCE
========================================================= */

$(function () {
  window.cugDataTable = new CugDataTable();

  cugDataTable.init();
});
