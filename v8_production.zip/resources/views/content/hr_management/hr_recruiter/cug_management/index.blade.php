@extends('layouts/layoutMaster')

@section('title', 'CUG Management')

@section('vendor-style')

    @vite([
        'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
    ])

@endsection



@section('vendor-script')

    @vite([
        'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/flatpickr/flatpickr.js'
    ])

@endsection



@section('content')
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
<style>
    /* =========================================================
   CUG MANAGEMENT
   Production UI Foundation
========================================================= */

:root {
    --primary: #8f1d1d;
    --primary-2: #b52b25;
    --accent: #f5a623;

    --bg: #f4f6f9;
    --card: #ffffff;

    --text: #172033;
    --muted: #6b7280;
    --border: #e5e7eb;

    --success: #16a34a;
    --warning: #d97706;
    --danger: #dc2626;

    --cug-primary-soft: rgba(143, 29, 29, 0.08);
    --cug-primary-soft-2: rgba(143, 29, 29, 0.04);

    --cug-success-soft: rgba(22, 163, 74, 0.09);
    --cug-warning-soft: rgba(217, 119, 6, 0.10);
    --cug-danger-soft: rgba(220, 38, 38, 0.09);

    --cug-radius-sm: 7px;
    --cug-radius-md: 10px;
    --cug-radius-lg: 14px;
    --cug-radius-xl: 16px;

    --cug-shadow-sm:
        0 2px 8px rgba(23, 32, 51, 0.04);

    --cug-shadow-md:
        0 8px 24px rgba(23, 32, 51, 0.08);

    --cug-transition:
        all 0.2s ease;
}


/* =========================================================
   PAGE
========================================================= */

.cug-page {
    width: 100%;
    min-width: 0;
    color: var(--text);
}

.cug-page *,
.cug-page *::before,
.cug-page *::after {
    box-sizing: border-box;
}


/* =========================================================
   BOOTSTRAP PRIMARY OVERRIDE
========================================================= */

.cug-page .btn-primary {
    --bs-btn-color: #fff;
    --bs-btn-bg: var(--primary);
    --bs-btn-border-color: var(--primary);

    --bs-btn-hover-color: #fff;
    --bs-btn-hover-bg: var(--primary-2);
    --bs-btn-hover-border-color: var(--primary-2);

    --bs-btn-active-color: #fff;
    --bs-btn-active-bg: var(--primary-2);
    --bs-btn-active-border-color: var(--primary-2);

    --bs-btn-disabled-color: #fff;
    --bs-btn-disabled-bg: var(--primary);
    --bs-btn-disabled-border-color: var(--primary);
}


/* =========================================================
   GENERAL BUTTONS
========================================================= */

.cug-page .btn {
    font-weight: 600;
    transition: var(--cug-transition);
}

.cug-page .btn:focus-visible {
    outline: 0;
    box-shadow:
        0 0 0 3px rgba(143, 29, 29, 0.15);
}

.cug-page .btn-label-secondary {
    background: transparent;
    border-color: var(--border);
    color: var(--text);
}

.cug-page .btn-label-secondary:hover {
    background: var(--cug-primary-soft);
    border-color: rgba(143, 29, 29, 0.20);
    color: var(--primary);
}


/* =========================================================
   FORM CONTROLS
========================================================= */

.cug-page .form-control,
.cug-page .form-select {
    color: var(--text);
    background-color: var(--card);
    border-color: var(--border);
    transition:
        border-color .2s ease,
        box-shadow .2s ease;
}

.cug-page .form-control::placeholder {
    color: #9ca3af;
}

.cug-page .form-control:focus,
.cug-page .form-select:focus {
    color: var(--text);
    border-color: var(--primary);
    box-shadow:
        0 0 0 .15rem rgba(143, 29, 29, .10);
}

.cug-page .form-control:disabled,
.cug-page .form-select:disabled {
    background-color: #f8f9fa;
    cursor: not-allowed;
}

.cug-page .form-control.is-invalid,
.cug-page .form-select.is-invalid {
    border-color: var(--danger);
}

.cug-page .form-control.is-invalid:focus,
.cug-page .form-select.is-invalid:focus {
    box-shadow:
        0 0 0 .15rem rgba(220, 38, 38, .10);
}


/* =========================================================
   FORM LABELS
========================================================= */

.cug-page .form-label {
    margin-bottom: 6px;
    color: var(--text);
    font-size: .78rem;
    font-weight: 600;
}

.cug-page .form-label .required {
    margin-left: 2px;
    color: var(--danger);
}


/* =========================================================
   SELECT2
========================================================= */

.cug-page .select2-container {
    width: 100% !important;
}

.cug-page
.select2-container--default
.select2-selection--single {
    height: 42px;
    min-height: 42px;
    display: flex;
    align-items: center;

    background-color: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--cug-radius-md);
}

.cug-page
.select2-container--default
.select2-selection--single
.select2-selection__rendered {
    padding-left: 12px;
    padding-right: 35px;

    color: var(--text);
    font-size: .82rem;
    line-height: 40px;
}

.cug-page
.select2-container--default
.select2-selection--single
.select2-selection__placeholder {
    color: #9ca3af;
}

.cug-page
.select2-container--default
.select2-selection--single
.select2-selection__arrow {
    top: 1px;
    right: 8px;
    height: 40px;
}

.select2-container--default
.select2-dropdown {
    z-index: 99999;
    overflow: hidden;

    border-color: var(--border);
    border-radius: 10px;

    box-shadow:
        0 10px 30px rgba(23, 32, 51, .12);
}

.select2-container--default
.select2-search--dropdown
.select2-search__field {
    border-color: var(--border);
    border-radius: 7px;
}

.select2-container--default
.select2-search--dropdown
.select2-search__field:focus {
    outline: 0;
    border-color: var(--primary);
}

.select2-container--default
.select2-results__option {
    padding: 8px 10px;
    color: var(--text);
    font-size: .78rem;
}

.select2-container--default
.select2-results__option--highlighted {
    background-color: var(--primary);
    color: #fff;
}


/* =========================================================
   DATE PICKER
========================================================= */

.cug-page .flatpickr-input {
    cursor: pointer;
}

.flatpickr-calendar {
    z-index: 99999 !important;
    border: 1px solid var(--border);
    border-radius: 12px;

    box-shadow:
        0 10px 30px rgba(23, 32, 51, .12);
}

.flatpickr-calendar .flatpickr-day.selected,
.flatpickr-calendar .flatpickr-day.startRange,
.flatpickr-calendar .flatpickr-day.endRange {
    background: var(--primary);
    border-color: var(--primary);
}

.flatpickr-calendar .flatpickr-day:hover {
    background: var(--cug-primary-soft);
    border-color: transparent;
    color: var(--primary);
}


/* =========================================================
   BADGES
========================================================= */

.cug-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;

    min-height: 24px;
    padding: 4px 8px;

    border-radius: 6px;

    font-size: .68rem;
    font-weight: 700;
    line-height: 1;
}

.cug-badge-primary {
    background: var(--cug-primary-soft);
    color: var(--primary);
}

.cug-badge-success {
    background: var(--cug-success-soft);
    color: var(--success);
}

.cug-badge-warning {
    background: var(--cug-warning-soft);
    color: var(--warning);
}

.cug-badge-danger {
    background: var(--cug-danger-soft);
    color: var(--danger);
}


/* =========================================================
   LOADING OVERLAY
========================================================= */

.cug-loading-overlay {
    position: absolute;
    inset: 0;

    z-index: 50;

    display: flex;
    align-items: center;
    justify-content: center;

    background: rgba(255, 255, 255, .72);

    backdrop-filter: blur(2px);
}

.cug-loading-spinner {
    width: 34px;
    height: 34px;

    border: 3px solid rgba(143, 29, 29, .15);
    border-top-color: var(--primary);

    border-radius: 50%;

    animation:
        cugSpin .7s linear infinite;
}

@keyframes cugSpin {

    to {
        transform: rotate(360deg);
    }

}


/* =========================================================
   BUTTON LOADING
========================================================= */

.cug-btn-loading {
    position: relative;
    pointer-events: none;
}

.cug-btn-loading .cug-btn-text {
    visibility: hidden;
}

.cug-btn-loading::after {
    content: "";

    position: absolute;

    top: 50%;
    left: 50%;

    width: 16px;
    height: 16px;

    margin-top: -8px;
    margin-left: -8px;

    border: 2px solid rgba(255, 255, 255, .35);
    border-top-color: #fff;

    border-radius: 50%;

    animation:
        cugSpin .65s linear infinite;
}


/* =========================================================
   SKELETON
========================================================= */

.cug-skeleton {
    overflow: hidden;

    border-radius: 6px;

    background:
        linear-gradient(
            90deg,
            #f1f2f4 25%,
            #e7e9ec 37%,
            #f1f2f4 63%
        );

    background-size: 400% 100%;

    animation:
        cugSkeleton 1.4s ease infinite;
}

@keyframes cugSkeleton {

    0% {
        background-position: 100% 0;
    }

    100% {
        background-position: 0 0;
    }

}


/* =========================================================
   AJAX ERROR
========================================================= */

.cug-ajax-error {
    padding: 18px;

    border: 1px solid rgba(220, 38, 38, .15);
    border-radius: 10px;

    background: rgba(220, 38, 38, .04);

    color: var(--danger);

    font-size: .78rem;
}


/* =========================================================
   TOOLTIP
========================================================= */

.cug-page .tooltip-inner {
    max-width: 240px;
    padding: 6px 9px;

    border-radius: 6px;

    font-size: .68rem;
}


/* =========================================================
   SCROLLBAR
========================================================= */

.cug-page ::-webkit-scrollbar {
    width: 7px;
    height: 7px;
}

.cug-page ::-webkit-scrollbar-track {
    background: transparent;
}

.cug-page ::-webkit-scrollbar-thumb {
    background: #d1d5db;
    border-radius: 20px;
}

.cug-page ::-webkit-scrollbar-thumb:hover {
    background: #9ca3af;
}


/* =========================================================
   ACCESSIBILITY
========================================================= */

.cug-page button:focus-visible,
.cug-page a:focus-visible,
.cug-page input:focus-visible,
.cug-page select:focus-visible {
    outline: 2px solid var(--primary);
    outline-offset: 2px;
}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 767.98px) {

    .cug-page .form-control,
    .cug-page .form-select {
        min-height: 40px;
    }

}

/* =========================================================
   HELPER LOADING OVERLAYS
========================================================= */

.cug-page-loading-overlay,
.cug-table-loading-overlay,
.cug-modal-loading-overlay {
    position: absolute;
    inset: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, .72);
    backdrop-filter: blur(2px);
}

.cug-page-loading-overlay {
    position: fixed;
    z-index: 1090;
}

.cug-table-loading-overlay {
    border-radius: 16px;
}

.cug-modal-loading-overlay {
    border-radius: inherit;
}

/* =========================================================
   DASHBOARD LOADING
========================================================= */

.cug-dashboard-fetching
.cug-stat-card {
    cursor: wait;
}

.cug-dashboard-loading
.cug-stat-value {
    opacity: .45;
    transition: opacity .2s ease;
}

.cug-dashboard-loading
.cug-stat-mini-icon {
    opacity: .35;
}

.cug-dashboard-loading
.cug-stat-card-footer {
    opacity: .55;
}

/* =========================================================
   DATATABLE PROCESSING
========================================================= */

.cug-table-card .dataTables_processing {
    position: absolute !important;
    top: 50% !important;
    left: 50% !important;
    z-index: 20;

    width: auto !important;
    min-width: 180px;

    padding: 12px 16px !important;

    transform: translate(-50%, -50%);

    border: 1px solid var(--border) !important;
    border-radius: 10px !important;

    background: rgba(255, 255, 255, .95) !important;

    color: var(--text) !important;

    box-shadow:
        0 8px 25px rgba(23, 32, 51, .10);

    font-size: .75rem !important;
    font-weight: 600;
}

.cug-table-card .dataTables_length select {
    min-width: 65px;
    margin: 0 5px;
    border-color: var(--border);
    border-radius: 7px;
}

.cug-table-card .dataTables_length,
.cug-table-card .dataTables_info {
    color: var(--muted);
    font-size: .72rem;
}
</style>

    <div class="cug-page" id="cugManagementPage">

        {{-- Topbar --}}
        @include(
            'content.cug_management.partials.topbar'
        )

        {{-- Toolbar --}}
        @include(
            'content.cug_management.partials.toolbar'
        )

        {{-- Dashboard Cards --}}
        @include(
            'content.cug_management.partials.cards'
        )

        {{-- Main DataTable --}}
        @include(
            'content.cug_management.partials.datatable'
        )

        {{-- Activity Timeline --}}
        @include(
            'content.cug_management.partials.timeline'
        )

    </div>

    {{-- =====================================================
        Modals
    ====================================================== --}}

    @include(
        'content.cug_management.modal.number_modal'
    )

    @include(
        'content.cug_management.modal.assign_modal'
    )

    @include(
        'content.cug_management.modal.change_staff_modal'
    )

    @include(
        'content.cug_management.modal.history_modal'
    )

    @push('scripts')

<script>
    window.cugRoutes = {
        store: @json(route('cug.management.store')),
        show: @json(route('cug.management.show', ['id' => '__ID__'])),
        update: @json(route('cug.management.update', ['id' => '__ID__'])),

        datatable: @json(route('cug.management.datatable')),

        companies: @json(route('cug.management.companies')),
        entities: @json(route('cug.management.entities')),
        branches: @json(route('cug.management.branches')),

        staffSearch: @json(route('cug.management.staff.search')),
        staffShow: @json(route('cug.management.staff.show', ['id' => '__ID__'])),

        assign: @json(route('cug.management.assign')),
        changeStaff: @json(route('cug.management.change-staff')),

        release: @json(route('cug.management.release', ['id' => '__ID__'])),
        deactivate: @json(route('cug.management.deactivate', ['id' => '__ID__'])),
        delete: @json(route('cug.management.delete', ['id' => '__ID__'])),

        assignmentHistory: @json(route('cug.management.assignment-history', ['id' => '__ID__'])),
        callHistory: @json(route('cug.management.call-history', ['id' => '__ID__']))
    };
</script>


{{-- CUG --}}
<script src="{{ asset('assets/js/cug/helper.js') }}"></script>
<script src="{{ asset('assets/js/cug/dashboard.js') }}"></script>
<script src="{{ asset('assets/js/cug/filter.js') }}"></script>
<script src="{{ asset('assets/js/cug/datatable.js') }}"></script>
<script src="{{ asset('assets/js/cug/modal.js') }}"></script>
@endpush

@endsection