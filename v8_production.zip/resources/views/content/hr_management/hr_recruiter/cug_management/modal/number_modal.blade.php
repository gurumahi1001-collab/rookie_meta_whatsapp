{{-- =========================================================
    CUG Management
    Add / Edit CUG Number Modal
========================================================= --}}

<div
    class="modal fade"
    id="cugNumberModal"
    tabindex="-1"
    aria-labelledby="cugNumberModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content cug-modal-content">

            {{-- =================================================
                HEADER
            ================================================= --}}

            <div class="modal-header cug-modal-header">

                <div class="cug-modal-heading">

                    <div class="cug-modal-icon">

                        <i
                            class="ti ti-device-mobile"
                            id="cugNumberModalIcon">
                        </i>

                    </div>

                    <div>

                        <h5
                            class="modal-title"
                            id="cugNumberModalLabel">

                            Add CUG Number

                        </h5>

                        <span
                            class="cug-modal-subtitle"
                            id="cugNumberModalSubtitle">

                            Add a new CUG number to the managed number pool.

                        </span>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================= --}}

            <form
                id="cugNumberForm"
                autocomplete="off">

                @csrf

                <input
                    type="hidden"
                    name="sno"
                    id="cugNumberId"
                    value="">

                <input
                    type="hidden"
                    name="_method"
                    id="cugNumberMethod"
                    value="POST">


                <div class="modal-body cug-modal-body">

                    {{-- =================================================
                        ALERT
                    ================================================= --}}

                    <div
                        class="alert alert-danger d-none cug-modal-alert"
                        id="cugNumberFormAlert"
                        role="alert">

                        <div class="d-flex align-items-start gap-2">

                            <i class="ti ti-alert-circle mt-1"></i>

                            <div>

                                <strong>
                                    Unable to save CUG number.
                                </strong>

                                <div
                                    class="mt-1"
                                    id="cugNumberFormAlertMessage">
                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        BASIC INFORMATION
                    ================================================= --}}

                    <div class="cug-form-section">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Number Information
                                </h6>

                                <span>
                                    Enter the CUG number and provider details.
                                </span>

                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- CUG Number --}}
                            <div class="col-md-7">

                                <label
                                    for="cugNumber"
                                    class="form-label">

                                    CUG Number

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <div class="cug-input-group">

                                    <span class="cug-input-prefix">

                                        <i class="ti ti-phone"></i>

                                    </span>

                                    <input
                                        type="text"
                                        class="form-control"
                                        id="cugNumber"
                                        name="cug_number"
                                        placeholder="Enter CUG number"
                                        maxlength="20"
                                        inputmode="numeric"
                                        autocomplete="off"
                                        required>

                                </div>

                                <div
                                    class="form-text"
                                    id="cugNumberHelp">

                                    Enter the complete CUG mobile number.

                                </div>

                            </div>


                            {{-- Provider --}}
                            <div class="col-md-5">

                                <label
                                    for="cugProvider"
                                    class="form-label">

                                    Provider

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select"
                                    id="cugProvider"
                                    name="provider"
                                    required>

                                    <option value="">
                                        Select Provider
                                    </option>

                                    <option value="Airtel">
                                        Airtel
                                    </option>

                                    <option value="Jio">
                                        Jio
                                    </option>

                                    <option value="Vi">
                                        Vi
                                    </option>

                                    <option value="BSNL">
                                        BSNL
                                    </option>

                                    <option value="Other">
                                        Other
                                    </option>

                                </select>

                            </div>


                            {{-- CUG Code --}}
                            <div class="col-md-6">

                                <label
                                    for="cugCode"
                                    class="form-label">

                                    CUG Code

                                    <span class="text-muted fw-normal">
                                        (Optional)
                                    </span>

                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    id="cugCode"
                                    name="cug_code"
                                    placeholder="Example: CUG-000001"
                                    maxlength="100">

                                <div class="form-text">

                                    Internal reference code for this number.

                                </div>

                            </div>


                            {{-- Status --}}
                            <div class="col-md-6">

                                <label
                                    for="cugStatus"
                                    class="form-label">

                                    Status

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select"
                                    id="cugStatus"
                                    name="status"
                                    required>

                                    <option value="0">
                                        Available
                                    </option>

                                    <option value="1">
                                        Assigned
                                    </option>

                                    <option value="2">
                                        Reserved
                                    </option>

                                    <option value="3">
                                        Inactive
                                    </option>

                                </select>

                                <div class="form-text">

                                    New numbers normally start as Available.

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        ORGANIZATION
                    ================================================= --}}

                    <div class="cug-form-section">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Organization
                                </h6>

                                <span>
                                    Select where this CUG number belongs.
                                </span>

                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Company --}}
                            <div class="col-md-4">

                                <label
                                    for="cugCompany"
                                    class="form-label">

                                    Company

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select cug-modal-select"
                                    id="cugCompany"
                                    name="company_id"
                                    required>

                                    <option value="">
                                        Select Company
                                    </option>

                                    {{-- AJAX populated --}}

                                </select>

                            </div>


                            {{-- Entity --}}
                            <div class="col-md-4">

                                <label
                                    for="cugEntity"
                                    class="form-label">

                                    Entity

                                </label>

                                <select
                                    class="form-select cug-modal-select"
                                    id="cugEntity"
                                    name="entity_id"
                                    disabled>

                                    <option value="">
                                        Select Entity
                                    </option>

                                    {{-- AJAX populated --}}

                                </select>

                            </div>


                            {{-- Branch --}}
                            <div class="col-md-4">

                                <label
                                    for="cugBranch"
                                    class="form-label">

                                    Branch

                                </label>

                                <select
                                    class="form-select cug-modal-select"
                                    id="cugBranch"
                                    name="branch_id"
                                    disabled>

                                    <option value="">
                                        Select Branch
                                    </option>

                                    {{-- AJAX populated --}}

                                </select>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        NOTES
                    ================================================= --}}

                    <div class="cug-form-section mb-0">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Notes
                                </h6>

                                <span>
                                    Optional internal information.
                                </span>

                            </div>

                        </div>


                        <div>

                            <label
                                for="cugRemarks"
                                class="form-label">

                                Remarks

                            </label>

                            <textarea
                                class="form-control"
                                id="cugRemarks"
                                name="remarks"
                                rows="3"
                                maxlength="500"
                                placeholder="Add any internal remarks...">
                            </textarea>

                            <div class="d-flex justify-content-end mt-1">

                                <small
                                    class="text-muted"
                                    id="cugRemarksCounter">

                                    0 / 500

                                </small>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER
                ================================================= --}}

                <div class="modal-footer cug-modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnSaveCugNumber">

                        <span class="cug-btn-text">

                            <i
                                class="ti ti-device-mobile-plus me-1"
                                id="cugSaveButtonIcon">
                            </i>

                            <span id="cugSaveButtonText">
                                Add CUG Number
                            </span>

                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>
<style>
    /* =========================================================
   CUG MODAL
========================================================= */

.cug-modal-content {
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow:
        0 20px 60px rgba(23, 32, 51, .16);
}

.cug-modal-header {
    padding: 18px 20px;
    border-bottom: 1px solid var(--border);
    background: var(--card);
}

.cug-modal-heading {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 12px;
}

.cug-modal-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 11px;

    background: var(--cug-primary-soft);
    color: var(--primary);

    font-size: 20px;
}

.cug-modal-header .modal-title {
    margin: 0;
    color: var(--text);
    font-size: .95rem;
    font-weight: 700;
}

.cug-modal-subtitle {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: .70rem;
    line-height: 1.4;
}

.cug-modal-body {
    max-height: calc(100vh - 190px);
    overflow-y: auto;
    padding: 20px;
}

.cug-modal-footer {
    padding: 14px 20px;
    border-top: 1px solid var(--border);
    background: #fafbfc;
}


/* =========================================================
   FORM SECTION
========================================================= */

.cug-form-section {
    margin-bottom: 22px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border);
}

.cug-form-section-header {
    margin-bottom: 15px;
}

.cug-form-section-header h6 {
    margin: 0;
    color: var(--text);
    font-size: .80rem;
    font-weight: 700;
}

.cug-form-section-header span {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: .68rem;
}


/* =========================================================
   INPUT GROUP
========================================================= */

.cug-input-group {
    position: relative;
    display: flex;
}

.cug-input-prefix {
    width: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--border);
    border-right: 0;

    border-radius: 8px 0 0 8px;

    background: #f8f9fa;
    color: var(--muted);

    font-size: 16px;
}

.cug-input-group .form-control {
    border-radius: 0 8px 8px 0;
}


/* =========================================================
   MODAL SELECT2
========================================================= */

.cug-modal-content
.select2-container--default
.select2-selection--single {
    min-height: 42px;
    height: 42px;
}

.cug-modal-content
.select2-container--default
.select2-selection--single
.select2-selection__rendered {
    line-height: 40px;
}


/* =========================================================
   ALERT
========================================================= */

.cug-modal-alert {
    border: 1px solid rgba(220, 38, 38, .15);
    border-radius: 9px;
    background: rgba(220, 38, 38, .05);
    color: var(--danger);
    font-size: .74rem;
}


/* =========================================================
   REQUIRED
========================================================= */

.cug-modal-content .required {
    color: var(--danger);
}


/* =========================================================
   FORM TEXT
========================================================= */

.cug-modal-content .form-text {
    margin-top: 5px;
    color: var(--muted);
    font-size: .65rem;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 767.98px) {

    .cug-modal-header {
        padding: 15px;
    }

    .cug-modal-body {
        max-height: calc(100vh - 160px);
        padding: 15px;
    }

    .cug-modal-footer {
        padding: 12px 15px;
    }

    .cug-modal-footer .btn {
        flex: 1;
    }

}
</style>