{{-- =========================================================
    CUG Management
    CUG History Modal
========================================================= --}}

<div
    class="modal fade"
    id="cugHistoryModal"
    tabindex="-1"
    aria-labelledby="cugHistoryModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-xl">

        <div class="modal-content cug-history-modal">

            {{-- =================================================
                HEADER
            ================================================= --}}

            <div class="modal-header cug-modal-header">

                <div class="cug-modal-heading">

                    <div class="cug-modal-icon">

                        <i class="ti ti-history"></i>

                    </div>

                    <div>

                        <h5
                            class="modal-title"
                            id="cugHistoryModalLabel">

                            CUG History

                        </h5>

                        <span
                            class="cug-modal-subtitle"
                            id="cugHistoryModalSubtitle">

                            Assignment and call activity for this CUG number.

                        </span>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                BODY
            ================================================= --}}

            <div class="modal-body cug-history-modal-body">

                {{-- =================================================
                    CUG SUMMARY
                ================================================= --}}

                <div class="cug-history-summary">

                    <div class="cug-history-summary-left">

                        <div class="cug-history-number-icon">

                            <i class="ti ti-device-mobile"></i>

                        </div>

                        <div>

                            <span class="cug-history-summary-label">

                                CUG Number

                            </span>

                            <strong
                                id="cugHistoryNumber"
                                class="cug-history-number">

                                —

                            </strong>

                            <div
                                id="cugHistoryProvider"
                                class="cug-history-provider">

                                —

                            </div>

                        </div>

                    </div>


                    <div class="cug-history-summary-stats">

                        <div class="cug-history-summary-stat">

                            <span>
                                Current Staff
                            </span>

                            <strong
                                id="cugHistoryCurrentStaff">

                                —

                            </strong>

                        </div>

                        <div class="cug-history-summary-stat">

                            <span>
                                Total Calls
                            </span>

                            <strong
                                id="cugHistoryTotalCalls">

                                0

                            </strong>

                        </div>

                        <div class="cug-history-summary-stat">

                            <span>
                                Current Status
                            </span>

                            <strong
                                id="cugHistoryStatus">

                                —

                            </strong>

                        </div>

                    </div>

                </div>


                {{-- =================================================
                    TABS
                ================================================= --}}

                <div class="cug-history-tabs-wrapper">

                    <ul
                        class="nav nav-tabs cug-history-tabs"
                        id="cugHistoryTabs"
                        role="tablist">

                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                type="button"
                                class="nav-link active"
                                id="cugAssignmentHistoryTab"
                                data-bs-toggle="tab"
                                data-bs-target="#cugAssignmentHistoryPane"
                                role="tab"
                                aria-controls="cugAssignmentHistoryPane"
                                aria-selected="true">

                                <i class="ti ti-users me-1"></i>

                                Assignment History

                                <span
                                    class="cug-history-tab-count"
                                    id="cugAssignmentHistoryCount">

                                    0

                                </span>

                            </button>

                        </li>


                        <li
                            class="nav-item"
                            role="presentation">

                            <button
                                type="button"
                                class="nav-link"
                                id="cugCallHistoryTab"
                                data-bs-toggle="tab"
                                data-bs-target="#cugCallHistoryPane"
                                role="tab"
                                aria-controls="cugCallHistoryPane"
                                aria-selected="false">

                                <i class="ti ti-phone-call me-1"></i>

                                Call History

                                <span
                                    class="cug-history-tab-count"
                                    id="cugCallHistoryCount">

                                    0

                                </span>

                            </button>

                        </li>

                    </ul>

                </div>


                {{-- =================================================
                    TAB CONTENT
                ================================================= --}}

                <div
                    class="tab-content cug-history-tab-content"
                    id="cugHistoryTabContent">


                    {{-- =================================================
                        ASSIGNMENT HISTORY
                    ================================================= --}}

                    <div
                        class="tab-pane fade show active"
                        id="cugAssignmentHistoryPane"
                        role="tabpanel"
                        aria-labelledby="cugAssignmentHistoryTab">

                        <div
                            class="cug-history-loading d-none"
                            id="cugAssignmentHistoryLoading">

                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>

                        </div>


                        <div
                            class="cug-assignment-timeline"
                            id="cugAssignmentTimeline">

                            {{-- AJAX populated --}}

                        </div>


                        <div
                            class="cug-history-empty d-none"
                            id="cugAssignmentHistoryEmpty">

                            <div class="cug-history-empty-icon">

                                <i class="ti ti-users-off"></i>

                            </div>

                            <strong>
                                No assignment history
                            </strong>

                            <span>
                                No staff assignment records were found for this CUG number.
                            </span>

                        </div>

                    </div>


                    {{-- =================================================
                        CALL HISTORY
                    ================================================= --}}

                    <div
                        class="tab-pane fade"
                        id="cugCallHistoryPane"
                        role="tabpanel"
                        aria-labelledby="cugCallHistoryTab">

                        <div class="cug-call-history-toolbar">

                            <div>

                                <span
                                    class="cug-call-history-title">

                                    Call Activity

                                </span>

                                <span
                                    class="cug-call-history-subtitle">

                                    Calls associated with this CUG number.

                                </span>

                            </div>


                            <div class="cug-call-history-filters">

                                <div class="cug-history-date-filter">

                                    <i class="ti ti-calendar"></i>

                                    <input
                                        type="text"
                                        class="form-control cug-date-input"
                                        id="cugCallHistoryFrom"
                                        placeholder="From">

                                </div>


                                <span class="cug-date-range-separator">
                                    —
                                </span>


                                <div class="cug-history-date-filter">

                                    <i class="ti ti-calendar"></i>

                                    <input
                                        type="text"
                                        class="form-control cug-date-input"
                                        id="cugCallHistoryTo"
                                        placeholder="To">

                                </div>


                                <button
                                    type="button"
                                    class="btn btn-sm btn-label-secondary"
                                    id="btnFilterCugCalls">

                                    <i class="ti ti-filter me-1"></i>

                                    Filter

                                </button>

                            </div>

                        </div>


                        <div
                            class="cug-call-history-loading d-none"
                            id="cugCallHistoryLoading">

                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>

                        </div>


                        <div
                            class="table-responsive cug-call-table-wrapper"
                            id="cugCallHistoryTableWrapper">

                            <table
                                class="table cug-call-history-table">

                                <thead>

                                    <tr>

                                        <th>
                                            Date / Time
                                        </th>

                                        <th>
                                            Type
                                        </th>

                                        <th>
                                            Caller / Number
                                        </th>

                                        <th>
                                            Duration
                                        </th>

                                        <th>
                                            Staff
                                        </th>

                                        <th>
                                            Status
                                        </th>

                                    </tr>

                                </thead>

                                <tbody
                                    id="cugCallHistoryBody">

                                    {{-- AJAX populated --}}

                                </tbody>

                            </table>

                        </div>


                        <div
                            class="cug-history-empty d-none"
                            id="cugCallHistoryEmpty">

                            <div class="cug-history-empty-icon">

                                <i class="ti ti-phone-off"></i>

                            </div>

                            <strong>
                                No call history
                            </strong>

                            <span>
                                No call records were found for the selected period.
                            </span>

                        </div>


                        <div
                            class="cug-call-pagination"
                            id="cugCallHistoryPagination">

                            {{-- AJAX populated --}}

                        </div>

                    </div>

                </div>

            </div>


            {{-- =================================================
                FOOTER
            ================================================= --}}

            <div class="modal-footer cug-modal-footer">

                <button
                    type="button"
                    class="btn btn-label-secondary"
                    data-bs-dismiss="modal">

                    Close

                </button>

            </div>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CUG HISTORY MODAL
========================================================= */

.cug-history-modal {
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow:
        0 20px 60px rgba(23, 32, 51, .16);
}

.cug-history-modal-body {
    max-height: calc(100vh - 170px);
    overflow-y: auto;
    padding: 20px;
}


/* =========================================================
   HISTORY SUMMARY
========================================================= */

.cug-history-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;

    margin-bottom: 20px;
    padding: 15px;

    border: 1px solid var(--border);
    border-radius: 12px;

    background: #fafbfc;
}

.cug-history-summary-left {
    min-width: 220px;

    display: flex;
    align-items: center;
    gap: 12px;
}

.cug-history-number-icon {
    width: 44px;
    height: 44px;
    min-width: 44px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 11px;

    background: var(--cug-primary-soft);
    color: var(--primary);

    font-size: 20px;
}

.cug-history-summary-label {
    display: block;

    margin-bottom: 2px;

    color: var(--muted);
    font-size: .63rem;
    font-weight: 600;
}

.cug-history-number {
    display: block;

    color: var(--text);
    font-size: .95rem;
    font-weight: 700;
    letter-spacing: .2px;
}

.cug-history-provider {
    margin-top: 2px;

    color: var(--muted);
    font-size: .66rem;
}

.cug-history-summary-stats {
    display: flex;
    align-items: stretch;
    gap: 1px;
}

.cug-history-summary-stat {
    min-width: 115px;

    padding: 0 14px;

    border-left: 1px solid var(--border);
}

.cug-history-summary-stat span {
    display: block;

    color: var(--muted);
    font-size: .62rem;
}

.cug-history-summary-stat strong {
    display: block;

    margin-top: 4px;

    color: var(--text);
    font-size: .76rem;
    font-weight: 700;
}


/* =========================================================
   TABS
========================================================= */

.cug-history-tabs-wrapper {
    border-bottom: 1px solid var(--border);
}

.cug-history-tabs {
    gap: 4px;
    border-bottom: 0;
}

.cug-history-tabs .nav-link {
    display: inline-flex;
    align-items: center;
    gap: 2px;

    margin-bottom: -1px;
    padding: 10px 13px;

    border: 0;
    border-bottom: 2px solid transparent;

    border-radius: 7px 7px 0 0;

    background: transparent;

    color: var(--muted);

    font-size: .72rem;
    font-weight: 600;

    transition: var(--cug-transition);
}

.cug-history-tabs .nav-link:hover {
    color: var(--primary);
    background: var(--cug-primary-soft-2);
}

.cug-history-tabs .nav-link.active {
    border-bottom-color: var(--primary);

    background: var(--cug-primary-soft-2);

    color: var(--primary);
}

.cug-history-tab-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    min-width: 19px;
    height: 18px;

    margin-left: 4px;
    padding: 0 5px;

    border-radius: 10px;

    background: var(--border);

    color: var(--muted);

    font-size: .58rem;
    font-weight: 700;
}

.cug-history-tabs .nav-link.active
.cug-history-tab-count {
    background: var(--primary);
    color: #fff;
}


/* =========================================================
   TAB CONTENT
========================================================= */

.cug-history-tab-content {
    padding-top: 20px;
}


/* =========================================================
   ASSIGNMENT TIMELINE
========================================================= */

.cug-assignment-timeline {
    position: relative;
    padding: 4px 4px 4px 8px;
}

.cug-assignment-history-item {
    position: relative;

    display: flex;
    gap: 13px;

    padding-bottom: 22px;
}

.cug-assignment-history-item:last-child {
    padding-bottom: 0;
}

.cug-assignment-history-item:not(:last-child)::before {
    content: "";

    position: absolute;

    left: 16px;
    top: 34px;
    bottom: 0;

    width: 1px;

    background: var(--border);
}

.cug-assignment-history-icon {
    position: relative;
    z-index: 2;

    width: 33px;
    height: 33px;
    min-width: 33px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 3px solid var(--card);
    border-radius: 50%;

    background: var(--cug-primary-soft);

    color: var(--primary);

    box-shadow:
        0 0 0 1px var(--border);

    font-size: 14px;
}

.cug-assignment-history-icon.assigned {
    background: var(--cug-success-soft);
    color: var(--success);
}

.cug-assignment-history-icon.released {
    background: var(--cug-warning-soft);
    color: var(--warning);
}

.cug-assignment-history-icon.transferred {
    background: var(--cug-primary-soft);
    color: var(--primary);
}

.cug-assignment-history-icon.current {
    background: var(--cug-success-soft);
    color: var(--success);
}

.cug-assignment-history-content {
    flex: 1;
    min-width: 0;
}

.cug-assignment-history-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 15px;
}

.cug-assignment-history-title {
    color: var(--text);
    font-size: .77rem;
    font-weight: 700;
}

.cug-assignment-history-date {
    white-space: nowrap;

    color: var(--muted);
    font-size: .64rem;
}

.cug-assignment-history-description {
    margin-top: 4px;

    color: var(--muted);
    font-size: .69rem;
    line-height: 1.5;
}

.cug-assignment-history-description strong {
    color: var(--text);
    font-weight: 600;
}

.cug-assignment-history-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;

    margin-top: 8px;
}

.cug-assignment-history-tag {
    display: inline-flex;
    align-items: center;
    gap: 4px;

    padding: 4px 7px;

    border-radius: 6px;

    background: var(--bg);

    color: var(--muted);

    font-size: .61rem;
    font-weight: 600;
}

.cug-assignment-history-tag.reason {
    background: var(--cug-warning-soft);
    color: var(--warning);
}


/* =========================================================
   CALL HISTORY TOOLBAR
========================================================= */

.cug-call-history-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;

    margin-bottom: 14px;
}

.cug-call-history-title {
    display: block;

    color: var(--text);
    font-size: .78rem;
    font-weight: 700;
}

.cug-call-history-subtitle {
    display: block;

    margin-top: 3px;

    color: var(--muted);
    font-size: .65rem;
}

.cug-call-history-filters {
    display: flex;
    align-items: center;
    gap: 7px;
}

.cug-history-date-filter {
    position: relative;
}

.cug-history-date-filter > i {
    position: absolute;

    top: 50%;
    left: 9px;

    z-index: 2;

    transform: translateY(-50%);

    color: var(--muted);

    font-size: 14px;

    pointer-events: none;
}

.cug-history-date-filter .form-control {
    width: 125px;

    height: 34px;

    padding-left: 29px;

    font-size: .66rem;
}

.cug-date-range-separator {
    color: var(--muted);
    font-size: .68rem;
}


/* =========================================================
   CALL TABLE
========================================================= */

.cug-call-table-wrapper {
    border: 1px solid var(--border);
    border-radius: 10px;
}

.cug-call-history-table {
    min-width: 760px;
    margin-bottom: 0;
}

.cug-call-history-table thead th {
    padding: 10px 12px;

    border-bottom: 1px solid var(--border);

    background: #fafbfc;

    color: var(--muted);

    font-size: .64rem;
    font-weight: 700;
    white-space: nowrap;
}

.cug-call-history-table tbody td {
    padding: 11px 12px;

    border-bottom: 1px solid var(--border);

    color: var(--text);

    font-size: .68rem;
    vertical-align: middle;
}

.cug-call-history-table tbody tr:last-child td {
    border-bottom: 0;
}

.cug-call-history-table tbody tr:hover {
    background: var(--cug-primary-soft-2);
}

.cug-call-datetime strong {
    display: block;

    color: var(--text);
    font-size: .68rem;
}

.cug-call-datetime span {
    display: block;

    margin-top: 2px;

    color: var(--muted);
    font-size: .60rem;
}

.cug-call-number {
    color: var(--text);
    font-weight: 600;
}

.cug-call-duration {
    color: var(--muted);
}

.cug-call-staff {
    color: var(--text);
    font-weight: 600;
}


/* =========================================================
   CALL TYPE
========================================================= */

.cug-call-type {
    display: inline-flex;
    align-items: center;
    gap: 4px;

    padding: 4px 7px;

    border-radius: 6px;

    font-size: .61rem;
    font-weight: 700;
}

.cug-call-type.incoming {
    background: var(--cug-success-soft);
    color: var(--success);
}

.cug-call-type.outgoing {
    background: var(--cug-primary-soft);
    color: var(--primary);
}

.cug-call-type.missed {
    background: var(--cug-danger-soft);
    color: var(--danger);
}


/* =========================================================
   CALL STATUS
========================================================= */

.cug-call-status {
    display: inline-flex;
    align-items: center;
    gap: 5px;

    font-size: .62rem;
    font-weight: 600;
}

.cug-call-status-dot {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: currentColor;
}


/* =========================================================
   EMPTY
========================================================= */

.cug-history-empty {
    min-height: 210px;

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    gap: 5px;

    text-align: center;
}

.cug-history-empty-icon {
    width: 48px;
    height: 48px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 5px;

    border-radius: 12px;

    background: var(--cug-primary-soft);

    color: var(--primary);

    font-size: 21px;
}

.cug-history-empty strong {
    color: var(--text);
    font-size: .76rem;
}

.cug-history-empty span {
    max-width: 320px;

    color: var(--muted);
    font-size: .65rem;
    line-height: 1.45;
}


/* =========================================================
   LOADING
========================================================= */

.cug-history-loading,
.cug-call-history-loading {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.cug-history-loading-row {
    height: 58px;

    border-radius: 8px;

    background:
        linear-gradient(
            90deg,
            #f1f2f4 25%,
            #e7e9ec 37%,
            #f1f2f4 63%
        );

    background-size: 400% 100%;

    animation:
        cugHistorySkeleton 1.4s ease infinite;
}

@keyframes cugHistorySkeleton {

    0% {
        background-position: 100% 0;
    }

    100% {
        background-position: 0 0;
    }

}


/* =========================================================
   CALL PAGINATION
========================================================= */

.cug-call-pagination {
    display: flex;
    justify-content: flex-end;

    margin-top: 12px;
}

.cug-call-pagination .pagination {
    margin-bottom: 0;
}

.cug-call-pagination .page-link {
    min-width: 30px;
    height: 30px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    padding: 0 7px;

    border-color: var(--border);

    color: var(--muted);

    font-size: .64rem;
}

.cug-call-pagination .page-item.active .page-link {
    border-color: var(--primary);
    background: var(--primary);
    color: #fff;
}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 767.98px) {

    .cug-history-modal-body {
        padding: 15px;
    }

    .cug-history-summary {
        align-items: flex-start;
        flex-direction: column;
    }

    .cug-history-summary-stats {
        width: 100%;
        overflow-x: auto;
    }

    .cug-history-summary-stat {
        flex: 1;
        min-width: 100px;
    }

    .cug-call-history-toolbar {
        align-items: flex-start;
        flex-direction: column;
    }

    .cug-call-history-filters {
        width: 100%;
        flex-wrap: wrap;
    }

    .cug-history-date-filter {
        flex: 1;
    }

    .cug-history-date-filter .form-control {
        width: 100%;
    }

    .cug-call-history-filters .btn {
        height: 34px;
    }

}

@media (max-width: 575.98px) {

    .cug-history-tabs .nav-link {
        padding: 9px 8px;
        font-size: .66rem;
    }

    .cug-history-tabs .nav-link i {
        display: none;
    }

}
</style>