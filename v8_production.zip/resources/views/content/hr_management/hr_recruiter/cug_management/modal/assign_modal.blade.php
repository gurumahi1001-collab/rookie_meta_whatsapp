{{-- =========================================================
    CUG Management
    Assign CUG Number → Staff Modal
========================================================= --}}

<div
    class="modal fade"
    id="cugAssignModal"
    tabindex="-1"
    aria-labelledby="cugAssignModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content cug-modal-content">

            {{-- =================================================
                HEADER
            ================================================= --}}

            <div class="modal-header cug-modal-header">

                <div class="cug-modal-heading">

                    <div class="cug-modal-icon cug-modal-icon-success">

                        <i class="ti ti-user-plus"></i>

                    </div>

                    <div>

                        <h5
                            class="modal-title"
                            id="cugAssignModalLabel">

                            Assign CUG Number

                        </h5>

                        <span
                            class="cug-modal-subtitle"
                            id="cugAssignModalSubtitle">

                            Assign an available CUG number to a staff member.

                        </span>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================= --}}

            <form
                id="cugAssignForm"
                autocomplete="off">

                @csrf

                <input
                    type="hidden"
                    name="cug_id"
                    id="cugAssignNumberId"
                    value="">


                <div class="modal-body cug-modal-body">

                    {{-- =================================================
                        ALERT
                    ================================================= --}}

                    <div
                        class="alert alert-danger d-none cug-modal-alert"
                        id="cugAssignFormAlert"
                        role="alert">

                        <div class="d-flex align-items-start gap-2">

                            <i class="ti ti-alert-circle mt-1"></i>

                            <div>

                                <strong>
                                    Unable to assign CUG number.
                                </strong>

                                <div
                                    class="mt-1"
                                    id="cugAssignFormAlertMessage">
                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        CUG NUMBER SUMMARY
                    ================================================= --}}

                    <div class="cug-assignment-summary">

                        <div class="cug-assignment-summary-icon">

                            <i class="ti ti-device-mobile"></i>

                        </div>

                        <div class="cug-assignment-summary-content">

                            <span class="cug-assignment-summary-label">

                                CUG Number

                            </span>

                            <strong
                                id="cugAssignNumber"
                                class="cug-assignment-number">

                                —

                            </strong>

                            <div
                                id="cugAssignProvider"
                                class="cug-assignment-provider">

                                —

                            </div>

                        </div>

                        <div
                            id="cugAssignCurrentStatus"
                            class="cug-status-badge cug-status-available">

                            <span class="cug-status-dot"></span>

                            Available

                        </div>

                    </div>


                    {{-- =================================================
                        STAFF
                    ================================================= --}}

                    <div class="cug-form-section">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Staff Assignment
                                </h6>

                                <span>
                                    Select the staff member who will use this CUG number.
                                </span>

                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Staff --}}
                            <div class="col-12">

                                <label
                                    for="cugAssignStaff"
                                    class="form-label">

                                    Staff

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select"
                                    id="cugAssignStaff"
                                    name="staff_id"
                                    required>

                                    <option value="">
                                        Search Staff
                                    </option>

                                </select>

                                <div class="form-text">

                                    Only eligible active staff should be selectable.

                                </div>

                            </div>


                            {{-- Assignment Date --}}
                            <div class="col-md-6">

                                <label
                                    for="cugAssignDate"
                                    class="form-label">

                                    Assignment Date

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <div class="cug-input-group">

                                    <span class="cug-input-prefix">

                                        <i class="ti ti-calendar-event"></i>

                                    </span>

                                    <input
                                        type="text"
                                        class="form-control cug-date-input"
                                        id="cugAssignDate"
                                        name="assigned_date"
                                        placeholder="Select date"
                                        required>

                                </div>

                                <div class="form-text">

                                    Defaults to today.

                                </div>

                            </div>


                            {{-- Assignment Type --}}
                            <div class="col-md-6">

                                <label
                                    for="cugAssignmentType"
                                    class="form-label">

                                    Assignment Type

                                </label>

                                <select
                                    class="form-select"
                                    id="cugAssignmentType"
                                    name="assignment_type">

                                    <option value="NEW">
                                        New Assignment
                                    </option>

                                    <option value="REASSIGN">
                                        Reassignment
                                    </option>

                                </select>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        STAFF PREVIEW
                    ================================================= --}}

                    <div
                        class="cug-staff-preview d-none"
                        id="cugAssignStaffPreview">

                        <div class="cug-staff-preview-avatar">

                            <span
                                id="cugAssignStaffInitials">
                                ?
                            </span>

                        </div>

                        <div class="cug-staff-preview-content">

                            <strong
                                id="cugAssignStaffName">

                                —

                            </strong>

                            <span
                                id="cugAssignStaffId">

                                —

                            </span>

                            <div class="cug-staff-preview-meta">

                                <span id="cugAssignStaffDepartment">
                                    —
                                </span>

                                <span class="cug-preview-divider">
                                    •
                                </span>

                                <span id="cugAssignStaffDesignation">
                                    —
                                </span>

                            </div>

                        </div>

                        <span
                            class="cug-badge cug-badge-success">

                            Active

                        </span>

                    </div>


                    {{-- =================================================
                        WARNING
                    ================================================= --}}

                    <div
                        class="cug-assignment-warning d-none"
                        id="cugAssignStaffWarning">

                        <div class="cug-assignment-warning-icon">

                            <i class="ti ti-alert-triangle"></i>

                        </div>

                        <div>

                            <strong>
                                Staff already has a CUG number
                            </strong>

                            <p id="cugAssignStaffWarningText">

                                This staff member is already assigned
                                to another CUG number.

                            </p>

                            <div class="cug-existing-cug">

                                <span>
                                    Existing CUG:
                                </span>

                                <strong
                                    id="cugAssignExistingNumber">

                                    —

                                </strong>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        REMARKS
                    ================================================= --}}

                    <div class="cug-form-section mb-0">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Assignment Notes
                                </h6>

                                <span>
                                    Optional information for the assignment history.
                                </span>

                            </div>

                        </div>


                        <label
                            for="cugAssignRemarks"
                            class="form-label">

                            Remarks

                        </label>

                        <textarea
                            class="form-control"
                            id="cugAssignRemarks"
                            name="remarks"
                            rows="3"
                            maxlength="500"
                            placeholder="Example: New employee CUG assignment...">
                        </textarea>

                        <div class="d-flex justify-content-end mt-1">

                            <small
                                class="text-muted"
                                id="cugAssignRemarksCounter">

                                0 / 500

                            </small>

                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER
                ================================================= --}}

                <div class="modal-footer cug-modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnAssignCug">

                        <span class="cug-btn-text">

                            <i class="ti ti-user-plus me-1"></i>

                            Assign CUG

                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   ASSIGNMENT MODAL
========================================================= */

.cug-modal-icon-success {
    background: var(--cug-success-soft);
    color: var(--success);
}


/* =========================================================
   CUG ASSIGNMENT SUMMARY
========================================================= */

.cug-assignment-summary {
    display: flex;
    align-items: center;
    gap: 13px;

    margin-bottom: 22px;
    padding: 14px;

    border: 1px solid var(--border);
    border-radius: 11px;

    background: #fafbfc;
}

.cug-assignment-summary-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 10px;

    background: var(--cug-primary-soft);
    color: var(--primary);

    font-size: 19px;
}

.cug-assignment-summary-content {
    min-width: 0;
    flex: 1;
}

.cug-assignment-summary-label {
    display: block;
    margin-bottom: 2px;

    color: var(--muted);
    font-size: .63rem;
    font-weight: 600;
}

.cug-assignment-number {
    display: block;

    color: var(--text);
    font-size: .94rem;
    letter-spacing: .2px;
}

.cug-assignment-provider {
    margin-top: 2px;

    color: var(--muted);
    font-size: .66rem;
}


/* =========================================================
   STAFF PREVIEW
========================================================= */

.cug-staff-preview {
    display: flex;
    align-items: center;
    gap: 11px;

    margin-top: 16px;
    margin-bottom: 22px;
    padding: 12px;

    border: 1px solid var(--border);
    border-radius: 10px;

    background: var(--card);
}

.cug-staff-preview-avatar {
    width: 40px;
    height: 40px;
    min-width: 40px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: var(--cug-primary-soft);
    color: var(--primary);

    font-size: .74rem;
    font-weight: 700;
}

.cug-staff-preview-content {
    flex: 1;
    min-width: 0;
}

.cug-staff-preview-content strong {
    display: block;

    overflow: hidden;

    color: var(--text);
    font-size: .77rem;
    font-weight: 700;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.cug-staff-preview-content > span {
    display: block;
    margin-top: 2px;

    color: var(--muted);
    font-size: .64rem;
}

.cug-staff-preview-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;

    margin-top: 4px;

    color: var(--muted);
    font-size: .62rem;
}

.cug-preview-divider {
    color: #d1d5db;
}


/* =========================================================
   EXISTING CUG WARNING
========================================================= */

.cug-assignment-warning {
    display: flex;
    align-items: flex-start;
    gap: 11px;

    margin-bottom: 22px;
    padding: 13px;

    border: 1px solid rgba(217, 119, 6, .18);
    border-radius: 10px;

    background: var(--cug-warning-soft);
}

.cug-assignment-warning-icon {
    width: 31px;
    height: 31px;
    min-width: 31px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: rgba(217, 119, 6, .12);
    color: var(--warning);

    font-size: 16px;
}

.cug-assignment-warning strong {
    display: block;

    color: #92400e;
    font-size: .73rem;
    font-weight: 700;
}

.cug-assignment-warning p {
    margin: 3px 0 7px;

    color: #92400e;
    font-size: .67rem;
    line-height: 1.45;
}

.cug-existing-cug {
    display: inline-flex;
    align-items: center;
    gap: 6px;

    padding: 5px 8px;

    border-radius: 6px;

    background: rgba(255, 255, 255, .65);

    color: var(--muted);
    font-size: .64rem;
}

.cug-existing-cug strong {
    color: #92400e;
    font-size: .68rem;
}


/* =========================================================
   DATE INPUT
========================================================= */

.cug-date-input {
    cursor: pointer;
}


/* =========================================================
   ASSIGN SELECT2
========================================================= */

#cugAssignModal
.select2-container--default
.select2-selection--single {
    min-height: 42px;
    height: 42px;
}

#cugAssignModal
.select2-container--default
.select2-selection--single
.select2-selection__rendered {
    line-height: 40px;
}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 575.98px) {

    .cug-assignment-summary {
        flex-wrap: wrap;
    }

    .cug-assignment-summary
    .cug-status-badge {
        margin-left: 55px;
    }

    .cug-staff-preview {
        align-items: flex-start;
    }

}
</style>