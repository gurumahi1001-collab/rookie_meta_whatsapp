{{-- =========================================================
    CUG Management
    Change / Transfer CUG Staff Modal
========================================================= --}}

<div
    class="modal fade"
    id="cugChangeStaffModal"
    tabindex="-1"
    aria-labelledby="cugChangeStaffModalLabel"
    aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content cug-modal-content">

            {{-- =================================================
                HEADER
            ================================================= --}}

            <div class="modal-header cug-modal-header">

                <div class="cug-modal-heading">

                    <div class="cug-modal-icon cug-modal-icon-transfer">

                        <i class="ti ti-user-shared"></i>

                    </div>

                    <div>

                        <h5
                            class="modal-title"
                            id="cugChangeStaffModalLabel">

                            Change CUG Staff

                        </h5>

                        <span
                            class="cug-modal-subtitle">

                            Transfer this CUG number from the current staff member to another staff member.

                        </span>

                    </div>

                </div>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                </button>

            </div>


            {{-- =================================================
                FORM
            ================================================= --}}

            <form
                id="cugChangeStaffForm"
                autocomplete="off">

                @csrf

                <input
                    type="hidden"
                    name="cug_id"
                    id="cugChangeCugId"
                    value="">

                <div class="modal-body cug-modal-body">

                    {{-- =================================================
                        ERROR
                    ================================================= --}}

                    <div
                        class="alert alert-danger d-none cug-modal-alert"
                        id="cugChangeStaffFormAlert"
                        role="alert">

                        <div class="d-flex align-items-start gap-2">

                            <i class="ti ti-alert-circle mt-1"></i>

                            <div>

                                <strong>
                                    Unable to change CUG staff.
                                </strong>

                                <div
                                    class="mt-1"
                                    id="cugChangeStaffFormAlertMessage">
                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        CUG SUMMARY
                    ================================================= --}}

                    <div class="cug-assignment-summary">

                        <div class="cug-assignment-summary-icon">

                            <i class="ti ti-device-mobile"></i>

                        </div>

                        <div class="cug-assignment-summary-content">

                            <span class="cug-assignment-summary-label">

                                CUG Number

                            </span>

                            <strong
                                id="cugChangeCugNumber"
                                class="cug-assignment-number">

                                —

                            </strong>

                            <div
                                id="cugChangeCugProvider"
                                class="cug-assignment-provider">

                                —

                            </div>

                        </div>

                        <span
                            class="cug-status-badge cug-status-assigned">

                            <span class="cug-status-dot"></span>

                            Assigned

                        </span>

                    </div>


                    {{-- =================================================
                        CURRENT ASSIGNMENT
                    ================================================= --}}

                    <div class="cug-transfer-section">

                        <div class="cug-transfer-section-header">

                            <div class="cug-transfer-step-number">
                                1
                            </div>

                            <div>

                                <h6>
                                    Current Staff
                                </h6>

                                <span>
                                    Existing assignment that will be closed.
                                </span>

                            </div>

                        </div>


                        <div
                            class="cug-current-staff-card"
                            id="cugCurrentStaffCard">

                            <div class="cug-current-staff-avatar">

                                <span
                                    id="cugCurrentStaffInitials">
                                    ?
                                </span>

                            </div>

                            <div class="cug-current-staff-content">

                                <strong
                                    id="cugCurrentStaffName">

                                    —

                                </strong>

                                <span
                                    id="cugCurrentStaffId">

                                    —

                                </span>

                                <div class="cug-current-staff-meta">

                                    <span
                                        id="cugCurrentStaffDepartment">

                                        —

                                    </span>

                                    <span class="cug-preview-divider">
                                        •
                                    </span>

                                    <span
                                        id="cugCurrentStaffDesignation">

                                        —

                                    </span>

                                </div>

                            </div>

                            <span class="cug-badge cug-badge-warning">

                                Current Owner

                            </span>

                        </div>

                    </div>


                    {{-- =================================================
                        TRANSFER ARROW
                    ================================================= --}}

                    <div class="cug-transfer-arrow">

                        <div class="cug-transfer-line"></div>

                        <div class="cug-transfer-arrow-icon">

                            <i class="ti ti-arrow-down"></i>

                        </div>

                        <div class="cug-transfer-line"></div>

                    </div>


                    {{-- =================================================
                        NEW STAFF
                    ================================================= --}}

                    <div class="cug-transfer-section">

                        <div class="cug-transfer-section-header">

                            <div class="cug-transfer-step-number cug-step-success">
                                2
                            </div>

                            <div>

                                <h6>
                                    Replacement Staff
                                </h6>

                                <span>
                                    Select the staff member who will receive this CUG number.
                                </span>

                            </div>

                        </div>


                        <div class="row g-3">

                            <div class="col-12">

                                <label
                                    for="cugReplacementStaff"
                                    class="form-label">

                                    New Staff

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select"
                                    id="cugReplacementStaff"
                                    name="new_staff_id"
                                    required>

                                    <option value="">
                                        Search replacement staff
                                    </option>

                                </select>

                                <div class="form-text">

                                    The replacement staff member must be active and eligible for CUG assignment.

                                </div>

                            </div>

                        </div>


                        {{-- New Staff Preview --}}

                        <div
                            class="cug-staff-preview d-none"
                            id="cugReplacementStaffPreview">

                            <div class="cug-staff-preview-avatar">

                                <span
                                    id="cugReplacementStaffInitials">
                                    ?
                                </span>

                            </div>

                            <div class="cug-staff-preview-content">

                                <strong
                                    id="cugReplacementStaffName">

                                    —

                                </strong>

                                <span
                                    id="cugReplacementStaffId">

                                    —

                                </span>

                                <div class="cug-staff-preview-meta">

                                    <span
                                        id="cugReplacementStaffDepartment">

                                        —

                                    </span>

                                    <span class="cug-preview-divider">
                                        •
                                    </span>

                                    <span
                                        id="cugReplacementStaffDesignation">

                                        —

                                    </span>

                                </div>

                            </div>

                            <span class="cug-badge cug-badge-success">

                                New Owner

                            </span>

                        </div>


                        {{-- Existing CUG warning --}}

                        <div
                            class="cug-assignment-warning d-none"
                            id="cugReplacementStaffWarning">

                            <div class="cug-assignment-warning-icon">

                                <i class="ti ti-alert-triangle"></i>

                            </div>

                            <div>

                                <strong>
                                    Replacement staff already has a CUG
                                </strong>

                                <p
                                    id="cugReplacementStaffWarningText">

                                    This staff member already has an assigned CUG number.

                                </p>

                                <div class="cug-existing-cug">

                                    <span>
                                        Existing CUG:
                                    </span>

                                    <strong
                                        id="cugReplacementExistingNumber">

                                        —

                                    </strong>

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        TRANSFER DETAILS
                    ================================================= --}}

                    <div class="cug-form-section">

                        <div class="cug-form-section-header">

                            <div>

                                <h6>
                                    Transfer Details
                                </h6>

                                <span>
                                    Record why and when the CUG ownership changed.
                                </span>

                            </div>

                        </div>


                        <div class="row g-3">

                            {{-- Effective Date --}}
                            <div class="col-md-6">

                                <label
                                    for="cugChangeEffectiveDate"
                                    class="form-label">

                                    Effective Date

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <div class="cug-input-group">

                                    <span class="cug-input-prefix">

                                        <i class="ti ti-calendar-event"></i>

                                    </span>

                                    <input
                                        type="text"
                                        class="form-control cug-date-input"
                                        id="cugChangeEffectiveDate"
                                        name="effective_date"
                                        placeholder="Select date"
                                        required>

                                </div>

                            </div>


                            {{-- Transfer Reason --}}
                            <div class="col-md-6">

                                <label
                                    for="cugTransferReason"
                                    class="form-label">

                                    Transfer Reason

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <select
                                    class="form-select"
                                    id="cugTransferReason"
                                    name="reason"
                                    required>

                                    <option value="">
                                        Select reason
                                    </option>

                                    <option value="STAFF_EXIT">
                                        Staff Exit
                                    </option>

                                    <option value="STAFF_TRANSFER">
                                        Staff Transfer
                                    </option>

                                    <option value="ROLE_CHANGE">
                                        Role Change
                                    </option>

                                    <option value="BUSINESS_REQUIREMENT">
                                        Business Requirement
                                    </option>

                                    <option value="TEMPORARY_REPLACEMENT">
                                        Temporary Replacement
                                    </option>

                                    <option value="OTHER">
                                        Other
                                    </option>

                                </select>

                            </div>


                            {{-- Remarks --}}
                            <div class="col-12">

                                <label
                                    for="cugChangeRemarks"
                                    class="form-label">

                                    Remarks

                                    <span class="required">
                                        *
                                    </span>

                                </label>

                                <textarea
                                    class="form-control"
                                    id="cugChangeRemarks"
                                    name="remarks"
                                    rows="3"
                                    maxlength="500"
                                    placeholder="Explain the reason for the CUG staff change..."
                                    required>
                                </textarea>

                                <div class="d-flex justify-content-end mt-1">

                                    <small
                                        class="text-muted"
                                        id="cugChangeRemarksCounter">

                                        0 / 500

                                    </small>

                                </div>

                            </div>

                        </div>

                    </div>


                    {{-- =================================================
                        HISTORY NOTICE
                    ================================================= --}}

                    <div class="cug-history-notice">

                        <div class="cug-history-notice-icon">

                            <i class="ti ti-history"></i>

                        </div>

                        <div>

                            <strong>
                                Assignment history will be preserved
                            </strong>

                            <p>

                                The current staff assignment will be closed,
                                and the new staff assignment will be recorded.
                                Previous CUG usage will remain available in history.

                            </p>

                        </div>

                    </div>

                </div>


                {{-- =================================================
                    FOOTER
                ================================================= --}}

                <div class="modal-footer cug-modal-footer">

                    <button
                        type="button"
                        class="btn btn-label-secondary"
                        data-bs-dismiss="modal">

                        Cancel

                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="btnChangeCugStaff">

                        <span class="cug-btn-text">

                            <i class="ti ti-user-shared me-1"></i>

                            Transfer CUG

                        </span>

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CHANGE STAFF / TRANSFER MODAL
========================================================= */

.cug-modal-icon-transfer {
    background: var(--cug-primary-soft);
    color: var(--primary);
}


/* =========================================================
   TRANSFER SECTION
========================================================= */

.cug-transfer-section {
    margin-bottom: 4px;
}

.cug-transfer-section-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
}

.cug-transfer-section-header h6 {
    margin: 0;
    color: var(--text);
    font-size: .80rem;
    font-weight: 700;
}

.cug-transfer-section-header span {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: .67rem;
}

.cug-transfer-step-number {
    width: 28px;
    height: 28px;
    min-width: 28px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: var(--cug-warning-soft);
    color: var(--warning);

    font-size: .70rem;
    font-weight: 800;
}

.cug-transfer-step-number.cug-step-success {
    background: var(--cug-success-soft);
    color: var(--success);
}


/* =========================================================
   CURRENT STAFF CARD
========================================================= */

.cug-current-staff-card {
    display: flex;
    align-items: center;
    gap: 11px;

    padding: 12px;

    border: 1px solid rgba(217, 119, 6, .18);
    border-radius: 10px;

    background: rgba(217, 119, 6, .045);
}

.cug-current-staff-avatar {
    width: 40px;
    height: 40px;
    min-width: 40px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: var(--cug-warning-soft);
    color: var(--warning);

    font-size: .74rem;
    font-weight: 700;
}

.cug-current-staff-content {
    flex: 1;
    min-width: 0;
}

.cug-current-staff-content strong {
    display: block;

    overflow: hidden;

    color: var(--text);
    font-size: .77rem;
    font-weight: 700;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.cug-current-staff-content > span {
    display: block;
    margin-top: 2px;

    color: var(--muted);
    font-size: .64rem;
}

.cug-current-staff-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 5px;

    margin-top: 4px;

    color: var(--muted);
    font-size: .62rem;
}


/* =========================================================
   TRANSFER ARROW
========================================================= */

.cug-transfer-arrow {
    display: flex;
    align-items: center;
    gap: 9px;

    margin: 10px 0;
}

.cug-transfer-line {
    flex: 1;
    height: 1px;
    background: var(--border);
}

.cug-transfer-arrow-icon {
    width: 28px;
    height: 28px;
    min-width: 28px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border: 1px solid var(--border);
    border-radius: 50%;

    background: var(--card);
    color: var(--primary);

    font-size: 14px;
}


/* =========================================================
   HISTORY NOTICE
========================================================= */

.cug-history-notice {
    display: flex;
    align-items: flex-start;
    gap: 11px;

    padding: 13px;

    border: 1px solid rgba(143, 29, 29, .12);
    border-radius: 10px;

    background: var(--cug-primary-soft-2);
}

.cug-history-notice-icon {
    width: 32px;
    height: 32px;
    min-width: 32px;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: var(--cug-primary-soft);
    color: var(--primary);

    font-size: 16px;
}

.cug-history-notice strong {
    display: block;

    color: var(--text);
    font-size: .73rem;
    font-weight: 700;
}

.cug-history-notice p {
    margin: 4px 0 0;

    color: var(--muted);
    font-size: .67rem;
    line-height: 1.5;
}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 575.98px) {

    .cug-current-staff-card {
        align-items: flex-start;
    }

    .cug-current-staff-card
    .cug-badge {
        display: none;
    }

}
</style>