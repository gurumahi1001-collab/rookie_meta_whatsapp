{{-- =========================================================
    CUG Management — Topbar
========================================================= --}}

<div class="cug-topbar mb-4">

    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">

        {{-- Left --}}
        <div class="d-flex align-items-center gap-3">

            <div class="cug-page-icon">

                <i class="ti ti-device-mobile"></i>

            </div>

            <div>

                <div class="d-flex align-items-center gap-2 mb-1">

                    <span class="text-muted small">
                        Communication
                    </span>

                    <i class="ti ti-chevron-right cug-breadcrumb-icon"></i>

                    <span class="text-muted small">
                        CUG
                    </span>

                </div>

                <h4 class="mb-0 fw-bold cug-page-title">

                    CUG Management

                </h4>

                <div class="cug-page-subtitle">

                    Manage CUG numbers, staff assignments and call history

                </div>

            </div>

        </div>

        {{-- Right --}}
        <div class="d-flex align-items-center flex-wrap gap-2">

            {{-- Refresh --}}
            <button
                type="button"
                class="btn btn-icon btn-label-secondary"
                id="btnRefreshCug"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Refresh">

                <i class="ti ti-refresh"></i>

            </button>

            {{-- Export --}}
            <button
                type="button"
                class="btn btn-label-secondary"
                id="btnExportCug">

                <i class="ti ti-file-export me-1"></i>

                Export

            </button>

            {{-- Add CUG --}}
            <button
                type="button"
                class="btn btn-primary"
                id="btnAddCug"
                data-bs-toggle="modal"
                data-bs-target="#cugNumberModal">

                <i class="ti ti-plus me-1"></i>

                Add CUG Number

            </button>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CUG TOPBAR
========================================================= */

.cug-topbar {
    position: relative;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px 22px;
    box-shadow: 0 2px 8px rgba(23, 32, 51, 0.04);
}

.cug-page-icon {
    width: 48px;
    height: 48px;
    min-width: 48px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    background: rgba(143, 29, 29, 0.10);
    color: var(--primary);
    font-size: 24px;
}

.cug-page-title {
    color: var(--text);
    font-size: 1.35rem;
    line-height: 1.35;
}

.cug-page-subtitle {
    margin-top: 3px;
    color: var(--muted);
    font-size: 0.82rem;
}

.cug-breadcrumb-icon {
    color: var(--muted);
    font-size: 13px;
}

.cug-topbar .btn {
    min-height: 40px;
    border-radius: 9px;
    font-weight: 600;
}

.cug-topbar .btn-primary {
    background: var(--primary);
    border-color: var(--primary);
}

.cug-topbar .btn-primary:hover,
.cug-topbar .btn-primary:focus {
    background: var(--primary-2);
    border-color: var(--primary-2);
}

.cug-topbar .btn-label-secondary {
    color: var(--text);
}

.cug-topbar .btn-label-secondary:hover {
    background: rgba(143, 29, 29, 0.06);
    color: var(--primary);
}

.cug-topbar .btn-icon {
    width: 40px;
    height: 40px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
</style>
