{{-- =========================================================
    CUG Management — Recent Activity
========================================================= --}}

<div class="cug-activity-card mb-4">

    {{-- Header --}}
    <div class="cug-activity-header">

        <div>

            <h5 class="mb-1 fw-semibold">

                Recent CUG Activity

            </h5>

            <span class="cug-table-subtitle">

                Latest assignments, transfers and releases

            </span>

        </div>

        <button
            type="button"
            class="btn btn-sm btn-label-secondary"
            id="btnViewAllCugHistory">

            <i class="ti ti-history me-1"></i>

            View History

        </button>

    </div>


    {{-- Activity Body --}}
    <div
        class="cug-activity-body"
        id="cugActivityTimeline">

        {{-- AJAX content --}}

        <div
            class="cug-activity-loading"
            id="cugActivityLoading">

            <div class="cug-timeline-skeleton"></div>
            <div class="cug-timeline-skeleton"></div>
            <div class="cug-timeline-skeleton"></div>

        </div>


        {{-- Empty --}}
        <div
            class="cug-activity-empty d-none"
            id="cugActivityEmpty">

            <div class="cug-activity-empty-icon">

                <i class="ti ti-history-off"></i>

            </div>

            <span>

                No recent CUG activity

            </span>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CUG ACTIVITY TIMELINE
========================================================= */

.cug-activity-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
}

.cug-activity-header {
    min-height: 74px;
    padding: 17px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    border-bottom: 1px solid var(--border);
}

.cug-activity-header h5 {
    color: var(--text);
    font-size: .95rem;
}

.cug-activity-header .btn {
    border-radius: 8px;
    font-size: .72rem;
    font-weight: 600;
}

.cug-activity-body {
    position: relative;
    padding: 20px;
}

/* =========================================================
   TIMELINE ITEM
========================================================= */

.cug-timeline {
    position: relative;
}

.cug-timeline-item {
    position: relative;
    display: flex;
    gap: 14px;
    padding-bottom: 22px;
}

.cug-timeline-item:last-child {
    padding-bottom: 0;
}

.cug-timeline-item:not(:last-child)::before {
    content: "";
    position: absolute;
    left: 16px;
    top: 34px;
    bottom: 0;
    width: 1px;
    background: var(--border);
}

.cug-timeline-icon {
    position: relative;
    z-index: 2;
    width: 33px;
    height: 33px;
    min-width: 33px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    border: 3px solid var(--card);
    background: rgba(143, 29, 29, .09);
    color: var(--primary);
    font-size: 15px;
    box-shadow: 0 0 0 1px var(--border);
}

.cug-timeline-icon.assigned {
    background: rgba(22, 163, 74, .10);
    color: var(--success);
}

.cug-timeline-icon.transferred {
    background: rgba(143, 29, 29, .10);
    color: var(--primary);
}

.cug-timeline-icon.released {
    background: rgba(217, 119, 6, .10);
    color: var(--warning);
}

.cug-timeline-icon.activated {
    background: rgba(22, 163, 74, .10);
    color: var(--success);
}

.cug-timeline-icon.deactivated {
    background: rgba(220, 38, 38, .10);
    color: var(--danger);
}

.cug-timeline-content {
    flex: 1;
    min-width: 0;
}

.cug-timeline-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 15px;
}

.cug-timeline-title {
    color: var(--text);
    font-size: .78rem;
    font-weight: 700;
}

.cug-timeline-time {
    color: var(--muted);
    font-size: .66rem;
    white-space: nowrap;
}

.cug-timeline-description {
    margin-top: 4px;
    color: var(--muted);
    font-size: .72rem;
    line-height: 1.5;
}

.cug-timeline-description strong {
    color: var(--text);
    font-weight: 600;
}

.cug-timeline-meta {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 7px;
    margin-top: 7px;
}

.cug-timeline-tag {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 7px;
    border-radius: 6px;
    background: var(--bg);
    color: var(--muted);
    font-size: .64rem;
    font-weight: 600;
}

.cug-timeline-tag.cug-number {
    color: var(--primary);
    background: rgba(143, 29, 29, .06);
}

/* =========================================================
   LOADING
========================================================= */

.cug-activity-loading {
    display: flex;
    flex-direction: column;
    gap: 18px;
}

.cug-timeline-skeleton {
    height: 48px;
    border-radius: 8px;
    background: linear-gradient(
        90deg,
        #f1f2f4 25%,
        #e8eaed 37%,
        #f1f2f4 63%
    );
    background-size: 400% 100%;
    animation: cugSkeleton 1.4s ease infinite;
}

@keyframes cugSkeleton {

    0% {
        background-position: 100% 0;
    }

    100% {
        background-position: 0 0;
    }

}

/* =========================================================
   EMPTY
========================================================= */

.cug-activity-empty {
    min-height: 160px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 9px;
    color: var(--muted);
    font-size: .76rem;
}

.cug-activity-empty-icon {
    width: 46px;
    height: 46px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    background: rgba(143, 29, 29, .07);
    color: var(--primary);
    font-size: 20px;
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 575.98px) {

    .cug-activity-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .cug-activity-header .btn {
        width: 100%;
    }

    .cug-activity-body {
        padding: 16px;
    }

    .cug-timeline-top {
        flex-direction: column;
        gap: 3px;
    }

}
</style>