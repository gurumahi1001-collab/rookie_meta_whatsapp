{{-- =========================================================
    CUG Management — DataTable
========================================================= --}}

<div class="cug-table-card mb-4">

    {{-- =====================================================
        Table Header
    ====================================================== --}}

    <div class="cug-table-header">

        <div>

            <h5 class="mb-1 fw-semibold">

                CUG Number Register

            </h5>

            <span class="cug-table-subtitle">

                Manage numbers, current assignments and CUG activity

            </span>

        </div>

        <div class="d-flex align-items-center gap-2">

            {{-- Selected Count --}}

            <span
                class="cug-selected-count d-none"
                id="cugSelectedCount">

                <span id="cugSelectedNumber">0</span>
                selected

            </span>

            {{-- Bulk Actions --}}

            <div
                class="dropdown d-none"
                id="cugBulkActions">

                <button
                    type="button"
                    class="btn btn-label-secondary dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false">

                    <i class="ti ti-list-check me-1"></i>

                    Bulk Actions

                </button>

                <ul class="dropdown-menu dropdown-menu-end">

                    <li>

                        <button
                            type="button"
                            class="dropdown-item"
                            id="btnBulkExportCug">

                            <i class="ti ti-file-export me-2"></i>

                            Export Selected

                        </button>

                    </li>

                    <li>

                        <hr class="dropdown-divider">

                    </li>

                    <li>

                        <button
                            type="button"
                            class="dropdown-item text-danger"
                            id="btnBulkDeactivateCug">

                            <i class="ti ti-device-mobile-off me-2"></i>

                            Deactivate Selected

                        </button>

                    </li>

                </ul>

            </div>

        </div>

    </div>


    {{-- =====================================================
        Table
    ====================================================== --}}

    <div class="table-responsive">

        <table
            class="table cug-data-table"
            id="cugDataTable">

            <thead>

                <tr>

                    <th class="cug-checkbox-column">

                        <input
                            type="checkbox"
                            class="form-check-input"
                            id="cugSelectAll"
                            aria-label="Select all CUG numbers">

                    </th>

                    <th>
                        CUG Number
                    </th>

                    <th>
                        Provider
                    </th>

                    <th>
                        Company
                    </th>

                    <th>
                        Entity
                    </th>

                    <th>
                        Current Staff
                    </th>

                    <th>
                        Assignment
                    </th>

                    <th>
                        Calls
                    </th>

                    <th>
                        Status
                    </th>

                    <th class="cug-action-column">
                        Actions
                    </th>

                </tr>

            </thead>

            <tbody>

                {{-- AJAX DataTable --}}

            </tbody>

        </table>

    </div>


    {{-- =====================================================
        Empty State
    ====================================================== --}}

    <div
        class="cug-table-empty d-none"
        id="cugTableEmpty">

        <div class="cug-empty-icon">

            <i class="ti ti-device-mobile-off"></i>

        </div>

        <h6 class="mb-1">

            No CUG numbers found

        </h6>

        <p class="mb-3">

            Try changing your filters or add a new CUG number.

        </p>

        <button
            type="button"
            class="btn btn-primary btn-sm"
            id="btnEmptyAddCug"
            data-bs-toggle="modal"
            data-bs-target="#cugNumberModal">

            <i class="ti ti-plus me-1"></i>

            Add CUG Number

        </button>

    </div>

</div>
<style>
    /* =========================================================
   CUG DATA TABLE
========================================================= */

.cug-table-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
}

.cug-table-header {
    min-height: 76px;
    padding: 18px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    border-bottom: 1px solid var(--border);
}

.cug-table-header h5 {
    color: var(--text);
    font-size: .95rem;
}

.cug-table-subtitle {
    color: var(--muted);
    font-size: .72rem;
}

.cug-selected-count {
    padding: 6px 10px;
    border-radius: 7px;
    background: rgba(143, 29, 29, .08);
    color: var(--primary);
    font-size: .75rem;
    font-weight: 600;
}

.cug-data-table {
    margin: 0 !important;
    width: 100% !important;
}

.cug-data-table thead th {
    padding: 13px 15px;
    background: #fafbfc;
    border-bottom: 1px solid var(--border);
    color: var(--muted);
    font-size: .69rem;
    font-weight: 700;
    letter-spacing: .02em;
    text-transform: uppercase;
    white-space: nowrap;
}

.cug-data-table tbody td {
    padding: 14px 15px;
    vertical-align: middle;
    border-bottom: 1px solid #f0f1f3;
    color: var(--text);
    font-size: .8rem;
}

.cug-data-table tbody tr {
    transition: background-color .15s ease;
}

.cug-data-table tbody tr:hover {
    background: rgba(143, 29, 29, .025);
}

.cug-data-table tbody tr:last-child td {
    border-bottom: 0;
}

.cug-checkbox-column {
    width: 42px !important;
    padding-left: 18px !important;
}

.cug-action-column {
    width: 70px !important;
    text-align: center;
}

.cug-data-table .form-check-input {
    width: 16px;
    height: 16px;
    margin: 0;
    cursor: pointer;
    border-color: #cbd0d7;
}

.cug-data-table .form-check-input:checked {
    background-color: var(--primary);
    border-color: var(--primary);
}

/* =========================================================
   CUG NUMBER CELL
========================================================= */

.cug-number-cell {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 170px;
}

.cug-number-icon {
    width: 34px;
    height: 34px;
    min-width: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: rgba(143, 29, 29, .08);
    color: var(--primary);
    font-size: 16px;
}

.cug-number-value {
    display: block;
    color: var(--text);
    font-weight: 700;
    letter-spacing: .25px;
}

.cug-number-id {
    display: block;
    margin-top: 2px;
    color: var(--muted);
    font-size: .66rem;
}

/* =========================================================
   STAFF CELL
========================================================= */

.cug-staff-cell {
    display: flex;
    align-items: center;
    gap: 9px;
    min-width: 170px;
}

.cug-staff-avatar {
    width: 34px;
    height: 34px;
    min-width: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(143, 29, 29, .09);
    color: var(--primary);
    font-size: .72rem;
    font-weight: 700;
}

.cug-staff-name {
    display: block;
    color: var(--text);
    font-weight: 600;
}

.cug-staff-id {
    display: block;
    margin-top: 2px;
    color: var(--muted);
    font-size: .66rem;
}

/* =========================================================
   STATUS
========================================================= */

.cug-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 9px;
    border-radius: 7px;
    font-size: .68rem;
    font-weight: 700;
    white-space: nowrap;
}

.cug-status-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
}

.cug-status-available {
    background: rgba(22, 163, 74, .09);
    color: var(--success);
}

.cug-status-available .cug-status-dot {
    background: var(--success);
}

.cug-status-assigned {
    background: rgba(143, 29, 29, .09);
    color: var(--primary);
}

.cug-status-assigned .cug-status-dot {
    background: var(--primary);
}

.cug-status-reserved {
    background: rgba(217, 119, 6, .10);
    color: var(--warning);
}

.cug-status-reserved .cug-status-dot {
    background: var(--warning);
}

.cug-status-inactive {
    background: rgba(220, 38, 38, .09);
    color: var(--danger);
}

.cug-status-inactive .cug-status-dot {
    background: var(--danger);
}

/* =========================================================
   ASSIGNMENT
========================================================= */

.cug-assignment-date {
    color: var(--text);
    font-size: .75rem;
    font-weight: 600;
}

.cug-assignment-duration {
    display: block;
    margin-top: 2px;
    color: var(--muted);
    font-size: .65rem;
}

.cug-unassigned {
    color: var(--muted);
    font-size: .74rem;
    font-style: italic;
}

/* =========================================================
   CALL COUNT
========================================================= */

.cug-call-count {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: var(--primary);
    font-weight: 700;
    cursor: pointer;
}

.cug-call-count:hover {
    color: var(--primary-2);
    text-decoration: underline;
}

/* =========================================================
   ACTION BUTTON
========================================================= */

.cug-row-action {
    width: 34px;
    height: 34px;
    padding: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: var(--muted);
}

.cug-row-action:hover {
    background: rgba(143, 29, 29, .08);
    color: var(--primary);
}

.cug-data-table .dropdown-menu {
    min-width: 190px;
    padding: 7px;
    border: 1px solid var(--border);
    border-radius: 10px;
    box-shadow: 0 8px 25px rgba(23, 32, 51, .12);
}

.cug-data-table .dropdown-item {
    border-radius: 7px;
    padding: 8px 10px;
    font-size: .78rem;
}

.cug-data-table .dropdown-item:hover {
    background: rgba(143, 29, 29, .06);
    color: var(--primary);
}

.cug-data-table .dropdown-item.text-danger:hover {
    background: rgba(220, 38, 38, .07);
    color: var(--danger);
}

/* =========================================================
   EMPTY STATE
========================================================= */

.cug-table-empty {
    padding: 55px 20px;
    text-align: center;
}

.cug-empty-icon {
    width: 58px;
    height: 58px;
    margin: 0 auto 15px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 14px;
    background: rgba(143, 29, 29, .07);
    color: var(--primary);
    font-size: 26px;
}

.cug-table-empty h6 {
    color: var(--text);
}

.cug-table-empty p {
    color: var(--muted);
    font-size: .78rem;
}

/* =========================================================
   DATATABLE CONTROLS
========================================================= */

.cug-table-card .dataTables_wrapper {
    padding-bottom: 0;
}

.cug-table-card .dataTables_info {
    padding: 16px 20px;
    color: var(--muted);
    font-size: .72rem;
}

.cug-table-card .dataTables_paginate {
    padding: 10px 20px 16px;
}

.cug-table-card .pagination {
    margin-bottom: 0;
}

.cug-table-card .page-link {
    min-width: 32px;
    height: 32px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 7px;
    font-size: .72rem;
}

.cug-table-card .page-item.active .page-link {
    background: var(--primary);
    border-color: var(--primary);
}

/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 767.98px) {

    .cug-table-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .cug-table-header > .d-flex {
        width: 100%;
    }

    .cug-table-header .dropdown,
    .cug-table-header .btn {
        width: 100%;
    }

    .cug-data-table thead th,
    .cug-data-table tbody td {
        padding-left: 11px;
        padding-right: 11px;
    }

}
</style>