{{-- =========================================================
    CUG Management — Toolbar
========================================================= --}}

<div class="cug-toolbar mb-4" id="cugToolbar">

    {{-- Main Filter Row --}}
    <div class="cug-toolbar-main">

        {{-- Search --}}
        <div class="cug-search-wrapper">

            <i class="ti ti-search cug-search-icon"></i>

            <input
                type="search"
                class="form-control cug-search-input"
                id="cugSearch"
                placeholder="Search CUG number, staff, employee ID..."
                autocomplete="off">

            <button
                type="button"
                class="cug-search-clear d-none"
                id="btnClearCugSearch"
                aria-label="Clear search">

                <i class="ti ti-x"></i>

            </button>

        </div>

        {{-- Company --}}
        <div class="cug-filter-field">

            <label class="cug-filter-label">
                Company
            </label>

            <select
                class="form-select cug-filter-select"
                id="filterCugCompany"
                name="company_id">

                <option value="">
                    All Companies
                </option>

            </select>

        </div>

        {{-- Entity --}}
        <div class="cug-filter-field">

            <label class="cug-filter-label">
                Entity
            </label>

            <select
                class="form-select cug-filter-select"
                id="filterCugEntity"
                name="entity_id"
                disabled>

                <option value="">
                    All Entities
                </option>

            </select>

        </div>

        {{-- Status --}}
        <div class="cug-filter-field">

            <label class="cug-filter-label">
                Status
            </label>

            <select
                class="form-select cug-filter-select"
                id="filterCugStatus"
                name="status">

                <option value="">
                    All Status
                </option>

                <option value="0">
                    Available
                </option>

                <option value="1">
                    Assigned
                </option>

                <option value="2">
                    Reserved
                </option>

                <option value="3">
                    Inactive
                </option>

            </select>

        </div>

        {{-- More Filters --}}
        <button
            type="button"
            class="btn btn-label-secondary cug-filter-toggle"
            id="btnCugAdvancedFilter"
            data-bs-toggle="collapse"
            data-bs-target="#cugAdvancedFilters"
            aria-expanded="false"
            aria-controls="cugAdvancedFilters">

            <i class="ti ti-adjustments-horizontal me-1"></i>

            Filters

            <span
                class="badge bg-primary ms-1 d-none"
                id="cugFilterCount">

                0

            </span>

        </button>

        {{-- Reset --}}
        <button
            type="button"
            class="btn btn-label-secondary"
            id="btnResetCugFilter">

            <i class="ti ti-refresh me-1"></i>

            Reset

        </button>

    </div>


    {{-- Advanced Filters --}}
    <div
        class="collapse"
        id="cugAdvancedFilters">

        <div class="cug-advanced-filter-panel mt-3">

            <div class="row g-3">

                {{-- Branch --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Branch

                    </label>

                    <select
                        class="form-select cug-filter-select"
                        id="filterCugBranch"
                        name="branch_id"
                        disabled>

                        <option value="">
                            All Branches
                        </option>

                    </select>

                </div>


                {{-- Provider --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Provider

                    </label>

                    <select
                        class="form-select cug-filter-select"
                        id="filterCugProvider"
                        name="provider">

                        <option value="">
                            All Providers
                        </option>

                        <option value="Airtel">
                            Airtel
                        </option>

                        <option value="Jio">
                            Jio
                        </option>

                        <option value="Vi">
                            Vi
                        </option>

                        <option value="BSNL">
                            BSNL
                        </option>

                    </select>

                </div>


                {{-- Assignment --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Assignment

                    </label>

                    <select
                        class="form-select cug-filter-select"
                        id="filterCugAssignment"
                        name="assignment_status">

                        <option value="">
                            All Assignments
                        </option>

                        <option value="assigned">
                            Assigned to Staff
                        </option>

                        <option value="available">
                            Unassigned
                        </option>

                    </select>

                </div>


                {{-- Staff --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Staff

                    </label>

                    <select
                        class="form-select cug-filter-select"
                        id="filterCugStaff"
                        name="staff_id">

                        <option value="">
                            All Staff
                        </option>

                    </select>

                </div>


                {{-- CUG Number From --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        CUG Number From

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="filterCugNumberFrom"
                        name="number_from"
                        inputmode="numeric"
                        maxlength="20"
                        placeholder="Starting number">

                </div>


                {{-- CUG Number To --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        CUG Number To

                    </label>

                    <input
                        type="text"
                        class="form-control"
                        id="filterCugNumberTo"
                        name="number_to"
                        inputmode="numeric"
                        maxlength="20"
                        placeholder="Ending number">

                </div>


                {{-- Assignment Date From --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Assigned From

                    </label>

                    <input
                        type="text"
                        class="form-control cug-date-filter"
                        id="filterCugAssignedFrom"
                        name="assigned_from"
                        placeholder="Select date">

                </div>


                {{-- Assignment Date To --}}
                <div class="col-xl-3 col-lg-4 col-md-6">

                    <label class="cug-filter-label">

                        Assigned To

                    </label>

                    <input
                        type="text"
                        class="form-control cug-date-filter"
                        id="filterCugAssignedTo"
                        name="assigned_to"
                        placeholder="Select date">

                </div>

            </div>

            {{-- Active Filter Summary --}}
            <div
                class="cug-filter-summary d-none"
                id="cugFilterSummary">

                <div class="d-flex align-items-center flex-wrap gap-2">

                    <span class="cug-filter-summary-title">

                        <i class="ti ti-filter me-1"></i>

                        Active Filters:

                    </span>

                    <div
                        class="d-flex align-items-center flex-wrap gap-2"
                        id="cugActiveFilterTags">
                    </div>

                    <button
                        type="button"
                        class="btn btn-sm btn-link text-danger p-0 ms-1"
                        id="btnClearAdvancedCugFilters">

                        Clear all

                    </button>

                </div>

            </div>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CUG TOOLBAR
========================================================= */

.cug-toolbar {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: 0 2px 8px rgba(23, 32, 51, 0.04);
}

.cug-toolbar-main {
    display: grid;
    grid-template-columns:
        minmax(260px, 1.8fr)
        minmax(170px, 1fr)
        minmax(170px, 1fr)
        minmax(150px, .85fr)
        auto
        auto;
    gap: 12px;
    align-items: end;
}

.cug-search-wrapper {
    position: relative;
}

.cug-search-icon {
    position: absolute;
    left: 13px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--muted);
    z-index: 2;
    pointer-events: none;
}

.cug-search-input {
    padding-left: 39px;
    padding-right: 38px;
    min-height: 42px;
}

.cug-search-clear {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    width: 26px;
    height: 26px;
    border: 0;
    background: transparent;
    color: var(--muted);
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.cug-search-clear:hover {
    background: rgba(143, 29, 29, .08);
    color: var(--primary);
}

.cug-filter-field {
    min-width: 0;
}

.cug-filter-label {
    display: block;
    margin-bottom: 6px;
    color: var(--text);
    font-size: .76rem;
    font-weight: 600;
}

.cug-filter-select,
.cug-filter-field .form-control {
    min-height: 42px;
    border-color: var(--border);
    border-radius: 8px;
}

.cug-filter-select:focus,
.cug-filter-field .form-control:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 .15rem rgba(143, 29, 29, .10);
}

.cug-filter-toggle,
.cug-toolbar-main > .btn {
    min-height: 42px;
    white-space: nowrap;
    border-radius: 8px;
    font-weight: 600;
}

.cug-advanced-filter-panel {
    padding: 18px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: var(--bg);
}

.cug-filter-summary {
    margin-top: 16px;
    padding-top: 14px;
    border-top: 1px solid var(--border);
}

.cug-filter-summary-title {
    color: var(--muted);
    font-size: .78rem;
    font-weight: 600;
}

.cug-filter-tag {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 5px 9px;
    border-radius: 7px;
    background: rgba(143, 29, 29, .08);
    color: var(--primary);
    font-size: .74rem;
    font-weight: 600;
}

.cug-filter-tag button {
    padding: 0;
    border: 0;
    background: transparent;
    color: inherit;
    line-height: 1;
}

.cug-toolbar .select2-container {
    width: 100% !important;
}

.cug-toolbar .select2-container--default
.select2-selection--single {
    min-height: 42px;
    height: 42px;
    border-color: var(--border);
    border-radius: 8px;
    display: flex;
    align-items: center;
}

.cug-toolbar .select2-container--default
.select2-selection--single
.select2-selection__rendered {
    line-height: 40px;
    color: var(--text);
    font-size: .875rem;
}

.cug-toolbar .select2-container--default
.select2-selection--single
.select2-selection__arrow {
    height: 40px;
}
</style>