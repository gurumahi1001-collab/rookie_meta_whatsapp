{{-- =========================================================
    CUG Management — Dashboard Cards
========================================================= --}}

<div class="row g-4 mb-4" id="cugDashboardCards">

    {{-- =====================================================
        Total CUG
    ====================================================== --}}

    <div class="col-xl-3 col-sm-6">

        <div
            class="cug-stat-card cug-stat-primary"
            id="cugCardTotal"
            data-card-filter="all">

            <div class="cug-stat-card-top">

                <div class="cug-stat-icon">

                    <i class="ti ti-device-mobile"></i>

                </div>

                <span class="cug-stat-label">
                    Total CUG
                </span>

            </div>

            <div class="cug-stat-card-body">

                <div class="d-flex align-items-end justify-content-between">

                    <div>

                        <h3
                            class="cug-stat-value"
                            id="cugTotalCount">

                            0

                        </h3>

                        <span class="cug-stat-description">

                            Registered CUG numbers

                        </span>

                    </div>

                    <div class="cug-stat-mini-icon">

                        <i class="ti ti-device-sim"></i>

                    </div>

                </div>

            </div>

            <div class="cug-stat-card-footer">

                <span>

                    <i class="ti ti-database me-1"></i>

                    CUG inventory

                </span>

                <i class="ti ti-arrow-up-right"></i>

            </div>

        </div>

    </div>


    {{-- =====================================================
        Assigned
    ====================================================== --}}

    <div class="col-xl-3 col-sm-6">

        <div
            class="cug-stat-card cug-stat-success"
            id="cugCardAssigned"
            data-card-filter="assigned">

            <div class="cug-stat-card-top">

                <div class="cug-stat-icon">

                    <i class="ti ti-user-check"></i>

                </div>

                <span class="cug-stat-status">

                    Active

                </span>

            </div>

            <div class="cug-stat-card-body">

                <div class="d-flex align-items-end justify-content-between">

                    <div>

                        <h3
                            class="cug-stat-value"
                            id="cugAssignedCount">

                            0

                        </h3>

                        <span class="cug-stat-description">

                            Assigned to staff

                        </span>

                    </div>

                    <div class="cug-stat-mini-icon">

                        <i class="ti ti-user"></i>

                    </div>

                </div>

            </div>

            <div class="cug-stat-card-footer">

                <span>

                    <i class="ti ti-users me-1"></i>

                    Current assignments

                </span>

                <i class="ti ti-arrow-up-right"></i>

            </div>

        </div>

    </div>


    {{-- =====================================================
        Available
    ====================================================== --}}

    <div class="col-xl-3 col-sm-6">

        <div
            class="cug-stat-card cug-stat-warning"
            id="cugCardAvailable"
            data-card-filter="available">

            <div class="cug-stat-card-top">

                <div class="cug-stat-icon">

                    <i class="ti ti-device-mobile-plus"></i>

                </div>

                <span class="cug-stat-status">

                    Ready

                </span>

            </div>

            <div class="cug-stat-card-body">

                <div class="d-flex align-items-end justify-content-between">

                    <div>

                        <h3
                            class="cug-stat-value"
                            id="cugAvailableCount">

                            0

                        </h3>

                        <span class="cug-stat-description">

                            Available for assignment

                        </span>

                    </div>

                    <div class="cug-stat-mini-icon">

                        <i class="ti ti-user-plus"></i>

                    </div>

                </div>

            </div>

            <div class="cug-stat-card-footer">

                <span>

                    <i class="ti ti-check me-1"></i>

                    Available pool

                </span>

                <i class="ti ti-arrow-up-right"></i>

            </div>

        </div>

    </div>


    {{-- =====================================================
        Inactive / Reserved
    ====================================================== --}}

    <div class="col-xl-3 col-sm-6">

        <div
            class="cug-stat-card cug-stat-danger"
            id="cugCardInactive"
            data-card-filter="inactive">

            <div class="cug-stat-card-top">

                <div class="cug-stat-icon">

                    <i class="ti ti-device-mobile-off"></i>

                </div>

                <span class="cug-stat-status">

                    Attention

                </span>

            </div>

            <div class="cug-stat-card-body">

                <div class="d-flex align-items-end justify-content-between">

                    <div>

                        <h3
                            class="cug-stat-value"
                            id="cugInactiveCount">

                            0

                        </h3>

                        <span class="cug-stat-description">

                            Reserved / inactive

                        </span>

                    </div>

                    <div class="cug-stat-mini-icon">

                        <i class="ti ti-alert-circle"></i>

                    </div>

                </div>

            </div>

            <div class="cug-stat-card-footer">

                <span>

                    <i class="ti ti-info-circle me-1"></i>

                    Requires attention

                </span>

                <i class="ti ti-arrow-up-right"></i>

            </div>

        </div>

    </div>

</div>


{{-- =========================================================
    Operational Summary
========================================================= --}}

<div class="row g-4 mb-4">

    {{-- Assignment Utilization --}}

    <div class="col-xl-4 col-lg-6">

        <div class="cug-summary-card">

            <div class="cug-summary-header">

                <div>

                    <span class="cug-summary-title">

                        Assignment Utilization

                    </span>

                    <small class="cug-summary-subtitle">

                        Current CUG allocation

                    </small>

                </div>

                <div class="cug-summary-icon bg-primary-subtle">

                    <i class="ti ti-chart-donut"></i>

                </div>

            </div>

            <div class="cug-utilization-body">

                <div class="cug-utilization-value">

                    <span id="cugUtilization">

                        0%

                    </span>

                    <small>

                        utilized

                    </small>

                </div>

                <div class="progress cug-progress">

                    <div
                        class="progress-bar"
                        id="cugUtilizationBar"
                        role="progressbar"
                        style="width:0%"
                        aria-valuenow="0"
                        aria-valuemin="0"
                        aria-valuemax="100">
                    </div>

                </div>

                <div class="d-flex justify-content-between mt-2">

                    <small class="text-muted">

                        Assigned

                        <strong id="cugUtilizationAssigned">
                            0
                        </strong>

                    </small>

                    <small class="text-muted">

                        Total

                        <strong id="cugUtilizationTotal">
                            0
                        </strong>

                    </small>

                </div>

            </div>

        </div>

    </div>


    {{-- Today's Calls --}}

    <div class="col-xl-4 col-lg-6">

        <div class="cug-summary-card">

            <div class="cug-summary-header">

                <div>

                    <span class="cug-summary-title">

                        Today's CUG Calls

                    </span>

                    <small class="cug-summary-subtitle">

                        Current day activity

                    </small>

                </div>

                <div class="cug-summary-icon bg-success-subtle">

                    <i class="ti ti-phone-call"></i>

                </div>

            </div>

            <div class="cug-call-summary">

                <div class="cug-call-total">

                    <span id="cugTodayCalls">

                        0

                    </span>

                    <small>

                        total calls

                    </small>

                </div>

                <div class="cug-call-breakdown">

                    <div>

                        <span class="cug-call-dot received"></span>

                        <span>

                            Received

                        </span>

                        <strong id="cugReceivedCalls">

                            0

                        </strong>

                    </div>

                    <div>

                        <span class="cug-call-dot dialled"></span>

                        <span>

                            Dialled

                        </span>

                        <strong id="cugDialledCalls">

                            0

                        </strong>

                    </div>

                    <div>

                        <span class="cug-call-dot missed"></span>

                        <span>

                            Missed

                        </span>

                        <strong id="cugMissedCalls">

                            0

                        </strong>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- Available Pool --}}

    <div class="col-xl-4 col-lg-12">

        <div class="cug-summary-card cug-summary-pool">

            <div class="cug-summary-header">

                <div>

                    <span class="cug-summary-title">

                        Number Pool

                    </span>

                    <small class="cug-summary-subtitle">

                        Availability overview

                    </small>

                </div>

                <div class="cug-summary-icon bg-warning-subtle">

                    <i class="ti ti-stack-2"></i>

                </div>

            </div>

            <div class="cug-pool-stats">

                <div class="cug-pool-stat">

                    <span class="cug-pool-dot available"></span>

                    <div>

                        <small>

                            Available

                        </small>

                        <strong id="cugPoolAvailable">

                            0

                        </strong>

                    </div>

                </div>

                <div class="cug-pool-stat">

                    <span class="cug-pool-dot assigned"></span>

                    <div>

                        <small>

                            Assigned

                        </small>

                        <strong id="cugPoolAssigned">

                            0

                        </strong>

                    </div>

                </div>

                <div class="cug-pool-stat">

                    <span class="cug-pool-dot reserved"></span>

                    <div>

                        <small>

                            Reserved

                        </small>

                        <strong id="cugPoolReserved">

                            0

                        </strong>

                    </div>

                </div>

                <div class="cug-pool-stat">

                    <span class="cug-pool-dot inactive"></span>

                    <div>

                        <small>

                            Inactive

                        </small>

                        <strong id="cugPoolInactive">

                            0

                        </strong>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<style>
    /* =========================================================
   CUG STAT CARDS
========================================================= */

.cug-stat-card {
    position: relative;
    min-height: 188px;
    overflow: hidden;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 18px;
    cursor: pointer;
    transition:
        transform .2s ease,
        box-shadow .2s ease,
        border-color .2s ease;
}

.cug-stat-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: var(--stat-color);
}

.cug-stat-card:hover {
    transform: translateY(-3px);
    border-color: var(--stat-color);
    box-shadow: 0 10px 25px rgba(23, 32, 51, .08);
}

.cug-stat-card.cug-stat-active {
    border-color: var(--stat-color);
    box-shadow: 0 0 0 2px color-mix(
        in srgb,
        var(--stat-color) 15%,
        transparent
    );
}

.cug-stat-primary {
    --stat-color: var(--primary);
}

.cug-stat-success {
    --stat-color: var(--success);
}

.cug-stat-warning {
    --stat-color: var(--warning);
}

.cug-stat-danger {
    --stat-color: var(--danger);
}

.cug-stat-card-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.cug-stat-icon {
    width: 42px;
    height: 42px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 11px;
    background: color-mix(
        in srgb,
        var(--stat-color) 10%,
        transparent
    );
    color: var(--stat-color);
    font-size: 21px;
}

.cug-stat-label,
.cug-stat-status {
    color: var(--muted);
    font-size: .75rem;
    font-weight: 600;
}

.cug-stat-status {
    padding: 5px 8px;
    border-radius: 6px;
    background: color-mix(
        in srgb,
        var(--stat-color) 8%,
        transparent
    );
    color: var(--stat-color);
}

.cug-stat-card-body {
    padding: 20px 0 15px;
}

.cug-stat-value {
    margin: 0;
    color: var(--text);
    font-size: 1.8rem;
    font-weight: 700;
    line-height: 1.1;
}

.cug-stat-description {
    display: block;
    margin-top: 7px;
    color: var(--muted);
    font-size: .75rem;
}

.cug-stat-mini-icon {
    color: color-mix(
        in srgb,
        var(--stat-color) 18%,
        transparent
    );
    font-size: 38px;
}

.cug-stat-card-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 11px;
    border-top: 1px solid var(--border);
    color: var(--muted);
    font-size: .72rem;
}

.cug-stat-card-footer i:last-child {
    color: var(--stat-color);
}


/* =========================================================
   SUMMARY CARDS
========================================================= */

.cug-summary-card {
    height: 100%;
    min-height: 176px;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
}

.cug-summary-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 15px;
}

.cug-summary-title {
    display: block;
    color: var(--text);
    font-size: .9rem;
    font-weight: 700;
}

.cug-summary-subtitle {
    display: block;
    margin-top: 4px;
    color: var(--muted);
    font-size: .72rem;
}

.cug-summary-icon {
    width: 38px;
    height: 38px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 9px;
    font-size: 19px;
}

.cug-utilization-body {
    margin-top: 23px;
}

.cug-utilization-value {
    display: flex;
    align-items: baseline;
    gap: 7px;
}

.cug-utilization-value span {
    color: var(--text);
    font-size: 1.65rem;
    font-weight: 700;
}

.cug-utilization-value small {
    color: var(--muted);
    font-size: .72rem;
}

.cug-progress {
    height: 7px;
    margin-top: 10px;
    overflow: hidden;
    background: #eef0f3;
    border-radius: 20px;
}

.cug-progress .progress-bar {
    background: var(--primary);
    border-radius: inherit;
    transition: width .6s ease;
}


/* =========================================================
   CALL SUMMARY
========================================================= */

.cug-call-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    margin-top: 22px;
}

.cug-call-total span {
    display: block;
    color: var(--text);
    font-size: 1.7rem;
    font-weight: 700;
}

.cug-call-total small {
    color: var(--muted);
    font-size: .72rem;
}

.cug-call-breakdown {
    min-width: 145px;
}

.cug-call-breakdown > div {
    display: grid;
    grid-template-columns: 8px 1fr auto;
    gap: 7px;
    align-items: center;
    margin-bottom: 7px;
    color: var(--muted);
    font-size: .7rem;
}

.cug-call-breakdown strong {
    color: var(--text);
}

.cug-call-dot,
.cug-pool-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    display: inline-block;
}

.cug-call-dot.received {
    background: var(--success);
}

.cug-call-dot.dialled {
    background: var(--primary);
}

.cug-call-dot.missed {
    background: var(--danger);
}


/* =========================================================
   NUMBER POOL
========================================================= */

.cug-pool-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px 22px;
    margin-top: 20px;
}

.cug-pool-stat {
    display: flex;
    align-items: center;
    gap: 9px;
}

.cug-pool-stat small {
    display: block;
    color: var(--muted);
    font-size: .68rem;
}

.cug-pool-stat strong {
    display: block;
    margin-top: 1px;
    color: var(--text);
    font-size: .9rem;
}

.cug-pool-dot.available {
    background: var(--success);
}

.cug-pool-dot.assigned {
    background: var(--primary);
}

.cug-pool-dot.reserved {
    background: var(--warning);
}

.cug-pool-dot.inactive {
    background: var(--danger);
}

@media (max-width: 767.98px) {

    .cug-stat-card {
        min-height: 170px;
    }

    .cug-stat-value {
        font-size: 1.55rem;
    }

    .cug-summary-card {
        min-height: auto;
    }

    .cug-call-summary {
        align-items: flex-start;
    }

}

@media (max-width: 575.98px) {

    .cug-call-summary {
        flex-direction: column;
        align-items: stretch;
    }

    .cug-call-breakdown {
        width: 100%;
    }

}
</style>