@extends('layouts/layoutMaster')

@section('title', 'Salary Balance Sheet')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'],)
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js'])
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<style>
    .mdi-loading {
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        100% {
            transform: rotate(360deg);
        }
    }

    .salary-table,
    .salary-child-table{
        width:100%;
        table-layout:fixed;
    }

    .salary-table td,
    .salary-table th,
    .salary-child-table td{
        vertical-align:middle;
    }

    .salary-child-table td{
        padding-top:14px;
        padding-bottom:14px;
    }

    .salary-child-table{
        margin-bottom:0;
    }

    .salary-child-table tr:last-child td{
        border-bottom:0;
    }

    .circular-progress {
    --value: 0;
    --size: 58px;
    --thickness: 6px;
    --progress-color: #0d6efd;
    --track-color: #e9ecef;

    width: var(--size);
    height: var(--size);
    border-radius: 50%;
    background:
        conic-gradient(
            var(--progress-color) calc(var(--value) * 1%),
            var(--track-color) 0
        );
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    margin: auto;
    transition: .4s ease;
}

.circular-progress::before {
    content: "";
    position: absolute;
    width: calc(var(--size) - var(--thickness) * 2);
    height: calc(var(--size) - var(--thickness) * 2);
    background: #fff;
    border-radius: 50%;
}

.circular-progress span {
    position: relative;
    z-index: 2;
    font-size: 12px;
    font-weight: 700;
    color: #495057;
}

.circular-progress:hover {
    transform: scale(1.08);
}
</style>
<!-- <style>
    .circular-progress {
    --value:0;
    --size:60px;
    --thickness:7px;

    width:var(--size);
    height:var(--size);
    border-radius:50%;
    position:relative;

    display:flex;
    align-items:center;
    justify-content:center;

    background:
        conic-gradient(
            from -90deg,
            var(--progress-color) calc(var(--value)*1%),
            #edf2f7 0
        );

    box-shadow:
        0 6px 18px rgba(0,0,0,.08),
        inset 0 1px 3px rgba(255,255,255,.8);

    transition:.35s ease;
}

.circular-progress::before{
    content:'';
    position:absolute;
    inset:7px;
    background:#fff;
    border-radius:50%;
    box-shadow:inset 0 2px 6px rgba(0,0,0,.08);
}

.circular-progress span{
    position:relative;
    z-index:2;
    font-weight:700;
    font-size:12px;
    color:#495057;
}

.circular-progress:hover{
    transform:translateY(-2px) scale(1.08);
    box-shadow:
        0 12px 24px rgba(0,0,0,.15);
}
</style> -->

<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
            <h5 class="card-title mb-1">Salary Balance Sheet</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element mb-1 gap-2 text-center">
            <div class="d-flex justify-content-end align-items-center flex-wrap gap-2 mb-1">
                <div class="d-flex flex-row align-items-center justify-content-between gap-2">
                    <input type="text" id="dash_month_picker" class="form-control w-100px" value="<?php echo date('M-Y') ?>" onchange="loadThemes(1)">
                </div> 
            </div>
        </div>
    </div>
    <div class="card-body pt-2">
        <div class="my-2 d-flex justify-content-center" id="summaryCards">
            <span class="text-center fs-4 fw-bold badge bg-label-success border border-success rounded">Salary Balance Sheet - <span id="month_filter_label"><?php echo date('M-Y') ?></span></span>
        </div>
        <div class="row ">
            <div class="col-lg-12 mt-2">
                <div class="table-responsive">
                    <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                        <colgroup>
                            <col style="width:32%">
                            <col style="width:8%">
                            <col style="width:10%">
                            <col style="width:12%">
                            <col style="width:12%">
                            <col style="width:10%">
                            <col style="width:10%">
                            <col style="width:6%">
                        </colgroup>
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                                <th>Company</th>
                                <th class="text-center">Employees</th>
                                <th class="text-end">Avg Salary</th>
                                <th class="text-end">Actual Value</th>
                                <th class="text-end">Shared Value</th>
                                <th class="text-end">Contribution %</th>
                                <th class="text-end">Sales Value</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot id="salaryFooter">

                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let currentPage = 1;
    let currentMonth = @json(date('M-Y'));
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);
    
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
    function buildMonthRow(item,month_int,year_int)
    {

        let fixed_gross=new Intl.NumberFormat('en-IN').format(item.fixed_gross_salary);
        let gross=new Intl.NumberFormat('en-IN').format(item.gross_salary);
        let deduction=new Intl.NumberFormat('en-IN').format(item.deduction);
        let net=new Intl.NumberFormat('en-IN').format(item.net_salary);

        let status='';
        let action='';

        let contributionColor = '#0d6efd';

        if (item.company_contribution_percentage >= 60) {
            contributionColor = '#198754';      // Green
        } else if (item.company_contribution_percentage >= 30) {
            contributionColor = '#ffc107';      // Yellow
        } else {
            contributionColor = '#dc3545';      // Red
        }


        return `

            <tr id="rev_prop_hd_${month_int}_${year_int}_${item.company_id}">
                <td style="position:relative;">
                <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex align-items-center gap-2">
                        <div class="me-2 cursor-pointer">
                            <a href="javascript:;" class="border  rounded px-1 py-1 bg-primary text-white" onclick="rev_prop_fuc(${month_int},${year_int},${item.company_id})">
                                <i class="mdi mdi-plus fs-4" id="rev_prop_${month_int}_${year_int}_${item.company_id}_plus_btton"></i>
                            </a>
                        </div>
                        <div class="d-flex align-items-center">
                            ${item.company_id == 0 ? 
                            `<img
                                src="/fav_icons/${item.company_favicon}"
                                style="width:35px;height:35px"
                                class="rounded me-2">`
                            :
                            `<img
                                src="/Company_favicon/${item.company_favicon}"
                                style="width:35px;height:35px"
                                class="rounded me-2">`
                            }
                            <strong>
                                ${item.company_name}
                            </strong>
                        </div>
                    </div>
                </td>
                <td class="text-center">
                    ${item.staff}
                </td>
                <td class="text-end">
                    ₹${Number(item.avg_salary).toLocaleString('en-IN')}
                </td>
                <td class="text-end text-success">
                    ₹${Number(item.actual_salary).toLocaleString('en-IN')}
                </td>
               <td class="text-end"
                    data-bs-toggle="tooltip"
                    title="₹${Number(item.actual_salary || 0).toLocaleString('en-IN')} + ₹${Number(item.other_company_share || 0).toLocaleString('en-IN')} = ₹${Number(item.shared_value || 0).toLocaleString('en-IN')}">
                    ₹${Number(item.shared_value || 0).toLocaleString('en-IN')}
                </td>
                <td class="text-center">

                    <div class="circular-progress"
                        style="
                            --value:${item.company_contribution_percentage};
                            --progress-color:${contributionColor};
                        "
                       data-bs-toggle="tooltip" title="${item.company_contribution_percentage}%">

                        <span>${item.company_contribution_percentage}%</span>

                    </div>

                </td>

                <td class="text-end" >
                    ₹${Number(item.sales_value).toLocaleString('en-IN')}
                </td>

                <td class="text-center" data-bs-toggle="tooltip" title=" ${item.salary_consumption_percentage}%">
                    ${
                        item.status === 'profit'
                        ? '<span class="badge bg-success">Profit</span>'
                        : item.status === 'loss'
                        ? '<span class="badge bg-warning">Loss</span>'
                        :item.status === 'danger'

                        ? '<span class="badge bg-danger">Danger</span>'
                    
                        : '<span class="badge bg-light">-</span>'
                    }
                </td>
            </tr>
            <tr id="rev_prop_${month_int}_${year_int}_${item.company_id}_tbox" style="display:none;">
                <td colspan="8" class="bg-label-warning px-2 pb-2 pt-1">
                    <div class="table-responsive">
                        <table class="table bg-white salary-child-table mb-0">
                            <colgroup>
                                <col style="width:32%">
                                <col style="width:8%">
                                <col style="width:10%">
                                <col style="width:12%">
                                <col style="width:12%">
                                <col style="width:10%">
                                <col style="width:10%">
                                <col style="width:6%">
                            </colgroup>

                            <tbody id="company_body_${month_int}_${year_int}_${item.company_id}">
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>

        `;

    }
    function loadThemes(page = 1) {
       
        const monthFilter = $('#dash_month_picker').val() ;
        $('#month_filter_label').text(monthFilter)

        const url = `/salary_balance_sheet/company-summary?page=${page}&month_filter=${monthFilter}&type=company`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader
         document.getElementById("salaryFooter").innerHTML=`

            <tr class="table-warning fs-5 fw-bold">
                <td>OverAll</td>
                <td class="text-center">
                    
                </td>
                <td></td>
                <td class="text-end">
                    
                </td>
                <td class="text-end">
                    
                </td>
                <td></td>
                <td class="text-end">
                    
                </td>
                <td></td>
            </tr>

        `;

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {

                let overall={
                    staff:0,
                    actual:0,
                    shared:0,
                    total:0,
                    sales:0
                };
              
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildMonthRow(item,res.month_int,res.year_int));

                        overall.staff+=Number(item.staff);
                        overall.actual+=Number(item.actual_salary);
                        overall.shared+=Number(item.shared_value);
                        overall.total+=Number(item.shared_value);
                        overall.sales+=Number(item.sales_value);
                    });

                   

                    document.getElementById("salaryFooter").innerHTML=`

                        <tr class="table-warning fs-5 fw-bold">
                            <td>OverAll</td>
                            <td class="text-center">
                                ${overall.staff}
                            </td>
                            <td></td>
                            <td class="text-end">
                                ${money(overall.actual)}
                            </td>
                            <td class="text-end">
                                ${money(overall.shared)}
                            </td>
                            <td></td>
                            <td class="text-end">
                                ${money(overall.sales)}
                            </td>
                            <td></td>
                        </tr>

                    `;

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                    document.getElementById('deductionsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    document.getElementById('earningsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    document.getElementById("salaryFooter").innerHTML=`

                        <tr class="table-warning fs-5 fw-bold">
                            <td>OverAll</td>
                            <td class="text-center">
                                
                            </td>
                            <td></td>
                            <td class="text-end">
                               
                            </td>
                            <td class="text-end">
                               
                            </td>
                            <td></td>
                            <td class="text-end">
                                
                            </td>
                            <td></td>
                        </tr>

                    `;
                }
                
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }


    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }
    loadThemes(1);

    function money(amount){
        if(amount==null)
        return "-";
        return "₹"+Number(amount).toLocaleString('en-IN');
    }
</script>
<script>
    $('#dash_month_picker').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        });
</script>

<script>
    function rev_prop_fuc(month,year,company_id) {
        var rev_prop_tbox = document.getElementById(`rev_prop_${month}_${year}_${company_id}_tbox`);
        var plus_button = document.getElementById(`rev_prop_${month}_${year}_${company_id}_plus_btton`);
        var header = document.getElementById(`rev_prop_hd_${month}_${year}_${company_id}`);

        if (rev_prop_tbox.style.display === "none" || rev_prop_tbox.style.display === "") {
            rev_prop_tbox.style.display = "table-row";
            plus_button.classList.remove("mdi-plus");
            plus_button.classList.add("mdi-minus");
            // header.style.backgroundColor = "#f9f3c5db";
            loadEntity(month,year,company_id)
        } else {
            rev_prop_tbox.style.display = "none";
            plus_button.classList.remove("mdi-minus");
            plus_button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    }
</script>
<script>
    function loadEntity(month,year,company_id)
    {

        let body=$("#company_body_"+month+"_"+year+"_"+company_id);

        body.html(`
            <tr>
                <td colspan="8" class="text-center">
                    Loading...
                </td>
            </tr>
        `);

        $.ajax({
            url:"/salary_balance_sheet/entity-summary",
            type:"GET",
            data:{
                _token:$('meta[name=csrf-token]').attr('content'),
                month:month,
                year:year,
                company_id:company_id
            },
            success:function(res){
                renderEntityTable( month,year, res.data ,company_id);
                
            }
        });

    }

    function renderEntityTable(month,year,data,company_id)
    {
        let html='';
        let status='';
        let action='';

       
        data.forEach(function(item){
             let contributionColor = '#0d6efd';

            if (item.company_contribution_percentage >= 60) {
                contributionColor = '#198754';      // Green
            } else if (item.company_contribution_percentage >= 30) {
                contributionColor = '#ffc107';      // Yellow
            } else {
                contributionColor = '#dc3545';      // Red
            }
            html+=`
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.entity_base_color || ''};"></div>
                   
                    <div class="d-flex align-items-center">
                        ${company_id != '0' ?
                        `<img
                            src="/Entity_favicons/${item.entity_id}/${item.entity_favicon}"
                            style="width:35px;height:35px"
                            class="rounded me-2">`:''
                        }
                       
                        <strong>
                            ${item.entity_name}
                        </strong>
                    </div>
                </td>
                <td class="text-center">
                    ${item.staff}
                </td>
                <td class="text-end">
                    ₹${Number(item.avg_salary).toLocaleString('en-IN')}
                </td>
                <td class="text-end text-success">
                    ₹${Number(item.actual_salary).toLocaleString('en-IN')}
                </td>
                <td class="text-end"
                    data-bs-toggle="tooltip"
                    title="₹${Number(item.actual_salary || 0).toLocaleString('en-IN')} + ₹${Number(item.other_company_share || 0).toLocaleString('en-IN')} = ₹${Number(item.shared_value || 0).toLocaleString('en-IN')}">
                    ₹${Number(item.shared_value || 0).toLocaleString('en-IN')}
                </td>
               
                <td class="text-center">

                    <div class="circular-progress"
                        style="
                            --value:${item.company_contribution_percentage};
                            --progress-color:${contributionColor};
                        "
                       data-bs-toggle="tooltip" title="${item.company_contribution_percentage}%">

                        <span>${item.company_contribution_percentage}%</span>

                    </div>

                </td>
                <td class="text-end ">
                     ₹${Number(item.sales_value).toLocaleString('en-IN')}
                </td>
                <td class="text-center" data-bs-toggle="tooltip" title=" ${item.salary_consumption_percentage}%">
                    ${
                        item.status === 'profit'
                        ? '<span class="badge bg-success">Profit</span>'
                        : item.status === 'loss'
                        ? '<span class="badge bg-warning">Loss</span>'
                        :item.status === 'danger'

                        ? '<span class="badge bg-danger">Danger</span>'
                    
                        : '<span class="badge bg-light">-</span>'
                    }
                </td>
            </tr>
            `;
        });
        $("#company_body_"+month+"_"+year+"_"+company_id).html(html);
        $('[data-bs-toggle="tooltip"]').tooltip();
    }

 

</script>

@endsection