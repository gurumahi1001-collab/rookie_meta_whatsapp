@extends('layouts/layoutMaster')

@section('title', 'Resource Request')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')

<style>
    .template-icon {
        width: 60px;
        height: 60px;
        border-radius: 18px;
        background: linear-gradient(135deg, #ab2b22, #d94b3f);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
    }

    .summary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 0;
        border-bottom: 1px dashed #eee;
    }

    .summary-item strong {
        font-size: 16px;
        font-weight: 700;
    }

    .summary-item.net strong {
        color: #16a34a;
    }

    .summary-item.deduction strong {
        color: #dc2626;
    }

    .payroll-summary-card {
        top: 20px;
    }
</style>
<style>
    .payroll-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    .payroll-title {
        font-size: 32px;
        font-weight: 800;
        margin-bottom: 5px;
        color: #111827;
    }

    .payroll-subtitle {
        color: #6b7280;
        margin: 0;
    }

    .payroll-header-icon {
        width: 70px;
        height: 70px;
        border-radius: 22px;
        background: linear-gradient(135deg, #991b1b, #dc2626);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 32px;
        box-shadow: 0 10px 30px rgba(220, 38, 38, .25);
    }

    .card {
        border: none !important;
        border-radius: 22px !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, .06);
    }

    .payroll-component-card {
        background: white;
        border-radius: 18px;
        padding: 20px;
        margin-bottom: 18px;
        border: 1px solid #f1f5f9;
        transition: .3s;
    }

    .payroll-component-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, .06);
    }

    .payroll-label {
        font-weight: 700;
        color: #374151;
        margin-bottom: 8px;
    }

    .payroll-input {
        border-radius: 12px;
        border: 1px solid #d1d5db;
        min-height: 48px;
    }

    .payroll-input:focus {
        border-color: #dc2626;
        box-shadow: 0 0 0 4px rgba(220, 38, 38, .1);
    }

    .template-icon {
        width: 70px;
        height: 70px;
        border-radius: 20px;
        background: linear-gradient(135deg, #991b1b, #dc2626);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
    }

    .summary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 0;
        border-bottom: 1px dashed #e5e7eb;
    }

    .summary-item strong {
        font-size: 18px;
        font-weight: 800;
    }

    .summary-item.net strong {
        color: #16a34a;
    }

    .summary-item.deduction strong {
        color: #dc2626;
    }

    .payroll-summary-card {
        top: 20px;
        background: white;
    }

    .remove-row-btn {
        width: 42px;
        height: 42px;
        border-radius: 12px;
    }

    #gross_preview {
        color: #2563eb;
    }

    #ctc_preview {
        color: #7c3aed;
    }

    #employer_preview {
        color: #ea580c;
    }
</style>
<!-- Lead List Table -->
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp
<div class="card">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Salary Structures</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR General
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">

            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" onclick="openStructureModal()">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Payroll salary Template
            </a>
        </div>
    </div>
    <a href="#" id="downloadPng" aria-label="Download as PNG" class="max-md:mb-4! max-md:mt-8! group flex-none max-md:order-last" aria-label="Hugging Face">
    </a>
    <div class="card-body">

        <div class="row">

            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Salary Template..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold text-primary"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold text-primary"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>

                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Template</th>
                                <th>Code</th>
                                <th>Gross Salary</th>
                                <th>Monthly CTC</th>
                                <th>Effective From</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Create Campaign-->
<div class="modal fade" id="kt_modal_create_salary_structure" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <div class="payroll-header">
                        <div>
                            <h2 class="payroll-title" id="salaryTemplateModalTitle">Payroll Salary Template</h2>
                            <p class="payroll-subtitle"> Configure salary structure, earnings and deductions</p>
                        </div>

                    </div>
                </div>
                <form id="structureForm">
                    @csrf
                    <input type="hidden" name="sno" id="structure_sno">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-6 mb-4">
                                <label class="form-label fw-semibold">Template Type</label>
                                <select class="form-select select3" id="template_type">
                                    <option value="monthly">Monthly Salary</option>
                                    <option value="intern">Internship</option>
                                    <option value="contract">Contract</option>
                                </select>
                            </div>
                            <!-- LEFT SIDE -->
                            <div class="col-xl-8">
                                <!-- TEMPLATE INFO -->
                                <div class="card border-0 shadow-sm rounded-4 mb-4">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center justify-content-between mb-4">
                                            <div>
                                                <h3 class="fw-bold mb-1">Create Salary Template</h3>
                                                <div class="text-muted">Configure payroll salary structure</div>
                                            </div>
                                            <div class="template-icon">
                                                <i class="mdi mdi-file-document-edit-outline"></i>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 mb-4">

                                                <label class="form-label fw-semibold">
                                                    Template Name
                                                </label>

                                                <input
                                                    type="text"
                                                    class="form-control custom-input"
                                                    id="template_name"
                                                    placeholder="Software Engineer L1">

                                            </div>
                                            <div class="col-lg-6 mb-4">

                                                <label class="form-label fw-semibold">
                                                    Template Code
                                                </label>

                                                <input
                                                    type="text"
                                                    class="form-control custom-input"
                                                    id="template_code"
                                                    placeholder="SE_L1">

                                            </div>
                                            <div class="col-lg-6 mb-4">

                                                <label class="form-label fw-semibold">
                                                    Gross Salary
                                                </label>

                                                <input
                                                    type="text"
                                                    class="form-control custom-input gross_salary"
                                                    id="gross_salary"
                                                    placeholder="50000" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">

                                            </div>
                                            <div class="col-lg-6 mb-4">

                                                <label class="form-label fw-semibold">
                                                    Effective From
                                                </label>

                                                <input
                                                    type="text"
                                                    class="form-control custom-input common_datepicker"
                                                    id="effective_from">

                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- EARNING COMPONENTS -->
                                <div class="card border-0 shadow-sm rounded-4 mb-4">
                                    <div class="card-body p-4">
                                        <div class="d-flex justify-content-between align-items-center mb-4">
                                            <div>
                                                <h5 class="fw-bold mb-1">Earnings Components</h5>
                                                <small class="text-muted">Gross salary breakup configuration</small>
                                            </div>
                                            <button type="button" class="btn btn-primary rounded-pill" onclick="addComponentRow('earning')">
                                                <i class="mdi mdi-plus"></i> Add Component
                                            </button>
                                        </div>
                                        <div id="earning_components">
                                            <div class="empty-component-message text-center text-muted py-4">
                                                No components added
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- DEDUCTIONS -->
                                <div class="card border-0 shadow-sm rounded-4 mb-5">
                                    <div class="card-body p-4">
                                        <div class="d-flex justify-content-between align-items-center mb-4">
                                            <div>
                                                <h5 class="fw-bold mb-1">Deduction Components</h5>
                                                <small class="text-muted">Configure employee deductions</small>
                                            </div>
                                            <button type="button" class="btn btn-danger rounded-pill" onclick="addComponentRow('deduction')">
                                                <i class="mdi mdi-minus-circle-outline"></i>Add Deduction
                                            </button>
                                        </div>
                                        <div id="deduction_components">
                                            <div class="empty-component-message text-center text-muted py-4">
                                                No components added
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card border-0 shadow-sm rounded-4 mt-4">

                                    <div class="card-header bg-light">
                                        <h5 class="mb-0">
                                            Employer Contribution
                                        </h5>
                                    </div>

                                    <div class="card-body">

                                        <div id="employer_components">

                                            <div class="empty-component-message text-center text-muted py-4">
                                                No employer contributions
                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </div>

                            <!-- RIGHT SIDE -->

                            <div class="col-xl-4">

                                <div class="card border-0 shadow-lg rounded-4 sticky-top payroll-summary-card">

                                    <div class="card-body p-4">

                                        <div class="summary-header mb-4">

                                            <div class="summary-icon">
                                                <i class="mdi mdi-cash-multiple"></i>
                                            </div>

                                            <div>

                                                <h5 class="fw-bold mb-1">
                                                    Salary Summary
                                                </h5>

                                                <small class="text-muted">
                                                    Live payroll calculation
                                                </small>

                                            </div>

                                        </div>

                                        <div class="salary-summary-list">
                                            <div class="summary-item">
                                                <span>Gross Earnings</span>
                                                <strong id="gross_preview">
                                                    ₹ 0.00
                                                </strong>
                                            </div>

                                            <div class="summary-item deduction">
                                                <span>Total Deduction</span>
                                                <strong id="deduction_preview">
                                                    ₹ 0.00
                                                </strong>
                                            </div>

                                            <div class="summary-item employer">
                                                <span>Employer Contribution</span>
                                                <strong id="employer_preview">
                                                    ₹ 0.00
                                                </strong>
                                            </div>
                                            <hr>
                                            <div class="summary-item net">
                                                <span>Net Salary</span>
                                                <strong id="net_preview">
                                                    ₹ 0.00
                                                </strong>
                                            </div>

                                            <div class="summary-item ctc">
                                                <span>Monthly CTC</span>
                                                <strong id="ctc_preview">
                                                    ₹ 0.00
                                                </strong>
                                            </div>
                                        </div>

                                        <button
                                            type="button"
                                            class="btn btn-primary w-100 mt-4 py-3 rounded-pill fw-bold save-template-btn"
                                            onclick="saveTemplate()">
                                            <i class="mdi mdi-content-save-outline me-1"></i>
                                            Save Salary Template
                                        </button>

                                    </div>

                                </div>

                            </div>

                            <div class="col-lg-12 mb-4">

                                <label class="form-label fw-semibold">
                                    Description
                                </label>

                                <textarea
                                    class="form-control"
                                    rows="3"
                                    id="description"></textarea>

                            </div>

                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Campaign-->

<!--begin::Modal - Delete Campaign-->
<div class=" modal fade" id="kt_modal_delete_payroll_template" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Template ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign-->
@php

$earningOptions = '';

$deductionOptions = '';

foreach($components as $component){

$option = '
<option value="'.$component->sno.'"
    data-category="'.$component->category.'"
    data-calculation="'.$component->calculation_type.'"
    data-percentage="'.$component->percentage_value.'"
    data-rule="'.$component->rule_code.'"
    data-rule-expression="'.$component->rule_expression.'"
    data-code="'.$component->component_code.'"
    data-name="'.$component->component_name.'">

    '.$component->component_name.'

</option>

';

if($component->category == 'earning'){

$earningOptions .= $option;
}

if($component->category == 'deduction'){

$deductionOptions .= $option;
}
}

@endphp
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function buildRow(item) {
        return `

        <tr>

            <td>
                <div class="fw-bold text-black">
                    ${item.template_name}
                </div>
            </td>

            <td>
                <span class="badge bg-light-primary text-primary">
                    ${item.template_code}
                </span>
            </td>

            <td>
                ₹ ${item.gross_salary}
            </td>

            <td>
                ₹ ${item.monthly_ctc}
            </td>

            <td>
                ${formatDate(item.effective_from)}
            </td>

            <td>

                ${
                    item.status == 0
                    ?
                    `<span class="badge bg-success">Active</span>`
                    :
                    `<span class="badge bg-danger">Inactive</span>`
                }

            </td>

            <td class="text-center">

                <span class="text-end">
                
                    <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                      
                        <a href="javascript:;" class="dropdown-item" onclick="editTemplate(${item.sno})">
                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                        </a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_payroll_template" onclick="confirmDelete('${item.sno}', '${item.template_name}')">
                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                        </a>
                    </div>
                </span>

            </td>

        </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/payroll/salary-template?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;
        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
               
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
             <tr class="no-data-found">
                <td colspan="4" class="text-center">No Data Found</td>
            </tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }
    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };
    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);
    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });
    // Initial load
    loadThemes(1);
</script>
<script>
    let componentIndex = 0;

    function openStructureModal(type = 'create', data = null) {

        $('#structureForm')[0].reset();
        $('#structure_sno').val('');
        $('#earning_components').html(`
            <div class="empty-component-message text-center text-muted py-4">
                No components added
            </div>
        `);

        $('#deduction_components').html(`
            <div class="empty-component-message text-center text-muted py-4">
                No components added
            </div>
        `);

        $('#employer_components').html(`
            <div class="empty-component-message text-center text-muted py-4">
                No employer contributions
            </div>
        `);
        $('#gross_preview').html('₹ 0.00');
        $('#deduction_preview').html('₹ 0.00');
        $('#employer_preview').html('₹ 0.00');
        $('#net_preview').html('₹ 0.00');
        $('#ctc_preview').html('₹ 0.00');
        componentIndex = 0;

        if (type === 'create') {

            $('#salaryTemplateModalTitle').html('Create Payroll Salary Template');

            // DEFAULT ROWS
            addComponentRow('earning');
            addComponentRow('earning');
            addComponentRow('earning');

        } else {

            $('#salaryTemplateModalTitle').html('Edit Payroll Salary Template');

            if (data) {

                $('#structure_sno').val(data.sno);
                $('#template_name').val(data.template_name);
                $('#template_code').val(data.template_code);
                $('#gross_salary').val(data.gross_salary);
                $('#effective_from').val(data.effective_from);
                $('#template_type').val(data.template_type);
                $('#description').val(data.description);

                if (data.details && data.details.length > 0) {

                    data.details.forEach(detail => {

                        /*
                        |--------------------------------------------------------------------------
                        | EMPLOYER CONTRIBUTION
                        |--------------------------------------------------------------------------
                        */

                        if (detail.component_type === 'employer_contribution') {

                            addEmployerContributionRow({
                                component_code: detail.component.component_code,
                                component_name: detail.component_name,
                                calculation_type: detail.calculation_type,
                                percentage_value: detail.percentage,
                                amount: detail.amount,
                                formula_expression: detail.component.formula_expression || ''
                            });

                            return;
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | EARNING / DEDUCTION
                        |--------------------------------------------------------------------------
                        */

                        addComponentRow(
                            detail.component_type,
                            detail
                        );
                    });
                }
            }

            calculateSummary();
        }

        $('#kt_modal_create_salary_structure').modal('show');
    }

    function addComponentRow(type = 'earning', rowData = null) {

        let componentOptions = '';


        if (type === 'earning') {
            $('.empty-component-message').remove();

            componentOptions = `{!! $earningOptions !!}`;

        } else if (type === 'deduction') {
            $('.empty-component-message').remove();

            componentOptions = `{!! $deductionOptions !!}`;
        }

        let html = `

            <div class="component-row payroll-component-card"
                data-type="${type}">

                <div class="row g-3 align-items-end">

                    <div class="col-lg-4">

                        <label class="form-label payroll-label">
                            Component
                        </label>

                        <select class="form-select payroll-input component_id">

                            <option value="">
                                Select Component
                            </option>

                            ${componentOptions}

                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label payroll-label">
                            Calc Type
                        </label>

                        <select class="form-select select3 payroll-input calculation_type" >
                            <option value="">Select</option>
                            <option value="fixed">Fixed</option>
                            <option value="percentage">Percentage</option>
                            <option value="manual_input">Manual Input</option>
                            <option value="formula">Formula</option>
                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label payroll-label">
                            %
                        </label>

                        <input type="text"
                            min="0"
                            max="100"
                            class="form-control payroll-input percentage" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"
                            placeholder="0">

                    </div>

                    <div class="col-lg-3">

                        <label class="form-label payroll-label">
                            Amount
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">₹</span>

                            <input type="text"
                                min="0"
                                class="form-control payroll-input amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"
                                placeholder="0.00">

                        </div>

                    </div>

                    <div class="col-lg-1 text-end">

                        <button type="button"
                                class="btn btn-danger btn-sm remove-row-btn">

                            <i class="mdi mdi-trash-can-outline"></i>

                        </button>

                    </div>

                </div>

            </div>
        `;

        if (type === 'earning') {

            $('#earning_components').append(html);

        } else {

            $('#deduction_components').append(html);
        }

        let row = $('.component-row').last();

        if (rowData) {

            row.find('.component_id')
                .val(rowData.component_sno)
                .trigger('change');

            setTimeout(() => {

                row.find('.calculation_type')
                    .val(rowData.calculation_type)
                    .trigger('change');

                row.find('.percentage')
                    .val(rowData.percentage);

                row.find('.amount')
                    .val(rowData.amount);

            }, 50);
        }

        setTimeout(() => {
            calculateSummary();
        }, 200);
    }
    $(document).on('change', '.component_id', function () {

    let row = $(this).closest('.component-row');

    let selectedValue = $(this).val();

    let duplicate = false;

    $('.component_id').not(this).each(function () {

        if ($(this).val() === selectedValue && selectedValue !== '') {

            duplicate = true;
        }
    });

    if (duplicate) {

        toastr.error('Component already selected');

        $(this).val('').trigger('change');

        return;
    }

    let selected = $(this).find(':selected');

    let calculationType = selected.data('calculation') || '';

    let percentage = parseFloat(selected.data('percentage')) || 0;

    let componentCode = selected.data('code');

    /*
    |--------------------------------------------------------------------------
    | SET CALCULATION TYPE
    |--------------------------------------------------------------------------
    */

    row.find('.calculation_type')
        .val(calculationType)
        .trigger('change');

    /*
    |--------------------------------------------------------------------------
    | RESET VALUES
    |--------------------------------------------------------------------------
    */

    row.find('.percentage').val('');

    row.find('.amount').val('');

    /*
    |--------------------------------------------------------------------------
    | ENABLE ALL FIRST
    |--------------------------------------------------------------------------
    */

    row.find('.percentage').prop('readonly', false);

    row.find('.amount').prop('readonly', false);

    /*
    |--------------------------------------------------------------------------
    | EMPLOYER CONTRIBUTIONS
    |--------------------------------------------------------------------------
    */

    if (componentCode === 'PF') {

        addEmployerContributionRow({
            component_code: 'EMPLOYER_PF',
            component_name: 'Employer PF',
            calculation_type: 'formula',
            percentage_value: 12,
            formula_expression: 'IF((basic + da) > 15000,1800,(basic + da) * 0.12)'
        });
    }

    if (componentCode === 'ESI') {

        addEmployerContributionRow({
            component_code: 'EMPLOYER_ESI',
            component_name: 'Employer ESI',
            calculation_type: 'formula',
            percentage_value: 3.25,
            formula_expression: 'IF(gross_salary <= 21000,gross_salary * 0.0325,0)'
        });
    }

    /*
    |--------------------------------------------------------------------------
    | TYPE CONTROLS
    |--------------------------------------------------------------------------
    */

    if (calculationType === 'percentage') {

        row.find('.percentage')
            .val(percentage);

        row.find('.percentage')
            .prop('readonly', false);

        row.find('.amount')
            .prop('readonly', true);
    }

    else if (calculationType === 'fixed') {

        row.find('.percentage')
            .val(0)
            .prop('readonly', true);

        row.find('.amount')
            .prop('readonly', false);
    }

    else if (calculationType === 'manual_input') {

        row.find('.percentage')
            .val(0)
            .prop('readonly', true);

        row.find('.amount')
            .prop('readonly', false);
    }

    else if (calculationType === 'formula') {

        row.find('.percentage')
            .val(0)
            .prop('readonly', true);

        row.find('.amount')
            .prop('readonly', true);
    }

    calculateSummary();
    });

    $(document).on('change', '.calculation_type', function () {

        let row = $(this).closest('.component-row');

        let type = $(this).val();

        row.find('.percentage').prop('readonly', false);

        row.find('.amount').prop('readonly', false);

        if (type === 'percentage') {

            row.find('.amount').prop('readonly', true);
        }

        if (
            type === 'fixed' ||
            type === 'manual_input'
        ) {

            row.find('.percentage')
                .val(0)
                .prop('readonly', true);
        }

        if (type === 'formula') {

            row.find('.percentage')
                .val(0)
                .prop('readonly', true);

            row.find('.amount')
                .prop('readonly', true);
        }

        calculateSummary();
    });
    $(document).on('change', '.component_id', function() {
        let selected = $(this).val();
        let count = 0;
        $('.component_id').each(function() {
            if ($(this).val() === selected && selected !== '') {
                count++;
            }
        });
        if (count > 1) {
            toastr.error('Component already selected');
            $(this).val('');
            return;
        }
    });

    $(document).on('click', '.remove-row-btn', function() {
        let parentCard = $(this).closest('.component-row');
        let container = parentCard.parent();
        parentCard.remove();
        // show empty message again
        if (container.find('.component-row').length === 0) {
            container.html(`
                <div class="empty-component-message text-center text-muted py-4">
                    No components added
                </div>
            `);
        }

        calculateSummary();
    })

    $(document).on(
        'keyup change',
        '#gross_salary,.percentage,.amount',
        function() {
            calculateSummary();
        }
    );

    function addEmployerContributionRow(data) {

        let exists = false;

        $('#employer_components .employer-row').each(function () {

            if ($(this).attr('data-code') === data.component_code) {
                exists = true;
            }
        });

        if (exists) {
            return;
        }

        $('#employer_components .empty-component-message').remove();

        let html = `

        <div class="component-row payroll-component-card employer-row"
            data-code="${data.component_code}"
            data-formula="${data.formula_expression || ''}">

            <div class="row g-3 align-items-end">

                <div class="col-lg-3">

                    <label class="form-label payroll-label">
                        Component
                    </label>

                     <input type="hidden"
                        class="component_id"
                        value="${data.component_sno || ''}">

                    <input type="hidden"
                        class="hiddencode"
                        value="${data.component_code || ''}">

                    <input type="text"
                        class="form-control"
                        value="${data.component_name}"
                        readonly>

                </div>

                <div class="col-lg-2">

                    <label class="form-label payroll-label">
                        Calc Type
                    </label>

                    <select class="form-select employer-calculation-type">

                        <option value="fixed"
                            ${data.calculation_type === 'fixed' ? 'selected' : ''}>
                            Fixed
                        </option>

                        <option value="percentage"
                            ${data.calculation_type === 'percentage' ? 'selected' : ''}>
                            Percentage
                        </option>

                        <option value="manual_input"
                            ${data.calculation_type === 'manual_input' ? 'selected' : ''}>
                            Manual Input
                        </option>

                        <option value="formula"
                            ${data.calculation_type === 'formula' ? 'selected' : ''}>
                            Formula
                        </option>

                    </select>

                </div>

                <div class="col-lg-2">

                    <label class="form-label payroll-label">
                        %
                    </label>

                    <input type="text"
                        class="form-control employer-percentage"
                        value="${data.percentage_value || 0}">

                </div>

                <div class="col-lg-3">

                    <label class="form-label payroll-label">
                        Amount
                    </label>

                    <input type="text"
                        class="form-control employer-amount"
                        value="${data.amount || 0}">

                </div>

            </div>

        </div>
        `;

        $('#employer_components').append(html);

        calculateSummary();

    }


   $(document).on(
    'change',
    '.employer-calculation-type',
    function () {

        let row = $(this).closest('.employer-row');

        let type = $(this).val();

        row.find('.employer-percentage')
            .prop('readonly', false);

        row.find('.employer-amount')
            .prop('readonly', false);

        if (type === 'percentage') {

            row.find('.employer-amount')
                .prop('readonly', true);
        }

        if (
            type === 'fixed' ||
            type === 'manual_input'
        ) {

            row.find('.employer-percentage')
                .prop('readonly', true);
        }

        if (type === 'formula') {

            row.find('.employer-percentage')
                .prop('readonly', true);

            row.find('.employer-amount')
                .prop('readonly', true);
        }

        calculateSummary();
    }

    );
    $(document).on(
    'keyup change',
    '.employer-amount',
    function () {

        calculateSummary();
    }

    );


    function calculateSummary() {
        let grossSalary = parseFloat($('#gross_salary').val()) || 0;
        let earnings = 0;
        let deductions = 0;
        let employerContribution = 0;
        let basic = 0;
        let da = 0;
        $('#earning_components .component-row').each(function() {

            let row = $(this);

            let calculationType = row.find('.calculation_type').val();

            let percentage = parseFloat(row.find('.percentage').val()) || 0;

            let amount = parseFloat(row.find('.amount').val()) || 0;

            if (calculationType === 'percentage') {

                amount = (grossSalary * percentage) / 100;

                row.find('.amount').val(amount.toFixed(2));
            }

            earnings += amount;
        });
        // $('#deduction_components .component-row').each(function() {

        //     let row = $(this);

        //     let calculationType = row.find('.calculation_type').val();

        //     let percentage = parseFloat(row.find('.percentage').val()) || 0;

        //     let amount = parseFloat(row.find('.amount').val()) || 0;

        //     if (calculationType === 'percentage') {

        //         amount = (grossSalary * percentage) / 100;

        //         row.find('.amount').val(amount.toFixed(2));
        //     }

        //     deductions += amount;
        // });
        $('#earning_components .component-row').each(function() {

            let earningRow = $(this);

            let earningSelected =
                earningRow.find('.component_id option:selected');

            let earningCode =
                earningSelected.data('code');

            let earningAmount =
                parseFloat(
                    earningRow.find('.amount').val()
                ) || 0;

            if (earningCode === 'BASIC') {
                basic = earningAmount;
            }

            if (earningCode === 'DA') {
                da = earningAmount;
            }
        });

       
        $('#deduction_components .component-row').each(function () {

            let row = $(this);

            let selected =
                row.find('.component_id option:selected');

            let calculationType =
                row.find('.calculation_type').val();

            let percentage =
                parseFloat(
                    row.find('.percentage').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.amount').val()
                ) || 0;

            let componentCode =
                selected.data('code') || '';

            let ruleExpression =
                selected.data('rule-expression') || '';

            /*
            |--------------------------------------------------------------------------
            | PERCENTAGE TYPE
            |--------------------------------------------------------------------------
            */

            if (calculationType === 'percentage') {

                /*
                |--------------------------------------------------------------------------
                | PF %
                |--------------------------------------------------------------------------
                */

                if (componentCode === 'PF') {

                    let pfBase = basic + da;

                    amount =
                        pfBase > 15000
                            ? 1800
                            : (pfBase * 0.12);
                }

                /*
                |--------------------------------------------------------------------------
                | ESI %
                |--------------------------------------------------------------------------
                */

                else if (componentCode === 'ESI') {

                    amount =
                        earnings <= 21000
                            ? (earnings * 0.0075)
                            : 0;
                }

                /*
                |--------------------------------------------------------------------------
                | NORMAL %
                |--------------------------------------------------------------------------
                */

                else {

                    amount =
                        (grossSalary * percentage) / 100;
                }

                row.find('.amount')
                    .val(parseFloat(amount).toFixed(2));
            }

            /*
            |--------------------------------------------------------------------------
            | FORMULA TYPE
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'formula'
            ) {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | DEFAULT PF FORMULA
                    |--------------------------------------------------------------------------
                    */

                    if (componentCode === 'PF') {

                        amount =
                            (basic + da) > 15000
                                ? 1800
                                : ((basic + da) * 0.12);
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | DEFAULT ESI FORMULA
                    |--------------------------------------------------------------------------
                    */

                    else if (componentCode === 'ESI') {

                        amount =
                            earnings <= 21000
                                ? (earnings * 0.0075)
                                : 0;
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | CUSTOM FORMULA
                    |--------------------------------------------------------------------------
                    */

                    else if (ruleExpression) {

                        let formula = ruleExpression;

                        formula =
                            formula.replaceAll(
                                'gross_salary',
                                earnings
                            );

                        formula =
                            formula.replaceAll(
                                'basic',
                                basic
                            );

                        formula =
                            formula.replaceAll(
                                'da',
                                da
                            );

                        formula = formula.replace(
                            /IF\((.*?),(.*?),(.*?)\)/g,
                            '($1 ? $2 : $3)'
                        );

                        amount = eval(formula);
                    }

                    row.find('.amount')
                        .val(parseFloat(amount).toFixed(2));

                } catch (e) {

                    amount = 0;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL INPUT
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {

            

                if (componentCode === 'ESI') {
                    amount =
                        earnings <= 21000
                            ? parseFloat(
                                row.find('.amount').val()
                            ) || 0
                            : 0;
                    console.log(amount)
                    // row.find('.amount')
                    //     .val(parseFloat(amount).toFixed(2));
                }else {
                    amount =
                        parseFloat(
                            row.find('.amount').val()
                        ) || 0;
                }

                row.find('.percentage')
                    .val(0);
            }

            deductions += parseFloat(amount) || 0;
        });

        $('#employer_components .employer-row').each(function () {

            let row = $(this);

            let calculationType =
                row.find('.employer-calculation-type').val();

            let percentage =
                parseFloat(
                    row.find('.employer-percentage').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.employer-amount').val()
                ) || 0;

            let formula =
                row.attr('data-formula') || '';

            /*
            |--------------------------------------------------------------------------
            | PERCENTAGE
            |--------------------------------------------------------------------------
            */

            if (calculationType === 'percentage') {

                amount = (grossSalary * percentage) / 100;

                row.find('.employer-amount')
                    .val(amount.toFixed(2));
            }

            /*
            |--------------------------------------------------------------------------
            | FORMULA
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'formula' &&
                formula
            ) {

                try {

                    let expression = formula;

                    expression = expression.replaceAll(
                        'gross_salary',
                        earnings
                    );

                    expression = expression.replaceAll(
                        'basic',
                        basic
                    );

                    expression = expression.replaceAll(
                        'da',
                        da
                    );

                    expression = expression.replace(
                        /IF\((.*?),(.*?),(.*?)\)/g,
                        '($1 ? $2 : $3)'
                    );

                    amount = eval(expression);

                    row.find('.employer-amount')
                        .val(parseFloat(amount).toFixed(2));

                } catch (e) {

                    amount = 0;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL INPUT
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {

                let componentCode =
                    row.attr('data-code') || '';

                if (componentCode === 'EMPLOYER_ESI') {

                    amount =
                        earnings <= 21000
                            ? parseFloat(
                                row.find('.employer-amount').val()
                            ) || 0
                            : 0;

                    // row.find('.employer-amount')
                    //     .val(parseFloat(amount).toFixed(2));
                }

                /*
                |--------------------------------------------------------------------------
                | NORMAL FIXED / MANUAL
                |--------------------------------------------------------------------------
                */

                else {

                    amount = parseFloat(
                        row.find('.employer-amount').val()
                    ) || 0;
                }

                row.find('.employer-percentage')
                    .val(0);
            }
           

            employerContribution += amount;
        });
        // ==========================
        // FINAL
        // ==========================

        let netSalary = earnings - deductions;

        let ctc = earnings + employerContribution;

        $('#gross_preview').html(
            '₹ ' + earnings.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#deduction_preview').html(
            '₹ ' + deductions.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#employer_preview').html(
            '₹ ' + employerContribution.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#net_preview').html(
            '₹ ' + netSalary.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#ctc_preview').html(
            '₹ ' + ctc.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );
    }

    function validateGrossPercentage() {

        let totalPercentage = 0;

        $('#earning_components .component-row').each(function() {

            totalPercentage += parseFloat(
                $(this).find('.percentage').val()
            ) || 0;
        });

        if (totalPercentage > 100) {

            toastr.error(
                'Earning percentage cannot exceed 100%'
            );
        }
    }

    function saveTemplate() {

        let totalPercentage = 0;

        if ($('#template_name').val() === '') {

            toastr.error('Template name required');
            return;
        }

        if ($('#template_code').val() === '') {

            toastr.error('Template code required');
            return;
        }

        if ($('#gross_salary').val() === '') {

            toastr.error('Gross salary required');
            return;
        }

        $('#earning_components .component-row').each(function() {

            totalPercentage += parseFloat(
                $(this).find('.percentage').val()
            ) || 0;
        });

        if (totalPercentage !== 100) {

            toastr.error(
                'Earnings percentage must equal exactly 100%'
            );

            return;
        }

        let details = [];

        $('#earning_components .component-row').each(function() {
            let row = $(this);
            if (!row.find('.component_id').val()) {
                return;
            }
            details.push({
                component_sno: row.find('.component_id').val(),
                percentage: row.find('.percentage').val(),
                amount: row.find('.amount').val(),
                calculation_type: row.find('.calculation_type').val(),
                component_type: 'earning'
            });
        });

        $('#deduction_components .component-row').each(function() {
            let row = $(this);
            if (!row.find('.component_id').val()) {
                return;
            }
            details.push({
                component_sno: row.find('.component_id').val(),
                percentage: row.find('.percentage').val(),
                amount: row.find('.amount').val(),
                calculation_type: row.find('.calculation_type').val(),
                component_type: 'deduction'
            });
        });

        let employer_contributions = [];

        $('#employer_components .employer-row').each(function() {

            let row = $(this);

            employer_contributions.push({

                component_sno: row.find('.component_id').val(),

                component_code: row.find('.hiddencode').val(),

                component_name: row.find('input[type="text"]').val(),

                percentage: row.find('.employer-percentage').val(),

                amount: row.find('.employer-amount').val(),

                calculation_type: row.find('.employer-calculation-type').val()
            });
        });

        let payload = {
            _token: '{{ csrf_token() }}',
            sno: $('#structure_sno').val(),
            template_name: $('#template_name').val(),
            template_code: $('#template_code').val(),
            gross_salary: $('#gross_salary').val(),
            effective_from: $('#effective_from').val(),
            template_type: $('#template_type').val(),
            description: $('#description').val(),
            details: details,
            employer_contributions: employer_contributions
        };
        $('.save-template-btn')
            .prop('disabled', true)
            .html(`
                <span class="spinner-border spinner-border-sm me-2"></span>
                Saving...
            `);
        $.ajax({

            url: '/payroll/salary-template/save',

            type: 'POST',

            data: payload,

            success: function(response) {

                toastr.success(response.message);

                $('#kt_modal_create_salary_structure').modal('hide');

                loadThemes(1);
            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message || 'Something went wrong'
                );
            },

            complete: function() {

                $('.save-template-btn')
                    .prop('disabled', false)
                    .html(`
                        <i class="mdi mdi-content-save-outline me-1"></i>
                        Save Salary Template
                    `);
            }
        });
    }

    function editTemplate(id) {

        $.ajax({

            url: '/payroll/salary-template/edit/' + id,

            type: 'GET',

            success: function(response) {

                openStructureModal(
                    'edit',
                    response.data
                );
            },

            error: function() {

                toastr.error('Unable to load template');
            }
        });
    }

    $(document).ready(function() {

        $('.common_datepicker').datepicker({

            todayHighlight: true,

            autoclose: true,

            format: 'dd-M-yyyy'
        });
    });
</script>
<script>
    function confirmDelete(id, staff) {

        document.querySelector('#kt_modal_delete_payroll_template .btn-danger').setAttribute('data-id', id);
        $('#delete_message').html(
            'Are you sure you want to delete Template ?<br><br> <b class="text-black fw-bold fs-4">' +
            staff +
            '</b>');
    }

    function deleteFunc() {
        var categoryId = document.querySelector('#kt_modal_delete_payroll_template .btn-danger').getAttribute('data-id');

        fetch('/staff_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {
                toastr.error(error);
            });
    }
</script>

<!-- 
<div class="card border-0 shadow-sm rounded-4 mt-4">

    <div class="card-header bg-light">
        <h5 class="mb-0">
            Employer Contribution
        </h5>
    </div>

    <div class="card-body">

        <div id="employer_components">

            <div class="empty-component-message text-center text-muted py-4">
                No employer contributions
            </div>

        </div>

    </div>

</div>
INSERT INTO egc_payroll_components
(
    component_code,
    component_name,
    category,
    calculation_type,
    percentage_value
)
VALUES
(
    'EMPLOYER_PF',
    'Employer PF',
    'employer_contribution',
    'formula',
    13
),
(
    'EMPLOYER_ESI',
    'Employer ESI',
    'employer_contribution',
    'formula',
    3.25
); -->

@endsection