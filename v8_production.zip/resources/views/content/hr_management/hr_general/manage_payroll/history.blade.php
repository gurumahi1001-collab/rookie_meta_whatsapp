@extends('layouts/layoutMaster')

@section('title', 'Manage Payroll')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
//  'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
//  'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'],)
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js'])
@endsection

@section('content')

<style>

.card {

border-radius:12px;

}

.table {

font-size:14px;

}

.modal-content {

border-radius:12px;

}

.badge {

font-size:12px;

}

</style>


<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
            <h5 class="card-title mb-1">Manage Payroll</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element mb-1 gap-2 text-center">
            <div class="d-flex justify-content-end align-items-center flex-wrap gap-2 mb-1">
                <div class="d-flex flex-row align-items-center justify-content-between gap-2">
                    <ul class="nav nav-pills justify-content-end" role="tablist">
                        <li class="nav-item me-1">
                            <a class="nav-link px-3" href="#" id="prevMonth">
                            <div class="text-center">
                                <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                            </div>
                            </a>
                        </li>
                        <li class="nav-item me-1 mt-1">
                            <a class="nav-link active px-3" href="#">
                            <div class="text-center">
                                <span class="fs-6 fw-semibold text-white text-capitalize" id="currentMonth"><?php echo date('M-Y') ?></span>
                            </div>
                            </a>
                        </li>
                        <li class="nav-item me-1">
                            <a class="nav-link px-3" href="#" id="nextMonth">
                            <div class="text-center">
                                <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                            </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-2">
        <div class="container-fluid py-4">

<div class="card shadow border-0">

<div class="card-header bg-dark text-white">

<h4 class="mb-0">
Payroll History
</h4>

</div>

<div class="card-body">

<table class="table table-hover align-middle">

<thead class="table-light">

<tr>
<th>Month</th>
<th>Year</th>
<th>Type</th>
<th>Date</th>
<th>Action</th>
</tr>

</thead>

<tbody id="historyTable">

</tbody>

</table>

</div>

</div>

</div>


<!-- Details Modal -->

<div class="modal fade" id="detailsModal">

<div class="modal-dialog modal-xl modal-dialog-centered">

<div class="modal-content border-0 shadow">

<div class="modal-header bg-primary text-white">

<h5 class="modal-title">

Payroll Details

</h5>

<button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>

</div>

<div class="modal-body">

<table class="table table-bordered">

<thead>

<tr>

<th>Staff</th>
<th>Basic</th>
<th>Present</th>
<th>Absent</th>
<th>LOP</th>
<th>PF</th>
<th>ESI</th>
<th>Net</th>

</tr>

</thead>

<tbody id="detailsTable">

</tbody>

</table>

</div>

</div>

</div>

</div>
    </div>
</div>


<div class="modal fade" id="payslipModal">

<div class="modal-dialog modal-lg modal-dialog-centered">

<div class="modal-content border-0 shadow">

<div class="modal-header bg-success text-white">

<h5>Payslip</h5>

<button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>

</div>

<div class="modal-body" id="payslipContent">

</div>

<div class="modal-footer">

<button class="btn btn-primary" onclick="printPayslip()">

Print

</button>

<button class="btn btn-success" id="pdfBtn">

Download PDF

</button>

</div>

</div>

</div>

</div>
<script>

function loadHistory()
{

$.get('/payroll/history/data',function(res){

let html='';

res.forEach(row=>{

html+=`

<tr>

<td>${getMonthName(row.payroll_month)}</td>

<td>${row.payroll_year}</td>

<td>
<span class="badge bg-info">${row.run_type}</span>
</td>

<td>${row.created_at}</td>

<td>

<button class="btn btn-sm btn-primary"

onclick="viewDetails(${row.sno})">

View Details

</button>

<button class="btn btn-sm btn-success"

onclick="viewPayslip(${row.entry_id})">

Payslip

</button>

</td>

</tr>

`;

});

$('#historyTable').html(html);

});

}


function viewDetails(runId)
{

$.get('/payroll/history/details/'+runId,function(res){

let html='';

res.forEach(row=>{

html+=`

<tr>

<td>
${row.name}
<br>
<small class="text-muted">${row.staff_code}</small>
</td>

<td>₹${row.basic_salary}</td>

<td>${row.present_days}</td>

<td>${row.absent_days}</td>

<td class="text-danger">
₹${row.lop_amount}
</td>

<td>
₹${row.pf_amount}
</td>

<td>
₹${row.esi_amount}
</td>

<td class="text-success fw-bold">
₹${row.net_salary}
</td>

</tr>

`;

});

$('#detailsTable').html(html);

new bootstrap.Modal(document.getElementById('detailsModal')).show();

});

}


function getMonthName(month)
{

return new Date(0,month-1).toLocaleString('en',{month:'long'});

}


loadHistory();

</script>

<script>

function viewPayslip(entryId)
{

$.get('/payroll/payslip/'+entryId,function(data){

$('#pdfBtn').attr('onclick',

"window.open('/payroll/payslip/pdf/"+entryId+"')");

let html = `

<div class="p-3">

<h4 class="text-center mb-3">
Payslip
</h4>

<div class="row mb-3">

<div class="col-md-6">

<b>${data.name}</b><br>

Staff Code: ${data.staff_code}

</div>

<div class="col-md-6 text-end">

Bank: ${data.bank_name ?? '-'}<br>

Account: ${data.account_number ?? '-'}

</div>

</div>

<table class="table table-bordered">

<tr>
<th>Basic Salary</th>
<td>₹${data.basic_salary}</td>
</tr>

<tr>
<th>Present Days</th>
<td>${data.present_days}</td>
</tr>

<tr>
<th>Absent Days</th>
<td>${data.absent_days}</td>
</tr>

<tr class="text-danger">
<th>LOP Deduction</th>
<td>₹${data.lop_amount}</td>
</tr>

<tr>
<th>PF</th>
<td>₹${data.pf_amount}</td>
</tr>

<tr>
<th>ESI</th>
<td>₹${data.esi_amount}</td>
</tr>

<tr class="table-success">

<th>Net Salary</th>

<td class="fw-bold">
₹${data.net_salary}
</td>

</tr>

</table>

</div>

`;

$('#payslipContent').html(html);

new bootstrap.Modal(document.getElementById('payslipModal')).show();

});

}


function printPayslip()
{

let content = document.getElementById('payslipContent').innerHTML;

let win = window.open();

win.document.write(content);

win.print();

}

</script>
@endsection