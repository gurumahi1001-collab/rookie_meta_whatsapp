@extends('layouts/layoutMaster')

@section('title', 'Payroll Reports')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'],)
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js'])
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<style>
    /*======================================================
            PAYROLL DASHBOARD - PRODUCTION UI
    ======================================================*/
    
    .payroll-card:hover{

        transform:translateY(-6px);

        box-shadow:
        0 15px 45px rgba(37,99,235,.12);

    }

    .payroll-card:hover .icon-box{

        transform:rotate(-8deg) scale(1.08);

    }

    .icon-box{

        transition:.35s;

    }

    .payroll-dashboard{
        --radius:18px;
        --shadow:0 12px 35px rgba(15,23,42,.08);
        --border:#e8edf4;
        --text:#1f2937;
        --muted:#7b8794;
    }

    /* Header */
    .payroll-summary-header{
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:10px;
    }

    .dashboard-title{
        font-size:28px;
        font-weight:700;
        color:#1f2937;
    }

    .dashboard-subtitle{
        color:#7b8794;
        font-size:14px;
        font-weight:500;
    }

    .dashboard-month{
        text-align:right;
    }

    .month-label{
        font-size:12px;
        color:#8b98a5;
        display:block;
    }

    .dashboard-month h5{
        font-weight:700;
        color:#344054;
        margin-top:4px;
    }

    /*================================================*/

    .payroll-card{
        position:relative;
        background:#fff;
        border-radius:18px;
        overflow:hidden;
        border:1px solid var(--border);
        box-shadow:var(--shadow);
        transition:.35s;
        height:100%;
        min-height:250px;
    }

    .payroll-card:hover{
        transform:translateY(-6px);
        box-shadow:
        0 18px 40px rgba(15,23,42,.13);
    }

    /*===========================================*/
    .card-top-border{
        height:5px;
        width:100%;
    }

    .bg-success{
        background:#16a34a;
    }

    .bg-primary{
        background:#2563eb;
    }

    .bg-danger{
        background:#ef4444;
    }

    .bg-purple{
        background:#7c3aed;
    }

    /*===========================================*/

    .card-body-custom{
        padding:22px;
    }

    /*===========================================*/

    .icon-box{
        width:50px;
        height:50px;
        border-radius:12px;
        display:flex;
        justify-content:center;
        align-items:center;
        margin-bottom:18px;
    }

    .icon-box i{
        color:#fff;
        /* font-size:30px; */
    }

    .success{
        background:linear-gradient(135deg,#22c55e,#15803d);
    }

    .primary{
        background:linear-gradient(135deg,#3b82f6,#1d4ed8);
    }

    .danger{
        background:linear-gradient(135deg,#ef4444,#b91c1c);
    }

    .purple{
        background:linear-gradient(135deg,#8b5cf6,#6d28d9);
    }

    /*===========================================*/
    .card-title{
        font-size:14px;
        color:#7b8794;
        font-weight:600;
        letter-spacing:.2px;
    }

    .card-value{
        font-size:34px;
        font-weight:700;
        color:#111827;
        margin-top:6px;
        margin-bottom:14px;
        word-break:break-word;
    }

    .card-label{
        font-size:14px;
        color:#6b7280;
        margin-top:2px;
    }

    /*===========================================*/
    hr{
        margin:16px 0;
        border-color:#edf2f7;
    }

    /*===========================================*/
    .mini-row{
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:10px;
    }

    .mini-row span{
        font-size:13px;
        color:#7b8794;
    }

    .mini-row strong{
        color:#111827;
        font-size:15px;
        font-weight:700;
    }

    /*===========================================*/
    .trend-badge{

        display:inline-flex;

        align-items:center;

        gap:8px;

        padding:8px 14px;

        border-radius:50px;

        backdrop-filter:blur(12px);

        border:1px solid rgba(255,255,255,.4);

        font-size:13px;

        font-weight:700;

    }
    .card-value-success{

        background:

        linear-gradient(
            90deg,
            #111827,
            #15803d
        );

        -webkit-background-clip:text;

        color:transparent;

    }

    .card-value-primary{

        background:

        linear-gradient(
            90deg,
            #111827,
            #2563eb
        );

        -webkit-background-clip:text;

        color:transparent;

    }
    .card-value-danger{

        background:

        linear-gradient(
            90deg,
            #111827,
            #b91c1c
        );

        -webkit-background-clip:text;

        color:transparent;

    }

    .card-value-purple{

        background:

        linear-gradient(
            90deg,
            #111827,
            #7c3aed
        );

        -webkit-background-clip:text;

        color:transparent;

    }

    .trend-badge i{
        font-size:18px;
    }

    /* Positive */
    .trend-up{
        background:#ecfdf3;
        color:#16a34a;
    }

    /* Negative */

    .trend-down{
        background:#fff1f2;
        color:#dc2626;
    }

    /* Neutral */
    .trend-neutral{
        background:#f4f4f5;
        color:#6b7280;
    }

    /*===========================================*/

    .workforce-card{
        background:
        linear-gradient(180deg,#ffffff,#fbfcfd);
    }

    .gross-card{
        background:
        linear-gradient(180deg,#ffffff,#f8fbff);
    }

    .deduction-card{
        background:
        linear-gradient(180deg,#ffffff,#fff9f9);
    }

    .net-card{
        background:
        linear-gradient(180deg,#ffffff,#faf8ff);
    }

    /*===========================================*/

    .payroll-card::after{

        content:'';

        position:absolute;

        width:180px;

        height:180px;

        right:-80px;

        top:-80px;

        border-radius:50%;

        background:

        radial-gradient(

            rgba(37,99,235,.10),

            transparent

        );

    }

    .payroll-card{

        animation:fadeCard .6s ease;

    }

    @keyframes fadeCard{

    from{

    opacity:0;

    transform:translateY(30px);

    }

    to{

    opacity:1;

    transform:none;

    }

    }

    /*===========================================*/
    @media(max-width:1200px){
        .card-value{
            font-size:30px;
        }
    }

    @media(max-width:992px){
        .payroll-card{
            min-height:220px;
        }
        .card-value{
            font-size:28px;
        }

        .icon-box{
            width:56px;
            height:56px;
        }

        .icon-box i{
            font-size:26px;
        }
    }

    @media(max-width:768px){
        .dashboard-title{
            font-size:24px;
        }

        .payroll-summary-header{
            flex-direction:column;
            align-items:flex-start;
            gap:15px;
        }

        .dashboard-month{
            text-align:left;
        }

        .card-value{
            font-size:26px;
        }
    }

    @media(max-width:576px){
        .card-body-custom{
            padding:18px;
        }

        .card-value{
            font-size:24px;
        }

        .icon-box{
            width:50px;
            height:50px;
        }

        .icon-box i{
            font-size:22px;
        }
    }
</style>
<style>

    .salary-company-label{
        display:inline-block;
        margin-top:4px;
        padding:4px 10px;
        font-size:12px;
        font-weight:600;
        color:#fff;
        border-radius:4px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
        max-width:140px;
        line-height:1.4;
    }
    /* Button hover */
    .retry-btn {
        transition: all 0.2s ease;
    }

    .retry-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Success pop */
    .success-pop {
        animation: pop 0.4s ease;
    }

    @keyframes pop {
        0% {
            transform: scale(0.5);
            opacity: 0;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<style>
    .selected-month-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 14px;
        border-radius: 20px;
        background: #f1f3f5;
        color: #333;
        font-weight: 600;
        font-size: 13px;
        transition: all 0.3s ease;
    }

    /* Glow + highlight animation */
    .selected-month-badge.active {
        background: linear-gradient(135deg, #4e73df, #6f42c1);
        color: #fff;
        box-shadow: 0 0 12px rgba(78, 115, 223, 0.5);
    }

    /* subtle pulse */
    .selected-month-badge.active {
        animation: pulseGlow 1s ease;
    }

    @keyframes pulseGlow {
        0% {
            box-shadow: 0 0 0 rgba(78, 115, 223, 0.2);
        }

        50% {
            box-shadow: 0 0 15px rgba(78, 115, 223, 0.6);
        }

        100% {
            box-shadow: 0 0 10px rgba(78, 115, 223, 0.4);
        }
    }
</style>
<style>

    .payroll-table-wrapper{
        overflow-x:auto;
        overflow-y:auto;
        max-width:100%;
    }
    .table-responsive{
        overflow-x:auto;
    }

    .sticky_table{
        min-width:1700px;
        border-collapse:separate;
        border-spacing:0;
    }

    .sticky_table th,
    .sticky_table td{
        white-space:nowrap;
        min-width:120px;
        vertical-align:middle;
    }

    .sticky_table th:first-child,
    .sticky_table td:first-child{
        position:sticky;
        left:0;
        min-width:260px;
        background:#fff;
        z-index:30;
    }

    .sticky_table thead th:first-child{
        background:#ab2b22;
        color:#fff;
        z-index:50;
    }

    .sticky_table th:last-child,
    .sticky_table td:last-child{
        position:sticky;
        right:0;
        width:140px;
        background:#fff;
        z-index:30;
    }

    .sticky_table thead th:last-child{
        background:#ab2b22;
        color:#fff;
    }

    .sticky_table th:nth-last-child(2),
    .sticky_table td:nth-last-child(2){
        position:sticky;
        right:140px;
        width:140px;
        background:#fff;
        z-index:30;
    }

    .sticky_table thead th:nth-last-child(2){
        background:#ab2b22;
        color:#fff;
    }


</style>

<style>
    .attendance-cards .card-attendance {
        width: 150px;
        /* fixed width for all cards */
        min-width: 150px;
        max-width: 150px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0.5rem;
        /* smaller padding */
        gap: 0.25rem;
    }

    .attendance-cards .percent-value {
        font-size: 1.2rem;
        /* reduced font */
        line-height: 1.2;
        word-wrap: break-word;
    }

    .avatar-frame {
        width: 110px;
        height: 110px;
        border-radius: 50%;
        padding: 4px;
        box-shadow: 0 15px 25px -8px rgba(235, 93, 37, 0.3);
    }

    .avatar-inner {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .avatar-inner img {
        width: 100%;
        height: 100%;
        object-fit: fill;
    }
</style>

<style>
    .team-card {
        width: 180px;
        background-color: #fff;
        border-radius: 0.4rem;
        border: 1px solid #e0e0e0;
        transition: transform 0.2s, box-shadow 0.2s;
        cursor: pointer;
    }


    .role-indicator {
        width: 40px;
        height: 40px;
    }

    .role-abbr {
        font-size: 0.8rem;
    }

    .team-info .fs-6 {
        margin-bottom: 0.1rem;
        font-size: 0.95rem !important;
    }

    .team-info .fs-8 {
        font-size: 0.75rem;
        color: #6c757d;
    }
</style>
<style>
    .attendance-badge {
        cursor: pointer;
    }

    .attendance-tooltip {
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%) scale(0.95);
        background: #ffffff;
        border-radius: 12px;
        padding: 12px;
        width: 220px;
        font-size: 12px;
        opacity: 0;
        visibility: hidden;
        transition: all 0.25s ease;
        z-index: 1000;
        border: 1px solid #eee;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }

    .attendance-badge:hover .attendance-tooltip {
        opacity: 1;
        visibility: visible;
        transform: translateX(-50%) scale(1);
    }

    /* Header */
    .tooltip-header {
        font-weight: 600;
        font-size: 13px;
        margin-bottom: 8px;
        color: #333;
        border-bottom: 1px dashed #eee;
        padding-bottom: 5px;
    }

    /* Rows */
    .tooltip-row.fancy {
        display: flex;
        justify-content: space-between;
        padding: 4px 0;
        transition: 0.2s;
    }

    .tooltip-row.fancy:hover {
        background: #f8f9fa;
        border-radius: 6px;
        padding-left: 6px;
        padding-right: 6px;
    }

    .tooltip-row .label {
        color: #6c757d;
    }

    .tooltip-row .value {
        font-weight: 600;
        color: #28a745;
    }
</style>
<style>
    .mdi-loading {
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        100% {
            transform: rotate(360deg);
        }
    }
</style>
<style>
    .payroll-action-btn {
        transition: all .25s ease;
    }

    .payroll-action-btn:hover {
        transform: translateY(-2px);
    }

    .verify-summary-card {
        background: #f8f9fa;
        border-radius: 18px;
        padding: 25px;
        border: 1px solid #edf0f2;
    }

    .verify-icon-box,
    .freeze-icon-box {
        width: 70px;
        height: 70px;
        border-radius: 20px;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
            <h5 class="card-title mb-1">Payroll Reports</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element mb-1 gap-2 text-center">
           
            <div class="d-flex justify-content-end align-items-center flex-wrap gap-2 mb-1">
                <div id="payrollWorkflowStatus"></div>
                <button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#payrollExportModal" onclick = "openBankMonth()">
                    <i class="mdi mdi-bank me-1"></i>Export
                </button>
                <button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#payrollCommonExportModal" onclick = "openCommonMonth()">
                    <i class="mdi mdi-cash-multiple me-1"></i>Export
                </button>
                <!-- <button type="button" class="btn btn-primary " onclick="exportExcel()" id="export_btn" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Export Excel">
                    <span class="mdi mdi-export"></span>
                </button> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>
                <div class="d-flex flex-row align-items-center justify-content-between gap-2">
                    <input type="text" id="global_date_picker" class="form-control w-100px" value="<?php echo date('M-Y') ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-2">
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Company<span class="text-danger">*</span></label>
                    <select id="salary_company" name="salary_company" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="business_div">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Type<span class="text-danger">*</span></label>
                    <select id="salary_type_fill" name="salary_type_fill" class="select3 form-select">
                        <option value="">All</option>
                        <option value="1">Cash</option>
                        <option value="2">Bank</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Date<span class="text-danger">*</span></label>
                    <select id="salary_date_fill" name="salary_date_fill" class="select3 form-select">
                        <option value="">All</option>
                        <option value="1">5th</option>
                        <option value="2">15th</option>
                    </select>
                </div>

                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date of Joining</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                        <option value="0_2_months">0-2 Months</option>
                        <option value="2_4_months">2-4 Months</option>
                        <option value="4_6_months">4-6 Months</option>
                        <option value="gt_6_months">Greater than 6 Months</option>
                        <option value="6_12_months">6-12 Months</option>
                        <option value="gt_1_year">Greater than 1 Year</option>
                        <option value="1_2_years">1-2 Years</option>
                        <option value="gt_2_years">Greater than 2 Years</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>

                <div class="col-lg-4 mb-2" id="">
                    <label for="exit_staff_fill" class="text-black mb-1 fs-6 fw-semibold">Exit Staff</label>
                    <input type="checkbox" value="1" id="exit_staff_fill" class="form-check-input ">
                </div>
                <div class="col-lg-4 mt-4" id="">
                    <div>
                        <label for="only_bank_fill" class="text-black mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Without Variable">Only Bank Amount</label>
                        <input type="checkbox" value="1" id="only_bank_fill" class="form-check-input ">
                    </div>
                    <div>
                        <label for="only_variable_fill" class="text-black mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Only Variable Staff">Only Variable Staff</label>
                        <input type="checkbox" value="1" id="only_variable_fill" class="form-check-input ">
                    </div>
                </div>
            </div>

            

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_general/payroll') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row pt-2">
            <div class="row payroll-dashboard">
                <!-- Workforce -->
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="payroll-card workforce-card">
                        <div class="card-top-border bg-success"></div>
                        <div class="card-body-custom">
                            <div class="card-content">
                                <div class="d-flex gap-1 align-items-center">
                                    <div class="icon-box success">
                                        <i class="mdi mdi-account-group fs-3"></i>
                                    </div>
                                    <div class="card-title">Workforce</div>
                                </div>
                                <div class="card-value card-value-success">
                                    <span id="totalEmployees">0</span>
                                </div>
                                <div class="card-label">Total Employees</div>
                                <hr>
                                <div class="mini-row">
                                    <span>Fixed Payroll</span>
                                    <strong id="totalFixedGrossSalary">₹0</strong>
                                </div>
                                <div class="mini-row">
                                    <span> Active Payroll</span>
                                    <strong>100%</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Gross Payroll -->
                <div class="col-xl-3 col-lg-6 col-md-6 position-relative attendance-badge">
                    <div class="payroll-card gross-card">
                        <div class="card-top-border primary"></div>
                        <div class="card-body-custom">
                            
                            <div class="card-content">
                                <div class="d-flex gap-1 align-items-center">
                                    <div class="icon-box primary">
                                        <i class="mdi mdi-cash-multiple fs-3"></i>
                                    </div>
                                    <div class="card-title">Gross Payroll</div>
                                </div>
                                
                                <div class="card-value card-value-primary " id="totalGrossSalary">₹0</div>
                                <div class="trend-badge" id="grossVariationBadge">
                                    <i class="mdi mdi-trending-up"></i>
                                    <span id="grossVariation">0%</span>
                                </div>
                                <hr>
                                <div class="mini-row">
                                    <span>Previous Month</span>
                                    <strong id="previousgross">₹0</strong>
                                </div>

                                <div class="mini-row">
                                    <span>Difference</span>
                                    <strong id="grossDifference">₹0</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="attendance-tooltip shadow-sm" id="grossSalaryTooltip">
                        <div class="tooltip-header">Earnings Breakdown</div>
                        <div id="earningsBreakdown"></div>
                    </div>
                    
                </div>
                <!-- Payroll Deductions -->
                <div class="col-xl-3 col-lg-6 col-md-6 position-relative attendance-badge">
                    <div class="payroll-card deduction-card">
                        <div class="card-top-border bg-danger"></div>
                        <div class="card-body-custom">
                            
                            <div class="card-content">
                                <div class="d-flex gap-1 align-items-center">
                                    <div class="icon-box danger">
                                        <i class="mdi mdi-cash-minus fs-3"></i>
                                    </div>
                                    <div class="card-title">Payroll Deductions</div>
                                </div>
                                
                                <div class="card-value card-value-danger" id="totalDeduction"> ₹0</div>
                                <div class="trend-badge" id="deductionVariationBadge">
                                    <i class="mdi mdi-trending-down"></i>
                                    <span id="deductionVariation">0%</span>
                                </div>
                                <hr>
                                <div class="mini-row">
                                    <span>Previous Month</span>
                                    <strong id="previousdeduction">₹0</strong>
                                </div>

                                <div class="mini-row">
                                    <span> Difference</span>
                                    <strong id="deductionDifference"> ₹0</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="attendance-tooltip shadow-sm" id="deductionTooltip">
                        <div class="tooltip-header">Deductions Breakdown</div>
                        <div id="deductionsBreakdown"></div>
                    </div>
                </div>
                <!-- Net Payroll -->
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="payroll-card net-card">
                        <div class="card-top-border bg-purple"></div>
                        <div class="card-body-custom">
                            
                            <div class="card-content">
                                <div class="d-flex gap-1 align-items-center">
                                    <div class="icon-box purple">
                                        <i class="mdi mdi-wallet fs-3"></i>
                                    </div>
                                    <div class="card-title">Net Payroll</div>
                                </div>
                                
                                <div class="card-value card-value-purple" id="totalNetSalary">₹0</div>
                                <div class="trend-badge" id="netVariationBadge">
                                    <i class="mdi mdi-trending-up"></i>
                                    <span id="netVariation">0%</span>
                                </div>
                                
                                <hr>
                                <div class="mini-row">
                                    <span>Previous Month</span>
                                    <strong id="previousnet">₹0</strong>
                                </div>
                                <div class="mini-row">
                                    <span>Difference</span>
                                    <strong id="netDifference">₹0</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-lg-4">
                <div class="row">

                </div>
            </div> -->
            <!-- <div class="col-lg-8 attendance-cards d-flex align-items-center justify-content-end gap-2">
                <div class="d-flex flex-column gap-1 mb-0 border border-success p-2 rounded bg-label-success text-center card-attendance">
                    <label class="fw-bold text-black percent-value" id="totalEmployees">0</label>
                    <label class="text-black fw-semibold fs-8">Total Staff</label>
                </div>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-warning p-2 rounded bg-label-warning text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalFixedGrossSalary">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Total Gross Salary</label>
                    </div>
                </span>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-warning p-2 rounded bg-label-warning text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalGrossSalary">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Total Payroll Earnings</label>
                    </div>
                    <div class="attendance-tooltip shadow-sm" id="grossSalaryTooltip">
                        <div class="tooltip-header">Earnings Breakdown</div>
                        <div id="earningsBreakdown"></div>
                    </div>
                </span>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-danger p-2 rounded bg-label-danger text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalDeduction">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Payroll Deductions</label>
                    </div>
                    <div class="attendance-tooltip shadow-sm" id="deductionTooltip">
                        <div class="tooltip-header">Deductions Breakdown</div>
                        <div id="deductionsBreakdown"></div>
                    </div>
                </span>
                <div class="d-flex flex-column gap-1 mb-0 border border-info p-2 rounded bg-label-info text-center card-attendance">
                    <label class="fw-bold text-black percent-value" id="totalNetSalary">₹ 0</label>
                    <label class="text-black fw-semibold fs-8">Total Net Salary</label>
                </div>
            </div> -->
        </div>
        <div class="row mt-4">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mt-2">
                <div class="table-responsive payroll-table-wrapper">
                    <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                                <th>Staff</th>
                                <th>Gross</th>
                                <th>On Duty</th>
                                <th>Incentive</th>
                                <th>Variable</th>
                                <th>LOP Days</th>
                                <th>LOP</th>
                                <th>PF</th>
                                <th>ESI</th>
                                <th>PT</th>
                                <th>TDS</th>
                                <th>Deductions</th>
                                <th class="">Net Salary</th>
                            </tr>
                        </thead>
                        <!-- <tbody id="payrollTable" class="text-black fw-semibold fs-7 "></tbody> -->
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                

                            </tr>
                        </tbody>

                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ALTER TABLE `egc_payslip_template` ADD `letter_head_image` TEXT NULL AFTER `payslip_template`; -->

<div class="modal fade" id="payrollExportModal" tabindex="-1"  aria-labelledby="payrollExportModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1 mb-2">
                <div class="">
                    <div class="d-flex align-items-center gap-4">

                        <div>
                            <span class="modal-title fw-bold mb-1 fs-4 text-black">
                                <i class="mdi mdi-file-export-outline me-2 fs-4 text-black"></i>
                                Export Bank Payroll Report - <span id="bank_month_label" class="badge bg-label-info rounded"></span>
                            </span>

                            <!-- <small class="opacity-75">
                                Export Bank payroll register in Excel, PDF or Word format.
                            </small> -->

                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div class="row">
                    <!-- LEFT SIDE -->
                    <div class="col-lg-8">
                        <div class="card border">
                            <div class="card-header ">
                                <h5 class="mb-0 fw-bold">Company Bank & Cheque Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Payroll Month -->
                                    <!-- <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Payroll Month</label>
                                        <input type="text" id="export_month" class="form-control this_month_dt_fill" value="{{ date('M-Y') }}" onchange="loadPayrollBankDetails()">
                                    </div> -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Salary Date</label>
                                        <select id="salary_date_fill_custm"class="select3 form-select">
                                            <option value="1">5th</option>
                                            <option value="2">15th</option>
                                            <option value="">All</option>
                                        </select>
                                    </div>
                                    <!-- Salary Company -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Salary Company</label>
                                        <select id="salary_company_custm" class="select3 form-select" onchange="loadPayrollBankDetails()">
                                            <option value="">All</option>
                                            @foreach($company_list as $company)
                                            <option value="{{$company->sno}}">
                                                {{$company->company_name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                   
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Cheque Number</label>
                                        <input type="text" id="cheque_no" class="form-control" placeholder="Enter Cheque Number">
                                    </div>
                                  
                                </div>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Company Bank Account</label>
                                        <select id="company_bank_id" class="form-select select3">
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Bank Name</label>
                                        <input type="text" id="bank_name" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Branch</label>
                                        <input type="text" id="bank_branch" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Account Holder</label>
                                        <input type="text" id="account_holder" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Account Number</label>
                                        <input type="text" id="current_account" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">IFSC Code</label>
                                        <input type="text" id="ifsc_code" class="form-control" readonly>
                                    </div>
                                    

                                </div>
                                <div class="text-end mt-2">
                                    <button type="button" class="btn btn-warning"  onclick="saveChequeDetails()">
                                        <i class="mdi mdi-content-save"></i>
                                            Update Cheque
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <!-- RIGHT SIDE -->
                    <div class="col-lg-4">
                        <div class="card border">
                            <div class="card-header ">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0 fw-bold">Export Settings</h5>
                                    <span class="badge bg-label-info ">Bank</span>
                                </div>
                                <input type="hidden" id="salary_type_fill_custm" value="2">
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <label class="fw-semibold d-block mb-3">Export Format</label>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="export_format" value="pdf" checked>
                                        <label class="form-check-label">PDF (.pdf)</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="export_format" value="excel" >
                                        <label class="form-check-label">Excel (.xlsx)</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="export_format" value="docx">
                                        <label class="form-check-label">Word (.docx)</label>
                                    </div>
                                </div>
                                <hr>
                                
                                <!-- <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="exit_staff_fill">
                                    <label class="form-check-label">
                                        Include Exit Staff
                                    </label>
                                </div> -->
                                

                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="only_bank_fill_custm" checked>
                                    <label class="form-check-label">
                                        Only Bank Amount
                                    </label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="exit_staff_fill_custm">
                                    <label class="form-check-label fw-semibold">
                                        Include Exit Staff <span class="badge bg-label-primary rounded" id="exit_staff_count_label">00</span>
                                    </label>
                                </div>

                                <div id="exitStaffContainer" class="d-none">
                                    <label class="fw-bold mb-2">
                                        Select Exit Staff
                                    </label>

                                    <div id="exitStaffList"
                                        class="border rounded p-3"
                                        style="max-height:320px;overflow-y:auto;background:#fafafa;">
                                    </div>
                                </div>

                                <!-- <div class="alert alert-info mt-4 mb-0">
                                    <small>
                                        <strong>Note:</strong>
                                        Excel is recommended for payroll processing.
                                    </small>
                                </div> -->

                                <div class=" mt-4">
                                    <button type="button" class="btn btn-primary text-end" onclick="exportPayroll()">
                                        <i class="mdi mdi-file-export-outline me-1"></i> Bank Payroll
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<div class="modal fade" id="payrollCommonExportModal" tabindex="-1"  aria-labelledby="payrollCommonExportModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1 mb-2">
                <div class="">
                    <div class="d-flex align-items-center gap-4">

                        <div>
                            <span class="modal-title fw-bold mb-1 fs-4 text-black">
                                <i class="mdi mdi-file-export-outline me-2 fs-4"></i>
                                Export Payroll Report - <span id="common_month_label" class="badge bg-label-info rounded"></span>
                            </span>

                            <!-- <small class="opacity-75">
                                Export payroll register in Excel, PDF or Word format.
                            </small> -->

                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div class="row">
                    <!-- LEFT SIDE -->
                    <div class="col-lg-8">
                        <div class="card border">
                            <div class="card-header ">
                                <h5 class="mb-0 fw-bold">Filter</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <!-- Payroll Month -->
                                    <!-- <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Payroll Month</label>
                                        <input type="text" id="export_month_common" class="form-control this_month_dt_fill" value="{{ date('M-Y') }}" >
                                    </div> -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Salary Type</label>
                                        <select id="salary_type_fill_common" name="salary_type_fill" class="select3 form-select">
                                            <option value="">All</option>
                                            <option value="1">Cash</option>
                                            <option value="2">Bank</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Salary Date</label>
                                        <select id="salary_date_fill_common"class="select3 form-select">
                                            <option value="">All</option>
                                            <option value="1">5th</option>
                                            <option value="2">15th</option>
                                        </select>
                                    </div>
                                    <!-- Salary Company -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Salary Company</label>
                                        <select id="salary_company_common" class="select3 form-select" >
                                            <option value="">All</option>
                                            @foreach($company_list as $company)
                                            <option value="{{$company->sno}}">
                                                {{$company->company_name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="form-check form-switch mt-4">
                                            <input class="form-check-input" type="checkbox" id="only_bank_fill_common" >
                                            <label class="form-check-label">
                                                Only Bank Amount
                                            </label>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="only_variable_fill_common" >
                                            <label class="form-check-label">
                                                Only Variable Staff
                                            </label>
                                        </div>
                                    </div>

                                    
                                                                    
                                </div>
                                
                                
                            </div>
                        </div>
                        
                    </div>

                    <!-- RIGHT SIDE -->
                    <div class="col-lg-4">
                        <div class="card border">
                            <div class="card-header ">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0 fw-bold">Export Settings</h5>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="mb-4">
                                    <label class="fw-semibold d-block mb-3">Export Format</label>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="common_export_format" value="full" checked>
                                        <label class="form-check-label">Full View</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="common_export_format" value="pdf">
                                        <label class="form-check-label">PDF (.pdf)</label>
                                    </div>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="common_export_format" value="excel" >
                                        <label class="form-check-label">Excel (.xlsx)</label>
                                    </div>
                                    <!-- <div class="form-check">
                                        <input class="form-check-input" type="radio" name="common_export_format" value="docx">
                                        <label class="form-check-label">Word (.docx)</label>
                                    </div> -->
                                </div>
                                <!-- <hr> -->
                                
                                <!-- <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="exit_staff_fill">
                                    <label class="form-check-label">
                                        Include Exit Staff
                                    </label>
                                </div> -->
                                

                                

                                <!-- <div class="alert alert-info mt-4 mb-0">
                                    <small>
                                        <strong>Note:</strong>
                                        Excel is recommended for payroll processing.
                                    </small>
                                </div> -->

                                <div class=" mt-2">
                                    <button type="button" class="btn btn-primary text-end" onclick="exportCommonPayroll()">
                                        <i class="mdi mdi-file-export-outline me-1"></i> Export Payroll
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="breakdown_modal">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="fw-bold">Payroll Breakdown</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <!-- EMPLOYEE INFO -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body d-flex justify-content-between">
                        <div class="d-flex gap-3 align-items-center">
                            <div class="avatar-frame bg-primary">
                                <div class="avatar-inner">
                                    <img src="" alt="staff Image" id="emp_image">
                                </div>
                            </div>
                            <div>
                                <div class="name-title flex-grow-1">
                                    <h4 id="emp_name">Jack</h4>
                                    <div class="d-flex flex-wrap gap-3 align-items-center mt-1">
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-briefcase-outline"></i> <span id="emp_job_role">Position</span> </span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-email-outline"></i> <span id="emp_email">abc@gmail.com</span></span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-phone-outline"></i> <span id="emp_mobile">99989999999</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="text-end d-flex flex-column justify-content-between">
                            <div>
                                <div>Gross: ₹ <span id="emp_basic"></span></div>
                                <div class="fw-bold text-primary">
                                    Net: ₹ <span id="emp_net"></span>
                                </div>
                            </div>
                            <input type="hidden" name="" id="hidden_entry_encrypt">
                            <div id="payslip_btn_saved" class="d-none">
                                <span class="mdi mdi-download-circle-outline fs-1 fw-bold text-success cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download PaySlip" onclick="printPayslip()"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ATTENDANCE -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-primary mb-2">Attendance Summary</h6>

                        <div class="row text-center">

                            <div class="col">
                                <div class="fw-bold text-success" id="present"></div>
                                <small>Present</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-danger" id="absent"></div>
                                <small>Absent</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-warning" id="late"></div>
                                <small>Late</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-info" id="lop"></div>
                                <small>LOP Days</small>
                            </div>

                        </div>

                    </div>
                </div>

                <!-- COMPONENTS -->
                <div class="row">

                    <!-- Earnings -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-success">
                                Earnings
                            </div>
                            <div class="card-body" id="earning_body"></div>
                        </div>
                    </div>

                    <!-- Deductions -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-danger">
                                Deductions
                            </div>
                            <div class="card-body" id="deduction_body"></div>
                        </div>
                    </div>

                    <!-- Employer -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-info">
                                Employer Contribution
                            </div>
                            <div class="card-body" id="employer_body"></div>
                        </div>
                    </div>

                </div>

                <!-- RULES -->
                <!-- <div class="card mt-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-danger">Rule Breakdown</h6>

                        <div id="rule_body"></div>

                    </div>
                </div> -->

                <!-- FINAL SUMMARY -->
                <div class="card mt-3 shadow-sm bg-label-primary">
                    <div class="card-body">

                        <div class="d-flex justify-content-between">
                            <span>Total Earnings</span>
                            <span id="total_earn"></span>
                        </div>

                        <div class="d-flex justify-content-between">
                            <span>Total Deductions</span>
                            <span id="total_ded"></span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Net Salary</span>
                            <span id="net_salary_final"></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Employer Contribution</span>
                            <span id="total_employer"></span>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="saved_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5>Saved Payroll Details</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>


            <div class="modal-body">

                <!-- EMPLOYEE INFO -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body d-flex justify-content-between">
                        <div class="d-flex gap-3 align-items-center">
                            <div class="avatar-frame bg-primary">
                                <div class="avatar-inner">
                                    <img src="" alt="staff Image" id="emp_image_saved">
                                </div>
                            </div>
                            <div>
                                <div class="name-title flex-grow-1">
                                    <h4 id="emp_name_saved">Jack</h4>
                                    <div class="d-flex flex-wrap gap-3 align-items-center mt-1">
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-briefcase-outline"></i> <span id="emp_job_role_saved">Position</span> </span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-email-outline"></i> <span id="emp_email_saved">abc@gmail.com</span></span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-phone-outline"></i> <span id="emp_mobile_saved">99989999999</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>



                        
                        <div class="text-end d-flex flex-column justify-content-between">
                            <div>
                                <div>Gross: ₹ <span id="emp_basic_saved"></span></div>
                                <div class="fw-bold text-primary">
                                    Net: ₹ <span id="emp_net_saved"></span>
                                </div>
                            </div>
                            <div>
                                <span class="mdi mdi-download-circle-outline fs-1 fw-bold text-success cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download PaySlip" onclick="printPayslip()"></span>
                            </div>
                        </div>


                    </div>
                </div>

                <!-- ATTENDANCE -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-primary mb-2">Attendance Summary</h6>

                        <div class="row text-center">

                            <div class="col">
                                <div class="fw-bold text-success" id="present_saved"></div>
                                <small>Present</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-danger" id="absent_saved"></div>
                                <small>Absent</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-warning" id="late_saved"></div>
                                <small>Late</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-info" id="lop_saved"></div>
                                <small>LOP Days</small>
                            </div>

                        </div>

                    </div>
                </div>

                <!-- COMPONENTS -->
                <div class="row">

                    <!-- Earnings -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-success">
                                Earnings
                            </div>
                            <div class="card-body" id="earning_body_saved"></div>
                        </div>
                    </div>

                    <!-- Deductions -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-danger">
                                Deductions
                            </div>
                            <div class="card-body" id="deduction_body_saved"></div>
                        </div>
                    </div>

                    <!-- Employer -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-info">
                                Employer Contribution
                            </div>
                            <div class="card-body" id="employer_body_saved"></div>
                        </div>
                    </div>

                </div>

                <!-- RULES -->
                <!-- <div class="card mt-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-danger">Rule Breakdown</h6>

                        <div id="saved_body"></div>

                    </div>
                </div> -->

                <!-- FINAL SUMMARY -->
                <div class="card mt-3 shadow-sm bg-label-primary">
                    <div class="card-body">

                        <div class="d-flex justify-content-between">
                            <span>Total Earnings</span>
                            <span id="total_earn_saved"></span>
                        </div>

                        <div class="d-flex justify-content-between">
                            <span>Total Deductions</span>
                            <span id="total_ded_saved"></span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Net Salary</span>
                            <span id="net_salary_final_saved"></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Employer Contribution</span>
                            <span id="total_employer_saved"></span>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>


<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    let currentPage = 1;
    let currentMonth = @json(date('M-Y'));
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);
    let payrollData = [];
    let previewData = [];
    let currentPayrollProcessId = null;



    $(document).ready(function() {

        $('#global_date_picker').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        }).on('changeDate', function() {
            currentMonth = $(this).val();
            loadThemes(1);
        });

        $('#export_month').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        })
        $('#export_month_common').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        })

    });


    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    // function getExperienceDuration(joinDate) {
    //     if (!joinDate) return '-';

    //     const start = new Date(joinDate);
    //     const now = new Date();

    //     if (isNaN(start)) return '-'; // invalid date safeguard

    //     // Determine direction
    //     const isFuture = start > now;
    //     const earlier = isFuture ? now : start;
    //     const later = isFuture ? start : now;

    //     // Calculate raw differences
    //     let years = later.getFullYear() - earlier.getFullYear();
    //     let months = later.getMonth() - earlier.getMonth();
    //     let days = later.getDate() - earlier.getDate();

    //     // Adjust days
    //     if (days < 0) {
    //         const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
    //         days += prevMonth.getDate();
    //         months--;
    //     }

    //     // Adjust months
    //     if (months < 0) {
    //         months += 12;
    //         years--;
    //     }

    //     // Build result text
    //     let result = '';
    //     if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
    //     if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
    //     if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

    //     if (!result.trim()) result = '0 days';

    //     result = result.trim();

    //     // Add "In" or "Ago"
    //     if (isFuture) {
    //         result = `In ${result}`;
    //     } else if (result !== '0 days') {
    //         // result += ' ago';
    //         result += '';
    //     }

    //     return result;
    // }

    function getExperienceDuration(
        joinDate,
        status = 0,
        staffLastDate = null,
        noticeEndDate = null
    ) {

        if (!joinDate) return '-';
        const start = new Date(joinDate);
        if (isNaN(start)) return '-';
        /*
        |--------------------------------------------------------------------------
        | END DATE BASED ON STATUS
        |--------------------------------------------------------------------------
        */
        let endDate = new Date();
        /*
        |--------------------------------------------------------------------------
        | NOTICE PERIOD STAFF
        |--------------------------------------------------------------------------
        */
        if (
            status == 4 &&
            noticeEndDate
        ) {

            endDate = new Date(noticeEndDate);
        }
        /*
        |--------------------------------------------------------------------------
        | EXIT STAFF
        |--------------------------------------------------------------------------
        */
        else if (
            [5, 6, 7].includes(parseInt(status)) &&
            staffLastDate
        ) {

            endDate = new Date(staffLastDate);
        }
        /*
        |--------------------------------------------------------------------------
        | INVALID DATE SAFEGUARD
        |--------------------------------------------------------------------------
        */
        if (isNaN(endDate)) {
            endDate = new Date();
        }
        /*
        |--------------------------------------------------------------------------
        | DETERMINE DIRECTION
        |--------------------------------------------------------------------------
        */
        const isFuture = start > endDate;
        const earlier = isFuture ? endDate : start;
        const later = isFuture ? start : endDate;
        /*
        |--------------------------------------------------------------------------
        | CALCULATE DIFFERENCE
        |--------------------------------------------------------------------------
        */
        let years =
            later.getFullYear()
            - earlier.getFullYear();
        let months =
            later.getMonth()
            - earlier.getMonth();
        let days =
            later.getDate()
            - earlier.getDate();
        /*
        |--------------------------------------------------------------------------
        | ADJUST DAYS
        |--------------------------------------------------------------------------
        */
        if (days < 0) {
            const prevMonth =
                new Date(
                    later.getFullYear(),
                    later.getMonth(),
                    0
                );
            days += prevMonth.getDate();
            months--;
        }
        /*
        |--------------------------------------------------------------------------
        | ADJUST MONTHS
        |--------------------------------------------------------------------------
        */
        if (months < 0) {
            months += 12;
            years--;
        }
        /*
        |--------------------------------------------------------------------------
        | BUILD RESULT
        |--------------------------------------------------------------------------
        */
        let result = '';
        if (years > 0) {
            result += `${years} yr${years > 1 ? 's' : ''} `;
        }
        if (months > 0) {
            result += `${months} month${months > 1 ? 's' : ''} `;
        }
        if (days > 0) {
            result += `${days} day${days > 1 ? 's' : ''}`;
        }
        if (!result.trim()) {
            result = '0 day';
        }
        return result.trim();
    }

    function buildRow(item, index) {

        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        var dataParoll = typeof item.dataParoll === 'string' ? JSON.parse(item.dataParoll) : item.dataParoll;

        let staff_image = '';
        if (item.isStaffImage) {
            if (data.staff_image && data.staff_image.trim() !== '') {
                if (data.company_type == 1) {
                    staff_image = `staff_images/Management/${data.staff_image}`;
                } else {
                    staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;

        let payslipBtn = item.is_saved

            ?
            `
            <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                data-bs-target="#breakdown_modal"
                data-bs-toggle="tooltip" data-bs-placement="bottom"
                title="View" onclick="viewBreakdown(${item.sno})">
                <i class="mdi mdi-eye fs-3 text-black"></i>
            </button>`

            :
            `
            <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                data-bs-target="#breakdown_modal"
                data-bs-toggle="tooltip" data-bs-placement="bottom"
                title="View" onclick="viewBreakdown(${item.sno})" >
                <i class="mdi mdi-eye fs-3 text-black"></i>
            </button>`;

        let existStatus = '';
        let  existColor = '';
        let  last_date = '';
        switch (item.staff_status) {
            case 4:
                existStatus = 'Notice Period';
                existColor = 'bg-secondary';
                last_date = item.notice_end_date ? formatDateCommon(item.notice_end_date) : '';
                break;
            case 5: 
                existStatus = 'Relive';
                existColor = 'bg-success';
                last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
            case 6: 
                existStatus = 'Abscond';
                existColor = 'bg-warning';
                  last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
            case 7: 
                existStatus = 'Terminate';
                existColor = 'bg-danger';
                  last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
        }

        return `
            <tr>
                <td >
                    <!-- Left colored bar for company -->
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || '#6c757d'};"></div>

                    <div class="d-flex align-items-center ps-2">
                        <!-- Staff Image -->
                        <div class="symbol symbol-40px me-3 ">
                            <div class="image-input image-input-circle">
                                <img src="${staff_image}" 
                                    alt="user-avatar"  
                                    class="rounded-circle"
                                    style="width:40px; height:40px; object-fit:fill;"
                                    onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}${data.gender == 1 ? 'user_2.png' : 'user_7.png'}';"/>
                            </div>
                        </div>

                        <!-- Staff Info -->
                        <div class="d-flex flex-column flex-grow-1">
                            <!-- Name + Gender Icon -->
                            <div class="d-flex align-items-center flex-wrap">
                                <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                                    data-bs-toggle="tooltip" title="${item.name}">
                                    ${item.name}
                                </span>

                                ${data.gender == 1 
                                    ? `<i class="mdi mdi-face-man text-info fs-7" data-bs-toggle="tooltip" title="Male"></i>` 
                                    : `<i class="mdi mdi-face-woman text-pink fs-7" data-bs-toggle="tooltip" title="Female"></i>`
                                }
                            </div>

                            <!-- Employee ID + Nickname -->
                            <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                                <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${data.staff_code  || '-'}</span>
                                <span class="text-primary" data-bs-toggle="tooltip" title="Nickname">${data.nick_name || '-'}</span>
                            </div>

                            <!-- Company Badge -->
                            <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                                style="background-color:${item.company_base_color || '#6c757d'}; color:#fff; max-width:150px;"
                                data-bs-toggle="tooltip" title="${data.company_name || '-'}">
                                ${data.company_name || '-'}
                            </span>

                            <div class="">
                                <div class="d-flex align-items-start justify-content-center flex-column mb-1">
                                    <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                                    ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                                    </label>
                                    <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                                    ${data.date_of_joining
                                            ? getExperienceDuration(
                                                data.date_of_joining,
                                                item.staff_status,
                                                item.staff_last_date,
                                                item.notice_end_date
                                            )
                                            : '0 Day'}
                                    </label>
                                </div>
                                <div>
                                    <label class="badge ${existColor} fs-7 text-black fw-bold mb-2">
                                    ${existStatus}
                                    </label>
                                    <span class="d-block">
                                        <span class="text-danger" data-bs-toggle="tooltip" title="Last Date">${last_date || ''}</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <label class="badge bg-label-success mb-2 text-nowrap">
                        <span class="mdi mdi-currency-rupee   fs-8"></span>
                        <span class="fs-7">${data.basic_salary ? new Intl.NumberFormat('en-IN').format(data.basic_salary) :'0'}</span>
                    </label>
                    <div>
                        <label class="badge bg-label-primary text-nowrap">
                            <span class="fs-7">
                                ${
                                    data.salary_type == 1 ? 'Cash' :
                                    data.salary_type == 2 ? 'Bank' : '-'
                                }
                            </span>
                            <span class="ms-1" style="color:${data.salary_company_base_color || '#6c757d'}"  data-bs-toggle="tooltip" title="${data.salary_company_name || '-'}"><i class="mdi mdi-bank"></i></span>
                        </label>
                        <label class="badge bg-label-info text-nowrap">
                            <span class="fs-7">
                                ${
                                    data.salary_date == 1 ? '5th' :
                                    data.salary_date == 2 ? '15th' : '-'
                                }
                            </span>
                        </label>
                    </div>
                   
                </td>
                <td align="right">
                    <span class="text-success fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.onduty ? new Intl.NumberFormat('en-IN').format(dataParoll.onduty) :'0'}</span>
                    </span>
                    
                </td>
                <td>
                    <span class="text-success fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.incentive ? new Intl.NumberFormat('en-IN').format(dataParoll.incentive) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-success fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.variable ? new Intl.NumberFormat('en-IN').format(dataParoll.variable) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="badge bg-label-danger fs-5 text-nowrap"> ${dataParoll.lop_days}</span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.lopAmount ? new Intl.NumberFormat('en-IN').format(dataParoll.lopAmount) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.pf ? new Intl.NumberFormat('en-IN').format(dataParoll.pf) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.esi ? new Intl.NumberFormat('en-IN').format(dataParoll.esi) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.pt ? new Intl.NumberFormat('en-IN').format(dataParoll.pt) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap">
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.tax ? new Intl.NumberFormat('en-IN').format(dataParoll.tax) :'0'}</span>
                    </span>
                </td>
                <td class="text-end">
                    <span class="badge bg-danger fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.deductions ? new Intl.NumberFormat('en-IN').format(dataParoll.deductions) :'0'}</span>
                    </span>
                </td>
                <td class="text-end">
                    <span class="badge bg-success fw-bold fs-5 text-nowrap cursor-pointer" data-bs-toggle="modal" data-bs-target="#breakdown_modal" onclick="viewBreakdown(${item.sno})">
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.net ? new Intl.NumberFormat('en-IN').format(dataParoll.net) :'0'}</span>
                    </span> 
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        // const company_fill = '';
        const company_fill = document.getElementById('company_fill').value;
        const salary_company = document.getElementById('salary_company').value;
        // const entity_fill = ''
        const entity_fill = document.getElementById('entity_fill').value;
        const monthFilter = $('#global_date_picker').val() || currentMonth;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const department_fill = document.getElementById('department_fill').value;
        const salary_date_fill = document.getElementById('salary_date_fill').value;
        const salary_type_fill = document.getElementById('salary_type_fill').value;
        const exit_staff_fill = $('#exit_staff_fill').is(':checked') ? 1 : 0;
        const only_bank_fill = $('#only_bank_fill').is(':checked') ? 1 : 0;
        const only_variable_fill = $('#only_variable_fill').is(':checked') ? 1 : 0;
        console.log(monthFilter)

        const url = `/hr_general/payroll_reports?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&salary_company=${salary_company}&entity_fill=${entity_fill}&month_filter=${monthFilter}&department_fill=${department_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}&salary_date_fill=${salary_date_fill}&salary_type_fill=${salary_type_fill}&exit_staff_fill=${exit_staff_fill}&only_bank_fill=${only_bank_fill}&only_variable_fill=${only_variable_fill}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        let totalSalary = 0;
        let totalDeduction = 0;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                previewData = res.data;
                currentPayrollProcessId = res.payroll_process_id ? res.payroll_process_id : '';
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        totalSalary += parseFloat(item.net_salary);
                        totalDeduction += parseFloat(item.lop_amount) + parseFloat(item.pf_amount) + parseFloat(item.esi_amount);
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });





                    $('#totalEmployees').text(res.total);
                    let total_net_salary = res.total_net_salary ? new Intl.NumberFormat('en-IN').format(res.total_net_salary) : '0';
                    let total_gross_salary = res.total_gross_salary ? new Intl.NumberFormat('en-IN').format(res.total_gross_salary) : '0';
                    let total_fixed_gross_salary = res.total_fixed_gross_salary ? new Intl.NumberFormat('en-IN').format(res.total_fixed_gross_salary) : '0';
                    let total_deduction = res.total_deduction ? new Intl.NumberFormat('en-IN').format(res.total_deduction) : '0';

                    $('#totalNetSalary').text("₹" + total_net_salary);
                    $('#totalGrossSalary').text("₹" + total_gross_salary);
                    $('#totalFixedGrossSalary').text("₹" + total_fixed_gross_salary);
                    $('#totalDeduction').text("₹" + total_deduction);

                    let earningsHtml = '';

                    if (res.earnings_summary && res.earnings_summary.length > 0) {

                        res.earnings_summary.forEach(item => {
                            let amount = new Intl.NumberFormat('en-IN').format(item.total);

                            earningsHtml += `
                                <div class="tooltip-row fancy">
                                    <span class="label fw-bold fs-6">${item.name}</span>
                                    <span class="value fw-bold fs-6 text-nowrap">₹ ${amount}</span>
                                </div>
                            `;
                        });

                    } else {
                        earningsHtml = `<div class="text-muted text-center">No Data</div>`;
                    }



                    document.getElementById('earningsBreakdown').innerHTML = earningsHtml;

                    let deductionsHtml = '';

                    if (res.deductions_summary && res.deductions_summary.length > 0) {

                        res.deductions_summary.forEach(item => {
                            let amount = new Intl.NumberFormat('en-IN').format(item.total);

                            deductionsHtml += `
                                <div class="tooltip-row fancy">
                                    <span class="label fs-6 fw-bold">${item.name}</span>
                                    <span class="value fs-6 fw-bold text-nowrap text-danger">₹ ${amount}</span>
                                </div>
                            `;
                        });

                    } else {
                        deductionsHtml = `<div class="text-muted text-center">No Data</div>`;
                    }

                    document.getElementById('deductionsBreakdown').innerHTML = deductionsHtml;

                    animateValue(
                        document.getElementById("totalEmployees"),
                        0,
                        res.total,
                        false
                    );

                    animateValue(
                        document.getElementById("totalGrossSalary"),
                        0,
                        res.total_gross_salary,
                        true
                    );

                    animateValue(
                        document.getElementById("totalFixedGrossSalary"),
                        0,
                        res.total_fixed_gross_salary,
                        true
                    );

                    animateValue(
                        document.getElementById("totalDeduction"),
                        0,
                        res.total_deduction,
                        true
                    );

                    animateValue(
                        document.getElementById("totalNetSalary"),
                        0,
                        res.total_net_salary,
                        true
                    );

                    updateTrendCard(
                        "gross",
                        res.current.gross,
                        res.previous.gross
                    );

                    updateTrendCard(
                        "deduction",
                        res.current.deduction,
                        res.previous.deduction
                    );

                    updateTrendCard(
                        "net",
                        res.current.net,
                        res.previous.net
                    );

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                    document.getElementById('deductionsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    document.getElementById('earningsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    $('#totalEmployees').text(0);
                    $('#totalNetSalary').text("₹0");
                    $('#totalGrossSalary').text("₹0");
                }

                
                renderWorkflowStatus(res.workflow);

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="13" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        $('#company_fill').val('').change();
        $('#entity_fill').val('').change();
        $('#department_fill').val('').change();
        $('#dt_fill_issue_rpt').val('all').change();
        $('#salary_date_fill').val('').change();
        $('#salary_type_fill').val('').change();
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });
    // Initial load
    loadThemes(1);
</script>
<script>
    function viewBreakdown(staffId) {

        let staff = previewData.find(x => x.sno == staffId);

        var data = typeof staff.data === 'string' ? JSON.parse(staff.data) : staff.data;
        var dataParoll = typeof staff.dataParoll === 'string' ? JSON.parse(staff.dataParoll) : staff.dataParoll;

        let staff_image = '';
        if (staff.isStaffImage) {
            if (data.staff_image && data.staff_image.trim() !== '') {
                if (data.company_type == 1) {
                    staff_image = `staff_images/Management/${data.staff_image}`;
                } else {
                    staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;
        let absentdays = parseInt(staff.absent_days) || 0;
        let leavedays = parseInt(staff.leave_days) || 0;
        let totalLeavedays = absentdays + leavedays;

        // 👉 BASIC INFO
        $('#emp_image').attr('src', staff_image);
        $('#emp_name').text(staff.name);
        $('#emp_email').text(data.email_id);
        $('#emp_job_role').text(data.job_role_name);
        $('#emp_mobile').text(data.mobile_no);
        $('#emp_basic').text(staff.basic_salary);
        $('#emp_net').text(dataParoll.net);

        $('#present').text(staff.present_days || 0);
        $('#absent').text(totalLeavedays || 0);
        $('#late').text(staff.late_count || 0);
        $('#lop').text(dataParoll.lop_days);

        $('#hidden_entry_encrypt').val(staff.entry_encrypt)


        // 👉 EARNINGS
        let earnHTML = '';
        let dedHTML = '';
        let employerHTML = '';

        if (
            dataParoll.components &&
            dataParoll.components.length > 0
        ) {

            dataParoll.components.forEach(c => {

                let row = `
                <div class="d-flex justify-content-between border-bottom py-2">
                    <span class="fw-semibold">
                        ${c.component || '-'}
                    </span>

                    <span class="fw-bold text-nowrap">
                        ₹ ${new Intl.NumberFormat('en-IN')
                            .format(c.amount || 0)}
                    </span>
                </div>`;

                if (c.type === 'earning') {

                    earnHTML += row;

                } else if (c.type === 'deduction') {

                    dedHTML += row;

                } else if (
                    c.type === 'employer_contribution'
                ) {

                    employerHTML += row;
                }
            });

        } else {

            earnHTML = `
                <div class="text-muted text-center py-3">
                    No Earnings Found
                </div>
            `;

            dedHTML = `
                <div class="text-muted text-center py-3">
                    No Deductions Found
                </div>
            `;
            employerHTML = `
                <div class="text-muted text-center py-3">
                    No Employer Contribution Found
                </div>
            `;
        }

        $('#earning_body').html(earnHTML);

        $('#deduction_body').html(dedHTML);
        $('#employer_body').html(employerHTML);


        

        // 👉 SUMMARY
        $('#total_earn').text('₹ ' + dataParoll.earnings);
        $('#total_ded').text('₹ ' + dataParoll.deductions);
        $('#net_salary_final').text('₹ ' + dataParoll.net);
        $('#total_employer').text(
            '₹ ' + dataParoll.employer_contribution
        );

        if(staff.is_saved){
            $('#payslip_btn_saved').removeClass('d-none')
           
        }else{
            $('#payslip_btn_saved').addClass('d-none')
        }

        // $('#breakdown_modal').modal('show');
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
    $(".list_page_empty").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
   
    function viewBreakdownSaved(entryId, encrypt_id) {

        $('#hidden_entry_encrypt').val(encrypt_id)

        $.get('/payroll/entry/' + entryId, function(res) {

            let staff = res.data;

            var data = typeof staff.data === 'string' ? JSON.parse(staff.data) : staff.data;
            var dataParoll = typeof staff.dataParoll === 'string' ? JSON.parse(staff.dataParoll) : staff.dataParoll;

            let staff_image = '';
            if (staff.isStaffImage) {
                if (data.staff_image && data.staff_image.trim() !== '') {
                    if (data.company_type == 1) {
                        staff_image = `staff_images/Management/${data.staff_image}`;
                    } else {
                        staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                    }
                } else {
                    staff_image = data.gender == 1 ?
                        'assets/egc_images/auth/user_2.png' :
                        'assets/egc_images/auth/user_7.png';
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }

            staff_image = `{{ asset('${staff_image}') }}`;
            let absentdays = parseInt(staff.absent_days) || 0;
            let leavedays = parseInt(staff.leave_days) || 0;
            let totalLeavedays = absentdays + leavedays;

            // 👉 BASIC INFO
            $('#emp_image_saved').attr('src', staff_image);
            $('#emp_name_saved').text(staff.name);
            $('#emp_email_saved').text(data.email_id);
            $('#emp_job_role_saved').text(data.job_role_name);
            $('#emp_mobile_saved').text(data.mobile_no);
            $('#emp_basic_saved').text(staff.basic_salary);
            $('#emp_net_saved').text(dataParoll.net);

            $('#present_saved').text(staff.present_days || 0);
            $('#absent_saved').text(totalLeavedays || 0);
            $('#late_saved').text(staff.late_count || 0);
            $('#lop_saved').text(dataParoll.lop_days);

            // 👉 EARNINGS
            let earnHTML = '';
            let dedHTML = '';
            let employerHTML = '';

            if (
                dataParoll.components &&
                dataParoll.components.length > 0
            ) {

                dataParoll.components.forEach(c => {

                    let row = `
                <div class="d-flex justify-content-between border-bottom py-2">
                    <span class="fw-semibold">
                        ${c.component || '-'}
                    </span>

                    <span class="fw-bold text-nowrap">
                        ₹ ${new Intl.NumberFormat('en-IN')
                            .format(c.amount || 0)}
                    </span>
                </div>`;

                    if (c.type === 'earning') {

                        earnHTML += row;

                    } else if (c.type === 'deduction') {

                        dedHTML += row;

                    } else if (
                        c.type === 'employer_contribution'
                    ) {

                        employerHTML += row;
                    }
                });

            } else {

                earnHTML = `
                <div class="text-muted text-center py-3">
                    No Earnings Found
                </div>
            `;

                dedHTML = `
                <div class="text-muted text-center py-3">
                    No Deductions Found
                </div>
            `;
                employerHTML = `
                    <div class="text-muted text-center py-3">
                        No Employer Contribution Found
                    </div>
                `;
            }

            $('#earning_body_saved').html(earnHTML);

            $('#deduction_body_saved').html(dedHTML);
            $('#employer_body_saved').html(employerHTML);


            // 👉 RULES
            let ruleHTML = '';

            //  SUMMARY
            $('#total_earn_saved').text('₹ ' + dataParoll.earnings);
            $('#total_ded_saved').text('₹ ' + dataParoll.deductions);
            $('#net_salary_final_saved').text('₹ ' + dataParoll.net);
            $('#total_employer_saved').text(
                '₹ ' + dataParoll.employer_contribution
            );



        });

    }

    function exportExcel() {

        let month = $('#global_date_picker').val();

        const company_fill = $('#company_fill').val();
        const entity_fill = $('#entity_fill').val();
        const salary_date_fill = $('#salary_date_fill').val();
        const salary_type_fill = $('#salary_type_fill').val();

        let url =
            `/payroll/export?month_filter=${encodeURIComponent(month)}`
            + `&company_fill=${company_fill}`
            + `&entity_fill=${entity_fill}`
            + `&salary_date_fill=${salary_date_fill}`
            + `&salary_type_fill=${salary_type_fill}`;

        window.open(url, '_blank', 'noopener,noreferrer');
    }

    function printPayslip() {
        var entry_id = $('#hidden_entry_encrypt').val();

        if (!entry_id) {
            toastr.error('Entry ID not found');
            return;
        }

        window.open('/payroll/payslip_print/' + entry_id, '_blank');
    }
</script>

<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');

            var department = $('#department_fill');

            if (countryId == 'egc') {
                $('#business_div').hide();
                var entity_id = 0;
                department.empty().append('<option value="">Select Department</option>');

                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                department.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });

            } else {
                $('#business_div').show();
                stateDropdown.empty().append('<option value="">Select Entity</option>');
                department.empty().append('<option value="">Select Department</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }

            }




        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });


    })
</script>


<script>
    function renderWorkflowStatus(workflow) {

        let html = '';
        let month = $('#global_date_picker').val();
        if (!workflow.generated) {

            html = `
            <div class="alert alert-secondary mb-0">
                ${month} Payroll not generated
            </div>`;
        }
        else if (!workflow.hr_verified) {

            html = `
            <div class="alert alert-warning mb-0">
                ${month} Payroll generated and awaiting HR verification
            </div>`;
        }
        else if (!workflow.frozen) {

            html = `
            <div class="alert alert-info mb-0">
               ${month} HR verified. Ready for payroll freeze.
            </div>`;
        }
        else {

            html = `
            <div class="alert alert-success mb-0">
                Payroll frozen successfully. Payslips can now be distributed.
            </div>`;
        }

        $('#payrollWorkflowStatus').html(html);
    }
</script>
<script>
    function exportPayroll()
    {
        let format = $('input[name=export_format]:checked').val();

        if($('#salary_company_custm').val() == ''){
                toastr.warning('Salary Company is Required')
                return false;
        }
        if($('#cheque_no').val() == ''){
                toastr.warning('Cheque Number is Required')
                return false;
        }

        let exitStaffIds = [];

        $(".exit_staff_checkbox:checked").each(function(){
            exitStaffIds.push($(this).val());
        });

        let url = "/payroll/custom_export?"
            + $.param({
                format : format,
                month_filter : $('#global_date_picker').val(),
                salary_company : $('#salary_company_custm').val(),
                salary_type_fill : $('#salary_type_fill_custm').val(),
                salary_date_fill : $('#salary_date_fill_custm').val(),
                cheque_no: $('#cheque_no').val(),
                // exit_staff : $('#exit_staff_fill_custm').is(':checked') ? 1 : 0,
                only_bank_fill : $('#only_bank_fill_custm').is(':checked') ? 1 : 0,
                include_exit_staff_fill : $('#exit_staff_fill_custm').is(':checked') ? 1 : 0,
                exit_staff_ids : exitStaffIds
            });

        window.open(url,'_blank');
    }
</script>

<script>
    let payrollBanks = [];
    function loadPayrollBankDetails()
    {
         $('#cheque_no').val('');

                
        $.ajax({
            url:'/payroll/get-bank-details',
            type:'GET',
            data:{
                salary_company:$('#salary_company_custm').val(),
                month:$('#global_date_picker').val(),
                salary_date:$('#salary_date_fill_custm').val()
            },
            success:function(res){
                    if(!res.status){
                        toastr.error(res.message);
                        return;
                    }

                    payrollBanks = res.banks;

                    let html='';

                    $.each(payrollBanks,function(i,bank){

                        html += `
                            <option value="${bank.sno}"
                            ${bank.sno==res.selected_bank?'selected':''}>
                                ${bank.bank_name} - ${bank.account_number}
                            </option>
                        `;

                    });

                    $('#company_bank_id').html(html);

                    fillSelectedBank();

                    $('#cheque_no').val(res.cheque_no);

                    // if(res.salary_date){
                    //     $('#salary_date_fill_custm')
                    //     .val(res.salary_date)
                    //     .trigger('change');
                    // }
                    
            }

        });
    }

    function saveChequeDetails()
    {
        $.ajax({
            url:'/payroll/save-cheque-details',
            type:'POST',
            data:{
                _token:$('meta[name="csrf-token"]').attr('content'),
                salary_company:$('#salary_company_custm').val(),
                month:$('#export_month').val(),
                salary_date:$('#salary_date_fill_custm').val(),
                cheque_no:$('#cheque_no').val(),
                company_bank_id:$('#company_bank_id').val(),
                current_acct:$('#current_account').val(),
            },

            success:function(res){
                toastr.success('Cheque details saved successfully.');
            },

            error:function(){
                toastr.error('Unable to save.');
            }

        });

    }

    function fillSelectedBank(){

        let id = $('#company_bank_id').val();

        let bank = payrollBanks.find(x => x.sno == id);

        if(!bank) return;

        $('#bank_name').val(bank.bank_name);
        $('#bank_branch').val(bank.bank_branch);
        $('#account_holder').val(bank.account_holder);
        $('#ifsc_code').val(bank.ifsc_code);
        $('#current_account').val(bank.account_number);
    }

    $(document).on('change','#company_bank_id',fillSelectedBank);
</script>
<script>
    function exportCommonPayroll()
    {
        let format = $('input[name=common_export_format]:checked').val();

        // if($('#salary_company_common').val() == ''){
        //         toastr.warning('Salary Company is Required')
        //         return false;
        // }
        

        let url = "/payroll/common_export?"
            + $.param({
                format : format,
                month_filter : $('#global_date_picker').val(),
                salary_company : $('#salary_company_common').val(),
                salary_type_fill : $('#salary_type_fill_common').val(),
                salary_date_fill : $('#salary_date_fill_common').val(),
                // exit_staff : $('#exit_staff_fill_custm').is(':checked') ? 1 : 0,
                only_bank_fill : $('#only_bank_fill_common').is(':checked') ? 1 : 0,
                only_variable_fill : $('#only_variable_fill_common').is(':checked') ? 1 : 0
            });

        window.open(url,'_blank');
    }
</script>
<script>
let exitStaffList = [];

$("#exit_staff_fill_custm").change(function () {
    if ($(this).is(":checked")) {
        $("#exitStaffContainer").removeClass("d-none");
        // exitStaffList();
    } else {
        $("#exitStaffContainer").addClass("d-none");
        $("#exitStaffList").html("");

    }

});

function renderExitStaff() {
    let html = "";
    if(exitStaffList.length > 0 ){
        exitStaffList.forEach(function(staff){
            let image = "";
            if(staff.company_type == 1){
                image = "/staff_images/Management/" + staff.staff_image;
            }else{
                image = "/staff_images/Buisness/"  + staff.company_id + "/" + staff.entity_id + "/" + staff.staff_image;
            }
            html += `
            <div class="card border mb-2 shadow-sm">
                <div class="card-body p-2">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <img src="${image}"  onerror="this.src='/assets/egc_images/default_user.png'" style="width:55px;height:55px;border-radius:50%;object-fit:fill">
                        </div>
                        <div class="flex-grow-1">
                            <div class="fw-bold">${staff.staff_name}</div>
                            <small class="text-muted">${staff.staff_code}</small>
                            <br>
                            <small class="text-primary"> ${staff.entity_name ?? 'Elysium Groups'}</small>
                        </div>
                        <div>
                            <input type="checkbox" class="form-check-input exit_staff_checkbox" value="${staff.sno}">
                        </div>
                    </div>
                </div>
            </div>
            `;
        });
    }else{
        html = "<div class='text-center text-muted'>No Exit Staff Found</div>";
    } 

    $("#exitStaffList").html(html);

}
</script>
<script>
    function exitStaffListFunc(){
        $.ajax({
            url:'/get_month_exit_staff',
            type:'GET',
            data:{
                salary_company:$('#salary_company_custm').val(),
                month:$('#global_date_picker').val(),
                salary_date:$('#salary_date_fill_custm').val()
            },
            success:function(res){
                    exitStaffList = res.exit_staff || [];   
                    let exitStaffCount = exitStaffList.length || 0;
                    $('#exit_staff_count_label').text(exitStaffCount);
                    renderExitStaff();    
            }

        });
    }

    function openBankMonth(){
        let month = $('#global_date_picker').val();
        $('#bank_month_label').text(month);
        loadPayrollBankDetails()
        exitStaffListFunc();
    }
    function openCommonMonth(){
        let month = $('#global_date_picker').val();
        $('#common_month_label').text(month);
        
        
    }
</script>
<script>

    function formatCurrency(amount) {
        amount = parseFloat(amount || 0);
        return "₹" + new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 2,
            minimumFractionDigits: 0
        }).format(amount);
    }

    function getVariation(current, previous) {
        current = parseFloat(current || 0);
        previous = parseFloat(previous || 0);
        if (previous === 0) {
            return {
                percent: "0.00",
                difference: current,
                direction: "same"
            };
        }

        const difference = current - previous;
        const percentage = ((difference / previous) * 100);

        return {
            percent: Math.abs(percentage).toFixed(2),
            difference: difference,
            direction:
                difference > 0 ? "up" :
                difference < 0 ? "down" :
                "same"
        };

    }
    
    function updateTrendCard(type, current, previous) {

        const trend = getVariation(current, previous);

        const variationSpan =
            document.getElementById(type + "Variation");

        const badge =
            document.getElementById(type + "VariationBadge");

        const previousLabel =
            document.getElementById("previous" + type);

        const differenceLabel =
            document.getElementById(type + "Difference");

        previousLabel.innerHTML =
            formatCurrency(previous);

        differenceLabel.innerHTML =
            formatCurrency(Math.abs(trend.difference));

        badge.classList.remove(
            "trend-up",
            "trend-down",
            "trend-neutral"
        );

        if (trend.direction === "up") {

            badge.classList.add("trend-up");

            badge.innerHTML = `
                <i class="mdi mdi-trending-up"></i>
                <span>${trend.percent}%</span>
            `;

        }

        else if (trend.direction === "down") {

            badge.classList.add("trend-down");

            badge.innerHTML = `
                <i class="mdi mdi-trending-down"></i>
                <span>${trend.percent}%</span>
            `;

        }

        else {

            badge.classList.add("trend-neutral");

            badge.innerHTML = `
                <i class="mdi mdi-minus"></i>
                <span>0.00%</span>
            `;

        }

    }

    function animateValue(element,start,end,currency=true){

    let duration=1200;

    let startTimestamp=null;

    function step(timestamp){

        if(!startTimestamp)
            startTimestamp=timestamp;

        let progress=Math.min(
            (timestamp-startTimestamp)/duration,
            1
        );

        let value=start+(end-start)*progress;

        if(currency){

            element.innerHTML=
                "₹"+
                new Intl.NumberFormat('en-IN').format(
                    Math.round(value)
                );

        }else{

            element.innerHTML=
                Math.round(value);

        }

        if(progress<1){
            requestAnimationFrame(step);
        }

    }

    requestAnimationFrame(step);

}
</script>
@endsection