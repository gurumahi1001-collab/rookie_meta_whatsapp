<div id="payslipArea" class="d-flex justify-content-center py-4">

    <div class="payslip shadow-sm">

        <!-- HEADER -->
        <div class="payslip-header d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1 fw-semibold">Payslip</h4>
                <div class="text-muted small">January 2026</div>
            </div>

            <div class="text-end">
                <div class="company-name fw-semibold">Elysium Group</div>
                <div class="badge-paid">PAID</div>
            </div>
        </div>

        <!-- EMPLOYEE INFO -->
        <div class="info-grid mt-4">
            <div>
                <label>Employee</label>
                <div>{{$data->name ?? '-'}}</div>
            </div>
            <div>
                <label>Employee ID</label>
                <div>{{$data->staff_code ?? '-'}}</div>
            </div>
            <div>
                <label>Department</label>
                <div>Production</div>
            </div>
            <div>
                <label>Designation</label>
                <div>Developer</div>
            </div>
        </div>

        <!-- SUMMARY -->
        <div class="summary-grid mt-4">
            <div class="summary-card">
                <label>Gross Salary</label>
                <div class="amount">₹ {{$data->basic_salary ?? '-'}}</div>
            </div>

            <div class="summary-card">
                <label>Total Deductions</label>
                <div class="amount text-danger">₹ 175.00</div>
            </div>

            <div class="summary-card highlight">
                <label>Net Pay</label>
                <div class="amount">₹ {{$data->net_salary ?? '-'}}</div>
            </div>
        </div>

        <!-- TABLE SECTION -->
        <div class="row mt-4">
            <div class="col-6">
                <h6 class="section-title">Earnings</h6>
                <table class="table payroll-table">
                    <tr><td>Base Salary</td><td class="text-end">₹ 5,000</td></tr>
                    <tr><td>Monthly Incentive</td><td class="text-end">₹ 500</td></tr>
                    <tr><td>Travel Allowance</td><td class="text-end">₹ 200</td></tr>
                    <tr class="fw-semibold border-top">
                        <td>Total Earnings</td>
                        <td class="text-end text-success">₹ 6,000</td>
                    </tr>
                </table>
            </div>

            <div class="col-6">
                <h6 class="section-title">Deductions</h6>
                <table class="table payroll-table">
                    <tr><td>LOP</td><td class="text-end">₹ 100</td></tr>
                    <tr><td>Professional Tax</td><td class="text-end">₹ 50</td></tr>
                    <tr><td>Other</td><td class="text-end">₹ 25</td></tr>
                    <tr class="fw-semibold border-top">
                        <td>Total Deductions</td>
                        <td class="text-end text-danger">₹ 175</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- FOOTER -->
        <div class="footer-note mt-4 text-center">
            This is a system generated payslip and does not require signature.
        </div>

    </div>
</div>
<style>
    body {
    font-family: 'Public Sans', sans-serif;
    background: #f5f6f8;
}

.payslip {
    width: 210mm;
    min-height: 297mm;
    background: #ffffff;
    padding: 40px;
    border-radius: 6px;
}

/* Header */
.payslip-header {
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 15px;
}

.company-name {
    font-size: 14px;
}

.badge-paid {
    margin-top: 6px;
    display: inline-block;
    padding: 4px 12px;
    font-size: 12px;
    background: #ecfdf5;
    color: #059669;
    border-radius: 20px;
}

/* Info grid */
.info-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}

.info-grid label {
    font-size: 11px;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.info-grid div {
    font-weight: 500;
}

/* Summary */
.summary-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.summary-card {
    border: 1px solid #e5e7eb;
    padding: 20px;
    border-radius: 8px;
}

.summary-card label {
    font-size: 12px;
    color: #6b7280;
}

.summary-card .amount {
    font-size: 20px;
    font-weight: 600;
    margin-top: 5px;
}

.summary-card.highlight {
    background: #111827;
    color: #ffffff;
}

/* Table */
.section-title {
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 10px;
}

.payroll-table td {
    border: none;
    padding: 6px 0;
    font-size: 14px;
}

.payroll-table tr.border-top td {
    border-top: 1px solid #e5e7eb;
    padding-top: 10px;
}

/* Footer */
.footer-note {
    font-size: 12px;
    color: #6b7280;
    border-top: 1px solid #e5e7eb;
    padding-top: 15px;
}
</style>