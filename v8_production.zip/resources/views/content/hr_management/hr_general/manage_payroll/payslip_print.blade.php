<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payslip</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

    @php
        $helper = new \App\Helpers\Helpers();
        $baseColor = $data->salary_company_color ?? '#ab2b22';
    @endphp

    <style>
        body {
            font-family: 'Public Sans', sans-serif;
        }

        .print-container {
            /* width: 210mm; */
            width: 794px; 
            min-height: 1123px;
            /* min-height: 297mm; */
            margin: auto;
            position: relative;
            overflow: hidden;
        }

        .print-container > *:not(img) {
            position: relative;
            z-index: 2;
        }

        .summary-box {
            border: 1px solid {{ $baseColor }};
            border-radius: 12px;
            padding: 16px;
            background: #fff;
        }

        .flex-fill {
            max-height: 450px;
            overflow-y: auto;
        }

        .card-row:nth-child(even) {
            background-color: rgba(0,0,0,0.03);
        }

        /* .qr-box {
            width: 110px;
            height: 110px;
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 5px;
            background: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
        } */

        @page {
            size: A4;
            margin: 0;
        }

        @media print {
            body {
                margin: 0;
                padding: 0;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .print-container {
                /* width: 210mm;
                min-height: 297mm; */
                width: 794px; 
            min-height: 1123px;
            }
        }
        /* .textmuted{
            color:#0000009e;
        } */
    </style>
</head>

<body>

<div class="d-flex justify-content-center">
<div class="print-container shadow-lg px-4 py-4 bg-white">

    <!-- Background -->
    <img src="{{ $data->payslip_template_url ?? asset('assets/egc_images/payslip_bg.jpg') }}"
         style="position:absolute; top:0; left:0; width:210mm; height:297mm; object-fit:cover; z-index:0;"
         alt="Payslip Background">

    <!-- Header -->
    <div class="px-4 py-3 border-bottom d-flex justify-content-between align-items-center" style="margin-top:90px;">
        <div>
            <h3 class="fw-bold mb-1">PAYSLIP</h3>
            <p class="textmuted mb-0">
                {{ date('F', mktime(0,0,0,$data->payroll_month,1)) }} {{ $data->payroll_year }}
            </p>
        </div>

        <span class="badge rounded-pill px-4 py-2 fw-bold"
              style="background-color: {{ $baseColor }}33; color: {{ $baseColor }};">
            PAID
        </span>
    </div>

    <!-- Employee Info -->
    <div class="row g-2 px-4 py-2 bg-light">
        <div class="col-3">
            <small class="textmuted ">Employee Name</small>
            <div class="fw-bold">{{ $data->name }}</div>
        </div>
        <div class="col-3">
            <small class="textmuted ">Employee ID</small>
            <div class="fw-bold">{{ $data->staff_code }}</div>
        </div>
        <div class="col-3">
            <small class="textmuted ">Department</small>
            <div class="fw-bold">{{ $data->department_name }}</div>
        </div>
        <div class="col-3">
            <small class="textmuted ">Designation</small>
            <div class="fw-bold">{{ $data->job_role_name ?? ''}}</div>
        </div>
    </div>

    <!-- Summary -->
    <div class="row g-2 px-4 py-2">
        <div class="col-4">
            <div class="summary-box">
                <small class="textmuted ">Gross Salary</small>
                <div class="fw-bold fs-4">₹ {{ number_format($data->total_earnings,2) }}</div>
            </div>
        </div>

        <div class="col-4">
            <div class="summary-box">
                <small class="textmuted ">Total Deductions</small>
                <div class="fw-bold fs-4">₹ {{ number_format($data->total_deductions,2) }}</div>
            </div>
        </div>

        <div class="col-4">
            <div class="summary-box text-white" style="background: {{ $baseColor }}">
                <small class="fw-bold">Net Payable</small>
                <div class="fw-bold fs-3">₹ {{ number_format($data->net_salary,2) }}</div>
            </div>
        </div>
    </div>

    <!-- Earnings & Deductions -->
    <div class="px-4 pb-1">
        <div class="row g-3">
            <div class="col-12 d-flex flex-column flex-sm-row gap-3">

                <!-- Earnings -->
                <div class="flex-fill border rounded shadow-sm p-3 d-flex flex-column">
                    <h6 class="fw-bold text-center p-2 rounded"
                        style="background: {{ $baseColor }}22; color: {{ $baseColor }}">
                        Earnings
                    </h6>

                    <div class="flex-grow-1 mt-2">
                        @foreach($data->components->where('type','earning') as $c)
                        <div class="d-flex justify-content-between py-2 border-bottom">
                            <span>{{ $c->component_name }}</span>
                            <span class="fw-bold">₹ {{ number_format($c->amount,2) }}</span>
                        </div>
                        @endforeach
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top fw-bold">
                        <span>Total Earnings</span>
                        <span>₹ {{ number_format($data->total_earnings,2) }}</span>
                    </div>
                </div>

                <!-- Deductions -->
                <div class="flex-fill border rounded shadow-sm p-3 d-flex flex-column">
                    <h6 class="fw-bold text-center p-2 rounded"
                        style="background:#ff4d4d22; color:#dc3545">
                        Deductions
                    </h6>

                    <div class="flex-grow-1 mt-2">
                        @foreach($data->components->where('type','deduction') as $c)
                        <div class="d-flex justify-content-between py-2 border-bottom">
                            <span>{{ $c->component_name }}</span>
                            <span class="fw-bold">₹ {{ number_format($c->amount,2) }}</span>
                        </div>
                        @endforeach
                    </div>

                    <div class="d-flex justify-content-between mt-3 pt-2 border-top fw-bold">
                        <span>Total Deductions</span>
                        <span>₹ {{ number_format($data->total_deductions,2) }}</span>
                    </div>
                </div>

            </div>
        </div>

        <!-- Net Payable in Words -->
        <div class="row mt-3">
            <div class="col-12">
                <div class="border rounded p-3 text-center fw-semibold"
                     style="background:#f5f5f5;">
                    Net Payable (in words):
                    {{ $data->net_salary > 0 ? $helper->convertNumberToWords($data->net_salary) : 'Zero'}}
                </div>
            </div>
        </div>

    </div>

    <div class="px-4 pb-3 d-flex justify-content-end mt-2">
        <div class="text-center">
            <div id="qrcode1" class="qr-box"></div>
            <small class="text-muted d-block mt-1">Scan to Verify</small>
        </div>
    </div>

</div>
</div>

<!-- PDF Script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>


<script>
    
        let  qrDataForQRCodeURL = @json($payroll_qr_verified_url);
        generateQRCode(qrDataForQRCodeURL, 'qrcode1'); 
      function generateQRCode(qrData, targetElementId) {
        QRCode.toDataURL(
            qrData,
            {
                width: 125, // Adjust size for visibility
                height: 125, // Adjust size for visibility
                margin: 1 // Ensure scannability with a small margin
            },
            function (error, url) {
                if (error) {
                    console.error('QR Code Error:', error);
                } else {
                    console.log(`QR Code generated successfully for ${targetElementId}!`);
                    // Create an img element and set its src to the generated data URL
                    const img = document.createElement('img');
                    img.src = url;
                     img.style.width="125px";
                     img.style.border="1px solid #acaaaa";
                     img.style.borderRadius="4px";
                     img.style.padding="4px"; 
                    document.getElementById(targetElementId).appendChild(img); // Append the img to the div

                    setTimeout(() => {
                            downloadpdf()
                    }, 500);
                }
            }
        );
    }

</script>

<script>
// function downloadpdf() {
//     const element = document.querySelector('.print-container');

//     const opt = {
//         margin: 0,
//         filename: 'Payslip_{{ $data->staff_code }}.pdf',
//         image: { type: 'jpeg', quality: 1 },
//         html2canvas: { scale: 2 },
//         jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
//     };

//     html2pdf().set(opt).from(element).save();
// }
// function downloadpdf() {

//     const element = document.querySelector('.print-container');

//     // const opt = {
//     //     margin: [0,0,0,0],
//     //     filename: 'Payslip_{{$data->staff_code ?? "Employee"}}_Jan_2026.pdf',
//     //     image: { type: 'jpeg', quality: 1 },
//     //     html2canvas: { 
//     //         scale: 2,
//     //         useCORS: true
//     //     },
//     //     // html2canvas: { scale: 1.8 },
//     //     jsPDF: { 
//     //         unit: 'mm',
//     //         format: 'a4',
//     //         orientation: 'portrait'
//     //     }
//     // };

//     // const opt = {
//     //     margin: 0,
//     //     filename: 'Payslip_{{$data->staff_code ?? "Employee"}}.pdf',
//     //     image: { type: 'jpeg', quality: 1 },
//     //     // html2canvas: { 
//     //     //     scale: 3, // 🔥 increase quality
//     //     //     useCORS: true,
//     //     //     scrollY: 0
//     //     // },
//     //     // jsPDF: { 
//     //     //     unit: 'mm',
//     //     //     format: [210, 297], // ✅ exact A4
//     //     //     orientation: 'portrait'
//     //     // }
//     //     html2canvas: { 
//     //         scale: 2,
//     //         useCORS: true,
//     //         scrollY: 0
//     //     },
//     //     jsPDF: { 
//     //         unit: 'mm',
//     //         format: 'a4',
//     //         orientation: 'portrait'
//     //     }
//     // };


//     const opt = {
//         margin: 0,
//         filename: 'Payslip_{{$data->staff_code ?? "Employee"}}.pdf',
//         image: { type: 'jpeg', quality: 1 },
//         html2canvas: { scale: 1.5 }, 
//         jsPDF: {
//             unit: 'mm',
//             format: 'a4',
//             orientation: 'portrait'
//         }
//     };

//     // document.getElementById('downloadPdfBtn').style.display = 'none';

//     // html2pdf().set(opt).from(element).save().then(() => {
//     //     // document.getElementById('downloadPdfBtn').style.display = 'inline-block';
//     // });

//     html2pdf().set(opt).from(element).save();

// }
function downloadpdf() {
    const element = document.querySelector('.print-container');

    const opt = {
        margin: 0,
        filename: 'Payslip_{{$data->staff_code ?? "Employee"}}.pdf',
        image: { type: 'jpeg', quality: 1 },
        html2canvas: { scale: 2.5, useCORS: true, scrollY: 0 },
        jsPDF: { unit: 'mm', format: [210, 297], orientation: 'portrait' }
    };

    html2pdf().set(opt).from(element).save();
}
// 
</script>

</body>
</html>