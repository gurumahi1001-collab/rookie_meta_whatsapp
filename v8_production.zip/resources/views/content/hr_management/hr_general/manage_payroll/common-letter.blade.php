<!DOCTYPE html>
<html>
    <head>
        <title>Payroll - {{$payroll['month']}} </title>
        <meta charset="utf-8">

        <style>
            /* @page{
                margin:20px 25px;
            } */
            body{
                font-family: DejaVu Sans;
                font-size:13px;
                color:#000;
            }

            .header{
               
                text-align:center;
                font-size:22px;
                font-weight:bold;
            }

            .logo{
                height:70px;
            }


            .right{
                text-align:right;
            }

            .bold{
                font-weight:bold;
            }

           

            table{
                width:100%;
                border-collapse:collapse;
                page-break-inside:auto;
            }

            thead{
                display: table-header-group;
            }
           
            

            table th{
                /* background:#efefef; */
                border:1px solid #000;
                padding:8px;
            }

            table td{
                border:1px solid #000;
                padding:7px;
            }

            tbody tr{
                page-break-inside: avoid;
            }

            .center{
                text-align:center;
            }

            .amount{
                text-align:right;
            }

            

          
           

        </style>

    </head>
    <body>
        @php
            $formatter = new NumberFormatter('en_IN', NumberFormatter::DECIMAL);
          
        @endphp
        @php
            $rows = $payroll['rows'] ?? [];
        @endphp

        <div class="header">
           Payroll Report - {{ $payroll['month'] }}
        </div>
        <div style="height:5px;"></div>
        <div class="right">Date : {{ $payroll['format_salary_date'] }}</div>
        <br>
        <div class="letter-content">
            <table>
                <thead>
                    <tr style="background:{{$payroll['company_base_color'] ?? '#ab2b22'}};color:white;">
                         <th style="width:3%;">Sl</th>
                            <th style="width:20%;">Employee</th>

                            <th style="width:6%;">Gross</th>
                            <th style="width:6%;">OD</th>
                            <th style="width:6%;">INC</th>
                            <th style="width:6%;">VAR</th>

                            <th style="width:5%;">LOP</th>
                            <th style="width:7%;">LOP Ded</th>

                            <th style="width:5%;">PF</th>
                            <th style="width:5%;">ESI</th>
                            <th style="width:5%;">PT</th>

                            <th style="width:8%;">Deduction</th>
                            <th style="width:8%;">Net</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($rows as $index=>$row)
                    <tr>
                        <td class="center">
                            {{ $index+1 }}
                        </td>
                        <td>
                            <strong>{{ $row['staff_name'] }}</strong><br>
                            <small>{{ $row['staff_id'] }}</small><br>
                            <small>{{ Str::limit($row['salary_company_name'],18) }}</small><br>
                            <small>{{ $row['entity_name'] }}</small>
                        </td>
                        
                        <td class="amount">
                            {{ $formatter->format($row['gross_salary']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['onduty']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['incentive']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['variable']) }}
                        </td>
                        <td class="">
                           {{ $row['lop_days']}}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['lopAmount']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['pf']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['esi']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['pt']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['deductions']) }}
                        </td>
                        <td class="amount">
                            {{ $formatter->format($row['amount']) }}
                        </td>
                    </tr>
                    @endforeach
                    <tr>
                        <td colspan="12" class="center bold">TOTAL</td>
                        <td class="amount bold">
                        {{ $formatter->format($payroll['grand_total']) }}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </body>
</html>