<!DOCTYPE html>
<html>
<head>

<style>

body{
font-family: DejaVu Sans, sans-serif;
font-size:12px;
color:#333;
}

.header{
width:100%;
border-bottom:2px solid #0d6efd;
margin-bottom:15px;
padding-bottom:10px;
}

.logo{
height:60px;
}

.company{
text-align:right;
}

.title{
text-align:center;
font-size:18px;
font-weight:bold;
margin-top:10px;
margin-bottom:15px;
}

.table{
width:100%;
border-collapse:collapse;
}

.table td{
padding:6px;
border:1px solid #ddd;
}

.net{
background:#e9f7ef;
font-weight:bold;
}

</style>

</head>
<body>


<div class="header">

<table width="100%">

<tr>

<td>

<img src="{{ public_path('uploads/company_logo.png') }}" class="logo">

</td>

<td class="company">

<b>Your Company Name Pvt Ltd</b><br>
Chennai, Tamil Nadu<br>
India

</td>

</tr>

</table>

</div>


<div class="title">
Payslip
</div>


<table width="100%" style="margin-bottom:15px;">

<tr>
<td><b>Staff Name:</b></td>
<td>{{ $data->name }}</td>

<td><b>Staff Code:</b></td>
<td>{{ $data->staff_code }}</td>
</tr>

<tr>
<td><b>Month:</b></td>
<td>{{ date('F Y', strtotime($data->created_at)) }}</td>

<td><b>Date:</b></td>
<td>{{ date('d-m-Y') }}</td>
</tr>

</table>


<table class="table">

<tr>
<td>Basic Salary</td>
<td align="right">₹{{ number_format($data->basic_salary,2) }}</td>
</tr>

<tr>
<td>LOP Deduction</td>
<td align="right">₹{{ number_format($data->lop_amount,2) }}</td>
</tr>

<tr>
<td>PF Deduction</td>
<td align="right">₹{{ number_format($data->pf_amount,2) }}</td>
</tr>

<tr>
<td>ESI Deduction</td>
<td align="right">₹{{ number_format($data->esi_amount,2) }}</td>
</tr>

<tr class="net">
<td>Net Salary</td>
<td align="right">₹{{ number_format($data->net_salary,2) }}</td>
</tr>

</table>


<br><br>

<table width="100%">
<tr>
<td>Employee Signature</td>
<td align="right">Authorized Signature</td>
</tr>
</table>


</body>
</html>