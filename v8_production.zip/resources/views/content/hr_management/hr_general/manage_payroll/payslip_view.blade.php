
<div class="container">

<h4>Payslip</h4>

<p>
Employee: {{ $entry->name }}
</p>

<p>
Employee Code: {{ $entry->employee_code }}
</p>

<p>
Month: {{ $entry->payroll_month }}/{{ $entry->payroll_year }}
</p>

<hr>

<table class="table table-bordered">

<thead>

<tr>

<th>Component</th>
<th>Earning</th>
<th>Deduction</th>

</tr>

</thead>

<tbody>

@foreach($components as $c)

<tr>

<td>{{ $c->component_name }}</td>

<td>

{{ $c->component_type=='EARNING' ? $c->amount : '' }}

</td>

<td>

{{ $c->component_type=='DEDUCTION' ? $c->amount : '' }}

</td>

</tr>

@endforeach

</tbody>

</table>

<h5>
Net Salary: {{ $entry->net_salary }}
</h5>

</div>