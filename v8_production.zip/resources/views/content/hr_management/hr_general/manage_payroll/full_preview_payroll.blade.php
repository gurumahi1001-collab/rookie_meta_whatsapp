@extends('layouts/blankLayout')

<title>Payroll Report View - {{ $payroll['month'] }}</title>

@section('content')

<style>

@page{
    size:A3 landscape;
    margin:12px;
}

body{
    font-family:DejaVu Sans;
    font-size:9px;
    color:#222;
    margin:0;
}

.header{
    text-align:center;
    font-size:24px;
    font-weight:bold;
    color:#222;
    margin-bottom:4px;
}

.sub-header{
    text-align:center;
    font-size:21px;
    color:#666;
    margin-bottom:12px;
}

.right{
    text-align:right;
    font-size:22px;
    margin-bottom:10px;
}

table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
}

thead{
    display:table-header-group;
}

tfoot{
    display:table-row-group;
}

tbody tr{
    page-break-inside:avoid;
}

th{
    background:{{$payroll['company_base_color'] ?? '#ab2b22'}};
    color:#fff;
    border:1px solid #000;
    padding:6px 3px;
    font-size:22px;
    text-align:center;
    vertical-align:middle;
}

td{
    border:1px solid #000;
    padding:5px;
    vertical-align:top;
    word-wrap:break-word;
}

tbody tr:nth-child(even){
    background:#fafafa;
}

.center{
    text-align:center;
}

.amount{
    text-align:right;
    white-space:nowrap;
    font-weight:bold;
    font-size:24px;
}

.staff-cell{
    line-height:1.25;
}

.staff-name{
    font-size:18px;
    font-weight:bold;
    color:#1f2937;
    margin-bottom:2px;
}

.staff-id{
    font-size:16px;
    color:#666;
    margin-bottom:5px;
}

/* .badge{
    display:inline-block;
    padding:4px 6px;
    color:#fff;
    font-size:17px;
    font-weight:bold;
    border-radius:3px;
    margin-bottom:3px;
} */

.company-badge{
    background:#0d6efd;
}

.meta{
    font-size:16px;
    color:#444;
    margin-top:2px;
}

.bank{
    color:#0d6efd;
    font-weight:bold;
}

.cash{
    color:#198754;
    font-weight:bold;
}

.salary-date{
    color:#c0392b;
    font-weight:bold;
}

tfoot td{
    background:#ececec;
    font-weight:bold;
    font-size:22px;
    white-space:nowrap;
}

.total-title{
    text-align:center;
    font-size:23px;
}

</style>

@php
$formatter = new NumberFormatter('en_IN', NumberFormatter::DECIMAL);
$rows = $payroll['rows'] ?? [];
$totals = [
    'gross'=>0,
    'onduty'=>0,
    'incentive'=>0,
    'variable'=>0,
    'lop_days'=>0,
    'lop'=>0,
    'pf'=>0,
    'esi'=>0,
    'pt'=>0,
    'tds'=>0,
    'deduction'=>0,
    'net'=>0,
];

foreach($rows as $r){
    $totals['gross'] += $r['gross_salary'];
    $totals['onduty'] += $r['onduty'];
    $totals['incentive'] += $r['incentive'];
    $totals['variable'] += $r['variable'];
    $totals['lop_days'] += $r['lop_days'];
    $totals['lop'] += $r['lopAmount'];
    $totals['pf'] += $r['pf'];
    $totals['esi'] += $r['esi'];
    $totals['pt'] += $r['pt'];
    $totals['tds'] += $r['tax'];
    $totals['deduction'] += $r['deductions'];
    $totals['net'] += $r['amount'];
}
@endphp


<div>
    <div class="header mt-3">
        Payroll Report
    </div>
    <div class="sub-header">
        {{ $payroll['month'] }}
    </div>
    <div class="right">
        Date :
        <strong>{{ $payroll['format_salary_date'] }}</strong>
    </div>
    <table>
        <thead>
            <tr>
                <th width="3%">#</th>
                <th width="17%%">Employee</th>
                <th width="9%">Gross</th>
                <th width="5%">OD</th>
                <th width="6%">INC</th>
                <th width="6%">VAR</th>
                <th width="5%">LOP D</th>
                <th width="9%">LOP</th>
                <th width="7%">PF</th>
                <th width="6%">ESI</th>
                <th width="6%">PT</th>
                <th width="6%">TDS</th>
                <th width="9%">DED</th>
                <th width="9%">NET</th>
            </tr>
        </thead>
        <tbody>
            @foreach($rows as $index => $row)

                <tr>
                    <td class="center fs-4 text-nowrap">
                        {{ $index + 1 }}
                    </td>
                    <td class="staff-cell">
                        <div class="staff-name">
                            {{ $row['staff_name'] }}
                        </div>
                        <div class="staff-id">
                            ID : {{ $row['staff_id'] }}
                        </div>
                       
                        {{-- Entity --}}
                        <div style="margin-top:3px;">
                            <span class="fw-semibold fs-7 text-truncate badge  d-block"
                                style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: {{ $row['entity_base_color'] ?? '#ab2b22'}};"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="{{ $row['entity_name'] ?? 'Elysium Groups'}}" >
                                {{ $row['entity_name'] ?? 'Elysium Groups'}}
                            </span>
                        </div>

                        {{-- Salary Type & Date --}}
                        <div class="meta">
                            Salary Type :
                            @if(($row['salary_type'])==1)
                                <span class="cash">
                                    CASH
                                </span>
                            @else
                                <span class="bank">
                                    BANK
                                </span>
                                
                            @endif
                        </div>
                        <div class="meta">
                            Salary Date :
                            <span class="salary-date">
                                @if(($row['salary_date'])==1)
                                    05-{{$payroll['month']}}
                                @else
                                    15-{{$payroll['month']}}
                                    
                                @endif
                            </span>
                        </div>
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['gross_salary']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['onduty']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['incentive']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['variable']) }}
                    </td>
                    <td class="center fs-4">
                        {{ $row['lop_days'] }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['lopAmount']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['pf']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['esi']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['pt']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($row['tax']) }}
                    </td>
                    <td class="amount">
                        <strong>
                            {{ $formatter->format($row['deductions']) }}
                        </strong>
                    </td>
                    <td
                        class="amount"
                        style="font-size:24px;
                            color:#0b6b0b;">
                        <strong>
                            {{ $formatter->format($row['amount']) }}
                        </strong>
                    </td>
                </tr>
            @endforeach
            </tbody>

            <tfoot>
                <tr>
                    <td colspan="2" class="total-title">
                        GRAND TOTAL
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['gross']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['onduty']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['incentive']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['variable']) }}
                    </td>
                    <td class="center">
                        {{ $formatter->format($totals['lop_days']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['lop']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['pf']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['esi']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['pt']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['tds']) }}
                    </td>
                    <td class="amount">
                        {{ $formatter->format($totals['deduction']) }}
                    </td>
                    <td class="amount" style="font-size:24px;color:#0b6b0b;">
                        {{ $formatter->format($totals['net']) }}
                    </td>
                </tr>
            </tfoot>
        </table>
        <br><br>
        <table style="border:none;">
            <tr>
                <td style="border:none;font-size:18px;">
                    <strong>Legend :</strong>
                    Gross = Gross Salary &nbsp;&nbsp;|
                    OD = On Duty Allowance &nbsp;&nbsp;|
                    INC = Incentive &nbsp;&nbsp;|
                    VAR = Variable Pay &nbsp;&nbsp;|
                    LOP D = Loss Of Pay Days &nbsp;&nbsp;|
                    LOP = Loss Of Pay Amount &nbsp;&nbsp;|
                    PF = Provident Fund &nbsp;&nbsp;|
                    ESI = Employee State Insurance &nbsp;&nbsp;|
                    PT = Professional Tax &nbsp;&nbsp;|
                    TDS = Tax Deduction at Source &nbsp;&nbsp;|
                    DED = Total Deductions &nbsp;&nbsp;|
                    NET = Net Salary
                </td>
            </tr>
        </table>
        <br>
        <!-- <table style="border:none;">
            <tr>
                <td style="border:none;text-align:left;font-size:8px;color:#666;">
                    Generated On :
                    {{ now()->format('d-M-Y h:i A') }}
                </td>
                <td style="border:none;text-align:right;font-size:8px;color:#666;">
                    Payroll Report • {{ $payroll['month'] }}
                </td>
            </tr>
        </table> -->
    </div>
    @endsection