<!DOCTYPE html>
<html>
    <head>
        <title>Bank Payroll - {{$payroll['month']}} </title>
        <meta charset="utf-8">

        <style>
            /* @page{
                margin:20px 25px;
            } */
            body{
                font-family: DejaVu Sans;
                font-size:13px;
                color:#000;
            }

            .header{
               
                /* text-align:center; */
            }

            .logo{
                height:70px;
            }


            .right{
                text-align:right;
            }

            .bold{
                font-weight:bold;
            }

           

            table{
                width:100%;
                border-collapse:collapse;
                page-break-inside:auto;
            }

            thead{
                display: table-header-group;
            }
           
            

            table th{
                /* background:#efefef; */
                border:1px solid #000;
                padding:8px;
            }

            table td{
                border:1px solid #000;
                padding:7px;
            }

            tbody tr{
                page-break-inside: avoid;
            }

            .center{
                text-align:center;
            }

            .amount{
                text-align:right;
            }

            

          
           

        </style>

    </head>
    <body>
        @php
            $formatter = new NumberFormatter('en_IN', NumberFormatter::DECIMAL);
          
        @endphp

        <div class="header">
            @if(file_exists($payroll['company_logo']))
            <img src="{{ $payroll['company_logo'] }}" class="logo" style="width: 100%; max-width: 1000px; height: auto;">
            @endif
        </div>
        <div style="height:45px;"></div>
        <div class="right">Date : {{ $payroll['format_salary_date'] }}</div>
        <br>
        <b>To</b>
        <br>
        The Manager
        <br>
        {{ $payroll['bank_name'] }}
        <br>
        {{ $payroll['bank_branch'] }}
        <br><br>
        <b>Reg : Our Current Account No : {{ $payroll['current_account'] }}</b>
        <br><br>
        Dear Sir,
        <br>
        <p style="text-indent: 25px;">Please find here with enclosed yourselves cheque for an amount of <b>Rs.{{ $formatter->format($payroll['grand_total']); }}</b>- (Rupees {{ $payroll['amount_words'] }} only ) vide cheque <b> {{ $payroll['cheque_no'] }}</b>. <b><span style="white-space: nowrap;">{{ $payroll['default_salary_date'] }}<span></b> for our staff salary transfers purpose.  Please arrange to credit in the respective account with you as detailed below towards staff salary.</p>
        <br><br>
        @php
            $rowsPerPage = 35;
            $chunks = array_chunk($payroll['rows'], $rowsPerPage);
        @endphp
        <div class="letter-content">
            @foreach($chunks as $page => $rows)
            <table>
                <thead>
                    <tr style="background:{{$payroll['company_base_color'] ?? '#ab2b22'}};color:white;">
                        <th width="8%">Sl</th>
                        <th>Employee Name</th>
                        <th width="25%">Account Number</th>
                        <th width="18%">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($rows as $index=>$row)
                    <tr>
                        <td class="center">
                            {{ ($page * $rowsPerPage) + $loop->iteration }}
                        </td>
                        <td>
                            {{ $row['staff_name'] }}
                        </td>
                        <td style="white-space:nowrap;">
                            {{ $row['account_no'] }}
                        </td>
                        <td class="amount">
                        {{ $formatter->format($row['amount']) }}
                        </td>
                    </tr>
                    @endforeach

                    @if($loop->last)
                    <tr>
                        <td colspan="3" class="center bold">TOTAL</td>
                        <td class="amount bold">
                        {{ $formatter->format($payroll['grand_total']) }}
                        </td>
                    </tr>
                     @endif
                    
                </tbody>
            </table>

            @if($loop->last)
            <table style="width:100%;border:none;border-collapse:collapse;margin-top:20px;">
                <tr>
                    <td style="border:none;padding:0;">
                        For {{ $payroll['company_name'] }}
                        <div style="height:60px;"></div>
                        <strong>Managing Director</strong>
                    </td>
                </tr>
            </table>
            @endif

            @if(!$loop->last)
            <div style="page-break-after:always;"></div>
            @endif

            @endforeach

        </div>
    </body>
</html>