@extends('layouts/layoutMaster')

@section('title', 'Manage Payroll')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
// 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'],)
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js'])
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<style>
    /* Button hover */
    .retry-btn {
        transition: all 0.2s ease;
    }

    .retry-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    /* Success pop */
    .success-pop {
        animation: pop 0.4s ease;
    }

    @keyframes pop {
        0% {
            transform: scale(0.5);
            opacity: 0;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<style>
    .selected-month-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px 14px;
        border-radius: 20px;
        background: #f1f3f5;
        color: #333;
        font-weight: 600;
        font-size: 13px;
        transition: all 0.3s ease;
    }

    /* Glow + highlight animation */
    .selected-month-badge.active {
        background: linear-gradient(135deg, #4e73df, #6f42c1);
        color: #fff;
        box-shadow: 0 0 12px rgba(78, 115, 223, 0.5);
    }

    /* subtle pulse */
    .selected-month-badge.active {
        animation: pulseGlow 1s ease;
    }

    @keyframes pulseGlow {
        0% {
            box-shadow: 0 0 0 rgba(78, 115, 223, 0.2);
        }

        50% {
            box-shadow: 0 0 15px rgba(78, 115, 223, 0.6);
        }

        100% {
            box-shadow: 0 0 10px rgba(78, 115, 223, 0.4);
        }
    }
</style>
<style>
    .sticky_table thead th:not(:first-child):not(:last-child) {
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
        line-height: 1.2;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a {
        display: flex;
        flex-direction: column;
        text-decoration: none;
        color: inherit;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:first-child {
        font-weight: 600;
        font-size: 14px;

    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:last-child {
        font-size: 12px;
        color: #ccc;

    }

    .sticky_table tbody td {
        vertical-align: middle;
    }

    .sticky_table tbody td:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #fff;
    }

    .sticky_table thead th:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ab2b22;
    }


    .sticky_table tbody td:last-child {
        position: sticky;
        right: 0;
        z-index: 2;
        background: #fff;
    }

    .sticky_table thead th:last-child {
        position: sticky;
        right: 0;
        z-index: 2;
        background: #ab2b22;
    }

    .sticky_table tbody td:nth-last-child(2) {
        position: sticky;
        right: 100px;
        z-index: 3;
        background: #fff;
    }

    .sticky_table thead th:nth-last-child(2) {
        position: sticky;
        right: 100px;
        z-index: 3;
        background: #ab2b22;
    }

    .sticky_table tbody td:nth-last-child(3) {
        position: sticky;
        right: 200px;
        z-index: 3;
        background: #fff;
    }

    .sticky_table thead th:nth-last-child(3) {
        position: sticky;
        right: 200px;
        z-index: 3;
        background: #ab2b22;
    }
</style>

<style>
    .attendance-cards .card-attendance {
        width: 150px;
        /* fixed width for all cards */
        min-width: 150px;
        max-width: 150px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 0.5rem;
        /* smaller padding */
        gap: 0.25rem;
    }

    .attendance-cards .percent-value {
        font-size: 1.2rem;
        /* reduced font */
        line-height: 1.2;
        word-wrap: break-word;
    }

    .avatar-frame {
        width: 110px;
        height: 110px;
        border-radius: 50%;
        padding: 4px;
        box-shadow: 0 15px 25px -8px rgba(235, 93, 37, 0.3);
    }

    .avatar-inner {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .avatar-inner img {
        width: 100%;
        height: 100%;
        object-fit: fill;
    }
</style>

<style>
    .team-card {
        width: 180px;
        background-color: #fff;
        border-radius: 0.4rem;
        border: 1px solid #e0e0e0;
        transition: transform 0.2s, box-shadow 0.2s;
        cursor: pointer;
    }


    .role-indicator {
        width: 40px;
        height: 40px;
    }

    .role-abbr {
        font-size: 0.8rem;
    }

    .team-info .fs-6 {
        margin-bottom: 0.1rem;
        font-size: 0.95rem !important;
    }

    .team-info .fs-8 {
        font-size: 0.75rem;
        color: #6c757d;
    }
</style>
<style>
    .attendance-badge {
        cursor: pointer;
    }

    .attendance-tooltip {
        position: absolute;
        top: 120%;
        left: 50%;
        transform: translateX(-50%) scale(0.95);
        background: #ffffff;
        border-radius: 12px;
        padding: 12px;
        width: 220px;
        font-size: 12px;
        opacity: 0;
        visibility: hidden;
        transition: all 0.25s ease;
        z-index: 1000;
        border: 1px solid #eee;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    }

    .attendance-badge:hover .attendance-tooltip {
        opacity: 1;
        visibility: visible;
        transform: translateX(-50%) scale(1);
    }

    /* Header */
    .tooltip-header {
        font-weight: 600;
        font-size: 13px;
        margin-bottom: 8px;
        color: #333;
        border-bottom: 1px dashed #eee;
        padding-bottom: 5px;
    }

    /* Rows */
    .tooltip-row.fancy {
        display: flex;
        justify-content: space-between;
        padding: 4px 0;
        transition: 0.2s;
    }

    .tooltip-row.fancy:hover {
        background: #f8f9fa;
        border-radius: 6px;
        padding-left: 6px;
        padding-right: 6px;
    }

    .tooltip-row .label {
        color: #6c757d;
    }

    .tooltip-row .value {
        font-weight: 600;
        color: #28a745;
    }
</style>
<style>
    .mdi-loading {
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        100% {
            transform: rotate(360deg);
        }
    }
</style>
<style>
    .payroll-action-btn {
        transition: all .25s ease;
    }

    .payroll-action-btn:hover {
        transform: translateY(-2px);
    }

    .verify-summary-card {
        background: #f8f9fa;
        border-radius: 18px;
        padding: 25px;
        border: 1px solid #edf0f2;
    }

    .verify-icon-box,
    .freeze-icon-box {
        width: 70px;
        height: 70px;
        border-radius: 20px;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
            <h5 class="card-title mb-1">Manage Payroll</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">HR Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element mb-1 gap-2 text-center">
            <div class="d-flex justify-content-end align-items-center flex-wrap gap-2 mb-1">
                <div id="payrollWorkflowStatus"></div>
                <button type="button" class="btn btn-primary " onclick="exportExcel()" id="export_btn">
                    <span class="mdi mdi-export"></span> Export Excel
                </button>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>
                <div class="d-flex flex-row align-items-center justify-content-between gap-2">
                    <input type="text" id="global_date_picker" class="form-control w-100px" value="<?php echo date('M-Y') ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="card-body pt-2">
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Company<span class="text-danger">*</span></label>
                    <select id="salary_company" name="salary_company" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="business_div">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Type<span class="text-danger">*</span></label>
                    <select id="salary_type_fill" name="salary_type_fill" class="select3 form-select">
                        <option value="">All</option>
                        <option value="1">Cash</option>
                        <option value="2">Bank</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Date<span class="text-danger">*</span></label>
                    <select id="salary_date_fill" name="salary_date_fill" class="select3 form-select">
                        <option value="">All</option>
                        <option value="1">5th</option>
                        <option value="2">15th</option>
                    </select>
                </div>

                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date of Joining</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                        <option value="0_2_months">0-2 Months</option>
                        <option value="2_4_months">2-4 Months</option>
                        <option value="4_6_months">4-6 Months</option>
                        <option value="gt_6_months">Greater than 6 Months</option>
                        <option value="6_12_months">6-12 Months</option>
                        <option value="gt_1_year">Greater than 1 Year</option>
                        <option value="1_2_years">1-2 Years</option>
                        <option value="gt_2_years">Greater than 2 Years</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mt-4" id="">
                    <label for="exit_staff_fill" class="text-black mt-4 fs-6 fw-semibold">Exit Staff</label>
                    <input type="checkbox" value="1" id="exit_staff_fill" class="form-check-input mt-4">
                </div>
                <div class="col-lg-4 mt-4" id="">
                    <label for="only_bank_fill" class="text-black mt-4 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Without Variable,Performance Incentives">Only Bank Amount</label>
                    <input type="checkbox" value="1" id="only_bank_fill" class="form-check-input mt-4">
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_general/payroll') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row pt-4">
            <div class="col-lg-4">
                <div class="row">
                    
                    <div class="d-flex flex-wrap gap-2" id="payrollWorkflowActions">
                        <button id="generate_payroll_btn" class="btn btn-primary d-none" data-bs-toggle="modal" data-bs-target="#kt_modal_generate_payroll" onclick="openGeneratePayroll()">
                            <span class="d-flex align-items-center">
                            <i class="mdi mdi-cog-play me-1"></i>
                            <span>Payroll Process</span> 
                            </span>
                        </button>

                        <button id="hr_verify_btn" class="btn btn-warning d-none" onclick="openHrVerificationModal()">
                            <span class="d-flex align-items-center">
                            <i class="mdi mdi-account-check me-1"></i>
                            <span>HR Verification</span> 
                            </span>
                        </button>

                        <button id="freeze_payroll_btn"  class="btn btn-danger d-none" onclick="openFreezePayrollModal()">
                            <span class="d-flex align-items-center">
                            <i class="mdi mdi-lock me-1"></i>
                            <span>Freeze Payroll</span> 
                            </span>
                        </button>

                        <button id="send_payslip_btn" class="btn btn-success d-none" data-bs-toggle="modal" data-bs-target="#kt_modal_send_bulk_payslip" onClick='bulkSendPaySlipFunc()'>
                            <span class="d-flex align-items-center">
                            <i class="mdi mdi-send me-1"></i>
                            <span>Send Payslips</span> 
                             @if( $payslipCount > 0)
                            <span class="badge bg-white text-success badge-pill  rounded-circle">
                                {{ $payslipCount }}
                            </span>
                            @endif
                            
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 attendance-cards d-flex align-items-center justify-content-end gap-2">
                <div class="d-flex flex-column gap-1 mb-0 border border-success p-2 rounded bg-label-success text-center card-attendance">
                    <label class="fw-bold text-black percent-value" id="totalEmployees">0</label>
                    <label class="text-black fw-semibold fs-8">Total Staff</label>
                </div>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-warning p-2 rounded bg-label-warning text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalFixedGrossSalary">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Total Gross Salary</label>
                    </div>
                </span>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-warning p-2 rounded bg-label-warning text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalGrossSalary">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Total Earnings</label>
                    </div>
                    <div class="attendance-tooltip shadow-sm" id="grossSalaryTooltip">
                        <div class="tooltip-header">Earnings Breakdown</div>
                        <div id="earningsBreakdown"></div>
                    </div>
                </span>
                <span class="attendance-badge position-relative">
                    <div class="d-flex flex-column gap-1 mb-0 border border-danger p-2 rounded bg-label-danger text-center card-attendance">
                        <label class="fw-bold text-black percent-value" id="totalDeduction">₹ 0</label>
                        <label class="text-black fw-semibold fs-8">Total Deduction</label>
                    </div>
                    <div class="attendance-tooltip shadow-sm" id="deductionTooltip">
                        <div class="tooltip-header">Deductions Breakdown</div>
                        <div id="deductionsBreakdown"></div>
                    </div>
                </span>
                <div class="d-flex flex-column gap-1 mb-0 border border-info p-2 rounded bg-label-info text-center card-attendance">
                    <label class="fw-bold text-black percent-value" id="totalNetSalary">₹ 0</label>
                    <label class="text-black fw-semibold fs-8">Total Net Salary</label>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mt-2">
                <div class="table-responsive">
                    <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                                <th>Staff</th>
                                <th>Date of Joining</th>
                                <th>Basic</th>
                                <th>Earnings</th>
                                <th>Deductions</th>
                                <th>LOP</th>
                                <th class="">Net Salary</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <!-- <tbody id="payrollTable" class="text-black fw-semibold fs-7 "></tbody> -->
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>

                            </tr>
                        </tbody>

                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>
</div>




<!--begin::Modal Generate Payroll--->
<div class="modal fade" id="kt_modal_generate_payroll" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-4">

                        <div class="verify-icon-box">
                            <i class="mdi mdi-cog-play text-success fs-1"></i>
                        </div>

                        <div>
                            <h2 class="fw-bold text-dark mb-1">
                                Generate Payroll
                            </h2>
                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    <div class="">
                        <div class="selected-month-badge" id="selectedPayrollMonth">
                            <i class="mdi mdi-calendar-month me-1"></i>
                            <span>Apr-2026</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="progress rounded mb-4">
                            <div id="payrollProgress" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div id="payrollSteps">
                            <div class="step-item mb-3">
                                <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                                <span class="ms-2 text-black">Attendance Calculation</span>
                            </div>
                            <div class="step-item mb-3">
                                <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                                <span class="ms-2 text-black">LOP Calculation</span>
                            </div>
                            <div class="step-item mb-3">
                                <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                                <span class="ms-2 text-black">PF / ESI Calculation</span>
                            </div>
                            <div class="step-item mb-3">
                                <i class="mdi mdi-checkbox-marked-circle-outline text-success"></i>
                                <span class="ms-2 text-black">Final Salary Processing</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end mt-1" >
                    <button type="button" id="confirmGenerateBtn" class="btn btn-primary" onclick="runPayroll()">Start Generation</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!-- ===================================================== -->
<!-- HR VERIFY MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="kt_modal_hr_verification" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-4">

                        <div class="verify-icon-box">
                            <i class="mdi mdi-account-check text-warning fs-1"></i>
                        </div>

                        <div>

                            <h2 class="fw-bold text-dark mb-1">
                                HR Payroll Verification
                            </h2>

                            <div class="text-dark opacity-75">
                                Validate payroll before final freeze
                            </div>

                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div class="row g-5 mb-7">
                    <div class="col-md-4">
                        <div class="verify-summary-card">
                            <div class="text-muted fs-7 mb-2"> Total Employees</div>
                            <h2 class="fw-bold text-dark mb-0" id="verify_total_employees">0</h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="verify-summary-card">
                            <div class="text-muted fs-7 mb-2">Gross Payroll</div>
                            <h2 class="fw-bold text-success mb-0" id="verify_total_gross">₹0</h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="verify-summary-card">
                            <div class="text-muted fs-7 mb-2">Net Payable</div>
                            <h2 class="fw-bold text-primary mb-0" id="verify_total_netpay">₹0</h2>
                        </div>
                    </div>
                </div>

                <div id="verifyPayrollLoader" class="text-center py-15">
                    <div class="spinner-border text-warning"></div>
                    <div class="mt-4 fw-semibold">
                        Loading Payroll Details...
                    </div>
                </div>

                <div id="verifyPayrollContent" class="d-none">
                    <!-- PROCESS INFO -->
                    <div class="row g-5 mb-6">
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Payroll Month
                                </div>
                                <div class="fw-bold fs-4"
                                    id="verify_process_month">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Status
                                </div>
                                <div id="verify_process_status"></div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Processed By
                                </div>
                                <div class="fw-bold"
                                    id="verify_hr_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Processed At
                                </div>
                                <div class="fw-bold"
                                    id="verify_processed_at">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- PROGRESS -->
                    <div class="mb-7">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="fw-semibold">
                                Payroll Progress
                            </span>
                            <span class="fw-bold"
                                id="verify_processed_employees">
                            </span>
                        </div>
                        <div class="progress h-10px">
                            <div class="progress-bar bg-success"
                                id="verifyProgressBar"
                                style="width:0%">
                            </div>
                        </div>
                    </div>
                    <!-- EMPLOYEE PREVIEW -->
                    <div class="border rounded-4 overflow-hidden">
                        <div class="table-responsive max-h-400px">
                            <table class="table table-row-bordered align-middle mb-0">
                                <thead class="sticky-top">
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                                        <th>Staff</th>
                                        <th>Gross</th>
                                        <th>Deduction</th>
                                        <th>Net Pay</th>
                                    </tr>
                                </thead>
                                <tbody id="verifyEmployeeTable">
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- CHECKLIST -->
                    <div class="border rounded-4 p-5 bg-light">
                        <h5 class="fw-bold mb-5">Verification Checklist</h5>
                        <div class="d-flex flex-column gap-4" id="verificationChecklistContainer">
                        </div>
                    </div>
                    <div class="my-1">
                        <label for="hr_verify_remarks"> Remarks</label>
                        <textarea
                        id="hr_verify_remarks"
                        class="form-control"
                        rows="4"
                        placeholder="Enter HR verification notes">
                        </textarea>
                    </div>
                    
                </div>
                <div id="btn-verify-payroll">
                    <div class="d-flex justify-content-end mt-1" >
                        <button type="button" class="btn btn-primary px-6 btn-verify-payroll" onclick="submitHrVerification()">
                            <i class="mdi mdi-check-circle-outline me-1"></i>Verify Payroll
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!-- ===================================================== -->
<!-- FREEZE PAYROLL MODAL -->
<!-- ===================================================== -->
<div class="modal fade" id="kt_modal_freeze_payroll" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-4">
                        <div class="freeze-icon-box">
                            <i class="mdi mdi-lock text-danger fs-1"></i>
                        </div>
                        <div>
                            <h2 class="fw-bold text-white mb-1">
                                Freeze Payroll
                            </h2>
                            <div class="text-white opacity-75">
                                This action permanently locks payroll
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">

                <div class="alert alert-danger rounded-4">
                    <div class="fw-bold mb-2">Warning</div>
                    After freezing:
                    <ul class="mt-3 mb-0">
                        <li>Payroll cannot be edited</li>
                        <li>Salary becomes locked</li>
                        <li>Payslips become official</li>
                        <li>Compliance snapshot is finalized</li>
                    </ul>
                </div>
                <div class="card border mb-5">
                    <div class="card-header">
                        <h5 class="mb-0">
                            Freeze Validation
                        </h5>
                    </div>

                    <div class="card-body">

                        <div id="freezeValidationList">

                        </div>

                    </div>
                </div>

                <div id="freezePayrollContent" class="d-none">
                    <!-- PROCESS INFO -->
                    <div class="row g-5 mb-6">
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Payroll Month
                                </div>
                                <div class="fw-bold fs-4" id="freeze_payroll_month">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Total Gross
                                </div>
                                <div id="freeze_total_gross"></div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Total Deduction
                                </div>
                                <div class="fw-bold" id="freeze_total_deduction">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="verify-summary-card">
                                <div class="text-muted fs-7">
                                    Total Net
                                </div>
                                <div class="fw-bold"
                                    id="freeze_total_netpay">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card border mb-5">
                    <div class="card-header">
                        HR Verification
                    </div>

                    <div class="card-body">

                        <div>
                            Verified At :
                            <span id="freeze_verified_at"></span>
                        </div>

                        <div class="mt-2">
                            Remarks :
                            <span id="freeze_verification_remarks"></span>
                        </div>

                    </div>
                </div>

                <div class="mt-2">
                    <label class="form-label fw-semibold">
                        Freeze Reason
                    </label>
                    <textarea class="form-control form-control-solid"
                        rows="4"
                        id="freeze_reason"
                        placeholder="Enter freeze reason..."></textarea>

                </div>

                

                <div class="mt-4">
                    <label class="form-check form-check-custom form-check-solid">
                        <input class="form-check-input"
                            type="checkbox"
                            id="freeze_confirmation">
                        <span class="form-check-label fw-semibold text-danger">
                            I confirm payroll verification is completed
                        </span>
                    </label>    
                </div>

                <div id="freezePayrollLoader"
                    class="text-center py-15">

                    <div class="spinner-border text-warning"></div>

                    <div class="mt-4 fw-semibold">
                        Loading Payroll Details...
                    </div>

                </div>

                
        
                <div class="d-flex justify-content-end mt-1">
                    <button id="freezeSubmitBtn" type="button" class="btn btn-primary px-6" onclick="submitFreezePayroll()">
                        <i class="mdi mdi-lock-check-outline me-1"></i>Freeze Payroll
                    </button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="kt_modal_lock_payroll" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content rounded">
            <!-- Modal Header -->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom pb-3">
                <h3 class="text-center text-black">Lock Payroll</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body pt-5 pb-10 px-10 px-xl-20">
                <div class="mb-4">
                    <h6>Are you sure you want to lock the payroll for this period?</h6>
                    <p class="text-muted">Once you lock payroll, no further changes can be made to the entries for the selected month and year.</p>
                </div>
                <div class="form-group">
                    <label for="lockMonth" class="form-label">Select Month and Year</label>
                    <input type="text" class="form-control" id="lockMonth" name="lockMonth" value="{{ date('M-Y') }}" readonly>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" onclick="lockPayroll()">Lock Payroll</button>
            </div>
        </div>
    </div>
</div>

<!--end::Modal - Generate Payroll-->

<div class="modal fade" id="payrollRunModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="payrollRunForm">
                @csrf
                <div class="modal-header">
                    <h5>Generate Payroll</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Month</label>
                        <select name="month" class="form-control select3">
                            @for($i=1;$i<=12;$i++)
                                <option value="{{ $i }}">{{ $i }}</option>
                                @endfor
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Year</label>
                        <input type="number" name="year" class="form-control" value="{{ date('Y') }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" onclick="createPayrollRun()">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- <div class="modal fade" id="breakdown_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5>Salary Breakdown</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <div id="breakdown_body"></div>

                <hr>

                <h6 class="text-danger">Rules Applied</h6>
                <div id="rule_body"></div>

            </div>

        </div>
    </div>
</div> -->
<div class="modal fade" id="breakdown_modal">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="fw-bold">Payroll Breakdown</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <!-- EMPLOYEE INFO -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body d-flex justify-content-between">
                        <div class="d-flex gap-3 align-items-center">
                            <div class="avatar-frame bg-primary">
                                <div class="avatar-inner">
                                    <img src="" alt="staff Image" id="emp_image">
                                </div>
                            </div>
                            <div>
                                <div class="name-title flex-grow-1">
                                    <h4 id="emp_name">Jack</h4>
                                    <div class="d-flex flex-wrap gap-3 align-items-center mt-1">
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-briefcase-outline"></i> <span id="emp_job_role">Position</span> </span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-email-outline"></i> <span id="emp_email">abc@gmail.com</span></span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-phone-outline"></i> <span id="emp_mobile">99989999999</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>




                        <div class="text-end d-flex flex-column justify-content-between">
                            <div>
                                <div>Gross: ₹ <span id="emp_basic"></span></div>
                                <div class="fw-bold text-primary">
                                    Net: ₹ <span id="emp_net"></span>
                                </div>
                            </div>
                            <input type="hidden" name="" id="hidden_entry_encrypt">
                            <div id="payslip_btn_saved" class="d-none">
                                <span class="mdi mdi-download-circle-outline fs-1 fw-bold text-success cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download PaySlip" onclick="printPayslip()"></span>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- ATTENDANCE -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-primary mb-2">Attendance Summary</h6>

                        <div class="row text-center">

                            <div class="col">
                                <div class="fw-bold text-success" id="present"></div>
                                <small>Present</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-danger" id="absent"></div>
                                <small>Absent</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-warning" id="late"></div>
                                <small>Late</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-info" id="lop"></div>
                                <small>LOP Days</small>
                            </div>

                        </div>

                    </div>
                </div>

                <!-- COMPONENTS -->
                <div class="row">

                    <!-- Earnings -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-success">
                                Earnings
                            </div>
                            <div class="card-body" id="earning_body"></div>
                        </div>
                    </div>

                    <!-- Deductions -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-danger">
                                Deductions
                            </div>
                            <div class="card-body" id="deduction_body"></div>
                        </div>
                    </div>

                    <!-- Employer -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-info">
                                Employer Contribution
                            </div>
                            <div class="card-body" id="employer_body"></div>
                        </div>
                    </div>

                </div>

                <!-- RULES -->
                <!-- <div class="card mt-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-danger">Rule Breakdown</h6>

                        <div id="rule_body"></div>

                    </div>
                </div> -->

                <!-- FINAL SUMMARY -->
                <div class="card mt-3 shadow-sm bg-label-primary">
                    <div class="card-body">

                        <div class="d-flex justify-content-between">
                            <span>Total Earnings</span>
                            <span id="total_earn"></span>
                        </div>

                        <div class="d-flex justify-content-between">
                            <span>Total Deductions</span>
                            <span id="total_ded"></span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Net Salary</span>
                            <span id="net_salary_final"></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Employer Contribution</span>
                            <span id="total_employer"></span>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="saved_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5>Saved Payroll Details</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>


            <div class="modal-body">

                <!-- EMPLOYEE INFO -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body d-flex justify-content-between">
                        <div class="d-flex gap-3 align-items-center">
                            <div class="avatar-frame bg-primary">
                                <div class="avatar-inner">
                                    <img src="" alt="staff Image" id="emp_image_saved">
                                </div>
                            </div>
                            <div>
                                <div class="name-title flex-grow-1">
                                    <h4 id="emp_name_saved">Jack</h4>
                                    <div class="d-flex flex-wrap gap-3 align-items-center mt-1">
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-briefcase-outline"></i> <span id="emp_job_role_saved">Position</span> </span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-email-outline"></i> <span id="emp_email_saved">abc@gmail.com</span></span>
                                        <span class="badge-professional badge bg-label-primary rounded"><i class="mdi mdi-phone-outline"></i> <span id="emp_mobile_saved">99989999999</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <input type="hidden" name="" id="hidden_entry_encrypt">
                        <div class="text-end d-flex flex-column justify-content-between">
                            <div>
                                <div>Gross: ₹ <span id="emp_basic_saved"></span></div>
                                <div class="fw-bold text-primary">
                                    Net: ₹ <span id="emp_net_saved"></span>
                                </div>
                            </div>
                            <div>
                                <span class="mdi mdi-download-circle-outline fs-1 fw-bold text-success cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download PaySlip" onclick="printPayslip()"></span>
                            </div>
                        </div>


                    </div>
                </div>

                <!-- ATTENDANCE -->
                <div class="card mb-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-primary mb-2">Attendance Summary</h6>

                        <div class="row text-center">

                            <div class="col">
                                <div class="fw-bold text-success" id="present_saved"></div>
                                <small>Present</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-danger" id="absent_saved"></div>
                                <small>Absent</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-warning" id="late_saved"></div>
                                <small>Late</small>
                            </div>

                            <div class="col">
                                <div class="fw-bold text-info" id="lop_saved"></div>
                                <small>LOP Days</small>
                            </div>

                        </div>

                    </div>
                </div>

                <!-- COMPONENTS -->
                <div class="row">

                    <!-- Earnings -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-success">
                                Earnings
                            </div>
                            <div class="card-body" id="earning_body_saved"></div>
                        </div>
                    </div>

                    <!-- Deductions -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-danger">
                                Deductions
                            </div>
                            <div class="card-body" id="deduction_body_saved"></div>
                        </div>
                    </div>

                    <!-- Employer -->
                    <div class="col-md-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-label-info">
                                Employer Contribution
                            </div>
                            <div class="card-body" id="employer_body_saved"></div>
                        </div>
                    </div>

                </div>

                <!-- RULES -->
                <!-- <div class="card mt-3 shadow-sm">
                    <div class="card-body">

                        <h6 class="fw-bold text-danger">Rule Breakdown</h6>

                        <div id="saved_body"></div>

                    </div>
                </div> -->

                <!-- FINAL SUMMARY -->
                <div class="card mt-3 shadow-sm bg-label-primary">
                    <div class="card-body">

                        <div class="d-flex justify-content-between">
                            <span>Total Earnings</span>
                            <span id="total_earn_saved"></span>
                        </div>

                        <div class="d-flex justify-content-between">
                            <span>Total Deductions</span>
                            <span id="total_ded_saved"></span>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between fw-bold fs-5">
                            <span>Net Salary</span>
                            <span id="net_salary_final_saved"></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Employer Contribution</span>
                            <span id="total_employer_saved"></span>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="kt_modal_send_bulk_payslip" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded shadow">

            <!-- Header -->
            <div class="modal-header border-0 pb-0">
                <h3 class="fw-bold text-dark">Send Payslip</h3>

                <button type="button" class="btn btn-sm btn-icon" data-bs-dismiss="modal">
                    ✕
                </button>
            </div>

            <!-- Body -->
            <div class="modal-body pt-2 px-10 pb-8">

                <!-- Payroll Info -->
                <div class="row mb-5">
                    <div class="col-lg-6">
                        <p><strong>Month:</strong> <span id="payslip_month"></span></p>
                        <p><strong>Total Staff:</strong> <span id="payslip_total"></span></p>
                    </div>
                    <div class="col-lg-6 text-lg-end">
                        <button id="bulkSendBtn" class="btn btn-danger">
                            Send Payslips
                        </button>
                    </div>
                </div>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle" id="payslip_table">
                        <thead class="bg-primary">
                            <tr>
                                <th>
                                    <input type="checkbox" id="selectAll" class="form-check-input border border-3">
                                </th>
                                <th>Staff</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    let currentPage = 1;
    let currentMonth = @json(date('M-Y'));
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);
    let payrollData = [];
    let previewData = [];
    let currentPayrollProcessId = null;



    $(document).ready(function() {

        $('#global_date_picker').datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        }).on('changeDate', function() {
            currentMonth = $(this).val();
            loadThemes(1);
        });

    });


    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    // function getExperienceDuration(joinDate) {
    //     if (!joinDate) return '-';

    //     const start = new Date(joinDate);
    //     const now = new Date();

    //     if (isNaN(start)) return '-'; // invalid date safeguard

    //     // Determine direction
    //     const isFuture = start > now;
    //     const earlier = isFuture ? now : start;
    //     const later = isFuture ? start : now;

    //     // Calculate raw differences
    //     let years = later.getFullYear() - earlier.getFullYear();
    //     let months = later.getMonth() - earlier.getMonth();
    //     let days = later.getDate() - earlier.getDate();

    //     // Adjust days
    //     if (days < 0) {
    //         const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
    //         days += prevMonth.getDate();
    //         months--;
    //     }

    //     // Adjust months
    //     if (months < 0) {
    //         months += 12;
    //         years--;
    //     }

    //     // Build result text
    //     let result = '';
    //     if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
    //     if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
    //     if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

    //     if (!result.trim()) result = '0 days';

    //     result = result.trim();

    //     // Add "In" or "Ago"
    //     if (isFuture) {
    //         result = `In ${result}`;
    //     } else if (result !== '0 days') {
    //         // result += ' ago';
    //         result += '';
    //     }

    //     return result;
    // }

    function getExperienceDuration(
        joinDate,
        status = 0,
        staffLastDate = null,
        noticeEndDate = null
    ) {

        if (!joinDate) return '-';
        const start = new Date(joinDate);
        if (isNaN(start)) return '-';
        /*
        |--------------------------------------------------------------------------
        | END DATE BASED ON STATUS
        |--------------------------------------------------------------------------
        */
        let endDate = new Date();
        /*
        |--------------------------------------------------------------------------
        | NOTICE PERIOD STAFF
        |--------------------------------------------------------------------------
        */
        if (
            status == 4 &&
            noticeEndDate
        ) {

            endDate = new Date(noticeEndDate);
        }
        /*
        |--------------------------------------------------------------------------
        | EXIT STAFF
        |--------------------------------------------------------------------------
        */
        else if (
            [5, 6, 7].includes(parseInt(status)) &&
            staffLastDate
        ) {

            endDate = new Date(staffLastDate);
        }
        /*
        |--------------------------------------------------------------------------
        | INVALID DATE SAFEGUARD
        |--------------------------------------------------------------------------
        */
        if (isNaN(endDate)) {
            endDate = new Date();
        }
        /*
        |--------------------------------------------------------------------------
        | DETERMINE DIRECTION
        |--------------------------------------------------------------------------
        */
        const isFuture = start > endDate;
        const earlier = isFuture ? endDate : start;
        const later = isFuture ? start : endDate;
        /*
        |--------------------------------------------------------------------------
        | CALCULATE DIFFERENCE
        |--------------------------------------------------------------------------
        */
        let years =
            later.getFullYear()
            - earlier.getFullYear();
        let months =
            later.getMonth()
            - earlier.getMonth();
        let days =
            later.getDate()
            - earlier.getDate();
        /*
        |--------------------------------------------------------------------------
        | ADJUST DAYS
        |--------------------------------------------------------------------------
        */
        if (days < 0) {
            const prevMonth =
                new Date(
                    later.getFullYear(),
                    later.getMonth(),
                    0
                );
            days += prevMonth.getDate();
            months--;
        }
        /*
        |--------------------------------------------------------------------------
        | ADJUST MONTHS
        |--------------------------------------------------------------------------
        */
        if (months < 0) {
            months += 12;
            years--;
        }
        /*
        |--------------------------------------------------------------------------
        | BUILD RESULT
        |--------------------------------------------------------------------------
        */
        let result = '';
        if (years > 0) {
            result += `${years} yr${years > 1 ? 's' : ''} `;
        }
        if (months > 0) {
            result += `${months} month${months > 1 ? 's' : ''} `;
        }
        if (days > 0) {
            result += `${days} day${days > 1 ? 's' : ''}`;
        }
        if (!result.trim()) {
            result = '0 day';
        }
        return result.trim();
    }

    function buildRow(item, index) {

        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
        var dataParoll = typeof item.dataParoll === 'string' ? JSON.parse(item.dataParoll) : item.dataParoll;

        let staff_image = '';
        if (item.isStaffImage) {
            if (data.staff_image && data.staff_image.trim() !== '') {
                if (data.company_type == 1) {
                    staff_image = `staff_images/Management/${data.staff_image}`;
                } else {
                    staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;

        let payslipBtn = item.is_saved

            ?
            `<button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#breakdown_modal"
             onclick="viewBreakdown(${item.sno})" > 
             <i class="mdi mdi-eye"></i>Payslip
            </button>`

            :
            `<button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#breakdown_modal"
            onclick="viewBreakdown(${item.sno})" >
                <i class="mdi mdi-eye"></i>
            </button>`;

        let existStatus = '';
        let  existColor = '';
        let  last_date = '';
        switch (item.staff_status) {
            case 4:
                existStatus = 'Notice Period';
                existColor = 'bg-secondary';
                last_date = item.notice_end_date ? formatDateCommon(item.notice_end_date) : '';
                break;
            case 5: 
                existStatus = 'Relive';
                existColor = 'bg-success';
                last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
            case 6: 
                existStatus = 'Abscond';
                existColor = 'bg-warning';
                  last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
            case 7: 
                existStatus = 'Terminate';
                existColor = 'bg-danger';
                  last_date = item.staff_last_date ? formatDateCommon(item.staff_last_date) : '';
                break;
        }

        return `
            <tr>
                <td style="position:relative;">
                    <!-- Left colored bar for company -->
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || '#6c757d'};"></div>

                    <div class="d-flex align-items-center ps-2">
                        <!-- Staff Image -->
                        <div class="symbol symbol-40px me-3">
                            <div class="image-input image-input-circle">
                                <img src="${staff_image}" 
                                    alt="user-avatar"  
                                    class="rounded-circle"
                                    style="width:40px; height:40px; object-fit:fill;"
                                    onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}${data.gender == 1 ? 'user_2.png' : 'user_7.png'}';"/>
                            </div>
                        </div>

                        <!-- Staff Info -->
                        <div class="d-flex flex-column flex-grow-1">
                            <!-- Name + Gender Icon -->
                            <div class="d-flex align-items-center flex-wrap">
                                <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                                    data-bs-toggle="tooltip" title="${item.name}">
                                    ${item.name}
                                </span>

                                ${data.gender == 1 
                                    ? `<i class="mdi mdi-face-man text-info fs-7" data-bs-toggle="tooltip" title="Male"></i>` 
                                    : `<i class="mdi mdi-face-woman text-pink fs-7" data-bs-toggle="tooltip" title="Female"></i>`
                                }
                            </div>

                            <!-- Employee ID + Nickname -->
                            <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                                <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${data.staff_code  || '-'}</span>
                                <span class="text-primary" data-bs-toggle="tooltip" title="Nickname">${data.nick_name || '-'}</span>
                            </div>

                            <!-- Company Badge -->
                            <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                                style="background-color:${item.company_base_color || '#6c757d'}; color:#fff; max-width:150px;"
                                data-bs-toggle="tooltip" title="${data.company_name || '-'}">
                                ${data.company_name || '-'}
                            </span>

                            <!-- Department Badge -->
                            <span class="badge bg-warning fs-8 text-truncate mb-1 text-black" 
                                style="max-width: 120px;" 
                                data-bs-toggle="tooltip" title="${data.department_name || '-'}">
                                ${data.department_name || '-'}
                            </span>

                            <!-- Job Role Badge (truncated) -->
                            <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                                style="color: #046d85 !important; max-width:150px;" 
                                data-bs-toggle="tooltip" title="${data.job_role_name || '-'}">
                                ${data.job_role_name || '-'}
                            </span>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column mb-1">
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                           ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                        </label>
                        <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                           ${data.date_of_joining
                                ? getExperienceDuration(
                                    data.date_of_joining,
                                    item.staff_status,
                                    item.staff_last_date,
                                    item.notice_end_date
                                )
                                : '0 Day'}
                        </label>
                    </div>
                    <div>
                        <label class="badge ${existColor} fs-7 text-black fw-bold mb-2">
                        ${existStatus}
                        </label>
                        <span class="d-block">
                            <span class="text-danger" data-bs-toggle="tooltip" title="Last Date">${last_date || ''}</span>
                        </span>
                    </div>
                </td>
                <td align="right">
                    <label class="badge bg-label-success mb-2 text-nowrap">
                        <span class="mdi mdi-currency-rupee   fs-8"></span>
                        <span class="fs-7">${data.basic_salary ? new Intl.NumberFormat('en-IN').format(data.basic_salary) :'0'}</span>
                    </label>
                    <div>
                        <label class="badge bg-label-primary text-nowrap">
                            <span class="fs-7">
                                ${
                                    data.salary_type == 1 ? 'Cash' :
                                    data.salary_type == 2 ? 'Bank' : '-'
                                }
                            </span>
                        </label>
                        <label class="badge bg-label-info text-nowrap">
                            <span class="fs-7">
                                ${
                                    data.salary_date == 1 ? '5th' :
                                    data.salary_date == 2 ? '15th' : '-'
                                }
                            </span>
                        </label>
                    </div>
                    
                </td>
                <td>
                    <span class="text-sucess fs-5 text-nowrap"> 
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.earnings ? new Intl.NumberFormat('en-IN').format(dataParoll.earnings) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="text-danger fs-5 text-nowrap">
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.deductions ? new Intl.NumberFormat('en-IN').format(dataParoll.deductions) :'0'}</span>
                    </span>
                </td>
                <td>
                    <span class="badge bg-label-danger fs-5 text-nowrap"> ${dataParoll.lop_days}</span>
                </td>
                <td>
                    <span class="text-success fw-bold fs-5 text-nowrap">
                        <span class="mdi mdi-currency-rupee "></span>
                        <span class="">${dataParoll.net ? new Intl.NumberFormat('en-IN').format(dataParoll.net) :'0'}</span>
                    </span> 
                </td>
                <td>
                    ${payslipBtn}
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        // const company_fill = '';
        const company_fill = document.getElementById('company_fill').value;
        const salary_company = document.getElementById('salary_company').value;
        // const entity_fill = ''
        const entity_fill = document.getElementById('entity_fill').value;
        const monthFilter = $('#global_date_picker').val() || currentMonth;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const department_fill = document.getElementById('department_fill').value;
        const salary_date_fill = document.getElementById('salary_date_fill').value;
        const salary_type_fill = document.getElementById('salary_type_fill').value;
        const exit_staff_fill = $('#exit_staff_fill').is(':checked') ? 1 : 0;
        const only_bank_fill = $('#only_bank_fill').is(':checked') ? 1 : 0;
        console.log(monthFilter)

        const url = `/hr_general/payroll?page=${page}&sorting_filter=${perpage}&search_filter=${search}&salary_company=${salary_company}&company_fill=${company_fill}&entity_fill=${entity_fill}&month_filter=${monthFilter}&department_fill=${department_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}&salary_date_fill=${salary_date_fill}&salary_type_fill=${salary_type_fill}&exit_staff_fill=${exit_staff_fill}&only_bank_fill=${only_bank_fill}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        let totalSalary = 0;
        let totalDeduction = 0;
        $('#totalEmployees').text(0);
                    $('#totalNetSalary').text("₹0");
                    $('#totalGrossSalary').text("₹0");
                    $('#totalFixedGrossSalary').text("₹0");
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                previewData = res.data;
                currentPayrollProcessId = res.payroll_process_id ? res.payroll_process_id : '';
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        totalSalary += parseFloat(item.net_salary);
                        totalDeduction += parseFloat(item.lop_amount) + parseFloat(item.pf_amount) + parseFloat(item.esi_amount);
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });





                    $('#totalEmployees').text(res.total);
                    let total_net_salary = res.total_net_salary ? new Intl.NumberFormat('en-IN').format(res.total_net_salary) : '0';
                    let total_gross_salary = res.total_gross_salary ? new Intl.NumberFormat('en-IN').format(res.total_gross_salary) : '0';
                    let total_fixed_gross_salary = res.total_fixed_gross_salary ? new Intl.NumberFormat('en-IN').format(res.total_fixed_gross_salary) : '0';
                    let total_deduction = res.total_deduction ? new Intl.NumberFormat('en-IN').format(res.total_deduction) : '0';

                    $('#totalNetSalary').text("₹" + total_net_salary);
                    $('#totalGrossSalary').text("₹" + total_gross_salary);
                    $('#totalFixedGrossSalary').text("₹" + total_fixed_gross_salary);
                    $('#totalDeduction').text("₹" + total_deduction);

                    let earningsHtml = '';

                    if (res.earnings_summary && res.earnings_summary.length > 0) {

                        res.earnings_summary.forEach(item => {
                            let amount = new Intl.NumberFormat('en-IN').format(item.total);

                            earningsHtml += `
                                <div class="tooltip-row fancy">
                                    <span class="label fw-bold fs-6">${item.name}</span>
                                    <span class="value fw-bold fs-6 text-nowrap">₹ ${amount}</span>
                                </div>
                            `;
                        });

                    } else {
                        earningsHtml = `<div class="text-muted text-center">No Data</div>`;
                    }

                    document.getElementById('earningsBreakdown').innerHTML = earningsHtml;

                    let deductionsHtml = '';

                    if (res.deductions_summary && res.deductions_summary.length > 0) {

                        res.deductions_summary.forEach(item => {
                            let amount = new Intl.NumberFormat('en-IN').format(item.total);

                            deductionsHtml += `
                                <div class="tooltip-row fancy">
                                    <span class="label fs-6 fw-bold">${item.name}</span>
                                    <span class="value fs-6 fw-bold text-nowrap text-danger">₹ ${amount}</span>
                                </div>
                            `;
                        });

                    } else {
                        deductionsHtml = `<div class="text-muted text-center">No Data</div>`;
                    }

                    document.getElementById('deductionsBreakdown').innerHTML = deductionsHtml;

                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                    document.getElementById('deductionsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    document.getElementById('earningsBreakdown').innerHTML = '<div class="text-muted text-center">No Data</div>';
                    $('#totalEmployees').text(0);
                    $('#totalNetSalary').text("₹0");
                    $('#totalGrossSalary').text("₹0");
                    $('#totalFixedGrossSalary').text("₹0");
                }

                updatePayrollWorkflow(res.workflow);
                renderWorkflowStatus(res.workflow);

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        $('#salary_company').val('').change();
        $('#company_fill').val('').change();
        $('#entity_fill').val('').change();
        $('#department_fill').val('').change();
        $('#dt_fill_issue_rpt').val('all').change();
        $('#salary_date_fill').val('').change();
        $('#salary_type_fill').val('').change();
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });
    // Initial load
    loadThemes(1);
</script>
<script>
    function viewBreakdown(staffId) {

        let staff = previewData.find(x => x.sno == staffId);

        var data = typeof staff.data === 'string' ? JSON.parse(staff.data) : staff.data;
        var dataParoll = typeof staff.dataParoll === 'string' ? JSON.parse(staff.dataParoll) : staff.dataParoll;

        let staff_image = '';
        if (staff.isStaffImage) {
            if (data.staff_image && data.staff_image.trim() !== '') {
                if (data.company_type == 1) {
                    staff_image = `staff_images/Management/${data.staff_image}`;
                } else {
                    staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;
        let absentdays = parseInt(staff.absent_days) || 0;
        let leavedays = parseInt(staff.leave_days) || 0;
        let totalLeavedays = absentdays + leavedays;

        // 👉 BASIC INFO
        $('#emp_image').attr('src', staff_image);
        $('#emp_name').text(staff.name);
        $('#emp_email').text(data.email_id);
        $('#emp_job_role').text(data.job_role_name);
        $('#emp_mobile').text(data.mobile_no);
        $('#emp_basic').text(staff.basic_salary);
        $('#emp_net').text(dataParoll.net);

        $('#present').text(staff.present_days || 0);
        $('#absent').text(totalLeavedays || 0);
        $('#late').text(staff.late_count || 0);
        $('#lop').text(dataParoll.lop_days);

        $('#hidden_entry_encrypt').val(staff.entry_encrypt)

        // 👉 EARNINGS
        let earnHTML = '';
        let dedHTML = '';
        let employerHTML = '';

        if (
            dataParoll.components &&
            dataParoll.components.length > 0
        ) {

            dataParoll.components.forEach(c => {

                let row = `
                <div class="d-flex justify-content-between border-bottom py-2">
                    <span class="fw-semibold">
                        ${c.component || '-'}
                    </span>

                    <span class="fw-bold text-nowrap">
                        ₹ ${new Intl.NumberFormat('en-IN')
                            .format(c.amount || 0)}
                    </span>
                </div>`;

                if (c.type === 'earning') {

                    earnHTML += row;

                } else if (c.type === 'deduction') {

                    dedHTML += row;

                } else if (
                    c.type === 'employer_contribution'
                ) {

                    employerHTML += row;
                }
            });

        } else {

            earnHTML = `
                <div class="text-muted text-center py-3">
                    No Earnings Found
                </div>
            `;

            dedHTML = `
                <div class="text-muted text-center py-3">
                    No Deductions Found
                </div>
            `;
            employerHTML = `
                <div class="text-muted text-center py-3">
                    No Employer Contribution Found
                </div>
            `;
        }

        $('#earning_body').html(earnHTML);

        $('#deduction_body').html(dedHTML);
        $('#employer_body').html(employerHTML);


        // $('#earning_body').html(earnHTML);
        // $('#deduction_body').html(dedHTML);

        // // 👉 RULES
        // let ruleHTML = '';

        // dataParoll.rules.forEach(r => {

        //     ruleHTML += `
        //     <div class="border rounded p-2 mb-2">

        //         <div class="fw-bold text-danger">${r.rule}</div>

        //         <div class="small text-muted">
        //             Days: ${r.days || '-'} |
        //             Amount: ₹ ${r.amount}
        //         </div>

        //     </div>
        //     `;
        // });

        // $('#rule_body').html(ruleHTML);

        // 👉 SUMMARY
        $('#total_earn').text('₹ ' + dataParoll.earnings);
        $('#total_ded').text('₹ ' + dataParoll.deductions);
        $('#net_salary_final').text('₹ ' + dataParoll.net);
        $('#total_employer').text(
            '₹ ' + dataParoll.employer_contribution
        );

        if(staff.is_saved){
            $('#payslip_btn_saved').removeClass('d-none')
           
        }else{
            $('#payslip_btn_saved').addClass('d-none')
        }

        // $('#breakdown_modal').modal('show');
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
    $(".list_page_empty").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    function openPayrollRunModal() {
        $('#payrollRunModal').modal('show');
    }

    function createPayrollRun() {
        $.post('/payroll/run/create',
            $('#payrollRunForm').serialize(),
            function(res) {
                if (res.status)
                    location.reload();
            });
    }

    function processPayroll(runSno) {

        if (!confirm('Process payroll now?')) return;

        $.post('/payroll/run/process/' + runSno, {
                _token: '{{ csrf_token() }}'
            },
            function(res) {
                toastr.success(res.message);
                // location.reload();
            });

    }


    // function runPayroll(){

    //     $.post('/payroll/run_new',{
    //         month: $('#month').val(),
    //         year: $('#year').val(),
    //         _token:'{{ csrf_token() }}'
    //     },function(){

    //         toastr.success('Payroll Generated');

    //         loadPayrollList();

    //     });

    // }

    // function lockPayroll(){

    //     $.post('/payroll/lock',{
    //         month: $('#month').val(),
    //          year: $('#year').val(),
    //         _token:'{{ csrf_token() }}'
    //     },function(){

    //         toastr.success('Payroll Locked');

    //     });

    // }

    function loadPayrollList() {

        let month = $('#month').val();

        $.get('/payroll/list', {
            month: month
        }, function(res) {

            let html = '';

            res.forEach(row => {

                html += `
            <tr>

                <td>${row.name}</td>
                <td>${row.basic_salary}</td>

                <td class="text-success">
                    ₹ ${row.total_earnings}
                </td>

                <td class="text-danger">
                    ₹ ${row.total_deductions}
                </td>

                <td class="fw-bold text-primary">
                    ₹ ${row.net_salary}
                </td>

                <td>${row.lop_days}</td>

                <td class="d-flex gap-1">

                    <button class="btn btn-sm btn-info"
                        onclick="viewBreakdownSaved(${row.entry_id},'${row.entry_encrypt}')">
                        View
                    </button>

                    <button class="btn btn-sm btn-dark"
                        onclick="viewPayslip('${row.entry_encrypt}')">
                        Payslip
                    </button>

                </td>

            </tr>
            `;

            });

            $('#payroll_preview').html(html);

        });

    }


    // function loadPreview(){

    //     $.get('/payroll/preview',{
    //         month_filter: $('#global_date_picker').val(),
    //     },function(res){

    //         let html = '';
    //         previewData =res;
    //         res.forEach(row => {

    //             html += `
    //             <tr>

    //                 <td>${row.name}</td>
    //                 <td>${row.basic}</td>
    //                 <td class="text-success">${row.earnings}</td>
    //                 <td class="text-danger">${row.deductions}</td>
    //                 <td class="fw-bold">${row.net}</td>
    //                 <td>${row.lop_days}</td>

    //                 <td>
    //                     <button class="btn btn-sm btn-info"
    //                         onclick="viewBreakdown(${row.staff_id})">
    //                         View
    //                     </button>
    //                 </td>

    //             </tr>
    //             `;

    //         });

    //         $('#payroll_preview').html(html);

    //     });

    // }

    // function viewBreakdown(staffId){

    //     let staff = previewData.find(x => x.staff_id == staffId);

    //     let html = '';

    //     staff.components.forEach(c => {

    //         html += `
    //         <div class="d-flex justify-content-between">
    //             <span>${c.name}</span>
    //             <span>${c.amount}</span>
    //         </div>
    //         `;

    //     });

    //     $('#breakdown_body').html(html);
    //     $('#breakdown_modal').modal('show');

    // }


    // function viewBreakdown(staffId){

    //     let staff = previewData.find(x => x.staff_id == staffId);
    //     console.log(staff)
    //     let html = '<h6 class="text-success">Components</h6>';
    //     if(staff.components.length>0){
    //         staff.components.forEach(c => {
    //             html += `
    //             <div class="d-flex justify-content-between border-bottom py-1">
    //                 <span>${c.name}</span>
    //                 <span>₹ ${c.amount}</span>
    //             </div>`;
    //         });
    //     }

    //     let ruleHtml = '';

    //     staff.rules.forEach(r => {
    //         ruleHtml += `
    //         <div class="d-flex justify-content-between border-bottom py-1">
    //             <span>${r.rule}</span>
    //             <span>₹ ${r.amount}</span>
    //         </div>`;
    //     });

    //     $('#breakdown_body').html(html);
    //     $('#rule_body').html(ruleHtml);

    //     $('#breakdown_modal').modal('show');
    // }

    function viewBreakdownSaved(entryId, encrypt_id) {

        $('#hidden_entry_encrypt').val(encrypt_id)

        $.get('/payroll/entry/' + entryId, function(res) {

            let staff = res.data;

            var data = typeof staff.data === 'string' ? JSON.parse(staff.data) : staff.data;
            var dataParoll = typeof staff.dataParoll === 'string' ? JSON.parse(staff.dataParoll) : staff.dataParoll;

            let staff_image = '';
            if (staff.isStaffImage) {
                if (data.staff_image && data.staff_image.trim() !== '') {
                    if (data.company_type == 1) {
                        staff_image = `staff_images/Management/${data.staff_image}`;
                    } else {
                        staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
                    }
                } else {
                    staff_image = data.gender == 1 ?
                        'assets/egc_images/auth/user_2.png' :
                        'assets/egc_images/auth/user_7.png';
                }
            } else {
                staff_image = data.gender == 1 ?
                    'assets/egc_images/auth/user_2.png' :
                    'assets/egc_images/auth/user_7.png';
            }

            staff_image = `{{ asset('${staff_image}') }}`;
            let absentdays = parseInt(staff.absent_days) || 0;
            let leavedays = parseInt(staff.leave_days) || 0;
            let totalLeavedays = absentdays + leavedays;

            // 👉 BASIC INFO
            $('#emp_image_saved').attr('src', staff_image);
            $('#emp_name_saved').text(staff.name);
            $('#emp_email_saved').text(data.email_id);
            $('#emp_job_role_saved').text(data.job_role_name);
            $('#emp_mobile_saved').text(data.mobile_no);
            $('#emp_basic_saved').text(staff.basic_salary);
            $('#emp_net_saved').text(dataParoll.net);

            $('#present_saved').text(staff.present_days || 0);
            $('#absent_saved').text(totalLeavedays || 0);
            $('#late_saved').text(staff.late_count || 0);
            $('#lop_saved').text(dataParoll.lop_days);

            // 👉 EARNINGS
            let earnHTML = '';
            let dedHTML = '';
            let employerHTML = '';

            if (
                dataParoll.components &&
                dataParoll.components.length > 0
            ) {

                dataParoll.components.forEach(c => {

                    let row = `
                <div class="d-flex justify-content-between border-bottom py-2">
                    <span class="fw-semibold">
                        ${c.component || '-'}
                    </span>

                    <span class="fw-bold text-nowrap">
                        ₹ ${new Intl.NumberFormat('en-IN')
                            .format(c.amount || 0)}
                    </span>
                </div>`;

                    if (c.type === 'earning') {

                        earnHTML += row;

                    } else if (c.type === 'deduction') {

                        dedHTML += row;

                    } else if (
                        c.type === 'employer_contribution'
                    ) {

                        employerHTML += row;
                    }
                });

            } else {

                earnHTML = `
                <div class="text-muted text-center py-3">
                    No Earnings Found
                </div>
            `;

                dedHTML = `
                <div class="text-muted text-center py-3">
                    No Deductions Found
                </div>
            `;
                employerHTML = `
                    <div class="text-muted text-center py-3">
                        No Employer Contribution Found
                    </div>
                `;
            }

            $('#earning_body_saved').html(earnHTML);

            $('#deduction_body_saved').html(dedHTML);
            $('#employer_body_saved').html(employerHTML);


            // 👉 RULES
            let ruleHTML = '';

            // dataParoll.rules.forEach(r => {

            //     ruleHTML += `
            //     <div class="border rounded p-2 mb-2">

            //         <div class="fw-bold text-danger">${r.rule}</div>

            //         <div class="small text-muted">
            //             Days: ${r.days || '-'} |
            //             Amount: ₹ ${r.amount}
            //         </div>

            //     </div>
            //     `;
            // });

            // $('#saved_body').html(ruleHTML);

            //  SUMMARY
            $('#total_earn_saved').text('₹ ' + dataParoll.earnings);
            $('#total_ded_saved').text('₹ ' + dataParoll.deductions);
            $('#net_salary_final_saved').text('₹ ' + dataParoll.net);
            $('#total_employer_saved').text(
                '₹ ' + dataParoll.employer_contribution
            );



        });

    }
    // function exportExcel(){

    //     let month = $('#global_date_picker').val();

    //     window.location.href = '/payroll/export?month_filter='+month;

    // }

    function exportExcel() {

        let month = $('#global_date_picker').val();

        const salary_company = $('#salary_company').val();
        const company_fill = $('#company_fill').val();
        const entity_fill = $('#entity_fill').val();
        const salary_date_fill = $('#salary_date_fill').val();
        const salary_type_fill = $('#salary_type_fill').val();
        const only_bank_fill = $('#only_bank_fill').is(':checked') ? 1 : 0;

        let url =
            `/payroll/export?month_filter=${encodeURIComponent(month)}`
            + `&salary_company=${salary_company}`
            + `&company_fill=${company_fill}`
            + `&entity_fill=${entity_fill}`
            + `&only_bank_fill=${only_bank_fill}`
            + `&salary_date_fill=${salary_date_fill}`
            + `&salary_type_fill=${salary_type_fill}`;

        window.open(url, '_blank', 'noopener,noreferrer');
    }

   


    // function runPayroll(){

    //     $('#kt_modal_generate_payroll').modal('show');

    //     let steps = [
    //         'Attendance Calculation',
    //         'LOP Calculation',
    //         'PF / ESI Calculation',
    //         'Final Salary Processing'
    //     ];

    //     let i = 0;

    //     let interval = setInterval(()=>{

    //         if(i >= steps.length){
    //             clearInterval(interval);

    //             $.post('/payroll/run_new',{
    //                 month: $('#global_date_picker').val(),
    //                 _token:'{{ csrf_token() }}'
    //             },function(){

    //                 toastr.success('Payroll Generated');

    //                 $('#kt_modal_generate_payroll').modal('hide');
    //                 loadPayrollList();

    //             });

    //         }

    //         i++;

    //     },800);

    // }


    // function runPayroll() {

    //     // $('#kt_modal_generate_payroll').modal('show');
    //     $('#confirmGenerateBtn').prop('disabled', true).text('Processing...');

    //     let steps = [
    //         'Attendance Calculation',
    //         'LOP Calculation',
    //         'PF / ESI Calculation',
    //         'Final Salary Processing'
    //     ];

    //     let i = 0;
    //     let interval = setInterval(() => {
    //         if (i < steps.length) {
    //         $('#payrollSteps .step-item').eq(i).find('i').removeClass('mdi-checkbox-marked-circle-outline').addClass('mdi-checkbox-marked-circle');
    //         $('#payrollSteps .step-item').eq(i).find('span').addClass('text-success');
    //         $('#payrollProgress').css('width', ((i + 1) * 25) + '%');
    //         }

    //         if (i >= steps.length) {
    //             clearInterval(interval);

    //             $.post('/payroll/run_new', {
    //                 month_filter: $('#global_date_picker').val(),
    //                 _token: '{{ csrf_token() }}'
    //             }, function () {
    //                 toastr.success('Payroll Generated');

    //                 $('#kt_modal_generate_payroll').modal('hide');
    //                 loadthemes(1);
    //                 $('#confirmGenerateBtn').prop('disabled', false).text('Start Generation');
    //             });
    //         }else{
    //              $('#confirmGenerateBtn').prop('disabled', false).text('Start Generation');
    //         }

    //         i++;
    //     }, 800);
    // }

    function runPayroll() {

        const btn = $('#confirmGenerateBtn');
        btn.prop('disabled', true).text('Processing...');

        let steps = [
            'Attendance Calculation',
            'LOP Calculation',
            'PF / ESI Calculation',
            'Final Salary Processing'
        ];

        let i = 0;

        // RESET UI FIRST
        $('#payrollSteps .step-item i')
            .removeClass()
            .addClass('mdi mdi-progress-clock text-muted');

        $('#payrollSteps .step-item span')
            .removeClass('text-success text-danger')
            .addClass('text-muted');

        $('#payrollProgress').css('width', '0%');

        let interval = setInterval(() => {

            if (i < steps.length) {

                let step = $('#payrollSteps .step-item').eq(i);

                // LOADING STATE
                step.find('i')
                    .removeClass()
                    .addClass('mdi mdi-loading mdi-spin text-primary');

                step.find('span')
                    .removeClass('text-muted')
                    .addClass('text-primary');

                $('#payrollProgress').css('width', ((i + 1) * 25) + '%');
            }

            // LAST STEP → CALL API
            if (i >= steps.length) {

                clearInterval(interval);

                $.ajax({
                    url: '/payroll/run_new',
                    type: 'POST',
                    data: {
                        month_filter: $('#global_date_picker').val(),
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(res) {

                        // ✅ MARK ALL AS SUCCESS
                        $('#payrollSteps .step-item').each(function() {
                            $(this).find('i')
                                .removeClass()
                                .addClass('mdi mdi-check-circle text-success');

                            $(this).find('span')
                                .removeClass('text-primary')
                                .addClass('text-success');
                        });

                        $('#payrollProgress')
                            .removeClass('bg-danger')
                            .addClass('bg-success');

                        toastr.success('Payroll Generated Successfully 🎉');

                        setTimeout(() => {
                            $('#kt_modal_generate_payroll').modal('hide');
                            loadThemes(1);
                        }, 800);

                    },
                    error: function(xhr) {

                        // ❌ STOP ALL LOADING ICONS FIRST
                        $('#payrollSteps .step-item i').each(function() {
                            if ($(this).hasClass('mdi-loading')) {
                                $(this)
                                    .removeClass()
                                    .addClass('mdi mdi-close-circle text-danger');
                            }
                        });

                        // ❌ MARK FAILED STEP CLEARLY
                        let failedIndex = Math.min(i - 1, steps.length - 1);

                        let step = $('#payrollSteps .step-item').eq(failedIndex);

                        step.find('i')
                            .removeClass()
                            .addClass('mdi mdi-close-circle text-danger');

                        step.find('span')
                            .removeClass('text-primary')
                            .addClass('text-danger');

                        // ❌ PROGRESS BAR RED
                        $('#payrollProgress')
                            .removeClass('bg-success')
                            .addClass('bg-danger');

                        // ❌ ERROR MESSAGE (SHOW REAL ERROR)
                        let errorMsg = xhr.responseJSON?.error || xhr.responseJSON?.message || 'Payroll Failed ❌';

                        toastr.error(errorMsg);
                    },
                    complete: function() {
                        btn.prop('disabled', false).text('Start Generation');
                    }
                });

            } else {
                // MARK PREVIOUS STEP SUCCESS
                if (i > 0) {
                    let prev = $('#payrollSteps .step-item').eq(i - 1);

                    prev.find('i')
                        .removeClass()
                        .addClass('mdi mdi-check-circle text-success');

                    prev.find('span')
                        .removeClass('text-primary')
                        .addClass('text-success');
                }
            }

            i++;

        }, 800);
    }

    function lockPayroll() {

        $.post('/payroll/lock', {
            month_filter: $('#lockMonth').val(),
            _token: '{{ csrf_token() }}'
        }, function() {
            toastr.success('Payroll Locked');
            $('#kt_modal_lock_payroll').modal('hide');
        });
    }

    function printPayslip() {
        var entry_id = $('#hidden_entry_encrypt').val();

        if (!entry_id) {
            toastr.error('Entry ID not found');
            return;
        }

        window.open('/payroll/payslip_print/' + entry_id, '_blank');
    }
</script>

<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');

            var department = $('#department_fill');

            if (countryId == 'egc') {
                $('#business_div').hide();
                var entity_id = 0;
                department.empty().append('<option value="">Select Department</option>');

                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                department.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });

            } else {
                $('#business_div').show();
                stateDropdown.empty().append('<option value="">Select Entity</option>');
                department.empty().append('<option value="">Select Department</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }

            }




        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });


    })
</script>
<script>
    var staffList = [];

    function bulkSendPaySlipFunc() {
        staffList = [];
        const month_filter = $('#global_date_picker').val() || currentMonth;

        $.get('/view_payslip_staffs/' + month_filter, function(res) {

            if (!res.success) return;

            $('#payslip_month').text(res.month + ' ' + res.year);
            $('#payslip_total').text(res.data.length);

            let tbody = $('#payslip_table tbody');
            tbody.empty();

            res.data.forEach(staff => {

                let statusText = 'Pending';
                let statusClass = 'text-muted';
                let showRetry = false;
                let showRetryText = 'Send';

                if (staff.email_send == 1) {
                    statusText = 'Sent';
                    statusIcon = 'mdi mdi-check-circle text-success';
                    statusClass = 'text-success';
                    showRetryText = 'Resend';
                    showRetry = true;
                } else if (staff.email_send == 2) {
                    statusText = 'Failed';
                    statusClass = 'text-danger';
                    showRetryText = 'Retry';
                    showRetry = true;
                } else {
                    statusText = 'Pending';
                    statusClass = 'text-muted';
                    showRetry = false;
                }

                let actionIcon = '';
                let actionClass = 'btn-primary';

                if (staff.email_send == 1) {
                    actionIcon = 'mdi-email-sync'; // resend
                    actionClass = 'btn-success';
                } else if (staff.email_send == 2) {
                    actionIcon = 'mdi-refresh'; // retry
                    actionClass = 'btn-danger';
                } else {
                    actionIcon = 'mdi-send'; // send
                    actionClass = 'btn-primary';
                }



                let staff_image = '';
                if (staff.isStaffImage) {
                    if (staff.staff_image && staff.staff_image.trim() !== '') {
                        if (staff.company_type == 1) {
                            staff_image = `staff_images/Management/${staff.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${staff.company_id}/${staff.entity_id}/${staff.staff_image}`;
                        }
                    } else {
                        staff_image = staff.gender == 1 ?
                            'assets/egc_images/auth/user_2.png' :
                            'assets/egc_images/auth/user_7.png';
                    }
                } else {
                    staff_image = staff.gender == 1 ?
                        'assets/egc_images/auth/user_2.png' :
                        'assets/egc_images/auth/user_7.png';
                }

                staff_image = `{{ asset('${staff_image}') }}`;

                tbody.append(`
                        <tr data-id="${staff.payroll_entry_id}">
                            <td style="position:relative;">
                                <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${staff.company_base_color || '#6c757d'};"></div>
                                <input type="checkbox" class="staff-check form-check-input" value="${staff.payroll_entry_id}">
                            </td>
                            <td >
                                <div class="d-flex align-items-center ps-2">
                                    <!-- Staff Image -->
                                    <div class="symbol symbol-40px me-3">
                                        <div class="image-input image-input-circle">
                                            <img src="${staff_image}" 
                                                alt="user-avatar"  
                                                class="rounded-circle"
                                                style="width:40px; height:40px; object-fit:fill;"
                                                onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}${staff.gender == 1 ? 'user_2.png' : 'user_7.png'}';"/>
                                        </div>
                                    </div>

                                    <!-- Staff Info -->
                                    <div class="d-flex flex-column flex-grow-1">
                                        <!-- Name + Gender Icon -->
                                        <div class="d-flex align-items-center flex-wrap">
                                            <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                                                data-bs-toggle="tooltip" title="${staff.staff_name}">
                                                ${staff.staff_name}
                                            </span>

                                            ${staff.gender == 1 
                                                ? `<i class="mdi mdi-face-man text-info fs-7" data-bs-toggle="tooltip" title="Male"></i>` 
                                                : `<i class="mdi mdi-face-woman text-pink fs-7" data-bs-toggle="tooltip" title="Female"></i>`
                                            }
                                        </div>

                                        <!-- Employee ID + Nickname -->
                                        <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                                            <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${staff.staff_id  || '-'}</span>
                                            <span class="text-primary" data-bs-toggle="tooltip" title="Nickname">${staff.nick_name || '-'}</span>
                                        </div>

                                        <!-- Company Badge -->
                                        <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                                            style="background-color:${staff.company_base_color || '#6c757d'}; color:#fff; max-width:150px;"
                                            data-bs-toggle="tooltip" title="${staff.company_name || '-'}">
                                            ${staff.company_name || '-'}
                                        </span>

                                        <!-- Department Badge -->
                                        <span class="badge bg-warning fs-8 text-truncate mb-1 text-black" 
                                            style="max-width: 120px;" 
                                            data-bs-toggle="tooltip" title="${staff.department_name || '-'}">
                                            ${staff.department_name || '-'}
                                        </span>

                                        <!-- Job Role Badge (truncated) -->
                                        <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                                            style="color: #046d85 !important; max-width:150px;" 
                                            data-bs-toggle="tooltip" title="${staff.job_role_name || '-'}">
                                            ${staff.job_role_name || '-'}
                                        </span>
                                    </div>
                                </div>
                            </td>
                            <td>${staff.mobile_no}</td>
                            <td>${staff.email_id || '-'}</td>

                            <td>
                                <div class="status-text ${statusClass}">
                                    <span class="mdi ${staff.email_send == 1 ? 'mdi-check-circle text-success' : staff.email_send == 2 ? 'mdi-close-circle text-danger' : 'mdi-clock-outline text-muted'} me-1"></span>
                                    ${statusText}
                                </div>

                                <div class="progress mt-1" style="height:6px; display:none;">
                                    <div class="progress-bar" style="width:0%"></div>
                                </div>
                              
                                <button class="btn btn-sm ${actionClass} retry-btn mt-2 d-flex align-items-center gap-1" style="${showRetry ? '' : 'display:none !important'};">
                                    <i class="mdi ${actionIcon} action-icon"></i>
                                    <span>${showRetryText}</span>
                                </button>
                            </td>
                        </tr>
                        `);

                staffList.push(staff);
            });
        });
    }
    $('#selectAll').on('change', function() {
        $('.staff-check').prop('checked', $(this).is(':checked'));
    });
    $('#bulkSendBtn').click(function() {

        let selected = $('.staff-check:checked');

        if (selected.length === 0) {
            alert('Please select at least one staff');
            return;
        }

        $(this).prop('disabled', true).text('Sending...');

        let index = 0;

        function sendNext() {

            if (index >= selected.length) {
                $('#bulkSendBtn').prop('disabled', false).text('Send Payslips');
                return;
            }

            let row = $(selected[index]).closest('tr');
            let id = $(selected[index]).val();

            sendPayslip(row, id, () => {
                index++;
                sendNext();
            });
        }

        sendNext();
    });

    // function sendPayslip(row, id, callback) {

    //     let statusText = row.find('.status-text');
    //     let progress = row.find('.progress');
    //     let bar = row.find('.progress-bar');
    //     let retryBtn = row.find('.retry-btn');

    //     retryBtn.hide();
    //     progress.show();
    //     bar.css('width', '10%');

    //     statusText.text('Sending...').removeClass().addClass('status-text text-warning');

    //     // Animate progress
    //     let width = 10;
    //     let interval = setInterval(() => {
    //         width += 10;
    //         if (width >= 90) clearInterval(interval);
    //         bar.css('width', width + '%');
    //     }, 200);

    //     $.post('/send_month_payslip', {
    //         id: id,
    //         _token: '{{ csrf_token() }}'
    //     })
    //     .done(res => {

    //         clearInterval(interval);
    //         bar.css('width', '100%');

    //         if (res.success) {
    //             statusText.text('Sent')
    //                 .removeClass()
    //                 .addClass('status-text text-success');

    //             bar.removeClass().addClass('progress-bar bg-success');

    //         } else {
    //             failState();
    //         }
    //     })
    //     .fail(() => {
    //         failState();
    //     })
    //     .always(() => {
    //         setTimeout(() => progress.hide(), 800);
    //         callback();
    //     });

    //     function failState() {
    //         statusText.text('Failed')
    //             .removeClass()
    //             .addClass('status-text text-danger');

    //         bar.removeClass().addClass('progress-bar bg-danger');
    //         retryBtn.show();
    //     }
    // }

    function sendPayslip(row, id, callback) {

        let statusText = row.find('.status-text');
        let progress = row.find('.progress');
        let bar = row.find('.progress-bar');
        let retryBtn = row.find('.retry-btn');
        let icon = retryBtn.find('i');

        retryBtn.prop('disabled', true);
        // retryBtn.hide();
        progress.show();

        icon.removeClass().addClass('mdi mdi-loading mdi-spin');
        bar.removeClass().addClass('progress-bar bg-warning');

        statusText.text('Sending...')
            .removeClass()
            .addClass('status-text text-warning');

        let width = 10;

        let interval = setInterval(() => {
            width += 10;
            if (width >= 90) clearInterval(interval);
            bar.css('width', width + '%');
        }, 150);

        $.post('/send_month_payslip', {
                id: id,
                _token: '{{ csrf_token() }}'
            })
            .done(res => {

                clearInterval(interval);
                bar.css('width', '100%');

                if (res.success) {
                    statusText.text('Sent')
                        .removeClass()
                        .addClass('status-text text-success');

                    bar.removeClass().addClass('progress-bar bg-success');
                    icon.removeClass().addClass('mdi mdi-check-circle text-success success-pop');

                } else {
                    failState(res.message);
                }
            })
            .fail(() => {
                failState('Server Error');
            })
            .always(() => {
                setTimeout(() => progress.hide(), 800);
                callback();
            });

        function failState(msg) {
            statusText.text('Failed')
                .removeClass()
                .addClass('status-text text-danger');

            bar.removeClass().addClass('progress-bar bg-danger');
            icon.removeClass().addClass('mdi mdi-alert-circle text-danger');
            retryBtn.show().prop('disabled', false);
            // retryBtn.show();
        }


    }

    $(document).on('click', '.retry-btn', function() {

        let row = $(this).closest('tr');
        let id = row.data('id');

        sendPayslip(row, id, () => {});
    });

    function openGeneratePayroll() {
        let selectedMonth = $('#global_date_picker').val();
        let monthEl = document.getElementById('selectedPayrollMonth');
        monthEl.innerHTML = `
            <i class="mdi mdi-calendar-month me-1"></i>
            <span>${selectedMonth}</span>
        `;
        // 🔥 Add highlight animation
        monthEl.classList.remove('active');
        void monthEl.offsetWidth; // reflow trick
        monthEl.classList.add('active');
    }
</script>
<script>
    function openHrVerificationModal(processId) {

        $('#verifyPayrollLoader').removeClass('d-none');
        $('#verifyPayrollContent').addClass('d-none');
        $('#verify_total_employees').text('0');
        $('#verify_processed_employees').text('0');
        $('#verify_total_gross').text('₹0');
        $('#verify_total_deduction').text('₹0');
        $('#verify_total_netpay').text('₹0');
        $('#verify_process_month').text('-');
        $('#verify_process_status').html('');
        $('#verify_hr_name').text('-');
        $('#verify_processed_at').text('-');
        $('#verifyProgressBar').css('width', '0%').removeClass('bg-success').addClass('bg-warning');
        $('#kt_modal_hr_verification').modal('show');

        $.ajax({
            url: '/payroll/process/details',
            type: 'GET',
            data: {
                process_id: currentPayrollProcessId
            },
            success: function(res) {
                let data = res.data;
                $('#verify_total_employees').text(data.total_employees);
                $('#verify_processed_employees').text(data.processed_employees);
                $('#verify_total_gross').text('₹' + data.total_gross);
                $('#verify_total_deduction').text('₹' + data.total_deduction);
                $('#verify_total_netpay').text('₹' + data.total_netpay);
                $('#verify_process_month').text(data.payroll_month);
                $('#verify_hr_name').text(data.processed_by);
                $('#verify_processed_at').text(data.processed_at);
                let statusBadge = `
                <span class="badge bg-label-success">
                    ${data.process_status.toUpperCase()}
                </span>
            `;
                if (data.process_status === 'processing') {
                    statusBadge = `
                    <span class="badge bg-label-warning">
                        PROCESSING
                    </span>
                `;
                }
                if (data.process_status === 'draft') {
                    statusBadge = `
                    <span class="badge bg-label-secondary ">
                        DRAFT
                    </span>
                `;
                }
                if (data.payroll_freeze == 1) {
                    statusBadge = `
                    <span class="badge bg-label-danger ">
                        FROZEN
                    </span>
                `;
                }
                $('#verify_process_status').html(statusBadge);
                let progress = 0;
                if (data.total_employees > 0) {
                    progress = Math.round(
                        (data.processed_employees /
                            data.total_employees) * 100
                    );
                }
                $('#verifyProgressBar').css('width', progress + '%');

                let checklistHtml = '';

                $.each(data.checklist, function(index, item) {

                    let checked = '';

                    if (
                        data.verification_data &&
                        data.verification_data[item.key]
                    ) {
                        checked = 'checked';
                    }

                    checklistHtml += `
                        <label
                            class="form-check form-check-custom form-check-solid">

                            <input
                                class="form-check-input verify-check"
                                type="checkbox"
                                data-key="${item.key}"
                                ${checked}
                            >

                            <span class="form-check-label fw-semibold">
                                ${item.label}
                            </span>

                        </label>
                    `;
                });

                $('#verificationChecklistContainer')
                    .html(checklistHtml);

                if (data.hr_verified) {

                    $('#hr_verify_remarks')
                        .val(data.verification_remarks);

                    $('.verify-check')
                        .prop('disabled', true);

                    $('#hr_verify_remarks').prop('readonly', true);

                    $('#btn-verify-payroll').hide();
                }

                let tbody = '';
                $.each(data.top_employees, function(index, emp) {
                    tbody += `
                    <tr>
                        <td>
                            <div class="d-flex align-items-center ps-2">
                                <div class="symbol symbol-30px me-3">
                                    <div class="image-input image-input-circle">
                                        <img src="${emp.staffImageUrl}" 
                                            alt="user-avatar"  
                                            class="rounded-circle"
                                            style="width:30px; height:30px; object-fit:fill;"/>
                                    </div>
                                </div>
                                <div class="d-flex flex-column flex-grow-1">
                                    <!-- Name + Gender Icon -->
                                    <div class="d-flex align-items-center flex-wrap">
                                        <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                                            data-bs-toggle="tooltip" title="${emp.staff_name}">
                                            ${emp.staff_name}
                                        </span>

                                        ${emp.gender == 1 
                                            ? `<i class="mdi mdi-face-man text-info fs-7" data-bs-toggle="tooltip" title="Male"></i>` 
                                            : `<i class="mdi mdi-face-woman text-pink fs-7" data-bs-toggle="tooltip" title="Female"></i>`
                                        }
                                    </div>
                                    <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                                        <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${emp.staff_code  || '-'}</span>
                                        <span class="text-primary" data-bs-toggle="tooltip" title="Nickname">${emp.nick_name || '-'}</span>
                                    </div>
                                    <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                                        style="background-color:${emp.company_base_color || '#6c757d'}; color:#fff; max-width:150px;"
                                        data-bs-toggle="tooltip" title="${emp.company_name || '-'}">
                                        ${emp.company_name || '-'}
                                    </span>
                                    <span class="badge bg-warning fs-8 text-truncate mb-1 text-black" 
                                        style="max-width: 120px;" 
                                        data-bs-toggle="tooltip" title="${emp.department_name || '-'}">
                                        ${emp.department_name || '-'}
                                    </span>
                                    <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                                        style="color: #046d85 !important; max-width:150px;" 
                                        data-bs-toggle="tooltip" title="${emp.job_role_name || '-'}">
                                        ${emp.job_role_name || '-'}
                                    </span>
                                </div>
                            </div>
                        </td>
                        <td class="text-end">
                            ₹${new Intl.NumberFormat('en-IN').format(emp.gross_earnings || 0)}
                        </td>
                        <td class="text-end">
                            ₹${new Intl.NumberFormat('en-IN').format(emp.gross_deductions || 0)}
                        </td>
                        <td class="text-end">
                            <span class="fw-bold text-success text-end">
                                ₹${new Intl.NumberFormat('en-IN').format(emp.net_payable || 0)}
                            </span>
                        </td>
                    </tr>
                `;
                });
                $('#verifyEmployeeTable').html(tbody);
                $('#verifyPayrollLoader').addClass('d-none');
                $('#verifyPayrollContent').removeClass('d-none');
            },
            error: function(xhr) {
                toastr.error(
                    xhr.responseJSON?.message ??
                    'Unable to load payroll details'
                );
                $('#kt_modal_hr_verification')
                    .modal('hide');
            }
        });
    }

    function openFreezePayrollModal(processId) {

        $('#freezePayrollLoader').removeClass('d-none');
        $('#freezePayrollContent').addClass('d-none');
        $('#kt_modal_freeze_payroll').modal('show');
        $.ajax({
            url: '/payroll/process/details',
            type: 'GET',
            data: {
                process_id: currentPayrollProcessId
            },
            success: function(res) {
                let data = res.data;
                $('#freeze_payroll_month').text(data.payroll_month);
                $('#freeze_total_employees').text(data.total_employees);
                $('#freeze_total_netpay').text('₹' + data.total_netpay);
                $('#freeze_process_status').text(data.process_status.toUpperCase());
                $('#freeze_total_deduction').text(data.total_deduction);
                $('#freeze_total_gross').text(data.total_gross);
                $('#freezePayrollLoader').addClass('d-none');
                $('#freezePayrollContent').removeClass('d-none');

                let validationHtml = '';

                validationHtml += `
                <div class="d-flex justify-content-between mb-3">
                    <span>
                        Payroll Generated
                    </span>

                    <span class="badge ${
                        data.freeze_validation.payroll_generated
                        ? 'bg-success'
                        : 'bg-danger'
                    }">

                        ${
                            data.freeze_validation.payroll_generated
                            ? 'Passed'
                            : 'Failed'
                        }

                    </span>
                </div>
                `;

                validationHtml += `
                <div class="d-flex justify-content-between mb-3">
                    <span>
                        All Employees Processed
                    </span>

                    <span class="badge ${
                        data.freeze_validation.all_employees_processed
                        ? 'bg-success'
                        : 'bg-danger'
                    }">

                        ${
                            data.freeze_validation.all_employees_processed
                            ? 'Passed'
                            : 'Failed'
                        }

                    </span>
                </div>
                `;

                validationHtml += `
                <div class="d-flex justify-content-between mb-3">
                    <span>
                        HR Verification Completed
                    </span>

                    <span class="badge ${
                        data.freeze_validation.hr_verified
                        ? 'bg-success'
                        : 'bg-danger'
                    }">

                        ${
                            data.freeze_validation.hr_verified
                            ? 'Passed'
                            : 'Failed'
                        }

                    </span>
                </div>
                `;

                $('#freezeValidationList')
                .html(validationHtml);

                $('#freeze_verified_at')
                .text(data.verified_at ?? '-');

                $('#freeze_verification_remarks')
                .text(
                    data.verification_remarks ?? '-'
                );

                let canFreeze =
                    data.freeze_validation.payroll_generated &&
                    data.freeze_validation.all_employees_processed &&
                    data.freeze_validation.hr_verified &&
                    !data.freeze_validation.already_frozen;

                if (!canFreeze) {

                    $('#freezeSubmitBtn')
                        .prop('disabled', true);

                } else {

                    $('#freezeSubmitBtn')
                        .prop('disabled', false);
                }
            },
            error: function(xhr) {
                toastr.error(
                    xhr.responseJSON?.message ??
                    'Unable to load payroll details'
                );
                $('#kt_modal_freeze_payroll').modal('hide');
            }
        });
    }

    function updatePayrollWorkflow(workflow) {

        $('#generate_payroll_btn').addClass('d-none');
        $('#hr_verify_btn').addClass('d-none');
        $('#freeze_payroll_btn').addClass('d-none');
        $('#send_payslip_btn').addClass('d-none');

        /*
        |--------------------------------------------------------------------------
        | Stage 1
        |--------------------------------------------------------------------------
        */

        if (!workflow.generated) {

            $('#generate_payroll_btn')
                .removeClass('d-none')
                .removeAttr('disabled');

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Stage 2
        |--------------------------------------------------------------------------
        */

        $('#hr_verify_btn').removeClass('d-none');

        if (!workflow.hr_verified) {

            $('#hr_verify_btn')
                .removeClass('btn-success')
                .addClass('btn-warning')
                .html(`
                    <i class="mdi mdi-account-check"></i>
                    HR Verify
                `);

            $('#freeze_payroll_btn')
                .removeClass('d-none')
                .prop('disabled', true)
                .attr(
                    'title',
                    'HR verification required'
                );

            $('#send_payslip_btn')
                .removeClass('d-none')
                .prop('disabled', true);

            return;
        }

        /*
        |--------------------------------------------------------------------------
        | Stage 3
        |--------------------------------------------------------------------------
        */

        $('#hr_verify_btn')
            .removeClass('btn-warning')
            .addClass('btn-success')
            .html(`
                <i class="mdi mdi-check-decagram"></i>
                HR Verified
            `)
            .prop('disabled', true);

        $('#freeze_payroll_btn')
            .removeClass('d-none')
            .prop('disabled', false);

        $('#send_payslip_btn')
            .removeClass('d-none')
            .prop('disabled', true);

        /*
        |--------------------------------------------------------------------------
        | Stage 4
        |--------------------------------------------------------------------------
        */

        if (workflow.frozen) {

            $('#freeze_payroll_btn')
                .removeClass('btn-danger')
                .addClass('btn-success')
                .html(`
                    <i class="mdi mdi-lock-check"></i>
                    Payroll Frozen
                `)
                .prop('disabled', true);

            $('#send_payslip_btn')
                .prop('disabled', false);
        }
    }

    function renderWorkflowStatus(workflow) {

        let html = '';

        if (!workflow.generated) {

            html = `
            <div class="alert alert-secondary mb-0">
                Payroll not generated
            </div>`;
        }
        else if (!workflow.hr_verified) {

            html = `
            <div class="alert alert-warning mb-0">
                Payroll generated and awaiting HR verification
            </div>`;
        }
        else if (!workflow.frozen) {

            html = `
            <div class="alert alert-info mb-0">
                HR verified. Ready for payroll freeze.
            </div>`;
        }
        else {

            html = `
            <div class="alert alert-success mb-0">
                Payroll frozen successfully. Payslips can now be distributed.
            </div>`;
        }

        $('#payrollWorkflowStatus').html(html);
    }

    function submitHrVerification()
    {
        let checklist = {};
        $('.verify-check').each(function() {
            checklist[$(this).data('key')] =
                $(this).is(':checked') ? 1 : 0;
        });
        $.ajax({
            url: '/payroll/verify',
            type: 'POST',
            data: {
                process_id: currentPayrollProcessId,
                checklist_json:JSON.stringify(checklist),
                remarks:  $('#hr_verify_remarks').val(),
                _token: csrfToken
            },
            success: function(res) {
                toastr.success(res.message);
                $('#kt_modal_hr_verification') .modal('hide');
                loadThemes(1);
            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON.message
                );
            }
        });
    }

    function submitFreezePayroll() {
        if (!$('#freeze_confirmation').is(':checked')) {
            toastr.error('Please confirm before freeze');
            return;
        }
        $.ajax({
            url: '/payroll/freeze',
            type: 'POST',
            data: {
                process_id: currentPayrollProcessId,
                freeze_reason: $('#freeze_reason').val(),
                _token: csrfToken
            },
            success: function(res) {
                toastr.success(res.message);
                $('#kt_modal_freeze_payroll').modal('hide');
                loadThemes(1);
            },

            error: function(xhr) {
                toastr.error(xhr.responseJSON.message);
            }
        });
    }
</script>
@endsection