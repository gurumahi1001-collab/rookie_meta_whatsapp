<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Employee Payslip - Elysium Group</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap"
        rel="stylesheet" />

    <style>
        
        body {
            font-family: 'Public Sans', sans-serif;
            /* background-color: #f8f6f6; */
        }

        .primary-bg {
            background-color: #96261E !important;
        }

        .primary-text {
            color: #96261E !important;
        }

        /* .summary-box {
            border: 1px solid #dee2e6;
            border-radius: 12px;
            padding: 20px;
        } */

        .summary-box {
            border: 1px solid {{ $data->company_base_color ?? '#dee2e6' }};
            border-radius: 12px;
            padding: 16px;
            background: #fff;
        }

        .card-row {
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .card-row:nth-child(even) {
            background-color: rgba(0,0,0,0.03);
        }

        .flex-fill {
            max-height: 400px; /* prevent overflow for long component lists */
            overflow-y: auto;
        }

        .print-container {
            /* background: #ffffff; */
            /* border-radius: 16px; */
            overflow: hidden;
            padding-top: 110px !important;
            /* background-image: url('{{ asset("assets/egc_images/payslip_bg.jpg") }}') !important; */
            background-size: 100% 100% !important;
            /* background-size: cover !important; */
            background-position: center !important;
            background-repeat: no-repeat !important;
        }

        @page {
            size: A4;
            margin: 0;
        }

        /* ================= PRINT STYLES ================= */
        @media print {

            html,
            body {
                height: 100%;
                width: 100%;
            }

            body {
                margin: 0 !important;
                padding: 0 !important;
                /* zoom: 0.78 !important; */

                /* background-image: url('{{ asset("assets/egc_images/payslip_bg.jpg") }}') !important; */
                /* background-size: 100% 100% !important;
                background-position: center !important;
                background-repeat: no-repeat !important; */

                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* REMOVE BOOTSTRAP CONTAINER PADDING */
            .container {
                max-width: 100% !important;
                padding: 0 !important;
            }

            /* REMOVE ROW NEGATIVE MARGINS */
            .row {
                margin-left: 0 !important;
                margin-right: 0 !important;
            }
/* 
            .print-container {
                box-shadow: none !important;
                background: transparent !important;
                margin-top: 150px;
                width: 100% !important;
                padding-top: 0px !important;
            } */

                

            .print-container {
                width: 210mm;
                min-height: 297mm;
                margin: 0 auto;
                page-break-after: avoid;
            }

            #bg_img {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 297mm;
                z-index: -1;
            }

            /* Reduce vertical paddings */
            .p-4 { padding: 10px !important; }
            .py-3 { padding-top: 8px !important; padding-bottom: 8px !important; }

            /* Reduce row gaps */
            .g-4 { row-gap: 10px !important; column-gap: 10px !important; }

            /* Reduce table spacing */
            .table td, 
            .table th {
                padding: 6px 8px !important;
            }

            /* Reduce heading sizes */
            h3 { font-size: 22px !important; }
            .fs-4 { font-size: 18px !important; }
            .fs-3 { font-size: 20px !important; }

            /* Avoid page breaks */
            .print-container,
            .row,
            table {
                page-break-inside: avoid !important;
            }
        }


        /* .print-container {
            width: 210mm;
            height: 297mm;
            position: relative;
            overflow: hidden;
        } */
            /* .print-container {
                width: 210mm;
                min-height: 297mm;
                position: relative;
                overflow: hidden;
            } */
            .print-container {
                width: 210mm;
                min-height: 297mm;
                margin: auto;
                position: relative;
            }

        .print-container > *:not(img) {
            position: relative;
            z-index: 2;
        }

        /* .print-container {
            page-break-after: avoid;
            page-break-inside: avoid;
        } */
            body {
              
            }
       
    </style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
    @endphp
</head>
<body>
    <!-- <div class="text-end p-3">
        <button class="btn btn-success" id="downloadPdfBtn">
            Download PDF
        </button>
    </div> -->
    <div id="payslipArea" class="d-flex justify-content-center">
       <div class="print-container shadow-lg px-4 py-4 bg-white">
        <img id="bg_img" src="{{ $data->payslip_template_url ?? asset('assets/egc_images/payslip_bg.jpg') }}"
            style="
                position:absolute;
                top:0;
                left:0;
                width:210mm;
                height:297mm;
                object-fit: cover;
                z-index:0;
            " alt="Payslip background">
            <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                <div>
                    <h3 class="fw-bold mb-1" style="font-size: 28px;">PAYSLIP</h3>
                    <p class="text-muted mb-0">
                        {{ $data->payroll_month ? date('F', mktime(0, 0, 0, $data->payroll_month, 1)) : date('F') }} {{ $data->payroll_year ?? date('Y') }}
                    </p>
                </div>
                <div class="text-end">
                    
                    @if($data->company_base_color)
                    <span class="badge rounded-pill px-4 py-2 fw-bold"
                        style="background-color: {{ $data->company_base_color }}33; color: {{ $data->company_base_color }};">
                        PAID
                    </span>
                    @else
                    <span class="badge rounded-pill px-4 py-2 fw-bold"
                        style="background-color: rgba(150,38,30,0.1); color:#96261E;">
                        PAID
                    </span>
                    @endif
                </div>
            </div>
            <div class="row g-2 p-4 bg-light">
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Employee Name</small>
                    <div class="fw-bold">{{$data->name ?? '-'}}</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Employee ID</small>
                    <div class="fw-bold">{{$data->staff_code ?? '-'}}</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Department</small>
                    <div class="fw-bold">Production</div>
                </div>
                <div class="col-3">
                    <small class="text-uppercase text-muted fw-bold">Designation</small>
                    <div class="fw-bold">Developer</div>
                </div>
            </div>
            <div class="row g-2 p-4">
                <div class="col-4">
                    <div class="summary-box">
                        <small class="text-muted fw-bold">Gross Salary</small>
                        <div class="fw-bold fs-4">&#8377; {{$data->total_earnings ?? 0}}</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="summary-box">
                        <small class="text-muted fw-bold">Total Deductions</small>
                        <div class="fw-bold fs-4">&#8377; {{$data->total_deductions ?? 0}}</div>
                    </div>
                </div>
                 @if($data->company_base_color)
                 <div class="col-4">
                    <div class="summary-box text-white" style="background-color: {{ $data->company_base_color ?? '#ab2b22' }};">
                        <small class="fw-bold">Net Payable</small>
                        <div class="fw-bold fs-3">&#8377; {{$data->net_salary ?? '-'}}</div>
                    </div>
                </div>
                 @else
                 <div class="col-4">
                    <div class="summary-box primary-bg text-white">
                        <small class="fw-bold">Net Payable</small>
                        <div class="fw-bold fs-3">&#8377; {{$data->net_salary ?? '-'}}</div>
                    </div>
                </div>
                 @endif
                
            </div>
            <div class="px-4 pb-4">
                
                <div class="row g-3">
                    <div class="col-12 d-flex flex-column flex-sm-row gap-3">
                        <!-- Earnings Card -->
                        <div class="flex-fill border rounded shadow-sm p-3 d-flex flex-column">
                            <h6 class="text-success fw-bold bg-success bg-opacity-10 p-2 rounded text-center">
                                Earnings
                            </h6>
                            <div class="flex-grow-1 d-flex flex-column mt-2">
                                @foreach($data->components as $c)
                                    @if($c->type == 'earning')
                                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                        <span class="fw-medium">{{ $c->component_name }}</span>
                                        <span class="fw-bold">₹ {{ number_format($c->amount, 2) }}</span>
                                    </div>
                                    @endif
                                @endforeach
                                <!-- Fill space if necessary -->
                                @for($i = count($data->components->where('type', 'earning')); $i < count($data->components->where('type', 'deduction')); $i++)
                                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom invisible">
                                        <span>Placeholder</span>
                                        <span>0</span>
                                    </div>
                                @endfor
                            </div>
                            <div class="d-flex justify-content-between mt-3 pt-2 border-top fw-bold">
                                <span>Total Earnings</span>
                                <span>₹ {{ number_format($data->total_earnings ?? 0, 2) }}</span>
                            </div>
                        </div>

                        <!-- Deductions Card -->
                        <div class="flex-fill border rounded shadow-sm p-3 d-flex flex-column">
                            <h6 class="text-danger fw-bold bg-danger bg-opacity-10 p-2 rounded text-center">
                                Deductions
                            </h6>
                            <div class="flex-grow-1 d-flex flex-column mt-2">
                                @foreach($data->components as $c)
                                    @if($c->type == 'deduction')
                                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                        <span class="fw-medium">{{ $c->component_name }}</span>
                                        <span class="fw-bold">₹ {{ number_format($c->amount, 2) }}</span>
                                    </div>
                                    @endif
                                @endforeach
                                <!-- Fill space if necessary -->
                                @for($i = count($data->components->where('type', 'deduction')); $i < count($data->components->where('type', 'earning')); $i++)
                                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom invisible">
                                        <span>Placeholder</span>
                                        <span>0</span>
                                    </div>
                                @endfor
                            </div>
                            <div class="d-flex justify-content-between mt-3 pt-2 border-top fw-bold">
                                <span>Total Deductions</span>
                                <span>₹ {{ number_format($data->total_deductions ?? 0, 2) }}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-12">
                        <div class="border rounded p-3 text-center text-muted fw-bold" style="background-color: #f8f8f8;">
                            Net Payable (in words): {{ $helper->convertNumberToWords($data->net_salary ?? '0') }}
                        </div>
                    </div>
                </div>
            </div>
        
            
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <!-- <script>
        window.print();
    </script> -->
   <script>

 function downloadpdf() {

    const element = document.querySelector('.print-container');

    // const opt = {
    //     margin: [0,0,0,0],
    //     filename: 'Payslip_{{$data->staff_code ?? "Employee"}}_Jan_2026.pdf',
    //     image: { type: 'jpeg', quality: 1 },
    //     html2canvas: { 
    //         scale: 2,
    //         useCORS: true
    //     },
    //     // html2canvas: { scale: 1.8 },
    //     jsPDF: { 
    //         unit: 'mm',
    //         format: 'a4',
    //         orientation: 'portrait'
    //     }
    // };

    // const opt = {
    //     margin: 0,
    //     filename: 'Payslip_{{$data->staff_code ?? "Employee"}}.pdf',
    //     image: { type: 'jpeg', quality: 1 },
    //     // html2canvas: { 
    //     //     scale: 3, // 🔥 increase quality
    //     //     useCORS: true,
    //     //     scrollY: 0
    //     // },
    //     // jsPDF: { 
    //     //     unit: 'mm',
    //     //     format: [210, 297], // ✅ exact A4
    //     //     orientation: 'portrait'
    //     // }
    //     html2canvas: { 
    //         scale: 2,
    //         useCORS: true,
    //         scrollY: 0
    //     },
    //     jsPDF: { 
    //         unit: 'mm',
    //         format: 'a4',
    //         orientation: 'portrait'
    //     }
    // };


    const opt = {
        margin: 0,
        filename: 'Payslip_{{$data->staff_code ?? "Employee"}}.pdf',
        image: { type: 'jpeg', quality: 1 },
        html2canvas: { scale: 1.5 }, 
        jsPDF: {
            unit: 'mm',
            format: 'a4',
            orientation: 'portrait'
        }
    };

    // document.getElementById('downloadPdfBtn').style.display = 'none';

    // html2pdf().set(opt).from(element).save().then(() => {
    //     // document.getElementById('downloadPdfBtn').style.display = 'inline-block';
    // });

    html2pdf().set(opt).from(element).save();

}
// downloadpdf()
</script>
</body>
</html>