<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Payslip Verification</title>

    <!-- Favicon -->
    <link rel="icon" href="{{$favUrl}}" type="image/png" />

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

    @php
        $baseColor = $record->salary_company_color ?? '#0d6efd';
    @endphp

    <style>
        body {
            font-family: 'Public Sans', sans-serif;
            background: linear-gradient(135deg, #eef2f7, #dfe9f3);
        }

        .card-main {
            max-width: 700px;
            margin: 40px auto;
            border-radius: 20px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 20px 50px rgba(0,0,0,0.1);
        }

        .header {
            background: linear-gradient(135deg, {{ $baseColor }}, #00000020);
            color: #fff;
            padding: 25px;
            text-align: center;
        }

        .logo {
            height: 50px;
            margin-bottom: 10px;
        }

        .status {
            display: inline-block;
            padding: 6px 18px;
            border-radius: 50px;
            background: #ffffff22;
            font-size: 14px;
        }

        .body {
            padding: 25px;
        }

        .label {
            font-size: 12px;
            color: #888;
        }

        .value {
            font-weight: 600;
            font-size: 15px;
        }

        .salary-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
        }

        .earn { color: green; }
        .deduct { color: red; }

        .footer {
            text-align: center;
            font-size: 12px;
            color: #888;
            padding: 15px;
        }

        @media(max-width: 576px) {
            .card-main {
                margin: 15px;
            }
        }
    </style>
</head>

<body>

<div class="card-main">

    <!-- HEADER -->
    <div class="header">
        @if($record->salary_company_id != 0)
            @if($record->salary_company_logo)
                <img src="{{ asset('Company_logos/'.$record->salary_company_logo) }}" class="logo px-2 bg-white py-1 rounded">
            @endif
        @else
            @if($record->company_logo)
                <img src="{{ asset('logos/'.$record->company_logo) }}" class="logo px-2 bg-white py-1 rounded">
            @endif
        @endif
        

        <h5 class="mb-1">{{ $record->salary_company_name }}</h5>
        <small>Payslip Verification</small>

        <div class="mt-2">
            <span class="status">✔ Verified</span>
        </div>
    </div>

    <!-- BODY -->
    <div class="body">

        <!-- Employee Info -->
        <div class="row g-3 mb-3">

            <div class="col-6">
                <div class="label">Employee</div>
                <div class="value">{{ $record->name }}</div>
            </div>

            <div class="col-6">
                <div class="label">Employee ID</div>
                <div class="value">{{ $record->staff_code }}</div>
            </div>

            <div class="col-6">
                <div class="label">Department</div>
                <div class="value">{{ $record->department_name }}</div>
            </div>

            <div class="col-6">
                <div class="label">Designation</div>
                <div class="value">{{ $record->job_role_name }}</div>
            </div>

            <div class="col-6">
                <div class="label">Payroll Month</div>
                <div class="value">
                    {{ date('F', mktime(0,0,0,$record->payroll_month,1)) }}
                    {{ $record->payroll_year }}
                </div>
            </div>

            <div class="col-6">
                <div class="label">Generated On</div>
                <div class="value">{{ date('d M Y', strtotime($record->created_at)) }}</div>
            </div>

        </div>

        <!-- Salary Summary -->
        <div class="salary-box mb-3">

            <div class="d-flex justify-content-between">
                <span>Total Earnings</span>
                <strong class="earn">₹ {{ number_format($record->total_earnings,2) }}</strong>
            </div>

            <div class="d-flex justify-content-between">
                <span>Total Deductions</span>
                <strong class="deduct">₹ {{ number_format($record->total_deductions,2) }}</strong>
            </div>

            <hr>

            <div class="d-flex justify-content-between">
                <strong>Net Salary</strong>
                <strong style="color: {{ $baseColor }}">
                    ₹ {{ number_format($record->net_salary,2) }}
                </strong>
            </div>

        </div>

        <!-- Components -->
        <div class="row">

            <!-- Earnings -->
            <div class="col-md-6 mb-3">
                <h6 class="text-success">Earnings</h6>
                 @if($record->components->where('type','earning')->count() == 0)
                    <div class="small text-muted">No earnings applied.</div>
                 @else
                    @foreach($record->components->where('type','earning') as $c)
                        <div class="d-flex justify-content-between small">
                            <span>{{ $c->component_name }}</span>
                            <span class="text-nowrap">₹ {{ number_format($c->amount,2) }}</span>
                        </div>
                    @endforeach
                @endif
            </div>

            <!-- Deductions -->
            <div class="col-md-6 mb-3">
                <h6 class="text-danger">Deductions</h6>
                @if($record->components->where('type','deduction')->count() == 0)
                    <div class="small text-muted">No deductions applied.</div>
                @else
                    @foreach($record->components->where('type','deduction') as $c)
                        <div class="d-flex justify-content-between small">
                            <span>{{ $c->component_name }}</span>
                            <span class="text-nowrap">₹ {{ number_format($c->amount,2) }}</span>
                        </div>
                    @endforeach
                @endif
                
            </div>

        </div>

    </div>

    <!-- FOOTER -->
    <div class="footer">
        This payslip is digitally verified by {{ $record->salary_company_name }}.
    </div>

</div>

</body>
</html>