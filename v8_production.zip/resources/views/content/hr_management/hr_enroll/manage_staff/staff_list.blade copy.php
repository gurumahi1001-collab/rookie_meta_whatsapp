@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp
<style>
    .skeleton-transfer {
    position: relative;
    overflow: hidden;
    background: #e9ecef;
    border-radius: 6px;
}

.skeleton-transfer::after {
    content: "";
    position: absolute;
    top: 0;
    left: -150%;
    width: 150%;
    height: 100%;
    background: linear-gradient(
        90deg,
        rgba(255,255,255,0) 0%,
        rgba(255,255,255,0.7) 50%,
        rgba(255,255,255,0) 100%
    );
    animation: shimmer 1.5s infinite;
}

@keyframes shimmer {
    100% {
        left: 150%;
    }
}

.skeleton-circle-transfer {
    width: 110px;
    height: 110px;
    border-radius: 50%;
}

.skeleton-text-transfer {
    height: 16px;
    margin-bottom: 10px;
}

.skeleton-title-transfer {
    height: 28px;
    width: 200px;
    margin-bottom: 12px;
}

.skeleton-badge-transfer {
    height: 24px;
    width: 90px;
    border-radius: 20px;
}
</style>
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn {
        width: 100%;
        height: 100%;
        display: none;
        color: black;
        background-color: rgba(0, 0, 0, 0.2);
    }

    .document-thumbnail:hover .view-btn {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>
<style>
    .mini_dashboard_box .dashboard-card {
        border-radius: 12px;
        transition: all .3s ease;
    }

    .mini_dashboard_box .dashboard-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .dashboard-icon {
        /* font-size:28px; */
        /* margin-bottom:5px; */
    }

    .total-card {
        background: #f8f9fa;
    }

    .company-card {
        color: #fff;
    }

    .company-card img {
        height: 35px;
        margin-bottom: 5px;
    }

    .company-count {
        font-size: 22px;
        font-weight: bold;
    }
</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <ul class="nav nav-tabs border-bottom-0" role="tablist">
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/manage_staff') }}"
                    type="button"
                    class="nav-link active"
                    role="tab">
                    Staff
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/exit_staff') }}"
                    type="button"
                    class="nav-link"
                    role="tab">
                    Exit Staff
                </a>
            </li>
        </ul>
        <div class="d-flex align-items-center justify-content-between gap-2">
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->

            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="mini_dashbaord">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Dashboard"><i class="mdi mdi-view-dashboard text-center"></i></span>
            </a>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Manage Staff</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Enroll
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                @if($user_id == 0)
                <button class="btn btn-dark" type="button" onclick="openBulkSalaryModal()"> <i class="mdi mdi-account-cash me-1"></i> </button>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_old_staff">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Old Staff
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_report">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>update report
                </a>
                @endif
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_update_staffId" onclick="open_update_staffId()">
                    <span class="me-2"><i class="mdi mdi-account-box-edit-outline"></i></span>Update Staff Id
                </a>
                <a href="{{ url('hr_enroll/manage_staff/add_staff') }}" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Staff
                </a>
            </div>
        </div>
        <div class="mini_dashboard_box mb-3" style="display: none;">
            <div class="row border rounded align-items-center p-2 border-primary mx-2">

                <!-- Total Staff -->
                <div class="col-md-3">
                    <div class="card dashboard-card total-card shadow-sm h-100 border">
                        <div class="card-body text-center d-flex flex-column align-items-center justify-content-center">
                            <div class="dashboard-icon">
                                <i class="mdi mdi-account-group fs-3"></i>
                            </div>

                            <h3 class="fw-bold mb-0" id="total_staff_dash">0</h3>
                            <small class="text-muted">Total Staff</small>
                        </div>
                    </div>
                </div>

                <!-- Company cards -->
                <div class="col-md-9">
                    <div class="d-flex gap-2 align-items-center flex-wrap" id="companyStaffCards">

                    </div>
                </div>

            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                        <option value="0_2_months">0-2 Months</option>
                        <option value="2_4_months">2-4 Months</option>
                        <option value="4_6_months">4-6 Months</option>
                        <option value="gt_6_months">Greater than 6 Months</option>
                        <option value="6_12_months">6-12 Months</option>
                        <option value="gt_1_year">Greater than 1 Year</option>
                        <option value="1_2_years">1-2 Years</option>
                        <option value="gt_2_years">Greater than 2 Years</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                        class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-100px">Company / Entity</th>
                                <th class="min-w-100px">Dept /Div /<br>Job Role</th>
                                <th class="min-w-100px">Date Of Joining</th>
                                <th class="min-w-100px">Salary</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="assignShiftModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="assign_staff_img" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Assign Shift</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="assign_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="assign_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <input type="hidden" id="assign_staff_id">
                <input type="hidden" id="current_shift_id">

                <div class="row">
                    <!-- CURRENT SHIFT -->
                    <div class="col-md-6" id="currentShiftBox" style="display:none;">
                        <div class="card border shadow-sm mb-4">
                            <div class="card-header bg-label-warning">
                                <b>Current Shift</b>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="fw-semibold text-dark">Shift Name</label>
                                    <input type="text" id="current_shift_name" class="form-control" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold text-dark">End Date</label>
                                    <input type="text" id="previous_end_date" class="form-control common_datepicker">
                                    <small class="text-muted">Last working day of current shift</small>
                                </div>
                                <div id="currentShiftPreview" class="border border-primary rounded p-3 bg-light d-none">
                                    <div class="d-flex justify-content-between mb-2">
                                        <b class="text-primary">Shift Schedule</b>
                                        <span class="badge bg-success" id="currentShiftTotalDuration"></span>
                                    </div>
                                    <div id="currentShiftDays"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- NEW SHIFT -->
                    <div class="col-md-6">
                        <div class="card border shadow-sm">
                            <div class="card-header bg-label-primary">
                                <b>Assign New Shift</b>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="fw-semibold">Select Shift</label>
                                    <select id="shift_select" class="form-select select3" onchange="shift_change_func()">
                                        <option value="">Select Shift</option>
                                        @foreach($shifts as $shift)
                                        <option value="{{$shift->sno}}">
                                            {{$shift->shift_name}}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold">Start Date</label>
                                    <input type="text" id="shift_start_date" class="form-control common_datepicker">
                                    <small class="text-muted">Next working day of Assign shift</small>
                                </div>
                                <div id="shiftPreview" class="border rounded border-primary p-3 bg-label-success d-none">
                                    <div class="d-flex justify-content-between mb-2">
                                        <b class="text-primary">Shift Schedule</b>
                                        <span class="badge bg-success" id="shiftTotalDuration"></span>
                                    </div>
                                    <div id="shiftDays"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end mt-3">
                    <button type="button" class="btn btn-primary px-5" onclick="assignShift()">Assign Shift</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<!--begin::Modal view staff--->
<div class="modal fade" id="employeePayrollModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="payroll_staff_img" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">Employee Payroll Details</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="payroll_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="payroll_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white rounded-bottom-1">
                <form id="employeePayrollForm">
                    @csrf
                    <input type="hidden" name="employee_sno" id="employee_sno">
                    <div class="modal-body">

                    <div class="col-lg-4">
                        <label class="fw-semibold">
                            Account Type
                        </label>

                        <div>

                            <div class="form-check form-check-inline">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="is_multiple_account"
                                    value="0"
                                    checked
                                    onclick="accountTypeChange()">

                                <label class="form-check-label">
                                    Single Account
                                </label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="is_multiple_account"
                                    value="1"
                                    onclick="accountTypeChange()">

                                <label class="form-check-label">
                                    Multiple Account
                                </label>
                            </div>

                        </div>
                    </div>

                        <!-- Salary PROFILE -->
                        <div class="d-flex gap-1">
                            <h6 class="text-primary">Salary Details</h6>
                        </div>
                        <!-- PAYROLL PROFILE -->
                        <div class="row singleSalaryDiv">
                            <div class="col-lg-12 mb-3">
                                <div class="row">
                                    <div class="col-lg-12">

                                        <div class="card shadow-sm border-0 rounded-3">
                                            <div class="card-body row">
                                                <h6 class="fw-bold mb-3 text-primary">Salary Info</h6>
                                                <div class="col-lg-4">

                                                    <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span class="text-danger">*</span></label></label>
                                                    <input type="text" id="basic_salary" class="form-control mb-2" name="basic_salary" placeholder="Enter Basic Salary" oninput="this.value=this.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1'); per_day_salary_value();">
                                                    <div class="text-danger error_msg"></div>
                                                </div>

                                                <div class="col-lg-4">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost<span class="text-danger">*</span></label>
                                                    <input type="text" id="per_hr_cost" class="form-control mb-2" name="per_hr_cost" placeholder="Enter Per Hour Cost" value="{{$staffData->per_hour_cost ?? ''}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                    <div class="text-danger error_msg"></div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Per Day Salary<span class="text-danger">*</span></label></label>
                                                    <input type="text" id="per_day_salary" class="form-control mb-2" name="per_day_salary" placeholder="Enter Per Day Cost" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" readonly>
                                                    <div class="text-danger error_msg"></div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Casual Leave<span class="text-danger">*</span></label></label>
                                                    <input type="text" id="casual_leave_count" class="form-control" name="casual_leave_count" placeholder="Enter Casual Leave count" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" maxlength="2" value="">
                                                    <div class="text-danger error_msg"></div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Type<span class="text-danger">*</span></label></label>
                                                    <div>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="radio" name="salary_type" id="salary_cash" onclick="salary_type_checked()"
                                                                value="1" checked />
                                                            <label class="form-check-label" for="salary_cash">Cash</label>
                                                        </div>
                                                        <div class="form-check form-check-inline">
                                                            <input class="form-check-input" type="radio" name="salary_type" id="salary_bank"
                                                                value="2" onclick="salary_type_checked()" />
                                                            <label class="form-check-label" for="salary_bank">Bank</label>
                                                        </div>
                                                    </div>
                                                    <div class="text-danger error_msg"></div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <label class="text-black mb-1 fs-6 fw-semibold">Salary Date<span class="text-danger">*</span></label></label>
                                                    <select name="salary_date" id="salary_date" class="select3 form-select required-field">
                                                        <option value="">Select Salary Date</option>
                                                        <option value="1">5th</option>
                                                        <option value="2">15th</option>
                                                    </select>
                                                    <div class="text-danger error_msg"></div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="d-flex justify-content-between mt-3">

                                                        <div>
                                                            <div class="fw-semibold">Payslip Available</div>
                                                        </div>

                                                        <div class="form-check ">
                                                            <input class="form-check-input" value="1" name="is_payslip" id="is_payslip" type="checkbox" checked>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="multipleAccountDiv" class="d-none">

                            <div class="d-flex justify-content-between mb-3">

                                <h5 class="text-primary">
                                    Salary Accounts
                                </h5>

                                <button
                                    type="button"
                                    class="btn btn-primary btn-sm"
                                    onclick="addSalaryAccountRow()">

                                    Add Account
                                </button>

                            </div>

                            <table class="table table-bordered">

                                <thead>
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th>Primary</th>
                                        <th>Company</th>
                                        <th>Bank</th>
                                        <th>Gross Salary</th>
                                        <th>Per Day</th>
                                        <th>Per Hour</th>
                                        <th>Payslip</th>
                                        <th></th>
                                    </tr>
                                </thead>

                                <tbody id="salaryAccountBody">

                                </tbody>

                            </table>

                        </div>

                        <hr class="salary_bank_div">

                        <!-- BANK DETAILS -->
                        <div class="d-flex gap-1 salary_bank_div">
                            <h6 class="text-primary">Bank Details</h6>
                        </div>

                        <div class="row salary_bank_div">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Staff Bank Name <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field" id="staff_bank_name"
                                    name="staff_bank_name" placeholder="Enter Staff Bank Name" value="" />
                                <small class="text-danger error" data-error="staff_bank_name"></small>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Staff Bank Branch <span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field" id="staff_bank_branch"
                                    name="staff_bank_branch" placeholder="Enter Staff Bank Branch" value="" />
                                <small class="text-danger error" data-error="staff_bank_branch"></small>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder" id="staff_acc_holder" name="staff_acc_holder" maxlength="50" value="" />
                                <small class="text-danger error" data-error="staff_acc_holder"></small>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No" id="staff_acc_no" name="staff_acc_no" maxlength="20" value="" />
                                <small class="text-danger error" data-error="staff_acc_no"></small>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code" id="ifsc_code" name="ifsc_code" maxlength="20" oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'');" value="" />
                                <small class="text-danger error" data-error="ifsc_code"></small>
                            </div>


                        </div>
                        <hr class="salary_bank_div">
                        <!-- STATUTORY DETAILS -->
                        <div class="d-flex gap-1 salary_bank_div">
                            <h6 class="text-primary">Statutory & Tax Details</h6>
                        </div>
                        <div class="row mb-3 salary_bank_div">
                            <div class="col-md-3">
                                <label>UAN Number (PF) <small class="text-muted">( e.g. 10300400 )</small></label>
                                <input type="text" name="uan_no" class="form-control"
                                    placeholder="Enter UAN Number" maxlength="12" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                <small class="text-danger error" data-error="uan_no"></small>
                            </div>
                            <div class="col-md-3">
                                <label>ESI Number <small class="text-muted">( e.g. 2203344 )</small></label>
                                <input type="text" name="esi_no" class="form-control"
                                    placeholder="Enter ESI Number" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                <small class="text-danger error" data-error="esi_no"></small>
                            </div>
                            <div class="col-md-3">
                                <label>PAN Number <small class="text-muted">( e.g. ABCD34F )</small></label>
                                <input type="text" name="pan_no" class="form-control"
                                    placeholder="Enter PAN Number" maxlength="10" oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'');">
                                <small class="text-danger error" data-error="pan_no"></small>
                            </div>
                            <div class="col-md-3">
                                <label>Aadhar Number <small class="text-muted">( e.g. 98761234 )</small></label>
                                <input type="text" name="aadhar_no" class="form-control" placeholder="Enter Aadhar Number" maxlength="12" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                <small class="text-danger error" data-error="aadhar_no"></small>
                            </div>
                        </div>
                        <hr class="">
                        <!-- Company Bank DETAILS -->
                        <div class="d-flex gap-1 ">
                            <h6 class="text-primary">Company Bank Details</h6>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3 ">
                                <div class="row">
                                    <div class="col-lg-4 mb-3 ">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Salary Company<span
                                                class="text-danger">*</span></label>
                                        <select id="salary_company_id" name="salary_company_id" class="select3 form-select required-field" onchange="salary_company_change()">
                                            <option value="">Select Company Name</option>
                                            @if(isset($company_list))
                                            @foreach($company_list as $clist)
                                            <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                    <div class="col-lg-4 mb-3 ">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Salary Company<span
                                                class="text-danger">*</span></label>
                                        <select id="salary_bank_id" name="salary_bank_id" class="select3 form-select required-field">
                                            <option value="">Select Company Bank</option>
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="savePayrollBtn" onclick="validation_func()">
                            <span class="btn-text">Save Payroll Details</span>
                            <span class="spinner-border spinner-border-sm d-none"></span>
                        </button>
                    </div>

                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

<div class="modal fade" id="salaryMappingModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="salaryMappingForm">
                @csrf
                <input type="hidden" name="employee_sno" id="mapping_employee_sno">
                <div class="modal-header">
                    <h5>Employee Salary Mapping</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label>Salary Structure</label>
                            <select name="salary_structure_sno" class="form-control select3">
                                <option value="">Select Structure</option>
                                @foreach($structures as $s)
                                <option value="{{ $s->sno }}">
                                    {{ $s->structure_name }}
                                </option>
                                @endforeach
                            </select>
                            <small class="text-danger error" data-error="salary_structure_sno"></small>
                        </div>

                        <div class="col-md-6">
                            <label>Effective From</label>
                            <input type="text" name="effective_fromsss" class="form-control common_datepicker" placeholder="Select Effective From Date">
                            <small class="text-danger error" data-error="effective_fromsss"></small>
                        </div>

                    </div>
                    <div class="mt-3">
                        <label>Change Reason</label>
                        <input type="text" name="change_reason" class="form-control" placeholder="Example: Annual increment">
                    </div>
                    <hr>

                    <h6>Salary History</h6>

                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Structure</th>
                                <th>Effective From</th>
                                <th>Effective To</th>
                                <th>Reason</th>
                            </tr>
                        </thead>
                        <tbody id="salaryHistoryTable" class="text-black fw-semibold fs-7">

                        </tbody>
                    </table>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" onclick="saveSalaryMapping()" id="saveMappingBtn">
                        <span class="btn-text">
                            Save Salary Mapping
                        </span>
                        <span class="spinner-border spinner-border-sm d-none"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--begin::Modal - Send Test Template-->
<div class="modal fade" id="kt_modal_send_test_template" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Test Template</h3>
                </div>

                <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">

                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="text-danger" id="communication_err"></div>
                    </div>
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description">Thank you for your Service Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of </textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Test Template</button>
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Test Template-->

<!--begin::Modal Filter-->
<div class="modal fade" id="kt_modal_update_staffId" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">

            <div class="modal-header border-0">
                <h3 class="text-center w-100">Update Staff ID</h3>
                <button class="btn btn-sm btn-icon btn-light" data-bs-dismiss="modal">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>

            <div class="modal-body px-6 pb-6">

                <!-- COMPANY TABS -->
                <ul class="nav nav-tabs flex-nowrap" role="tablist" id="companyTabs">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                        <div class="scroll-container" id="scrollContainer">
                            <li class="item nav-item">
                                <a type="button"
                                    class="nav-link scroll-link company-tab active"
                                    data-company="0"
                                    data-bs-toggle="tab" href="#">
                                    Elysium Groups
                                </a>
                            </li>
                            @foreach ($company_list as $comp)
                            <li class="item nav-item">
                                <a type="button"
                                    class="nav-link scroll-link company-tab"
                                    data-company="{{$comp->sno}}"
                                    data-bs-toggle="tab" href="#"
                                    aria-selected="true">
                                    {{ $comp->company_name }}
                                </a>
                            </li>
                            @endforeach
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>

                <!-- STAFF LIST -->
                <div class="mt-4" id="companyStaffList">
                    <div class="text-center text-muted py-5">
                        Loading staff...
                    </div>
                </div>

                <!-- BULK UPDATE BUTTON -->
                <div class="mt-4 text-end" id="bulkUpdateContainer" style="display:none;">
                    <button class="btn btn-primary" id="bulkUpdateBtn">
                        Bulk Update Staff IDs
                    </button>
                </div>

            </div>

        </div>
    </div>
</div>
<!--end::Modal Filter-->

<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<!--begin::Modal exit staff--->
<div class="modal fade" id="kt_modal_exit_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Exit Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="cus_drp_form" action="{{ route('departure_staff') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <input type="hidden" id="exist_sts_change_id" name="exist_sts_change_id" />
                    <input type="hidden" id="exist_staff_id" name="exist_staff_id" />
                    <div class="row mb-3">
                        <div class="col-lg-6 mb-2 border-end">
                            <div class="row">
                                <div class="col-lg-12 d-flex align-items-center px-1 mb-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-px-100 h-auto rounded-circle"
                                                id="exist_staff_profile_image" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="fs-5 fw-bold" id="exist_staff_name">Mahesh Kumar</label>
                                        <div class="d-flex text-primary">
                                            <a href="javascript:;" class="text-primary fw-semibold fs-7" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name" id="exist_nick_name">
                                                Karthik
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-domain fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_company_name">Elysium Techonologies Pvt Ltd</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-office-building fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Entity Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_entity_name">Click My Project</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-graph fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_department">Sales</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-file-tree fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Division Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_division">Business Development Executive</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-briefcase fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Position"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_job_role">Senior Executive</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-calendar-badge-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_doj">12-Sep-2024</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <div class="row mt-2 mb-3">
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="notice_period" id="notice_period" value="4" onchange="departure_func(4);" checked />
                                        <label class="form-check-label" for="notice_period">Notice Period</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="relieve" id="relieve" value="5" onchange="departure_func(5);" />
                                        <label class="form-check-label" for="relieve">Relieve</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="upscond" id="upscond" value="6" onchange="departure_func(6);" />
                                        <label class="form-check-label" for="franchise">Abscond</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="terminate" id="terminate" value="7" onchange="departure_func(7);" />
                                        <label class="form-check-label" for="franchise">Terminate</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="date_view">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Last Attend Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="staff_last_date" name="staff_last_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />

                                </div>
                                <div id="staff_last_date_err" class="text-danger"></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6 mt-2" style="display:none;" id="starting_date">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span class="text-danger">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="notice_start_date" name="notice_start_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                                    </div>
                                    <div id="notice_start_date_err" class="text-danger"></div>
                                </div>
                                <div class="col-lg-6 mt-2" style="display:none;" id="ending_date">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span class="text-danger">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="notice_end_date" name="notice_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly />
                                    </div>
                                    <div id="notice_end_date_err" class="text-danger"></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="reason_add">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="dep_reason" name="dep_reason" placeholder="Enter Reason"></textarea>
                                <div id="dep_reason_err" class="text-danger"></div>
                            </div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                        <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">No</button>
                        <button type="button" class="btn btn-primary me-3" id="exit_submit_butt" onclick="status_change_validation()">Exit Period</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - exit staff-->



<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_old_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Add Old Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form method="POST" action="{{ route('add_old_staff') }}" enctype="multipart/form-data" autocomplete="off" id="addOldStaffForm">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <input type="hidden" id="staff_data_payload" name="staff_data_payload" />
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                            <select id="staff_company_name" name="staff_company_name" class="select3 form-select">
                                <option value="">Select Company Name</option>
                                @if(isset($company_list))
                                @foreach($company_list as $clist)
                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                @endforeach
                                @endif
                            </select>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                            <select id="staff_entity_name" name="staff_entity_name" class="select3 form-select">
                                <option value="">Select Entity Name</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                            <select id="staff_branch_name" name="staff_branch_name" class="select3 form-select">
                                <option value="">Select Branch Name</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff data :</label>
                            <span lass="text-black mb-1 fs-6 fw-semibold " id="total_Staff_data">0 </span>Record Found
                            <div lass="text-black mb-1 fs-6 fw-semibold " id="total_Staff_list"></div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                        <button type="button" class="btn btn-primary me-3" id="submitStaffBtn" onclick="submit_form()">Add Old Staff</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_staff_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Staff Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form method="POST" action="{{ route('update_staff_timestamp_report') }}" enctype="multipart/form-data" autocomplete="off" id="updateTimestampForm">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                            <input type="text" id="date_timestamp" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-lg-6">
                            <label class="text-black mb-1 fs-6 fw-semibold">Timestamp data :</label>
                            <span lass="text-black mb-1 fs-6 fw-semibold " id="total_timestamp_data">0 </span>Record Found

                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                        <button type="button" class="btn btn-primary me-3" id="submitTimestampBtn" onclick="submit_timestamp_form()">Update Staff Timestamp</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id" />
                <!-- <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div> -->
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->


<div class="modal fade" id="filePreviewModal" tabindex="-1" aria-labelledby="filePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="filePreviewModalLabel">File Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Modal content dynamically injected -->
                <div id="filePreviewContent" class="d-flex justify-content-center align-items-center">
                    <!-- Preview content will be added here dynamically -->
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="view_staff_img_sm" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View Staff</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <div class="skeleton-loader-view w-150px"></div>
                    <label class="fs-5 fw-semibold text-primary view-data" id="view_staff_name" style="display:none;">Mahesh Kumar</label>
                    <div class="skeleton-loader-view w-125px"></div>
                    <label class="fs-6 fw-semibold text-black view-data" id="view_staff_mobile" style="display:none;">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <input type="hidden" id="sts_change_idol" name="sts_change_id" />
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link active"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                    Basic Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link"
                                    role="tab"
                                    data-bs-toggle="tab" data-bs-target="#contact_info" aria-controls="contact_info" aria-selected="false">
                                    Contact Details
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#work_info" aria-controls="work_info" aria-selected="false">
                                    Work Type
                                </button>
                            </li>
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#edu_info" aria-controls="edu_info" aria-selected="false">
                                    Education Details
                                </button>
                            </li>
                            <!-- <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Application" aria-controls="Application" aria-selected="false">
                                    Application Details
                                </button>
                            </li> -->
                            <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#StaffCheckList" aria-controls="StaffCheckList" aria-selected="false">
                                    Staff Checklist
                                </button>
                            </li>
                            <!-- <li class="nav-item">
                                <button
                                    type="button"
                                    class="nav-link" role="tab"
                                    data-bs-toggle="tab" data-bs-target="#Orientation" aria-controls="Orientation" aria-selected="false">
                                    Orientation
                                </button>
                            </li> -->
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-8">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_email" style="display:none;">-</label>
                                        </div>

                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Date Of Birth</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_dob" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Gender</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_gender" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_father_name" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Father Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_father_occup" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_name" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Occupation</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_occup" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Mother Tongue</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_mother_tongue" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Languages Known</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_language_knw" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_marital_status" style="display:none;">Married</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Children</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_has_children" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Siblings</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_has_siblings" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Hobby</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_hobby" style="display:none;">-</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_staff_descrip" style="display:none;">-</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-175px h-175px rounded-circle"
                                                id="view_staff_profile_image" style="border: 2px solid #ab2b22;" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="row">

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Company Details</div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Company Details</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_company_type" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_department" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Division</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_division" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_job_role" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Designation Details</div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Pseudo Name</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_nick_name" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Date Of Joining</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_doj" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Basic Salary</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-danger view-data" id="view_staff_salary" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Per Hour Cost</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-danger view-data" id="view_staff_per_hr_cost" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Skill Tag</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_skill_tag" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Login Credentials</div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_user_name" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_password" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">User Role</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <div class="col-6">
                                                    <div class="skeleton-loader-view max-w-75"></div>
                                                    <label class="fw-semibold fs-6 text-black view-data" id="view_staff_user_role" style="display:none;">-</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Other Credentials</div>
                                        </div>

                                        <div id="otherCredentialsContainer"></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="contact_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">

                                    <div class="row">
                                        <div id="contactPersonContainer"></div>
                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Permanent Address</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_permnt_address">-</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Residential Address</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_temp_address">-</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile Number</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_alternate_no">-</label>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="work_info" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Type</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black" id="view_exp_type">Experience</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Shifted Company Count</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black" id="view_shift_comp_count">2</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Total Years Of Experience</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6">
                                                    <span class="badge bg-primary text-white px-3 fs-7" id="view_total_yr_exp">3</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div id="workDetailsContainer" class="row"></div>

                                        <div class="divider text-start-center">
                                            <div class="divider-text fs-5 text-primary fw-semibold my-2">Attachment Details</div>
                                        </div>

                                        <div id="documentContainer" class="col-lg-12 d-flex align-items-center justify-content-start gap-3 flex-wrap py-3 px-1">

                                        </div>



                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="edu_info" role="tabpanel">
                            <div class="row mb-2">

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-3 fw-semibold fs-7 text-dark">Course Completed</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black" id="view_staff_completed_course_tag">-</label>
                                    </div>
                                </div>


                                <div class="divider text-start-center">
                                    <div class="divider-text fs-5 text-primary fw-semibold my-2">Educational Details</div>
                                </div>


                                <div id="educationContainer" class="row"></div>



                            </div>
                        </div>
                        <div class="tab-pane fade" id="Application" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Technical Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Java , C# , .Net ,FullStack</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Non Technical Position</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Sales Management , SEO Analyst</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Interview Attended Company</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">
                                                    <span class="badge bg-label-primary text-primary fw-semibold fs-6 rounded">EIBS</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Already Attended Interview In Elysium Groups</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Attended Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">07-10-2024 , 04-11-2024 , 12-01-2025</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Submit Original Certificate</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Accepted To Travel For Official Purpose</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Yes</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Joining Status</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">Immediate Joining</label>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <div class="row mb-2">
                                                <label class="col-5 fw-semibold fs-7 text-dark">Joining Date</label>
                                                <label class="col-1 fw-semibold fs-7">:</label>
                                                <label class="col-6 fw-semibold fs-6 text-black">07-10-2025</label>
                                            </div>
                                        </div>


                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="StaffCheckList" role="tabpanel">
                            <div class="row mb-2">
                                <div class="col-lg-12">
                                    <div id="documentCheckContainer" class="row"></div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="Orientation" role="tabpanel">
                            <div class="row mb-2">
                                <h5 class="title fw-bold mt-2 text-warning">Staff Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <img src="#"
                                                style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Company Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Job Role</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Executive</label>
                                    </div>
                                </div>

                                <h5 class="title fw-bold mt-2 text-warning">Department Introduction</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Score</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Department</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">HR Management</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">Karthiga</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Report</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <img src="#"
                                                style="width:70px; height:70px;" />
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->



<div class="modal fade" id="employeeSalaryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="salary_staff_img" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Update Salary Structure</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="salary_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="salary_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <form id="employeeSalaryForm">
                    @csrf
                    <input type="hidden" id="employee_sno">
                    <input type="hidden" id="employee_structure_sno">
                    <div class="row">
                        <!-- LEFT -->
                        <div class="col-xl-8">
                            <!-- EMPLOYEE INFO -->
                            <div class="card border-0 shadow-sm rounded-4 mb-4">
                                <div class="card-body p-4">
                                    <div class="row">
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Employee Name</label>
                                            <input type="text" class="form-control" id="employee_name" readonly>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Employee ID</label>
                                            <input type="text" class="form-control" id="employee_code" readonly>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold"> Salary Template</label>
                                            <select class="form-select select2" id="payroll_template_sno">
                                                <option value="">Select Template</option>
                                                @foreach($salaryTemplates as $template)
                                                <option value="{{ $template->sno }}">{{ $template->template_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">
                                                Effective From
                                            </label>
                                            <input type="text" class="form-control common_datepicker" id="effective_from">
                                        </div>

                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Gross Salary</label>
                                            <input type="number" class="form-control" id="employee_gross_salary">
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Revision Reason</label>
                                            <input type="text" class="form-control" id="revision_reason">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- COMPONENTS -->
                            <div class="card border-0 shadow-sm rounded-4">
                                <div class="card-body p-4">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <div>
                                            <h5 class="fw-bold mb-1">Salary Components</h5>
                                            <small class="text-muted">Earnings and deductions</small>
                                        </div>
                                    </div>
                                    <div id="employee_salary_components"></div>
                                </div>
                            </div>
                        </div>
                        <!-- RIGHT -->
                        <div class="col-xl-4">
                            <div class="card border-0 shadow-lg rounded-4 sticky-top">
                                <div class="card-body p-4">
                                    <h5 class="fw-bold mb-4">Salary Summary</h5>
                                    <div class="summary-item">
                                        <span>Total Earnings</span>
                                        <strong id="emp_total_earnings">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Total Deductions</span>
                                        <strong id="emp_total_deductions">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Net Salary</span>
                                        <strong id="emp_net_salary">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>CTC</span>
                                        <strong id="emp_ctc">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Employer Contribution</span>
                                        <strong id="emp_employer_contribution">
                                            ₹ 0.00
                                        </strong>
                                    </div>
                                    <button type="button" class="btn btn-primary w-100 mt-4 save-employee-salary-btn" onclick="saveEmployeeSalaryStructure()">
                                        <i class="mdi mdi-content-save-outline me-1"></i>Save Salary Structure
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="monthlyInputModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">

                        <h3 class="text-black"> Update variable Amount</h3>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <form id="monthlyInputForm">

                    @csrf

                    <input type="hidden" id="monthly_employee_sno">
                    <input type="hidden" id="payroll_variable_component_sno" value="13">
                    <div class="card border-0 bg-light rounded-4 mb-4">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-2">
                                    <img id="variable_staff_img" class="rounded-circle" width="50">
                                </div>
                                <div class="col-lg-5">
                                    <h5 id="variable_staff_name"
                                        class="fw-bold mb-1">
                                    </h5>
                                    <div id="variable_staff_mobile"
                                        class="text-muted">
                                    </div>
                                </div>
                                <div class="col-lg-5 text-end">
                                    <span class="badge bg-warning text-dark px-4 py-2">
                                        VARIABLE COMPONENT
                                    </span>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-lg-6 mb-4">

                            <label class="form-label fw-semibold">
                                Monthly Amount
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    ₹
                                </span>

                                <input type="number"
                                    class="form-control form-control-lg"
                                    id="variable_amount">

                            </div>

                        </div>

                        <div class="col-lg-6 mb-4">
                            <label class="form-label fw-semibold">Month</label>
                            <input type="text" class="form-control month_filter_common_class" id="variable_from_month" value="{{date('M-Y')}}" />
                        </div>

                    </div>

                    <div id="variable_alert"></div>



                    <div class="alert alert-warning rounded-4 border-0">

                        <div class="d-flex">

                            <i class="mdi mdi-alert-circle-outline fs-2 me-3"></i>

                            <div>

                                <small>
                                    Variable amount will Include In Fixed Gross salary after 3 continuous months.
                                </small>

                            </div>

                        </div>

                    </div>



                    <div class="mb-4">

                        <label class="form-label fw-semibold">
                            HR Remarks
                        </label>

                        <textarea
                            class="form-control"
                            rows="3"
                            id="remarks"></textarea>

                    </div>
                    <button type="button"
                        class="btn btn-primary w-100 py-3 fw-bold rounded-4"
                        onclick="saveVariableAmount()">

                        <i class="mdi mdi-content-save-outline me-1"></i>

                        Save Variable Amount

                    </button>

                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="bulkSalaryModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-dark text-white">
                <div>
                    <h3 class="mb-1">
                        Bulk Salary Structure Update
                    </h3>
                    <small>
                        Auto assign templates based on salary type
                    </small>
                </div>
                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- LEFT -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm border-0 rounded-4 mb-4">
                            <div class="card-body">
                                <h5 class="fw-bold mb-4">
                                    Settings
                                </h5>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Template For Salary Type 1
                                    </label>
                                    <select class="form-select select3"
                                        id="bulk_template_type_1">
                                        @foreach($salaryTemplates as $template)
                                        <option value="{{ $template->sno }}">
                                            {{ $template->template_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Template For Salary Type 2
                                    </label>
                                    <select class="form-select select3"
                                        id="bulk_template_type_2">
                                        @foreach($salaryTemplates as $template)
                                        <option value="{{ $template->sno }}">
                                            {{ $template->template_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Effective From
                                    </label>
                                    <input type="date"
                                        class="form-control"
                                        id="bulk_effective_from">
                                </div>

                                <div class="mb-4">

                                    <label class="form-label fw-semibold">
                                        Revision Reason
                                    </label>

                                    <textarea class="form-control"
                                        id="bulk_revision_reason"></textarea>
                                </div>

                                <button class="btn btn-primary w-100"
                                    onclick="previewBulkSalaryEmployees()">

                                    <i class="mdi mdi-eye"></i>
                                    Preview Employees

                                </button>

                            </div>

                        </div>

                    </div>

                    <!-- RIGHT -->

                    <div class="col-lg-8">

                        <div class="card border-0 shadow-sm rounded-4">

                            <div class="card-body">

                                <div class="d-flex justify-content-between align-items-center mb-3">

                                    <div>

                                        <h5 class="fw-bold mb-1">
                                            Employee Preview
                                        </h5>

                                        <small class="text-muted">
                                            Employees without salary structure
                                        </small>

                                    </div>

                                    <span class="badge bg-dark fs-6"
                                        id="bulk_total_staff">
                                        0 Staff
                                    </span>

                                </div>

                                <div class="table-responsive">

                                    <table class="table align-middle">

                                        <thead>

                                            <tr>
                                                <th>Employee</th>
                                                <th>Salary Type</th>
                                                <th>Current Template</th>
                                                <th>Current From</th>
                                                <th>Current To</th>
                                                <th>New Template</th>
                                                <th>New Effective From</th>
                                            </tr>

                                        </thead>

                                        <tbody id="bulk_salary_preview_body">

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="modal-footer">

                <button class="btn btn-light"
                    data-bs-dismiss="modal">

                    Cancel

                </button>

                <button class="btn btn-success"
                    id="bulk_salary_save_btn"
                    onclick="saveBulkSalaryStructure()">

                    <i class="mdi mdi-content-save"></i>
                    Apply Bulk Salary Structure

                </button>

            </div>

        </div>

    </div>
</div>




<div class="modal fade" id="otPayrollModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="salary_staff_img" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Monthly OT Payroll</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="ot_staff_name">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <div class="row mb-4">

                    <div class="col-lg-4">
                        <input type="hidden" id="ot_monthly_employee_sno">

                        <label class="form-label">
                            Month
                        </label>

                        <input type="text"
                            id="ot_month"
                            class="form-control month_filter_common_class"
                            value="{{date('M-Y')}}">
                    </div>

                    <div class="col-lg-3 d-flex align-items-end">

                        <button class="btn btn-primary w-100"
                            onclick="loadOTDetails()">

                            Load OT Details
                        </button>
                    </div>

                </div>
                <div class="row g-3 mb-4">

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-primary text-white">
                            <div class="card-body">
                                <div>Total OT Hours</div>
                                <h2 id="total_ot_hours">0 Hrs</h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-success text-white">
                            <div class="card-body">
                                <div>Total OT Amount</div>
                                <h2>₹ <span id="overall_ot_amount">0.00</span></h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-warning text-dark">
                            <div class="card-body">
                                <div>Total OT Days</div>
                                <h2 id="total_ot_days">0</h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-dark text-white">
                            <div class="card-body">
                                <div>Department</div>
                                <h2 id="department_name">-</h2>
                            </div>
                        </div>
                    </div>

                </div>

                <div id="ot_summary" class="mb-2"></div>

                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                    <th>Date</th>
                                    <th>Day</th>
                                    <th>Status</th>
                                    <th>Shift Time</th>
                                    <th>Actual In</th>
                                    <th>Actual Out</th>
                                    <th>Worked Hours</th>
                                    <th>OT Hours</th>
                                    <th>OT Rate</th>
                                    <th>OT Amount</th>
                                    <th>Remarks</th>
                            </tr>
                        </thead>

                        <tbody id="ot_table_body"></tbody>

                    </table>

                </div>
                <div class="d-flex justify-content-end">
                     <button class="btn btn-success"
                    onclick="saveOTPayroll()" id="btnSaveOT">

                    Save OT Payroll
                </button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="kt_modal_staff_transferModel" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-1">
                        <div class="">
                            <i class="mdi mdi-transit-transfer text-dark fs-1"></i>
                        </div>

                        <div>
                            <h2 class="fw-bold text-dark mb-1">
                              Staff Transfer
                            </h2>
                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <form id="staffTransferForm">

                    <input type="hidden" id="transfer_staff_sno" name="staff_sno">
                    <div class="row card shadow-sm border-0 ">

                        <!-- Staff Profile -->
                        <div id="staffTransferProfile"></div>

                        <!-- Transfer Form -->
                        <div class="mt-5">
                            <div class="bg-light-primary">
                                <span class="ps-4 fs-4 fw-bold">
                                    Transfer To
                                </span>
                            </div>
                            <div class="card-body">
                                <div class="row mb-2">
                                    <div class="col-md-6 mb-3">
                                        <label class="fw-semibold">
                                            Company Type
                                        </label>
                                        <div>
                                            <div class="form-check form-check-inline mb-3">
                                                <label class="form-check-label" for="management">
                                                    <input class="form-check-input required-field" type="radio" name="company"
                                                        id="transfer_management" value="1" checked onclick="toggleDivs()"/>
                                                    Management
                                                </label>
                                            </div>
                                            <div class="form-check form-check-inline mb-3">
                                                <label class="form-check-label" for="business">
                                                    <input class="form-check-input required-field" type="radio" name="company"
                                                        id="transfer_business" value="2"  onclick="toggleDivs()"/>
                                                    Business
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div ">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_company" name="transfer_company" class="select3 form-select transfer-field">
                                            <option value="">Select Company Name</option>
                                                @if(isset($company_list))
                                                @foreach($company_list as $clist)
                                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                                @endforeach
                                                @endif
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_entity" name="transfer_entity" class="select3 form-select transfer-field">
                                            <option value="">Select Entity Name</option>
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_branch" name="transfer_branch" class="select3 form-select transfer-field">
                                            <option value="">Select Branch</option>
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_department" id="transfer_department" class="select3 form-select transfer-field">
                                                <option value="">Select Department</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Division<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_division" id="transfer_division" class="select3 form-select transfer-field">
                                                <option value="">Select Division</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_job_role" id="transfer_job_role" class="select3 form-select transfer-field" onchange="triggerTransferPreview()">
                                                <option value="">Select Job Role</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">User Role<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_role" id="transfer_role" class="select3 form-select transfer-field" onchange="triggerTransferPreview()">
                                                <option value="">Select User Role</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>

                                
                                        
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Transfer Reason <span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_reason" name="transfer_reason" class="select3 form-select transfer-field"
                                            onchange="toggleInputField_tranfer(this.value)">
                                            <option value="">Select Reason</option>
                                            @if (isset($exitReason) && count($exitReason) > 0)
                                            @foreach ($exitReason as $s_reason)
                                            @if($s_reason->exit_type == 8)
                                            <option value="{{ $s_reason->sno }}"
                                                data-comments-check="{{ $s_reason->comments_check }}">
                                                {{ $s_reason->reason_name }}
                                            </option>
                                            @endif
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="" id="transfer_comments_div" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments </label>
                                            <input type="text" class="form-control" name="transfer_comments_text"
                                                id="transfer_comments_text" value="" placeholder="Enter Comments"
                                                oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                        </div>
                                    </div>
                                        
                                    
                                
                                </div>
                            </div>
                        </div>

                        <!-- Summary -->
                        <div id="transferSummaryCard" class="mt-5"></div>
                    

                        <div class="d-flex justify-content-end my-3">
                            <button type="button" id="btnTransferStaff"  onclick="transferStaff()" class="btn btn-primary btn-lg px-10">
                                <i class="mdi mdi-transit-transfer"></i>
                                Transfer Staff
                            </button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<script>
    function open_update_staffId() {
        loadCompanyStaff(0);
    }

    // CLICK COMPANY TAB
    $(document).on("click", ".company-tab", function() {
        let companyId = $(this).data("company");
        loadCompanyStaff(companyId);
    });

    // COMMON FUNCTION TO LOAD STAFF
    function loadCompanyStaff(companyId) {

        $("#companyStaffList").html(`
        <div class="text-center py-5">
            <div class="spinner-border"></div>
            <p>Loading staff...</p>
        </div>
    `);

        $.ajax({
            url: "/get-company-staff",
            type: "GET",
            data: {
                company_id: companyId
            },
            success: function(res) {

                // RENDER STAFF TABLE HTML COMING FROM BACKEND
                $("#companyStaffList").html(res.staff_html);

                // Show Bulk Update button when list loads
                $("#bulkUpdateContainer").show();
            }
        });
    }

    // BULK UPDATE BUTTON CLICK
    $("#bulkUpdateBtn").on("click", function() {

        let updates = [];

        $("tr").each(function() {

            let sno = $(this).find(".staff-id-input").data("sno");

            if (!sno) return; // skip non-staff rows

            let staff_id = $(this).find(".staff-id-input").val();
            let timechamp_id = $(this).find(".staff-timechamp-id-input").val();

            updates.push({
                sno: sno,
                staff_id: staff_id,
                timechamp_id: timechamp_id
            });
        });

        $.ajax({
            url: "/bulk-update-staff-id",
            type: "POST",
            data: {
                _token: $("meta[name='csrf-token']").attr("content"),
                updates: updates
            },
            success: function(res) {
                toastr.success("Bulk Update Successful!");
                window.location.href = '/hr_enroll/manage_staff';
            }
        });
    });
</script>

<script>
    function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    // window.location.href = '/hr_enroll/manage_staff';
                    submitBtn.disabled = false;
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

<script>
    function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {

        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;

        let staff_image = '';
        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }
        staff_image = `{{ asset('${staff_image}') }}`;

        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle">
                                <img src="${item.staffProfile}" 
                                    alt="user-avatar"  class="w-px-40 h-px-40 rounded-circle"
                                    id="uploadedlogo" onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}' ${(item.gender == 1 ? 'user_2.png' : 'user_7.png')}"/>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label>
                                <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.staff_name}</span>
                                ${item.gender == 1 ?
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                        class="mdi mdi-face-man text-info"></i></span>`
                                 : 
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i
                                        class="mdi mdi-face-woman text-info"></i></span>`
                                }
                                
                            </label>
                            <span class="fs-8 me-1 d-block text-primary text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.nick_name || '-'}</span>
                            <div class="d-flex  fs-8" style="color:rgb(114,57,234) !important;">
                                <a href="javascript:;" class=" fs-8" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Staff Nick Name" style="color:rgb(114,57,234) !important;">
                                    ${data.staff_id || '-'}
                                </a>
                                <div class="">
                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                        data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9" style="color:rgb(114,57,234) !important;"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Mob No</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.mobile_no || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Email ID</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.email_id || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">DOB</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                ${data.dob ? formatDateCommon(data.dob) : '-'}
                                                <span 
                                                    class="badge fs-8 bg-info" 
                                                    data-bs-toggle="tooltip" 
                                                    title="${data.dob ? getNextBDayDate(data.dob).full : '-'}">
                                                    ${data.dob ? getNextBDayDate(data.dob).short : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Educational</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">
                                            ${data.education && Array.isArray(data.education) && data.education.length > 0 ? data.education : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ${data.shift_time_id == 0 ? 
                        `<span class="mdi mdi-timer-alert-outline text-danger ms-1 fs-6 cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Shift" onclick='openShiftAssign(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.shift_time_id}")'></span>`
                        :''
                        }
                    </div>
                </td>
                <td>
                    ${data.company_type == 1 ?
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold fs-7 text-truncate badge bg-label-danger d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>
                     </div>`
                    :
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>

                        <label class="fw-semibold fs-7 text-truncate badge  d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: ${item.company_base_color || ''};"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.entity_name || '-'}" >
                            ${data.entity_name || '-'}
                        </label>
                    </div>`
                    }
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column gap-1">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.department_name || '-'}">
                            ${data.department_name || '-'}
                        </label>
                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.division_name || '-'}">
                            ${data.division_name || '-'}
                        </label>
                        <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                            <span class="fs-7">${data.job_role_name || '-'}</span>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                           ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                        </label>
                        <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                           ${data.date_of_joining ? getExperienceDuration(data.date_of_joining) : '0 Day'}
                        </label>
                    </div>
                </td>
                <td align="right">
                    <label class="badge bg-success text-white fw-bold mb-2 text-nowrap">
                        <span class="mdi mdi-currency-rupee text-white fw-bold fs-8"></span>
                        <span class="fs-7">${data.basic_salary ? new Intl.NumberFormat('en-IN').format(data.basic_salary) :'-'}</span>
                    </label>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                    
                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                         ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${item.sno})">
                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i> View</span>
                            </a>`
                            :''}
                            <a href="{{ url('/hr_enroll/manage_staff/update_staff/${item.encrypted_id}')}}" class="dropdown-item">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            <a href="javascript:void(0)" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_transferModel" onclick="openTransferModel(${item.sno})">
                                <span>
                                    <i class="mdi mdi-transit-transfer fs-4 text-primary me-2"></i>
                                    Transfer Staff
                                </span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#employeePayrollModal" onclick='openProfilePayroll(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.basic_salary}","${data.casual_leave_count_per_month}")'>
                                <span><i class="mdi mdi-account-credit-card fs-4 text-black me-1"></i>Update Account</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#employeeSalaryModal"  onclick='openEmployeeSalaryModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Update Salary</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#monthlyInputModal"  onclick='openMonthlyInputModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Variable Amount</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openOTPayrollModal( ${item.sno},"${item.staff_name}"
                            )'>
                                <span>
                                    <i class="mdi mdi-clock-outline fs-4 text-black me-1"></i>
                                    OT Payroll
                                </span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openShiftAssign(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.shift_time_id}","${data.date_of_joining}","${data.shift_name || '-'}")' >
                                <span><i class="mdi mdi-clock-outline fs-4 text-black me-1"></i>Assign Shift</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openSalaryAppraisal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.salary_log_id}","${data.date_of_joining}","${data.basic_salary || '-'}")' >
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Salary Appraisal</span>
                            </a>
                            
                            <a href="javascript:;" class="dropdown-item" onclick='openSalaryMappingModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-account-credit-card fs-4 text-black me-1"></i>Salary Mapping</span>
                            </a>
                            ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_exit_staff" onclick="existStaffModal(${item.sno})">
                                <span><i class="mdi mdi-exit-to-app fs-3 text-black me-1"></i></span>
                                <span>Exit</span>
                            </a>
                             <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_test_template" >
                                <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Test Template</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_staff" onclick="confirmDelete('${item.sno}', '${item.staff_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>` : ''}
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_enroll/manage_staff?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    $('#total_staff_dash').text(res.total);

                    $('#companyStaffCards').html('');

                    res.company_counts.forEach(item => {

                        let logoPath = '';
                        if (item.company_id == 0) {
                            if (item.company_logo && item.company_logo.includes('.')) {
                                logoPath = `/logos/${item.company_logo}`;
                            }
                        } else {
                            if (item.company_logo) {
                                logoPath = `/Company_logos/${item.company_logo}`;
                            }
                        }

                        // ${logoPath ? `<img src="${logoPath}" alt="">` : ''}

                        // static company logo


                        let card = `
                            <div class="w-150px">
                                <div class="card company-card shadow-sm" style="background:${item.entity_base_color}">
                                    <div class="card-body text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.company_name || '-'}">
                                        <div class="dashboard-icon text-white">
                                            <i class="mdi mdi-account-group text-white fs-3"></i>
                                        </div>
                                        <div class="company-count">${item.total}</div>
                                        <small>${item.entity_short_name || 'EGC'}</small>

                                    </div>
                                </div>
                            </div>
                        `;

                        $('#companyStaffCards').append(card);
                    });
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    $('#total_staff_dash').text(0);
                    $('#companyStaffCards').html('');
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);
</script>

<script>
    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function departure_data_fetch_func(data) {
        let image = '';
        if (data.staff_image) {
            var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
            image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        } else if (data.cus_gender == 1 || data.cus_gender === '1') {
            image = `<img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        } else if (data.cus_gender == 2 || data.cus_gender === '2') {
            image = `<img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        }
        var html = `<div class="row mt-4 mb-3">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}"/>

                  <div class="col-lg-3 mb-3">
                      <div class="row">
                          <div class="align-items-sm-center gap-4">
                              ${image}
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9 mb-3">
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">
                              <span class="badge bg-info">${data.department_name}</span></label>
                      </div>
                  </div>
              </div>`;
        document.getElementById('staff_data_view').innerHTML = html;

    }
    departure_func(4)

    function departure_func(val) {
        // Fetch elements required for all conditions
        $('#exist_sts_change_id').val(val);
        $('#dep_reason_err').html('');
        $('#notice_end_date_err').html('');
        var reason_add = document.getElementById("reason_add");
        var date_view = document.getElementById("date_view");
        var starting_date = document.getElementById("starting_date");
        var ending_date = document.getElementById("ending_date");
        // Hide all elements initially
        reason_add.style.display = "none";
        date_view.style.display = "none";
        starting_date.style.display = "none";
        ending_date.style.display = "none";
        // Handle specific conditions based on `val`
        switch (val) {
            case 4: // Show both dates and reason
                starting_date.style.display = "block";
                ending_date.style.display = "block";
                reason_add.style.display = "block";
                $('#notice_period').prop('checked', true);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Notice Period');
                break;
            case 5: // Show reason only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', true);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Relive');
                break;
            case 6: // Show reason and date view only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', true);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Abscond');
                break;
            case 7: // Show reason only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', true);
                $('#exit_submit_butt').html('Terminate');
                break;
        }
    }

    function status_change_validation() {
        $('#exit_submit_butt').prop('disabled', true);
        var err = 0;
        var exist_sts_change_id = $('#exist_sts_change_id').val();
        if (exist_sts_change_id == 4) {

            var notice_start_date = $('#notice_start_date').val().trim();
            if (notice_start_date == '') {
                $('#notice_start_date_err').html('Notice Start date is requered..!');
                err++;
            } else {
                $('#notice_start_date_err').html('');
            }

            var notice_end_date = $('#notice_end_date').val().trim();
            if (notice_end_date == '') {
                $('#notice_end_date_err').html('Notice end date is requered..!');
                err++;
            } else {
                $('#notice_end_date_err').html('');
            }

        } else {
            var staff_last_date = $('#staff_last_date').val().trim();
            if (staff_last_date == '') {
                $('#staff_last_date_err').html('Last Attend date is requered..!');
                err++;
            } else {
                $('#staff_last_date_err').html('');
            }
        }

        var dep_reason = $('#dep_reason').val().trim();
        if (dep_reason == '') {
            $('#dep_reason_err').html('Enter Reason is requered..!');
            err++;
        } else {
            $('#dep_reason_err').html('');
        }

        if (err > 0) {
            $('#exit_submit_butt').prop('disabled', false);
            return false;
        } else {
            $('#exit_submit_butt').prop('disabled', true);
            $('#cus_drp_form').submit();
        }
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function() {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(document).ready(function() {

        // When company changes
        $('#staff_company_name').on('change', function() {
            var companyId = $(this).val();
            var entityDropdown = $('#staff_entity_name');

            // Reset dropdown
            entityDropdown.empty().append('<option value="">Select Entity</option>');

            if (companyId) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: {
                        company_id: companyId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                entityDropdown.append(
                                    $('<option></option>')
                                    .attr('value', entity.sno)
                                    .attr('data-baseurl', entity.entity_base_url)
                                    .text(entity.entity_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
        });

        // When entity changes
        $('#staff_entity_name').on('change', function() {
            $('#staff_add_btn').prop('disabled', true);
            $('#staff_data_payload').val('');
            $('#total_Staff_data').text('0');
            var entityId = $(this).val();
            const verify_key = 'egcsecret2030datagetapierp';
            var branchDropdown = $('#staff_branch_name');
            if (entityId) {
                $.ajax({
                    url: "{{ route('entity_branch_dropdown_list') }}",
                    type: "GET",
                    data: {
                        entity_id: entityId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                branchDropdown.append(
                                    $('<option></option>')
                                    .attr('value', entity.sno)
                                    .text(entity.branch_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
            var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
            if (baseurl) {
                var url = baseurl + 'api/staff_data_get';
                $.ajax({
                    url: url,
                    type: "GET",
                    data: {
                        auth_key: verify_key
                    },
                    success: function(response) {
                        console.log('response:', response);
                        if (response.status === 200 && response.data) {
                            console.log(response.data);
                            var length = response.data.length;
                            var staffData = response.data;
                            $('#total_Staff_data').text(length + ' ')
                            // TODO: handle data display or form updates here
                            if (length > 0) {
                                $('#staff_add_btn').prop('disabled', false);
                                // $('#staff_data_payload').val(JSON.stringify(staffData));
                            } else {
                                $('#staff_add_btn').prop('disabled', true);
                            }
                            staffData.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

                            staffData.map((sdata) => {
                                if (sdata.external_uuid) {
                                    sdata.alreadyExists = 1;
                                } else {
                                    sdata.alreadyExists = 0;
                                }
                            })
                            loadDataView(staffData, baseurl)
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching staff data:', error);
                    }
                });
            }
        });

    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>

<!-- status Change -->
<script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
    function confirmDelete(id, staff) {

        document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
        $('#delete_message').html(
            'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
            staff +
            '</b>');
    }

    function deleteFunc() {
        var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

        fetch('/staff_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {
                toastr.error(error);
            });
    }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

        result = result.trim();

        // Add "In" or "Ago"
        if (isFuture) {
            result = `In ${result}`;
        } else if (result !== '0 days') {
            // result += ' ago';
            result += '';
        }

        return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return {
            short: '-',
            full: '-'
        };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return {
            short: '-',
            full: '-'
        };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return {
                short: '🎉 Today',
                full: '🎉 Happy Birthday!'
            };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return {
            short: short.trim(),
            full
        };
    }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $('#mini_dashbaord').click(function() {
        $('.mini_dashboard_box').slideToggle('slow');
    });
</script>
<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');

            stateDropdown.empty().append('<option value="">Select Entity</option>');

            if (countryId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: {
                        company_id: countryId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                    'value', state.sno).text(state
                                    .entity_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });
        // division dropdown
        $('#department_fill').on('change', function() {
            var department_id = $(this).val();
            var stateDropdown = $('#division_fill');
            stateDropdown.empty().append('<option value="">Select Division</option>');

          

            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_division') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdivisionid', state.erp_division_id)
                                    .text(state.division_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Division:', error);
                    }
                });

            }
        });

        $('#division_fill').on('change', function() {
            var department_id = $(this).val();

            var jobRoleDropdown = $('#job_role_fill');

            jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

            let erp_depert = $(this).find(':selected').data('erpdivisionid');
            $('#erp_division_id').val(erp_depert);

            if (department_id) {
                // Fetch and populate states based on selected country
                // Job role dropdown
                $.ajax({
                    url: "{{ route('get_job_role') }}",
                    type: "GET",
                    data: {
                        division_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpjobroleid', state.erp_job_role_id)
                                    .text(state.job_position_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Job Role:', error);
                    }
                });
            }
        });

    })
</script>

<script>
    $('#sendMessageBtn').on('click', function(e) {
        var err = 0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');


        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();



        if (sms == 1 || email == 1 || whatsapp == 1) {
            $('#communication_err').text('');
        } else {
            $('#communication_err').text('Please Select Any One Communication.!');
            err++;
        }



        if (err == 0) {
            $('#sendMessageBtn').prop('disabled', true);
            $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/send_test_template',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        // location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                        $('#sendMessageBtn').prop('disabled', true);
                        resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                    $('#sendMessageBtn').prop('disabled', true);
                    resetButton();
                }
            });
        }

        function resetButton() {
            $('#sendMessageBtn').prop('disabled', false);
            $('#sendMessageBtn').text('Send Test Template');
            $('#sendMessageBtn .spinner-border').addClass('d-none');
        }
    });
</script>
<script>
    function send_proposal_whatsapp_func() {
        const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
        const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }
</script>

<script>
    function viewStaff(id) {
        // Show skeleton loaders before fetch
        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
            skeleton.style.display = 'block'; // Show skeleton loaders
        });

        // Hide actual data elements
        document.querySelectorAll('.view-data').forEach(element => {
            element.style.display = 'none'; // Hide actual data until it is loaded
        });

        fetch('/staff_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    let staff_image = '';
                    if (com.staff_image && com.staff_image.trim() !== '') {
                        if (com.company_type == 1) {
                            staff_image = `staff_images/Management/${com.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
                        }
                    } else {
                        staff_image = com.gender == 1 ?
                            'assets/egc_images/auth/user_2.png' :
                            'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;

                    document.getElementById('view_staff_img_sm').src = com.profile_image_url;
                    document.getElementById('view_staff_profile_image').src = com.profile_image_url;

                    document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                        skeleton.style.display = 'none'; // Hide skeleton loaders
                    });
                    document.querySelectorAll('.view-data').forEach(element => {
                        element.style.display = 'block'; // Show actual data
                    });

                    let skillsJson = safeJsonParse(com.knowledge_tag);
                    let skillsArray = safeJsonParse(skillsJson);
                    let skillNames = Array.isArray(skillsArray) ?
                        skillsArray.map(s => s.value) : [];

                    let displaySkills = skillNames.join(", ");


                    let courseTagJson = safeJsonParse(com.course_tag);
                    let courseTagArray = safeJsonParse(courseTagJson);
                    let courseNames = Array.isArray(courseTagArray) ?
                        courseTagArray.map(s => s.value) : [];

                    let displayCourseTag = courseNames.join(", ");

                    $('#view_staff_name').html(com.staff_name);
                    $('#view_staff_mobile').html(com.mobile_no);
                    $('#view_staff_email').html(com.email_id);
                    $('#view_staff_dob').html(com.dob ? formatDateCommon(com.dob) : '-');
                    $('#view_staff_gender').html(com.gender == 1 ? 'Male' : (com.gender == 2 ? 'Female' : 'Other'));
                    $('#view_staff_father_name').html(com.father_name || '-');
                    $('#view_staff_mother_name').html(com.mother_name || '-');
                    $('#view_staff_father_occup').html(com.father_occup || '-');
                    $('#view_staff_mother_occup').html(com.mother_occup || '-');
                    $('#view_staff_mother_tongue').html(com.mother_tongue || '-');
                    $('#view_staff_language_knw').html(com.language_known ? com.language_known.join(',') : '-');
                    $('#view_staff_marital_status').html(com.martial_status == 2 ? 'Unmarried' : (com.martial_status == 1 ? 'Married' : '-'));
                    $('#view_staff_has_children').html(com.has_children || '-');
                    $('#view_staff_has_siblings').html(com.has_siblings || '-');
                    $('#view_staff_hobby').html(com.hobbies ? com.hobbies.join(',') : '-');
                    $('#view_staff_descrip').html(com.description || '-');

                    /* company details */
                    $('#view_staff_company_type').html(com.company_type == 1 ? 'Mangement' : 'Buisness');
                    $('#view_staff_department').html(com.department_name || '-');
                    $('#view_staff_division').html(com.division_name || '-');
                    $('#view_staff_job_role').html(com.job_role_name || '-');

                    /* Designation  details */
                    $('#view_staff_nick_name').html(com.nick_name || '-');
                    $('#view_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');
                    $('#view_staff_salary').html(com.basic_salary ? '₹ ' + new Intl.NumberFormat('en-IN').format(com.basic_salary) : '-');
                    $('#view_staff_per_hr_cost').html(com.per_hour_cost ? '₹ ' + new Intl.NumberFormat('en-IN').format(com.per_hour_cost) : '-');
                    $('#view_staff_skill_tag').html(displaySkills || '-');

                    /* Login  details */
                    $('#view_staff_user_name').html(com.user_name || '-');
                    $('#view_staff_password').html(com.password || '-');
                    $('#view_staff_user_role').html(com.role_name || '-');

                    /* other Credential */
                    if (com.other_credential && com.other_credential.length > 0) {
                        let credentialsHTML = '';

                        com.other_credential.forEach((credential) => {
                            credentialsHTML += `
                                <h5 class="title fw-bold mt-2 text-warning">${credential.credential_name} Credentials</h5>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.user_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.password || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">
                                            <a class="text-truncate max-w-150px" href="${credential.url_link || '#'}" target="_blank">${credential.url_link ? credential.url_link : '-'}</a>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${credential.description || '-'}</label>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('otherCredentialsContainer').innerHTML = credentialsHTML;
                    } else {
                        document.getElementById('otherCredentialsContainer').innerHTML = '<p>No other credentials available.</p>';
                    }


                    if (com.contact_person_name && com.contact_person_name.length > 0) {
                        let contactPersonHTML = '';
                        const contactPersonNo = com.contact_person_no || [];
                        const relationship = com.relationship || [];

                        com.contact_person_name.forEach((contact, index) => {
                            contactPersonHTML += `
                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${contact || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${contactPersonNo[index] || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Relation ${index + 1}</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${relationship[index] || '-'}</label>
                                    </div>
                                </div>
                            `;
                        });

                        document.getElementById('contactPersonContainer').innerHTML = contactPersonHTML;
                    } else {
                        document.getElementById('contactPersonContainer').innerHTML = '';
                    }




                    $('#view_staff_permnt_address').html(com.address || '-');
                    $('#view_staff_temp_address').html(com.residential_address || '-');
                    $('#view_staff_alternate_no').html(com.alternative_no || '-');

                    /* Work Details */
                    $('#view_exp_type').html(com.exp_type == 1 ? 'Fresher' : (com.exp_type == 2 ? 'Experience' : '-'));
                    $('#view_shift_comp_count').html(com.total_company_shift || '-');
                    $('#view_total_yr_exp').html(com.total_experience || '-');

                    if (com.work_details && com.work_details.length > 0) {
                        let worksHTML = '';

                        com.work_details.forEach((work, index) => {
                            let compCount = index + 1;
                            worksHTML += `
                                <h5 class="title fw-bold mt-2 text-warning">${compCount + getOrdinalSuffix(compCount)} Company</h5>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.position || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">
                                        <span class="badge bg-primary text-white px-3 fs-7">${work.year_of_experience || '-'}</span>
                                    </label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.company_name || '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-danger">${work.salary ? '₹ '+ new Intl.NumberFormat('en-IN').format(work.salary) +' /-':'-'} </label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.start_date ? formatDateCommon(work.start_date) : '-'}</label>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="row mb-2">
                                    <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
                                    <label class="col-1 fw-semibold fs-7">:</label>
                                    <label class="col-6 fw-semibold fs-6 text-black">${work.end_date ? formatDateCommon(work.end_date) : '-'}</label>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('workDetailsContainer').innerHTML = worksHTML;
                    } else {
                        document.getElementById('workDetailsContainer').innerHTML = '<p>No Experience Details.</p>';
                    }

                    if (com.documents && com.documents.length > 0) {
                        let documentHTML = '';

                        com.documents.forEach((document, index) => {
                            let documentName = document.document_name || 'Unknown Document';

                            // Start with a Bootstrap card for each document
                            documentHTML += `
                                <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                                    <div class="card shadow-sm">
                                        <div class="card-body">
                                            <h5 class="card-title text-primary">${documentName}</h5>
                                            <div class="d-flex flex-wrap justify-content-start gap-3">
                            `;

                            // Loop through the files for each document
                            document.files.forEach((file, fileIndex) => {
                                const fileExtension = file.split('.').pop().toLowerCase();
                                let fileHTML = '';

                                // Check if the file is an image
                                if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
                                    fileHTML = `
                                    
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
                                            <img src="${file}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <span class="view-btn">
                                                    <i class="mdi mdi-eye"></i> 
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                }
                                // If the file is a document (pdf, docx, etc.)
                                else if (['pdf'].includes(fileExtension)) {
                                    fileHTML = `
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
                                        
                                            <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <span class="view-btn">
                                                    <i class="mdi mdi-eye"></i> 
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                }
                                // If file is unsupported (other types)
                                else {
                                    fileHTML = `
                                        <div class="document-thumbnail position-relative border rounded cursor-pointer" >
                                        
                                            <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
                                            <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
                                                <a href="${file}" download class="view-btn">
                                                    <i class="mdi mdi-download-circle-outline text-dark fs-3 fw-light"></i> 
                                                </a>
                                                
                                            </div>
                                        </div>
                                    `;
                                }

                                // Add the file's HTML to the document's section
                                documentHTML += fileHTML;
                            });

                            // Close the card layout and document container
                            documentHTML += `
                                        </div> 
                                    </div> 
                                </div>
                            </div> 
                            `;
                        });

                        // Insert the generated HTML into the container
                        document.getElementById('documentContainer').innerHTML = documentHTML;
                    } else {
                        document.getElementById('documentContainer').innerHTML = '<p class="text-muted">No documents available.</p>';
                    }


                    if (com.qualification && com.qualification.length > 0) {
                        let educationHTML = '';

                        com.qualification.forEach((qualification, index) => {
                            let compCount = index + 1;
                            educationHTML += `
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.qualification_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.major_name ? qualification.major_name  : (qualification.major || '-') }</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.university_name || '-'}</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                  <div class="row mb-2">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Year</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <label class="col-6 fw-semibold fs-6 text-black">${qualification.year || '-'}</label>
                                    </div>
                                </div>
                                <hr>
                            `;
                        });
                        document.getElementById('educationContainer').innerHTML = educationHTML;
                    } else {
                        document.getElementById('educationContainer').innerHTML = '<p>No Qualification Found.</p>';
                    }


                    if (com.document_checkList && com.document_checkList.length > 0) {
                        let docCheckListHTML = '';

                        com.document_checkList.forEach((checklist, index) => {
                            let compCount = index + 1;
                            docCheckListHTML += `
                                <div class="form-check mb-3">
                                    <input class="form-check-input checklist-item" type="checkbox" ${checklist.is_checked ==1 ? 'checked' :''} disabled>
                                    <label class="fw-semibold fs-6 text-black" >${checklist.document_checklist}</label>
                                </div>
                            `;
                        });
                        document.getElementById('documentCheckContainer').innerHTML = docCheckListHTML;
                    } else {
                        document.getElementById('documentCheckContainer').innerHTML = '<p>No Documents.</p>';
                    }

                    $('#view_staff_completed_course_tag').html(displayCourseTag || '-');




                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    function safeJsonParse(str) {
        try {
            return JSON.parse(str);
        } catch (e) {
            return str;
        }
    }

    function getOrdinalSuffix(number) {
        const suffixes = ["th", "st", "nd", "rd"];
        const remainder = number % 100;
        return suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    }

    function previewFile(file, doc_name) {
        const fileExtension = file.split('.').pop().toLowerCase();
        $('#filePreviewModalLabel').text(doc_name)
        const previewContainer = document.getElementById('filePreviewContent');
        previewContainer.innerHTML = ''; // Clear any previous content

        // Handle the preview based on file type
        if (['pdf', 'docx'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <iframe src="${file}" style="width: 100%; height: 500px;" frameborder="0"></iframe>
            `;
        } else if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <img src="${file}" alt="Preview Image" style="width: 100%; max-height: 500px; object-fit: contain;" />
            `;
        } else {
            previewContainer.innerHTML = `
                <p class="text-center text-muted">File format not supported for preview.</p>
            `;
        }
    }

    function loadDataView(list, baseurl) {
        let html = "";

        if (list.length === 0) {
            html += `<span class="text-center text-danger">No attendance found</span>`;
        } else {
            list.forEach(a => {
                html += `
                    <span class="list-group-item d-flex align-items-center justify-content-between mb-3 shadow-sm rounded px-3 py-2 ${a.alreadyExists == 1 ? 'bg-label-dark':'bg-label-success'} " >
                        
                        <!-- LEFT SIDE -->
                        <div class="d-flex align-items-center">
                            <img src="${a.staff_image}"
                             alt="${a.staff_name}"
                             class="rounded-circle me-3 staff-avatar"
                             width="50" height="50"
                             onerror="replaceWithInitials(this, '${a.staff_name.replace(/'/g, "\\'")}')">

                            <div>
                                <h6 class="fw-semibold mb-0">
                                    ${a.staff_name}
                                    <span class="text-primary small">(${a.nick_name})</span>
                                    ${a.alreadyExists == 1 ?
                                        ``
                                        :
                                        '<span class="badge bg-label-danger">New</span>'
                                        }
                                </h6>
                                <small class="text-muted">
                                    ${a.role_name} | ${a.department_name}
                                </small>
                            </div>
                        </div>

                        <!-- RIGHT SIDE (Created At) -->
                        <span class="badge bg-success-subtle text-success fw-semibold">
                            ${formatDateCommon(a.created_at)}
                        </span>

                    </span>
                `;
            });
        }

        document.getElementById("total_Staff_list").innerHTML = html;
    }

    function getInitials(name) {
        if (!name) return '';
        const words = name.trim().split(' ');

        return (words[0][0]).toUpperCase();
    }

    function getAvatarColor(name) {
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

    function replaceWithInitials(img, name) {
        console.log(img, name)
        const initials = getInitials(name);
        const color = getAvatarColor(name);
        console.log(name, initials)
        const div = document.createElement('div');
        div.className = `rounded-circle ${color} text-white d-flex align-items-center justify-content-center me-3 fw-bold`;
        div.style.width = '50px';
        div.style.height = '50px';
        div.innerText = initials;

        img.replaceWith(div);
    }
</script>
<script>
    function existStaffModal(id) {

        $('#exist_staff_id').val(id);

        fetch('/staff_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    let staff_image = '';
                    if (com.staff_image && com.staff_image.trim() !== '') {
                        if (com.company_type == 1) {
                            staff_image = `staff_images/Management/${com.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
                        }
                    } else {
                        staff_image = com.gender == 1 ?
                            'assets/egc_images/auth/user_2.png' :
                            'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;

                    document.getElementById('exist_staff_profile_image').src = staff_image;

                    document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                        skeleton.style.display = 'none'; // Hide skeleton loaders
                    });
                    document.querySelectorAll('.exist-data').forEach(element => {
                        element.style.display = 'block'; // Show actual data
                    });

                    $('#exist_staff_name').html(com.staff_name);
                    $('#exist_nick_name').html(com.nick_name || '-');
                    $('#exist_staff_company_name').html(com.company_type == 1 ? 'Elysium Groups' : com.company_name);
                    $('#exist_entity_name').html(com.company_type == 1 ? '-' : com.entity_name);
                    $('#exist_staff_department').html(com.department_name || '-');
                    $('#exist_staff_division').html(com.division_name || '-');
                    $('#exist_staff_job_role').html(com.job_role_name || '-');
                    $('#exist_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');

                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

<script>
    let staff_bank_company_id = 0;
    let staff_bank_id = 0;
    var existingSalaryComponents = '';
    let payrollRules = [];

    // function openProfilePayroll(id, name, mobile, email, image,salary,leave_count){

    //         staff_bank_company_id = 0;
    //         staff_bank_id = 0;
    //         $('#employee_sno').val(id);
    //         $('#payroll_staff_name').text(name);
    //         $('#casual_leave_count').val(leave_count);
    //         $('#basic_salary').val(salary);
    //         $('#payroll_staff_mobile').text(mobile);
    //         var perDaySalary = (parseFloat(salary) / 30).toFixed(2); 
    //         $('#per_day_salary').val(perDaySalary);
    //         // $('#payroll_staff_email').text(email);
    //         $('#payroll_staff_img').attr('src', image);
    //         $('.error').text('');

    //     $.get('/employee/payroll/details/' + id, function (res) {

    //         if (res.data) {
    //             Object.keys(res.data).forEach(key => {
    //                 $('[name="'+key+'"]').val(res.data[key]);
    //                 if (res.data.per_day_salary === null) {
    //                     var calculatedPerDaySalary = (parseFloat(res.data.basic_salary) / 30).toFixed(2);
    //                     $('#per_day_salary').val(calculatedPerDaySalary);
    //                 }
    //             });
    //         }else {

    //             // Clear other fields as well
    //             $('[name="bank_account_no"]').val('');
    //             $('[name="bank_name"]').val('');
    //             $('[name="ifsc_code"]').val('');
    //             $('[name="uan_no"]').val('');
    //             $('[name="esi_no"]').val('');
    //             $('[name="pan_no"]').val('');
    //             $('[name="aadhar_no"]').val('');

    //             // Optionally clear error messages
    //             $('.error').text('');
    //         }

    //     });
    // }

    function openProfilePayroll(id, name, mobile, email, image, salary, leave_count) {

        staff_bank_company_id = 0;
        staff_bank_id = 0;
        existingSalaryComponents = [];
        $('#salary_company_id').val('').change();
        $('#salary_bank_id').val('').change();
        $('#employee_sno').val(id);
        $('#payroll_staff_name').text(name);
        $('#payroll_staff_mobile').text(mobile);
        $('#casual_leave_count').val(leave_count);
        $('#basic_salary').val(salary);
        $('#payroll_staff_img').attr('src', image);

        let perDaySalary = (parseFloat(salary) / 30).toFixed(2);
        $('#per_day_salary').val(perDaySalary);

        //  loadComponents();
        salary_type_checked();
        per_day_salary_value();
        $('.error').text('');

        $.ajax({
            url: '/employee/payroll/details/' + id,
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                // =============================
                // STAFF MAIN DATA
                // =============================
                if (res.data) {

                    staff_bank_company_id = res.data.staff_bank_company_id || res.data.salary_company_id;
                    staff_bank_id = res.data.salary_bank_id || 0;

                    Object.keys(res.data).forEach(key => {

                        let el = $('[name="' + key + '"]');
                        // ❌ Skip file inputs
                        if (el.attr('type') === 'file') return;
                        //  Handle checkbox
                        if (el.attr('type') === 'checkbox') {
                            el.prop('checked', res.data[key] == 1);
                        }
                        //  Handle radio
                        else if (el.attr('type') === 'radio') {
                            $(`[name="${key}"][value="${res.data[key]}"]`).prop('checked', true);
                        }
                        //  Normal input
                        else {
                            el.val(res.data[key] ?? '');
                        }

                    });

                    // per day fallback
                    if (!res.data.per_day_salary) {
                        let calculated = (parseFloat(res.data.basic_salary) / 30).toFixed(2);
                        $('#per_day_salary').val(calculated);
                    }

                    $('#salary_date').val(res.data.salary_date).change();
                    // salary type toggle
                    if (res.data.salary_type == 2) {
                        $('#salary_bank').prop('checked', true);
                    } else {
                        $('#salary_cash').prop('checked', true);
                    }

                    salary_type_checked();
                }

                // =============================
                //  STAFF BANK DETAILS
                // =============================
                if (res.staffBank) {
                    $('#staff_bank_name').val(res.staffBank.bank_name || '');
                    $('#staff_bank_branch').val(res.staffBank.bank_branch || '');
                    $('#staff_acc_holder').val(res.staffBank.account_holder || '');
                    $('#staff_acc_no').val(res.staffBank.bank_account_no || '');
                    $('#ifsc_code').val(res.staffBank.ifsc_code || '');
                }

                // =============================
                //  STATUTORY DETAILS
                // =============================
                if (res.staffStatutory) {
                    $('[name="uan_no"]').val(res.staffStatutory.uan_no || '');
                    $('[name="esi_no"]').val(res.staffStatutory.esi_no || '');
                    $('[name="pan_no"]').val(res.staffStatutory.pan_no || '');
                    $('[name="aadhar_no"]').val(res.staffStatutory.aadhar_no || '');
                }
                // =============================
                //  COMPANY + BANK AUTO SELECT
                // =============================
                if (staff_bank_company_id) {
                    $('#salary_company_id').val(staff_bank_company_id).trigger('change');
                    salary_company_change(); // load banks
                }
            },

            error: function(xhr) {
                console.error(xhr.responseText);
                alert('Error loading payroll details');
            }
        });
    }

let companyOptions = $('#salary_company_id').html();
    function employeePayrollSubmit() {

        const form = document.getElementById("employeePayrollForm");
        const reloadPage = tableState.currentPage;

        if (!form) return;

        let formData = new FormData(form);

        // ✅ ADD SALARY COMPONENTS
        let components = collectSalaryComponents();
        formData.append('salary_components', JSON.stringify(components));
        formData.append(
            'salary_accounts',
            JSON.stringify(
                collectSalaryAccounts()
            )
        );
        formData.append(
            'is_multiple_account',
            $('[name="is_multiple_account"]:checked').val()
        );

        $('.error').text('');

        let btn = $('#savePayrollBtn');
        btn.prop('disabled', true);
        btn.find('.btn-text').addClass('d-none');
        btn.find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: '/employee/payroll/save',
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('input[name="_token"]').val()
            },

            success: function(res) {

                if (res.status) {
                    toastr.success("Updated Successfully");

                    // ✅ OPTIONAL: close modal instead reload
                    $('#employeePayrollModal').modal('hide');
                    loadThemes(reloadPage);

                    // location.reload();
                } else {
                    toastr.error(res.message || "Update failed");
                }
            },

            error: function(xhr) {

                // ✅ VALIDATION ERRORS
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;

                    $.each(errors, function(key, val) {
                        $('[data-error="' + key + '"]').text(val[0]);
                    });
                }

                toastr.error(xhr.responseJSON?.message || 'Something went wrong');
            },

            complete: function() {
                // ✅ ALWAYS RESET BUTTON
                btn.prop('disabled', false);
                btn.find('.btn-text').removeClass('d-none');
                btn.find('.spinner-border').addClass('d-none');
            }
        });
    }

    function validation_func() {

        let err = false;
        $('.error').text('');

        function setError(field, message) {
            $('[data-error="' + field + '"]').text(message);
            if (!err) {
                $('[name="' + field + '"]').focus();
            }
            err = true;
        }

        let salary_type_checked = $('[name="salary_type"]:checked').val();
        if (salary_type_checked == 2) {

            // let pay_cycle = $('[name="pay_cycle"]').val().trim();
            // let payroll_status = $('[name="payroll_status"]').val().trim();
            // let tax_regime = $('[name="tax_regime"]').val().trim();
            let bank_account_no = $('[name="staff_acc_no"]').val().trim();
            let bank_name = $('[name="staff_bank_name"]').val().trim();
            let ifsc_code = $('[name="ifsc_code"]').val().trim();
            let pan_no = $('[name="pan_no"]').val().trim();
            let aadhar_no = $('[name="aadhar_no"]').val().trim();

            // Payroll Profile
            // if (!pay_cycle) {
            //     setError('pay_cycle', 'Please select pay cycle.');
            // }

            // if (!payroll_status) {
            //     setError('payroll_status', 'Please select payroll status.');
            // }

            // if (!tax_regime) {
            //     setError('tax_regime', 'Please select tax regime.');
            // }

            // Bank Details
            if (!bank_account_no) {
                // setError('bank_account_no', 'Bank account number is required.');
            } else if (!/^[0-9]{6,20}$/.test(bank_account_no)) {
                setError('staff_acc_no', 'Enter valid bank account number.');
            }

            if (!bank_name) {
                // setError('bank_name', 'Bank name is required.');
            }

            if (!ifsc_code) {
                // setError('ifsc_code', 'IFSC code is required.');
            } else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc_code.toUpperCase())) {
                setError('ifsc_code', 'Enter valid IFSC code.');
            }

            // Statutory
            if (!pan_no) {
                // setError('pan_no', 'PAN number is required.');
            } else if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan_no.toUpperCase())) {
                setError('pan_no', 'Enter valid PAN number.');
            }

            if (aadhar_no && !/^[0-9]{12}$/.test(aadhar_no)) {
                setError('aadhar_no', 'Aadhar must be 12 digits.');
            }

        }

        // If no error → submit
        if (!err) {
            employeePayrollSubmit();
        }
    }
</script>
<script>
    function openSalaryMappingModal(employeeSno) {

        $('#mapping_employee_sno').val(employeeSno);

        $('.error').text('');

        $.get('/staff/salary-mapping/' + employeeSno, function(res) {
            let rows = '';
            res.history.forEach(h => {
                rows += `
                    <tr>
                        <td>${h.structure_name}</td>
                        <td>${h.effective_from}</td>
                        <td>${h.effective_to??''}</td>
                        <td>${h.change_reason??''}</td>
                    </tr>
                `;
            });
            $('#salaryHistoryTable').html(rows);
            $('#salaryMappingModal').modal('show');
        });

    }

    function saveSalaryMapping() {

        $('.error').text('');
        let btn = $('#saveMappingBtn');
        btn.prop('disabled', true);
        btn.find('.btn-text').addClass('d-none');
        btn.find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: '/staff/salary-mapping/save',
            method: 'POST',
            data: $('#salaryMappingForm').serialize(),
            error: function(xhr) {
                if (xhr.status == 422) {
                    $.each(xhr.responseJSON.errors, function(k, v) {
                        $('[data-error="' + k + '"]').text(v[0]);
                    });
                }
            },
            success: function(res) {
                if (res.status) {
                    toastr.success('Salary mapped successfully');
                    $('#salaryMappingModal').modal('hide');
                }
            },
            complete: function() {
                btn.prop('disabled', false);
                btn.find('.btn-text').removeClass('d-none');
                btn.find('.spinner-border').addClass('d-none');
            }

        });

    }
</script>

<script>
    function shift_change_func() {

        let shiftId = $('#shift_select').val();
        if (!shiftId) {
            $('#shiftPreview').addClass('d-none');
            return;
        }

        fetch('/get-shift-detail/' + shiftId)
            .then(res => res.json())
            .then(res => {
                if (!res.status) return;

                let html = '';
                let total = res.total_duration;

                res.shift.days.forEach(day => {
                    let hours = Math.floor(day.duration_minutes / 60);
                    let mins = day.duration_minutes % 60;
                    html += `
            <div class="d-flex justify-content-between border-bottom border-primary py-2">
                        <div>
                            <b>${formatDayName(day.day_name)}</b>
                        </div>
                        <div class="d-flex gap-1">
                            <span class="badge bg-label-info small">
                                ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
                            </span>
                            <span class="badge bg-label-primary">
                                ${hours}h ${mins}m
                            </span>
                        </div>
                    </div>
            `;
                });

                let totalHours = Math.floor(total / 60);
                let totalMins = total % 60;
                $('#shiftDays').html(html);
                $('#shiftTotalDuration').text(totalHours + 'h ' + totalMins + 'm');
                $('#shiftPreview').removeClass('d-none');
            });

    }

    // function assignShift(){
    //     let staffId=$('#assign_staff_id').val();
    //     let shiftId=$('#shift_select').val();
    //     if(!shiftId){
    //         toastr.warning('Please select shift');
    //         return;
    //     }
    //     fetch('/assign-shift',{
    //         method:'POST',
    //         headers:{
    //         'Content-Type':'application/json',
    //         'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
    //         },
    //         body:JSON.stringify({
    //             staff_id:staffId,
    //             shift_id:shiftId
    //         })
    //     })
    //     .then(res=>res.json())
    //     .then(res=>{
    //         if(res.status){
    //             toastr.success(res.message);
    //             $('#assignShiftModal').modal('hide');
    //             loadThemes(1);
    //         }
    //     });
    // }

    function assignShift() {
        let staffId = $('#assign_staff_id').val();
        let shiftId = $('#shift_select').val();
        let startDate = $('#shift_start_date').val();
        let endDate = $('#previous_end_date').val();
        let currentShift = $('#current_shift_id').val();

        if (!shiftId) {
            toastr.warning('Select shift');
            return;
        }

        fetch('/assign-shift', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                body: JSON.stringify({
                    staff_id: staffId,
                    shift_id: shiftId,
                    start_date: startDate,
                    end_date: endDate,
                    current_shift_id: currentShift
                })

            })
            .then(res => res.json())
            .then(res => {
                if (res.status) {
                    toastr.success(res.message);
                    $('#assignShiftModal').modal('hide');
                    loadThemes(1);
                } else {
                    toastr.error(res.message);
                }

            });

    }
    // function openShiftAssign(staffId,name, mobile, email, image,shift_time,date_of_joining){
    //     $('#assign_staff_id').val(staffId);

    //         $('#assign_staff_name').text(name);
    //         $('#assign_staff_mobile').text(mobile);
    //         $('#assign_staff_img').attr('src', image);
    //         if(shift_time != 0){
    //             $('#shift_select').val(shift_time).change();
    //             $('#shift_start_date').val(new Date().toISOString().split('T')[0]);
    //         }else{
    //             $('#shift_start_date').val(date_of_joining);

    //         }

    //     $('#assignShiftModal').modal('show');
    // }

    // function openShiftAssign(staffId,name,mobile,email,image,shift_time,date_of_joining,shift_name){

    //     $('#current_shift_name').val('');
    //     $('#previous_end_date').val('');
    //     $('#shift_start_date').val('');
    //     $('#shift_start_date').val('');
    //     $('#assign_staff_id').val('');
    //     $('#currentShiftBox').hide();
    //     $('#current_shift_id').val('').change();


    //     $('#assign_staff_name').text(name);
    //     $('#assign_staff_mobile').text(mobile);
    //     $('#assign_staff_img').attr('src', image);
    //     $('#current_shift_id').val(shift_time);
    //     $('#assign_staff_id').val(staffId);


    //     if(shift_time != 0){
    //         // SHOW CURRENT SHIFT CARD
    //         $('#currentShiftBox').show();
    //         $('#current_shift_name').val(shift_name);
    //         $('#previous_end_date').val(new Date().toISOString().split('T')[0]);
    //         $('#shift_start_date').val(new Date().toISOString().split('T')[0]);
    //         loadCurrentShiftDetails(shift_time);
    //     }else{
    //         // FIRST TIME ASSIGN
    //         $('#currentShiftBox').hide();
    //         $('#shift_start_date').val(date_of_joining);
    //     }
    //     $('#assignShiftModal').modal('show');

    // }

    function openShiftAssign(staffId, name, mobile, email, image, shift_time, date_of_joining, shift_name) {

        //  FULL RESET (VERY IMPORTANT)
        $('#assign_staff_id').val('');
        $('#current_shift_id').val('');
        $('#shift_select').val('').trigger('change');

        $('#current_shift_name').val('');
        $('#previous_end_date').val('');
        $('#shift_start_date').val('');

        //  CLEAR PREVIEWS
        $('#currentShiftDays').html('');
        $('#shiftDays').html('');
        $('#currentShiftTotalDuration').text('');
        $('#shiftTotalDuration').text('');

        $('#currentShiftPreview').addClass('d-none');
        $('#shiftPreview').addClass('d-none');

        $('#currentShiftBox').hide();

        //  SET STAFF DATA
        $('#assign_staff_name').text(name);
        $('#assign_staff_mobile').text(mobile);
        $('#assign_staff_img').attr('src', image);

        $('#assign_staff_id').val(staffId);
        $('#current_shift_id').val(shift_time);

        //  HANDLE SHIFT LOGIC
        if (shift_time && shift_time != 0) {

            $('#currentShiftBox').show();

            $('#current_shift_name').val(shift_name);

            let today = new Date().toISOString().split('T')[0];

            $('#previous_end_date').val(today);
            $('#shift_start_date').val(today);

            loadCurrentShiftDetails(shift_time);

        } else {

            $('#currentShiftBox').hide();

            $('#shift_start_date').val(date_of_joining);
        }

        $('#assignShiftModal').modal('show');
    }

    // function loadCurrentShiftDetails(shiftId){
    //     if(!shiftId){
    //         $('#currentShiftPreview').addClass('d-none');
    //         return;
    //     }

    //     fetch('/get-shift-detail/'+shiftId)
    //     .then(res=>res.json())
    //     .then(res=>{
    //         let html='';
    //         let total=res.total_duration;
    //         res.shift.days.forEach(day=>{
    //             let hours=Math.floor(day.duration_minutes/60);
    //             let mins=day.duration_minutes%60;
    //             html+=`
    //                 <div class="d-flex justify-content-between border-bottom border-primary py-2">
    //                     <div>
    //                         <b>${formatDayName(day.day_name)}</b>
    //                     </div>
    //                     <div class="d-flex gap-1">
    //                         <span class="badge bg-label-warning small">
    //                             ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
    //                         </span>
    //                         <span class="badge bg-label-primary">
    //                             ${hours}h ${mins}m
    //                         </span>
    //                     </div>
    //                 </div>
    //             `;
    //         });
    //         let totalHours=Math.floor(total/60);
    //         let totalMins=total%60;
    //         $('#currentShiftTotalDuration').text(totalHours+'h '+totalMins+'m');
    //         $('#currentShiftDays').html(html);
    //         $('#currentShiftPreview').removeClass('d-none');

    //     });

    // }

    let currentShiftRequest = null;

    function loadCurrentShiftDetails(shiftId) {

        if (!shiftId) {
            $('#currentShiftPreview').addClass('d-none');
            return;
        }

        currentShiftRequest = shiftId;

        fetch('/get-shift-detail/' + shiftId)
            .then(res => res.json())
            .then(res => {

                // ✅ Ignore old response
                if (currentShiftRequest != shiftId) return;

                let html = '';
                let total = res.total_duration;

                res.shift.days.forEach(day => {
                    let hours = Math.floor(day.duration_minutes / 60);
                    let mins = day.duration_minutes % 60;

                    html += `
                    <div class="d-flex justify-content-between border-bottom border-primary py-2">
                        <div><b>${formatDayName(day.day_name)}</b></div>
                        <div class="d-flex gap-1">
                            <span class="badge bg-label-warning small">
                                ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
                            </span>
                            <span class="badge bg-label-primary">
                                ${hours}h ${mins}m
                            </span>
                        </div>
                    </div>
                `;
                });

                let totalHours = Math.floor(total / 60);
                let totalMins = total % 60;

                $('#currentShiftTotalDuration').text(totalHours + 'h ' + totalMins + 'm');
                $('#currentShiftDays').html(html);
                $('#currentShiftPreview').removeClass('d-none');
            });
    }

    function formatTime(timeString) {
        if (!timeString) return "-";

        const parts = timeString.split(":");
        if (parts.length < 2) return "-";

        let hours = parseInt(parts[0]);
        let minutes = parts[1];
        let seconds = parts[2] || "00";

        let ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12;

        return `${hours.toString().padStart(2,"0")}:${minutes} ${ampm}`;
    }

    function formatDayName(day) {
        const days = {
            mon: "Monday",
            tue: "Tuesday",
            wed: "Wednesday",
            thu: "Thursday",
            fri: "Friday",
            sat: "Saturday",
            sun: "Sunday"
        };

        return days[day?.toLowerCase()] || day;
    }

    // $(document).ready(function () {
    //         $('.common_datepicker').datepicker({
    //             todayHighlight: true,
    //             autoclose: true,
    //             format: 'dd-M-yyyy'
    //         });
    //     });
</script>

<script>
    function calculatePerHourCost() {

        let salary = parseFloat($('#basic_salary').val()) || 0;

        let workingHours = 8; // ✅ You can change this (or make dynamic)

        if (salary <= 0) {
            $('#per_hr_cost').val('0.00');
            return;
        }

        let perHour = salary / (30 * workingHours);

        perHour = Math.round(perHour * 100) / 100;

        $('#per_hr_cost').val(perHour.toFixed(2));
    }


    // function per_day_salary_value(){
    //     var salary =parseFloat($('#basic_salary').val());
    //     if (isNaN(salary) || salary <= 0) {
    //         $('#per_day_salary').val('0.0');
    //         return;
    //     }
    //     let perDaySalary = salary / 30;
    //     perDaySalary = Math.round(perDaySalary * 100) / 100;
    //     $('#per_day_salary').val(perDaySalary.toFixed(1));
    // }

    function per_day_salary_value() {

        let salary = parseFloat($('#basic_salary').val());

        if (isNaN(salary) || salary <= 0) {
            $('#per_day_salary').val('0.00');
            $('#per_hr_cost').val('0.00');
            return;
        }

        // ✅ Per Day
        let perDaySalary = salary / 30;
        perDaySalary = Math.round(perDaySalary * 100) / 100;
        $('#per_day_salary').val(perDaySalary.toFixed(1));

        // ✅ Per Hour (8 hrs default)
        let workingHours = 8;
        let perHour = salary / (30 * workingHours);
        perHour = Math.round(perHour * 100) / 100;
        $('#per_hr_cost').val(perHour.toFixed(1));
    }



    function salary_type_checked() {
        if ($('#salary_bank').is(':checked')) {
            $('.salary_bank_div').removeClass('d-none');
        } else {
            $('.salary_bank_div').addClass('d-none');
            resetSalaryCalculation();
        }


    }

    function resetSalaryCalculation() {
        console.log("reset salary")

        // Uncheck all components
        $('.comp-toggle').prop('checked', false);

        // Hide all component boxes
        $('[id^="comp_"]').addClass('d-none');
        $('[id^="card_comp_"]').addClass('bg-label-light');

        // Reset component values (optional: set to 0)
        // $('.comp-value').val(0);

        // Reset totals
        $('#total_earn').text('0.00');
        $('#total_ded').text('0.00');
        $('#net_salary').text('0.00');

        // Recalculate with clean state
        calculateSalary();
    }

    function salary_company_change() {


        let id = $('#salary_company_id').val();

        if (!id) return;

        $.ajax({
            url: '/company-banks/' + id,
            type: 'GET',
            success: function(res) {

                let options = '<option value="">Select Bank</option>';

                res.data.forEach(bank => {
                    options += `<option value="${bank.sno}" ${staff_bank_id == bank.sno ? 'selected' : ''}>
                            ${bank.bank_name} - ${bank.account_number}
                        </option>`;
                });

                $('#salary_bank_id').html(options);
            }
        });
    }

    function renderComponentCard(c) {

        let existing = existingSalaryComponents ? existingSalaryComponents.find(e => e.component_id == c.sno) : '';
        let isChecked = existing && existing.is_active == 1;
        let amount = existing ? existing.amount : (c.default_value || 0);
        let calcType = existing ? existing.calculation_type : c.calculation_type;

        return `
            <div class="card border-0 shadow-sm mb-2 p-2 ${isChecked ? '' : 'bg-label-light'}" id="card_comp_${c.sno}">

                <div class="d-flex justify-content-between">

                    <div>
                        <div class="fw-semibold">${c.component_name}</div>
                        <small class="text-muted">${c.calculation_type}</small>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input comp-toggle"
                            type="checkbox"
                            ${isChecked ? 'checked' : ''}
                            data-id="${c.sno}"
                            data-type="${c.type}"
                            data-rule="${c.rule_type}">
                    </div>

                </div>

                
                <div class="comp-box mt-2 ${isChecked ? '' : 'd-none'}" id="comp_${c.sno}">

                    <div class="d-flex gap-2">

                        <select class="form-select calc-type select3" data-id="${c.sno}">
                            <option value="fixed" ${calcType == 'fixed' ? 'selected' : ''}>₹</option>
                            <option value="percentage" ${calcType == 'percentage' ? 'selected' : ''}>%</option>
                        </select>

                        <input type="number"
                            class="form-control comp-value"
                            data-id="${c.sno}"
                            value="${amount}">

                    </div>

                </div>

            </div>
            `;
    }

    function loadComponents() {
        $.ajax({
            url: '/salary-components',
            type: 'GET',
            success: function(res) {

                let earn = '';
                let ded = '';

                res.forEach(c => {
                    let card = renderComponentCard(c);
                    if (c.type === 'earning') earn += card;
                    else ded += card;
                });

                $('#earnings_area').html(earn);
                $('#deductions_area').html(ded);

                calculateSalary();
            },
            error: function() {
                toastr.error('Failed to load salary components');
            }
        });

    }



    $(document).on('change', '.comp-toggle', function() {

        let id = $(this).data('id');
        let box = $('#comp_' + id);
        let card = $('#card_comp_' + id);

        if ($(this).is(':checked')) {
            box.removeClass('d-none').hide().slideDown(150);
            card.removeClass('bg-label-light');
        } else {
            box.slideUp(150, function() {
                $(this).addClass('d-none');
                card.addClass('bg-label-light');
            });
        }

        calculateSalary();

    });

    function calculateSalary() {
        console.log("calenter")

        let basic = parseFloat($('#basic_salary').val()) || 0;

        applyPayrollRules(basic);

        let earnings = basic;
        let deductions = 0;

        $('.comp-toggle:checked').each(function() {

            let id = $(this).data('id');
            let type = $(this).data('type');

            let val = parseFloat($(`.comp-value[data-id="${id}"]`).val()) || 0;
            let calc = $(`.calc-type[data-id="${id}"]`).val();

            if (calc === 'percentage') {
                val = (basic * val) / 100;
            }

            if (type === 'earning') earnings += val;
            else deductions += val;

        });

        $('#total_earn').text(earnings.toFixed(2));
        $('#total_ded').text(deductions.toFixed(2));
        $('#net_salary').text((earnings - deductions).toFixed(2));

    }

    $(document).on('input change', '.comp-value, .calc-type, #basic_salary', function() {
        calculateSalary();
    });

    $('#basic_salary').on('input', function() {

        let salary = parseFloat($(this).val()) || 0;

        let perDay = salary / 30;

        $('#per_day_salary').val(perDay.toFixed(2));

    });

    function collectSalaryComponents() {

        let components = [];

        $('.comp-toggle').each(function() {

            let id = $(this).data('id');

            components.push({
                component_id: id,
                amount: $(`.comp-value[data-id="${id}"]`).val() || 0,
                calc_type: $(`.calc-type[data-id="${id}"]`).val(),
                is_active: $(this).is(':checked') ? 1 : 0
            });

        });

        return components;
    }

    function applyPayrollRules(basic) {

        payrollRules.forEach(rule => {

            if (rule.rule_type === 'esi') {

                let limit = rule.condition.salary_limit || 0;

                $('.comp-toggle').each(function() {

                    let compRule = $(this).data('rule');
                    let id = $(this).data('id');

                    if (compRule === 'esi') {

                        if (basic > limit) {
                            $(this).prop('checked', false).prop('disabled', true);
                            $('#comp_' + id).addClass('d-none');
                            $('#card_comp_' + id).addClass('bg-label-light');
                        } else {
                            $(this).prop('disabled', false);
                            //  $('#card_comp_'+id).removeClass('bg-label-light');
                        }

                    }

                });

            }
        });

    }
</script>

<!-- Salary Appraisal -->
<script>
    function openSalaryAppraisal(staffId, name, mobile, email, image, salary_log_id, date_of_joining, shift_name) {

        //  FULL RESET (VERY IMPORTANT)
        $('#salary_staff_id').val('');
        $('#current_salary_id').val('');

        $('#current_salary_name').val('');
        $('#previous_salary_end_date').val('');
        $('#salary_start_date').val('');


        $('#currentsalaryPreview').addClass('d-none');
        $('#salaryPreview').addClass('d-none');

        $('#currentsalaryBox').hide();

        //  SET STAFF DATA
        $('#assign_staff_name').text(name);
        $('#assign_staff_mobile').text(mobile);
        $('#assign_staff_img').attr('src', image);

        $('#assign_staff_id').val(staffId);
        $('#current_shift_id').val(salary_log_id);

        //  HANDLE SHIFT LOGIC
        if (salary_log_id && salary_log_id != 0) {

            $('#currentsalaryBox').show();

            $('#current_salary_name').val(shift_name);

            let today = new Date().toISOString().split('T')[0];

            $('#previous_salary_end_date').val(today);
            $('#salary_start_date').val(today);

            // loadCurrentShiftDetails(salary_log_id);

        } else {

            $('#currentShiftBox').hide();

            $('#shift_start_date').val(date_of_joining);
        }

        $('#salaryAppraisalModal').modal('show');
    }
</script>
<script>
    function openEmployeeSalaryModal(employeeId, name, mobile, email, image) {

        $('#salary_staff_name').text(name);
        $('#salary_staff_mobile').text(mobile);
        $('#salary_staff_img').attr('src', image);

        $('#employeeSalaryForm')[0].reset();

        $('#employee_salary_components').html('');

        $('#employee_sno').val(employeeId);

        $('#employee_structure_sno').val('');

        /*
        |--------------------------------------------------------------------------
        | RESET SUMMARY
        |--------------------------------------------------------------------------
        */

        $('#emp_total_earnings').html('₹ 0.00');

        $('#emp_total_deductions').html('₹ 0.00');

        $('#emp_net_salary').html('₹ 0.00');

        $('#emp_ctc').html('₹ 0.00');

        $.ajax({

            url: '/payroll/employee-structure/get/' + employeeId,

            type: 'GET',

            success: function(response) {

                let data = response.data;

                /*
                |--------------------------------------------------------------------------
                | EMPLOYEE INFO
                |--------------------------------------------------------------------------
                */

                $('#employee_name').val(
                    data.employee.employee_name || ''
                );

                $('#employee_code').val(
                    data.employee.employee_code || ''
                );

                /*
                |--------------------------------------------------------------------------
                | IF STRUCTURE EXISTS
                |--------------------------------------------------------------------------
                */

                if (data.structure) {

                    $('#employee_structure_sno').val(
                        data.structure.sno
                    );

                    $('#payroll_template_sno').val(
                        data.structure.payroll_template_sno
                    ).trigger('change');

                    $('#employee_gross_salary').val(
                        data.structure.gross_salary
                    );

                    $('#effective_from').val(
                        data.structure.effective_from
                    );

                    $('#revision_reason').val(
                        data.structure.revision_reason
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | COMPONENT DETAILS
                    |--------------------------------------------------------------------------
                    */

                    if (
                        data.details &&
                        data.details.length > 0
                    ) {

                        data.details.forEach(detail => {

                            appendEmployeeComponent(detail);

                        });
                    }

                } else {
                    $('#payroll_template_sno').val('').trigger('change');
                    $('#employee_gross_salary').val(
                        data.employee.gross_salary || 0
                    );
                    $('#effective_from').val('');
                    $('#revision_reason').val('');
                    $('#employee_salary_components').html(`

                        <div class="alert alert-warning rounded-4 border-0">

                            <div class="d-flex align-items-center">

                                <i class="mdi mdi-alert-circle-outline fs-2 me-3"></i>

                                <div>

                                    <div class="fw-bold">
                                        No Salary Structure Found
                                    </div>

                                    <small>
                                        Create employee salary structure by selecting template.
                                    </small>

                                </div>

                            </div>

                        </div>

                    `);
                }

                calculateEmployeeSalarySummary();

                $('#employeeSalaryModal').modal('show');
            },

            error: function(xhr) {

                toastr.error(

                    xhr.responseJSON?.message ||

                    'Unable to load employee structure'
                );
            }
        });
    }
</script>
<script>
    function appendEmployeeComponent(detail) {
        let grossSalary = parseFloat( $('#employee_gross_salary').val()) || 0;
        let calculationType =detail.calculation_type || '';
        let percentage = parseFloat( detail.percentage_value ||detail.percentage || 0);
        let fixedAmount = parseFloat(detail.amount ||detail.fixed_amount || 0);
        let amount = parseFloat( detail.calculated_amount || 0);

        if (calculationType === 'percentage') {
            amount = (grossSalary * percentage) / 100;
        } else if (calculationType === 'fixed') {
            amount = fixedAmount;
        }

        let amountReadonly = calculationType === 'manual_input' ? '' : 'readonly';
        let badge = '';
        if (detail.component_type === 'earning') {
            badge =
                '<span class="badge bg-success">Earning</span>';
        } else if (
            detail.component_type === 'deduction'
        ) {
            badge =
                '<span class="badge bg-danger">Deduction</span>';
        } else {
            badge = '<span class="badge bg-primary">Employer</span>';
        }
        let html = `
            <div class="salary-component-row card border-0 shadow-sm rounded-4 mb-3"
                data-calculation-type="${calculationType}">

                <div class="card-body">

                    <div class="row align-items-end">

                        <div class="col-lg-4">
                            <label class="form-label fw-semibold">
                                Component
                            </label>

                            <input type="text"
                                class="form-control"
                                value="${detail.component_name}"
                                readonly>

                            <input type="hidden"
                                class="payroll_component_sno"
                                value="${detail.payroll_component_sno || detail.component_sno}">

                            <input type="hidden"
                                class="payroll_rule_sno"
                                value="${detail.payroll_rule_sno || ''}">
                        </div>

                        <div class="col-lg-2">

                            <label class="form-label fw-semibold">
                                Type
                            </label>

                            <div class="mt-2">${badge}</div>

                            <input type="hidden"
                                class="component_type"
                                value="${detail.component_type}">

                            <input type="hidden"
                                class="component_code"
                                value="${detail.component_code || ''}">

                            <input type="hidden"
                                class="rule_expression"
                                value="${detail.rule_expression || ''}">
                        </div>

                        <div class="col-lg-2">

                            <label class="form-label fw-semibold">
                                %
                            </label>

                            <input type="number"
                                class="form-control percentage_value"
                                value="${percentage}"
                                readonly>
                        </div>

                        <div class="col-lg-4">

                            <label class="form-label fw-semibold">
                                Amount
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    ₹
                                </span>

                                <input type="number"
                                    class="form-control calculated_amount"
                                    value="${parseFloat(amount).toFixed(2)}"
                                    ${amountReadonly}>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
            `;
        $('#employee_salary_components').append(html);
        calculateEmployeeSalarySummary();
    }
</script>
<script>
    $(document).on('keyup change', '#employee_gross_salary', function() {
        let grossSalary = parseFloat($(this).val()) || 0;

        $('.salary-component-row').each(function() {
            let row = $(this);
            let calculationType = row.data('calculation-type');

            if (calculationType === 'percentage') {
                let percentage = parseFloat(row.find('.percentage_value').val()) || 0;
                let amount = (grossSalary * percentage) / 100;

                row.find('.calculated_amount').val(amount.toFixed(2));
            }
        });
        calculateEmployeeSalarySummary();
    });

    function calculateEmployeeSalarySummary() {

        let grossSalary =
            parseFloat($('#employee_gross_salary').val()) || 0;

        let earnings = 0;
        let deductions = 0;
        let employerContribution = 0;

        let basic = 0;
        let da = 0;

        /*
        |--------------------------------------------------------------------------
        | STEP 1
        | CALCULATE EARNINGS FIRST
        |--------------------------------------------------------------------------
        */

        $('.salary-component-row').each(function () {

            let row = $(this);

            let type =
                row.find('.component_type').val();

            if (type !== 'earning') {
                return;
            }

            let calculationType =
                row.data('calculation-type');

            let percentage =
                parseFloat(
                    row.find('.percentage_value').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.calculated_amount').val()
                ) || 0;

            /*
            |--------------------------------------------------------------------------
            | PERCENTAGE
            |--------------------------------------------------------------------------
            */

            if (calculationType === 'percentage') {

                amount =
                    (grossSalary * percentage) / 100;
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {

                amount =
                    parseFloat(
                        row.find('.calculated_amount').val()
                    ) || 0;
            }

            row.find('.calculated_amount')
                .val(parseFloat(amount).toFixed(2));

            /*
            |--------------------------------------------------------------------------
            | BASIC + DA
            |--------------------------------------------------------------------------
            */

            let componentCode =
                row.find('.component_code').val();

            if (componentCode === 'BASIC') {
                basic = amount;
            }

            if (componentCode === 'DA') {
                da = amount;
            }

            earnings += amount;
        });

        /*
        |--------------------------------------------------------------------------
        | STEP 2
        | DEDUCTIONS + EMPLOYER CONTRIBUTIONS
        |--------------------------------------------------------------------------
        */

        $('.salary-component-row').each(function () {

            let row = $(this);

            let type =
                row.find('.component_type').val();

            if (
                type !== 'deduction' &&
                type !== 'employer_contribution'
            ) {
                return;
            }

            let componentCode =
                row.find('.component_code').val();

            let calculationType =
                row.data('calculation-type');

            let percentage =
                parseFloat(
                    row.find('.percentage_value').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.calculated_amount').val()
                ) || 0;

            /*
            |--------------------------------------------------------------------------
            | PF
            |--------------------------------------------------------------------------
            */

            if (
                componentCode === 'PF' &&
                calculationType !== 'fixed'
            ) {

                let pfBase = basic + da;

                amount =
                    pfBase > 15000
                        ? 1800
                        : (pfBase * 0.12);
            }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYER PF
            |--------------------------------------------------------------------------
            */

            else if (
                componentCode === 'EMPLOYER_PF' &&
                calculationType !== 'fixed'
            ) {

                let pfBase = basic + da;

                amount =
                    pfBase > 15000
                        ? 1800
                        : (pfBase * 0.12);
            }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYEE ESI
            |--------------------------------------------------------------------------
            */

            else if (componentCode === 'ESI') {
                let esiBase = basic + da;
                if (esiBase > 21000) {
                    amount = 0;
                }else if (calculationType === 'fixed') {
                    amount = parseFloat( row.find('.calculated_amount').val()) || 0;
                }else {
                amount = esiBase * 0.0075;
            }
        }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYER ESI
            |--------------------------------------------------------------------------
            */
            else if (componentCode === 'EMPLOYER_ESI') {
                let esiBase = basic + da;
                if (esiBase > 21000) {
                    amount = 0;
                }else if (calculationType === 'fixed') {
                    amount = parseFloat( row.find('.calculated_amount').val()) || 0;
                }else {
                    amount = esiBase * 0.0325;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | NORMAL PERCENTAGE
            |--------------------------------------------------------------------------
            */

            else if (calculationType === 'percentage') {

                amount =
                    (grossSalary * percentage) / 100;
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {
                if (componentCode === 'PT') {

                    amount =
                        grossSalary <= 10000
                            ? 140
                            : 208;
                }else{
                    amount =
                    parseFloat(
                        row.find('.calculated_amount').val()
                    ) || 0;
                }
                
            }

            row.find('.calculated_amount')
                .val(parseFloat(amount).toFixed(2));

            /*
            |--------------------------------------------------------------------------
            | TOTALS
            |--------------------------------------------------------------------------
            */

            if (type === 'deduction') {
                deductions += amount;
            }

            if (type === 'employer_contribution') {
                employerContribution += amount;
            }
        });

        /*
        |--------------------------------------------------------------------------
        | FINAL SUMMARY
        |--------------------------------------------------------------------------
        */

        let netSalary =
            earnings - deductions;

        let ctc =
            earnings + employerContribution;

        $('#emp_total_earnings').html(
            '₹ ' +
            earnings.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_total_deductions').html(
            '₹ ' +
            deductions.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_employer_contribution').html(
            '₹ ' +
            employerContribution.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_net_salary').html(
            '₹ ' +
            netSalary.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_ctc').html(
            '₹ ' +
            ctc.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );
    }

    $(document).on('change', '#payroll_template_sno', function() {
        let templateId = $(this).val();
        $('#employee_salary_components').html('');
        if (templateId == '') {
            return;
        }
        $.ajax({
            url: '/payroll/template/components/' +
                templateId,
            type: 'GET',
            success: function(response) {
                let details = response.data.details;
                if (details.length > 0) {
                    details.forEach(detail => {
                        appendEmployeeComponent(detail);
                    });
                    calculateEmployeeSalarySummary();
                } else {
                    $('#employee_salary_components')
                        .html(`
                            <div class="alert alert-warning rounded-4">
                                No components found in template
                            </div>

                        `);
                }
            },
            error: function(xhr) {
                toastr.error(
                    xhr.responseJSON?.message ||
                    'Unable to load template components'
                );
            }
        });
    });
</script>
<script>
    function saveEmployeeSalaryStructure() {
        let employeeSno = $('#employee_sno').val();
        let payrollTemplateSno = $('#payroll_template_sno').val();
        let grossSalary = $('#employee_gross_salary').val();
        let effectiveFrom = $('#effective_from').val();
        let revisionReason = $('#revision_reason').val();
        if (employeeSno == '') {
            toastr.error('Employee not found');
            return;
        }
        if (grossSalary == '') {
            toastr.error('Gross salary required');
            return;
        }
        if (effectiveFrom == '') {
            toastr.error('Effective date required');
            return;
        }

        let details = [];
        $('.salary-component-row').each(function(index) {
            let row = $(this);
            let componentSno = row.find('.payroll_component_sno').val();
            let componentType = row.find('.component_type').val();
            let calculationType = row.data('calculation-type');
            let percentageValue = parseFloat(row.find('.percentage_value').val()) || 0;
            let calculatedAmount = parseFloat(row.find('.calculated_amount').val()) || 0;
            details.push({

                payroll_component_sno: componentSno,

                payroll_rule_sno: row.find('.payroll_rule_sno').val(),

                component_type: componentType,

                calculation_type: calculationType,

                percentage_value: percentageValue,

                calculated_amount: calculatedAmount,

                fixed_amount: calculatedAmount,

                include_in_ctc: 1,

                include_in_gross: componentType === 'earning' ? 1 : 0,

                include_in_payslip: 1,

                display_order: index + 1
            });
        });
        if (details.length == 0) {
            toastr.error(
                'Please add salary components'
            );
            return;
        }
        let btn = $('.save-employee-salary-btn');
        btn.prop('disabled', true);
        btn.html(` <span class="spinner-border spinner-border-sm me-2"></span> Saving...`);

        let payload = {
            _token: $('meta[name="csrf-token"]').attr('content'),
            employee_sno: employeeSno,
            payroll_template_sno: payrollTemplateSno,
            gross_salary: grossSalary,
            effective_from: effectiveFrom,
            revision_reason: revisionReason,
            details: details
        };

        $.ajax({
            url: '/payroll/employee-structure/save',
            type: 'POST',
            data: payload,
            success: function(response) {
                toastr.success(response.message);
                $('#employeeSalaryModal').modal('hide');
                if (typeof loadThemes === 'function') {
                    loadThemes(1);
                }
                if (typeof loadStaff === 'function') {
                    loadStaff(1);
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        toastr.error(value[0]);
                    });
                } else {
                    toastr.error(xhr.responseJSON?.message || 'Failed to save salary structure');
                }
            },
            complete: function() {
                btn.prop('disabled', false);
                btn.html(`<i class="mdi mdi-content-save-outline me-1"></i> Save Salary Structure`);
            }
        });
    }
</script>
<!-- variable Amount -->
<script>
    function addMonthlyInputRow(data = null) {
        let html = `
        <div class="monthly-input-row card border rounded-4 mb-3">

            <div class="card-body">

                <div class="row align-items-end">

                    <div class="col-lg-3">

                        <label class="form-label fw-semibold">
                            Component
                        </label>

                        <select class="form-select monthly_component">

                            <option value="">
                                Select Component
                            </option>

                            @foreach($components as $component)

                                <option value="{{ $component->sno }}">

                                    {{ $component->component_name }}

                                </option>

                            @endforeach

                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Type
                        </label>

                        <select class="form-select input_type">

                            <option value="earning">
                                Earning
                            </option>

                            <option value="deduction">
                                Deduction
                            </option>

                            <option value="reimbursement">
                                Reimbursement
                            </option>

                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Qty
                        </label>

                        <input type="number"
                            class="form-control quantity"
                            value="1">

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Rate
                        </label>

                        <input type="number"
                            class="form-control rate"
                            value="0">

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Amount
                        </label>

                        <input type="number"
                            class="form-control amount"
                            value="0">

                    </div>

                    <div class="col-lg-1">

                        <button type="button"
                            class="btn btn-danger remove-monthly-row">

                            <i class="mdi mdi-trash-can-outline"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>
        `;

        $('#monthly_input_rows').append(html);

        let row = $('.monthly-input-row').last();

        if (data) {

            row.find('.monthly_component')
                .val(data.payroll_component_sno);

            row.find('.input_type')
                .val(data.input_type);

            row.find('.quantity')
                .val(data.quantity);

            row.find('.rate')
                .val(data.rate);

            row.find('.amount')
                .val(data.amount);
        }
    }
</script>
<script>
    function openMonthlyInputModal(
        employeeId,
        name,
        mobile,
        email,
        image
    ) {

        $('#monthlyInputForm')[0].reset();

        $('#monthly_employee_sno')
            .val(employeeId);

        $('#variable_staff_name')
            .text(name);

        $('#variable_staff_mobile')
            .text(mobile);

        $('#variable_staff_img')
            .attr('src', image);

        $('#variable_alert').html('');

        /*
        |--------------------------------------------------------------------------
        | DEFAULT
        |--------------------------------------------------------------------------
        */

        $('#variable_from_month')
            .prop('disabled', false);

        $('#variable_from_month')
            .datepicker('update', '');

        $.ajax({

            url: '/payroll/variable-amount/get/' +
                employeeId,

            type: 'GET',

            success: function(response) {

                /*
                |--------------------------------------------------------------------------
                | ACTIVE VARIABLE EXISTS
                |--------------------------------------------------------------------------
                */

                if (
                    response.status &&
                    response.data
                ) {

                    let data = response.data;

                    $('#variable_amount')
                        .val(data.amount);

                    $('#remarks')
                        .val(data.remarks);

                    /*
                    |--------------------------------------------------------------------------
                    | DO NOT CHANGE EFFECTIVE MONTH
                    |--------------------------------------------------------------------------
                    */

                    $('#variable_from_month')
                        .val('');

                    $('#variable_from_month')
                        .prop('disabled', true);

                    /*
                    |--------------------------------------------------------------------------
                    | ALERT
                    |--------------------------------------------------------------------------
                    */

                    $('#variable_alert').html(`

                        <div class="alert alert-success rounded-4 border-0">

                            <div class="d-flex align-items-center">

                                <i class="mdi mdi-check-circle fs-2 me-3"></i>

                                <div>

                                    <div class="fw-bold">
                                        Active Variable Amount Found
                                    </div>

                                    <small>
                                        Valid Till :
                                        ${moment(data.end_month)
                                            .format('MMM YYYY')}
                                    </small>

                                </div>

                            </div>

                        </div>

                    `);
                }

                /*
                |--------------------------------------------------------------------------
                | NO ACTIVE VARIABLE
                |--------------------------------------------------------------------------
                */
                else {

                    $('#variable_from_month')
                        .prop('disabled', false);

                    $('#variable_alert').html(`

                        <div class="alert alert-warning rounded-4 border-0">

                            <div class="d-flex align-items-center">

                                <i class="mdi mdi-alert-circle fs-2 me-3"></i>

                                <div>

                                    <div class="fw-bold">
                                        No Active Variable Amount
                                    </div>

                                    <small>
                                        HR can create new variable amount.
                                    </small>

                                </div>

                            </div>

                        </div>

                    `);
                }

                $('#monthlyInputModal')
                    .modal('show');
            },

            error: function() {

                toastr.error(
                    'Unable to fetch variable amount'
                );
            }
        });
    }
</script>

<script>
    function saveVariableAmount() {

        $.ajax({

            url: '/payroll/variable-amount/save',

            type: 'POST',

            data: {

                _token: $('meta[name="csrf-token"]').attr('content'),

                employee_sno: $('#monthly_employee_sno').val(),

                payroll_component_sno: $('#payroll_variable_component_sno').val(),

                amount: $('#variable_amount').val(),

                start_month: $('#variable_from_month').val(),

                remarks: $('#remarks').val()
            },

            success: function(response) {

                toastr.success(response.message);

                $('#monthlyInputModal')
                    .modal('hide');
            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Save failed'
                );
            }
        });
    }
</script>
<script>

</script>
<script>
    function openBulkSalaryModal() {

        $('#bulkSalaryModal').modal('show');

        $('#bulk_salary_preview_body').html('');

        $('#bulk_total_staff').html('0 Staff');
    }

    function previewBulkSalaryEmployees() {

        $.ajax({

            url: '/payroll/bulk/preview',

            type: 'GET',

            success: function(response) {

                let rows = '';

                let total = 0;

                response.data.forEach(item => {

                    total++;

                    let newTemplate =
                        item.salary_type == 1
                        ? $('#bulk_template_type_1 option:selected').text()
                        : $('#bulk_template_type_2 option:selected').text();

                    rows += `
                    <tr>

                        <td>
                            <strong>${item.staff_name}</strong>
                            <br>
                            <small>${item.staff_id}</small>
                        </td>

                        <td>
                            ${
                                item.salary_type == 1
                                ? '<span class="badge bg-success">CASH</span>'
                                : '<span class="badge bg-primary">BANK</span>'
                            }
                        </td>

                        <td>
                            ${item.current_template ?? 'No Structure'}
                        </td>

                        <td>
                            ${item.effective_from ?? '-'}
                        </td>

                        <td>
                            ${item.effective_to ?? 'Current'}
                        </td>

                        <td>
                            <span class="text-success fw-bold">
                                ${newTemplate}
                            </span>
                        </td>

                        <td>
                            ${$('#bulk_effective_from').val()}
                        </td>

                    </tr>
                    `;
                });

                $('#bulk_salary_preview_body').html(rows);

                $('#bulk_total_staff')
                    .html(total + ' Staff');

            },

            error: function() {

                toastr.error('Failed to load employees');

            }

        });

    }

    function saveBulkSalaryStructure() {

        let payload = {

            _token: $('meta[name="csrf-token"]').attr('content'),

            template_type_1: $('#bulk_template_type_1').val(),

            template_type_2: $('#bulk_template_type_2').val(),

            effective_from: $('#bulk_effective_from').val(),

            revision_reason: $('#bulk_revision_reason').val()

        };

        let btn = $('#bulk_salary_save_btn');

        btn.prop('disabled', true);

        btn.html(`
        <span class="spinner-border spinner-border-sm"></span>
        Processing...
    `);

        $.ajax({

            url: '/payroll/bulk/save',

            type: 'POST',

            data: payload,

            success: function(response) {

                toastr.success(response.message);

                $('#bulkSalaryModal').modal('hide');

            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Failed'
                );

            },

            complete: function() {

                btn.prop('disabled', false);

                btn.html(`
                <i class="mdi mdi-content-save"></i>
                Apply Bulk Salary Structure
            `);

            }

        });

    }
</script>

<script>
    function openOTPayrollModal(
        employeeId,
        name
    ) {
        $('#ot_monthly_employee_sno').val(employeeId);
        $('#ot_staff_name').html(name);
        $('#ot_table_body').html('');
        $('#ot_summary').html('');
        $('#otPayrollModal').modal('show');
        loadOTDetails();
    }
</script>
<script>
    function loadOTDetails() {
        let employeeId = $('#ot_monthly_employee_sno').val();

        let month = $('#ot_month').val();

        $('#ot_table_body').html(`
            <tr>
                <td colspan="11" class="text-center">
                <div class="spinner-border text-primary">
                </div>
                <p class="mt-2">
                Loading OT Details...
                </p>
                </td>
            </tr>
        `);

        $.ajax({
            url: '/payroll/ot/details',
            type: 'GET',
            data: {
                employee_sno: employeeId,
                month: month
            },
            success: function(response) {
                let rows = '';
                let totalAmount = 0;
                let totalHours = 0;
                response.data.forEach(item => {
                    totalAmount += parseFloat(item.ot_amount);
                    totalHours += parseFloat(item.ot_hours);
                    rows += `

                    <tr class="ot-row">

                        <td>

                            ${item.date}

                            <input
                                type="hidden"
                                class="attendance_date"
                                value="${item.date}">

                        </td>

                        <td>

                            <span class="badge bg-dark">

                                ${item.day}

                            </span>

                        </td>

                        <td>

                            <span class="badge

                                ${item.attendance_type == 'OT'
                                    ? 'bg-danger'
                                    : 'bg-success'}">

                                ${item.attendance_type}

                            </span>

                        </td>

                        <td>

                            ${item.shift_time ?? '-'}

                        </td>

                        <td>

                            ${item.actual_in ?? '-'}

                        </td>

                        <td>

                            ${item.actual_out ?? '-'}

                        </td>

                        <td>

                            ${item.worked_hours
                                ? formatHours(item.worked_hours)
                                : '-'}

                        </td>

                        <td>

                            <strong class="text-primary">

                                ${formatHours(item.ot_hours)}

                            </strong>

                            <input
                                type="hidden"
                                class="ot_hours"
                                value="${item.ot_hours}">

                        </td>

                        <td>

                            ₹ ${Number(item.ot_rate).toFixed(2)}

                        </td>

                        <td>

                            <input
                                type="number"
                                class="form-control ot_amount"
                                value="${item.ot_amount}"
                                step="0.01">

                        </td>

                        <td>

                            <input
                                type="text"
                                class="form-control remarks"
                                value="${item.remarks ?? ''}">

                        </td>

                    </tr>

                    `;

                    $('#ot_table_body').html(rows);
                })
                $('#total_ot_hours').html(formatHours(totalHours));

                $('#total_ot_days').html(response.data.length);

                $('#overall_ot_amount').html( totalAmount.toFixed(2));

                $('#department_name').html(response.department_name ?? '-');

                if(response.data.length == 0)
                {
                    $('#ot_table_body').html(`

                    <tr>

                        <td colspan="11"
                            class="text-center text-muted">

                            No OT records found

                        </td>

                    </tr>

                    `);

                    return;
                }
            } 
        });
    }
</script>
<script>
    function saveOTPayroll() {

        $('#btnSaveOT')
        .prop('disabled', true)
        .html(
            '<span class="spinner-border spinner-border-sm"></span> Saving...'
        );

        let rows = [];
        $('#ot_table_body tr').each(function() {
            rows.push({
                attendance_date:
                    $(this)
                        .find('.attendance_date')
                        .val(),
                ot_hours:
                    $(this)
                        .find('.ot_hours')
                        .val(),
                ot_amount:
                    $(this)
                        .find('.ot_amount')
                        .val(),
                remarks:
                    $(this)
                        .find('.remarks')
                        .val()
            });
        });
        $.ajax({
            url: '/payroll/ot/save',
            type: 'POST',
            data: {
                _token:$('meta[name="csrf-token"]').attr('content'),
                employee_sno: $('#ot_monthly_employee_sno').val(),
                payroll_month:$('#ot_month').val(),
                rows: rows
            },
            success: function(response) {
                toastr.success(response.message);
                $('#otPayrollModal').modal('hide');
                $('#btnSaveOT')
                .prop('disabled', false)
                .html('Save OT Payroll');
                
            },
            error: function(xhr) {
                $('#btnSaveOT')
                .prop('disabled', false)
                .html('Save OT Payroll');
                toastr.error(
                    xhr.responseJSON?.message ||
                    'Save failed'
                );
            }
        });
    }
</script>
<script>
function formatHours(hours) {
    let totalMinutes = Math.round(hours * 60);
    let hrs = Math.floor(totalMinutes / 60);
    let mins = totalMinutes % 60;
    let result = '';
    if (hrs > 0) {
        result += hrs + ' hr ';
    }
    if (mins > 0) {
        result += mins + ' mins';
    }
    return result.trim();
}
</script>
<script>

    $(document).on(
    'change',
    '.ot_amount',
    function(){

        $(this)
        .closest('tr')
        .addClass('table-warning');

    });

function calculateTotalOTAmount()
{
    let total = 0;
    $('.ot_amount').each(function(){
        total += parseFloat(
            $(this).val()
        ) || 0;

    });
    $('#overall_ot_amount')
        .html(total.toFixed(2));
}

$(document).on(
'keyup change',
'.ot_amount',
calculateTotalOTAmount
);

</script>

<script>
    function openTransferModel(staffSno)
    {
        $('#transfer_staff_sno').val(staffSno);

        $('#transferSummaryCard').html('');
        window.currentTransferData = null;

        $.ajax({
            url: '/staff/get-transfer-data',
            type: 'GET',
            data: {
                staff_sno: staffSno
            },

            beforeSend: function () {

                $('#staffTransferProfile').html(`
                    <div class="">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-md-2 text-center">
                                    <div class="skeleton-transfer skeleton-circle-transfer mx-auto"></div>
                                </div>
                                <div class="col-md-10">
                                    <div class="skeleton-transfer skeleton-title-transfer"></div>
                                    <div class="skeleton-transfer skeleton-badge-transfer mb-4"></div>
                                    <div class="row mt-4">
                                        ${Array(6).fill(`
                                            <div class="col-md-4 mb-3">
                                                <div class="border rounded p-3">
                                                    <div class="skeleton-transfer skeleton-text-transfer w-50 mb-2"></div>
                                                    <div class="skeleton-transfer skeleton-text-transfer"></div>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `);

            },

            success: function (res)
            {
                renderTransferStaffProfile(res);
                toggleDivs();

                window.currentTransferData = res;
            
            }
        });
    }

    function renderTransferStaffProfile(data)
    {
        $('#staffTransferProfile').html(`
            <div class="">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-2 text-center">
                            <img src="${data.profile_image_url}" class="rounded-circle border" width="110" height="110">
                        </div>
                        <div class="col-md-10">
                            <span class="fs-5 fw-bold text-dark">
                                ${data.staff_name}
                            </span>
                            <span class="badge bg-primary">
                                ${data.staff_id}
                            </span>
                            <div class="row mt-4">
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Company</small>
                                        <h6>
                                            ${data.company_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Entity</small>
                                        <h6>
                                            ${data.entity_name}
                                        </h6>
                                    </div>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Branch</small>
                                        <h6>
                                            ${data.branch_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Department</small>
                                        <h6>
                                            ${data.department_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Division</small>
                                        <h6>
                                            ${data.division_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Job Role</small>
                                        <h6>
                                            ${data.job_role_name}
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
    }

    function triggerTransferPreview()
    {
        setTimeout(function(){

            generateTransferSummary();

        },200);
    }

    // $(document).on(
    //     'change',
    //     '.transfer-field',
    //     function () {

    //         console.log('field changed');

    //         triggerTransferPreview();
    //     }
    // );

    function generateTransferSummary()
    {
        let oldData = window.currentTransferData;
        let company = $('#transfer_company option:selected').val() ? $('#transfer_company option:selected').text() : '-';
        let entity = $('#transfer_entity option:selected').val() ? $('#transfer_entity option:selected').text() : '-';
        let branch = $('#transfer_branch option:selected').val() ?  $('#transfer_branch option:selected').text() : '-';
        let department =$('#transfer_department option:selected').val() ? $('#transfer_department option:selected').text() : '-';
        let division =$('#transfer_division option:selected').val()  ? $('#transfer_division option:selected').text() : '-';
        let jobRole =$('#transfer_job_role option:selected').val() ? $('#transfer_job_role option:selected').text() : '-';
        let role =$('#transfer_role option:selected').val() ? $('#transfer_role option:selected').text() : '-';

        $('#transferSummaryCard').html(`
            <div class="card border-warning shadow">
                <div class="card-header bg-warning">
                    <h4 class="mb-0 text-dark fw-bold">
                        Transfer Summary
                    </h4>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="text-danger">
                                Current Details
                            </h4>
                            <hr>
                            <p>
                                <b>Company :</b>
                                ${oldData.company_name}
                            </p>
                            <p>
                                <b>Entity :</b>
                                ${oldData.entity_name}
                            </p>
                            <p>
                                <b>Branch :</b>
                                ${oldData.branch_name}
                            </p>
                            <p>
                                <b>Department :</b>
                                ${oldData.department_name}
                            </p>
                            <p>
                                <b>Division :</b>
                                ${oldData.division_name}
                            </p>
                            <p>
                                <b>Job Role :</b>
                                ${oldData.job_role_name}
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h4 class="text-success">
                                Transfer To
                            </h4>
                            <hr>
                            <p><b>Company :</b> ${company}</p>
                            <p><b>Entity :</b> ${entity}</p>
                            <p><b>Branch :</b> ${branch}</p>
                            <p><b>Department :</b> ${department}</p>
                            <p><b>Division :</b> ${division}</p>
                            <p><b>Job Role :</b> ${jobRole}</p>
                            <p><b>User Role :</b> ${role}</p>

                        </div>
                    </div>
                </div>
            </div>

        `);

        
    }

    function transferStaff()
    {
        let btn = $('#btnTransferStaff');
        btn.prop('disabled', true);
        const reloadPage = tableState.currentPage;
        let validate = false;
        let company_type = 1;
        let company_id = 0;
        let entity_id = 0;
        let branch_id = 0;

        if($("#transfer_business").is(":checked")){
            company_type = 2;
            company_id = $('#transfer_company').val();
            if(!company_id){
                validate =true;
                toastr.error('Company is Required');
                btn.prop('disabled', false);
                return false;
            }
            entity_id =$('#transfer_entity').val();
            if(!entity_id){
                validate =true;
                toastr.error('Entity is Required');
                btn.prop('disabled', false);
                return false;
            }
            branch_id =$('#transfer_branch').val();
            if(!branch_id){
                    validate =true;
                    toastr.error('Branch is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        }

        let department_id =$('#transfer_department').val();
        if(!department_id){
                    validate =true;
                    toastr.error('Department is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let division_id =$('#transfer_division').val();
        if(!division_id){
                    validate =true;
                    toastr.error('Division is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let job_role_id =$('#transfer_job_role').val();
        if(!division_id){
                    validate =true;
                    toastr.error('Job Role is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let role_id =$('#transfer_role').val();
        if(!role_id){
            validate =true;
            toastr.error('User Role is Required');
                btn.prop('disabled', false);
            return false;
        }

        $.ajax({
            url: '/staff/transfer',
            type: 'POST',
            data: {
                _token:$('meta[name="csrf-token"]').attr('content'),
                staff_sno: $('#transfer_staff_sno').val(),
                company_type:company_type,
                company_id:company_id ,
                entity_id: entity_id,
                branch_id: branch_id,
                department_id:department_id,
                division_id: division_id,
                job_role_id: job_role_id,
                role_id:role_id,
                reason_id: $('#transfer_reason').val(),
                reason_comment: $('#transfer_comments_text').val()
            },
            success: function(res)
            {
                if(res.status)
                {
                    toastr.success(res.message);
                    $('#kt_modal_staff_transferModel').modal('hide');
                    loadThemes(reloadPage);
                }
                else
                {
                    toastr.error(res.message);
                }
            },
            complete:function()
            {
                btn.prop('disabled', false);
            }
        });
    }
</script>
<script>
    function toggleInputField_tranfer(value) {

        var leaveCommentsDiv = document.getElementById('transfer_comments_div');
        var selectedOption = document.querySelector('#transfer_reason option:nth-child(' + (document.getElementById(
            'transfer_reason').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (commentsCheck == '1') {
            leaveCommentsDiv.style.display = 'block';
        } else {
            leaveCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>
     $(document).ready(function() {
            // Business dropdown
            $('#transfer_company').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#transfer_entity');
                var branchDropdown = $('#transfer_branch');
                var departmentDropdown = $('#transfer_department');
                var divisionDropdown = $('#transfer_division');
                var jobroleDropdown = $('#transfer_job_role');
                var userroleDropdown = $('#transfer_role');

                stateDropdown.empty().append('<option value="">Select Entity</option>');
                branchDropdown.empty().append('<option value="">Select Branch</option>');
                departmentDropdown.empty().append('<option value="">Select Department</option>');
                divisionDropdown.empty().append('<option value="">Select Division</option>');
                jobroleDropdown.empty().append('<option value="">Select Job Role</option>');
                userroleDropdown.empty().append('<option value="">Select User Role</option>');
                if (countryId) {
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
                triggerTransferPreview()
            });
            // depart list
            $('#transfer_entity').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#transfer_department');
                var branchDropdown = $('#transfer_branch');
                var roleDropdown = $('#transfer_role');

                branchDropdown.empty().append('<option value="">Select Branch</option>');
                stateDropdown.empty().append('<option value="">Select Department</option>');
                roleDropdown.empty().append('<option value="">Select User Role</option>');

                if (entity_id) {
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('entity_branch_dropdown_list') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    branchDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.branch_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('user_role_by_entity') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    roleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.role_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Role:', error);
                        }
                    });

                }

                 triggerTransferPreview()
            });
            
            // division dropdown
             $('#transfer_department').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#transfer_division');
                var jobroleDropdown = $('#transfer_job_role');
                stateDropdown.empty().append('<option value="">Select Division</option>');
                jobroleDropdown.empty().append('<option value="">Select Job Role</option>');
               

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
                 triggerTransferPreview()
             });

              $('#transfer_division').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#transfer_job_role');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

               
                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
                 triggerTransferPreview()
             });          
            
    });

    function toggleDivs() {
        if ($("#transfer_management").is(":checked")) {
            $(".business_div").hide();
             var entity_id = 0;
                var stateDropdown = $('#transfer_department');
                var roleDropdown = $('#transfer_role');

               
                stateDropdown.empty().append('<option value="">Select Department</option>');
                roleDropdown.empty().append('<option value="">Select User Role</option>');

      
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('user_role_by_entity') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    roleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.role_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Role:', error);
                        }
                    });
             triggerTransferPreview()
                
        } else if ($("#transfer_business").is(":checked")) {
            $(".business_div").show();
             triggerTransferPreview()
        }
    }
</script>

<script>
    function accountTypeChange()
{
    let type =
        $('[name="is_multiple_account"]:checked').val();

    if(type == 1)
    {
        $('#multipleAccountDiv')
            .removeClass('d-none');

        $('.singleSalaryDiv')
            .addClass('d-none');
    }
    else
    {
        $('#multipleAccountDiv')
            .addClass('d-none');

        $('.singleSalaryDiv')
            .removeClass('d-none');
    }
}

function addSalaryAccountRow(data = null)
{
    let row = `
    <tr>

        <td>
            <input
              type="radio"
              name="primary_account"
              class="primary-account"
              value="">
        </td>

        <td>
            <select
                class="form-select company-id">

                ${companyOptions}
            </select>
        </td>

        <td>
            <select
                class="form-select bank-id">

            </select>
        </td>

        <td>
            <input
                type="number"
                class="form-control gross-salary"
                value="0">

        </td>

        <td>
            <input
                type="text"
                class="form-control per-day"
                readonly>

        </td>

        <td>
            <input
                type="text"
                class="form-control per-hour"
                readonly>

        </td>

        <td>
            <input
                type="checkbox"
                class="is-payslip">
        </td>

        <td>

            <button
                class="btn btn-danger btn-sm"
                onclick="$(this).closest('tr').remove(); calculateTotals();">

                X

            </button>

        </td>

    </tr>
    `;

    $('#salaryAccountBody').append(row);
}


$(document).on(
'input',
'.gross-salary',
function()
{
    let salary =
        parseFloat($(this).val()) || 0;

    let perDay =
        salary / 30;

    let perHour =
        salary / (30 * 8);

    let row =
        $(this).closest('tr');

    row.find('.per-day')
        .val(perDay.toFixed(2));

    row.find('.per-hour')
        .val(perHour.toFixed(2));

    calculateTotals();
});


function calculateTotals()
{
    let totalSalary = 0;
    let totalPerDay = 0;
    let totalPerHour = 0;

    $('.gross-salary').each(function()
    {
        totalSalary +=
            parseFloat($(this).val()) || 0;
    });

    $('.per-day').each(function()
    {
        totalPerDay +=
            parseFloat($(this).val()) || 0;
    });

    $('.per-hour').each(function()
    {
        totalPerHour +=
            parseFloat($(this).val()) || 0;
    });

    $('#basic_salary')
        .val(totalSalary.toFixed(2));

    $('#per_day_salary')
        .val(totalPerDay.toFixed(2));

    $('#per_hr_cost')
        .val(totalPerHour.toFixed(2));
}

function collectSalaryAccounts()
{
    let accounts = [];

    $('#salaryAccountBody tr').each(function()
    {
        accounts.push({

            salary_company_id:
                $(this).find('.company-id').val(),

            salary_bank_id:
                $(this).find('.bank-id').val(),

            gross_salary:
                $(this).find('.gross-salary').val(),

            per_day_salary:
                $(this).find('.per-day').val(),

            per_hour_cost:
                $(this).find('.per-hour').val(),

            is_primary:
                $(this)
                .find('.primary-account')
                .is(':checked') ? 1 : 0,

            is_payslip:
                $(this)
                .find('.is-payslip')
                .is(':checked') ? 1 : 0
        });
    });

    return accounts;
}
</script>
@endsection