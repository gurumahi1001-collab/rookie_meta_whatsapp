@extends('layouts/layoutMaster')

@section('title', 'Manage Staff')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
$auth_role_id = auth()->user()->role_id ;
@endphp
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
     $module_name = 'HR Management';
     $submenu_name = 'HR Enroll & General';
     $last_name = 'Manage Staff';
   

    
    
    if(auth()->user()->hasPermission($module_name , $submenu_name , $last_name, 'List')){
        $recent_activity = 1;
    }else{
       $recent_activity = 0;
    }
@endphp
<style>

    /* ==========================================================
       MODAL
    ========================================================== */
    :root{
         --erp-primary:#B12B21;
        --erp-primary-dark:#8F1D16;
        --erp-secondary:#F5A623;

        --erp-bg:#F7F7F9;
        --erp-card:#FFFFFF;

        --erp-text:#2F3542;
        --erp-text-light:#6B7280;

        --erp-border:#E8DDD2;
        --erp-border-light:#F2EAE2;

        --erp-light:#FFF7EE;
        --erp-light-2:#FFF2E0;

        --erp-shadow-sm:0 2px 8px rgba(177,43,33,.05);
        --erp-shadow:0 6px 18px rgba(177,43,33,.08);
        --erp-shadow-lg:0 15px 35px rgba(177,43,33,.12);
    }
    .staff-profile-modal {
        border: 0;
        overflow: hidden;
        border-radius: 16px;
        background: var(--erp-bg);
        box-shadow:
            0 18px 45px rgba(177,43,33,.10),
            0 6px 20px rgba(0,0,0,.06);
        position: relative;
    }
    #kt_modal_view_staff .modal-dialog {
        max-width: 1380px;
    }
    #kt_modal_view_staff .modal-content {
        min-height: 82vh;
        max-height: 94vh;
    }
    /* ==== HEADER ==== */
    .staff-profile-header {
        position: relative;
        background:#FFF8EF;
        border-bottom: 1px solid  var(--erp-border);
    }
    .staff-header-bg{
        /* position:absolute;
        inset:0 0 auto 0;
        height:6px;
        background:linear-gradient(
            90deg,
            var(--erp-primary),
            var(--erp-secondary)
        ); */
    }
    .staff-profile-header-content {
        padding: 28px 32px 22px;
    }
    .staff-modal-close {
        position: absolute;
        top: 18px;
        right: 18px;
        width: 36px;
        height: 36px;
        border: 0;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f1f5f9;
        color: #475569;
        font-size: 21px;
        transition: .2s ease;
        z-index: 5;
    }
    .staff-modal-close:hover {
        background: #E6D8CC;
        color: #0f172a;
        transform: rotate(90deg);
    }

    /* ==== PROFILE AVATAR ==== */
    .staff-profile-avatar {
        width: 92px;
        height: 92px;
        padding: 4px;
        border-radius: 24px;
        background: linear-gradient(
            135deg,
            var(--erp-primary),
            var(--erp-secondary)
        );
        box-shadow:
            0 10px 30px rgba(0,0,0,.08),
            0 2px 8px rgba(0,0,0,.04);
    }

    .staff-profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: fill;
        border-radius: 20px;
        border: 3px solid #ffffff;
        background: #ffffff;
    }

    .staff-status-indicator {
        position: absolute;
        width: 17px;
        height: 17px;
        right: -2px;
        bottom: 5px;
        border-radius: 50%;
        border: 3px solid #ffffff;
    }

    /* ==========================================================
       PROFILE HEADER TEXT
    ========================================================== */

    .staff-profile-name {
        font-size: 1.55rem;
        font-weight: 700;
        color: #111827;
        letter-spacing: -.02em;
    }

    .staff-profile-position {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        color: #64748b;
        font-size: .9rem;
        font-weight: 500;
    }

    .staff-dot-separator {
        width: 4px;
        height: 4px;
        background: #94a3b8;
        border-radius: 50%;
    }

    .staff-meta-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        border-radius: 8px;
        background: #f1f5f9;
        color: #475569;
        font-size: .75rem;
        font-weight: 600;
    }

    .staff-meta-badge i {
        font-size: 15px;
        color:var(--erp-primary);
    }

    /* ==========================================================
       HEADER ACTIONS
    ========================================================== */

    .staff-header-actions {
        display: flex;
        align-items: center;
        gap: 12px;
        padding-right: 42px;
    }

    .staff-profile-completion-card {
        padding: 10px 14px;
        border:1px solid var(--erp-border);
        box-shadow:var(--erp-shadow-sm);
        border-radius: 12px;
        background: #ffffff;
    }

    .staff-completion-circle {
        --progress: 0;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        position: relative;
        background:conic-gradient(
        var(--erp-primary) calc(var(--progress) * 1%),
        #ECECEC 0
        );
    }

    .staff-completion-circle::before {
        content: '';
        position: absolute;
        width: 38px;
        height: 38px;
        background: #ffffff;
        border-radius: 50%;
    }

    .staff-completion-circle span {
        position: relative;
        z-index: 1;
        font-size: .68rem;
        font-weight: 700;
        color:var(--erp-primary);
    }

    /* ==========================================================
       QUICK INFO ROW
    ========================================================== */

    .staff-quick-info-row {
        margin-top: 22px;
        padding-top: 18px;
        border-top: 1px solid var(--erp-border-light);
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
    }

    .staff-quick-info {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
        padding: 10px 12px;
        border-radius: 10px;
        background: #FFFDFB;
    }

    .staff-quick-icon {
        width: 34px;
        height: 34px;
        border-radius: 9px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: 18px;
    }

    .staff-quick-info span:first-child {
        display: block;
        margin-bottom: 2px;
        font-size: .81rem;
        font-weight: 600;
        color: #94a3b8;
    }

    .staff-quick-value {
        display: block;
        color: #334155;
        font-size: .78rem;
        font-weight: 600;
        text-decoration: none;
    }

    a.staff-quick-value:hover {
        color:var(--erp-primary);
    }


    /* ==========================================================
       NAVIGATION
    ========================================================== */
    .staff-profile-navigation {
        position: relative;
        z-index: 3;
        background: #ffffff;
        border-bottom: 1px solid  var(--erp-border);
    }
    .staff-tabs-scroll {
        overflow-x: auto;
        overflow-y: hidden;
        scrollbar-width: thin;
    }
    .staff-profile-tabs {
        flex-wrap: nowrap;
        min-width: max-content;
        padding: 0 25px;
    }

    .staff-profile-tabs .nav-link {
        position: relative;
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 15px 13px;
        border: 0;
        border-radius: 0;
        background: transparent;
        color: #64748b;
        font-size: .78rem;
        font-weight: 600;
        white-space: nowrap;
        transition: .2s ease;
    }

    .staff-profile-tabs .nav-link i {
        font-size: 17px;
    }

    .staff-profile-tabs .nav-link:hover {
        color:var(--erp-primary);
    }

    .staff-profile-tabs .nav-link.active {
        color:var(--erp-primary);
        background: transparent;
    }

    .staff-profile-tabs .nav-link.active::after {
        content: '';
        position: absolute;
        height: 3px;
        left: 10px;
        right: 10px;
        bottom: 0;
        border-radius: 4px 4px 0 0;
        background:var(--erp-primary);
    }

    .staff-tab-count {
        min-width: 19px;
        padding: 3px 5px;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: .62rem;
    }

    /* ==========================================================
       BODY
    ========================================================== */
    .staff-profile-body {
        padding: 25px 28px 32px;
        background: var(--erp-bg);
        overflow-x: hidden;
    }

    /* ==========================================================
       SECTION CARDS
    ========================================================== */

    .staff-section-card {
        background: #ffffff;
        border: 1px solid  var(--erp-border);
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(15, 23, 42, .025);
    }

    .staff-section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        padding: 17px 20px;
        border-bottom: 1px solid var(--erp-border-light);
    }

    .staff-section-header h5 {
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0;
        color: #1e293b;
        font-size: .93rem;
        font-weight: 700;
    }

    .staff-section-header h5 i {
        color:var(--erp-primary);
        font-size: 19px;
    }

    .staff-section-header p {
        margin: 4px 0 0;
        color: #94a3b8;
        font-size: .72rem;
    }

    .staff-section-body {
        padding: 20px;
    }


    /* ==========================================================
       INFO ITEMS
    ========================================================== */

    .staff-info-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
        min-height: 56px;
        padding: 10px 13px;
        border-radius: 9px;
        background: #FFF8EF;
        transition: .2s ease;
    }

    .staff-info-item:hover {
        background: #f1f5f9;
    }

    .staff-info-label {
        color: #94a3b8;
        font-size: .68rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: .03em;
    }

    .staff-info-value {
        color: #334155;
        font-size: .82rem;
        font-weight: 600;
        word-break: break-word;
    }

    .staff-description {
        color: #475569;
        line-height: 1.7;
        font-size: .82rem;
    }


    /* ==========================================================
       SUB SECTIONS
    ========================================================== */

    .staff-inner-divider {
        height: 1px;
        margin: 24px 0;
        background: var(--erp-border-light);
    }

    .staff-subsection-title {
        display: flex;
        align-items: center;
        gap: 7px;
        margin-bottom: 14px;
        color: #334155;
        font-size: .82rem;
        font-weight: 700;
    }

    .staff-subsection-title i {
       color:var(--erp-primary);
        font-size: 18px;
    }


    /* ==========================================================
       CONTACT
    ========================================================== */

    .staff-contact-line {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px dashed #E6D8CC;
    }

    .staff-contact-line:last-child {
        border-bottom: 0;
    }

    .staff-contact-icon {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        border-radius: 10px;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: 18px;
    }

    .staff-contact-line span {
        display: block;
        color: #94a3b8;
        font-size: .67rem;
        font-weight: 600;
    }

    .staff-contact-line strong {
        display: block;
        margin-top: 2px;
        color: #334155;
        font-size: .78rem;
        font-weight: 600;
    }

    /* ==========================================================
       ADDRESS
    ========================================================== */

    .staff-address-card {
        display: flex;
        gap: 14px;
        padding: 15px;
        border: 1px solid var(--erp-border-light);
        border-radius: 10px;
        background: #FFF8EF;
    }

    .staff-address-icon {
        width: 38px;
        height: 38px;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: 19px;
    }

    .staff-address-card span {
        color: #94a3b8;
        font-size: .68rem;
        font-weight: 600;
        text-transform: uppercase;
    }

    .staff-address-card p {
        margin: 5px 0 0;
        color: #475569;
        font-size: .8rem;
        line-height: 1.6;
    }


    /* ==========================================================
       SALARY
    ========================================================== */

    .staff-salary-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 0;
        border-bottom: 1px dashed #E6D8CC;
    }
    .staff-salary-item:last-child {
        border-bottom: 0;
    }
    .staff-salary-item span {
        color: #64748b;
        font-size: .75rem;
        font-weight: 500;
    }
    .staff-salary-item strong {
        color: #0F8B3A;
        font-size: .9rem;
        font-weight: 700;
    }

    /* ==========================================================
       SECURITY
    ========================================================== */
    .staff-security-notice {
        display: flex;
        gap: 12px;
        padding: 14px;
        border: 1px solid #fde68a;
        border-radius: 10px;
        background: #fffbeb;
    }

    .staff-security-notice > i {
        color: #d97706;
        font-size: 22px;
    }
    .staff-security-notice strong {
        color: #92400e;
        font-size: .78rem;
    }

    .staff-security-notice p {
        margin: 3px 0 0;
        color: #a16207;
        font-size: .68rem;
    }

    /* ==========================================================
       TIMELINE
    ========================================================== */

    .staff-timeline {
        position: relative;
    }

    .staff-timeline-item {
        position: relative;
        padding-left: 35px;
        padding-bottom: 25px;
    }

    .staff-timeline-item:last-child {
        padding-bottom: 0;
    }

    .staff-timeline-item::before {
        content: '';
        position: absolute;
        left: 10px;
        top: 20px;
        bottom: -5px;
        width: 2px;
        background: #E6D8CC;
    }

    .staff-timeline-item:last-child::before {
        display: none;
    }

    .staff-timeline-dot {
        position: absolute;
        left: 3px;
        top: 4px;
        width: 16px;
        height: 16px;
        border: 4px solid #FFF2E0;
        border-radius: 50%;
        color:var(--erp-primary);
    }

    .staff-timeline-card {
        padding: 15px;
        border: 1px solid  var(--erp-border);
        border-radius: 10px;
        background: #ffffff;
    }


    /* ==========================================================
       EMPTY STATE
    ========================================================== */

    .staff-empty-state {
        padding: 35px 20px;
        text-align: center;
    }

    .staff-empty-state i {
        display: block;
        margin-bottom: 10px;
        color: #cbd5e1;
        font-size: 42px;
    }

    .staff-empty-state h6 {
        margin-bottom: 4px;
        color: #475569;
        font-size: .85rem;
        font-weight: 700;
    }

    .staff-empty-state p {
        margin: 0;
        color: #94a3b8;
        font-size: .72rem;
    }


    /* ==========================================================
       CHECKLIST
    ========================================================== */

    .staff-checklist-progress {
        color: #64748b;
        font-size: .72rem;
        font-weight: 600;
    }

    .staff-checklist-progressbar {
        height: 7px;
        background: #E6D8CC;
        border-radius: 10px;
    }

    .staff-checklist-progressbar .progress-bar {
        border-radius: 10px;
        background: linear-gradient(
            90deg,
            var(--erp-primary),
            var(--erp-secondary)
        );

        transition: width .5s ease;
    }


    /* ==========================================================
       FOOTER
    ========================================================== */

    .staff-profile-footer {
        display: flex;
        align-items: center;
        justify-content: end;
        padding: 14px 25px;
        border-top: 1px solid  var(--erp-border);
        background: #ffffff;
    }


    /* ==========================================================
       LOADING OVERLAY
    ========================================================== */

    .staff-loading-overlay {
        position: absolute;
        inset: 0;
        z-index: 100;
        display: flex;
        align-items: center;
        justify-content: center;
       background:rgba(255,248,240,.94);
        backdrop-filter: blur(3px);
    }

    .staff-loading-content {
        text-align: center;
    }


    /* ==========================================================
       ERROR STATE
    ========================================================== */

    .staff-error-state {
        position: absolute;
        inset: 0;
        z-index: 110;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #ffffff;
    }

    .staff-error-icon {
        width: 72px;
        height: 72px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #fff1f2;
        color: #e11d48;
        font-size: 38px;
    }


    /* ==========================================================
       SKELETON
    ========================================================== */

    .staff-skeleton {
        position: relative;
        overflow: hidden;
        border-radius: 6px;
        background: #F3ECE5;
    }

    .staff-skeleton::after {
        content: '';
        position: absolute;
        inset: 0;
        transform: translateX(-100%);
        background: linear-gradient(
            90deg,
            transparent,
            rgba(255,255,255,.65),
            transparent
        );
        animation: staffSkeletonShimmer 1.3s infinite;
    }

    .sk-name {
        width: 220px;
        height: 24px;
    }

    .sk-position {
        width: 165px;
        height: 14px;
    }

    .sk-badge {
        width: 85px;
        height: 25px;
    }

    @keyframes staffSkeletonShimmer {
        100% {
            transform: translateX(100%);
        }
    }


    /* ==========================================================
       RESPONSIVE
    ========================================================== */

    @media (max-width: 1199.98px) {
        #kt_modal_view_staff .modal-dialog {
            max-width: 100%;
            margin: 0;
        }
        #kt_modal_view_staff .modal-content {
            min-height: 100vh;
            max-height: 100vh;
            border-radius: 0;
        }
    }


    @media (max-width: 991.98px) {
        .staff-profile-header-content {
            padding: 25px 20px 18px;
        }
        .staff-header-actions {
            width: 100%;
            padding-right: 0;
        }
        .staff-profile-completion-card {
            flex: 1;
        }
        .staff-quick-info-row {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        .staff-profile-body {
            padding: 20px;
        }
    }


    @media (max-width: 575.98px) {
        .staff-profile-avatar {
            width: 72px;
            height: 72px;
            border-radius: 19px;
        }

        .staff-profile-avatar img {
            border-radius: 16px;
        }

        .staff-profile-name {
            font-size: 1.2rem;
        }

        .staff-meta-badge {
            font-size: .68rem;
        }

        .staff-quick-info-row {
            grid-template-columns: 1fr;
        }

        .staff-profile-tabs {
            padding: 0 10px;
        }

        .staff-profile-tabs .nav-link {
            padding: 13px 10px;
        }

        .staff-profile-body {
            padding: 15px;
        }

        .staff-section-header {
            padding: 15px;
        }

        .staff-section-body {
            padding: 15px;
        }

        .staff-profile-footer {
            padding: 12px 15px;
        }

        .staff-profile-footer > div {
            display: none;
        }

        .staff-profile-footer .btn {
            width: 100%;
        }

    }

    /* ================================================================
    STAFF SALARY & PAYROLL
    ================================================================ */

    #kt_modal_view_staff .staff-payroll-panel {
        padding: 24px;
        border: 1px solid  var(--erp-border);
        border-radius: 14px;
        background: #fff;
    }

    #kt_modal_view_staff .staff-payroll-summary-card {
        height: 100%;
        min-height: 155px;
        padding: 20px;
        border: 1px solid  var(--erp-border);
        border-radius: 14px;
        background: #fff;
        transition:
            transform .2s ease,
            box-shadow .2s ease,
            border-color .2s ease;
    }

    #kt_modal_view_staff .staff-payroll-summary-card:hover {
        transform: translateY(-2px);
        border-color: #c7d2fe;
        box-shadow: 0 10px 25px rgba(15, 23, 42, .06);
    }

    #kt_modal_view_staff .staff-payroll-summary-primary {
        background:
            linear-gradient(
                135deg,
                rgba(79, 70, 229, .07),
                rgba(255, 255, 255, 1)
            );
    }

    #kt_modal_view_staff .staff-payroll-summary-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
    }

    #kt_modal_view_staff .staff-payroll-summary-icon,
    #kt_modal_view_staff .staff-payroll-heading-icon,
    #kt_modal_view_staff .staff-payroll-account-icon {
        width: 42px;
        height: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        border-radius: 11px;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: 21px;
    }

    #kt_modal_view_staff .staff-payroll-summary-label {
        display: block;
        margin-bottom: 4px;
        color: #94a3b8;
        font-size: 12px;
        font-weight: 600;
    }

    #kt_modal_view_staff .staff-payroll-summary-value {
        margin: 0 0 5px;
        color: #0f172a;
        font-size: 24px;
        font-weight: 700;
    }

    #kt_modal_view_staff .staff-payroll-summary-caption {
        color: #94a3b8;
        font-size: 11px;
    }

    #kt_modal_view_staff .staff-payroll-nav {
        padding: 4px;
        gap: 3px;
        border-radius: 10px;
        background: #f5f7fb;
    }

    #kt_modal_view_staff .staff-payroll-nav .nav-link {
        padding: 8px 14px;
        border-radius: 8px;
        color: #64748b;
        font-size: 12px;
        font-weight: 600;
    }

    #kt_modal_view_staff .staff-payroll-nav .nav-link.active {
        background: #fff;
        color:var(--erp-primary);
        box-shadow: 0 2px 7px rgba(15, 23, 42, .07);
    }

    #kt_modal_view_staff .staff-current-structure-header {
        padding: 18px;
        border: 1px solid  var(--erp-border);
        border-radius: 12px;
        background: #FFFDFB;
    }

    #kt_modal_view_staff .staff-salary-metric {
        height: 100%;
        padding: 16px;
        border: 1px solid #edf0f5;
        border-radius: 11px;
        background: #fff;
    }

    #kt_modal_view_staff .staff-salary-metric span {
        display: block;
        margin-bottom: 5px;
        color: #94a3b8;
        font-size: 11px;
        font-weight: 600;
    }

    #kt_modal_view_staff .staff-salary-metric strong {
        color: #1e293b;
        font-size: 17px;
        font-weight: 700;
    }

    #kt_modal_view_staff .staff-component-section {
        overflow: hidden;
        border: 1px solid  var(--erp-border);
        border-radius: 12px;
    }

    #kt_modal_view_staff .staff-component-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 16px;
        border-bottom: 1px solid #edf0f5;
        background: #FFFDFB;
        font-size: 12px;
        font-weight: 700;
    }

    #kt_modal_view_staff .staff-component-list {
        padding: 5px 16px;
    }

    #kt_modal_view_staff .staff-component-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px dashed #e5e7eb;
    }

    #kt_modal_view_staff .staff-component-row:last-child {
        border-bottom: 0;
    }

    #kt_modal_view_staff .staff-component-name {
        min-width: 0;
    }

    #kt_modal_view_staff .staff-component-name strong {
        display: block;
        color: #334155;
        font-size: 12px;
    }

    #kt_modal_view_staff .staff-component-name span {
        color: #94a3b8;
        font-size: 10px;
    }

    #kt_modal_view_staff .staff-component-amount {
        flex-shrink: 0;
        color: #0f172a;
        font-size: 12px;
        font-weight: 700;
    }


    /* SALARY HISTORY */

    #kt_modal_view_staff .staff-salary-history-timeline {
        position: relative;
    }

    #kt_modal_view_staff .staff-salary-history-item {
        position: relative;
        padding-left: 36px;
        padding-bottom: 28px;
    }

    #kt_modal_view_staff .staff-salary-history-item::before {
        content: "";
        position: absolute;
        top: 15px;
        bottom: -5px;
        left: 10px;
        width: 1px;
        background: #E6D8CC;
    }

    #kt_modal_view_staff
    .staff-salary-history-item:last-child::before {
        display: none;
    }

    #kt_modal_view_staff .staff-salary-history-dot {
        position: absolute;
        top: 4px;
        left: 3px;
        z-index: 1;
        width: 15px;
        height: 15px;
        border: 3px solid #fff;
        border-radius: 50%;
        background:var(--erp-primary);
        box-shadow: 0 0 0 2px #c7d2fe;
    }

    #kt_modal_view_staff .staff-salary-history-card {
        padding: 17px;
        border: 1px solid  var(--erp-border);
        border-radius: 12px;
        background: #fff;
    }


    /* PAYROLL TABLE */

    #kt_modal_view_staff .staff-payroll-table-wrapper {
        border: 1px solid  var(--erp-border);
        border-radius: 12px;
    }

    #kt_modal_view_staff
    .staff-payroll-table-wrapper table {
        margin-bottom: 0;
    }

    #kt_modal_view_staff
    .staff-payroll-table-wrapper thead th {
        padding: 13px 15px;
        border-bottom: 1px solid  var(--erp-border);
        background: #FFFDFB;
    }

    #kt_modal_view_staff
    .staff-payroll-table-wrapper tbody td {
        padding: 14px 15px;
    }


    /* EXPANDED PAYROLL */

    #kt_modal_view_staff .staff-payroll-detail-row td {
        padding: 0 !important;
        background: #FFFDFB;
    }

    #kt_modal_view_staff .staff-payroll-detail-content {
        padding: 20px;
    }

    #kt_modal_view_staff .staff-payroll-detail-grid {
        display: grid;
        grid-template-columns:
            repeat(3, minmax(0, 1fr));
        gap: 16px;
    }


    /* SALARY SKELETON */

    #kt_modal_view_staff .staff-skeleton {
        position: relative;
        overflow: hidden;
        border-radius: 6px;
        background: #edf0f5;
    }

    #kt_modal_view_staff .staff-skeleton::after {
        content: "";
        position: absolute;
        inset: 0;
        transform: translateX(-100%);
        background:
            linear-gradient(
                90deg,
                transparent,
                rgba(255, 255, 255, .65),
                transparent
            );
        animation:
            staffSkeletonShimmer
            1.4s
            infinite;
    }

    #kt_modal_view_staff .staff-skeleton-circle {
        width: 42px;
        height: 42px;
        border-radius: 50%;
    }

    #kt_modal_view_staff .staff-skeleton-text-sm {
        width: 45%;
        height: 10px;
    }

    #kt_modal_view_staff .staff-skeleton-text-lg {
        width: 70%;
        height: 18px;
    }

    @keyframes staffSkeletonShimmer {
        100% {
            transform: translateX(100%);
        }
    }


    /* RESPONSIVE */

    @media (max-width: 991.98px) {

        #kt_modal_view_staff
        .staff-payroll-detail-grid {
            grid-template-columns:
                repeat(2, minmax(0, 1fr));
        }

    }

    @media (max-width: 767.98px) {

        #kt_modal_view_staff .staff-payroll-panel {
            padding: 17px;
        }

        #kt_modal_view_staff .staff-payroll-nav {
            width: 100%;
            overflow-x: auto;
            flex-wrap: nowrap;
        }

        #kt_modal_view_staff
        .staff-payroll-nav .nav-link {
            white-space: nowrap;
        }

        #kt_modal_view_staff
        .staff-payroll-detail-grid {
            grid-template-columns: 1fr;
        }

        #staffSalaryAccountSelectorWrapper {
            width: 100%;
        }

        #staffSalaryAccountSelector {
            width: 100% !important;
        }

    }

    #kt_modal_view_staff .staff-current-experience-card {
        position: relative;
        overflow: hidden;
        padding: 22px;
        border: 1px solid var(--erp-border);
        border-radius: 14px;
        background: linear-gradient(
            135deg,
            #FFF8EF 0%,
            #FFFFFF 100%
        );
    }

    #kt_modal_view_staff .staff-current-experience-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
         background: linear-gradient(
            180deg,
            var(--erp-primary),
            var(--erp-secondary)
        );
    }

    #kt_modal_view_staff .staff-current-experience-icon {
        width: 46px;
        height: 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        border-radius: 12px;
        background: var(--erp-light);
        color: var(--erp-primary);
        font-size: 23px;
    }

    #kt_modal_view_staff .staff-current-experience-duration {
        padding: 14px 18px;
        border: 1px solid #E6D8CC;
        border-radius: 11px;
        background: rgba(255,255,255,.95);
    }

    @media (min-width: 992px) {

        #kt_modal_view_staff
        .staff-current-experience-duration {
            text-align: right;
        }

    }

</style>

<style>
   /* ================================================================
    STAFF PROFILE COMPLETION
    ================================================================ */
    .staff-completion-wrapper {
        /* Default variables */
        --completion-color: #7239ea;
        --completion-soft: rgba(114, 57, 234, 0.08);

        display: inline-flex;
        align-items: center;
        gap: 10px;
        min-width: 140px;
        padding: 7px 9px;
        border-radius: 12px;
        cursor: default;
        transition:
            background-color 0.2s ease,
            transform 0.2s ease,
            box-shadow 0.2s ease;
    }
    /* Optional subtle hover */
    .staff-completion-wrapper:hover {
        background: var(--completion-soft);
        transform: translateY(-1px);
    }
    /* ================================================================
    CIRCULAR PROGRESS
    ================================================================ */
    .staff-completion-ring {
        --completion: 0;
        position: relative;
        width: 46px;
        height: 46px;
        flex: 0 0 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        /*
        * Dynamic progress ring
        *
        * 0% -> empty
        * 50% -> half
        * 100% -> full
        */
        background:conic-gradient(var(--completion-color) calc( var(--completion) * 1% ), #e9edf5 0 );
        transition:  background 0.3s ease, transform 0.2s ease;
    }
    /*
    * Inner white circle
    */
    .staff-completion-ring::before {
        content: '';
        position: absolute;
        inset: 4px;
        border-radius: 50%;
        background: #ffffff;
        box-shadow: 0 1px 3px  rgba(0, 0, 0, 0.05);
    }


    /* Center percentage */
    .staff-completion-ring-center {
        position: relative;
        z-index: 1;
        display: flex;
        align-items: baseline;
        justify-content: center;
        line-height: 1;
    }

    .staff-completion-value {
        font-size: 12px;
        font-weight: 700;
        color: #181c32;
    }

    .staff-completion-percent {
        margin-left: 1px;
        font-size: 8px;
        font-weight: 700;
        color: #7e8299;
    }

    /* 100% Check */
    .staff-completion-check {
        font-size: 20px;
        color: var(--completion-color);
    }
    /* ================================================================
    PROFILE INFORMATION
    ================================================================ */
    .staff-completion-info {
        display: flex;
        flex-direction: column;
        min-width: 0;
    }
    .staff-completion-title {
        margin-bottom: 2px;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.3;
        color: #5e6278;
    }
    .staff-completion-status {
        display: flex;
        align-items: center;
        gap: 3px;
        font-size: 10px;
        font-weight: 600;
        line-height: 1.3;
        white-space: nowrap;
        color: var(--completion-color);
    }
    .staff-completion-status i {
        font-size: 14px;
        color:  var(--completion-color);
    }
    /* ================================================================
    0% - 24%
    RED
    ================================================================ */
    .staff-completion-danger {
        --completion-color: #f1416c;
        --completion-soft: rgba( 241, 65, 108, 0.08 );
    }
    /* ================================================================
    25% - 49%
    ORANGE
    ================================================================ */
    .staff-completion-orange {
        --completion-color: #f97316;
        --completion-soft: rgba(249, 115, 22, 0.08);
    }
    /* ================================================================
    50% - 74%
    AMBER
    ================================================================ */
    .staff-completion-warning {
        --completion-color: #f1bc00;
        --completion-soft: rgba( 241, 188, 0, 0.08);
    }
    /* ================================================================
    75% - 99%
    PURPLE
    ================================================================ */
    .staff-completion-primary {
        --completion-color: #7239ea;
        --completion-soft: rgba( 114, 57, 234, 0.08 );
    }
    /* ================================================================
    100%
    GREEN
    ================================================================ */
    .staff-completion-success {
        --completion-color: #50cd89;
        --completion-soft: rgba(80,205,137, 0.08);
    }
    /* ================================================================
    COMPLETE PROFILE EFFECT
    ================================================================ */
    .staff-completion-success
    .staff-completion-ring {
        box-shadow: 0 0 0 3px rgba(80,205,137, 0.10);
    }
    /* ================================================================
    HOVER EFFECT
    ================================================================ */
    .staff-completion-wrapper:hover
    .staff-completion-ring {
        transform: scale(1.04);
    }

    /* ================================================================
    RESPONSIVE
    ================================================================ */
    @media (max-width: 1200px) {
        .staff-completion-wrapper {
            min-width: auto;
            padding: 5px;
        }
        .staff-completion-info {
            display: none;
        }
    }
</style>

<style>
    /* DOCUMENT CARD */
    #kt_modal_view_staff .staff-document-card {
        display: flex;
        align-items: center;
        gap: 12px;
        min-height: 78px;
        padding: 14px;
        border: 1px solid #E8DDD2;
        border-radius: 11px;
        background: #ffffff;
        transition:
            border-color .2s ease,
            box-shadow .2s ease,
            transform .2s ease;
    }
    #kt_modal_view_staff .staff-document-card:hover {
        border-color: #c7d2fe;
        box-shadow: 0 8px 20px rgba(79, 70, 229, .08);
        transform: translateY(-2px);
    }

    #kt_modal_view_staff .staff-document-icon {
        width: 44px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        border-radius: 11px;
        background:#FFF2E0;
        color:var(--erp-primary);
        font-size: 23px;
    }
    /* CHECKLIST */
    #kt_modal_view_staff .staff-checklist-icon {
        flex-shrink: 0;
        line-height: 1;
    }
    /* TIMELINE */
    #kt_modal_view_staff .staff-timeline-card {
        transition:
            border-color .2s ease,
            box-shadow .2s ease;
    }
    #kt_modal_view_staff .staff-timeline-card:hover {
        border-color: #c7d2fe;
        box-shadow: 0 5px 15px rgba(15, 23, 42, .04);
    }
    /* DYNAMIC TAGS */
    #kt_modal_view_staff
    .badge.badge-light-primary {
        background:#FFF2E0;
        color:var(--erp-primary);
    }


    /* MOBILE */
    @media (max-width: 575.98px) {
        #kt_modal_view_staff
        .staff-document-card {
            padding:12px;
        }

        #kt_modal_view_staff
        .staff-document-icon {
            width: 38px;
            height: 38px;
            font-size: 20px;
        }
    }

</style>

<style>
    .salary-timeline{
        position:relative;
        margin-left:15px;
    }

    .salary-timeline::before{
        content:"";
        position:absolute;
        left:12px;
        top:0;
        bottom:0;
        width:3px;
        background:#dee2e6;
    }

    .timeline-item{
        position:relative;
    }

    .timeline-dot{
        position:absolute;
        width:16px;
        height:16px;
        border-radius:50%;
        left:5px;
        top:20px;
        border:3px solid #fff;
        box-shadow:0 0 0 2px #0d6efd;
    }
</style>
<style>
    .skeleton-transfer {
        position: relative;
        overflow: hidden;
        background: #e9ecef;
        border-radius: 6px;
    }

    .skeleton-transfer::after {
        content: "";
        position: absolute;
        top: 0;
        left: -150%;
        width: 150%;
        height: 100%;
        background: linear-gradient(
            90deg,
            rgba(255,255,255,0) 0%,
            rgba(255,255,255,0.7) 50%,
            rgba(255,255,255,0) 100%
        );
        animation: shimmer 1.5s infinite;
    }

    @keyframes shimmer {
        100% {
            left: 150%;
        }
    }

    .skeleton-circle-transfer {
        width: 110px;
        height: 110px;
        border-radius: 50%;
    }

    .skeleton-text-transfer {
        height: 16px;
        margin-bottom: 10px;
    }

    .skeleton-title-transfer {
        height: 28px;
        width: 200px;
        margin-bottom: 12px;
    }

    .skeleton-badge-transfer {
        height: 24px;
        width: 90px;
        border-radius: 20px;
    }
</style>
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }

    .view-btn {
        width: 100%;
        height: 100%;
        display: none;
        color: black;
        background-color: rgba(0, 0, 0, 0.2);
    }

    .document-thumbnail:hover .view-btn {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */
</style>
<style>
    .mini_dashboard_box .dashboard-card {
        border-radius: 12px;
        transition: all .3s ease;
    }

    .mini_dashboard_box .dashboard-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .dashboard-icon {
        /* font-size:28px; */
        /* margin-bottom:5px; */
    }

    .total-card {
        background: #f8f9fa;
    }

    .company-card {
        color: #fff;
    }

    .company-card img {
        height: 35px;
        margin-bottom: 5px;
    }

    .company-count {
        font-size: 22px;
        font-weight: bold;
    }
</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>

<!-- view STaff css -->
 


<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <ul class="nav nav-tabs border-bottom-0" role="tablist">
            <li class="nav-item">
                <a href="{{ url('/hr_enroll/manage_staff') }}"
                    type="button"
                    class="nav-link active"
                    role="tab">
                    Staff
                </a>
            </li>
            <li class="nav-item position-relative">
                <a href="{{ url('/hr_enroll/exit_staff') }}"
                    type="button"
                    class="nav-link"
                    role="tab">
                    Exit Staff
                    <span id="exitPendingBadge"
                        class="ms-2 badge rounded-pill bg-danger d-none">
                        0
                    </span>
                </a>
            </li>
        </ul>
        <div class="d-flex align-items-center justify-content-between gap-2">
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->

            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="mini_dashbaord">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Dashboard"><i class="mdi mdi-view-dashboard text-center"></i></span>
            </a>
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black">Manage Staff {{$recent_activity}}</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                HR Enroll
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                @if($user_id == 0)
                <button class="btn btn-dark" type="button" onclick="openBulkSalaryModal()"> <i class="mdi mdi-account-cash me-1"></i> </button>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_old_staff">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Old Staff
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_report">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>update report
                </a>
                @endif
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_update_staffId" onclick="open_update_staffId()">
                    <span class="me-2"><i class="mdi mdi-account-box-edit-outline"></i></span>Update Staff Id
                </a>
                <a href="{{ url('hr_enroll/manage_staff/add_staff') }}" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Staff
                </a>
            </div>
        </div>
        <div class="mini_dashboard_box mb-3" style="display: none;">
            <div class="row border rounded align-items-center p-2 border-primary mx-2">

                <!-- Total Staff -->
                <div class="col-md-3">
                    <div class="card dashboard-card total-card shadow-sm h-100 border">
                        <div class="card-body text-center d-flex flex-column align-items-center justify-content-center">
                            <div class="dashboard-icon">
                                <i class="mdi mdi-account-group fs-3"></i>
                            </div>

                            <h3 class="fw-bold mb-0" id="total_staff_dash">0</h3>
                            <small class="text-muted">Total Staff</small>
                        </div>
                    </div>
                </div>

                <!-- Company cards -->
                <div class="col-md-9">
                    <div class="d-flex gap-2 align-items-center flex-wrap" id="companyStaffCards">

                    </div>
                </div>

            </div>
        </div>
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" {{$company_fill== $clist->sno ? 'selected':''}}>{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                        <option value="0_2_months">0-2 Months</option>
                        <option value="2_4_months">2-4 Months</option>
                        <option value="4_6_months">4-6 Months</option>
                        <option value="gt_6_months">Greater than 6 Months</option>
                        <option value="6_12_months">6-12 Months</option>
                        <option value="gt_1_year">Greater than 1 Year</option>
                        <option value="1_2_years">1-2 Years</option>
                        <option value="gt_2_years">Greater than 2 Years</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 mb-2 py-1 rounded bg-label-warning" style="border: 1px solid #fba919; display: none;" id="filter_div">
                <div class="row">
                    <div class="col-lg-4 border-end border-danger">
                        <div class="row">
                            <label class="col-5 fw-semibold fs-6 text-danger">Staff</label>
                            <label class="col-1 fw-semibold fs-6 text-danger">:</label>
                            <label class="col-6 fw-bold fs-6 text-danger">Kanimozhi</label>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap align-items-center justify-content-end gap-3 py-2">
                    <a href="javascript:void(0)" onclick="clearFilter()"
                        class="btn btn-sm fw-bold text-white" style="background-color: #350501ff">
                        Clear Filter
                    </a>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Staff</th>
                                <th class="min-w-100px">Company / Entity</th>
                                <th class="min-w-100px">Dept /Div /<br>Job Role</th>
                                <th class="min-w-100px">Date Of Joining</th>
                                <th class="min-w-100px">Completion</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-80px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body">
                            <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>



    
<div class="modal fade" id="AppraisalsalaryHistoryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex align-items-center">
                    <img id="emp_image" src="/assets/egc_images/auth/user_2.png" class="rounded-circle border me-3" style="width:70px;height:70px;object-fit:cover;">
                    <div>
                        <h3 class="mb-1 fw-bold text-dark">Salary Appraisal History</h3>
                        <div class="fw-semibold text-primary" id="emp_name"> -</div>
                        <small class="text-muted" id="emp_mobile"> -</small>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white rounded-bottom-1">
                <div class="modal-body bg-light">
                <input  type="hidden" id="employee_sno">
                <!-- Summary -->
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <label class="text-muted mb-2">Salary Account</label>
                                <select  id="history_account" class="form-select select3">
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted">Current Salary</div>
                                <div id="current_salary_hist" class="fs-2 fw-bold text-success mt-2"> ₹0</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted">
                                    Pending History
                                </div>
                                <div id="pending_count" class="fs-2 fw-bold text-warning mt-2">0</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hidden Template -->
                <select id="history_template_master" class="d-none">
                    <option value="">Select Template</option>
                    @foreach($salaryTemplates as $template)
                        <option value="{{$template->sno}}">
                            {{$template->template_name}}
                        </option>
                    @endforeach
                </select>
                <!-- Entry -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="mb-0 fw-bold"> Salary Appraisal Entries</h5>
                                <small class="text-muted">Maintain employee salary history in chronological order.</small>
                            </div>
                            <button  type="button" class="btn btn-primary" onclick="addAppraisalHistoryRow()">
                                <i class="mdi mdi-plus-circle-outline me-1"></i>
                                Add Appraisal
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="historyRows"></div>
                    </div>
                </div>
                <!-- Timeline -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0 fw-bold"> Salary Timeline</h5>
                    </div>
                    <div class="card-body">
                        <div id="salaryTimeline">
                            <div class="text-center text-muted py-5">
                                Loading...
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <div class="modal-footer bg-white">
                <button  class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <button id="saveHistoryBtn" class="btn btn-success">
                    <i class="mdi mdi-content-save-outline me-1"></i>
                    Save Salary History
                </button>
            </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="assignShiftModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="assign_staff_img" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Assign Shift</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="assign_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="assign_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <input type="hidden" id="assign_staff_id">
                <input type="hidden" id="current_shift_id">

                <div class="row">
                    <!-- CURRENT SHIFT -->
                    <div class="col-md-6" id="currentShiftBox" style="display:none;">
                        <div class="card border shadow-sm mb-4">
                            <div class="card-header bg-label-warning">
                                <b>Current Shift</b>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="fw-semibold text-dark">Shift Name</label>
                                    <input type="text" id="current_shift_name" class="form-control" readonly>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold text-dark">End Date</label>
                                    <input type="text" id="previous_end_date" class="form-control common_datepicker">
                                    <small class="text-muted">Last working day of current shift</small>
                                </div>
                                <div id="currentShiftPreview" class="border border-primary rounded p-3 bg-light d-none">
                                    <div class="d-flex justify-content-between mb-2">
                                        <b class="text-primary">Shift Schedule</b>
                                        <span class="badge bg-success" id="currentShiftTotalDuration"></span>
                                    </div>
                                    <div id="currentShiftDays"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- NEW SHIFT -->
                    <div class="col-md-6">
                        <div class="card border shadow-sm">
                            <div class="card-header bg-label-primary">
                                <b>Assign New Shift</b>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="fw-semibold">Select Shift</label>
                                    <select id="shift_select" class="form-select select3" onchange="shift_change_func()">
                                        <option value="">Select Shift</option>
                                        @foreach($shifts as $shift)
                                        <option value="{{$shift->sno}}">
                                            {{$shift->shift_name}}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold">Start Date</label>
                                    <input type="text" id="shift_start_date" class="form-control common_datepicker">
                                    <small class="text-muted">Next working day of Assign shift</small>
                                </div>
                                <div id="shiftPreview" class="border rounded border-primary p-3 bg-label-success d-none">
                                    <div class="d-flex justify-content-between mb-2">
                                        <b class="text-primary">Shift Schedule</b>
                                        <span class="badge bg-success" id="shiftTotalDuration"></span>
                                    </div>
                                    <div id="shiftDays"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end mt-3">
                    <button type="button" class="btn btn-primary px-5" onclick="assignShift()">Assign Shift</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="salaryHistoryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="history_staff_img" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">Employee Salary Revision</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="history_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="history_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white rounded-bottom-1">
                
                <form id="salaryHistoryForm">
                    @csrf
                    <input type="hidden" id="history_employee_sno">
                    <input type="hidden" id="history_salary_account_id">

                    

                    <div class="row">
                            <div id="employee_summary_card" class="col-6"></div>
                            <div id="current_salary_card" class="col-6"></div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                           <div id="salary_revision_section">

                                <div class="card shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        Bulk Appraisal Management
                                    </div>

                                    <div class="card-body">

                                        <div class="alert alert-info mb-0">

                                            Use the timeline to manage historical salary records.

                                            <br>

                                            Mark one record as Current Salary.

                                            <br>

                                            Records will be recreated chronologically.

                                        </div>

                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn btn-success"
                            onclick="saveBulkHistory()">

                            Save Appraisal History

                        </button>

                    </div>
                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<!--begin::Modal view staff--->
<div class="modal fade" id="employeePayrollModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="payroll_staff_img" class="avatar-img" />
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">Employee Payroll Details</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="payroll_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="payroll_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white rounded-bottom-1">
                <form id="employeePayrollForm">
                    @csrf
                    <input type="hidden" name="employee_sno" id="update_acc_employee_sno">
                    <!-- Payroll Configuration -->
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0 text-primary">Payroll Configuration</h5>
                        </div>
                        <input type="hidden" id="single_salary_account_sno" name="single_salary_account_sno">
                        <div class="card-body">
                            <div class="row">
                                <!-- Account Type -->
                                <div class="col-lg-4 mb-3">
                                    <label class="fw-semibold">
                                        Account Type
                                    </label>
                                    <div class="mt-2">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="is_multiple_account" value="0" checked onclick="accountTypeChange()">
                                            <label class="form-check-label">
                                                Single Account
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="is_multiple_account" value="1" onclick="accountTypeChange()">
                                            <label class="form-check-label">
                                                Multiple Account
                                            </label>
                                        </div>

                                    </div>
                                </div>

                                <!-- Casual Leave -->
                                <div class="col-lg-2 mb-3">
                                    <label class="fw-semibold">
                                        Casual Leave
                                    </label>
                                    <input type="text" class="form-control" id="casual_leave_count" name="casual_leave_count" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                                </div>

                                <!-- Salary Type -->
                                <div class="col-lg-3 mb-3">
                                    <label class="fw-semibold">
                                        Salary Type
                                    </label>
                                    <div class="mt-2">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="salary_type" id="salary_cash" value="1"  checked>
                                            <label class="form-check-label">
                                                Cash
                                            </label>
                                        </div>

                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="salary_type" id="salary_bank"  value="2">
                                            <label class="form-check-label">
                                                Bank
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!-- Salary Date -->
                                <div class="col-lg-2 mb-3">
                                    <label class="fw-semibold">
                                        Salary Date
                                    </label>
                                    <select name="salary_date" id="salary_date" class="form-select select3">
                                        <option value="">Select</option>
                                        <option value="1">5th</option>
                                        <option value="2">15th</option>
                                    </select>
                                </div>
                                <!-- Payslip -->
                                <div class="col-lg-1 mb-3">
                                    <label class="fw-semibold">
                                        Payslip
                                    </label>
                                    <div class="mt-2">
                                        <input class="form-check-input" type="checkbox" id="is_payslip" name="is_payslip" value="1">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- SINGLE ACCOUNT PAYROLL -->
                    <div id="singleAccountDiv">
                        <div class="card shadow-sm border-0 mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0 text-primary">
                                    Single Account Payroll
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="fw-semibold">
                                            Basic Salary
                                        </label>
                                        <input type="number" class="form-control" id="basic_salary" name="basic_salary" oninput="per_day_salary_value()" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <label class="fw-semibold">
                                            Per Day Salary
                                        </label>

                                        <input type="text"  class="form-control" id="per_day_salary" name="per_day_salary" readonly>
                                    </div>

                                    <div class="col-lg-4 mb-3">
                                        <label class="fw-semibold">
                                            Per Hour Cost
                                        </label>
                                        <input type="text" class="form-control" id="per_hr_cost"  name="per_hr_cost" readonly>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label class="fw-semibold">
                                            Salary Company
                                        </label>
                                        <select id="salary_company_id" name="salary_company_id"  class="form-select select3" onchange="salary_company_change()">
                                            <option value="">Select Company</option>
                                            @foreach($company_list as $company)
                                            <option value="{{ $company->sno }}">
                                                {{ $company->company_name }}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="fw-semibold">
                                            Salary Bank
                                        </label>
                                        <select id="salary_bank_id" name="salary_bank_id" class="form-select select3">
                                            <option value=""> Select Bank</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- MULTIPLE ACCOUNT PAYROLL -->
                    <div id="multipleAccountDiv" class="d-none">
                        <div class="card shadow-sm border-0 mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center bg-light">

                                <h5 class="mb-0 text-primary">
                                    Multiple Salary Accounts
                                </h5>

                                <button
                                    type="button"
                                    class="btn btn-primary btn-sm"
                                    onclick="addSalaryAccountRow()">

                                    Add Account
                                </button>

                            </div>
                            <div class="card-body p-0 mt-2">

                                <div class="table-responsive">

                                    <table class="table table-bordered align-middle mb-0">

                                        <thead >

                                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                                <th>Primary</th>
                                                <th class="max-w-250px">Company</th>
                                                <th class="max-w-250px">Bank</th>
                                                <th>Gross Salary</th>
                                                <th>Per Day</th>
                                                <th>Per Hour</th>
                                            </tr>

                                        </thead>

                                        <tbody id="salaryAccountBody">

                                        </tbody>

                                    </table>

                                </div>

                            </div>
                        </div>
                        <!-- Salary Summary -->
                        <div class="card shadow-sm border-0 mb-4">

                            <div class="card-header bg-light">
                                <h5 class="mb-0 text-primary">
                                    Salary Summary
                                </h5>
                            </div>

                            <div class="card-body">

                                <div class="row">

                                    <div class="col-lg-4">
                                        <label>Total Gross Salary</label>

                                        <input
                                            type="text"
                                            id="total_gross_salary"
                                            class="form-control"
                                            readonly>
                                    </div>

                                    <div class="col-lg-4">
                                        <label>Total Per Day</label>

                                        <input
                                            type="text"
                                            id="total_per_day"
                                            class="form-control"
                                            readonly>
                                    </div>

                                    <div class="col-lg-4">
                                        <label>Total Per Hour</label>

                                        <input
                                            type="text"
                                            id="total_per_hour"
                                            class="form-control"
                                            readonly>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- STATUTORY DETAILS -->
                    <div class="card shadow-sm border-0 mb-4 statutorySection">
                        <div class="card-header bg-light">
                            <h5 class="mb-0 text-primary">
                                Statutory Details
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label>UAN Number</label>
                                    <input type="text" name="uan_no" class="form-control" maxlength="12" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                </div>

                                <div class="col-lg-3 mb-3">
                                    <label>ESI Number</label>
                                    <input type="text" name="esi_no" class="form-control" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label>PAN Number</label>
                                    <input  type="text" name="pan_no" class="form-control" maxlength="10" oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'');">
                                </div>

                                <div class="col-lg-3 mb-3">
                                    <label>Aadhar Number</label>
                                    <input  type="text" name="aadhar_no"  class="form-control" oninput="this.value=this.value.replace(/[^0-9]/g,'');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow-sm border-0 mb-4 statutorySection">
                        <div class="card-header bg-light">
                            <h5 class="mb-0 text-primary">
                                Staff Bank Details
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label>Staff Bank Name</label>
                                    <input  type="text" name="staff_bank_name" id="staff_bank_name" class="form-control" placeholder="Enter Staff Bank Name" value="" >
                                    <small class="text-danger error" data-error="staff_bank_name"></small>
                                </div>

                                <div class="col-lg-3 mb-3">
                                    <label>Staff Bank Branch</label>
                                    <input type="text" class="form-control required-field" id="staff_bank_branch" name="staff_bank_branch" placeholder="Enter Staff Bank Branch" value="" />
                                    <small class="text-danger error" data-error="staff_bank_branch"></small>
                                </div>

                                <div class="col-lg-3 mb-3">
                                    <label>Account Holder</label>

                                    <input type="text" class="form-control" placeholder="Enter Account Holder" id="staff_acc_holder" name="staff_acc_holder" maxlength="50" value="" />
                                    <small class="text-danger error" data-error="staff_acc_holder"></small>
                                </div>

                                <div class="col-lg-3 mb-3">
                                    <label>Account No</label>
                                    <input type="text" class="form-control" placeholder="Enter Account No" id="staff_acc_no" name="staff_acc_no" maxlength="20" value="" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                                    <small class="text-danger error" data-error="staff_acc_no"></small>
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label>IFSC Code</label>
                                    <input type="text" class="form-control" placeholder="Enter IFSC Code" id="ifsc_code" name="ifsc_code" maxlength="20" oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'');" value="" />
                                    <small class="text-danger error" data-error="ifsc_code"></small>
                                </div>

                            </div>

                        </div>
                    </div>
                    <!-- Save Button -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="savePayrollBtn" onclick="validation_func()">
                            <span class="btn-text">
                                Save Payroll Details
                            </span>
                            <span class="spinner-border spinner-border-sm d-none"></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - view staff-->

<div class="modal fade" id="salaryMappingModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="salaryMappingForm">
                @csrf
                <input type="hidden" name="employee_sno" id="mapping_employee_sno">
                <div class="modal-header">
                    <h5>Employee Salary Mapping</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-6">
                            <label>Salary Structure</label>
                            <select name="salary_structure_sno" class="form-control select3">
                                <option value="">Select Structure</option>
                                @foreach($structures as $s)
                                <option value="{{ $s->sno }}">
                                    {{ $s->structure_name }}
                                </option>
                                @endforeach
                            </select>
                            <small class="text-danger error" data-error="salary_structure_sno"></small>
                        </div>

                        <div class="col-md-6">
                            <label>Effective From</label>
                            <input type="text" name="effective_fromsss" class="form-control common_datepicker" placeholder="Select Effective From Date">
                            <small class="text-danger error" data-error="effective_fromsss"></small>
                        </div>

                    </div>
                    <div class="mt-3">
                        <label>Change Reason</label>
                        <input type="text" name="change_reason" class="form-control" placeholder="Example: Annual increment">
                    </div>
                    <hr>

                    <h6>Salary History</h6>

                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Structure</th>
                                <th>Effective From</th>
                                <th>Effective To</th>
                                <th>Reason</th>
                            </tr>
                        </thead>
                        <tbody id="salaryHistoryTable" class="text-black fw-semibold fs-7">

                        </tbody>
                    </table>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" onclick="saveSalaryMapping()" id="saveMappingBtn">
                        <span class="btn-text">
                            Save Salary Mapping
                        </span>
                        <span class="spinner-border spinner-border-sm d-none"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--begin::Modal - Send Test Template-->
<div class="modal fade" id="kt_modal_send_test_template" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Test Template</h3>
                </div>

                <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">

                <div class="communication_check">
                    
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <div class="badge bg-label-primary rounded-pill mb-1">
                            <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                            <span class="align-middle fw-semibold">Edit profile URL</span>
                        </div>
                    </div>
                </div>
                <div class="row communication_check">
                    
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="text-danger" id="communication_err"></div>
                    </div>
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description">Thank you for your Service Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of </textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Test Template</button>
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Test Template-->

<div class="modal fade" id="kt_modal_send_profile_edit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Profile Edit Link</h3>
                </div>

                <div class="border rounded-3 p-4 mb-5 bg-label-light">
                    <div class="d-flex align-items-center gap-4">

                        <div class="symbol symbol-60px">
                            <img id="profile_edit_staff_image"
                                 src="{{ asset('assets/egc_images/auth/user_3.png') }}"
                                 class="rounded-circle w-60px h-60px"
                                 style="object-fit:cover;"
                                 alt="Staff">
                        </div>

                        <div class="flex-grow-1">
                            <div class="fw-bold fs-5 text-dark"
                                 id="profile_edit_staff_name">
                                Loading...
                            </div>

                            <div class="text-muted fs-7 mt-1">
                                Employee ID:
                                <span class="fw-semibold text-dark"
                                      id="profile_edit_staff_id">-</span>
                            </div>

                            <div class="d-flex flex-wrap gap-3 mt-2">

                                <span class="text-muted fs-8">
                                    <i class="mdi mdi-phone-outline me-1"></i>
                                    <span id="profile_edit_mobile">-</span>
                                </span>

                                <span class="text-muted fs-8">
                                    <i class="mdi mdi-email-outline me-1"></i>
                                    <span id="profile_edit_email">-</span>
                                </span>

                            </div>
                        </div>

                    </div>
                </div>

                <div class="mb-5">
                    <label class="form-label fw-bold text-dark">
                        Profile Edit URL
                    </label>

                    <div class="input-group">
                        <input type="text"
                               id="profile_edit_url"
                               class="form-control"
                               readonly>

                        <button type="button"
                                class="btn btn-light-primary"
                                id="copy_profile_edit_url">
                            <i class="mdi mdi-content-copy me-1"></i>
                            Copy
                        </button>
                    </div>
                    <div class="text-muted fs-8 mt-2">
                        This secure link allows the employee to update their editable profile information.
                    </div>
                </div>

                <input type="hidden" id="profile_edit_encrypted_id" value="">
                <input type="hidden" id="send_profile_whatsapp" value="0">
                <input type="hidden" id="send_profile_email" value="0">
                <input type="hidden" id="send_profile_sms" value="0">

                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <span class="badge bg-label-primary rounded-pill">
                            <i class="mdi mdi-link-variant me-1"></i>
                            Profile Edit
                        </span>
                    </div>
                </div>
                <div class="row ">
                    
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 profile-communication-btn" id="profile_edit_whatsapp_btn" onclick="toggleProfileCommunication('whatsapp')">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 profile-communication-btn" id="profile_edit_email_btn" onclick="toggleProfileCommunication('email')" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 profile-communication-btn" id="profile_edit_sms_btn" onclick="toggleProfileCommunication('sms')" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/egc_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="text-danger" id="communication_err"></div>
                    </div>

                    <div id="profile_edit_communication_err"
                        class="text-danger fs-8 mt-2">
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4 gap-2">
                    <button type="button"
                            class="btn btn-light"
                            data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button"
                            class="btn btn-primary"
                            id="sendProfileEditBtn">
                        <i class="mdi mdi-send-outline me-1"></i>
                        Send Profile Edit Link
                        <span class="spinner-border spinner-border-sm d-none ms-2"
                            id="sendProfileEditLoader">
                        </span>
                    </button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>




<!--begin::Modal - Send Test Template-->

<!--end::Modal - Send Test Template-->

<!--begin::Modal Filter-->
<div class="modal fade" id="kt_modal_update_staffId" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded">

            <div class="modal-header border-0">
                <h3 class="text-center w-100">Update Staff ID</h3>
                <button class="btn btn-sm btn-icon btn-light" data-bs-dismiss="modal">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>

            <div class="modal-body px-6 pb-6">

                <!-- COMPANY TABS -->
                <ul class="nav nav-tabs flex-nowrap" role="tablist" id="companyTabs">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                        <div class="scroll-container" id="scrollContainer">
                            <li class="item nav-item">
                                <a type="button"
                                    class="nav-link scroll-link company-tab active"
                                    data-company="0"
                                    data-bs-toggle="tab" href="#">
                                    Elysium Groups
                                </a>
                            </li>
                            @foreach ($company_list as $comp)
                            <li class="item nav-item">
                                <a type="button"
                                    class="nav-link scroll-link company-tab"
                                    data-company="{{$comp->sno}}"
                                    data-bs-toggle="tab" href="#"
                                    aria-selected="true">
                                    {{ $comp->company_name }}
                                </a>
                            </li>
                            @endforeach
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>

                <!-- STAFF LIST -->
                <div class="mt-4" id="companyStaffList">
                    <div class="text-center text-muted py-5">
                        Loading staff...
                    </div>
                </div>

                <!-- BULK UPDATE BUTTON -->
                <div class="mt-4 text-end" id="bulkUpdateContainer" style="display:none;">
                    <button class="btn btn-primary" id="bulkUpdateBtn">
                        Bulk Update Staff IDs
                    </button>
                </div>

            </div>

        </div>
    </div>
</div>
<!--end::Modal Filter-->

<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->


<!--begin::Modal exit staff--->
<div class="modal fade" id="kt_modal_exit_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Exit Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="cus_drp_form" action="{{ route('departure_staff') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <input type="hidden" id="exist_sts_change_id" name="exist_sts_change_id" />
                    <input type="hidden" id="exist_staff_id" name="exist_staff_id" />
                    <div class="row mb-3">
                        <div class="col-lg-6 mb-2 border-end">
                            <div class="row">
                                <div class="col-lg-12 d-flex align-items-center px-1 mb-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            <img src="{{ asset('assets/egc_images/auth/user_2.png') }}"
                                                alt="user-avatar" class="w-px-100 h-auto rounded-circle"
                                                id="exist_staff_profile_image" />
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="fs-5 fw-bold" id="exist_staff_name">Mahesh Kumar</label>
                                        <div class="d-flex text-primary">
                                            <a href="javascript:;" class="text-primary fw-semibold fs-7" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name" id="exist_nick_name">
                                                Karthik
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-domain fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Company Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_company_name">Elysium Techonologies Pvt Ltd</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-office-building fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Entity Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_entity_name">Click My Project</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-graph fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_department">Sales</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-file-tree fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Division Name"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_division">Business Development Executive</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-briefcase fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Job Position"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_job_role">Senior Executive</label>
                                </div>
                                <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-start gap-2">
                                    <i class="mdi mdi-calendar-badge-outline fs-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining"></i>
                                    <label class="fs-7 fw-semibold text-black" id="exist_staff_doj">12-Sep-2024</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-2">
                            <div class="row mt-2 mb-3">
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="notice_period" id="notice_period" value="4" onchange="departure_func(4);" checked />
                                        <label class="form-check-label" for="notice_period">Notice Period</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="relieve" id="relieve" value="5" onchange="departure_func(5);" />
                                        <label class="form-check-label" for="relieve">Relieve</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="upscond" id="upscond" value="6" onchange="departure_func(6);" />
                                        <label class="form-check-label" for="franchise">Abscond</label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="terminate" id="terminate" value="7" onchange="departure_func(7);" />
                                        <label class="form-check-label" for="franchise">Terminate</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="date_view">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Last Attend Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="staff_last_date" name="staff_last_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />

                                </div>
                                <div id="staff_last_date_err" class="text-danger"></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6 mt-2" style="display:none;" id="starting_date">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Starting Date<span class="text-danger">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="notice_start_date" name="notice_start_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                                    </div>
                                    <div id="notice_start_date_err" class="text-danger"></div>
                                </div>
                                <div class="col-lg-6 mt-2" style="display:none;" id="ending_date">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Ending Date<span class="text-danger">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="notice_end_date" name="notice_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly />
                                    </div>
                                    <div id="notice_end_date_err" class="text-danger"></div>
                                </div>
                            </div>
                            <div class="col-lg-12 mt-2 mb-3" style="display:none;" id="reason_add">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="dep_reason" name="dep_reason" placeholder="Enter Reason"></textarea>
                                <div id="dep_reason_err" class="text-danger"></div>
                            </div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                        <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">No</button>
                        <button type="button" class="btn btn-primary me-3" id="exit_submit_butt" onclick="status_change_validation()">Exit Period</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - exit staff-->



<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_old_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Add Old Staff</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form method="POST" action="{{ route('add_old_staff') }}" enctype="multipart/form-data" autocomplete="off" id="addOldStaffForm">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <input type="hidden" id="staff_data_payload" name="staff_data_payload" />
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                            <select id="staff_company_name" name="staff_company_name" class="select3 form-select">
                                <option value="">Select Company Name</option>
                                @if(isset($company_list))
                                @foreach($company_list as $clist)
                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                @endforeach
                                @endif
                            </select>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                            <select id="staff_entity_name" name="staff_entity_name" class="select3 form-select">
                                <option value="">Select Entity Name</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                            <select id="staff_branch_name" name="staff_branch_name" class="select3 form-select">
                                <option value="">Select Branch Name</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff data :</label>
                            <span lass="text-black mb-1 fs-6 fw-semibold " id="total_Staff_data">0 </span>Record Found
                            <div lass="text-black mb-1 fs-6 fw-semibold " id="total_Staff_list"></div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                        <button type="button" class="btn btn-primary me-3" id="submitStaffBtn" onclick="submit_form()">Add Old Staff</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_staff_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Staff Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form method="POST" action="{{ route('update_staff_timestamp_report') }}" enctype="multipart/form-data" autocomplete="off" id="updateTimestampForm">
                @csrf
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="row mb-3">
                        <div class="col-lg-12 mb-2">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                            <input type="text" id="date_timestamp" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-lg-6">
                            <label class="text-black mb-1 fs-6 fw-semibold">Timestamp data :</label>
                            <span lass="text-black mb-1 fs-6 fw-semibold " id="total_timestamp_data">0 </span>Record Found

                        </div>
                    </div>
                    <!--end::Modal body-->
                    <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                        <button type="button" class="btn btn-primary me-3" id="submitTimestampBtn" onclick="submit_timestamp_form()">Update Staff Timestamp</button>
                    </div>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_filter" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Filter</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <input type="hidden" id="sts_change_id" name="sts_change_id" />
                <!-- <div class="row mb-3">
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Name /Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Staff Name /Mobile No" />
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                        <select id="company_name" name="company_name" class="select3 form-select">
                            <option value="">Select Company Name</option>
                            <option value="1">Elysium Techonologies Pvt Ltd</option>
                            <option value="2">Elysium Acadmy</option>
                            <option value="3">Elsyian Inteliigence Business Solution</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                        <select id="entity_name" name="entity_name" class="select3 form-select">
                            <option value="">Select Entity Name</option>
                            <option value="1">Click My Project</option>
                            <option value="2">PhD izone</option>
                            <option value="3">E-Pro</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                        <select id="dept_name" name="dept_name" class="select3 form-select">
                            <option value="">Select Department Name</option>
                            <option value="1">Production</option>
                            <option value="2">Sales</option>
                            <option value="3">Internal Management</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                        <select id="div_name" name="div_name" class="select3 form-select">
                            <option value="">Select Division Name</option>
                            <option value="1">Pre Sales</option>
                            <option value="2">Post Sales</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                        <select id="job_role_name" name="job_role_name" class="select3 form-select">
                            <option value="">Select Job Role</option>
                            <option value="1">Junior Sales Executive</option>
                            <option value="2">Senior Sales Executive</option>
                            <option value="3">Sales Team Lead</option>
                        </select>
                    </div>
                     <div class="col-lg-4 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div> -->
                <!--end::Modal body-->
                <div class="d-flex justify-content-between align-items-center pb-2 mt-4">
                    <!-- <button  type="submit" class="btn btn-primary me-3" id="departure_submit_butt">Yes</button> -->
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Reset</button>
                    <button type="button" class="btn btn-primary me-3" id="filter_btn" data-bs-dismiss="modal">Add Filter</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->


<div class="modal fade" id="filePreviewModal" tabindex="-1" aria-labelledby="filePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="filePreviewModalLabel">File Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Modal content dynamically injected -->
                <div id="filePreviewContent" class="d-flex justify-content-center align-items-center">
                    <!-- Preview content will be added here dynamically -->
                </div>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal view staff--->

<!--end::Modal - view staff-->



<div class="modal fade" id="employeeSalaryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="salary_staff_img" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Update Salary Structure</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="salary_staff_name">-</label>
                    <label class="fs-6 fw-semibold text-black " id="salary_staff_mobile">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <form id="employeeSalaryForm">
                    @csrf
                    <input type="hidden" id="employee_sno">
                    <input type="hidden" id="employee_structure_sno">
                    <div class="row">
                        <!-- LEFT -->
                        <div class="col-xl-8">
                            <!-- EMPLOYEE INFO -->
                            <div class="card border-0 shadow-sm rounded-4 mb-4">
                                <div class="card-body p-4">
                                    <div class="row">
                                       
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Salary Account</label>
                                            <select class="form-select select3" id="salary_account_id" onchange="salary_account_change()">
                                            </select>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold"> Salary Template</label>
                                            <select class="form-select select2" id="payroll_template_sno">
                                                <option value="">Select Template</option>
                                                @foreach($salaryTemplates as $template)
                                                <option value="{{ $template->sno }}">{{ $template->template_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">
                                                Effective From
                                            </label>
                                            <input type="text" class="form-control common_datepicker" id="effective_from">
                                        </div>

                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Gross Salary</label>
                                            <input type="text" class="form-control" id="employee_gross_salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                        </div>
                                        <div class="col-lg-6 mb-4">
                                            <label class="form-label fw-semibold">Revision Reason</label>
                                            <input type="text" class="form-control" id="revision_reason">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- COMPONENTS -->
                            <div class="card border-0 shadow-sm rounded-4">
                                <div class="card-body p-4">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <div>
                                            <h5 class="fw-bold mb-1">Salary Components</h5>
                                            <small class="text-muted">Earnings and deductions</small>
                                        </div>
                                    </div>
                                    <div id="employee_salary_components"></div>
                                </div>
                            </div>
                        </div>
                        <!-- RIGHT -->
                        <div class="col-xl-4">
                            <div class="card border-0 shadow-lg rounded-4 sticky-top">
                                <div class="card-body p-4">
                                    <h5 class="fw-bold mb-4">Salary Summary</h5>
                                    <div class="summary-item">
                                        <span>Total Earnings</span>
                                        <strong id="emp_total_earnings">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Total Deductions</span>
                                        <strong id="emp_total_deductions">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Net Salary</span>
                                        <strong id="emp_net_salary">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>CTC</span>
                                        <strong id="emp_ctc">₹ 0.00</strong>
                                    </div>
                                    <div class="summary-item">
                                        <span>Employer Contribution</span>
                                        <strong id="emp_employer_contribution">
                                            ₹ 0.00
                                        </strong>
                                    </div>
                                    <button type="button" class="btn btn-primary w-100 mt-4 save-employee-salary-btn" onclick="saveEmployeeSalaryStructure()">
                                        <i class="mdi mdi-content-save-outline me-1"></i>Save Salary Structure
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="monthlyInputModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">

                        <h3 class="text-black"> Update variable Amount</h3>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <form id="monthlyInputForm">

                    @csrf

                    <input type="hidden" id="monthly_employee_sno">
                    <input type="hidden" id="payroll_variable_component_sno" value="13">
                    <div class="card border-0 bg-light rounded-4 mb-4">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-2">
                                    <img id="variable_staff_img" class="rounded-circle" width="50">
                                </div>
                                <div class="col-lg-5">
                                    <h5 id="variable_staff_name"
                                        class="fw-bold mb-1">
                                    </h5>
                                    <div id="variable_staff_mobile"
                                        class="text-muted">
                                    </div>
                                </div>
                                <div class="col-lg-5 text-end">
                                    <span class="badge bg-warning text-dark px-4 py-2">
                                        VARIABLE COMPONENT
                                    </span>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-lg-6 mb-4">

                            <label class="form-label fw-semibold">
                                Monthly Amount
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    ₹
                                </span>

                                <input type="number"
                                    class="form-control form-control-lg"
                                    id="variable_amount">

                            </div>

                        </div>

                        <div class="col-lg-6 mb-4">
                            <label class="form-label fw-semibold">Month</label>
                            <input type="text" class="form-control month_filter_common_class" id="variable_from_month" value="{{date('M-Y')}}" />
                        </div>

                    </div>

                    <div id="variable_alert"></div>



                    <div class="alert alert-warning rounded-4 border-0">

                        <div class="d-flex">

                            <i class="mdi mdi-alert-circle-outline fs-2 me-3"></i>

                            <div>

                                <small>
                                    Variable amount will Include In Fixed Gross salary after 3 continuous months.
                                </small>

                            </div>

                        </div>

                    </div>



                    <div class="mb-4">

                        <label class="form-label fw-semibold">
                            HR Remarks
                        </label>

                        <textarea
                            class="form-control"
                            rows="3"
                            id="remarks"></textarea>

                    </div>
                    <button type="button"
                        class="btn btn-primary w-100 py-3 fw-bold rounded-4"
                        onclick="saveVariableAmount()">

                        <i class="mdi mdi-content-save-outline me-1"></i>

                        Save Variable Amount

                    </button>

                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="bulkSalaryModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-dark text-white">
                <div>
                    <h3 class="mb-1">
                        Bulk Salary Structure Update
                    </h3>
                    <small>
                        Auto assign templates based on salary type
                    </small>
                </div>
                <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- LEFT -->
                    <div class="col-lg-4">
                        <div class="card shadow-sm border-0 rounded-4 mb-4">
                            <div class="card-body">
                                <h5 class="fw-bold mb-4">
                                    Settings
                                </h5>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Template For Salary Type 1
                                    </label>
                                    <select class="form-select select3"
                                        id="bulk_template_type_1">
                                        @foreach($salaryTemplates as $template)
                                        <option value="{{ $template->sno }}">
                                            {{ $template->template_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Template For Salary Type 2
                                    </label>
                                    <select class="form-select select3"
                                        id="bulk_template_type_2">
                                        @foreach($salaryTemplates as $template)
                                        <option value="{{ $template->sno }}">
                                            {{ $template->template_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label fw-semibold">
                                        Effective From
                                    </label>
                                    <input type="date"
                                        class="form-control"
                                        id="bulk_effective_from">
                                </div>

                                <div class="mb-4">

                                    <label class="form-label fw-semibold">
                                        Revision Reason
                                    </label>

                                    <textarea class="form-control"
                                        id="bulk_revision_reason"></textarea>
                                </div>

                                <button class="btn btn-primary w-100"
                                    onclick="previewBulkSalaryEmployees()">

                                    <i class="mdi mdi-eye"></i>
                                    Preview Employees

                                </button>

                            </div>

                        </div>

                    </div>

                    <!-- RIGHT -->

                    <div class="col-lg-8">

                        <div class="card border-0 shadow-sm rounded-4">

                            <div class="card-body">

                                <div class="d-flex justify-content-between align-items-center mb-3">

                                    <div>

                                        <h5 class="fw-bold mb-1">
                                            Employee Preview
                                        </h5>

                                        <small class="text-muted">
                                            Employees without salary structure
                                        </small>

                                    </div>

                                    <span class="badge bg-dark fs-6"
                                        id="bulk_total_staff">
                                        0 Staff
                                    </span>

                                </div>

                                <div class="table-responsive">

                                    <table class="table align-middle">

                                        <thead>

                                            <tr>
                                                <th>Employee</th>
                                                <th>Salary Type</th>
                                                <th>Current Template</th>
                                                <th>Current From</th>
                                                <th>Current To</th>
                                                <th>New Template</th>
                                                <th>New Effective From</th>
                                            </tr>

                                        </thead>

                                        <tbody id="bulk_salary_preview_body">

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="modal-footer">

                <button class="btn btn-light"
                    data-bs-dismiss="modal">

                    Cancel

                </button>

                <button class="btn btn-success"
                    id="bulk_salary_save_btn"
                    onclick="saveBulkSalaryStructure()">

                    <i class="mdi mdi-content-save"></i>
                    Apply Bulk Salary Structure

                </button>

            </div>

        </div>

    </div>
</div>




<div class="modal fade" id="otPayrollModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" id="salary_staff_img" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black"> Monthly OT Payroll</h3>
                    </div>
                </div>
                <div class="d-flex flex-column gap-1">
                    <label class="fs-5 fw-semibold text-primary " id="ot_staff_name">-</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <div class="row mb-4">

                    <div class="col-lg-4">
                        <input type="hidden" id="ot_monthly_employee_sno">

                        <label class="form-label">
                            Month
                        </label>

                        <input type="text"
                            id="ot_month"
                            class="form-control month_filter_common_class"
                            value="{{date('M-Y')}}">
                    </div>

                    <div class="col-lg-3 d-flex align-items-end">

                        <button class="btn btn-primary w-100"
                            onclick="loadOTDetails()">

                            Load OT Details
                        </button>
                    </div>

                </div>
                <div class="row g-3 mb-4">

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-primary text-white">
                            <div class="card-body">
                                <div>Total OT Hours</div>
                                <h2 id="total_ot_hours">0 Hrs</h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-success text-white">
                            <div class="card-body">
                                <div>Total OT Amount</div>
                                <h2>₹ <span id="overall_ot_amount">0.00</span></h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-warning text-dark">
                            <div class="card-body">
                                <div>Total OT Days</div>
                                <h2 id="total_ot_days">0</h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-0 bg-dark text-white">
                            <div class="card-body">
                                <div>Department</div>
                                <h2 id="department_name">-</h2>
                            </div>
                        </div>
                    </div>

                </div>

                <div id="ot_summary" class="mb-2"></div>

                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                    <th>Date</th>
                                    <th>Day</th>
                                    <th>Status</th>
                                    <th>Shift Time</th>
                                    <th>Actual In</th>
                                    <th>Actual Out</th>
                                    <th>Worked Hours</th>
                                    <th>OT Hours</th>
                                    <th>OT Rate</th>
                                    <th>OT Amount</th>
                                    <th>Remarks</th>
                            </tr>
                        </thead>

                        <tbody id="ot_table_body"></tbody>

                    </table>

                </div>
                <div class="d-flex justify-content-end">
                     <button class="btn btn-success"
                    onclick="saveOTPayroll()" id="btnSaveOT">

                    Save OT Payroll
                </button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="kt_modal_staff_transferModel" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-1">
                        <div class="">
                            <i class="mdi mdi-transit-transfer text-dark fs-1"></i>
                        </div>

                        <div>
                            <h2 class="fw-bold text-dark mb-1">
                              Staff Transfer
                            </h2>
                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <form id="staffTransferForm">

                    <input type="hidden" id="transfer_staff_sno" name="staff_sno">
                    <div class="row card shadow-sm border-0 ">

                        <!-- Staff Profile -->
                        <div id="staffTransferProfile"></div>

                        <!-- Transfer Form -->
                        <div class="mt-5">
                            <div class="bg-light-primary">
                                <span class="ps-4 fs-4 fw-bold">
                                    Transfer To
                                </span>
                            </div>
                            <div class="card-body">
                                <div class="row mb-2">
                                    <div class="col-md-6 mb-3">
                                        <label class="fw-semibold">
                                            Company Type
                                        </label>
                                        <div>
                                            <div class="form-check form-check-inline mb-3">
                                                <label class="form-check-label" for="management">
                                                    <input class="form-check-input required-field" type="radio" name="company"
                                                        id="transfer_management" value="1" checked onclick="toggleDivs()"/>
                                                    Management
                                                </label>
                                            </div>
                                            <div class="form-check form-check-inline mb-3">
                                                <label class="form-check-label" for="business">
                                                    <input class="form-check-input required-field" type="radio" name="company"
                                                        id="transfer_business" value="2"  onclick="toggleDivs()"/>
                                                    Business
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div ">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_company" name="transfer_company" class="select3 form-select transfer-field">
                                            <option value="">Select Company Name</option>
                                                @if(isset($company_list))
                                                @foreach($company_list as $clist)
                                                <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                                @endforeach
                                                @endif
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_entity" name="transfer_entity" class="select3 form-select transfer-field">
                                            <option value="">Select Entity Name</option>
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3 business_div">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_branch" name="transfer_branch" class="select3 form-select transfer-field">
                                            <option value="">Select Branch</option>
                                        </select>
                                        <div class="text-danger error_msg"></div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_department" id="transfer_department" class="select3 form-select transfer-field">
                                                <option value="">Select Department</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Division<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_division" id="transfer_division" class="select3 form-select transfer-field">
                                                <option value="">Select Division</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_job_role" id="transfer_job_role" class="select3 form-select transfer-field" onchange="triggerTransferPreview()">
                                                <option value="">Select Job Role</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">User Role<span
                                                class="text-danger">*</span></label>
                                        <div class="">
                                            <select name="transfer_role" id="transfer_role" class="select3 form-select transfer-field" onchange="triggerTransferPreview()">
                                                <option value="">Select User Role</option>
                                            </select>
                                            <div class="text-danger error_msg"></div>
                                        </div>
                                    </div>

                                
                                        
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Transfer Reason <span
                                                class="text-danger">*</span></label>
                                        <select id="transfer_reason" name="transfer_reason" class="select3 form-select transfer-field"
                                            onchange="toggleInputField_tranfer(this.value)">
                                            <option value="">Select Reason</option>
                                            @if (isset($exitReason) && count($exitReason) > 0)
                                            @foreach ($exitReason as $s_reason)
                                            @if($s_reason->exit_type == 8)
                                            <option value="{{ $s_reason->sno }}"
                                                data-comments-check="{{ $s_reason->comments_check }}">
                                                {{ $s_reason->reason_name }}
                                            </option>
                                            @endif
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <div class="" id="transfer_comments_div" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments </label>
                                            <input type="text" class="form-control" name="transfer_comments_text"
                                                id="transfer_comments_text" value="" placeholder="Enter Comments"
                                                oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                        </div>
                                    </div>
                                        
                                    
                                
                                </div>
                            </div>
                        </div>

                        <!-- Summary -->
                        <div id="transferSummaryCard" class="mt-5"></div>
                    

                        <div class="d-flex justify-content-end my-3">
                            <button type="button" id="btnTransferStaff"  onclick="transferStaff()" class="btn btn-primary btn-lg px-10">
                                <i class="mdi mdi-transit-transfer"></i>
                                Transfer Staff
                            </button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<div class="modal fade" id="kt_modal_view_staff" tabindex="-1" aria-labelledby="staffProfileModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-fullscreen-xl-down modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content staff-profile-modal">
            <div id="staffViewLoadingOverlay" class="staff-loading-overlay">
                <div class="staff-loading-content">
                    <div class="spinner-border text-primary mb-4"
                         style="width: 3rem; height: 3rem;"
                         role="status">
                    </div>
                    <h5 class="fw-bold mb-1">Loading Employee Profile</h5>
                    <p class="text-muted mb-0">Retrieving employee information...</p>
                </div>
            </div>
            <div id="staffViewErrorState" class="staff-error-state d-none">
                <div class="text-center px-5">
                    <div class="staff-error-icon mx-auto mb-4">
                        <i class="mdi mdi-alert-circle-outline"></i>
                    </div>
                    <h4 class="fw-bold text-gray-900 mb-2">
                        Unable to load employee profile
                    </h4>
                    <p class="text-muted mb-5" id="staffViewErrorMessage">
                        Something went wrong while retrieving the employee information.
                    </p>
                    <button type="button" class="btn btn-primary" id="staffViewRetryBtn">
                        <i class="mdi mdi-refresh me-1"></i>Try Again
                    </button>
                    <button type="button" class="btn btn-light ms-2" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
            <div id="staffViewContent">
                <div class="staff-profile-header">
                    <div class="staff-header-bg"></div>
                    <button type="button"
                            class="staff-modal-close"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                        <i class="mdi mdi-close"></i>
                    </button>
                    <div class="staff-profile-header-content">
                        <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-5">
                            {{-- LEFT PROFILE --}}
                            <div class="d-flex align-items-center gap-4 min-w-0">

                                {{-- PROFILE IMAGE --}}
                                <div class="position-relative flex-shrink-0">
                                    <div class="staff-profile-avatar skeleton-target">
                                        <img id="viewStaffProfileImage" src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="Employee" onerror="this.src='{{ asset('assets/egc_images/auth/user_2.png') }}'">
                                    </div>
                                    <span id="viewStaffStatusIndicator"  class="staff-status-indicator bg-success">
                                    </span>
                                </div>

                                {{-- PROFILE DETAILS --}}
                                <div class="min-w-0">
                                    {{-- SKELETON --}}
                                    <div class="staff-header-skeleton staff-skeleton-group">
                                        <div class="staff-skeleton sk-name mb-3"></div>
                                        <div class="staff-skeleton sk-position mb-3"></div>
                                        <div class="d-flex gap-2">
                                            <div class="staff-skeleton sk-badge"></div>
                                            <div class="staff-skeleton sk-badge"></div>
                                        </div>
                                    </div>

                                    {{-- REAL DATA --}}
                                    <div class="staff-view-data d-none">
                                        <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                                            <h2 id="viewStaffName" class="staff-profile-name mb-0 text-truncate">-</h2>
                                            <span id="viewStaffEmploymentBadge"
                                                  class="badge bg-label-success">
                                                Active
                                            </span>
                                        </div>
                                        <div class="staff-profile-position mb-3">
                                            <span id="viewStaffJobRole">-</span>
                                            <span class="staff-dot-separator"></span>
                                            <span id="viewStaffDepartment">-</span>
                                        </div>
                                        <div class="d-flex flex-wrap gap-2">
                                            <span class="staff-meta-badge">
                                                <i class="mdi mdi-card-account-details-outline"></i>
                                                <span id="viewStaffEmployeeId">-</span>
                                            </span>
                                            <span class="staff-meta-badge">
                                                <i class="mdi mdi-domain"></i>
                                                <span id="viewStaffCompany">-</span>
                                            </span>
                                            <span class="staff-meta-badge">
                                                <i class="mdi mdi-calendar-check-outline"></i>
                                                Joined
                                                <span id="viewStaffJoiningDate">-</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- RIGHT HEADER SUMMARY --}}
                            <div class="staff-header-actions">
                                <div class="staff-profile-completion-card">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="staff-completion-circle"
                                             id="viewStaffCompletionCircle"
                                             style="--progress: 0">
                                            <span id="viewStaffCompletionPercentage">
                                                0%
                                            </span>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-gray-900">
                                                Profile Completion
                                            </div>
                                            <div class="fs-8 text-muted">
                                                Employee information coverage
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown">
                                    <button type="button"
                                            class="btn btn-icon btn-light btn-sm"
                                            data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-4"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                        <li>
                                            <button class="dropdown-item"
                                                    type="button"
                                                    onclick="window.print()">
                                                <i class="mdi mdi-printer-outline me-2"></i>
                                                Print Profile
                                            </button>
                                        </li>
                                        <li>
                                            <button class="dropdown-item"
                                                    type="button"
                                                    id="staffViewRefreshBtn">
                                                <i class="mdi mdi-refresh me-2"></i>
                                                Refresh Profile
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        {{-- QUICK CONTACT SUMMARY --}}
                        <div class="staff-quick-info-row">
                            <div class="staff-quick-info">
                                <div class="staff-quick-icon">
                                    <i class="mdi mdi-email-outline"></i>
                                </div>
                                <div class="min-w-0">
                                    <span>Email Address</span>
                                    <a href="#" id="viewStaffEmailLink" target="_blank" rel="noopener noreferrer" class="staff-quick-value text-truncate text-black">
                                        <span id="viewStaffEmail" class="text-black">-</span>
                                    </a>
                                </div>
                            </div>
                            <div class="staff-quick-info">
                                <div class="staff-quick-icon">
                                    <i class="mdi mdi-phone-outline"></i>
                                </div>
                                <div>
                                    <span>Mobile Number</span>
                                    <a href="#" id="viewStaffMobileLink" target="_blank" rel="noopener noreferrer"
                                       class="staff-quick-value text-black">
                                        <span id="viewStaffMobile" class="text-black">-</span>
                                    </a>
                                </div>
                            </div>
                            <div class="staff-quick-info">
                                <div class="staff-quick-icon">
                                    <i class="mdi mdi-briefcase-outline"></i>
                                </div>
                                <div>
                                    <span>Employment Type</span>
                                    <strong id="viewStaffExperienceType"
                                            class="staff-quick-value">
                                        -
                                    </strong>
                                </div>
                            </div>
                            <div class="staff-quick-info">
                                <div class="staff-quick-icon">
                                    <i class="mdi mdi-account-key-outline"></i>
                                </div>
                                <div>
                                    <span>Login Access</span>
                                    <strong id="viewStaffLoginAccess"
                                            class="staff-quick-value">
                                        -
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- =================================================
                    NAVIGATION TABS
                ================================================== --}}
                <div class="staff-profile-navigation">
                    <div class="staff-tabs-scroll">
                        <ul class="nav staff-profile-tabs"
                            id="staffProfileTabs"
                            role="tablist">
                            <li class="nav-item">
                                <button class="nav-link active"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffOverviewTab"
                                        type="button">
                                    <i class="mdi mdi-view-dashboard-outline"></i>
                                    <span>Overview</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffPersonalTab"
                                        type="button">
                                    <i class="mdi mdi-account-outline"></i>
                                    <span>Personal</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffFamilyTab"
                                        type="button">
                                    <i class="mdi mdi-account-group-outline"></i>
                                    <span>Family</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffContactTab"
                                        type="button">
                                    <i class="mdi mdi-map-marker-outline"></i>
                                    <span>Contact</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffEmploymentTab"
                                        type="button">
                                    <i class="mdi mdi-office-building-outline"></i>
                                    <span>Employment</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffExperienceTab"
                                        type="button">
                                    <i class="mdi mdi-briefcase-clock-outline"></i>
                                    <span>Experience</span>
                                    <span class="badge staff-tab-count"
                                          id="viewStaffWorkCount">
                                        0
                                    </span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffEducationTab"
                                        type="button">
                                    <i class="mdi mdi-school-outline"></i>
                                    <span>Education</span>
                                    <span class="badge staff-tab-count"
                                          id="viewStaffEducationCount">
                                        0
                                    </span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffAccessTab"
                                        type="button">
                                    <i class="mdi mdi-shield-account-outline"></i>
                                    <span>Access</span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffDocumentsTab"
                                        type="button">
                                    <i class="mdi mdi-file-document-multiple-outline"></i>
                                    <span>Documents</span>
                                    <span class="badge staff-tab-count"
                                          id="viewStaffDocumentCount">
                                        0
                                    </span>
                                </button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link"
                                        data-bs-toggle="tab"
                                        data-bs-target="#staffChecklistTab"
                                        type="button">
                                    <i class="mdi mdi-clipboard-check-outline"></i>
                                    <span>Checklist</span>
                                </button>
                            </li>
                            @if($auth_role_id == 1)
                            <li class="nav-item">
                                <button
                                    class="nav-link"
                                    id="staffSalaryPayrollTabBtn"
                                    data-bs-toggle="tab"
                                    data-bs-target="#staffSalaryPayrollTab"
                                    type="button"
                                    role="tab"
                                    aria-controls="staffSalaryPayrollTab"
                                    aria-selected="false">
                                    <span class="staff-tab-icon">
                                        <i class="mdi mdi-cash-multiple"></i>
                                    </span>
                                    <span>Salary & Payroll</span>
                                    <span class="badge badge-light-primary ms-2 d-none" id="staffSalaryPendingBadge">
                                        0
                                    </span>
                                </button>
                            </li>
                            @endif
                        </ul>
                    </div>
                </div>

                {{-- =================================================
                    TAB CONTENT
                ================================================== --}}
                <div class="modal-body staff-profile-body">
                    <div class="tab-content">
                        {{-- =================================================
                            1. OVERVIEW
                        ================================================== --}}
                        <div class="tab-pane fade show active" id="staffOverviewTab">
                            <div class="row g-5">
                                {{-- LEFT --}}
                                <div class="col-xl-8">
                                    <div class="staff-section-card mb-5">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-account-box-outline"></i>
                                                    Employee Summary
                                                </h5>
                                                <p>
                                                    Key employee and organizational information
                                                </p>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="row g-4">
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Employee ID
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="staff_id">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Full Name
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="staff_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Company Type
                                                        </span>
                                                        <span class="staff-info-value"
                                                              id="overviewCompanyType">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Company / Entity
                                                        </span>
                                                        <span class="staff-info-value"
                                                              id="overviewCompanyEntity">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Department
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="department_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Division
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="division_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Job Role
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="job_role_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            System Role
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="role_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Date of Joining
                                                        </span>
                                                        <span class="staff-info-value staff-date"
                                                              data-staff-field="date_of_joining">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Experience Type
                                                        </span>
                                                        <span class="staff-info-value"
                                                              id="overviewExperienceType">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {{-- DESCRIPTION --}}
                                    <!-- <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-text-box-outline"></i>
                                                    Employee Description
                                                </h5>
                                                <p>
                                                    Additional notes and employee profile summary
                                                </p>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <p class="staff-description mb-0"
                                               data-staff-field="description">
                                                No description available.
                                            </p>
                                        </div>
                                    </div> -->
                                </div>

                                {{-- RIGHT --}}
                                <div class="col-xl-4">
                                    {{-- CONTACT CARD --}}
                                    <div class="staff-section-card mb-5">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-card-account-phone-outline"></i>
                                                    Quick Contact
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="staff-contact-line">
                                                <div class="staff-contact-icon">
                                                    <i class="mdi mdi-email-outline"></i>
                                                </div>
                                                <div class="min-w-0">
                                                    <span>Email</span>
                                                    <strong class="text-break"
                                                            data-staff-field="email_id">
                                                        -
                                                    </strong>
                                                </div>
                                            </div>
                                            <div class="staff-contact-line">
                                                <div class="staff-contact-icon">
                                                    <i class="mdi mdi-phone-outline"></i>
                                                </div>
                                                <div>
                                                    <span>Mobile</span>
                                                    <strong data-staff-field="mobile_no">
                                                        -
                                                    </strong>
                                                </div>
                                            </div>
                                            <div class="staff-contact-line">
                                                <div class="staff-contact-icon">
                                                    <i class="mdi mdi-phone-plus-outline"></i>
                                                </div>
                                                <div>
                                                    <span>Alternate Number</span>
                                                    <strong data-staff-field="alternative_no">
                                                        -
                                                    </strong>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    {{-- SKILLS --}}
                                    <div class="staff-section-card">

                                        <div class="staff-section-header">

                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-lightbulb-outline"></i>
                                                    Skills & Knowledge
                                                </h5>
                                            </div>

                                        </div>

                                        <div class="staff-section-body">

                                            <div id="viewStaffSkillsContainer"
                                                 class="d-flex flex-wrap gap-2">

                                                <span class="text-muted fs-7">
                                                    No skills available
                                                </span>

                                            </div>

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>

                        {{-- ================================================================
                            SALARY & PAYROLL TAB
                        ================================================================ --}}
                        <div class="tab-pane fade" id="staffSalaryPayrollTab" role="tabpanel" aria-labelledby="staffSalaryPayrollTabBtn">

                            {{-- ============================================================
                                MAIN WRAPPER
                            ============================================================ --}}
                            <div id="staffSalaryPayrollWrapper" class="position-relative">

                                {{-- ========================================================
                                    SALARY ERROR STATE
                                ======================================================== --}}
                                <div id="staffSalaryPayrollError" class="d-none">
                                    <div class="border border-dashed border-danger rounded-3 bg-light-danger p-8 text-center">
                                        <div class="d-flex align-items-center justify-content-center mx-auto mb-4 rounded-circle bg-danger text-white"
                                            style="width: 55px; height: 55px;">
                                            <i class="mdi mdi-alert-circle-outline fs-2"></i>
                                        </div>
                                        <h5 class="fw-bold text-gray-900 mb-2">
                                            Unable to Load Salary Information
                                        </h5>
                                        <p class="text-muted fs-7 mb-5" id="staffSalaryPayrollErrorMessage">
                                            Something went wrong while loading salary and payroll details.
                                        </p>
                                        <button type="button" class="btn btn-sm btn-primary" id="staffSalaryPayrollRetryBtn">
                                            <i class="mdi mdi-refresh me-1"></i>
                                            Retry
                                        </button>
                                    </div>
                                </div>

                                {{-- ========================================================
                                    SKELETON LOADER
                                ======================================================== --}}
                                <div id="staffSalaryPayrollSkeleton">
                                    {{-- Summary skeleton --}}
                                    <div class="row g-4 mb-6">
                                        @for ($i = 0; $i < 4; $i++)
                                            <div class="col-sm-6 col-xl-3">
                                                <div class="staff-payroll-summary-card">
                                                    <div class="staff-skeleton staff-skeleton-circle mb-3"></div>
                                                    <div class="staff-skeleton staff-skeleton-text-sm mb-2"></div>
                                                    <div class="staff-skeleton staff-skeleton-text-lg"></div>
                                                </div>
                                            </div>
                                        @endfor
                                    </div>

                                    {{-- Structure skeleton --}}
                                    <div class="staff-payroll-panel mb-6">
                                        <div class=" d-flex justify-content-between align-items-center mb-5 ">
                                            <div>
                                                <div class="staff-skeleton staff-skeleton-text-lg mb-2"></div>
                                                <div class="staff-skeleton staff-skeleton-text-sm"></div>
                                            </div>
                                            <div class="staff-skeleton" style="width: 160px; height: 38px;"></div>
                                        </div>

                                        <div class="row g-4">
                                            @for ($i = 0; $i < 6; $i++)
                                                <div class="col-md-6">
                                                    <div class="staff-skeleton" style="height: 58px;" ></div>
                                                </div>
                                            @endfor
                                        </div>
                                    </div>

                                    {{-- History skeleton --}}
                                    <div class="staff-payroll-panel">
                                        @for ($i = 0; $i < 4; $i++)
                                            <div class="d-flex align-items-center gap-4 py-4 border-bottom">
                                                <div class="staff-skeleton staff-skeleton-circle"></div>
                                                <div class="flex-grow-1">
                                                    <div class="staff-skeleton staff-skeleton-text-lg mb-2"></div>
                                                    <div class="staff-skeleton staff-skeleton-text-sm"></div>
                                                </div>
                                            </div>
                                        @endfor
                                    </div>
                                </div>

                                {{-- ========================================================
                                    ACTUAL SALARY CONTENT
                                ======================================================== --}}
                                <div id="staffSalaryPayrollContent" class="d-none" >
                                    {{-- ====================================================
                                        SALARY HEADER
                                    ==================================================== --}}
                                    <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4 mb-6">
                                        <div>
                                            <div class="d-flex align-items-center gap-2 mb-1">
                                                <div class="staff-payroll-heading-icon">
                                                    <i class="mdi mdi-cash-multiple"></i>
                                                </div>
                                                <h4 class="fw-bold text-gray-900 mb-0">
                                                    Salary & Payroll
                                                </h4>
                                            </div>
                                            <p class="text-muted fs-7 mb-0">
                                                Salary structure, revisions and processed payroll history
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <button type="button" class="btn btn-sm btn-light-primary" id="staffSalaryPayrollRefreshBtn">
                                                <i class="mdi mdi-refresh me-1"></i>
                                                Refresh
                                            </button>
                                        </div>
                                    </div>

                                    {{-- ====================================================
                                        SUMMARY CARDS
                                    ==================================================== --}}
                                    <div class="row g-4 mb-6">
                                        {{-- Current Gross Salary --}}
                                        <div class="col-sm-6 col-xl-3">
                                            <div class=" staff-payroll-summary-card staff-payroll-summary-primary">
                                                <div class="staff-payroll-summary-top">
                                                    <div class="staff-payroll-summary-icon">
                                                        <i class="mdi mdi-wallet-outline"></i>
                                                    </div>
                                                    <span class="badge badge-light-primary">
                                                        Current
                                                    </span>
                                                </div>
                                                <span class="staff-payroll-summary-label">
                                                    Gross Salary
                                                </span>
                                                <h3 class="staff-payroll-summary-value" id="staffPayrollCurrentSalary">
                                                    ₹0
                                                </h3>
                                                <span class="staff-payroll-summary-caption" id="staffPayrollCurrentSalaryCaption">
                                                    Primary salary account
                                                </span>
                                            </div>
                                        </div>
                                        {{-- Salary Accounts --}}
                                        <div class="col-sm-6 col-xl-3">
                                            <div class="staff-payroll-summary-card">
                                                <div class="staff-payroll-summary-top">
                                                    <div class="staff-payroll-summary-icon bg-light-info text-info">
                                                        <i class="mdi mdi-bank-outline"></i>
                                                    </div>
                                                </div>
                                                <span class="staff-payroll-summary-label">
                                                    Salary Accounts
                                                </span>
                                                <h3 class="staff-payroll-summary-value" id="staffPayrollAccountCount" >
                                                    0
                                                </h3>
                                                <span class="staff-payroll-summary-caption">
                                                    Active salary accounts
                                                </span>
                                            </div>
                                        </div>
                                        {{-- Salary Revisions --}}
                                        <div class="col-sm-6 col-xl-3">
                                            <div class="staff-payroll-summary-card">
                                                <div class="staff-payroll-summary-top">
                                                    <div class="staff-payroll-summary-icon bg-light-warning text-warning">
                                                        <i class="mdi mdi-chart-timeline-variant"></i>
                                                    </div>
                                                </div>
                                                <span class="staff-payroll-summary-label">
                                                    Salary Revisions
                                                </span>
                                                <h3 class="staff-payroll-summary-value" id="staffPayrollRevisionCount" >
                                                    0
                                                </h3>
                                                <span class="staff-payroll-summary-caption" id="staffPayrollPendingCaption">
                                                    No pending revisions
                                                </span>
                                            </div>
                                        </div>

                                        {{-- Processed Payroll --}}
                                        <div class="col-sm-6 col-xl-3">
                                            <div class="staff-payroll-summary-card">
                                                <div class="staff-payroll-summary-top">
                                                    <div class="  staff-payroll-summary-icon bg-light-success text-success">
                                                        <i class="mdi mdi-check-decagram-outline"></i>
                                                    </div>
                                                </div>
                                                <span class="staff-payroll-summary-label">
                                                    Payroll Records
                                                </span>
                                                <h3 class="staff-payroll-summary-value" id="staffPayrollProcessedCount">
                                                    0
                                                </h3>
                                                <span class="staff-payroll-summary-caption">
                                                    Recent processed records
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    {{-- ====================================================
                                        INTERNAL SALARY SUB TABS
                                    ==================================================== --}}
                                    <div class="staff-payroll-panel">
                                        <div class="d-flex flex-column flex-xl-row align-items-xl-center justify-content-between gap-4 mb-6">
                                            <ul class="nav nav-pills staff-payroll-nav" id="staffPayrollInternalTabs">
                                                <li class="nav-item">
                                                    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#staffCurrentSalaryPane" type="button">
                                                        <i class="mdi mdi-cash-check me-1"></i>
                                                        Current Structure
                                                    </button>
                                                </li>
                                                <li class="nav-item">
                                                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#staffSalaryHistoryPane" type="button">
                                                        <i class="mdi mdi-chart-timeline-variant me-1"></i>
                                                        Salary History
                                                    </button>
                                                </li>
                                                <li class="nav-item">
                                                    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#staffPayrollHistoryPane" type="button">
                                                        <i class="mdi mdi-receipt-text-clock-outline me-1"></i>
                                                        Payroll History
                                                    </button>
                                                </li>
                                            </ul>
                                            {{-- Salary Account Selector --}}
                                            <div class=" d-flex align-items-center gap-2" id="staffSalaryAccountSelectorWrapper">
                                                <span class="fs-8 fw-semibold text-muted text-nowrap">
                                                    Salary Account
                                                </span>
                                                <select class="form-select form-select-sm fw-semibold select3" id="staffSalaryAccountSelector" style="min-width: 210px;">
                                                </select>
                                            </div>
                                        </div>
                                        <div class="tab-content">
                                            {{-- ================================================
                                                CURRENT SALARY STRUCTURE
                                            ================================================ --}}
                                            <div class="tab-pane fade show active" id="staffCurrentSalaryPane">
                                                {{-- Structure Header --}}
                                                <div class="staff-current-structure-header mb-5">
                                                    <div class="row g-4 align-items-center">
                                                        <div class="col-lg-7">
                                                            <div class="d-flex align-items-start gap-3">
                                                                <div class="staff-payroll-account-icon">
                                                                    <i class="mdi mdi-bank-outline"></i>
                                                                </div>
                                                                <div>
                                                                    <div class="d-flex flex-wrap align-items-center gap-2 mb-1 ">
                                                                        <h5 class="fw-bold text-gray-900 mb-0" id="staffCurrentSalaryAccountName">
                                                                            -
                                                                        </h5>
                                                                        <span class="badge bg-label-success d-none" id="staffCurrentSalaryPrimaryBadge">
                                                                            Primary
                                                                        </span>
                                                                    </div>
                                                                    <div class="text-muted fs-7">
                                                                        Template:
                                                                        <span class="fw-semibold text-gray-700" id="staffCurrentSalaryTemplate">
                                                                            -
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-5">
                                                            <div class="d-flex flex-wrap justify-content-lg-end gap-4">
                                                                <div>
                                                                    <span class="staff-info-label">Effective From</span>
                                                                    <div class="staff-info-value" id="staffCurrentSalaryEffectiveFrom">
                                                                        -
                                                                    </div>
                                                                </div>
                                                                <div>
                                                                    <span class="staff-info-label">Effective To</span>
                                                                    <div class="staff-info-value" id="staffCurrentSalaryEffectiveTo">
                                                                        Present
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                {{-- Salary Calculation Summary --}}
                                                <div class="row g-4 mb-6">
                                                    <div class="col-sm-6 col-lg-3">
                                                        <div class="staff-salary-metric">
                                                            <span>Configured Gross</span>
                                                            <strong id="staffStructureGrossSalary">
                                                                ₹0
                                                            </strong>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3">
                                                        <div class="staff-salary-metric">
                                                            <span>Total Earnings</span>
                                                            <strong class="text-success" id="staffStructureTotalEarnings">
                                                                ₹0
                                                            </strong>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3">
                                                        <div class="staff-salary-metric">
                                                            <span>Total Deductions</span>
                                                            <strong class="text-danger" id="staffStructureTotalDeductions">
                                                                ₹0
                                                            </strong>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3">
                                                        <div class="staff-salary-metric">
                                                            <span>Employer Contribution</span>
                                                            <strong class="text-primary" id="staffStructureEmployerContribution">
                                                                ₹0
                                                            </strong>
                                                        </div>
                                                    </div>
                                                </div>


                                                {{-- Component Breakdown --}}
                                                <div class="row g-5">
                                                    {{-- Earnings --}}
                                                    <div class="col-xl-4">
                                                        <div class="staff-component-section h-100">
                                                            <div class="staff-component-heading text-success">
                                                                <span>
                                                                    <i class="mdi mdi-plus-circle-outline me-1"></i>
                                                                    Earnings
                                                                </span>
                                                                <!-- <strong id="staffEarningsComponentCount"> 0</strong> -->
                                                            </div>
                                                            <div id="staffCurrentEarningsList" class="staff-component-list">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    {{-- Deductions --}}
                                                    <div class="col-xl-4">
                                                        <div class="staff-component-section h-100">
                                                            <div class="staff-component-heading text-danger">
                                                                <span>
                                                                    <i class="mdi mdi-minus-circle-outline me-1"></i>
                                                                    Deductions
                                                                </span>
                                                                <!-- <strong id="staffDeductionComponentCount"> 0</strong> -->
                                                            </div>
                                                            <div id="staffCurrentDeductionsList" class="staff-component-list">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {{-- Employer Contributions --}}
                                                    <div class="col-xl-4">
                                                        <div class="staff-component-section h-100 ">
                                                            <div class="staff-component-heading text-primary">
                                                                <span>
                                                                    <i class="mdi mdi-domain-plus me-1"></i>
                                                                    Employer Contribution
                                                                </span>
                                                                <!-- <strong id="staffEmployerComponentCount"> 0</strong> -->
                                                            </div>
                                                            <div id="staffCurrentEmployerList" class="staff-component-list" >
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                {{-- No Structure --}}
                                                <div id="staffCurrentSalaryEmpty" class="d-none" >
                                                    <div class="staff-empty-state">
                                                        <i class="mdi mdi-cash-remove"></i>
                                                        <h6>
                                                            No Active Salary Structure
                                                        </h6>
                                                        <p>
                                                            No active payroll structure is configured
                                                            for this salary account.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- ================================================
                                                SALARY REVISION HISTORY
                                            ================================================ --}}
                                            <div  class="tab-pane fade" id="staffSalaryHistoryPane">
                                                <div class="d-flex align-items-center justify-content-between mb-5 " >
                                                    <div>
                                                        <h5 class="fw-bold text-gray-900 mb-1">
                                                            Salary Revision History
                                                        </h5>
                                                        <p class="text-muted fs-8 mb-0">
                                                            Appraisals and salary changes over time
                                                        </p>
                                                    </div>
                                                    <span class="badge badge-light-warning" id="staffSalaryHistoryPendingBadge">
                                                        0 Pending
                                                    </span>
                                                </div>
                                                <div id="staffSalaryHistoryTimeline" class="staff-salary-history-timeline">
                                                </div>
                                            </div>

                                            {{-- ================================================
                                                PAYROLL HISTORY
                                            ================================================ --}}
                                            <div class="tab-pane fade" id="staffPayrollHistoryPane" >
                                                <div class=" d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-5">
                                                    <div>
                                                        <h5 class="fw-bold text-gray-900 mb-1">
                                                            Processed Payroll History
                                                        </h5>
                                                        <p class="text-muted fs-8 mb-0">
                                                            Actual monthly payroll calculations
                                                        </p>
                                                    </div>
                                                    <div class="d-flex align-items-center gap-2">
                                                        <select class="form-select form-select-sm select3" id="staffPayrollYearFilter" style="width: 120px;">
                                                            <option value="">All Years</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="table-responsive staff-payroll-table-wrapper">
                                                    <table class=" table align-middle table-row-dashed gy-4">
                                                        <thead>
                                                            <tr class=" text-muted fw-semibold fs-8 text-uppercase bg-primary ">
                                                                <th>Month</th>
                                                                <th class="text-end">Gross</th>
                                                                <th class="text-end">Deductions</th>
                                                                <th class="text-end">LOP</th>
                                                                <th class="text-end">Net Payable</th>
                                                                <th class="text-center">Payslip</th>
                                                                <th class="text-center">Details</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="staffPayrollHistoryTableBody">
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div id="staffPayrollHistoryEmpty" class="d-none">
                                                    <div class="staff-empty-state">
                                                        <i class="mdi mdi-receipt-text-remove-outline"></i>
                                                        <h6>No Payroll History</h6>
                                                        <p>
                                                            No processed payroll records were found
                                                            for this employee.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        {{-- =================================================
                            2. PERSONAL INFORMATION
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffPersonalTab">
                            <div class="staff-section-card">
                                <div class="staff-section-header">
                                    <div>
                                        <h5>
                                            <i class="mdi mdi-account-details-outline"></i>
                                            Personal Information
                                        </h5>
                                        <p>
                                            Identity, demographic and personal details
                                        </p>
                                    </div>
                                </div>
                                <div class="staff-section-body">
                                    <div class="row g-4">
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Full Name
                                                </span>
                                                <span class="staff-info-value" data-staff-field="staff_name">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Nick / Pseudo Name
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="nick_name">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Gender
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalGender">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Date of Birth
                                                </span>
                                                <span class="staff-info-value staff-date"
                                                      data-staff-field="dob">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Birth Place
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="birth_place">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Blood Group
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalBloodGroup">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Height
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="height">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Weight
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="weight">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Nationality
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalNationality">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Religion
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalReligion">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Community
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalCommunity">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Caste
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="caste">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Mother Tongue
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="mother_tongue">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Marital Status
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalMaritalStatus">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-4">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Anniversary Date
                                                </span>
                                                <span class="staff-info-value staff-date"
                                                      data-staff-field="anniversary_date">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Identification Mark
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="identification_mark">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="staff-inner-divider"></div>
                                    <div class="row g-5">
                                        <div class="col-lg-6">
                                            <h6 class="staff-subsection-title">
                                                <i class="mdi mdi-translate"></i>
                                                Languages Known
                                            </h6>
                                            <div id="viewStaffLanguagesContainer"
                                                 class="d-flex flex-wrap gap-2">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <h6 class="staff-subsection-title">
                                                <i class="mdi mdi-heart-outline"></i>
                                                Hobbies
                                            </h6>
                                            <div id="viewStaffHobbiesContainer"
                                                 class="d-flex flex-wrap gap-2">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="staff-inner-divider"></div>
                                    <h6 class="staff-subsection-title">
                                        <i class="mdi mdi-car-outline"></i>
                                        Driving & Vehicle Information
                                    </h6>
                                    <div class="row g-4">
                                        <div class="col-md-6 col-xl-3">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Vehicle Available
                                                </span>
                                                <span class="staff-info-value"
                                                      id="personalVehicleStatus">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-3">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Driving License
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="driving_license_no">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-3">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    Vehicle Registration
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="vehicle_register_no">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-xl-3">
                                            <div class="staff-info-item">
                                                <span class="staff-info-label">
                                                    License Expiry
                                                </span>
                                                <span class="staff-info-value staff-date"
                                                      data-staff-field="license_expiry">
                                                    -
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        {{-- =================================================
                            3. FAMILY
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffFamilyTab">
                            <div class="row g-5">
                                <div class="col-xl-6">
                                    <div class="staff-section-card h-100">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-human-male-female-child"></i>
                                                    Parent Details
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="row g-4">
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Father Name
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="father_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Father Occupation
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="father_occup">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Mother Name
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="mother_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Mother Occupation
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="mother_occup">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <div class="staff-section-card h-100">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-ring"></i>
                                                    Spouse Details
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="row g-4">
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Spouse Name
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="spouse_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Mobile
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="spouse_mobile">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Date of Birth
                                                        </span>
                                                        <span class="staff-info-value staff-date"
                                                              data-staff-field="spouse_dob">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Working Status
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="spouse_is_working">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Designation
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="spouse_designation">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Company
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="spouse_company_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {{-- CHILDREN --}}
                                <div class="col-12">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-account-child-outline"></i>
                                                    Children
                                                </h5>
                                                <p>
                                                    Registered children information
                                                </p>
                                            </div>
                                            <span class="badge badge-light-primary" id="viewStaffChildrenCount">
                                                0
                                            </span>
                                        </div>
                                        <div class="staff-section-body"
                                             id="viewStaffChildrenContainer">
                                        </div>
                                    </div>
                                </div>

                                {{-- SIBLINGS --}}
                                <div class="col-12">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-account-multiple-outline"></i>
                                                    Siblings
                                                </h5>
                                                <p>Sibling information</p>
                                            </div>
                                            <span class="badge badge-light-primary"  id="viewStaffSiblingsCount">
                                                0
                                            </span>
                                        </div>
                                        <div class="staff-section-body" id="viewStaffSiblingsContainer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- =================================================
                            4. CONTACT
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffContactTab">
                            <div class="row g-5">
                                <div class="col-xl-7">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-map-marker-outline"></i>
                                                    Address Information
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="staff-address-card mb-4">
                                                <div class="staff-address-icon">
                                                    <i class="mdi mdi-home-map-marker"></i>
                                                </div>
                                                <div>
                                                    <span>Permanent Address</span>
                                                    <p data-staff-field="address">
                                                        -
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="staff-address-card mb-4">
                                                <div class="staff-address-icon">
                                                    <i class="mdi mdi-home-city-outline"></i>
                                                </div>
                                                <div>
                                                    <span>Residential Address</span>
                                                    <p data-staff-field="residential_address">
                                                        -
                                                    </p>
                                                </div>
                                            </div>
                                            <div id="viewStaffLocationAction" class="d-none">
                                                <a href="#" id="viewStaffLocationLink" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-light-primary">
                                                    <i class="mdi mdi-map-marker-radius-outline me-1"></i>
                                                    View Location
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-5">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-phone-alert-outline"></i>
                                                    Emergency Contacts
                                                </h5>
                                                <p>
                                                    People to contact in an emergency
                                                </p>
                                            </div>
                                        </div>
                                        <div class="staff-section-body"
                                             id="viewStaffEmergencyContacts">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-share-variant-outline"></i>
                                                    Social Profiles
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body"
                                             id="viewStaffSocialMediaContainer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- =================================================
                            5. EMPLOYMENT
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffEmploymentTab">
                            <div class="row g-5">
                                <div class="col-xl-8">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-office-building-outline"></i>
                                                    Organization Details
                                                </h5>
                                                <p>
                                                    Current organizational assignment
                                                </p>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="row g-4">
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Company Type
                                                        </span>
                                                        <span class="staff-info-value"
                                                              id="employmentCompanyType">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Company
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="company_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Entity
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="entity_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Department
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="department_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Division
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="division_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Job Position
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="job_role_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            User Role
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="role_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Employee ID
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="staff_id">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Nick Name
                                                        </span>
                                                        <span class="staff-info-value"
                                                              data-staff-field="nick_name">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="staff-info-item">
                                                        <span class="staff-info-label">
                                                            Date of Joining
                                                        </span>
                                                        <span class="staff-info-value staff-date"
                                                              data-staff-field="date_of_joining">
                                                            -
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {{-- SALARY SUMMARY --}}
                                <div class="col-xl-4">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-cash-multiple"></i>
                                                    Compensation
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="staff-salary-item">
                                                <span>Basic Salary</span>
                                                <strong id="viewStaffBasicSalary">-</strong>
                                            </div>
                                            <div class="staff-salary-item">
                                                <span>Per Day Salary</span>
                                                <strong id="viewStaffPerDaySalary">-</strong>
                                            </div>
                                            <div class="staff-salary-item">
                                                <span>Per Hour Cost</span>
                                                <strong id="viewStaffPerHourCost">-</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {{-- SKILLS --}}
                                <div class="col-12">
                                    <div class="staff-section-card">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-tag-multiple-outline"></i>
                                                    Skill Tags
                                                </h5>
                                            </div>
                                        </div>
                                        <div class="staff-section-body">
                                            <div id="viewStaffEmploymentSkills"
                                                 class="d-flex flex-wrap gap-2">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {{-- =================================================
                            6. EXPERIENCE
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffExperienceTab">
                            <div class="staff-section-card">
                                <div class="staff-section-header">
                                    <div>
                                        <h5>
                                            <i class="mdi mdi-briefcase-clock-outline"></i>
                                            Work Experience
                                        </h5>
                                        <p>
                                            Previous employment history and professional experience
                                        </p>
                                    </div>
                                    <div class="d-flex gap-2">
                                        <span class="badge badge-light-primary">
                                            Type:
                                            <span id="experienceTypeBadge">-</span>
                                        </span>
                                        <span class="badge badge-light-info">
                                            Total:
                                            <span id="experienceTotalYears">-</span>
                                        </span>
                                    </div>
                                </div>
                                <div class="staff-section-body">
                                    <div id="staffCurrentExperienceCard" class="staff-current-experience-card d-none mb-6">
                                        <div class="row align-items-center g-4">
                                            <div class="col-lg-7">
                                                <div class="d-flex align-items-start gap-3">
                                                    <div class="staff-current-experience-icon">
                                                        <i class="mdi mdi-briefcase-check-outline"></i>
                                                    </div>
                                                    <div>
                                                        <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                                                            <h5 class="fw-bold text-gray-900 mb-0" id="staffCurrentExperienceCompany">
                                                                -
                                                            </h5>
                                                            <span class="badge bg-label-success">
                                                                Currently Working
                                                            </span>
                                                        </div>
                                                        <div class="fw-semibold text-gray-700 fs-7 mb-1" id="staffCurrentExperienceRole">
                                                            -
                                                        </div>
                                                        <div class="text-muted fs-8" id="staffCurrentExperienceDepartment">
                                                            -
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="staff-current-experience-duration">
                                                    <span class="staff-info-label">
                                                        Current Experience
                                                    </span>
                                                    <strong id="staffCurrentExperienceDuration" class="d-block text-primary fs-5">
                                                        -
                                                    </strong>
                                                    <span id="staffCurrentExperiencePeriod" class="text-muted fs-8">
                                                        -
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="viewStaffWorkTimeline" class="staff-timeline">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- =================================================
                            7. EDUCATION
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffEducationTab">
                            <div class="staff-section-card">
                                <div class="staff-section-header">
                                    <div>
                                        <h5>
                                            <i class="mdi mdi-school-outline"></i>
                                            Education & Qualifications
                                        </h5>
                                        <p>
                                            Academic history and completed qualifications
                                        </p>
                                    </div>
                                </div>
                                <div class="staff-section-body">
                                    <div id="viewStaffEducationTimeline"class="staff-timeline">
                                    </div>
                                    <div class="staff-inner-divider"></div>
                                    <h6 class="staff-subsection-title">
                                        <i class="mdi mdi-certificate-outline"></i>
                                        Course Tags
                                    </h6>
                                    <div id="viewStaffCourseTags" class="d-flex flex-wrap gap-2">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- =================================================
                            8. LOGIN & CREDENTIAL ACCESS
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffAccessTab">
                            <div class="row g-5">
                                {{-- ERP LOGIN --}}
                                <div class="col-xl-5">
                                    <div class="staff-section-card h-100">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-shield-account-outline"></i>
                                                    ERP Login Access
                                                </h5>
                                                <p>
                                                    Employee system authentication details
                                                </p>
                                            </div>
                                            <span id="viewStaffLoginStatusBadge"  class="badge badge-light-secondary">
                                                -
                                            </span>
                                        </div>
                                        <div class="staff-section-body">
                                            <div class="staff-info-item mb-4">
                                                <span class="staff-info-label">
                                                    Username
                                                </span>
                                                <span class="staff-info-value"  data-staff-field="user_name">
                                                    -
                                                </span>
                                            </div>
                                            <div class="staff-info-item mb-4">
                                                <span class="staff-info-label">
                                                    User Role
                                                </span>
                                                <span class="staff-info-value"
                                                      data-staff-field="role_name">
                                                    -
                                                </span>
                                            </div>
                                            <input type="hidden" name="" id="view_staff_id_hidden">
                                            <input type="hidden" id="passwordSecuritySession">
                                            {{-- Do not display actual password --}}
                                            <!-- <div class="staff-security-notice">
                                                <i class="mdi mdi-shield-lock-outline"></i>
                                                <div>
                                                    <strong>
                                                        Password Protected
                                                    </strong>
                                                    <p>
                                                        Passwords are intentionally hidden for security.
                                                    </p>
                                                </div>
                                            </div> -->
                                            <div class="staff-security-notice">

                                                <i class="mdi mdi-shield-lock-outline"></i>

                                                <div class="flex-grow-1" id="passwordContainer">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <strong>
                                                                Password Protected
                                                            </strong>

                                                            <p>
                                                                Passwords are intentionally hidden for security.
                                                            </p>
                                                        </div>
                                                        <button type="button" class="btn btn-primary btn-sm" onclick="startPasswordReveal()">
                                                            <i class="mdi mdi-qrcode-scan"></i>
                                                        </button>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                {{-- OTHER CREDENTIALS --}}
                                <div class="col-xl-7">
                                    <div class="staff-section-card h-100">
                                        <div class="staff-section-header">
                                            <div>
                                                <h5>
                                                    <i class="mdi mdi-key-chain-variant"></i>
                                                    Other Credentials
                                                </h5>
                                                <p>
                                                    Additional service and platform access
                                                </p>
                                            </div>
                                        </div>
                                        <div class="staff-section-body"
                                             id="viewStaffCredentialsContainer">
                                        </div>
                                    </div>
                                </div>
                                <div id="passwordSecurityQrBox"  class="text-center mt-3"  style="display:none;">
                                    <hr>
                                    <h6>
                                        Scan QR using Security App
                                    </h6>
                                    <img id="passwordSecurityQrImage"  src=""  width="250">
                                    <p  id="passwordSecurityStatus" class="mt-2 text-muted">
                                    Waiting for scan...
                                    </p>
                                    <input  type="hidden" id="passwordSecuritySession">
                                </div>
                                <div id="passwordPinBox" class="mt-3" style="display:none;">
                                    <hr>
                                    <h6 class="text-center">Enter Security PIN</h6>
                                    <input  type="text" class="form-control text-center"  id="securityPin"  maxlength="6" placeholder="Enter PIN">
                                    <div class="text-center mt-2">
                                        <button
                                            type="button"
                                            class="btn btn-success"
                                            onclick="verifySecurityPin()">
                                            Verify PIN
                                        </button>
                                    </div>
                                    <div  id="securityPinMessage" class="text-center mt-2"></div>
                                </div>
                            </div>
                        </div>
                        {{-- =================================================
                            9. DOCUMENTS
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffDocumentsTab">
                            <div class="staff-section-card">
                                <div class="staff-section-header">
                                    <div>
                                        <h5>
                                            <i class="mdi mdi-file-document-multiple-outline"></i>
                                            Employee Documents
                                        </h5>
                                        <p>
                                            Uploaded employee documents and attachments
                                        </p>
                                    </div>
                                </div>
                                <div class="staff-section-body">
                                    <div class="row g-4" id="viewStaffDocumentsContainer">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- =================================================
                            10. CHECKLIST
                        ================================================== --}}
                        <div class="tab-pane fade" id="staffChecklistTab">
                            <div class="staff-section-card">
                                <div class="staff-section-header">
                                    <div>
                                        <h5>
                                            <i class="mdi mdi-clipboard-check-outline"></i>
                                            Staff Document Checklist
                                        </h5>
                                        <p>
                                            Required HR documentation completion status
                                        </p>
                                    </div>
                                    <div class="staff-checklist-progress">
                                        <span id="viewStaffChecklistProgressText">
                                            0 / 0 Completed
                                        </span>
                                    </div>
                                </div>
                                <div class="staff-section-body">
                                    <div class="progress staff-checklist-progressbar mb-5">
                                        <div id="viewStaffChecklistProgressBar"
                                             class="progress-bar"
                                             role="progressbar"
                                             style="width: 0%">
                                        </div>
                                    </div>
                                    <div class="row g-3"
                                         id="viewStaffChecklistContainer">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- =================================================
                    MODAL FOOTER
                ================================================== --}}
                <div class="staff-profile-footer">
                    <!-- <div class="text-muted fs-8">
                        <i class="mdi mdi-information-outline me-1"></i>
                        Employee information is displayed based on available HR records.
                    </div> -->
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                        <i class="mdi mdi-close me-1"></i>
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="kt_modal_staff_assign_assets" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class="d-flex align-items-center gap-1">
                        <div class="">
                            <i class="mdi mdi-transit-transfer text-dark fs-1"></i>
                        </div>

                        <div>
                            <h2 class="fw-bold text-dark mb-1">
                              Assign Assets
                            </h2>
                        </div>

                    </div>
                </div>
                <div class=" mb-3">
                    
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div id="staffCurrentlyAssignedAssetsSection" class="mb-7 d-none">
                    <div class=" d-flex align-items-center justify-content-between mb-4">
                        <div>
                            <h4 class="fw-bold text-gray-900 mb-1">
                                Currently Assigned
                            </h4>
                            <div class="text-muted fs-7">
                                Assets currently held by this employee.
                            </div>
                        </div>
                        <span class="badge badge-light-primary fs-7" id="staffAssignedAssetCount">
                            0 Assets
                        </span>
                    </div>
                    <div id="staffCurrentlyAssignedAssets" class="row g-3">
                        <!-- Rendered dynamically -->
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<script>
    function open_update_staffId() {
        loadCompanyStaff(0);
    }

    // CLICK COMPANY TAB
    $(document).on("click", ".company-tab", function() {
        let companyId = $(this).data("company");
        loadCompanyStaff(companyId);
    });

    // COMMON FUNCTION TO LOAD STAFF
    function loadCompanyStaff(companyId) {

        $("#companyStaffList").html(`
        <div class="text-center py-5">
            <div class="spinner-border"></div>
            <p>Loading staff...</p>
        </div>
    `);

        $.ajax({
            url: "/get-company-staff",
            type: "GET",
            data: {
                company_id: companyId
            },
            success: function(res) {

                // RENDER STAFF TABLE HTML COMING FROM BACKEND
                $("#companyStaffList").html(res.staff_html);

                // Show Bulk Update button when list loads
                $("#bulkUpdateContainer").show();
            }
        });
    }

    // BULK UPDATE BUTTON CLICK
    $("#bulkUpdateBtn").on("click", function() {

        let updates = [];

        $("tr").each(function() {

            let sno = $(this).find(".staff-id-input").data("sno");

            if (!sno) return; // skip non-staff rows

            let staff_id = $(this).find(".staff-id-input").val();
            let timechamp_id = $(this).find(".staff-timechamp-id-input").val();

            updates.push({
                sno: sno,
                staff_id: staff_id,
                timechamp_id: timechamp_id
            });
        });

        $.ajax({
            url: "/bulk-update-staff-id",
            type: "POST",
            data: {
                _token: $("meta[name='csrf-token']").attr("content"),
                updates: updates
            },
            success: function(res) {
                toastr.success("Bulk Update Successful!");
                window.location.href = '/hr_enroll/manage_staff';
            }
        });
    });
</script>

<script>
    function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    // window.location.href = '/hr_enroll/manage_staff';
                    submitBtn.disabled = false;
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

<script>
    function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    let tableState = {
        currentPage: 1
    };

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function normalizeProfileCompletion(value) {
        const percentage = Number(value);
        if (!Number.isFinite(percentage)) {
            return 0;
        }
        return Math.max( 0, Math.min(100, Math.round(percentage)));
    }


    function getProfileCompletionMeta(percentage) {

        if (percentage >= 100) {
            return {
                className: 'staff-completion-success',
                label: 'Complete',
                icon: 'mdi-check-circle'
            };
        }

        if (percentage >= 75) {
            return {
                className: 'staff-completion-primary',
                label: 'Almost done',
                icon: 'mdi-progress-check'
            };
        }

        if (percentage >= 50) {
            return {
                className: 'staff-completion-warning',
                label: 'In progress',
                icon: 'mdi-progress-clock'
            };
        }

        if (percentage >= 25) {
            return {
                className: 'staff-completion-orange',
                label: 'Needs attention',
                icon: 'mdi-alert-circle-outline'
            };
        }

        return {
            className: 'staff-completion-danger',
            label: 'Incomplete',
            icon: 'mdi-alert-outline'
        };
    }


    function buildProfileCompletion(value) {

        const percentage = normalizeProfileCompletion(value);

        const meta = getProfileCompletionMeta(percentage);

        return `
            <div class=" staff-completion-wrapper ${meta.className}" data-bs-toggle="tooltip" data-bs-placement="top" title="Staff profile is ${percentage}% complete" >
                <div class="staff-completion-ring" style="--completion: ${percentage};" role="progressbar" aria-valuenow="${percentage}" aria-valuemin="0" aria-valuemax="100" aria-label="Profile completion ${percentage}%">
                    <div class="staff-completion-ring-center">
                        ${
                            percentage === 100
                                ? `
                                    <i class="mdi mdi-check staff-completion-check"></i>
                                `
                                : `
                                    <span class="staff-completion-value">${percentage}</span>
                                    <span class="staff-completion-percent">%</span>
                                `
                        }
                    </div>
                </div>
                <div class="staff-completion-info">
                    <div class="staff-completion-title">Profile</div>
                    <div class="staff-completion-status">
                        <i class="mdi ${meta.icon}"></i>
                        <span>${meta.label}</span>
                    </div>
                </div>
            </div>
        `;
    }

    function parseDOB(dateStr) {
            if (!dateStr) return null;

            dateStr = dateStr.trim();

            // Format: YYYY-MM-DD
            if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
                const [y, m, d] = dateStr.split('-').map(Number);
                return new Date(y, m - 1, d);
            }
            // Format: DD-MMM-YYYY
            if (/^\d{1,2}-[A-Za-z]{3}-\d{4}$/.test(dateStr)) {
                const months = {
                    Jan:0, Feb:1, Mar:2, Apr:3,
                    May:4, Jun:5, Jul:6, Aug:7,
                    Sep:8, Oct:9, Nov:10, Dec:11
                };

                const parts = dateStr.split('-');
                const day = parseInt(parts[0], 10);
                const month = months[parts[1]];
                const year = parseInt(parts[2], 10);
                if (month === undefined) return null;
                return new Date(year, month, day);
            }

            return null;
    }

     
    function calculateAge(date) {

        const dobString = date;
        const dob = parseDOB(dobString);
        if (!dob || isNaN(dob.getTime())) {
            return {
                status: false,
                message: 'Invalid Date of Birth'
            };
        }
        const today = new Date();
        if (dob > today) {
            return {
                status: false,
                message: 'DOB cannot be in the future'
            };
        }
        let years = today.getFullYear() - dob.getFullYear();
        let months = today.getMonth() - dob.getMonth();
        let days = today.getDate() - dob.getDate();

        if (days < 0) {
            months--;
            const previousMonth = new Date(
                today.getFullYear(),
                today.getMonth(),
                0
            ).getDate();
            days += previousMonth;
        }

        if (months < 0) {
            years--;
            months += 12;
        }
        return {
            status: true,
            years,
            months,
            days,
            text: `${years} Year${years !== 1 ? 's' : ''} ${months} Month${months !== 1 ? 's' : ''} ${days} Day${days !== 1 ? 's' : ''}`
        };
    }

    function fetch_staff_age(date){
        const age = calculateAge(date);
        if (age.status) {
            return (age.text);
        } else {
            return ('-');
        }
    }

    function buildRow(item, index) {

        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;

        let staff_image = '';
        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1 ?
                'assets/egc_images/auth/user_2.png' :
                'assets/egc_images/auth/user_7.png';
        }
        staff_image = `{{ asset('${staff_image}') }}`;

        return `
            <tr>
                <td style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || ''};"></div>
                    <div class="d-flex">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle">
                                <img src="${item.staffProfile}" 
                                    alt="user-avatar"  class="w-px-40 h-px-40 rounded-circle"
                                    id="uploadedlogo" onerror="this.onerror=null; this.src='{{ asset('assets/egc_images/auth/') }}' ${(item.gender == 1 ? 'user_2.png' : 'user_7.png')}"/>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label>
                                <span class="fs-7 me-1 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.staff_name}</span>
                                ${item.gender == 1 ?
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                        class="mdi mdi-face-man text-info"></i></span>`
                                 : 
                                    `<span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Female"><i
                                        class="mdi mdi-face-woman text-info"></i></span>`
                                }
                                
                            </label>
                            <span class="fs-8 me-1 d-block text-primary text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">${item.nick_name || '-'}</span>
                            <div class="d-flex  fs-8" style="color:rgb(114,57,234) !important;">
                                <a href="javascript:;" class=" fs-8" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Staff Nick Name" style="color:rgb(114,57,234) !important;">
                                    ${data.staff_id || '-'}
                                </a>
                                <div class="">
                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                        data-bs-toggle="dropdown" data-trigger="hover">
                                        <i class="ms-1 mdi mdi-information fs-9" style="color:rgb(114,57,234) !important;"></i>
                                    </a>
                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Mob No</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.mobile_no || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Email ID</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">${data.email_id || '-'}</div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">DOB</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                ${data.dob ? formatDateCommon(data.dob) : '-'}
                                                <span 
                                                    class="badge fs-8 bg-info" 
                                                    data-bs-toggle="tooltip" 
                                                    title="${data.dob ? getNextBDayDate(data.dob).full : '-'}">
                                                    ${data.dob ? getNextBDayDate(data.dob).short : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Age</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                <span  class="badge fs-7 bg-warning text-black rounded" data-bs-toggle="tooltip" 
                                                    title="${data.dob ? fetch_staff_age(data.dob) : '-'}">
                                                    ${data.dob ? fetch_staff_age(data.dob) : '-'}
                                                </span>
                                            </div>
                                        </div>
                                        <div class="mb-2 d-flex">
                                            <div class="fw-semibold w-30">Educational</div>
                                            <div class="mx-1">:</div>
                                            <div class="fw-bold">
                                            ${data.education && Array.isArray(data.education) && data.education.length > 0 ? data.education : '-'}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ${data.shift_time_id == 0 ? 
                        `<span class="mdi mdi-timer-alert-outline text-danger ms-1 fs-6 cursor-pointer" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Shift" onclick='openShiftAssign(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.shift_time_id}")'></span>`
                        :''
                        }
                    </div>
                </td>
                <td>
                    ${data.company_type == 1 ?
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold fs-7 text-truncate badge bg-label-danger d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>
                     </div>`
                    :
                    `<div class="d-flex align-items-start justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.company_name || '-'}">
                            ${data.company_name || '-'}
                        </label>

                        <label class="fw-semibold fs-7 text-truncate badge  d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px; background-color: ${item.company_base_color || ''};"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.entity_name || '-'}" >
                            ${data.entity_name || '-'}
                        </label>
                    </div>`
                    }
                </td>
                <td>
                    <div class="d-flex align-items-start justify-content-center flex-column gap-1">
                        <label class="fw-semibold text-black fs-7 text-truncate d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.department_name || '-'}">
                            ${data.department_name || '-'}
                        </label>
                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${data.division_name || '-'}">
                            ${data.division_name || '-'}
                        </label>
                        <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
                            <span class="fs-7">${data.job_role_name || '-'}</span>
                        </label>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-end justify-content-center flex-column">
                        <label class="fw-semibold text-black fs-7 d-block text-nowrap">
                           ${data.date_of_joining ? formatDateCommon(data.date_of_joining) : '-'}
                        </label>
                        <label class="badge bg-warning text-black fw-semibold fs-8 text-dark d-block text-nowrap">
                           ${data.date_of_joining ? getExperienceDuration(data.date_of_joining) : '0 Day'}
                        </label>
                    </div>
                    <div align="right">
                        <label class="badge bg-success text-white fw-bold mt-2 text-nowrap">
                            <span class="mdi mdi-currency-rupee text-white fw-bold fs-8"></span>
                            <span class="fs-7">${data.basic_salary ? new Intl.NumberFormat('en-IN').format(data.basic_salary) :'-'}</span>
                        </label>
                    </div>
                </td>
                <td align="left">
                    <div>
                        ${buildProfileCompletion(
                            data.completion_percentage
                        )}
                    </div>
                    
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                    
                </td>
                <td >
                    <span class="text-end">
                    
                        <a href="javascript:;" class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important;">
                        <a href="javascript:;"
                            class="dropdown-item"
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_send_profile_edit"
                            onclick="send_profile_edit('${item.encrypted_id}')">

                            <span>
                                <i class="mdi mdi-link-variant fs-4 text-black me-1"></i>
                                Send Profile Edit
                            </span>
                        </a>
                         ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_staff" onclick="viewStaff(${item.sno})">
                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i> View</span>
                            </a>`
                            :''}
                            <a href="{{ url('/hr_enroll/manage_staff/update_staff/${item.encrypted_id}')}}" class="dropdown-item">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                            </a>
                            <a href="{{ url('/employee/profile/${item.encrypted_id}')}}" class="dropdown-item">
                                <span><i
                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Profile Edit</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_profile_edit" onclick="send_profile_edit('${item.encrypted_id})">
                                <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Profile Edit</span>
                            </a>
                            <a href="javascript:void(0)" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_transferModel" onclick="openTransferModel(${item.sno})">
                                <span>
                                    <i class="mdi mdi-transit-transfer fs-4 text-primary me-2"></i>
                                    Transfer Staff
                                </span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#employeePayrollModal" onclick='openProfilePayroll(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.basic_salary}","${data.casual_leave_count_per_month}")'>
                                <span><i class="mdi mdi-account-credit-card fs-4 text-black me-1"></i>Update Account</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#employeeSalaryModal"  onclick='openEmployeeSalaryModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Update Salary</span>
                            </a>
                            <a href="javascript:void(0)" class="dropdown-item" onclick="openSalaryHistoryModal(${item.sno})">
                                <i class="mdi mdi-history fs-5 me-2"></i>
                                Appraisal History
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#monthlyInputModal"  onclick='openMonthlyInputModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Variable Amount</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openOTPayrollModal( ${item.sno},"${item.staff_name}"
                            )'>
                                <span>
                                    <i class="mdi mdi-clock-outline fs-4 text-black me-1"></i>
                                    OT Payroll
                                </span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openShiftAssign(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.shift_time_id}","${data.date_of_joining}","${data.shift_name || '-'}")' >
                                <span><i class="mdi mdi-clock-outline fs-4 text-black me-1"></i>Assign Shift</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" onclick='openSalaryAppraisal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}","${data.salary_log_id}","${data.date_of_joining}","${data.basic_salary || '-'}")' >
                                <span><i class="mdi mdi-cash-edit fs-4 text-black me-1"></i>Salary Appraisal</span>
                            </a>
                            
                            <a href="javascript:;" class="dropdown-item" onclick='openSalaryMappingModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${data.email_id || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-account-credit-card fs-4 text-black me-1"></i>Salary Mapping</span>
                            </a>

                            <a href="javascript:;" class="dropdown-item" onclick='openAppraisalSalaryHistoryModal(${item.sno},"${item.staff_name}","${data.mobile_no || '-'}","${staff_image}")'>
                                <span><i class="mdi mdi-cash-edit fs-4 text-warning me-1"></i><span class="text-black">Salary History</span></span>
                            </a>
                            
                            ${auth_user_id ==0 ?
                            `<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_exit_staff" onclick="existStaffModal(${item.sno})">
                                <span><i class="mdi mdi-exit-to-app fs-3 text-black me-1"></i></span>
                                <span>Exit</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_test_template" >
                                <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Test Template</span>
                            </a>
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_staff" onclick="confirmDelete('${item.sno}', '${item.staff_name}')">
                                <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                            </a>` : ''}
                        </div>
                    </span>
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_enroll/manage_staff?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}&dt_fill_issue_rpt=${dt_fill_issue_rpt}&from_dt_iss_rpt=${from_dt_iss_rpt}&to_dt_iss_rpt=${to_dt_iss_rpt}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    $('#total_staff_dash').text(res.total);

                    $('#companyStaffCards').html('');

                    res.company_counts.forEach(item => {

                        let logoPath = '';
                        if (item.company_id == 0) {
                            if (item.company_logo && item.company_logo.includes('.')) {
                                logoPath = `/logos/${item.company_logo}`;
                            }
                        } else {
                            if (item.company_logo) {
                                logoPath = `/Company_logos/${item.company_logo}`;
                            }
                        }

                        // ${logoPath ? `<img src="${logoPath}" alt="">` : ''}

                        // static company logo


                        let card = `
                            <div class="w-150px">
                                <div class="card company-card shadow-sm" style="background:${item.entity_base_color}">
                                    <div class="card-body text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.company_name || '-'}">
                                        <div class="dashboard-icon text-white">
                                            <i class="mdi mdi-account-group text-white fs-3"></i>
                                        </div>
                                        <div class="company-count">${item.total}</div>
                                        <small>${item.entity_short_name || 'EGC'}</small>

                                    </div>
                                </div>
                            </div>
                        `;

                        $('#companyStaffCards').append(card);
                    });
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                } else {
                    $('#total_staff_dash').text(0);
                    $('#companyStaffCards').html('');
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }


                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    // loadThemes(1);
</script>

<script>
    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }

    function departure_data_fetch_func(data) {
        let image = '';
        if (data.staff_image) {
            var imgUrl = "{{ asset('staff_images/') }}/" + data.staff_image;
            image = `<img src="${imgUrl}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        } else if (data.cus_gender == 1 || data.cus_gender === '1') {
            image = `<img src="{{ asset('assets/egc_images/auth/user_1.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        } else if (data.cus_gender == 2 || data.cus_gender === '2') {
            image = `<img src="{{ asset('assets/egc_images/auth/user_2.png') }}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />`;
        }
        var html = `<div class="row mt-4 mb-3">
                <input type="hidden" id="sts_change_sno" name="sts_change_sno" value="${data.sno}"/>

                  <div class="col-lg-3 mb-3">
                      <div class="row">
                          <div class="align-items-sm-center gap-4">
                              ${image}
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-9 mb-3">
                      <div class="row mb-1">
                          <label class="col-4 text-dark fs-7 fw-semibold">Staff Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.staff_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Nick Name</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${data.nick_name}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Date of Joining</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">${formatDate(data.date_of_joining)}</label>
                      </div>
                      <div class="row mb-3">
                          <label class="col-4 text-dark fs-7 fw-semibold">Department</label>
                          <label class="col-1 text-dark fs-6 fw-bold">:</label>
                          <label class="col-7 text-dark fs-6 fw-bold">
                              <span class="badge bg-info">${data.department_name}</span></label>
                      </div>
                  </div>
              </div>`;
        document.getElementById('staff_data_view').innerHTML = html;

    }
    departure_func(4)

    function departure_func(val) {
        // Fetch elements required for all conditions
        $('#exist_sts_change_id').val(val);
        $('#dep_reason_err').html('');
        $('#notice_end_date_err').html('');
        var reason_add = document.getElementById("reason_add");
        var date_view = document.getElementById("date_view");
        var starting_date = document.getElementById("starting_date");
        var ending_date = document.getElementById("ending_date");
        // Hide all elements initially
        reason_add.style.display = "none";
        date_view.style.display = "none";
        starting_date.style.display = "none";
        ending_date.style.display = "none";
        // Handle specific conditions based on `val`
        switch (val) {
            case 4: // Show both dates and reason
                starting_date.style.display = "block";
                ending_date.style.display = "block";
                reason_add.style.display = "block";
                $('#notice_period').prop('checked', true);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Notice Period');
                break;
            case 5: // Show reason only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', true);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Relive');
                break;
            case 6: // Show reason and date view only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', true);
                $('#terminate').prop('checked', false);
                $('#exit_submit_butt').html('Abscond');
                break;
            case 7: // Show reason only
                reason_add.style.display = "block";
                date_view.style.display = "block";
                $('#notice_period').prop('checked', false);
                $('#relieve').prop('checked', false);
                $('#upscond').prop('checked', false);
                $('#terminate').prop('checked', true);
                $('#exit_submit_butt').html('Terminate');
                break;
        }
    }

    function status_change_validation() {
        $('#exit_submit_butt').prop('disabled', true);
        var err = 0;
        var exist_sts_change_id = $('#exist_sts_change_id').val();
        if (exist_sts_change_id == 4) {

            var notice_start_date = $('#notice_start_date').val().trim();
            if (notice_start_date == '') {
                $('#notice_start_date_err').html('Notice Start date is requered..!');
                err++;
            } else {
                $('#notice_start_date_err').html('');
            }

            var notice_end_date = $('#notice_end_date').val().trim();
            if (notice_end_date == '') {
                $('#notice_end_date_err').html('Notice end date is requered..!');
                err++;
            } else {
                $('#notice_end_date_err').html('');
            }

        } else {
            var staff_last_date = $('#staff_last_date').val().trim();
            if (staff_last_date == '') {
                $('#staff_last_date_err').html('Last Attend date is requered..!');
                err++;
            } else {
                $('#staff_last_date_err').html('');
            }
        }

        var dep_reason = $('#dep_reason').val().trim();
        if (dep_reason == '') {
            $('#dep_reason_err').html('Enter Reason is requered..!');
            err++;
        } else {
            $('#dep_reason_err').html('');
        }

        if (err > 0) {
            $('#exit_submit_butt').prop('disabled', false);
            return false;
        } else {
            $('#exit_submit_butt').prop('disabled', true);
            $('#cus_drp_form').submit();
        }
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Show filter div on "Add Filter"
        document.getElementById('filter_btn').addEventListener('click', function() {
            document.getElementById('filter_div').style.display = 'block';
        });
    });

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    $(document).ready(function() {

        // When company changes
        $('#staff_company_name').on('change', function() {
            var companyId = $(this).val();
            var entityDropdown = $('#staff_entity_name');

            // Reset dropdown
            entityDropdown.empty().append('<option value="">Select Entity</option>');

            if (companyId) {
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: {
                        company_id: companyId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                entityDropdown.append(
                                    $('<option></option>')
                                    .attr('value', entity.sno)
                                    .attr('data-baseurl', entity.entity_base_url)
                                    .text(entity.entity_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
        });

        // When entity changes
        $('#staff_entity_name').on('change', function() {
            $('#staff_add_btn').prop('disabled', true);
            $('#staff_data_payload').val('');
            $('#total_Staff_data').text('0');
            var entityId = $(this).val();
            const verify_key = 'egcsecret2030datagetapierp';
            var branchDropdown = $('#staff_branch_name');
            if (entityId) {
                $.ajax({
                    url: "{{ route('entity_branch_dropdown_list') }}",
                    type: "GET",
                    data: {
                        entity_id: entityId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(entity) {
                                branchDropdown.append(
                                    $('<option></option>')
                                    .attr('value', entity.sno)
                                    .text(entity.branch_name)
                                );
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching entities:', error);
                    }
                });
            }
            var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
            if (baseurl) {
                var url = baseurl + 'api/staff_data_get';
                $.ajax({
                    url: url,
                    type: "GET",
                    data: {
                        auth_key: verify_key
                    },
                    success: function(response) {
                        console.log('response:', response);
                        if (response.status === 200 && response.data) {
                            console.log(response.data);
                            var length = response.data.length;
                            var staffData = response.data;
                            $('#total_Staff_data').text(length + ' ')
                            // TODO: handle data display or form updates here
                            if (length > 0) {
                                $('#staff_add_btn').prop('disabled', false);
                                // $('#staff_data_payload').val(JSON.stringify(staffData));
                            } else {
                                $('#staff_add_btn').prop('disabled', true);
                            }
                            staffData.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

                            staffData.map((sdata) => {
                                if (sdata.external_uuid) {
                                    sdata.alreadyExists = 1;
                                } else {
                                    sdata.alreadyExists = 0;
                                }
                            })
                            loadDataView(staffData, baseurl)
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching staff data:', error);
                    }
                });
            }
        });

    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>

<!-- status Change -->
<script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
    function confirmDelete(id, staff) {

        document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
        $('#delete_message').html(
            'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
            staff +
            '</b>');
    }

    function deleteFunc() {
        var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

        fetch('/staff_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {
                toastr.error(error);
            });
    }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
        if (!joinDate) return '-';

        const start = new Date(joinDate);
        const now = new Date();

        if (isNaN(start)) return '-'; // invalid date safeguard

        // Determine direction
        const isFuture = start > now;
        const earlier = isFuture ? now : start;
        const later = isFuture ? start : now;

        // Calculate raw differences
        let years = later.getFullYear() - earlier.getFullYear();
        let months = later.getMonth() - earlier.getMonth();
        let days = later.getDate() - earlier.getDate();

        // Adjust days
        if (days < 0) {
            const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        // Adjust months
        if (months < 0) {
            months += 12;
            years--;
        }

        // Build result text
        let result = '';
        if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
        if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

        if (!result.trim()) result = '0 days';

        result = result.trim();

        // Add "In" or "Ago"
        if (isFuture) {
            result = `In ${result}`;
        } else if (result !== '0 days') {
            // result += ' ago';
            result += '';
        }

        return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return {
            short: '-',
            full: '-'
        };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return {
            short: '-',
            full: '-'
        };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return {
                short: '🎉 Today',
                full: '🎉 Happy Birthday!'
            };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return {
            short: short.trim(),
            full
        };
    }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $('#mini_dashbaord').click(function() {
        $('.mini_dashboard_box').slideToggle('slow');
    });
</script>
<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');

            stateDropdown.empty().append('<option value="">Select Entity</option>');

            if (countryId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('entity_list') }}",
                    type: "GET",
                    data: {
                        company_id: countryId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                    'value', state.sno).text(state
                                    .entity_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });
        // division dropdown
        $('#department_fill').on('change', function() {
            var department_id = $(this).val();
            var stateDropdown = $('#division_fill');
            stateDropdown.empty().append('<option value="">Select Division</option>');

          

            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_division') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdivisionid', state.erp_division_id)
                                    .text(state.division_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Division:', error);
                    }
                });

            }
        });

        $('#division_fill').on('change', function() {
            var department_id = $(this).val();

            var jobRoleDropdown = $('#job_role_fill');

            jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

            let erp_depert = $(this).find(':selected').data('erpdivisionid');
            $('#erp_division_id').val(erp_depert);

            if (department_id) {
                // Fetch and populate states based on selected country
                // Job role dropdown
                $.ajax({
                    url: "{{ route('get_job_role') }}",
                    type: "GET",
                    data: {
                        division_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpjobroleid', state.erp_job_role_id)
                                    .text(state.job_position_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Job Role:', error);
                    }
                });
            }
        });

    })
</script>

<script>
    $('#sendMessageBtn').on('click', function(e) {
        var err = 0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');


        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();



        if (sms == 1 || email == 1 || whatsapp == 1) {
            $('#communication_err').text('');
        } else {
            $('#communication_err').text('Please Select Any One Communication.!');
            err++;
        }



        if (err == 0) {
            $('#sendMessageBtn').prop('disabled', true);
            $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/send_test_template',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        // location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                        $('#sendMessageBtn').prop('disabled', true);
                        resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                    $('#sendMessageBtn').prop('disabled', true);
                    resetButton();
                }
            });
        }

        function resetButton() {
            $('#sendMessageBtn').prop('disabled', false);
            $('#sendMessageBtn').text('Send Test Template');
            $('#sendMessageBtn .spinner-border').addClass('d-none');
        }
    });
</script>
<script>
    function send_proposal_whatsapp_func() {
        const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
        const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }
</script>

<script>
    // function viewStaff(id) {
    //     // Show skeleton loaders before fetch
    //     document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
    //         skeleton.style.display = 'block'; // Show skeleton loaders
    //     });

    //     // Hide actual data elements
    //     document.querySelectorAll('.view-data').forEach(element => {
    //         element.style.display = 'none'; // Hide actual data until it is loaded
    //     });

    //     fetch('/staff_view/' + id, {
    //             method: 'GET',
    //             headers: {
    //                 'Content-Type': 'application/json',
    //                 'X-CSRF-TOKEN': '{{ csrf_token() }}'
    //             }
    //         })
    //         .then(response => response.json())
    //         .then(data => {
    //             if (data.status === 200) {
    //                 var com = data.data;
    //                 let staff_image = '';
    //                 if (com.staff_image && com.staff_image.trim() !== '') {
    //                     if (com.company_type == 1) {
    //                         staff_image = `staff_images/Management/${com.staff_image}`;
    //                     } else {
    //                         staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
    //                     }
    //                 } else {
    //                     staff_image = com.gender == 1 ?
    //                         'assets/egc_images/auth/user_2.png' :
    //                         'assets/egc_images/auth/user_7.png';
    //                 }
    //                 staff_image = `{{ asset('${staff_image}') }}`;

    //                 document.getElementById('view_staff_img_sm').src = com.profile_image_url;
    //                 document.getElementById('view_staff_profile_image').src = com.profile_image_url;

    //                 document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
    //                     skeleton.style.display = 'none'; // Hide skeleton loaders
    //                 });
    //                 document.querySelectorAll('.view-data').forEach(element => {
    //                     element.style.display = 'block'; // Show actual data
    //                 });

    //                 let skillsJson = safeJsonParse(com.knowledge_tag);
    //                 let skillsArray = safeJsonParse(skillsJson);
    //                 let skillNames = Array.isArray(skillsArray) ?
    //                     skillsArray.map(s => s.value) : [];

    //                 let displaySkills = skillNames.join(", ");


    //                 let courseTagJson = safeJsonParse(com.course_tag);
    //                 let courseTagArray = safeJsonParse(courseTagJson);
    //                 let courseNames = Array.isArray(courseTagArray) ?
    //                     courseTagArray.map(s => s.value) : [];

    //                 let displayCourseTag = courseNames.join(", ");

    //                 $('#view_staff_name').html(com.staff_name);
    //                 $('#view_staff_mobile').html(com.mobile_no);
    //                 $('#view_staff_email').html(com.email_id);
    //                 $('#view_staff_dob').html(com.dob ? formatDateCommon(com.dob) : '-');
    //                 $('#view_staff_gender').html(com.gender == 1 ? 'Male' : (com.gender == 2 ? 'Female' : 'Other'));
    //                 $('#view_staff_father_name').html(com.father_name || '-');
    //                 $('#view_staff_mother_name').html(com.mother_name || '-');
    //                 $('#view_staff_father_occup').html(com.father_occup || '-');
    //                 $('#view_staff_mother_occup').html(com.mother_occup || '-');
    //                 $('#view_staff_mother_tongue').html(com.mother_tongue || '-');
    //                 $('#view_staff_language_knw').html(com.language_known ? com.language_known.join(',') : '-');
    //                 $('#view_staff_marital_status').html(com.martial_status == 2 ? 'Unmarried' : (com.martial_status == 1 ? 'Married' : '-'));
    //                 $('#view_staff_has_children').html(com.has_children || '-');
    //                 $('#view_staff_has_siblings').html(com.has_siblings || '-');
    //                 $('#view_staff_hobby').html(com.hobbies ? com.hobbies.join(',') : '-');
    //                 $('#view_staff_descrip').html(com.description || '-');

    //                 /* company details */
    //                 $('#view_staff_company_type').html(com.company_type == 1 ? 'Mangement' : 'Buisness');
    //                 $('#view_staff_department').html(com.department_name || '-');
    //                 $('#view_staff_division').html(com.division_name || '-');
    //                 $('#view_staff_job_role').html(com.job_role_name || '-');

    //                 /* Designation  details */
    //                 $('#view_staff_nick_name').html(com.nick_name || '-');
    //                 $('#view_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');
    //                 $('#view_staff_salary').html(com.basic_salary ? '₹ ' + new Intl.NumberFormat('en-IN').format(com.basic_salary) : '-');
    //                 $('#view_staff_per_hr_cost').html(com.per_hour_cost ? '₹ ' + new Intl.NumberFormat('en-IN').format(com.per_hour_cost) : '-');
    //                 $('#view_staff_skill_tag').html(displaySkills || '-');

    //                 /* Login  details */
    //                 $('#view_staff_user_name').html(com.user_name || '-');
    //                 $('#view_staff_password').html(com.password || '-');
    //                 $('#view_staff_user_role').html(com.role_name || '-');

    //                 /* other Credential */
    //                 if (com.other_credential && com.other_credential.length > 0) {
    //                     let credentialsHTML = '';

    //                     com.other_credential.forEach((credential) => {
    //                         credentialsHTML += `
    //                             <h5 class="title fw-bold mt-2 text-warning">${credential.credential_name} Credentials</h5>
    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Username</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${credential.user_name || '-'}</label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Password</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${credential.password || '-'}</label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">URL</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">
    //                                         <a class="text-truncate max-w-150px" href="${credential.url_link || '#'}" target="_blank">${credential.url_link ? credential.url_link : '-'}</a>
    //                                     </label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${credential.description || '-'}</label>
    //                                 </div>
    //                             </div>
    //                         `;
    //                     });
    //                     document.getElementById('otherCredentialsContainer').innerHTML = credentialsHTML;
    //                 } else {
    //                     document.getElementById('otherCredentialsContainer').innerHTML = '<p>No other credentials available.</p>';
    //                 }


    //                 if (com.contact_person_name && com.contact_person_name.length > 0) {
    //                     let contactPersonHTML = '';
    //                     const contactPersonNo = com.contact_person_no || [];
    //                     const relationship = com.relationship || [];

    //                     com.contact_person_name.forEach((contact, index) => {
    //                         contactPersonHTML += `
    //                             <div class="col-lg-12">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Contact Person ${index + 1}</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${contact || '-'}</label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-12">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile Number ${index + 1}</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${contactPersonNo[index] || '-'}</label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-12">
    //                                 <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Relation ${index + 1}</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${relationship[index] || '-'}</label>
    //                                 </div>
    //                             </div>
    //                         `;
    //                     });

    //                     document.getElementById('contactPersonContainer').innerHTML = contactPersonHTML;
    //                 } else {
    //                     document.getElementById('contactPersonContainer').innerHTML = '';
    //                 }




    //                 $('#view_staff_permnt_address').html(com.address || '-');
    //                 $('#view_staff_temp_address').html(com.residential_address || '-');
    //                 $('#view_staff_alternate_no').html(com.alternative_no || '-');

    //                 /* Work Details */
    //                 $('#view_exp_type').html(com.exp_type == 1 ? 'Fresher' : (com.exp_type == 2 ? 'Experience' : '-'));
    //                 $('#view_shift_comp_count').html(com.total_company_shift || '-');
    //                 $('#view_total_yr_exp').html(com.total_experience || '-');

    //                 if (com.work_details && com.work_details.length > 0) {
    //                     let worksHTML = '';

    //                     com.work_details.forEach((work, index) => {
    //                         let compCount = index + 1;
    //                         worksHTML += `
    //                             <h5 class="title fw-bold mt-2 text-warning">${compCount + getOrdinalSuffix(compCount)} Company</h5>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">Position</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-black">${work.position || '-'}</label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">Experience Years</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-black">
    //                                     <span class="badge bg-primary text-white px-3 fs-7">${work.year_of_experience || '-'}</span>
    //                                 </label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">Company Name</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-black">${work.company_name || '-'}</label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">Salary</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-danger">${work.salary ? '₹ '+ new Intl.NumberFormat('en-IN').format(work.salary) +' /-':'-'} </label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">Start Date</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-black">${work.start_date ? formatDateCommon(work.start_date) : '-'}</label>
    //                                 </div>
    //                             </div>

    //                             <div class="col-lg-6">
    //                                 <div class="row mb-2">
    //                                 <label class="col-5 fw-semibold fs-7 text-dark">End Date</label>
    //                                 <label class="col-1 fw-semibold fs-7">:</label>
    //                                 <label class="col-6 fw-semibold fs-6 text-black">${work.end_date ? formatDateCommon(work.end_date) : '-'}</label>
    //                                 </div>
    //                             </div>
    //                         `;
    //                     });
    //                     document.getElementById('workDetailsContainer').innerHTML = worksHTML;
    //                 } else {
    //                     document.getElementById('workDetailsContainer').innerHTML = '<p>No Experience Details.</p>';
    //                 }

    //                 if (com.documents && com.documents.length > 0) {
    //                     let documentHTML = '';

    //                     com.documents.forEach((document, index) => {
    //                         let documentName = document.document_name || 'Unknown Document';

    //                         // Start with a Bootstrap card for each document
    //                         documentHTML += `
    //                             <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
    //                                 <div class="card shadow-sm">
    //                                     <div class="card-body">
    //                                         <h5 class="card-title text-primary">${documentName}</h5>
    //                                         <div class="d-flex flex-wrap justify-content-start gap-3">
    //                         `;

    //                         // Loop through the files for each document
    //                         document.files.forEach((file, fileIndex) => {
    //                             const fileExtension = file.split('.').pop().toLowerCase();
    //                             let fileHTML = '';

    //                             // Check if the file is an image
    //                             if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
    //                                 fileHTML = `
                                    
    //                                     <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
    //                                         <img src="${file}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
    //                                         <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
    //                                             <span class="view-btn">
    //                                                 <i class="mdi mdi-eye"></i> 
    //                                             </span>
    //                                         </div>
    //                                     </div>
    //                                 `;
    //                             }
    //                             // If the file is a document (pdf, docx, etc.)
    //                             else if (['pdf'].includes(fileExtension)) {
    //                                 fileHTML = `
    //                                     <div class="document-thumbnail position-relative border rounded cursor-pointer" data-bs-toggle="modal" data-bs-target="#filePreviewModal" onclick="previewFile('${file}','${documentName}')">
                                        
    //                                         <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
    //                                         <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
    //                                             <span class="view-btn">
    //                                                 <i class="mdi mdi-eye"></i> 
    //                                             </span>
    //                                         </div>
    //                                     </div>
    //                                 `;
    //                             }
    //                             // If file is unsupported (other types)
    //                             else {
    //                                 fileHTML = `
    //                                     <div class="document-thumbnail position-relative border rounded cursor-pointer" >
                                        
    //                                         <img src="http://192.168.3.96:8080/assets/phdizone_images/Document.jpg" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" >
    //                                         <div class="view-icon position-absolute top-0 start-0 w-100 h-100  justify-content-center">
    //                                             <a href="${file}" download class="view-btn">
    //                                                 <i class="mdi mdi-download-circle-outline text-dark fs-3 fw-light"></i> 
    //                                             </a>
                                                
    //                                         </div>
    //                                     </div>
    //                                 `;
    //                             }

    //                             // Add the file's HTML to the document's section
    //                             documentHTML += fileHTML;
    //                         });

    //                         // Close the card layout and document container
    //                         documentHTML += `
    //                                     </div> 
    //                                 </div> 
    //                             </div>
    //                         </div> 
    //                         `;
    //                     });

    //                     // Insert the generated HTML into the container
    //                     document.getElementById('documentContainer').innerHTML = documentHTML;
    //                 } else {
    //                     document.getElementById('documentContainer').innerHTML = '<p class="text-muted">No documents available.</p>';
    //                 }


    //                 if (com.qualification && com.qualification.length > 0) {
    //                     let educationHTML = '';

    //                     com.qualification.forEach((qualification, index) => {
    //                         let compCount = index + 1;
    //                         educationHTML += `
    //                             <div class="col-lg-6">
    //                               <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Qualification Type</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${qualification.qualification_name || '-'}</label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                               <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Major</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${qualification.major_name ? qualification.major_name  : (qualification.major || '-') }</label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                               <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">University Name</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${qualification.university_name || '-'}</label>
    //                                 </div>
    //                             </div>
    //                             <div class="col-lg-6">
    //                               <div class="row mb-2">
    //                                     <label class="col-5 fw-semibold fs-7 text-dark">Year</label>
    //                                     <label class="col-1 fw-semibold fs-7">:</label>
    //                                     <label class="col-6 fw-semibold fs-6 text-black">${qualification.year || '-'}</label>
    //                                 </div>
    //                             </div>
    //                             <hr>
    //                         `;
    //                     });
    //                     document.getElementById('educationContainer').innerHTML = educationHTML;
    //                 } else {
    //                     document.getElementById('educationContainer').innerHTML = '<p>No Qualification Found.</p>';
    //                 }


    //                 if (com.document_checkList && com.document_checkList.length > 0) {
    //                     let docCheckListHTML = '';

    //                     com.document_checkList.forEach((checklist, index) => {
    //                         let compCount = index + 1;
    //                         docCheckListHTML += `
    //                             <div class="form-check mb-3">
    //                                 <input class="form-check-input checklist-item" type="checkbox" ${checklist.is_checked ==1 ? 'checked' :''} disabled>
    //                                 <label class="fw-semibold fs-6 text-black" >${checklist.document_checklist}</label>
    //                             </div>
    //                         `;
    //                     });
    //                     document.getElementById('documentCheckContainer').innerHTML = docCheckListHTML;
    //                 } else {
    //                     document.getElementById('documentCheckContainer').innerHTML = '<p>No Documents.</p>';
    //                 }

    //                 $('#view_staff_completed_course_tag').html(displayCourseTag || '-');




    //                 $('[data-bs-toggle="tooltip"]').tooltip();
    //             } else {
    //                 console.error(data.error_msg);
    //             }
    //         })
    //         .catch(error => {
    //             console.error('Error:', error);
    //         });
    // }

    function safeJsonParse(str) {
        try {
            return JSON.parse(str);
        } catch (e) {
            return str;
        }
    }

    function getOrdinalSuffix(number) {
        const suffixes = ["th", "st", "nd", "rd"];
        const remainder = number % 100;
        return suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    }

    function previewFile(file, doc_name) {
        const fileExtension = file.split('.').pop().toLowerCase();
        $('#filePreviewModalLabel').text(doc_name)
        const previewContainer = document.getElementById('filePreviewContent');
        previewContainer.innerHTML = ''; // Clear any previous content

        // Handle the preview based on file type
        if (['pdf', 'docx'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <iframe src="${file}" style="width: 100%; height: 500px;" frameborder="0"></iframe>
            `;
        } else if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
            previewContainer.innerHTML = `
                <img src="${file}" alt="Preview Image" style="width: 100%; max-height: 500px; object-fit: contain;" />
            `;
        } else {
            previewContainer.innerHTML = `
                <p class="text-center text-muted">File format not supported for preview.</p>
            `;
        }
    }

    function loadDataView(list, baseurl) {
        let html = "";

        if (list.length === 0) {
            html += `<span class="text-center text-danger">No attendance found</span>`;
        } else {
            list.forEach(a => {
                html += `
                    <span class="list-group-item d-flex align-items-center justify-content-between mb-3 shadow-sm rounded px-3 py-2 ${a.alreadyExists == 1 ? 'bg-label-dark':'bg-label-success'} " >
                        
                        <!-- LEFT SIDE -->
                        <div class="d-flex align-items-center">
                            <img src="${a.staff_image}"
                             alt="${a.staff_name}"
                             class="rounded-circle me-3 staff-avatar"
                             width="50" height="50"
                             onerror="replaceWithInitials(this, '${a.staff_name.replace(/'/g, "\\'")}')">

                            <div>
                                <h6 class="fw-semibold mb-0">
                                    ${a.staff_name}
                                    <span class="text-primary small">(${a.nick_name})</span>
                                    ${a.alreadyExists == 1 ?
                                        ``
                                        :
                                        '<span class="badge bg-label-danger">New</span>'
                                        }
                                </h6>
                                <small class="text-muted">
                                    ${a.role_name} | ${a.department_name}
                                </small>
                            </div>
                        </div>

                        <!-- RIGHT SIDE (Created At) -->
                        <span class="badge bg-success-subtle text-success fw-semibold">
                            ${formatDateCommon(a.created_at)}
                        </span>

                    </span>
                `;
            });
        }

        document.getElementById("total_Staff_list").innerHTML = html;
    }

    function getInitials(name) {
        if (!name) return '';
        const words = name.trim().split(' ');

        return (words[0][0]).toUpperCase();
    }

    function getAvatarColor(name) {
        const colors = ['bg-primary', 'bg-success', 'bg-info', 'bg-warning', 'bg-danger'];
        let hash = 0;
        for (let i = 0; i < name.length; i++) {
            hash = name.charCodeAt(i) + ((hash << 5) - hash);
        }
        return colors[Math.abs(hash) % colors.length];
    }

    function replaceWithInitials(img, name) {
        console.log(img, name)
        const initials = getInitials(name);
        const color = getAvatarColor(name);
        console.log(name, initials)
        const div = document.createElement('div');
        div.className = `rounded-circle ${color} text-white d-flex align-items-center justify-content-center me-3 fw-bold`;
        div.style.width = '50px';
        div.style.height = '50px';
        div.innerText = initials;

        img.replaceWith(div);
    }
</script>
<script>
    function existStaffModal(id) {

        $('#exist_staff_id').val(id);

        fetch('/staff_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    let staff_image = '';
                    if (com.staff_image && com.staff_image.trim() !== '') {
                        if (com.company_type == 1) {
                            staff_image = `staff_images/Management/${com.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${com.company_id}/${com.entity_id}/${com.staff_image}`;
                        }
                    } else {
                        staff_image = com.gender == 1 ?
                            'assets/egc_images/auth/user_2.png' :
                            'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;

                    document.getElementById('exist_staff_profile_image').src = staff_image;

                    document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                        skeleton.style.display = 'none'; // Hide skeleton loaders
                    });
                    document.querySelectorAll('.exist-data').forEach(element => {
                        element.style.display = 'block'; // Show actual data
                    });

                    $('#exist_staff_name').html(com.staff_name);
                    $('#exist_nick_name').html(com.nick_name || '-');
                    $('#exist_staff_company_name').html(com.company_type == 1 ? 'Elysium Groups' : com.company_name);
                    $('#exist_entity_name').html(com.company_type == 1 ? '-' : com.entity_name);
                    $('#exist_staff_department').html(com.department_name || '-');
                    $('#exist_staff_division').html(com.division_name || '-');
                    $('#exist_staff_job_role').html(com.job_role_name || '-');
                    $('#exist_staff_doj').html(com.date_of_joining ? formatDateCommon(com.date_of_joining) : '-');

                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

<script>
    let staff_bank_company_id = 0;
    let staff_bank_id = 0;
    var existingSalaryComponents = '';
    let payrollRules = [];

    // function openProfilePayroll(id, name, mobile, email, image,salary,leave_count){

    //         staff_bank_company_id = 0;
    //         staff_bank_id = 0;
    //         $('#employee_sno').val(id);
    //         $('#payroll_staff_name').text(name);
    //         $('#casual_leave_count').val(leave_count);
    //         $('#basic_salary').val(salary);
    //         $('#payroll_staff_mobile').text(mobile);
    //         var perDaySalary = (parseFloat(salary) / 30).toFixed(2); 
    //         $('#per_day_salary').val(perDaySalary);
    //         // $('#payroll_staff_email').text(email);
    //         $('#payroll_staff_img').attr('src', image);
    //         $('.error').text('');

    //     $.get('/employee/payroll/details/' + id, function (res) {

    //         if (res.data) {
    //             Object.keys(res.data).forEach(key => {
    //                 $('[name="'+key+'"]').val(res.data[key]);
    //                 if (res.data.per_day_salary === null) {
    //                     var calculatedPerDaySalary = (parseFloat(res.data.basic_salary) / 30).toFixed(2);
    //                     $('#per_day_salary').val(calculatedPerDaySalary);
    //                 }
    //             });
    //         }else {

    //             // Clear other fields as well
    //             $('[name="bank_account_no"]').val('');
    //             $('[name="bank_name"]').val('');
    //             $('[name="ifsc_code"]').val('');
    //             $('[name="uan_no"]').val('');
    //             $('[name="esi_no"]').val('');
    //             $('[name="pan_no"]').val('');
    //             $('[name="aadhar_no"]').val('');

    //             // Optionally clear error messages
    //             $('.error').text('');
    //         }

    //     });
    // }

    function openProfilePayroll(id, name, mobile, email, image, salary, leave_count) {

        staff_bank_company_id = 0;
        staff_bank_id = 0;
        existingSalaryComponents = [];
         $('#salaryAccountBody').html('');
        $('#salary_company_id').val('').change();
        $('#salary_bank_id').val('').change();
        $('#update_acc_employee_sno').val(id);
        $('#payroll_staff_name').text(name);
        $('#payroll_staff_mobile').text(mobile);
        $('#casual_leave_count').val(leave_count);
        $('#basic_salary').val(salary);
        $('#payroll_staff_img').attr('src', image);

        let perDaySalary = (parseFloat(salary) / 30).toFixed(2);
        $('#per_day_salary').val(perDaySalary);

        //  loadComponents();
        salary_type_checked();
        per_day_salary_value();
        $('.error').text('');

        $.ajax({
            url: '/employee/payroll/details/' + id,
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                // =============================
                // STAFF MAIN DATA
                // =============================
                if (res.data) {

                    staff_bank_company_id = res.data.staff_bank_company_id || res.data.salary_company_id;
                    staff_bank_id = res.data.salary_bank_id || 0;

                    Object.keys(res.data).forEach(key => {

                        let el = $('[name="' + key + '"]');
                        // ❌ Skip file inputs
                        if (el.attr('type') === 'file') return;
                        //  Handle checkbox
                        if (el.attr('type') === 'checkbox') {
                            el.prop('checked', res.data[key] == 1);
                        }
                        //  Handle radio
                        else if (el.attr('type') === 'radio') {
                            $(`[name="${key}"][value="${res.data[key]}"]`).prop('checked', true);
                        }
                        //  Normal input
                        else {
                            el.val(res.data[key] ?? '');
                        }

                    });

                    // per day fallback
                    if (!res.data.per_day_salary) {
                        let calculated = (parseFloat(res.data.basic_salary) / 30).toFixed(2);
                        $('#per_day_salary').val(calculated);
                    }

                    $('#salary_date').val(res.data.salary_date).change();
                    // salary type toggle
                    if (res.data.salary_type == 2) {
                        $('#salary_bank').prop('checked', true);
                    } else {
                        $('#salary_cash').prop('checked', true);
                    }

                    salary_type_checked();
                }

                // =============================
                //  STAFF BANK DETAILS
                // =============================
                if (res.staffBank) {
                    $('#staff_bank_name').val(res.staffBank.bank_name || '');
                    $('#staff_bank_branch').val(res.staffBank.bank_branch || '');
                    $('#staff_acc_holder').val(res.staffBank.account_holder || '');
                    $('#staff_acc_no').val(res.staffBank.bank_account_no || '');
                    $('#ifsc_code').val(res.staffBank.ifsc_code || '');
                }

                // =============================
                //  STATUTORY DETAILS
                // =============================
                if (res.staffStatutory) {
                    $('[name="uan_no"]').val(res.staffStatutory.uan_no || '');
                    $('[name="esi_no"]').val(res.staffStatutory.esi_no || '');
                    $('[name="pan_no"]').val(res.staffStatutory.pan_no || '');
                    $('[name="aadhar_no"]').val(res.staffStatutory.aadhar_no || '');
                }
                // =============================
                //  COMPANY + BANK AUTO SELECT
                // =============================
                if (staff_bank_company_id) {
                    $('#salary_company_id').val(staff_bank_company_id).trigger('change');
                    salary_company_change(); // load banks
                }

                if(res.singleSalaryAccount)
                {
                    $('#single_salary_account_sno')
                        .val(res.singleSalaryAccount.sno);
                }

                if(res.salaryAccounts &&
                res.salaryAccounts.length > 0 && res.data.is_multiple_account == 1)
                {
                    $('[name="is_multiple_account"][value="1"]')
                        .prop('checked', true);

                    accountTypeChange();

                    $('#salaryAccountBody').html('');

                    res.salaryAccounts.forEach(account => {

                        addSalaryAccountRow(account);

                    });

                    calculateMultipleAccountTotals();
                }
                else
                {
                    $('[name="is_multiple_account"][value="0"]')
                        .prop('checked', true);

                    accountTypeChange();
                }
            },

            error: function(xhr) {
                console.error(xhr.responseText);
                alert('Error loading payroll details');
            }
        });
    }

    let companyOptions = $('#salary_company_id').html();
    function employeePayrollSubmit() {

        const form = document.getElementById("employeePayrollForm");
        const reloadPage = tableState.currentPage;

        if (!form) return;

        
        let accountType =
            $('[name="is_multiple_account"]:checked').val() || 0;

        let salaryType =
            $('[name="salary_type"]:checked').val() || 1;

        let accounts = [];

        if(accountType == 1)
        {
            accounts = collectSalaryAccounts();

            if(accounts.length === 0)
            {
                toastr.error(
                    'Please add at least one salary account'
                );
                return;
            }

            let primaryAccounts =
                accounts.filter(
                    x => parseInt(x.is_primary) === 1
                );

            if(primaryAccounts.length !== 1)
            {
                toastr.error(
                    'Select exactly one primary account'
                );
                return;
            }

            for(let i = 0; i < accounts.length; i++)
            {
                if(!accounts[i].salary_company_id)
                {
                    toastr.error(
                        'Company is required in row ' + (i + 1)
                    );
                    return;
                }

                // if(
                //     salaryType == 2 &&
                //     !accounts[i].salary_bank_id
                // )
                // {
                //     toastr.error(
                //         'Bank is required in row ' + (i + 1)
                //     );
                //     return;
                // }

                if(
                    parseFloat(accounts[i].gross_salary || 0) <= 0
                )
                {
                    toastr.error(
                        'Gross salary must be greater than 0 in row ' + (i + 1)
                    );
                    return;
                }
            }
        }

        let formData = new FormData(form);

        // ✅ ADD SALARY COMPONENTS
        let components = collectSalaryComponents();
        
        formData.append(
            'is_multiple_account',
            accountType
        );

        formData.append(
            'salary_accounts',
            JSON.stringify(accounts)
        );

        // formData.append(
        //     'salary_components',
        //     JSON.stringify(
        //         collectSalaryComponents()
        //     )
        // );

        $('.error').text('');

        let btn = $('#savePayrollBtn');
        btn.prop('disabled', true);
        btn.find('.btn-text').addClass('d-none');
        btn.find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: '/employee/payroll/save',
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('input[name="_token"]').val()
            },

            success: function(res) {

                if (res.status) {
                    toastr.success("Updated Successfully");

                    // ✅ OPTIONAL: close modal instead reload
                    $('#employeePayrollModal').modal('hide');
                    loadThemes(reloadPage);

                    // location.reload();
                } else {
                    toastr.error(res.message || "Update failed");
                }
            },

            error: function(xhr) {

                // ✅ VALIDATION ERRORS
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;

                    $.each(errors, function(key, val) {
                        $('[data-error="' + key + '"]').text(val[0]);
                    });
                }

                toastr.error(xhr.responseJSON?.message || 'Something went wrong');
            },

            complete: function() {
                // ✅ ALWAYS RESET BUTTON
                btn.prop('disabled', false);
                btn.find('.btn-text').removeClass('d-none');
                btn.find('.spinner-border').addClass('d-none');
            }
        });
    }

    function validation_func() {

        let err = false;
        $('.error').text('');

        function setError(field, message) {
            $('[data-error="' + field + '"]').text(message);
            if (!err) {
                $('[name="' + field + '"]').focus();
            }
            err = true;
        }

        let salary_type_checked = $('[name="salary_type"]:checked').val();
        if (salary_type_checked == 2) {

            // let pay_cycle = $('[name="pay_cycle"]').val().trim();
            // let payroll_status = $('[name="payroll_status"]').val().trim();
            // let tax_regime = $('[name="tax_regime"]').val().trim();
            let bank_account_no = $('[name="staff_acc_no"]').val().trim();
            let bank_name = $('[name="staff_bank_name"]').val().trim();
            let ifsc_code = $('[name="ifsc_code"]').val().trim();
            let pan_no = $('[name="pan_no"]').val().trim();
            let aadhar_no = $('[name="aadhar_no"]').val().trim();

            // Payroll Profile
            // if (!pay_cycle) {
            //     setError('pay_cycle', 'Please select pay cycle.');
            // }

            // if (!payroll_status) {
            //     setError('payroll_status', 'Please select payroll status.');
            // }

            // if (!tax_regime) {
            //     setError('tax_regime', 'Please select tax regime.');
            // }

            // Bank Details
            if (!bank_account_no) {
                // setError('bank_account_no', 'Bank account number is required.');
            } else if (!/^[0-9]{6,20}$/.test(bank_account_no)) {
                setError('staff_acc_no', 'Enter valid bank account number.');
            }

            if (!bank_name) {
                // setError('bank_name', 'Bank name is required.');
            }

            if (!ifsc_code) {
                // setError('ifsc_code', 'IFSC code is required.');
            } else if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc_code.toUpperCase())) {
                setError('ifsc_code', 'Enter valid IFSC code.');
            }

            // Statutory
            if (!pan_no) {
                // setError('pan_no', 'PAN number is required.');
            } else if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan_no.toUpperCase())) {
                setError('pan_no', 'Enter valid PAN number.');
            }

            if (aadhar_no && !/^[0-9]{12}$/.test(aadhar_no)) {
                setError('aadhar_no', 'Aadhar must be 12 digits.');
            }

        }

        // If no error → submit
        if (!err) {
            employeePayrollSubmit();
        }
    }
</script>
<script>
    function openSalaryMappingModal(employeeSno) {

        $('#mapping_employee_sno').val(employeeSno);

        $('.error').text('');

        $.get('/staff/salary-mapping/' + employeeSno, function(res) {
            let rows = '';
            res.history.forEach(h => {
                rows += `
                    <tr>
                        <td>${h.structure_name}</td>
                        <td>${h.effective_from}</td>
                        <td>${h.effective_to??''}</td>
                        <td>${h.change_reason??''}</td>
                    </tr>
                `;
            });
            $('#salaryHistoryTable').html(rows);
            $('#salaryMappingModal').modal('show');
        });

    }

    function saveSalaryMapping() {

        $('.error').text('');
        let btn = $('#saveMappingBtn');
        btn.prop('disabled', true);
        btn.find('.btn-text').addClass('d-none');
        btn.find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: '/staff/salary-mapping/save',
            method: 'POST',
            data: $('#salaryMappingForm').serialize(),
            error: function(xhr) {
                if (xhr.status == 422) {
                    $.each(xhr.responseJSON.errors, function(k, v) {
                        $('[data-error="' + k + '"]').text(v[0]);
                    });
                }
            },
            success: function(res) {
                if (res.status) {
                    toastr.success('Salary mapped successfully');
                    $('#salaryMappingModal').modal('hide');
                }
            },
            complete: function() {
                btn.prop('disabled', false);
                btn.find('.btn-text').removeClass('d-none');
                btn.find('.spinner-border').addClass('d-none');
            }

        });

    }
</script>

<script>
    function shift_change_func() {

        let shiftId = $('#shift_select').val();
        if (!shiftId) {
            $('#shiftPreview').addClass('d-none');
            return;
        }

        fetch('/get-shift-detail/' + shiftId)
            .then(res => res.json())
            .then(res => {
                if (!res.status) return;

                let html = '';
                let total = res.total_duration;

                res.shift.days.forEach(day => {
                    let hours = Math.floor(day.duration_minutes / 60);
                    let mins = day.duration_minutes % 60;
                    html += `
            <div class="d-flex justify-content-between border-bottom border-primary py-2">
                        <div>
                            <b>${formatDayName(day.day_name)}</b>
                        </div>
                        <div class="d-flex gap-1">
                            <span class="badge bg-label-info small">
                                ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
                            </span>
                            <span class="badge bg-label-primary">
                                ${hours}h ${mins}m
                            </span>
                        </div>
                    </div>
            `;
                });

                let totalHours = Math.floor(total / 60);
                let totalMins = total % 60;
                $('#shiftDays').html(html);
                $('#shiftTotalDuration').text(totalHours + 'h ' + totalMins + 'm');
                $('#shiftPreview').removeClass('d-none');
            });

    }

    // function assignShift(){
    //     let staffId=$('#assign_staff_id').val();
    //     let shiftId=$('#shift_select').val();
    //     if(!shiftId){
    //         toastr.warning('Please select shift');
    //         return;
    //     }
    //     fetch('/assign-shift',{
    //         method:'POST',
    //         headers:{
    //         'Content-Type':'application/json',
    //         'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
    //         },
    //         body:JSON.stringify({
    //             staff_id:staffId,
    //             shift_id:shiftId
    //         })
    //     })
    //     .then(res=>res.json())
    //     .then(res=>{
    //         if(res.status){
    //             toastr.success(res.message);
    //             $('#assignShiftModal').modal('hide');
    //             loadThemes(1);
    //         }
    //     });
    // }

    function assignShift() {
        let staffId = $('#assign_staff_id').val();
        let shiftId = $('#shift_select').val();
        let startDate = $('#shift_start_date').val();
        let endDate = $('#previous_end_date').val();
        let currentShift = $('#current_shift_id').val();

        if (!shiftId) {
            toastr.warning('Select shift');
            return;
        }

        fetch('/assign-shift', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                body: JSON.stringify({
                    staff_id: staffId,
                    shift_id: shiftId,
                    start_date: startDate,
                    end_date: endDate,
                    current_shift_id: currentShift
                })

            })
            .then(res => res.json())
            .then(res => {
                if (res.status) {
                    toastr.success(res.message);
                    $('#assignShiftModal').modal('hide');
                    loadThemes(1);
                } else {
                    toastr.error(res.message);
                }

            });

    }
    // function openShiftAssign(staffId,name, mobile, email, image,shift_time,date_of_joining){
    //     $('#assign_staff_id').val(staffId);

    //         $('#assign_staff_name').text(name);
    //         $('#assign_staff_mobile').text(mobile);
    //         $('#assign_staff_img').attr('src', image);
    //         if(shift_time != 0){
    //             $('#shift_select').val(shift_time).change();
    //             $('#shift_start_date').val(new Date().toISOString().split('T')[0]);
    //         }else{
    //             $('#shift_start_date').val(date_of_joining);

    //         }

    //     $('#assignShiftModal').modal('show');
    // }

    // function openShiftAssign(staffId,name,mobile,email,image,shift_time,date_of_joining,shift_name){

    //     $('#current_shift_name').val('');
    //     $('#previous_end_date').val('');
    //     $('#shift_start_date').val('');
    //     $('#shift_start_date').val('');
    //     $('#assign_staff_id').val('');
    //     $('#currentShiftBox').hide();
    //     $('#current_shift_id').val('').change();


    //     $('#assign_staff_name').text(name);
    //     $('#assign_staff_mobile').text(mobile);
    //     $('#assign_staff_img').attr('src', image);
    //     $('#current_shift_id').val(shift_time);
    //     $('#assign_staff_id').val(staffId);


    //     if(shift_time != 0){
    //         // SHOW CURRENT SHIFT CARD
    //         $('#currentShiftBox').show();
    //         $('#current_shift_name').val(shift_name);
    //         $('#previous_end_date').val(new Date().toISOString().split('T')[0]);
    //         $('#shift_start_date').val(new Date().toISOString().split('T')[0]);
    //         loadCurrentShiftDetails(shift_time);
    //     }else{
    //         // FIRST TIME ASSIGN
    //         $('#currentShiftBox').hide();
    //         $('#shift_start_date').val(date_of_joining);
    //     }
    //     $('#assignShiftModal').modal('show');

    // }

    function openShiftAssign(staffId, name, mobile, email, image, shift_time, date_of_joining, shift_name) {

        //  FULL RESET (VERY IMPORTANT)
        $('#assign_staff_id').val('');
        $('#current_shift_id').val('');
        $('#shift_select').val('').trigger('change');

        $('#current_shift_name').val('');
        $('#previous_end_date').val('');
        $('#shift_start_date').val('');

        //  CLEAR PREVIEWS
        $('#currentShiftDays').html('');
        $('#shiftDays').html('');
        $('#currentShiftTotalDuration').text('');
        $('#shiftTotalDuration').text('');

        $('#currentShiftPreview').addClass('d-none');
        $('#shiftPreview').addClass('d-none');

        $('#currentShiftBox').hide();

        //  SET STAFF DATA
        $('#assign_staff_name').text(name);
        $('#assign_staff_mobile').text(mobile);
        $('#assign_staff_img').attr('src', image);

        $('#assign_staff_id').val(staffId);
        $('#current_shift_id').val(shift_time);

        //  HANDLE SHIFT LOGIC
        if (shift_time && shift_time != 0) {

            $('#currentShiftBox').show();

            $('#current_shift_name').val(shift_name);

            let today = new Date().toISOString().split('T')[0];

            $('#previous_end_date').val(today);
            $('#shift_start_date').val(today);

            loadCurrentShiftDetails(shift_time);

        } else {

            $('#currentShiftBox').hide();

            $('#shift_start_date').val(date_of_joining);
        }

        $('#assignShiftModal').modal('show');
    }

    // function loadCurrentShiftDetails(shiftId){
    //     if(!shiftId){
    //         $('#currentShiftPreview').addClass('d-none');
    //         return;
    //     }

    //     fetch('/get-shift-detail/'+shiftId)
    //     .then(res=>res.json())
    //     .then(res=>{
    //         let html='';
    //         let total=res.total_duration;
    //         res.shift.days.forEach(day=>{
    //             let hours=Math.floor(day.duration_minutes/60);
    //             let mins=day.duration_minutes%60;
    //             html+=`
    //                 <div class="d-flex justify-content-between border-bottom border-primary py-2">
    //                     <div>
    //                         <b>${formatDayName(day.day_name)}</b>
    //                     </div>
    //                     <div class="d-flex gap-1">
    //                         <span class="badge bg-label-warning small">
    //                             ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
    //                         </span>
    //                         <span class="badge bg-label-primary">
    //                             ${hours}h ${mins}m
    //                         </span>
    //                     </div>
    //                 </div>
    //             `;
    //         });
    //         let totalHours=Math.floor(total/60);
    //         let totalMins=total%60;
    //         $('#currentShiftTotalDuration').text(totalHours+'h '+totalMins+'m');
    //         $('#currentShiftDays').html(html);
    //         $('#currentShiftPreview').removeClass('d-none');

    //     });

    // }

    let currentShiftRequest = null;

    function loadCurrentShiftDetails(shiftId) {

        if (!shiftId) {
            $('#currentShiftPreview').addClass('d-none');
            return;
        }

        currentShiftRequest = shiftId;

        fetch('/get-shift-detail/' + shiftId)
            .then(res => res.json())
            .then(res => {

                // ✅ Ignore old response
                if (currentShiftRequest != shiftId) return;

                let html = '';
                let total = res.total_duration;

                res.shift.days.forEach(day => {
                    let hours = Math.floor(day.duration_minutes / 60);
                    let mins = day.duration_minutes % 60;

                    html += `
                    <div class="d-flex justify-content-between border-bottom border-primary py-2">
                        <div><b>${formatDayName(day.day_name)}</b></div>
                        <div class="d-flex gap-1">
                            <span class="badge bg-label-warning small">
                                ${day.time_from ? formatTime(day.time_from) : '-'} - ${day.time_to? formatTime(day.time_to) : '-'}
                            </span>
                            <span class="badge bg-label-primary">
                                ${hours}h ${mins}m
                            </span>
                        </div>
                    </div>
                `;
                });

                let totalHours = Math.floor(total / 60);
                let totalMins = total % 60;

                $('#currentShiftTotalDuration').text(totalHours + 'h ' + totalMins + 'm');
                $('#currentShiftDays').html(html);
                $('#currentShiftPreview').removeClass('d-none');
            });
    }

    function formatTime(timeString) {
        if (!timeString) return "-";

        const parts = timeString.split(":");
        if (parts.length < 2) return "-";

        let hours = parseInt(parts[0]);
        let minutes = parts[1];
        let seconds = parts[2] || "00";

        let ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12;

        return `${hours.toString().padStart(2,"0")}:${minutes} ${ampm}`;
    }

    function formatDayName(day) {
        const days = {
            mon: "Monday",
            tue: "Tuesday",
            wed: "Wednesday",
            thu: "Thursday",
            fri: "Friday",
            sat: "Saturday",
            sun: "Sunday"
        };

        return days[day?.toLowerCase()] || day;
    }

    // $(document).ready(function () {
    //         $('.common_datepicker').datepicker({
    //             todayHighlight: true,
    //             autoclose: true,
    //             format: 'dd-M-yyyy'
    //         });
    //     });
</script>

<script>
    function calculatePerHourCost() {

        let salary = parseFloat($('#basic_salary').val()) || 0;

        let workingHours = 8; // ✅ You can change this (or make dynamic)

        if (salary <= 0) {
            $('#per_hr_cost').val('0.00');
            return;
        }

        let perHour = salary / (30 * workingHours);

        perHour = Math.round(perHour * 100) / 100;

        $('#per_hr_cost').val(perHour.toFixed(2));
    }


    // function per_day_salary_value(){
    //     var salary =parseFloat($('#basic_salary').val());
    //     if (isNaN(salary) || salary <= 0) {
    //         $('#per_day_salary').val('0.0');
    //         return;
    //     }
    //     let perDaySalary = salary / 30;
    //     perDaySalary = Math.round(perDaySalary * 100) / 100;
    //     $('#per_day_salary').val(perDaySalary.toFixed(1));
    // }

    function per_day_salary_value() {

        let salary = parseFloat($('#basic_salary').val());

        if (isNaN(salary) || salary <= 0) {
            $('#per_day_salary').val('0.00');
            $('#per_hr_cost').val('0.00');
            return;
        }

        // ✅ Per Day
        let perDaySalary = salary / 30;
        perDaySalary = Math.round(perDaySalary * 100) / 100;
        $('#per_day_salary').val(perDaySalary.toFixed(1));

        // ✅ Per Hour (8 hrs default)
        let workingHours = 8;
        let perHour = salary / (30 * workingHours);
        perHour = Math.round(perHour * 100) / 100;
        $('#per_hr_cost').val(perHour.toFixed(1));
    }



    function salary_type_checked()
    {
        let salaryType =
            $('[name="salary_type"]:checked').val();

        if(salaryType == "2")
        {
            $('.statutorySection').removeClass('d-none');
        }
        else
        {
            $('.statutorySection').addClass('d-none');
        }
    }

    $(document).on(
        'change',
        '[name="salary_type"]',
        salary_type_checked
    );

    function resetSalaryCalculation() {
        console.log("reset salary")

        // Uncheck all components
        $('.comp-toggle').prop('checked', false);

        // Hide all component boxes
        $('[id^="comp_"]').addClass('d-none');
        $('[id^="card_comp_"]').addClass('bg-label-light');

        // Reset component values (optional: set to 0)
        // $('.comp-value').val(0);

        // Reset totals
        $('#total_earn').text('0.00');
        $('#total_ded').text('0.00');
        $('#net_salary').text('0.00');

        // Recalculate with clean state
        calculateSalary();
    }

    function salary_company_change() {


        let id = $('#salary_company_id').val();

        if (!id) return;

        $.ajax({
            url: '/company-banks/' + id,
            type: 'GET',
            success: function(res) {

                let options = '<option value="">Select Bank</option>';

                res.data.forEach(bank => {
                    options += `<option value="${bank.sno}" ${staff_bank_id == bank.sno ? 'selected' : ''}>
                            ${bank.bank_name} - ${bank.account_number}
                        </option>`;
                });

                $('#salary_bank_id').html(options);
            }
        });
    }

    function renderComponentCard(c) {

        let existing = existingSalaryComponents ? existingSalaryComponents.find(e => e.component_id == c.sno) : '';
        let isChecked = existing && existing.is_active == 1;
        let amount = existing ? existing.amount : (c.default_value || 0);
        let calcType = existing ? existing.calculation_type : c.calculation_type;

        return `
            <div class="card border-0 shadow-sm mb-2 p-2 ${isChecked ? '' : 'bg-label-light'}" id="card_comp_${c.sno}">

                <div class="d-flex justify-content-between">

                    <div>
                        <div class="fw-semibold">${c.component_name}</div>
                        <small class="text-muted">${c.calculation_type}</small>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input comp-toggle"
                            type="checkbox"
                            ${isChecked ? 'checked' : ''}
                            data-id="${c.sno}"
                            data-type="${c.type}"
                            data-rule="${c.rule_type}">
                    </div>

                </div>

                
                <div class="comp-box mt-2 ${isChecked ? '' : 'd-none'}" id="comp_${c.sno}">

                    <div class="d-flex gap-2">

                        <select class="form-select calc-type select3" data-id="${c.sno}">
                            <option value="fixed" ${calcType == 'fixed' ? 'selected' : ''}>₹</option>
                            <option value="percentage" ${calcType == 'percentage' ? 'selected' : ''}>%</option>
                        </select>

                        <input type="number"
                            class="form-control comp-value"
                            data-id="${c.sno}"
                            value="${amount}">

                    </div>

                </div>

            </div>
            `;
    }

    function loadComponents() {
        $.ajax({
            url: '/salary-components',
            type: 'GET',
            success: function(res) {

                let earn = '';
                let ded = '';

                res.forEach(c => {
                    let card = renderComponentCard(c);
                    if (c.type === 'earning') earn += card;
                    else ded += card;
                });

                $('#earnings_area').html(earn);
                $('#deductions_area').html(ded);

                calculateSalary();
            },
            error: function() {
                toastr.error('Failed to load salary components');
            }
        });

    }



    $(document).on('change', '.comp-toggle', function() {

        let id = $(this).data('id');
        let box = $('#comp_' + id);
        let card = $('#card_comp_' + id);

        if ($(this).is(':checked')) {
            box.removeClass('d-none').hide().slideDown(150);
            card.removeClass('bg-label-light');
        } else {
            box.slideUp(150, function() {
                $(this).addClass('d-none');
                card.addClass('bg-label-light');
            });
        }

        calculateSalary();

    });

    function calculateSalary() {
        console.log("calenter")

        let basic = parseFloat($('#basic_salary').val()) || 0;

        applyPayrollRules(basic);

        let earnings = basic;
        let deductions = 0;

        $('.comp-toggle:checked').each(function() {

            let id = $(this).data('id');
            let type = $(this).data('type');

            let val = parseFloat($(`.comp-value[data-id="${id}"]`).val()) || 0;
            let calc = $(`.calc-type[data-id="${id}"]`).val();

            if (calc === 'percentage') {
                val = (basic * val) / 100;
            }

            if (type === 'earning') earnings += val;
            else deductions += val;

        });

        $('#total_earn').text(earnings.toFixed(2));
        $('#total_ded').text(deductions.toFixed(2));
        $('#net_salary').text((earnings - deductions).toFixed(2));

    }

    $(document).on('input change', '.comp-value, .calc-type, #basic_salary', function() {
        calculateSalary();
    });

    $('#basic_salary').on('input', function() {

        let salary = parseFloat($(this).val()) || 0;

        let perDay = salary / 30;

        $('#per_day_salary').val(perDay.toFixed(2));

    });

    function collectSalaryComponents() {

        let components = [];

        $('.comp-toggle').each(function() {

            let id = $(this).data('id');

            components.push({
                component_id: id,
                amount: $(`.comp-value[data-id="${id}"]`).val() || 0,
                calc_type: $(`.calc-type[data-id="${id}"]`).val(),
                is_active: $(this).is(':checked') ? 1 : 0
            });

        });

        return components;
    }

    function applyPayrollRules(basic) {

        payrollRules.forEach(rule => {

            if (rule.rule_type === 'esi') {

                let limit = rule.condition.salary_limit || 0;

                $('.comp-toggle').each(function() {

                    let compRule = $(this).data('rule');
                    let id = $(this).data('id');

                    if (compRule === 'esi') {

                        if (basic > limit) {
                            $(this).prop('checked', false).prop('disabled', true);
                            $('#comp_' + id).addClass('d-none');
                            $('#card_comp_' + id).addClass('bg-label-light');
                        } else {
                            $(this).prop('disabled', false);
                            //  $('#card_comp_'+id).removeClass('bg-label-light');
                        }

                    }

                });

            }
        });

    }
</script>

<!-- Salary Appraisal -->
<script>
    function openSalaryAppraisal(staffId, name, mobile, email, image, salary_log_id, date_of_joining, shift_name) {

        //  FULL RESET (VERY IMPORTANT)
        $('#salary_staff_id').val('');
        $('#current_salary_id').val('');

        $('#current_salary_name').val('');
        $('#previous_salary_end_date').val('');
        $('#salary_start_date').val('');


        $('#currentsalaryPreview').addClass('d-none');
        $('#salaryPreview').addClass('d-none');

        $('#currentsalaryBox').hide();

        //  SET STAFF DATA
        $('#assign_staff_name').text(name);
        $('#assign_staff_mobile').text(mobile);
        $('#assign_staff_img').attr('src', image);

        $('#assign_staff_id').val(staffId);
        $('#current_shift_id').val(salary_log_id);

        //  HANDLE SHIFT LOGIC
        if (salary_log_id && salary_log_id != 0) {

            $('#currentsalaryBox').show();

            $('#current_salary_name').val(shift_name);

            let today = new Date().toISOString().split('T')[0];

            $('#previous_salary_end_date').val(today);
            $('#salary_start_date').val(today);

            // loadCurrentShiftDetails(salary_log_id);

        } else {

            $('#currentShiftBox').hide();

            $('#shift_start_date').val(date_of_joining);
        }

        $('#salaryAppraisalModal').modal('show');
    }
</script>
<script>
    function openEmployeeSalaryModal(employeeId, name, mobile, email, image) {

        $('#salary_staff_name').text(name);
        $('#salary_staff_mobile').text(mobile);
        $('#salary_staff_img').attr('src', image);

        $('#employeeSalaryForm')[0].reset();

        $('#employee_salary_components').html('');

        $('#employee_sno').val(employeeId);

        $('#employee_structure_sno').val('');

        /*
        |--------------------------------------------------------------------------
        | RESET SUMMARY
        |--------------------------------------------------------------------------
        */

        $('#emp_total_earnings').html('₹ 0.00');

        $('#emp_total_deductions').html('₹ 0.00');

        $('#emp_net_salary').html('₹ 0.00');

        $('#emp_ctc').html('₹ 0.00');

       

        $.get(
            '/payroll/employee-salary-accounts/' + employeeId,
            function(response){

                let html =
                    '<option value="">Select Account</option>';

                response.data.forEach(acc => {

                    html += `
                        <option value="${acc.sno}">
                            ${acc.company_name}
                            - ₹${acc.gross_salary}
                        </option>
                    `;
                });

                $('#salary_account_id').html(html);
            }
        );
    }
</script>
<script>
    function appendEmployeeComponent(detail) {
        let grossSalary = parseFloat( $('#employee_gross_salary').val()) || 0;
        let calculationType =detail.calculation_type || '';
        let percentage = parseFloat( detail.percentage_value ||detail.percentage || 0);
        let fixedAmount = parseFloat(detail.amount ||detail.fixed_amount || 0);
        let amount = parseFloat( detail.calculated_amount || 0);

        if (calculationType === 'percentage') {
            amount = (grossSalary * percentage) / 100;
        } else if (calculationType === 'fixed') {
            amount = fixedAmount;
        }

        let amountReadonly = calculationType === 'manual_input' ? '' : 'readonly';
        let badge = '';
        if (detail.component_type === 'earning') {
            badge =
                '<span class="badge bg-success">Earning</span>';
        } else if (
            detail.component_type === 'deduction'
        ) {
            badge =
                '<span class="badge bg-danger">Deduction</span>';
        } else {
            badge = '<span class="badge bg-primary">Employer</span>';
        }
        let html = `
            <div class="salary-component-row card border-0 shadow-sm rounded-4 mb-3"
                data-calculation-type="${calculationType}">

                <div class="card-body">

                    <div class="row align-items-end">

                        <div class="col-lg-4">
                            <label class="form-label fw-semibold">
                                Component
                            </label>

                            <input type="text"
                                class="form-control"
                                value="${detail.component_name}"
                                readonly>

                            <input type="hidden"
                                class="payroll_component_sno"
                                value="${detail.payroll_component_sno || detail.component_sno}">

                            <input type="hidden"
                                class="payroll_rule_sno"
                                value="${detail.payroll_rule_sno || ''}">
                        </div>

                        <div class="col-lg-2">

                            <label class="form-label fw-semibold">
                                Type
                            </label>

                            <div class="mt-2">${badge}</div>

                            <input type="hidden"
                                class="component_type"
                                value="${detail.component_type}">

                            <input type="hidden"
                                class="component_code"
                                value="${detail.component_code || ''}">

                            <input type="hidden"
                                class="rule_expression"
                                value="${detail.rule_expression || ''}">
                        </div>

                        <div class="col-lg-2">

                            <label class="form-label fw-semibold">
                                %
                            </label>

                            <input type="number"
                                class="form-control percentage_value"
                                value="${percentage}"
                                readonly>
                        </div>

                        <div class="col-lg-4">

                            <label class="form-label fw-semibold">
                                Amount
                            </label>

                            <div class="input-group">

                                <span class="input-group-text">
                                    ₹
                                </span>

                                <input type="text"
                                    class="form-control calculated_amount"
                                    value="${parseFloat(amount).toFixed(2)}"
                                    ${amountReadonly} oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
                            </div>
                        </div>

                    </div>

                </div>

            </div>
            `;
        $('#employee_salary_components').append(html);
        calculateEmployeeSalarySummary();
    }
</script>
<script>
    $(document).on('keyup change', '#employee_gross_salary', function() {
        let grossSalary = parseFloat($(this).val()) || 0;

        $('.salary-component-row').each(function() {
            let row = $(this);
            let calculationType = row.data('calculation-type');

            if (calculationType === 'percentage') {
                let percentage = parseFloat(row.find('.percentage_value').val()) || 0;
                let amount = (grossSalary * percentage) / 100;

                row.find('.calculated_amount').val(amount.toFixed(2));
            }
        });
        calculateEmployeeSalarySummary();
    });

    function calculateEmployeeSalarySummary() {

        let grossSalary =
            parseFloat($('#employee_gross_salary').val()) || 0;

        let earnings = 0;
        let deductions = 0;
        let employerContribution = 0;

        let basic = 0;
        let da = 0;

        /*
        |--------------------------------------------------------------------------
        | STEP 1
        | CALCULATE EARNINGS FIRST
        |--------------------------------------------------------------------------
        */

        $('.salary-component-row').each(function () {

            let row = $(this);

            let type =
                row.find('.component_type').val();

            if (type !== 'earning') {
                return;
            }

            let calculationType =
                row.data('calculation-type');

            let percentage =
                parseFloat(
                    row.find('.percentage_value').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.calculated_amount').val()
                ) || 0;

            /*
            |--------------------------------------------------------------------------
            | PERCENTAGE
            |--------------------------------------------------------------------------
            */

            if (calculationType === 'percentage') {

                amount =
                    (grossSalary * percentage) / 100;
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {

                amount =
                    parseFloat(
                        row.find('.calculated_amount').val()
                    ) || 0;
            }

            row.find('.calculated_amount')
                .val(parseFloat(amount).toFixed(2));

            /*
            |--------------------------------------------------------------------------
            | BASIC + DA
            |--------------------------------------------------------------------------
            */

            let componentCode =
                row.find('.component_code').val();

            if (componentCode === 'BASIC') {
                basic = amount;
            }

            if (componentCode === 'DA') {
                da = amount;
            }

            earnings += amount;
        });

        /*
        |--------------------------------------------------------------------------
        | STEP 2
        | DEDUCTIONS + EMPLOYER CONTRIBUTIONS
        |--------------------------------------------------------------------------
        */

        $('.salary-component-row').each(function () {

            let row = $(this);

            let type =
                row.find('.component_type').val();

            if (
                type !== 'deduction' &&
                type !== 'employer_contribution'
            ) {
                return;
            }

            let componentCode =
                row.find('.component_code').val();

            let calculationType =
                row.data('calculation-type');

            let percentage =
                parseFloat(
                    row.find('.percentage_value').val()
                ) || 0;

            let amount =
                parseFloat(
                    row.find('.calculated_amount').val()
                ) || 0;

            /*
            |--------------------------------------------------------------------------
            | PF
            |--------------------------------------------------------------------------
            */

            if (
                componentCode === 'PF' &&
                calculationType !== 'fixed'
            ) {

                let pfBase = basic + da;

                amount =
                    pfBase > 15000
                        ? 1800
                        : (pfBase * 0.12);
            }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYER PF
            |--------------------------------------------------------------------------
            */

            else if (
                componentCode === 'EMPLOYER_PF' &&
                calculationType !== 'fixed'
            ) {

                let pfBase = basic + da;

                amount =
                    pfBase > 15000
                        ? 1800
                        : (pfBase * 0.12);
            }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYEE ESI
            |--------------------------------------------------------------------------
            */

            else if (componentCode === 'ESI') {
                let esiBase = basic + da;
                if (esiBase > 21000) {
                    amount = 0;
                }else if (calculationType === 'fixed') {
                    amount = parseFloat( row.find('.calculated_amount').val()) || 0;
                }else {
                amount = esiBase * 0.0075;
            }
        }

            /*
            |--------------------------------------------------------------------------
            | EMPLOYER ESI
            |--------------------------------------------------------------------------
            */
            else if (componentCode === 'EMPLOYER_ESI') {
                let esiBase = basic + da;
                if (esiBase > 21000) {
                    amount = 0;
                }else if (calculationType === 'fixed') {
                    amount = parseFloat( row.find('.calculated_amount').val()) || 0;
                }else {
                    amount = esiBase * 0.0325;
                }
            }

            /*
            |--------------------------------------------------------------------------
            | NORMAL PERCENTAGE
            |--------------------------------------------------------------------------
            */

            else if (calculationType === 'percentage') {

                amount =
                    (grossSalary * percentage) / 100;
            }

            /*
            |--------------------------------------------------------------------------
            | FIXED / MANUAL
            |--------------------------------------------------------------------------
            */

            else if (
                calculationType === 'fixed' ||
                calculationType === 'manual_input'
            ) {
                if (componentCode === 'PT') {

                    amount =
                        grossSalary <= 10000
                            ? 140
                            : 208;
                }else{
                    amount =
                    parseFloat(
                        row.find('.calculated_amount').val()
                    ) || 0;
                }
                
            }

            row.find('.calculated_amount')
                .val(parseFloat(amount).toFixed(2));

            /*
            |--------------------------------------------------------------------------
            | TOTALS
            |--------------------------------------------------------------------------
            */

            if (type === 'deduction') {
                deductions += amount;
            }

            if (type === 'employer_contribution') {
                employerContribution += amount;
            }
        });

        /*
        |--------------------------------------------------------------------------
        | FINAL SUMMARY
        |--------------------------------------------------------------------------
        */

        let netSalary =
            earnings - deductions;

        let ctc =
            earnings + employerContribution;

        $('#emp_total_earnings').html(
            '₹ ' +
            earnings.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_total_deductions').html(
            '₹ ' +
            deductions.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_employer_contribution').html(
            '₹ ' +
            employerContribution.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_net_salary').html(
            '₹ ' +
            netSalary.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );

        $('#emp_ctc').html(
            '₹ ' +
            ctc.toLocaleString('en-IN', {
                minimumFractionDigits: 2
            })
        );
    }

    $(document).on('change', '#payroll_template_sno', function() {
        let templateId = $(this).val();
        $('#employee_salary_components').html('');
        if (templateId == '') {
            return;
        }
        $.ajax({
            url: '/payroll/template/components/' +
                templateId,
            type: 'GET',
            success: function(response) {
                let details = response.data.details;
                if (details.length > 0) {
                    details.forEach(detail => {
                        appendEmployeeComponent(detail);
                    });
                    calculateEmployeeSalarySummary();
                } else {
                    $('#employee_salary_components')
                        .html(`
                            <div class="alert alert-warning rounded-4">
                                No components found in template
                            </div>

                        `);
                }
            },
            error: function(xhr) {
                toastr.error(
                    xhr.responseJSON?.message ||
                    'Unable to load template components'
                );
            }
        });
    });
</script>
<script>
    function saveEmployeeSalaryStructure() {
        let employeeSno = $('#employee_sno').val();
        let payrollTemplateSno = $('#payroll_template_sno').val();
        let grossSalary = $('#employee_gross_salary').val();
        let effectiveFrom = $('#effective_from').val();
        let revisionReason = $('#revision_reason').val();
        if (employeeSno == '') {
            toastr.error('Employee not found');
            return;
        }
        if (grossSalary == '') {
            toastr.error('Gross salary required');
            return;
        }
        if (effectiveFrom == '') {
            toastr.error('Effective date required');
            return;
        }

        let details = [];
        $('.salary-component-row').each(function(index) {
            let row = $(this);
            let componentSno = row.find('.payroll_component_sno').val();
            let componentType = row.find('.component_type').val();
            let calculationType = row.data('calculation-type');
            let percentageValue = parseFloat(row.find('.percentage_value').val()) || 0;
            let calculatedAmount = parseFloat(row.find('.calculated_amount').val()) || 0;
            details.push({

                payroll_component_sno: componentSno,

                payroll_rule_sno: row.find('.payroll_rule_sno').val(),

                component_type: componentType,

                calculation_type: calculationType,

                percentage_value: percentageValue,

                calculated_amount: calculatedAmount,

                fixed_amount: calculatedAmount,

                include_in_ctc: 1,

                include_in_gross: componentType === 'earning' ? 1 : 0,

                include_in_payslip: 1,

                display_order: index + 1
            });
        });
        if (details.length == 0) {
            toastr.error(
                'Please add salary components'
            );
            return;
        }
        let btn = $('.save-employee-salary-btn');
        btn.prop('disabled', true);
        btn.html(` <span class="spinner-border spinner-border-sm me-2"></span> Saving...`);

        let payload = {
            _token: $('meta[name="csrf-token"]').attr('content'),
            employee_sno: employeeSno,
            salary_account_id:$('#salary_account_id').val(),
            payroll_template_sno: payrollTemplateSno,
            gross_salary: grossSalary,
            effective_from: effectiveFrom,
            revision_reason: revisionReason,
            details: details
        };

        $.ajax({
            url: '/payroll/employee-structure/save',
            type: 'POST',
            data: payload,
            success: function(response) {
                toastr.success(response.message);
                $('#employeeSalaryModal').modal('hide');
                if (typeof loadThemes === 'function') {
                    loadThemes(1);
                }
                if (typeof loadStaff === 'function') {
                    loadStaff(1);
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        toastr.error(value[0]);
                    });
                } else {
                    toastr.error(xhr.responseJSON?.message || 'Failed to save salary structure');
                }
            },
            complete: function() {
                btn.prop('disabled', false);
                btn.html(`<i class="mdi mdi-content-save-outline me-1"></i> Save Salary Structure`);
            }
        });
    }
</script>
<!-- variable Amount -->
<script>
    function addMonthlyInputRow(data = null) {
        let html = `
        <div class="monthly-input-row card border rounded-4 mb-3">

            <div class="card-body">

                <div class="row align-items-end">

                    <div class="col-lg-3">

                        <label class="form-label fw-semibold">
                            Component
                        </label>

                        <select class="form-select monthly_component">

                            <option value="">
                                Select Component
                            </option>

                            @foreach($components as $component)

                                <option value="{{ $component->sno }}">

                                    {{ $component->component_name }}

                                </option>

                            @endforeach

                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Type
                        </label>

                        <select class="form-select input_type">

                            <option value="earning">
                                Earning
                            </option>

                            <option value="deduction">
                                Deduction
                            </option>

                            <option value="reimbursement">
                                Reimbursement
                            </option>

                        </select>

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Qty
                        </label>

                        <input type="text"
                            class="form-control quantity"
                            value="1" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Rate
                        </label>

                        <input type="text"
                            class="form-control rate"
                            value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">

                    </div>

                    <div class="col-lg-2">

                        <label class="form-label fw-semibold">
                            Amount
                        </label>

                        <input type="text"
                            class="form-control amount"
                            value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">

                    </div>

                    <div class="col-lg-1">

                        <button type="button"
                            class="btn btn-danger remove-monthly-row">

                            <i class="mdi mdi-trash-can-outline"></i>

                        </button>

                    </div>

                </div>

            </div>

        </div>
        `;

        $('#monthly_input_rows').append(html);

        let row = $('.monthly-input-row').last();

        if (data) {

            row.find('.monthly_component')
                .val(data.payroll_component_sno);

            row.find('.input_type')
                .val(data.input_type);

            row.find('.quantity')
                .val(data.quantity);

            row.find('.rate')
                .val(data.rate);

            row.find('.amount')
                .val(data.amount);
        }
    }
</script>
<script>
    function openMonthlyInputModal(
        employeeId,
        name,
        mobile,
        email,
        image
    ) {

        $('#monthlyInputForm')[0].reset();

        $('#monthly_employee_sno')
            .val(employeeId);

        $('#variable_staff_name')
            .text(name);

        $('#variable_staff_mobile')
            .text(mobile);

        $('#variable_staff_img')
            .attr('src', image);

        $('#variable_alert').html('');

        /*
        |--------------------------------------------------------------------------
        | DEFAULT
        |--------------------------------------------------------------------------
        */

        $('#variable_from_month')
            .prop('disabled', false);

        $('#variable_from_month')
            .datepicker('update', '');

        $.ajax({

            url: '/payroll/variable-amount/get/' +
                employeeId,

            type: 'GET',

            success: function(response) {

                /*
                |--------------------------------------------------------------------------
                | ACTIVE VARIABLE EXISTS
                |--------------------------------------------------------------------------
                */

                if (
                    response.status &&
                    response.data
                ) {

                    let data = response.data;

                    $('#variable_amount')
                        .val(data.amount);

                    $('#remarks')
                        .val(data.remarks);

                    /*
                    |--------------------------------------------------------------------------
                    | DO NOT CHANGE EFFECTIVE MONTH
                    |--------------------------------------------------------------------------
                    */

                    $('#variable_from_month')
                        .val('');

                    $('#variable_from_month')
                        .prop('disabled', true);

                    /*
                    |--------------------------------------------------------------------------
                    | ALERT
                    |--------------------------------------------------------------------------
                    */

                    $('#variable_alert').html(`

                        <div class="alert alert-success rounded-4 border-0">

                            <div class="d-flex align-items-center">

                                <i class="mdi mdi-check-circle fs-2 me-3"></i>

                                <div>

                                    <div class="fw-bold">
                                        Active Variable Amount Found
                                    </div>

                                    <small>
                                        Valid Till :
                                        ${moment(data.end_month)
                                            .format('MMM YYYY')}
                                    </small>

                                </div>

                            </div>

                        </div>

                    `);
                }

                /*
                |--------------------------------------------------------------------------
                | NO ACTIVE VARIABLE
                |--------------------------------------------------------------------------
                */
                else {

                    $('#variable_from_month')
                        .prop('disabled', false);

                    $('#variable_alert').html(`

                        <div class="alert alert-warning rounded-4 border-0">

                            <div class="d-flex align-items-center">

                                <i class="mdi mdi-alert-circle fs-2 me-3"></i>

                                <div>

                                    <div class="fw-bold">
                                        No Active Variable Amount
                                    </div>

                                    <small>
                                        HR can create new variable amount.
                                    </small>

                                </div>

                            </div>

                        </div>

                    `);
                }

                $('#monthlyInputModal')
                    .modal('show');
            },

            error: function() {

                toastr.error(
                    'Unable to fetch variable amount'
                );
            }
        });
    }
</script>

<script>
    function saveVariableAmount() {

        $.ajax({

            url: '/payroll/variable-amount/save',

            type: 'POST',

            data: {

                _token: $('meta[name="csrf-token"]').attr('content'),

                employee_sno: $('#monthly_employee_sno').val(),

                payroll_component_sno: $('#payroll_variable_component_sno').val(),

                amount: $('#variable_amount').val(),

                start_month: $('#variable_from_month').val(),

                remarks: $('#remarks').val()
            },

            success: function(response) {

                toastr.success(response.message);

                $('#monthlyInputModal')
                    .modal('hide');
            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Save failed'
                );
            }
        });
    }
</script>
<script>

</script>
<script>
    function openBulkSalaryModal() {

        $('#bulkSalaryModal').modal('show');

        $('#bulk_salary_preview_body').html('');

        $('#bulk_total_staff').html('0 Staff');
    }

    function previewBulkSalaryEmployees() {

        $.ajax({

            url: '/payroll/bulk/preview',

            type: 'GET',

            success: function(response) {

                let rows = '';

                let total = 0;

                response.data.forEach(item => {

                    total++;

                    let newTemplate =
                        item.salary_type == 1
                        ? $('#bulk_template_type_1 option:selected').text()
                        : $('#bulk_template_type_2 option:selected').text();

                    rows += `
                    <tr>

                        <td>
                            <strong>${item.staff_name}</strong>
                            <br>
                            <small>${item.staff_id}</small>
                        </td>

                        <td>
                            ${
                                item.salary_type == 1
                                ? '<span class="badge bg-success">CASH</span>'
                                : '<span class="badge bg-primary">BANK</span>'
                            }
                        </td>

                        <td>
                            ${item.current_template ?? 'No Structure'}
                        </td>

                        <td>
                            ${item.effective_from ?? '-'}
                        </td>

                        <td>
                            ${item.effective_to ?? 'Current'}
                        </td>

                        <td>
                            <span class="text-success fw-bold">
                                ${newTemplate}
                            </span>
                        </td>

                        <td>
                            ${$('#bulk_effective_from').val()}
                        </td>

                    </tr>
                    `;
                });

                $('#bulk_salary_preview_body').html(rows);

                $('#bulk_total_staff')
                    .html(total + ' Staff');

            },

            error: function() {

                toastr.error('Failed to load employees');

            }

        });

    }

    function saveBulkSalaryStructure() {

        let payload = {

            _token: $('meta[name="csrf-token"]').attr('content'),

            template_type_1: $('#bulk_template_type_1').val(),

            template_type_2: $('#bulk_template_type_2').val(),

            effective_from: $('#bulk_effective_from').val(),

            revision_reason: $('#bulk_revision_reason').val()

        };

        let btn = $('#bulk_salary_save_btn');

        btn.prop('disabled', true);

        btn.html(`
        <span class="spinner-border spinner-border-sm"></span>
        Processing...
    `);

        $.ajax({

            url: '/payroll/bulk/save',

            type: 'POST',

            data: payload,

            success: function(response) {

                toastr.success(response.message);

                $('#bulkSalaryModal').modal('hide');

            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Failed'
                );

            },

            complete: function() {

                btn.prop('disabled', false);

                btn.html(`
                <i class="mdi mdi-content-save"></i>
                Apply Bulk Salary Structure
            `);

            }

        });

    }
</script>

<script>
    function openOTPayrollModal(
        employeeId,
        name
    ) {
        $('#ot_monthly_employee_sno').val(employeeId);
        $('#ot_staff_name').html(name);
        $('#ot_table_body').html('');
        $('#ot_summary').html('');
        $('#otPayrollModal').modal('show');
        loadOTDetails();
    }
</script>
<script>
    function loadOTDetails() {
        let employeeId = $('#ot_monthly_employee_sno').val();

        let month = $('#ot_month').val();

        $('#ot_table_body').html(`
            <tr>
                <td colspan="11" class="text-center">
                <div class="spinner-border text-primary">
                </div>
                <p class="mt-2">
                Loading OT Details...
                </p>
                </td>
            </tr>
        `);

        $.ajax({
            url: '/payroll/ot/details',
            type: 'GET',
            data: {
                employee_sno: employeeId,
                month: month
            },
            success: function(response) {
                let rows = '';
                let totalAmount = 0;
                let totalHours = 0;
                response.data.forEach(item => {
                    totalAmount += parseFloat(item.ot_amount);
                    totalHours += parseFloat(item.ot_hours);
                    rows += `

                    <tr class="ot-row">

                        <td>

                            ${item.date}

                            <input
                                type="hidden"
                                class="attendance_date"
                                value="${item.date}">

                        </td>

                        <td>

                            <span class="badge bg-dark">

                                ${item.day}

                            </span>

                        </td>

                        <td>

                            <span class="badge

                                ${item.attendance_type == 'OT'
                                    ? 'bg-danger'
                                    : 'bg-success'}">

                                ${item.attendance_type}

                            </span>

                        </td>

                        <td>

                            ${item.shift_time ?? '-'}

                        </td>

                        <td>

                            ${item.actual_in ?? '-'}

                        </td>

                        <td>

                            ${item.actual_out ?? '-'}

                        </td>

                        <td>

                            ${item.worked_hours
                                ? formatHours(item.worked_hours)
                                : '-'}

                        </td>

                        <td>

                            <strong class="text-primary">

                                ${formatHours(item.ot_hours)}

                            </strong>

                            <input
                                type="hidden"
                                class="ot_hours"
                                value="${item.ot_hours}">

                        </td>

                        <td>

                            ₹ ${Number(item.ot_rate).toFixed(2)}

                        </td>

                        <td>

                            <input
                                type="text"
                                class="form-control ot_amount"
                                value="${item.ot_amount}"
                                step="0.01" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">

                        </td>

                        <td>

                            <input
                                type="text"
                                class="form-control remarks"
                                value="${item.remarks ?? ''}">

                        </td>

                    </tr>

                    `;

                    $('#ot_table_body').html(rows);
                })
                $('#total_ot_hours').html(formatHours(totalHours));

                $('#total_ot_days').html(response.data.length);

                $('#overall_ot_amount').html( totalAmount.toFixed(2));

                $('#department_name').html(response.department_name ?? '-');

                if(response.data.length == 0)
                {
                    $('#ot_table_body').html(`

                    <tr>

                        <td colspan="11"
                            class="text-center text-muted">

                            No OT records found

                        </td>

                    </tr>

                    `);

                    return;
                }
            } 
        });
    }
</script>
<script>
    function saveOTPayroll() {

        $('#btnSaveOT')
        .prop('disabled', true)
        .html(
            '<span class="spinner-border spinner-border-sm"></span> Saving...'
        );

        let rows = [];
        $('#ot_table_body tr').each(function() {
            rows.push({
                attendance_date:
                    $(this)
                        .find('.attendance_date')
                        .val(),
                ot_hours:
                    $(this)
                        .find('.ot_hours')
                        .val(),
                ot_amount:
                    $(this)
                        .find('.ot_amount')
                        .val(),
                remarks:
                    $(this)
                        .find('.remarks')
                        .val()
            });
        });
        $.ajax({
            url: '/payroll/ot/save',
            type: 'POST',
            data: {
                _token:$('meta[name="csrf-token"]').attr('content'),
                employee_sno: $('#ot_monthly_employee_sno').val(),
                payroll_month:$('#ot_month').val(),
                rows: rows
            },
            success: function(response) {
                toastr.success(response.message);
                $('#otPayrollModal').modal('hide');
                $('#btnSaveOT')
                .prop('disabled', false)
                .html('Save OT Payroll');
                
            },
            error: function(xhr) {
                $('#btnSaveOT')
                .prop('disabled', false)
                .html('Save OT Payroll');
                toastr.error(
                    xhr.responseJSON?.message ||
                    'Save failed'
                );
            }
        });
    }
</script>
<script>
function formatHours(hours) {
    let totalMinutes = Math.round(hours * 60);
    let hrs = Math.floor(totalMinutes / 60);
    let mins = totalMinutes % 60;
    let result = '';
    if (hrs > 0) {
        result += hrs + ' hr ';
    }
    if (mins > 0) {
        result += mins + ' mins';
    }
    return result.trim();
}
</script>
<script>

    $(document).on(
    'change',
    '.ot_amount',
    function(){

        $(this)
        .closest('tr')
        .addClass('table-warning');

    });

function calculateTotalOTAmount()
{
    let total = 0;
    $('.ot_amount').each(function(){
        total += parseFloat(
            $(this).val()
        ) || 0;

    });
    $('#overall_ot_amount')
        .html(total.toFixed(2));
}

$(document).on(
'keyup change',
'.ot_amount',
calculateTotalOTAmount
);

</script>

<script>
    function openTransferModel(staffSno)
    {
        $('#transfer_staff_sno').val(staffSno);

        $('#transferSummaryCard').html('');
        window.currentTransferData = null;

        $.ajax({
            url: '/staff/get-transfer-data',
            type: 'GET',
            data: {
                staff_sno: staffSno
            },

            beforeSend: function () {

                $('#staffTransferProfile').html(`
                    <div class="">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-md-2 text-center">
                                    <div class="skeleton-transfer skeleton-circle-transfer mx-auto"></div>
                                </div>
                                <div class="col-md-10">
                                    <div class="skeleton-transfer skeleton-title-transfer"></div>
                                    <div class="skeleton-transfer skeleton-badge-transfer mb-4"></div>
                                    <div class="row mt-4">
                                        ${Array(6).fill(`
                                            <div class="col-md-4 mb-3">
                                                <div class="border rounded p-3">
                                                    <div class="skeleton-transfer skeleton-text-transfer w-50 mb-2"></div>
                                                    <div class="skeleton-transfer skeleton-text-transfer"></div>
                                                </div>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `);

            },

            success: function (res)
            {
                renderTransferStaffProfile(res);
                toggleDivs();

                window.currentTransferData = res;
            
            }
        });
    }

    function renderTransferStaffProfile(data)
    {
        $('#staffTransferProfile').html(`
            <div class="">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-2 text-center">
                            <img src="${data.profile_image_url}" class="rounded-circle border" width="110" height="110">
                        </div>
                        <div class="col-md-10">
                            <span class="fs-5 fw-bold text-dark">
                                ${data.staff_name}
                            </span>
                            <span class="badge bg-primary">
                                ${data.staff_id}
                            </span>
                            <div class="row mt-4">
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Company</small>
                                        <h6>
                                            ${data.company_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Entity</small>
                                        <h6>
                                            ${data.entity_name}
                                        </h6>
                                    </div>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Branch</small>
                                        <h6>
                                            ${data.branch_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Department</small>
                                        <h6>
                                            ${data.department_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Division</small>
                                        <h6>
                                            ${data.division_name}
                                        </h6>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3">
                                        <small>Job Role</small>
                                        <h6>
                                            ${data.job_role_name}
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
    }

    function triggerTransferPreview()
    {
        setTimeout(function(){

            generateTransferSummary();

        },200);
    }

    // $(document).on(
    //     'change',
    //     '.transfer-field',
    //     function () {

    //         console.log('field changed');

    //         triggerTransferPreview();
    //     }
    // );

    function generateTransferSummary()
    {
        let oldData = window.currentTransferData;
        let company = $('#transfer_company option:selected').val() ? $('#transfer_company option:selected').text() : '-';
        let entity = $('#transfer_entity option:selected').val() ? $('#transfer_entity option:selected').text() : '-';
        let branch = $('#transfer_branch option:selected').val() ?  $('#transfer_branch option:selected').text() : '-';
        let department =$('#transfer_department option:selected').val() ? $('#transfer_department option:selected').text() : '-';
        let division =$('#transfer_division option:selected').val()  ? $('#transfer_division option:selected').text() : '-';
        let jobRole =$('#transfer_job_role option:selected').val() ? $('#transfer_job_role option:selected').text() : '-';
        let role =$('#transfer_role option:selected').val() ? $('#transfer_role option:selected').text() : '-';

        $('#transferSummaryCard').html(`
            <div class="card border-warning shadow">
                <div class="card-header bg-warning">
                    <h4 class="mb-0 text-dark fw-bold">
                        Transfer Summary
                    </h4>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h4 class="text-danger">
                                Current Details
                            </h4>
                            <hr>
                            <p>
                                <b>Company :</b>
                                ${oldData.company_name}
                            </p>
                            <p>
                                <b>Entity :</b>
                                ${oldData.entity_name}
                            </p>
                            <p>
                                <b>Branch :</b>
                                ${oldData.branch_name}
                            </p>
                            <p>
                                <b>Department :</b>
                                ${oldData.department_name}
                            </p>
                            <p>
                                <b>Division :</b>
                                ${oldData.division_name}
                            </p>
                            <p>
                                <b>Job Role :</b>
                                ${oldData.job_role_name}
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h4 class="text-success">
                                Transfer To
                            </h4>
                            <hr>
                            <p><b>Company :</b> ${company}</p>
                            <p><b>Entity :</b> ${entity}</p>
                            <p><b>Branch :</b> ${branch}</p>
                            <p><b>Department :</b> ${department}</p>
                            <p><b>Division :</b> ${division}</p>
                            <p><b>Job Role :</b> ${jobRole}</p>
                            <p><b>User Role :</b> ${role}</p>

                        </div>
                    </div>
                </div>
            </div>

        `);

        
    }

    function transferStaff()
    {
        let btn = $('#btnTransferStaff');
        btn.prop('disabled', true);
        const reloadPage = tableState.currentPage;
        let validate = false;
        let company_type = 1;
        let company_id = 0;
        let entity_id = 0;
        let branch_id = 0;

        if($("#transfer_business").is(":checked")){
            company_type = 2;
            company_id = $('#transfer_company').val();
            if(!company_id){
                validate =true;
                toastr.error('Company is Required');
                btn.prop('disabled', false);
                return false;
            }
            entity_id =$('#transfer_entity').val();
            if(!entity_id){
                validate =true;
                toastr.error('Entity is Required');
                btn.prop('disabled', false);
                return false;
            }
            branch_id =$('#transfer_branch').val();
            if(!branch_id){
                    validate =true;
                    toastr.error('Branch is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        }

        let department_id =$('#transfer_department').val();
        if(!department_id){
                    validate =true;
                    toastr.error('Department is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let division_id =$('#transfer_division').val();
        if(!division_id){
                    validate =true;
                    toastr.error('Division is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let job_role_id =$('#transfer_job_role').val();
        if(!division_id){
                    validate =true;
                    toastr.error('Job Role is Required');
                    btn.prop('disabled', false);
                    return false;
                }
        let role_id =$('#transfer_role').val();
        if(!role_id){
            validate =true;
            toastr.error('User Role is Required');
                btn.prop('disabled', false);
            return false;
        }

        $.ajax({
            url: '/staff/transfer',
            type: 'POST',
            data: {
                _token:$('meta[name="csrf-token"]').attr('content'),
                staff_sno: $('#transfer_staff_sno').val(),
                company_type:company_type,
                company_id:company_id ,
                entity_id: entity_id,
                branch_id: branch_id,
                department_id:department_id,
                division_id: division_id,
                job_role_id: job_role_id,
                role_id:role_id,
                reason_id: $('#transfer_reason').val(),
                reason_comment: $('#transfer_comments_text').val()
            },
            success: function(res)
            {
                if(res.status)
                {
                    toastr.success(res.message);
                    $('#kt_modal_staff_transferModel').modal('hide');
                    loadThemes(reloadPage);
                }
                else
                {
                    toastr.error(res.message);
                }
            },
            complete:function()
            {
                btn.prop('disabled', false);
            }
        });
    }
</script>
<script>
    function toggleInputField_tranfer(value) {

        var leaveCommentsDiv = document.getElementById('transfer_comments_div');
        var selectedOption = document.querySelector('#transfer_reason option:nth-child(' + (document.getElementById(
            'transfer_reason').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (commentsCheck == '1') {
            leaveCommentsDiv.style.display = 'block';
        } else {
            leaveCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>
     $(document).ready(function() {
            // Business dropdown
            $('#transfer_company').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#transfer_entity');
                var branchDropdown = $('#transfer_branch');
                var departmentDropdown = $('#transfer_department');
                var divisionDropdown = $('#transfer_division');
                var jobroleDropdown = $('#transfer_job_role');
                var userroleDropdown = $('#transfer_role');

                stateDropdown.empty().append('<option value="">Select Entity</option>');
                branchDropdown.empty().append('<option value="">Select Branch</option>');
                departmentDropdown.empty().append('<option value="">Select Department</option>');
                divisionDropdown.empty().append('<option value="">Select Division</option>');
                jobroleDropdown.empty().append('<option value="">Select Job Role</option>');
                userroleDropdown.empty().append('<option value="">Select User Role</option>');
                if (countryId) {
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
                triggerTransferPreview()
            });
            // depart list
            $('#transfer_entity').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#transfer_department');
                var branchDropdown = $('#transfer_branch');
                var roleDropdown = $('#transfer_role');

                branchDropdown.empty().append('<option value="">Select Branch</option>');
                stateDropdown.empty().append('<option value="">Select Department</option>');
                roleDropdown.empty().append('<option value="">Select User Role</option>');

                if (entity_id) {
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('entity_branch_dropdown_list') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    branchDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.branch_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('user_role_by_entity') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    roleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.role_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Role:', error);
                        }
                    });

                }

                 triggerTransferPreview()
            });
            
            // division dropdown
             $('#transfer_department').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#transfer_division');
                var jobroleDropdown = $('#transfer_job_role');
                stateDropdown.empty().append('<option value="">Select Division</option>');
                jobroleDropdown.empty().append('<option value="">Select Job Role</option>');
               

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
                 triggerTransferPreview()
             });

              $('#transfer_division').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#transfer_job_role');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

               
                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
                 triggerTransferPreview()
             });          
            
    });

    function toggleDivs() {
        if ($("#transfer_management").is(":checked")) {
            $(".business_div").hide();
             var entity_id = 0;
                var stateDropdown = $('#transfer_department');
                var roleDropdown = $('#transfer_role');

               
                stateDropdown.empty().append('<option value="">Select Department</option>');
                roleDropdown.empty().append('<option value="">Select User Role</option>');

      
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('user_role_by_entity') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    roleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .text(state.role_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Role:', error);
                        }
                    });
             triggerTransferPreview()
                
        } else if ($("#transfer_business").is(":checked")) {
            $(".business_div").show();
             triggerTransferPreview()
        }
    }
</script>

<script>
    function accountTypeChange() {
        let accountType = $('[name="is_multiple_account"]:checked').val();
        if (accountType == 1) {
            // Multiple Account
            $('#multipleAccountDiv').removeClass('d-none');
            $('#singleAccountDiv').addClass('d-none');
            $('.companyBankSection').addClass('d-none');
            calculateMultipleAccountTotals();
        } else {
            // Single Account
            $('#multipleAccountDiv').addClass('d-none');
            $('#singleAccountDiv').removeClass('d-none');
            if ($('#salary_bank').is(':checked')) {
                $('.companyBankSection').removeClass('d-none');
            }
            per_day_salary_value();
        }
    }


    function addSalaryAccountRow(data = null)
    {
        let row = $(`
        <tr>
            <input type="hidden" class="salary-account-sno" value="${data?.sno || ''}">
            <td>
                <input type="radio" name="primary_account" class="primary-account form-check-input" ${data?.is_primary ? 'checked' : ''}>
            </td>
            <td >
                <select class="form-select company-id select3" onchange="companyBankChange(this)">
                    ${companyOptions}
                </select>
            </td>
            <td>
                <select class="form-select bank-id select3">
                    <option value="">Select Bank</option>
                </select>
            </td>
            <td>
                <input type="text" class="form-control gross-salary" value="${data?.gross_salary || 0}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
            </td>
            <td>
                <input type="text" class="form-control per-day" value="${data?.per_day_salary || 0}" readonly>
            </td>
            <td>
                <input type="text" class="form-control per-hour" value="${data?.per_hour_cost || 0}" readonly>
            </td>
            <td>
                <button type="button" class="btn btn-danger btn-sm remove-row">x</button>
            </td>
        </tr>
        `);

        $('#salaryAccountBody').append(row);

        row.find('.select3').each(function () {
            if ($(this).hasClass('select2-hidden-accessible')) {
                $(this).select2('destroy');
            }
            $(this).select2({
                dropdownParent: $('#multipleAccountDiv'),
                width: '100%'
            });
        });

        if(data){
            row.find('.company-id').val(data.salary_company_id).trigger('change');
            setTimeout(() => {
                row.find('.bank-id').val(data.salary_bank_id);
            }, 500);
        }
    }

    $(document).on(
        'input',
        '.gross-salary',
        function () {

            let salary =
                parseFloat($(this).val()) || 0;

            let perDay =
                salary / 30;

            let perHour =
                salary / (30 * 8);

            let row =
                $(this).closest('tr');

            row.find('.per-day')
                .val(perDay.toFixed(2));

            row.find('.per-hour')
                .val(perHour.toFixed(2));

            calculateMultipleAccountTotals();
        }
    );

    function collectSalaryAccounts()
    {
        let accounts = [];
        $('#salaryAccountBody tr').each(function()
        {
            accounts.push({
                sno: $(this).find('.salary-account-sno').val(),
                salary_company_id:$(this).find('.company-id').val(),
                salary_bank_id:$(this).find('.bank-id').val(),
                gross_salary:$(this).find('.gross-salary').val(),
                per_day_salary:$(this).find('.per-day').val(),
                per_hour_cost:$(this).find('.per-hour').val(),
                is_primary:$(this).find('.primary-account').is(':checked') ? 1 : 0
            });
        });
        return accounts;
    }

    
    function companyBankChange(element) {
        let companyId = $(element).val();
        let bankDropdown =$(element).closest('tr').find('.bank-id');
        bankDropdown.html('<option value="">Loading...</option>');
        $.ajax({
            url: '/company-banks/' + companyId,
            type: 'GET',
            success: function (res) {
                let options ='<option value="">Select Bank</option>';
                res.data.forEach(bank => {
                    options += `
                    <option value="${bank.sno}">
                        ${bank.bank_name}-${bank.account_number}
                    </option>
                    `;
                });
                bankDropdown.html(options);
            }
        });
    }
    function calculateMultipleAccountTotals()
    {
        let totalSalary = 0;
        let totalPerDay = 0;
        let totalPerHour = 0;

        $('#salaryAccountBody tr').each(function()
        {
            totalSalary +=
                parseFloat($(this).find('.gross-salary').val()) || 0;

            totalPerDay +=
                parseFloat($(this).find('.per-day').val()) || 0;

            totalPerHour +=
                parseFloat($(this).find('.per-hour').val()) || 0;
        });

        $('#total_gross_salary')
            .val(totalSalary.toFixed(2));

        $('#total_per_day')
            .val(totalPerDay.toFixed(2));

        $('#total_per_hour')
            .val(totalPerHour.toFixed(2));
    }

    $(document).on(
        'click',
        '.remove-row',
        function()
        {
            $(this).closest('tr').remove();

            calculateMultipleAccountTotals();
        }
    );
</script>
<script>
   
    function salary_account_change(){
        let employeeId =$('#employee_sno').val();
        let accountId = $('#salary_account_id').val();
        loadSalaryStructure( employeeId,accountId );

    }

    function loadSalaryStructure(employeeId,accountId){
            $.ajax({ url: '/payroll/employee-structure/get/' + employeeId+ '/'+ accountId,
                type: 'GET',
                success: function(response) {
                    let data = response.data;
                    /*
                    |--------------------------------------------------------------------------
                    | IF STRUCTURE EXISTS
                    |--------------------------------------------------------------------------
                    */
                    if (data.structure) {
                        $('#employee_structure_sno').val(data.structure.sno);
                        $('#payroll_template_sno').val(data.structure.payroll_template_sno).trigger('change');
                        $('#employee_gross_salary').val(data.structure.gross_salary);
                        $('#effective_from').val(data.structure.effective_from);
                        $('#revision_reason').val( data.structure.revision_reason);
                        /*
                        |--------------------------------------------------------------------------
                        | COMPONENT DETAILS
                        |--------------------------------------------------------------------------
                        */
                        if (data.details && data.details.length > 0) {
                            data.details.forEach(detail => {
                                appendEmployeeComponent(detail);

                            });
                        }
                    } else {
                        $('#payroll_template_sno').val('').trigger('change');
                        $('#employee_gross_salary').val(data.employee.gross_salary || 0 );
                        $('#effective_from').val('');
                        $('#revision_reason').val('');
                        $('#employee_salary_components').html(`
                            <div class="alert alert-warning rounded-4 border-0">
                                <div class="d-flex align-items-center">
                                    <i class="mdi mdi-alert-circle-outline fs-2 me-3"></i>
                                    <div>
                                        <div class="fw-bold">
                                            No Salary Structure Found
                                        </div>
                                        <small>
                                            Create employee salary structure by selecting template.
                                        </small>
                                    </div>
                                </div>
                            </div>
                        `);
                    }
                    calculateEmployeeSalarySummary();
                    $('#employeeSalaryModal').modal('show');
                },

                error: function(xhr) {
                    toastr.error(
                        xhr.responseJSON?.message || 'Unable to load employee structure'
                    );
                }
            });
        
    }
</script>

<script>
    function openSalaryHistoryModal(employeeId)
    {
        $('#salaryHistoryForm')[0].reset();

        $('#history_employee_sno').val(employeeId);

        $('#salary_history_content').html(`
            <div class="text-center py-10">
                <div class="spinner-border text-primary"></div>
            </div>
        `);

        $('#salaryHistoryModal').modal('show');

        loadSalaryHistoryData(employeeId);
    }

    function loadSalaryHistoryData(employeeId)
    {
        $.ajax({
            url : '/payroll/history/employee/' + employeeId,
            type : 'GET',
            success : function(response)
            {
                renderSalaryHistory(response);
            },
            error : function(xhr)
            {
                toastr.error( xhr.responseJSON?.message ||'Failed to load employee');
            }
        });
    }

    function renderSalaryHistory(response)
    {
        let employee = response.employee;
        let accounts = response.accounts || [];
        let lastAppraisal = response.last_appraisal || null;

        document.getElementById('history_staff_img').src =
            employee.profile_image_url ||
            '/assets/egc_images/auth/user_2.png';

        $('#history_staff_name').text(employee.staff_name);
        $('#history_staff_mobile').text(employee.staff_id);

         let options = '';

        accounts.forEach(account => {

            options += `
                <option value="${account.sno}"
                        data-gross="${account.gross_salary}"
                        data-day="${account.per_day_salary}"
                        data-hour="${account.per_hour_cost}">

                    ${account.is_primary == 1 ? 'Primary' : 'Secondary'}
                    -
                    ₹ ${account.gross_salary}

                </option>
            `;
        });

        let templateOptions = '';
        let templates = @json($salaryTemplates);

        templates.forEach(account => {
            templateOptions += `
                <option value="${account.sno}">${account.template_name}</option>
            `;
        });

        

        window.payrollTemplateOptions = templateOptions;

        

    

        $('#employee_summary_card').html(`
            <div class="card shadow-sm mb-4">

                <div class="card-header bg-light">
                    Employee Information
                </div>

                <div class="card-body">

                    <div class="mb-2">
                        <strong>ID :</strong>
                        ${employee.staff_id}
                    </div>

                    <div class="mb-2">
                        <strong>Joining :</strong>
                        ${employee.date_of_joining ?? '-'}
                    </div>

                    <div class="mb-2">
                        <strong>Total Revisions :</strong>
                        ${response.appraisal_history.length}
                    </div>
                    <div class="mb-3">

                        <label>Salary Account</label>

                        <select id="salary_account_select">

                        </select>

                    </div>

                </div>

            </div>
        `);

        $('#current_salary_card').html(`
            <div class="card shadow-sm mb-4">

                <div class="card-header bg-success text-white">
                    Current Active Salary
                </div>

                <div class="card-body">

                    <h2 class="text-success">

                        ₹ ${Number(response.current_salary)
                            .toLocaleString('en-IN')}

                    </h2>

                    <div class="mt-2">

                        Effective From :
                        ${response.current_effective_from}

                    </div>

                </div>

            </div>
        `);

        renderTimeline(response.appraisal_history || []);
       
    }
</script>


<script>
    function saveSalaryRevision(){
        let payload = {
            _token : $('meta[name="csrf-token"]').attr('content'),
            employee_sno :$('#history_employee_sno').val(),
            salary_account_id :$('#salary_account_select').val(),
            current_salary :$('#current_salary').val(),
            revised_salary :$('#revised_salary').val(),
            per_day_salary :$('#per_day_salary').val(),
            per_hour_cost :$('#per_hour_cost').val(),
            appraisal_type :$('#appraisal_type').val(),
            appraisal_unit :$('#appraisal_unit').val(),
            appraisal_value :$('#appraisal_value').val(),
            appraisal_reason :$('#appraisal_reason').val(),
            effective_from :$('#effective_from').val(),
            effective_to :$('#effective_to').val()
        };

        if(payload.salary_account_id == ''){
            toastr.error('Select Salary Account');
            return;
        }
        if(payload.appraisal_type == ''){
            toastr.error('Select Appraisal Type');
            return;
        }

        if(payload.effective_from == ''){
            toastr.error('Select Effective From');
            return;
        }

        $.ajax({
            url : '/payroll/appraisal/save',
            type : 'POST',
            data : payload,
            success : function(response)
            {
                toastr.success(response.message);
                $('#salaryHistoryModal').modal('hide');
                loadStaff(1);
            },
            error : function(xhr)
            {
                toastr.error(
                    xhr.responseJSON?.message ||
                    'Failed to save appraisal'
                );
            }
        });
    }
</script>
<script>
    function renderTimeline(history)
    {
        let rows = '';

        if(history.length > 0)
        {
            history.forEach((item,index)=>{

                rows += `
                <tr>

                    <td>
                        ${item.effective_from ?? '-'}
                    </td>

                    <td>
                        ${item.appraisal_type ?? '-'}
                    </td>

                    <td>
                        ₹ ${Number(item.current_gross_salary || 0)
                            .toLocaleString('en-IN')}
                    </td>

                    <td>
                        ₹ ${Number(item.revised_gross_salary || 0)
                            .toLocaleString('en-IN')}
                    </td>

                    <td>
                        ${item.appraisal_reason ?? '-'}
                    </td>

                    <td>

                        ${
                            index === history.length - 1
                            ? '<span class="badge bg-success">Current</span>'
                            : '<span class="badge bg-secondary">History</span>'
                        }

                    </td>

                </tr>
                `;
            });
        }
        else
        {
            // rows = `
            // <tr>
            //     <td colspan="6" class="text-center">
            //         No Appraisal History Found
            //     </td>
            // </tr>
            // `;
        }

        $('#salary_revision_section').html(`
            <div class="card shadow-sm">

                <div class="card-header bg-light d-flex justify-content-between">

                    <h5 class="mb-0">
                        Salary Appraisal Timeline
                    </h5>

                    <button
                        type="button"
                        class="btn btn-sm btn-primary"
                        onclick="addHistoryRow()">
                        Add History
                    </button>

                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                     <table class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Current</th>
                                <th>Effective From</th>
                                <th>Effective To</th>
                                <th>Appraisal Type</th>
                                <th>Unit</th>
                                <th>Value</th>
                                <th>Reason</th>
                                <th>Gross Salary</th>
                                <th>Payroll Template</th>
                                <th>Earnings</th>
                                <th>Deductions</th>
                                <th>Net Salary</th>
                                <th>Employer Contribution</th>
                                <th>CTC</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="timeline_body">
                            ${rows}
                        </tbody>
                    </table>
                    </div>
                </div>

            </div>
        `);
    }
</script>

<script>
    function addHistoryRow()
{
   
    const rowHtml = `
        <tr class="new-history-row">

            <td>
                <input  type="radio"  name="current_row" class="current_salary_row">
            </td>

            <td>
                <input type="text" class="form-control history_from common_datepicker_cust" placeholder="Select Effective From" readonly>
            </td>

            <td>
                <input type="text" class="form-control history_to common_datepicker_cust" placeholder="Select Effective To" readonly>
            </td>

            <td>
                <select class="form-select history_type select3 ">
                    <option value="Joining">Joining</option>
                    <option value="Yearly Appraisal">Yearly Appraisal</option>
                    <option value="Performance">Performance</option>
                    <option value="Project">Project</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="10X Warrior">10X Warrior</option>
                </select>
            </td>

            <td>
                <select class="form-select history_unit select3">
                    <option value="percentage">%</option>
                    <option value="value">Value</option>
                </select>
            </td>

            <td>
                <input type="text" placeholder="Enter Value" class="form-control history_value" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
            </td>
            <td>
                <textarea class="form-control history_reason" rows="1"></textarea>
            </td>

            <td>
                <input type="text" class="form-control gross_salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
            </td>

            <td>
                <select class="form-select payroll_template select3">
                    ${window.payrollTemplateOptions}
                </select>
            </td>

            <td>
                <input type="text" class="form-control earnings" readonly>
            </td>

            <td>
                <input type="text" class="form-control deductions" readonly>
            </td>
            <td>
                <input type="text" class="form-control net_salary" readonly>
            </td>

            <td>
                <input type="text" class="form-control employer_contribution" readonly>
            </td>
            <td>
                <input type="text" class="form-control ctc_amount" readonly>
            </td>
            <td>
                <button type="button" class="btn btn-sm btn-danger" onclick="$(this).closest('tr').remove()">
                    X
                </button>
            </td>
        </tr>
    `;
    $('#timeline_body').append(rowHtml);

    const $newRow = $('#timeline_body tr:last');

    $newRow.find('.select3').select2({
        width: '100%',
        dropdownParent: $('#salary_revision_section'),
        placeholder: 'Select'
    });

    $('.common_datepicker_cust').datepicker({
        todayHighlight: true,
        autoclose: true,
        format: 'dd-M-yyyy'
    });

}
</script>
<script>
    function saveBulkHistory()
{
    let histories = [];

    $('#timeline_body tr').each(function(){

        let row = $(this);

        if(row.find('.history_date').length)
        {
            histories.push({

                effective_from :
                    row.find('.history_from').val(),

                effective_to :
                    row.find('.history_to').val(),

                appraisal_type :
                    row.find('.history_type').val(),

                appraisal_unit_type :
                    row.find('.history_unit').val(),

                appraisal_value :
                    row.find('.history_value').val(),

                appraisal_reason :
                    row.find('.history_reason').val(),

                gross_salary :
                    row.find('.gross_salary').val(),

                payroll_template_sno :
                    row.find('.payroll_template').val(),

                is_current :
                    row.find('.current_salary_row').is(':checked')
                    ? 1
                    : 0
            });
        }
    });

    $.ajax({

        url : '/payroll/appraisal/bulk-save',

        type : 'POST',

        data : {
            _token : $('meta[name=csrf-token]').attr('content'),
            employee_sno : $('#history_employee_sno').val(),
            histories : histories
        },

        success : function(response)
        {
            toastr.success(response.message);

            $('#salaryHistoryModal').modal('hide');

            loadStaff(1);
        }
    });
}
</script>
<script>
    let appraisalRowIndex = 0;

    function openAppraisalSalaryHistoryModal( employeeId, employeeName, mobileNo,employeeImage ){

        resetSalaryHistoryModal();

        $("#employee_sno").val(employeeId);
        $("#emp_name").text(employeeName);
        $("#emp_mobile").text(mobileNo);
        $("#emp_image").attr("src",employeeImage);

        $("#AppraisalsalaryHistoryModal").modal("show");

        $("#salaryTimeline").html(getTimelineLoader());
        $("#historyRows").empty();
        appraisalRowIndex = 0;
        $("#pending_count").text("Loading...");
        $("#current_salary_hist").text("Loading...");

        loadSalaryAccounts(employeeId);
        // addAppraisalHistoryRow();

        loadSalaryHistory(employeeId);  
            // editable cards
          

        // loadSalaryTimeline(employeeId);     // bottom timeline

    }

    function loadSalaryHistory(employeeId)
    {

        $("#historyRows").empty();
        appraisalRowIndex = 0;
        $("#current_salary_hist").text("Loading...");
        $("#pending_count").text("Loading...");

        $.ajax({
            url: "/payroll/appraisal/history/" + employeeId,
            type: "GET",
            success: function (res)
            {

                if (!res.status) {
                    toastr.error("Unable to load history");
                    return;
                }

                $("#current_salary_hist").text("₹" + Number(res.current_salary || 0).toLocaleString());
                $("#pending_count").text(res.pending_history || 0);

                let rows = res.data;
                if(rows.length==0){
                    addAppraisalHistoryRow();
                    renderEmptyTimeline();
                    return;
                }

                

                rows.forEach(function(item){
                    addAppraisalHistoryRow(item);
                });

                renderTimelineHistory(rows);

            },

            error:function(){
                toastr.error("Unable to load salary history.");
                $("#current_salary_hist").text('₹0');
                $("#pending_count").text(0);

            }

        });

    }
    
    function resetSalaryHistoryModal(){
        $("#employee_sno").val("");
        $("#emp_name").text("-");
        $("#emp_mobile").text("-");
        $("#emp_image").attr("src","/assets/egc_images/auth/user_2.png");
        $("#historyRows").empty();
        appraisalRowIndex = 0;
        renderEmptyTimeline();
        $("#history_account").html("");
        $("#current_salary_hist").text("₹0");
        $("#pending_count").text("0");
    }

    function getTimelineLoader(){
        return `
        <div class="text-center py-5">
            <div class="spinner-border text-warning" role="status">
            </div>
            <div class="mt-3">
                Loading salary history...
            </div>
        </div>

        `;
    }

    function addAppraisalHistoryRow(data = {}) {

        appraisalRowIndex++;

        const rowId = appraisalRowIndex;

        const templateOptions = $("#history_template_master").html();

        const html = `
        <div class="card appraisal-row border-0 shadow-sm mb-4" id="historyRow_${rowId}">
            <div class="card-header bg-light">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="history-title mb-1">Appraisal #${rowId}</h5>
                        <small class="text-muted">Salary Revision Details</small>
                    </div>
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeHistoryRow(${rowId})">
                        <i class="mdi mdi-delete-outline"></i>
                    </button>
                </div>
            </div>
            <div class="card-body" id="history_row_add_${rowId}">
                <input type="hidden" class="history_sno" value="${data.sno ?? ''}">
                <div class="row g-3">
                    <div class="col-lg-3">
                        <label class="form-label">Effective Month</label>
                        <input type="text" placeholder="select Month" class="form-control effective_month month_picker" value="${data.effective_from ? data.effective_from.substring(0,7) : ''}">
                    </div>
                    <div class="col-lg-3">
                        <label class="form-label">Gross Salary</label>
                        <input type="text" placeholder="Enter Gross Salary" class="form-control gross_salary" value="${data.gross_salary ?? ''}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
                    </div>
                    <div class="col-lg-3" >
                        <label class="form-label">Payroll Template</label>
                        <select class="form-select template_select select3" id="history_pay_template_${rowId}">
                            ${templateOptions}
                        </select>
                    </div>
                    <div class="col-lg-3">
                        <label class="form-label">Appraisal Type</label>
                        <select class="form-select appraisal_type select3" id="history_appr_type_${rowId}">
                            <option value="0">Joining</option>
                            <option value="1">Yearly Appraisal</option>
                            <option value="2">Special Appraisal</option>
                            <option value="3">Promotion</option>
                            <option value="5">10X Warrior</option>
                        </select>
                    </div>
                </div>
                <div class="joining-section mt-4">
                    <div class="row g-3">
                        <div class="col-lg-2">
                            <label class="form-label">Unit </label>
                            <select class="form-select appraisal_unit select3" id="history_appr_unit_${rowId}">
                                <option value="%">%</option>
                                <option value="Rs">Rs</option>
                            </select>
                        </div>
                        <div class="col-lg-2">
                            <label class="form-label"> Value</label>
                            <input  type="text" class="form-control appraisal_value" placeholder="Enter Value" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
                        </div>
                        <div class="col-lg-8">
                            <label class="form-label">Reason</label>
                            <textarea rows="2" class="form-control appraisal_reason" placeholder="Enter Reason"></textarea>
                        </div>
                    </div>
                </div>
                <hr class="my-4">
                <div class="form-check mb-3">
                    <input  type="checkbox" class="form-check-input variable_check" id="variable_${rowId}" onclick="changeCheckVariable(this)">
                    <label class="form-check-label" for="variable_${rowId}"> Variable Incentive</label>
                </div>
                <div class="variable-section d-none">
                    <div class="row g-3">
                        <div class="col-lg-4">
                            <label class="form-label">Variable Amount</label>
                            <input type="text" class="form-control variable_amount" placeholder="Enter Variable Amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '')">
                        </div>
                        <div class="col-lg-3">
                            <label class="form-label"> Start Month</label>
                            <input type="text" class="form-control variable_from variable_month_picker" placeholder="select Start Month" onchange="changeVariableMonth(this)">
                        </div>
                        <div class="col-lg-2">
                            <label class="form-label">Months</label>
                            <input type="text" class="form-control variable_months" value="${data.variable_months ?? 3}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" onkeyup="changeVariableMonth(this)">
                        </div>
                        <div class="col-lg-3">
                            <label class="form-label">End Month</label>
                            <input readonly class="form-control variable_end">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;

        $("#historyRows").append(html);
        const row = $("#historyRow_" + rowId);
        row.find(".template_select").val(data.payroll_template_sno ?? "");
        row.find(".appraisal_type").val(data.appraisal_type ?? 0);
        row.find(".appraisal_unit").val(data.appraisal_unit ?? "%");
        row.find(".appraisal_value").val(data.appraisal_value ?? "");
        row.find(".appraisal_reason").val(data.appraisal_reason ?? "");
        row.find(".variable_amount") .val(data.variable_amount ?? "");
        row.find(".variable_months").val(data.variable_months ?? 3);
        row.find(".template_select,.appraisal_type,.appraisal_unit")
            .select2({
                width: "100%",
                dropdownParent: $("#history_row_add_"+ rowId)
            });
        
        row.find(".month_picker").datepicker({
            format: "yyyy-mm",
            minViewMode: "months",
            autoclose: true,
            endDate: new Date()
        });
        row.find(".variable_month_picker").datepicker({
            format: "yyyy-mm",
            minViewMode: "months",
            autoclose: true,
            endDate: new Date()
        });

        if (parseFloat(data.variable_amount || 0) > 0) {

            row.find(".variable_check").prop("checked", true);

            row.find(".variable-section").removeClass("d-none");

            row.find(".variable_amount").val(data.variable_amount);

            row.find(".variable_months").val(data.variable_months);

            // If backend sends these
            row.find(".variable_from").val(data.variable_from || "");
            row.find(".variable_end").val(data.variable_end_month || "");

            calculateVariableEndMonth(row);
        }

        row.find(".appraisal_type").trigger("change");

        row[0].scrollIntoView({
            behavior: "smooth",
            block: "center"
        });

    }

    function removeHistoryRow(id){
        $("#historyRow_"+id)
            .slideUp(150,function(){
                $(this).remove();
                $(".history-title").each(function(i){
                    $(this).text("Appraisal #"+(i+1));
                });
            });
    }

    function reArrangeHistoryRows()
    {
        $(".appraisal-row").each(function(index){

            $(this)
            .find(".history-title")
            .text("Appraisal #" + (index + 1));

        });
    }

    $(document).on("change", ".appraisal_type", function () {
        let row = $(this).closest(".appraisal-row");
        let type = $(this).val();
        if (type == "0") {
            row.find(".joining-section").slideUp(150);
            row.find(".variable-section").slideUp(150);
            row.find(".variable_check").prop("checked", false);

        } else {
            row.find(".joining-section").slideDown(150);
        }
        if(type=="0"){
            row.find(".variable_check").prop("checked",false).prop("disabled",true);
        }
        else {
            row.find(".variable_check").prop("disabled",false);
        }

    });
    
    function loadSalaryAccounts(employeeId)
    {
        $("#history_account").html(
            '<option>Loading Salary Accounts...</option>'
        );

       

        $.ajax({
            url: "/payroll/employee-salary-accounts/" + employeeId,
            type: "GET",
            dataType: "json",
            success: function(response){

                if(!response.status){
                    toastr.error(response.message);
                    return;
                }

                let html = '';
               
              
                

                if(response.data.length == 0){
                    html = `
                        <option value="">No Salary Account Found</option>
                    `;
                    
                    
                }else{
                    response.data.forEach(function(account){
                        html += `
                            <option
                                value="${account.sno}"
                                ${account.is_current == 1 ? 'selected' : ''}>
                                ${account.company_name}
                                - ₹${parseFloat(account.gross_salary).toLocaleString()}
                            </option>
                        `;
                    });

                   

                }
                

                $("#history_account").html(html);
                $("#history_account").trigger("change");

            },

            error:function(xhr){

                $("#history_account").html(
                    '<option value="">Unable to Load</option>'
                );

              

                toastr.error(
                    xhr.responseJSON?.message ??
                    "Unable to load salary accounts."
                );

            }

        });

    }

    function changeCheckVariable(element) {

        const row = $(element).closest(".appraisal-row");
        const section = row.find(".variable-section");

        if ($(element).is(":checked")) {

            section
                .removeClass("d-none")
                .hide()
                .slideDown(200);

        } else {

            section.slideUp(200, function () {

                $(this).addClass("d-none");

            });

            row.find(".variable_amount").val("");
            row.find(".variable_months").val(3);
            row.find(".variable_end").val("");
        }
    }
    

    function changeVariableMonth(element){
         const row = $(element).closest(".appraisal-row");
         calculateVariableEndMonth(row);
    }

  

    

    function calculateVariableEndMonth(row) {

        let start = row.find(".variable_from").val();

        let months = parseInt(
            row.find(".variable_months").val()
        );

        if (!start || isNaN(months) || months <= 0) {
            row.find(".variable_end").val("");
            return;
        }

        let dt = new Date(start + "-01");

        dt.setMonth(dt.getMonth() + months - 1);

        let month = String(dt.getMonth() + 1).padStart(2, "0");

        row.find(".variable_end").val(
            dt.getFullYear() + "-" + month
        );
    }

    $(document).off("click","#saveHistoryBtn").on("click","#saveHistoryBtn",bulkSaveHistory);

    function bulkSaveHistory() {
        const payload = collectHistoryRows();
        if (!payload) {
            return;
        }
        submitHistory(payload);
    }

    function submitHistory(payload) {

        const btn = $("#saveHistoryBtn");

        btn.prop("disabled", true).html('<span class="spinner-border spinner-border-sm me-2"></span>Saving...');

        $.ajax({
            url: "/payroll/appraisal/history/bulk-save",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(payload),
            headers: {
                "X-CSRF-TOKEN":
                $('meta[name="csrf-token"]').attr("content")
            },
            success: function(res) {
                toastr.success(res.message);
                loadSalaryHistory(payload.employee_sno);
            },
            error: function(xhr) {
                toastr.error(xhr.responseJSON?.message ?? "Unable to save salary history.");
            },
            complete: function() {
                btn.prop("disabled", false).html('<i class="mdi mdi-content-save-outline me-1"></i>Save Salary History');
            }
        });

    }

    function collectHistoryRows() {

        const payload = {
            employee_sno: $("#employee_sno").val(),
            history: []
        };

        let valid = true;
        let months = [];
        $(".appraisal-row").each(function () {
            const row = $(this);
            row.find(".is-invalid").removeClass("is-invalid");
            const history = {
                sno: row.find(".history_sno").val(),
                salary_account_id: $("#history_account").val(),
                payroll_template_sno: row.find(".template_select").val(),
                effective_from: row.find(".effective_month").val(),
                gross_salary: row.find(".gross_salary").val(),
                appraisal_type: row.find(".appraisal_type").val(),
                appraisal_unit: row.find(".appraisal_unit").val(),
                appraisal_value: row.find(".appraisal_value").val(),
                appraisal_reason: row.find(".appraisal_reason").val(),
                variable_check: row.find(".variable_check").is(":checked") ? 1 : 0,
                variable_amount: row.find(".variable_amount").val(),
                variable_from: row.find(".variable_from").val(),
                variable_months: row.find(".variable_months").val(),
                variable_end_month: row.find(".variable_end").val(),
            };

            if (!validateHistoryRow(row, history, months)) {
                valid = false;
            }

            months.push(history.effective_from);
            payload.history.push(history);
        });

        if (!valid) {
            toastr.error("Please correct highlighted fields." );
            return false;
        }
        return payload;
    }

    function validateHistoryRow(row, history, months) {

        let valid = true;
        function invalid(el) {
            row.find(el).addClass("is-invalid");
            valid = false;
        }

        if (!history.salary_account_id)
            invalid("#history_account");

        if (!history.payroll_template_sno)
            invalid(".template_select");

        if (!history.effective_from)
            invalid(".effective_month");

        if (!history.gross_salary || history.gross_salary <= 0)
            invalid(".gross_salary");

        if (months.includes(history.effective_from)) {
            toastr.error("Duplicate effective month.");
            invalid(".effective_month");
        }

        if (history.variable_check) {
            if (!history.variable_amount)
                invalid(".variable_amount");

            if (!history.variable_months)
                invalid(".variable_months");
        }
        return valid;

    }

    function renderEmptyTimeline() {

        $("#salaryTimeline").html(`
            <div class="text-center">

                <i class="mdi mdi-history text-warning fs-1"
                ></i>

                <h5 class="mt-3">
                    No Salary History Found
                </h5>

                <p class="text-muted">
                    Create the employee's historical salary records using the
                    <strong>Add Appraisal</strong> button above.
                </p>

            </div>
        `);

    }
    function renderTimelineHistory(rows) {

        const timeline = $("#salaryTimeline");

        timeline.empty();

        if (!rows || rows.length === 0) {
            renderEmptyTimeline();
            return;
        }

        // Sort by Effective Month
        rows.sort(function (a, b) {
            return a.effective_from.localeCompare(b.effective_from);
        });

        let html = `
            <div class="salary-timeline">
        `;

        rows.forEach(function (item, index) {

            const salary = Number(item.gross_salary || 0).toLocaleString();

            const appraisalBadge = {
                0: "secondary",
                1: "primary",
                2: "warning",
                3: "success",
                5: "danger"
            };

            const badgeColor = appraisalBadge[item.appraisal_type] || "secondary";

            const processedHtml = item.processed
                ? `<span class="badge bg-success">Processed</span>`
                : `<span class="badge bg-warning text-dark">Pending</span>`;

            html += `
            <div class="timeline-item position-relative ps-5 pb-4">

                <div class="timeline-dot bg-primary"></div>

                <div class="card shadow-sm border-0">

                    <div class="card-header bg-light d-flex justify-content-between align-items-center">

                        <div>

                            <span class="badge bg-${badgeColor}">
                                ${item.appraisal_type_name}
                            </span>

                            <span class="ms-2 fw-bold">
                                ${item.effective_from}
                            </span>

                        </div>

                        ${processedHtml}

                    </div>

                    <div class="card-body">

                        <div class="row">

                            <div class="col-md-4 mb-2">

                                <small class="text-muted d-block">
                                    Gross Salary
                                </small>

                                <strong class="text-success">
                                    ₹${salary}
                                </strong>

                            </div>

                            <div class="col-md-4 mb-2">

                                <small class="text-muted d-block">
                                    Payroll Template
                                </small>

                                <strong>
                                    ${item.template_name ?? "-"}
                                </strong>

                            </div>

                            <div class="col-md-4 mb-2">

                                <small class="text-muted d-block">
                                    Company
                                </small>

                                <strong>
                                    ${item.account_name ?? "-"}
                                </strong>

                            </div>

                        </div>
            `;

            if (parseFloat(item.appraisal_value || 0) > 0) {

                html += `
                    <hr>

                    <div class="row">

                        <div class="col-md-4">

                            <small class="text-muted d-block">
                                Appraisal
                            </small>

                            <strong>
                                ${item.appraisal_value}
                                ${item.appraisal_unit}
                            </strong>

                        </div>

                        <div class="col-md-8">

                            <small class="text-muted d-block">
                                Reason
                            </small>

                            <strong>
                                ${item.appraisal_reason ?? "-"}
                            </strong>

                        </div>

                    </div>
                `;
            }

            if (parseFloat(item.variable_amount || 0) > 0) {

                html += `
                    <hr>

                    <div class="row">

                        <div class="col-md-4">

                            <small class="text-muted d-block">
                                Variable Incentive
                            </small>

                            <strong class="text-primary">
                                ₹${Number(item.variable_amount).toLocaleString()}
                            </strong>

                        </div>

                        <div class="col-md-4">

                            <small class="text-muted d-block">
                                Months
                            </small>

                            <strong>
                                ${item.variable_months}
                            </strong>

                        </div>

                    </div>
                `;
            }

            html += `
                    </div>

                </div>

            </div>
            `;

        });

        html += `</div>`;

        timeline.html(html);

    }
</script>

<script>
     let currentStaffpassword = null;
    /* ================================================================
     STAFF PROFILE VIEW
    =================================== */
    (() => {
        'use strict';
        let currentStaffViewId = null;
       
        let staffViewAbortController = null;

        const STAFF_DEFAULT_IMAGE ="{{ asset('assets/egc_images/auth/user_2.png') }}";
        /* ================================================================
           MAIN VIEW FUNCTION
        ================================================================= */
        window.viewStaff = async function(id) {
            if (!id) {
                console.error('Staff ID is required.');
                return;
            }
            $('#view_staff_id_hidden').val(id);
             resetPasswordSecurityUI();
            currentStaffViewId = id;
            // Initialize Salary & Payroll for this employee.
            if (typeof window.prepareStaffSalaryPayroll === 'function') {
                window.prepareStaffSalaryPayroll(id);
            }

            resetStaffView();
            showStaffViewLoading();

            if (staffViewAbortController) {
                staffViewAbortController.abort();
            }

            staffViewAbortController = new AbortController();

            try {
                const response = await fetch(
                    `/staff_detailed_view/${encodeURIComponent(id)}`,
                    {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        signal: staffViewAbortController.signal
                    }
                );

                /*
                 * Try parsing JSON safely.
                 */
                let result = null;

                try {
                    result = await response.json();
                } catch (jsonError) {
                    throw new Error('The server returned an invalid response.' );
                }

                if ( !response.ok || Number(result.status) !== 200 || !result.data) {
                    throw new Error( result.error_msg || result.message || 'Unable to load employee information.');
                }

                renderStaffProfile(result.data);
                hideStaffViewLoading();
                currentStaffpassword = result.data.password;

            } catch (error) {
                if (error.name === 'AbortError') {
                    return;
                }
                console.error('Staff View Error:',error);
                hideStaffViewLoading();
                showStaffViewError( error.message || 'Something went wrong while loading the employee profile.' );
            }

        };


        /* ================================================================
           MASTER RENDER
        ================================================================= */

        function renderStaffProfile(staff) {

            if (!staff) {
                showStaffViewError(
                    'Employee information is unavailable.'
                );
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | 1. Generic data-staff-field rendering
            |--------------------------------------------------------------------------
            */
            renderGenericFields(staff);
            /*
            |--------------------------------------------------------------------------
            | 2. Profile Header
            |--------------------------------------------------------------------------
            */
            renderProfileHeader(staff);
            /*
            |--------------------------------------------------------------------------
            | 3. Overview
            |--------------------------------------------------------------------------
            */
            renderOverview(staff);
            /*
            |--------------------------------------------------------------------------
            | 4. Personal
            |--------------------------------------------------------------------------
            */
            renderPersonalInformation(staff);
            /*
            |--------------------------------------------------------------------------
            | 5. Family
            |--------------------------------------------------------------------------
            */
            renderFamilyInformation(staff);
            /*
            |--------------------------------------------------------------------------
            | 6. Contact
            |--------------------------------------------------------------------------
            */
            renderContactInformation(staff);
            /*
            |--------------------------------------------------------------------------
            | 7. Employment
            |--------------------------------------------------------------------------
            */
            renderEmploymentInformation(staff);
            /*
            |--------------------------------------------------------------------------
            | 8. Work Experience
            |--------------------------------------------------------------------------
            */
            renderCurrentWorkingExperience(staff);

            renderWorkExperience(staff);
            /*
            |--------------------------------------------------------------------------
            | 9. Education
            |--------------------------------------------------------------------------
            */
            renderEducation(staff);
            /*
            |--------------------------------------------------------------------------
            | 10. Access / Credentials
            |--------------------------------------------------------------------------
            */
            renderAccessInformation(staff);
            /*
            |--------------------------------------------------------------------------
            | 11. Documents
            |--------------------------------------------------------------------------
            */
            renderDocuments(staff);
            /*
            |--------------------------------------------------------------------------
            | 12. Document Checklist
            |--------------------------------------------------------------------------
            */
            renderDocumentChecklist(staff);
            /*
            |--------------------------------------------------------------------------
            | 13. Summary Counters
            |--------------------------------------------------------------------------
            */
            renderSummaryCounts(staff);
            /*
            |--------------------------------------------------------------------------
            | 14. Profile Completion
            |--------------------------------------------------------------------------
            */
            renderProfileCompletion(staff);
            /*
            |--------------------------------------------------------------------------
            | Show rendered content
            |--------------------------------------------------------------------------
            */
            document.querySelectorAll('#kt_modal_view_staff .staff-skeleton-group')
                .forEach(element => {
                    element.classList.add('d-none');
                });

            document.querySelectorAll('#kt_modal_view_staff .staff-view-data')
                .forEach(element => {
                    element.classList.remove('d-none');
                });

        }


        /* ================================================================
           GENERIC FIELD RENDERER
        ================================================================= */

        function renderGenericFields(staff) {

                document.querySelectorAll('#kt_modal_view_staff [data-staff-field]' )
                .forEach(element => {

                    const field = element.dataset.staffField;

                    let value = getNestedValue( staff, field );

                    /*
                     * Date fields
                     */
                    if (element.classList.contains('staff-date')) {
                        value = formatStaffDate(value);
                    }
                    setText(element,value);
                });
        }

        /* ================================================================
           PROFILE HEADER
        ================================================================= */

        function renderProfileHeader(staff) {
            /*
             * Profile image
             */
            const imageElement = document.getElementById('viewStaffProfileImage');

            if (imageElement) {
                imageElement.src = valueOrNull(staff.profile_image_url) || STAFF_DEFAULT_IMAGE;

                imageElement.onerror = function() {
                    this.onerror = null;
                    this.src = STAFF_DEFAULT_IMAGE;
                };
            }

            /*
             * Name
             */

            setTextById('viewStaffName',staff.staff_name );

            /*
             * Job Role
             */
            setTextById('viewStaffJobRole', staff.job_role_name );
            /*
             * Department
             */
            setTextById('viewStaffDepartment',staff.department_name );

            /*
             * Employee ID
             *
             * Prefer staff_id.
             * Fall back to sno.
             */
            setTextById('viewStaffEmployeeId', staff.staff_id || staff.employee_id || staff.sno );
            /*
             * Company / Entity
             */
            let companyDisplay = staff.company_name || staff.entity_name || '-';

            if (valueOrNull(staff.company_name) && valueOrNull(staff.entity_name)) {
                companyDisplay = `${staff.company_name} / ${staff.entity_name}`;
            }

            setTextById('viewStaffCompany',companyDisplay );

            /*
             * Joining Date
             */

            setTextById('viewStaffJoiningDate', formatDateCommon(staff.date_of_joining));

            /*
             * Email
             */
            setTextById('viewStaffEmail',staff.email_id );

            const emailLink = document.getElementById('viewStaffEmailLink');

            if (emailLink) {
                if (valueOrNull(staff.email_id)) {
                    emailLink.href = `mailto:${staff.email_id}`;
                    emailLink.classList.remove('pe-none');
                } else {
                    emailLink.href = '#';
                    emailLink.classList.add('pe-none');
                }
            }
            /*
             * Mobile
             */
            setTextById('viewStaffMobile',staff.mobile_no );

            const mobileLink = document.getElementById('viewStaffMobileLink');

            if (mobileLink) {
                if (valueOrNull(staff.mobile_no)) {
                    mobileLink.href = `tel:${staff.mobile_no}`;
                    mobileLink.classList.remove('pe-none');
                } else {
                    mobileLink.href = '#';
                    mobileLink.classList.add('pe-none');
                }
            }

            /*
             * Experience Type
             */

            const experienceType = getExperienceType(staff.exp_type);

            setTextById('viewStaffExperienceType',experienceType);

            /*
             * Login Access
             */

            const loginAccess = isEnabled(staff.login_access) ? 'Enabled' : 'Disabled';

            setTextById('viewStaffLoginAccess', loginAccess);

            /*
             * Employment Status
             */
            renderEmploymentStatus(staff);

        }


        /* ================================================================
           EMPLOYMENT STATUS
        ================================================================= */

        function renderEmploymentStatus(staff) {

            const badge = document.getElementById('viewStaffEmploymentBadge');
            const indicator = document.getElementById('viewStaffStatusIndicator');

            if (!badge) {
                return;
            }

            /*
             * Your application excludes status = 2,
             * so active/inactive handling can be adjusted
             * according to your actual status values.
             */
            const active = Number(staff.status) !== 2;

            badge.className = active ? 'badge bg-label-success' : 'badge bg-label-danger';

            badge.textContent = active ? 'Active' : 'Inactive';

            if (indicator) {
                indicator.className = active ? 'staff-status-indicator bg-success' : 'staff-status-indicator bg-danger';
            }

        }

        /* ================================================================
           OVERVIEW
        ================================================================= */

        function renderOverview(staff) {

            const companyType = getCompanyType(staff.company_type);

            setTextById('overviewCompanyType',companyType);

            let companyEntity = '-';

            if (valueOrNull(staff.company_name) && valueOrNull(staff.entity_name)) {
                companyEntity =`${staff.company_name} / ${staff.entity_name}`;
            } else {
                companyEntity = staff.company_name || staff.entity_name || '-';
            }

            setTextById('overviewCompanyEntity', companyEntity);
            setTextById('overviewExperienceType', getExperienceType(staff.exp_type));

            /*
             * Skills
             */
            renderTagCollection('viewStaffSkillsContainer',staff.skills,'No skills available');

        }


        /* ================================================================
           PERSONAL INFORMATION
        ================================================================= */

        function renderPersonalInformation(staff) {
            /*
             * Gender
             */
            setTextById('personalGender', getGender(staff.gender));
            /*
             * Blood Group
             *
             * Backend may return resolved name or raw value.
             */
            setTextById('personalBloodGroup', staff.blood_group_name || staff.blood_group || '-' );
            /*
             * Nationality
             */
            setTextById( 'personalNationality', staff.nationality_name || staff.nationality || '-');
            /*
             * Religion
             */
            setTextById( 'personalReligion',staff.religion_name || staff.religion || '-');
            /*
             * Community
             */
            setTextById('personalCommunity', staff.community_name || staff.community || '-' );
            /*
             * Marital Status
             */
            setTextById( 'personalMaritalStatus',getMaritalStatus(staff.martial_status));
            /*
             * Vehicle
             */
            setTextById('personalVehicleStatus',isEnabled( staff.vehicle_status || staff.has_vehicle ) ? 'Available' : 'Not Available' );
            /*
             * Languages
             */
            renderTagCollection('viewStaffLanguagesContainer',staff.language_known,'No languages added' );
            /*
             * Hobbies
             */
            renderTagCollection('viewStaffHobbiesContainer', staff.hobbies, 'No hobbies added' );
        }


        /* ================================================================
           FAMILY INFORMATION
        ================================================================= */

        function renderFamilyInformation(staff) {

            renderChildren( normalizeArray( staff.children));

            renderSiblings(normalizeArray(staff.siblings));

        }


        /* ================================================================
           CHILDREN
        ================================================================= */

        function renderChildren(children) {

            const container = document.getElementById('viewStaffChildrenContainer');
            const count =document.getElementById('viewStaffChildrenCount');
            if (count) {
                count.textContent = children.length;
            }
            if (!container) {
                return;
            }

            if (!children.length) {
                container.innerHTML =
                    emptyStateHTML(
                        'mdi-account-child-outline',
                        'No children information',
                        'No children details have been added.'
                    );
                return;
            }


            container.innerHTML =
                `<div class="row g-4">
                    ${
                        children.map(
                            (child, index) => {

                                return `
                                    <div class="col-md-6 col-xl-4">
                                        <div class="staff-info-item h-100">
                                            <div class="d-flex align-items-center gap-2 mb-2">
                                                <div class="staff-contact-icon">
                                                    <i class="mdi mdi-account-child-outline"></i>
                                                </div>
                                                <strong class="fs-7 text-gray-800">
                                                    ${escapeHTML(
                                                        child.name ||
                                                        `Child ${index + 1}`
                                                    )}
                                                </strong>
                                            </div>

                                            <div class="fs-8 text-muted mb-1">

                                                Gender:
                                                <strong class="text-gray-700">

                                                    ${escapeHTML(
                                                        getGender(
                                                            child.gender
                                                        )
                                                    )}

                                                </strong>

                                            </div>

                                            <div class="fs-8 text-muted">

                                                Date of Birth:
                                                <strong class="text-gray-700">

                                                    ${escapeHTML(
                                                        formatDateCommon(child.dob)
                                                    )}

                                                </strong>

                                            </div>

                                        </div>

                                    </div>
                                `;

                            }
                        ).join('')
                    }
                </div>`;

        }


        /* ================================================================
           SIBLINGS
        ================================================================= */

        function renderSiblings(siblings) {

            const container =
                document.getElementById(
                    'viewStaffSiblingsContainer'
                );


            const count =
                document.getElementById(
                    'viewStaffSiblingsCount'
                );


            if (count) {

                count.textContent =
                    siblings.length;

            }


            if (!container) {
                return;
            }


            if (!siblings.length) {

                container.innerHTML =
                    emptyStateHTML(
                        'mdi-account-multiple-outline',
                        'No sibling information',
                        'No sibling details have been added.'
                    );

                return;

            }


            container.innerHTML =
                `<div class="row g-4">

                    ${
                        siblings.map(
                            (sibling, index) => {

                                return `
                                    <div class="col-md-6 col-xl-4">

                                        <div class="staff-info-item h-100">

                                            <strong class="fs-7 text-gray-800 mb-2">

                                                ${escapeHTML(
                                                    sibling.name ||
                                                    `Sibling ${index + 1}`
                                                )}

                                            </strong>

                                            <div class="fs-8 text-muted mb-1">

                                                Relation:

                                                <strong class="text-gray-700">

                                                    ${escapeHTML(
                                                        sibling.relation ||
                                                        '-'
                                                    )}

                                                </strong>

                                            </div>

                                            <div class="fs-8 text-muted">

                                                Occupation:

                                                <strong class="text-gray-700">

                                                    ${escapeHTML(
                                                        sibling.occupation ||
                                                        '-'
                                                    )}

                                                </strong>

                                            </div>

                                        </div>

                                    </div>
                                `;

                            }
                        ).join('')
                    }

                </div>`;

        }


        /* ================================================================
           CONTACT INFORMATION
        ================================================================= */

        function renderContactInformation(staff) {

            renderEmergencyContacts(
                normalizeArray(
                    staff.emergency_contacts
                )
            );


            renderLocation(staff);

            renderSocialMedia(
                staff.social_media
            );

        }


        /* ================================================================
           EMERGENCY CONTACTS
        ================================================================= */

        function renderEmergencyContacts(contacts) {

            const container = document.getElementById('viewStaffEmergencyContacts');

            if (!container) {
                return;
            }

            if (!contacts.length) {
                container.innerHTML =
                    emptyStateHTML(
                        'mdi-phone-alert-outline',
                        'No emergency contacts',
                        'Emergency contact information is unavailable.'
                    );

                return;

            }

            container.innerHTML =
                contacts.map(
                    (contact, index) => {

                        const mobile = valueOrNull(contact.mobile);

                        return `
                            <div class="staff-contact-line">
                                <div class="staff-contact-icon">
                                    <i class="mdi mdi-account-outline"></i>
                                </div>
                                <div class="min-w-0 flex-grow-1">
                                    <span>
                                        ${escapeHTML(contact.relation || `Contact ${index + 1}`)}
                                    </span>
                                    <strong>
                                        ${escapeHTML( contact.name || '-')}
                                    </strong>
                                    ${
                                        mobile
                                            ? `
                                                <a href="tel:${escapeAttribute(mobile)}"
                                                    class="fs-8 text-primary text-decoration-none">
                                                    <i class="mdi mdi-phone-outline me-1"></i>
                                                    ${escapeHTML(mobile)}
                                                </a>
                                            `
                                            : ''
                                    }
                                </div>
                            </div>
                        `;
                    }
                ).join('');
        }


        /* ================================================================
           LOCATION
        ================================================================= */

        function renderLocation(staff) {

            const wrapper =  document.getElementById('viewStaffLocationAction');

            const link = document.getElementById('viewStaffLocationLink');

            if (!wrapper || !link) {
                return;
            }

            const latitude = valueOrNull(staff.location_data?.latitude);
            const longitude = valueOrNull( staff.location_data?.longitude );
            const location_link = valueOrNull( staff.location_data?.location_url );

            if (latitude && longitude) {
                link.href = `https://www.google.com/maps?q=${encodeURIComponent(latitude)},${encodeURIComponent(longitude)}`;
                wrapper.classList.remove('d-none');
            } else if(location_link){
                link.href = location_link;
                wrapper.classList.remove('d-none');
            } else {
                wrapper.classList.add('d-none');
                link.href = '#';
            }

        }


        /* ================================================================
           SOCIAL MEDIA
        ================================================================= */

        function renderSocialMedia(socialMedia) {

            const container =
                document.getElementById(
                    'viewStaffSocialMediaContainer'
                );


            if (!container) {
                return;
            }


            let profiles = [];


            if (Array.isArray(socialMedia)) {

                profiles =
                    socialMedia;

            } else if (
                socialMedia &&
                typeof socialMedia === 'object'
            ) {

                profiles =
                    Object.entries(
                        socialMedia
                    ).map(
                        ([platform, url]) => ({
                            platform,
                            url
                        })
                    );

            }


            profiles =
                profiles.filter(profile => {

                    return valueOrNull(
                        profile.url ||
                        profile.link ||
                        profile.value
                    );

                });


            if (!profiles.length) {

                container.innerHTML =
                    emptyStateHTML(
                        'mdi-share-variant-outline',
                        'No social profiles',
                        'No social media profiles have been added.'
                    );

                return;

            }


            container.innerHTML =
                `<div class="d-flex flex-wrap gap-3">

                    ${
                        profiles.map(profile => {

                            const platform =
                                profile.platform ||
                                profile.name ||
                                'Social Profile';


                            const url =
                                profile.url ||
                                profile.link ||
                                profile.value;


                            return `
                                <a
                                    href="${escapeAttribute(url)}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    class="btn btn-sm btn-light-primary"
                                >

                                    <i class="mdi mdi-open-in-new me-1"></i>

                                    ${escapeHTML(platform)}

                                </a>
                            `;

                        }).join('')
                    }

                </div>`;

        }


        /* ================================================================
           EMPLOYMENT
        ================================================================= */

        function renderEmploymentInformation(staff) {

            setTextById(
                'employmentCompanyType',
                getCompanyType(
                    staff.company_type
                )
            );


            /*
             * Salary values
             */

            setTextById(
                'viewStaffBasicSalary',
                formatCurrency(
                    staff.basic_salary
                )
            );


            setTextById(
                'viewStaffPerDaySalary',
                formatCurrency(
                    staff.per_day_salary
                )
            );


            setTextById(
                'viewStaffPerHourCost',
                formatCurrency(
                    staff.per_hour_cost
                )
            );


            /*
             * Employment skills
             */

            renderTagCollection(
                'viewStaffEmploymentSkills',
                staff.skills,
                'No skill tags available'
            );

        }


        /* ================================================================
           WORK EXPERIENCE
        ================================================================= */

        function renderWorkExperience(staff) {

            const works =
                normalizeArray(
                    staff.work_details
                );


            const container =
                document.getElementById(
                    'viewStaffWorkTimeline'
                );


            setTextById(
                'experienceTypeBadge',
                getExperienceType(
                    staff.exp_type
                )
            );


            let totalExperience =
                staff.total_experience;


            if (
                valueOrNull(totalExperience)
            ) {

                totalExperience =
                    `${totalExperience} ${
                        Number(totalExperience) === 1
                            ? 'Year'
                            : 'Years'
                    }`;

            } else {

                totalExperience = '-';

            }


            setTextById(
                'experienceTotalYears',
                totalExperience
            );


            if (!container) {
                return;
            }


            /*
             * Fresher
             */

            if (
                Number(staff.exp_type) === 1
            ) {

                container.innerHTML =
                    emptyStateHTML(
                        'mdi-account-school-outline',
                        'Fresher',
                        'This employee is registered as a fresher.'
                    );

                return;

            }


            if (!works.length) {

                container.innerHTML =
                    emptyStateHTML(
                        'mdi-briefcase-clock-outline',
                        'No work experience',
                        'Previous employment information is unavailable.'
                    );

                return;

            }


            container.innerHTML =
                works.map(
                    (work, index) => {

                        const experience =
                            valueOrNull(
                                work.year_of_experience
                            )
                                ? `${work.year_of_experience} Years`
                                : '-';


                        return `
                            <div class="staff-timeline-item">

                                <span class="staff-timeline-dot"></span>

                                <div class="staff-timeline-card">

                                    <div
                                        class="
                                            d-flex
                                            flex-column
                                            flex-md-row
                                            justify-content-between
                                            gap-3
                                            mb-3
                                        "
                                    >

                                        <div>

                                            <h6 class="fw-bold text-gray-900 mb-1">

                                                ${
                                                    escapeHTML(
                                                        work.position ||
                                                        'Position Not Available'
                                                    )
                                                }

                                            </h6>

                                            <div class="text-primary fw-semibold fs-7">

                                                <i class="mdi mdi-domain me-1"></i>

                                                ${
                                                    escapeHTML(
                                                        work.company_name ||
                                                        '-'
                                                    )
                                                }

                                            </div>

                                        </div>


                                        <div class="text-md-end">

                                            <span class="badge badge-light-primary">

                                                ${escapeHTML(experience)}

                                            </span>

                                        </div>

                                    </div>


                                    <div class="row g-3">

                                        <div class="col-md-6 col-lg-3">

                                            <span class="staff-info-label">
                                                Start Date
                                            </span>

                                            <div class="staff-info-value">

                                                ${
                                                    escapeHTML(
                                                        formatDateCommon(work.start_date)
                                                    )
                                                }

                                            </div>

                                        </div>


                                        <div class="col-md-6 col-lg-3">

                                            <span class="staff-info-label">
                                                End Date
                                            </span>

                                            <div class="staff-info-value">

                                                ${
                                                    escapeHTML(
                                                        formatDateCommon(work.end_date)
                                                    )
                                                }

                                            </div>

                                        </div>


                                        <div class="col-md-6 col-lg-3">

                                            <span class="staff-info-label">
                                                Salary
                                            </span>

                                            <div class="staff-info-value text-success">

                                                ${
                                                    escapeHTML(
                                                        formatCurrency(
                                                            work.salary
                                                        )
                                                    )
                                                }

                                            </div>

                                        </div>


                                        <div class="col-md-6 col-lg-3">

                                            <span class="staff-info-label">
                                                Experience
                                            </span>

                                            <div class="staff-info-value">

                                                ${escapeHTML(experience)}

                                            </div>

                                        </div>

                                    </div>


                                    ${
                                        valueOrNull(
                                            work.exit_reason
                                        )
                                            ? `
                                                <div class="mt-3 pt-3 border-top">

                                                    <span class="staff-info-label">

                                                        Exit Reason

                                                    </span>

                                                    <p class="mb-0 mt-1 fs-7 text-gray-700">

                                                        ${
                                                            escapeHTML(
                                                                work.exit_reason
                                                            )
                                                        }

                                                    </p>

                                                </div>
                                            `
                                            : ''
                                    }

                                </div>

                            </div>
                        `;

                    }
                ).join('');

        }

        function renderCurrentWorkingExperience(staff) {

            const card = document.getElementById(
                'staffCurrentExperienceCard'
            );

            if (!card) {
                return;
            }

            const experience =
                staff?.current_work_experience || null;

            /*
            |--------------------------------------------------------------------------
            | NO CURRENT EXPERIENCE DATA
            |--------------------------------------------------------------------------
            */

            if (
                !experience ||
                !valueOrNull(experience.joined_date)
            ) {

                card.classList.add('d-none');

                setTextById(
                    'staffCurrentExperienceCompany',
                    '-'
                );

                setTextById(
                    'staffCurrentExperienceRole',
                    '-'
                );

                setTextById(
                    'staffCurrentExperienceDepartment',
                    '-'
                );

                setTextById(
                    'staffCurrentExperienceDuration',
                    '-'
                );

                setTextById(
                    'staffCurrentExperiencePeriod',
                    '-'
                );

                return;
            }


            /*
            |--------------------------------------------------------------------------
            | SHOW CURRENT EXPERIENCE
            |--------------------------------------------------------------------------
            */

            card.classList.remove('d-none');


            /*
            |--------------------------------------------------------------------------
            | COMPANY / ENTITY
            |--------------------------------------------------------------------------
            */

            let companyDisplay =
                staff.company_name ||
                staff.entity_name ||
                '-';

            if (
                valueOrNull(staff.company_name) &&
                valueOrNull(staff.entity_name)
            ) {
                companyDisplay =
                    `${staff.company_name} / ${staff.entity_name}`;
            }

            setTextById(
                'staffCurrentExperienceCompany',
                companyDisplay
            );


            /*
            |--------------------------------------------------------------------------
            | CURRENT JOB ROLE
            |--------------------------------------------------------------------------
            */

            setTextById(
                'staffCurrentExperienceRole',
                staff.job_role_name || '-'
            );


            /*
            |--------------------------------------------------------------------------
            | DEPARTMENT / DIVISION
            |--------------------------------------------------------------------------
            */

            const departmentParts = [
                staff.department_name,
                staff.division_name
            ]
            .filter(
                item => valueOrNull(item)
            );

            setTextById(
                'staffCurrentExperienceDepartment',
                departmentParts.length
                    ? departmentParts.join(' • ')
                    : '-'
            );


            /*
            |--------------------------------------------------------------------------
            | CURRENT EXPERIENCE DURATION
            |--------------------------------------------------------------------------
            */

            setTextById(
                'staffCurrentExperienceDuration',
                experience.formatted || '-'
            );


            /*
            |--------------------------------------------------------------------------
            | JOINED DATE → PRESENT
            |--------------------------------------------------------------------------
            */

            const joinedDate =formatDateCommon(experience.joined_date);

            setTextById(
                'staffCurrentExperiencePeriod',
                joinedDate && joinedDate !== '-'
                    ? `${joinedDate} - Present`
                    : 'Present'
            );
        }


        /* ================================================================
           EDUCATION
        ================================================================= */

        function renderEducation(staff) {

            const qualifications =
                normalizeArray(
                    staff.qualification
                );


            const container =
                document.getElementById(
                    'viewStaffEducationTimeline'
                );


            if (container) {

                if (!qualifications.length) {

                    container.innerHTML =
                        emptyStateHTML(
                            'mdi-school-outline',
                            'No education information',
                            'Qualification information has not been added.'
                        );

                } else {

                    container.innerHTML =
                        qualifications.map(
                            qualification => {

                                const major =
                                    qualification.major_name ||
                                    qualification.major ||
                                    '-';


                                return `
                                    <div class="staff-timeline-item">

                                        <span class="staff-timeline-dot"></span>

                                        <div class="staff-timeline-card">

                                            <div
                                                class="
                                                    d-flex
                                                    flex-column
                                                    flex-md-row
                                                    justify-content-between
                                                    gap-3
                                                "
                                            >

                                                <div>

                                                    <h6 class="fw-bold text-gray-900 mb-1">

                                                        ${
                                                            escapeHTML(
                                                                qualification.qualification_name ||
                                                                '-'
                                                            )
                                                        }

                                                    </h6>

                                                    <div class="text-primary fs-7 fw-semibold">

                                                        ${
                                                            escapeHTML(
                                                                major
                                                            )
                                                        }

                                                    </div>

                                                </div>


                                                ${
                                                    valueOrNull(
                                                        qualification.year
                                                    )
                                                        ? `
                                                            <span class="badge badge-light-primary align-self-start">

                                                                ${
                                                                    escapeHTML(
                                                                        qualification.year
                                                                    )
                                                                }

                                                            </span>
                                                        `
                                                        : ''
                                                }

                                            </div>


                                            <div class="mt-3">

                                                <span class="staff-info-label">

                                                    University / Institution

                                                </span>

                                                <div class="staff-info-value">

                                                    ${
                                                        escapeHTML(
                                                            qualification.university_name ||
                                                            '-'
                                                        )
                                                    }

                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                `;

                            }
                        ).join('');

                }

            }


            /*
             * Course tags
             */

            renderTagCollection(
                'viewStaffCourseTags',
                staff.course_tags,
                'No completed course tags available'
            );

        }


        /* ================================================================
           LOGIN & CREDENTIAL ACCESS
        ================================================================= */

        function renderAccessInformation(staff) {

            const loginEnabled =
                isEnabled(
                    staff.login_access
                );


            const badge =
                document.getElementById(
                    'viewStaffLoginStatusBadge'
                );


            if (badge) {

                badge.className =
                    loginEnabled
                        ? 'badge bg-label-success'
                        : 'badge bg-label-danger';


                badge.textContent =
                    loginEnabled
                        ? 'Enabled'
                        : 'Disabled';

            }


            renderCredentials(
                normalizeArray(
                    staff.other_credential
                )
            );

        }


        /* ================================================================
           OTHER CREDENTIALS
        ================================================================= */

        function renderCredentials(credentials) {

            const container =
                document.getElementById(
                    'viewStaffCredentialsContainer'
                );


            if (!container) {
                return;
            }


            if (!credentials.length) {

                container.innerHTML =
                    emptyStateHTML(
                        'mdi-key-chain-variant',
                        'No additional credentials',
                        'No external platform credentials have been registered.'
                    );

                return;

            }


            container.innerHTML =
                credentials.map(
                    credential => {

                        const url =
                            valueOrNull(
                                credential.url_link
                            );


                        return `
                            <div
                                class="
                                    border
                                    rounded-3
                                    p-4
                                    mb-3
                                    bg-light
                                "
                            >

                                <div
                                    class="
                                        d-flex
                                        align-items-start
                                        justify-content-between
                                        gap-3
                                    "
                                >

                                    <div class="min-w-0">

                                        <div class="fw-bold text-gray-900 mb-2">

                                            ${
                                                escapeHTML(
                                                    credential.credential_name ||
                                                    'Credential'
                                                )
                                            }

                                        </div>


                                        <div class="fs-8 text-muted mb-1">

                                            Username

                                        </div>

                                        <div class="fw-semibold text-gray-700 text-break">

                                            ${
                                                escapeHTML(
                                                    credential.user_name ||
                                                    '-'
                                                )
                                            }

                                        </div>

                                    </div>


                                    ${
                                        url
                                            ? `
                                                <a
                                                    href="${escapeAttribute(url)}"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    class="btn btn-icon btn-sm btn-light-primary"
                                                    title="Open website"
                                                >

                                                    <i class="mdi mdi-open-in-new"></i>

                                                </a>
                                            `
                                            : ''
                                    }

                                </div>


                                ${
                                    valueOrNull(
                                        credential.description
                                    )
                                        ? `
                                            <div class="mt-3 pt-3 border-top">

                                                <span class="fs-8 text-muted">

                                                    Description

                                                </span>

                                                <p class="fs-7 text-gray-700 mb-0 mt-1">

                                                    ${
                                                        escapeHTML(
                                                            credential.description
                                                        )
                                                    }

                                                </p>

                                            </div>
                                        `
                                        : ''
                                }

                            </div>
                        `;

                    }
                ).join('');

        }


        /* ================================================================
           DOCUMENTS
        ================================================================= */

        function renderDocuments(staff) {

            const documents =
                normalizeArray(
                    staff.documents
                );


            const container =
                document.getElementById(
                    'viewStaffDocumentsContainer'
                );


            if (!container) {
                return;
            }


            if (!documents.length) {

                container.innerHTML =
                    `<div class="col-12">

                        ${
                            emptyStateHTML(
                                'mdi-file-document-outline',
                                'No documents available',
                                'No employee documents have been uploaded.'
                            )
                        }

                    </div>`;

                return;

            }


            let documentHTML = '';


            documents.forEach(
                document => {

                    const files =
                        normalizeArray(
                            document.files
                        );


                    if (!files.length) {

                        documentHTML += `
                            <div class="col-md-6 col-xl-4">
                                <div class="staff-document-card">
                                    <div class="staff-document-icon">
                                        <i class="mdi mdi-file-document-outline"></i>
                                    </div>
                                    <div class="min-w-0 flex-grow-1">
                                        <div class="fw-bold fs-7 text-gray-800">
                                            ${
                                                escapeHTML(
                                                    document.document_name ||
                                                    'Document'
                                                )
                                            }

                                        </div>

                                        <span class="fs-8 text-muted">

                                            No file attached

                                        </span>

                                    </div>

                                </div>

                            </div>
                        `;

                        return;

                    }


                    files.forEach(
                        file => {

                            const icon =
                                getDocumentIcon(
                                    file.type,
                                    file.extension
                                );


                            documentHTML += `
                                <div class="col-md-6 col-xl-4">

                                    <div class="staff-document-card">

                                        <div class="staff-document-icon">

                                            <i class="mdi ${icon}"></i>

                                        </div>


                                        <div class="min-w-0 flex-grow-1">

                                            <div
                                                class="
                                                    fw-bold
                                                    fs-7
                                                    text-gray-800
                                                    text-truncate
                                                    max-w-150px
                                                "
                                                title="${
                                                    escapeAttribute(
                                                        document.document_name ||
                                                        'Document'
                                                    )
                                                }"
                                            >

                                                ${
                                                    escapeHTML(
                                                        document.document_name ||
                                                        'Document'
                                                    )
                                                }

                                            </div>

                                            <div
                                                class="
                                                    fs-8
                                                    text-muted
                                                    text-truncate
                                                    max-w-150px
                                                "
                                                title="${
                                                    escapeAttribute(
                                                        file.name ||
                                                        ''
                                                    )
                                                }"
                                            >

                                                ${
                                                    escapeHTML(
                                                        file.name ||
                                                        'Attachment'
                                                    )
                                                }

                                            </div>

                                        </div>


                                        <div class="dropdown">

                                            <button
                                                type="button"
                                                class="btn btn-icon btn-sm btn-light"
                                                data-bs-toggle="dropdown"
                                            >

                                                <i class="mdi mdi-dots-vertical"></i>

                                            </button>


                                            <ul class="dropdown-menu dropdown-menu-end">

                                                <li>

                                                    <a
                                                        class="dropdown-item"
                                                        href="${
                                                            escapeAttribute(
                                                                file.url
                                                            )
                                                        }"
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                    >

                                                        <i class="mdi mdi-eye-outline me-2"></i>

                                                        View

                                                    </a>

                                                </li>


                                                <li>

                                                    <a
                                                        class="dropdown-item"
                                                        href="${
                                                            escapeAttribute(
                                                                file.url
                                                            )
                                                        }"
                                                        download
                                                    >

                                                        <i class="mdi mdi-download-outline me-2"></i>

                                                        Download

                                                    </a>

                                                </li>

                                            </ul>

                                        </div>

                                    </div>

                                </div>
                            `;

                        }
                    );

                }
            );


            container.innerHTML =
                documentHTML;

        }


        /* ================================================================
           DOCUMENT CHECKLIST
        ================================================================= */

        function renderDocumentChecklist(staff) {

            const checklist =
                normalizeArray(
                    staff.document_checkList
                );


            const container =
                document.getElementById(
                    'viewStaffChecklistContainer'
                );


            const summary =
                staff.checklist_summary ||
                {};


            let total =
                Number(
                    summary.total
                );


            let completed =
                Number(
                    summary.completed
                );


            if (
                !Number.isFinite(total)
            ) {

                total =
                    checklist.length;

            }


            if (
                !Number.isFinite(completed)
            ) {

                completed =
                    checklist.filter(
                        item =>
                            Number(
                                item.is_checked
                            ) === 1
                    ).length;

            }


            let percentage =
                total > 0
                    ? Math.round(
                        (
                            completed /
                            total
                        ) * 100
                    )
                    : 0;


            if (
                Number.isFinite(
                    Number(
                        summary.percentage
                    )
                )
            ) {

                percentage =
                    Number(
                        summary.percentage
                    );

            }


            setTextById(
                'viewStaffChecklistProgressText',
                `${completed} / ${total} Completed`
            );


            const progressBar =
                document.getElementById(
                    'viewStaffChecklistProgressBar'
                );


            if (progressBar) {

                progressBar.style.width =
                    `${percentage}%`;


                progressBar.setAttribute(
                    'aria-valuenow',
                    percentage
                );

            }


            if (!container) {
                return;
            }


            if (!checklist.length) {

                container.innerHTML =
                    `<div class="col-12">

                        ${
                            emptyStateHTML(
                                'mdi-clipboard-check-outline',
                                'No checklist available',
                                'No HR document checklist items are configured.'
                            )
                        }

                    </div>`;

                return;

            }


            container.innerHTML =
                checklist.map(
                    item => {

                        const checked =
                            Number(
                                item.is_checked
                            ) === 1;


                        return `
                            <div class="col-md-6 col-xl-4">

                                <div
                                    class="
                                        d-flex
                                        align-items-center
                                        gap-3
                                        border
                                        rounded-3
                                        p-3
                                        h-100
                                        ${
                                            checked
                                                ? 'bg-light-success'
                                                : 'bg-light'
                                        }
                                    "
                                >

                                    <div
                                        class="
                                            staff-checklist-icon
                                            ${
                                                checked
                                                    ? 'text-success'
                                                    : 'text-muted'
                                            }
                                        "
                                    >

                                        <i
                                            class="
                                                mdi
                                                ${
                                                    checked
                                                        ? 'mdi-check-circle'
                                                        : 'mdi-checkbox-blank-circle-outline'
                                                }
                                                fs-3
                                            "
                                        ></i>

                                    </div>


                                    <div class="min-w-0">

                                        <div class="fw-semibold fs-7 text-gray-800">

                                            ${
                                                escapeHTML(
                                                    item.document_checklist ||
                                                    item.checklist_name ||
                                                    'Checklist Item'
                                                )
                                            }

                                        </div>

                                        <span
                                            class="
                                                fs-8
                                                ${
                                                    checked
                                                        ? 'text-success'
                                                        : 'text-muted'
                                                }
                                            "
                                        >

                                            ${
                                                checked
                                                    ? 'Completed'
                                                    : 'Pending'
                                            }

                                        </span>

                                    </div>

                                </div>

                            </div>
                        `;

                    }
                ).join('');

        }


        /* ================================================================
           SUMMARY COUNTERS
        ================================================================= */

        function renderSummaryCounts(staff) {

            const summary =
                staff.summary ||
                {};


            const workCount =
                summary.work_experience_count ??
                normalizeArray(
                    staff.work_details
                ).length;


            const educationCount =
                summary.education_count ??
                normalizeArray(
                    staff.qualification
                ).length;


            const documentCount =
                summary.document_file_count ??
                countDocumentFiles(
                    staff.documents
                );


            setTextById(
                'viewStaffWorkCount',
                workCount
            );


            setTextById(
                'viewStaffEducationCount',
                educationCount
            );


            setTextById(
                'viewStaffDocumentCount',
                documentCount
            );

        }


        /* ================================================================
           PROFILE COMPLETION
        ================================================================= */

        function renderProfileCompletion(staff) {

            let percentage =
                Number(
                    staff.completion_percentage
                );


            if (
                !Number.isFinite(percentage)
            ) {

                percentage = 0;

            }


            percentage =
                Math.max(
                    0,
                    Math.min(
                        100,
                        Math.round(
                            percentage
                        )
                    )
                );


            setTextById(
                'viewStaffCompletionPercentage',
                `${percentage}%`
            );


            const circle =
                document.getElementById(
                    'viewStaffCompletionCircle'
                );


            if (circle) {

                circle.style.setProperty(
                    '--progress',
                    percentage
                );

            }

        }


        /* ================================================================
           TAG COLLECTION
        ================================================================= */

        function renderTagCollection(
            containerId,
            values,
            emptyText
        ) {

            const container =
                document.getElementById(
                    containerId
                );


            if (!container) {
                return;
            }


            const items =
                normalizeArray(
                    values
                )
                    .map(item => {

                        if (
                            typeof item === 'object' &&
                            item !== null
                        ) {

                            return (
                                item.value ||
                                item.name ||
                                null
                            );

                        }

                        return item;

                    })
                    .filter(
                        item =>
                            valueOrNull(item)
                    );


            if (!items.length) {

                container.innerHTML =
                    `<span class="text-muted fs-7">

                        ${escapeHTML(emptyText)}

                    </span>`;

                return;

            }


            container.innerHTML =
                items.map(
                    item => {

                        return `
                            <span class="badge badge-light-primary px-3 py-2">

                                ${escapeHTML(item)}

                            </span>
                        `;

                    }
                ).join('');

        }


        /* ================================================================
           RESET STAFF VIEW
        ================================================================= */
        function resetCurrentWorkingExperience() {

            const card =
                document.getElementById(
                    'staffCurrentExperienceCard'
                );

            if (card) {
                card.classList.add('d-none');
            }

            setTextById(
                'staffCurrentExperienceCompany',
                '-'
            );

            setTextById(
                'staffCurrentExperienceRole',
                '-'
            );

            setTextById(
                'staffCurrentExperienceDepartment',
                '-'
            );

            setTextById(
                'staffCurrentExperienceDuration',
                '-'
            );

            setTextById(
                'staffCurrentExperiencePeriod',
                '-'
            );
        }
        function resetStaffView() {

            /*
             * Hide error.
             */
            resetCurrentWorkingExperience();
            const errorState =
                document.getElementById(
                    'staffViewErrorState'
                );


            if (errorState) {

                errorState.classList.add(
                    'd-none'
                );

            }


            /*
             * Reset generic fields.
             */

            document
                .querySelectorAll(
                    '#kt_modal_view_staff [data-staff-field]'
                )
                .forEach(element => {

                    element.textContent = '-';

                });


            /*
             * Hide actual header.
             */

            document
                .querySelectorAll(
                    '#kt_modal_view_staff .staff-view-data'
                )
                .forEach(element => {

                    element.classList.add(
                        'd-none'
                    );

                });


            /*
             * Show skeleton.
             */

            document
                .querySelectorAll(
                    '#kt_modal_view_staff .staff-skeleton-group'
                )
                .forEach(element => {

                    element.classList.remove(
                        'd-none'
                    );

                });


            /*
             * Reset image.
             */

            const image =
                document.getElementById(
                    'viewStaffProfileImage'
                );


            if (image) {

                image.src =
                    STAFF_DEFAULT_IMAGE;

            }


            /*
             * Reset dynamic containers.
             */

            const dynamicContainers = [

                'viewStaffSkillsContainer',

                'viewStaffLanguagesContainer',

                'viewStaffHobbiesContainer',

                'viewStaffChildrenContainer',

                'viewStaffSiblingsContainer',

                'viewStaffEmergencyContacts',

                'viewStaffSocialMediaContainer',

                'viewStaffEmploymentSkills',

                'viewStaffWorkTimeline',

                'viewStaffEducationTimeline',

                'viewStaffCourseTags',

                'viewStaffCredentialsContainer',

                'viewStaffDocumentsContainer',

                'viewStaffChecklistContainer'

            ];


            dynamicContainers.forEach(
                id => {

                    const element =
                        document.getElementById(
                            id
                        );


                    if (element) {

                        element.innerHTML = '';

                    }

                }
            );


            /*
             * Reset counts.
             */

            setTextById(
                'viewStaffWorkCount',
                '0'
            );

            setTextById(
                'viewStaffEducationCount',
                '0'
            );

            setTextById(
                'viewStaffDocumentCount',
                '0'
            );

            setTextById(
                'viewStaffChildrenCount',
                '0'
            );

            setTextById(
                'viewStaffSiblingsCount',
                '0'
            );


            /*
             * Reset completion.
             */

            setTextById(
                'viewStaffCompletionPercentage',
                '0%'
            );


            const completionCircle =
                document.getElementById(
                    'viewStaffCompletionCircle'
                );


            if (completionCircle) {

                completionCircle.style.setProperty(
                    '--progress',
                    0
                );

            }


            /*
             * Reset checklist.
             */

            setTextById(
                'viewStaffChecklistProgressText',
                '0 / 0 Completed'
            );


            const progress =
                document.getElementById(
                    'viewStaffChecklistProgressBar'
                );


            if (progress) {

                progress.style.width =
                    '0%';

            }


            /*
             * Reset location.
             */

            const location =
                document.getElementById(
                    'viewStaffLocationAction'
                );


            if (location) {

                location.classList.add(
                    'd-none'
                );

            }


            /*
             * Reset active tab to Overview.
             */

            const overviewTab =
                document.querySelector(
                    '#staffProfileTabs button[data-bs-target="#staffOverviewTab"]'
                );


            if (
                overviewTab &&
                typeof bootstrap !== 'undefined'
            ) {

                try {

                    bootstrap
                        .Tab
                        .getOrCreateInstance(
                            overviewTab
                        )
                        .show();

                } catch (error) {

                    console.warn(
                        'Unable to reset staff tab:',
                        error
                    );

                }

            }

        }


        /* ================================================================
           LOADING
        ================================================================= */

        function showStaffViewLoading() {

            const loading =
                document.getElementById(
                    'staffViewLoadingOverlay'
                );


            const error =
                document.getElementById(
                    'staffViewErrorState'
                );


            if (loading) {

                loading.classList.remove(
                    'd-none'
                );

                loading.style.display =
                    'flex';

            }


            if (error) {

                error.classList.add(
                    'd-none'
                );

            }

        }


        function hideStaffViewLoading() {

            const loading =
                document.getElementById(
                    'staffViewLoadingOverlay'
                );


            if (loading) {

                loading.classList.add(
                    'd-none'
                );

                loading.style.display =
                    'none';

            }

        }


        /* ================================================================
           ERROR
        ================================================================= */

        function showStaffViewError(message) {

            const error =
                document.getElementById(
                    'staffViewErrorState'
                );


            const messageElement =
                document.getElementById(
                    'staffViewErrorMessage'
                );


            if (messageElement) {

                messageElement.textContent =
                    message;

            }


            if (error) {

                error.classList.remove(
                    'd-none'
                );

                error.style.display =
                    'flex';

            }

        }


        /* ================================================================
           RETRY / REFRESH
        ================================================================= */

        document.addEventListener(
            'DOMContentLoaded',
            function() {

                const retryButton =
                    document.getElementById(
                        'staffViewRetryBtn'
                    );


                const refreshButton =
                    document.getElementById(
                        'staffViewRefreshBtn'
                    );


                if (retryButton) {

                    retryButton.addEventListener(
                        'click',
                        function() {

                            if (
                                currentStaffViewId
                            ) {

                                window.viewStaff(
                                    currentStaffViewId
                                );

                            }

                        }
                    );

                }


                if (refreshButton) {

                    refreshButton.addEventListener(
                        'click',
                        function() {

                            if (
                                currentStaffViewId
                            ) {

                                window.viewStaff(
                                    currentStaffViewId
                                );

                            }

                        }
                    );

                }


                /*
                 * Abort request when modal closes.
                 */

                const modal =
                    document.getElementById(
                        'kt_modal_view_staff'
                    );


                if (modal) {

                    modal.addEventListener(
                        'hidden.bs.modal',
                        function() {

                            if (
                                staffViewAbortController
                            ) {

                                staffViewAbortController.abort();

                            }

                        }
                    );

                }

            }
        );


        /* ================================================================
           HELPER: SET TEXT
        ================================================================= */

        function setTextById(
            id,
            value
        ) {

            const element =
                document.getElementById(
                    id
                );


            if (!element) {
                return;
            }


            setText(
                element,
                value
            );

        }


        function setText(
            element,
            value
        ) {

            if (!element) {
                return;
            }


            element.textContent =
                valueOrNull(value)
                    ? String(value)
                    : '-';

        }


        /* ================================================================
           HELPER: VALUE
        ================================================================= */

        function valueOrNull(value) {

            if (
                value === null ||
                value === undefined ||
                value === ''
            ) {

                return null;

            }


            return value;

        }


        /* ================================================================
           HELPER: NESTED VALUE
        ================================================================= */

        function getNestedValue(
            object,
            path
        ) {

            if (
                !object ||
                !path
            ) {

                return null;

            }


            return path
                .split('.')
                .reduce(
                    (
                        current,
                        key
                    ) => {

                        if (
                            current === null ||
                            current === undefined
                        ) {

                            return null;

                        }


                        return current[key];

                    },
                    object
                );

        }


        /* ================================================================
           HELPER: NORMALIZE ARRAY
        ================================================================= */

        function normalizeArray(value) {

            if (
                Array.isArray(value)
            ) {

                return value;

            }


            if (
                value === null ||
                value === undefined ||
                value === ''
            ) {

                return [];

            }


            if (
                typeof value === 'string'
            ) {

                try {

                    let parsed =
                        JSON.parse(
                            value
                        );


                    /*
                     * Handle double encoded JSON.
                     */

                    if (
                        typeof parsed === 'string'
                    ) {

                        parsed =
                            JSON.parse(
                                parsed
                            );

                    }


                    return Array.isArray(parsed)
                        ? parsed
                        : [];

                } catch (error) {

                    return [];

                }

            }


            return [];

        }


        /* ================================================================
           HELPER: DATE FORMAT
        ================================================================= */

        function formatStaffDate(value) {

            if (!valueOrNull(value)) {
                return '-';
            }


            /*
             * Avoid timezone shift for YYYY-MM-DD.
             */

            const dateOnlyMatch =
                String(value).match(
                    /^(\d{4})-(\d{2})-(\d{2})/
                );


            if (dateOnlyMatch) {

                const year =
                    dateOnlyMatch[1];

                const month =
                    dateOnlyMatch[2];

                const day =
                    dateOnlyMatch[3];


                return `${day}-${month}-${year}`;

            }


            const date =
                new Date(
                    value
                );


            if (
                Number.isNaN(
                    date.getTime()
                )
            ) {

                return String(value);

            }


            return new Intl.DateTimeFormat(
                'en-GB',
                {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                }
            ).format(date);

        }


        /* ================================================================
           HELPER: CURRENCY
        ================================================================= */

        function formatCurrency(value) {

            if (
                value === null ||
                value === undefined ||
                value === ''
            ) {

                return '-';

            }


            const amount =
                Number(value);


            if (
                Number.isNaN(amount)
            ) {

                return String(value);

            }


            return new Intl.NumberFormat(
                'en-IN',
                {
                    style: 'currency',
                    currency: 'INR',
                    maximumFractionDigits: 2
                }
            ).format(amount);

        }


        /* ================================================================
           HELPER: GENDER
        ================================================================= */

        function getGender(value) {

            switch (
                Number(value)
            ) {

                case 1:
                    return 'Male';

                case 2:
                    return 'Female';

                case 3:
                    return 'Other';

                default:
                    return valueOrNull(value)
                        ? String(value)
                        : '-';

            }

        }


        /* ================================================================
           HELPER: MARITAL STATUS
        ================================================================= */

        function getMaritalStatus(value) {

            switch (
                Number(value)
            ) {

                case 1:
                    return 'Married';

                case 2:
                    return 'Unmarried';

                default:
                    return valueOrNull(value)
                        ? String(value)
                        : '-';

            }

        }


        /* ================================================================
           HELPER: EXPERIENCE TYPE
        ================================================================= */

        function getExperienceType(value) {

            switch (
                Number(value)
            ) {

                case 1:
                    return 'Fresher';

                case 2:
                    return 'Experienced';

                default:
                    return '-';

            }

        }


        /* ================================================================
           HELPER: COMPANY TYPE
        ================================================================= */

        function getCompanyType(value) {

            switch (
                Number(value)
            ) {

                case 1:
                    return 'Management';

                case 2:
                    return 'Business';

                default:
                    return valueOrNull(value)
                        ? String(value)
                        : '-';

            }

        }


        /* ================================================================
           HELPER: ENABLED STATUS
        ================================================================= */

        function isEnabled(value) {

            return (
                value === true ||
                value === 1 ||
                value === '1' ||
                value === 'true'
            );

        }


        /* ================================================================
           HELPER: DOCUMENT COUNT
        ================================================================= */

        function countDocumentFiles(
            documents
        ) {

            return normalizeArray(
                documents
            ).reduce(
                (
                    total,
                    document
                ) => {

                    return (
                        total +
                        normalizeArray(
                            document.files
                        ).length
                    );

                },
                0
            );

        }


        /* ================================================================
           HELPER: DOCUMENT ICON
        ================================================================= */

        function getDocumentIcon(
            type,
            extension
        ) {

            if (
                type === 'pdf' ||
                extension === 'pdf'
            ) {

                return 'mdi-file-pdf-box';

            }


            if (
                type === 'image'
            ) {

                return 'mdi-file-image-outline';

            }


            if (
                type === 'word'
            ) {

                return 'mdi-file-word-outline';

            }


            if (
                type === 'excel'
            ) {

                return 'mdi-file-excel-outline';

            }


            return 'mdi-file-document-outline';

        }


        /* ================================================================
           HELPER: EMPTY STATE
        ================================================================= */

        function emptyStateHTML(
            icon,
            title,
            description
        ) {

            return `
                <div class="staff-empty-state">

                    <i class="mdi ${escapeAttribute(icon)}"></i>

                    <h6>

                        ${escapeHTML(title)}

                    </h6>

                    <p>

                        ${escapeHTML(description)}

                    </p>

                </div>
            `;

        }


        /* ================================================================
           SECURITY: ESCAPE HTML
        ================================================================= */

        function escapeHTML(value) {

            if (
                value === null ||
                value === undefined
            ) {

                return '';

            }


            return String(value)
                .replace(
                    /&/g,
                    '&amp;'
                )
                .replace(
                    /</g,
                    '&lt;'
                )
                .replace(
                    />/g,
                    '&gt;'
                )
                .replace(
                    /"/g,
                    '&quot;'
                )
                .replace(
                    /'/g,
                    '&#039;'
                );

        }


        /* ================================================================
           SECURITY: ESCAPE ATTRIBUTE
        ================================================================= */

        function escapeAttribute(value) {

            return escapeHTML(
                value
            );

        }

    })();
</script>

<script>
    /* ================================================================
        STAFF SALARY & PAYROLL — ADVANCED LAZY LOAD
    ================================================================ */
    (() => {
        'use strict';
       
        let salaryPayrollEmployeeId = null;
        let salaryPayrollLoadedEmployeeId = null;
        let salaryPayrollLoading = false;
        let salaryPayrollAbortController = null;
        let salaryPayrollData = null;
        let selectedSalaryAccountId = null;
        let payrollSelectedYear = '';
        /*
        |--------------------------------------------------------------------------
        | PUBLIC INITIALIZER
        |--------------------------------------------------------------------------
        |
        | Call this from your existing viewStaff(id).
        |
        */
        window.prepareStaffSalaryPayroll = function(employeeId) {

            if (salaryPayrollAbortController) {
                salaryPayrollAbortController.abort();
                salaryPayrollAbortController = null;
            }

            salaryPayrollLoading = false;
            salaryPayrollEmployeeId = employeeId;

            /*
            * If another employee is opened,
            * invalidate previous cached data.
            */

            if (String(salaryPayrollLoadedEmployeeId) !== String(employeeId)) {
                salaryPayrollLoadedEmployeeId = null;
                salaryPayrollData = null;
                selectedSalaryAccountId = null;
                payrollSelectedYear = '';
            }
            resetStaffSalaryPayrollUI();
        };

        /*
        |--------------------------------------------------------------------------
        | LAZY LOAD
        |--------------------------------------------------------------------------
        */
        window.loadStaffSalaryPayroll = async function(forceRefresh = false) {
            if (!salaryPayrollEmployeeId) {
                showSalaryPayrollError('Employee information is unavailable.');
                return;
            }
            /*
            * Already loaded.
            */
            if (!forceRefresh && salaryPayrollData && String(salaryPayrollLoadedEmployeeId) === String(salaryPayrollEmployeeId)) {
                renderSalaryPayroll(salaryPayrollData);
                return;
            }
            /*
            * Prevent duplicate requests.
            */
            if (salaryPayrollLoading) {
                return;
            }
            /*
            * Cancel old request.
            */
            if (salaryPayrollAbortController) {
                salaryPayrollAbortController.abort();
            }


            salaryPayrollAbortController = new AbortController();
            salaryPayrollLoading = true;
            showSalaryPayrollSkeleton();
            try {
                const employeeId = salaryPayrollEmployeeId;
                const response = await fetch(
                                    `/staff/${encodeURIComponent(employeeId)}/salary-payroll`,{
                                        method: 'GET',
                                        headers: {
                                            'Accept': 'application/json',
                                            'X-Requested-With': 'XMLHttpRequest'
                                        },
                                        signal: salaryPayrollAbortController.signal
                                    }
                                );

                let result;
                try {
                    result = await response.json();
                } catch (error) {
                    throw new Error('The server returned an invalid response.');
                }
                if ( !response.ok || !result.status || !result.data ) {
                    throw new Error( result.error_msg || result.message || 'Unable to load salary and payroll information.');
                }
                /*
                * Ignore stale response if HR opened
                * another employee during request.
                */

                if ( String(employeeId) !== String(salaryPayrollEmployeeId) ) {
                    return;
                }


                salaryPayrollData = result.data;
                salaryPayrollLoadedEmployeeId = employeeId;

                /*
                * Select primary account initially.
                */
                selectedSalaryAccountId = getInitialSalaryAccountId( salaryPayrollData);
                renderSalaryPayroll(salaryPayrollData );
            } catch (error) {
                if (error.name === 'AbortError') {
                    return;
                }
                console.error('Salary Payroll View Error:', error );
                showSalaryPayrollError( error.message || 'Something went wrong while loading salary information.');
            } finally {
                salaryPayrollLoading = false;
            }
        };

        /*
        |--------------------------------------------------------------------------
        | MASTER RENDER
        |--------------------------------------------------------------------------
        */
        function renderSalaryPayroll(data) {
            if (!data) {
                showSalaryPayrollError( 'Salary information is unavailable.' );
                return;
            }
            hideSalaryPayrollSkeleton();
            renderSalarySummary( data );
            renderSalaryAccountSelector(data );
            renderSelectedSalaryStructure(data );
            renderSalaryHistory( data.salary_history || [] );
            renderPayrollYearFilter(data.payroll_history || []);
            renderPayrollHistory( data.payroll_history || []);
            showSalaryPayrollContent();
        }
        /*
        |--------------------------------------------------------------------------
        | SUMMARY
        |--------------------------------------------------------------------------
        */
        function renderSalarySummary(data) {
            const summary = data.summary || {};
            setSalaryText('staffPayrollCurrentSalary', salaryCurrency(summary.current_salary ));

            setSalaryText('staffPayrollAccountCount', summary.salary_account_count ?? 0);

            setSalaryText('staffPayrollRevisionCount', summary.salary_revision_count ?? 0);

            setSalaryText('staffPayrollProcessedCount', summary.processed_payroll_count ?? 0);

            /*
            * Pending appraisals.
            */
            const pending = Number( summary.pending_appraisal_count || 0);
            const pendingCaption =document.getElementById('staffPayrollPendingCaption');

            if (pendingCaption) {
                pendingCaption.textContent = pending > 0 ? `${pending} pending ${ pending === 1 ? 'revision' : 'revisions'}` : 'No pending revisions';
            }
            /*
            * Main tab pending badge.
            */
            const pendingBadge =document.getElementById('staffSalaryPendingBadge' );
            if (pendingBadge) {
                pendingBadge.textContent = pending;
                pendingBadge.classList.toggle('d-none', pending <= 0);
            }
            /*
            * Salary history pending badge.
            */
            setSalaryText('staffSalaryHistoryPendingBadge', `${pending} Pending`);
            /*
            * Current salary caption.
            */
            const accounts =normalizeSalaryArray(data.salary_accounts);
            const primary =accounts.find(account => Number( account.is_primary) === 1) || accounts[0];

            setSalaryText('staffPayrollCurrentSalaryCaption', primary?.account_name ? primary.account_name : 'Primary salary account');

        }
        /*
        |--------------------------------------------------------------------------
        | INITIAL ACCOUNT
        |--------------------------------------------------------------------------
        */
        function getInitialSalaryAccountId(data) {

            const accounts = normalizeSalaryArray( data.salary_accounts );
            if (!accounts.length) {
                return null;
            }
            const primary =accounts.find( account => Number(account.is_primary ) === 1 );
            return String( primary?.sno ?? accounts[0].sno );
        }

        /*
        |--------------------------------------------------------------------------
        | SALARY ACCOUNT SELECTOR
        |--------------------------------------------------------------------------
        */
        function renderSalaryAccountSelector(data) {
            const selector = document.getElementById('staffSalaryAccountSelector');
            const wrapper =document.getElementById('staffSalaryAccountSelectorWrapper');
            if (!selector) {
                return;
            }
            const accounts = normalizeSalaryArray( data.salary_accounts);
            selector.innerHTML = '';
            if (!accounts.length) {
                selector.innerHTML ='<option value="">No Salary Account</option>';
                selector.disabled = true;
                if (wrapper) {
                    wrapper.classList.add('opacity-50');
                }
                return;
            }
            selector.disabled =false;
            if (wrapper) {
                wrapper.classList.remove('opacity-50');
            }
            accounts.forEach(
                account => {
                    const option = document.createElement('option');
                    option.value = account.sno;
                    option.textContent = `${account.account_name || 'Salary Account'}${ Number(account.is_primary) === 1 ? ' — Primary' : '' }`;
                    selector.appendChild( option);
                }

            );


            /*
            * Ensure selected account exists.
            */

            const accountExists = accounts.some(account => String(account.sno) === String(selectedSalaryAccountId));

            if (!accountExists) {
                selectedSalaryAccountId = getInitialSalaryAccountId( data);
            }

            selector.value = selectedSalaryAccountId || '';
        }

        /*
        |--------------------------------------------------------------------------
        | CURRENT SALARY STRUCTURE
        |--------------------------------------------------------------------------
        */
        function renderSelectedSalaryStructure(data) {

            const structures = normalizeSalaryArray( data.current_structures );
            const selected = structures.find(item => String(item.salary_account_id) === String(selectedSalaryAccountId));
            const empty = document.getElementById('staffCurrentSalaryEmpty');

            if (!selected) {
                clearCurrentSalaryStructure();
                if (empty) {
                    empty.classList.remove('d-none');
                }
                return;
            }
            /*
            * Account exists but structure doesn't.
            */
            if (!selected.structure) {
                clearCurrentSalaryStructure();
                setSalaryText( 'staffCurrentSalaryAccountName',selected.account_name || 'Salary Account');
                setSalaryText('staffStructureGrossSalary', salaryCurrency( selected.account_gross_salary) );

                if (empty) {
                    empty.classList.remove('d-none');
                }
                updatePrimarySalaryBadge( selected.is_primary);
                return;
            }


            if (empty) {
                empty.classList.add('d-none' );
            }
            const structure = selected.structure;
            /*
            * Header.
            */
            setSalaryText('staffCurrentSalaryAccountName', selected.account_name ||'Salary Account');
            updatePrimarySalaryBadge(selected.is_primary );
            setSalaryText( 'staffCurrentSalaryTemplate',structure.template_name || '-' );
            setSalaryText('staffCurrentSalaryEffectiveFrom', formatSalaryDate(structure.effective_from));
            setSalaryText('staffCurrentSalaryEffectiveTo',structure.effective_to ? formatSalaryDate( structure.effective_to) : 'Present');
            /*
            * Component collections.
            */

            const earnings = normalizeSalaryArray( selected.earnings);
            const deductions =normalizeSalaryArray(selected.deductions);
            const employer =normalizeSalaryArray(selected.employer_contributions);
            /*
            * Calculate configured component totals.
            */
            const totalEarnings =calculateStructureComponentTotal(earnings);
            const totalDeductions =calculateStructureComponentTotal(deductions);
            const totalEmployer =calculateStructureComponentTotal(employer);
            /*
            * Metrics.
            */
            setSalaryText('staffStructureGrossSalary',salaryCurrency( structure.gross_salary ?? selected.account_gross_salary));

            setSalaryText('staffStructureTotalEarnings', salaryCurrency(totalEarnings));
            setSalaryText('staffStructureTotalDeductions', salaryCurrency(totalDeductions ));
            setSalaryText( 'staffStructureEmployerContribution',salaryCurrency(totalEmployer ));
            /*
            * Counts.
            */
            // setSalaryText( 'staffEarningsComponentCount', earnings.length );
            // setSalaryText('staffDeductionComponentCount', deductions.length );
            // setSalaryText('staffEmployerComponentCount',employer.length);
            /*
            * Component lists.
            */

            renderStructureComponentList('staffCurrentEarningsList', earnings,'No earning components configured.');
            renderStructureComponentList('staffCurrentDeductionsList',deductions,'No deduction components configured.' );
            renderStructureComponentList('staffCurrentEmployerList',employer,'No employer contributions configured.' );
        }
        /*
        |--------------------------------------------------------------------------
        | STRUCTURE COMPONENT TOTAL
        |--------------------------------------------------------------------------
        */

        function calculateStructureComponentTotal(components) {

            return normalizeSalaryArray(components).reduce((total, component) => {
                    const amount = Number( component.calculated_amount ?? component.fixed_amount ?? 0);
                    return total + (Number.isFinite(amount) ? amount : 0);
                }, 0
            );

        }

        /*
        |--------------------------------------------------------------------------
        | STRUCTURE COMPONENT LIST
        |--------------------------------------------------------------------------
        */
        function renderStructureComponentList(containerId,components, emptyMessage) {

            const container = document.getElementById( containerId);
            if (!container) {
                return;
            }
            components = normalizeSalaryArray(components);

            if (!components.length) {
                container.innerHTML = `
                    <div class=" py-5 text-center text-muted fs-8">
                        ${salaryEscapeHTML( emptyMessage)}
                    </div>
                `;
                return;
            }

            container.innerHTML =
                components.map(
                    component => {
                        const amount =component.calculated_amount ?? component.fixed_amount ?? 0;
                        const calculation =  getSalaryCalculationLabel( component );
                        return `
                            <div class="staff-component-row">
                                <div class="staff-component-name">
                                    <strong>
                                        ${salaryEscapeHTML( component.component_name || component.component || 'Component')}
                                    </strong>
                                    <span>
                                        ${salaryEscapeHTML(calculation )}
                                    </span>
                                </div>
                                <div class="staff-component-amount">
                                    ${salaryEscapeHTML(salaryCurrency(amount))}
                                </div>
                            </div>
                        `;
                    }
                ).join('');
        }
        /*
        |--------------------------------------------------------------------------
        | CALCULATION LABEL
        |--------------------------------------------------------------------------
        */

        function getSalaryCalculationLabel(component) {
            const type =component.calculation_type ?? component.master_calculation_type;
            const percentage =Number( component.percentage_value ?? component.percentage ?? 0);
            if (percentage > 0 ) {
                return `${percentage}%`;
            }
            if (type !== null && type !== undefined && type !== '' ) {
                return `Calculation Type: ${type}`;
            }
            return 'Fixed Amount';
        }

        /*
        |--------------------------------------------------------------------------
        | CLEAR CURRENT STRUCTURE
        |--------------------------------------------------------------------------
        */

        function clearCurrentSalaryStructure() {
            setSalaryText('staffCurrentSalaryAccountName', '-');
            setSalaryText('staffCurrentSalaryTemplate', '-');
            setSalaryText( 'staffCurrentSalaryEffectiveFrom', '-' );
            setSalaryText('staffCurrentSalaryEffectiveTo', '-');
            setSalaryText('staffStructureGrossSalary', salaryCurrency(0));
            setSalaryText('staffStructureTotalEarnings',salaryCurrency(0));
            setSalaryText('staffStructureTotalDeductions', salaryCurrency(0) );
            setSalaryText('staffStructureEmployerContribution', salaryCurrency(0));
            // setSalaryText('staffEarningsComponentCount', 0);
            // setSalaryText('staffDeductionComponentCount', 0);
            // setSalaryText('staffEmployerComponentCount', 0);

            const containers = [
                'staffCurrentEarningsList',
                'staffCurrentDeductionsList',
                'staffCurrentEmployerList'
            ];

            containers.forEach( id => {

                    const element = document.getElementById( id );

                    if (element) {
                        element.innerHTML = '';
                    }
                }
            );

            updatePrimarySalaryBadge(false);

        }

        /*
        |--------------------------------------------------------------------------
        | PRIMARY BADGE
        |--------------------------------------------------------------------------
        */

        function updatePrimarySalaryBadge(isPrimary) {

            const badge = document.getElementById('staffCurrentSalaryPrimaryBadge');

            if (!badge) {
                return;
            }

            badge.classList.toggle('d-none', !( isPrimary === true || Number(isPrimary) === 1));

        }

        /*
        |--------------------------------------------------------------------------
        | SALARY REVISION HISTORY
        |--------------------------------------------------------------------------
        */

        function renderSalaryHistory(history ) {
            const container = document.getElementById('staffSalaryHistoryTimeline');

            if (!container) {
                return;
            }

            history = normalizeSalaryArray( history);

            if (!history.length) {
                container.innerHTML =
                    salaryEmptyState(
                        'mdi-chart-timeline-variant-shimmer',
                        'No Salary Revision History',
                        'No salary appraisal or revision records were found.'
                    );
                return;
            }


            /*
            * Endpoint returns newest first.
            */
            container.innerHTML =
                history.map(
                    (row,index) => {
                        const processed = row.processed === true || Number( row.processed ) === 1;
                        const appraisalName = row.appraisal_type_name || 'Salary Revision';
                        const appraisalValue = formatAppraisalValue(row );
                        const variableAmount = Number( row.variable_amount || 0);
                        return `
                            <div class="staff-salary-history-item">
                                <span class="staff-salary-history-dot"></span>
                                <div class="staff-salary-history-card">
                                    <div
                                        class="d-flex flex-column flex-lg-row align-items-lg-start justify-content-between gap-3 mb-4">
                                        <div>
                                            <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                                                <h6 class=" fw-bold text-gray-900 mb-0" >
                                                    ${salaryEscapeHTML(appraisalName ) }
                                                </h6>
                                                <span class=" badge ${ processed ? 'bg-label-success' : 'bg-label-warning' } " >
                                                    ${ processed ? 'Processed' : 'Pending'}
                                                </span>
                                            </div>
                                            <div class="fs-8 text-muted ">
                                                Effective
                                                <strong class=" text-gray-700">
                                                    ${salaryEscapeHTML(formatSalaryMonth(row.effective_from)) }
                                                </strong>
                                            </div>
                                        </div>
                                        <div class="text-lg-end">
                                            <span class="d-block fs-8 text-muted">
                                                Gross Salary
                                            </span>
                                            <strong class=" fs-5 text-gray-900" >
                                                ${salaryEscapeHTML(salaryCurrency( row.gross_salary ))}
                                            </strong>
                                        </div>
                                    </div>
                                    <div class=" row g-3">
                                        <div class="col-sm-6 col-lg-3 ">
                                            <span class=" staff-info-label" >
                                                Account
                                            </span>
                                            <div class=" staff-info-value">
                                                ${salaryEscapeHTML(row.account_name || '-')}
                                            </div>
                                        </div>
                                        <div class=" col-sm-6 col-lg-3 " >
                                            <span class="staff-info-label ">
                                                Template
                                            </span>
                                            <div class="staff-info-value">
                                                ${salaryEscapeHTML(row.template_name || '-') }
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <span class="staff-info-label">
                                                Appraisal
                                            </span>
                                            <div class="staff-info-value text-success">
                                                ${salaryEscapeHTML(appraisalValue)}
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <span class="staff-info-label">
                                                Processed On
                                            </span>
                                            <div class="staff-info-value">
                                                ${salaryEscapeHTML( row.processed_at || (processed ? '-' : 'Pending') )}
                                            </div>
                                        </div>
                                    </div>

                                    ${row.appraisal_reason
                                            ? `
                                                <div class=" mt-4 pt-4 border-top">
                                                    <span class="staff-info-label">
                                                        Appraisal Reason
                                                    </span>
                                                    <p class=" mb-0 mt-1 fs-7 text-gray-700" >
                                                        ${ salaryEscapeHTML( row.appraisal_reason) }
                                                    </p>
                                                </div>
                                            `
                                            : ''
                                    }

                                    ${variableAmount > 0
                                            ? `
                                                <div class=" mt-4 p-3 rounded-3 bg-light-primary ">
                                                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                                                        <div>
                                                            <span class=" d-block fs-8 text-muted">
                                                                Variable Pay
                                                            </span>
                                                            <strong class="text-primary">
                                                                ${salaryEscapeHTML( salaryCurrency(variableAmount))}
                                                            </strong>
                                                        </div>
                                                        <div class=" text-md-end">
                                                            <span class=" d-block fs-8 text-muted" >
                                                                Period
                                                            </span>
                                                            <strong class="fs-7 text-gray-700">
                                                                ${salaryEscapeHTML(getVariablePayPeriod( row ))  }
                                                            </strong>
                                                        </div>
                                                    </div>
                                                </div>

                                            `
                                            : ''
                                    }
                                </div>
                            </div>
                        `;
                    }
                ).join('');
        }

        /*
        |--------------------------------------------------------------------------
        | APPRAISAL VALUE
        |--------------------------------------------------------------------------
        */
        function formatAppraisalValue(row) {

            const value = Number(row.appraisal_value || 0);

            const unit = String(row.appraisal_unit || '').toLowerCase();

            if (unit.includes('%') || unit.includes('percent')) {
                return `${value}%`;
            }
            if (value > 0 ) {
                return salaryCurrency(value);
            }
            return '-';

        }


        /*
        |--------------------------------------------------------------------------
        | VARIABLE PAY PERIOD
        |--------------------------------------------------------------------------
        */

        function getVariablePayPeriod( row) {
            if ( row.variable_from && row.variable_end_month) {
                return `${row.variable_from} - ${row.variable_end_month}`;
            }

            if (row.variable_months) {
                return `${row.variable_months} Months`;
            }

            return '-';
        }

        /*
        |--------------------------------------------------------------------------
        | PAYROLL YEAR FILTER
        |--------------------------------------------------------------------------
        */
        function renderPayrollYearFilter(payrollHistory) {
            const selector = document.getElementById('staffPayrollYearFilter');

            if (!selector) {
                return;
            }
            payrollHistory = normalizeSalaryArray(payrollHistory);

            const years = [
                ...new Set(
                    payrollHistory
                        .map( row => Number( row.year ))
                        .filter(year => Number.isFinite(year) )
                )
            ].sort((a, b) => b - a);

            selector.innerHTML ='<option value="">All Years</option>';

            years.forEach(
                year => {
                    const option =document.createElement('option');
                    option.value =  year;
                    option.textContent = year;
                    selector.appendChild( option);
                }
            );

            if (payrollSelectedYear && years.includes( Number( payrollSelectedYear) )) {
                selector.value = payrollSelectedYear;
            } else {
                payrollSelectedYear = '';
                selector.value = '';
            }
        }

        /*
        |--------------------------------------------------------------------------
        | PAYROLL HISTORY
        |--------------------------------------------------------------------------
        */
        function renderPayrollHistory(payrollHistory) {

            const body = document.getElementById('staffPayrollHistoryTableBody');

            const empty = document.getElementById( 'staffPayrollHistoryEmpty');

            if (!body) {
                return;
            }

            payrollHistory = normalizeSalaryArray(payrollHistory);


            /*
            * Year filter.
            */

            if (payrollSelectedYear) {
                payrollHistory =
                    payrollHistory.filter(
                        row => String(row.year) === String(payrollSelectedYear)
                    );
            }

            body.innerHTML = '';

            if (!payrollHistory.length) {
                if (empty) {
                    empty.classList.remove('d-none');
                }

                return;
            }

            if (empty) {
                empty.classList.add('d-none');
            }
            body.innerHTML =
                payrollHistory.map(
                    (payroll,index) => {

                        const detailId =`staffPayrollDetail_${payroll.sno || index}`;

                        const hasPayslip = payroll.has_payslip === true || Number(payroll.has_payslip) === 1;

                        return `
                            <tr>
                                <td>
                                    <div class=" d-flex align-items-center gap-3">
                                        <div class="staff-payroll-month-icon">
                                            <i class="mdi mdi-calendar-month-outline"></i>
                                        </div>
                                        <div>
                                            <strong class=" d-block fs-7 text-gray-900">
                                                ${salaryEscapeHTML(payroll.month_label || '-')}
                                            </strong>
                                            <span class="fs-8 text-muted">
                                                ${salaryEscapeHTML(`${payroll.present_days ?? 0} Present`) }
                                            </span>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-end fw-semibold" >
                                    ${salaryEscapeHTML(salaryCurrency(payroll.gross_earnings))}
                                </td>
                                <td class="text-end text-danger fw-semibold">
                                    ${salaryEscapeHTML(salaryCurrency(payroll.gross_deductions))}
                                </td>
                                <td class="text-end">
                                    <div>
                                        ${salaryEscapeHTML(salaryCurrency(payroll.lop_amount))}
                                    </div>
                                    <span class=" fs-9 text-muted" >
                                        ${salaryEscapeHTML(`${payroll.lop_days ?? 0} Days`)}
                                    </span>
                                </td>
                                <td class="text-end" >
                                    <strong class="text-success fs-6" >
                                        ${salaryEscapeHTML(salaryCurrency(payroll.net_payable))}
                                    </strong>
                                </td>
                                <td class="text-center">
                                    ${ hasPayslip
                                            ? `
                                                <button type="button"
                                                    class="btn btn-icon btn-sm btn-light-primary"
                                                    onclick="openStaffPayslip('${salaryEscapeAttribute(payroll.payslip_encrypt || '')}')"
                                                    title="View Payslip">
                                                    <i class=" mdi mdi-file-document-outline"></i>
                                                </button>
                                            `
                                            : `
                                                <span class="badge badge-light">
                                                    N/A
                                                </span>
                                            `
                                    }
                                </td>
                                <td class="text-center">
                                    <button type="button" 
                                        class="btn btn-icon btn-sm btn-light staff-payroll-expand-btn" 
                                        data-target="${detailId}" title="View Breakdown">
                                        <i class=" mdi mdi-chevron-down"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr id="${detailId}" class="staff-payroll-detail-row d-none">
                                <td colspan="7">
                                    ${buildPayrollDetailHTML(payroll)}
                                </td>
                            </tr>
                        `;
                    }
                ).join('');

            bindPayrollExpandButtons();

        }

        /*
        |--------------------------------------------------------------------------
        | PAYROLL DETAIL
        |--------------------------------------------------------------------------
        */
        function buildPayrollDetailHTML(payroll) {
            const earnings = normalizeSalaryArray(payroll.earnings);
            const deductions = normalizeSalaryArray(payroll.deductions);
            const employer = normalizeSalaryArray(payroll.employer_contributions);

            return `
                <div class=" staff-payroll-detail-content">
                    <div class="staff-payroll-detail-grid mb-5">
                        ${payrollMetricHTML('Gross Earnings',payroll.gross_earnings)}
                        ${payrollMetricHTML('Total Deductions',payroll.gross_deductions)}
                        ${payrollMetricHTML('Net Payable',payroll.net_payable )}
                        ${payrollMetricHTML( 'Employer Contribution',payroll.employer_contribution)}
                        ${payrollMetricHTML( 'Monthly CTC', payroll.monthly_ctc)}
                        ${payrollMetricHTML('LOP Amount', payroll.lop_amount)}
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-4">
                            ${payrollComponentGroupHTML('Earnings',earnings,'text-success' )}
                        </div>
                        <div class="col-lg-4">
                            ${payrollComponentGroupHTML('Deductions',deductions,'text-danger' ) }
                        </div>
                        <div class="col-lg-4">
                            ${payrollComponentGroupHTML('Employer Contributions',employer,'text-primary' )}
                        </div>
                    </div>
                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | PAYROLL METRIC
        |--------------------------------------------------------------------------
        */

        function payrollMetricHTML(label,amount) {
            return `
                <div class="staff-salary-metric">
                    <span>
                        ${salaryEscapeHTML(label)}
                    </span>
                    <strong>
                        ${salaryEscapeHTML(salaryCurrency(amount))}
                    </strong>
                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | PAYROLL COMPONENT GROUP
        |--------------------------------------------------------------------------
        */

        function payrollComponentGroupHTML( title, components, titleClass) {

            components = normalizeSalaryArray(components);

            let rows;

            if (!components.length) {
                rows = `
                    <div class=" text-muted fs-8 py-4 text-center">
                        No components
                    </div>
                `;

            } else {
                rows = components.map(
                        component => `
                            <div class="staff-component-row">
                                <div class="staff-component-name">
                                    <strong>
                                        ${salaryEscapeHTML(component.component || 'Component' )}
                                    </strong>
                                </div>
                                <div class="staff-component-amount">
                                    ${salaryEscapeHTML(salaryCurrency(component.amount))}
                                </div>
                            </div>
                        `).join('');
            }

            return `
                <div class="staff-component-section h-100 bg-white">
                    <div class="staff-component-heading ${titleClass}">
                        <span>${salaryEscapeHTML(title)}</span>
                        <strong> ${components.length}</strong>
                    </div>
                    <div class="staff-component-list">
                        ${rows}
                    </div>
                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | EXPAND PAYROLL
        |--------------------------------------------------------------------------
        */
        function bindPayrollExpandButtons() {

            document.querySelectorAll('#staffPayrollHistoryTableBody .staff-payroll-expand-btn')
                .forEach(button => {
                        button.addEventListener('click', function() {

                                const targetId = this.dataset.target;
                                const row = document.getElementById(targetId);

                                if (!row) {
                                    return;
                                }

                                const opening = row.classList.contains('d-none');
                                row.classList.toggle('d-none');

                                const icon = this.querySelector('i');

                                if (icon) {
                                    icon.className = opening ? 'mdi mdi-chevron-up' : 'mdi mdi-chevron-down';
                                }
                            }
                        );
                    }
                );
        }

        /*
        |--------------------------------------------------------------------------
        | PAYSLIP
        |--------------------------------------------------------------------------
        |
        | Replace route if your payslip route is different.
        |
        */
        window.openStaffPayslip = function(encryptedPayslip) {
            if (!encryptedPayslip) {
                return;
            }

            /*
            * Update this URL to match your actual payslip route.
            */

            const url =`/payroll/payslip_staff/${encodeURIComponent(encryptedPayslip)}`;
            window.open(url,'_blank','noopener,noreferrer');

        };

        /*
        |--------------------------------------------------------------------------
        | EVENT LISTENERS
        |--------------------------------------------------------------------------
        */

        document.addEventListener('DOMContentLoaded',function() {

                /*
                * Lazy load when main Salary tab opens.
                */
                const salaryTab = document.getElementById('staffSalaryPayrollTabBtn');

                if (salaryTab) {
                    salaryTab.addEventListener('shown.bs.tab',function() {
                            window.loadStaffSalaryPayroll(false);
                        }
                    );
                }
                /*
                * Salary account switch.
                */
                const accountSelector = document.getElementById('staffSalaryAccountSelector');

                if (accountSelector) {
                    accountSelector.addEventListener('change',function() {

                            selectedSalaryAccountId =this.value;

                            if (salaryPayrollData) {
                                renderSelectedSalaryStructure(salaryPayrollData);
                            }
                        }
                    );
                }
                /*
                * Payroll year filter.
                */
                const yearSelector = document.getElementById('staffPayrollYearFilter');

                if (yearSelector) {
                    yearSelector.addEventListener('change',function() {

                            payrollSelectedYear = this.value;

                            if (salaryPayrollData) {
                                renderPayrollHistory(salaryPayrollData.payroll_history || []);
                            }
                        }
                    );
                }

                /*
                * Retry.
                */
                const retryButton = document.getElementById('staffSalaryPayrollRetryBtn');

                if (retryButton) {
                    retryButton.addEventListener('click',function() {
                            window.loadStaffSalaryPayroll(true);
                        }
                    );
                }
                /*
                * Refresh.
                */
                const refreshButton = document.getElementById('staffSalaryPayrollRefreshBtn');

                if (refreshButton) {
                    refreshButton.addEventListener('click',
                        function() {
                            window.loadStaffSalaryPayroll(true);
                        }
                    );
                }

                /*
                * Abort salary request when staff modal closes.
                */
                const modal = document.getElementById('kt_modal_view_staff');

                if (modal) {
                    modal.addEventListener('hidden.bs.modal',function() {
                            if (salaryPayrollAbortController) {
                                salaryPayrollAbortController.abort();
                            }
                            salaryPayrollLoading = false;
                        }
                    );
                }
            }
        );

        /*
        |--------------------------------------------------------------------------
        | SKELETON
        |--------------------------------------------------------------------------
        */

        function showSalaryPayrollSkeleton() {
            const skeleton = document.getElementById('staffSalaryPayrollSkeleton');
            const content = document.getElementById('staffSalaryPayrollContent');

            const error = document.getElementById('staffSalaryPayrollError');

            if (skeleton) {
                skeleton.classList.remove('d-none' );
            }
            if (content) {
                content.classList.add('d-none');
            }
            if (error) {
                error.classList.add('d-none');
            }
        }

        function hideSalaryPayrollSkeleton() {
            const skeleton = document.getElementById('staffSalaryPayrollSkeleton');
            if (skeleton) {
                skeleton.classList.add('d-none');
            }
        }

        function showSalaryPayrollContent() {
            const content = document.getElementById('staffSalaryPayrollContent');
            const error = document.getElementById('staffSalaryPayrollError');

            if (content) {
                content.classList.remove('d-none');
            }
            if (error) {
                error.classList.add('d-none');
            }
        }

        /*
        |--------------------------------------------------------------------------
        | ERROR
        |--------------------------------------------------------------------------
        */

        function showSalaryPayrollError(message) {
            hideSalaryPayrollSkeleton();

            const content = document.getElementById('staffSalaryPayrollContent');
            const error = document.getElementById('staffSalaryPayrollError');
            
            const errorMessage =document.getElementById('staffSalaryPayrollErrorMessage');
            if (content) {
                content.classList.add('d-none');
            }
            if (errorMessage) {
                errorMessage.textContent =message;
            }
            if (error) {
                error.classList.remove('d-none');
            }
        }

        /*
        |--------------------------------------------------------------------------
        | RESET
        |--------------------------------------------------------------------------
        */

        function resetStaffSalaryPayrollUI() {
            if (salaryPayrollAbortController) {
                salaryPayrollAbortController.abort();

            }

            salaryPayrollLoading = false;

            showSalaryPayrollSkeleton();
            const pendingBadge =document.getElementById('staffSalaryPendingBadge');

            if (pendingBadge) {
                pendingBadge.classList.add('d-none');
                pendingBadge.textContent ='0';
            }
            /*
            * Reset internal salary tab.
            */
            const currentTab =document.querySelector('#staffPayrollInternalTabs button[data-bs-target="#staffCurrentSalaryPane"]');

            if (currentTab && typeof bootstrap !== 'undefined') {
                try {
                    bootstrap.Tab.getOrCreateInstance(currentTab).show();
                } catch (error) {
                    console.warn('Unable to reset salary tab.',error);
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | HELPERS
        |--------------------------------------------------------------------------
        */

        function setSalaryText(id,value) {

            const element =document.getElementById(id);

            if (!element) {
                return;
            }

            element.textContent = value !== null && value !== undefined && value !== '' ? String(value) : '-';

        }

        function salaryCurrency(value) {

            const amount = Number(value || 0);

            return new Intl.NumberFormat(
                'en-IN',
                {
                    style:'currency',
                    currency:'INR',
                    maximumFractionDigits: 2
                }

            ).format(Number.isFinite(amount) ? amount : 0);

        }

        function normalizeSalaryArray(value) {
            return Array.isArray(value) ? value : [];
        }

        function formatSalaryDate(value) {

            if (!value) {
                return '-';
            }

            const match = String(value).match(/^(\d{4})-(\d{2})-(\d{2})/);

            if (match) {
                return `${match[3]}-${match[2]}-${match[1]}`;
            }

            return String(value);
        }

        function formatSalaryMonth(value) {

            if (!value) {
                return '-';
            }

            const match = String(value).match(/^(\d{4})-(\d{2})/);

            if (!match) {
                return String(value);
            }

            const date = new Date(Number(match[1]),Number(match[2]) - 1,1);

            return new Intl.DateTimeFormat('en-IN',{month:'short',year:'numeric'}).format(date);

        }


        function salaryEmptyState(icon,title,description) {
            return `
                <div class="staff-empty-state">
                    <i class="mdi ${salaryEscapeAttribute(icon)}"></i>
                    <h6>${salaryEscapeHTML(title)}</h6>
                    <p>${salaryEscapeHTML(description)}</p>
                </div>
            `;
        }

        function salaryEscapeHTML(value) {

            if (value === null ||value === undefined) {
                return '';
            }
            return String(value)
                .replace(/&/g,'&amp;')
                .replace(/</g,'&lt;')
                .replace(/>/g,'&gt;')
                .replace(/"/g,'&quot;')
                .replace(/'/g,'&#039;');
        }

        function salaryEscapeAttribute(value) {
            return salaryEscapeHTML(value);
        }

    })();
</script>


<script>
    function loadExitPendingAlerts() {
        $('#skeleton-loader').show(); 

        fetch('/hr_enroll/exit_staff_pending', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(r => r.json())
        .then(res => {
            // exitPendingMap = {};

            // res.staff.forEach(item => {
            //     exitPendingMap[item.external_uuid] = item;
            // });
            $('#exitPendingBadge').text(res.total_pending);
            $('#exitPendingBadge').toggleClass('d-none', res.total_pending == 0);
        })
        .catch(console.error);

    }

    async function initializePage() {              
        await loadExitPendingAlerts();                  
        loadThemes();
    }

    $(initializePage);
</script>
<script>


    let passwordSecurityTimer = null;
    let passwordAccessTimer = null;

    let currentPasswordSecuritySession = null;

function resetPasswordSecurityUI()
{
    clearInterval(passwordSecurityTimer);
    clearInterval(passwordAccessTimer);

    passwordSecurityTimer = null;
    passwordAccessTimer = null;
    currentPasswordSecuritySession = null;

    $("#passwordSecuritySession").val("");
    $("#securityPin").val("");
    $("#securityPinMessage").html("");
    $("#passwordSecurityQrImage").attr("src", "");
    $("#passwordSecurityQrBox").hide();
    $("#passwordPinBox").hide();
    $("#passwordSecurityStatus").html("Waiting for scan...");
    $("#passwordContainer").html(`
        <div class="d-flex justify-content-between align-items-center ">           
        <div>           
            <strong>Password Protected</strong>
            <p>Passwords are intentionally hidden for security.</p>
        </div>
            <button type="button" class="btn btn-primary btn-sm" onclick="startPasswordReveal()">
                <i class="mdi mdi-qrcode-scan"></i>
            </button>
        </div>

    `);
}
/* Start Password Reveal */
function startPasswordReveal()
{
    let recordId = $("#view_staff_id_hidden").val();

    if (!recordId) {
        toastr.error("Staff record not found.");
        return;
    }

    /*Always reset previous staff state*/
    resetPasswordSecurityUI();
    /*Create Security Session*/
    $.ajax({
        url: "/create-session",
        type: "POST",
        data: {
            module_id: 1,
            record_id: recordId,
            _token: $('meta[name="csrf-token"]').attr("content")
        },
        success: function(res)
        {
            if (!res.status) {
                toastr.error(res.message || "Unable to create security session.");
                return;
            }

            currentPasswordSecuritySession = res.data.session_uuid;

            $("#passwordSecuritySession").val(res.data.session_uuid);
            $("#passwordSecurityQrBox").show();
            $("#passwordSecurityQrImage").attr("src","data:image/svg+xml;base64," + res.data.qr_image);
            $("#passwordSecurityStatus").html('<span class="text-muted">' +'Waiting for mobile scan...' +'</span>');

            checkPasswordSecurityStatus();
        },
        error: function(xhr)
        {
            toastr.error(xhr.responseJSON?.message || "Unable to create security session.");
        }
    });
}

/* Check Security Session */
function checkPasswordSecurityStatus()
{
    clearInterval(passwordSecurityTimer);

    passwordSecurityTimer = setInterval(function()
    {
        let uuid = $("#passwordSecuritySession").val();

        if (!uuid) {
            return;
        }
        $.ajax({
            url: "/security/session/" + uuid,
            type: "GET",
            success: function(res)
            {
                if (!res.status) {
                    return;
                }

                let status = res.data.status;

                /* CREATED */

                if (status === "CREATED") {
                    $("#passwordSecurityStatus")
                        .html(
                            '<span class="text-muted">' +
                            'Waiting for mobile scan...' +
                            '</span>'
                        );
                }


                /* SCANNED */
                if (status === "SCANNED") {
                    $("#passwordSecurityStatus")
                        .html('<span class="text-success fw-bold">' +'<i class="mdi mdi-cellphone-check"></i> ' +'Mobile Connected' +'</span>');
                }
                /* PIN GENERATED */
                if (status === "PIN_GENERATED") {
                    clearInterval(passwordSecurityTimer);
                    showPinInput();
                }
                /* VERIFIED */
                if (status === "VERIFIED") {
                    clearInterval(passwordSecurityTimer);
                    loadStaffPassword();
                }
                /* EXPIRED */
                if (status === "EXPIRED" || status === "CLOSED") {
                    hideRevealedPassword();
                    clearInterval(passwordSecurityTimer);
                }
            },
            error: function(xhr)
            {
                if (xhr.status === 404) {
                    hideRevealedPassword();
                    clearInterval(passwordSecurityTimer);
                }
            }
        });

    }, 3000);
}


/* Show PIN */

function showPinInput()
{
    $("#passwordSecurityQrBox").hide();

    $("#passwordPinBox").show();

    $("#securityPin").val("");

    $("#securityPinMessage").html("");

    $("#securityPin").focus();
}

/* Verify PIN */
function verifySecurityPin()
{
    let uuid = $("#passwordSecuritySession").val();
    let pin = $.trim($("#securityPin").val());
    if (!uuid) {
        toastr.error("Security session not found.");
        return;
    }

    if (!pin) {
        toastr.warning("Please enter the security PIN.");
        $("#securityPin").focus();
        return;
    }

    $.ajax({
        url: "/api/security/verify-pin",
        type: "POST",
        data: {
            session_uuid: uuid,
            pin: pin
        },
        headers: {
            "Accept": "application/json"
        },
        success: function(res)
        {
            if (!res.status) {
                $("#securityPinMessage").html('<span class="text-danger">' + (res.message || "Invalid PIN.") + '</span>');
                return;
            }

            $("#passwordPinBox").hide();
            $("#passwordSecurityStatus")
                .html(
                    '<span class="text-success fw-bold">' +
                    '<i class="mdi mdi-shield-check"></i> ' +
                    'Verified' +
                    '</span>'
                );

            /* Load ONLY this session's staff password */
            loadStaffPassword();

        },
        error: function(xhr)
        {
            $("#securityPinMessage")
                .html(
                    '<span class="text-danger">' +
                    (
                        xhr.responseJSON?.message ||
                        "PIN verification failed."
                    ) +
                    '</span>'
                );
        }
    });
}


/* Load Staff Password */
function loadStaffPassword()
{
    let uuid = $("#passwordSecuritySession").val();

    if (!uuid) {
        return;
    }

    $.ajax({
        url: "/security/staff-password/" + uuid,
        type: "GET",
        success: function(res)
        {
            if (!res.status) {
                hideRevealedPassword();
                return;
            }

            /* Verify returned staff ID matches current modal staff*/
            let currentStaffId = String($("#view_staff_id_hidden").val());
            let returnedStaffId = String(res.data.staff_id);
            if (currentStaffId !== returnedStaffId) {
                console.error("Security staff mismatch.");
                hideRevealedPassword();
                return;
            }

            /* Show Password */
            $("#passwordContainer").html(`
                <div class="d-flex align-items-center gap-2">
                    <i class="mdi mdi-shield-check-outline text-success fs-4"></i>
                    <div class="flex-grow-1">
                        <strong class="text-success">
                            Password Verified
                        </strong>
                        <div class="mt-2">
                            <span
                                id="revealedStaffPassword"
                                class="fw-bold fs-5 text-dark">
                                ${escapeHtml(res.data.password)}
                            </span>
                        </div>
                        <small id="passwordAccessExpiry" class="text-danger fw-bold"></small>
                    </div>
                </div>
            `);

            /* Start expiry countdown */

            startPasswordExpiryCountdown(res.data.expires_at );
        },

        error: function(xhr)
        {
            hideRevealedPassword();
            if (xhr.status === 403) {
                toastr.warning(xhr.responseJSON?.message || "Security access has expired.");
            }
        }

    });
}


/* Password Expiry Countdown */

function startPasswordExpiryCountdown(expiresAt)
{
    clearInterval(passwordAccessTimer);

    function updateExpiry()
    {

        let expiry =
            new Date(expiresAt).getTime();

        let now =
            new Date().getTime();

        let remaining =
            expiry - now;

        if (remaining <= 0) {

            hideRevealedPassword();

            return;
        }

        let seconds =
            Math.floor(remaining / 1000);

        let minutes =
            Math.floor(seconds / 60);

        seconds =
            seconds % 60;

        $("#passwordAccessExpiry")
            .text(
                "Access expires in " +
                minutes +
                ":" +
                String(seconds).padStart(2, "0")
            );
    }

    updateExpiry();

    passwordAccessTimer =
        setInterval(updateExpiry, 1000);
}


/*
|--------------------------------------------------------------------------
| Hide Password After Expiry
|--------------------------------------------------------------------------
*/

function hideRevealedPassword()
{
    clearInterval(passwordAccessTimer);

    clearInterval(passwordSecurityTimer);

    passwordAccessTimer = null;

    passwordSecurityTimer = null;

    currentPasswordSecuritySession = null;

    $("#passwordSecuritySession").val("");

    $("#securityPin").val("");

    $("#passwordSecurityQrImage").attr(
        "src",
        ""
    );

    $("#passwordSecurityQrBox").hide();

    $("#passwordPinBox").hide();

    $("#passwordSecurityStatus")
        .html("Access expired.");

    /*
    |--------------------------------------------------------------------------
    | IMPORTANT:
    | Return exactly to hidden state
    |--------------------------------------------------------------------------
    */

    $("#passwordContainer").html(`
        <div class="d-flex justify-content-center align-items-center" >
            <div>                
                <strong>
                    Password Protected
                </strong>

                <p>
                    Passwords are intentionally hidden for security.
                </p>
            </div>  

            <button
                type="button"
                class="btn btn-primary btn-sm"
                onclick="startPasswordReveal()">
                <i class="mdi mdi-qrcode-scan"></i>
            </button>
        </div>

    `);
}


/*
|--------------------------------------------------------------------------
| HTML Escape
|--------------------------------------------------------------------------
*/

function escapeHtml(value)
{
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
</script>

<script>

    let profileEditRequest = null;

    function send_profile_edit(encryptedId) {

        $('#profile_edit_encrypted_id').val(encryptedId);

        // Reset communication
        $('#send_profile_whatsapp').val(0);
        $('#send_profile_email').val(0);
        $('#send_profile_sms').val(0);

        $('.profile-communication-btn').removeClass('act_bx_selected');

        $('#profile_edit_communication_err').text('');

        // Loading state
        $('#profile_edit_staff_name').text('Loading...');
        $('#profile_edit_staff_id').text('-');
        $('#profile_edit_mobile').text('-');
        $('#profile_edit_email').text('-');

        $('#profile_edit_url').val('Loading...');

        $('#profile_edit_staff_image')
            .attr('src', '{{ asset('assets/egc_images/auth/user_3.png') }}');

        if (profileEditRequest) {
            profileEditRequest.abort();
        }

        profileEditRequest = $.ajax({

            url: "{{ route('staff.profile.edit.details') }}",

            method: "GET",

            data: {
                encrypted_id: encryptedId
            },

            headers: {
                'Accept': 'application/json'
            },

            success: function(response) {

                if (response.status !== 200) {
                    toastr.error(
                        response.message || 'Unable to load staff details.'
                    );
                    return;
                }

                const staff = response.data || {};

                $('#profile_edit_staff_name')
                    .text(staff.staff_name || '-');

                $('#profile_edit_staff_id')
                    .text(staff.staff_id || '-');

                $('#profile_edit_mobile')
                    .text(staff.mobile_no || '-');

                $('#profile_edit_email')
                    .text(staff.email_id || '-');

                if (staff.staff_image) {
                    $('#profile_edit_staff_image')
                        .attr('src', staff.staff_image);
                }

                $('#profile_edit_url')
                    .val(staff.profile_edit_url || '-');
            },

            error: function(xhr, status) {

                if (status === 'abort') {
                    return;
                }

                const message =
                    xhr.responseJSON?.message ||
                    'Unable to load staff details.';

                toastr.error(message);

                $('#profile_edit_staff_name').text('-');
                $('#profile_edit_url').val('-');
            }

        });
    }


    function toggleProfileCommunication(type) {

        let input;
        let button;

        if (type === 'whatsapp') {
            input = $('#send_profile_whatsapp');
            button = $('#profile_edit_whatsapp_btn');
        }

        if (type === 'email') {
            input = $('#send_profile_email');
            button = $('#profile_edit_email_btn');
        }

        if (type === 'sms') {
            input = $('#send_profile_sms');
            button = $('#profile_edit_sms_btn');
        }

        const active = input.val() == 1;

        input.val(active ? 0 : 1);

        if (!active) {
            button.addClass('act_bx_selected');
        } else {
            button.removeClass('act_bx_selected');
        }

        $('#profile_edit_communication_err').text('');
    }


    $('#copy_profile_edit_url').on('click', function() {

        const input = document.getElementById('profile_edit_url');

        if (!input || !input.value || input.value === 'Loading...') {
            toastr.warning('Profile URL is not ready yet.');
            return;
        }

        navigator.clipboard.writeText(input.value)
            .then(function() {
                toastr.success('Profile edit URL copied.');
            })
            .catch(function() {
                input.select();
                document.execCommand('copy');
                toastr.success('Profile edit URL copied.');
            });
    });


    $('#sendProfileEditBtn').on('click', function(e) {

        e.preventDefault();

        const btn = $('#sendProfileEditBtn');
        const loader = $('#sendProfileEditLoader');

        const encryptedId =  $('#profile_edit_encrypted_id').val();

        const whatsapp = $('#send_profile_whatsapp').val();

        const email = $('#send_profile_email').val();

        const sms = $('#send_profile_sms').val();

        $('#profile_edit_communication_err').text('');

        if (!encryptedId) {
            toastr.error('Staff information is not available.');
            return;
        }

        if (
            whatsapp != 1 &&
            email != 1 &&
            sms != 1
        ) {
            $('#profile_edit_communication_err')
                .text('Please select at least one communication method.');

            return;
        }

        btn.prop('disabled', true);
        loader.removeClass('d-none');

        $.ajax({

            url: "{{ route('staff.profile.edit.send') }}",

            method: "POST",

            headers: {
                'X-CSRF-TOKEN':
                    document
                        .querySelector('meta[name="csrf-token"]')
                        .getAttribute('content'),

                'Accept': 'application/json'
            },

            data: {
                encrypted_id: encryptedId,
                whatsapp: whatsapp,
                email: email,
                sms: sms
            },

            success: function(response) {

                if (response.status === 200) {

                    toastr.success(
                        response.message ||
                        'Profile edit link sent successfully.'
                    );

                    const modal =
                        bootstrap.Modal.getInstance(
                            document.getElementById(
                                'kt_modal_send_profile_edit'
                            )
                        );

                    modal?.hide();

                } else {

                    toastr.error(
                        response.message ||
                        'Unable to send profile edit link.'
                    );
                }
            },

            error: function(xhr) {

                toastr.error(
                    xhr.responseJSON?.message ||
                    'Unable to send profile edit link.'
                );

            },

            complete: function() {

                btn.prop('disabled', false);
                loader.addClass('d-none');
            }

        });
    });
</script>

@endsection