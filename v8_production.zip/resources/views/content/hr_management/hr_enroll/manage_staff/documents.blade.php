<div class="tab-pane fade"
id="documents_information">

<div class="row g-4">

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Total Documents</h6>

<h2 id="docTotal">0</h2>

</div>

</div>

</div>

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Uploaded</h6>

<h2 class="text-success"

id="docUploaded">

0

</h2>

</div>

</div>

</div>

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Pending</h6>

<h2 class="text-warning"

id="docPending">

0

</h2>

</div>

</div>

</div>

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Expired</h6>

<h2 class="text-danger"

id="docExpired">

0

</h2>

</div>

</div>

</div>

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Rejected</h6>

<h2 class="text-danger"

id="docRejected">

0

</h2>

</div>

</div>

</div>

<div class="col-lg-2">

<div class="card border-0 shadow-sm rounded-4 text-center">

<div class="card-body">

<h6>Verification</h6>

<h2 id="verifyPercent">

100%

</h2>

</div>

</div>

</div>

</div>

<div class="card shadow-sm border-0 rounded-4 mt-4">

<div class="card-header">

<h5>

Required Documents

</h5>

</div>

<div class="card-body">

<div class="row"

id="documentChecklist">

</div>

</div>

</div>

<div class="card shadow-sm border-0 rounded-4 mt-4">

<div class="card-header d-flex justify-content-between">

<h5>

Uploaded Documents

</h5>

<button class="btn btn-primary">

Upload New

</button>

</div>

<div class="card-body">

<table class="table table-hover align-middle">

<thead>

<tr>

<th>Document</th>

<th>Status</th>

<th>Uploaded</th>

<th>Expiry</th>

<th>Actions</th>

</tr>

</thead>

<tbody id="uploadedDocuments">

</tbody>

</table>

</div>

</div>

<div class="card shadow-sm border-0 rounded-4 mt-4">

<div class="card-header">

<h5>

Expiry Monitor

</h5>

</div>

<div class="card-body">

<div id="expiryList">

</div>

</div>

</div>

<div class="card shadow-sm border-0 rounded-4 mt-4">

<div class="card-header">

<h5>

Verification Timeline

</h5>

</div>

<div class="card-body">

<div id="verificationTimeline">

</div>

</div>

</div>