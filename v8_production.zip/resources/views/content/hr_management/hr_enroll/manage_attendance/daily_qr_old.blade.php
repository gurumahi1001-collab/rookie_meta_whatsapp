@extends('layouts/blankLayout')

@section('title', 'Apply Job - Welcome')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/dropzone/dropzone.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/dropzone/dropzone.js'])
@endsection

@section('page-script')
    @vite('resources/assets/js/forms-file-upload.js')
@endsection

@section('content')


<style>
    /* =========================================================
       ATTENDANCE QR MODAL
    ========================================================= */

    .attendance-qr-modal .modal-dialog {
        max-width: 720px;
    }

    .attendance-qr-modal .modal-content {
        border: 0;
        border-radius: 24px;
        overflow: hidden;
        background: #f8fafc;
        box-shadow: 0 25px 70px rgba(15, 23, 42, 0.25);
    }

    /* Header */

    .attendance-qr-header {
        /* background: linear-gradient(
            135deg,
            #0d6efd 0%,
            #2563eb 50%,
            #4f46e5 100%
        ); */
        background: linear-gradient(
            135deg,
            #8F1D1D 0%,
            #B52B25 45%,
            #D63B25 75%,
            #F5A623 100%
        );
        color: #ffffff;
        padding: 25px 30px;
        position: relative;
        overflow: hidden;
    }

    .attendance-qr-header::before {
        content: "";
        position: absolute;
        width: 220px;
        height: 220px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.08);
        right: -70px;
        top: -120px;
    }

    .attendance-qr-header::after {
        content: "";
        position: absolute;
        width: 150px;
        height: 150px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.06);
        left: -70px;
        bottom: -90px;
    }

    .attendance-header-content {
        position: relative;
        z-index: 2;
    }

    .attendance-header-icon {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.16);
        backdrop-filter: blur(8px);
        font-size: 27px;
    }

    .attendance-header-title {
        font-size: 21px;
        font-weight: 700;
        margin: 0;
    }

    .attendance-header-subtitle {
        font-size: 13px;
        opacity: 0.85;
        margin-top: 3px;
    }

    /* Close */

    .attendance-close {
        position: absolute;
        top: 20px;
        right: 20px;
        z-index: 5;
        width: 36px;
        height: 36px;
        border: 0;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.15);
        color: #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .attendance-close:hover {
        background: rgba(255, 255, 255, 0.25);
        transform: scale(1.05);
    }

    /* Body */

    .attendance-qr-body {
        padding: 28px;
    }

    /* Status */

    .qr-status-row {
        display: flex;
        justify-content: center;
        margin-bottom: 18px;
    }

    .qr-live-status {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 14px;
        border-radius: 30px;
        font-size: 12px;
        font-weight: 700;
        background: #ecfdf3;
        color: #15803d;
        border: 1px solid #bbf7d0;
    }

    .qr-live-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #16a34a;
        animation: qrPulse 1.5s infinite;
    }

    @keyframes qrPulse {
        0% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.5);
        }

        70% {
            box-shadow: 0 0 0 7px rgba(22, 163, 74, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0);
        }
    }

    /* QR */

    .qr-display-wrapper {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    }

    .qr-card {
        background: #ffffff;
        border-radius: 24px;
        padding: 18px;
        border: 1px solid #e5e7eb;
        box-shadow:
            0 15px 40px rgba(15, 23, 42, 0.08),
            0 3px 10px rgba(15, 23, 42, 0.04);
        position: relative;
    }

    .qr-card::before {
        content: "";
        position: absolute;
        inset: -5px;
        border-radius: 28px;
        border: 2px solid rgba(13, 110, 253, 0.08);
        pointer-events: none;
    }

    .qr-image-container {
        width: 330px;
        height: 330px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #ffffff;
        border-radius: 16px;
        overflow: hidden;
    }

    .qr-image {
        width: 310px;
        height: 310px;
        object-fit: contain;
        display: block;
    }

    /* Loading */

    .qr-loading {
        display: none;
        width: 310px;
        height: 310px;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 12px;
    }

    .qr-loading-spinner {
        width: 42px;
        height: 42px;
        border: 4px solid #e5e7eb;
        border-top-color: #8F1D1D;
        border-radius: 50%;
        animation: qrSpin 0.8s linear infinite;
    }

    @keyframes qrSpin {
        to {
            transform: rotate(360deg);
        }
    }

    /* Countdown */

    .qr-countdown-wrapper {
        text-align: center;
        margin-top: 20px;
    }

    .qr-countdown-label {
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        color: #64748b;
        margin-bottom: 4px;
    }

    .qr-countdown {
        font-size: 27px;
        font-weight: 800;
        color: #0f172a;
        letter-spacing: 1px;
        font-variant-numeric: tabular-nums;
    }

    .qr-countdown.warning {
        color: #d97706;
    }

    .qr-countdown.danger {
        color: #dc2626;
    }

    /* Progress */

    .qr-progress-container {
        margin-top: 9px;
    }

    .qr-progress {
        height: 6px;
        border-radius: 20px;
        background: #e5e7eb;
        overflow: hidden;
    }

    .qr-progress-bar {
        height: 100%;
        width: 100%;
        border-radius: 20px;
        background: linear-gradient(
            90deg,
            #16a34a,
            #22c55e
        );
        transition: width 1s linear;
    }

    /* Instruction */

    .qr-instruction-card {
        margin-top: 22px;
        padding: 17px 18px;
        background: #eff6ff;
        border: 1px solid #dbeafe;
        border-radius: 15px;
    }

    .qr-instruction-icon {
        width: 42px;
        height: 42px;
        min-width: 42px;
        border-radius: 12px;
        background: #dbeafe;
        color: #8F1D1D;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 21px;
    }

    .qr-instruction-title {
        font-size: 14px;
        font-weight: 700;
        color: #1e3a8a;
    }

    .qr-instruction-text {
        font-size: 12px;
        color: #475569;
        line-height: 1.6;
        margin-top: 2px;
    }

    /* Details */

    .qr-details {
        margin-top: 18px;
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }

    .qr-detail-item {
        background: #ffffff;
        border: 1px solid #e5e7eb;
        border-radius: 13px;
        padding: 12px 14px;
    }

    .qr-detail-label {
        font-size: 10px;
        font-weight: 600;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .qr-detail-value {
        margin-top: 3px;
        font-size: 13px;
        font-weight: 700;
        color: #334155;
    }

    /* Copy link */

    .qr-link-section {
        margin-top: 18px;
    }

    .qr-link-input {
        background: #f8fafc !important;
        border-color: #e2e8f0 !important;
        font-size: 11px !important;
        color: #64748b !important;
    }

    /* Footer */

    .attendance-qr-footer {
        padding: 16px 28px 24px;
        background: #f8fafc;
        border-top: 1px solid #eef2f7;
    }

    .qr-security-note {
        text-align: center;
        font-size: 11px;
        color: #94a3b8;
    }

    .qr-security-note i {
        color: #16a34a;
    }

    /* Expired */

    .qr-expired-overlay {
        display: none;
        position: absolute;
        inset: 18px;
        background: rgba(255, 255, 255, 0.96);
        border-radius: 16px;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        z-index: 5;
    }

    .qr-expired-icon {
        width: 58px;
        height: 58px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #fee2e2;
        color: #dc2626;
        font-size: 28px;
        margin-bottom: 12px;
    }

    .qr-expired-title {
        font-weight: 800;
        color: #991b1b;
        font-size: 16px;
    }

    .qr-expired-text {
        font-size: 12px;
        color: #64748b;
        margin-top: 4px;
    }

    /* Mobile */

    @media (max-width: 576px) {

        .attendance-qr-modal .modal-dialog {
            margin: 10px;
        }

        .attendance-qr-body {
            padding: 20px 15px;
        }

        .qr-image-container {
            width: 260px;
            height: 260px;
        }

        .qr-image,
        .qr-loading {
            width: 240px;
            height: 240px;
        }

        .qr-card {
            padding: 12px;
        }

        .qr-details {
            grid-template-columns: 1fr;
        }

        .attendance-qr-header {
            padding: 20px;
        }
    }
</style>


<div class="attendance-qr-modal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- HEADER -->
            <div class="attendance-qr-header">
                
                <div class="attendance-header-content">
                    <div class="d-flex align-items-center gap-3">
                        <div class="attendance-header-icon">
                            <i class="mdi mdi-qrcode-scan"></i>
                        </div>
                        <div>
                            <h3 class="attendance-header-title">
                                Daily Attendance
                            </h3>
                            <div class="attendance-header-subtitle">
                                Scan this QR code to check in or check out
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- BODY -->
            <div class="attendance-qr-body">
                <!-- LIVE STATUS -->
                <div class="qr-status-row">
                    <div class="qr-live-status" id="qrLiveStatus">
                        <span class="qr-live-dot"></span>
                        <span id="qrStatusText">
                            QR CODE ACTIVE
                        </span>
                    </div>
                </div>
                <!-- QR -->
                <div class="qr-display-wrapper">
                    <div class="qr-card">
                        <div class="qr-image-container">
                            <!-- QR -->
                            <img id="qrImage"
                                 src="{{ asset('assets/egc_images/qr_code.png') }}"
                                 class="qr-image"
                                 alt="Daily Attendance QR Code">
                            <!-- LOADING -->
                            <div id="qrLoading" class="qr-loading">
                                <div class="qr-loading-spinner"></div>
                                <div class="text-muted fs-7">
                                    Generating secure QR...
                                </div>
                            </div>
                        </div>
                        <!-- EXPIRED OVERLAY -->
                        <div id="qrExpiredOverlay"
                             class="qr-expired-overlay">
                            <div class="qr-expired-icon">
                                <i class="mdi mdi-clock-alert-outline"></i>
                            </div>
                            <div class="qr-expired-title">
                                QR Code Expired
                            </div>
                            <div class="qr-expired-text">
                                Generating a new secure QR code...
                            </div>
                        </div>
                    </div>
                </div>
                <!-- COUNTDOWN -->
                <div class="qr-countdown-wrapper">
                    <div class="qr-countdown-label">
                        QR refreshes automatically in
                    </div>
                    <div id="qrCountdown"
                         class="qr-countdown">
                        --:--
                    </div>
                    <div class="qr-progress-container">
                        <div class="qr-progress">
                            <div id="qrProgressBar"
                                 class="qr-progress-bar">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- INSTRUCTIONS -->
                <div class="qr-instruction-card">
                    <div class="d-flex align-items-start gap-3">
                        <div class="qr-instruction-icon">
                            <i class="mdi mdi-cellphone-nfc"></i>
                        </div>
                        <div>
                            <div class="qr-instruction-title">
                                How to mark attendance
                            </div>
                            <div class="qr-instruction-text">
                                Open the Elysium One app on your mobile,
                                scan this QR code and complete the
                                Check-In or Check-Out process.
                            </div>
                        </div>
                    </div>
                </div>
                <!-- DETAILS -->
                <div class="qr-details">
                    <div class="qr-detail-item">
                        <div class="qr-detail-label">
                            Date
                        </div>
                        <div class="qr-detail-value"
                             id="qrDate">
                            --
                        </div>
                    </div>
                    <div class="qr-detail-item">
                        <div class="qr-detail-label">
                            Generated At
                        </div>
                        <div class="qr-detail-value"
                             id="qrGeneratedAt">
                            --
                        </div>
                    </div>
                    <div class="qr-detail-item">
                        <div class="qr-detail-label">
                            Valid Until
                        </div>
                        <div class="qr-detail-value"
                             id="qrExpiresAt">
                            --
                        </div>
                    </div>
                    <div class="qr-detail-item">
                        <div class="qr-detail-label">
                            Security
                        </div>
                        <div class="qr-detail-value">
                            <i class="mdi mdi-shield-check text-success me-1"></i>
                            Temporary QR
                        </div>
                    </div>
                </div>
                <!-- LINK -->
                <div class="qr-link-section">
                    <div class="input-group">
                        <input type="text"
                               id="download_qr_code_name"
                               class="form-control qr-link-input"
                               readonly placeholder="Secure attendance link">
                        <button type="button" class="btn btn-light-primary" onclick="copyAttendanceQrLink()">
                            <i class="mdi mdi-content-copy me-1"></i>
                            Copy
                        </button>
                    </div>
                </div>
            </div>
            <!-- FOOTER -->
            <div class="attendance-qr-footer">
                <div class="qr-security-note">
                    <i class="mdi mdi-shield-lock-outline me-1"></i>
                    For security, this QR code automatically changes
                    every 10 minutes.
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    let attendanceQrTimer = null;
    let attendanceQrRefreshTimer = null;

    let attendanceQrExpiresAt = null;
    let attendanceQrGeneratedAt = null;

    const ATTENDANCE_QR_DURATION_SECONDS = 10 * 60;


    /* OPEN / GENERATE QR */
    function generateQr() {

        clearAttendanceQrTimers();

        resetAttendanceQrUI();

        generateNewAttendanceQr();
    }

    /* GENERATE NEW QR */
    async function generateNewAttendanceQr() {

        showQrLoading(true);

        try {

                const response = await fetch(
                    "{{ url('/gen_daily_checkin_qr/generate-qr') }}",
                    {
                        method: 'GET',

                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },

                        cache: 'no-store'
                    }
                );

                if (!response.ok) {

                    throw new Error(
                        `HTTP error: ${response.status}`
                    );
                }

                const data = await response.json();
                console.log('Attendance QR Response:', data);
                if (
                    data.status !== 200 ||
                    !data.qr_base64 ||
                    !data.expires_at
                ) {

                    console.error(
                        'Invalid QR response:',
                        data
                    );

                    throw new Error(
                        data.message ||
                        'QR generation failed'
                    );
                }


                $('#qrImage')
                    .hide()
                    .attr(
                        'src',
                        data.qr_base64
                    )
                    .fadeIn(250);

                $('#qrDate').text(
                    data.date_formatted ??
                    moment().format('DD MMM YYYY')
                );


                $('#qrGeneratedAt').text(
                    data.generated_at_formatted ??
                    moment().format('hh:mm:ss A')
                );

                $('#qrExpiresAt').text(
                    data.expires_at_formatted ??
                    data.expires_at
                );



                $('#download_qr_code_name')
                .val(
                    data.link || ''
                );


                attendanceQrExpiresAt =
                    new Date(
                        data.expires_at
                    ).getTime();


                attendanceQrGeneratedAt =
                    data.generated_at
                        ? new Date(
                            data.generated_at
                        ).getTime()
                        : Date.now();


                showQrLoading(false);


                setQrStatus(
                    'active',
                    'QR CODE ACTIVE'
                );

                $('#qrExpiredOverlay')
                    .hide();


                startAttendanceQrCountdown();


        } catch (error) {

            console.error(
                'Attendance QR Error:',
                error
            );


            showQrLoading(false);


            setQrStatus(
                'error',
                'QR GENERATION FAILED'
            );


            /*
            |--------------------------------------------------------------------------
            | Retry after 5 seconds
            |--------------------------------------------------------------------------
            */

            attendanceQrRefreshTimer =
                setTimeout(
                    generateNewAttendanceQr,
                    5000
                );
        }
    }


    /* COUNTDOWN */
    function startAttendanceQrCountdown() {
        clearInterval(attendanceQrTimer);
        updateAttendanceQrCountdown();

        attendanceQrTimer =
            setInterval(
                updateAttendanceQrCountdown,
                1000
            );
    }


    /* UPDATE COUNTDOWN  */
    function updateAttendanceQrCountdown() {

        if (!attendanceQrExpiresAt) {
            return;
        }


        const now =
            Date.now();


        const remaining =
            Math.max(
                0,
                attendanceQrExpiresAt - now
            );


        const totalSeconds =
            Math.floor(
                remaining / 1000
            );


        const minutes =
            Math.floor(
                totalSeconds / 60
            );


        const seconds =
            totalSeconds % 60;


        const formatted =
            String(minutes).padStart(2, '0')
            + ':' +
            String(seconds).padStart(2, '0');


        $('#qrCountdown')
            .text(formatted);


        /*
         * Progress percentage
         */
        const totalDuration =
            ATTENDANCE_QR_DURATION_SECONDS * 1000;


        const percentage =
            Math.max(
                0,
                Math.min(
                    100,
                    (remaining / totalDuration) * 100
                )
            );


        $('#qrProgressBar')
            .css(
                'width',
                percentage + '%'
            );


        /*
         * Warning states
         */
        $('#qrCountdown')
            .removeClass(
                'warning danger'
            );


        if (totalSeconds <= 60) {

            $('#qrCountdown')
                .addClass('danger');

        } else if (totalSeconds <= 180) {

            $('#qrCountdown')
                .addClass('warning');

        }


        /*
         * Expired
         */
        if (remaining <= 0) {

            handleAttendanceQrExpired();

        }

    }

    /* QR EXPIRED  */
    function handleAttendanceQrExpired() {

        clearInterval(
            attendanceQrTimer
        );


        $('#qrCountdown')
            .text('00:00')
            .addClass('danger');


        $('#qrExpiredOverlay')
            .css('display', 'flex');


        setQrStatus(
            'expired',
            'QR CODE REFRESHING'
        );


        /*
         * Small delay prevents visual flickering
         * and gives user feedback that QR changed.
         */
        attendanceQrRefreshTimer =
            setTimeout(
                generateNewAttendanceQr,
                1200
            );
    }


    /* STATUS  */
    function setQrStatus(
        status,
        text
    ) {

        const statusElement =
            $('#qrLiveStatus');


        $('#qrStatusText')
            .text(text);


        statusElement
            .removeClass(
                'qr-status-active qr-status-error'
            );


        if (status === 'active') {

            statusElement.css({
                'background': '#ecfdf3',
                'color': '#15803d',
                'border-color': '#bbf7d0'
            });

        } else if (status === 'expired') {

            statusElement.css({
                'background': '#fff7ed',
                'color': '#c2410c',
                'border-color': '#fed7aa'
            });

        } else {

            statusElement.css({
                'background': '#fef2f2',
                'color': '#b91c1c',
                'border-color': '#fecaca'
            });

        }

    }


    /* LOADING */
    function showQrLoading(show) {

        if (show) {

            $('#qrImage')
                .hide();

            $('#qrLoading')
                .css('display', 'flex');

        } else {

            $('#qrLoading')
                .hide();

            $('#qrImage')
                .show();

        }

    }


    /* RESET UI */
    function resetAttendanceQrUI() {

        $('#qrImage')
            .hide();


        $('#qrLoading')
            .css('display', 'flex');


        $('#qrExpiredOverlay')
            .hide();


        $('#qrCountdown')
            .removeClass(
                'warning danger'
            )
            .text('--:--');


        $('#qrProgressBar')
            .css(
                'width',
                '100%'
            );


        $('#qrDate')
            .text('--');


        $('#qrGeneratedAt')
            .text('--');


        $('#qrExpiresAt')
            .text('--');


        $('#download_qr_code_name')
            .val('');


        setQrStatus(
            'active',
            'GENERATING SECURE QR'
        );

    }


    /* COPY LINK */
    async function copyAttendanceQrLink() {

        const input =
            document.getElementById(
                'download_qr_code_name'
            );


        if (!input.value) {

            toastr.warning(
                'QR link is not available'
            );

            return;
        }


        try {

            await navigator.clipboard.writeText(
                input.value
            );


            toastr.success(
                'Attendance link copied'
            );


        } catch (error) {

            /*
             * Fallback
             */
            input.select();

            document.execCommand(
                'copy'
            );


            toastr.success(
                'Attendance link copied'
            );

        }

    }


    /* CLEAR TIMERS  */
    function clearAttendanceQrTimers() {

        if (attendanceQrTimer) {

            clearInterval(
                attendanceQrTimer
            );

            attendanceQrTimer = null;
        }


        if (attendanceQrRefreshTimer) {

            clearTimeout(
                attendanceQrRefreshTimer
            );

            attendanceQrRefreshTimer = null;
        }

    }


    /** MODAL CLOSED */
    $('#kt_modal_qr_generate')
        .on(
            'hidden.bs.modal',
            function () {

                clearAttendanceQrTimers();

                attendanceQrExpiresAt = null;
                attendanceQrGeneratedAt = null;

            }
        );


  
    document.addEventListener(
        'visibilitychange',
        function () {

            if (
                document.visibilityState === 'visible' &&
                $('#kt_modal_qr_generate').hasClass('show')
            ) {

                if (
                    !attendanceQrExpiresAt ||
                    Date.now() >= attendanceQrExpiresAt
                ) {

                    generateNewAttendanceQr();

                }

            }

        }
    );

generateQr();
</script>
@endsection