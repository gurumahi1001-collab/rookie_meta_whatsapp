@extends('layouts/blankLayout')

@section('title', 'Daily Attendance')

@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">


<style>
    :root {
        --brand-dark: #7f1d1d;
        --brand: #b52b25;
        --brand-light: #dc4a2f;
        --brand-accent: #f5a623;

        --bg: #f5f7fb;
        --surface: #ffffff;

        --text-primary: #172033;
        --text-secondary: #667085;
        --text-muted: #98a2b3;

        --border: #e7eaf0;

        --success: #16a34a;
        --success-bg: #ecfdf3;
        --success-border: #bbf7d0;

        --warning: #d97706;
        --danger: #dc2626;
    }

    html,
    body {
        width: 100%;
        height: 100%;
        margin: 0;
        overflow: hidden !important;
        background: var(--bg);
    }

    body {
        overscroll-behavior: none;
    }

    .attendance-display {
        width: 100%;
        height: 100vh;
        height: 100dvh;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        position: relative;
        background:
            radial-gradient(
                circle at 8% 5%,
                rgba(181, 43, 37, 0.07),
                transparent 24%
            ),
            radial-gradient(
                circle at 95% 90%,
                rgba(245, 166, 35, 0.08),
                transparent 25%
            ),
            #f6f8fc;
    }

    /* =========================================================
       TOP BRAND BAR
    ========================================================= */

    .attendance-topbar {
        height: clamp(68px, 8vh, 92px);
        min-height: clamp(68px, 8vh, 92px);

        display: flex;
        align-items: center;
        justify-content: space-between;

        padding: 0 clamp(22px, 3vw, 52px);

        color: #ffffff;

        background:
            linear-gradient(
                120deg,
                #7f1d1d 0%,
                #a82420 35%,
                #c93426 67%,
                #e66b25 100%
            );

        position: relative;
        overflow: hidden;

        box-shadow: 0 6px 24px rgba(127, 29, 29, 0.16);

        z-index: 10;
    }

    .attendance-topbar::before {
        content: "";
        position: absolute;

        width: 300px;
        height: 300px;

        border-radius: 50%;

        background: rgba(255, 255, 255, 0.055);

        top: -210px;
        right: 20%;
    }

    .attendance-topbar::after {
        content: "";
        position: absolute;

        width: 220px;
        height: 220px;

        border-radius: 50%;

        background: rgba(255, 255, 255, 0.045);

        right: -70px;
        bottom: -160px;
    }

    .topbar-brand,
    .topbar-clock {
        position: relative;
        z-index: 2;
    }

    .topbar-brand {
        display: flex;
        align-items: center;
        gap: clamp(11px, 1.2vw, 18px);
        min-width: 0;
    }

    .brand-icon {
        width: clamp(42px, 3.7vw, 56px);
        height: clamp(42px, 3.7vw, 56px);

        flex: 0 0 auto;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 15px;

        background: rgba(255, 255, 255, 0.15);

        border: 1px solid rgba(255, 255, 255, 0.14);

        box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.15),
            0 5px 15px rgba(71, 13, 13, 0.12);

        backdrop-filter: blur(10px);

        font-size: clamp(22px, 2vw, 30px);
    }

    .brand-title {
        margin: 0;

        color: #ffffff;

        font-size: clamp(18px, 1.65vw, 27px);
        font-weight: 800;

        letter-spacing: -0.35px;

        line-height: 1.1;
    }

    .brand-subtitle {
        margin-top: 4px;

        font-size: clamp(10px, 0.82vw, 13px);
        font-weight: 500;

        color: rgba(255, 255, 255, 0.78);

        letter-spacing: 0.1px;
    }

    .topbar-clock {
        display: flex;
        align-items: center;
        gap: clamp(12px, 1.3vw, 20px);
    }

    .clock-date {
        text-align: right;
    }

    .clock-day {
        font-size: clamp(10px, 0.8vw, 12px);
        font-weight: 600;

        color: rgba(255, 255, 255, 0.75);

        text-transform: uppercase;
        letter-spacing: 0.7px;
    }

    .clock-full-date {
        margin-top: 2px;

        font-size: clamp(12px, 1vw, 15px);
        font-weight: 700;

        white-space: nowrap;
    }

    .clock-time {
        min-width: clamp(110px, 9vw, 145px);

        text-align: center;

        padding: 9px 15px;

        border-radius: 13px;

        background: rgba(255, 255, 255, 0.13);

        border: 1px solid rgba(255, 255, 255, 0.12);

        backdrop-filter: blur(10px);

        font-size: clamp(17px, 1.5vw, 23px);
        font-weight: 800;

        font-variant-numeric: tabular-nums;

        white-space: nowrap;
    }

    /* =========================================================
       MAIN SCREEN
    ========================================================= */

    .attendance-main {
        flex: 1;
        min-height: 0;

        display: grid;

        grid-template-columns:
            minmax(300px, 0.88fr)
            minmax(380px, 1.12fr);

        gap: clamp(18px, 2.2vw, 38px);

        width: min(1500px, 100%);

        margin: 0 auto;

        padding:
            clamp(18px, 2.2vh, 32px)
            clamp(22px, 3vw, 52px);

        align-items: center;
    }

    /* =========================================================
       LEFT CONTENT
    ========================================================= */

    .attendance-info {
        min-width: 0;

        display: flex;
        flex-direction: column;
        justify-content: center;

        padding-right: clamp(0px, 1vw, 16px);
    }

    .attendance-eyebrow {
        display: inline-flex;
        align-items: center;

        width: fit-content;

        gap: 7px;

        padding: 6px 11px;

        border-radius: 30px;

        background: #fff1f0;
        border: 1px solid #ffd9d6;

        color: var(--brand);

        font-size: clamp(9px, 0.75vw, 11px);
        font-weight: 800;

        letter-spacing: 0.7px;
        text-transform: uppercase;

        margin-bottom: clamp(10px, 1.5vh, 18px);
    }

    .attendance-eyebrow-dot {
        width: 7px;
        height: 7px;

        border-radius: 50%;

        background: var(--brand);

        box-shadow: 0 0 0 4px rgba(181, 43, 37, 0.10);
    }

    .attendance-heading {
        margin: 0;

        max-width: 620px;

        font-size: clamp(30px, 3.1vw, 53px);
        font-weight: 850;

        line-height: 1.06;

        letter-spacing: -1.5px;

        color: var(--text-primary);
    }

    .attendance-heading span {
        color: var(--brand);
    }

    .attendance-description {
        max-width: 570px;

        margin:
            clamp(11px, 1.6vh, 20px)
            0
            0;

        color: var(--text-secondary);

        font-size: clamp(12px, 1.05vw, 16px);

        line-height: 1.65;
    }

    /* Steps */

    .attendance-steps {
        margin-top: clamp(18px, 2.5vh, 30px);

        display: grid;

        gap: clamp(8px, 1vh, 12px);

        max-width: 590px;
    }

    .attendance-step {
        display: flex;
        align-items: center;

        gap: clamp(10px, 1vw, 14px);

        padding:
            clamp(9px, 1vh, 13px)
            clamp(11px, 1.1vw, 16px);

        background: rgba(255, 255, 255, 0.82);

        border: 1px solid var(--border);

        border-radius: 14px;

        box-shadow: 0 3px 12px rgba(15, 23, 42, 0.025);
    }

    .step-number {
        width: clamp(31px, 2.5vw, 39px);
        height: clamp(31px, 2.5vw, 39px);

        min-width: clamp(31px, 2.5vw, 39px);

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 11px;

        background: #fff1f0;

        color: var(--brand);

        font-size: clamp(12px, 1vw, 15px);
        font-weight: 800;
    }

    .step-title {
        color: #344054;

        font-size: clamp(11px, 0.92vw, 14px);
        font-weight: 750;
    }

    .step-text {
        margin-top: 1px;

        color: var(--text-muted);

        font-size: clamp(9px, 0.72vw, 11px);
    }

    /* =========================================================
       QR PANEL
    ========================================================= */

    .qr-panel {
        min-width: 0;

        height: 100%;

        max-height: 690px;

        display: flex;
        flex-direction: column;

        justify-content: center;

        background: rgba(255, 255, 255, 0.92);

        border: 1px solid rgba(225, 228, 235, 0.95);

        border-radius: clamp(20px, 1.7vw, 28px);

        padding:
            clamp(16px, 1.8vh, 24px)
            clamp(18px, 2vw, 30px);

        box-shadow:
            0 20px 55px rgba(15, 23, 42, 0.07),
            0 3px 12px rgba(15, 23, 42, 0.03);

        position: relative;
        overflow: hidden;
    }

    .qr-panel::before {
        content: "";

        position: absolute;

        width: 200px;
        height: 200px;

        border-radius: 50%;

        background: rgba(181, 43, 37, 0.035);

        right: -100px;
        top: -100px;
    }

    .qr-panel-header {
        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 15px;

        position: relative;
        z-index: 2;

        margin-bottom: clamp(8px, 1.1vh, 13px);
    }

    .qr-panel-title {
        font-size: clamp(14px, 1.2vw, 18px);
        font-weight: 800;

        color: var(--text-primary);
    }

    .qr-panel-subtitle {
        margin-top: 2px;

        font-size: clamp(9px, 0.72vw, 11px);

        color: var(--text-muted);
    }

    /* Live Status */

    .qr-live-status {
        flex: 0 0 auto;

        display: inline-flex;
        align-items: center;

        gap: 7px;

        padding: 7px 11px;

        border-radius: 30px;

        background: var(--success-bg);
        color: #15803d;

        border: 1px solid var(--success-border);

        font-size: clamp(8px, 0.68vw, 10px);
        font-weight: 800;

        letter-spacing: 0.3px;

        white-space: nowrap;
    }

    .qr-live-dot {
        width: 7px;
        height: 7px;

        border-radius: 50%;

        background: var(--success);

        animation: qrPulse 1.5s infinite;
    }

    @keyframes qrPulse {
        0% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.45);
        }

        70% {
            box-shadow: 0 0 0 6px rgba(22, 163, 74, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0);
        }
    }

    /* QR Area */

    .qr-area {
        display: flex;
        justify-content: center;
        align-items: center;

        flex: 1;
        min-height: 0;

        position: relative;
        z-index: 2;
    }

    .qr-card {
        position: relative;

        padding: clamp(10px, 1vw, 15px);

        background: #ffffff;

        border: 1px solid #e4e7ec;

        border-radius: clamp(17px, 1.5vw, 23px);

        box-shadow:
            0 15px 35px rgba(15, 23, 42, 0.08),
            0 2px 6px rgba(15, 23, 42, 0.04);
    }

    .qr-card::before {
        content: "";

        position: absolute;
        inset: -5px;

        border-radius: calc(clamp(17px, 1.5vw, 23px) + 5px);

        border: 2px solid rgba(181, 43, 37, 0.07);

        pointer-events: none;
    }

    .qr-image-container {
        /*
         * Critical:
         * QR automatically adapts to screen height + width.
         */
        width: min(36vh, 28vw, 370px);
        height: min(36vh, 28vw, 370px);

        min-width: 190px;
        min-height: 190px;

        display: flex;
        align-items: center;
        justify-content: center;

        background: #ffffff;

        border-radius: 14px;

        overflow: hidden;
    }

    .qr-image {
        width: 94%;
        height: 94%;

        object-fit: contain;

        display: block;
    }

    /* Loading */

    .qr-loading {
        display: none;

        position: absolute;
        inset: 0;

        align-items: center;
        justify-content: center;

        flex-direction: column;

        gap: 10px;

        background: #ffffff;

        border-radius: 14px;

        z-index: 4;
    }

    .qr-loading-spinner {
        width: clamp(35px, 3vw, 45px);
        height: clamp(35px, 3vw, 45px);

        border: 4px solid #edf0f3;
        border-top-color: var(--brand);

        border-radius: 50%;

        animation: qrSpin 0.75s linear infinite;
    }

    @keyframes qrSpin {
        to {
            transform: rotate(360deg);
        }
    }

    .qr-loading-text {
        font-size: clamp(9px, 0.75vw, 11px);
        color: var(--text-muted);
        font-weight: 600;
    }

    /* Expired */

    .qr-expired-overlay {
        display: none;

        position: absolute;
        inset: clamp(10px, 1vw, 15px);

        align-items: center;
        justify-content: center;

        flex-direction: column;

        text-align: center;

        background: rgba(255, 255, 255, 0.97);

        border-radius: 14px;

        z-index: 6;
    }

    .qr-expired-icon {
        width: 52px;
        height: 52px;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 50%;

        background: #fee2e2;

        color: var(--danger);

        font-size: 25px;

        margin-bottom: 10px;
    }

    .qr-expired-title {
        color: #991b1b;

        font-size: 14px;
        font-weight: 800;
    }

    .qr-expired-text {
        margin-top: 3px;

        color: var(--text-muted);

        font-size: 10px;
    }

    /* Countdown */

    .qr-timer-section {
        margin-top: clamp(8px, 1vh, 13px);

        position: relative;
        z-index: 2;
    }

    .qr-timer-row {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;

        gap: 15px;
    }

    .qr-timer-label {
        color: var(--text-muted);

        font-size: clamp(8px, 0.67vw, 10px);
        font-weight: 700;

        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .qr-countdown {
        color: var(--text-primary);

        font-size: clamp(20px, 2vw, 29px);
        font-weight: 850;

        line-height: 1;

        font-variant-numeric: tabular-nums;
        letter-spacing: 0.5px;
    }

    .qr-countdown.warning {
        color: var(--warning);
    }

    .qr-countdown.danger {
        color: var(--danger);
    }

    .qr-progress {
        width: 100%;
        height: 5px;

        margin-top: 7px;

        border-radius: 20px;

        background: #edf0f3;

        overflow: hidden;
    }

    .qr-progress-bar {
        width: 100%;
        height: 100%;

        border-radius: 20px;

        background: linear-gradient(
            90deg,
            #16a34a,
            #22c55e
        );

        transition: width 1s linear;
    }

    /* Details */

    .qr-meta {
        display: grid;

        grid-template-columns: repeat(3, 1fr);

        gap: clamp(6px, 0.7vw, 9px);

        margin-top: clamp(9px, 1.2vh, 14px);

        position: relative;
        z-index: 2;
    }

    .qr-meta-item {
        min-width: 0;

        padding:
            clamp(7px, 0.8vh, 10px)
            clamp(8px, 0.8vw, 11px);

        border-radius: 10px;

        background: #f8fafc;

        border: 1px solid #edf0f3;
    }

    .qr-meta-label {
        color: var(--text-muted);

        font-size: clamp(7px, 0.58vw, 9px);
        font-weight: 700;

        text-transform: uppercase;
        letter-spacing: 0.45px;
    }

    .qr-meta-value {
        margin-top: 2px;

        color: #344054;

        font-size: clamp(9px, 0.76vw, 11px);
        font-weight: 750;

        white-space: nowrap;

        overflow: hidden;
        text-overflow: ellipsis;
    }

    /* Security */

    .qr-security {
        display: flex;
        align-items: center;
        justify-content: center;

        gap: 5px;

        margin-top: clamp(8px, 1vh, 12px);

        color: var(--text-muted);

        font-size: clamp(8px, 0.67vw, 10px);

        position: relative;
        z-index: 2;
    }

    .qr-security i {
        color: var(--success);

        font-size: 14px;
    }

    /* =========================================================
       FOOTER
    ========================================================= */

    .attendance-footer {
        height: clamp(34px, 4.2vh, 48px);
        min-height: clamp(34px, 4.2vh, 48px);

        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 20px;

        padding: 0 clamp(22px, 3vw, 52px);

        border-top: 1px solid #e8ebf0;

        background: rgba(255, 255, 255, 0.72);

        color: var(--text-muted);

        font-size: clamp(8px, 0.67vw, 10px);
    }

    .footer-security {
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .footer-security i {
        color: var(--success);
    }

    .footer-help {
        white-space: nowrap;
    }

   /* =========================================================
   GLOBAL RESPONSIVE FOUNDATION
========================================================= */

html {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden !important;
}

html,
body,
.attendance-display,
.attendance-display *,
.attendance-display *::before,
.attendance-display *::after {
    box-sizing: border-box;
}

body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden !important;
}


/* =========================================================
   RESPONSIVE ATTENDANCE DISPLAY
   Designed for:
   320px mobile
   360px mobile
   390px mobile
   480px mobile
   600px tablet
   768px tablet
   800px tablet
   1024px
   1280x720
   1280x800
   1366x768
   1440x900
   1920x1080
   2K / 4K
========================================================= */


/* =========================================================
   BASE
========================================================= */

.attendance-display {
    width: 100%;
    height: 100dvh;
    min-height: 0;

    display: flex;
    flex-direction: column;

    overflow: hidden !important;
}


/* =========================================================
   HEADER
========================================================= */

.attendance-topbar {
    flex: 0 0 clamp(56px, 8vh, 88px);

    width: 100%;
    min-width: 0;

    padding-left: clamp(10px, 3vw, 48px);
    padding-right: clamp(10px, 3vw, 48px);

    display: flex;
    align-items: center;
    justify-content: space-between;

    overflow: hidden;
}

.topbar-brand,
.topbar-clock {
    min-width: 0;
}

.topbar-brand {
    gap: clamp(8px, 1.2vw, 18px);
}

.brand-icon {
    width: clamp(34px, 3.6vw, 54px);
    height: clamp(34px, 3.6vw, 54px);

    min-width: 34px;
    min-height: 34px;

    border-radius: clamp(9px, 1vw, 15px);

    font-size: clamp(17px, 1.8vw, 28px);
}

.brand-title {
    font-size: clamp(14px, 1.55vw, 25px);

    white-space: nowrap;
}

.brand-subtitle {
    font-size: clamp(8px, 0.75vw, 12px);

    white-space: nowrap;
}

.topbar-clock {
    gap: clamp(6px, 1vw, 18px);
}

.clock-day {
    font-size: clamp(8px, 0.75vw, 12px);
}

.clock-full-date {
    font-size: clamp(9px, 0.9vw, 14px);
}

.clock-time {
    min-width: clamp(82px, 8vw, 140px);

    padding: clamp(5px, 0.8vh, 10px)
             clamp(7px, 1vw, 15px);

    font-size: clamp(11px, 1.4vw, 22px);
}


/* =========================================================
   MAIN
========================================================= */

.attendance-main {
    flex: 1 1 auto;

    width: 100%;
    max-width: 1800px;

    min-width: 0;
    min-height: 0;

    margin: 0 auto;

    display: grid;

    grid-template-columns:
        minmax(0, 0.88fr)
        minmax(0, 1.12fr);

    gap: clamp(10px, 2vw, 36px);

    padding:
        clamp(8px, 2vh, 28px)
        clamp(10px, 3vw, 48px);

    align-items: stretch;

    overflow: hidden;
}


/* =========================================================
   LEFT INFORMATION
========================================================= */

.attendance-info {
    min-width: 0;
    min-height: 0;

    display: flex;
    flex-direction: column;
    justify-content: center;

    padding: 0;

    overflow: hidden;
}

.attendance-eyebrow {
    margin-bottom: clamp(7px, 1.5vh, 17px);

    padding:
        clamp(4px, 0.7vh, 6px)
        clamp(7px, 0.8vw, 11px);

    font-size: clamp(7px, 0.7vw, 11px);
}

.attendance-heading {
    width: 100%;
    max-width: 620px;

    margin: 0;

    font-size:
        clamp(24px, 3.2vw, 54px);

    line-height: 1.05;

    letter-spacing: clamp(-1px, -0.08vw, -1.5px);

    overflow-wrap: break-word;
}

.attendance-description {
    width: 100%;
    max-width: 570px;

    margin-top: clamp(7px, 1.5vh, 18px);

    font-size: clamp(9px, 0.95vw, 15px);

    line-height: 1.5;
}

.attendance-steps {
    width: 100%;
    max-width: 590px;

    margin-top: clamp(10px, 2vh, 25px);

    gap: clamp(5px, 0.9vh, 11px);
}

.attendance-step {
    min-width: 0;

    padding:
        clamp(6px, 1vh, 12px)
        clamp(7px, 1vw, 15px);

    gap: clamp(7px, 0.9vw, 13px);

    border-radius: clamp(9px, 1vw, 14px);
}

.step-number {
    width: clamp(26px, 2.5vw, 39px);
    height: clamp(26px, 2.5vw, 39px);

    min-width: clamp(26px, 2.5vw, 39px);

    font-size: clamp(9px, 0.9vw, 15px);
}

.step-title {
    font-size: clamp(8px, 0.85vw, 14px);
}

.step-text {
    font-size: clamp(7px, 0.65vw, 11px);
}


/* =========================================================
   QR PANEL
========================================================= */

.qr-panel {
    width: 100%;
    min-width: 0;
    min-height: 0;

    height: auto;
    max-height: none;

    align-self: stretch;

    padding:
        clamp(8px, 1.8vh, 24px)
        clamp(9px, 1.8vw, 28px);

    border-radius:
        clamp(14px, 1.6vw, 26px);

    display: flex;
    flex-direction: column;

    overflow: hidden;
}


/* =========================================================
   QR HEADER
========================================================= */

.qr-panel-header {
    width: 100%;
    min-width: 0;

    flex: 0 0 auto;

    margin-bottom: clamp(4px, 1vh, 12px);

    gap: 8px;
}

.qr-panel-title {
    font-size: clamp(11px, 1.15vw, 19px);
}

.qr-panel-subtitle {
    font-size: clamp(7px, 0.65vw, 11px);
}

.qr-live-status {
    padding:
        clamp(4px, 0.7vh, 7px)
        clamp(6px, 0.8vw, 11px);

    gap: 5px;

    font-size: clamp(6px, 0.62vw, 10px);
}

.qr-live-dot {
    width: clamp(5px, 0.45vw, 7px);
    height: clamp(5px, 0.45vw, 7px);
}


/* =========================================================
   QR AREA
========================================================= */

.qr-area {
    flex: 1 1 auto;

    min-width: 0;
    min-height: 0;

    width: 100%;

    display: flex;

    align-items: center;
    justify-content: center;

    overflow: hidden;
}

.qr-card {
    max-width: 100%;
    max-height: 100%;

    padding: clamp(5px, 1vw, 14px);

    flex: 0 1 auto;

    display: flex;
    align-items: center;
    justify-content: center;
}

.qr-image-container {
    /*
     * IMPORTANT:
     * Never allow QR to determine panel width.
     * QR is limited by BOTH available width and height.
     */
    width: min(
        42vh,
        30vw,
        460px
    );

    height: min(
        42vh,
        30vw,
        460px
    );

    min-width: 0;
    min-height: 0;

    max-width: 100%;
    max-height: 100%;

    aspect-ratio: 1 / 1;

    display: flex;
    align-items: center;
    justify-content: center;

    overflow: hidden;
}

.qr-image {
    width: 94%;
    height: 94%;

    max-width: 100%;
    max-height: 100%;

    object-fit: contain;
}


/* =========================================================
   TIMER
========================================================= */

.qr-timer-section {
    flex: 0 0 auto;

    width: 100%;

    margin-top: clamp(4px, 0.9vh, 12px);
}

.qr-timer-row {
    gap: 8px;
}

.qr-timer-label {
    font-size: clamp(6px, 0.62vw, 10px);
}

.qr-countdown {
    font-size: clamp(16px, 1.9vw, 30px);
}

.qr-progress {
    height: clamp(3px, 0.5vh, 5px);

    margin-top: clamp(3px, 0.6vh, 7px);
}


/* =========================================================
   META
========================================================= */

.qr-meta {
    flex: 0 0 auto;

    width: 100%;

    gap: clamp(3px, 0.7vw, 9px);

    margin-top: clamp(4px, 1vh, 13px);
}

.qr-meta-item {
    min-width: 0;

    padding:
        clamp(4px, 0.8vh, 10px)
        clamp(5px, 0.7vw, 11px);

    border-radius: clamp(6px, 0.7vw, 10px);
}

.qr-meta-label {
    font-size: clamp(5px, 0.55vw, 9px);
}

.qr-meta-value {
    margin-top: 2px;

    font-size: clamp(7px, 0.72vw, 11px);
}


/* =========================================================
   SECURITY
========================================================= */

.qr-security {
    flex: 0 0 auto;

    margin-top: clamp(4px, 0.8vh, 11px);

    font-size: clamp(6px, 0.62vw, 10px);
}

.qr-security i {
    font-size: clamp(10px, 1vw, 14px);
}


/* =========================================================
   FOOTER
========================================================= */

.attendance-footer {
    flex: 0 0 clamp(25px, 4vh, 46px);

    width: 100%;
    min-width: 0;

    padding-left: clamp(8px, 3vw, 48px);
    padding-right: clamp(8px, 3vw, 48px);

    font-size: clamp(6px, 0.65vw, 10px);

    overflow: hidden;
}

.footer-help,
.footer-security {
    min-width: 0;
}

.footer-help {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


/* =========================================================
   1280 × 800 / 1366 × 768 / 1440 × 900
   THIS FIXES YOUR SCREENSHOT
========================================================= */

@media (min-width: 1000px) and
       (max-width: 1599.98px) {

    .attendance-main {
        grid-template-columns:
            minmax(0, 0.82fr)
            minmax(0, 1.18fr);

        gap: clamp(12px, 1.6vw, 24px);

        padding-left: clamp(16px, 2.5vw, 36px);
        padding-right: clamp(16px, 2.5vw, 36px);

        padding-top: clamp(8px, 1.6vh, 18px);
        padding-bottom: clamp(8px, 1.6vh, 18px);
    }

    .attendance-heading {
        font-size: clamp(27px, 3.1vw, 44px);
    }

    .attendance-description {
        font-size: clamp(9px, 0.85vw, 13px);
        line-height: 1.45;
    }

    .attendance-steps {
        margin-top: clamp(10px, 1.8vh, 18px);
    }

    .attendance-step {
        padding: clamp(6px, 0.9vh, 9px) 10px;
    }

    .qr-panel {
        padding:
            clamp(8px, 1.5vh, 16px)
            clamp(10px, 1.5vw, 20px);
    }

    .qr-image-container {
        width: min(
            40vh,
            29vw,
            370px
        );

        height: min(
            40vh,
            29vw,
            370px
        );
    }
}


/* =========================================================
   SHORT DESKTOP / TABLET LANDSCAPE
   800×600
   1024×600
   1280×720
   1366×768
========================================================= */

@media (orientation: landscape)
       and (max-height: 800px) {

    .attendance-topbar {
        flex-basis: clamp(50px, 8vh, 68px);
    }

    .attendance-main {
        padding-top: clamp(5px, 1.2vh, 12px);
        padding-bottom: clamp(5px, 1.2vh, 12px);

        gap: clamp(8px, 1.4vw, 18px);
    }

    .attendance-heading {
        font-size: clamp(24px, 3vw, 39px);
    }

    .attendance-description {
        margin-top: 7px;

        font-size: clamp(8px, 0.78vw, 11px);

        line-height: 1.4;
    }

    .attendance-steps {
        margin-top: 9px;
        gap: 5px;
    }

    .attendance-step {
        padding: 5px 8px;
    }

    .step-number {
        width: 28px;
        height: 28px;
        min-width: 28px;
    }

    .step-text {
        font-size: 7px;
    }

    .qr-panel {
        padding: 7px 10px;
    }

    .qr-image-container {
        width: min(
            38vh,
            28vw,
            320px
        );

        height: min(
            38vh,
            28vw,
            320px
        );
    }

    .qr-meta {
        margin-top: 5px;
    }

    .qr-meta-item {
        padding: 5px 7px;
    }

    .attendance-footer {
        flex-basis: 25px;
    }
}


/* =========================================================
   1280 × 800 SPECIFIC
   Prevent horizontal overflow
========================================================= */

@media (min-width: 1100px)
       and (max-width: 1400px)
       and (min-height: 700px)
       and (max-height: 850px) {

    .attendance-main {
        width: 100%;
        max-width: 1400px;

        grid-template-columns:
            minmax(0, 0.82fr)
            minmax(0, 1.18fr);

        padding-left: 28px;
        padding-right: 28px;

        gap: 18px;
    }

    .qr-panel {
        width: 100%;
        min-width: 0;
    }

    .qr-image-container {
        width: min(
            39vh,
            28vw,
            350px
        );

        height: min(
            39vh,
            28vw,
            350px
        );
    }

    .qr-countdown {
        font-size: 24px;
    }
}


/* =========================================================
   TABLET LANDSCAPE
   768 × 600
   800 × 600
   1024 × 768
========================================================= */

@media (orientation: landscape)
       and (min-width: 768px)
       and (max-width: 1099.98px) {

    .attendance-main {
        grid-template-columns:
            minmax(0, 0.78fr)
            minmax(0, 1.22fr);

        gap: 10px;

        padding:
            8px
            14px;
    }

    .attendance-topbar {
        flex-basis: 58px;

        padding-left: 14px;
        padding-right: 14px;
    }

    .brand-icon {
        width: 36px;
        height: 36px;

        font-size: 18px;
    }

    .brand-title {
        font-size: 15px;
    }

    .brand-subtitle {
        display: none;
    }

    .clock-day {
        display: none;
    }

    .clock-full-date {
        font-size: 10px;
    }

    .clock-time {
        min-width: 92px;

        padding: 6px 8px;

        font-size: 13px;
    }

    .attendance-heading {
        font-size: clamp(22px, 3.4vw, 34px);
    }

    .attendance-description {
        font-size: 9px;

        line-height: 1.4;
    }

    .attendance-steps {
        margin-top: 8px;

        gap: 5px;
    }

    .attendance-step {
        padding: 5px 7px;
    }

    .step-number {
        width: 27px;
        height: 27px;
        min-width: 27px;
    }

    .step-title {
        font-size: 9px;
    }

    .step-text {
        display: none;
    }

    .qr-panel {
        padding: 7px 10px;

        border-radius: 16px;
    }

    .qr-panel-subtitle {
        display: none;
    }

    .qr-image-container {
        width: min(
            40vh,
            31vw,
            300px
        );

        height: min(
            40vh,
            31vw,
            300px
        );
    }

    .qr-countdown {
        font-size: 19px;
    }

    .qr-meta-item {
        padding: 5px 6px;
    }

    .attendance-footer {
        display: none;
    }
}


/* =========================================================
   PORTRAIT TABLET
   768×1024
   800×1280
   834×1194
========================================================= */

@media (orientation: portrait)
       and (min-width: 768px) {

    .attendance-topbar {
        flex-basis: 68px;

        padding-left: 18px;
        padding-right: 18px;
    }

    .brand-icon {
        width: 40px;
        height: 40px;
    }

    .brand-title {
        font-size: 17px;
    }

    .brand-subtitle {
        display: none;
    }

    .clock-date {
        display: none;
    }

    .attendance-main {
        grid-template-columns: 1fr;

        grid-template-rows:
            auto
            minmax(0, 1fr);

        gap: 10px;

        padding:
            12px
            18px;
    }

    .attendance-info {
        align-items: center;

        text-align: center;

        overflow: hidden;
    }

    .attendance-eyebrow {
        margin-left: auto;
        margin-right: auto;
    }

    .attendance-heading {
        max-width: 700px;

        font-size: clamp(
            25px,
            4.5vw,
            42px
        );
    }

    .attendance-description {
        max-width: 650px;

        margin-left: auto;
        margin-right: auto;

        font-size: 11px;
    }

    .attendance-steps {
        width: min(680px, 100%);

        grid-template-columns: repeat(3, minmax(0, 1fr));

        margin-top: 10px;
    }

    .attendance-step {
        min-width: 0;

        padding: 7px;
    }

    .step-text {
        display: none;
    }

    .qr-panel {
        width: min(650px, 100%);

        margin: 0 auto;

        min-height: 0;

        padding: 10px 14px;
    }

    .qr-image-container {
        width: min(
            36vh,
            48vw,
            360px
        );

        height: min(
            36vh,
            48vw,
            360px
        );
    }

    .attendance-footer {
        flex-basis: 30px;

        justify-content: center;
    }

    .footer-help {
        display: none;
    }
}


/* =========================================================
   SMALL PORTRAIT TABLET
   600×800
   600×960
========================================================= */

@media (orientation: portrait)
       and (min-width: 600px)
       and (max-width: 767.98px) {

    .attendance-topbar {
        flex-basis: 60px;

        padding: 0 14px;
    }

    .brand-icon {
        width: 36px;
        height: 36px;

        font-size: 18px;
    }

    .brand-title {
        font-size: 15px;
    }

    .brand-subtitle,
    .clock-date {
        display: none;
    }

    .attendance-main {
        grid-template-columns: 1fr;

        grid-template-rows:
            auto
            minmax(0, 1fr);

        gap: 7px;

        padding: 8px 12px;
    }

    .attendance-info {
        align-items: center;

        text-align: center;
    }

    .attendance-eyebrow {
        display: none;
    }

    .attendance-heading {
        font-size: clamp(
            21px,
            5vw,
            29px
        );
    }

    .attendance-description {
        max-width: 550px;

        margin-top: 5px;

        font-size: 9px;

        line-height: 1.35;
    }

    .attendance-steps {
        display: none;
    }

    .qr-panel {
        width: min(570px, 100%);

        margin: 0 auto;

        padding: 8px 11px;
    }

    .qr-panel-subtitle {
        display: none;
    }

    .qr-image-container {
        width: min(
            38vh,
            65vw,
            320px
        );

        height: min(
            38vh,
            65vw,
            320px
        );
    }

    .attendance-footer {
        display: none;
    }
}


/* =========================================================
   MOBILE PORTRAIT
   400 - 599
========================================================= */

@media (orientation: portrait)
       and (min-width: 400px)
       and (max-width: 599.98px) {

    .attendance-topbar {
        flex-basis: 56px;

        padding: 0 9px;
    }

    .brand-icon {
        width: 32px;
        height: 32px;

        font-size: 16px;
    }

    .brand-title {
        font-size: 13px;
    }

    .brand-subtitle,
    .clock-date {
        display: none;
    }

    .clock-time {
        min-width: 78px;

        padding: 5px 7px;

        font-size: 11px;
    }

    .attendance-main {
        grid-template-columns: 1fr;

        grid-template-rows:
            auto
            minmax(0, 1fr);

        gap: 5px;

        padding: 6px 7px;
    }

    .attendance-info {
        align-items: center;

        text-align: center;
    }

    .attendance-eyebrow,
    .attendance-description,
    .attendance-steps {
        display: none;
    }

    .attendance-heading {
        font-size: clamp(
            18px,
            5.5vw,
            24px
        );
    }

    .qr-panel {
        width: 100%;

        padding: 7px 8px;

        border-radius: 14px;
    }

    .qr-panel-subtitle {
        display: none;
    }

    .qr-panel-title {
        font-size: 11px;
    }

    .qr-live-status {
        padding: 4px 6px;

        font-size: 6px;
    }

    .qr-image-container {
        width: min(
            40vh,
            76vw,
            300px
        );

        height: min(
            40vh,
            76vw,
            300px
        );
    }

    .qr-countdown {
        font-size: 18px;
    }

    .qr-meta {
        gap: 3px;
    }

    .qr-meta-item {
        padding: 4px 5px;
    }

    .qr-meta-label {
        font-size: 5px;
    }

    .qr-meta-value {
        font-size: 7px;
    }

    .qr-security {
        font-size: 6px;
    }

    .attendance-footer {
        display: none;
    }
}


/* =========================================================
   SMALL MOBILE
   <=399
========================================================= */

@media (orientation: portrait)
       and (max-width: 399.98px) {

    .attendance-topbar {
        flex-basis: 52px;

        padding: 0 7px;
    }

    .brand-icon {
        width: 29px;
        height: 29px;

        border-radius: 8px;

        font-size: 15px;
    }

    .brand-title {
        font-size: 12px;
    }

    .brand-subtitle,
    .clock-date {
        display: none;
    }

    .clock-time {
        min-width: 70px;

        padding: 4px 6px;

        font-size: 10px;
    }

    .attendance-main {
        padding: 5px;

        gap: 4px;
    }

    .attendance-heading {
        font-size: 17px;
    }

    .qr-panel {
        padding: 6px;

        border-radius: 12px;
    }

    .qr-panel-title {
        font-size: 10px;
    }

    .qr-live-status {
        padding: 3px 5px;

        font-size: 5px;
    }

    .qr-image-container {
        width: min(
            39vh,
            78vw,
            270px
        );

        height: min(
            39vh,
            78vw,
            270px
        );
    }

    .qr-countdown {
        font-size: 16px;
    }

    .qr-progress {
        height: 3px;
    }

    .qr-meta {
        gap: 2px;
        margin-top: 3px;
    }

    .qr-meta-item {
        padding: 3px;
    }

    .qr-meta-label {
        font-size: 4px;
    }

    .qr-meta-value {
        font-size: 6px;
    }

    .qr-security {
        display: none;
    }

    .attendance-footer {
        display: none;
    }
}


/* =========================================================
   LANDSCAPE MOBILE
   568×320
   667×375
   844×390
========================================================= */

@media (orientation: landscape)
       and (max-width: 900px)
       and (max-height: 550px) {

    .attendance-topbar {
        flex-basis: 46px;

        padding: 0 8px;
    }

    .brand-icon {
        width: 29px;
        height: 29px;

        font-size: 15px;
    }

    .brand-title {
        font-size: 12px;
    }

    .brand-subtitle,
    .clock-date {
        display: none;
    }

    .clock-time {
        min-width: 72px;

        padding: 4px 6px;

        font-size: 10px;
    }

    .attendance-main {
        grid-template-columns:
            minmax(0, 0.7fr)
            minmax(0, 1.3fr);

        gap: 7px;

        padding: 4px 7px;
    }

    .attendance-eyebrow,
    .attendance-description,
    .attendance-steps {
        display: none;
    }

    .attendance-heading {
        font-size: 17px;
    }

    .qr-panel {
        padding: 5px 7px;

        border-radius: 11px;
    }

    .qr-panel-subtitle {
        display: none;
    }

    .qr-panel-title {
        font-size: 9px;
    }

    .qr-live-status {
        padding: 3px 5px;

        font-size: 5px;
    }

    .qr-image-container {
        width: min(
            42vh,
            30vw,
            220px
        );

        height: min(
            42vh,
            30vw,
            220px
        );
    }

    .qr-countdown {
        font-size: 14px;
    }

    .qr-meta {
        margin-top: 3px;
    }

    .qr-meta-item {
        padding: 3px 4px;
    }

    .qr-security,
    .attendance-footer {
        display: none;
    }
}


/* =========================================================
   VERY SHORT SCREEN
   320px - 450px HEIGHT
========================================================= */

@media (max-height: 450px) {

    .attendance-topbar {
        flex-basis: 44px;
    }

    .attendance-main {
        padding-top: 3px;
        padding-bottom: 3px;
    }

    .attendance-description,
    .attendance-steps,
    .qr-panel-subtitle,
    .qr-security,
    .attendance-footer {
        display: none;
    }

    .attendance-heading {
        font-size: clamp(16px, 2.8vw, 28px);
    }

    .qr-image-container {
        width: min(
            42vh,
            30vw,
            220px
        );

        height: min(
            42vh,
            30vw,
            220px
        );
    }
}


/* =========================================================
   ULTRA WIDE
========================================================= */

@media (min-aspect-ratio: 21 / 9) {

    .attendance-main {
        max-width: 1800px;

        grid-template-columns:
            minmax(0, 0.9fr)
            minmax(0, 1.1fr);
    }

    .qr-image-container {
        width: min(
            48vh,
            30vw,
            500px
        );

        height: min(
            48vh,
            30vw,
            500px
        );
    }
}


/* =========================================================
   LARGE 2K / 4K DISPLAY
========================================================= */

@media (min-width: 1600px)
       and (min-height: 800px) {

    .attendance-main {
        max-width: 1800px;

        grid-template-columns:
            minmax(0, 0.85fr)
            minmax(0, 1.15fr);

        gap: 30px;

        padding-left: 45px;
        padding-right: 45px;
    }

    .attendance-heading {
        font-size: clamp(42px, 3vw, 62px);
    }

    .attendance-description {
        font-size: 15px;
    }

    .qr-image-container {
        width: min(
            47vh,
            32vw,
            500px
        );

        height: min(
            47vh,
            32vw,
            500px
        );
    }

    .qr-countdown {
        font-size: 30px;
    }
}
</style>


<div class="attendance-display">

    {{-- ======================================================
        TOP HEADER
    ======================================================= --}}
    <header class="attendance-topbar">

        <div class="topbar-brand">

            <div class="brand-icon">
                <i class="mdi mdi-qrcode-scan"></i>
            </div>

            <div>
                <h1 class="brand-title">
                    Elysium One
                </h1>

                <div class="brand-subtitle">
                    Employee Attendance Management
                </div>
            </div>

        </div>


        <div class="topbar-clock">

            <div class="clock-date">

                <div class="clock-day"
                     id="displayDay">
                    --
                </div>

                <div class="clock-full-date"
                     id="displayDate">
                    --
                </div>

            </div>


            <div class="clock-time"
                 id="displayTime">
                --:--:--
            </div>

        </div>

    </header>


    {{-- ======================================================
        MAIN
    ======================================================= --}}
    <main class="attendance-main">

        {{-- LEFT SIDE --}}
        <section class="attendance-info">

            <div class="attendance-eyebrow">

                <span class="attendance-eyebrow-dot"></span>

                Daily Attendance

            </div>


            <h2 class="attendance-heading">
                Welcome! Mark your
                <span>attendance.</span>
            </h2>


            <p class="attendance-description">
                Scan the secure QR code using the Elysium One mobile
                application to complete your daily Check-In or Check-Out.
            </p>


            <div class="attendance-steps">

                <div class="attendance-step">

                    <div class="step-number">
                        1
                    </div>

                    <div>
                        <div class="step-title">
                            Open Elysium One
                        </div>

                        <div class="step-text">
                            Launch the employee mobile application.
                        </div>
                    </div>

                </div>


                <div class="attendance-step">

                    <div class="step-number">
                        2
                    </div>

                    <div>
                        <div class="step-title">
                            Scan the QR Code
                        </div>

                        <div class="step-text">
                            Use the attendance scanner inside the app.
                        </div>
                    </div>

                </div>


                <div class="attendance-step">

                    <div class="step-number">
                        3
                    </div>

                    <div>
                        <div class="step-title">
                            Confirm Attendance
                        </div>

                        <div class="step-text">
                            Complete your Check-In or Check-Out.
                        </div>
                    </div>

                </div>

            </div>

        </section>


        {{-- ==================================================
            QR PANEL
        =================================================== --}}
        <section class="qr-panel">

            <div class="qr-panel-header">

                <div>

                    <div class="qr-panel-title">
                        Scan Attendance QR
                    </div>

                    <div class="qr-panel-subtitle">
                        Secure QR automatically refreshes every 10 minutes
                    </div>

                </div>


                <div class="qr-live-status"
                     id="qrLiveStatus">

                    <span class="qr-live-dot"></span>

                    <span id="qrStatusText">
                        GENERATING
                    </span>

                </div>

            </div>


            {{-- QR --}}
            <div class="qr-area">

                <div class="qr-card">

                    <div class="qr-image-container">

                        <img
                            id="qrImage"
                            src="{{ asset('assets/egc_images/qr_code.png') }}"
                            class="qr-image"
                            alt="Daily Attendance QR Code"
                        >


                        <div id="qrLoading"
                             class="qr-loading">

                            <div class="qr-loading-spinner"></div>

                            <div class="qr-loading-text">
                                Generating secure QR...
                            </div>

                        </div>

                    </div>


                    {{-- Expired --}}
                    <div id="qrExpiredOverlay"
                         class="qr-expired-overlay">

                        <div class="qr-expired-icon">
                            <i class="mdi mdi-refresh"></i>
                        </div>

                        <div class="qr-expired-title">
                            Refreshing QR Code
                        </div>

                        <div class="qr-expired-text">
                            Please wait a moment...
                        </div>

                    </div>

                </div>

            </div>


            {{-- TIMER --}}
            <div class="qr-timer-section">

                <div class="qr-timer-row">

                    <div>

                        <div class="qr-timer-label">
                            QR refreshes in
                        </div>

                    </div>


                    <div id="qrCountdown"
                         class="qr-countdown">
                        --:--
                    </div>

                </div>


                <div class="qr-progress">

                    <div id="qrProgressBar"
                         class="qr-progress-bar">
                    </div>

                </div>

            </div>


            {{-- DETAILS --}}
            <div class="qr-meta">

                <div class="qr-meta-item">

                    <div class="qr-meta-label">
                        Date
                    </div>

                    <div class="qr-meta-value"
                         id="qrDate">
                        --
                    </div>

                </div>


                <div class="qr-meta-item">

                    <div class="qr-meta-label">
                        Generated
                    </div>

                    <div class="qr-meta-value"
                         id="qrGeneratedAt">
                        --
                    </div>

                </div>


                <div class="qr-meta-item">

                    <div class="qr-meta-label">
                        Valid Until
                    </div>

                    <div class="qr-meta-value"
                         id="qrExpiresAt">
                        --
                    </div>

                </div>

            </div>


            <div class="qr-security">

                <i class="mdi mdi-shield-check-outline"></i>

                Secure temporary attendance QR

            </div>


            {{-- Hidden link - retained if needed elsewhere --}}
            <input
                type="hidden"
                id="download_qr_code_name"
                value=""
            >

        </section>

    </main>


    {{-- ======================================================
        FOOTER
    ======================================================= --}}
    <footer class="attendance-footer">

        <div class="footer-security">

            <i class="mdi mdi-shield-lock-outline"></i>

            QR codes are temporary and automatically refreshed
            for attendance security.

        </div>


        <div class="footer-help">
            Having trouble scanning? Please contact the Front Office or HR.
        </div>

    </footer>

</div>


<script>
    (() => {

        'use strict';

        /* =====================================================
           CONFIGURATION
        ===================================================== */

        const QR_DURATION_SECONDS = 10 * 60;
        const RETRY_DELAY = 5000;
        const REFRESH_DELAY = 1000;

        const QR_ENDPOINT =
            @json(url('/gen_daily_checkin_qr/generate-qr'));


        /* =====================================================
           STATE
        ===================================================== */

        let countdownTimer = null;
        let refreshTimer = null;

        let expiresAt = null;
        let generatedAt = null;

        let requestInProgress = false;

        let pageDestroyed = false;


        /* =====================================================
           DOM CACHE
        ===================================================== */

        const elements = {
            image: document.getElementById('qrImage'),
            loading: document.getElementById('qrLoading'),

            expiredOverlay:
                document.getElementById('qrExpiredOverlay'),

            countdown:
                document.getElementById('qrCountdown'),

            progressBar:
                document.getElementById('qrProgressBar'),

            status:
                document.getElementById('qrLiveStatus'),

            statusText:
                document.getElementById('qrStatusText'),

            date:
                document.getElementById('qrDate'),

            generated:
                document.getElementById('qrGeneratedAt'),

            expires:
                document.getElementById('qrExpiresAt'),

            link:
                document.getElementById('download_qr_code_name'),

            displayDay:
                document.getElementById('displayDay'),

            displayDate:document.getElementById('displayDate'),

            displayTime: document.getElementById('displayTime')
        };


        /* =====================================================
           DISPLAY CLOCK
        ===================================================== */

        function updateDisplayClock() {

            const now = new Date();

            elements.displayDay.textContent =
                now.toLocaleDateString(
                    'en-IN',
                    {
                        weekday: 'long'
                    }
                );

            elements.displayDate.textContent =
                now.toLocaleDateString(
                    'en-IN',
                    {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                    }
                );

            elements.displayTime.textContent =
                now.toLocaleTimeString(
                    'en-IN',
                    {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: true
                    }
                );
        }


        /* =====================================================
           DATE HELPERS
        ===================================================== */

        function formatDate(date) {

            return date.toLocaleDateString(
                'en-IN',
                {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                }
            );
        }


        function formatTime(date) {

            return date.toLocaleTimeString(
                'en-IN',
                {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                }
            );
        }


        /* =====================================================
           STATUS
        ===================================================== */

        function setQrStatus(status, text) {

            elements.statusText.textContent = text;

            let background;
            let color;
            let border;

            switch (status) {

                case 'active':

                    background = '#ecfdf3';
                    color = '#15803d';
                    border = '#bbf7d0';

                    break;


                case 'refreshing':

                    background = '#fff7ed';
                    color = '#c2410c';
                    border = '#fed7aa';

                    break;


                case 'error':

                    background = '#fef2f2';
                    color = '#b91c1c';
                    border = '#fecaca';

                    break;


                default:

                    background = '#f8fafc';
                    color = '#475569';
                    border = '#e2e8f0';
            }

            elements.status.style.background = background;
            elements.status.style.color = color;
            elements.status.style.borderColor = border;
        }


        /* =====================================================
           LOADING
        ===================================================== */

        function showLoading(show) {

            if (show) {

                elements.loading.style.display = 'flex';
                elements.image.style.visibility = 'hidden';

            } else {

                elements.loading.style.display = 'none';
                elements.image.style.visibility = 'visible';
            }
        }


        /* =====================================================
           RESET
        ===================================================== */

        function resetUI() {

            showLoading(true);

            elements.expiredOverlay.style.display = 'none';

            elements.countdown.classList.remove(
                'warning',
                'danger'
            );

            elements.countdown.textContent = '--:--';

            elements.progressBar.style.width = '100%';

            elements.date.textContent = '--';
            elements.generated.textContent = '--';
            elements.expires.textContent = '--';

            elements.link.value = '';

            setQrStatus(
                'refreshing',
                'GENERATING'
            );
        }


        /* =====================================================
           CLEAR TIMERS
        ===================================================== */

        function clearTimers() {

            if (countdownTimer !== null) {

                clearInterval(countdownTimer);

                countdownTimer = null;
            }


            if (refreshTimer !== null) {

                clearTimeout(refreshTimer);

                refreshTimer = null;
            }
        }


        /* =====================================================
           IMAGE PRELOAD
        ===================================================== */

        function loadQrImage(source) {

            return new Promise((resolve, reject) => {

                const image = new Image();

                image.onload = () => {

                    elements.image.src = source;

                    resolve();
                };

                image.onerror = reject;

                image.src = source;
            });
        }


        /* =====================================================
           GENERATE QR
        ===================================================== */

        async function generateNewQr() {

            if (
                requestInProgress ||
                pageDestroyed
            ) {
                return;
            }

            requestInProgress = true;

            clearTimers();

            showLoading(true);

            elements.expiredOverlay.style.display = 'none';

            setQrStatus(
                'refreshing',
                'GENERATING'
            );


            try {

                const response = await fetch(
                    QR_ENDPOINT,
                    {
                        method: 'GET',

                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },

                        cache: 'no-store',

                        credentials: 'same-origin'
                    }
                );


                if (!response.ok) {

                    throw new Error(
                        `QR request failed with HTTP ${response.status}`
                    );
                }


                const data = await response.json();


                if (
                    Number(data.status) !== 200 ||
                    !data.qr_base64 ||
                    !data.expires_at
                ) {

                    throw new Error(
                        data.message ||
                        'Invalid QR response received.'
                    );
                }


                /*
                 * Parse timestamps before updating the screen.
                 */
                const parsedExpiresAt =
                    new Date(data.expires_at);

                const parsedGeneratedAt =
                    data.generated_at
                        ? new Date(data.generated_at)
                        : new Date();


                if (
                    Number.isNaN(parsedExpiresAt.getTime()) ||
                    Number.isNaN(parsedGeneratedAt.getTime())
                ) {

                    throw new Error(
                        'Invalid QR timestamp received.'
                    );
                }


                /*
                 * Ensure QR image has loaded before hiding spinner.
                 */
                await loadQrImage(
                    data.qr_base64
                );


                expiresAt =
                    parsedExpiresAt.getTime();

                generatedAt =
                    parsedGeneratedAt.getTime();


                /*
                 * Server formatted values are preferred.
                 */
                elements.date.textContent =
                    data.date_formatted ||
                    formatDate(parsedGeneratedAt);


                elements.generated.textContent =
                    data.generated_at_formatted ||
                    formatTime(parsedGeneratedAt);


                elements.expires.textContent =
                    data.expires_at_formatted ||
                    formatTime(parsedExpiresAt);


                elements.link.value =
                    data.link || '';


                showLoading(false);


                setQrStatus(
                    'active',
                    'QR ACTIVE'
                );


                startCountdown();

            } catch (error) {

                console.error(
                    '[Attendance QR]',
                    error
                );


                showLoading(false);


                setQrStatus(
                    'error',
                    'CONNECTION ERROR'
                );


                elements.countdown.textContent = '--:--';


                /*
                 * Automatically retry.
                 */
                refreshTimer = setTimeout(
                    generateNewQr,
                    RETRY_DELAY
                );

            } finally {

                requestInProgress = false;
            }
        }


        /* =====================================================
           COUNTDOWN
        ===================================================== */

        function startCountdown() {

            if (!expiresAt) {
                return;
            }


            clearInterval(countdownTimer);


            updateCountdown();


            countdownTimer = setInterval(
                updateCountdown,
                1000
            );
        }


        function updateCountdown() {

            if (!expiresAt) {
                return;
            }


            const now = Date.now();

            const remaining =
                Math.max(
                    0,
                    expiresAt - now
                );


            const totalSeconds =
                Math.ceil(
                    remaining / 1000
                );


            const minutes =
                Math.floor(
                    totalSeconds / 60
                );


            const seconds =
                totalSeconds % 60;


            elements.countdown.textContent =
                String(minutes).padStart(2, '0') +
                ':' +
                String(seconds).padStart(2, '0');


            /*
             * Calculate actual duration when possible.
             *
             * This makes the UI reliable even if the backend
             * later changes QR duration.
             */
            let totalDuration =
                QR_DURATION_SECONDS * 1000;


            if (
                generatedAt &&
                expiresAt > generatedAt
            ) {

                totalDuration =
                    expiresAt - generatedAt;
            }


            const percentage =
                Math.max(
                    0,
                    Math.min(
                        100,
                        (remaining / totalDuration) * 100
                    )
                );


            elements.progressBar.style.width =
                `${percentage}%`;


            elements.countdown.classList.remove(
                'warning',
                'danger'
            );


            if (totalSeconds <= 60) {

                elements.countdown.classList.add(
                    'danger'
                );

            } else if (totalSeconds <= 180) {

                elements.countdown.classList.add(
                    'warning'
                );
            }


            if (remaining <= 0) {

                handleExpired();
            }
        }


        /* =====================================================
           EXPIRED
        ===================================================== */

        function handleExpired() {

            if (countdownTimer !== null) {

                clearInterval(countdownTimer);

                countdownTimer = null;
            }


            elements.countdown.textContent = '00:00';

            elements.countdown.classList.add(
                'danger'
            );


            elements.progressBar.style.width = '0%';


            elements.expiredOverlay.style.display =
                'flex';


            setQrStatus(
                'refreshing',
                'REFRESHING'
            );


            refreshTimer = setTimeout(
                generateNewQr,
                REFRESH_DELAY
            );
        }


        /* =====================================================
           PAGE VISIBILITY RECOVERY
        ===================================================== */

        function handleVisibilityChange() {

            if (document.visibilityState !== 'visible') {
                return;
            }


            /*
             * Browser timers may be throttled when a TV/tab
             * remains in background. Revalidate immediately
             * when the page becomes active.
             */
            if (
                !expiresAt ||
                Date.now() >= expiresAt
            ) {

                generateNewQr();

                return;
            }


            updateCountdown();
        }


        /* =====================================================
           NETWORK RECOVERY
        ===================================================== */

        function handleOnline() {

            if (
                !expiresAt ||
                Date.now() >= expiresAt
            ) {

                generateNewQr();
            }
        }


        function handleOffline() {

            setQrStatus(
                'error',
                'OFFLINE'
            );
        }


        /* =====================================================
           INITIALIZATION
        ===================================================== */

        function initializeAttendanceScreen() {

            updateDisplayClock();

            setInterval(
                updateDisplayClock,
                1000
            );


            resetUI();

            generateNewQr();


            document.addEventListener(
                'visibilitychange',
                handleVisibilityChange
            );


            window.addEventListener(
                'online',
                handleOnline
            );


            window.addEventListener(
                'offline',
                handleOffline
            );


            window.addEventListener(
                'beforeunload',
                () => {

                    pageDestroyed = true;

                    clearTimers();
                }
            );
        }


        /*
         * Blade script can be loaded before or after DOM ready
         * depending on layout/Vite configuration.
         */
        if (document.readyState === 'loading') {

            document.addEventListener(
                'DOMContentLoaded',
                initializeAttendanceScreen,
                {
                    once: true
                }
            );

        } else {

            initializeAttendanceScreen();
        }

    })();
</script>

@endsection