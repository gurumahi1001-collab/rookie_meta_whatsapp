@extends('layouts/blankLayout')

@section('title', 'Daily Attendance')

@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">
<style>


    :root {
        --attendance-primary: #8f1d1d;
        --attendance-primary-2: #b52b25;
        --attendance-accent: #f5a623;

        --attendance-bg: #f4f6f9;
        --attendance-card: #ffffff;

        --attendance-text: #172033;
        --attendance-muted: #6b7280;
        --attendance-border: #e5e7eb;

        --attendance-success: #16a34a;
        --attendance-warning: #d97706;
        --attendance-danger: #dc2626;
    }

    html,
    body {
        width: 100%;
        height: 100%;
        margin: 0;
        overflow: hidden !important;
        background: var(--attendance-bg);
    }

    body {
        font-family: inherit;
    }

    * {
        box-sizing: border-box;
    }

    /*  PAGE */
    .attendance-screen {
        width: 100vw;
        height: 100vh;
        height: 100dvh;

        display: flex;
        flex-direction: column;

        overflow: hidden;

        background:
            radial-gradient(
                circle at 85% 5%,
                rgba(245, 166, 35, .10),
                transparent 28%
            ),
            radial-gradient(
                circle at 5% 90%,
                rgba(143, 29, 29, .06),
                transparent 30%
            ),
            #f4f6f9;
    }


    /*  HEADER  */

    .attendance-header {
        height: clamp(74px, 10vh, 105px);
        min-height: 74px;

        display: flex;
        align-items: center;
        justify-content: space-between;

        padding: 0 clamp(20px, 3vw, 52px);

        color: #fff;

        background:
            linear-gradient(
                110deg,
                #781717 0%,
                #991f1f 38%,
                #bd3025 70%,
                #e77d20 100%
            );

        position: relative;
        overflow: hidden;
        flex-shrink: 0;

        box-shadow: 0 8px 30px rgba(90, 20, 20, .16);
    }

    .attendance-header::before {
        content: "";
        position: absolute;

        width: 360px;
        height: 360px;

        border-radius: 50%;

        background: rgba(255, 255, 255, .055);

        right: -80px;
        top: -240px;
    }

    .attendance-header::after {
        content: "";
        position: absolute;

        width: 200px;
        height: 200px;

        border-radius: 50%;

        background: rgba(255, 255, 255, .04);

        right: 22%;
        bottom: -160px;
    }

    .attendance-brand {
        display: flex;
        align-items: center;
        gap: clamp(12px, 1.3vw, 20px);

        position: relative;
        z-index: 2;

        min-width: 0;
    }

    .attendance-brand-icon {
        width: clamp(46px, 4vw, 62px);
        height: clamp(46px, 4vw, 62px);

        flex: 0 0 auto;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: clamp(13px, 1.2vw, 18px);

        background: rgba(255, 255, 255, .14);
        border: 1px solid rgba(255, 255, 255, .14);

        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);

        box-shadow: inset 0 1px 0 rgba(255,255,255,.12);
    }

    .attendance-brand-icon i {
        font-size: clamp(25px, 2.2vw, 34px);
    }

    .attendance-title {
        margin: 0;

        font-size: clamp(20px, 2vw, 30px);
        line-height: 1.15;
        font-weight: 800;

        letter-spacing: -.3px;
        color: #fff;
    }

    .attendance-subtitle {
        margin-top: 5px;

        font-size: clamp(11px, 1vw, 14px);
        font-weight: 400;

        color: rgba(255, 255, 255, .78);
    }


    /* Header right */
    .attendance-header-right {
        position: relative;
        z-index: 2;

        display: flex;
        align-items: center;
        gap: clamp(12px, 1.5vw, 24px);
    }

    .attendance-header-date {
        text-align: right;
    }

    .header-date-label {
        font-size: clamp(10px, .8vw, 12px);
        text-transform: uppercase;
        letter-spacing: .8px;
        color: rgba(255,255,255,.65);
        font-weight: 600;
    }

    .header-date-value {
        margin-top: 2px;

        font-size: clamp(13px, 1.15vw, 17px);
        font-weight: 700;

        color: #fff;
    }

    .attendance-clock {
        min-width: clamp(105px, 9vw, 145px);

        padding: clamp(9px, .8vw, 13px)
                 clamp(13px, 1.2vw, 19px);

        border-radius: 14px;

        background: rgba(255,255,255,.13);
        border: 1px solid rgba(255,255,255,.13);

        text-align: center;

        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }

    .attendance-clock-time {
        font-size: clamp(17px, 1.6vw, 24px);
        line-height: 1;
        font-weight: 800;

        font-variant-numeric: tabular-nums;
        letter-spacing: .4px;
    }

    /* MAIN CONTENT */

    .attendance-main {
        flex: 1;
        min-height: 0;

        display: flex;
        align-items: center;
        justify-content: center;

        padding: clamp(12px, 1.7vh, 24px)
                 clamp(16px, 2.5vw, 42px);

        overflow: hidden;
    }

    .attendance-panel {
        width: min(1180px, 100%);
        height: 100%;

        max-height: 760px;

        display: grid;
        grid-template-columns:
            minmax(330px, .9fr)
            minmax(360px, 1.1fr);

        overflow: hidden;

        border: 1px solid rgba(226, 232, 240, .9);
        border-radius: clamp(20px, 2vw, 30px);

        background: rgba(255,255,255,.94);

        box-shadow:
            0 24px 70px rgba(15, 23, 42, .08),
            0 4px 14px rgba(15, 23, 42, .035);
    }


    /* =========================================================
       LEFT QR SECTION
    ========================================================== */

    .attendance-qr-section {
        min-width: 0;
        min-height: 0;

        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;

        padding: clamp(16px, 2.2vh, 28px);

        border-right: 1px solid #edf0f4;

        background:
            radial-gradient(
                circle at center,
                rgba(143, 29, 29, .025),
                transparent 65%
            ),
            #fff;
    }


    /* Status */

    .qr-status {
        display: inline-flex;
        align-items: center;
        justify-content: center;

        gap: 8px;

        margin-bottom: clamp(10px, 1.5vh, 18px);

        padding: 7px 14px;

        border-radius: 999px;

        background: #ecfdf3;
        border: 1px solid #bbf7d0;

        color: #15803d;

        font-size: clamp(10px, .85vw, 12px);
        font-weight: 800;
        letter-spacing: .4px;

        white-space: nowrap;
    }

    .qr-live-dot {
        width: 8px;
        height: 8px;

        flex: 0 0 auto;

        border-radius: 50%;

        background: #16a34a;

        animation: qrPulse 1.5s infinite;
    }

    @keyframes qrPulse {
        0% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, .45);
        }

        70% {
            box-shadow: 0 0 0 7px rgba(22, 163, 74, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0);
        }
    }


    /* QR card */

    .qr-card {
        position: relative;

        width: min(
            40vh,
            380px,
            30vw
        );

        aspect-ratio: 1 / 1;

        padding: clamp(11px, 1.1vw, 16px);

        border-radius: clamp(18px, 1.6vw, 25px);

        background: #fff;

        border: 1px solid #e6e9ee;

        box-shadow:
            0 16px 45px rgba(15, 23, 42, .08),
            0 3px 10px rgba(15, 23, 42, .035);
    }

    .qr-card::before {
        content: "";

        position: absolute;
        inset: -5px;

        border: 2px solid rgba(143, 29, 29, .07);

        border-radius: inherit;

        pointer-events: none;
    }

    .qr-image-container {
        width: 100%;
        height: 100%;

        display: flex;
        align-items: center;
        justify-content: center;

        overflow: hidden;

        border-radius: clamp(12px, 1vw, 17px);

        background: #fff;
    }

    .qr-image {
        width: 100%;
        height: 100%;

        display: block;

        object-fit: contain;
    }


    /* QR loading */

    .qr-loading {
        width: 100%;
        height: 100%;

        display: none;
        flex-direction: column;
        align-items: center;
        justify-content: center;

        gap: 13px;

        color: #64748b;

        font-size: 12px;
    }

    .qr-loading-spinner {
        width: 44px;
        height: 44px;

        border: 4px solid #eceff3;
        border-top-color: var(--attendance-primary);

        border-radius: 50%;

        animation: qrSpin .8s linear infinite;
    }

    @keyframes qrSpin {
        to {
            transform: rotate(360deg);
        }
    }


    /* Expired */

    .qr-expired-overlay {
        display: none;

        position: absolute;
        inset: clamp(11px, 1.1vw, 16px);

        z-index: 10;

        align-items: center;
        justify-content: center;
        flex-direction: column;

        padding: 20px;

        text-align: center;

        border-radius: 16px;

        background: rgba(255,255,255,.97);
        backdrop-filter: blur(5px);
    }

    .qr-expired-icon {
        width: 58px;
        height: 58px;

        display: flex;
        align-items: center;
        justify-content: center;

        margin-bottom: 12px;

        border-radius: 50%;

        background: #fee2e2;
        color: #dc2626;

        font-size: 28px;
    }

    .qr-expired-title {
        font-size: 16px;
        font-weight: 800;
        color: #991b1b;
    }

    .qr-expired-text {
        margin-top: 4px;

        font-size: 11px;
        color: #64748b;
    }


    /* Countdown */

    .qr-countdown-area {
        width: min(360px, 90%);

        margin-top: clamp(11px, 1.5vh, 18px);

        text-align: center;
    }

    .qr-countdown-top {
        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 15px;

        margin-bottom: 7px;
    }

    .qr-countdown-label {
        font-size: clamp(9px, .75vw, 11px);
        font-weight: 700;

        text-transform: uppercase;
        letter-spacing: .55px;

        color: #94a3b8;
    }

    .qr-countdown {
        font-size: clamp(16px, 1.4vw, 21px);
        line-height: 1;

        font-weight: 800;

        color: #172033;

        font-variant-numeric: tabular-nums;
        letter-spacing: .6px;
    }

    .qr-countdown.warning {
        color: var(--attendance-warning);
    }

    .qr-countdown.danger {
        color: var(--attendance-danger);
    }

    .qr-progress {
        width: 100%;
        height: 5px;

        overflow: hidden;

        border-radius: 20px;

        background: #e9edf2;
    }

    .qr-progress-bar {
        width: 100%;
        height: 100%;

        border-radius: 20px;

        background:
            linear-gradient(
                90deg,
                #16a34a,
                #22c55e
            );

        transition: width 1s linear;
    }


    /* =========================================================
       RIGHT INFORMATION SECTION
    ========================================================== */

    .attendance-info-section {
        min-width: 0;
        min-height: 0;

        display: flex;
        flex-direction: column;
        justify-content: center;

        padding:
            clamp(22px, 3vh, 42px)
            clamp(24px, 3.3vw, 52px);

        background:
            linear-gradient(
                145deg,
                #fff 0%,
                #fbfcfd 100%
            );
    }

    .attendance-info-eyebrow {
        display: flex;
        align-items: center;

        gap: 8px;

        margin-bottom: 10px;

        color: var(--attendance-primary);

        font-size: clamp(10px, .8vw, 12px);
        font-weight: 800;

        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .attendance-info-eyebrow::before {
        content: "";

        width: 25px;
        height: 3px;

        border-radius: 5px;

        background: var(--attendance-primary);
    }

    .attendance-info-title {
        margin: 0;

        max-width: 520px;

        font-size: clamp(25px, 2.5vw, 39px);
        line-height: 1.12;

        font-weight: 800;

        letter-spacing: -.8px;

        color: #172033;
    }

    .attendance-info-description {
        max-width: 510px;

        margin-top: clamp(8px, 1.3vh, 15px);
        margin-bottom: 0;

        font-size: clamp(11px, 1vw, 14px);
        line-height: 1.65;

        color: #64748b;
    }


    /* Steps */

    .attendance-steps {
        display: grid;
        gap: clamp(8px, 1vh, 12px);

        margin-top: clamp(15px, 2.4vh, 28px);
    }

    .attendance-step {
        display: flex;
        align-items: center;

        gap: clamp(11px, 1.2vw, 16px);

        padding:
            clamp(10px, 1.2vh, 14px)
            clamp(11px, 1.2vw, 15px);

        border: 1px solid #edf0f4;

        border-radius: 14px;

        background: #fff;

        box-shadow: 0 3px 12px rgba(15,23,42,.025);
    }

    .attendance-step-number {
        width: clamp(34px, 2.8vw, 42px);
        height: clamp(34px, 2.8vw, 42px);

        flex: 0 0 auto;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 11px;

        background: #fff4f1;
        color: var(--attendance-primary);

        font-size: clamp(13px, 1vw, 16px);
        font-weight: 800;
    }

    .attendance-step-title {
        font-size: clamp(11px, .95vw, 14px);
        line-height: 1.25;

        font-weight: 700;

        color: #334155;
    }

    .attendance-step-text {
        margin-top: 2px;

        font-size: clamp(9px, .8vw, 11px);
        line-height: 1.4;

        color: #94a3b8;
    }


    /* Details */

    .attendance-meta {
        display: grid;
        grid-template-columns: repeat(3, 1fr);

        gap: clamp(7px, .8vw, 10px);

        margin-top: clamp(14px, 2vh, 23px);
    }

    .attendance-meta-item {
        min-width: 0;

        padding:
            clamp(9px, 1vh, 12px)
            clamp(9px, 1vw, 13px);

        border-radius: 12px;

        border: 1px solid #edf0f4;

        background: #f8fafc;
    }

    .attendance-meta-label {
        font-size: clamp(8px, .65vw, 10px);

        color: #94a3b8;

        font-weight: 700;

        text-transform: uppercase;
        letter-spacing: .45px;
    }

    .attendance-meta-value {
        margin-top: 3px;

        overflow: hidden;

        color: #334155;

        font-size: clamp(10px, .85vw, 12px);
        font-weight: 700;

        white-space: nowrap;
        text-overflow: ellipsis;
    }


    /* Security */

    .attendance-security {
        display: flex;
        align-items: center;

        gap: 10px;

        margin-top: clamp(12px, 1.7vh, 20px);

        padding: clamp(10px, 1.1vh, 13px)
                 clamp(11px, 1vw, 14px);

        border-radius: 12px;

        border: 1px solid #dcfce7;

        background: #f0fdf4;
    }

    .attendance-security-icon {
        width: 34px;
        height: 34px;

        flex: 0 0 auto;

        display: flex;
        align-items: center;
        justify-content: center;

        border-radius: 9px;

        background: #dcfce7;
        color: #15803d;

        font-size: 18px;
    }

    .attendance-security-title {
        font-size: clamp(10px, .85vw, 12px);
        font-weight: 700;

        color: #166534;
    }

    .attendance-security-text {
        margin-top: 1px;

        font-size: clamp(8px, .72vw, 10px);
        line-height: 1.4;

        color: #65a30d;
    }


    /* =========================================================
       FOOTER
    ========================================================== */

    .attendance-footer {
        height: clamp(34px, 4.5vh, 48px);

        flex-shrink: 0;

        display: flex;
        align-items: center;
        justify-content: center;

        padding: 0 20px;

        color: #94a3b8;

        font-size: clamp(9px, .75vw, 11px);
    }

    .attendance-footer i {
        margin-right: 5px;

        color: #16a34a;

        font-size: 14px;
    }


    /* =========================================================
       TABLET / PORTRAIT
    ========================================================== */

    @media (max-width: 850px) {

        .attendance-header {
            padding-left: 18px;
            padding-right: 18px;
        }

        .attendance-header-date {
            display: none;
        }

        .attendance-main {
            padding: 12px;
        }

        .attendance-panel {
            grid-template-columns: 1fr 1fr;
        }

        .attendance-info-section {
            padding: 22px 20px;
        }

        .attendance-info-title {
            font-size: clamp(21px, 3.2vw, 29px);
        }

        .attendance-meta {
            grid-template-columns: 1fr;
        }

        .attendance-meta-item:nth-child(2),
        .attendance-meta-item:nth-child(3) {
            display: none;
        }

        .qr-card {
            width: min(38vh, 42vw, 330px);
        }
    }


    /* =========================================================
       SMALL PORTRAIT TABLET / MOBILE KIOSK
    ========================================================== */

    @media (max-width: 650px) {

        .attendance-screen {
            overflow: hidden;
        }

        .attendance-header {
            height: 72px;
            min-height: 72px;
        }

        .attendance-subtitle {
            display: none;
        }

        .attendance-clock {
            min-width: 92px;
        }

        .attendance-main {
            padding: 8px;
        }

        .attendance-panel {
            display: flex;
            flex-direction: column;

            border-radius: 18px;
        }

        .attendance-qr-section {
            flex: 1;

            padding: 10px;

            border-right: 0;
        }

        .attendance-info-section {
            flex: 0 0 auto;

            justify-content: flex-start;

            padding: 10px 16px 13px;

            border-top: 1px solid #edf0f4;
        }

        .attendance-info-eyebrow,
        .attendance-info-title,
        .attendance-info-description,
        .attendance-meta,
        .attendance-security {
            display: none;
        }

        .attendance-steps {
            grid-template-columns: repeat(3, 1fr);

            gap: 6px;

            margin: 0;
        }

        .attendance-step {
            flex-direction: column;

            gap: 4px;

            padding: 7px 5px;

            text-align: center;
        }

        .attendance-step-number {
            width: 27px;
            height: 27px;

            border-radius: 8px;

            font-size: 11px;
        }

        .attendance-step-title {
            font-size: 9px;
        }

        .attendance-step-text {
            display: none;
        }

        .qr-status {
            margin-bottom: 7px;
            padding: 5px 10px;

            font-size: 9px;
        }

        .qr-card {
            width: min(43vh, 75vw, 300px);
        }

        .qr-countdown-area {
            margin-top: 8px;
        }

        .attendance-footer {
            height: 28px;

            font-size: 8px;
        }
    }


    /* =========================================================
       LOW HEIGHT DISPLAYS
       Example: 1366 x 768 office monitor
    ========================================================== */

    @media (max-height: 720px) and (min-width: 651px) {

        .attendance-header {
            height: 70px;
            min-height: 70px;
        }

        .attendance-main {
            padding-top: 10px;
            padding-bottom: 10px;
        }

        .attendance-panel {
            max-height: none;
        }

        .attendance-info-section {
            padding-top: 18px;
            padding-bottom: 18px;
        }

        .attendance-info-description {
            margin-top: 7px;
        }

        .attendance-steps {
            margin-top: 13px;
            gap: 7px;
        }

        .attendance-step {
            padding-top: 8px;
            padding-bottom: 8px;
        }

        .attendance-meta {
            margin-top: 12px;
        }

        .attendance-security {
            margin-top: 10px;
        }

        .qr-card {
            width: min(43vh, 29vw, 315px);
        }

        .qr-countdown-area {
            margin-top: 10px;
        }

        .attendance-footer {
            height: 30px;
        }
    }
</style>


<div class="attendance-screen">

    {{-- =====================================================
         HEADER
    ====================================================== --}}
    <header class="attendance-header">

        <div class="attendance-brand">

            <div class="attendance-brand-icon">
                <i class="mdi mdi-qrcode-scan"></i>
            </div>

            <div>
                <h1 class="attendance-title">
                    Daily Attendance 
                </h1>

                <div class="attendance-subtitle">
                    Employee Check-In & Check-Out
                </div>
            </div>

        </div>

       

        <div class="attendance-header-right">

            <div class="attendance-header-date">
                <div class="header-date-label"  id="headerCurrentDay">
                    Today 
                </div>

                <div class="header-date-value" id="headerCurrentDate">
                    --
                </div>
            </div>


            <div class="attendance-clock">
                <div class="attendance-clock-time"
                     id="attendanceClock">
                    --:--:--
                </div>
            </div>

        </div>

    </header>


    {{-- =====================================================
         MAIN
    ====================================================== --}}
    <main class="attendance-main">

        <div class="attendance-panel">


            {{-- =============================================
                 QR SIDE
            ============================================== --}}
            <section class="attendance-qr-section">

                <div class="qr-status"
                     id="qrLiveStatus">

                    <span class="qr-live-dot"></span>

                    <span id="qrStatusText">
                        GENERATING SECURE QR
                    </span>

                </div>


                <div class="qr-card">

                    <div class="qr-image-container p-2">

                        <img id="qrImage"
                            class="qr-image"
                            src="{{ asset('assets/egc_images/qr_code.png') }}"
                            alt="Daily Attendance QR Code"
                        >


                        <div id="qrLoading"
                             class="qr-loading">

                            <div class="qr-loading-spinner"></div>

                            <div>
                                Generating secure QR...
                            </div>

                        </div>

                    </div>


                    <div id="qrExpiredOverlay"
                         class="qr-expired-overlay">

                        <div class="qr-expired-icon">
                            <i class="mdi mdi-refresh"></i>
                        </div>

                        <div class="qr-expired-title">
                            Refreshing QR Code
                        </div>

                        <div class="qr-expired-text">
                            Please wait a moment...
                        </div>

                    </div>

                </div>


                {{-- Countdown --}}

                <div class="qr-countdown-area">

                    <div class="qr-countdown-top">

                        <div class="qr-countdown-label">
                            Secure QR refresh
                        </div>

                        <div id="qrCountdown"
                             class="qr-countdown">
                            --:--
                        </div>

                    </div>


                    <div class="qr-progress">

                        <div id="qrProgressBar"
                             class="qr-progress-bar">
                        </div>

                    </div>

                </div>

            </section>


            {{-- =============================================
                 INFORMATION SIDE
            ============================================== --}}
            <section class="attendance-info-section">

                <div class="attendance-info-eyebrow">
                    Employee Attendance
                </div>


                <h2 class="attendance-info-title">
                    Scan. Verify.<br>
                    Mark Attendance.
                </h2>


                <p class="attendance-info-description">
                    Use the Elysium One mobile app to securely
                    mark your daily Check-In or Check-Out.
                </p>


                {{-- Steps --}}

                <div class="attendance-steps">

                    <div class="attendance-step">

                        <div class="attendance-step-number">
                            1
                        </div>

                        <div>
                            <div class="attendance-step-title">
                                Open Elysium One
                            </div>

                            <div class="attendance-step-text">
                                Open the employee application on your mobile.
                            </div>
                        </div>

                    </div>


                    <div class="attendance-step">

                        <div class="attendance-step-number">
                            2
                        </div>

                        <div>
                            <div class="attendance-step-title">
                                Scan QR Code
                            </div>

                            <div class="attendance-step-text">
                                Point your mobile camera at the attendance QR.
                            </div>
                        </div>

                    </div>


                    <div class="attendance-step">

                        <div class="attendance-step-number">
                            3
                        </div>

                        <div>
                            <div class="attendance-step-title">
                                Confirm Attendance
                            </div>

                            <div class="attendance-step-text">
                                Complete your Check-In or Check-Out.
                            </div>
                        </div>

                    </div>

                </div>


                {{-- QR Metadata --}}

                <!-- <div class="attendance-meta">

                    <div class="attendance-meta-item">

                        <div class="attendance-meta-label">
                            Date
                        </div>

                        <div class="attendance-meta-value"
                             id="qrDate">
                            --
                        </div>

                    </div>


                    <div class="attendance-meta-item">

                        <div class="attendance-meta-label">
                            Generated
                        </div>

                        <div class="attendance-meta-value"
                             id="qrGeneratedAt">
                            --
                        </div>

                    </div>


                    <div class="attendance-meta-item">

                        <div class="attendance-meta-label">
                            Valid Until
                        </div>

                        <div class="attendance-meta-value"
                             id="qrExpiresAt">
                            --
                        </div>

                    </div>

                </div> -->


                {{-- Security --}}

                <div class="attendance-security">

                    <div class="attendance-security-icon">
                        <i class="mdi mdi-shield-check-outline"></i>
                    </div>

                    <div>

                        <div class="attendance-security-title">
                            Secure Temporary QR
                        </div>

                        <div class="attendance-security-text">
                            QR code automatically changes every 10 minutes
                            for attendance security.
                        </div>

                    </div>

                </div>


                {{-- Hidden URL required for existing logic --}}

                <input
                    type="hidden"
                    id="download_qr_code_name"
                    value=""
                >

            </section>

        </div>

    </main>


    {{-- =====================================================
         FOOTER
    ====================================================== --}}
    <footer class="attendance-footer">

        <span>
            <i class="mdi mdi-shield-lock-outline"></i>
            Secure Corporate Attendance System
        </span>

    </footer>

</div>


<script>
    /* =========================================================
       CONFIGURATION
    ========================================================== */

    let attendanceQrTimer = null;
    let attendanceQrRefreshTimer = null;

    let attendanceQrExpiresAt = null;
    let attendanceQrGeneratedAt = null;

    let attendanceQrRequestRunning = false;

    const ATTENDANCE_QR_DURATION_SECONDS = 10 * 60;


    /* =========================================================
       CLOCK
    ========================================================== */

    // function updateAttendanceClock() {

    //     const now = new Date();


    //     $('#attendanceClock').text(
    //         now.toLocaleTimeString(
    //             [],
    //             {
    //                 hour: '2-digit',
    //                 minute: '2-digit',
    //                 second: '2-digit'
    //             }
    //         )
    //     );


    //     $('#headerCurrentDate').text(
    //         now.toLocaleDateString(
    //             [],
    //             {
    //                 weekday: 'short',
    //                 day: '2-digit',
    //                 month: 'short',
    //                 year: 'numeric'
    //             }
    //         )
    //     );
    // }

    function updateAttendanceClock() {

        const now = new Date();

        $('#headerCurrentDay').text(
            now.toLocaleDateString(
                'en-IN',
                {
                    weekday: 'long'
                }
            )
        )

        $('#headerCurrentDate').text(
            now.toLocaleDateString(
                'en-IN',
                {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                }
            )
        )

        $('#attendanceClock').text(
            now.toLocaleTimeString(
                'en-IN',
                {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                }
            )
        )

    }

    

    updateAttendanceClock();

    setInterval(
        updateAttendanceClock,
        1000
    );


    /* =========================================================
       INITIALIZE
    ========================================================== */

    function generateQr() {

        clearAttendanceQrTimers();

        resetAttendanceQrUI();

        generateNewAttendanceQr();
    }


    /* =========================================================
       GENERATE QR
    ========================================================== */

    async function generateNewAttendanceQr() {

        /*
         * Prevent duplicate API requests.
         */
        if (attendanceQrRequestRunning) {
            return;
        }


        attendanceQrRequestRunning = true;

        showQrLoading(true);


        try {

            const response = await fetch(
                "{{ url('/gen_daily_checkin_qr/generate-qr') }}",
                {
                    method: 'GET',

                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },

                    cache: 'no-store'
                }
            );


            if (!response.ok) {

                throw new Error(
                    `HTTP error: ${response.status}`
                );
            }


            const data = await response.json();

            console.log(
                'Attendance QR Response:',
                data
            );


            if (
                data.status !== 200 ||
                !data.qr_base64 ||
                !data.expires_at
            ) {

                throw new Error(
                    data.message ||
                    'QR generation failed'
                );
            }


            /* -----------------------------------------
               QR IMAGE
            ------------------------------------------ */

            const qrImage =  document.getElementById('qrImage');


            /*
             * Preload QR before replacing current image.
             * Prevents white flickering.
             */
            const newImage = new Image();


            newImage.onload = function () {

                qrImage.src = data.qr_base64;

                $('#qrImage')
                    .stop(true, true)
                    .fadeIn(200);
            };


            newImage.src = data.qr_base64;


            /* -----------------------------------------
               DETAILS
            ------------------------------------------ */

            $('#qrDate').text(
                data.date_formatted ||
                formatCurrentDate()
            );


            $('#qrGeneratedAt').text(
                data.generated_at_formatted ||
                formatCurrentTime()
            );


            $('#qrExpiresAt').text(
                data.expires_at_formatted ||
                formatDateTime(
                    data.expires_at
                )
            );


            $('#download_qr_code_name').val(
                data.link || ''
            );


            /* -----------------------------------------
               TIMESTAMPS
            ------------------------------------------ */

            attendanceQrExpiresAt =
                parseServerDate(
                    data.expires_at
                );


            attendanceQrGeneratedAt =
                data.generated_at
                    ? parseServerDate(
                        data.generated_at
                    )
                    : Date.now();


            if (
                !attendanceQrExpiresAt ||
                Number.isNaN(
                    attendanceQrExpiresAt
                )
            ) {

                throw new Error(
                    'Invalid QR expiration time'
                );
            }


            /* -----------------------------------------
               UI
            ------------------------------------------ */

            showQrLoading(false);


            setQrStatus(
                'active',
                'QR CODE ACTIVE'
            );


            $('#qrExpiredOverlay')
                .hide();


            startAttendanceQrCountdown();


        } catch (error) {

            console.error(
                'Attendance QR Error:',
                error
            );


            showQrLoading(false);


            setQrStatus(
                'error',
                'QR GENERATION FAILED'
            );


            /*
             * Retry automatically.
             */
            attendanceQrRefreshTimer =
                setTimeout(
                    generateNewAttendanceQr,
                    5000
                );


        } finally {

            attendanceQrRequestRunning = false;
        }
    }


    /* =========================================================
       SERVER DATE PARSER
    ========================================================== */

    function parseServerDate(value) {

        if (!value) {
            return null;
        }


        /*
         * ISO / timezone aware value.
         */
        let parsed =
            new Date(value).getTime();


        if (!Number.isNaN(parsed)) {
            return parsed;
        }


        /*
         * Laravel datetime:
         * YYYY-MM-DD HH:mm:ss
         */
        parsed =
            new Date(
                value.replace(
                    ' ',
                    'T'
                )
            ).getTime();


        return parsed;
    }


    /* =========================================================
       COUNTDOWN
    ========================================================== */

    function startAttendanceQrCountdown() {

        clearInterval(
            attendanceQrTimer
        );


        updateAttendanceQrCountdown();


        attendanceQrTimer =
            setInterval(
                updateAttendanceQrCountdown,
                1000
            );
    }


    function updateAttendanceQrCountdown() {

        if (!attendanceQrExpiresAt) {
            return;
        }


        const now =
            Date.now();


        const remaining =
            Math.max(
                0,
                attendanceQrExpiresAt - now
            );


        const totalSeconds =
            Math.ceil(
                remaining / 1000
            );


        const minutes =
            Math.floor(
                totalSeconds / 60
            );


        const seconds =
            totalSeconds % 60;


        const formatted =
            String(minutes)
                .padStart(2, '0')
            +
            ':'
            +
            String(seconds)
                .padStart(2, '0');


        $('#qrCountdown')
            .text(formatted);


        /* -----------------------------------------
           PROGRESS
        ------------------------------------------ */

        const totalDuration =
            ATTENDANCE_QR_DURATION_SECONDS * 1000;


        const percentage =
            Math.max(
                0,
                Math.min(
                    100,
                    (
                        remaining /
                        totalDuration
                    ) * 100
                )
            );


        $('#qrProgressBar')
            .css(
                'width',
                percentage + '%'
            );


        /* -----------------------------------------
           WARNING STATES
        ------------------------------------------ */

        $('#qrCountdown')
            .removeClass(
                'warning danger'
            );


        if (totalSeconds <= 60) {

            $('#qrCountdown')
                .addClass('danger');

        } else if (totalSeconds <= 180) {

            $('#qrCountdown')
                .addClass('warning');
        }


        /* -----------------------------------------
           EXPIRED
        ------------------------------------------ */

        if (remaining <= 0) {

            handleAttendanceQrExpired();
        }
    }


    /* =========================================================
       EXPIRED
    ========================================================== */

    function handleAttendanceQrExpired() {

        clearInterval(
            attendanceQrTimer
        );


        attendanceQrTimer = null;


        $('#qrCountdown')
            .text('00:00')
            .removeClass('warning')
            .addClass('danger');


        $('#qrProgressBar')
            .css(
                'width',
                '0%'
            );


        $('#qrExpiredOverlay')
            .css(
                'display',
                'flex'
            );


        setQrStatus(
            'expired',
            'QR CODE REFRESHING'
        );


        if (attendanceQrRefreshTimer) {

            clearTimeout(
                attendanceQrRefreshTimer
            );
        }


        attendanceQrRefreshTimer =
            setTimeout(
                function () {

                    attendanceQrRefreshTimer = null;

                    generateNewAttendanceQr();

                },
                1000
            );
    }


    /* =========================================================
       STATUS
    ========================================================== */

    function setQrStatus(
        status,
        text
    ) {

        const statusElement =
            $('#qrLiveStatus');


        $('#qrStatusText')
            .text(text);


        if (status === 'active') {

            statusElement.css({
                background: '#ecfdf3',
                color: '#15803d',
                borderColor: '#bbf7d0'
            });


            $('.qr-live-dot').css({
                background: '#16a34a'
            });


        } else if (status === 'expired') {

            statusElement.css({
                background: '#fff7ed',
                color: '#c2410c',
                borderColor: '#fed7aa'
            });


            $('.qr-live-dot').css({
                background: '#f59e0b'
            });


        } else {

            statusElement.css({
                background: '#fef2f2',
                color: '#b91c1c',
                borderColor: '#fecaca'
            });


            $('.qr-live-dot').css({
                background: '#dc2626'
            });
        }
    }


    /* =========================================================
       LOADING
    ========================================================== */

    function showQrLoading(show) {

        if (show) {

            $('#qrImage')
                .hide();


            $('#qrLoading')
                .css(
                    'display',
                    'flex'
                );

        } else {

            $('#qrLoading')
                .hide();


            $('#qrImage')
                .show();
        }
    }


    /* =========================================================
       RESET
    ========================================================== */

    function resetAttendanceQrUI() {

        attendanceQrExpiresAt = null;
        attendanceQrGeneratedAt = null;


        $('#qrImage')
            .hide();


        $('#qrLoading')
            .css(
                'display',
                'flex'
            );


        $('#qrExpiredOverlay')
            .hide();


        $('#qrCountdown')
            .removeClass(
                'warning danger'
            )
            .text('--:--');


        $('#qrProgressBar')
            .css(
                'width',
                '100%'
            );


        $('#qrDate')
            .text('--');


        $('#qrGeneratedAt')
            .text('--');


        $('#qrExpiresAt')
            .text('--');


        $('#download_qr_code_name')
            .val('');


        setQrStatus(
            'active',
            'GENERATING SECURE QR'
        );
    }


    /* =========================================================
       CLEAR TIMERS
    ========================================================== */

    function clearAttendanceQrTimers() {

        if (attendanceQrTimer) {

            clearInterval(
                attendanceQrTimer
            );


            attendanceQrTimer = null;
        }


        if (attendanceQrRefreshTimer) {

            clearTimeout(
                attendanceQrRefreshTimer
            );


            attendanceQrRefreshTimer = null;
        }
    }


    /* =========================================================
       DATE HELPERS
    ========================================================== */

    function formatCurrentDate() {

        return new Date()
            .toLocaleDateString(
                [],
                {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                }
            );
    }


    function formatCurrentTime() {

        return new Date()
            .toLocaleTimeString(
                [],
                {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                }
            );
    }


    function formatDateTime(value) {

        const date =
            new Date(value);


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return value || '--';
        }


        return date.toLocaleTimeString(
            [],
            {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            }
        );
    }


    /* =========================================================
       TAB VISIBILITY
    ========================================================== */

    document.addEventListener(
        'visibilitychange',
        function () {

            if (
                document.visibilityState !==
                'visible'
            ) {
                return;
            }


            /*
             * Browser may throttle timers when
             * TV/tablet tab is inactive.
             *
             * Revalidate QR when display becomes active.
             */
            if (
                !attendanceQrExpiresAt ||
                Date.now() >= attendanceQrExpiresAt
            ) {

                clearAttendanceQrTimers();

                generateNewAttendanceQr();

            } else {

                /*
                 * Re-sync countdown immediately.
                 */
                startAttendanceQrCountdown();
            }
        }
    );


    /* =========================================================
       NETWORK RECOVERY
    ========================================================== */

    window.addEventListener(
        'online',
        function () {

            if (
                !attendanceQrExpiresAt ||
                Date.now() >= attendanceQrExpiresAt
            ) {

                clearAttendanceQrTimers();

                generateNewAttendanceQr();
            }
        }
    );


    /* =========================================================
       CLEANUP
    ========================================================== */

    window.addEventListener(
        'beforeunload',
        function () {

            clearAttendanceQrTimers();
        }
    );


    /* =========================================================
       START
    ========================================================== */

    document.addEventListener(
        'DOMContentLoaded',
        function () {

            generateQr();
        }
    );

</script>

@endsection