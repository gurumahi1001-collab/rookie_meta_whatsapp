@extends('layouts/layoutMaster')

@section('title', 'Manage Onboarding')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss', 
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/dropzone/dropzone.js', 
])
@endsection

@section('page-script')
    @vite('resources/assets/js/forms-file-upload.js')
@endsection

@section('content')
<style>
   .circular-progress {
        --progress: 50;
        --deg: calc((var(--progress) / 100) * 360deg);
        width: 60px;
        height: 60px;
        border-radius: 50%;
        position: relative;
        margin: 1em auto;
        background: conic-gradient(#E0E0E0 var(--deg), #E0E0E0 0deg);
        box-shadow: 0 2px 5px rgba(0,0,0,0.16), 0 2px 10px rgba(0,0,0,0.12);
        transition: all .4s linear;
    }

    .circular-progress::before {
        content: attr(data-progress) '%';
        position: absolute;
        inset: 0;
        margin: auto;
        width: 85%;
        height: 85%;
        background: var(--inner-color, #ab2b22);
        border-radius: 50%;
        font-size: 14px;
        color: rgba(0, 0, 0, 0.95);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        box-shadow: inset 0 2px 5px rgba(0,0,0,0.2);
        transition: background 0.4s ease;
    }

    .table-responsive {
        overflow-x: auto;
        position: relative;
    }

    .table thead th,
    .table tbody td {
        white-space: nowrap;
    }

    .sticky-col {
        position: sticky;
        z-index: 5;
    }

    .left-col {
        left: 0;
        z-index: 10;
        box-shadow: 3px 0 5px -2px rgba(0,0,0,0.1);
    }

    .right-col {
        right: 0;
        z-index: 10;
        box-shadow: -3px 0 5px -2px rgba(0,0,0,0.1);
    }

        /* Optional: Adjust scrollbar appearance */
    .table-responsive::-webkit-scrollbar {
        height: 8px;
    }
    .table-responsive::-webkit-scrollbar-thumb {
        background-color: #bdbdbd;
        border-radius: 10px;
    }

</style>
<style>
    .timeline-container {
        position: relative;
    }
    .timeline-item {
        position: relative;
    }
    .timeline-icon {
        position: relative;
    }
    .timeline-line {
        margin-top: 2px;
        flex-grow: 1;
    }

    .timeline-item {
        border-left: 0px !important;
    }

    .dropzone .file-previews {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        /* space between files */
        margin-top: 10px;
    }

    .icon-badge {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 8px;
        border-radius: 50%;
        background: #e5e7eb; /* bg-gray-200 */
        cursor: pointer;
    }

    .success-check {
        position: absolute;
        top: -10px;
        left: 20px;
        width: 24px;
        height: 24px;
        background: #22c55e; /* green */
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        border: 2px solid #fff; /* clean overlap */
    }

    /* Optional hover polish */
    .icon-badge:hover {
        background: #d1d5db;
    }

</style>
@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<!-- Lead List Table -->
 <div class="card card-action mb-2" style="box-shadow: none;">
    <div class="card-header border-bottom pb-0 mb-0 d-flex align-items-center justify-content-between">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Manage Onboarding</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR Enroll
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a>
        </div>
    </div>
</div>
<div class="row g-2 mb-4">
    <!-- <div class="col-lg-2">
        <div class="card rounded p-3" style="box-shadow: none;border: 1px solid #dbdbdb;">
            <div class="d-flex align-items-center justify-content-between gap-5">
                <div class="d-flex flex-column">
                    <label class="fw-semibold fs-6 text-black">Total Staff</label>
                    <label class="fw-semibold fs-6 text-dark">01</label>
                </div>
                <img src="{{ asset('assets/egc_images/logo/logo_small.png') }}" alt="Company Logo" class="bg-gray-100 rounded w-px-50 h-px-50 border border-4 border-gray-200"/>
            </div>
        </div>
    </div> -->
</div>
<div class="card bg-transparent" style="box-shadow: none;">
    <div class="card-body p-0 m-0">
        <!-- <div class="row g-1">
            <div class="accordian" id="accordionStaff1">
                <div class="accordion-item mb-2 rounded">
                    <h2 class="accordion-header bg-white rounded p-2" id="headingOne">
                        <button
                            type="button"
                            class="accordion-button collapsed d-flex align-items-center justify-content-between"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordion1_1"
                            aria-expanded="false"
                            aria-controls="accordion1_1"
                        >
                            <div class="d-flex align-items-center gap-3 flex-grow-1">
                                <img src="{{ asset('assets/egc_images/auth/user_1.png') }}"
                                    class="w-75px h-75px bg-gray-300 px-2 py-2 rounded">
                                <div class="d-flex align-items-start flex-column justiy-content-start">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="text-black fs-6 fw-semibold">
                                            Kathiravan
                                        </label>
                                        <span class="bg-primary text-white badge rounded fs-8">Elysium Group of Companies</span>
                                    </div>
                                    <span class="fs-7 text-dark fw-medium">
                                        HR Executive
                                    </span>
                                    <div class="d-flex align-items-center gap-2 mt-1">
                                        <span class="badge bg-label-success text-success rounded fs-7">3 Completed</span>
                                        <span class="badge bg-label-warning text-warning fs-7 rounded">
                                            1 InProgress
                                        </span>
                                        <span class="badge bg-label-danger text-danger rounded fs-7">1 Not Started</span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-center gap-3 me-5">
                                <span class="icon-badge success-badge" data-bs-toggle="tooltip" title="Document Collection">
                                    <i class="mdi mdi-file-document-plus-outline fs-4 text-black"></i>
                                    <span class="success-check">
                                        <i class="mdi mdi-check"></i>
                                    </span>
                                </span>
                                <span class="icon-badge success-badge" data-bs-toggle="tooltip" title="HR Evaluation">
                                    <i class="mdi mdi-briefcase-account-outline fs-4 text-black"></i>
                                    <span class="success-check">
                                        <i class="mdi mdi-check"></i>
                                    </span>
                                </span>
                                <span class="icon-badge success-badge" data-bs-toggle="tooltip" title="Self Evaluation">
                                    <i class="mdi mdi-account-check-outline fs-4 text-black"></i>
                                    <span class="success-check">
                                        <i class="mdi mdi-check"></i>
                                    </span>
                                </span>
                                <span class="icon-badge success-badge" data-bs-toggle="tooltip" title="Training">
                                    <i class="mdi mdi-badge-account-horizontal-outline fs-4 text-black"></i>
                                </span>
                                <span class="icon-badge success-badge" data-bs-toggle="tooltip" title="Final Evaluation">
                                    <i class="mdi mdi-shield-account-variant-outline fs-4 text-black"></i>
                            </div>
                            <div class="d-flex align-items-center gap-3 me-3">
                                <div class="d-flex align-items-start flex-column">
                                    <div class="position-relative progress-circle"
                                        data-percent="65"
                                        style="width:70px;height:70px;">
                                        <svg width="70" height="70" viewBox="0 0 100 100">
                                            <circle
                                                cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke="#e9ecef"
                                                stroke-width="8"
                                            />
                                            <circle
                                                class="progress-ring"
                                                cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke-width="8"
                                                stroke-linecap="round"
                                                transform="rotate(-90 50 50)"
                                            />
                                        </svg>
                                        <div class="position-absolute top-50 start-50 translate-middle">
                                            <strong class="progress-text">65%</strong>
                                        </div>
                                    </div>
                                    <span class="fw-semibold text-black fs-6">Score: <b class="text-danger">85</b></span>
                                </div>
                                <div class="d-flex align-items-center flex-column justify-content-center gap-1">
                                    <span class="fw-semibold text-black fs-6">Stages</span>
                                    <span class="badge py-2 px-2 bg-label-dark text-dark rounded-pill fs-5">05</span>
                                </div>
                            </div>
                        </button>
                    </h2>
                    <div id="accordion1_1" class="accordion-collapse collapse" data-bs-parent="#accordionStaff1">
                        <div class="accordion-body bg-gray-200">
                            <div class="row g-1 p-2 px-2">
                                <div class="col-lg-12 mb-2 p-2">
                                   @php
                                    $evaluations = [
                                        (object)[
                                            'title' => 'Document Collection',
                                            'status' => 'Completed',
                                            'score' => 95,
                                            'date' => '2025-10-18',
                                            'join_date' => '2026-02-05',
                                            'evaluator' => [
                                                (object)[
                                                    'name' => 'Jane Doe',
                                                    'role' => 'HR Manager'
                                                ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'HR Evaluation',
                                            'status' => 'Completed',
                                            'score' => 84,
                                            'date' => '2025-10-25',
                                            'evaluator' => [
                                                (object)[
                                                    'name' => 'Rahul Kumar',
                                                    'role' => 'HR Lead'
                                                ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Self Evaluation',
                                            'status' => 'Completed',
                                            'score' => 38,
                                            'date' => '2025-11-02',
                                            'evaluator' => [
                                                (object)[
                                                    'name' => 'Employee (Self)',
                                                    'role' => 'Self'
                                                ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Training',
                                            'status' => 'In Progress',
                                            'score' => 67,
                                            'date' => null,
                                            'evaluator' => [
                                                (object)[
                                                    'name' => 'Training Team',
                                                    'role' => 'Trainer'
                                                ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Final Evaluation',
                                            'status' => 'Upcoming',
                                            'score' => 0,
                                            'date' => null,
                                            'evaluator' => ''
                                        ],
                                    ];
                                    @endphp
                                    <div class="timeline-container position-relative">
                                        @foreach($evaluations as $evaluation)
                                        @php
                                            // Define status colors
                                            switch($evaluation->status) {
                                                case 'Completed':
                                                    $color = 'success'; // green
                                                    $progress = $evaluation->score ?? 0;
                                                    $label = 'Excellent';
                                                    break;
                                                case 'In Progress':
                                                    $color = 'primary'; // blue
                                                    $progress = $evaluation->score ?? 0;
                                                    $label = 'Good';
                                                    break;
                                                case 'Upcoming':
                                                    $color = 'warning'; // orange
                                                    $progress = 0;
                                                    $label = 'Pending';
                                                    break;
                                                default:
                                                    $color = 'secondary';
                                                    $progress = 0;
                                                    $label = '';
                                            }
                                        @endphp
                                        <div class="timeline-item d-flex mb-4 position-relative">
                                            <div class="timeline-icon d-flex flex-column align-items-center me-3">
                                                <div class="rounded-circle bg-{{ $color }}" style="width:24px;height:24px;"></div>
                                                @if(!$loop->last)
                                                <div class="timeline-line flex-grow-1" style="width:2px;background:#dee2e6;"></div>
                                                @endif
                                            </div>
                                            <div class="timeline-content flex-grow-1 p-3 border rounded" 
                                                style="background:#fff;">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <h6 class="mb-0 fw-semibold text-dark">{{ $evaluation->title }}</h6>
                                                    <span class="fw-bold text-black">{{ $evaluation->score ?? 0 }}/100</span>
                                                </div>
                                                <div class="d-flex align-items-start justify-content-between mb-1">
                                                    <div class="d-flex align-items-center justify-content-start gap-2">
                                                        <span class="badge bg-{{ $color }} text-white">{{ $evaluation->status }}</span>
                                                        @if($evaluation->date)
                                                        <span class="ms-2 text-dark rounded badge fs-8 border border-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Date">{{ \Carbon\Carbon::parse($evaluation->date)->format('d-M-Y') }}</span>
                                                        @endif
                                                        @if($evaluation->title === 'Document Collection' && !empty($evaluation->join_date))
                                                            <span class="ms-2 rounded badge fs-8" style="color: #3f7cff; border: 1px solid #3f7cff;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining">
                                                                {{ \Carbon\Carbon::parse($evaluation->join_date)->format('d-M-Y') }}
                                                            </span>
                                                        @endif
                                                        @if($evaluation->title === 'HR Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_hr_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-file-document-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                        @if($evaluation->title === 'Self Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_self_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-account-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                    </div>
                                                    <div class="d-flex align-items-center gap-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reporting Person">
                                                        <img src="{{ asset('assets/egc_images/auth/user_1.png') }}"
                                                            class="w-35px h-35px border border-gray-700 rounded-circle">
                                                        @if(!empty($evaluation->evaluator))
                                                            @foreach ($evaluation->evaluator as $evaluator)
                                                                <div class="d-flex flex-column">
                                                                    <label class="text-black fs-7 fw-semibold">
                                                                        {{ $evaluator->name }}
                                                                    </label>
                                                                    <span class="text-dark fs-8 fw-semibold">
                                                                        {{ $evaluator->role }}
                                                                    </span>
                                                                </div>
                                                            @endforeach
                                                        @else
                                                            <span class="text-muted">Evaluator not assigned</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="progress" style="height:8px;">
                                                    <div class="progress-bar bg-{{ $color }}" role="progressbar" 
                                                        style="width: {{ $progress }}%;" aria-valuenow="{{ $progress }}" 
                                                        aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <small class="text-muted">{{ $label }}</small>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="accordian" id="accordionStaff2">
                <div class="accordion-item mb-2 rounded">
                    <h2 class="accordion-header bg-white rounded p-2" id="headingOne">
                        <button
                            type="button"
                            class="accordion-button collapsed d-flex align-items-center justify-content-between"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordion1_2"
                            aria-expanded="false"
                            aria-controls="accordion1_2"
                        >
                            <div class="d-flex align-items-center gap-3 flex-grow-1">
                                <img src="{{ asset('assets/egc_images/auth/user_7.png') }}"
                                    class="w-75px h-75px bg-gray-300 px-2 py-2 rounded">
                                <div class="d-flex align-items-start flex-column justiy-content-start">
                                    <div class="d-flex align-items-center gap-2">
                                        <label class="text-black fs-6 fw-semibold">
                                            Vani Shree
                                        </label>
                                        <span class="bg-primary text-white badge rounded fs-8">Elysium Group of Companies</span>
                                    </div>
                                    <span class="fs-7 text-dark fw-medium">
                                        Front Desk Executive
                                    </span>  
                                    <div class="d-flex align-items-center gap-2 mt-1">
                                        <span class="badge bg-label-success text-success rounded fs-7">0 Completed</span>
                                        <span class="badge bg-label-warning text-warning fs-7 rounded">
                                            1 InProgress
                                        </span>
                                        <span class="badge bg-label-danger text-danger rounded fs-7">4 Not Started</span>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-center gap-3 me-5">
                                <span class="icon-badge" data-bs-toggle="tooltip" title="Document Collection">
                                    <i class="mdi mdi-file-document-plus-outline fs-4 text-black"></i>
                                </span>
                                <span class="icon-badge" data-bs-toggle="tooltip" title="HR Evaluation">
                                    <i class="mdi mdi-briefcase-account-outline fs-4 text-black"></i>
                                </span>
                                <span class="icon-badge" data-bs-toggle="tooltip" title="Self Evaluation">
                                    <i class="mdi mdi-account-check-outline fs-4 text-black"></i>
                                </span>
                                <span class="icon-badge" data-bs-toggle="tooltip" title="Training">
                                    <i class="mdi mdi-badge-account-horizontal-outline fs-4 text-black"></i>
                                </span>
                                <span class="icon-badge" data-bs-toggle="tooltip" title="Final Evaluation">
                                    <i class="mdi mdi-shield-account-variant-outline fs-4 text-black"></i>
                            </div>
                            <div class="d-flex align-items-center gap-3 me-3">
                                <div class="d-flex align-items-start flex-column">
                                    <div class="position-relative progress-circle"
                                        data-percent="15"
                                        style="width:70px;height:70px;">
                                        <svg width="70" height="70" viewBox="0 0 100 100">
                                            <circle
                                                cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke="#e9ecef"
                                                stroke-width="8"
                                            />
                                            <circle
                                                class="progress-ring"
                                                cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke-width="8"
                                                stroke-linecap="round"
                                                transform="rotate(-90 50 50)"
                                            />
                                        </svg>
                                        <div class="position-absolute top-50 start-50 translate-middle">
                                            <strong class="progress-text">15%</strong>
                                        </div>
                                    </div>
                                    <span class="fw-semibold text-black fs-6">Score: <b class="text-danger">20</b></span>
                                </div>
                                <div class="d-flex align-items-center flex-column justify-content-center gap-1">
                                    <span class="fw-semibold text-black fs-6">Stages</span>
                                    <span class="badge py-2 px-2 bg-label-dark text-dark rounded-pill fs-5">05</span>
                                </div>
                            </div>
                        </button>
                    </h2>
                    <div id="accordion1_2" class="accordion-collapse collapse" data-bs-parent="#accordionStaff2">
                        <div class="accordion-body bg-gray-200">
                            <div class="row g-1 p-2 px-2">
                                <div class="col-lg-12 mb-2 p-2">
                                   @php
                                    $evaluations = [
                                        (object)[
                                            'title' => 'Document Collection',
                                            'status' => 'In Progress',
                                            'score' => 0,
                                            'date' => null,
                                            'join_date' => null,
                                            'evaluator' => [
                                                (object)[ 'name' => 'HR Admin', 'role' => 'HR Executive' ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'HR Evaluation',
                                            'status' => 'Not Started',
                                            'score' => 0,
                                            'date' => null,
                                            'evaluator' => [
                                                (object)[ 'name' => 'Rahul Kumar', 'role' => 'HR Manager' ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Self Evaluation',
                                            'status' => 'Not Started',
                                            'score' => 0,
                                            'date' => null,
                                            'evaluator' => [
                                                (object)[ 'name' => 'Employee (Self)', 'role' => 'Self Assessment' ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Training',
                                            'status' => 'Not Started',
                                            'score' => 0,
                                            'date' => null,
                                            'evaluator' => [
                                                (object)[ 'name' => 'Training Team', 'role' => 'Trainer' ]
                                            ]
                                        ],
                                        (object)[
                                            'title' => 'Final Evaluation',
                                            'status' => 'Not Started',
                                            'score' => 0,
                                            'date' => null,
                                            'evaluator' => [
                                                (object)[ 'name' => 'Evaluation Panel', 'role' => 'Management' ]
                                            ]
                                        ],
                                    ];
                                    @endphp
                                    <div class="timeline-container position-relative">
                                        @foreach($evaluations as $evaluation)
                                        @php
                                            // Define status colors
                                            switch($evaluation->status) {
                                                case 'Completed':
                                                    $color = 'success'; // green
                                                    $progress = $evaluation->score ?? 0;
                                                    $label = 'Excellent';
                                                    break;
                                                case 'In Progress':
                                                    $color = 'primary'; // blue
                                                    $progress = $evaluation->score ?? 0;
                                                    $label = 'Good';
                                                    break;
                                                case 'Upcoming':
                                                    $color = 'warning'; // orange
                                                    $progress = 0;
                                                    $label = 'Pending';
                                                    break;
                                                default:
                                                    $color = 'secondary';
                                                    $progress = 0;
                                                    $label = '';
                                            }
                                        @endphp
                                        <div class="timeline-item d-flex mb-4 position-relative">
                                            <div class="timeline-icon d-flex flex-column align-items-center me-3">
                                                <div class="rounded-circle bg-{{ $color }}" style="width:24px;height:24px;"></div>
                                                @if(!$loop->last)
                                                <div class="timeline-line flex-grow-1" style="width:2px;background:#dee2e6;"></div>
                                                @endif
                                            </div>
                                            <div class="timeline-content flex-grow-1 p-3 border rounded" 
                                                style="background:#fff;">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <h6 class="mb-0 fw-semibold text-dark">{{ $evaluation->title }}</h6>
                                                    <div class="d-flex align-items-center justify-content-end gap-3">
                                                        @if($evaluation->title === 'Document Collection' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_document_upload" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-tray-arrow-up fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                        @if($evaluation->title === 'HR Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_hr_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-file-document-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                        @if($evaluation->title === 'Self Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_self_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-account-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                        <span class="fw-bold text-black">{{ $evaluation->score ?? 0 }}/100</span>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-start justify-content-between mb-1">
                                                    <div class="d-flex align-items-center justify-content-start gap-2">
                                                        <span class="badge bg-{{ $color }} text-white">{{ $evaluation->status }}</span>
                                                        @if($evaluation->date)
                                                        <span class="ms-2 text-dark rounded badge fs-8 border border-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Date">{{ \Carbon\Carbon::parse($evaluation->date)->format('d-M-Y') }}</span>
                                                        @endif
                                                        @if($evaluation->title === 'Document Collection' && !empty($evaluation->join_date))
                                                            <span class="ms-2 rounded badge fs-8" style="color: #3f7cff; border: 1px solid #3f7cff;"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Date of Joining">
                                                                {{ \Carbon\Carbon::parse($evaluation->join_date)->format('d-M-Y') }}
                                                            </span>
                                                        @endif
                                                        @if($evaluation->title === 'HR Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_hr_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-file-document-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                        @if($evaluation->title === 'Self Evaluation' && 
                                                            ($evaluation->status === 'Upcoming' || $evaluation->status === 'In Progress' || $evaluation->status === 'Not Started'))
                                                            <a data-bs-toggle="modal" data-bs-target="#kt_modal_self_evaluation" class="bg-gray-300 rounded-circle p-2">
                                                                <i class="mdi mdi-account-check-outline fs-4 text-black"></i>
                                                            </a>
                                                        @endif
                                                    </div>
                                                    <div class="d-flex align-items-center gap-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reporting Person">
                                                        <img src="{{ asset('assets/egc_images/auth/user_1.png') }}"
                                                            class="w-35px h-35px border border-gray-700 rounded-circle">
                                                        @if(!empty($evaluation->evaluator))
                                                            @foreach ($evaluation->evaluator as $evaluator)
                                                                <div class="d-flex flex-column">
                                                                    <label class="text-black fs-7 fw-semibold">
                                                                        {{ $evaluator->name }}
                                                                    </label>
                                                                    <span class="text-dark fs-8 fw-semibold">
                                                                        {{ $evaluator->role }}
                                                                    </span>
                                                                </div>
                                                            @endforeach
                                                        @else
                                                            <span class="text-muted">Evaluator not assigned</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="progress" style="height:8px;">
                                                    <div class="progress-bar bg-{{ $color }}" role="progressbar" 
                                                        style="width: {{ $progress }}%;" aria-valuenow="{{ $progress }}" 
                                                        aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <small class="text-muted">{{ $label }}</small>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="row">                                           
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="{{ $search_filter }}"/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="list-table-body"></div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>




<!--begin::Modal - Delete Staff-->
<div class=" modal fade" id="kt_modal_delete_staff" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Mahesh </b> Staff ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Staff-->

<div class="modal fade" id="kt_modal_document_upload" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="row mb-2">
                    <h3 class="text-black">Document Upload</h3>
                </div>
                <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                    <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                            <img src="{{ asset('assets/egc_images/auth/user_7.png') }}"
                                alt="user-avatar"  class="w-px-50 h-auto rounded-circle"
                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <label class="fs-5 fw-semibold text-primary">Vani Shree</label>
                        <label class="fs-7 fw-semibold text-dark">Front Desk Excuetive</label>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-5 px-10 px-xl-20 bg-white">
                <div class="row pb-2" style="border-bottom: 1px solid #dbdbdb;">
                    <div class="col-lg-6 mb-2">
                        <label class="text-black fs-6 fw-semibold">Date of Joining<span class="text-danger">*</span></label>
                        <input type="text" class="form-control common_datepicker" placeholder="Enter Date of Joining">
                    </div>
                    <div class="col-lg-12 mb-2">
                        <label class="fw-semibold text-black fs-5">Attach Document</label>
                    </div>
                    <div class="col-lg-12 mb-3 scroll-y max-h-350px">
                        <div id="document-wrapper">
                            <div class="document-row bg-gray-200 rounded px-2 py-2 mb-2">
                                <div class="row">
                                    <div class="col-lg-11">
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Document Type</label>
                                                <select id="doc_type_0" name="doc_type[]"
                                                    class="select3 form-select required-field">
                                                    <option value="">Select Document Type</option>
                                                    <option value="1">Aadhaar Card</option>
                                                    <option value="2">Ration Card</option>
                                                    <option value="3">Resume</option>
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                                                <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff_0">
                                                    <div class="dz-message needsclick fs-6">
                                                        <div class="text-center text-black me-3">Drop files here or click
                                                            to upload</div>
                                                    </div>
                                                    <div class="fallback">
                                                        <input type="file" name="attachment[]" multiple
                                                            class="required-field" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 d-flex align-items-center mt-2 justify-content-center">
                                        <div class="d-flex align-items-end mb-2 justify-content-end">
                                            <a href="javascript:;" class="btn text-danger px-2 py-1 staff_doc_del"
                                                style="display: none !important;">
                                                <i class="fa-solid fa-trash-can fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="mb-1 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary" id="add-doc-btn">
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center py-4">
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <a href="{{ url('/hr_enroll/manage_staff/add_staff') }}" type="button" class="btn btn-primary me-3">Upload</a>
                    <!-- <button type="button" class="btn btn-primary me-3" id="" data-bs-dismiss="modal">Upload</button> -->
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Document Upload-->

<!--begin::Modal HR Evaluation--->
<div class="modal fade" id="kt_modal_hr_evaluation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="row mb-2">
                    <h3 class="text-black">HR Evaluation</h3>
                </div>
                <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                    <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true" >
                            <img src="{{ asset('assets/egc_images/auth/user_7.png') }}"
                                alt="user-avatar"  class="w-px-50 h-auto rounded-circle"
                                id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <label class="fs-5 fw-semibold text-primary">Vani Shree</label>
                        <label class="fs-7 fw-semibold text-dark">Front Desk Excuetive</label>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-5 px-10 px-xl-20 bg-white">
                <div class="row pb-2" style="border-bottom: 1px solid #dbdbdb;">
                    <div class="col-lg-12 mb-2">
                        @php
                            $hrQuestions = [
                                [
                                    'id' => 'qn_1',
                                    'question' => 'First Day Performance',
                                    'type' => 'radio',
                                    'options' => ['Excellent', 'Good', 'Average', 'Poor'],
                                    'score' => 10
                                ],
                                [
                                    'id' => 'qn_2',
                                    'question' => 'Team Collaboration',
                                    'type' => 'checkbox',
                                    'options' => ['Participates actively', 'Helps colleagues', 'Shares knowledge'],
                                    'score' => 15
                                ],
                                [
                                    'id' => 'qn_3',
                                    'question' => 'Communication Skills',
                                    'type' => 'text',
                                    'score' => 20
                                ],
                                [
                                    'id' => 'qn_4',
                                    'question' => 'Technical Skills Assessment',
                                    'type' => 'input',
                                    'placeholder' => 'Enter marks out of 20',
                                    'score' => 20
                                ],
                                [
                                    'id' => 'qn_5',
                                    'question' => 'Overall Feedback',
                                    'type' => 'textarea',
                                    'placeholder' => 'Provide feedback...',
                                    'score' => 15
                                ],
                            ];
                            @endphp

                            <div class="row">
                                @foreach($hrQuestions as $question)
                                <div class="col-lg-12 mb-3 border border-gray-200 bg-gray-100 rounded p-3">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <label class="fw-medium text-black fs-6">{{ $question['question'] }}</label>
                                        <span class="badge bg-info text-white">Score: {{ $question['score'] }}</span>
                                    </div>
                                    
                                    {{-- Radio Buttons --}}
                                    @if($question['type'] === 'radio')
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        @foreach($question['options'] as $option)
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="{{ $question['id'] }}" id="{{ $question['id'] }}_{{ strtolower($option) }}" value="{{ strtolower($option) }}" />
                                            <label class="form-check-label" for="{{ $question['id'] }}_{{ strtolower($option) }}">{{ $option }}</label>
                                        </div>
                                        @endforeach
                                    </div>
                                    @endif

                                    {{-- Checkboxes --}}
                                    @if($question['type'] === 'checkbox')
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        @foreach($question['options'] as $option)
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="{{ $question['id'] }}[]" id="{{ $question['id'] }}_{{ strtolower(str_replace(' ', '_', $option)) }}" value="{{ strtolower($option) }}" />
                                            <label class="form-check-label" for="{{ $question['id'] }}_{{ strtolower(str_replace(' ', '_', $option)) }}">{{ $option }}</label>
                                        </div>
                                        @endforeach
                                    </div>
                                    @endif

                                    {{-- Text Area --}}
                                    @if($question['type'] === 'textarea')
                                    <textarea class="form-control" name="{{ $question['id'] }}" placeholder="{{ $question['placeholder'] }}" rows="3"></textarea>
                                    @endif

                                    {{-- Input Field --}}
                                    @if($question['type'] === 'input')
                                    <input type="text" class="form-control" name="{{ $question['id'] }}" placeholder="{{ $question['placeholder'] }}" />
                                    @endif

                                    {{-- Text Input (alternative for text-type questions) --}}
                                    @if($question['type'] === 'text')
                                    <input type="text" class="form-control" name="{{ $question['id'] }}" placeholder="Enter your answer" />
                                    @endif
                                </div>
                                @endforeach
                            </div>
                        <!-- <div class="row mb-2">
                            <label class="fw-medium text-black fs-6">First Day Performance</label>
                            <div class="d-flex align-items-center justify-content-start gap-2">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="qn_1" id="qn_1_execellent" value="excellent" checked/>
                                    <label class="form-check-label" for="qn_1_execellent">Excellent</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="qn_1" id="qn_1_good" value="good" />
                                    <label class="form-check-label" for="qn_1_good">Good</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="qn_1" id="qn_1_average" value="average" />
                                    <label class="form-check-label" for="qn_1_average">Average</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="qn_1" id="qn_1_poor" value="poor" />
                                    <label class="form-check-label" for="qn_1_poor">Poor</label>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="col-lg-6 mb-2">
                        <label class="text-black fs-6 fw-semibold">Total Score<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Total Score">
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center py-4">
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary me-3" id="" data-bs-dismiss="modal">Submit Score</button>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - HR Evaluation-->

<!--begin::Modal Self Evaluation--->
<div class="modal fade" id="kt_modal_self_evaluation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="row mb-2">
                    <h3 class="text-black">Self Evaluation</h3>
                </div>
                <div class="d-flex align-items-center justify-content-start gap-2 mb-2">
                    <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true">
                            <img src="{{ asset('assets/egc_images/auth/user_7.png') }}"
                                alt="user-avatar"  class="w-px-50 h-auto rounded-circle"
                                style="border: 2px solid #ab2b22;"/>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <label class="fs-5 fw-semibold text-primary">Vani Shree</label>
                        <label class="fs-7 fw-semibold text-dark">Front Desk Executive</label>
                    </div>
                </div>
            </div>
            <!--end::Modal header-->

            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-5 px-10 px-xl-20 bg-white">
                @php
                    $selfQuestions = [
                        [
                            'id' => 'self_qn_1',
                            'question' => 'Task Completion Efficiency',
                            'type' => 'radio',
                            'options' => ['Excellent', 'Good', 'Average', 'Poor'],
                            'score' => 10
                        ],
                        [
                            'id' => 'self_qn_2',
                            'question' => 'Proactiveness in Work',
                            'type' => 'checkbox',
                            'options' => ['Takes initiative', 'Offers help', 'Suggests improvements'],
                            'score' => 15
                        ],
                        [
                            'id' => 'self_qn_3',
                            'question' => 'Time Management',
                            'type' => 'input',
                            'placeholder' => 'Enter marks out of 20',
                            'score' => 20
                        ],
                        [
                            'id' => 'self_qn_4',
                            'question' => 'Communication & Coordination',
                            'type' => 'text',
                            'score' => 15
                        ],
                        [
                            'id' => 'self_qn_5',
                            'question' => 'Self Feedback / Suggestions',
                            'type' => 'textarea',
                            'placeholder' => 'Provide feedback...',
                            'score' => 15
                        ],
                    ];
                @endphp

                <div class="row">
                    @foreach($selfQuestions as $question)
                    <div class="col-lg-12 mb-3 border border-gray-200 bg-gray-100 rounded p-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="fw-medium text-black fs-6">{{ $question['question'] }}</label>
                            <span class="badge bg-info text-white">Score: {{ $question['score'] }}</span>
                        </div>

                        {{-- Radio Buttons --}}
                        @if($question['type'] === 'radio')
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            @foreach($question['options'] as $option)
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="{{ $question['id'] }}" id="{{ $question['id'] }}_{{ strtolower($option) }}" value="{{ strtolower($option) }}" />
                                <label class="form-check-label" for="{{ $question['id'] }}_{{ strtolower($option) }}">{{ $option }}</label>
                            </div>
                            @endforeach
                        </div>
                        @endif

                        {{-- Checkboxes --}}
                        @if($question['type'] === 'checkbox')
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            @foreach($question['options'] as $option)
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="{{ $question['id'] }}[]" id="{{ $question['id'] }}_{{ strtolower(str_replace(' ', '_', $option)) }}" value="{{ strtolower($option) }}" />
                                <label class="form-check-label" for="{{ $question['id'] }}_{{ strtolower(str_replace(' ', '_', $option)) }}">{{ $option }}</label>
                            </div>
                            @endforeach
                        </div>
                        @endif

                        {{-- Input --}}
                        @if($question['type'] === 'input')
                        <input type="text" class="form-control" name="{{ $question['id'] }}" placeholder="{{ $question['placeholder'] }}" />
                        @endif

                        {{-- Text --}}
                        @if($question['type'] === 'text')
                        <input type="text" class="form-control" name="{{ $question['id'] }}" placeholder="Enter your answer" />
                        @endif

                        {{-- Textarea --}}
                        @if($question['type'] === 'textarea')
                        <textarea class="form-control" name="{{ $question['id'] }}" placeholder="{{ $question['placeholder'] }}" rows="3"></textarea>
                        @endif
                    </div>
                    @endforeach
                </div>

                {{-- Total Score --}}
                <div class="row mb-2">
                    <div class="col-lg-6">
                        <label class="text-black fs-6 fw-semibold">Total Score<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Total Score">
                    </div>
                </div>

                {{-- Modal Footer Buttons --}}
                <div class="d-flex justify-content-between align-items-center py-4">
                    <button type="reset" class="btn btn-outline-danger text-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary me-3" id="" data-bs-dismiss="modal">Submit Score</button>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>

<script>
$(document).ready(function () {
    // When "Select All" is toggled
    $('#selectAll').on('change', function () {
        $('.checklist-item').prop('checked', this.checked);
        this.indeterminate = false; // reset any mixed state
    });

    // When any individual checkbox is toggled
    $('.checklist-item').on('change', function () {
        const total = $('.checklist-item').length;
        const checked = $('.checklist-item:checked').length;

        if (checked === total) {
            // All checked
            $('#selectAll').prop('checked', true).prop('checked', true);
        } else if (checked === 0) {
            // None checked
            $('#selectAll').prop('checked', false).prop('checked', false);
        } else {
            // Some checked → checked
            $('#selectAll').prop('checked', false).prop('checked', false);
        }
    });
});
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
document.querySelectorAll('.progress-circle').forEach(circle => {
    const percent = parseInt(circle.dataset.percent);
    const progressRing = circle.querySelector('.progress-ring');
    const text = circle.querySelector('.progress-text');

    const radius = 45;
    const circumference = 2 * Math.PI * radius;

    const offset = circumference - (percent / 100) * circumference;

    // Apply stroke values
    progressRing.style.strokeDasharray = circumference;
    progressRing.style.strokeDashoffset = offset;

    // Change color & width based on percentage
    if (percent <= 30) {
        progressRing.style.stroke = '#dc3545'; // red
        progressRing.style.strokeWidth = '6';
    } 
    else if (percent <= 70) {
        progressRing.style.stroke = '#ffc107'; // yellow
        progressRing.style.strokeWidth = '8';
    } 
    else {
        progressRing.style.stroke = '#198754'; // green
        progressRing.style.strokeWidth = '10';
    }

    text.textContent = percent + '%';
});
</script>

<script>
    $(document).ready(function() {

        function initDropzone(selector, dropzoneElement) {
            let previewWrapper = dropzoneElement.find(".file-previews");
            if (previewWrapper.length === 0) {
                previewWrapper = $('<div class="file-previews"></div>');
                dropzoneElement.append(previewWrapper);
            }

            new Dropzone(selector, {
                url: "/fake-upload",
                autoProcessQueue: false,
                addRemoveLinks: true,
                init: function() {
                    this.on("addedfile", function(file) {
                        let filePreview = `<div class="file-preview">${file.name}</div>`;
                        previewWrapper.append(filePreview);
                    });
                    this.on("removedfile", function(file) {
                        previewWrapper.find(`.file-preview:contains('${file.name}')`)
                            .remove();
                    });
                }
            });
        }

        // Initialize first Dropzone
        initDropzone("#dropzone-multi_staff_0", $(".document-row:first .dropzone"));

        $("#add-doc-btn").click(function() {
            let cloneIndex = $("#document-wrapper .document-row").length;

            // Destroy select2 on the original before cloning
            let firstRowSelect = $(".document-row:first select");
            firstRowSelect.select2('destroy');

            let clone = $(".document-row:first").clone(false, false);

            // Reinitialize select2 on original
            firstRowSelect.select2();

            // Clear values and remove previous Dropzone previews
            clone.find("select").val("");
            clone.find(".select2-container").remove(); // Remove any leftover select2 containers
            clone.find(".dropzone .file-previews").remove();
            clone.find("input[type=file]").val("");
            clone.find(".staff_doc_del").show();

            // Update IDs
            clone.find("select").attr("id", `doc_type_${cloneIndex}`);
            clone.find(".dropzone").attr("id", `dropzone-multi_staff_${cloneIndex}`);

            // Append clone
            $("#document-wrapper").append(clone);

            // Initialize select2 for cloned select
            clone.find("select").select2();

            // Initialize Dropzone for cloned row
            initDropzone(`#dropzone-multi_staff_${cloneIndex}`, clone.find(".dropzone"));
        });

        // Delete row
        $(document).on("click", ".staff_doc_del", function() {
            $(this).closest(".document-row").remove();
        });

        // Initialize select2 for first row
        $("#doc_type_0").select2();
    });
</script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildStageIcons(item) {

        const stages = [
            {
                key: 'Document Collection',
                icon: 'mdi-file-document-plus-outline'
            },
            {
                key: 'HR Evaluation',
                icon: 'mdi-briefcase-account-outline'
            },
            {
                key: 'Self Evaluation',
                icon: 'mdi-account-check-outline'
            },
            {
                key: 'Training',
                icon: 'mdi-badge-account-horizontal-outline'
            },
            {
                key: 'Final Evaluation',
                icon: 'mdi-shield-account-variant-outline'
            }
        ];

        let html = '';

        stages.forEach(stage => {

            const completed =
                item.completed_stages &&
                item.completed_stages.includes(stage.key);

            html += `
            <span class="icon-badge ${completed ? 'success-badge' : ''}"
                data-bs-toggle="tooltip"
                title="${stage.key}">

                <i class="mdi ${stage.icon} fs-4 text-black"></i>

                ${completed ? `
                <span class="success-check">
                    <i class="mdi mdi-check"></i>
                </span>` : ''}
            </span>`;
        });

        return html;
    }

    function buildRow(item,index){

        const accordionId = `accordionStaff${item.id}`;
        const collapseId = `accordion_${item.id}`;

        return `
        <div class="accordion mb-2" id="${accordionId}">

            <div class="accordion-item rounded">

                <h2 class="accordion-header bg-white rounded p-2">

                    <button
                        type="button"
                        class="accordion-button collapsed d-flex align-items-center justify-content-between"
                        data-bs-toggle="collapse"
                        data-bs-target="#${collapseId}"
                        aria-expanded="false">

                        <div class="d-flex align-items-center gap-3 flex-grow-1">

                            <img src="/assets/egc_images/auth/user_1.png"
                                class="w-75px h-75px bg-gray-300 px-2 py-2 rounded">

                            <div class="d-flex flex-column">

                                <div class="d-flex align-items-center gap-2">

                                    <label class="text-black fs-6 fw-semibold">
                                        ${item.candidate_name}
                                    </label>

                                    <span class="bg-primary text-white badge rounded fs-8">
                                        ${item.entity_name || ''}
                                    </span>

                                </div>

                                <span class="fs-7 text-dark fw-medium">
                                    ${item.job_role || '-'}
                                </span>

                                <div class="d-flex align-items-center gap-2 mt-1">

                                    <span class="badge bg-label-success text-success rounded fs-7">
                                        ${item.completed || 0} Completed
                                    </span>

                                    <span class="badge bg-label-warning text-warning rounded fs-7">
                                        ${item.inprogress || 0} InProgress
                                    </span>

                                    <span class="badge bg-label-danger text-danger rounded fs-7">
                                        ${item.notstarted || 0} Not Started
                                    </span>

                                </div>

                            </div>

                        </div>

                        <div class="d-flex align-items-center justify-content-center gap-3 me-5">

                            ${buildStageIcons(item)}

                        </div>

                        <div class="d-flex align-items-center gap-3 me-3">

                            <div class="d-flex flex-column">

                                <div class="position-relative progress-circle"
                                    data-percent="${item.progress || 0}"
                                    style="width:70px;height:70px;">

                                    <svg width="70" height="70" viewBox="0 0 100 100">

                                        <circle cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke="#e9ecef"
                                                stroke-width="8"/>

                                        <circle class="progress-ring"
                                                cx="50"
                                                cy="50"
                                                r="45"
                                                fill="none"
                                                stroke-width="8"
                                                stroke-linecap="round"
                                                transform="rotate(-90 50 50)"/>

                                    </svg>

                                    <div class="position-absolute top-50 start-50 translate-middle">

                                        <strong class="progress-text">
                                            ${item.progress || 0}%
                                        </strong>

                                    </div>

                                </div>

                                <span class="fw-semibold text-black fs-6">
                                    Score:
                                    <b class="text-danger">${item.score || 0}</b>
                                </span>

                            </div>

                            <div class="d-flex flex-column align-items-center">

                                <span class="fw-semibold text-black fs-6">
                                    Stages
                                </span>

                                <span class="badge py-2 px-2 bg-label-dark text-dark rounded-pill fs-5">
                                    ${item.total_stages || 5}
                                </span>

                            </div>

                        </div>

                    </button>

                </h2>

                <div id="${collapseId}"
                    class="accordion-collapse collapse"
                    data-bs-parent="#${accordionId}">

                    <div class="accordion-body bg-gray-200">

                        ${buildTimeline(item)}

                    </div>

                </div>

            </div>

        </div>`;
    }

    function getStageActionButton(evaluation) {

    const pendingStatuses = [
        'Not Started',
        'In Progress',
        'Upcoming'
    ];

    if (!pendingStatuses.includes(evaluation.status)) {
        return '';
    }

    switch (evaluation.title) {

        case 'Document Collection':
            return `
                <a data-bs-toggle="modal"
                   data-bs-target="#kt_modal_document_upload"
                   class="bg-gray-300 rounded-circle p-2">

                    <i class="mdi mdi-tray-arrow-up fs-4 text-black"></i>

                </a>
            `;

        case 'HR Evaluation':
            return `
                <a data-bs-toggle="modal"
                   data-bs-target="#kt_modal_hr_evaluation"
                   class="bg-gray-300 rounded-circle p-2">

                    <i class="mdi mdi-file-document-check-outline fs-4 text-black"></i>

                </a>
            `;

        case 'Self Evaluation':
            return `
                <a data-bs-toggle="modal"
                   data-bs-target="#kt_modal_self_evaluation"
                   class="bg-gray-300 rounded-circle p-2">

                    <i class="mdi mdi-account-check-outline fs-4 text-black"></i>

                </a>
            `;

        case 'Training':
            return `
                <a data-bs-toggle="modal"
                   data-bs-target="#kt_modal_training"
                   class="bg-gray-300 rounded-circle p-2">

                    <i class="mdi mdi-badge-account-horizontal-outline fs-4 text-black"></i>

                </a>
            `;

        case 'Final Evaluation':
            return `
                <a data-bs-toggle="modal"
                   data-bs-target="#kt_modal_final_evaluation"
                   class="bg-gray-300 rounded-circle p-2">

                    <i class="mdi mdi-shield-account-variant-outline fs-4 text-black"></i>

                </a>
            `;

        default:
            return '';
    }
}

    function buildTimeline(item) {

        let html = '';

        if (!item.evaluations || item.evaluations.length === 0) {
            return `<div class="text-center text-muted">No Timeline Available</div>`;
        }

        item.evaluations.forEach((evaluation, index) => {

            let color = 'secondary';
            let label = '';

            switch (evaluation.status) {

                case 'Completed':
                    color = 'success';
                    label = 'Excellent';
                    break;

                case 'In Progress':
                    color = 'primary';
                    label = 'Good';
                    break;

                case 'Upcoming':
                    color = 'warning';
                    label = 'Pending';
                    break;

                case 'Not Started':
                    color = 'secondary';
                    label = 'Not Started';
                    break;
            }

            html += `
            <div class="timeline-item d-flex mb-4 position-relative">

                <div class="timeline-icon d-flex flex-column align-items-center me-3">

                    <div class="rounded-circle bg-${color}"
                        style="width:24px;height:24px;">
                    </div>

                    ${index !== item.evaluations.length - 1
                        ? `<div class="timeline-line flex-grow-1"
                                style="width:2px;background:#dee2e6;"></div>`
                        : ''
                    }

                </div>

                <div class="timeline-content flex-grow-1 p-3 border rounded bg-white">

                    <div class="d-flex justify-content-between align-items-start mb-2">

                        <h6 class="mb-0 fw-semibold text-dark">
                            ${evaluation.title}
                        </h6>

                        <div class="d-flex align-items-center gap-3">

                            ${getStageActionButton(evaluation)}

                            <span class="fw-bold text-black">
                                ${evaluation.score || 0}/100
                            </span>

                        </div>

                    </div>

                    <div class="d-flex justify-content-between mb-2">

                        <div class="d-flex align-items-center gap-2">

                            <span class="badge bg-${color}">
                                ${evaluation.status}
                            </span>

                            ${evaluation.date
                                ? `<span class="badge border border-dark text-dark">
                                        ${evaluation.date}
                                </span>`
                                : ''
                            }

                            ${evaluation.join_date
                                ? `<span class="badge"
                                        style="color:#3f7cff;border:1px solid #3f7cff;">
                                        ${evaluation.join_date}
                                </span>`
                                : ''
                            }

                        </div>

                        <div class="d-flex align-items-center gap-2">

                            <img src="/assets/egc_images/auth/user_1.png"
                                class="w-35px h-35px rounded-circle border">

                            <div>

                                <div class="fw-semibold fs-7">
                                    ${evaluation.evaluator_name || 'Not Assigned'}
                                </div>

                                <div class="fs-8 text-muted">
                                    ${evaluation.evaluator_role || ''}
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="progress" style="height:8px;">

                        <div class="progress-bar bg-${color}"
                            style="width:${evaluation.score || 0}%;">
                        </div>

                    </div>

                    <small class="text-muted">
                        ${label}
                    </small>

                </div>

            </div>`;
        });

        return html;
    }
   
    // function buildRow(item,index) {    
        
    //     var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
  

    //    return `
    //         <tr >
    //             <td style="position:relative;">
    //             <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.entity_base_color || ''};"></div>
    //                 <div class="fw-bold">${item.candidate_name}</div>
    //                 <small class="text-primary">${item.personal_email}</small><br>
    //                 <small>${item.mobile}</small>
    //             </td>

    //             <td>
    //                   <div>
    //                     <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #046d85 !important">
    //                         <span class="fs-7">${item.job_role || '-'}</span>
    //                     </label>
    //                   </div>  
    //                     <div class="d-flex gap-1">     
    //                         <label class="fw-semibold text-black fs-8 text-truncate d-block"
    //                             style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
    //                             data-bs-toggle="tooltip" data-bs-placement="bottom"
    //                             title="${item.department || '-'}">
    //                             ${item.department || '-'}
    //                         </label> 
    //                         <span>/</span>
    //                         <label class="fw-semibold fs-8 text-truncate text-dark d-block"
    //                             style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 100px;"
    //                             data-bs-toggle="tooltip" data-bs-placement="bottom"
    //                             title="${item.division || '-'}">
    //                             ${item.division || '-'}
    //                         </label>
    //                     </div> 
    //             </td>

    //             <td>
    //                 <span class="fw-semibold bg-label-primary">${item.doj ?? '-'}</span>
    //             </td>

    //             <td>
    //                 <span class="badge bg-info">
    //                     ${item.onboarding_step}
    //                 </span>
    //             </td>

    //             <td class="text-center">
    //                 <a data-bs-toggle="modal" data-bs-target="#kt_modal_onboard_checklist">
    //                     <span><i
    //                             class="mdi mdi-square-edit-outline fs-3 text-black "></i></span>
    //                 </a>
                    
    //             </td>
    //         </tr>`;
    // }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        // const company_fill = document.getElementById('company_fill').value;
        // const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        // const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        // const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        // const job_role_fill = document.getElementById('job_role_fill').value;
        // const division_fill = document.getElementById('division_fill').value;
        // const department_fill = document.getElementById('department_fill').value;
        // const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_enroll/onboarding_staff?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }

                setTimeout(() => {

                    document.querySelectorAll('.progress-circle').forEach(circle => {

                        const percent = parseInt(circle.dataset.percent);

                        const progressRing =
                            circle.querySelector('.progress-ring');

                        const radius = 45;

                        const circumference =
                            2 * Math.PI * radius;

                        const offset =
                            circumference -
                            (percent / 100) * circumference;

                        progressRing.style.strokeDasharray =
                            circumference;

                        progressRing.style.strokeDashoffset =
                            offset;

                        if(percent <= 30){
                            progressRing.style.stroke = '#dc3545';
                        }
                        else if(percent <= 70){
                            progressRing.style.stroke = '#ffc107';
                        }
                        else{
                            progressRing.style.stroke = '#198754';
                        }
                    });

                },100);
                    

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return '';
        // return `
        //     <tr class="skeleton-loader" id="skeleton-loader">
        //         <td class="skeleton-cell">
        //             <div class="skeleton"></div>
        //         </td>
        //         <td class="skeleton-cell">
        //             <div class="skeleton"></div>
        //         </td>
        //         <td class="skeleton-cell">
        //             <div class="skeleton"></div>
        //         </td>
        //         <td class="skeleton-cell">
        //             <div class="skeleton"></div>
        //         </td>
        //         <td class="skeleton-cell">
        //             <div class="skeleton"></div>
        //         </td>
        //     </tr>
        //     `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="6" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if(total == 0){
            start =0;
        }else{
            start=start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    //  document.getElementById('filterSubmit').addEventListener('click', function() {
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    // Initial load
    loadThemes(1);

</script>


@endsection