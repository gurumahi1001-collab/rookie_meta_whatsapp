@extends('layouts/layoutMaster')

@section('title', 'Manage 10X')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
    #achieveLoader {
        padding: 30px;
    }



.warrior-badge {
    width: 44px;
    height: 44px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    position: relative;
    z-index: 1;
    border-radius: 50% !important;
    color: #fff !important;
    /* Premium metallic gold */
    background:
        radial-gradient(
            circle at 30% 25%,
            #fff8c7 0%,
            #ffd84d 18%,
            #f5b800 45%,
            #d98b00 72%,
            #9b5b00 100%
        ) !important;
    border: 2px solid #fff1a8 !important;
    /* Luxury depth */
    box-shadow:
        0 0 0 2px #d89b00,
        0 0 0 4px rgba(255, 193, 7, 0.20),
        0 5px 12px rgba(130, 82, 0, 0.35),
        inset 0 2px 2px rgba(255, 255, 255, 0.8),
        inset 0 -3px 5px rgba(100, 50, 0, 0.25);
    transition:
        transform 0.3s ease,
        box-shadow 0.3s ease;
}

/* Trophy icon */
.warrior-badge i {
    font-size: 22px;
    line-height: 1;
    color: #fffdf0 !important;
    filter: drop-shadow(0 2px 1px rgba(90, 50, 0, 0.55));
    position: relative;
    z-index: 3;
}

/* OUTER GLOW RING */
.warrior-badge::after {
    content: "";
    position: absolute;
    inset: -5px;
    border-radius: 50%;
    border: 1px solid rgba(255, 193, 7, 0.55);
    box-shadow: 0 0 8px rgba(255, 193, 7, 0.35);
    z-index: -1;
    transition: all 0.3s ease;
}

/* PREMIUM LIGHT REFLECTION */
.warrior-badge::before {
    content: "";
    position: absolute;
    width: 18px;
    height: 8px;
    top: 6px;
    left: 8px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.65);
    filter: blur(1px);
    transform: rotate(-30deg);
    z-index: 2;
}


/* HOVER EFFECT */
.warrior-badge:hover {
    transform: translateY(-3px) scale(1.12);
    box-shadow:
        0 0 0 2px #ffd43b,
        0 0 0 5px rgba(255, 193, 7, 0.25),
        0 8px 20px rgba(150, 90, 0, 0.45),
        0 0 18px rgba(255, 193, 7, 0.55),
        inset 0 2px 3px rgba(255, 255, 255, 0.9);
}

.warrior-badge:hover::after {
    inset: -7px;
    border-color: rgba(255, 193, 7, 0.8);
    box-shadow: 0 0 14px rgba(255, 193, 7, 0.6);
}


/* OPTIONAL: SUBTLE PULSE */

.warrior-badge {
    animation: warriorGlow 3s ease-in-out infinite;
}

@keyframes warriorGlow {

    0%,
    100% {
        box-shadow:
            0 0 0 2px #d89b00,
            0 0 0 4px rgba(255, 193, 7, 0.20),
            0 5px 12px rgba(130, 82, 0, 0.35),
            inset 0 2px 2px rgba(255, 255, 255, 0.8),
            inset 0 -3px 5px rgba(100, 50, 0, 0.25);
    }

    50% {
        box-shadow:
            0 0 0 2px #ffd43b,
            0 0 0 5px rgba(255, 193, 7, 0.30),
            0 0 18px rgba(98, 255, 7, 0.45),
            0 6px 16px rgba(130, 82, 0, 0.4),
            inset 0 2px 3px rgba(255, 255, 255, 0.9);
    }
}
</style>
<style>

    /* .timeline-scroll{
        max-width:350px;
        overflow-x:auto;
        overflow-y:hidden;
        white-space:nowrap;

        scrollbar-width:none;
        -ms-overflow-style:none;

        scroll-behavior:smooth;
    }

    .timeline-scroll::-webkit-scrollbar{
        display:none;
    }

    .timeline-month{
        flex:0 0 auto;
    } */

    .timeline-scroll {
        width: 100%;
        max-width: 350px;

        display: flex;
        flex-wrap: nowrap;

        overflow-x: auto;
        overflow-y: hidden;

        white-space: nowrap;

        scrollbar-width: none;
        -ms-overflow-style: none;

        scroll-behavior: smooth;

        /* IMPORTANT: isolate timeline scrolling */
        overscroll-behavior: contain;

        /* Prevent flex/table layout from expanding */
        min-width: 0;

        /* Do not allow vertical movement */
        height: 78px;
        align-items: flex-start;
    }

    .timeline-scroll::-webkit-scrollbar {
        display: none;
    }

    .timeline-month {
        flex: 0 0 auto;
    }

    

    .warrior-card{
        min-width:120px;
        padding:12px;
    }

    .table-hover tbody tr:hover{
        transform:translateY(-2px);
        transition:.2s;
        box-shadow:0 6px 18px rgba(0,0,0,.08);
    }

    .timeline-badge{
        transition:.2s;
    }

    .timeline-badge:hover{
        transform:scale(1.15);
    }

    .list_page td{
        vertical-align:middle;
    }

    

    .warrior-icon{
        font-size:28px;
    }
    .tenx-card-highlight {
        background: linear-gradient(
            135deg,
            #fff9e6 0%,
            #fff3cd 100%
        );
    }

    /* .timeline-badge {
        min-width: 55px;
    } */

  

    .warrior-glow {
        animation: pulseGlow 2s infinite;
    }

    @keyframes pulseGlow {

        0% {
            box-shadow: 0 0 0 rgba(255,193,7,.4);
        }

        50% {
            box-shadow: 0 0 20px rgba(255,193,7,.8);
        }

        100% {
            box-shadow: 0 0 0 rgba(255,193,7,.4);
        }
    }
</style>
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage 10X</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i>HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR SIB
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                
                <button type="button" class="btn btn-sm btn-primary" id="openAchieveModal">
                    <i class="mdi mdi-trophy me-1"></i> Assign 10X
                </button>

                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>

                <!-- <input type="text" id="global_year_picker" class="form-control w-100px" value="< ?php echo date('Y') ?>" onchange="loadThemes(1)"> -->
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" >{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2" id="entity_fill_div">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>

                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">
                        Month Filter
                    </label>

                    <select id="month_filter_mode"
                            name="month_filter_mode"
                            class="form-select">
                        <option value="all" selected>All</option>
                        <option value="single">Single Month</option>
                        <option value="custom">Custom Months</option>
                    </select>
                </div>

                <div class="col-lg-4 mb-2 d-none" id="single_month_wrapper">
                    <label class="text-black mb-1 fs-6 fw-semibold">
                        Select Month
                    </label>

                    <input type="text"
                        id="single_month"
                        class="form-control"
                        placeholder="Select Month"
                        autocomplete="off"
                        readonly>
                </div>

                <div class="col-lg-4 mb-2 d-none" id="custom_month_wrapper">
                    <label class="text-black mb-1 fs-6 fw-semibold">
                        Select Months
                    </label>

                    <input type="text"
                        id="custom_months"
                        class="form-control"
                        placeholder="Select multiple months"
                        autocomplete="off"
                        readonly>
                </div>
                
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_sib/manage_tenx') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row g-3 mb-4">

            <div class="col-xl-3 col-md-6">
                <div class="card shadow-sm  h-100 dashboard-filter-card"
                    data-dashboard-filter="this_month_10x"
                    role="button">

                    <div class="card-body d-flex align-items-center">
                        <div class="avatar avatar-md me-3 bg-label-primary rounded d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-trophy-outline fs-3"></i>
                        </div>

                        <div>
                            <small class="text-muted fw-semibold">
                                This Month 10X
                            </small>

                            <h3 class="mb-0 fw-bold"
                                id="count_this_month_10x">
                                0
                            </h3>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-md-6">
                <div class="card shadow-sm border-0 h-100 dashboard-filter-card"
                    data-dashboard-filter="last_month_10x"
                    role="button">

                    <div class="card-body d-flex align-items-center">
                        <div class="avatar avatar-md me-3 bg-label-warning rounded d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-trophy-outline fs-3"></i>
                        </div>

                        <div>
                            <small class="text-muted fw-semibold">
                                Last Month 10X
                            </small>

                            <h3 class="mb-0 fw-bold"
                                id="count_last_month_10x">
                                0
                            </h3>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-md-6">
                <div class="card shadow-sm border-0 h-100 dashboard-filter-card"
                    data-dashboard-filter="this_month_warrior"
                    role="button">

                    <div class="card-body d-flex align-items-center">
                        <div class="avatar avatar-md me-3 bg-label-success rounded d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-shield-star-outline fs-3"></i>
                        </div>

                        <div>
                            <small class="text-muted fw-semibold">
                                This Month 10X Warrior
                            </small>

                            <h3 class="mb-0 fw-bold"
                                id="count_this_month_warrior">
                                0
                            </h3>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-md-6">
                <div class="card shadow-sm border-0 h-100 dashboard-filter-card"
                    data-dashboard-filter="last_month_warrior"
                    role="button">

                    <div class="card-body d-flex align-items-center">
                        <div class="avatar avatar-md me-3 bg-label-danger rounded d-flex align-items-center justify-content-center">
                            <i class="mdi mdi-shield-star-outline fs-3"></i>
                        </div>

                        <div>
                            <small class="text-muted fw-semibold">
                                Last Month 10X Warrior
                            </small>

                            <h3 class="mb-0 fw-bold"
                                id="count_last_month_warrior">
                                0
                            </h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [6,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Company..."
                                value="" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive ">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead class="sticky-top">
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <!-- <th width="50">#</th>
                                 <th width="300"><i class="mdi mdi-account-star"></i>Staff</th>
                                <th class="text-center"><i class="mdi mdi-trophy"></i>Total 10X</th>
                                <th class="text-center"><i class="mdi mdi-fire-circle"></i>Current Streak</th>
                                <th class="text-center"><i class="mdi mdi-fire"></i>Best Streak</th>
                                <th class="text-center"><i class="mdi mdi-shield-crown"></i>Warrior Level</th>
                                <th width="500"><i class="mdi mdi-chart-timeline"></i>Achievement Timeline</th>
                                <th class="text-center"><i class="mdi mdi-calendar-check"></i>Latest</th> -->
                               
                                 <th width="300">Staff</th>
                                <th class="text-center text-nowrap">Total 10X</th>
                                <th class="text-center text-nowrap">Current Streak</th>
                                <th class="text-center text-nowrap">Best Streak</th>
                                <th width="500">Achievements</th>
                                <th class="text-center">Latest</th>
                            </tr>
                        </thead>
                        <tbody id="company-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table> 
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>




<div class="modal fade" id="achieveModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="text-black fs-3 fw-bold">Assign Staff 10X</span>
                </div>
                <div class=" mb-3">
                    <div class="row g-2">

                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">

                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label>Entity</label>
                        <select id="entitySelect" class="form-select select3" onchange="changeEntity()">
                            <option value="">Select Entity</option>
                            @if(isset($entity_list))
                            @foreach($entity_list as $e)
                            <option value="{{ $e->sno }}" data-baseurl="{{ $e->entity_base_url }}">{{ $e->entity_name }}</option>
                            @endforeach
                            @endif
                        </select>
                    </div>

                    <div class=" col-md-3">
                        <label>Branch</label>
                        <select id="branchSelect" class="form-select select3">
                            <option value="">Select Branch</option>
                        </select>
                    </div>
                    <div class=" col-md-3">
                        <label>Department</label>
                        <select id="department_id" class="form-select select3" onchange="changeDepart()">
                            <option value="">Select Department</option>
                        </select>
                    </div>
                    <div class=" col-md-3">
                        <label>Staff</label>
                        <select id="tenx_staff" class="form-select select3" onchange="staffChange()">
                            <option value="">Select Staff</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <h4>Staff profile</h4>
                        <div id="staffProfile"></div>
                    </div>
                    <div class="col-lg-6">
                        <h4>10X Award</h4>
                        <div class="row">
                            <div class="col-lg-6">
                                <div id="tenx_month">
                                    <label for="month_year">Month</label>
                                    <input class="form-control mb-2" type="text" id="month_year" name="month_year" value="{{date('M-Y')}}" readonly>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div id="amount">
                                    <label for="tenx_remarks">10x Amount</label>
                                    <input class="form-control mb-2" type="text" id="tenx_amount" name="tenx_amount" value="1000">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div id="remarks">
                                    <label for="tenx_remarks">Remarks</label>
                                    <textarea class="form-control mb-2" name="tenx_remarks" id="tenx_remarks" row="2"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="text-end mt-3">
                                    <button class="btn btn-success px-4 d-none" id="saveAchieveBtn">
                                        <i class="mdi mdi-check-circle-outline"></i>Update 10X
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<script>

    const months = [{
            name: 'April',
            q: 'Q1'
        }, {
            name: 'May',
            q: 'Q1'
        }, {
            name: 'June',
            q: 'Q1'
        },
        {
            name: 'July',
            q: 'Q2'
        }, {
            name: 'August',
            q: 'Q2'
        }, {
            name: 'September',
            q: 'Q2'
        },
        {
            name: 'October',
            q: 'Q3'
        }, {
            name: 'November',
            q: 'Q3'
        }, {
            name: 'December',
            q: 'Q3'
        },
        {
            name: 'January',
            q: 'Q4'
        }, {
            name: 'February',
            q: 'Q4'
        }, {
            name: 'March',
            q: 'Q4'
        }
    ];
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {

        let avatar = item.staff_image
            ? `
                <img src="${item.staff_image}" 
                                    alt="user-avatar"  
                                    class="rounded-circle"
                                    style="width:50px; height:50px; object-fit:fill;" />
            `
            : `
                <div class="rounded-circle bg-primary text-white fw-bold d-flex align-items-center justify-content-center"
                    style="width:50px;height:50px;font-size:22px;">
                    ${item.staff_name.charAt(0).toUpperCase()}
                </div>
            `;

        let warriorClass = '';
        let warriorIcon = '';
        let warriorBadge = '';

        const warriorConfig = {

            'Legend Warrior': {
                color: '#212529',
                icon: '👑'
            },

            'Elite Warrior': {
                color: '#0d6efd',
                icon: '🥇'
            },

            '10X Warrior': {
                color: '#198754',
                icon: '🏆'
            },

            'Rising Star': {
                color: '#0dcaf0',
                icon: '🚀'
            }
        };

        const warrior =
            warriorConfig[item.warrior_title] ||
            warriorConfig['Rising Star'];

        let warriorCard = `
            <div class="warrior-card ">

                <div
                    class="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center text-white"
                    style="
                        width:50px;
                        height:50px;
                        background:${warrior.color};
                        font-size:22px;
                    ">
                    ${warrior.icon}
                </div>

                <div class="fw-bold">
                    ${item.warrior_title}
                </div>

                <small class="text-muted">
                    Active Streak:
                    ${item.current_streak}
                </small>

            </div>
            `;

        let timelineHtml = '';

        item.timeline.forEach(m => {

            let icon = '';
            let badgeClass = '';
            let tooltip = `${m.month}-${m.year}`;
            if (m.warrior_month) {
                icon = 'mdi-trophy';
                badgeClass = ' warrior-badge text-dark';
                tooltip += ' - 10X Warrior';
            }else if (m.elite_month) {

                icon = 'mdi-medal';
                badgeClass = 'bg-primary';
                tooltip += ' - Elite Warrior';

            }else if (m.legend_month) {
                icon = 'mdi-crown';
                badgeClass = 'bg-dark text-white';
                tooltip += ' - Legend Warrior';

            }else if (m.achieved) {
                icon = 'mdi-check-circle';
                badgeClass = 'bg-success';

            }else if(m.current){
                icon = 'mdi mdi-timer-sand';
                badgeClass = 'bg-info text-black';
                tooltip += ' - In Progress';

            }  else {

                icon = 'mdi-close-circle';
                badgeClass = 'bg-danger';
            }

            timelineHtml += `
                <div
                    class="timeline-month text-center me-1 mt-2
                    ${m.current ? 'current-month' : ''}"
                    data-bs-toggle="tooltip"
                    title="${tooltip}"
                >
                    <div class="badge ${badgeClass} rounded-circle p-2">
                        <i class="mdi ${icon}"></i>
                    </div>

                    <div class="small fw-semibold mt-1"
                        style="font-size:10px">
                        ${m.month}
                    </div>
                </div>
            `;
        });

        

        let achievementPercent =
            item.total_tenx_months > 0
                ? ((item.max_streak / item.total_tenx_months) * 100).toFixed(0)
                : 0;

           

        return `
            <tr>

                <td class="fw-bold" style="position:relative;">
                    <div style="position:absolute; left:0; top:0; bottom:0; width:5px; background:${item.company_base_color || '#6c757d'};"></div>
                    
                    <div class="d-flex align-items-center ps-2">
                        <!-- Staff Image -->
                        <div class="symbol symbol-40px me-3">
                            <div class="image-input image-input-circle">
                                ${avatar}
                            </div>
                        </div>

                        <!-- Staff Info -->
                        <div class="d-flex flex-column flex-grow-1">
                            <!-- Name + Gender Icon -->
                            <div class="d-flex align-items-center flex-wrap">
                                <span class="fs-7 fw-semibold me-2 text-truncate" style="max-width: 120px;" 
                                    data-bs-toggle="tooltip" title="${item.staff_name}">
                                    ${item.staff_name}
                                </span>

                                ${item.gender == 1 
                                    ? `<i class="mdi mdi-face-man text-info fs-7" data-bs-toggle="tooltip" title="Male"></i>` 
                                    : `<i class="mdi mdi-face-woman text-pink fs-7" data-bs-toggle="tooltip" title="Female"></i>`
                                }
                            </div>

                            <!-- Employee ID + Nickname -->
                            <div class="d-flex flex-wrap fs-8 text-truncate mb-1">
                                <span class="me-2 " style="color:rgb(114,57,234) !important;" data-bs-toggle="tooltip" title="Employee ID">${item.staff_code  || '-'}</span>
                                <span class="text-primary" data-bs-toggle="tooltip" title="Nickname">${item.nick_name || '-'}</span>
                            </div>

                            <!-- Company Badge -->
                            <span class="badge fs-8 fw-bold mb-1 text-truncate" 
                                style="background-color:${item.company_base_color || '#AB2B22'}; color:#fff; max-width:150px;"
                                data-bs-toggle="tooltip" title="${item.company_name || '-'}">
                                ${item.company_name || '-'}
                            </span>

                          
                            <!-- Job Role Badge (truncated) -->
                            <span class="badge bg-label-info fs-8 fw-bold text-truncate" 
                                style="color: #046d85 !important; max-width:150px;" 
                                data-bs-toggle="tooltip" title="${item.job_role_name || '-'}">
                                ${item.job_role_name || '-'}
                            </span>
                            <div class="mt-1">

                                <span class="badge bg-label-success me-1">
                                    Total:
                                    ${item.total_tenx_months}
                                </span>

                                <span class="badge bg-label-danger">
                                    Active:
                                    ${item.current_streak}
                                </span>

                            </div>
                        </div>
                    </div>
                </td>
                

                <td class="text-center">

                    <div class="fw-bold fs-3 text-success">
                        ${item.total_tenx_months}
                    </div>

                    <small class="text-muted">
                        Months
                    </small>

                </td>
                <td class="text-center">

                    <div
                        class="
                            rounded-circle
                            bg-warning
                            text-black
                            d-inline-flex
                            align-items-center
                            justify-content-center
                            fw-bold "
                        style="
                            width:50px;
                            height:50px;
                            font-size:22px;
                        "
                    >
                        ${item.current_streak}
                    </div>

                    <div class="mt-2 small text-muted">
                        Active Streak
                    </div>

                </td>

                <td class="text-center">

                    <div
                        class="
                            rounded-circle
                            bg-danger
                            text-white
                            d-inline-flex
                            align-items-center
                            justify-content-center
                            fw-bold
                        "
                        style="
                            width:50px;
                            height:50px;
                            font-size:22px;
                        "
                    >
                        ${item.max_streak}
                    </div>

                    <div class="mt-2 small text-muted">
                        Best Record
                    </div>

                </td>

                

                <td>
                    <div class="timeline-scroll d-flex flex-nowrap">
                        ${timelineHtml}
                    </div>
                </td>

                <td class="text-center ">

                        <div class="fw-bold text-danger text-nowrap">
                            ${item.last_achievement || '-'}
                        </div>

                        <div class="small text-muted ">
                            Latest 10X
                        </div>

                    </td>

            </tr>
        `;
    }

    function hexToRGBA(hex, opacity) {
        let r = 0,
            g = 0,
            b = 0;

        if (hex.length == 7) {
            r = parseInt(hex.substring(1, 3), 16);
            g = parseInt(hex.substring(3, 5), 16);
            b = parseInt(hex.substring(5, 7), 16);
        }

        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    }

    let activeDashboardFilter = '';

    function loadThemes(page = 1 , dashboardFilter = null) {

        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

       

        const monthMode = $('#month_filter_mode').val();
        const singleMonth = $('#single_month').val();
        let customMonths = [];

        if (monthMode === 'custom') {
            const customValue = $('#custom_months').val();

            if (customValue) {
                customMonths = customValue
                    .split(',')
                    .map(value => value.trim())
                    .filter(Boolean);
            }
        }

        if (dashboardFilter !== null) {
            activeDashboardFilter = dashboardFilter;
        }

        const params = new URLSearchParams();

        params.append('page', page);
        params.append('sorting_filter', perpage);

        params.append('search_filter', search);
        params.append('company_fill', company_fill);
        params.append('entity_fill', entity_fill);
        params.append('department_fill', department_fill);
        params.append('division_fill', division_fill);
        params.append('job_role_fill', job_role_fill);

        params.append('month_filter_mode', monthMode);

        if (monthMode === 'single' && singleMonth) {
            params.append('single_month', singleMonth);
        }

        customMonths.forEach(month => {
            params.append('custom_months[]', month);
        });

        
        if (activeDashboardFilter) {

            params.append(
                'dashboard_filter',
                activeDashboardFilter
            );
        }

        const url = `/hr_sib/manage_tenx?${params.toString()}`;

        // const url = `/hr_sib/manage_tenx?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}`;

       

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('company-table-body').innerHTML = ''; // Clear old data
        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {

                if (res.dashboard) {

                    $('#count_this_month_10x')
                        .text(res.dashboard.this_month_10x ?? 0);

                    $('#count_last_month_10x')
                        .text(res.dashboard.last_month_10x ?? 0);

                    $('#count_this_month_warrior')
                        .text(res.dashboard.this_month_warrior ?? 0);

                    $('#count_last_month_warrior')
                        .text(res.dashboard.last_month_warrior ?? 0);
                }
                // Insert new data into the table
                if (res.data.length > 0) {
                     const tableBody = document.getElementById('company-table-body');
                    res.data.forEach((item, index) => {
                        tableBody.insertAdjacentHTML(
                            'beforeend',
                            buildRow(item, index)
                        );
                    });

                    requestAnimationFrame(() => {

                        tableBody
                            .querySelectorAll('.timeline-scroll')
                            .forEach(container => {

                                scrollTimelineToCurrentMonth(
                                    container,
                                    false
                                );

                            });

                    });

                } else {
                    document.getElementById('company-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                // $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function scrollTimelineToCurrentMonth(container, smooth = true) {

        if (!container) {
            return;
        }

        const currentMonth = container.querySelector('.current-month');

        if (!currentMonth) {
            return;
        }

        const containerWidth = container.clientWidth;
        const currentMonthLeft = currentMonth.offsetLeft;
        const currentMonthWidth = currentMonth.offsetWidth;

        const targetScrollLeft =
            currentMonthLeft -
            ((containerWidth - currentMonthWidth) / 2);

        container.scrollTo({
            left: Math.max(0, targetScrollLeft),
            top: 0,
            behavior: smooth ? 'smooth' : 'auto'
        });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="6" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);
</script>


<script>
    function changeEntity() {
        var entity_id = $('#entitySelect').val();
        var branchDropdown = $('#branchSelect');
        var department = $('#department_id');
        var staffDrop = $('#tenx_staff');
        $('#staffProfile').html(
            defaultStaffProfileCard()
        );

        $('#saveAchieveBtn')
            .addClass('d-none');
        branchDropdown.empty().append('<option value="" >Select Branch</option>');
        department.empty().append('<option value="" >Select Department</option>');
        staffDrop.empty().append('<option value="" >Select Staff</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });

              $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                department.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
        }
    }

    function changeDepart()
    {
        let department_id = $('#department_id').val();
        $('#staffProfile').html(
            defaultStaffProfileCard()
        );

        $('#saveAchieveBtn')
            .addClass('d-none');

        $('#tenx_staff').empty().append('<option value="">Select Staff</option>');

        $.ajax({
            url: "{{ route('staff_list_by_department') }}",
            type: "GET",
            data: {
                department_id: department_id
            },
            success: function(res){

                let html = '<option value="">Select Staff</option>';
                res.data.forEach(staff => {
                    html += `
                        <option value="${staff.sno}">
                            ${staff.staff_name}
                            - ${staff.job_position_name}
                        </option>
                    `;
                });

                $('#tenx_staff').html(html);
            }
        });
    }

    function staffChange(){
       
        let staff_id = $('#tenx_staff').val();

        if(!staff_id){
            $('#staffProfile').html('');
            return;
        }

        loadStaffProfile(staff_id);

    }

    function profileSkeleton()
    {
        return `
            <div class="card shadow-sm border-0">

                <div class="card-body">

                    <div class="placeholder-glow">

                        <span class="placeholder rounded-circle"
                            style="width:80px;height:80px;"></span>

                        <div class="mt-3">

                            <span class="placeholder col-8"></span>
                            <span class="placeholder col-6"></span>
                            <span class="placeholder col-7"></span>
                            <span class="placeholder col-5"></span>

                        </div>

                    </div>

                </div>

            </div>
        `;
    }


    function loadStaffProfile(staff_id)
    {
        $('#staffProfile').html(profileSkeleton());

        $.ajax({

            url: "{{ route('staff_tenx_profile') }}",

            type: "GET",

            data: {
                staff_id: staff_id
            },

            success: function(res){

                let s = res.staff;

                $('#staffProfile').html(buildProfileCard(s));

                $('#saveAchieveBtn')
                    .removeClass('d-none');
            }
        });
    }


    function buildProfileCard(s)
    {
        return `

        <div class="card border-0 shadow-sm">

            <div class="card-body">

                <div class="d-flex align-items-center">

                    <img
                        src="${s.profile_image}"
                        class="rounded-circle border"
                        width="80"
                        height="80"
                    >

                    <div class="ms-3">

                        <h5 class="mb-1 fw-bold">
                            ${s.staff_name}
                        </h5>

                        <div class="text-muted">
                            ${s.nick_name || '-'}
                        </div>

                        <span
                            class="badge mt-1"
                            style="
                                background:${s.entity_base_color};
                                color:#fff;
                            "
                        >
                            ${s.entity_name}
                        </span>

                    </div>

                </div>

                <hr>

                <div class="row g-2">

                    <div class="col-6">
                        <small class="text-muted">
                            Staff Id
                        </small>
                        <div class="fw-bold">
                            ${s.staff_code}
                        </div>
                    </div>

                    <div class="col-6">
                        <small class="text-muted">
                            DOJ
                        </small>
                        <div class="fw-bold">
                            ${s.date_of_joining}
                        </div>
                    </div>

                    <div class="col-6">
                        <small class="text-muted">
                            Company
                        </small>
                        <div class="fw-bold">
                            ${s.company_name}
                        </div>
                    </div>

                    <div class="col-6">
                        <small class="text-muted">
                            Branch
                        </small>
                        <div class="fw-bold">
                            ${s.branch_name}
                        </div>
                    </div>

                    <div class="col-12">
                        <small class="text-muted">
                            Designation
                        </small>
                        <div class="fw-bold">
                            ${s.job_role_name}
                        </div>
                    </div>

                </div>

                <hr>

                <div
                    class="alert alert-warning mb-0">

                    <strong>
                        Last 10X Achievement
                    </strong>

                    <div class="fs-4 fw-bold">
                        🏆 ${s.last_tenx}
                    </div>

                </div>

            </div>

        </div>
        `;
    }
   
   function defaultStaffProfileCard()
{
    return `
        <div class="card border-0 shadow-sm h-100">

            <div class="card-body text-center py-8">

                <div
                    class="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                    style="
                        width:90px;
                        height:90px;
                        background:#f5f8fa;
                    "
                >
                    <i
                        class="mdi mdi-account-search-outline fs-1"
                        style=" color:#b5b5c3;"
                    ></i>
                </div>

                <h4 class="fw-bold text-gray-800">
                    Staff Profile
                </h4>

                <p class="text-muted mb-4">
                    Select Entity → Department → Staff
                    to view employee information and
                    assign 10X achievement.
                </p>

                <div class="row g-3 text-start">

                    <div class="col-6">
                        <div class="bg-light rounded p-3">

                            <small class="text-muted">
                                Staff Name
                            </small>

                            <div class="fw-semibold text-gray-500">
                                ---
                            </div>

                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded p-3">

                            <small class="text-muted">
                                Staff Id
                            </small>

                            <div class="fw-semibold text-gray-500">
                                ---
                            </div>

                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded p-3">

                            <small class="text-muted">
                                Company
                            </small>

                            <div class="fw-semibold text-gray-500">
                                ---
                            </div>

                        </div>
                    </div>

                    <div class="col-6">
                        <div class="bg-light rounded p-3">

                            <small class="text-muted">
                                Branch
                            </small>

                            <div class="fw-semibold text-gray-500">
                                ---
                            </div>

                        </div>
                    </div>
                    <div class="col-12">
                        <div class="bg-light rounded p-3">
                            <small class="text-muted">
                                Designation
                            </small>
                             <div class="fw-semibold text-gray-500">
                                ---
                            </div>

                        </div>
                    </div>

                    <div class="col-12">
                        <div class="alert alert-light border mb-0">

                            <i class="mdi mdi-information-outline me-2"></i>

                            Last 10X Achievement will be displayed here

                        </div>
                    </div>

                </div>

            </div>

        </div>
    `;
}
</script>
<script>
    // OPEN MODAL
    $('#openAchieveModal').click(function() {

        $('#staffProfile').html(
            defaultStaffProfileCard()
        );

        $('#saveAchieveBtn')
            .addClass('d-none');
        $('#tenx_remarks').val('');
        $('#tenx_amount').val('1000');
        $('#achieveModal').modal('show');
    });
</script>
<script>
    let abortIncentiveController = new AbortController();
    let loaderInterval = null;

    function updateLoader(percent) {

        const circle = document.querySelector('.loader-progress');

        const radius = 60;
        const circumference = 2 * Math.PI * radius;

        const offset = circumference - ((percent / 100) * circumference);

        circle.style.strokeDashoffset = offset;

        $('#loaderPercent').text(percent + '%');




    }
    // OPEN MODAL
    $('#openIncentiveModal').click(function() {
        $('#incentiveModal').modal('show');
        $('#incentiveDate').val(new Date().toISOString().split('T')[0]);
    });
    // FETCH ERP DATA
    $('#fetchIncentiveBtn').click(function() {

        let month_year = $('#month_year').val();
        const verifyKey = 'egcsecret2030datagetapierp';

        let entityId = $('#entityIncentive').val();
        let branchId = $('#branchIncentive').val();
        let baseurl = $('#entityIncentive option:selected').data('baseurl');
        let erpBranchId = $('#branchIncentive option:selected').data('erpbranchid');
        let role_id = $('#roleIncentive option:selected').data('erproleid');

        if (!entityId || !branchId || !baseurl || !erpBranchId || !role_id) {
            toastr.warning('Select Entity & Branch');
            return;
        }

        if (!month_year) {
            toastr.warning('Select Month');
            return;
        }

        $('#incentiveLoader').removeClass('d-none');

        $('#incentiveCards').html('');
        updateLoader(0);

        let progress = 0;

        clearInterval(loaderInterval);

        loaderInterval = setInterval(() => {

            if (progress < 92) {

                progress += Math.floor(Math.random() * 8) + 2;

                if (progress > 92) {
                    progress = 92;
                } else if (progress >= 92 && progress < 98) {

                    progress += 0.4;

                    if (progress > 98) {
                        progress = 98;
                    }
                }

                updateLoader(Math.floor(progress));

                // updateLoader(progress);
            }

        }, 400);

        // abort previous request
        if (abortIncentiveController.signal) {
            abortIncentiveController.abort();
        }

        abortIncentiveController = new AbortController();
        const url = baseurl + `api/get_incentive_by_role?branch_id=${erpBranchId}&verify_key=${verifyKey}&role_id=${role_id}&month_year=${month_year}`;

        fetch(url, {
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                },
                signal: abortIncentiveController.signal
            })
            .then(res => res.json())
            .then(res => {
                clearInterval(loaderInterval);
                updateLoader(100);

                setTimeout(() => {

                    $('#incentiveLoader').addClass('d-none');

                }, 500);

                let html = '';

                res.data.forEach((item, index) => {

                    let initials = item.staff_name
                        .split(' ')
                        .map(x => x[0])
                        .join('')
                        .substring(0, 2);

                    let total = parseFloat(item.total_award) || 0;

                    let zeroClass = total <= 0 ? 'zero-award' : '';

                    let breakdownHtml = '';

                    Object.entries(item.breakdown).forEach(([key, value]) => {

                        let percent = total > 0 ?
                            ((value / total) * 100) :
                            0;

                        breakdownHtml += `
                            <div class="break-item">

                                <div class="break-top">

                                    <div class="break-label">
                                        ${key}
                                    </div>

                                    <div class="break-value">
                                        ₹ ${new Intl.NumberFormat('en-IN').format(value)}
                                    </div>

                                </div>

                            </div>
                        `;
                    });

                    html += `
                        <div class="accordion-item ${zeroClass}">

                            <h2 class="accordion-header" id="heading${index}">

                                <button class="accordion-button collapsed"
                                    type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapse${index}">

                                    <div class="w-100">

                                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                            <!-- LEFT -->
                                            <div class="d-flex align-items-center gap-3">

                                                <div class="staff-avatar">
                                                    ${initials}
                                                </div>

                                                <div>

                                                    <div class="staff-name">
                                                        ${item.staff_name}
                                                    </div>

                                                    
                                                </div>

                                            </div>

                                            <!-- RIGHT -->
                                            <div class="d-flex align-items-center gap-3">

                                            

                                                <div class="reward-box">

                                                    <div class="reward-label">
                                                        Total Incentive
                                                    </div>

                                                    <div class="reward-value">
                                                        ₹ ${new Intl.NumberFormat('en-IN').format(total)}
                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </button>

                            </h2>

                            <div id="collapse${index}"
                                class="accordion-collapse collapse"
                                data-bs-parent="#incentiveCards">

                                <div class="accordion-body p-4">

                                    <!-- BREAKDOWN -->
                                    <div class="breakdown-grid">

                                        ${breakdownHtml}

                                    </div>

                                    <!-- FOOTER -->
                                    <div class="incentive-footer">

                                        <div class="d-flex flex-wrap gap-3">

                                            <div class="footer-chip">
                                                Updated :
                                                <strong>
                                                    ${item.last_updated}
                                                </strong>
                                            </div>

                                            <div class="footer-chip">
                                                Next Update :
                                                <strong>
                                                    ${item.next_update}
                                                </strong>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>
                    `;
                });

                $('#incentiveCards').html(html);

                html += `
                    <div class="text-end mt-5">
                        <button
                            type="button"
                            class="btn btn-success btn-lg"
                            onclick="saveIncentiveData()">
                            <i class="mdi mdi-content-save-all"></i>
                            Save Incentive Data
                        </button>
                    </div>
                    `;

                    $('#incentiveCards').html(html);

                $('#incentiveLoader').addClass('d-none');

                window.incentivePayload = res.data;
            }).catch(err => {
                clearInterval(loaderInterval);

                $('#incentiveLoader').addClass('d-none');
                if (err.name !== "AbortError") {

                    console.error(err);

                    $('#incentiveCards').html(`
                        <div class="alert alert-danger">
                            Failed to load incentive data
                        </div>
                    `);
                }
            });
    });


  
</script>


<script>
    $('#month_year').datepicker({
        format: 'M-yyyy',
        viewMode: 'months',
        minViewMode: 'months',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>

<script>
    $('#saveAchieveBtn').on('click', function () {

        const btn = $(this);

        const staffId = $('#tenx_staff').val();
        const monthYear = $('#month_year').val();
        const amount = $('#tenx_amount').val();
        const remarks = $('#tenx_remarks').val();

        if (!staffId) {
            toastr.warning('Please select a staff');
            return;
        }

        if (!monthYear) {
            toastr.warning('Please select month');
            return;
        }

        if (!amount || Number(amount) <= 0) {
            toastr.warning('Please enter valid 10X amount');
            return;
        }

        btn.prop('disabled', true);

        btn.html(`
            <span class="spinner-border spinner-border-sm me-2"></span>
            Saving...
        `);

        $.ajax({
            url: "{{ route('update_tenx_log') }}",
            type: "POST",
            dataType: "json",
            data: {
                _token: "{{ csrf_token() }}",
                staff_id: staffId,
                month_year: monthYear,
                amount: amount,
                remarks: remarks
            },
            success: function (response) {
                if (response.status === 200) {
                    toastr.success(response.message);
                    $('#saveAchieveBtn').html(`
                        <i class="mdi mdi-check-circle-outline"></i>
                        Update 10X
                    `);

                    setTimeout(() => {
                        $('#achieveModal').modal('hide');
                        loadThemes();
                    }, 1000);

                } else {
                    toastr.error(response.message || 'Something went wrong');
                }
            },

            error: function (xhr) {
                let message = 'Failed to update 10X';

                if (xhr.responseJSON) {

                    if (xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }

                    if (xhr.responseJSON.errors) {
                        message = Object.values(
                            xhr.responseJSON.errors
                        ).flat().join('<br>');
                    }
                }
                toastr.error(message);
            },

            complete: function () {

                btn.prop('disabled', false);

                btn.html(`
                    <i class="mdi mdi-check-circle-outline"></i>
                    Update 10X
                `);
            }
        });
    });
</script>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    
</script>
<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');

            stateDropdown.empty().append('<option value="">Select Entity</option>');

            var departDropdown = $('#department_fill');

            departDropdown.empty().append('<option value="">Select Department</option>');

            if (countryId) {
                if (countryId == 'egc') {
                    $('#entity_fill_div').hide();
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: 0
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    departDropdown.append($('<option></option>').attr(
                                            'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }else{
                    $('#entity_fill_div').show();
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });

                }
                
            }
        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });
        // division dropdown
        $('#department_fill').on('change', function() {
            var department_id = $(this).val();
            var stateDropdown = $('#division_fill');
            stateDropdown.empty().append('<option value="">Select Division</option>');

          

            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_division') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdivisionid', state.erp_division_id)
                                    .text(state.division_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Division:', error);
                    }
                });

            }
        });

        $('#division_fill').on('change', function() {
            var department_id = $(this).val();

            var jobRoleDropdown = $('#job_role_fill');

            jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

            let erp_depert = $(this).find(':selected').data('erpdivisionid');
            $('#erp_division_id').val(erp_depert);

            if (department_id) {
                // Fetch and populate states based on selected country
                // Job role dropdown
                $.ajax({
                    url: "{{ route('get_job_role') }}",
                    type: "GET",
                    data: {
                        division_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpjobroleid', state.erp_job_role_id)
                                    .text(state.job_position_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Job Role:', error);
                    }
                });
            }
        });

    })
</script>
<script>
    $('#single_month').datepicker({
        format: 'yyyy-mm',
        startView: 'months',
        minViewMode: 'months',
        autoclose: true
    });

    $('#custom_months').datepicker({
        format: 'yyyy-mm',
        startView: 'months',
        minViewMode: 'months',
        multidate: true,
        multidateSeparator: ','
    });
    $('#month_filter_mode').on('change', function () {

        const mode = $(this).val();

        $('#single_month_wrapper').addClass('d-none');
        $('#custom_month_wrapper').addClass('d-none');

        if (mode === 'single') {
            $('#single_month_wrapper').removeClass('d-none');
        }

        if (mode === 'custom') {
            $('#custom_month_wrapper').removeClass('d-none');
        }
    });
</script>
<script>
    $(document).on(
        'click',
        '.dashboard-filter-card',
        function () {

            const filter =   $(this).data('dashboard-filter');

            if (activeDashboardFilter === filter) {

                activeDashboardFilter = '';

                $('.dashboard-filter-card')
                    .removeClass(
                        'border border-primary shadow-lg'
                    );

                loadThemes(1);

                return;
            }


            /*
            |--------------------------------------------------------------------------
            | Apply filter
            |--------------------------------------------------------------------------
            */

            activeDashboardFilter = filter;

            $('.dashboard-filter-card')
                .removeClass(
                    'border border-primary shadow-lg'
                );

            $(this)
                .addClass(
                    'border border-primary shadow-lg'
                );

            loadThemes(
                1,
                filter
            );
        }
    );
</script>
@endsection