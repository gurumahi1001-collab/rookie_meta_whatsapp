@extends('layouts/layoutMaster')

@section('title', 'Manage Appraisal')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp
<style>
    .salary-box.exited{
        background:#F5F5F5;
        color:#BDBDBD;
        border:1px dashed #D6D6D6;
        cursor:not-allowed;
    }
    .employee-exit{
        margin-top:8px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
    }

    .exit-date{
        color:#6B7280;
        font-size:11px;
        font-weight:600;
    }

    /* Notice */
    .chip-notice{
        background:#FFF3CD;
        color:#B26A00;
    }

    /* Relieved */
    .chip-relieved{
        background:#DCFCE7;
        color:#15803D;
    }
    /* Abscond */
    .chip-abscond{
        background:#FEF3C7;
        color:#B45309;
    }
    /* Terminated */

    .chip-terminated{
        background:#FEE2E2;
        color:#DC2626;
    }
</style>

<style>
    .employee-card{

        display:flex;
        align-items:center;
        position:relative;
        min-width:320px;

    }

.company-strip{

    width:5px;
    align-self:stretch;
    border-radius:10px;
    margin-right:12px;

}

.staff-avatar{

    width:52px;
    height:52px;
    border-radius:50%;
    object-fit:fill;
    border:2px solid #ECECEC;
    flex-shrink:0;

}

.employee-info{

    flex:1;
    overflow:hidden;

}

.employee-name{

    font-size:15px;
    font-weight:700;
    color:#222;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;

}

.employee-department{

    font-size:12px;
    color:#777;
    margin-top:2px;

}

.employee-footer{

    display:flex;
    flex-wrap:wrap;
    gap:6px;
    margin-top:7px;

}

.employee-chip{

    display:inline-flex;
    align-items:center;
    gap:4px;
    padding:2px 8px;
    border-radius:20px;
    font-size:11px;
    font-weight:600;

}

.chip-company{

    background:#fff;
    border:1px solid;

}

.chip-id{

    background:#F5F5F5;
    color:#555;

}

/* .chip-success{

    background:#DFF7E8;
    color:#0E8F48;

} */
</style>

<style>
    #loadingSkeleton{

        display:none;

    }

    #appraisalTable{

        display:block;

    }
   .appraisal-wrapper{
        overflow:auto;
        max-height:78vh;
    }

    .appraisal-table{
        min-width:max-content;
        border-collapse:separate;
        border-spacing:0;
    }

    .employee-col{
        min-width:300px;
    }

    .month-col{
        min-width:110px;
        text-align:center;
    }

    .current-col{
        min-width:140px;
        text-align:center;
    }

    .action-col{
        width:90px;
        text-align:center;
    }

    .sticky-left{
        position:sticky;
        left:0;
        background:#fff;
        z-index:100;
        box-shadow:5px 0 15px rgba(0,0,0,.05);
    }

    .sticky-right{
        position:sticky;
        right:0;
        background:#fff;
        z-index:100;
        box-shadow:-5px 0 15px rgba(0,0,0,.05);
    }

    /* .staff-avatar{
        width:48px;
        height:48px;
        border-radius:50%;
        object-fit:fill;
        border:2px solid #e5e7eb;
    } */

    .salary-box{
        padding:12px;
        border-radius:10px;
        text-align:center;
        font-weight:700;
        transition:.25s;
    }

    .before{
        background:#ECEFF1;
        color:#9E9E9E;
        pointer-events:none;
        opacity:.7;
    }

    .joining{
        background:#1565C0;
        color:#fff;
    }

    .normal{
        background:#fff;
        border:1px solid #E5E7EB;
    }

    .appraisal{
        background:#2ECC71;
        color:#fff;
    }

    .current{
        background:#FFF8E1;
        border:2px solid #FF9800;
        font-weight:700;
        color:#E65100;
    }

    .salary-box:hover{
        transform:translateY(-2px);
        box-shadow:0 10px 20px rgba(0,0,0,.12);
    }
</style>
<style>
    .salary-timeline{

    position:relative;

    margin-top:35px;

    padding-left:40px;

}

.salary-timeline::before{

    content:"";

    position:absolute;

    left:22px;

    top:0;

    bottom:0;

    width:4px;

    background:#E5E7EB;

}

.salary-timeline-item{

    position:relative;

    margin-bottom:30px;

}

.salary-timeline-dot{

    position:absolute;

    left:-30px;

    top:28px;

    width:18px;

    height:18px;

    border-radius:50%;

    border:4px solid #fff;

    /* box-shadow:0 0 0 4px #1565C0;
    background:#1565C0; */

    box-shadow:0 0 0 4px #AB2B22;
    background:#AB2B22;

}

.salary-timeline-card{

    background:#fff;

    border-radius:18px;

    padding:22px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

    transition:.3s;

}

.salary-timeline-card:hover{

    transform:translateY(-3px);

}

.salary-new{

    font-size:30px;

    font-weight:700;

    color:#198754;

}

.salary-old{

    text-decoration:line-through;

    color:#9CA3AF;

}

.salary-timeline-badge{

    border-radius:30px;

    padding:5px 12px;

    font-size:12px;

    font-weight:600;

}
.analytics-card{

    background:#fff;

    border-radius:18px;

    padding:25px;

    box-shadow:0 10px 30px rgba(0,0,0,.08);

    height:100%;

}

.analytics-title{

    color:#6B7280;

    font-size:14px;

}

.analytics-value{

    font-size:34px;

    font-weight:700;

}

.salary-progress{

    height:18px;

    border-radius:20px;

    overflow:hidden;

    background:#E5E7EB;

}

.salary-progress .progress-bar{

    font-weight:700;

}

.stat-item{

    display:flex;

    justify-content:space-between;

    padding:12px 0;

    border-bottom:1px dashed #EEE;

}
</style>
<style>
    .dashboard-card{
        border:none;
        border-radius:18px;
        overflow:hidden;
        transition:.3s;
        cursor:pointer;
        color:#fff;

        min-height:135px;      /* Same height */
        height:100%;

        display:flex;
    }
   

    .dashboard-card:hover{
        transform:translateY(-6px);
        box-shadow:0 18px 40px rgba(0,0,0,.18);

    }

    .dashboard-icon{
        width:30px;
        height:30px;
        border-radius:8px;
        display:flex;
        align-items:center;
        justify-content:center;
        background:rgba(255,255,255,.18);
    }

    .dashboard-value{
        font-size:34px;
        font-weight:700;
    }

    .dashboard-title{
        font-size:15px;
        font-weight:600;
        white-space:nowrap;
    }

    

    .bg-blue{
        background:linear-gradient(135deg,#4F8EF7,#2455D6);
    }

    .bg-green{
        background:linear-gradient(135deg,#38C172,#1E824C);
    }

    .bg-orange{
        background:linear-gradient(135deg,#FF9F43,#FF6B00);
    }

    .bg-red{
        background:linear-gradient(135deg,#FF5E7E,#E63757);
    }

    .bg-purple{
        background:linear-gradient(135deg,#7367F0,#5E50EE);
    }

    .progress{
        height:10px;
        border-radius:10px;
    }

    .progress-bar{
        border-radius:10px;
    }
</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Appraisal</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR SIB
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
           <div class="d-flex align-items-center justify-content-between gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white " id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">

        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" >{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <!-- <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Month</option>
                    </select>
                </div>
                 -->
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row g-4 align-items-stretch" id="dashboardCards"></div>
        
        <div class="">

            <div class="">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadEmployees(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="appraisalTableContainer">
                    <div id="loadingSkeleton" style="display:none">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                @for($i=0;$i<3;$i++)
                                    <tr>
                                        @for($j=0;$j<6;$j++)
                                        <td>
                                            <div class="placeholder-glow">
                                                <span class="placeholder col-12 rounded" style="height:38px;"></span>
                                            </div>
                                        </td>
                                        @endfor
                                    </tr>
                                @endfor
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="appraisalTable"></div>
                    <div class="text-center my-3" id="pagination-container">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="salaryModal">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary pb-4 text-white">
                <span class="mb-0 text-white fs-4 fw-bold">
                    <i class="mdi mdi-cash-multiple me-2 fs-4"></i>
                    Salary Appraisal Profile
                </span>
                <button
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body bg-light">
                <div id="salaryContent"></div>
            </div>
        </div>
    </div>
</div>

<style>
    .hero-card{
        /* background:linear-gradient(135deg,#2F80ED,#56CCF2); */
        /* background: linear-gradient(135deg, #B52A1F 0%, #D64532 100%); */
        background:linear-gradient(
        135deg,
        #AB2B22 0%,
        #B52A1F 40%,
        #D64532 75%,
        #FDB72C 100%
        );
        border-radius:18px;
        padding:30px;
        color:#fff;
        overflow:hidden;
        position:relative;
    }
    .hero-card::after{
        content:"";
        position:absolute;
        right:-50px;
        top:-40px;
        width:220px;
        height:220px;
        background:rgba(255,255,255,.08);
        border-radius:50%;
    }

    .hero-avatar{
        width:110px;
        height:110px;
        border-radius:50%;
        border:5px solid rgba(255,255,255,.25);
        object-fit:fill;

    }
    .hero-title{
        font-size:28px;
        font-weight:700;
    }
    .hero-sub{
        opacity:.9;
    }
    .hero-chip{
        display:inline-block;
        padding:5px 14px;
        border-radius:30px;
        background:rgba(255,255,255,.18);
        margin-right:8px;
        font-size:12px;
    }
    .kpi-card{
        background:#fff;
        border-radius:14px;
        padding:20px;
        box-shadow:0 8px 25px rgba(0,0,0,.08);
        text-align:center;
        height:100%;

    }
    .kpi-number{
        font-size:28px;
        font-weight:700;
        /* color:#1565C0; */
        color:#AB2B22;
    }
    .kpi-title{
        color:#666;
        font-size:13px;
    }
</style>


<script>
    function changeEntity() {
        var entity_id = $('#entitySelect').val();
        var branchDropdown = $('#branchSelect');
        branchDropdown.empty().append('');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    $('#global_year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>


<script>
   
    
    function currencyFormat(value) {
        value = Number(value || 0);
        if (value >= 10000000) {
            return (Math.floor((value / 10000000) * 100) / 100).toFixed(2) + ' Cr';
        }
        if (value >= 100000) {
            return (Math.floor((value / 100000) * 100) / 100).toFixed(2) + ' L';
        }
        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0
        }).format(value);
    }

    function getMonthName(monthNo, year) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };

        let displayYear = year;

        if ([1, 2, 3].includes(parseInt(monthNo))) {
            displayYear = parseInt(year) + 1;
        }

        return `${monthNames[monthNo]} ${displayYear}`;
    }

    function getMonthNameOnly(monthNo) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };


        return `${monthNames[monthNo]}`;
    }


    function noDataCard() {

        return `
            <div class="metrics-state-wrapper">
                <img
                     src="/assets/egc_images/no_data_found.png"
                    class="no-data-image">
                <div class="no-data-title">
                    Failed to load incentive data
                </div>
                <div class="no-data-subtitle">
                    Try changing filters or Please Try Again Later
                </div>
            </div>
        `;
    }

   

  
</script>
<script>
     function changeIncetiveEntity() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#branchIncentive');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });
                        if($('#entityIncentive').val() != ''){
                            changeIncetiveBranch()
                        }
                        
                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }

    function changeIncetiveBranch() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#roleIncentive');
        // branchDropdown.empty().append('<option value="" >Select Role</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('incentive_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erproleid', state.erp_role_id)
                                .text(state.role_name));
                        });

                        changeIncetiveRole()

                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    let abortIncentiveController = new AbortController();
    let loaderInterval = null;

    function updateLoader(percent) {

        const circle = document.querySelector('.loader-progress');

        const radius = 60;
        const circumference = 2 * Math.PI * radius;

        const offset = circumference - ((percent / 100) * circumference);

        circle.style.strokeDashoffset = offset;

        $('#loaderPercent').text(percent + '%');




    }
    
</script>
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    let tableState = {
        currentPage: 1
    };
   

</script>

<script>
    
    function loadEmployees(page = 1){

        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        // const to_dt_iss_rpt = document.getElementById('cus_custom_to_dt_fill').value;
        // const from_dt_iss_rpt = document.getElementById('cus_custom_from_dt_fill').value;
        // const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_sib/appraisal/list?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}`;

        showSkeleton();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                renderDashboard(res.dashboard);
                renderTable(res);
                renderPagination(res.current_page, res.last_page, res.total, perpage);
                // Hide skeleton loader after data is fetched
                isLoading = false;
                hideSkeleton();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                 hideSkeleton();
                isLoading = false;
            });
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadEmployees(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadEmployees(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadEmployees(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadEmployees(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadEmployees(1); // Reload the table data without the search filter
    });
</script>
<script>
    function showSkeleton(){
        $("#loadingSkeleton").removeClass("d-none").show();
        $("#appraisalTable").hide();
        $("#pagination-container").hide();
    }
    function hideSkeleton(){
        $("#loadingSkeleton").hide();
        $("#appraisalTable").fadeIn(200);
        $("#pagination-container").show();
    }
</script>
<script>
    function renderTable(response){
        let html=`
            <div class="table-responsive appraisal-wrapper">
                <table class="table appraisal-table align-middle">
                    ${renderHeader(response.headers)}
                    ${renderBody(response.data)}
                </table>
            </div>
        `;
        $("#appraisalTable").html(html);
        

        setTimeout(function(){

            scrollToCurrentMonth();

        },150);
    }

   
    // function scrollToCurrentMonth(){

    //     const wrapper=document.querySelector(".appraisal-wrapper");

    //     const current=document.querySelector(".current-month-column");

    //     if(!wrapper || !current)
    //         return;

    //     wrapper.scrollTo({

    //         left: current.offsetLeft - 250,

    //         behavior:"smooth"

    //     });

    // }

    function scrollToCurrentMonth(){

        const wrapper=document.querySelector(".appraisal-wrapper");

        const current=document.querySelector(".current-month-column");

        if(!wrapper || !current)
            return;

        const left =
            current.offsetLeft
            - (wrapper.clientWidth/2)
            + (current.clientWidth/2);

        wrapper.scrollTo({

            left:left,

            behavior:"smooth"

        });

    }
</script>
<script>
    function renderDashboard(d){

        let cards="";

        cards+=dashboardCard("bg-blue",
            "mdi-account-group",
            "Total Staff",
            d.total_staff);

        cards+=dashboardCard("bg-purple",
            "mdi-chart-line",
            "Appraised",
            d.appraised_staff);

        // cards+=dashboardCard("bg-orange",
        //     "mdi-clock-outline",
        //     "Pending",
        //     d.pending_staff);

        // cards+=dashboardCard("bg-purple",
        //     "mdi-currency-inr",
        //     "Average Salary",
        //     money(d.average_salary));

        // cards+=dashboardCard("bg-red",
        //     "mdi-bank",
        //     "Salary Cost",
        //     money(d.salary_cost));

        cards+=dashboardCard("bg-orange",
            "mdi-calendar-month",
            "This Month",
            d.this_month);

        cards+=dashboardCard("bg-green",
            "mdi-calendar",
            "This Year",
            d.this_year);

        // cards+=dashboardCard("bg-orange",
        //     "mdi-finance",
        //     "Avg Hike %",
        //     d.avg_increment+" %");

        // cards+=dashboardCard("bg-purple",
        //     "mdi-arrow-up-bold",
        //     "Highest Salary",
        //     money(d.highest_salary));

        // cards+=dashboardCard("bg-red",
        //     "mdi-arrow-down-bold",
        //     "Lowest Salary",
        //     money(d.lowest_salary));

        $("#dashboardCards").html(cards);

        // renderDistribution(d.types);

    }

function dashboardCard(bg,icon,title,value){

    return `
    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 d-flex">
        <div class="card dashboard-card ${bg} w-100">
            <div class="card-body">
                <div class="d-flex justify-content-between gap-1 w-100">
                    <div>
                        <div class="dashboard-title">${title}</div>
                        <div class="dashboard-value">${value}</div>
                    </div>
                    <div class="dashboard-icon">
                        <i class="mdi ${icon} fs-5"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;

}

function renderDistribution(t){
    let total=t.joining+t.yearly+t.special+t.project+t.warrior;

    let html="";
    html+=progress("Joining",t.joining,total,"primary");
    html+=progress("Yearly",t.yearly,total,"success");
    html+=progress("Special",t.special,total,"warning");
    html+=progress("Project",t.project,total,"info");
    html+=progress("10X Warrior",t.warrior,total,"danger");
    // $("#appraisalDistribution").html(html);
}

function progress(title,value,total,color){

    let p=0;
    if(total>0){
        p=((value/total)*100).toFixed(1);
    }

    return `
        <div class="mb-4">
            <div class="d-flex justify-content-between mb-1">
                <b>${title}</b>
                <span>${value}</span>
            </div>
            <div class="progress">
                <div class="progress-bar bg-${color}" style="width:${p}%">
                </div>
            </div>
        </div>
    `;

}
</script>
<script>
    function renderHeader(headers){
        let html="";
        html+=`
            <thead>
                <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary sticky-top">
                    <th class="sticky-left employee-col bg-primary">
                        Employee
                    </th>
                    <th class="current-col">
                        Current Salary
                    </th>
            `;
            headers.forEach(function(month){
                html+=`
                    <th class="month-col">
                        ${month.label}
                    </th>
                `;
            });
            html+=`
                <th class="sticky-right action-col bg-primary">
                    Action
                </th>
                </tr>
            </thead>
        `;

        return html;
    }
</script>
<script>
    function renderBody(rows){

        let html="<tbody>";
        rows.forEach(function(emp){
            html+=renderEmployee(emp);
        });
        html+="</tbody>";
        return html;
    }
</script>
<script>
    function renderEmployee(emp){

        let row="";
        row+="<tr>";
        row+=employeeColumn(emp);
        row+=`
            <td class="current-salary">
                ${money(emp.current_salary)}
            </td>
        `;
        emp.timeline.forEach(function(month){
            row+=monthCell(month);
        });
        row+=actionColumn(emp);
        row+="</tr>";
        
        return row;
    }
</script>
<script>
    function monthCell(month){

        let cls = month.status;

        if(month.current){
            cls += " current";
        }

        return `
            <td class="${cls == 'current' ? 'current-month-column' : ''}">
                <div
                    class="salary-box ${cls}" data-bs-toggle="tooltip" data-bs-placement="top" title="${month.type ?? ''}"
                    data-effective="${month.effective_from ?? ''}">
                    ${month.salary==null ? "-" : money(month.salary)}
                </div>
            </td>
        `;
    }
</script>
<script>
    function money(amount){
        if(amount==null)
        return "-";
        return "₹"+Number(amount).toLocaleString();
    }
</script>
<script>
    // function employeeColumn(emp){
    //     return`
    //         <td class="sticky-left employee-cell bg-white">
    //             <div class="d-flex align-items-center">
    //                 <img src="${emp.profile_image_url}" class="staff-avatar" loading="lazy">
    //                 <div class="ms-3">
    //                     <div class="fw-bold">${emp.staff_name}</div>
    //                     <div class="text-muted small">${emp.department_name}</div>
    //                     <div class="badge bg-light text-dark mt-1">${emp.staff_id}</div>
    //                 </div>
    //             </div>
    //         </td>
    //     `;
    // }
    function employeeColumn(emp){

        const companyColor = emp.company_base_color || "#B52A1F";

        let appraisalBadge = "";

        if(parseInt(emp.total_appraisal) >= 1){
            appraisalBadge = `
                <span class="employee-chip chip-success badge bg-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Total Appraisal Count">
                    ${emp.total_appraisal}
                </span>
            `;
        }

         // Exit Status
        let exitHtml = "";

        if(parseInt(emp.status) >= 4){

            let exitStatus = "";
            let exitClass = "";
            let exitDate = "";

            switch(parseInt(emp.status)){

                case 4:
                    exitStatus = "Notice Period";
                    exitClass = "chip-notice";
                    exitDate = emp.notice_end_date;
                break;

                case 5:
                    exitStatus = "Relieved";
                    exitClass = "chip-relieved";
                    exitDate = emp.staff_last_date;
                break;

                case 6:
                    exitStatus = "Abscond";
                    exitClass = "chip-abscond";
                    exitDate = emp.staff_last_date;
                break;

                case 7:
                    exitStatus = "Terminated";
                    exitClass = "chip-terminated";
                    exitDate = emp.staff_last_date;
                break;
            }

            exitHtml = `
                <div class="employee-exit">

                    <span class="employee-chip ${exitClass}">
                        <i class="mdi mdi-account-off"></i>
                        ${exitStatus}
                    </span>

                    <small class="employee-chip ${exitClass}">
                        <i class="mdi mdi-calendar"></i>
                        ${formatDateCommon(exitDate)}
                    </small>

                </div>
            `;
        }

        return `
        <td class="sticky-left employee-cell bg-white">

            <div class="employee-card">

                <div class="company-strip"
                    style="background:${companyColor};">
                </div>

                <img
                    src="${emp.profile_image_url}"
                    class="staff-avatar"
                    loading="lazy">

                <div class="employee-info">

                    <div class="d-flex gap-1">
                        <div class="employee-name">
                            ${emp.staff_name}
                        </div>
                        <span class="employee-chip chip-id">
                            ${emp.staff_id}
                        </span>
                         ${appraisalBadge}
                    </div>

                    <div class="employee-department">
                        ${emp.department_name ?? "-"}
                    </div>

                    <div class="employee-footer">

                        <span class="employee-chip chip-company"
                            style="
                            border-color:${companyColor};
                            color:${companyColor};">

                            <i class="mdi mdi-office-building"></i>

                            ${emp.company_name ?? "-"}

                        </span>

                    </div>
                    ${exitHtml}

                </div>

            </div>

        </td>
        `;
    }
</script>
<script>
    function actionColumn(emp){
        return`
            <td class="sticky-right bg-white">
                <button class="btn btn-sm btn-primary" onclick="viewSalary(${emp.sno})">
                    <i class="mdi mdi-eye"></i>
                </button>
            </td>
        `;
    }
</script>
<script>
   
</script>
<script>
    loadEmployees();
    
</script>
<script>
    function renderPagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadEmployees(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadEmployees(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadEmployees(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadEmployees(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadEmployees(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }
</script>
<script>
    function viewSalary(id){
        $.get(
            "/hr_sib/appraisal/details/"+id,
            function(res){
                renderSalaryModal(res);
                $("#salaryModal").modal("show");
            }
        );
    }

    function renderSalaryModal(res){
        let html="";
        html+=renderHero(res.staff,res.summary);
        html+=renderKPICards(res.summary);
        html+=renderAnalytics(res.summary);     // NEW
        html+=renderSalaryJourney(res);
        $("#salaryContent").html(html);

    }

    function renderHero(emp,summary){
        return `
            <div class="hero-card mb-4">
                <div class="row align-items-center">
                    <div class="col-lg-2 text-center">
                        <img src="${emp.profile_image_url}" class="hero-avatar">
                    </div>
                    <div class="col-lg-6">
                        <div class="hero-title">
                            ${emp.staff_name}
                         </div>
                        <div class="hero-sub">
                            ${emp.job_position_name}
                        </div>

                        <div class="mt-3">
                            <span class="hero-chip">
                                Employee ID :
                                ${emp.staff_id}
                            </span>
                            <span class="hero-chip">
                                ${emp.department_name}
                            </span>
                            <span class="hero-chip">
                                ${emp.division_name}
                            </span>
                        </div>

                        <div class="mt-3">
                            <i class="mdi mdi-calendar"></i>
                            Joining :
                            ${emp.date_of_joining}
                        </div>
                    </div>
                    <div class="col-lg-4 text-end">
                        <div style="font-size:14px">
                            Current Salary
                        </div>
                        <div style="font-size:40px;font-weight:700">
                            ₹${Number(summary.current_salary).toLocaleString()}
                        </div>

                        <div class="mt-2">
                            Growth
                            <span class="badge bg-success">
                                ${summary.salary_growth}%
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderKPICards(summary){
        return `
            <div class="row g-3">
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ₹${Number(summary.current_salary).toLocaleString()}
                        </div>
                        <div class="kpi-title">
                            Current Salary
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ${summary.total_appraisals}
                        </div>
                        <div class="kpi-title">
                            Appraisals
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ₹${Number(summary.total_increment).toLocaleString()}
                        </div>
                        <div class="kpi-title">
                            Total Increment
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ${summary.experience}
                        </div>
                        <div class="kpi-title">
                            Experience
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderSalaryJourney(res){

        let html="";

        html+=`
        <div class="card shadow-sm border-0 mt-4">

            <div class="card-header bg-white">

                <h4>

                    <i class="mdi mdi-chart-line text-success"></i>

                    Salary Journey

                </h4>

            </div>

            <div class="card-body">

                <div class="salary-timeline">
        `;

        html+=joiningCard(res);

        res.history.forEach(function(item,index){
            if(item.appraisal_type !=0){
                html+=timelineCard(item,index,res);
            }
        });

        html+=currentSalaryCard(res.summary);

        html+=`

                </div>

            </div>

        </div>`;

        return html;

    }

function joiningCard(res){

return `

<div class="salary-timeline-item">

<div class="salary-timeline-dot bg-blue"></div>

<div class="salary-timeline-card">

<span class="badge bg-primary">

Joining

</span>

<h3 class="mt-2">

₹${Number(res.summary.joining_salary).toLocaleString()}

</h3>

<div>

Joining Date

${res.staff.date_of_joining}

</div>

</div>

</div>

`;

}

// function timelineCard(item,index,res){

//     let previous=index===0 ? res.summary.joining_salary :res.history[index-1].gross_salary;
//     let increment=item.gross_salary-previous;
//     let percent=((increment/previous)*100).toFixed(1);
//     let custom_appraisal_type = '';

//     switch (item.appraisal_type) {
//         case 0:
//             custom_appraisal_type = 'Joining';
//             break;
//         case 1: 
//             custom_appraisal_type = 'Yearly';
//             break;
//         case 3: 
//             custom_appraisal_type = 'Project';
//             break;
//         case 5: 
//             custom_appraisal_type = '10X Warrior';
//             break;
//     }

//     let appraisal_type_name = item.appraisal_type_name ? item.appraisal_type_name : custom_appraisal_type;
    

//     return `
//         <div class="salary-timeline-item">
//             <div class="salary-timeline-dot bg-success"></div>
//                 <div class="salary-timeline-card">
//                     <div class="d-flex justify-content-between">
//                         <div>
//                             <h5>${appraisal_type_name}</h5>
//                             <small>${item.effective_from ? formatDateCommon(item.effective_from) : '-'}</small>
//                         </div>
//                         <span class="salary-timeline-badge bg-success">+${percent}%</span>
//                     </div>

//                     <hr>

//                 <div class="row">
//                     <div class="col-md-4">
//                         <div class="salary-old">
//                         ₹${Number(previous).toLocaleString()}
//                         </div>
//                     </div>
//                     <div class="col-md-4 text-center">
//                         <i class="mdi mdi-arrow-right fs-2"></i>
//                     </div>
//                     <div class="col-md-4 text-end">
//                         <div class="salary-new">
//                         ₹${Number(item.gross_salary).toLocaleString()}
//                         </div>
//                     </div>
//                 </div>
//                 <div class="mt-3">
//                     ${item.appraisal_reason??"-"}
//                 </div>
//             </div>
//         </div>

//     `;
// }

function timelineCard(item, index, res) {

    let previous = index === 0
        ? res.summary.joining_salary
        : res.history[index - 1].gross_salary;

    let custom_appraisal_type = '';

    switch (parseInt(item.appraisal_type)) {
        case 0:
            custom_appraisal_type = 'Joining';
            break;
        case 1:
            custom_appraisal_type = 'Yearly';
            break;
        case 3:
            custom_appraisal_type = 'Project';
            break;
        case 5:
            custom_appraisal_type = '10X Warrior';
            break;
        default:
            custom_appraisal_type = 'Appraisal';
    }

    let appraisal_type_name = item.appraisal_type_name || custom_appraisal_type;

    // Badge Value
    let badgeValue = '';
    let hike_amount = 0
    let originalSalaryOld = Number(item.gross_salary);

    if (item.appraisal_unit == '%') {
        // Percentage
        badgeValue = `+${Number(item.appraisal_value).toFixed(2)}%`;
        hike_amount =  (Number(item.appraisal_value) / 100) * originalSalaryOld ;
    } else {
        // Rupees
        badgeValue = `+₹${Number(item.appraisal_value).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`;
        hike_amount =  Number(item.appraisal_value);
    }

     let originalSalaryHike = originalSalaryOld + Math.round(hike_amount);

    return `
        <div class="salary-timeline-item">

            <div class="salary-timeline-dot bg-success"></div>

            <div class="salary-timeline-card">

                <div class="d-flex justify-content-between align-items-center">

                    <div>
                        <h5 class="mb-1">${appraisal_type_name}</h5>
                        <small class="text-muted">
                            ${item.effective_from ? formatDateCommon(item.effective_from) : '-'}
                        </small>
                    </div>

                    <span class="salary-timeline-badge bg-success text-white">
                        ${badgeValue}
                    </span>

                </div>

                <hr>

                <div class="row align-items-center">

                    <div class="col-md-4">
                        <div class="salary-old">
                            ₹${Number(item.gross_salary).toLocaleString('en-IN')}
                        </div>
                    </div>

                    <div class="col-md-4 text-center">
                        <i class="mdi mdi-arrow-right fs-2 text-primary"></i>
                    </div>

                    <div class="col-md-4 text-end">
                        <div class="salary-new">
                            ₹${Number(originalSalaryHike).toLocaleString('en-IN')}
                        </div>
                    </div>

                </div>

                <div class="mt-3 text-muted">
                    ${item.appraisal_reason || "-"}
                </div>

            </div>

        </div>
    `;
}

function currentSalaryCard(summary){

return `

<div class="salary-timeline-item">

<div class="salary-timeline-dot bg-warning"></div>

<div class="salary-timeline-card border border-warning">

<div class="d-flex justify-content-between">

<div>

<h4>

Current Salary

</h4>

</div>

<div class="salary-new">

₹${Number(summary.current_salary).toLocaleString()}

</div>

</div>

</div>

</div>

`;

}

function renderAnalytics(summary){

return`

<div class="card border-0 shadow mt-4">

<div class="card-header bg-white">

<h4>

<i class="mdi mdi-chart-areaspline text-success"></i>

Salary Analytics

</h4>

</div>

<div class="card-body">

<div class="row">

${growthCard(summary)}

${progressCard(summary)}

</div>

</div>

</div>

`;

}

function growthCard(summary){

return`

<div class="col-lg-6">

<div class="analytics-card">

<div class="analytics-title">

Salary Growth

</div>

<div class="analytics-value text-success">

${summary.salary_growth}%

</div>

<div class="mt-3">

Joining Salary

<strong>

₹${Number(summary.joining_salary).toLocaleString()}

</strong>

</div>

<div>

Current Salary

<strong>

₹${Number(summary.current_salary).toLocaleString()}

</strong>

</div>

<div class="mt-3">

Total Growth

<strong class="text-primary">

₹${Number(summary.total_increment).toLocaleString()}

</strong>

</div>

</div>

</div>

`;

}


function progressCard(summary){

return`

<div class="col-lg-6">

<div class="analytics-card">

<h5>

Salary Progress

</h5>

<div class="salary-progress mt-4">

<div

class="progress-bar bg-success"

style="width:${summary.salary_growth>100?100:summary.salary_growth}%">

${summary.salary_growth}%

</div>

</div>

<div class="mt-4">

<div class="stat-item">

<span>Total Appraisals</span>

<strong>

${summary.total_appraisals}

</strong>

</div>

<div class="stat-item">

<span>Highest Salary</span>

<strong>

₹${Number(summary.highest_salary).toLocaleString()}

</strong>

</div>

<div class="stat-item">

<span>Total Increment</span>

<strong>

₹${Number(summary.total_increment).toLocaleString()}

</strong>

</div>

<div class="stat-item">

<span>Experience</span>

<strong>

${summary.experience}

</strong>

</div>

</div>

</div>

</div>

`;

}

    function employeeCard(emp){

        return `
            <div class="row">
                <div class="col-lg-4">
                    <img src="${emp.profile_image_url}" class="rounded-circle avatar-xl">
                </div>
                <div class="col-lg-8">
                    <h4>${emp.staff_name}</h4>
                    <div>${emp.job_position_name}</div>
                    <div>${emp.department_name}</div>
                    <div>
                        Joining
                        ${emp.date_of_joining}
                    </div>
                </div>
            </div>
        `;

    }
    // function timeline(history){
    //     let html="";
    //     html+='<div class="timeline mt-4">';
    //     history.forEach(function(h){
    //         html+=timelineCard(h);
    //     });
    //     html+='</div>';

    //     return html;
    // }

    // function timelineCard(h){
    //     return `
    //         <div class="salary-history-card">
    //             <div>
    //                 <h5>₹${Number(h.gross_salary).toLocaleString()}</h5>
    //             </div>
    //             <div>
    //                 Effective
    //                 ${h.effective_from}
    //             </div>
    //             <div>${h.appraisal_type_name}</div>
    //             <div>
    //                 ${h.appraisal_reason}
    //             </div>
    //         </div>
    //     `;
    // }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
   
</script>
<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');
             var departDropdown = $('#department_fill');

            departDropdown.empty().append('<option value="">Select Department</option>');

            stateDropdown.empty().append('<option value="">Select Entity</option>');

            if (countryId) {
                if(countryId == 'egc'){
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: 0
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    departDropdown.append($('<option></option>').attr(
                                            'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }else{
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            }
        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });
        // division dropdown
        $('#department_fill').on('change', function() {
            var department_id = $(this).val();
            var stateDropdown = $('#division_fill');
            stateDropdown.empty().append('<option value="">Select Division</option>');

          

            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_division') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdivisionid', state.erp_division_id)
                                    .text(state.division_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Division:', error);
                    }
                });

            }
        });

        $('#division_fill').on('change', function() {
            var department_id = $(this).val();

            var jobRoleDropdown = $('#job_role_fill');

            jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

            let erp_depert = $(this).find(':selected').data('erpdivisionid');
            $('#erp_division_id').val(erp_depert);

            if (department_id) {
                // Fetch and populate states based on selected country
                // Job role dropdown
                $.ajax({
                    url: "{{ route('get_job_role') }}",
                    type: "GET",
                    data: {
                        division_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpjobroleid', state.erp_job_role_id)
                                    .text(state.job_position_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Job Role:', error);
                    }
                });
            }
        });

    })
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>

@endsection