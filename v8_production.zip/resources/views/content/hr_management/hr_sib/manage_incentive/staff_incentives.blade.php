@extends('layouts/layoutMaster')

@section('title', 'Manage Incentive')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
<style>
    
    .metrics-dashboard {

        padding: 20px;
        background: #f9fafb;
        min-height: 100vh;
    }

    .metrics-header {

        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        flex-wrap: wrap;
        gap: 15px;
    }

    .metrics-title {

        font-size: 28px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 4px;
    }

    .metrics-subtitle {

        color: #6b7280;
        margin: 0;
    }

    .metrics-filters {

        display: flex;
        gap: 10px;
        align-items: center;
    }

    .search-box {

        width: 260px;
    }

    .year-filter {

        width: 170px;
    }

    .metrics-grid {

        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
        gap: 20px;
    }

    .metric-card {

        background: #fff;
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        transition: 0.3s;
        border: 1px solid #eef2f7;
    }

    .metric-card:hover {

        transform: translateY(-4px);
    }

    .metric-header {

        padding: 20px;
        color: #fff;
        position: relative;
    }

    .metric-header-overlay {

        position: absolute;
        inset: 0;
        background: rgba(255, 255, 255, 0.06);
        backdrop-filter: blur(10px);
    }

    .metric-header-content {

        position: relative;
        z-index: 2;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .entity-info {

        display: flex;
        align-items: center;
        gap: 14px;
    }

    .entity-logo {

        width: 58px;
        height: 58px;
        border-radius: 18px;
        object-fit: cover;
        background: #fff;
        padding: 6px;
    }

    .entity-name {

        font-size: 18px;
        font-weight: 700;
    }

    .branch-name {

        opacity: 0.9;
        font-size: 13px;
    }

    .ai-badge {

        padding: 8px 14px;
        border-radius: 40px;
        font-size: 12px;
        font-weight: 700;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(6px);
    }

    .metric-body {

        padding: 20px;
    }

    .metric-stats {

        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin-bottom: 20px;
    }

    .metric-stat {

        background: #f8fafc;
        border-radius: 16px;
        padding: 14px;
    }

    .metric-label {

        color: #6b7280;
        font-size: 12px;
        margin-bottom: 6px;
    }

    .metric-value {

        font-size: 18px;
        font-weight: 700;
    }

    .progress-area {

        margin-bottom: 20px;
    }

    .progress-track {

        width: 100%;
        height: 12px;
        border-radius: 20px;
        background: #edf2f7;
        overflow: hidden;
    }

    .progress-fill {

        height: 100%;
        border-radius: 20px;
    }

    .quarter-grid {

        display: grid;
        gap: 14px;
    }

    .quarter-card {

        border: 1px solid #eef2f7;
        border-radius: 18px;
        overflow: hidden;
    }

    .quarter-header {

        padding: 14px 16px;
        background: #f8fafc;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
    }

    .quarter-title {

        font-weight: 700;
    }

    .quarter-body {

        padding: 16px;
    }

    .month-grid {

        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }

    .month-card {

        border: 1px solid #eef2f7;
        border-radius: 14px;
        padding: 12px;
        transition: 0.3s;
    }

    .month-card:hover {

        background: #f8fbff;
    }

    .month-name {

        font-weight: 700;
        margin-bottom: 8px;
    }

    .month-target {

        color: #111827;
        font-weight: 700;
        font-size: 15px;
    }

    .month-actual {

        color: #16a34a;
        font-weight: 700;
        margin-top: 4px;
    }

    .month-percent {

        margin-top: 10px;
        font-size: 12px;
        font-weight: 700;
    }

    @media(max-width:768px) {

        .metrics-grid {

            grid-template-columns: 1fr;
        }

        .metric-stats {

            grid-template-columns: 1fr;
        }

        .month-grid {

            grid-template-columns: 1fr;
        }
    }

    .metric-stat-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 14px;
        margin-bottom: 22px;
    }

    .metric-stat-card {
        background: #f8fafc;
        border-radius: 18px;
        padding: 18px;
    }

    .metric-big {
        font-size: 22px;
        font-weight: 800;
    }

    .overall-progress-wrap {
        margin-bottom: 20px;
    }

    .overall-progress-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .month-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .month-badge {
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 11px;
        font-weight: 700;
    }

    .metric-mini-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        margin-bottom: 12px;
    }

    .mini-box {
        background: #f8fafc;
        border-radius: 12px;
        padding: 10px;
    }

    .mini-box span {
        display: block;
        font-size: 11px;
        color: #64748b;
    }

    .mini-box strong {
        font-size: 14px;
    }

    .mini-progress {
        width: 100%;
        height: 8px;
        background: #edf2f7;
        border-radius: 20px;
        overflow: hidden;
    }

    .mini-progress-bar {
        height: 100%;
        border-radius: 20px;
    }

    .week-performance-card {
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 18px;
        margin-bottom: 16px;
    }

    .week-performance-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
    }

    .week-metric-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 14px;
    }

    .week-box {
        background: #f8fafc;
        padding: 14px;
        border-radius: 14px;
    }

    .week-box span {
        display: block;
        color: #64748b;
        font-size: 12px;
        margin-bottom: 4px;
    }

    .week-box strong {
        font-size: 15px;
    }

    @media(max-width:768px) {

        .metric-stat-grid {
            grid-template-columns: 1fr;
        }

        .week-metric-grid {
            grid-template-columns: 1fr;
        }

        .metric-mini-grid {
            grid-template-columns: 1fr;
        }

    }
</style>
<style>
    @media(max-width:992px) {

        .metric-stat-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .month-grid {
            grid-template-columns: 1fr;
        }

        .week-metric-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media(max-width:768px) {

        .metrics-grid {
            grid-template-columns: 1fr;
        }

        .metric-stat-grid,
        .week-metric-grid,
        .metric-mini-grid {
            grid-template-columns: 1fr;
        }

        .metric-header-content {
            flex-direction: column;
            align-items: flex-start;
        }

        .quarter-header {
            align-items: flex-start;
        }

        .quarter-percent {
            font-size: 16px;
        }

        .metric-big {
            font-size: 18px;
        }

        .entity-logo {
            width: 48px;
            height: 48px;
        }
    }
</style>
<style>
    .metric-card {
        min-width: 0;
        overflow: hidden;
    }

    .metric-stat-card,
    .month-card,
    .week-box,
    .quarter-card {
        min-width: 0;
    }

    .metric-big,
    .metric-value,
    .month-target,
    .month-actual,
    .week-box strong,
    .quarter-header span,
    .quarter-percent {

        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .quarter-header {

        display: flex;
        justify-content: space-between;
        align-items: center;

        gap: 12px;

        flex-wrap: wrap;
    }

    .quarter-header small {
        display: block;
        color: #64748b;
        margin-top: 2px;
        font-size: 12px;
        white-space: nowrap;
    }

    .quarter-right {
        flex-shrink: 0;
        text-align: right;
    }

    .quarter-percent {
        font-size: 20px;
        font-weight: 800;
        white-space: nowrap;
    }

    /* .month-card {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 100%;
        cursor: pointer;
    } */

    .month-card {

        min-height: 240px;

        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .month-grid {
        align-items: stretch;
    }

    .metric-mini-grid {
        flex: 1;
    }

    .metric-big {
        font-size: clamp(18px, 1.4vw, 24px);
        line-height: 1.2;
    }

    .metric-stat-grid {
        align-items: stretch;
    }

    .metric-stat-card {
        height: 100%;
    }

    .quarter-progress-wrap {
        padding: 0 16px 14px;
        background: #f8fafc;
    }

    .quarter-progress-track {
        width: 100%;
        height: 8px;
        border-radius: 20px;
        background: #e2e8f0;
        overflow: hidden;
    }

    .quarter-progress-fill {
        height: 100%;
        border-radius: 20px;
        transition: width .4s ease;
    }

    .month-name {
        font-size: 15px;
        line-height: 1.3;
    }

    .entity-name {
        line-height: 1.2;
    }

    .metric-header-content {
        gap: 12px;
    }

    .ai-badge {
        white-space: nowrap;
        flex-shrink: 0;
    }

    /* .metric-stat-grid {
        grid-template-columns: repeat(4, minmax(0, 1fr));
    }

    .month-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    } */
    .metric-stat-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));

        gap: 14px;
    }

    .month-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));

        gap: 12px;
    }

    .current-quarter {
        border: 2px solid #ab2b22 !important;
        box-shadow: 0 0 20px rgba(115, 103, 240, .2);
    }

    .current-month-card {
        border: 2px solid #28c76f !important;
        background: linear-gradient(135deg, #e9fff3, #ffffff);
    }

    .current-week {
        border: 2px solid #ff9f43 !important;
        background: #fff8ef;
    }
</style>
<style>
    .no-data-image {

        width: 180px;

        opacity: .95;

        margin-bottom: 18px;

        filter: drop-shadow(0 10px 20px rgba(0, 0, 0, .08));
    }

    .metrics-state-wrapper {

        grid-column: 1 / -1;

        width: 100%;

        min-height: 60vh;

        display: flex;

        align-items: center;

        justify-content: center;

        flex-direction: column;

    }

    .metrics-loader {

        width: 60px;
        height: 60px;

        border: 5px solid #e5e7eb;
        border-top-color: #ab2b22;

        border-radius: 50%;

        animation: spinLoader .8s linear infinite;
    }

    @keyframes spinLoader {

        to {
            transform: rotate(360deg);
        }
    }

    .no-data-image {

        width: 160px;
        opacity: .9;
    }

    .no-data-title {

        font-size: 22px;
        font-weight: 700;

        margin-top: 18px;

        color: #111827;
    }

    .no-data-subtitle {

        color: #6b7280;
        margin-top: 6px;
    }
</style>
<style>
    .incentive-accordion .accordion-item {
        border: 0;
        margin-bottom: 18px;
        border-radius: 24px !important;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0, 0, 0, .06);
        background: #fff;
    }

    .incentive-accordion .accordion-button {
        background: #fff;
        padding: 22px;
        box-shadow: none !important;
    }

    .incentive-accordion .accordion-button:not(.collapsed) {
        background:
            linear-gradient(135deg,
                rgba(115, 103, 240, .08),
                rgba(255, 255, 255, 1));
    }

    .incentive-accordion .accordion-button::after {
        background-size: 18px;
    }

    .staff-avatar {
        width: 58px;
        height: 58px;
        border-radius: 50%;
        background: linear-gradient(135deg, #ab2b22, #e2918b);
        color: #fff;
        font-size: 22px;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .staff-img {
        width: 58px;
        height: 58px;
        border-radius: 50%;
        object-fit: fill;
        /* border: 2px solid #e5e7eb; */
    }

    .staff-name {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
    }

    .staff-role {
        font-size: 12px;
        color: #6b7280;
    }

    .reward-box {
        min-width: 140px;
        text-align: center;
        background: #f8fafc;
        border-radius: 18px;
        padding: 12px 18px;
    }

    .reward-label {
        font-size: 11px;
        color: #6b7280;
    }

    .reward-value {
        font-size: 24px;
        font-weight: 800;
        color: #28c76f;
    }

    .breakdown-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 16px;
    }

    .break-item {
        background: #f8fafc;
        border-radius: 18px;
        padding: 16px;
        border: 1px solid #eef2f7;
    }

    .break-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        /* margin-bottom: 10px; */
    }

    .break-label {
        font-size: 13px;
        font-weight: 600;
        color: #374151;
    }

    .break-value {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
    }

    .break-progress {
        height: 8px;
        border-radius: 30px;
        overflow: hidden;
        background: #e5e7eb;
    }

    .break-progress-bar {
        height: 100%;
        border-radius: 30px;
        background: linear-gradient(90deg, #ab2b22, #e2918b);
    }

    .incentive-footer {
        border-top: 1px solid #eef2f7;
        margin-top: 20px;
        padding-top: 16px;
    }

    .footer-chip {
        padding: 10px 14px;
        border-radius: 14px;
        background: #f8fafc;
        font-size: 12px;
        color: #6b7280;
    }

    .footer-chip strong {
        color: #111827;
    }

    .currency-badge {
        padding: 6px 14px;
        border-radius: 30px;
        background: rgba(40, 199, 111, .12);
        color: #28c76f;
        font-size: 11px;
        font-weight: 700;
    }

    .zero-award {
        opacity: .65;
    }
</style>
<style>
    .incentive-loader-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        /* padding: 40px; */
    }


    .loader-circle-wrap {
        position: relative;
        width: 140px;
        height: 140px;
        margin: auto;
    }

    .loader-ring {
        transform: rotate(-90deg);
    }

    .loader-bg {
        fill: none;
        stroke: #edf2f7;
        stroke-width: 10;
    }

    .loader-progress {
        fill: none;
        stroke: #ab2b22;
        stroke-width: 10;
        stroke-linecap: round;
        stroke-dasharray: 377;
        stroke-dashoffset: 377;
        transition: stroke-dashoffset .4s ease;
    }

    .loader-center {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .loader-percent {
        font-size: 30px;
        font-weight: 800;
        color: #111827;
        line-height: 1;
    }

    .loader-status {
        font-size: 12px;
        color: #6b7280;
        margin-top: 6px;
    }

    .loader-title {
        font-size: 20px;
        font-weight: 700;
        color: #111827;
        margin-top: 24px;
    }

    .loader-subtitle {
        font-size: 13px;
        color: #6b7280;
        margin-top: 6px;
    }
</style>
<style>
    .metric-card{
    margin-top:25px;
    padding:20px;
    border:1px solid #e5e7eb;
    border-radius:12px;
    background:#fafafa;
}

.metric-title{
    font-size:16px;
    font-weight:700;
    margin-bottom:18px;
}

.metric-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:12px;
}

.metric-item{
    background:#fff;
    border-radius:10px;
    padding:12px 15px;
    border:1px solid #ececec;
}

.metric-item span{
    display:block;
    font-size:12px;
    color:#777;
    margin-bottom:4px;
}

.metric-item strong{
    font-size:15px;
    color:#222;
}

.incentive-accordion .accordion-header {
    position: relative;
}

.incentive-accordion .incentive-accordion-trigger {
    padding-right: 180px !important;
}

.incentive-accordion .incentive-download-btn {
    position: absolute;
    top: 50%;
    right: 55px;
    transform: translateY(-50%);
    z-index: 10;

    display: inline-flex;
    align-items: center;
    justify-content: center;

    min-height: 40px;
    padding: 8px 14px;

    border-radius: 10px;
    white-space: nowrap;
}

.incentive-accordion .incentive-download-btn:hover {
    transform: translateY(-50%) translateY(-1px);
}

.incentive-accordion .incentive-download-btn:disabled {
    cursor: wait;
    opacity: .75;
}

@media (max-width: 768px) {

    .incentive-accordion .incentive-accordion-trigger {
        padding-right: 22px !important;
        padding-bottom: 75px !important;
    }

    .incentive-accordion .incentive-download-btn {
        top: auto;
        bottom: 15px;
        right: 22px;
        transform: none;
    }

    .incentive-accordion .incentive-download-btn:hover {
        transform: translateY(-1px);
    }

}
</style>
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Incentive - <span class="target_label_year text-primary" id="target_label_year">{{ date('M-Y') }}</span></h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR SIB
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
           
        </div>
    </div>
    <div class="card-body">
        <div class="metrics-dashboard">

            <div class="metrics-header">

                <div class="metrics-title-block">

                    <h3 class="metrics-title">
                        Staff Incentive
                    </h3>

                    <!-- <p class="metrics-subtitle">
                        AI Driven Corporate Sales Analytics Dashboard
                    </p> -->

                </div>
                <div>
                    <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                        <div class="d-flex gap-2">

                                <div class="w-150px">
                                    <label>Month</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text">
                                            <i class="mdi mdi-calendar-month-outline fs-4"></i>
                                        </span>
                                        <input type="text"
                                            class="form-control month_filter_common_class"
                                            id="month_year"
                                            readonly
                                            value="{{ date('M-Y') }}" onchange="changeIncetiveRole()">
                                    </div>
                                </div>

                                <div class="w-250px">
                                    <label>Entity</label>
                                    <select id="entityIncentive" class="form-select select3" onchange="changeIncetiveEntity()">
                                        <!-- <option value="">Select Entity</option> -->
                                        @foreach($entity_list as $e)
                                        <option value="{{ $e->sno }}" data-baseurl="{{ $e->entity_base_url }}">{{ $e->entity_name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class=" w-250px">
                                    <label>Branch</label>
                                    <select id="branchIncentive" class="form-select select3" onchange="changeIncetiveBranch()">
                                        <!-- <option value="">Select Branch</option> -->
                                    </select>
                                </div>
                                <div class=" w-250px">
                                    <label>Role</label>
                                    <select id="roleIncentive" class="form-select select3" onchange="changeIncetiveRole()">
                                        <option value="">Select Role</option>
                                    </select>
                                </div>

                            </div>


                    </div>
                </div>
            </div>
            <div id="incentiveLoader" class="incentive-loader-wrapper d-none">
                <div class="incentive-loader-card">
                    <div class="loader-circle-wrap">
                        <svg class="loader-ring" width="140" height="140">
                            <circle class="loader-bg"
                                cx="70"
                                cy="70"
                                r="60">
                            </circle>
                            <circle class="loader-progress"
                                cx="70"
                                cy="70"
                                r="60">
                            </circle>
                        </svg>
                        <div class="loader-center">
                            <div id="loaderPercent" class="loader-percent">
                                0%
                            </div>
                            <div class="loader-status">
                                Fetching...
                            </div>
                        </div>
                    </div>
                    <div class="loader-title">
                        Retrieving Incentive Data
                    </div>
                    <div class="loader-subtitle mb-3">
                        Please wait while we process ERP records
                    </div>
                </div>
            </div>
            <div class="accordion incentive-accordion" id="incentiveCards"></div>
        </div>
    </div>
</div>






<script>
    function changeEntity() {
        var entity_id = $('#entitySelect').val();
        var branchDropdown = $('#branchSelect');
        branchDropdown.empty().append('');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    $('#global_year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>


<script>
   
    
    function currencyFormat(value) {
        value = Number(value || 0);
        if (value >= 10000000) {
            return (Math.floor((value / 10000000) * 100) / 100).toFixed(2) + ' Cr';
        }
        if (value >= 100000) {
            return (Math.floor((value / 100000) * 100) / 100).toFixed(2) + ' L';
        }
        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0
        }).format(value);
    }

    function getMonthName(monthNo, year) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };

        let displayYear = year;

        if ([1, 2, 3].includes(parseInt(monthNo))) {
            displayYear = parseInt(year) + 1;
        }

        return `${monthNames[monthNo]} ${displayYear}`;
    }

    function getMonthNameOnly(monthNo) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };


        return `${monthNames[monthNo]}`;
    }


    function noDataCard() {

        return `
            <div class="metrics-state-wrapper">
                <img
                     src="/assets/egc_images/no_data_found.png"
                    class="no-data-image">
                <div class="no-data-title">
                    Failed to load incentive data
                </div>
                <div class="no-data-subtitle">
                    Try changing filters or Please Try Again Later
                </div>
            </div>
        `;
    }

   

  
</script>
<script>
     function changeIncetiveEntity() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#branchIncentive');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });
                        if($('#entityIncentive').val() != ''){
                            changeIncetiveBranch()
                        }
                        
                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }

    function changeIncetiveBranch() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#roleIncentive');
        // branchDropdown.empty().append('<option value="" >Select Role</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('incentive_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erproleid', state.erp_role_id)
                                .text(state.role_name));
                        });

                        changeIncetiveRole()

                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    let abortIncentiveController = new AbortController();
    let loaderInterval = null;

    function updateLoader(percent) {

        const circle = document.querySelector('.loader-progress');

        const radius = 60;
        const circumference = 2 * Math.PI * radius;

        const offset = circumference - ((percent / 100) * circumference);

        circle.style.strokeDashoffset = offset;

        $('#loaderPercent').text(percent + '%');




    }

    const metricLabels = {
        target: "Target",
        actual: "Actual",
        tenx_status: "10X Status",

        target_pre: "Pre Sale Target",
        actual_pre: "Pre Sale Actual",
        target_post: "Post Sale Target",
        actual_post: "Post Sale Actual",

        target_pre_abv: "Pre ABV Target",
        actual_pre_abv: "Pre ABV Actual",

        target_pre_acv: "Pre ACV Target",
        actual_pre_acv: "Pre ACV Actual",

        target_post_abv: "Post ABV Target",
        actual_post_abv: "Post ABV Actual",

        target_post_acv: "Post ACV Target",
        actual_post_acv: "Post ACV Actual",

        team_pre_target: "Team Pre Target",
        team_pre_actual: "Team Pre Achieved",

        team_post_target: "Team Post Target",
        team_post_actual: "Team Post Achieved",

        abv_150_pre: "150% ABV Achievement (Pre)",
        abv_150_post: "150% ABV Achievement (Post)",

        yearly_150_acheived_pre: "Yearly 150% Achievement (Pre)",
        yearly_150_acheived_post: "Yearly 150% Achievement (Post)",

        nine_month_acheived: "9 Month Achievement",

        actual_issue: "Actual Issues",
        target_issue: "Target Issues",

        drop_collection: "Drop Collection",

        referrals: "Referrals",

        published_amount: "Published Incentive",

        bonus_amount: "Bonus Incentive",

        old_pending_perc: "Old Pending %",

        bonus_actual_perc: "Bonus Achievement %",

        bonus_actual_amount: "Bonus Collection",

        spot_actual: "Spot Collection",

        spot_target: "Spot Target"
    };

    const incentiveLabels = {
        "10X Award": "10X Award",
        "ABV Award": "Average Business Value Award",
        "ABV 150% Award": "150% Average Business Value Award",
        "BI Award": "Bonus Incentive",
        "SI Award": "Strategy Incentive",
        "PRF Award": "Performance Incentive",
        "PI Award": "Profitable Incentive",
        "LI Award": "Luxury Incentive",
        "SP Award": "Spot Incentive",
        "ECI Award": "Early Cash Incentive",
        "2X Award": "Double Target Achievement Award",
        "Team 10X Award": "Team 10X Achievement Award",
        "Yearly 150% Award": "Yearly 150% Performance Award",
        "9 Month Award": "9 Month Consistency Award"
    };
    
    function loadIncentive(){

        let month_year = $('#month_year').val();
        $('#target_label_year').text(month_year);
        const verifyKey = 'egcsecret2030datagetapierp';

        let entityId = $('#entityIncentive').val();
        let branchId = $('#branchIncentive').val();
        let baseurl = $('#entityIncentive option:selected').data('baseurl');
        let erpBranchId = $('#branchIncentive option:selected').data('erpbranchid');
        let role_id = $('#roleIncentive option:selected').data('erproleid');

        if (!entityId || !branchId || !baseurl || !erpBranchId || !role_id) {
            toastr.warning('Select Entity & Branch');
            return;
        }

        if (!month_year) {
            toastr.warning('Select Month');
            return;
        }

        $('#incentiveLoader').removeClass('d-none');

        $('#incentiveCards').html('');
        updateLoader(0);

        let progress = 0;

        clearInterval(loaderInterval);

        loaderInterval = setInterval(() => {

            if (progress < 92) {

                progress += Math.floor(Math.random() * 8) + 2;

                if (progress > 92) {
                    progress = 92;
                } else if (progress >= 92 && progress < 98) {

                    progress += 0.4;

                    if (progress > 98) {
                        progress = 98;
                    }
                }

                updateLoader(Math.floor(progress));

                // updateLoader(progress);
            }

        }, 400);

        // abort previous request
        if (abortIncentiveController.signal) {
            abortIncentiveController.abort();
        }

        abortIncentiveController = new AbortController();
        const url = `/hr_sib/manage_incentive?entity_id=${entityId}&branch_id=${erpBranchId}&verify_key=${verifyKey}&role_id=${role_id}&month_year=${month_year}`;
        fetch(url, {
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                },
                signal: abortIncentiveController.signal
            })
            .then(res => res.json())
            .then(res => {
                clearInterval(loaderInterval);
                updateLoader(100);

                setTimeout(() => {

                    $('#incentiveLoader').addClass('d-none');

                }, 500);

                let html = '';

                res.data.forEach((item, index) => {

                    let initials = item.staff_name
                        .split(' ')
                        .map(x => x[0])
                        .join('')
                        .substring(0, 2);

                     let imageHtml = item.staff_image
                        ? `<img src="${item.staff_image}" class="staff-img">`
                        : `<div class="staff-avatar">${initials}</div>`;

                    let total = parseFloat(item.total_award) || 0;

                    let zeroClass = total <= 0 ? 'zero-award' : '';

                    let breakdownHtml = '';

                    Object.entries(item.breakdown).forEach(([key, value]) => {

                        let percent = total > 0 ?
                            ((value / total) * 100) :
                            0;

                        breakdownHtml += `
                            <div class="break-item">

                                <div class="break-top">

                                    <div class="break-label">
                                        ${incentiveLabels[key] ?? key}
                                    </div>

                                    <div class="break-value">
                                        ₹ ${new Intl.NumberFormat('en-IN').format(value)}
                                    </div>

                                </div>

                            </div>
                        `;
                    });

                    let metrics = item.metrics || {};

                    let metricsHtml = '';

                    if (Object.keys(metrics).length) {

                        metricsHtml = `
                            <div class="metric-card">

                                <div class="metric-title">
                                    <i class="fa fa-circle-info text-primary me-2"></i>
                                    Performance Metrics
                                </div>

                                <div class="metric-grid">
                        `;

                        Object.entries(metrics).forEach(([key, value]) => {

                            let label = metricLabels[key] ??
                                key.replace(/_/g, ' ')
                                .replace(/\b\w/g, c => c.toUpperCase());

                            if (key === 'tenx_status') {
                                value = value
                                    ? '<span class="badge bg-success">Achieved</span>'
                                    : '<span class="badge bg-danger">Not Achieved</span>';
                            } else if (typeof value === 'boolean') {
                                value = value ? 'Yes' : 'No';
                            }

                            metricsHtml += `
                                <div class="metric-item">

                                    <span>${label}</span>

                                    <strong>${value}</strong>

                                </div>
                            `;
                        });

                        metricsHtml += `
                                </div>
                            </div>
                        `;
                    }

                    html += `
                        <div class="accordion-item ${zeroClass}">

                            <h2 class="accordion-header position-relative" id="heading${index}">

                                <!-- ACCORDION TRIGGER -->
                                <button
                                    class="accordion-button collapsed incentive-accordion-trigger"
                                    type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapse${index}"
                                    aria-expanded="false"
                                    aria-controls="collapse${index}"
                                >

                                    <div class="w-100 pe-5">

                                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                            <!-- LEFT -->
                                            <div class="d-flex align-items-center gap-3">

                                                <div class="staff-avatar">
                                                    ${imageHtml}
                                                </div>

                                                <div>

                                                    <div class="staff-name">
                                                        ${item.staff_name || 'No Name'}
                                                    </div>

                                                </div>

                                            </div>


                                            <!-- RIGHT -->
                                            <div class="d-flex align-items-center gap-3">

                                                <div class="reward-box">

                                                    <div class="reward-label">
                                                        Total Incentive
                                                    </div>

                                                    <div class="reward-value">
                                                        ₹ ${new Intl.NumberFormat('en-IN').format(total)}
                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </button>


                                <!-- DOWNLOAD PDF BUTTON -->
                                ${
                                    total > 0
                                        ? `
                                            <button
                                                type="button"
                                                class="btn btn-primary incentive-download-btn"
                                                data-index="${index}"
                                                title="Download Incentive PDF"
                                                aria-label="Download ${item.staff_name || 'staff'} incentive PDF"
                                            >
                                                <i class="mdi mdi-file-pdf-box-outline me-1"></i>
                                                <span class="download-text">
                                                    Download PDF
                                                </span>
                                            </button>
                                        `
                                        : ''
                                }

                            </h2>


                            <div
                                id="collapse${index}"
                                class="accordion-collapse collapse"
                                aria-labelledby="heading${index}"
                                data-bs-parent="#incentiveCards"
                            >

                                <div class="accordion-body p-4">

                                    <!-- BREAKDOWN -->
                                    <div class="breakdown-grid">
                                        ${breakdownHtml}
                                    </div>

                                    ${metricsHtml}

                                    <!-- FOOTER -->
                                    <div class="incentive-footer">

                                        <div class="d-flex flex-wrap gap-3">

                                            <div class="footer-chip">
                                                Updated :
                                                <strong>
                                                    ${item.last_updated || '-'}
                                                </strong>
                                            </div>

                                            <div class="footer-chip">
                                                Next Update :
                                                <strong>
                                                    ${item.next_update || '-'}
                                                </strong>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>
                    `;
                });

                $('#incentiveCards').html(html);

                $('#incentiveLoader').addClass('d-none');

                window.incentivePayload = res.data;
                window.incentivePdfMeta = res.pdf_meta || {};
            }).catch(err => {
                clearInterval(loaderInterval);

                $('#incentiveLoader').addClass('d-none');
                if (err.name !== "AbortError") {

                    console.error(err);

                    $('#incentiveCards').html(`
                            ${noDataCard()}
                    `);
                }
            });
    }

    async function generateStaffIncentivePDF(staff, index, button) {

        const $button = $(button);

        /*
        |--------------------------------------------------------------------------
        | Prevent duplicate generation
        |--------------------------------------------------------------------------
        */

        if ($button.data('pdf-generating') === true) {
            return;
        }

        $button.data('pdf-generating', true);

        const originalHtml = $button.html();

        $button.prop('disabled', true);

        $button.html(`
            <span
                class="spinner-border spinner-border-sm me-1"
                role="status"
                aria-hidden="true"
            ></span>
            Preparing...
        `);

        try {

            /*
            |--------------------------------------------------------------------------
            | Validate libraries
            |--------------------------------------------------------------------------
            */

            if (
                typeof window.jspdf === 'undefined' ||
                typeof window.jspdf.jsPDF === 'undefined'
            ) {
                throw new Error(
                    'jsPDF library is not loaded.'
                );
            }

            const { jsPDF } = window.jspdf;

            /*
            |--------------------------------------------------------------------------
            | Validate AutoTable
            |--------------------------------------------------------------------------
            */

            const doc = new jsPDF({
                orientation: 'portrait',
                unit: 'mm',
                format: 'a4'
            });

            if (typeof doc.autoTable !== 'function') {
                throw new Error(
                    'jsPDF AutoTable plugin is not loaded.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Validate staff data
            |--------------------------------------------------------------------------
            */

            if (!staff || typeof staff !== 'object') {
                throw new Error(
                    'Invalid staff incentive data.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | PDF metadata
            |--------------------------------------------------------------------------
            */

            const meta =
                window.incentivePdfMeta || {};


            /*
            |--------------------------------------------------------------------------
            | Total incentive
            |--------------------------------------------------------------------------
            */

            const total =
                Number(staff.total_award || 0);

            if (!Number.isFinite(total) || total <= 0) {

                toastr.warning(
                    'PDF is available only for staff with incentive amount greater than zero.'
                );

                return;
            }


            /* PDF dimensions*/
            const pageWidth = doc.internal.pageSize.getWidth();
            const pageHeight = doc.internal.pageSize.getHeight();
            const margin = 15;

            /*
            |--------------------------------------------------------------------------
            | Colors
            |--------------------------------------------------------------------------
            */

            function hexToRgb(hex, fallback = [171, 43, 34]) {

                if (!hex) {
                    return fallback;
                }

                hex = String(hex)
                    .trim()
                    .replace(/^#/, '');

                /*
                |--------------------------------------------------------------------------
                | Support shorthand:
                | #fff -> #ffffff
                |--------------------------------------------------------------------------
                */

                if (hex.length === 3) {
                    hex = hex
                        .split('')
                        .map(char => char + char)
                        .join('');
                }

                /*
                |--------------------------------------------------------------------------
                | Validate 6 digit hex
                |--------------------------------------------------------------------------
                */

                if (!/^[0-9a-fA-F]{6}$/.test(hex)) {
                    return fallback;
                }

                return [
                    parseInt(hex.substring(0, 2), 16),
                    parseInt(hex.substring(2, 4), 16),
                    parseInt(hex.substring(4, 6), 16)
                ];
            }


            const primary = hexToRgb(
                meta.entity_base_color,
                [171, 43, 34]
            );

            const dark = [31, 41, 55];

            const muted = [100, 116, 139];

            const light = [248, 250, 252];

            const success = [22, 163, 74];

            const danger = [220, 38, 38];

            const border = [226, 232, 240];

            const white = [255, 255, 255];


            /*
            |--------------------------------------------------------------------------
            | Helper: money
            |--------------------------------------------------------------------------
            |
            | NOTE:
            | jsPDF's default Helvetica font does not reliably support ₹.
            | Therefore "Rs." is intentionally used for production compatibility.
            |
            | If you want the actual ₹ symbol, embed a Unicode TTF font.
            |--------------------------------------------------------------------------
            */

            function money(value) {

                const amount =
                    Number(value || 0);

                return 'Rs. ' + amount.toLocaleString(
                    'en-IN',
                    {
                        minimumFractionDigits: 0,
                        maximumFractionDigits: 2
                    }
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: clean text
            |--------------------------------------------------------------------------
            */

            function cleanText(value, fallback = '-') {

                if (
                    value === null ||
                    value === undefined
                ) {
                    return fallback;
                }

                const text =
                    String(value)
                        .replace(/<[^>]*>/g, ' ')
                        .replace(/\s+/g, ' ')
                        .trim();

                return text || fallback;
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: safe filename
            |--------------------------------------------------------------------------
            */

            function safeFilename(value) {

                return cleanText(value, 'Staff')
                    .replace(/[^a-zA-Z0-9._ -]/g, '')
                    .replace(/\s+/g, '_')
                    .replace(/_+/g, '_')
                    .replace(/^[_ .]+|[_ .]+$/g, '')
                    .substring(0, 80) || 'Staff';
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: image URL
            |--------------------------------------------------------------------------
            */

            function resolveImageUrl(path) {

                if (!path) {
                    return null;
                }

                let value =
                    String(path).trim();

                if (!value) {
                    return null;
                }

                /*
                * Base64 / data URI
                */
                if (
                    value.startsWith('data:image/')
                ) {
                    return value;
                }

                /*
                * Absolute URL
                */
                if (
                    value.startsWith('http://') ||
                    value.startsWith('https://')
                ) {
                    return value;
                }

                /*
                * Root-relative path
                */
                if (value.startsWith('/')) {
                    return window.location.origin + value;
                }

                /*
                * Relative path
                */
                return new URL(
                    value,
                    window.location.origin + '/'
                ).href;
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: load image safely
            |--------------------------------------------------------------------------
            */

            async function loadImage(path) {

                const url =
                    resolveImageUrl(path);

                if (!url) {
                    return null;
                }

                /*
                * Data URI
                */
                if (url.startsWith('data:image/')) {
                    return url;
                }

                try {

                    const response =
                        await fetch(url, {
                            method: 'GET',
                            credentials: 'same-origin',
                            cache: 'force-cache'
                        });

                    if (!response.ok) {

                        console.warn(
                            'PDF image request failed:',
                            response.status,
                            url
                        );

                        return null;
                    }

                    const blob =
                        await response.blob();

                    if (!blob.type.startsWith('image/')) {

                        console.warn(
                            'PDF resource is not an image:',
                            blob.type,
                            url
                        );

                        return null;
                    }

                    return await new Promise(
                        (resolve) => {

                            const reader =
                                new FileReader();

                            reader.onload = () => {
                                resolve(reader.result);
                            };

                            reader.onerror = () => {
                                resolve(null);
                            };

                            reader.readAsDataURL(blob);
                        }
                    );

                } catch (error) {

                    console.warn(
                        'Unable to load PDF image:',
                        url,
                        error
                    );

                    return null;
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: format month
            |--------------------------------------------------------------------------
            */

            function formatMonthYear() {

                /*
                * Prefer the actual filter values if available.
                */

                const selectedMonth =
                    $('#selectedMonth').text().trim();

                const selectedYear =
                    $('#selectedYear')
                        .text()
                        .trim()
                        .replace(/[()]/g, '');

                /*
                * If month is already "August", return:
                *
                * August 2026
                */

                if (
                    selectedMonth &&
                    selectedYear
                ) {
                    return `${selectedMonth} ${selectedYear}`;
                }

                /*
                * Fallback to staff record.
                */

                if (
                    staff.month &&
                    staff.year
                ) {

                    const monthNames = [
                        'January',
                        'February',
                        'March',
                        'April',
                        'May',
                        'June',
                        'July',
                        'August',
                        'September',
                        'October',
                        'November',
                        'December'
                    ];

                    const monthNo =
                        Number(staff.month);

                    if (
                        monthNo >= 1 &&
                        monthNo <= 12
                    ) {
                        return `${monthNames[monthNo - 1]} ${staff.year}`;
                    }
                }

                return '-';
            }


            /*
            |--------------------------------------------------------------------------
            | Helper: add page footer
            |--------------------------------------------------------------------------
            */

            function addFooter() {

                const currentPage =
                    doc.internal.getNumberOfPages();

                doc.setPage(currentPage);

                doc.setDrawColor(...border);

                doc.line(
                    margin,
                    pageHeight - 12,
                    pageWidth - margin,
                    pageHeight - 12
                );

                doc.setFont(
                    'helvetica',
                    'normal'
                );

                doc.setFontSize(7);

                doc.setTextColor(...muted);

                doc.text(
                    'System-generated incentive statement',
                    margin,
                    pageHeight - 7
                );

                doc.text(
                    `Page ${currentPage}`,
                    pageWidth - margin,
                    pageHeight - 7,
                    {
                        align: 'right'
                    }
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Load branding images
            |--------------------------------------------------------------------------
            */

            const [
                companyLogo,
                staffImage,
                signatureImage
            ] = await Promise.all([

                loadImage(
                    meta.company_logo
                ),

                loadImage(
                    staff.staff_image
                ),

                loadImage(
                    meta.signature_image
                )

            ]);


            /*
            |--------------------------------------------------------------------------
            | Top accent
            |--------------------------------------------------------------------------
            */

            doc.setFillColor(...primary);

            doc.rect(
                0,
                0,
                pageWidth,
                5,
                'F'
            );


            /*
            |--------------------------------------------------------------------------
            | Company logo
            |--------------------------------------------------------------------------
            */

            if (companyLogo) {

                try {

                    doc.addImage(
                        companyLogo,
                        'AUTO',
                        margin,
                        11,
                        34,
                        20,
                        undefined,
                        'FAST'
                    );

                } catch (error) {

                    console.warn(
                        'Unable to add company logo:',
                        error
                    );
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Company information
            |--------------------------------------------------------------------------
            */

            const companyX =
                margin + 42;

            doc.setTextColor(...dark);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(15);

            doc.text(
                cleanText(
                    meta.entity_name,
                    'Company'
                ),
                companyX,
                18
            );

            doc.setFont(
                'helvetica',
                'normal'
            );

            doc.setFontSize(9);

            doc.setTextColor(...muted);

            doc.text(
                cleanText(
                    meta.branch_name,
                    'Branch'
                ),
                companyX,
                25
            );


            /*
            |--------------------------------------------------------------------------
            | Document title
            |--------------------------------------------------------------------------
            */

            doc.setTextColor(...dark);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(16);

            doc.text(
                'STAFF INCENTIVE STATEMENT',
                pageWidth - margin,
                18,
                {
                    align: 'right'
                }
            );

            doc.setFont(
                'helvetica',
                'normal'
            );

            doc.setFontSize(9);

            doc.setTextColor(...muted);

            doc.text(
                formatMonthYear(),
                pageWidth - margin,
                25,
                {
                    align: 'right'
                }
            );


            /*
            |--------------------------------------------------------------------------
            | Header divider
            |--------------------------------------------------------------------------
            */

            doc.setDrawColor(...border);

            doc.line(
                margin,
                37,
                pageWidth - margin,
                37
            );


            /*
            |--------------------------------------------------------------------------
            | Staff information card
            |--------------------------------------------------------------------------
            */

            const cardY = 44;

            const cardHeight = 48;

            const cardWidth =
                pageWidth - (margin * 2);

            doc.setFillColor(...light);

            doc.roundedRect(
                margin,
                cardY,
                cardWidth,
                cardHeight,
                4,
                4,
                'F'
            );

            doc.setDrawColor(...border);

            doc.roundedRect(
                margin,
                cardY,
                cardWidth,
                cardHeight,
                4,
                4,
                'S'
            );


            /*
            |--------------------------------------------------------------------------
            | Staff image
            |--------------------------------------------------------------------------
            */

            if (staffImage) {

                try {

                    doc.addImage(
                        staffImage,
                        'AUTO',
                        margin + 6,
                        cardY + 7,
                        32,
                        32,
                        undefined,
                        'FAST'
                    );

                } catch (error) {

                    console.warn(
                        'Unable to add staff image:',
                        error
                    );
                }

            }


            /*
            |--------------------------------------------------------------------------
            | Staff information
            |--------------------------------------------------------------------------
            */

            const staffX =
                margin + 46;

            doc.setTextColor(...dark);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(14);

            doc.text(
                cleanText(
                    staff.staff_name,
                    'Staff Member'
                ),
                staffX,
                cardY + 15
            );

            doc.setFont(
                'helvetica',
                'normal'
            );

            doc.setFontSize(9);

            doc.setTextColor(...muted);

            doc.text(
                `Branch: ${cleanText(meta.branch_name)}`,
                staffX,
                cardY + 23
            );

            doc.text(
                `Role: ${cleanText(
                    staff.role_name ||
                    staff.department_name ||
                    staff.role ||
                    '-'
                )}`,
                staffX,
                cardY + 30
            );

            if (staff.external_uuid) {

                doc.text(
                    `Staff ID: ${cleanText(staff.external_uuid)}`,
                    staffX,
                    cardY + 37
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Total incentive box
            |--------------------------------------------------------------------------
            */

            const totalBoxWidth = 49;

            const totalBoxX =
                pageWidth - margin - totalBoxWidth;

            doc.setFillColor(...success);

            doc.roundedRect(
                totalBoxX,
                cardY + 8,
                totalBoxWidth,
                30,
                4,
                4,
                'F'
            );

            doc.setTextColor(...white);

            doc.setFont(
                'helvetica',
                'normal'
            );

            doc.setFontSize(7);

            doc.text(
                'TOTAL INCENTIVE',
                totalBoxX + (totalBoxWidth / 2),
                cardY + 17,
                {
                    align: 'center'
                }
            );

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(12);

            doc.text(
                money(total),
                totalBoxX + (totalBoxWidth / 2),
                cardY + 29,
                {
                    align: 'center'
                }
            );


            /*
            |--------------------------------------------------------------------------
            | Incentive breakdown
            |--------------------------------------------------------------------------
            */

            const breakdown =
                staff.breakdown &&
                typeof staff.breakdown === 'object'
                    ? staff.breakdown
                    : {};

            const metrics =
                staff.metrics &&
                typeof staff.metrics === 'object'
                    ? staff.metrics
                    : {};

            const rows = [];


            Object.entries(breakdown)
                .forEach(([key, value]) => {

                    const reward =
                        Number(value || 0);

                    const label =
                        typeof incentiveLabels !== 'undefined'
                            ? (
                                incentiveLabels[key] ||
                                key
                            )
                            : key;

                    let target = '-';

                    let actual = '-';

                    /*
                    |--------------------------------------------------------------------------
                    | Metric lookup
                    |--------------------------------------------------------------------------
                    */

                   const metric = metrics[key];

                    if (
                        metric !== null &&
                        metric !== undefined
                    ) {

                        /*
                        |--------------------------------------------------------------------------
                        | Object metric
                        |--------------------------------------------------------------------------
                        */

                        if (
                            typeof metric === 'object' &&
                            !Array.isArray(metric)
                        ) {

                            target =
                                metric.target ??
                                metric.target_amount ??
                                metric.target_value ??
                                metric.required ??
                                '-';

                            actual =
                                metric.actual ??
                                metric.actual_amount ??
                                metric.actual_value ??
                                metric.achieved ??
                                metric.achieved_value ??
                                '-';

                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Primitive metric
                        |--------------------------------------------------------------------------
                        |
                        | If backend returns:
                        |
                        | metrics[key] = 10
                        |
                        | then use it as Actual.
                        |--------------------------------------------------------------------------
                        */

                        else if (
                            typeof metric === 'number' ||
                            typeof metric === 'string'
                        ) {

                            actual = metric;
                        }
                    }

                    rows.push([

                        cleanText(label),

                        cleanText(target),

                        cleanText(actual),

                        reward > 0
                            ? 'Achieved'
                            : 'Not Achieved',

                        money(reward)

                    ]);
                });


            /*
            |--------------------------------------------------------------------------
            | Fallback row
            |--------------------------------------------------------------------------
            */

            if (!rows.length) {

                rows.push([
                    'Staff Incentive',
                    '-',
                    '-',
                    'Achieved',
                    money(total)
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | Breakdown title
            |--------------------------------------------------------------------------
            */

            const tableStartY =
                cardY +
                cardHeight +
                15;

            doc.setTextColor(...dark);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(12);

            doc.text(
                'Incentive Breakdown',
                margin,
                tableStartY
            );


            /*
            |--------------------------------------------------------------------------
            | AutoTable
            |--------------------------------------------------------------------------
            */

            doc.autoTable({

                startY:
                    tableStartY + 5,

                margin: {
                    left: margin,
                    right: margin,
                    bottom: 20
                },

                head: [[
                    'Incentive',
                    'Target',
                    'Actual',
                    'Status',
                    'Award'
                ]],

                body: rows,

                theme: 'grid',

                styles: {

                    font: 'helvetica',

                    fontSize: 8.5,

                    cellPadding: 3,

                    valign: 'middle',

                    textColor: dark,

                    lineColor: border,

                    lineWidth: 0.2

                },

                headStyles: {

                    fillColor: primary,

                    textColor: white,

                    fontStyle: 'bold',

                    halign: 'center',

                    valign: 'middle'

                },

                bodyStyles: {

                    minCellHeight: 9

                },

                alternateRowStyles: {

                    fillColor: [252, 252, 253]

                },

                columnStyles: {

                    0: {
                        cellWidth: 53
                    },

                    1: {
                        cellWidth: 31,
                        halign: 'center'
                    },

                    2: {
                        cellWidth: 31,
                        halign: 'center'
                    },

                    3: {
                        cellWidth: 32,
                        halign: 'center'
                    },

                    4: {
                        cellWidth: 33,
                        halign: 'right',
                        fontStyle: 'bold'
                    }

                },

                didParseCell(data) {

                    if (
                        data.section === 'body' &&
                        data.column.index === 3
                    ) {

                        if (
                            data.cell.raw === 'Achieved'
                        ) {

                            data.cell.styles.textColor =
                                success;

                        } else {

                            data.cell.styles.textColor =
                                danger;
                        }
                    }
                },

                didDrawPage() {

                    addFooter();
                }

            });


            /*
            |--------------------------------------------------------------------------
            | Final total
            |--------------------------------------------------------------------------
            */

            let finalY =
                (doc.lastAutoTable?.finalY || tableStartY + 30) + 10;


            /*
            |--------------------------------------------------------------------------
            | Make sure total block doesn't overflow page
            |--------------------------------------------------------------------------
            */

            if (
                finalY >
                pageHeight - 65
            ) {

                doc.addPage();

                finalY = 25;
            }


            const finalBoxWidth = 75;

            const finalBoxX =
                pageWidth -
                margin -
                finalBoxWidth;

            doc.setFillColor(...light);

            doc.roundedRect(
                finalBoxX,
                finalY,
                finalBoxWidth,
                20,
                3,
                3,
                'F'
            );

            doc.setTextColor(...muted);

            doc.setFont(
                'helvetica',
                'normal'
            );

            doc.setFontSize(8);

            doc.text(
                'NET INCENTIVE',
                finalBoxX + (finalBoxWidth / 2),
                finalY + 7,
                {
                    align: 'center'
                }
            );

            doc.setTextColor(...success);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(13);

            doc.text(
                money(total),
                finalBoxX + (finalBoxWidth / 2),
                finalY + 15,
                {
                    align: 'center'
                }
            );


            /*
            |--------------------------------------------------------------------------
            | Signature
            |--------------------------------------------------------------------------
            */

            const signatureX =
                pageWidth - margin - 60;

            const signatureY =
                pageHeight - 48;


            if (signatureImage) {

                try {

                    doc.addImage(
                        signatureImage,
                        'AUTO',
                        signatureX + 5,
                        signatureY - 2,
                        45,
                        20,
                        undefined,
                        'FAST'
                    );

                } catch (error) {

                    console.warn(
                        'Unable to add signature image:',
                        error
                    );
                }
            }


            doc.setDrawColor(...border);

            doc.line(
                signatureX,
                pageHeight - 22,
                pageWidth - margin,
                pageHeight - 22
            );

            doc.setTextColor(...dark);

            doc.setFont(
                'helvetica',
                'bold'
            );

            doc.setFontSize(8);

            doc.text(
                'Authorized Signature',
                signatureX + 30,
                pageHeight - 16,
                {
                    align: 'center'
                }
            );


            /*
            |--------------------------------------------------------------------------
            | Footer
            |--------------------------------------------------------------------------
            */

            addFooter();


            /*
            |--------------------------------------------------------------------------
            | Filename
            |--------------------------------------------------------------------------
            */

            const staffName =
                safeFilename(
                    staff.staff_name
                );

            const month =
                safeFilename(
                    $('#selectedMonth')
                        .text()
                        .trim() ||
                    'Month'
                );

            const year =
                safeFilename(
                    $('#selectedYear')
                        .text()
                        .trim()
                        .replace(/[()]/g, '') ||
                    'Year'
                );


            const filename =
                `${staffName}_Incentive_${month}_${year}.pdf`;


            /*
            |--------------------------------------------------------------------------
            | Save PDF
            |--------------------------------------------------------------------------
            */

            doc.save(filename);


            /*
            |--------------------------------------------------------------------------
            | Success
            |--------------------------------------------------------------------------
            */

            toastr.success(
                'Incentive PDF downloaded successfully.'
            );

        } catch (error) {

            console.error(
                'Staff incentive PDF generation failed:',
                error
            );

            toastr.error(
                error?.message ||
                'Unable to generate incentive PDF.'
            );

        } finally {

            /*
            |--------------------------------------------------------------------------
            | Always restore button
            |--------------------------------------------------------------------------
            */

            $button.prop(
                'disabled',
                false
            );

            $button.html(
                originalHtml
            );

            $button.removeData(
                'pdf-generating'
            );
        }
    }

    $(document).on(
    'click',
    '.incentive-download-btn',
    function (e) {

       

        e.preventDefault();

        e.stopPropagation();

        /*
        | Prevent Bootstrap from receiving this click.
        */
        if (e.stopImmediatePropagation) {
            e.stopImmediatePropagation();
        }


        console.log(
            'INCENTIVE PDF BUTTON CLICKED'
        );


        /*
        |--------------------------------------------------------------------------
        | Get staff index
        |--------------------------------------------------------------------------
        */

        const index =
            Number(
                $(this).attr('data-index')
            );


        if (
            !Number.isInteger(index) ||
            index < 0
        ) {

            console.error(
                'Invalid staff index:',
                index
            );

            toastr.error(
                'Invalid staff incentive record.'
            );

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | Get staff data
        |--------------------------------------------------------------------------
        */

        const payload =
            window.incentivePayload || [];

        const staff =
            payload[index];


        console.log(
            'Staff data:',
            staff
        );


        if (
            !staff ||
            typeof staff !== 'object'
        ) {

            console.error(
                'Staff incentive data not found.',
                {
                    index,
                    payload
                }
            );

            toastr.error(
                'Staff incentive data not found.'
            );

            return;
        }


        /*
        |--------------------------------------------------------------------------
        | Check incentive amount
        |--------------------------------------------------------------------------
        */

        const total =
            Number(
                staff.total_award || 0
            );


        console.log(
            'Total incentive:',
            total
        );


        if (
            !Number.isFinite(total) ||
            total <= 0
        ) {

            toastr.warning(
                'PDF is available only for staff with incentive amount greater than zero.'
            );

            return;
        }


        /*Generate PDF*/

        generateStaffIncentivePDF(
            staff,
            index,
            this
        );

    }
);


    
</script>

<script>
    changeIncetiveEntity()
    
  function changeIncetiveRole (){
        loadIncentive()
    }
</script>
@endsection