{{-- Deprecated: productivity pages now inline their HTML, CSS, route manifest and AJAX JavaScript. Kept for backwards compatibility. --}}
