@extends('layouts/layoutMaster')

@section('title', 'BookMarks')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/sortablejs/sortable.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')

@endsection

@section('content')
<style>
#egBookMarks {
    --egbm-navy: #1f3864;
    --egbm-purple: #b52b25;
    --egbm-purple-soft: #fbeceb;
    --egbm-bg: #f5f6fa;
    --egbm-border: #dfe3ec;
    --egbm-text: #181818;
    --egbm-muted: #7a8497;
    --egbm-success: #2e7d5a;
    --egbm-danger: #b52b25;
    --egbm-white: #fff;
    color: var(--egbm-text);
    min-height: calc(100vh - 80px);
    margin: -1.5rem;
    width: calc(100% + 3rem);
    background: var(--egbm-bg);
    font-size: 13px;
    border: 0;
    border-radius: 0;
    overflow: hidden;
    box-shadow: none;
}

#egBookMarks * {
    box-sizing: border-box;
}

.egbm-layout {
    display: grid;
    grid-template-columns: 232px minmax(0, 1fr);
    min-height: calc(100vh - 128px);
}

.egbm-board-rail {
    background: #fff;
    border-right: 1px solid var(--egbm-border);
    min-height: 100%;
    position: relative;
    z-index: 2;
}

.egbm-rail-head {
    height: 58px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 11px 0 14px;
    border-bottom: 1px solid #edf0f5;
}

.egbm-rail-title {
    font-size: 10px;
    font-weight: 900;
    letter-spacing: .09em;
    color: #69758a;
}

.egbm-rail-add {
    border: 0;
    background: transparent;
    color: #ab2b22;
    font-size: 18px;
    line-height: 1;
}

.egbm-rail-add:hover {
    color: #96221f;
}

.egbm-board-list {
    padding: 0 7px 12px;
}

.egbm-board-item {
    width: 100%;
    border: 0;
    background: transparent;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 8px 9px;
    border-radius: 8px;
    text-align: left;
    color: #29436b;
    font-size: 11px;
    margin: 1px 0;
    cursor: pointer;
}

.egbm-board-item:hover {
    background: #fafbfe;
}

.egbm-board-item.active {
    background: #fbeceb;
    color: var(--egbm-purple);
    font-weight: 800;
}

.egbm-board-item .name {
    min-width: 0;
    flex: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.egbm-board-item .count {
    color: #8a94a7;
    font-size: 9px;
    min-width: 22px;
    text-align: right;
}

.egbm-board-item .lock {
    color: #8d96a8;
    font-size: 12px;
}

.egbm-board-item.active .count {
    color: #74809a;
}

.egbm-rail-empty {
    padding: 28px 16px;
    text-align: center;
    color: #96a0b3;
    font-size: 10px;
}

.egbm-main {
    min-width: 0;
    background: var(--egbm-bg);
    position: relative;
}

.egbm-workspace-head {
    height: 59px;
    background: #fff;
    border-bottom: 1px solid var(--egbm-border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 14px 0 19px;
    gap: 12px;
}

.egbm-board-heading {
    display: flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
}

.egbm-board-heading h2 {
    font-size: 16px;
    font-weight: 800;
    color: #173a70;
    margin: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.egbm-owner-avatar {
    width: 26px;
    height: 26px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    color: #fff;
    background: var(--egbm-purple);
    font-size: 8px;
    font-weight: 800;
    flex: 0 0 auto;
}

.egbm-board-company {
    font-size: 9px;
    color: #7f899a;
    display: block;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 240px;
}

.egbm-head-divider {
    width: 1px;
    height: 22px;
    background: #e2e5eb;
}

.egbm-top-links-label {
    font-size: 9px;
    color: #65728a;
    font-weight: 900;
    letter-spacing: .08em;
    white-space: nowrap;
}

.egbm-heading-meta {
    display: flex;
    align-items: center;
    gap: 9px;
    min-width: 0;
}

.egbm-workspace-actions {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

.egbm-board-search {
    height: 32px;
    width: 225px;
    border: 1px solid var(--egbm-border);
    background: #fbfcfe;
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 8px;
    color: #8d96a7;
}

.egbm-board-search input {
    width: 100%;
    border: 0;
    outline: 0;
    background: transparent;
    font-size: 10px;
}

.egbm-btn {
    height: 32px;
    border: 1px solid var(--egbm-border);
    background: #fff;
    color: #304464;
    border-radius: 8px;
    font-size: 10px;
    padding: 0 10px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 700;
}

.egbm-btn:hover {
    border-color: #c6ccda;
    background: #fafbfe;
}

.egbm-btn-primary {
    height: 32px;
    /* border: 1px solid var(--egbm-navy);
    background: var(--egbm-navy); */
    color: #fff;
    border-radius: 8px;
    font-size: 10px;
    padding: 0 11px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 800;
}

.egbm-btn-purple {
    height: 32px;
    border: 1px solid var(--egbm-purple);
    background: var(--egbm-purple);
    color: #fff;
    border-radius: 8px;
    font-size: 10px;
    padding: 0 11px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 800;
}

.egbm-btn-danger {
    height: 32px;
    border: 1px solid #f0d2d0;
    background: #fff;
    color: var(--egbm-danger);
    border-radius: 8px;
    font-size: 10px;
    padding: 0 10px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 700;
}

.egbm-icon-btn {
    width: 32px;
    height: 32px;
    border: 1px solid var(--egbm-border);
    background: #fff;
    /* color: var(--egbm-navy); */
    border-radius: 8px;
    display: inline-grid;
    place-items: center;
    transition: .16s ease;
}

.egbm-icon-btn:hover {
    background: #f7f8fb;
    border-color: #cdd3df;
    color: var(--egbm-purple);
}

.egbm-workspace-body {
    padding: 0 0 28px;
}

.egbm-toplink-strip {
    display: flex;
    gap: 7px;
    align-items: center;
    padding: 10px 14px 9px;
    background: #fff;
    border-bottom: 1px solid #edf0f5;
    overflow: auto;
}

.egbm-toplink {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    border: 1px solid #eceef4;
    background: #fbfcfe;
    padding: 5px 8px;
    border-radius: 7px;
    color: #355072;
    text-decoration: none;
}

.egbm-toplink:hover {
    background: #f7f7fb;
    border-color: #f0d2d0;
    color: var(--egbm-purple);
}

.egbm-toplink img {
    width: 16px;
    height: 16px;
    object-fit: contain;
    border-radius: 3px;
}

.egbm-toplink .tn {
    font-size: 9px;
    font-weight: 800;
    max-width: 180px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.egbm-toplink .tc {
    font-size: 8px;
    color: #9aa2b0;
}

.egbm-canvas {
    padding: 12px 14px 22px;
}

.egbm-category {
    background: #fff;
    border: 1px solid var(--egbm-border);
    border-radius: 9px;
    margin-bottom: 10px;
    overflow: hidden;
}

.egbm-category-head {
    min-height: 42px;
    padding: 0 9px 0 11px;
    border-bottom: 1px solid #edf0f5;
    display: flex;
    align-items: center;
    gap: 7px;
}

.egbm-category-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    flex: 0 0 auto;
}

.egbm-category-title {
    font-size: 10px;
    font-weight: 900;
    color: #2a466d;
    flex: 1;
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.egbm-category-count {
    font-size: 8px;
    color: #939bad;
}

.egbm-category-toggle {
    border: 0;
    background: transparent;
    color: #8f98a7;
    width: 24px;
    height: 24px;
    display: grid;
    place-items: center;
}

.egbm-category-more {
    border: 0;
    background: transparent;
    color: #8f98a7;
    width: 27px;
    height: 27px;
    border-radius: 7px;
}

.egbm-category-more:hover {
    background: #f5f6f9;
}

.egbm-category-tools {
    display: flex;
    align-items: center;
    gap: 2px;
}

.egbm-add-row {
    height: 48px;
    border-bottom: 1px solid #f1f3f7;
    padding: 7px 10px;
    display: flex;
    align-items: center;
    gap: 8px;
    background: #fcfdff;
}

.egbm-add-row i {
    color: #8f98a7;
    font-size: 16px;
}

.egbm-url-input {
    width: 100%;
    height: 32px;
    border: 0;
    outline: 0;
    background: transparent;
    font-size: 10px;
    color: #29436b;
}

.egbm-url-input::placeholder {
    color: #a1a8b5;
}

.egbm-link-row {
    min-height: 54px;
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 7px 10px;
    border-bottom: 1px solid #f1f3f7;
}

.egbm-link-row:last-child {
    border-bottom: 0;
}

.egbm-link-row:hover {
    background: #fcfcfe;
}

.egbm-link-favicon {
    width: 30px;
    height: 30px;
    border: 1px solid #eaedf2;
    border-radius: 8px;
    display: grid;
    place-items: center;
    background: #f8f9fb;
    position: relative;
    overflow: hidden;
    flex: 0 0 auto;
}

.egbm-link-favicon img {
    position: absolute;
    width: 20px;
    height: 20px;
    object-fit: contain;
    border-radius: 4px;
}

.egbm-link-favicon .fallback {
    font-size: 15px;
    color: #8e97a7;
}

.egbm-link-main {
    min-width: 0;
    flex: 1;
}

.egbm-link-title {
    font-size: 10px;
    font-weight: 800;
    color: #24426f;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.egbm-link-url {
    font-size: 8.5px;
    color: #8c96a7;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-top: 2px;
}

.egbm-link-note {
    font-size: 8px;
    color: #a2aab7;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-top: 2px;
}

.egbm-link-actions {
    display: flex;
    align-items: center;
    gap: 3px;
    opacity: .88;
}

.egbm-link-action {
    border: 0;
    background: transparent;
    color: #8a94a5;
    width: 27px;
    height: 27px;
    border-radius: 7px;
    display: grid;
    place-items: center;
}

.egbm-link-action:hover {
    background: #f4f5f8;
    color: var(--egbm-purple);
}

.egbm-link-action i {
    font-size: 14px;
}

.egbm-link-status {
    font-size: 8px;
    border-radius: 999px;
    padding: 3px 6px;
}

.egbm-health-healthy {
    background: #e8f5ed;
    color: #2d7959;
}

.egbm-health-broken {
    background: #fbeceb;
    color: #af3029;
}

.egbm-health-unknown {
    background: #eef1f5;
    color: #727c90;
}

.egbm-category-collapsed .egbm-add-row,
.egbm-category-collapsed .egbm-link-list {
    display: none;
}

.egbm-hidden-note {
    padding: 7px 11px;
    color: #9ba4b3;
    font-size: 8px;
    background: #fafbfc;
    border-bottom: 1px solid #f0f2f6;
}

.egbm-empty {
    min-height: 260px;
    display: grid;
    place-items: center;
    background: #fff;
    border: 1px dashed #dce1e9;
    border-radius: 9px;
    text-align: center;
    padding: 26px;
}

.egbm-empty i {
    font-size: 36px;
    color: #c3c9d4;
    margin-bottom: 8px;
}

.egbm-empty-title {
    font-size: 12px;
    font-weight: 800;
    color: #52627c;
}

.egbm-empty-text {
    font-size: 9px;
    color: #9099a9;
    margin-top: 3px;
}

.egbm-locked-banner {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    margin: 10px 14px 0;
    background: #fff9e9;
    border: 1px solid #f0e1bb;
    border-radius: 8px;
    font-size: 9px;
    color: #8b7130;
}

.egbm-locked-banner i {
    font-size: 15px;
}

.egbm-skeleton-shell {
    padding: 0;
    background: var(--egbm-bg);
}

.egbm-sk-head {
    height: 59px;
    background: #fff;
    border-bottom: 1px solid var(--egbm-border);
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 0 14px;
}

.egbm-sk-line {
    height: 10px;
    border-radius: 6px;
    background: linear-gradient(90deg, #eef1f5, #f8f9fb, #eef1f5);
    background-size: 200% 100%;
    animation: egbmShimmer 1.35s linear infinite;
}

.egbm-sk-board {
    width: 60px;
}

.egbm-sk-title {
    width: 130px;
}

.egbm-sk-search {
    margin-left: auto;
    width: 210px;
}

.egbm-sk-btn {
    width: 62px;
}

.egbm-sk-body {
    display: grid;
    grid-template-columns: 232px 1fr;
    min-height: calc(100vh - 200px);
    background: #fff;
}

.egbm-sk-left {
    border-right: 1px solid var(--egbm-border);
    padding: 14px;
}

.egbm-sk-right {
    padding: 12px 14px;
}

.egbm-sk-item {
    height: 33px;
    border-radius: 7px;
    margin-bottom: 6px;
}

.egbm-sk-cat {
    height: 120px;
    border: 1px solid #edf0f5;
    border-radius: 8px;
    margin-bottom: 10px;
    padding: 14px;
}

.egbm-sk-row {
    height: 14px;
    width: 65%;
    margin-bottom: 12px;
}

.egbm-sk-row.wide {
    width: 90%;
}

@keyframes egbmShimmer {
    0% {
        background-position: 200% 0;
    }

    100% {
        background-position: -200% 0;
    }
}

.egbm-error {
    margin: 16px;
    padding: 18px;
    border: 1px solid #efccca;
    background: #fff5f4;
    border-radius: 8px;
    color: #9e332d;
    text-align: center;
    font-size: 10px;
}

.egbm-error i {
    font-size: 24px;
    display: block;
    margin-bottom: 6px;
}

/* .egbm-modal {
    border: 1px solid var(--egbm-border);
    border-radius: 12px;
    box-shadow: 0 24px 55px rgba(31, 56, 100, .22);
} */

.egbm-modal .modal-header {
    padding: 14px 16px;
    border-bottom: 1px solid #edf0f5;
}

.egbm-modal .modal-footer {
    padding: 11px 16px;
    border-top: 1px solid #edf0f5;
}

.egbm-modal .modal-body {
    padding: 16px;
}

.egbm-modal-kicker {
    font-size: 8px;
    font-weight: 900;
    letter-spacing: .1em;
    color: #8a94a7;
}

.egbm-modal .modal-title {
    font-size: 16px;
    font-weight: 800;
    /* color: var(--egbm-navy); */
    margin: 3px 0;
}

.egbm-modal .form-label {
    font-size: 9px;
    font-weight: 800;
    /* color: #4e607d; */
    margin-bottom: 5px;
}

.egbm-modal .form-control,
.egbm-modal .form-select {
    font-size: 10px;
    min-height: 35px;
    border-color: var(--egbm-border);
    border-radius: 7px; 
}

.egbm-modal textarea.form-control {
    min-height: 80px;
}

.egbm-modal .form-text {
    font-size: 8px;
    color: #98a1b0;
    margin-top: 4px;
}

.egbm-check-row {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
}

.egbm-check-row input {
    position: absolute;
    opacity: 0;
}

.egbm-check-box {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    border: 1px solid var(--egbm-border);
    display: grid;
    place-items: center;
    background: #fff;
    color: #a0a7b4;
}

.egbm-check-row input:checked+.egbm-check-box {
    background: var(--egbm-purple);
    border-color: var(--egbm-purple);
    color: #fff;
}

.egbm-check-row strong {
    font-size: 9px;
    display: block;
    color: #3a5278;
}

.egbm-check-row small {
    font-size: 8px;
    display: block;
    color: #98a1b0;
    margin-top: 2px;
}

.egbm-upload-box {
    border: 1px dashed #cfd5e1;
    border-radius: 9px;
    background: #fbfcfe;
    padding: 14px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.egbm-upload-icon {
    width: 38px;
    height: 38px;
    border-radius: 9px;
    background: #fbeceb;
    color: var(--egbm-purple);
    display: grid;
    place-items: center;
    font-size: 18px;
}

.egbm-import-summary {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 8px;
    margin-bottom: 15px;
}

.egbm-summary-card {
    padding: 9px 10px;
    border: 1px solid #edf0f5;
    border-radius: 8px;
    background: #fbfcfe;
}

.egbm-summary-card .n {
    font-size: 16px;
    font-weight: 900;
    /* color: var(--egbm-navy); */
}

.egbm-summary-card .t {
    font-size: 8px;
    color: #8992a4;
    text-transform: uppercase;
    letter-spacing: .06em;
    margin-top: 2px;
}

.egbm-import-section-title {
    font-size: 9px;
    font-weight: 900;
    letter-spacing: .08em;
    color: #69758a;
    margin-bottom: 7px;
}

.egbm-import-row {
    display: grid;
    grid-template-columns: minmax(230px, 1.2fr) minmax(240px, 1fr);
    gap: 12px;
    align-items: center;
    border: 1px solid #edf0f5;
    border-radius: 8px;
    padding: 9px 10px;
    margin-bottom: 7px;
    background: #fff;
}

.egbm-import-folder {
    display: flex;
    align-items: flex-start;
    gap: 8px;
    min-width: 0;
}

.egbm-import-folder i {
    color: #c89a46;
    font-size: 15px;
}

.egbm-import-folder strong {
    display: block;
    font-size: 9px;
    color: #2f486c;
}

.egbm-import-folder small {
    display: block;
    font-size: 8px;
    color: #9ba3b2;
    margin-top: 2px;
}

.egbm-share-list-head {
    font-size: 9px;
    font-weight: 900;
    letter-spacing: .08em;
    color: #69758a;
}

.egbm-share-list {
    border: 1px solid #edf0f5;
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
}

.egbm-share-row {
    display: flex;
    align-items: center;
    gap: 9px;
    padding: 9px 10px;
    border-bottom: 1px solid #f0f2f6;
}

.egbm-share-row:last-child {
    border-bottom: 0;
}

.egbm-share-avatar {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: #fbeceb;
    color: var(--egbm-purple);
    display: grid;
    place-items: center;
    font-size: 8px;
    font-weight: 900;
    flex: 0 0 auto;
}

.egbm-share-main {
    min-width: 0;
    flex: 1;
}

.egbm-share-main strong {
    display: block;
    font-size: 9px;
    color: #344f76;
}

.egbm-share-main small {
    display: block;
    font-size: 8px;
    color: #99a2b2;
    margin-top: 2px;
}

.egbm-share-pill {
    font-size: 8px;
    border-radius: 999px;
    padding: 4px 7px;
    background: #eef1f5;
    color: #697488;
}

.egbm-share-pill.co {
    background: #fbeceb;
    color: #b52b25;
}

.egbm-share-pill.pending {
    background: #fff2d7;
    color: #9b6b00;
}

.egbm-confirm-icon {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background: #fff2d7;
    color: #aa7200;
    margin: 0 auto 11px;
    font-size: 20px;
}

/* Select3 look: same compact Bootstrap/Select2 language used elsewhere in the ERP. */
#egBookMarks .select2-container {
    width: 100% !important;
    /* font-size: 10px; */
}

.select2-container--default .select2-selection--single {
    height: 35px !important;
    /* border: 1px solid var(--egbm-border) !important; */
    /* border-radius: 7px !important;
    background: #fff !important; */
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    font-size: 10px !important;
    color: #3c4f6b !important;
    line-height: 33px !important;
    padding-left: 10px !important;
}

.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 33px !important;
}

.select2-dropdown {
    /* border-color: var(--egbm-border) !important; */
    /* border-radius: 7px !important; */
    overflow: hidden;
    box-shadow: 0 12px 30px rgba(31, 56, 100, .15);
}

.select2-results__option {
    /* font-size: 9px; */
    padding: 8px 10px;
}

.select2-container--default .select2-results__option--highlighted[aria-selected] {
    background: var(--egbm-purple) !important;
}

.select2-search--dropdown .select2-search__field {
    /* font-size: 10px; */
    /* border-radius: 6px; */
}

.egbm-board-rail-open {
    transform: translateX(0) !important;
}

.egbm-mobile-board-overlay {
    display: none;
}

@media(max-width:991px) {
    .egbm-layout {
        grid-template-columns: 200px minmax(0, 1fr);
    }

    .egbm-board-search {
        width: 180px;
    }

    .egbm-top-links-label {
        display: none;
    }

    .egbm-heading-meta {
        gap: 7px;
    }

    .egbm-board-rail {
        width: 200px;
    }

    .egbm-workspace-actions {
        gap: 4px;
    }
}

@media(max-width:767px) {
    #egBookMarks {
        margin: -1.5rem;
        width: calc(100% + 3rem);
    }

    .egbm-layout {
        display: block;
        position: relative;
    }

    .egbm-board-rail {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 235px;
        transform: translateX(-100%);
        transition: transform .18s ease;
        box-shadow: 14px 0 35px rgba(31, 56, 100, .12);
    }

    .egbm-main {
        min-height: calc(100vh - 140px);
    }

    .egbm-workspace-head {
        height: auto;
        min-height: 86px;
        align-items: flex-start;
        padding: 12px 10px;
        flex-direction: column;
    }

    .egbm-workspace-actions {
        /* width: 100%; */
        justify-content: flex-start;
    }

    .egbm-board-search {
        width: min(100%, 290px);
        flex: 1;
    }

    .egbm-canvas {
        padding: 10px;
    }

    .egbm-import-summary {
        grid-template-columns: repeat(2, 1fr);
    }

    .egbm-import-row {
        grid-template-columns: 1fr;
    }

    .egbm-link-actions {
        opacity: 1;
    }
}

/* BookMarks prototype-aligned surface and ERP theme integration. */
#egBookMarks {
    --egbm-primary: #b52b25;
    --egbm-primary-soft: #fbeceb;
    --egbm-accent: #f5a623;
    --egbm-category-red: #c63b33;
    --egbm-category-blue: #2267c8;
    --egbm-category-green: #27823e;
    --egbm-category-gold: #be8c06;
    --egbm-category-purple: #7b2fa2
}

#egBookMarks .egbm-layout {
    grid-template-columns: 232px minmax(0, 1fr)
}

#egBookMarks .egbm-workspace-head {
    min-height: 58px;
    height: 58px;
    padding: 0 14px;
    position: sticky;
    top: 0;
    z-index: 4
}

#egBookMarks .egbm-canvas {
    padding: 18px 22px 35px
}

#egBookMarks .egbm-category-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
    align-items: start
}

#egBookMarks .egbm-category-column {
    display: flex;
    flex-direction: column;
    gap: 16px;
    min-width: 0
}

#egBookMarks .egbm-category {
    border-top-width: 5px;
    border-radius: 10px;
    box-shadow: 0 1px 2px rgba(35, 54, 83, .04);
    transition: transform .16s ease, box-shadow .16s ease, opacity .16s ease
}

#egBookMarks .egbm-category[draggable="true"] {
    cursor: grab
}

#egBookMarks .egbm-category.egbm-dragging {
    opacity: .45;
    transform: scale(.99);
    box-shadow: 0 10px 28px rgba(31, 56, 100, .12)
}

#egBookMarks .egbm-category.egbm-drag-over {
    outline: 2px dashed var(--egbm-primary);
    outline-offset: 3px
}

#egBookMarks .egbm-category-head {
    height: 52px;
    min-height: 52px;
    padding: 0 12px
}

#egBookMarks .egbm-category-drag {
    display: none
}

#egBookMarks .egbm-category-title {
    font-size: 14px;
    color: #1b3860
}

#egBookMarks .egbm-category-count {
    font-size: 10px
}

#egBookMarks .egbm-add-row {
    height: 50px;
    margin: 9px 12px 0
}

#egBookMarks .egbm-link-list {
    padding: 8px 10px 11px
}

#egBookMarks .egbm-link-row {
    min-height: 48px;
    padding: 5px 7px
}

#egBookMarks .egbm-link-title {
    font-size: 11px;
    color: #24426f
}

#egBookMarks .egbm-link-url {
    font-size: 8.5px
}

#egBookMarks .egbm-link-actions {
    opacity: 1
}

#egBookMarks .egbm-inline-toplinks {
    display: flex;
    align-items: center;
    gap: 5px;
    margin-left: 8px;
    min-width: 0;
    max-width: 430px;
    overflow: hidden
}

#egBookMarks .egbm-inline-toplinks .egbm-top-links-label {
    font-size: 9px;
    letter-spacing: .07em;
    flex: 0 0 auto
}

#egBookMarks .egbm-inline-toplinks .egbm-toplink {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    min-width: 24px;
    height: 28px;
    padding: 3px 5px;
    border: 1px solid #e9edf3;
    background: #fafbfd;
    border-radius: 7px;
    color: #355072;
    overflow: hidden
}

#egBookMarks .egbm-inline-toplinks .egbm-toplink .egbm-link-favicon {
    width: 18px !important;
    height: 18px !important;
    border: 0;
    background: transparent
}

#egBookMarks .egbm-inline-toplinks .egbm-toplink .tn {
    display: none
}

#egBookMarks .egbm-order-help {
    display: flex;
    align-items: center;
    gap: 6px;
    border: 1px dashed #d7dfeb;
    background: #fafbfe;
    border-radius: 7px;
    padding: 8px 10px;
    color: #7b8799;
    font-size: 10px
}

#egBookMarks .egbm-order-help i {
    color: var(--egbm-primary);
    font-size: 15px
}

#egBookMarks .egbm-btn-primary {
    background: var(--egbm-primary);
    border-color: var(--egbm-primary)
}

#egBookMarks .egbm-btn-purple {
    background: var(--egbm-accent);
    border-color: var(--egbm-accent)
}

#egBookMarks .egbm-toplink:hover {
    border-color: var(--egbm-primary);
    color: var(--egbm-primary)
}

@media(max-width:1250px) {
    #egBookMarks .egbm-category-grid {
        gap: 14px
    }

    #egBookMarks .egbm-inline-toplinks {
        max-width: 300px
    }
}

@media(max-width:1050px) {
    #egBookMarks .egbm-category-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr))
    }
}

@media(max-width:800px) {
    #egBookMarks .egbm-category-grid {
        grid-template-columns: 1fr
    }
}
</style>

<style>
    .egbm-company-pill {
        display: inline-flex;
        align-items: center;
        max-width: 190px;
        padding: 4px 8px;
        border: 1px solid #e4e8ef;
        border-radius: 999px;
        background: #f8f9fb;
        color: #6f7a8f;
        font-size: 9px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .egbm-visibility-panel {
        display: flex;
        align-items: flex-start;
        gap: 11px;
        padding: 11px 12px;
        border: 1px solid #e5e9f0;
        border-radius: 9px;
        background: #fbfcfe;
    }

    .egbm-visibility-panel-icon {
        width: 30px;
        height: 30px;
        flex: 0 0 30px;
        border-radius: 8px;
        display: grid;
        place-items: center;
        background: #fbeceb;
        color: #b52b25;
        font-size: 16px;
    }

    .egbm-visibility-panel .select2-container--default .select2-selection--multiple {
        min-height: 38px;
        border-color: #dfe3ec;
        border-radius: 7px;
    }

    .egbm-visibility-panel .select2-container--default.select2-container--focus .select2-selection--multiple,
    .egbm-visibility-panel .select2-container--default .select2-selection--multiple:focus {
        border-color: #b52b25;
    }

    .egbm-visibility-panel .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background: #fbeceb;
        border-color: #f1c6c3;
        color: #8f241f;
        font-size: 9px;
    }



    .skeleton-glow {
        background: linear-gradient(90deg, #eef1f5, #f8f9fb, #eef1f5);
        background-size: 200% 100%;
        animation: egbmShimmer 1.35s linear infinite;
    }

    .egbm-favicon-preview {
        display: flex;
        align-items: center;
        gap: 9px;
        border: 1px solid #e8ebf1;
        background: #fbfcfe;
        border-radius: 8px;
        padding: 9px;
    }

    .egbm-favicon-preview>i {
        font-size: 17px;
        color: #4a3e8e;
    }

    .egbm-favicon-preview strong {
        display: block;
        font-size: 9px;
        color: #385171;
    }

    .egbm-favicon-preview small {
        display: block;
        font-size: 8px;
        color: #97a0ae;
        margin-top: 2px;
    }

    /* ============================================================
       Common Board Creation Modal
       ============================================================ */
   

    #egBookMarks .egbm-board-modal-header {
        padding: 18px 20px;
        background: linear-gradient(135deg, #ffffff 0%, #f9fbff 100%);
        border-bottom: 1px solid #e9edf4;
    }

    #egBookMarks .egbm-board-modal-icon {
        width: 42px;
        height: 42px;
        flex: 0 0 42px;
        border-radius: 12px;
        display: grid;
        place-items: center;
        background: #fbeceb;
        color: #b52b25;
        font-size: 21px;
    }

    #egBookMarks .egbm-board-modal-subtitle {
        color: #7f8ca0;
        font-size: 11px;
        line-height: 1.4;
    }

   

    #egBookMarks .egbm-board-scope-banner {
        display: flex;
        align-items: center;
        gap: 11px;
        padding: 11px 12px;
        margin-bottom: 16px;
        border: 1px solid #dce5f2;
        border-radius: 11px;
        background: #f7faff;
    }

    #egBookMarks .egbm-board-scope-icon {
        width: 32px;
        height: 32px;
        flex: 0 0 32px;
        border-radius: 9px;
        display: grid;
        place-items: center;
        background: #eaf1ff;
        color: #2860b9;
        font-size: 16px;
    }

    #egBookMarks .egbm-board-scope-title {
        color: #24466f;
        font-size: 10px;
        font-weight: 900;
        letter-spacing: .04em;
        text-transform: uppercase;
    }

    #egBookMarks .egbm-board-scope-text {
        margin-top: 2px;
        color: #7f8da1;
        font-size: 9px;
        line-height: 1.35;
    }

    #egBookMarks .egbm-board-scope-badge {
        margin-left: auto;
        flex: 0 0 auto;
        padding: 5px 8px;
        border-radius: 999px;
        background: #eaf1ff;
        color: #2860b9;
        font-size: 8px;
        font-weight: 900;
        letter-spacing: .08em;
    }

    #egBookMarks .egbm-board-section {
        padding: 15px;
        border: 1px solid #e3e8f0;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(31, 56, 100, .025);
    }

    #egBookMarks .egbm-board-section + .egbm-board-section {
        margin-top: 12px;
    }

    #egBookMarks .egbm-board-section-heading {
        display: flex;
        align-items: flex-start;
        gap: 9px;
        margin-bottom: 13px;
    }

    #egBookMarks .egbm-board-section-index {
        flex: 0 0 auto;
        min-width: 24px;
        padding-top: 1px;
        color: #b52b25;
        font-size: 9px;
        font-weight: 900;
        letter-spacing: .05em;
    }

    #egBookMarks .egbm-board-section-title {
        /* color:black28466e; */
        font-size: 11px;
        font-weight: 900;
    }

    #egBookMarks .egbm-board-section-help {
        margin-top: 2px;
        color: #96a1b2;
        font-size: 8.5px;
        line-height: 1.35;
    }

    #egBookMarks .egbm-board-section .form-label.required::after {
        content: ' *';
        color: #b52b25;
    }

    #egBookMarks .egbm-visibility-choice-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 9px;
    }

    #egBookMarks .egbm-visibility-choice {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 9px;
        width: 100%;
        min-height: 96px;
        padding: 11px;
        border: 1px solid #e1e6ee;
        border-radius: 11px;
        background: #fff;
        color: #334c6f;
        text-align: left;
        transition: border-color .15s ease, box-shadow .15s ease, background .15s ease, transform .15s ease;
    }

    #egBookMarks .egbm-visibility-choice:hover {
        border-color: #c8d4e5;
        box-shadow: 0 6px 18px rgba(31, 56, 100, .06);
        transform: translateY(-1px);
    }

    #egBookMarks .egbm-visibility-choice.is-active {
        border-color: #b52b25;
        background: #fffafa;
        box-shadow: 0 0 0 2px rgba(181, 43, 37, .08);
    }

    #egBookMarks .egbm-visibility-choice-icon {
        width: 32px;
        height: 32px;
        flex: 0 0 32px;
        border-radius: 9px;
        display: grid;
        place-items: center;
        background: #f3f5f9;
        color: #6d7c91;
        font-size: 16px;
    }

    #egBookMarks .egbm-visibility-choice.is-active .egbm-visibility-choice-icon {
        background: #fbeceb;
        color: #b52b25;
    }

    #egBookMarks .egbm-visibility-choice-copy {
        min-width: 0;
        padding-right: 14px;
    }

    #egBookMarks .egbm-visibility-choice-copy strong {
        display: block;
        color: #2b476d;
        font-size: 10px;
        font-weight: 900;
    }

    #egBookMarks .egbm-visibility-choice-copy small {
        display: block;
        margin-top: 4px;
        color: #8b97a9;
        font-size: 8.5px;
        line-height: 1.4;
    }

    #egBookMarks .egbm-visibility-choice-check {
        position: absolute;
        top: 9px;
        right: 9px;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: #e9edf3;
        color: transparent;
        font-size: 11px;
    }

    #egBookMarks .egbm-visibility-choice.is-active .egbm-visibility-choice-check {
        background: #b52b25;
        color: #fff;
    }

    #egBookMarks .egbm-visibility-target-card {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        margin-top: 11px;
        padding: 11px 12px;
        border: 1px solid #e2e7ef;
        border-radius: 10px;
        background: #fafbfd;
    }

    #egBookMarks .egbm-visibility-target-icon {
        width: 31px;
        height: 31px;
        flex: 0 0 31px;
        border-radius: 8px;
        display: grid;
        place-items: center;
        background: #fbeceb;
        color: #b52b25;
        font-size: 15px;
    }

    #egBookMarks .egbm-visibility-target-card .select2-container {
        width: 100% !important;
        min-width: 0;
    }

    #egBookMarks .egbm-visibility-target-card .select2-selection--multiple {
        min-height: 40px !important;
        padding: 3px 6px !important;
        border: 1px solid #dfe3ec !important;
        border-radius: 7px !important;
        background: #fff !important;
        cursor: pointer;
    }

    #egBookMarks .egbm-visibility-target-card .select2-selection--multiple:focus,
    #egBookMarks .egbm-visibility-target-card .select2-container--focus .select2-selection--multiple {
        border-color: #b52b25 !important;
        box-shadow: 0 0 0 2px rgba(181, 43, 37, .08) !important;
    }

    #egBookMarks .egbm-visibility-target-card .select2-selection__rendered {
        margin: 0 !important;
        padding: 0 !important;
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
    }

    #egBookMarks .egbm-visibility-target-card .select2-selection__choice {
        margin: 2px 0 !important;
        padding: 3px 7px !important;
        border: 1px solid #f1c6c3 !important;
        border-radius: 999px !important;
        background: #fbeceb !important;
        color: #8f241f !important;
        font-size: 9px !important;
        line-height: 1.25 !important;
    }

    #egBookMarks .egbm-visibility-target-card .select2-search__field {
        min-width: 120px !important;
        margin-top: 3px !important;
        font-size: 10px !important;
    }

    #egBookMarks .egbm-lock-option {
        position: relative;
        display: flex;
        align-items: center;
        gap: 11px;
        margin: 0;
        padding: 12px;
        border: 1px solid #e1e6ee;
        border-radius: 10px;
        background: #fafbfd;
        cursor: pointer;
        transition: border-color .15s ease, background .15s ease, box-shadow .15s ease;
    }

    #egBookMarks .egbm-lock-option input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
    }

    #egBookMarks .egbm-lock-option-icon {
        width: 34px;
        height: 34px;
        flex: 0 0 34px;
        border-radius: 9px;
        display: grid;
        place-items: center;
        background: #eef1f5;
        color: #728095;
        font-size: 17px;
    }

    #egBookMarks .egbm-lock-option-copy {
        min-width: 0;
        flex: 1;
    }

    #egBookMarks .egbm-lock-option-copy strong {
        display: block;
        color: #2b476d;
        font-size: 10px;
        font-weight: 900;
    }

    #egBookMarks .egbm-lock-option-copy small {
        display: block;
        margin-top: 3px;
        color: #909cad;
        font-size: 8.5px;
        line-height: 1.4;
    }

    #egBookMarks .egbm-lock-option-check {
        width: 22px;
        height: 22px;
        flex: 0 0 22px;
        border-radius: 7px;
        display: grid;
        place-items: center;
        border: 1px solid #d9dfe8;
        background: #fff;
        color: transparent;
        font-size: 12px;
    }

    #egBookMarks .egbm-lock-option:has(input:checked) {
        border-color: #c9b67a;
        background: #fffdf7;
        box-shadow: 0 0 0 2px rgba(200, 154, 70, .07);
    }

    #egBookMarks .egbm-lock-option:has(input:checked) .egbm-lock-option-icon {
        background: #fff2d7;
        color: #a56d00;
    }

    #egBookMarks .egbm-lock-option:has(input:checked) .egbm-lock-option-check {
        border-color: #b52b25;
        background: #b52b25;
        color: #fff;
    }

   

    #egBookMarks .egbm-board-footer-note {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-right: auto;
        color: #91a0b4;
        font-size: 8.5px;
    }

    #egBookMarks .egbm-board-footer-note i {
        color: #2d7b59;
        font-size: 14px;
    }

    @media (max-width: 767px) {
        #egBookMarks .egbm-visibility-choice-grid {
            grid-template-columns: 1fr;
        }

        #egBookMarks .egbm-board-scope-banner {
            align-items: flex-start;
        }

        #egBookMarks .egbm-board-scope-badge {
            margin-top: 1px;
        }

     

        #egBookMarks .egbm-board-footer-note {
            margin-right: 0;
        }

        
    }
    </style>

<style>
    :root {
        --egbm-navy: #203b68;
        --egbm-purple: #4a3b93;
        --egbm-border: #dfe4ee;
        --egbm-bg: #f4f6fa;
        --egbm-muted: #75839a;
    }

    html,
    body {
        background: var(--egbm-bg) !important;
    }

    .egbm-page {
        position: relative;
        margin: -1rem -1.5rem 0 !important;
        min-height: calc(100vh - 1rem);
        background: var(--egbm-bg);
        color: #17345d;
        font-size: 14px;
        overflow-x: hidden;
    }

    .egbm-prototype-header {
        height: 86px;
        display: flex;
        align-items: center;
        gap: 13px;
        padding: 0 20px 0 15px;
        background: #fff;
        border-bottom: 1px solid #e2e6ee;
        position: sticky;
        top: 0;
        z-index: 1040;
    }

    .egbm-proto-search-wrap {
        position: relative;
        width: 456px;
        flex: 0 0 456px;
    }

    .egbm-proto-search-wrap>i {
        position: absolute;
        left: 18px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 23px;
        color: #54709c;
        z-index: 2;
    }

    .egbm-proto-search {
        width: 100%;
        height: 42px;
        border: 1px solid #d7dfeb;
        border-radius: 9px;
        background: #f5f7fb;
        padding: 0 16px 0 50px;
        font-size: 16px;
        outline: 0;
        color: #1b3862;
    }

    .egbm-proto-search:focus {
        border-color: #b5c3dc;
        background: #fff;
        box-shadow: 0 0 0 3px rgba(70, 89, 145, .06);
    }

   

    .egbm-proto-spacer {
        flex: 1 1 auto;
    }

    .egbm-proto-field {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #738098;
        font-size: 14px;
        white-space: nowrap;
    }

    .egbm-proto-select {
        height: 36px;
        border: 1px solid #cbd4e3;
        border-radius: 8px;
        background: #fff;
        padding: 0 34px 0 11px;
        color: #40358a;
        font-size: 14px;
        font-weight: 500;
        min-width: 98px;
    }

    .egbm-proto-field:nth-of-type(2) .egbm-proto-select {
        min-width: 158px;
    }

    .egbm-proto-icon,
    .egbm-proto-notify,
    .egbm-proto-chevron {
        border: 0;
        background: transparent;
        color: #234c80;
        width: 34px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }

    .egbm-proto-notify {
        position: relative;
    }

    .egbm-notify-badge {
        position: absolute;
        right: -1px;
        top: 2px;
        min-width: 20px;
        height: 20px;
        padding: 0 5px;
        border-radius: 12px;
        background: #c61f2e;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid #fff;
    }

    .egbm-avatar {
        width: 40px;
        height: 40px;
        border: 0;
        border-radius: 50%;
        background: #51429a;
        color: #fff;
        font-weight: 700;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .egbm-header-popover {
        position: absolute;
        top: 66px;
        right: 76px;
        width: 310px;
        background: #fff;
        border: 1px solid #dee4ed;
        border-radius: 12px;
        box-shadow: 0 18px 45px rgba(28, 50, 87, .18);
        z-index: 1100;
        padding: 12px;
    }

    .egbm-notification-popover {
        right: 118px
    }

    .egbm-popover-title {
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .08em;
        color: #68778e;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 3px 6px 9px;
    }

    .egbm-app-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 9px 8px;
        border-radius: 8px;
        text-decoration: none;
        color: #26466f;
        font-size: 13px;
    }

    .egbm-app-item:hover {
        background: #f5f6fb;
    }

    .egbm-app-item i {
        font-size: 18px;
        color: #4d4295;
    }

    .egbm-notify-row {
        display: flex;
        gap: 10px;
        padding: 9px 7px;
        border-radius: 8px;
    }

    .egbm-notify-row.unread {
        background: #f6f5fb;
    }

    .egbm-notify-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #4d4295;
        margin-top: 6px;
        flex: 0 0 7px;
    }

    .egbm-notify-row strong {
        display: block;
        font-size: 12px;
        color: #203a62;
    }

    .egbm-notify-row small {
        display: block;
        font-size: 11px;
        color: #78849a;
        line-height: 1.35;
        margin-top: 2px;
    }

    .egbm-search-empty {
        padding: 22px;
        text-align: center;
        font-size: 12px;
        color: #8893a8;
    }

    .egbm-global-search-results {
        position: absolute;
        left: 0;
        right: 0;
        top: 49px;
        background: #fff;
        border: 1px solid #dde3ec;
        border-radius: 10px;
        box-shadow: 0 18px 42px rgba(29, 46, 77, .16);
        padding: 7px;
        z-index: 1200;
        max-height: 420px;
        overflow: auto;
    }

    .egbm-search-result {
        width: 100%;
        display: flex;
        gap: 10px;
        align-items: center;
        border: 0;
        background: #fff;
        text-align: left;
        padding: 9px;
        border-radius: 8px;
    }

    .egbm-search-result:hover {
        background: #f6f7fb;
    }

    .egbm-search-result-icon {
        width: 30px;
        height: 30px;
        border-radius: 8px;
        background: #f0f1f7;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #4a3e8e;
    }

    .egbm-search-result strong {
        display: block;
        font-size: 12px;
        color: #1e3b62;
    }

    .egbm-search-result small {
        display: block;
        font-size: 10px;
        color: #7f8ba1;
        margin-top: 2px;
    }

    .egbm-layout {
        display: grid;
        grid-template-columns: 285px minmax(0, 1fr);
        min-height: calc(100vh - 86px);
        gap: 0;
    }

    .egbm-board-rail {
        background: #fff;
        border-right: 1px solid #e0e4eb;
        padding: 23px 12px 30px;
        position: relative;
    }

    .egbm-rail-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        /* padding: 0 5px 12px */
    }

    .egbm-rail-title {
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .08em;
        color: #78879f;
    }

    .egbm-rail-add {
        width: 26px;
        height: 26px;
        border: 0;
        background: transparent;
        /* color: #4a3c94; */
        font-size: 23px;
        padding: 0;
    }

    .egbm-board-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
    }

    .egbm-board-item {
        display: grid !important;
        grid-template-columns: minmax(0, 1fr) auto auto;
        align-items: center;
        width: 100%;
        min-height: 40px;
        border: 0;
        border-radius: 8px;
        background: transparent;
        text-align: left;
        padding: 0 12px;
        color: #ab2b22;
        font-size: 14px;
        font-weight: 500;
    }

    .egbm-board-item:hover {
        background: #f1eceb;
    }

    .egbm-board-item.active {
        background: #fbeceb;
        color: #ab2b22;
        font-weight: 700;
    }

    .egbm-board-item .name {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .egbm-board-item .lock {
        color: #576b86;
        font-size: 15px;
        margin-left: 8px;
    }

    .egbm-board-item .count {
        color: #91a0b5;
        font-size: 12px;
        margin-left: 10px;
    }

    .egbm-main {
        min-width: 0;
        background: var(--egbm-bg);
    }

    .egbm-workspace-head {
        min-height: 74px;
        background: #fff;
        border-bottom: 1px solid #dfe4ed;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        padding: 0 26px;
        position: sticky;
        top: 86px;
        z-index: 900;
    }

    .egbm-heading-meta {
        display: flex;
        align-items: center;
        gap: 15px;
        min-width: 0;
        flex: 1;
    }

    .egbm-board-title-block h2 {
        margin: 0;
        /* color: #173862; */
        font-size: 22px;
        line-height: 1.1;
        font-weight: 700;
        white-space: nowrap;
    }

    .egbm-board-subline {
        display: flex;
        align-items: center;
        gap: 7px;
        margin-top: 5px;
    }

    .egbm-company-pill {
        font-size: 10px !important;
        padding: 3px 7px !important;
        background: #f8f9fc !important;
        color: #718099 !important;
        border-color: #e1e5ed !important;
    }

    .egbm-company-pill i {
        margin-right: 4px;
    }

    .egbm-lock-pill {
        font-size: 10px;
        color: #936b17;
        background: #fff8de;
        border: 1px solid #eee0aa;
        border-radius: 999px;
        padding: 3px 7px;
    }

    .egbm-inline-toplinks {
        display: flex;
        align-items: center;
        gap: 9px;
        min-width: 0;
        margin-left: 12px;
    }

    .egbm-top-links-label {
        font-size: 11px;
        color: #71809a;
        font-weight: 700;
        letter-spacing: .04em;
        white-space: nowrap;
    }

    .egbm-toplink {
        width: 30px;
        height: 30px;
        padding: 0;
        border: 0;
        background: #fff;
        border-radius: 7px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .egbm-toplink:hover {
        background: #f4f5f9;
    }

    .egbm-toplink .egbm-link-favicon {
        width: 22px !important;
        height: 22px !important;
    }

    .egbm-workspace-actions {
        display: flex;
        align-items: center;
        gap: 9px;
        flex: 0 0 auto;
    }

    .egbm-board-search {
        height: 40px;
        width: 279px;
        border: 1px solid #d7dfe9;
        background: #f7f8fb;
        border-radius: 9px;
        display: flex;
        align-items: center;
        padding: 0 11px;
        color: #74819b;
    }

    .egbm-board-search input {
        border: 0 !important;
        background: transparent !important;
        box-shadow: none !important;
        outline: 0 !important;
        width: 100%;
        height: 100%;
        font-size: 13px;
        color: #2a466e;
    }

    .egbm-board-search i {
        font-size: 19px;
        margin-right: 7px;
    }

    .egbm-inline-clear {
        border: 0;
        background: transparent;
        color: #8793a6;
        padding: 0;
    }

    .egbm-btn,
    .egbm-btn-purple,
    .egbm-btn-primary {
        height: 40px;
        border-radius: 9px;
        padding: 0 16px;
        border: 1px solid #d7deea;
        background: #fff;
        color: #28466d;
        font-size: 13px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 7px;
    }

    .egbm-btn-purple {
        background: #4b3d92;
        color: #fff;
        border-color: #4b3d92;
    }

    .egbm-btn-primary {
        background: #203d69;
        color: #fff;
        border-color: #203d69;
    }

    .egbm-icon-btn {
        width: 38px;
        height: 38px;
        border: 1px solid #d9e0ea;
        background: #fff;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #6a7b95;
    }

    .egbm-mobile-boards {
        display: none;
    }

    .egbm-toplinks-empty {
        font-size: 11px;
        color: #8491a7;
        letter-spacing: .05em;
        margin-left: 12px;
    }

    .egbm-canvas {
        padding: 18px 25px 35px;
    }

    .egbm-category-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 20px;
        align-items: start;
    }

    .egbm-category-column {
        display: flex;
        flex-direction: column;
        gap: 20px;
        min-width: 0;
    }

    .egbm-category {
        background: #fff;
        border: 1px solid #dfe4ec;
        border-top: 5px solid var(--egbm-category-color, #4a3e8e);
        border-radius: 12px;
        overflow: visible;
        box-shadow: 0 1px 2px rgba(35, 54, 83, .03);
    }

    .egbm-category-head {
        height: 52px;
        display: flex;
        align-items: center;
        gap: 9px;
        padding: 0 14px;
        border-bottom: 1px solid #edf0f5;
    }

    .egbm-category-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: var(--egbm-category-color, #4a3e8e);
        flex: 0 0 7px;
    }

    .egbm-category-title {
        font-size: 15px;
        font-weight: 700;
        color: #1b3860;
        flex: 1;
        min-width: 0;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .egbm-category-count {
        font-size: 11px;
        color: #98a4b6;
    }

    .egbm-category-toggle,
    .egbm-category-more {
        border: 0;
        background: transparent;
        color: #8190a8;
        width: 24px;
        height: 30px;
        padding: 0;
    }

    .egbm-add-row {
        height: 52px;
        margin: 0 14px;
        display: flex;
        align-items: center;
        gap: 8px;
        border: 1px dashed #bcc7d7;
        background: #fafbfe;
        border-radius: 7px;
        margin-top: 9px;
        padding: 0 11px;
    }

    .egbm-add-row>i {
        color: #7788a2;
        font-size: 18px;
    }

    .egbm-url-input {
        border: 0 !important;
        background: transparent !important;
        outline: 0 !important;
        box-shadow: none !important;
        width: 100%;
        font-size: 12px !important;
        color: #536b8c !important;
    }

    .egbm-link-list {
        padding: 8px 10px 11px;
    }

    .egbm-link-row {
        min-height: 48px;
        border-radius: 7px;
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 5px 7px;
    }

    .egbm-link-row:hover {
        background: #f5f6fa;
    }

    .egbm-link-favicon {
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 0 0 auto;
        border-radius: 6px;
        overflow: hidden;
        background: #f3f5f8;
    }

    .egbm-link-favicon img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        border-radius: 5px;
    }

    .egbm-link-favicon .fallback {
        display: flex;
        align-items: center;
        justify-content: center;
        color: #a2adbe;
    }

    .egbm-link-main {
        min-width: 0;
        flex: 1;
    }

    .egbm-link-open {
        border: 0;
        background: transparent;
        padding: 0;
        text-align: left;
        width: 100%;
        min-width: 0;
    }

    .egbm-link-title {
        display: block;
        color: #1a3a62;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .egbm-link-url {
        display: block;
        color: #8693a7;
        font-size: 10px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-top: 2px;
    }

    .egbm-link-note {
        display: block;
        color: #9aa5b5;
        font-size: 9px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-top: 2px;
    }

    .egbm-link-actions {
        display: flex;
        align-items: center;
        gap: 2px;
        opacity: .85;
    }

    .egbm-link-action {
        border: 0;
        background: transparent;
        color: #9eacc0;
        width: 28px;
        height: 30px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
    }

    .egbm-link-action:hover {
        color: #61728d;
    }

    .egbm-category-empty {
        padding: 22px 8px 18px;
        text-align: center;
        color: #a0aabc;
        font-size: 11px;
    }

    .egbm-category-collapsed .egbm-add-row,
    .egbm-category-collapsed .egbm-link-list {
        display: none;
    }

    .egbm-locked-banner {
        margin: 12px 25px 0;
        padding: 9px 12px;
        border-radius: 8px;
        border: 1px solid #eadfae;
        background: #fff8de;
        color: #765f25;
        font-size: 12px;
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .egbm-workspace-body {
        min-width: 0;
    }

    .egbm-empty {
        min-height: 420px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: #718096;
    }

    .egbm-empty>div {
        max-width: 450px;
    }

    .egbm-empty i {
        font-size: 48px;
        color: #9ba8b9;
    }

    .egbm-empty-title {
        font-size: 18px;
        font-weight: 700;
        color: #25466f;
        margin-top: 8px;
    }

    .egbm-empty-text {
        font-size: 12px;
        margin-top: 5px;
        color: #8793a7;
    }

    .egbm-skeleton-shell {
        padding: 20px 25px;
    }

    .egbm-rail-empty {
        padding: 30px 12px;
        text-align: center;
        color: #93a0b3;
        font-size: 11px;
    }

    .egbm-user-menu {
        min-width: 220px;
    }

    .egbm-prototype-header select:focus {
        outline: none;
        box-shadow: none;
    }

    @media(max-width:1250px) {
        .egbm-proto-search-wrap {
            width: 350px;
            flex-basis: 350px;
        }

        .egbm-workspace-actions .egbm-btn:first-of-type {
            display: none;
        }

        .egbm-category-grid {
            gap: 15px;
        }

        .egbm-inline-toplinks {
            display: flex;
            max-width: 300px;
        }
    }

    @media(max-width:1050px) {
        .egbm-prototype-header {
            gap: 8px;
        }

     

        .egbm-proto-field span {
            display: none;
        }

        .egbm-category-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .egbm-workspace-head {
            flex-wrap: wrap;
            padding: 10px 18px;
        }

        .egbm-heading-meta {
            width: 100%;
        }

        .egbm-workspace-actions {
            /* width: 100%; */
        }

        .egbm-board-search {
            flex: 1;
            width: auto;
        }

        .egbm-layout {
            grid-template-columns: 245px minmax(0, 1fr);
        }
    }

    @media(max-width:800px) {
        .egbm-prototype-header {
            height: 70px;
            padding: 0 10px;
        }

        .egbm-proto-search-wrap {
            flex: 1;
            width: auto;
        }

       
        .egbm-proto-field {
            display: none;
        }

        .egbm-layout {
            grid-template-columns: 1fr;
            min-height: calc(100vh - 70px);
        }

        .egbm-board-rail {
            position: fixed;
            left: 0;
            top: 70px;
            bottom: 0;
            width: 285px;
            z-index: 1080;
            transform: translateX(-100%);
            transition: .2s;
            box-shadow: 10px 0 30px rgba(23, 43, 75, .13);
        }

        .egbm-board-rail-open {
            transform: translateX(0);
        }

        .egbm-mobile-boards {
            display: inline-flex;
            width: 32px;
            height: 32px;
            align-items: center;
            justify-content: center;
            border: 1px solid #dbe1ea;
            background: #fff;
            border-radius: 7px;
            color: #576a86;
        }

        .egbm-proto-icon,
        .egbm-proto-notify,
        .egbm-proto-chevron {
            font-size: 20px;
            width: 30px;
        }

        .egbm-avatar {
            width: 36px;
            height: 36px;
        }

        .egbm-category-grid {
            grid-template-columns: 1fr;
        }

        .egbm-canvas {
            padding: 13px;
        }

        .egbm-workspace-head {
            top: 70px;
        }

        .egbm-locked-banner {
            margin: 10px 13px 0;
        }
    }

    @media(max-width:520px) {
        .egbm-proto-search {
            height: 38px;
            font-size: 13px;
        }

        .egbm-proto-search-wrap>i {
            font-size: 19px;
            left: 13px;
        }

        .egbm-proto-search {
            padding-left: 40px;
        }

        .egbm-prototype-header {
            gap: 4px;
        }

        .egbm-header-popover {
            right: 8px;
            width: calc(100vw - 16px);
        }

        .egbm-notification-popover {
            right: 8px;
        }

        .egbm-workspace-actions {
            gap: 5px;
        }

        .egbm-btn,
        .egbm-btn-purple,
        .egbm-btn-primary {
            padding: 0 10px;
            font-size: 11px;
        }

        .egbm-category-head {
            padding: 0 11px;
        }

        .egbm-link-row {
            gap: 7px;
        }

        .egbm-link-actions {
            gap: 0;
        }
    }
</style>

<style>
    /* ERP card-list shell override: keeps BookMarks logic/IDs unchanged. */
    #egBookMarks.egbm-page.card.card-action {
        width: 100% !important;
        min-height: 0 !important;
        margin: 0 !important;
        border-radius: 0.375rem;
        background: var(--egbm-bg, #f5f6fa);
        color: inherit;
        overflow: visible;
        box-shadow: none;
    }

    #egBookMarks.egbm-page.card.card-action > .card-header {
        position: relative;
        z-index: 1001;
        gap: 12px;
    }

    #egBookMarks.egbm-page.card.card-action > .card-body {
        padding: 0 !important;
        background: var(--egbm-bg, #f5f6fa);
    }

    #egBookMarks .egbm-header-company {
        flex: 0 0 180px;
        min-width: 160px;
    }

    #egBookMarks .egbm-proto-search-wrap {
        width: min(420px, 34vw);
        min-width: 250px;
        flex: 1 1 320px;
    }

    #egBookMarks .egbm-proto-search {
        height: 38px;
        font-size: 13px;
    }

    #egBookMarks .egbm-layout {
        min-height: calc(100vh - 230px);
    }

    @media (max-width: 991.98px) {
        #egBookMarks.egbm-page.card.card-action > .card-header {
            align-items: flex-start !important;
        }

        #egBookMarks .egbm-header-company {
            flex: 1 1 160px;
        }

        #egBookMarks .egbm-proto-search-wrap {
            min-width: 220px;
            width: min(360px, 42vw);
        }
    }

    @media (max-width: 767.98px) {
        #egBookMarks.egbm-page.card.card-action > .card-header {
            flex-direction: column;
        }

        #egBookMarks .egbm-header-company,
        #egBookMarks .egbm-proto-search-wrap {
            width: 100%;
            min-width: 0;
            flex-basis: auto;
        }

        #egBookMarks .egbm-layout {
            min-height: calc(100vh - 300px);
        }
    }

    /* ERP list-page header alignment: compact controls, standard action button,
       and the same visual hierarchy used by card-based list screens. */
    #egBookMarks.egbm-page {
        margin: 0 !important;
        width: 100% !important;
        min-height: auto;
        background: transparent;
        overflow: visible;
    }

    #egBookMarks .egbm-card-shell {
        margin-bottom: 0;
        overflow: hidden;
    }

    #egBookMarks .egbm-card-shell > .card-header {
        padding: .75rem 1rem .35rem;
        min-height: 74px;
        gap: 1rem;
    }

    #egBookMarks .egbm-card-shell .card-title {
        line-height: 1.2;
    }

    #egBookMarks .egbm-card-shell .custom-breadcrumb {
        margin-bottom: .15rem;
    }

    #egBookMarks .egbm-header-actions {
        margin-bottom: .35rem;
        flex-wrap: nowrap !important;
    }

    #egBookMarks .egbm-header-company {
        width: 180px;
        min-width: 180px;
    }

    #egBookMarks .egbm-proto-search-wrap.egbm-header-search {
        position: relative;
        width: 260px;
        min-width: 240px;
        flex: 0 1 260px;
    }

    #egBookMarks .egbm-header-search .egbm-proto-search {
        height: 36px;
        border-radius: .375rem;
        background: #fff;
        border: 1px solid #dfe3e8;
        padding-left: 38px;
        padding-right: 10px;
        font-size: .8125rem;
        color: #343a40;
    }

    #egBookMarks .egbm-header-search > i {
        left: 12px;
        font-size: 17px;
        color: #7a8497;
    }

    #egBookMarks .egbm-header-company .select2-container,
    #egBookMarks .egbm-header-company .select2-selection--single {
        width: 100% !important;
    }

    #egBookMarks .egbm-header-company .select2-selection--single {
        height: 36px;
        border-radius: .375rem;
        border-color: #dfe3e8;
    }

    #egBookMarks .egbm-header-company .select2-selection__rendered {
        line-height: 34px;
        font-size: .8125rem;
        padding-left: 11px;
    }

    #egBookMarks .egbm-header-company .select2-selection__arrow {
        height: 34px;
    }

    #egBookMarks .egbm-header-add {
        min-height: 36px;
        white-space: nowrap;
        padding-left: .8rem;
        padding-right: .8rem;
    }

    @media (max-width: 1199.98px) {
        #egBookMarks .egbm-header-search {
            width: 220px;
            min-width: 200px;
            flex-basis: 220px;
        }
    }

    @media (max-width: 991.98px) {
        #egBookMarks .egbm-card-shell > .card-header {
            align-items: flex-start !important;
        }

        #egBookMarks .egbm-header-actions {
            margin-left: auto;
        }

        #egBookMarks .egbm-header-company {
            width: 160px;
            min-width: 160px;
        }
    }

    @media (max-width: 767.98px) {
        #egBookMarks .egbm-card-shell > .card-header {
            flex-direction: column;
            padding: .75rem 1rem 1rem;
        }

        #egBookMarks .egbm-header-actions {
            width: 100%;
            margin: 0;
            flex-wrap: wrap !important;
        }

        #egBookMarks .egbm-header-company,
        #egBookMarks .egbm-header-search {
            width: 100% !important;
            min-width: 0 !important;
            flex: 1 1 100% !important;
        }

        #egBookMarks .egbm-header-add {
            width: auto;
        }
    }
</style>

<div id="egBookMarks" class="egbm-page">
    <div class="card card-action egbm-card-shell">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">BookMarks</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item " aria-current="page">
                            <a href="javascript:void(0);" >
                                Tool Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                BookMarks
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>

            <div class="egbm-header-actions d-flex justify-content-end align-items-center gap-2 flex-wrap">
                <div class="egbm-header-company">
                    <select id="egbmGlobalCompanyFilter" class="egbm-proto-company select3"
                        aria-label="Company" data-placeholder="Company" onchange="companyFilterChange()"></select>
                </div>

                <div class="egbm-proto-search-wrap egbm-header-search">
                    <i class="mdi mdi-magnify"></i>
                    <input id="egbmGlobalSearch" type="search" class="egbm-proto-search"
                        placeholder="Search contacts, bookmarks, knowledge..." autocomplete="off">
                    <div id="egbmGlobalSearchResults" class="egbm-global-search-results d-none"></div>
                </div>

                <button type="button" class="btn btn-sm fw-bold btn-primary text-white egbm-header-add"
                    id="egbmHeaderAddBoard" aria-label="Add Board">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Board
                </button>
            </div>
        </div>

        <div class="card-body p-0">
        <div class="egbm-layout">
            <aside class="egbm-board-rail" id="egbmBoardRail">
                <div class="egbm-rail-head bg-label-warning rounded">
                    <div class="egbm-rail-title text-dark fw-bold">YOUR BOARDS</div>
                    <button type="button" class="egbm-rail-add" id="egbmRailAdd" title="Add board">
                        <i class="mdi mdi-plus-circle-outline"></i>
                    </button>
                </div>
                <div id="egbmBoardList" class="egbm-board-list"></div>
                <div id="egbmBoardRailEmpty" class="egbm-rail-empty d-none"></div>
            </aside>

            <main class="egbm-main">
                <div id="egbmSkeleton" class="egbm-skeleton-shell"></div>
                <div id="egbmWorkspace" class="d-none"></div>
            </main>
        </div>
    </div>


<style>
    /* ============================================================
       Share Board - production UI
       ============================================================ */
    #egbmShareModal .modal-dialog {
        max-width: 920px;
    }

    #egbmShareModal .egbm-share-modal {
        border: 0;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 24px 70px rgba(31, 56, 100, .20);
    }

    #egbmShareModal .egbm-share-modal-header {
        padding: 18px 20px;
        border-bottom: 1px solid #e7ebf2;
        background: #fff;
    }

    #egbmShareModal .egbm-share-header-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: grid;
        place-items: center;
        flex: 0 0 44px;
        background: #fbeceb;
        color: #b52b25;
        font-size: 21px;
    }

    #egbmShareModal .egbm-share-modal-body {
        padding: 18px 20px 20px;
        background: #f6f8fb;
    }

    #egbmShareModal .egbm-share-section {
        padding: 15px;
        margin-bottom: 12px;
        background: #fff;
        border: 1px solid #e3e8f0;
        border-radius: 12px;
    }

    #egbmShareModal .egbm-share-section:last-of-type {
        margin-bottom: 0;
    }

    #egbmShareModal .egbm-share-section-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 12px;
    }

    #egbmShareModal .egbm-share-section-title {
        /* color: #243f67; */
        font-size: 12px;
        line-height: 1.25;
        font-weight: 800;
    }

    #egbmShareModal .egbm-share-section-subtitle,
    #egbmShareModal .egbm-share-current-subtitle {
        margin-top: 3px;
        color: #8894a8;
        font-size: 9px;
        line-height: 1.35;
    }

    #egbmShareModal .egbm-share-step {
        min-width: 28px;
        height: 23px;
        padding: 0 7px;
        border-radius: 999px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #f3f5f8;
        color: #7f8ca0;
        font-size: 8px;
        font-weight: 900;
        letter-spacing: .08em;
    }

    #egbmShareModal .egbm-share-type-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 9px;
    }

    #egbmShareModal .egbm-share-type-card {
        width: 100%;
        min-height: 78px;
        padding: 11px;
        display: flex;
        align-items: center;
        gap: 9px;
        position: relative;
        text-align: left;
        background: #fbfcfe;
        border: 1px solid #dfe5ee;
        border-radius: 10px;
        color: #29466f;
        transition: border-color .16s ease, background .16s ease, box-shadow .16s ease;
    }

    #egbmShareModal .egbm-share-type-card:hover {
        background: #fff;
        border-color: #c9d4e4;
    }

    #egbmShareModal .egbm-share-type-card.is-active {
        background: #fff8f7;
        border-color: #c53a32;
        box-shadow: 0 5px 16px rgba(181, 43, 37, .08);
    }

    #egbmShareModal .egbm-share-type-icon {
        width: 32px;
        height: 32px;
        flex: 0 0 32px;
        display: grid;
        place-items: center;
        border-radius: 9px;
        background: #f0f3f7;
        color: #667791;
        font-size: 17px;
    }

    #egbmShareModal .egbm-share-type-card.is-active .egbm-share-type-icon {
        background: #fbeceb;
        color: #b52b25;
    }

    #egbmShareModal .egbm-share-type-copy {
        min-width: 0;
        flex: 1;
    }

    #egbmShareModal .egbm-share-type-copy strong {
        display: block;
        color: #29466f;
        font-size: 10px;
        font-weight: 800;
    }

    #egbmShareModal .egbm-share-type-copy small {
        display: block;
        margin-top: 2px;
        color: #8995a7;
        font-size: 8px;
        line-height: 1.35;
    }

    #egbmShareModal .egbm-share-type-check {
        width: 19px;
        height: 19px;
        flex: 0 0 19px;
        display: grid;
        place-items: center;
        border: 1px solid #dbe1ea;
        border-radius: 50%;
        color: transparent;
        font-size: 12px;
    }

    #egbmShareModal .egbm-share-type-card.is-active .egbm-share-type-check {
        border-color: #c53a32;
        background: #c53a32;
        color: #fff;
    }

    #egbmShareModal .egbm-share-target-box {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 11px;
        border: 1px solid #e2e7ef;
        border-radius: 10px;
        background: #fbfcfe;
    }

    #egbmShareModal .egbm-share-target-icon {
        width: 34px;
        height: 34px;
        flex: 0 0 34px;
        display: grid;
        place-items: center;
        border-radius: 9px;
        background: #eef2f7;
        color: #61718b;
        font-size: 17px;
    }

    #egbmShareModal .egbm-share-target-box .select2-container {
        width: 100% !important;
    }

    #egbmShareModal .egbm-share-target-hint {
        margin-top: 4px;
        color: #929daf;
        font-size: 8px;
        line-height: 1.35;
    }

    #egbmShareModal .egbm-share-eligible-panel {
        margin-top: 9px;
        padding: 10px 11px;
        border: 1px solid #e5e9f1;
        border-radius: 9px;
        background: #f8fafc;
    }

    #egbmShareModal .egbm-share-eligible-summary {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
    }

    #egbmShareModal .egbm-share-eligible-count {
        color: #29466f;
        font-size: 10px;
        font-weight: 800;
    }

    #egbmShareModal .egbm-share-eligible-caption {
        margin-top: 2px;
        color: #8c98ab;
        font-size: 8px;
    }

    #egbmShareModal .egbm-share-eligible-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        margin-top: 8px;
        max-height: 95px;
        overflow: auto;
    }

    #egbmShareModal .egbm-share-eligible-chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 7px;
        border-radius: 999px;
        border: 1px solid #e0e6ef;
        background: #fff;
        color: #52647f;
        font-size: 8px;
    }

    #egbmShareModal .egbm-share-eligible-more {
        color: #8b96a8;
        font-size: 8px;
        align-self: center;
    }

    #egbmShareModal .egbm-share-expiry-wrap {
        position: relative;
    }

    #egbmShareModal .egbm-share-expiry-wrap > i {
        position: absolute;
        left: 11px;
        top: 50%;
        transform: translateY(-50%);
        z-index: 2;
        color: #8b97a9;
        font-size: 15px;
    }

    #egbmShareModal #egbmShareExpiry {
        padding-left: 34px;
    }

    #egbmShareModal .egbm-share-current-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 3px 2px 8px;
    }

    #egbmShareModal .egbm-share-list {
        background: #fff;
        border: 1px solid #e3e8f0;
        border-radius: 12px;
        overflow: hidden;
    }

    #egbmShareModal .egbm-share-row {
        min-height: 60px;
        padding: 9px 11px;
        border-bottom: 1px solid #eef1f5;
    }

    #egbmShareModal .egbm-share-row:last-child {
        border-bottom: 0;
    }

    #egbmShareModal .egbm-share-source-pill {
        background: #eef2f7;
        color: #6d7b90;
    }

    #egbmShareModal .egbm-share-source-pill.visibility {
        background: #fbeceb;
        color: #a52a24;
    }

    #egbmShareModal .egbm-share-security-note {
        margin-right: auto;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: #8793a6;
        font-size: 8px;
    }

    #egbmShareModal .egbm-share-security-note i {
        color: #2e7d5a;
        font-size: 15px;
    }

    #egbmShareModal .select2-container--default .select2-selection--single,
    #egbmShareModal .select2-container--default .select2-selection--multiple {
        min-height: 38px;
        border-color: #dfe4ed;
        border-radius: 7px;
        background: #fff;
    }

    #egbmShareModal .select2-container--default .select2-selection--single .select2-selection__rendered {
        font-size: 10px;
        line-height: 36px;
        color: #314a6d;
    }

    #egbmShareModal .select2-container--default .select2-selection--multiple {
        padding: 3px 5px;
    }

    #egbmShareModal .select2-container--default .select2-selection--multiple .select2-selection__choice {
        margin-top: 3px;
        padding: 3px 6px 3px 21px;
        border: 1px solid #efcbc8;
        border-radius: 999px;
        background: #fbeceb;
        color: #8f241f;
        font-size: 8px;
    }

    #egbmShareModal .select2-container--default.select2-container--focus .select2-selection--single,
    #egbmShareModal .select2-container--default.select2-container--focus .select2-selection--multiple {
        border-color: #b52b25;
        box-shadow: 0 0 0 3px rgba(181, 43, 37, .06);
    }

    #egbmShareModal .select2-dropdown {
        z-index: 1200;
        border-color: #dce3ed;
        border-radius: 8px;
        box-shadow: 0 14px 35px rgba(28, 48, 79, .18);
    }

    #egbmShareModal .select2-results__option {
        padding: 8px 10px;
        font-size: 9px;
    }

    @media (max-width: 767.98px) {
        #egbmShareModal .egbm-share-type-grid {
            grid-template-columns: 1fr;
        }

        #egbmShareModal .egbm-share-modal-body {
            padding: 14px;
        }

        #egbmShareModal .egbm-share-modal-header {
            padding: 15px;
        }

        #egbmShareModal .egbm-share-security-note {
            display: none;
        }
    }
</style>
        <!-- Board modal -->
        <div  class="modal fade " id="egbmBoardModal" tabindex="-1" aria-labelledby="egbmBoardModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg ">
                <div class="modal-content egbm-modal ">
                    <div class="modal-header egbm-board-modal-header">
                        <div class="d-flex align-items-start gap-3 min-w-0">
                            <div class="egbm-board-modal-icon">
                                <i class="mdi mdi-view-dashboard-outline"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="egbm-modal-kicker">BOOKMARK BOARD</div>
                                <h5 class="modal-title mb-1" id="egbmBoardModalTitle">New Board</h5>
                                <!-- <div class="egbm-board-modal-subtitle" id="egbmBoardModalSubtitle">
                                    Create one common board and decide exactly who can access it.
                                </div> -->
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <form id="egbmBoardForm" autocomplete="off">
                        <div class="modal-body egbm-board-modal-body">
                            <!-- <div class="egbm-board-scope-banner">
                                <div class="egbm-board-scope-icon"><i class="mdi mdi-earth"></i></div>
                                <div class="min-w-0 flex-grow-1">
                                    <div class="egbm-board-scope-title">Common board</div>
                                    <div class="egbm-board-scope-text">
                                        Boards are not owned by a company. Access is controlled only by the visibility you choose below.
                                    </div>
                                </div>
                                <span class="egbm-board-scope-badge">COMMON</span>
                            </div> -->

                            <div class="egbm-board-section">
                                <div class="egbm-board-section-heading">
                                    <span class="egbm-board-section-index">01</span>
                                    <div>
                                        <div class="egbm-board-section-title">Board details</div>
                                        <div class="egbm-board-section-help">Give the board a clear name and an optional description.</div>
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label required">Board name</label>
                                        <input type="text" class="form-control" name="board_name" maxlength="160"
                                            placeholder="e.g. Business Tools" required>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Description</label>
                                        <textarea class="form-control" name="description" rows="3" maxlength="5000"
                                            placeholder="What should this board contain?"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="egbm-board-section">
                                <div class="egbm-board-section-heading">
                                    <span class="egbm-board-section-index">02</span>
                                    <div>
                                        <div class="egbm-board-section-title">Who can access this board?</div>
                                        <div class="egbm-board-section-help" id="egbmBoardVisibilityHint">
                                            Only the creator can view a private board by default. Additional access can still be granted from Share.
                                        </div>
                                    </div>
                                </div>

                                <select class="d-none" id="egbmBoardVisibility" name="visibility" aria-hidden="true" tabindex="-1">
                                    <option value="Private">Private</option>
                                    <option value="Company">Company</option>
                                    <option value="Group">Group</option>
                                </select>

                                <div class="egbm-visibility-choice-grid" role="radiogroup" aria-label="Board visibility">
                                    <button type="button" class="egbm-visibility-choice is-active" data-egbm-visibility="Private" aria-pressed="true">
                                        <span class="egbm-visibility-choice-icon"><i class="mdi mdi-lock-outline"></i></span>
                                        <span class="egbm-visibility-choice-copy">
                                            <strong>Private</strong>
                                            <small>Only the creator can view it by default. Use Share when you need an additional exception.</small>
                                        </span>
                                        <span class="egbm-visibility-choice-check"><i class="mdi mdi-check"></i></span>
                                    </button>
                                    <button type="button" class="egbm-visibility-choice" data-egbm-visibility="Company" aria-pressed="false">
                                        <span class="egbm-visibility-choice-icon"><i class="mdi mdi-office-building-outline"></i></span>
                                        <span class="egbm-visibility-choice-copy">
                                            <strong>Companies</strong>
                                            <small>All staff in the selected active companies can view the board.</small>
                                        </span>
                                        <span class="egbm-visibility-choice-check"><i class="mdi mdi-check"></i></span>
                                    </button>
                                    <button type="button" class="egbm-visibility-choice" data-egbm-visibility="Group" aria-pressed="false">
                                        <span class="egbm-visibility-choice-icon"><i class="mdi mdi-account-multiple-outline"></i></span>
                                        <span class="egbm-visibility-choice-copy">
                                            <strong>Staff group</strong>
                                            <small>Only the staff members selected below can view the board.</small>
                                        </span>
                                        <span class="egbm-visibility-choice-check"><i class="mdi mdi-check"></i></span>
                                    </button>
                                </div>

                                <div class="egbm-visibility-target-card d-none" id="egbmVisibilityCompanyWrap">
                                    <div class="egbm-visibility-target-icon"><i class="mdi mdi-office-building-outline"></i></div>
                                    <div class="flex-grow-1 min-w-0">
                                        <label class="form-label required mb-1">Select companies</label>
                                        <select class="form-select select3" id="egbmVisibilityCompanies" name="visibility_company_ids"  data-placeholder="Select one or more companies" multiple>
                                        </select>
                                        <div class="form-text">Every active staff member belonging to a selected company can view this board.</div>
                                    </div>
                                </div>

                                <div class="egbm-visibility-target-card d-none" id="egbmVisibilityGroupWrap">
                                    <div class="egbm-visibility-target-icon"><i class="mdi mdi-account-multiple-outline"></i></div>
                                    <div class="flex-grow-1 min-w-0">
                                        <label class="form-label required mb-1">Select staff</label>
                                        <select class="form-select select3" id="egbmVisibilityUsers"
                                            name="visibility_user_ids" multiple
                                            data-placeholder="Select one or more staff"></select>
                                        <div class="form-text">Only the selected active staff members can view this board.</div>
                                    </div>
                                </div>
                            </div>

                            <div class="egbm-board-section egbm-board-security-section">
                                <div class="egbm-board-section-heading">
                                    <span class="egbm-board-section-index">03</span>
                                    <div>
                                        <div class="egbm-board-section-title">Board security</div>
                                        <div class="egbm-board-section-help">Locking keeps the board visible while preventing routine content changes.</div>
                                    </div>
                                </div>
                                <label class="egbm-lock-option">
                                    <input type="checkbox" name="is_locked" value="1">
                                    <span class="egbm-lock-option-icon"><i class="mdi mdi-lock-outline"></i></span>
                                    <span class="egbm-lock-option-copy">
                                        <strong>Lock this board</strong>
                                        <small>Prevent adding, editing, moving, deleting and reordering routine content until it is unlocked.</small>
                                    </span>
                                    <span class="egbm-lock-option-check"><i class="mdi mdi-check"></i></span>
                                </label>
                            </div>
                        </div>

                        <div class="modal-footer egbm-board-modal-footer">
                            <div class="egbm-board-footer-note">
                                <!-- <i class="mdi mdi-shield-check-outline"></i>
                                <span>Access changes are saved securely with the board.</span> -->
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary px-4" id="egbmBoardSave">
                                    <i class="mdi mdi-plus"></i> Create board
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
       
            
                
            
        

        <!-- Share Board modal -->
        <div class="modal fade" id="egbmShareModal" tabindex="-1" aria-labelledby="egbmShareTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg ">
                <div class="modal-content egbm-modal egbm-share-modal">
                    <div class="modal-header egbm-share-modal-header">
                        <div class="d-flex align-items-center gap-3 min-w-0">
                            <div class="egbm-share-header-icon">
                                <i class="mdi mdi-share-variant-outline"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="egbm-modal-kicker">SHARE BOARD</div>
                                <h5 class="modal-title" id="egbmShareTitle">Share board</h5>
                                <div class="small text-muted">Choose who can access this board and what they can do.</div>
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body egbm-share-modal-body">
                        <input type="hidden" id="egbmShareType" value="user">

                        <div class="egbm-share-section">
                            <div class="egbm-share-section-head">
                                <div>
                                    <div class="egbm-share-section-title">Share with</div>
                                    <div class="egbm-share-section-subtitle">Select one sharing method.</div>
                                </div>
                                <span class="egbm-share-step">01</span>
                            </div>

                            <div class="egbm-share-type-grid" id="egbmShareTypeCards" role="group" aria-label="Share recipient type">
                                <button type="button" class="egbm-share-type-card is-active" data-share-type="user" aria-pressed="true">
                                    <span class="egbm-share-type-icon"><i class="mdi mdi-account-outline"></i></span>
                                    <span class="egbm-share-type-copy">
                                        <strong>Person</strong>
                                        <small>One staff member</small>
                                    </span>
                                    <span class="egbm-share-type-check"><i class="mdi mdi-check"></i></span>
                                </button>
                                <button type="button" class="egbm-share-type-card" data-share-type="company" aria-pressed="false">
                                    <span class="egbm-share-type-icon"><i class="mdi mdi-office-building-outline"></i></span>
                                    <span class="egbm-share-type-copy">
                                        <strong>Companies</strong>
                                        <small>All active staff in selected companies</small>
                                    </span>
                                    <span class="egbm-share-type-check"><i class="mdi mdi-check"></i></span>
                                </button>
                                <button type="button" class="egbm-share-type-card" data-share-type="group" aria-pressed="false">
                                    <span class="egbm-share-type-icon"><i class="mdi mdi-account-multiple-outline"></i></span>
                                    <span class="egbm-share-type-copy">
                                        <strong>Staff group</strong>
                                        <small>Multiple staff members</small>
                                    </span>
                                    <span class="egbm-share-type-check"><i class="mdi mdi-check"></i></span>
                                </button>
                            </div>
                        </div>

                        <div class="egbm-share-section">
                            <div class="egbm-share-section-head">
                                <div>
                                    <div class="egbm-share-section-title" id="egbmShareTargetLabel">Select person</div>
                                    <div class="egbm-share-section-subtitle" id="egbmShareTargetHelper">Choose one active staff member.</div>
                                </div>
                                <span class="egbm-share-step">02</span>
                            </div>

                            <div class="egbm-share-target-box">
                                <div class="egbm-share-target-icon" id="egbmShareTargetIcon">
                                    <i class="mdi mdi-account-outline"></i>
                                </div>
                                <div class="flex-grow-1 min-w-0">
                                    <select class="form-select select3" id="egbmShareTarget" data-placeholder="Search staff…"></select>
                                    <div class="egbm-share-target-hint" id="egbmShareTargetHint">Only active staff members are shown.</div>
                                </div>
                            </div>
                            <div id="egbmShareEligiblePanel" class="egbm-share-eligible-panel d-none"></div>
                        </div>

                        <div class="egbm-share-section">
                            <div class="egbm-share-section-head">
                                <div>
                                    <div class="egbm-share-section-title">Access settings</div>
                                    <div class="egbm-share-section-subtitle">Apply the same access level and expiry to the selected recipients.</div>
                                </div>
                                <span class="egbm-share-step">03</span>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Access level</label>
                                    <select class="form-select select3" id="egbmSharePermission" data-placeholder="Permission">
                                        <option value="View">Viewer · Can open and use the board</option>
                                        <option value="Manage">Co-owner · Can manage the board</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Access expiry</label>
                                    <div class="egbm-share-expiry-wrap">
                                        <i class="mdi mdi-calendar-clock-outline"></i>
                                        <input type="text" class="form-control" id="egbmShareExpiry" placeholder="No expiry">
                                    </div>
                                    <div class="egbm-share-target-hint">Leave empty to keep access until it is revoked.</div>
                                </div>
                            </div>
                        </div>

                        <div class="egbm-share-current-head">
                            <div>
                                <div class="egbm-share-list-head mb-0">CURRENT ACCESS</div>
                                <div class="egbm-share-current-subtitle">Existing board access is shown below.</div>
                            </div>
                        </div>
                        <div id="egbmShareList" class="egbm-share-list"></div>
                    </div>

                    <div class="modal-footer egbm-share-modal-footer">
                        <!-- <div class="egbm-share-security-note">
                            <i class="mdi mdi-shield-check-outline"></i>
                            <span>Only you or a board manager can change sharing.</span>
                        </div> -->
                        <div class="d-flex align-items-center gap-2">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" id="egbmShareSave">
                                <i class="mdi mdi-account-plus-outline"></i> Share board
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Import modal -->
        <div class="modal fade" id="egbmImportModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
                <div class="modal-content egbm-modal">
                    <div class="modal-header">
                        <div>
                            <div class="egbm-modal-kicker">IMPORT BOOKMARKS</div>
                            <h5 class="modal-title">Import bookmarks</h5>
                            <div class="small text-muted">
                                Upload a browser HTML export, review folders, then map each folder to a category.
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div id="egbmImportStepUpload">
                            <div class="egbm-upload-box">
                                <div class="egbm-upload-icon">
                                    <i class="mdi mdi-file-upload-outline"></i>
                                </div>
                                <div>
                                    <strong>Choose your bookmarks HTML file</strong>
                                    <div class="small text-muted">
                                        Chrome / Edge / Firefox export · maximum 10 MB · up to 500 valid public links.
                                    </div>
                                </div>
                                <label class="btn btn-light btn-sm ms-auto mb-0">
                                    Browse
                                    <input type="file" id="egbmImportFile" accept=".html,.htm,text/html" hidden>
                                </label>
                            </div>
                            <div id="egbmImportFileMeta" class="d-none mt-3"></div>
                        </div>
                        <div id="egbmImportStepMap" class="d-none">
                            <div id="egbmImportSummary" class="egbm-import-summary"></div>
                            <div class="egbm-import-section-title">FOLDER → CATEGORY MAPPING</div>
                            <div id="egbmImportMappings"></div>
                        </div>
                        <div id="egbmImportStepBusy" class="d-none"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary d-none" id="egbmImportSubmit">
                            <i class="mdi mdi-upload-outline"></i> Import bookmarks
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Category / Bookmark modal -->
        <div class="modal fade" id="egbmFormModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content egbm-modal">
                    <div class="modal-header">
                        <div>
                            <div class="egbm-modal-kicker" id="egbmFormKicker">BOOKMARKS</div>
                            <h5 class="modal-title" id="egbmFormTitle">Category</h5>
                            <div class="small text-muted" id="egbmFormSubtitle"></div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form id="egbmForm">
                        <div class="modal-body" id="egbmFormBody"></div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" id="egbmFormSave">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Confirm modal -->
        <div class="modal fade" id="egbmConfirmModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-sm">
                <div class="modal-content egbm-modal">
                    <div class="modal-body text-center p-4">
                        <div class="egbm-confirm-icon"><i class="mdi mdi-alert-outline"></i></div>
                        <h5 id="egbmConfirmTitle" class="mb-2"></h5>
                        <p id="egbmConfirmBody" class="text-muted small mb-4"></p>
                        <div class="d-flex justify-content-center gap-2">
                            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" id="egbmConfirmYes">Confirm</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    const root = document.getElementById('egBookMarks');
    const $root = $(root);

    const config = @js(
        [
            'module' => 'bookmarks', 
            'routes' => [
                'lookups' => route('productivity.bookmarks.lookups'),
                'boards' => route('productivity.bookmarks.boards'), 
                'board' => url('/productivity/bookmarks/board'), 
                'boardShow' => url('/productivity/bookmarks'),
                'boardStore' => route('productivity.bookmarks.board.store'), 
                'boardUpdate' => url('/productivity/bookmarks/boards'), 
                'boardDelete' => url('/productivity/bookmarks/boards'),
                'categoryStore' => url('/productivity/bookmarks/boards'), 
                'categoryReorder' => url('/productivity/bookmarks/boards'), 
                'categoryUpdate' => url('/productivity/bookmarks/categories'), 
                'categoryDelete' => url('/productivity/bookmarks/categories'), 
                'bookmarkStore' => route('productivity.bookmarks.store'), 
                'bookmarkQuick' => route('productivity.bookmarks.quick'),
                'bookmarkUpdate' => url('/productivity/bookmarks'), 
                'bookmarkDelete' => url('/productivity/bookmarks'), 
                'bookmarkOpen' => url('/productivity/bookmarks'),
                'bookmarkHealth' => url('/productivity/bookmarks'), 
                'bookmarkMoveCopy' => url('/productivity/bookmarks'), 
                'bookmarkFavicon' => route('productivity.bookmarks.favicon'),
                'bookmarkFaviconImage' => route('productivity.bookmarks.favicon.image'), 
                'globalSearch' =>route('productivity.global.search'), 
                'menu' => route('productivity.menu'), 
                'notifications' => route('productivity.notifications'), 
                'notificationsRead' => route('productivity.notifications.read'),
                'bookmarkImportPreview' => route('productivity.bookmarks.import.preview'), 
                'bookmarkImport' => route('productivity.bookmarks.import.html'), 
                'users' => route('productivity.users'),
                'shares' => [
                    'data' => route('productivity.shares.data'), 
                    'store' => route('productivity.shares.store'), 
                    'revoke' => url('/productivity/shares'), 
                ],
    
            ],
        ]);

    const R = config.routes || {};

    const state = {
        boardId: Number(localStorage.getItem('egbm.activeBoard') || 0),
        boardSearch: '',
        workspaceSearch: '',
        companyFilter: 'all',
        searchTimer: null,
        globalSearchTimer: null,
        boardRows: [],
        boardData: null,
        lookups: {
            companies: [],
            staff: [],
            owners: [],
            current_user: null
        },
        modalMode: null,
        shareBoardId: null,
        importBoardId: null,
        importFile: null,
        importPreview: null,
        requestSeq: 0,
        faviconCache: {},
    };

    const $boardList = $('#egbmBoardList');
    const $workspace = $('#egbmWorkspace');
    const $skeleton = $('#egbmSkeleton');
    const boardModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egbmBoardModal'));
    const shareModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egbmShareModal'));
    const importModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egbmImportModal'));
    const formModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egbmFormModal'));
    const confirmModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egbmConfirmModal'));

    function esc(v) {
        return String(v ?? '').replace(/[&<>'"]/g, function(ch) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#039;',
                '"': '&quot;'
            })[ch];
        });
    }

    /**
     * Normalize a user-entered URL before sending it to the server.
     * Accepts common input such as:
     *   instagram.com
     *   www.instagram.com/path
     *   https://instagram.com
     * Explicit non-HTTP schemes are left untouched so the backend can reject them safely.
     */
    function normalizeUserUrl(value) {
        let url = String(value || '').trim();
        if (!url) return '';

        if (url.indexOf('//') === 0) {
            return 'https:' + url;
        }

        if (/^[a-z][a-z0-9+.-]*:/i.test(url)) {
            return url;
        }

        return 'https://' + url;
    }

    function initials(name) {
        const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
        if (!parts.length) return 'SN';
        if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }

    function ajax(method, endpoint, data, options) {
        const opts = options || {};
        const settings = {
            url: endpoint,
            method: method,
            data: data,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') || ''
            },
            dataType: opts.dataType || 'json',
            timeout: opts.timeout || 30000,
        };
        if (opts.processData !== undefined) settings.processData = opts.processData;
        if (opts.contentType !== undefined) settings.contentType = opts.contentType;
        if (opts.cache !== undefined) settings.cache = opts.cache;
        
        return $.ajax(settings).then(function(res) {
            return res;
        }, function(xhr) {
            const payload = xhr.responseJSON || {};
            return $.Deferred().reject({
                status: xhr.status,
                message: payload.message 
                        || payload.error 
                        || (payload.errors ? Object.values(payload.errors).flat()[0] : null) 
                        || 'The server could not complete this request.'
            }).promise();
        });
    }

    function query(obj) {
        const parts = [];
        Object.keys(obj || {}).forEach(function(key) {
            const value = obj[key];
            if (value === null || value === undefined || value === '') return;
            parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
        });
        return parts.join('&');
    }

    function route(base, id, suffix) {
        return String(base).replace(/\/$/, '') + '/' + encodeURIComponent(id) + (suffix ? '/' + suffix : '');
    }

    function skeleton() {
        $workspace.addClass('d-none').empty();
        $skeleton.removeClass('d-none').html(
            '<div class="egbm-sk-head"><div class="egbm-sk-line egbm-sk-title"></div><div class="egbm-sk-line egbm-sk-title"></div><div class="egbm-sk-line egbm-sk-search"></div><div class="egbm-sk-line egbm-sk-btn"></div><div class="egbm-sk-line egbm-sk-btn"></div></div>' +
            '<div class="egbm-sk-body"><div class="egbm-sk-left">' + Array.from({
                length: 8
            }).map(function() {
                return '<div class="egbm-sk-line egbm-sk-item"></div>';
            }).join('') +
            '</div><div class="egbm-sk-right"><div class="egbm-sk-line egbm-sk-row wide"></div><div class="egbm-sk-line egbm-sk-row"></div>' +
            Array.from({
                length: 3
            }).map(function() {
                return '<div class="egbm-sk-cat"><div class="egbm-sk-line egbm-sk-row"></div><div class="egbm-sk-line egbm-sk-row wide"></div><div class="egbm-sk-line egbm-sk-row"></div></div>';
            }).join('') + '</div></div>'
        );
    }

    function errorScreen(message) {
        $skeleton.addClass('d-none');
        $workspace.removeClass('d-none').html(
            '<div class="egbm-error"><i class="mdi mdi-cloud-alert-outline"></i><strong>BookMarks could not be loaded</strong><div class="mt-1">' +
            esc(message || 'Please try again.') +
            '</div><button type="button" class="btn btn-sm btn-light mt-3" id="egbmRetry"><i class="mdi mdi-refresh"></i> Retry</button></div>'
        );
    }

    function setSelect($select, items, selected, placeholder, format) {
        const value = selected == null ? '' : String(selected);
        $select.empty().append('<option value=""></option>');
        (items || []).forEach(function(item) {
            const itemValue = item.value ?? item.sno ?? item.id;
            const label = format ? format(item) : (item.label ?? item.name ?? item.company_name ?? item
                .staff_name ?? item.category_name ?? '');
            $select.append($('<option>', {
                value: itemValue,
                text: label
            }));
        });
        $select.val(value);
        if ($select.hasClass('select2-hidden-accessible')) {
            $select.trigger('change');
        } else {
            // initSelect3($select.parent().length ? $select.parent() : $select);
        }
    }

    function destroySelect3($select) {
        const $target = $select && $select.jquery ? $select : $($select);
        if (!$target.length) return;
        if ($target.hasClass('select2-hidden-accessible')) {
            $target.select2('destroy');
        }
        $target.removeAttr('data-select2-id');
    }

    function setSelectMulti($select, items, selected, placeholder, format) {
        const $target = $select && $select.jquery ? $select : $($select);
        const values = Array.isArray(selected) ? selected.map(String) : (selected ? [String(selected)] : []);

        // Visibility selectors can be shown/hidden repeatedly. Rebuild Select2 only
        // after the target container is visible so its width/position is calculated correctly.
        // destroySelect3($target);
        $target.empty();

        (items || []).forEach(function(item) {
            const itemValue = item.value ?? item.sno ?? item.id;
            const label = format ? format(item) : (item.label ?? item.name ?? item.company_name ??
                item.staff_name ?? '');
            $target.append($('<option>', {
                value: itemValue,
                text: label
            }));
        });

        $target.val(values);
        // initSelect3($target);
        $target.val(values).trigger('change');
    }

    function initSelect3(scope) {
        if (typeof $.fn.select2 !== 'function') return;
        const $scope = scope ? $(scope) : $(root);
        $scope.find('select.select3').addBack('select.select3').each(function() {
            const $select = $(this);

            // These two selectors belong to conditional visibility panels. They are
            // initialized by renderBoardVisibilityTargets() after the panel is shown,
            // avoiding Select2 being created against a display:none parent.
            if ($select.is('#egbmVisibilityCompanies, #egbmVisibilityUsers, #egbmShareTarget')) return;

            if ($select.hasClass('select2-hidden-accessible')) return;
            const $modal = $select.closest('.modal');
            $select.select2({
                width: '100%',
                dropdownParent: $modal.length ? $modal : $(document.body),
                placeholder: $select.data('placeholder') || $select.find('option:first').text() ||
                    'Select',
                allowClear: true,
                closeOnSelect: !$select.prop('multiple'),
                minimumResultsForSearch: 8,
                maximumSelectionLength: $select.data('max-selected') ? Number($select.data(
                    'max-selected')) : 0,
            });
        });
    }

    function closeAnySelect3() {
        $(root).find('select.select3.select2-hidden-accessible').each(function() {
            $(this).select2('close');
        });
    }

    function renderBoardRail() {
        const term = String(state.boardSearch || '').trim().toLowerCase();
        const rows = state.boardRows.filter(function(b) {
            if (!term) return true;
            return String(b.board_name || '').toLowerCase().includes(term) ||
                String(b.company_short_name || '').toLowerCase().includes(term) ||
                String(b.company_name || '').toLowerCase().includes(term);
        });

        if (!rows.length) {
            $boardList.html('');
            $('#egbmBoardRailEmpty').removeClass('d-none').html(
                '<i class="mdi mdi-bookmark-off-outline" style="font-size:24px"></i><div class="fw-bold mt-2">No boards</div><div class="mt-1">Create a board to start saving links.</div><button class="btn btn-primary btn-sm mt-3" id="egbmRailEmptyAdd"><i class="mdi mdi-plus"></i> Add board</button>'
            );
            return;
        }

        $('#egbmBoardRailEmpty').addClass('d-none').empty();
        $boardList.html(rows.map(function(b) {
            const active = Number(b.sno) === Number(state.boardId);
            const company = b.company_short_name || b.company_name || '';
            const badgeTitle = Number(b.company_id || 0) === 0 ? 'Common Board' : (company || b.board_name || 'Board');
            return '<button type="button" class="egbm-board-item ' + (active ? 'active' : '') +
                '" data-board-id="' + esc(b.sno) + '" title="' + esc(badgeTitle) + '">' +
                '<span class="name">' + esc(b.board_name || 'Untitled Board') + '</span>' +
                (b.is_locked ? '<i class="mdi mdi-lock-outline lock"></i>' : '') +
                '<span class="count">' + esc(b.bookmark_count || 0) + '</span>' +
                '</button>';
        }).join(''));
    }

    function loadLookups() {
        return ajax('GET', R.lookups + '?' + query({
            company_id: currentCompanyFilter()
        })).done(function(res) {
            state.lookups = res.data || state.lookups;
            populateBoardModalLookups();
        });
    }

    function currentCompanyFilter() {
        const value = state.companyFilter || $('#egbmGlobalCompanyFilter').val();
        return value || 'all';
    }

    function loadBoards(openSelected) {
        if (openSelected !== false || !state.boardData) skeleton();
        const seq = ++state.requestSeq;
        return ajax('GET', R.boards + '?' + query({
            company_id: currentCompanyFilter(),
            search: state.boardSearch,
        })).done(function(res) {
            if (seq !== state.requestSeq) return;
            state.boardRows = Array.isArray(res.data) ? res.data : [];
            renderBoardRail();

            const exists = state.boardRows.some(function(b) {
                return Number(b.sno) === Number(state.boardId);
            });
            if (!exists) state.boardId = Number(state.boardRows[0]?.sno || 0);

            if (state.boardId && openSelected !== false) {
                localStorage.setItem('egbm.activeBoard', state.boardId);
                loadBoard(state.boardId);
            } else if (state.boardId && state.boardData) {
                // Refreshing the board rail after an AJAX mutation must never
                // replace the current workspace with the global empty state.
                $skeleton.addClass('d-none');
                $workspace.removeClass('d-none');
            } else if (!state.boardId) {
                state.boardData = null;
                $skeleton.addClass('d-none');
                $workspace.removeClass('d-none').html(
                    '<div class="egbm-empty"><div><i class="mdi mdi-bookmark-multiple-outline"></i><div class="egbm-empty-title">Your BookMarks workspace is ready</div><div class="egbm-empty-text">Create your first board, then add links with the inline URL field.</div><button type="button" class="egbm-btn-purple mt-3" id="egbmEmptyAdd"><i class="mdi mdi-plus"></i> Create board</button></div></div>'
                );
            }
        }).fail(function(err) {
            errorScreen(err.message);
        });
    }

    function loadBoard(id) {
        $skeleton.removeClass('d-none');
        $workspace.addClass('d-none');
        $skeleton.html(
            '<div class="egbm-sk-head"><div class="egbm-sk-line egbm-sk-title"></div><div class="egbm-sk-line egbm-sk-title"></div><div class="egbm-sk-line egbm-sk-search"></div><div class="egbm-sk-line egbm-sk-btn"></div><div class="egbm-sk-line egbm-sk-btn"></div></div><div class="egbm-sk-right" style="min-height:420px"><div class="egbm-sk-line egbm-sk-row wide"></div><div class="egbm-sk-cat"></div><div class="egbm-sk-cat"></div><div class="egbm-sk-cat"></div></div>'
        );

        return ajax('GET', route(R.board, id) + '?' + query({
            search: state.workspaceSearch
        })).done(function(res) {
            try {
                state.boardId = Number(id);
                state.boardData = res.data || null;
                localStorage.setItem('egbm.activeBoard', state.boardId);
                renderBoardRail();
                renderBoardWorkspace();
            } catch (error) {
                console.error('BookMarks render error:', error);
                errorScreen(
                    'BookMarks data loaded, but the workspace could not be rendered. Please retry.');
            }
        }).fail(function(err) {
            errorScreen(err.message);
        });
    }

    function bookmarkFavicon(bookmark) {
        if (!bookmark) return '';

        const stored = String(bookmark.favicon_url || '').trim();
        if (!stored) return '';

        // Only render ERP-owned cached favicons. Never render generated/fallback
        // icons, Google S2 proxy URLs, or arbitrary third-party icon URLs.
        if (/google\.com\/s2\/favicons/i.test(stored)) return '';
        if (/_fallback\./i.test(stored)) return '';

        try {
            const parsed = new URL(stored, window.location.origin);
            const path = String(parsed.pathname || '');
            const validPath =
                /^\/(storage\/)?favicons\/bookmark_[a-f0-9]{40}\.(ico|png|jpg|jpeg|webp|svg|gif|bmp)$/i.test(path) ||
                /^\/favicon\/bookmark_[a-f0-9]{40}\.(ico|png|jpg|jpeg|webp|svg|gif|bmp)$/i.test(path);

            return validPath ? parsed.href : '';
        } catch (e) {
            return '';
        }
    }

    function faviconMarkup(bookmark, size) {
        const stored = bookmarkFavicon(bookmark);
        const resolver = !stored && bookmark?.url ? normalizeUserUrl(String(bookmark.url)) : '';
        const image = stored
            ? '<img loading=\"lazy\" decoding=\"async\" referrerpolicy=\"no-referrer\" src=\"' + esc(stored) +
            '\" alt=\"Official favicon\" onload=\"$(this).prev().hide();\" onerror=\"this.style.display=\'none\';$(this).prev().show();\">'
            : (resolver
                ? '<img loading=\"lazy\" decoding=\"async\" referrerpolicy=\"no-referrer\" data-egbm-favicon-source=\"' +
                esc(resolver) + '\" alt=\"Official favicon\" style=\"display:none\">'
                : '');

        return '<div class=\"egbm-link-favicon\" style=\"width:' + size + 'px;height:' + size + 'px\">' +
            '<span class=\"fallback\"><i class=\"mdi mdi-bookmark-outline\"></i></span>' +
            image +
            '</div>';
    }

    function resolveRenderedFavicons() {
        const jobs = [];
        const seen = {};
        $workspace.find('img[data-egbm-favicon-source]').each(function() {
            const urlValue = String($(this).attr('data-egbm-favicon-source') || '').trim();
            if (!urlValue || seen[urlValue]) return;
            seen[urlValue] = true;
            jobs.push(urlValue);
        });
        if (!jobs.length || !R.bookmarkFavicon) return;

        let cursor = 0;
        let active = 0;
        const maxConcurrent = 5;

        function applyToImages(urlValue, faviconUrl) {
            $workspace.find('img[data-egbm-favicon-source]').filter(function() {
                return String($(this).attr('data-egbm-favicon-source') || '') === urlValue;
            }).each(function() {
                if (faviconUrl) {
                    $(this).attr('src', faviconUrl).attr('data-egbm-favicon-resolved', '1').show();
                    $(this).prev().hide();
                } else {
                    this.style.display = 'none';
                    $(this).prev().show();
                }
            });
        }

        function pump() {
            while (active < maxConcurrent && cursor < jobs.length) {
                const urlValue = jobs[cursor++];
                active++;

                // Unresolved/migrated records are always refreshed so an old
                // generated icon can never be reused as if it were official.
                ajax('GET', R.bookmarkFavicon + '?url=' + encodeURIComponent(urlValue) + '&refresh=1', null, {
                        timeout: 12000
                    })
                    .done(function(res) {
                        const resolved = String(res.data?.favicon_url || '');
                        state.faviconCache[urlValue] = resolved;
                        applyToImages(urlValue, resolved);
                    })
                    .fail(function() {
                        state.faviconCache[urlValue] = '';
                        applyToImages(urlValue, '');
                    })
                    .always(function() {
                        active--;
                        pump();
                    });
            }
        }

        pump();
    }

    function healthBadge(status) {

        const s = String(status || 'unknown').toLowerCase();
        if (s === 'healthy') return '<span class="egbm-link-status egbm-health-healthy">Healthy</span>';
        if (s === 'broken') return '<span class="egbm-link-status egbm-health-broken">Broken</span>';
        if (s === 'checking') return '<span class="egbm-link-status egbm-health-unknown">Checking</span>';
        return '<span class="egbm-link-status egbm-health-unknown">Unknown</span>';
    }

    function renderTopLinksInline(items) {
        const rows = Array.isArray(items) ? items : [];
        if (!rows.length) return '';
        return '<div class="egbm-inline-toplinks"><span class="egbm-top-links-label">TOP LINKS</span>' +
            rows.slice(0, 6).map(function(b) {
                return '<button type="button" class="egbm-toplink" data-egbm-open-link data-id="' +
                    esc(b.sno) + '" title="Open ' + esc(b.bookmark_name || b.url || 'Bookmark') + '">' +
                    faviconMarkup(b, 20) + '<span class="tn">' + esc(b.bookmark_name || b.url || 'Bookmark') +
                    '</span></button>';
            }).join('') + '</div>';
    }

    function renderCategoryCard(c, rows, board, canManage) {
        const count = Number(c.bookmark_count || rows.length || 0);
        const collapsed = c.is_collapsed ? ' egbm-category-collapsed' : '';
        return '<section class="egbm-category' + collapsed + '" draggable="' + (canManage && !board.is_locked ?
                'true' : 'false') + '" data-category-id="' + esc(c.sno) +
            '" style="--egbm-category-color:' + esc(c.color || '#4A3E8E') + '">' +
            '<div class="egbm-category-head"><span class="egbm-category-drag" title="Drag to reorder"><i class="mdi mdi-drag-vertical"></i></span><span class="egbm-category-dot"></span><div class="egbm-category-title">' +
            esc(c.category_name || 'Category') + '</div><span class="egbm-category-count">' + esc(count) +
            '</span>' +
            '<button type="button" class="egbm-category-toggle" data-egbm-action="toggle-category" title="Expand / collapse"><i class="mdi ' +
            (c.is_collapsed ? 'mdi-chevron-right' : 'mdi-chevron-down') + '"></i></button>' +
            '<div class="dropdown"><button type="button" class="egbm-category-more" data-bs-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end">' +
            (canManage ? '<li><button class="dropdown-item" data-egbm-action="rename-category" data-category-id="' +
                esc(c.sno) +
                '"><i class="mdi mdi-pencil-outline me-2"></i>Rename</button></li><li><button class="dropdown-item" data-egbm-action="recolour-category" data-category-id="' +
                esc(c.sno) +
                '"><i class="mdi mdi-palette-outline me-2"></i>Recolour</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" data-egbm-action="delete-category" data-category-id="' +
                esc(c.sno) + '"><i class="mdi mdi-delete-outline me-2"></i>Delete category</button></li>' :
                '<li><span class="dropdown-item-text text-muted">View only</span></li>') +
            '</ul></div></div>' +
            (!board.is_locked && canManage ?
                '<div class="egbm-add-row"><i class="mdi mdi-link-plus"></i><input class="egbm-url-input" data-egbm-url-input data-category-id="' +
                esc(c.sno) + '" placeholder="Paste URL or instagram.com, press Enter" autocomplete="off"></div>' : '') +
            (!rows.length ?
                '<div class="egbm-link-list"><div class="egbm-category-empty">No bookmarks in this category.</div></div>' :
                '<div class="egbm-link-list">' + rows.map(function(b) {
                    return bookmarkRow(b, canManage && !board.is_locked);
                }).join('') + '</div>') +
            '</section>';
    }

    function categoryBookmarkMap() {
        const grouped = {};
        const source = state.boardData?.bookmarks || {};

        Object.keys(source).forEach(function(key) {
            grouped[String(key)] = Array.isArray(source[key]) ? source[key] : [];
        });

        return new Proxy(grouped, {
            get: function(target, prop) {
                return target[String(prop)] || [];
            }
        });
    }

    function renderBoardWorkspace() {
        const d = state.boardData || {};
        const board = d.board || {};
        const categories = Array.isArray(d.categories) ? d.categories : [];
        const grouped = categoryBookmarkMap();
        const topLinks = Array.isArray(d.top_links) ? d.top_links : [];
        const canManage = board.can_manage !== false;
        const boardScopeLabel = Number(board.company_id || 0) === 0 ? 'Common Board' : (board.company_name || board.company_short_name || 'Company Board');
        const boardScopeIcon = Number(board.company_id || 0) === 0 ? 'mdi-earth' : 'mdi-domain';
        const header =
            `<div class="egbm-workspace-head"><div class="egbm-heading-meta"><button type="button" class="egbm-mobile-boards" id="egbmBoardsToggle"><i class="mdi mdi-menu"></i></button><div class="egbm-board-title-block"><h2>` +
            esc(board.board_name || 'Board') +
            `</h2><div class="egbm-board-subline">`+
            (board.is_locked ?
                '<span class="egbm-lock-pill"><i class="mdi mdi-lock-outline"></i> Locked</span>' : '') +
            '</div></div>' + renderTopLinksInline(topLinks) + '</div>' +
            '<div class="egbm-workspace-actions"><div class="egbm-board-search"><i class="mdi mdi-magnify"></i><input id="egbmBoardWorkspaceSearch" type="search" value="' +
            esc(state.workspaceSearch) +
            '" placeholder="Search this board" autocomplete="off"><button type="button" class="egbm-inline-clear ' +
            (state.workspaceSearch ? '' : 'd-none') +
            '" id="egbmBoardWorkspaceClear"><i class="mdi mdi-close"></i></button></div>' +
            // (canManage ? '<button type="button" class="egbm-btn" data-egbm-action="import" data-board-id="' + esc(
            //     board.sno) + '"><i class="mdi mdi-upload-outline"></i> Import</button>' : '') +
            (canManage ?
                '<button type="button" class="egbm-btn-purple" data-egbm-action="share-board" data-board-id="' +
                esc(board.sno) + '"><i class="mdi mdi-account-multiple-plus-outline"></i> Share</button>' : '') +
            (canManage ?
                '<button type="button" class="egbm-btn-primary" data-egbm-action="new-category" data-board-id="' +
                esc(board.sno) + '"><i class="mdi mdi-plus"></i> Category</button>' : '') +
            (canManage ?
                '<div class="dropdown"><button class="egbm-icon-btn" type="button" data-bs-toggle="dropdown"><i class="mdi mdi-dots-horizontal"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" data-egbm-action="edit-board" data-board-id="' +
                esc(board.sno) +
                '"><i class="mdi mdi-pencil-outline me-2"></i>Edit board</button></li><li><button class="dropdown-item" data-egbm-action="toggle-lock" data-board-id="' +
                esc(board.sno) + '"><i class="mdi mdi-lock-outline me-2"></i>' + (board.is_locked ? 'Unlock board' :
                    'Lock board') +
                '</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" data-egbm-action="archive-board" data-board-id="' +
                esc(board.sno) +
                '"><i class="mdi mdi-archive-outline me-2"></i>Archive board</button></li></ul></div>' : '') +
            '</div></div>';
        let body = '';
        if (!categories.length) {
            body =
                '<div class="egbm-canvas"><div class="egbm-empty"><div><i class="mdi mdi-shape-outline"></i><div class="egbm-empty-title">No categories yet</div><div class="egbm-empty-text">Create a category to start storing bookmarks in this board.</div>' +
                (canManage ?
                    '<button type="button" class="egbm-btn-primary mt-3" data-egbm-action="new-category" data-board-id="' +
                    esc(board.sno) + '"><i class="mdi mdi-plus"></i> Add category</button>' : '') +
                '</div></div></div>';
        } else {
            const columns = [
                [],
                [],
                []
            ];
            categories.forEach(function(c, index) {
                columns[index % 3].push(c);
            });
            body = '<div class="egbm-canvas"><div class="egbm-category-grid">' +
                columns.map(function(col) {
                    return '<div class="egbm-category-column">' + col.map(function(c) {
                        const rows = Array.isArray(grouped[c.sno]) ? grouped[c.sno] : [];
                        return renderCategoryCard(c, rows, board, canManage);
                    }).join('') + '</div>';
                }).join('') + '</div></div>';
        }
        $skeleton.addClass('d-none');
        $workspace.removeClass('d-none').html(header + (board.is_locked ?
            '<div class="egbm-locked-banner"><i class="mdi mdi-lock-outline"></i><span>This board is locked. Links remain available, while routine changes are disabled.</span></div>' :
            '') + '<div class="egbm-workspace-body">' + body + '</div>');
        resolveRenderedFavicons();
    }

    function bookmarkRow(b, canManage) {
        const title = b.bookmark_name || b.url || 'Bookmark';
        const note = b.description || '';
        return '<div class="egbm-link-row" data-bookmark-id="' + esc(b.sno) + '">' + faviconMarkup(b, 30) +
            '<div class="egbm-link-main"><button type="button" class="egbm-link-open" data-egbm-action="open-bookmark" data-id="' +
            esc(b.sno) + '" title="Open ' + esc(title) + '"><span class="egbm-link-title">' + esc(title) +
            '</span><span class="egbm-link-url">' + esc(b.url || '') + '</span>' + (note ?
                '<span class="egbm-link-note">' + esc(note) + '</span>' : '') + '</button></div>' +
            '<div class="egbm-link-actions">' +
            '<button type="button" class="egbm-link-action" data-egbm-action="open-bookmark" data-id="' + esc(b
                .sno) + '" title="Open"><i class="mdi mdi-open-in-new"></i></button>' + (canManage ?
                '<button type="button" class="egbm-link-action" data-egbm-action="edit-bookmark" data-id="' + esc(b
                    .sno) + '" title="Edit"><i class="mdi mdi-pencil-outline"></i></button>' : '') +
            '<button type="button" class="egbm-link-action" data-egbm-action="copy-bookmark" data-id="' + esc(b
                .sno) + '" title="Copy URL"><i class="mdi mdi-content-copy"></i></button>' + (canManage ?
                '<div class="dropdown"><button type="button" class="egbm-link-action" data-bs-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" data-egbm-action="bookmark-health" data-id="' +
                esc(b.sno) +
                '"><i class="mdi mdi-heart-pulse me-2"></i>Check health</button></li><li><button class="dropdown-item" data-egbm-action="move-copy" data-id="' +
                esc(b.sno) +
                '"><i class="mdi mdi-content-copy me-2"></i>Move / copy</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" data-egbm-action="delete-bookmark" data-id="' +
                esc(b.sno) + '"><i class="mdi mdi-delete-outline me-2"></i>Remove</button></li></ul></div>' : '') +
            '</div></div>';
    }

    function populateBoardModalLookups(item) {
        const visibility = item?.visibility || 'Private';

        $('#egbmBoardVisibility').val(visibility);
        setBoardVisibilityChoice(visibility);
        renderBoardVisibilityTargets(item);
        // initSelect3('#egbmBoardModal');
    }

    function setBoardVisibilityChoice(visibility) {
        const value = ['Private', 'Company', 'Group'].includes(visibility) ? visibility : 'Private';
        $('#egbmBoardVisibility').val(value);

        $('#egbmBoardModal .egbm-visibility-choice').each(function() {
            const active = String($(this).data('egbm-visibility')) === value;
            $(this).toggleClass('is-active', active).attr('aria-pressed', active ? 'true' : 'false');
        });
    }

    function renderBoardVisibilityTargets(item) {
        const visibility = ['Private', 'Company', 'Group'].includes($('#egbmBoardVisibility').val()) ?
            $('#egbmBoardVisibility').val() : 'Private';
        const $companyWrap = $('#egbmVisibilityCompanyWrap');
        const $groupWrap = $('#egbmVisibilityGroupWrap');
        const $companySelect = $('#egbmVisibilityCompanies');
        const $userSelect = $('#egbmVisibilityUsers');
        const currentUser = state.lookups.current_user || {};
        const companies = state.lookups.companies || [];
        const staff = state.lookups.staff || [];

        // Always reset the conditional controls first. This also guarantees that a
        // Select2 instance created in a previous visibility mode is removed cleanly.
        $companyWrap.addClass('d-none');
        $groupWrap.addClass('d-none');
        // destroySelect3($companySelect);
        // destroySelect3($userSelect);
        $companySelect.empty().val([]);
        $userSelect.empty().val([]);

        if (visibility === 'Company') {
            $companyWrap.removeClass('d-none');

            const existing = Array.isArray(item?.visibility_company_ids) ?
                item.visibility_company_ids.map(Number) : [];

            setSelectMulti($companySelect, companies, existing, 'Select one or more companies', function(c) {
                return c.sno === 0 || c.sno === '0' ?
                    (c.company_name || 'Elysium Groups') :
                    (c.company_name || c.company_short_name || ('Company #' + c.sno));
            });
        } else if (visibility === 'Group') {
            $groupWrap.removeClass('d-none');

            const existing = Array.isArray(item?.visibility_user_ids) ?
                item.visibility_user_ids.map(Number) : [];

            setSelectMulti($userSelect, staff, existing, 'Select one or more staff', function(u) {
                const company = u.company_short_name || u.company_name || 'No company';
                return (u.staff_name || ('Staff #' + u.sno)) + ' · ' + company;
            });
        }

        setBoardVisibilityChoice(visibility);

        $('#egbmBoardVisibilityHint').text(
            visibility === 'Company' ?
            'Choose one or more active companies. All staff belonging to those companies can view the board.' :
            visibility === 'Group' ?
            'Choose the active staff members who can view the board.' :
            'Only the creator can view this board by default.'
        );
    }

    function openBoardModal(item) {
        state.modalMode = item ? 'edit' : 'new';
        $('#egbmBoardModalTitle').text(item ? 'Edit Board' : 'New Board');
        $('#egbmBoardModalSubtitle').text(item ? 'Update the board without leaving the BookMarks workspace.' :
            'Create a common board with clear access controls.');
        $('#egbmBoardForm')[0].reset();
        $('#egbmBoardForm [name="board_name"]').val(item?.board_name || '');
        $('#egbmBoardForm [name="description"]').val(item?.description || '');
        $('#egbmBoardForm [name="is_locked"]').prop('checked', !!item?.is_locked);
        populateBoardModalLookups(item || null);
        $('#egbmBoardSave').html(item ? '<i class="mdi mdi-content-save-outline"></i> Save board' :
            '<i class="mdi mdi-plus"></i> Create board');
        boardModal().show();
        // initSelect3('#egbmBoardModal');
    }


    function nextCategoryColor() {
        const palette = ['#b52b25',
            '#2267c8', '#27823e', '#be8c06', '#7b2fa2'
        ];
        const rows = Array.isArray(state.boardData?.categories) ? state.boardData.categories : [];
        return palette[rows.length % palette.length];
    }

    function openCategoryForm(category, mode) {
        const isColor = mode === 'recolour';
        $('#egbmFormKicker').text('CATEGORY');
        $('#egbmFormTitle').text(isColor ? 'Recolour category' : (category ? 'Rename category' : 'Add category'));
        $('#egbmFormSubtitle').text(isColor ? 'Use the category colour to make boards easier to scan.' :
            'Categories stay inside the current board.');
        const body = '<div class="row g-3">' +
            (!isColor ?
                '<div class="col-12"><label class="form-label">Category name <span class="text-danger">*</span></label><input class="form-control" name="category_name" value="' +
                esc(category?.category_name || '') +
                '" maxlength="160" required placeholder="e.g. Dev Tools"></div>' : '') +
            '<div class="col-12"><label class="form-label">Colour <span class="text-danger">*</span></label><input type="color" class="form-control form-control-color" name="color" value="' +
            esc(category?.color || nextCategoryColor()) + '" title="Choose category colour"></div>' +
            
            '</div>';
        $('#egbmFormBody').html(body);
        $('#egbmForm').off('submit.egbm').on('submit.egbm', function(e) {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(this).entries());
            delete data.sort_order;
            const endpoint = category ? route(R.categoryUpdate, category.sno) : route(R.categoryStore, state
                .boardId, 'categories');
            const method = category ? 'PUT' : 'POST';
            submitForm(endpoint, method, data, function() {
                formModal().hide();
                loadBoard(state.boardId);
                loadBoards(false);
            });
        });
        formModal().show();
    }

    function openBookmarkForm(item) {
        $('#egbmFormKicker').text('BOOKMARK');
        $('#egbmFormTitle').text(item ? 'Edit bookmark' : 'Add bookmark');
        $('#egbmFormSubtitle').text('The favicon is resolved from the official website and cached by ERP.');
        const categories = Array.isArray(state.boardData?.categories) ? state.boardData.categories : [];
        const categoryId = item?.category_id || categories[0]?.sno || '';
        $('#egbmFormBody').html(
            '<div class="row g-3">' +
            '<div class="col-md-7"><label class="form-label">Name <span class="text-danger">*</span></label><input class="form-control" name="bookmark_name" maxlength="180" value="' +
            esc(item?.bookmark_name || '') + '" required placeholder="e.g. Company Portal"></div>' +
            '<div class="col-md-5"><label class="form-label">Category <span class="text-danger">*</span></label><select class="form-select select3" name="category_id" data-placeholder="Select category"></select></div>' +
            '<div class="col-12"><label class="form-label">URL <span class="text-danger">*</span></label><input class="form-control" name="url" maxlength="2000" value="' +
            esc(item?.url || '') + '" required placeholder="example.com or https://example.com"></div>' +
            '<div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="3" maxlength="5000" placeholder="Optional notes">' +
            esc(item?.description || '') + '</textarea></div>' +
            '<div class="col-12"><label class="form-label">Tags</label><input class="form-control" name="tags" value="' +
            esc(Array.isArray(item?.tags_json) ? item.tags_json.join(', ') : '') +
            '" placeholder="erp, finance, reference"></div>' +
            '<div class="col-12"><div class="egbm-favicon-preview"><i class="mdi mdi-shield-check-outline"></i><div><strong>Official favicon</strong><small>Resolved server-side from the bookmark URL on save.</small></div><button type="button" class="egbm-btn" id="egbmResolveIcon">Resolve now</button></div></div>' +
            '</div>'
        );
        setSelect($('#egbmForm [name="category_id"]'), categories, categoryId, 'Select category', function(c) {
            return c.category_name;
        });
        $('#egbmForm').off('submit.egbm').on('submit.egbm', function(e) {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(this).entries());
            data.board_id = state.boardId;
            data.url = normalizeUserUrl(data.url);
            $('#egbmForm [name="url"]').val(data.url);
            data.tags = String(data.tags || '').split(',').map(function(x) {
                return x.trim();
            }).filter(Boolean);
            const endpoint = item ? route(R.bookmarkUpdate, item.sno) : R.bookmarkStore;
            const method = item ? 'PUT' : 'POST';
            submitForm(endpoint, method, data, function() {
                formModal().hide();
                loadBoard(state.boardId);
                loadBoards(false);
            });
        });
        $('#egbmForm').off('click.icon').on('click.icon', '#egbmResolveIcon', function() {
            const urlValue = normalizeUserUrl($('#egbmForm [name="url"]').val());
            if (!urlValue) {
                toastr.error('Enter a URL first.');
                return;
            }
            $('#egbmForm [name="url"]').val(urlValue);
            const $btn = $(this),
                old = $btn.html();
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');
            ajax('GET', R.bookmarkFavicon + '?url=' + encodeURIComponent(urlValue) + '&refresh=1').done(function(res) {
                toastr.success(res.data?.resolved ? 'Official favicon resolved and cached.' :
                    'No usable favicon was exposed by this site.', res.data?.resolved ?
                    'success' : 'warning');
            }).fail(function(err) {
                toastr.error(err.message);
            }).always(function() {
                $btn.prop('disabled', false).html(old);
            });
        });
        formModal().show();
        // initSelect3('#egbmFormModal');
    }

    function submitForm(endpoint, method, data, done) {
        const $button = $('#egbmFormSave').prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
        ajax(method, endpoint, data).done(function(res) {
            toastr.success(res.message || 'Saved successfully.');
            if (done) done(res);
        }).fail(function(err) {
            toastr.error(err.message || 'Save failed.');
        }).always(function() {
            $button.prop('disabled', false).text('Save');
        });
    }

    function confirmAction(title, message, confirmText, fn) {
        $('#egbmConfirmTitle').text(title);
        $('#egbmConfirmBody').text(message);
        $('#egbmConfirmYes').text(confirmText || 'Confirm').off('click.egbm').on('click.egbm', function() {
            const $btn = $(this).prop('disabled', true);
            let result;
            try {
                result = fn();
            } catch (e) {
                toastr.error(e.message || 'Action failed.');
            }
            const finish = function() {
                $btn.prop('disabled', false);
                confirmModal().hide();
            };
            if (result && typeof result.always === 'function') result.always(finish);
            else if (result && typeof result.finally === 'function') result.finally(finish);
            else finish();
        });
        confirmModal().show();
    }

    function openShare(boardId) {
        state.shareBoardId = Number(boardId);
        const board = state.boardData?.board || state.boardRows.find(function(b) {
            return Number(b.sno) === Number(boardId);
        }) || {};

        $('#egbmShareTitle').text('Share “' + (board.board_name || 'Board') + '”');
        $('#egbmSharePermission').val('View').trigger('change');
        resetShareExpiryPicker(true);
        setShareType('user', false);

        const modalElement = document.getElementById('egbmShareModal');
        $(modalElement).off('shown.bs.modal.egbmShare').one('shown.bs.modal.egbmShare', function() {
            loadShareTargets('user', []);
            loadShares(boardId);
        });

        shareModal().show();
    }

    function setShareType(type, shouldLoadTargets) {
        const allowed = ['user', 'company', 'group'];
        const value = allowed.includes(String(type)) ? String(type) : 'user';

        $('#egbmShareType').val(value);
        $('#egbmShareTypeCards [data-share-type]').each(function() {
            const active = String($(this).data('share-type')) === value;
            $(this).toggleClass('is-active', active).attr('aria-pressed', active ? 'true' : 'false');
        });

        if (shouldLoadTargets !== false) {
            loadShareTargets(value, []);
        }
    }

    function shareTypeConfig(type) {
        if (type === 'company') {
            return {
                multiple: true,
                label: 'Select companies',
                helper: 'Choose one or more active companies. All active staff in those companies will be eligible.',
                hint: 'Company access follows the selected companies; new active staff in those companies are included automatically.',
                placeholder: 'Search companies…',
                icon: 'mdi-office-building-outline'
            };
        }

        if (type === 'group') {
            return {
                multiple: true,
                label: 'Select staff',
                helper: 'Choose the staff members who should receive access.',
                hint: 'Each selected staff member receives the same access level and expiry.',
                placeholder: 'Search staff…',
                icon: 'mdi-account-multiple-outline'
            };
        }

        return {
            multiple: false,
            label: 'Select person',
            helper: 'Choose one active staff member.',
            hint: 'Only active staff members are shown.',
            placeholder: 'Search staff…',
            icon: 'mdi-account-outline'
        };
    }

    function initShareTargetSelect(multiple, placeholder) {
        const $target = $('#egbmShareTarget');
        if (!$target.length || typeof $.fn.select2 !== 'function') return;

        destroySelect3($target);
        $target.prop('multiple', !!multiple);
        $target.select2({
            width: '100%',
            dropdownParent: $('#egbmShareModal .modal-content'),
            placeholder: placeholder || 'Select',
            allowClear: !multiple,
            closeOnSelect: !multiple,
            minimumResultsForSearch: multiple ? 0 : 8
        });
    }

    function shareTargetItems(type) {
        if (type === 'company') {
            return (state.lookups.companies || []).map(function(c) {
                return {
                    value: c.sno,
                    label: c.company_name || c.company_short_name || ('Company #' + c.sno),
                    company_id: c.sno
                };
            });
        }

        return (state.lookups.staff || []).map(function(u) {
            return {
                value: u.sno,
                label: (u.staff_name || ('Staff #' + u.sno)) + (u.email_id ? ' · ' + u.email_id : ''),
                company_id: u.company_id,
                company_name: u.company_short_name || u.company_name || 'No company'
            };
        });
    }

    function loadShareTargets(type, selectedValues) {
        const config = shareTypeConfig(type);
        const selected = Array.isArray(selectedValues) ? selectedValues.map(String) : [];
        const $target = $('#egbmShareTarget');
        const items = shareTargetItems(type);

        $('#egbmShareTargetLabel').text(config.label);
        $('#egbmShareTargetHelper').text(config.helper);
        $('#egbmShareTargetHint').text(config.hint);
        $('#egbmShareTargetIcon').find('i').attr('class', 'mdi ' + config.icon);

        if (!$target.length) return;

        $target.prop('disabled', true).empty();
        items.forEach(function(item) {
            $target.append($('<option>', {
                value: item.value,
                text: item.label
            }));
        });

        initShareTargetSelect(config.multiple, config.placeholder);

        if (config.multiple) {
            const validSelected = selected.filter(function(value) {
                return items.some(function(item) { return String(item.value) === String(value); });
            });
            $target.val(validSelected).trigger('change');
        } else {
            const value = selected[0] || '';
            $target.val(value).trigger('change');
        }

        $target.prop('disabled', false);
        updateShareEligiblePanel(type);

        $target.off('change.egbmShareTarget').on('change.egbmShareTarget', function() {
            updateShareEligiblePanel(type);
        });
    }

    function getShareTargetValues() {
        const value = $('#egbmShareTarget').val();
        if (Array.isArray(value)) {
            return value.map(String).filter(Boolean);
        }
        return value ? [String(value)] : [];
    }

    function findShareStaffById(id) {
        return (state.lookups.staff || []).find(function(u) {
            return String(u.sno) === String(id);
        });
    }

    function renderShareEligiblePanel(type, title, caption, names) {
        const $panel = $('#egbmShareEligiblePanel');
        if (!$panel.length || !names.length) {
            $panel.addClass('d-none').empty();
            return;
        }

        const visibleNames = names.slice(0, 24);
        const remaining = Math.max(0, names.length - visibleNames.length);
        $panel.removeClass('d-none').html(
            '<div class="egbm-share-eligible-summary">' +
                '<div><div class="egbm-share-eligible-count">' + esc(title) + '</div>' +
                '<div class="egbm-share-eligible-caption">' + esc(caption) + '</div></div>' +
            '</div>' +
            '<div class="egbm-share-eligible-chips">' +
                visibleNames.map(function(name) {
                    return '<span class="egbm-share-eligible-chip"><i class="mdi mdi-account-outline"></i>' + esc(name) + '</span>';
                }).join('') +
                (remaining ? '<span class="egbm-share-eligible-more">+' + remaining + ' more</span>' : '') +
            '</div>'
        );
    }

    function updateShareEligiblePanel(type) {
        const values = getShareTargetValues();
        if (!values.length) {
            $('#egbmShareEligiblePanel').addClass('d-none').empty();
            return;
        }

        if (type === 'company') {
            const companyIds = values.map(Number);
            const companies = (state.lookups.companies || []).filter(function(c) {
                return companyIds.includes(Number(c.sno));
            });
            const eligibleStaff = (state.lookups.staff || []).filter(function(u) {
                return companyIds.includes(Number(u.company_id));
            });
            const names = eligibleStaff.map(function(u) { return u.staff_name || ('Staff #' + u.sno); });
            renderShareEligiblePanel(
                type,
                eligibleStaff.length + ' active staff eligible',
                companies.length + ' compan' + (companies.length === 1 ? 'y' : 'ies') + ' selected · access applies automatically to eligible staff',
                names
            );
            return;
        }

        if (type === 'group') {
            const staff = values.map(findShareStaffById).filter(Boolean);
            renderShareEligiblePanel(
                type,
                staff.length + ' staff selected',
                'These staff members will receive the selected access level.',
                staff.map(function(u) { return u.staff_name || ('Staff #' + u.sno); })
            );
            return;
        }

        const user = findShareStaffById(values[0]);
        if (user) {
            renderShareEligiblePanel(
                type,
                user.staff_name || ('Staff #' + user.sno),
                (user.company_short_name || user.company_name || 'Staff member') + (user.email_id ? ' · ' + user.email_id : ''),
                []
            );
        } else {
            $('#egbmShareEligiblePanel').addClass('d-none').empty();
        }
    }

    function loadShares(boardId) {
        $('#egbmShareList').html(
            '<div class="egbm-share-row"><div class="skeleton-glow" style="width:100%;height:30px;border-radius:7px"></div></div>' +
            '<div class="egbm-share-row"><div class="skeleton-glow" style="width:84%;height:30px;border-radius:7px"></div></div>'
        );

        ajax('GET', R.shares.data + '?' + query({
            resource_type: 'board',
            resource_id: boardId
        })).done(function(res) {
            const rows = Array.isArray(res.data) ? res.data : [];
            if (!rows.length) {
                $('#egbmShareList').html(
                    '<div class="py-4 text-center text-muted" style="font-size:9px">No additional access has been shared yet.</div>'
                );
                return;
            }

            $('#egbmShareList').html(rows.map(function(x) {
                const companies = state.lookups.companies || [];
                const users = state.lookups.staff || [];
                const company = companies.find(function(c) {
                    return String(c.sno) === String(x.grantee_id);
                });
                const user = users.find(function(u) {
                    return String(u.sno) === String(x.grantee_id);
                });
                const metadata = (function() {
                    try { return x.metadata_json ? JSON.parse(x.metadata_json) : {}; } catch (e) { return {}; }
                })();
                const fromVisibility = metadata.source === 'bookmarks_visibility';

                let name = '';
                let sub = '';
                let icon = 'mdi-account-outline';

                if (x.grantee_type === 'company') {
                    name = company?.company_name || company?.company_short_name || ('Company #' + x.grantee_id);
                    sub = 'All active staff in this company';
                    icon = 'mdi-office-building-outline';
                } else if (x.grantee_type === 'user') {
                    name = user?.staff_name || ('Staff #' + x.grantee_id);
                    sub = user?.email_id || (user?.company_short_name || user?.company_name || 'Staff member');
                    icon = 'mdi-account-outline';
                } else {
                    name = 'Legacy access';
                    sub = 'Existing access created by an older sharing rule';
                    icon = 'mdi-shield-account-outline';
                }

                const permission = x.permission === 'Manage' ?
                    '<span class="egbm-share-pill co">Co-owner</span>' :
                    '<span class="egbm-share-pill">Viewer</span>';
                const status = x.status === 'pending' ?
                    '<span class="egbm-share-pill pending">Pending</span>' : '';
                const source = fromVisibility ?
                    '<span class="egbm-share-pill egbm-share-source-pill visibility">Board visibility</span>' :
                    '<span class="egbm-share-pill egbm-share-source-pill">Shared access</span>';
                const revoke = fromVisibility ? '' :
                    '<button class="egbm-link-action text-danger" data-share-revoke="' + esc(x.sno) + '" title="Revoke access" aria-label="Revoke access">' +
                    '<i class="mdi mdi-close"></i></button>';

                return '<div class="egbm-share-row d-flex align-items-center gap-2">' +
                    '<div class="egbm-share-avatar"><i class="mdi ' + icon + '"></i></div>' +
                    '<div class="egbm-share-main flex-grow-1 min-w-0"><strong>' + esc(name) + '</strong><small>' +
                    esc(sub) + ' · ' + esc(x.expires_at || 'No expiry') + '</small></div>' +
                    '<div class="d-flex align-items-center flex-wrap justify-content-end gap-1">' + source + permission + status + revoke + '</div>' +
                    '</div>';
            }).join(''));
        }).fail(function(err) {
            $('#egbmShareList').html('<div class="egbm-error m-2">' + esc(err.message || 'Unable to load current access.') + '</div>');
        });
    }

    function openImport(boardId) {
        state.importBoardId = Number(boardId);
        state.importFile = null;
        state.importPreview = null;
        $('#egbmImportFile').val('');
        $('#egbmImportFileMeta').addClass('d-none').empty();
        $('#egbmImportStepUpload').removeClass('d-none');
        $('#egbmImportStepMap').addClass('d-none').empty();
        $('#egbmImportStepBusy').addClass('d-none').empty();
        $('#egbmImportSubmit').addClass('d-none').prop('disabled', true);
        importModal().show();
    }

    function importPreview(file) {
        state.importFile = file;
        const $meta = $('#egbmImportFileMeta').removeClass('d-none').html(
            '<div class="egbm-summary-card"><div class="n">' + esc(file.name) +
            '</div><div class="t">Selected file</div></div>');
        const form = new FormData();
        form.append('board_id', state.importBoardId);
        form.append('file', file);
        $('#egbmImportStepBusy').removeClass('d-none').html(
            '<div class="py-5 text-center"><div class="spinner-border spinner-border-sm text-primary"></div><div class="small text-muted mt-2">Reading folders and links…</div></div>'
        );
        ajax('POST', R.bookmarkImportPreview, form, {
            processData: false,
            contentType: false,
            timeout: 45000
        }).done(function(res) {
            state.importPreview = res.data || {};
            renderImportMapping();
        }).fail(function(err) {
            toastr.error(err.message || 'Import preview failed.');
        }).always(function() {
            $('#egbmImportStepBusy').addClass('d-none').empty();
        });
    }

    function renderImportMapping() {
        const d = state.importPreview || {};
        const folders = Array.isArray(d.folders) ? d.folders : [];
        const categories = Array.isArray(d.categories) ? d.categories : [];
        $('#egbmImportStepMap').removeClass('d-none');
        $('#egbmImportSummary').html(
            summaryCard(d.total || 0, 'BOOKMARKS') +
            summaryCard(folders.length, 'FOLDERS') +
            summaryCard(categories.length, 'EXISTING CATEGORIES') +
            summaryCard('500', 'IMPORT LIMIT')
        );
        $('#egbmImportMappings').html(folders.length ? folders.map(function(f, idx) {
                const options = [{
                    value: '',
                    label: 'Skip this folder'
                }].concat(categories.map(function(c) {
                    return {
                        value: c.sno,
                        label: c.category_name
                    };
                }), [{
                    value: 'new:' + f.folder,
                    label: '+ New: ' + f.folder
                }]);
                return '<div class="egbm-import-row"><div class="egbm-import-folder"><i class="mdi mdi-folder-outline"></i><div><strong>' +
                    esc(f.folder) + '</strong><small>' + esc(f.count) + ' bookmarks' + (f.sample?.length ?
                        ' · ' + esc(f.sample[0].name) : '') +
                    '</small></div></div><select class="form-select select3 egbm-import-map" data-folder-index="' +
                    idx + '" data-placeholder="Choose a category"></select></div>' +
                    (idx === folders.length - 1 ? '' : '');
            }).join('') :
            '<div class="py-4 text-center text-muted">No valid public bookmarks were detected.</div>');
        folders.forEach(function(f, idx) {
            const $select = $('#egbmImportMappings .egbm-import-map[data-folder-index="' + idx + '"]');
            const opts = categories.map(function(c) {
                return {
                    value: c.sno,
                    label: c.category_name
                };
            });
            opts.push({
                value: 'new:' + f.folder,
                label: '+ New: ' + f.folder
            });
            setSelect($select, opts, '', 'Choose a category');
        });
        // initSelect3('#egbmImportStepMap');
        $('#egbmImportSubmit').toggleClass('d-none', folders.length === 0).prop('disabled', folders.length === 0);
    }

    function summaryCard(n, t) {
        return '<div class="egbm-summary-card"><div class="n">' + esc(n) + '</div><div class="t">' + esc(t) +
            '</div></div>';
    }

    function submitImport() {
        if (!state.importFile) {
            toastr.error('Choose an HTML bookmark file first.');
            return;
        }
        const mapping = {};
        const folders = Array.isArray(state.importPreview?.folders) ? state.importPreview.folders : [];
        $('#egbmImportMappings .egbm-import-map').each(function() {
            const idx = Number($(this).data('folder-index'));
            const folder = folders[idx]?.folder;
            if (folder) mapping[folder] = String($(this).val() || '');
        });
        const form = new FormData();
        form.append('board_id', state.importBoardId);
        form.append('file', state.importFile);
        form.append('mapping', JSON.stringify(mapping));
        const $btn = $('#egbmImportSubmit').prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-1"></span>Importing…');
        ajax('POST', R.bookmarkImport, form, {
            processData: false,
            contentType: false,
            timeout: 90000
        }).done(function(res) {
            const d = res.data || {};
            toastr.success('Imported ' + (d.imported || 0) + ' · skipped ' + ((d.duplicates || 0) + (d.skipped ||
                0)) + ' · new categories ' + (d.newCategories || 0));
            importModal().hide();
            loadBoards(false);
            loadBoard(state.importBoardId);
        }).fail(function(err) {
            toastr.error(err.message || 'Import failed.');
        }).always(function() {
            $btn.prop('disabled', false).html('<i class="mdi mdi-upload-outline"></i> Import bookmarks');
        });
    }

    function openBookmark(id) {
        ajax('POST', route(R.bookmarkOpen, id, 'open')).done(function(res) {
            if (res.data?.url) window.open(res.data.url, '_blank', 'noopener,noreferrer');
            loadBoard(state.boardId);
            loadBoards(false);
        }).fail(function(err) {
            toastr.error(err.message);
        });
    }

    function copyBookmark(id) {
        ajax('GET', route(R.boardShow, id)).done(function(res) {
            const url = res.data?.url || res.data?.bookmark?.url;
            if (!url) {
                toastr.error('Bookmark URL unavailable.');
                return;
            }
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(url).then(() => toastr.success('Bookmark URL copied.')).catch(() =>
                    fallbackCopy(url));
            } else fallbackCopy(url);
        }).fail(function() {
            toastr.error('Unable to load bookmark URL.');
        });
    }

    function fallbackCopy(text) {
        const el = document.createElement('textarea');
        el.value = text;
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.select();
        try {
            document.execCommand('copy');
            toastr.success('Bookmark URL copied.');
        } catch (e) {
            toastr.error('Copy failed.');
        }
        document.body.removeChild(el);
    }

    function editBookmark(id) {
        ajax('GET', route(R.boardShow, id)).done(function(res) {
            openBookmarkForm(res.data || {});
        }).fail(function(err) {
            toastr.error(err.message);
        });
    }

    function checkHealth(id) {
        ajax('POST', route(R.bookmarkHealth, id, 'health')).done(function(res) {
            toastr.success((res.data?.health_status || '') === 'healthy' ? 'Link is healthy.' :
                'Link reported broken.', 'warning');
            loadBoard(state.boardId);
        }).fail(function(err) {
            toastr.error(err.message);
        });
    }

    function deleteBookmark(id) {
        confirmAction('Remove bookmark', 'This bookmark will be archived and removed from the active board.',
            'Remove',
            function() {
                return ajax('DELETE', route(R.bookmarkDelete, id)).done(function() {
                    toastr.success('Bookmark removed.');
                    loadBoard(state.boardId);
                    loadBoards(false);
                });
            });
    }

    function moveCopy(id) {
        const boards = state.boardRows.filter(function(b) {
            return b.can_manage !== false;
        });
        const boardOptions = boards.map(function(b) {
            return {
                value: b.sno,
                label: b.board_name
            };
        });
        $('#egbmFormKicker').text('BOOKMARK');
        $('#egbmFormTitle').text('Move / copy bookmark');
        $('#egbmFormSubtitle').text('Choose a target board and category. Copy resets the click counter.');
        $('#egbmFormBody').html(
            '<div class="row g-3"><div class="col-md-4"><label class="form-label">Action</label><select class="form-select select3" name="mode"><option value="move">Move</option><option value="copy">Copy</option></select></div><div class="col-md-8"><label class="form-label">Target board</label><select class="form-select select3" name="target_board_id"></select></div><div class="col-12"><label class="form-label">Target category</label><select class="form-select select3" name="target_category_id"></select></div></div>'
        );
        setSelect($('#egbmForm [name="target_board_id"]'), boardOptions, state.boardId, 'Target board');
        loadTargetCategories(state.boardId, '');
        $('#egbmForm').off('change.move', '[name="target_board_id"]').on('change.move', '[name="target_board_id"]',
            function() {
                loadTargetCategories($(this).val(), '');
            });
        $('#egbmForm').off('submit.move').on('submit.move', function(e) {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(this).entries());
            $('#egbmFormSave').prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
            ajax('POST', route(R.bookmarkMoveCopy, id, 'move-copy'), data).done(function(r) {
                formModal().hide();
                toastr.success(r.message || 'Bookmark moved.');
                loadBoards(false);
                loadBoard(state.boardId);
            }).fail(function(err) {
                toastr.error(err.message);
            }).always(function() {
                $('#egbmFormSave').prop('disabled', false).text('Save');
            });
        });
        formModal().show();
        // initSelect3('#egbmFormModal');
    }

    function loadTargetCategories(boardId, selected) {
        ajax('GET', route(R.board, boardId)).done(function(res) {
            const cats = Array.isArray(res.data?.categories) ? res.data.categories : [];
            setSelect($('#egbmForm [name="target_category_id"]'), cats, selected, 'Target category',
                function(c) {
                    return c.category_name;
                });
        });
    }

    function quickAddUrl(categoryId, urlValue) {
        const url = normalizeUserUrl(urlValue);
        if (!url) return;
        const category = Number(categoryId);
        const $input = $('.egbm-url-input[data-category-id="' + String(category) + '"]');
        $input.prop('disabled', true).val('Adding…');
        ajax('POST', R.bookmarkQuick, {
            board_id: state.boardId,
            category_id: category,
            bookmark_name: '',
            url: url,
            description: '',
            tags: []
        }).done(function(res) {
            toastr.success(res.message || 'Bookmark added.');
            loadBoard(state.boardId);
            loadBoards(false);
        }).fail(function(err) {
            $input.val(url);
            toastr.error(err.message || 'Unable to add bookmark.');
        }).always(function() {
            $input.prop('disabled', false);
        });
    }

    function persistCategoryCollapsed(categoryId, collapsed) {
        const category = (state.boardData?.categories || []).find(function(c) {
            return Number(c.sno) === Number(categoryId);
        });
        if (!category) return;
        if (!state.boardData.board?.can_manage || state.boardData.board?.is_locked) return;
        const data = {
            category_name: category.category_name,
            color: category.color || nextCategoryColor(),
            is_collapsed: collapsed ? 1 : 0
        };
        ajax('PUT', route(R.categoryUpdate, categoryId), data).fail(function() {});
    }

    // Delegation — all bookmark interactions remain AJAX driven.
    $workspace.on('click', '[data-egbm-action="open-bookmark"]', function(e) {
        e.preventDefault();
        openBookmark(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="copy-bookmark"]', function(e) {
        e.preventDefault();
        copyBookmark(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="edit-bookmark"]', function(e) {
        e.preventDefault();
        editBookmark(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="delete-bookmark"]', function(e) {
        e.preventDefault();
        deleteBookmark(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="bookmark-health"]', function(e) {
        e.preventDefault();
        checkHealth(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="move-copy"]', function(e) {
        e.preventDefault();
        moveCopy(Number($(this).data('id')));
    });
    $workspace.on('click', '[data-egbm-action="share-board"]', function(e) {
        e.preventDefault();
        openShare(Number($(this).data('board-id')));
    });
    $workspace.on('click', '[data-egbm-action="import"]', function(e) {
        e.preventDefault();
        openImport(Number($(this).data('board-id')));
    });
    $workspace.on('click', '[data-egbm-action="new-category"]', function(e) {
        e.preventDefault();
        openCategoryForm(null, 'new');
    });
    $workspace.on('click', '[data-egbm-action="rename-category"]', function(e) {
        e.preventDefault();
        const id = Number($(this).data('category-id'));
        const c = (state.boardData?.categories || []).find(function(x) {
            return Number(x.sno) === id;
        });
        if (c) openCategoryForm(c, 'rename');
    });
    $workspace.on('click', '[data-egbm-action="recolour-category"]', function(e) {
        e.preventDefault();
        const id = Number($(this).data('category-id'));
        const c = (state.boardData?.categories || []).find(function(x) {
            return Number(x.sno) === id;
        });
        if (c) openCategoryForm(c, 'recolour');
    });
    $workspace.on('click', '[data-egbm-action="delete-category"]', function(e) {
        e.preventDefault();
        const id = Number($(this).data('category-id'));
        confirmAction('Delete category', 'A category can only be deleted when it has no active bookmarks.',
            'Delete',
            function() {
                return ajax('DELETE', route(R.categoryDelete, id)).done(function() {
                    toastr.success('Category deleted.');
                    loadBoard(state.boardId);
                });
            });
    });
    $workspace.on('click', '[data-egbm-action="toggle-category"]', function(e) {
        e.preventDefault();
        const $section = $(this).closest('.egbm-category');
        const collapsed = $section.toggleClass('egbm-category-collapsed').hasClass(
            'egbm-category-collapsed');
        $(this).find('i').attr('class', 'mdi ' + (collapsed ? 'mdi-chevron-right' : 'mdi-chevron-down'));
        persistCategoryCollapsed(Number($section.data('category-id')), collapsed);
    });
    let draggedCategoryId = 0;

    function getCategoryVisualOrder() {
        const nodes = $('.egbm-category[data-category-id]').get();

        return nodes.map(function(node, index) {
            const rect = node.getBoundingClientRect();

            return {
                id: Number($(node).data('category-id') || 0),
                top: rect.top,
                left: rect.left,
                index: index
            };
        }).filter(function(item) {
            return item.id > 0;
        }).sort(function(a, b) {
            if (Math.abs(a.top - b.top) > 4) {
                return a.top - b.top;
            }

            if (Math.abs(a.left - b.left) > 4) {
                return a.left - b.left;
            }

            return a.index - b.index;
        }).map(function(item) {
            return item.id;
        });
    }

    function applyCategoryOrderToState(ids) {
        const categories = Array.isArray(state.boardData?.categories) ? state.boardData.categories : [];
        if (!categories.length || !ids.length) return;

        const byId = {};
        categories.forEach(function(category) {
            byId[String(category.sno)] = category;
        });

        const ordered = [];
        const used = {};

        ids.forEach(function(id) {
            const key = String(id);
            if (!used[key] && byId[key]) {
                used[key] = true;
                ordered.push(byId[key]);
            }
        });

        categories.forEach(function(category) {
            const key = String(category.sno);
            if (!used[key]) {
                used[key] = true;
                ordered.push(category);
            }
        });

        ordered.forEach(function(category, index) {
            category.sort_order = index + 1;
        });

        state.boardData.categories = ordered;
    }

    $workspace.on('dragstart', '.egbm-category[draggable="true"]', function(e) {
        draggedCategoryId = Number($(this).data('category-id') || 0);
        $(this).addClass('egbm-dragging');

        if (e.originalEvent?.dataTransfer) {
            e.originalEvent.dataTransfer.effectAllowed = 'move';
            e.originalEvent.dataTransfer.setData('text/plain', String(draggedCategoryId));
        }
    });

    $workspace.on('dragend', '.egbm-category', function() {
        $('.egbm-category').removeClass('egbm-dragging egbm-drag-over');
        draggedCategoryId = 0;
    });

    $workspace.on('dragover', '.egbm-category[draggable="true"]', function(e) {
        if (!draggedCategoryId) return;

        e.preventDefault();
        $(this).addClass('egbm-drag-over');

        if (e.originalEvent?.dataTransfer) {
            e.originalEvent.dataTransfer.dropEffect = 'move';
        }
    });

    $workspace.on('dragleave', '.egbm-category', function(e) {
        if (!e.currentTarget.contains(e.relatedTarget)) {
            $(this).removeClass('egbm-drag-over');
        }
    });

    $workspace.on('drop', '.egbm-category[draggable="true"]', function(e) {
        if (!draggedCategoryId) return;

        e.preventDefault();

        const $target = $(this);
        const targetId = Number($target.data('category-id') || 0);
        const $source = $('.egbm-category[data-category-id="' + draggedCategoryId + '"]');

        if (!$source.length || targetId === draggedCategoryId) {
            $('.egbm-category').removeClass('egbm-dragging egbm-drag-over');
            draggedCategoryId = 0;
            return;
        }

        /*
         * Category cards are displayed in a visual row-major grid, while the
         * current markup keeps three column containers. Never use the raw DOM
         * order here because that order is column-major. Build the order from
         * the visible card positions, then place the dragged card immediately
         * after the card it was dropped on.
         */
        const currentOrder = getCategoryVisualOrder();
        const sourceIndex = currentOrder.indexOf(draggedCategoryId);
        const targetIndex = currentOrder.indexOf(targetId);

        if (sourceIndex === -1 || targetIndex === -1) {
            $('.egbm-category').removeClass('egbm-dragging egbm-drag-over');
            draggedCategoryId = 0;
            return;
        }

        currentOrder.splice(sourceIndex, 1);

        const newTargetIndex = currentOrder.indexOf(targetId);
        currentOrder.splice(newTargetIndex + 1, 0, draggedCategoryId);

        applyCategoryOrderToState(currentOrder);

        $('.egbm-category').removeClass('egbm-dragging egbm-drag-over');
        draggedCategoryId = 0;

        /* Render immediately so the screen reflects the exact order being saved. */
        renderBoardWorkspace();
        persistCategoryOrder(currentOrder);
    });

    function persistCategoryOrder(ids) {
        const orderIds = Array.isArray(ids) && ids.length ? ids.map(Number) : getCategoryVisualOrder();

        if (!orderIds.length || !state.boardId || state.boardData?.board?.is_locked ||
            state.boardData?.board?.can_manage === false) {
            return;
        }

        const $canvas = $('.egbm-canvas');
        const $hint = $(
            '<div class="egbm-order-saving"><span class="spinner-border spinner-border-sm me-1"></span>Saving category order…</div>'
        );

        $canvas.prepend($hint);

        ajax('PUT', route(R.categoryReorder, state.boardId, 'categories/reorder'), {
                category_ids: orderIds
            })
            .done(function() {
                /*
                 * The page uses three independent category columns. The raw DOM
                 * order is therefore column-major, while the user sees the
                 * categories row-by-row. Keep the state in the same visual order
                 * that was just saved, then rebuild the columns immediately.
                 *
                 * This keeps the live UI and the server order consistent without
                 * requiring a full page refresh.
                 */
                applyCategoryOrderToState(orderIds);
                renderBoardWorkspace();

                toastr.success('Category order saved.');
            })
            .fail(function(err) {
                toastr.error(err.message || 'Unable to save category order.');

                /*
                 * On failure, reload from the server so the workspace returns
                 * to the last persisted order.
                 */
                loadBoard(state.boardId);
            })
            .always(function() {
                $hint.remove();
            });
    }

    $workspace.on('click', '[data-egbm-action="edit-board"]', function(e) {
        e.preventDefault();
        const b = state.boardData?.board || state.boardRows.find(function(x) {
            return Number(x.sno) === Number($(this).data('board-id'));
        }, this);
        if (b) openBoardModal(b);
    });
    $workspace.on('click', '[data-egbm-action="toggle-lock"]', function(e) {
        e.preventDefault();
        const b = state.boardData?.board || {};
        const data = {
            board_name: b.board_name,
            icon: b.icon || 'mdi-bookmark-outline',
            description: b.description || '',
            visibility: b.visibility || 'Private',
            is_locked: b.is_locked ? 0 : 1,
            is_archived: b.is_archived ? 1 : 0
        };
        ajax('PUT', route(R.boardUpdate, b.sno), data).done(function() {
            toastr.success(b.is_locked ? 'Board unlocked.' : 'Board locked.');
            loadBoards(false);
            loadBoard(b.sno);
        }).fail(function(err) {
            toastr.error(err.message);
        });
    });
    $workspace.on('click', '[data-egbm-action="archive-board"]', function(e) {
        e.preventDefault();
        const b = state.boardData?.board || {};
        confirmAction('Archive board',
            'The board and its links will leave the active BookMarks list. Records remain auditable.',
            'Archive',
            function() {
                return ajax('DELETE', route(R.boardDelete, b.sno)).done(function() {
                    toastr.success('Board archived.');
                    state.boardId = 0;
                    loadBoards(false);
                });
            });
    });
    $workspace.on('keydown', '[data-egbm-url-input]', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            quickAddUrl($(this).data('category-id'), $(this).val());
        }
    });
    $workspace.on('click', '[data-egbm-open-link]', function(e) {
        e.preventDefault();
        const id = Number($(this).data('id'));
        openBookmark(id);
    });
    $workspace.on('click', '#egbmBoardWorkspaceClear', function() {
        state.workspaceSearch = '';
        loadBoard(state.boardId);
    });
    $workspace.on('input', '#egbmBoardWorkspaceSearch', function() {
        state.workspaceSearch = String($(this).val() || '');
        clearTimeout(state.searchTimer);
        state.searchTimer = setTimeout(function() {
            loadBoard(state.boardId);
        }, 280);
    });

    $boardList.on('click', '.egbm-board-item', function() {
        const id = Number($(this).data('board-id'));
        if (!id) return;
        state.boardId = id;
        state.workspaceSearch = '';
        loadBoard(id);
    });
    $workspace.on('click', '#egbmBoardsToggle', function() {
        $('#egbmBoardRail').toggleClass('egbm-board-rail-open');
    });
    $root.on('click', '#egbmRailAdd,#egbmRailEmptyAdd,#egbmEmptyAdd,#egbmHeaderAddBoard', function() {
        populateBoardModalLookups(null);
        openBoardModal(null);
    });
    $root.on('click', '#egbmRetry', function() {
        loadBoards();
    });
    $('#egbmImportFile').on('change', function() {
        if (this.files?. [0]) importPreview(this.files[0]);
    });
    $('#egbmImportSubmit').on('click', submitImport);

    $('#egbmBoardVisibility').on('change', function() {
        const visibility = ['Private', 'Company', 'Group'].includes($(this).val()) ? $(this).val() : 'Private';
        setBoardVisibilityChoice(visibility);
        renderBoardVisibilityTargets(state.modalMode === 'edit' ? (state.boardData?.board || {}) : null);
    });

    $root.on('click', '#egbmBoardModal .egbm-visibility-choice', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const visibility = String($(this).attr('data-egbm-visibility') || 'Private');
        if (!['Private', 'Company', 'Group'].includes(visibility)) return;

        // Apply the choice directly. Do not depend on a hidden Select2/native
        // change event to switch the visibility panel.
        $('#egbmBoardVisibility').val(visibility);
        setBoardVisibilityChoice(visibility);
        renderBoardVisibilityTargets(state.modalMode === 'edit' ? (state.boardData?.board || {}) : null);
    });

    $('#egbmBoardForm').on('submit', function(e) {
        e.preventDefault();
        const visibility = $('#egbmBoardVisibility').val() || 'Private';
        const companyIds = $('#egbmVisibilityCompanies').val() || [];
        const userIds = $('#egbmVisibilityUsers').val() || [];

        if (visibility === 'Company' && !companyIds.length) {
            toastr.error('Select at least one company for Company visibility.');
            return;
        }

        if (visibility === 'Group' && !userIds.length) {
            toastr.error('Select at least one staff member for Group visibility.');
            return;
        }

        const data = {
            board_name: $('#egbmBoardForm [name="board_name"]').val(),
            description: $('#egbmBoardForm [name="description"]').val(),
            visibility: visibility,
            visibility_company_ids: companyIds,
            visibility_user_ids: userIds,
            is_locked: $('#egbmBoardForm [name="is_locked"]').is(':checked') ? 1 : 0
        };
        const isEdit = state.modalMode === 'edit';
        const current = state.boardData?.board || {};
        const endpoint = isEdit ? route(R.boardUpdate, current.sno) : R.boardStore;
        const method = isEdit ? 'PUT' : 'POST';
        const $btn = $('#egbmBoardSave').prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
        ajax(method, endpoint, data).done(function(res) {
            boardModal().hide();
            toastr.success(res.message || 'Board saved.');
            const id = Number(res.data?.sno || res.data?.board?.sno || 0);
            loadBoards(false).always(function() {
                if (id) {
                    state.boardId = id;
                    loadBoard(id);
                }
            });
        }).fail(function(err) {
            toastr.error(err.message);
        }).always(function() {
            $btn.prop('disabled', false).html(isEdit ?
                '<i class="mdi mdi-content-save-outline"></i> Save board' :
                '<i class="mdi mdi-plus"></i> Create board');
        });
    });

    $('#egbmShareTypeCards').on('click', '[data-share-type]', function() {
        setShareType(String($(this).data('share-type')));
    });

    $('#egbmShareSave').on('click', function() {
        const $btn = $(this).prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-1"></span>Sharing…');

        const shareMode = String($('#egbmShareType').val() || 'user');
        const targetIds = getShareTargetValues();

        if (!state.shareBoardId) {
            toastr.error('Select a board before sharing.');
            $btn.prop('disabled', false).html('<i class="mdi mdi-account-plus-outline"></i> Share board');
            return;
        }

        if (!targetIds.length) {
            toastr.error(shareMode === 'company' ? 'Select at least one company.' :
                shareMode === 'group' ? 'Select at least one staff member.' : 'Select a staff member.');
            $btn.prop('disabled', false).html('<i class="mdi mdi-account-plus-outline"></i> Share board');
            return;
        }

        if (shareMode === 'user' && targetIds.length > 1) {
            toastr.error('A person share accepts one staff member at a time.');
            $btn.prop('disabled', false).html('<i class="mdi mdi-account-plus-outline"></i> Share board');
            return;
        }

        const granteeType = shareMode === 'company' ? 'company' : 'user';
        const data = {
            resource_type: 'board',
            resource_id: state.shareBoardId,
            grantee_type: granteeType,
            grantee_id: granteeType === 'user' && shareMode === 'user' ? targetIds[0] : targetIds,
            permission: $('#egbmSharePermission').val(),
            expires_at: $('#egbmShareExpiry').val() || null
        };

        ajax('POST', R.shares.store, data).done(function(res) {
            toastr.success(res.message || 'Board shared successfully.');
            loadShares(state.shareBoardId);
            $('#egbmShareTarget').val(granteeType === 'user' && shareMode === 'user' ? '' : []).trigger('change');
        }).fail(function(err) {
            toastr.error(err.message || 'Unable to share the board.');
        }).always(function() {
            $btn.prop('disabled', false).html(
                '<i class="mdi mdi-account-plus-outline"></i> Share board');
        });
    });
    $('#egbmShareList').on('click', '[data-share-revoke]', function() {
        const id = Number($(this).data('share-revoke'));
        confirmAction('Revoke access', 'This recipient will lose access to the board.', 'Revoke',
            function() {
                return ajax('POST', route(R.shares.revoke, id, 'revoke')).done(function() {
                    toastr.success('Share revoked.');
                    loadShares(state.shareBoardId);
                });
            });
    });


    $('#egbmShareModal').on('hidden.bs.modal.egbmShare', function() {
        destroySelect3($('#egbmShareTarget'));
        $('#egbmShareTarget').prop('multiple', false).empty();
        $('#egbmShareEligiblePanel').addClass('d-none').empty();
    });

    // Optional company selector when the ERP exposes a page-level company filter.
    if (!$('#egbmGlobalCompanyFilter').length) {
        // The prototype places company scope in the global ERP header; BookMarks
        // does not duplicate it here when the shell already provides it.
    }

    function renderGlobalHeader() {
        const u = state.lookups.current_user || {};
        const role = u.is_super_admin ? 'Super Admin' : (u.role_name || 'Staff');
        const name = u.name || u.staff_name || 'ERP User';
        $('#egbmProtoRole').empty().append($('<option>', {
            value: role,
            text: role
        })).val(role);
        $('#egbmAvatarText').text(initials(name));
        $('#egbmUserName').text(name);
        $('#egbmUserRole').text(role);
        const companies = state.lookups.companies || [];
        const $company = $('#egbmGlobalCompanyFilter');
        $company.empty().append('<option value="all">All Companies</option>');
        companies.forEach(function(c) {
            $company.append($('<option>', {
                value: c.sno,
                text: c.company_name || 'Elysium Groups'
            }));
        });
        $company.val(state.companyFilter || 'all');
    }

    function searchGlobal(term) {
        term = String(term || '').trim();
        if (term.length < 2) {
            $('#egbmGlobalSearchResults').addClass('d-none').empty();
            return;
        }
        ajax('GET', R.globalSearch + '?' + query({
            q: term
        })).done(function(res) {
            const rows = Array.isArray(res.data) ? res.data : [];
            if (!rows.length) {
                $('#egbmGlobalSearchResults').removeClass('d-none').html(
                    '<div class="egbm-search-empty">No results found.</div>');
                return;
            }
            $('#egbmGlobalSearchResults').removeClass('d-none').html(rows.map(function(x) {
                return '<button type="button" class="egbm-search-result" data-search-module="' +
                    esc(x.module) + '" data-search-id="' + esc(x.id) +
                    '" data-search-board-id="' + esc(x.board_id || '') +
                    '"><span class="egbm-search-result-icon"><i class="mdi mdi-' + esc(x.icon ||
                        'magnify') + '"></i></span><span><strong>' + esc(x.title || '') +
                    '</strong><small>' + esc(x.subtitle || x.module || '') +
                    '</small></span></button>';
            }).join(''));
        }).fail(function() {
            $('#egbmGlobalSearchResults').addClass('d-none');
        });
    }

    function loadAppsMenu() {
        ajax('GET', R.menu).done(function(res) {
            const rows = Array.isArray(res.data) ? res.data : [];
            $('#egbmAppsMenu').removeClass('d-none').html(
                '<div class="egbm-popover-title">APPLICATIONS</div>' + rows.map(function(x) {
                    return '<a class="egbm-app-item" href="' + esc(x.route || '#') +
                        '"><i class="mdi mdi-' + esc(x.icon || 'apps') + '"></i><span>' + esc(x
                            .label || '') + '</span></a>';
                }).join(''));
        });
    }

    function loadNotifications() {
        ajax('GET', R.notifications).done(function(res) {
            const d = res.data || {};
            const rows = Array.isArray(d.rows) ? d.rows : [];
            const unread = Number(d.unread || 0);
            $('#egbmNotificationBadge').toggleClass('d-none', unread <= 0).text(unread > 99 ? '99+' :
                unread);
            $('#egbmNotificationMenu').removeClass('d-none').html(
                '<div class="egbm-popover-title"><span>NOTIFICATIONS</span><button type="button" class="btn btn-sm btn-link p-0" id="egbmMarkNotifications">Mark all read</button></div>' +
                (rows.length ? rows.map(function(x) {
                    return '<div class="egbm-notify-row ' + (!x.is_read ? 'unread' : '') +
                        '"><div class="egbm-notify-dot"></div><div><strong>' + esc(x.title || x
                            .message || 'Notification') + '</strong><small>' + esc(x.message ||
                            '') + '</small></div></div>';
                }).join('') : '<div class="egbm-search-empty">No notifications.</div>'));
        });
    }

    function companyFilterChange() {
        state.companyFilter = $('#egbmGlobalCompanyFilter').val() || 'all';
        state.boardId = 0;
        state.workspaceSearch = '';
        loadLookups().always(function() {
            loadBoards(true);
        });
    }
    $('#egbmGlobalSearch').on('input', function() {
        clearTimeout(state.globalSearchTimer);
        const value = $(this).val();
        state.globalSearchTimer = setTimeout(function() {
            searchGlobal(value);
        }, 220);
    });
    $(document).on('click', '#egbmGlobalSearchResults .egbm-search-result', function() {
        const module = $(this).data('search-module');
        const boardId = Number($(this).data('search-board-id') || 0);
        $('#egbmGlobalSearchResults').addClass('d-none');
        $('#egbmGlobalSearch').val('');
        if (module === 'BookMarks' && boardId) {
            state.workspaceSearch = '';
            loadBoard(boardId);
        }
    });
    $('#egbmAppsLauncher').on('click', function(e) {
        e.preventDefault();
        $('#egbmNotificationMenu').addClass('d-none');
        loadAppsMenu();
    });
    $('#egbmNotifications').on('click', function(e) {
        e.preventDefault();
        $('#egbmAppsMenu').addClass('d-none');
        loadNotifications();
    });
    $(document).on('click', '#egbmMarkNotifications', function() {
        ajax('POST', R.notificationsRead, {}).always(function() {
            loadNotifications();
        });
    });
    $('#egbmRefresh').on('click', function() {
        loadLookups().always(function() {
            loadBoards(true);
        });
    });
    let egbmShareExpiryPicker = null;

    function initializeShareExpiryPicker() {
        const element = document.getElementById('egbmShareExpiry');

        if (!element || typeof flatpickr === 'undefined') {
            return;
        }

        if (element._flatpickr) {
            element._flatpickr.destroy();
        }

        egbmShareExpiryPicker = flatpickr(element, {
            enableTime: true,
            dateFormat: 'Y-m-d H:i',
            time_24hr: true,
            minuteIncrement: 5,
            defaultDate: new Date(),
            minDate: new Date(),
            allowInput: false,
            disableMobile: true,
            clickOpens: true
        });
    }

    function resetShareExpiryPicker(defaultToNow) {
        const useCurrentDateTime = defaultToNow !== false;
        const element = document.getElementById('egbmShareExpiry');

        if (!element) {
            return;
        }

        if (!element._flatpickr) {
            initializeShareExpiryPicker();
        }

        if (!element._flatpickr) {
            return;
        }

        if (useCurrentDateTime) {
            element._flatpickr.set('minDate', new Date());
            element._flatpickr.setDate(new Date(), true);
        } else {
            element._flatpickr.clear();
        }
    }

    initializeShareExpiryPicker();
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#egbmAppsLauncher,#egbmAppsMenu').length) $('#egbmAppsMenu').addClass(
            'd-none');
        if (!$(e.target).closest('#egbmNotifications,#egbmNotificationMenu').length) $(
            '#egbmNotificationMenu').addClass('d-none');
        if (!$(e.target).closest('#egbmGlobalSearch,#egbmGlobalSearchResults').length) $(
            '#egbmGlobalSearchResults').addClass('d-none');
    });

    function boot() {
        // initSelect3(root);
        loadLookups().done(function() {
            renderGlobalHeader();
        }).always(function() {
            renderGlobalHeader();
            loadBoards(true);
        });
    }

    boot();</script>
@endsection