@extends('layouts/layoutMaster')

@section('title', 'Portals & Apps')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<style>
    #egPortalApps {
        --egpa-primary:var(--expense-primary,#b12a1f);
        --egpa-primary-hover:var(--expense-primary-hover,#8f1f16);
        --egpa-accent:var(--bs-warning,#d19b22);
        --egpa-ink:#192335;
        /* --egpa-navy:#263f67; */
        --egpa-navy:#181818;
        --egpa-muted:#778398;
        --egpa-line:#dfe5ee;
        --egpa-bg:#f6f7fa;
        --egpa-card:#fff
    }
    #egPortalApps .egpa-shell {
        min-height:calc(100vh - 90px);
        /* background:var(--egpa-bg); */
        padding:18px 24px 28px
    }
    #egPortalApps .egpa-head {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:18px;
        margin-bottom:16px
    }
    #egPortalApps .egpa-head-title {
        min-width:0
    }
    .egpa-title {
        margin:0;
        color:var(--egpa-primary);
        font-size:21px;
        font-weight:800;
        letter-spacing:-.25px
    }
    .egpa-sub {
        margin:4px 0 0;
        color:var(--egpa-muted);
        font-size:11px
    }
    #egPortalApps .egpa-toolbar {
        display:flex;
        align-items:center;
        justify-content:flex-end;
        gap:8px;
        flex-wrap:wrap
    }
    #egPortalApps .egpa-control {
        height:35px;
        border:1px solid var(--egpa-line);
        background:#fff;
        border-radius:8px;
        color:var(--egpa-ink);
        padding:0 10px;
        font-size:11px;
        min-width:120px
    }
    #egPortalApps .egpa-btn {
        height:35px;
        border-radius:8px;
        padding:0 12px;
        font-size:11px;
        font-weight:700;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:5px
    }
    #egPortalApps .egpa-btn-primary {
        background:var(--egpa-primary);
        border:1px solid var(--egpa-primary);
        color:#fff
    }
    .egpa-btn-primary:hover {
        background:var(--egpa-primary-hover);
        border-color:var(--egpa-primary-hover);
        color:#fff
    }
    #egPortalApps .egpa-btn-light {
        background:#fff;
        border:1px solid var(--egpa-line);
        color:var(--egpa-navy)
    }
    #egPortalApps .egpa-btn-dark {
        background:var(--egpa-navy);
        border:1px solid var(--egpa-navy);
        color:#fff
    }
    #egPortalApps .egpa-switch {
        display:flex;
        border:1px solid var(--egpa-line);
        background:#fff;
        border-radius:8px;
        overflow:hidden
    }
    .egpa-switch button {
        height:35px;
        width:38px;
        border:0;
        border-right:1px solid var(--egpa-line);
        background:#fff;
        color:#7d8799
    }
    .egpa-switch button:last-child {
        border-right:0
    }
    .egpa-switch button.active {
        background:var(--egpa-primary);
        color:#fff
    }
    #egPortalApps .egpa-most {
        margin-bottom:18px
    }
    .egpa-section-label {
        margin:0 0 7px;
        color:#7b8799;
        font-size:9px;
        font-weight:800;
        letter-spacing:.08em
    }
    .egpa-most-grid {
        display:grid;
        grid-template-columns:repeat(3,minmax(0,1fr));
        gap:12px
    }
    #egPortalApps .egpa-most-card {
        display:flex;
        align-items:center;
        gap:10px;
        min-height:72px;
        padding:12px 14px;
        background:var(--egpa-primary);
        border-radius:12px;
        color:#fff;
        box-shadow:0 8px 22px rgba(177,42,31,.10)
    }
    #egPortalApps .egpa-icon {
        display:flex;
        align-items:center;
        justify-content:center;
        overflow:hidden;
        flex:0 0 auto
    }
    .egpa-icon img {
        width:100%;
        height:100%;
        object-fit:contain
    }
    .egpa-most-icon {
        width:40px;
        height:40px;
        border-radius:11px;
        background:rgba(255,255,255,.12);
        color:var(--egpa-accent);
        font-size:20px
    }
    .egpa-card-icon {
        width:42px;
        height:42px;
        border-radius:11px;
        background:#f1f3f6;
        color:var(--egpa-navy);
        font-size:18px
    }
    .egpa-detail-icon {
        width:58px;
        height:58px;
        border-radius:15px;
        background:var(--egpa-primary);
        color:var(--egpa-accent);
        font-size:24px
    }
    #egPortalApps .egpa-most-copy {
        min-width:0;
        flex:1
    }
    .egpa-most-name {
        font-size:12px;
        font-weight:800;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis
    }
    .egpa-most-meta {
        font-size:9px;
        opacity:.76;
        margin-top:2px
    }
    .egpa-most-open button {
        height:29px;
        padding:0 10px;
        border-radius:7px
    }
    #egPortalApps .egpa-section {
        margin-top:2px
    }
    .egpa-section-head {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        margin-bottom:8px
    }
    .egpa-section-title {
        color:var(--egpa-primary);
        font-size:12px;
        font-weight:800
    }
    .egpa-section-meta {
        color:#8993a3;
        font-size:9px
    }
    #egPortalApps .egpa-grid {
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(270px,1fr));
        gap:14px
    }
    #egPortalApps .egpa-card {
        position:relative;
        display:flex;
        flex-direction:column;
        min-height:168px;
        padding:14px;
        background:#fff;
        border:1px solid var(--egpa-line);
        border-radius:12px;
        transition:.16s ease;
        cursor:pointer
    }
    .egpa-card:hover {
        transform:translateY(-2px);
        border-color:rgba(177,42,31,.3);
        box-shadow:0 10px 24px rgba(31,56,100,.08)
    }
    #egPortalApps .egpa-card-head {
        display:flex;
        gap:10px;
        align-items:flex-start
    }
    .egpa-card-main {
        min-width:0;
        flex:1
    }
    .egpa-card-name {
        color:var(--egpa-ink);
        font-size:12px;
        font-weight:800;
        line-height:1.35
    }
    .egpa-card-purpose {
        margin-top:4px;
        color:var(--egpa-muted);
        font-size:9px;
        line-height:1.45;
        min-height:28px
    }
    #egPortalApps .egpa-tags {
        display:flex;
        flex-wrap:wrap;
        gap:5px;
        margin-top:10px
    }
    .egpa-tag {
        display:inline-flex;
        align-items:center;
        gap:4px;
        padding:4px 7px;
        border-radius:999px;
        background:#f2f4f7;
        color:#69778c;
        font-size:8px;
        font-weight:700
    }
    .egpa-tag.company {
        background:#fbefec;
        color:var(--egpa-primary)
    }
    .egpa-tag.live {
        background:#ebf8f0;
        color:#27834b
    }
    .egpa-tag.maintenance {
        background:#fff7e4;
        color:#a76a00
    }
    .egpa-tag.deprecated {
        background:#fff0f0;
        color:#b52b25
    }
    #egPortalApps .egpa-card-footer {
        display:flex;
        align-items:center;
        justify-content:flex-end;
        gap:6px;
        margin-top:auto;
        padding-top:12px
    }
    .egpa-card-menu .btn {
        width:30px;
        height:30px;
        padding:0
    }
    .egpa-open-btn {
        height:30px!important;
        padding:0 9px!important
    }
    #egPortalApps .egpa-list {
        border:1px solid var(--egpa-line);
        border-radius:12px;
        overflow:hidden;
        background:#fff
    }
    .egpa-list-row {
        display:grid;
        grid-template-columns:minmax(210px,1.6fr) minmax(180px,1.3fr) 95px 105px 120px 90px;
        gap:10px;
        align-items:center;
        padding:10px 12px;
        border-bottom:1px solid #edf0f4;
        background:#fff;
        cursor:pointer
    }
    .egpa-list-row:last-child {
        border-bottom:0
    }
    .egpa-list-row:hover {
        background:#fbfcfe
    }
    .egpa-list-row.head {
        background:#f8f9fb;
        cursor:default
    }
    .egpa-list-label {
        color:#9aa4b4;
        font-size:8px;
        font-weight:800;
        letter-spacing:.05em;
        text-transform:uppercase
    }
    .egpa-list-app {
        display:flex;
        align-items:center;
        gap:8px;
        min-width:0
    }
    .egpa-list-value {
        color:var(--egpa-ink);
        font-size:9px;
        font-weight:700
    }
    .egpa-list-purpose {
        color:#7a8799;
        font-size:8px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
        margin-top:2px
    }
    #egPortalApps .egpa-empty {
        padding:55px 20px;
        text-align:center
    }
    .egpa-empty-icon {
        width:54px;
        height:54px;
        border-radius:14px;
        background:#f0f2f5;
        color:var(--egpa-primary);
        display:inline-flex;
        align-items:center;
        justify-content:center;
        font-size:24px;
        margin-bottom:10px
    }
    .egpa-empty-title {
        color:var(--egpa-primary);
        font-size:13px;
        font-weight:800
    }
    .egpa-empty-sub {
        margin-top:4px;
        color:var(--egpa-muted);
        font-size:10px
    }
    #egPortalApps .egpa-loading {
        padding:60px 20px;
        text-align:center;
        color:#7d8798;
        font-size:10px
    }
    .egpa-loading .spinner-border {
        width:1rem;
        height:1rem
    }
    .egpa-alert {
        margin-bottom:10px;
        font-size:10px;
        border-radius:8px
    }
    #egPortalApps .egpa-pagination {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
        padding:12px 0 0;
        color:#7d8799;
        font-size:9px
    }
    .egpa-pagination .btn {
        height:28px;
        width:28px;
        padding:0;
        border-radius:7px
    }
    #egPortalApps .egpa-detail {
        padding:4px 0 22px
    }
    .egpa-back {
        display:inline-flex;
        align-items:center;
        gap:5px;
        color:var(--egpa-primary);
        text-decoration:none;
        font-size:10px;
        font-weight:800;
        margin-bottom:10px
    }
    .egpa-detail-card {
        background:#fff;
        border:1px solid var(--egpa-line);
        border-radius:14px;
        overflow:hidden;
        box-shadow:0 8px 22px rgba(31,56,100,.05)
    }
    .egpa-detail-hero {
        padding:16px 18px;
        border-bottom:1px solid var(--egpa-line);
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:15px
    }
    .egpa-detail-left {
        display:flex;
        align-items:center;
        gap:13px;
        min-width:0
    }
    .egpa-detail-main {
        min-width:0
    }
    .egpa-detail-name {
        margin:0;
        color:var(--egpa-primary);
        font-size:18px;
        font-weight:800
    }
    .egpa-detail-purpose {
        margin-top:3px;
        color:var(--egpa-muted);
        font-size:10px
    }
    .egpa-detail-meta {
        display:flex;
        flex-wrap:wrap;
        gap:8px;
        margin-top:6px;
        color:#798699;
        font-size:8px
    }
    .egpa-detail-meta strong {
        color:var(--egpa-ink)
    }
    .egpa-detail-actions {
        display:flex;
        align-items:center;
        gap:6px;
        flex-wrap:wrap;
        justify-content:flex-end
    }
    .egpa-detail-body {
        padding:15px 18px
    }
    .egpa-panel {
        padding:12px;
        border:1px solid var(--egpa-line);
        border-radius:11px;
        background:#fff
    }
    .egpa-panel + .egpa-panel {
        margin-top:10px
    }
    .egpa-panel-title {
        font-size:11px;
        font-weight:800;
        color:var(--egpa-primary);
        margin-bottom:9px
    }
    .egpa-api-box {
        font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
        background:#f7f8fa;
        border:1px solid #e7ebf0;
        border-radius:8px;
        padding:10px;
        white-space:pre-wrap;
        word-break:break-word;
        color:#445269;
        font-size:9px;
        line-height:1.55
    }
    .egpa-media-grid {
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(100px,1fr));
        gap:9px
    }
    .egpa-media-thumb {
        position:relative;
        aspect-ratio:16/10;
        border-radius:9px;
        overflow:hidden;
        border:1px solid var(--egpa-line);
        background:#eef1f4
    }
    .egpa-media-thumb img {
        width:100%;
        height:100%;
        object-fit:cover
    }
    .egpa-history {
        padding-left:12px
    }
    .egpa-history-item {
        position:relative;
        border-left:2px solid #e0e5ec;
        padding:8px 0 12px 15px
    }
    .egpa-history-item:before {
        content:'';
        position:absolute;
        left:-7px;
        top:11px;
        width:11px;
        height:11px;
        border-radius:50%;
        background:var(--egpa-primary);
        box-shadow:0 0 0 4px #fff
    }
    .egpa-history-head {
        display:flex;
        align-items:center;
        gap:7px;
        flex-wrap:wrap
    }
    .egpa-version {
        font-size:12px;
        font-weight:800;
        color:var(--egpa-primary)
    }
    .egpa-current {
        padding:3px 6px;
        border-radius:999px;
        background:#edf9f1;
        color:#2d8d55;
        font-size:7px;
        font-weight:800
    }
    .egpa-history-date {
        color:#8b95a5;
        font-size:8px
    }
    .egpa-history-section {
        margin-top:6px;
        color:#7b8798;
        font-size:7px;
        font-weight:800;
        letter-spacing:.07em
    }
    .egpa-history-lines {
        margin:2px 0 0;
        padding-left:13px
    }
    .egpa-history-lines li {
        color:var(--egpa-ink);
        font-size:9px;
        line-height:1.5
    }
    #egPortalApps .modal-content {
        border:0;
        border-radius:14px;
        overflow:hidden;
        box-shadow:0 24px 70px rgba(18,38,63,.18)
    }
    #egPortalApps .modal-header {
        padding:13px 16px;
        border-bottom:1px solid var(--egpa-line)
    }
    #egPortalApps .modal-title {
        /* font-weight:800; */
        color:var(--egpa-primary)
    }
    #egPortalApps .modal-body {
        padding:16px;
        background:#f9fafb
    }
    #egPortalApps .modal-footer {
        padding:11px 16px;
        border-top:1px solid var(--egpa-line)
    }
    #egPortalApps .form-label {
        /* font-size:9px; */
        /* color:#69778a; */
        font-weight:700;
        margin-bottom:4px
    }
    #egPortalApps .form-control,#egPortalApps .form-select {
        min-height:36px;
        border-color:var(--egpa-line);
        border-radius:8px;
        /* font-size:10px */
    }
    #egPortalApps textarea.form-control {
        min-height:78px
    }
    #egPortalApps .form-control:focus,#egPortalApps .form-select:focus {
        border-color:var(--egpa-primary);
        box-shadow:0 0 0 .16rem rgba(177,42,31,.08)
    }
    #egPortalApps .egpa-form-card {
        background:#fff;
        border:1px solid var(--egpa-line);
        border-radius:10px;
        padding:12px
    }
    .egpa-form-card + .egpa-form-card {
        margin-top:9px
    }
    .egpa-form-title {
        /* font-size:10px; */
        font-weight:800;
        color:var(--egpa-primary);
        margin-bottom:8px
    }
    .egpa-optional {
        color:#9aa3b1;
        font-size:10px;
        font-weight:500
    }
    .egpa-preview-wrap {
        display:flex;
        gap:10px;
        align-items:center;
        flex-wrap:wrap
    }
    .egpa-preview-icon {
        width:52px;
        height:52px;
        border-radius:12px;
        background:#eef1f4;
        border:1px solid var(--egpa-line);
        display:flex;
        align-items:center;
        justify-content:center;
        overflow:hidden;
        color:#97a1af;
        font-size:20px
    }
    .egpa-preview-icon img {
        width:100%;
        height:100%;
        object-fit:contain
    }
    .egpa-preview-caption {
        color:#7c8798;
        font-size:8px
    }
    .egpa-screenshot-previews {
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(82px,1fr));
        gap:7px;
        margin-top:8px
    }
    .egpa-shot {
        position:relative;
        aspect-ratio:16/10;
        border-radius:8px;
        overflow:hidden;
        border:1px solid var(--egpa-line);
        background:#eef1f4
    }
    .egpa-shot img {
        width:100%;
        height:100%;
        object-fit:cover
    }
    .egpa-shot span {
        position:absolute;
        left:4px;
        right:4px;
        bottom:4px;
        padding:3px 4px;
        border-radius:5px;
        background:rgba(0,0,0,.52);
        color:#fff;
        font-size:7px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis
    }
    .egpa-package {
        display:flex;
        align-items:center;
        gap:9px;
        padding:9px 10px;
        border:1px dashed #cfd7e2;
        border-radius:8px;
        background:#fbfcfd
    }
    .egpa-package i {
        font-size:20px;
        color:var(--egpa-primary)
    }
    .egpa-package-copy {
        min-width:0
    }
    .egpa-package-name {
        font-size:9px;
        font-weight:800;
        color:var(--egpa-ink);
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis
    }
    .egpa-package-size {
        font-size:7px;
        color:#8b95a4
    }
    .egpa-progress {
        display:none;
        margin-top:10px;
        padding:10px;
        border-radius:9px;
        background:#f1f4f7
    }
    .egpa-progress.active {
        display:block
    }
    .egpa-progress-top {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:8px;
        font-size:8px;
        color:#667489
    }
    .egpa-progress-title {
        font-weight:800;
        color:var(--egpa-primary)
    }
    .egpa-progress-track {
        height:8px;
        background:#dfe5eb;
        border-radius:999px;
        overflow:hidden;
        margin-top:7px
    }
    .egpa-progress-bar {
        height:100%;
        width:0;
        background:linear-gradient(90deg,var(--egpa-primary),var(--egpa-accent));
        transition:width .16s ease;
        position:relative
    }
    .egpa-progress-bar:after {
        content:'';
        position:absolute;
        inset:0;
        background:linear-gradient(90deg,transparent,rgba(255,255,255,.38),transparent);
        animation:egpaShimmer 1.35s linear infinite
    }
    @keyframes egpaShimmer {
        from {
            transform:translateX(-100%)
        }
        to {
            transform:translateX(100%)
        }
    }
    .egpa-progress-status {
        margin-top:5px;
        color:#8590a0;
        font-size:8px
    }
    .egpa-saving {
        color:#2b8b53;
        font-weight:700
    }
    .egpa-warning {
        margin-top:7px;
        padding:7px 8px;
        border-radius:7px;
        background:#fff8e8;
        color:#916000;
        font-size:8px
    }
    @media(max-width:1100px) {
        #egPortalApps .egpa-list-row {
            grid-template-columns:minmax(210px,1.6fr) minmax(150px,1.3fr) 80px 90px 110px 80px
        }
    }
    @media(max-width:900px) {
        #egPortalApps .egpa-head {
            align-items:flex-start;
            flex-direction:column
        }
        .egpa-toolbar {
            width:100%;
            justify-content:flex-start
        }
        .egpa-most-grid {
            grid-template-columns:1fr
        }
        .egpa-detail-hero {
            align-items:flex-start;
            flex-direction:column
        }
        .egpa-detail-actions {
            justify-content:flex-start
        }
    }
    @media(max-width:720px) {
        #egPortalApps .egpa-shell {
            padding:15px 12px 22px
        }
        .egpa-grid {
            grid-template-columns:1fr
        }
        .egpa-list {
            overflow-x:auto
        }
        .egpa-list-row {
            min-width:780px
        }
        .egpa-title {
            font-size:18px
        }
    }
</style>

<div id="egPortalApps" class="egpa-page">

    <div class="card card-action egpa-shell">
        <div class="egpa-head card-header border-bottom pb-1 d-flex justify-content-between align-items-center ">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">InHouse Portals &amp; Apps</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Portals &amp; Apps
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>

            <div class="egbm-header-actions d-flex justify-content-end align-items-center gap-2 flex-wrap">
                

                 <div class="egpa-toolbar" id="egpaToolbar">
                    <div class="min-w-150px">
                        <select id="egpaStatus" class="egpa-control select3" aria-label="Status" onchange="status_filter_change_func()">
                            <option value="">Status · All</option>
                            <option value="Live">Live</option>
                            <option value="Under Maintenance">Under Maintenance</option>
                            <option value="Deprecated">Deprecated</option>
                        </select>
                    </div>
                    <div class="min-w-150px">
                        <select id="egpaPlatform" class="egpa-control select3" aria-label="Type" onchange="platform_filter_change_func()">
                            <option value="">All types</option>
                            <option value="Web Portal">Portal</option>
                            <option value="Mobile App">Mobile App</option>
                            <option value="Desktop">Desktop App</option>
                        </select>
                    </div>
                    <div class="egpa-switch" role="group" aria-label="View">
                        <button type="button" class="active" data-egpa-view="grid">
                            <i class="mdi mdi-view-grid-outline"></i>
                        </button>
                        <button type="button" data-egpa-view="list">
                            <i class="mdi mdi-view-list-outline"></i>
                        </button>
                    </div>
                    <div class="dropdown">
                        <button type="button" class="btn egpa-btn egpa-btn-light shadow-none" data-bs-toggle="dropdown" title="More actions">
                            <i class="mdi mdi-dots-vertical"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <button type="button" class="dropdown-item" data-egpa-action="export">
                                    <i class="mdi mdi-file-excel-outline me-2"></i>Export XLSX
                                </button>
                            </li>
                        </ul>
                    </div>
                    <button type="button" class="btn egpa-btn egpa-btn-primary" id="egpaAdd">
                        <i class="mdi mdi-plus"></i>Add Portal / App
                    </button>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <div id="egpaAlert" class="alert egpa-alert d-none"></div>
            <div id="egpaWorkspace"></div>
        </div>
    </div>

    <div class="modal fade" id="egpaFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered ">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="egpaFormTitle">Register a Portal / App</h5>
                        <!-- <div class="text-muted" style="font-size:8px" id="egpaFormSub">All supporting fields are optional.</div> -->
                    </div><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="egpaForm" enctype="multipart/form-data">
                    <div class="modal-body" id="egpaFormBody">

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn egpa-btn egpa-btn-light" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn egpa-btn egpa-btn-primary" id="egpaSave">
                            <span class="save-label">Save</span>
                            <span class="save-loading d-none">
                                <span class="spinner-border spinner-border-sm me-1"></span>Processing…
                            </span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpaShareModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title">Share Portal / App</h5>
                        <div class="text-muted" style="font-size:8px">Give a user, role, company or the group controlled access.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="egpaShareId">
                    <div class="egpa-form-card">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Share with</label>
                                <select id="egpaShareType" class="form-select">
                                    <option value="user">User</option>
                                    <option value="role">Role</option>
                                    <option value="company">Company</option>
                                    <option value="group">Group</option>
                                </select>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label">Recipient</label>
                                <select id="egpaShareRecipient" class="form-select">

                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Permission</label>
                                <select id="egpaSharePermission" class="form-select">
                                    <option value="View">View</option>
                                    <option value="Manage">Manage</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Expiry 
                                    <span class="egpa-optional">optional</span>
                                </label>
                                <input type="datetime-local" id="egpaShareExpiry" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="egpa-form-card">
                        <div class="egpa-form-title">Existing access</div>
                        <div id="egpaShareList"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn egpa-btn egpa-btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn egpa-btn egpa-btn-primary" id="egpaShareSave">Share</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const root=document.getElementById('egPortalApps');
    const $root=$(root);
    const config=@js([
        'module'=>'portals',
        'routes'=>[
            'data'=>route('productivity.portals.data'),
            'store'=>route('productivity.portals.store'),
            'show'=>url('/productivity/portals'),
            'update'=>url('/productivity/portals'),
            'version'=>url('/productivity/portals'),
            'launch'=>url('/productivity/portals'),
            'subscribe'=>url('/productivity/portals'),
            'download'=>url('/productivity/portals'),
            'currentVersion'=>url('/productivity/portals'),
            'media'=>url('/productivity/portals'),
            'exportXlsx'=>route('productivity.portals.export.xlsx'),
            'companies'=>route('productivity.companies'),
            'users'=>route('productivity.users'),
            'favicon'=>route('productivity.bookmarks.favicon'),
            'passwallet'=>url('/productivity/passwallet'),
            'shares'=>[
                'data'=>route('productivity.shares.data'), 
                'store'=>route('productivity.shares.store'), 
                'revoke'=>url('/productivity/shares')
            ]
        ]
    ]);

    const R=config.routes|| {
    };

    const state= {
        page:1, 
        perPage:24, 
        search:'', 
        status:'', 
        platform:'', 
        view:'grid', 
        mode:'list', 
        app:null, 
        requestSeq:0, 
        ownerRequest:null, 
        faviconCache: {}
    };

    const $workspace=$('#egpaWorkspace'), 
    $alert=$('#egpaAlert'), 
    formModal=()=>bootstrap.Modal.getOrCreateInstance(document.getElementById('egpaFormModal')), 
    shareModal=()=>bootstrap.Modal.getOrCreateInstance(document.getElementById('egpaShareModal'));

    function esc(v) {
        return String(v??'').replace(/[&<>'"]/g, 
            ch=>( {
                '&':'&amp;', 
                '<':'&lt;', 
                '>':'&gt;', 
                "'":'&#039;', 
                '"':'&quot;'
            }
        [ch]));
    }

    function query(obj) {
        return Object.keys(obj || {})
            .filter(function(key) {
                return obj[key] !== '' && obj[key] !== null && obj[key] !== undefined;
            })
            .map(function(key) {
                return `${encodeURIComponent(key)}=${encodeURIComponent(obj[key])}`;
            })
            .join('&');
    }

    function route(base, id, suffix) {
        const path = String(base).replace(/\/$/, '');
        const encodedId = encodeURIComponent(id);
        return suffix
            ? `${path}/${encodedId}/${suffix}`
            : `${path}/${encodedId}`;
    }

    function notify(message, type) {
        $alert.removeClass('d-none alert-success alert-danger alert-warning')
        .addClass(`alert-${type === 'error' ? 'danger' : (type || 'success')}`)
        .text(message||'Done.'); clearTimeout(window.__egpaTimer); 

        window.__egpaTimer=setTimeout(()=>$alert.addClass('d-none'), 4200);
    }
    function failMessage(xhr) {
        const p=xhr?.responseJSON|| {}; 
        return p.message||(p.errors?Object.values(p.errors).flat()[0]:null)||'The server could not complete this request.';
    }

    function ajax(method, endpoint, data, opts) {
        const o=opts|| {}, 
        settings= {
            url:endpoint, 
            method, 
            data, 
            dataType:o.dataType||'json', 
            timeout:o.timeout||30000, 
            headers: {
                'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')||'', 
                'X-Requested-With':'XMLHttpRequest', 
                'Accept':'application/json'
            }
        }; 

        if(o.processData!==undefined)settings.processData=o.processData; 
        if(o.contentType!==undefined)settings.contentType=o.contentType; 

        return $.ajax(settings).then(r=>r, e=>$.Deferred().reject( {
            status:e.status, 
            message:failMessage(e)
        }).promise());

    }

    function skeleton() {
        if(state.mode==='detail')return; 
        $workspace.html(
            `<div class="egpa-loading">
                <span class="spinner-border spinner-border-sm me-2"></span>
                Loading Portals &amp; Apps…
            </div>`
        );
    }

    function errorScreen(message) {
        $workspace.html(
            `<div class="egpa-empty">
                <div class="egpa-empty-icon">
                    <i class="mdi mdi-cloud-alert-outline"></i>
                </div>
                <div class="egpa-empty-title">Portals &amp; Apps could not be loaded</div>
                <div class="egpa-empty-sub">${esc(message||'Please try again.')}</div>
                <div class="mt-3">
                    <button type="button" class="btn egpa-btn egpa-btn-primary" data-egpa-action="retry">
                        <i class="mdi mdi-refresh"></i>Retry
                    </button>
                </div>
            </div>`
        );
    }

    function bytes(n) {
        n = Number(n || 0);

        if (n >= 1073741824) return `${(n / 1073741824).toFixed(2)} GB`;
        if (n >= 1048576) return `${(n / 1048576).toFixed(2)} MB`;
        if (n >= 1024) return `${(n / 1024).toFixed(1)} KB`;

        return `${n} B`;
    }

    function statusClass(status) {
        return status==='Live'?'live':status==='Under Maintenance'?'maintenance':'deprecated';
    }

    function iconMarkup(app, cls) {
        const c = cls || 'egpa-card-icon';
        const src = String(app?.icon_url || '');

        if (src) {
            return `
                <span class="egpa-icon ${c}">
                    <img
                        loading="lazy"
                        decoding="async"
                        referrerpolicy="no-referrer"
                        src="${esc(src)}"
                        alt=""
                    >
                </span>
            `;
        }

        return `
            <span
                class="egpa-icon ${c}"
                data-egpa-favicon-for="${esc(app?.app_url || '')}"
            >
                <i class="mdi mdi-application-outline"></i>
            </span>
        `;
    }

    function renderMostUsed(rows) {
        if(!rows.length)return ''; 

        return (
            `
            <div class="egpa-most">
                <div class="egpa-section-label">MOST USED</div>
                <div class="egpa-most-grid">
                    ${
                        rows.slice(0, 3).map(a=>
                            `<div class="egpa-most-card" data-egpa-card="${esc(a.sno)}">
                                ${iconMarkup(a, 'egpa-most-icon')}
                                <div class="egpa-most-copy">
                                    <div class="egpa-most-name">
                                        ${esc(a.app_name)}
                                    </div>
                                    <div class="egpa-most-meta">
                                        ${esc(a.opens_this_month||0)} opens this month
                                    </div>
                                </div>
                                <div class="egpa-most-open">
                                    <button type="button" class="btn egpa-btn egpa-btn-light" data-egpa-action="launch" data-id="${esc(a.sno)}">
                                        Open
                                    </button>
                                </div>
                            </div>`
                        )
                        .join('')
                    }
                </div>
            </div>
            `
        );
        
    }

    function manageMenu(app) {
        if(!Number(app.can_manage))return ''; 

        return (
            `<div class="dropdown egpa-card-menu">
                <button type="button" class="btn egpa-btn egpa-btn-light border-none shadow-none" data-bs-toggle="dropdown" title="Manage" data-egpa-stop>
                    <i class="mdi mdi-dots-vertical"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <button type="button" class="dropdown-item" data-egpa-action="edit" data-id="${esc(app.sno)}">
                            <i class="mdi mdi-pencil-outline me-2"></i>Edit
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item" data-egpa-action="version" data-id="${esc(app.sno)}">
                            <i class="mdi mdi-source-branch-plus me-2"></i>Record update
                        </button>
                    </li>
                    <li>
                        <button type="button" class="dropdown-item" data-egpa-action="share" data-id="${esc(app.sno)}">
                            <i class="mdi mdi-share-variant-outline me-2"></i>Share
                        </button>
                    </li>
                </ul>
            </div>`
        );
    }

    function renderGrid(rows) {

        if(!rows.length){
            return (`
                <div class="egpa-empty">
                    <div class="egpa-empty-icon">
                        <i class="mdi mdi-application-off-outline"></i>
                    </div>
                    <div class="egpa-empty-title">No portals or apps found</div>
                    <div class="egpa-empty-sub">Register your first internal tool or change the filters.</div>
                    <div class="mt-3">
                        <button type="button" class="btn egpa-btn egpa-btn-primary" data-egpa-action="new">
                            <i class="mdi mdi-plus"></i>Add Portal / App
                        </button>
                    </div>
                </div>`
            );
        }else{
            return(`
                <div class="egpa-section">
                    <div class="egpa-section-head">
                        <div class="egpa-section-title">ALL PORTALS &amp; APPS</div>
                        <div class="egpa-section-meta">
                            ${esc(rows.length)} shown
                        </div>
                    </div>
                    <div class="egpa-grid">
                    ${rows.map(a=> {
                        const sc=statusClass(a.status); 
                        return (`
                            <div class="egpa-card" data-egpa-card="${esc(a.sno)}">
                                <div class="egpa-card-head">
                                    ${iconMarkup(a)}
                                    <div class="egpa-card-main">
                                        <div class="egpa-card-name">
                                            ${esc(a.app_name)}
                                        </div>
                                        <div class="egpa-card-purpose">
                                            ${esc(a.purpose||'Internal portal / application')}
                                        </div>
                                    </div>
                                </div>
                                <div class="egpa-tags">
                                    <span class="egpa-tag company">
                                        ${esc(a.company_name||'Group')}
                                    </span>
                                    <span class="egpa-tag">
                                        ${esc(a.platform||'Web Portal')}
                                    </span>
                                    <span class="egpa-tag">
                                        v${esc(a.current_version||'—')}
                                    </span>
                                    <span class="egpa-tag ${sc}">
                                        ${esc(a.status||'Live')}
                                    </span>
                                </div>
                                <div class="egpa-card-footer">
                                    ${manageMenu(a)}
                                    <button type="button" class="btn egpa-btn egpa-btn-light egpa-open-btn shadow-none bg-warning" data-egpa-action="launch" data-id="${esc(a.sno)}">
                                        <i class="mdi mdi-open-in-new"></i>Open
                                    </button>
                                </div>
                            </div>`
                        );
                        
                    }).join('')}</div>
                </div>`
            );
        }   
    }

    function renderList(rows) {
        if (!rows.length) {
            return renderGrid(rows);
        }

        const groups = {};

        rows.forEach(function(app) {
            const company = app.company_name || 'Group';
            (groups[company] ||= []).push(app);
        });

        const body = Object.keys(groups)
            .sort()
            .map(function(company) {
                return groups[company].map(function(app) {
                    const sc = statusClass(app.status);

                    return `
                        <div class="egpa-list-row" data-egpa-card="${esc(app.sno)}">
                            <div class="egpa-list-app">
                                ${iconMarkup(app, 'egpa-card-icon')}
                                <div style="min-width:0">
                                    <div class="egpa-list-value">${esc(app.app_name)}</div>
                                    <div class="egpa-list-purpose">
                                        ${esc(app.app_url || 'Package available')}
                                    </div>
                                </div>
                            </div>

                            <div class="egpa-list-value" style="font-weight:500;color:#748196">
                                ${esc(app.purpose || '—')}
                            </div>

                            <div class="egpa-list-value">v${esc(app.current_version || '—')}</div>

                            <div class="egpa-list-value" style="font-weight:500;color:#748196">
                                ${esc(app.environment || 'Production')}
                            </div>

                            <div>
                                <span class="egpa-tag ${sc}">${esc(app.status || 'Live')}</span>
                            </div>

                            <div class="d-flex justify-content-end gap-1">
                                ${manageMenu(app)}
                                <button
                                    type="button"
                                    class="btn egpa-btn egpa-btn-light egpa-open-btn"
                                    data-egpa-action="launch"
                                    data-id="${esc(app.sno)}"
                                >
                                    <i class="mdi mdi-open-in-new"></i>
                                </button>
                            </div>
                        </div>
                    `;
                }).join('');
            })
            .join('');

        return `
            <div class="egpa-section">
                <div class="egpa-section-head">
                    <div class="egpa-section-title">ALL PORTALS &amp; APPS</div>
                    <div class="egpa-section-meta">Company grouped list</div>
                </div>

                <div class="egpa-list">
                    <div class="egpa-list-row head">
                        <div class="egpa-list-label">Portal / App</div>
                        <div class="egpa-list-label">Purpose</div>
                        <div class="egpa-list-label">Version</div>
                        <div class="egpa-list-label">Environment</div>
                        <div class="egpa-list-label">Status</div>
                        <div></div>
                    </div>

                    ${body}
                </div>
            </div>
        `;
    }
    function pagination(meta) {
        const currentPage = Number(meta?.current_page || 1);
        const lastPage = Number(meta?.last_page || 1);
        const total = Number(meta?.total || 0);

        if (lastPage <= 1) {
            return '';
        }

        const previousPage = Math.max(1, currentPage - 1);
        const nextPage = Math.min(lastPage, currentPage + 1);
        const previousDisabled = currentPage <= 1 ? 'disabled' : '';
        const nextDisabled = currentPage >= lastPage ? 'disabled' : '';

        return `
            <div class="egpa-pagination">
                <div>${esc(total)} portal/app record(s)</div>
                <div class="d-flex gap-1">
                    <button
                        type="button"
                        class="btn egpa-btn egpa-btn-light"
                        data-egpa-page="${previousPage}"
                        ${previousDisabled}
                    >
                        <i class="mdi mdi-chevron-left"></i>
                    </button>

                    <button
                        type="button"
                        class="btn egpa-btn egpa-btn-light"
                        data-egpa-page="${nextPage}"
                        ${nextDisabled}
                    >
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>
            </div>
        `;
    }
    function loadData() {
        if (state.mode !== 'detail') {
            skeleton();
        }

        const seq = ++state.requestSeq;

        ajax('GET', `${R.data}?${query({
            page: state.page,
            per_page: state.perPage,
            search: state.search,
            status: state.status,
            platform: state.platform
        })}`).done(function(res) {
            if (seq !== state.requestSeq) {
                return;
            }

            const data = res?.data || {};
            const page = data.rows || {};
            const rows = Array.isArray(page.data) ? page.data : [];
            const mostUsed = Array.isArray(data.most_used) ? data.most_used : [];
            const surface = state.view === 'list' ? renderList(rows) : renderGrid(rows);

            $workspace.html(`
                ${renderMostUsed(mostUsed)}
                <div id="egpaListSurface">
                    ${surface}
                    ${pagination(page)}
                </div>
            `);

            resolveFavicons();
        }).fail(function(err) {
            if (seq !== state.requestSeq) {
                return;
            }

            errorScreen(err.message);
        });
    }
    function resolveFavicons() {
        const $nodes=$('[data-egpa-favicon-for]').filter(function() {
            return !$(this).data('resolved') && $(this).attr('data-egpa-favicon-for');
        }); const todo=[]; $nodes.each(function() {
            const u=$(this).attr('data-egpa-favicon-for'); if(u&&!todo.includes(u))todo.push(u);
        }); todo.forEach(u=> {
            if(state.faviconCache[u]!==undefined) {
                applyFavicon(u, state.faviconCache[u]); return;
            }
            ajax('GET', `${R.favicon}?url=${encodeURIComponent(u)}`, null, {
                timeout:12000
            }).done(r=> {
                state.faviconCache[u]=String(r?.data?.favicon_url||''); applyFavicon(u, state.faviconCache[u]);
            }).fail(()=> {
                state.faviconCache[u]='';
            });
        });
    }
    function applyFavicon(url, src) {
        $('[data-egpa-favicon-for]')
            .filter(function() {
                return $(this).attr('data-egpa-favicon-for') === url;
            })
            .each(function() {
                $(this).data('resolved', true);

                if (src) {
                    $(this).html(`
                        <img
                            loading="lazy"
                            decoding="async"
                            src="${esc(src)}"
                            alt=""
                        >
                    `);
                }
            });
    }
    function field(name, label, value, type, opt) {
        const options = opt || {};
        const col = options.col || 6;
        const required = options.required ? ' required' : '';
        const optionalText = options.required
            ? '<span class="text-danger">*</span>'
            : '<span class="egpa-optional">optional</span>';

        if (type === 'textarea') {
            return `
                <div class="col-md-${col}">
                    <label class="form-label">
                        ${esc(label)} ${optionalText}
                    </label>
                    <textarea
                        class="form-control"
                        name="${esc(name)}"
                        rows="${options.rows || 3}"
                        placeholder="${esc(options.placeholder || '')}"${required}
                    >${esc(value || '')}</textarea>
                </div>
            `;
        }

        if (type === 'select') {
            const optionHtml = (options.options || [])
                .map(function(item) {
                    const selected = String(item.value) === String(value ?? '')
                        ? 'selected'
                        : '';

                    return `
                        <option value="${esc(item.value)}" ${selected}>
                            ${esc(item.label)}
                        </option>
                    `;
                })
                .join('');

            return `
                <div class="col-md-${col}">
                    <label class="form-label">
                        ${esc(label)} ${optionalText}
                    </label>
                    <select
                        class="form-select select3"
                        name="${esc(name)}"
                        id="${esc(options.id || name)}"${required}
                    >
                        <option value="">${esc(options.blank || 'Select')}</option>
                        ${optionHtml}
                    </select>
                </div>
            `;
        }

        return `
            <div class="col-md-${col}">
                <label class="form-label">
                    ${esc(label)} ${optionalText}
                </label>
                <input
                    class="form-control"
                    type="${esc(type || 'text')}"
                    name="${esc(name)}"
                    value="${esc(value ?? '')}"
                    placeholder="${esc(options.placeholder || '')}"${required}
                >
            </div>
        `;
    }
    function formHtml(app, mode) {
        const a = app || {};
        const editing = mode === 'edit';

        const release = editing
            ? `
                <div class="egpa-form-card">
                    <div class="egpa-form-title">Current release</div>
                    <div class="text-muted" style="font-size:9px">
                        Current version: <strong>${esc(a.current_version || 'Not released')}</strong>.
                        Use <strong>Record update</strong> from the application detail to upload a new package or publish a new version.
                    </div>
                    <div class="egpa-progress" id="egpaUploadProgress">
                        <div class="egpa-progress-top">
                            <span class="egpa-progress-title" id="egpaProgressTitle">Preparing upload…</span>
                            <strong id="egpaProgressPercent">0%</strong>
                        </div>
                        <div class="egpa-progress-track">
                            <div class="egpa-progress-bar" id="egpaProgressBar"></div>
                        </div>
                        <div class="egpa-progress-status" id="egpaProgressStatus">
                            Your browser is preparing the selected files.
                        </div>
                    </div>
                </div>
            `
            : `
                <div class="egpa-form-card">
                    <div class="egpa-form-title">
                        Application package &amp; current release
                        <span class="egpa-optional">optional</span>
                    </div>

                    <div class="row g-3">
                        ${field('version_no', 'Version', '', 'text', {
                            col: 4,
                            placeholder: '1.0.0'
                        })}
                        ${field('build_number', 'Build number', '', 'number', {
                            col: 4,
                            placeholder: '100'
                        })}
                        ${field('change_type', 'Release type', 'Release', 'select', {
                            col: 4,
                            options: [
                                { value: 'Release', label: 'Release' },
                                { value: 'New Features', label: 'New Features' },
                                { value: 'Improvement', label: 'Improvement' },
                                { value: 'Bug Fix', label: 'Bug Fix' },
                                { value: 'Security', label: 'Security' },
                                { value: 'Maintenance', label: 'Maintenance' }
                            ]
                        })}

                        <div class="col-12">
                            <label class="form-label">
                                Package file <span class="egpa-optional">APK / AAB / ZIP · up to 1 GB</span>
                            </label>
                            <input
                                type="file"
                                id="egpaPackageFile"
                                name="package_file"
                                class="form-control"
                                accept=".apk,.aab,.zip"
                            >
                            <div id="egpaPackagePreview" class="mt-2"></div>
                            <div class="egpa-warning">
                                Signed APK/AAB files are stored as uploaded. ZIP source bundles may be re-packed on the server when safe, without changing APK/AAB bytes.
                            </div>
                        </div>

                        ${field('update_details', 'What’s new / changes', '', 'textarea', {
                            col: 6,
                            rows: 3,
                            placeholder: 'One item per line'
                        })}
                        ${field('bug_fix_details', 'Bug fixes', '', 'textarea', {
                            col: 6,
                            rows: 3,
                            placeholder: 'One item per line'
                        })}
                        ${field('release_notes', 'Release notes', '', 'textarea', {
                            col: 12,
                            rows: 3,
                            placeholder: 'Optional detailed release notes'
                        })}
                    </div>

                    <div class="egpa-progress" id="egpaUploadProgress">
                        <div class="egpa-progress-top">
                            <span class="egpa-progress-title" id="egpaProgressTitle">Preparing upload…</span>
                            <strong id="egpaProgressPercent">0%</strong>
                        </div>
                        <div class="egpa-progress-track">
                            <div class="egpa-progress-bar" id="egpaProgressBar"></div>
                        </div>
                        <div class="egpa-progress-status" id="egpaProgressStatus">
                            Your browser is preparing the selected files.
                        </div>
                    </div>
                </div>
            `;

        return `
            <div class="egpa-form-card">
                <div class="egpa-form-title">Basic details</div>
                <div class="row g-3">
                    ${field('app_name', 'App / Portal name', a.app_name, 'text', {
                        required: true,
                        col: 6,
                        placeholder: 'e.g. Attendance Hub'
                    })}
                   


                    <div class="col-md-6">
                        <label class="form-label">
                            Type <span class="text-danger">*</span>
                        </label>
                        <select class="form-select select3" name="platform" id="platform" required >
                            <option value="Web Portal" ${a.platform == 'Web Portal' ? 'selected' : ''}>Portal</option>
                            <option value="Mobile App" ${a.platform == 'Mobile App' ? 'selected' : ''}>Mobile App</option>
                            <option value="Desktop" ${a.platform == 'Desktop' ? 'selected' : ''}>Desktop App</option>
                        </select>
                    </div> 
                
                    ${field('app_url', 'Link / App URL', a.app_url, 'text', {
                        col: 12,
                        placeholder: 'https://portal.example.com'
                    })}
                    ${field('purpose', 'Purpose', a.purpose, 'text', {
                        col: 12,
                        placeholder: 'One-line description'
                    })}

                    <div class="col-md-6">
                        <label class="form-label">
                            Owning company <span class="egpa-optional">optional</span>
                        </label>
                        <select class="form-select" id="egpaCompany" name="company_id">
                            <option value="">Group / Shared</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">
                            Technical owner <span class="egpa-optional">optional</span>
                        </label>
                        <input
                            type="hidden"
                            id="egpaOwnerId"
                            name="technical_owner_user_id"
                            value="${esc(a.technical_owner_user_id || '')}"
                        >
                        <input
                            type="text"
                            class="form-control"
                            id="egpaOwnerSearch"
                            autocomplete="off"
                            placeholder="Search staff"
                            value="${esc(a.technical_owner_name || '')}"
                        >
                        <div id="egpaOwnerSuggestions" class="d-none"></div>
                    </div>

                    ${field('environment', 'Environment', a.environment || 'Production', 'select', {
                        col: 6,
                        options: [
                            { value: 'Production', label: 'Production' },
                            { value: 'Staging', label: 'Staging' }
                        ]
                    })}
                    ${field('status', 'Status', a.status || 'Live', 'select', {
                        col: 6,
                        options: [
                            { value: 'Live', label: 'Live' },
                            { value: 'Under Maintenance', label: 'Under Maintenance' },
                            { value: 'Deprecated', label: 'Deprecated' }
                        ]
                    })}
                </div>
            </div>

            <div class="egpa-form-card">
                <div class="egpa-form-title">Icon &amp; screenshots</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">
                            Icon image <span class="egpa-optional">optional</span>
                        </label>
                        <div class="egpa-preview-wrap">
                            <div class="egpa-preview-icon" id="egpaIconPreview">
                                ${a.icon_url
                                    ? `<img src="${esc(a.icon_url)}" alt="">`
                                    : '<i class="mdi mdi-image-outline"></i>'}
                            </div>
                            <div style="flex:1;min-width:180px">
                                <input
                                    type="file"
                                    id="egpaIconFile"
                                    name="icon"
                                    class="form-control"
                                    accept=".png,.jpg,.jpeg,.webp"
                                >
                                <div class="egpa-preview-caption" id="egpaIconCaption">
                                    Portal/App icon. If no image is uploaded, the official favicon from the link can be used.
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">
                            Screenshots <span class="egpa-optional">optional · up to 8</span>
                        </label>
                        <input
                            type="file"
                            id="egpaScreenshots"
                            name="screenshots[]"
                            class="form-control"
                            accept=".png,.jpg,.jpeg,.webp"
                            multiple
                        >
                        <div class="egpa-screenshot-previews" id="egpaScreenshotPreviews"></div>
                    </div>
                </div>
            </div>

            ${release}

            <div class="egpa-form-card">
                <div class="row g-3">
                    ${field('passwallet_entry_id', 'PassWallet entry ID', a.passwallet_entry_id || '', 'number', {
                        col: 6,
                        placeholder: 'optional credential link'
                    })}
                </div>
            </div>
        `;
    }
    function hydrateCompany(selected) {
        const $select = $('#egpaCompany');

        if (!$select.length) {
            return;
        }

        ajax('GET', R.companies, null, {
            timeout: 15000
        }).done(function(response) {
            const rows = Array.isArray(response?.data) ? response.data : [];
            const options = rows.map(function(company) {
                const isSelected = String(company.sno) === String(selected ?? '')
                    ? 'selected'
                    : '';

                return `
                    <option value="${esc(company.sno)}" ${isSelected}>
                        ${esc(company.company_name)}
                    </option>
                `;
            }).join('');

            $select.html(`
                <option value="">Group / Shared</option>
                ${options}
            `);
        });
    }
    function ownerSearch() {
        const $input = $('#egpaOwnerSearch');
        const $id = $('#egpaOwnerId');
        const $box = $('#egpaOwnerSuggestions');

        if (!$input.length) {
            return;
        }

        $input.off('.egpaOwner').on('input.egpaOwner', function() {
            const term = $.trim(this.value || '');
            $id.val('');

            if (term.length < 2) {
                $box.addClass('d-none').empty();
                return;
            }

            if (state.ownerRequest) {
                state.ownerRequest.abort();
            }

            state.ownerRequest = $.ajax({
                url: R.users,
                type: 'GET',
                data: {
                    q: term,
                    limit: 12
                },
                dataType: 'json'
            }).done(function(response) {
                const rows = Array.isArray(response?.data) ? response.data : [];

                const options = rows.map(function(user) {
                    const staffId = user.sno || user.user_id;
                    const staffName = user.staff_name || user.name || 'Staff';
                    const email = user.email_id || '';

                    return `
                        <button
                            type="button"
                            class="btn btn-sm w-100 text-start"
                            data-egpa-owner="${esc(staffId)}"
                            data-egpa-owner-name="${esc(user.staff_name || user.name || user.email_id || '')}"
                        >
                            ${esc(staffName)}
                            <small class="text-muted">${esc(email)}</small>
                        </button>
                    `;
                }).join('');

                $box
                    .toggleClass('d-none', !rows.length)
                    .css({
                        position: 'relative',
                        'z-index': 20,
                        background: '#fff',
                        border: '1px solid #dfe5ee',
                        borderRadius: '8px'
                    })
                    .html(options);
            }).fail(function() {
                $box.addClass('d-none').empty();
            });
        });

        $box.off('.egpaOwner').on('click.egpaOwner', '[data-egpa-owner]', function() {
            $id.val($(this).data('egpa-owner'));
            $input.val($(this).data('egpa-owner-name'));
            $box.addClass('d-none').empty();
        });
    }
    function setupPreviews() {
        const iconInput = document.getElementById('egpaIconFile');
        const iconPreview = document.getElementById('egpaIconPreview');
        const iconCaption = document.getElementById('egpaIconCaption');

        if (iconInput) {
            iconInput.onchange = function() {
                const file = this.files?.[0];

                if (!file) {
                    return;
                }

                const reader = new FileReader();

                reader.onload = function(event) {
                    iconPreview.innerHTML = `
                        <img src="${esc(event.target.result)}" alt="">
                    `;
                    iconCaption.textContent = `${file.name} · ${bytes(file.size)}`;
                };

                reader.readAsDataURL(file);
            };
        }

        const screenshots = document.getElementById('egpaScreenshots');
        const screenshotWrap = document.getElementById('egpaScreenshotPreviews');

        if (screenshots) {
            screenshots.onchange = function() {
                screenshotWrap.innerHTML = '';

                Array.from(this.files || []).slice(0, 8).forEach(function(file) {
                    const reader = new FileReader();

                    reader.onload = function(event) {
                        screenshotWrap.insertAdjacentHTML('beforeend', `
                            <div class="egpa-shot">
                                <img src="${esc(event.target.result)}" alt="">
                                <span>${esc(file.name)}</span>
                            </div>
                        `);
                    };

                    reader.readAsDataURL(file);
                });

                if (this.files.length > 8) {
                    notify('Only the first 8 screenshots will be uploaded.', 'warning');
                }
            };
        }

        const packageInput = document.getElementById('egpaPackageFile');
        const packagePreview = document.getElementById('egpaPackagePreview');

        if (packageInput) {
            packageInput.onchange = function() {
                const file = this.files?.[0];

                packagePreview.innerHTML = file
                    ? `
                        <div class="egpa-package">
                            <i class="mdi mdi-package-variant"></i>
                            <div class="egpa-package-copy">
                                <div class="egpa-package-name">${esc(file.name)}</div>
                                <div class="egpa-package-size">
                                    ${bytes(file.size)} · ready for upload
                                </div>
                            </div>
                        </div>
                    `
                    : '';
            };
        }

        const urlInput = root.querySelector('[name="app_url"]');

        if (urlInput) {
            urlInput.addEventListener('blur', resolveFormFavicon);
        }
    }
    function resolveFormFavicon() {
        const url = $.trim($('#egpaForm [name="app_url"]').val() || '');

        if (!url || $('#egpaIconFile').val()) {
            return;
        }

        const normalizedUrl = /^https?:\/\//i.test(url)
            ? url
            : `https://${url}`;

        ajax('GET', `${R.favicon}?url=${encodeURIComponent(normalizedUrl)}`, null, {
            timeout: 12000
        }).done(function(response) {
            const src = String(response?.data?.favicon_url || '');

            if (src) {
                $('#egpaIconPreview').html(`
                    <img src="${esc(src)}" alt="">
                `).next().find('.egpa-preview-caption').text(
                    'Official site favicon loaded from the link.'
                );
            }
        });
    }
    function openForm(app, mode) {
        const currentApp = app || {};
        const isEdit = mode === 'edit';

        $('#egpaFormTitle').text(
            isEdit ? 'Edit Portal / App' : 'Register a Portal / App'
        );

        // $('#egpaFormSub').text(
        //     isEdit
        //         ? 'Update details and media without leaving the page.'
        //         : 'Add a portal or mobile/desktop application. Supporting fields are optional.'
        // );

        $('#egpaFormBody').html(formHtml(currentApp, mode));
        $('#egpaSave .save-label').text(isEdit ? 'Save changes' : 'Register');
        $('#egpaSave .save-loading').addClass('d-none');
        $('#egpaSave .save-label').removeClass('d-none').closest('button').prop('disabled', false);

        hydrateCompany(currentApp.company_id);
        ownerSearch();
        setupPreviews();

        root.dataset.formMode = mode || 'create';
        root.dataset.formId = currentApp.sno || '';

        formModal().show();
    }
    function openVersion(id) {
        ajax('GET', route(R.show, id)).done(function(response) {
            const app = response?.data?.app || {};
            const today = new Date().toISOString().slice(0, 10);

            $('#egpaFormTitle').text('Record update');
            // $('#egpaFormSub').text(
            //     'Version history, release notes and optional package upload are retained together.'
            // );

            $('#egpaFormBody').html(`
                <div class="egpa-form-card">
                    <div class="egpa-form-title">
                        ${esc(app.app_name || 'Portal / App')}
                    </div>

                    <div class="row g-3">
                        ${field('version_no', 'Version', '', 'text', {
                            required: false,
                            col: 4,
                            placeholder: 'Leave blank to auto-generate'
                        })}
                        ${field('build_number', 'Build number', '', 'number', {
                            col: 4,
                            placeholder: 'optional'
                        })}
                        ${field('change_type', 'Release type', 'Release', 'select', {
                            col: 4,
                            options: [
                                { value: 'Release', label: 'Release' },
                                { value: 'New Features', label: 'New Features' },
                                { value: 'Improvement', label: 'Improvement' },
                                { value: 'Bug Fix', label: 'Bug Fix' },
                                { value: 'Security', label: 'Security' },
                                { value: 'Maintenance', label: 'Maintenance' }
                            ]
                        })}
                        ${field('update_details', 'What’s new / changes', '', 'textarea', {
                            col: 6,
                            rows: 4,
                            placeholder: 'One item per line'
                        })}
                        ${field('bug_fix_details', 'Bug fixes', '', 'textarea', {
                            col: 6,
                            rows: 4,
                            placeholder: 'One item per line'
                        })}
                        ${field('release_notes', 'Release notes', '', 'textarea', {
                            col: 12,
                            rows: 4
                        })}

                        <div class="col-md-4">
                            <label class="form-label">
                                Release file <span class="egpa-optional fs-8">optional · up to 1 GB</span>
                            </label>
                            <input
                                type="file"
                                id="egpaPackageFile"
                                name="package_file"
                                class="form-control"
                                accept=".apk,.aab,.zip"
                            >
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">
                                Screenshots <span class="egpa-optional">optional</span>
                            </label>
                            <input
                                type="file"
                                id="egpaScreenshots"
                                name="screenshots[]"
                                class="form-control"
                                accept=".png,.jpg,.jpeg,.webp"
                                multiple
                            >
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">
                                Update date <span class="egpa-optional">optional</span>
                            </label>
                            <input
                                type="date"
                                name="update_date"
                                class="form-control"
                                value="${today}"
                            >
                        </div>

                        <div class="col-12">
                            <div id="egpaPackagePreview"></div>
                            <div class="egpa-screenshot-previews" id="egpaScreenshotPreviews"></div>
                        </div>
                    </div>

                    <div class="egpa-progress" id="egpaUploadProgress">
                        <div class="egpa-progress-top">
                            <span class="egpa-progress-title" id="egpaProgressTitle">Preparing upload…</span>
                            <strong id="egpaProgressPercent">0%</strong>
                        </div>
                        <div class="egpa-progress-track">
                            <div class="egpa-progress-bar" id="egpaProgressBar"></div>
                        </div>
                        <div class="egpa-progress-status" id="egpaProgressStatus">
                            Your browser is preparing the selected files.
                        </div>
                    </div>
                </div>
            `);

            $('#egpaSave .save-label').text('Save update');
            $('#egpaSave .save-loading').addClass('d-none');
            $('#egpaSave .save-label').removeClass('d-none').closest('button').prop('disabled', false);

            root.dataset.formMode = 'version';
            root.dataset.formId = id;

            setupPreviews();
            formModal().show();
        }).fail(function(error) {
            notify(error.message || 'Unable to load version form.', 'error');
        });
    }
    function setProgress(p, title, status) {
        $('#egpaUploadProgress').addClass('active'); $('#egpaProgressBar').css('width', p+'%'); $('#egpaProgressPercent').text(Math.round(p)+'%'); $('#egpaProgressTitle').text(title); $('#egpaProgressStatus').text(status);
    }
    function uploadForm($form) {
        const mode=root.dataset.formMode||'create', id=Number(root.dataset.formId||0), fd=new FormData($form[0]);
        const screenshotInput=document.getElementById('egpaScreenshots');
        if(screenshotInput) {
            fd.delete('screenshots[]'); Array.from(screenshotInput.files||[]).slice(0, 8).forEach(f=>fd.append('screenshots[]', f, f.name));
        }
        const packageInput=document.getElementById('egpaPackageFile');
        if(packageInput?.files?.[0] && packageInput.files[0].size>1073741824) {
            notify('The application package is larger than the 1 GB production limit.', 'error'); return;
        }
        let url=R.store; if(mode==='edit') {
            url=route(R.update, id); fd.append('_method', 'PUT');
        } else if(mode==='version') {
            url=route(R.version, id);
        }
        $('#egpaSave').prop('disabled', true); $('#egpaSave .save-label').addClass('d-none'); $('#egpaSave .save-loading').removeClass('d-none'); setProgress(2, 'Preparing upload…', 'Validating fields and preparing selected files.');
        const xhr=new XMLHttpRequest(); xhr.open('POST', url, true); xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content')||''); xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest'); xhr.setRequestHeader('Accept', 'application/json');
        xhr.upload.onloadstart=()=>setProgress(6, 'Uploading securely…', 'The transfer has started.');
        xhr.upload.onprogress=e=> {
            if(e.lengthComputable) {
                const p = 6 + (e.loaded / e.total) * 84;
                    setProgress(p, 'Uploading securely…', `${bytes(e.loaded)} of ${bytes(e.total)} uploaded`);
            }
        };
        xhr.onload=()=> {
            let payload= {
            }; try {
                payload=JSON.parse(xhr.responseText||'{}')
            } catch(e) {
            }; if(xhr.status>=200&&xhr.status<300) {
                setProgress(96, 'Processing & optimizing…', 'The server is storing files, optimizing images and updating release metadata.'); setTimeout(()=>setProgress(100, 'Completed', 'Everything was saved successfully.'), 120); setTimeout(()=> {
                    formModal().hide(); notify(payload.message||'Saved successfully.'); if(mode==='version'&&id)openDetail(id, true); else if(mode==='edit'&&id)openDetail(id, true); else loadData();
                }, 360);
            } else {
                notify(payload.message||(payload.errors?Object.values(payload.errors).flat()[0]:'Unable to save the record.'), 'error'); $('#egpaSave').prop('disabled', false); $('#egpaSave .save-label').removeClass('d-none'); $('#egpaSave .save-loading').addClass('d-none');
            }
        };
        xhr.onerror=()=> {
            notify('The upload connection failed. Please try again.', 'error'); $('#egpaSave').prop('disabled', false); $('#egpaSave .save-label').removeClass('d-none'); $('#egpaSave .save-loading').addClass('d-none');
        };
        xhr.ontimeout=()=> {
            notify('The upload timed out. For large files, verify the server upload limits in the deployment notes.', 'error'); $('#egpaSave').prop('disabled', false); $('#egpaSave .save-label').removeClass('d-none'); $('#egpaSave .save-loading').addClass('d-none');
        };
        xhr.timeout=0; xhr.send(fd);
    }
    function openDetail(id, silent) {
        state.mode = 'detail';

        if (!silent) {
            $workspace.html(`
                <div class="egpa-loading">
                    <span class="spinner-border spinner-border-sm me-2"></span>
                    Loading application details…
                </div>
            `);
        }

        ajax('GET', route(R.show, id), null, {
            timeout: 30000
        }).done(function(response) {
            const data = response?.data || {};

            state.app = data.app || null;
            $('#egpaToolbar').addClass('d-none');

            $workspace.html(
                renderDetail(
                    data.app || {},
                    Array.isArray(data.versions) ? data.versions : [],
                    Array.isArray(data.media) ? data.media : [],
                    data.current_version_json,
                    data.is_subscribed
                )
            );
        }).fail(function(error) {
            notify(error.message || 'Unable to load details.', 'error');

            if (!silent) {
                goBack();
            }
        });
    }
    function lineItems(text) {
        return String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    }
    function renderDetail(app, versions, media, currentJson, subscribed) {
        const shots = media.filter(function(item) {
            return item.media_type === 'screenshot';
        });

        const credentialButton = app.passwallet_entry_id
            ? `
                <button
                    type="button"
                    class="btn egpa-btn egpa-btn-light"
                    data-egpa-action="credential"
                    data-id="${esc(app.passwallet_entry_id)}"
                >
                    <i class="mdi mdi-shield-key-outline"></i>
                </button>
            `
            : '';

        const manageActions = Number(app.can_manage)
            ? `
                <div class="dropdown">
                    <button
                        type="button"
                        class="btn egpa-btn egpa-btn-light"
                        data-bs-toggle="dropdown"
                    >
                        <i class="mdi mdi-dots-vertical"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <button class="dropdown-item" data-egpa-action="edit" data-id="${esc(app.sno)}">
                                <i class="mdi mdi-pencil-outline me-2"></i>Edit
                            </button>
                        </li>
                        <li>
                            <button class="dropdown-item" data-egpa-action="version" data-id="${esc(app.sno)}">
                                <i class="mdi mdi-source-branch-plus me-2"></i>Record update
                            </button>
                        </li>
                        <li>
                            <button class="dropdown-item" data-egpa-action="share" data-id="${esc(app.sno)}">
                                <i class="mdi mdi-share-variant-outline me-2"></i>Share
                            </button>
                        </li>
                    </ul>
                </div>
            `
            : '';

        const currentMetadataPanel = currentJson
            ? `
                <div class="egpa-panel">
                    <div class="egpa-panel-title">Current version API metadata</div>
                    <div class="egpa-api-box" id="egpaCurrentApiJson">
                        ${esc(JSON.stringify(currentJson, null, 2))}
                    </div>
                    <button
                        type="button"
                        class="btn egpa-btn egpa-btn-light mt-2"
                        data-egpa-action="copy-api"
                    >
                        <i class="mdi mdi-content-copy"></i>Copy JSON
                    </button>
                </div>
            `
            : '';

        const screenshotsPanel = shots.length
            ? `
                <div class="egpa-panel">
                    <div class="egpa-panel-title">Application screenshots</div>
                    <div class="egpa-media-grid">
                        ${shots.map(function(item) {
                            return `
                                <div class="egpa-media-thumb">
                                    <img src="${esc(item.url)}" alt="">
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            `
            : '';

        const versionHistory = versions.length
            ? versions.map(function(version, index) {
                const updates = lineItems(version.update_details);
                const bugFixes = lineItems(version.bug_fix_details);
                const currentBadge = index === 0
                    ? '<span class="egpa-current">CURRENT</span>'
                    : '';
                const changeType = version.change_type
                    ? `
                        <div class="egpa-history-date mt-1">
                            ${esc(version.change_type)}
                        </div>
                    `
                    : '';
                const whatsNew = updates.length
                    ? `
                        <div class="egpa-history-section">WHAT’S NEW</div>
                        <ul class="egpa-history-lines">
                            ${updates.map(function(item) {
                                return `<li>${esc(item)}</li>`;
                            }).join('')}
                        </ul>
                    `
                    : '';
                const bugFixSection = bugFixes.length
                    ? `
                        <div class="egpa-history-section">BUG FIXES</div>
                        <ul class="egpa-history-lines">
                            ${bugFixes.map(function(item) {
                                return `<li>${esc(item)}</li>`;
                            }).join('')}
                        </ul>
                    `
                    : '';
                const releaseNotes = version.release_notes
                    ? `
                        <div class="egpa-history-section">RELEASE NOTES</div>
                        <div class="egpa-history-date" style="font-size:9px;line-height:1.5">
                            ${esc(version.release_notes)}
                        </div>
                    `
                    : '';
                const packageLink = version.package_path
                    ? `
                        <div class="mt-2">
                            <a class="btn egpa-btn egpa-btn-light" href="${esc(version.download_url)}">
                                <i class="mdi mdi-download-outline"></i>
                                ${esc(version.formatted_stored_size || 'Download package')}
                                ${version.saving_percent ? ` · ${esc(version.saving_percent)}% optimized` : ''}
                            </a>
                        </div>
                    `
                    : '';

                return `
                    <div class="egpa-history-item">
                        <div class="egpa-history-head">
                            <span class="egpa-version">v${esc(version.version_no)}</span>
                            ${currentBadge}
                            <span class="egpa-history-date">
                                ${esc(version.update_date || '')} · ${esc(version.updated_by_name || 'Team')}
                            </span>
                        </div>
                        ${changeType}
                        ${whatsNew}
                        ${bugFixSection}
                        ${releaseNotes}
                        ${packageLink}
                    </div>
                `;
            }).join('')
            : `
                <div class="egpa-empty" style="padding:28px 10px">
                    <div class="egpa-empty-title">No version history yet</div>
                    <div class="egpa-empty-sub">
                        Record the first update to start the release timeline.
                    </div>
                </div>
            `;

        return `
            <div class="egpa-detail">
                <a href="#" class="egpa-back" data-egpa-action="back">
                    <i class="mdi mdi-arrow-left"></i>
                    All Portals &amp; Apps
                </a>

                <div class="egpa-detail-card">
                    <div class="egpa-detail-hero">
                        <div class="egpa-detail-left">
                            ${iconMarkup(app, 'egpa-detail-icon')}
                            <div class="egpa-detail-main">
                                <h2 class="egpa-detail-name">
                                    ${esc(app.app_name || 'Portal / App')}
                                </h2>
                                <div class="egpa-detail-purpose">
                                    ${esc(app.purpose || 'Internal portal / application')}
                                </div>
                                <div class="egpa-detail-meta">
                                    <span><strong>${esc(app.company_name || 'Group')}</strong></span>
                                    <span>${esc(app.platform || 'Web Portal')}</span>
                                    <span>${esc(app.environment || 'Production')}</span>
                                    <span>Owner: <strong>${esc(app.technical_owner_name || '—')}</strong></span>
                                    <span class="egpa-tag ${statusClass(app.status)}">
                                        ${esc(app.status || 'Live')}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="egpa-detail-actions">
                            <button
                                type="button"
                                class="btn egpa-btn egpa-btn-light"
                                data-egpa-action="subscribe"
                                data-id="${esc(app.sno)}"
                            >
                                <i class="mdi ${subscribed ? 'mdi-bell-check-outline' : 'mdi-bell-outline'}"></i>
                            </button>

                            ${credentialButton}

                            <button
                                type="button"
                                class="btn egpa-btn egpa-btn-dark"
                                data-egpa-action="launch"
                                data-id="${esc(app.sno)}"
                            >
                                <i class="mdi mdi-open-in-new"></i>Open
                            </button>

                            ${manageActions}
                        </div>
                    </div>

                    <div class="egpa-detail-body">
                        ${currentMetadataPanel}
                        ${screenshotsPanel}

                        <div class="egpa-panel">
                            <div class="egpa-panel-title">
                                Version history
                                <span class="egpa-optional">· ${esc(versions.length)} release(s)</span>
                            </div>
                            <div class="egpa-history">
                                ${versionHistory}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    function launch(id) {
        const popup=window.open('about:blank', '_blank', 'noopener,noreferrer'); ajax('POST', route(R.launch, id)).done(r=> {
            const u=r?.data?.url||''; if(!u) {
                if(popup&&!popup.closed)popup.close(); notify('No launch URL is available.', 'error'); return;
            }
            if(popup&&!popup.closed)popup.location.href=u; else notify('Your browser blocked the new tab. Allow pop-ups for this ERP.', 'error');
        }).fail(e=> {
            if(popup&&!popup.closed)popup.close(); notify(e.message||'Unable to launch.', 'error');
        });
    }
    function toggleSubscribe(id) {
        ajax('POST', route(R.subscribe, id)).done(r=> {
            notify(r?.message||'Subscription updated.'); if(state.mode==='detail')openDetail(id, true); else loadData();
        }).fail(e=>notify(e.message||'Unable to update subscription.', 'error'));
    }
    function openShare(id) {
        $('#egpaShareId').val(id); $('#egpaShareType').trigger('change'); loadShares(id); shareModal().show();
    }
    function loadShares(id) {
        ajax('GET', R.shares.data, {
            resource_type: 'portal',
            resource_id: id
        }).done(function(response) {
            const rows = Array.isArray(response?.data) ? response.data : [];

            const html = rows.length
                ? rows.map(function(share) {
                    return `
                        <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                            <div>
                                <div style="font-size:9px;font-weight:800">
                                    ${esc(share.grantee_type)} · ${esc(share.grantee_id)}
                                </div>
                                <div class="text-muted" style="font-size:8px">
                                    ${esc(share.permission)} · ${esc(share.status)} · ${esc(share.expires_at || 'No expiry')}
                                </div>
                            </div>
                            <button
                                type="button"
                                class="btn egpa-btn egpa-btn-light"
                                data-egpa-share-revoke="${esc(share.sno)}"
                            >
                                <i class="mdi mdi-close"></i>
                            </button>
                        </div>
                    `;
                }).join('')
                : `
                    <div class="text-muted" style="font-size:9px">
                        No active or pending shares.
                    </div>
                `;

            $('#egpaShareList').html(html);
        }).fail(function(error) {
            notify(error.message || 'Unable to load shares.', 'error');
        });
    }
    function loadShareRecipients(type) {
        const $select = $('#egpaShareRecipient');

        if (type === 'group') {
            return $select.html(`
                <option value="0">Whole Group</option>
            `);
        }

        if (type === 'role') {
            const roles = [
                'Super Admin',
                'Group Admin',
                'Company Admin',
                'Module Manager',
                'Staff',
                'Auditor'
            ];

            return $select.html(
                roles.map(function(role) {
                    return `<option value="${esc(role)}">${esc(role)}</option>`;
                }).join('')
            );
        }

        const endpoint = type === 'company' ? R.companies : R.users;

        ajax('GET', endpoint, {
            limit: 100
        }, {
            timeout: 15000
        }).done(function(response) {
            const rows = Array.isArray(response?.data) ? response.data : [];
            const options = rows.map(function(item) {
                if (type === 'company') {
                    return `
                        <option value="${esc(item.sno)}">
                            ${esc(item.company_name)}
                        </option>
                    `;
                }

                return `
                    <option value="${esc(item.sno || item.user_id)}">
                        ${esc(item.staff_name || item.name || item.email_id || '')}
                    </option>
                `;
            }).join('');

            $select.html(options || `
                <option value="">No recipients</option>
            `);
        }).fail(function() {
            $select.html(`
                <option value="">Unable to load recipients</option>
            `);
        });
    }
    function saveShare() {
        const id=$('#egpaShareId').val(); ajax('POST', R.shares.store, {
            resource_type:'portal', resource_id:id, grantee_type:$('#egpaShareType').val(), grantee_id:$('#egpaShareRecipient').val(), permission:$('#egpaSharePermission').val(), expires_at:$('#egpaShareExpiry').val()
        }).done(r=> {
            notify(r?.message||'Share created.'); loadShares(id);
        }).fail(e=>notify(e.message||'Unable to share.', 'error'));
    }
    function exportPortals() {
        const xhr=$.ajax( {
            url:R.exportXlsx, type:'GET', xhrFields: {
                responseType:'blob'
            }
        }); xhr.done(function(blob, status, jq) {
            const contentDisposition = jq.getResponseHeader('Content-Disposition') || '';
            const match = contentDisposition.match(/filename="?([^";]+)"?/i);
            const name = match ? match[1] : 'portal_apps.xlsx';
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');

            link.href = url;
            link.download = name;
            document.body.appendChild(link);
            link.click();
            link.remove();
            URL.revokeObjectURL(url);

            notify('Portals & Apps export downloaded.');
        }).fail(e=>notify(failMessage(e), 'error'));
    }
    function goBack() {
        state.mode='list'; state.app=null; $('#egpaToolbar').removeClass('d-none'); loadData();
    }
    function editApp(id) {
        ajax('GET', route(R.show, id)).done(r=>openForm(r?.data?.app|| {
        }, 'edit')).fail(e=>notify(e.message||'Unable to load app.', 'error'));
    }
    $('#egpaAdd').on('click', ()=>openForm( {
    }, 'create'));

    function status_filter_change_func() {
        state.status=$('#egpaStatus').val(); 
        state.page=1; 
        loadData();
    }
    function platform_filter_change_func() {
        state.platform=$('#egpaPlatform').val(); 
        state.page=1; 
        loadData();
    }

  
    $root.on('click', '[data-egpa-view]', function() {
        $root.find('[data-egpa-view]').removeClass('active'); $(this).addClass('active'); state.view=$(this).data('egpa-view'); loadData();
    });
    $root.on('click', '[data-egpa-page]', function() {
        state.page=Number($(this).data('egpa-page'))||1; loadData();
    });
    $root.on('click', '[data-egpa-card]', function(e) {
        if($(e.target).closest('[data-egpa-action],[data-egpa-stop],button,a,input,select,.dropdown').length)return; const id=$(this).data('egpa-card'); if(id)openDetail(id);
    });
    $root.on('click', '[data-egpa-action]', function(e) {
        e.preventDefault(); 
        e.stopPropagation(); 
        const a=$(this).data('egpa-action'), id=$(this).data('id'); 
        if(a==='new')return openForm( {
        }, 'create'); if(a==='retry')return loadData(); if(a==='back')return goBack(); if(a==='launch')return launch(id); if(a==='edit')return editApp(id); if(a==='version')return openVersion(id); if(a==='subscribe')return toggleSubscribe(id); if(a==='share')return openShare(id); if(a==='export')return exportPortals(); if(a==='credential')return window.open(route(R.passwallet, id), '_blank', 'noopener,noreferrer'); if(a==='copy-api') {
            navigator.clipboard?.writeText($('#egpaCurrentApiJson').text()).then(()=>notify('Current version JSON copied.')).catch(()=>notify('Copy was blocked by the browser.', 'error'));
        }
    });
    $root.on('submit', '#egpaForm', function(e) {
        e.preventDefault(); 
        uploadForm($(this));
    });

    $('#egpaShareType').on('change', function() {
        loadShareRecipients(this.value);
    });

    $('#egpaShareSave').on('click', saveShare);

    $('#egpaShareList').on('click', '[data-egpa-share-revoke]', function() {
        const grant=$(this).data('egpa-share-revoke'),id=$('#egpaShareId').val(); 

        ajax('POST', route(R.shares.revoke, grant), {
            _method:'DELETE'
        }).done(r=> {
            notify(r?.message||'Share revoked.'); 
            loadShares(id);
        }).fail(e=>notify(e.message||'Unable to revoke share.', 'error'));
    });

    loadData();
</script>
@endsection
