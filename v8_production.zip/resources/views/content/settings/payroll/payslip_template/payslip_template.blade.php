@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Payslip Template')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
        .credential-wrapper {
             min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
            width: 280px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
            align-items:center;
            gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>
<!-- Users List Table -->
<div class="card">
    <div class="card-header pb-1">
        <ul class="nav nav-tabs flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                            class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                            
                <div class="scroll-container" id="scrollContainer">
                    <li class="item nav-item">
                        <a href="{{ url('/settings/general_settings') }}"
                            type="button"
                            class="nav-link scroll-link "
                            role="tab">
                            General Settings
                        </a>
                    </li>        
                    <li class="item nav-item">
                        <a
                            href="{{ url('/settings/broadcast_theme') }}"
                            type="button"
                            class="nav-link scroll-link "
                            aria-selected="true">
                            Common
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/credential_book') }}" type="button"
                            class="nav-link scroll-link ">
                            Entity
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                            HRM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/rule_category') }}" type="button"
                            class="nav-link scroll-link active">
                            Payroll
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/applicant_status') }}" type="button"
                            class="nav-link scroll-link ">
                            Recruitment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/interview_mode') }}" type="button"
                            class="nav-link scroll-link ">
                            Interview
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                            class="nav-link scroll-link">
                            Assessment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Management
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="{{ url('/settings/business/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Business
                            </a>
                        </li>

                    <li class="nav-item">
                        <a href="{{ url('/settings/api_config') }}" type="button"
                            class="nav-link scroll-link ">
                            API Config
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/admin/webhooks') }}" type="button"
                            class="nav-link scroll-link ">
                            Webhook Moniter
                        </a>
                    </li>
                </div>
                <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                        class="mdi mdi-chevron-right fs-2 text-white"></i></button>
            </div>
        </ul>
    </div>
    <div class="card-body px-1 py-1">
            <div class="d-flex credential-wrapper">
                <!-- CONTENT -->
                <div class="tab-content flex-grow-1 position-relative">
                    <!-- Toggle Button -->
                    <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                        <i class="mdi mdi-chevron-right"></i>
                    </button>

                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Pay Component</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Payroll </a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Payslip Template
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_category">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Payslip Template
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between mb-4 ">
                                <div>
                                    <span>Show</span>
                                    <select id="perpage" class="form-select form-select-sm w-75px"
                                        onchange="loadThemes(1)">
                                        @php $options = [5,10, 25, 100, 500]; @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                                {{ $option }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input type="text" id="search_filter" class="searchQueryInput"
                                            placeholder="Search Pay Component..."
                                            value="{{ $search_filter }}"/>
                                        
                                        <div class="searchAction">
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                                    <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                                </a>
                                                <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                                    <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-50px">Company Name</th>
                                        <th class="min-w-150px">Template</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                    <tr class="skeleton-loader" id="skeleton-loader">
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                        <td class="skeleton-cell">
                                            <div class="skeleton"></div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-center my-3" id="pagination-container">
                            <!-- Pagination buttons will appear here -->
                        </div>
                    </div>
                </div>
                <!-- SIDEBAR -->
                <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                    <ul class="nav nav-tabs flex-column" role="tablist">
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/rule_category') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Payroll Rule</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Rule"><i class="mdi mdi-clipboard-text-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/payroll_salary_component') }}" class="nav-link "  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">Salary Component</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Salary Component"><i class="mdi mdi-cog-outline fs-3"></i></span>
                                </label>
                            </a>
                        </li>
                        <li class="nav-item px-1">
                            <a href="{{ url('/settings/payslip_templates') }}" class="nav-link active"  role="tab">
                                <label class="fs-6 right_nav">
                                    <span class="tab-text">payslip Template</span>
                                    <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                                </label>
                                
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
    </div>
</div>


<!--begin::Modal - Add Rule Category -->
<div class="modal fade" id="kt_modal_add_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Payslip Template</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <form id="addForm" action="{{ route('add_payslip_template') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                                <select id="company_id" name="company_id" class="select3 form-select ">
                                    <option value="">Select Company Name</option>
                                    <option value="0">Elysium Groups</option>
                                        @if(isset($company_list))
                                        @foreach($company_list as $clist)
                                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                        @endforeach
                                        @endif
                                </select>
                                <div class="text-danger" id="company_id_err"></div>
                        </div>
                    <div class="col-lg-12 mb-4">
                        <label class="text-black mb-2 fs-6 fw-semibold">
                            Payslip Template <span class="text-danger">*</span>
                        </label>

                        <div class="row align-items-center">

                            <!-- LEFT SIDE: Upload -->
                            <div class="col-lg-6">
                                <div class="border rounded p-4 text-center bg-light position-relative" style="min-height: 180px;">
                                    
                                    <input type="file" id="upload" class="file-in d-none" 
                                        name="payslip_template_img" accept="image/png, image/jpeg" />

                                    <div>
                                        <i class="mdi mdi-cloud-upload-outline" style="font-size:40px;"></i>
                                        <p class="mb-1 mt-2 fw-semibold">Click to upload</p>
                                        <small class="text-muted">JPG, PNG (Max: 800KB)</small>
                                    </div>

                                    <button type="button" class="btn btn-sm btn-primary mt-3"
                                        onclick="$('#upload').click()">
                                        Choose File
                                    </button>

                                    <div id="payslip_template_img_err" class="text-danger mt-2"></div>
                                </div>
                            </div>

                            <!-- RIGHT SIDE: Preview -->
                            <div class="col-lg-6">
                                <div class="border rounded p-3 text-center bg-white" style="min-height: 180px;">
                                    <p class="text-muted mb-2">Preview</p>

                                    <img src="https://placehold.net/default.png" 
                                        id="uploadedlogo"
                                        class="img-fluid rounded border"
                                        style="max-height:150px; object-fit:contain;" />

                                    <div class="mt-2">
                                        <button type="button" class="btn btn-sm btn-outline-danger" id="removeImage">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-12 mb-4">
                        <label class="text-black mb-2 fs-6 fw-semibold">
                            Letter Head <span class="text-danger">*</span>
                        </label>

                        <div class="row align-items-center">

                            <!-- LEFT SIDE: Upload -->
                            <div class="col-lg-6">
                                <div class="border rounded p-4 text-center bg-light position-relative" style="min-height: 180px;">
                                    
                                    <input type="file" id="letter_head_upload" class="file-in d-none" 
                                        name="letter_head_img" accept="image/png, image/jpeg" />

                                    <div>
                                        <i class="mdi mdi-cloud-upload-outline" style="font-size:40px;"></i>
                                        <p class="mb-1 mt-2 fw-semibold">Click to upload</p>
                                        <small class="text-muted">JPG, PNG (Max: 800KB)</small>
                                    </div>

                                    <button type="button" class="btn btn-sm btn-primary mt-3"
                                        onclick="$('#letter_head_upload').click()">
                                        Choose File
                                    </button>

                                    <div id="letter_head_upload_img_err" class="text-danger mt-2"></div>
                                </div>
                            </div>

                            <!-- RIGHT SIDE: Preview -->
                            <div class="col-lg-6">
                                <div class="border rounded p-3 text-center bg-white" style="min-height: 180px;">
                                    <p class="text-muted mb-2">Preview</p>

                                    <img src="https://placehold.net/default.png" 
                                        id="letterUploadedlogo"
                                        class="img-fluid rounded border"
                                        style="max-height:150px; object-fit:contain;" />

                                    <div class="mt-2">
                                        <button type="button" class="btn btn-sm btn-outline-danger" id="removeImageLetter">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="createbtn" class="btn btn-primary" onclick="addValidateForm()">Create Payslip Template</button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Rule Category-->


<!--begin::Modal - Update Rule Category -->
<div class="modal fade" id="kt_modal_update_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Pay Component</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <form id="updateForm" action="{{ route('payslip_template_update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="row">
                            <!-- Basic -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                                <select id="company_id_edit" name="company_id" class="select3 form-select ">
                                    <option value="">Select Company Name</option>
                                    <option value="0">Elysium Groups</option>
                                        @if(isset($company_list))
                                        @foreach($company_list as $clist)
                                        <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                        @endforeach
                                        @endif
                                </select>
                                <div class="text-danger" id="company_id_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">
                                Payslip Template <span class="text-danger">*</span>
                            </label>

                            <div class="row align-items-center">

                                <!-- LEFT SIDE: Upload -->
                                <div class="col-lg-6">
                                    <div class="border rounded p-4 text-center bg-light position-relative" style="min-height: 180px;">
                                        
                                        <input type="file" id="upload_edit" class="file-in-edit d-none" 
                                            name="payslip_template_img" accept="image/png, image/jpeg" />

                                        <div>
                                            <i class="mdi mdi-cloud-upload-outline" style="font-size:40px;"></i>
                                            <p class="mb-1 mt-2 fw-semibold">Click to upload</p>
                                            <small class="text-muted">JPG, PNG (Max: 800KB)</small>
                                        </div>

                                        <button type="button" class="btn btn-sm btn-primary mt-3"
                                            onclick="$('#upload_edit').click()">
                                            Choose File
                                        </button>

                                        <div id="payslip_template_img_edit_err" class="text-danger mt-2"></div>
                                    </div>
                                </div>

                                <!-- RIGHT SIDE: Preview -->
                                <div class="col-lg-6">
                                    <div class="border rounded p-3 text-center bg-white" style="min-height: 180px;">
                                        <p class="text-muted mb-2">Preview</p>

                                        <img src="https://placehold.net/default.png" 
                                            id="uploadedlogo_edit"
                                            class="img-fluid rounded border"
                                            style="max-height:150px; object-fit:contain;" />

                                        <div class="mt-2">
                                            <button type="button" class="btn btn-sm btn-outline-danger" id="removeImage_edit">
                                                Remove
                                            </button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-2 fs-6 fw-semibold">
                                Letter Head <span class="text-danger">*</span>
                            </label>

                            <div class="row align-items-center">

                                <!-- LEFT SIDE: Upload -->
                                <div class="col-lg-6">
                                    <div class="border rounded p-4 text-center bg-light position-relative" style="min-height: 180px;">
                                        
                                        <input type="file" id="upload_edit_letter" class="file-in-edit d-none" 
                                            name="letter_head_img" accept="image/png, image/jpeg" />

                                        <div>
                                            <i class="mdi mdi-cloud-upload-outline" style="font-size:40px;"></i>
                                            <p class="mb-1 mt-2 fw-semibold">Click to upload</p>
                                            <small class="text-muted">JPG, PNG (Max: 800KB)</small>
                                        </div>

                                        <button type="button" class="btn btn-sm btn-primary mt-3"
                                            onclick="$('#upload_edit_letter').click()">
                                            Choose File
                                        </button>

                                        <div id="upload_edit_letter_img_edit_err" class="text-danger mt-2"></div>
                                    </div>
                                </div>

                                <!-- RIGHT SIDE: Preview -->
                                <div class="col-lg-6">
                                    <div class="border rounded p-3 text-center bg-white" style="min-height: 180px;">
                                        <p class="text-muted mb-2">Preview</p>

                                        <img src="https://placehold.net/default.png" 
                                            id="uploadedlogo_edit_letter"
                                            class="img-fluid rounded border"
                                            style="max-height:150px; object-fit:contain;" />

                                        <div class="mt-2">
                                            <button type="button" class="btn btn-sm btn-outline-danger" id="removeImage_edit_letter">
                                                Remove
                                            </button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="updatebtn" onclick="editValidateForm()">Update Pay Component</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal -->

<!--begin::Modal - Delete Rule Category-->
<div class="modal fade" id="kt_modal_delete_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Attendance </b>
                    Pay Component ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Rule Category-->




<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
            <tr>

                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <label class="fs-7 fw-medium">${item.company_name}</label>
                </td>
                <td>
                <div>
                <img src="${item.payslip_template ? `/settings/payslip_template/${item.payslip_template}` :'https://placehold.net/default.png'}" 
                                        class="img-fluid rounded border"
                                        style="max-width:120px; object-fit:contain;" />
                </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                        <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_update_rule_category"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Edit" onclick="openEditModal('${item.sno}', '${item.company_id}','${item.payslip_template || ''}','${item.letter_head_image || ''}')">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                        </button>
                        <button class="btn btn-icon btn-sm" type="button" 
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_rule_category"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Delete"  onclick="confirmDelete('${item.sno}', '${item.company_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/payslip_templates?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(5));
            }
                 $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/payslip_template_status_change/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(1);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id, name) {
  
          document.querySelector('#kt_modal_delete_rule_category .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete <b class="text-danger">' +
              name +
              '</b> Pay Component ?');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_rule_category .btn-danger').getAttribute('data-id');

          fetch('/payslip_template_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {

              });
      }
</script>

<!-- add validate -->
 <script>
  function addValidateForm(){
    $("#createbtn").prop('disabled', true);
    var err =0;

         var company_id = document.getElementById("company_id").value.trim();
        if (company_id === "") {
            document.getElementById('company_id_err').innerHTML = 'Component Name is required...!';
            err++;
        } else {
            document.getElementById('company_id_err').innerHTML = '';
        }
        
        
      

    if(err>0){
        $("#createbtn").prop('disabled', false);
        return false;
       }else{
          $("#createbtn").prop('disabled', true);
          $('#addForm').submit();
       }
  }
 </script>
  <!-- edit Validate -->
  <script>
  function openEditModal(id,company_id,image,letterHeadimage){ 
   
        $('#edit_id').val(id);
        $('#company_id_edit').val(company_id).change();

        let defaultImage = "https://placehold.net/default.png";

        let imgPath = image 
            ? `/settings/payslip_template/${image}` 
            : defaultImage;

        let letterHeadPath = image 
            ? `/settings/letter_head/${letterHeadimage}` 
            : defaultImage;

        $('#uploadedlogo_edit').attr('src', imgPath);
        $('#uploadedlogo_edit_letter').attr('src', letterHeadPath);

  }
  function editValidateForm(){
    var err =0;
        
        var company_id_edit = document.getElementById("company_id_edit").value.trim();
        if (company_id_edit === "") {
            document.getElementById('company_id_edit_err').innerHTML = 'Company Name is required...!';
            err++;
        } else {
            document.getElementById('company_id_edit_err').innerHTML = '';
        }

        

    if(err>0){
        $("#updatebtn").prop('disabled', false);
        return false;
       }else{
          $("#updatebtn").prop('disabled', true);
          $('#updateForm').submit();
       }
  }
 </script>
<script>
    const fileInput = document.getElementById('upload');
    const previewImg = document.getElementById('uploadedlogo');
    const removeBtn = document.getElementById('removeImage');

    const defaultImage = "https://placehold.net/default.png";

    // Preview image
    fileInput.addEventListener('change', function () {
        const file = this.files[0];

        if (!file) return;

        // Validate size (800KB)
        if (file.size > 800 * 1024) {
            alert("File size should be less than 800KB");
            fileInput.value = "";
            return;
        }

        // Validate type
        if (!['image/jpeg', 'image/png'].includes(file.type)) {
            alert("Only JPG & PNG allowed");
            fileInput.value = "";
            return;
        }

        previewImg.src = URL.createObjectURL(file);
    });

    // Remove image
    removeBtn.addEventListener('click', function () {
        fileInput.value = "";
        previewImg.src = defaultImage;
    });
  
</script>
<script>
const fileInputEdit = document.getElementById('upload_edit');
const previewImgEdit = document.getElementById('uploadedlogo_edit');
const removeBtnEdit = document.getElementById('removeImage_edit');

const defaultImageEdit = "https://placehold.net/default.png";

// Preview image (EDIT)
fileInputEdit.addEventListener('change', function () {
    const file = this.files[0];

    if (!file) return;

    // Validate size
    if (file.size > 800 * 1024) {
        alert("File size should be less than 800KB");
        fileInputEdit.value = "";
        return;
    }

    // Validate type
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
        alert("Only JPG & PNG allowed");
        fileInputEdit.value = "";
        return;
    }

    previewImgEdit.src = URL.createObjectURL(file);
});

// Remove image (EDIT)
removeBtnEdit.addEventListener('click', function () {
    fileInputEdit.value = "";
    previewImgEdit.src = defaultImageEdit;
});
</script>
<script>
    const fileInputLetter = document.getElementById('letter_head_upload');
    const previewImgLetter = document.getElementById('letterUploadedlogo');
    const removeBtnLetter = document.getElementById('removeImageLetter');

    const defaultImageLetter = "https://placehold.net/default.png";

    // Preview image
    fileInputLetter.addEventListener('change', function () {
        const file = this.files[0];

        if (!file) return;

        // Validate size (800KB)
        if (file.size > 800 * 1024) {
            alert("File size should be less than 800KB");
            fileInputLetter.value = "";
            return;
        }

        // Validate type
        if (!['image/jpeg', 'image/png'].includes(file.type)) {
            alert("Only JPG & PNG allowed");
            fileInputLetter.value = "";
            return;
        }

        previewImgLetter.src = URL.createObjectURL(file);
    });

    // Remove image
    removeBtnLetter.addEventListener('click', function () {
        fileInputLetter.value = "";
        previewImgLetter.src = defaultImageLetter;
    });
  
</script>
<script>
const fileInputEditLetter = document.getElementById('upload_edit_letter');
const previewImgEditLetter = document.getElementById('uploadedlogo_edit_letter');
const removeBtnEditLetter = document.getElementById('removeImage_edit_letter');

const defaultImageEditLetter = "https://placehold.net/default.png";

// Preview image (EDIT)
fileInputEditLetter.addEventListener('change', function () {
    const file = this.files[0];

    if (!file) return;

    // Validate size
    if (file.size > 800 * 1024) {
        alert("File size should be less than 800KB");
        fileInputEditLetter.value = "";
        return;
    }

    // Validate type
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
        alert("Only JPG & PNG allowed");
        fileInputEditLetter.value = "";
        return;
    }

    previewImgEditLetter.src = URL.createObjectURL(file);
});

// Remove image (EDIT)
removeBtnEditLetter.addEventListener('click', function () {
    fileInputEditLetter.value = "";
    previewImgEditLetter.src = defaultImageEditLetter;
});
</script>
@endsection
