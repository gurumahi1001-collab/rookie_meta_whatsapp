@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Pay Component')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
    .credential-wrapper {
        min-height: 70vh;
    }

    /* Sidebar */
    .tab-sidebar {
        width: 280px;
        transition: all 0.3s ease;
        background: #fff;
        border-left: 1px solid #ddd;
    }

    .tab-sidebar.collapsed {
        width: 60px;
    }

    .tab-sidebar .nav-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
    }

    .tab-sidebar .nav-link i {
        font-size: 22px;
    }

    .nav-align-sideright .nav-link.active>label {
        background-color: #cfcfcf;
        color: #000;
        padding: 5px 8px;
        border-radius: 5px;
    }

    .tab-sidebar ul {
        /* align-items: end; */
    }


    /* Hide text when collapsed */
    .tab-sidebar.collapsed .tab-text {
        display: none;
    }

    .tab-sidebar.collapsed ul {
        align-items: center;
    }

    /* Toggle button */
    .toggle-btn {
        position: absolute;
        top: 15px;
        right: -15px;
        z-index: 10;
        background: #ab2b22;
        color: #fff;
        border: none;
        width: 30px;
        height: 30px;
        border-radius: 50%;
    }

    /* When sidebar collapsed */
    .tab-sidebar.collapsed+.tab-content .toggle-btn {
        right: -15px;
    }

    .tab-sidebar .right_nav {
        cursor: pointer !important;
        width: 100%;
        display: flex;
        justify-content: end;
        align-items: center;
        gap: 4px;
    }

    .tab-sidebar .right_nav:hover {
        color: #ab2b22 !important;
    }
</style>
<!-- Users List Table -->
<div class="card">
    <div class="card-header pb-1">
        <ul class="nav nav-tabs flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                            class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>

                <div class="scroll-container" id="scrollContainer">
                    <li class="item nav-item">
                        <a href="{{ url('/settings/general_settings') }}"
                            type="button"
                            class="nav-link scroll-link "
                            role="tab">
                            General Settings
                        </a>
                    </li>
                    <li class="item nav-item">
                        <a
                            href="{{ url('/settings/broadcast_theme') }}"
                            type="button"
                            class="nav-link scroll-link "
                            aria-selected="true">
                            Common
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/credential_book') }}" type="button"
                            class="nav-link scroll-link ">
                            Entity
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                            HRM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/rule_category') }}" type="button"
                            class="nav-link scroll-link active">
                            Payroll
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/applicant_status') }}" type="button"
                            class="nav-link scroll-link ">
                            Recruitment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/interview_mode') }}" type="button"
                            class="nav-link scroll-link ">
                            Interview
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                            class="nav-link scroll-link">
                            Assessment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/business/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Business
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/settings/api_config') }}" type="button"
                            class="nav-link scroll-link ">
                            API Config
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/admin/webhooks') }}" type="button"
                            class="nav-link scroll-link ">
                            Webhook Moniter
                        </a>
                    </li>
                </div>
                <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                        class="mdi mdi-chevron-right fs-2 text-white"></i></button>
            </div>
        </ul>
    </div>
    <div class="card-body px-1 py-1">
        <div class="d-flex credential-wrapper">
            <!-- CONTENT -->
            <div class="tab-content flex-grow-1 position-relative">
                <!-- Toggle Button -->
                <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                    <i class="mdi mdi-chevron-right"></i>
                </button>

                <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                    <div class="d-flex flex-column align-items-start">
                        <h5 class="card-title mb-1 text-black">Pay Component</h5>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb custom-breadcrumb">
                                <!-- Home -->
                                <li class="breadcrumb-item">
                                    <a href="{{ url('/dashboard') }}">
                                        <i class="mdi mdi-cog"></i> Settings
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="javascript:void(0);">Payroll </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <a href="javascript:void(0);" class="active-link">
                                        Pay Component
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                        <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_add_category">
                            <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Pay Component
                        </a>
                    </div>

                </div>
                <div class="card-body">

                    <div class="row g-4">

                        <div class="col-lg-6">

                            <h5 class="text-success mb-3">
                                Earnings
                            </h5>

                            <div id="earning_list"></div>

                        </div>

                        <div class="col-lg-6">

                            <h5 class="text-danger mb-3">
                                Deductions
                            </h5>

                            <div id="deduction_list"></div>

                        </div>

                        <div class="col-lg-6">

                            <h5 class="text-primary mb-3">
                                Employer Contributions
                            </h5>

                            <div id="employer_contribution_list"></div>

                        </div>

                        <!-- <div class="col-lg-6">

                            <h5 class="text-warning mb-3">
                                Reimbursements
                            </h5>

                            <div id="reimbursement_list"></div>

                        </div> -->

                    </div>

                </div>
            </div>
            <!-- SIDEBAR -->
            <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                <ul class="nav nav-tabs flex-column" role="tablist">
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/rule_category') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Payroll Rule</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Rule"><i class="mdi mdi-clipboard-text-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payroll_salary_component') }}" class="nav-link active" role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Salary Component</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Salary Component"><i class="mdi mdi-cog-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payslip_templates') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">payslip Template</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Rule Category -->
<div class="modal fade" id="kt_modal_add_category" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <div class="modal-header">
                <h3 class="text-black">Create Pay Component</h3>
                <div class="btn btn-sm btn-icon" data-bs-dismiss="modal"><i class="mdi mdi-close fs-2"></i>
                </div>
            </div>

            <div class="modal-body px-10 pb-10">
                <div class="row">
                    <!-- NAME -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Component Name</label>
                        <input type="text" class="form-control" id="component_name">
                        <small class="text-danger" id="err_component_name"></small>
                    </div>
                    <!-- CODE -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Component Code</label>
                        <input type="text" class="form-control" id="component_code">
                        <small class="text-danger" id="err_component_code"></small>
                    </div>
                    <!-- CATEGORY -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Category</label>
                        <select class="form-select select3" id="category">
                            <option value="earning">Earning</option>
                            <option value="deduction">Deduction</option>
                            <option value="employer_contribution">Employer Contribution</option>
                            <option value="reimbursement">Reimbursement</option>
                        </select>
                    </div>
                    <!-- CALCULATION -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Calculation Type</label>
                        <select class="form-select select3" id="calculation_type" onchange="toggleCalculationFields()">
                            <option value="fixed">Fixed</option>
                            <option value="percentage">Percentage</option>
                            <option value="formula">Formula</option>
                            <option value="manual_input">Manual Input</option>
                        </select>
                    </div>
                    <!-- PERCENTAGE -->
                    <div class="col-lg-6 mb-4 d-none" id="percentage_div">
                        <label class="fw-semibold mb-1">Percentage Value</label>
                        <input type="number" class="form-control" id="percentage_value">
                    </div>
                    <!-- FORMULA -->
                    <div class="col-lg-12 mb-4 d-none" id="formula_div">
                        <label class="fw-semibold mb-1">Formula Expression</label>
                        <textarea class="form-control" id="formula_expression"></textarea>
                    </div>
                    <!-- RULE -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Payroll Rule</label>
                        <select class="form-select select3" id="rule_id">
                            <option value="">No Rule</option>
                            @foreach($rules as $rule)
                            <option value="{{ $rule->id }}">{{ $rule->rule_name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <!-- DISPLAY ORDER -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Display Order</label>
                        <input type="number" class="form-control" id="display_order" value="0">
                    </div>
                </div>
                <!-- FLAGS -->
                <div class="row mt-3 mb-4">
                    <div class="col-lg-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="taxable" checked>
                            <label class="form-check-label">
                                Taxable
                            </label>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="lop_applicable" checked>
                            <label class="form-check-label">LOP Applicable</label>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="variable_component">
                            <label class="form-check-label">Variable</label>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="include_in_payslip" checked>
                            <label class="form-check-label">Payslip</label>
                        </div>
                    </div>
                </div>
                <!-- BUTTON -->
                <div class="text-end">
                    <button type="button" class="btn btn-primary" onclick="saveData()" id="createbtn">Create Component</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::Modal - Add  Rule Category-->


<!--begin::Modal - Update Rule Category -->
<!-- Update Payroll Component Modal -->
<div class="modal fade" id="kt_modal_update_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded">
            <!-- Header -->
            <div class="modal-header border-bottom pb-3">
                <h3 class="text-black mb-0">Update Pay Component</h3>
                <div class="btn btn-sm btn-icon rounded border border-dark"
                    data-bs-dismiss="modal">
                    <i class="mdi mdi-close fs-4 text-black"></i>
                </div>
            </div>

            <!-- Body -->
            <div class="modal-body pt-5 pb-8 px-8">
                <input type="hidden" id="edit_id">
                <div class="row">
                    <!-- Component Name -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Component Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name_edit" placeholder="Enter Component Name">
                        <small class="text-danger" id="err_name_edit"></small>
                    </div>
                    <!-- Component Code -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Component Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control text-uppercase" id="code_edit" placeholder="Enter Component Code">
                        <small class="text-danger" id="err_code_edit"></small>
                    </div>
                    <!-- Category -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Category</label>
                        <select class="form-select select3" id="category_edit">
                            <option value="earning">Earning</option>
                            <option value="deduction">Deduction</option>
                            <option value="employer_contribution">Employer Contribution</option>
                            <option value="reimbursement">Reimbursement</option>
                        </select>
                    </div>
                    <!-- Calculation Type -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Calculation Type</label>
                        <select class="form-select select3" id="calc_edit" onchange="toggleEditCalculationFields()">
                            <option value="fixed">Fixed</option>
                            <option value="percentage">Percentage</option>
                            <option value="formula">Formula</option>
                            <option value="manual_input">Manual Input</option>
                        </select>
                    </div>
                    <!-- Percentage -->
                    <div class="col-lg-6 mb-4 percentage_box_edit d-none">
                        <label class="fw-semibold mb-1">Percentage Value</label>
                        <input type="number" class="form-control" id="percentage_value_edit" placeholder="Enter Percentage">
                    </div>
                    <!-- Formula -->
                    <div class="col-lg-12 mb-4 formula_box_edit d-none">
                        <label class="fw-semibold mb-1">Formula Expression</label>
                        <textarea class="form-control" rows="3" id="formula_expression_edit" placeholder="Enter Formula"></textarea>
                    </div>

                    <!-- Rule -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">
                            Payroll Rule
                        </label>
                        <select class="form-select select3" id="rule_id_edit">
                            <option value="">No Rule</option>
                            @foreach($rules as $rule)
                            <option value="{{ $rule->id }}">
                                {{ $rule->rule_name }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <!-- Display Order -->
                    <div class="col-lg-6 mb-4">
                        <label class="fw-semibold mb-1">Display Order</label>
                        <input type="number" class="form-control" id="display_order_edit" placeholder="Display Order">
                    </div>
                </div>
                <!-- Switches -->
                <div class="row mt-2">
                    <div class="col-lg-3 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="taxable_edit">
                            <label class="form-check-label">Taxable</label>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="lop_applicable_edit">
                            <label class="form-check-label">LOP Applicable</label>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="include_in_ctc_edit">
                            <label class="form-check-label">Include In CTC</label>
                        </div>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="include_in_payslip_edit">
                            <label class="form-check-label">
                                Include In Payslip
                            </label>
                        </div>
                    </div>
                </div>
                <!-- Footer -->
                <div class="d-flex justify-content-end mt-5">
                    <button type="button" class="btn btn-primary" id="updatebtn" onclick="updateData()">Update Component</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!--end::Modal -->

<!--begin::Modal - Delete Rule Category-->
<div class="modal fade" id="kt_modal_delete_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Attendance </b>
                    Pay Component ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Rule Category-->




<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item, index) {
        return `
            <tr>

                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <label class="fs-7 fw-medium">${item.component_name}</label>
                    <a href="#" data-bs-toggle="tooltip"
                        data-bs-placement="right" title="${item.component_type || '-'}">
                        <i class="mdi mdi mdi-help-circle text-dark"></i>
                    </a>
                </td>
                <td><label class="fs-7 fw-medium">${item.component_code || '-'}</label></td>
                <td><label class="fs-7 fw-medium">${item.component_type || '-'}</label></td>
                <td><label class="fs-7 fw-medium">${item.is_taxable ? 'Yes':'No'}</label></td>
                <td><label class="fs-7 fw-medium">${item.is_statutory ? 'Yes':'No'}</label></td>
                <td><label class="fs-7 fw-medium">${item.show_in_payslip ? 'Yes':'No'}</label></td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                       
                    <button class="btn btn-icon btn-sm"
                        type="button"
                        data-bs-toggle="modal"
                        data-bs-target="#kt_modal_update_rule_category"
                        title="Edit"
                        onclick="openEditModal('${item.sno}')">

                        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                    </button>
                        <button class="btn btn-icon btn-sm" type="button" 
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_rule_category"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Delete"  onclick="confirmDelete('${item.sno}', '${item.component_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = 25;
        const search = '';
        const url = `/settings/payroll_component?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });
                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(9));
                }
                $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(col) {
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // loadThemes(1);
</script>

<!-- status Change -->
<script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/salary_component_status_change/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadUI(1);
                    // location.reload();
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
    function confirmDelete(id, name) {

        document.querySelector('#kt_modal_delete_rule_category .btn-danger').setAttribute('data-id', id);
        $('#delete_message').html(
            'Are you sure you want to delete <b class="text-danger">' +
            name +
            '</b> Salary Component ?');
    }

    function deleteFunc() {
        var categoryId = document.querySelector('#kt_modal_delete_rule_category .btn-danger').getAttribute('data-id');

        fetch('/salary_component_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {

            });
    }
</script>

<!-- add validate -->
<script>
    function addValidateForm() {
        $("#createbtn").prop('disabled', true);
        var err = 0;

        var component_name = document.getElementById("component_name").value.trim();
        if (component_name === "") {
            document.getElementById('component_name_err').innerHTML = 'Component Name is required...!';
            err++;
        } else {
            document.getElementById('component_name_err').innerHTML = '';
        }

        var component_code = document.getElementById("component_code").value.trim();
        if (component_code === "") {
            document.getElementById('component_code_err').innerHTML = 'Component Code is required...!';
            err++;
        } else {
            document.getElementById('component_code_err').innerHTML = '';
        }

        var component_type = document.getElementById("component_type").value.trim();
        if (component_type === "") {
            document.getElementById('component_type_err').innerHTML = 'Component Type is required...!';
            err++;
        } else {
            document.getElementById('component_type_err').innerHTML = '';
        }


        if (err > 0) {
            $("#createbtn").prop('disabled', false);
            return false;
        } else {
            $("#createbtn").prop('disabled', true);
            $('#addForm').submit();
        }
    }
</script>
<!-- edit Validate -->
<script>
    // Open Edit Modal
    function openEditModal(id) {

        $('#edit_id').val(id);
        $.ajax({
            url: '/salary-components/edit',
            type: 'GET',
            data: {
                id: id
            },
            success: function(res) {
                if (res.status == 200) {
                    let row = res.data;
                    $('#name_edit').val(row.component_name);
                    $('#code_edit').val(row.component_code);
                    $('#category_edit').val(row.category).trigger('change');
                    $('#calc_edit').val(row.calculation_type).trigger('change');
                    $('#percentage_value_edit').val(row.percentage_value);
                    $('#formula_expression_edit').val(row.formula_expression);
                    $('#rule_id_edit').val(row.rule_id).trigger('change');
                    $('#display_order_edit').val(row.display_order);
                    $('#taxable_edit').prop('checked', row.taxable == 1);
                    $('#lop_applicable_edit').prop('checked', row.lop_applicable == 1);
                    $('#include_in_ctc_edit').prop('checked', row.include_in_ctc == 1);
                    $('#include_in_payslip_edit').prop('checked', row.include_in_payslip == 1);

                }
            }
        });
    }





    // Update Data
    function updateData() {

        $('#updatebtn').prop('disabled', true);

        let err = 0;
        let name = $('#name_edit').val().trim();
        let code = $('#code_edit').val().trim();
        if (!name) {
            $('#err_name_edit').text('Component Name Required');
            err++;
        } else {
            $('#err_name_edit').text('');
        }

        if (!code) {
            $('#err_code_edit').text('Component Code Required');
            err++;
        } else {
            $('#err_code_edit').text('');
        }

        if (err > 0) {
            $('#updatebtn').prop('disabled', false);
            return;
        }

        $.ajax({
            url: '/salary-components/update',
            type: 'POST',
            data: {
                sno: $('#edit_id').val(),
                component_name: name,
                component_code: code.toUpperCase(),
                category: $('#category_edit').val(),
                calculation_type: $('#calc_edit').val(),
                percentage_value: $('#percentage_value_edit').val(),
                formula_expression: $('#formula_expression_edit').val(),
                rule_id: $('#rule_id_edit').val(),
                display_order: $('#display_order_edit').val(),
                taxable: $('#taxable_edit').is(':checked') ? 1 : 0,
                lop_applicable: $('#lop_applicable_edit').is(':checked') ? 1 : 0,
                include_in_ctc: $('#include_in_ctc_edit').is(':checked') ? 1 : 0,
                include_in_payslip: $('#include_in_payslip_edit').is(':checked') ? 1 : 0,
                _token: '{{ csrf_token() }}'
            },
            success: function(res) {
                $('#updatebtn').prop('disabled', false);
                if (res.status == 200) {
                    $('#kt_modal_update_rule_category').modal('hide');
                    toastr.success(res.message);
                    loadUI();
                } else {
                    toastr.error(res.message);
                }
            },
            error: function() {
                $('#updatebtn').prop('disabled', false);
                toastr.error('Something went wrong');
            }
        });
    }
</script>
<script>
    function renderUI(data) {

        let earningHTML = '';
        let deductionHTML = '';
        let employerHTML = '';
        let reimbursementHTML = '';

        data.forEach(row => {

            let card = buildComponentCard(row);

            if (row.category === 'earning') {

                earningHTML += card;

            } else if (row.category === 'deduction') {

                deductionHTML += card;

            } else if (row.category === 'employer_contribution') {

                employerHTML += card;

            } else if (row.category === 'reimbursement') {

                reimbursementHTML += card;
            }

        });

        $('#earning_list').html(
            earningHTML || noDataCard('No earnings components')
        );

        $('#deduction_list').html(
            deductionHTML || noDataCard('No deduction components')
        );

        $('#employer_contribution_list').html(
            employerHTML || noDataCard('No employer contributions')
        );

        // $('#reimbursement_list').html(
        //     reimbursementHTML || noDataCard('No reimbursement components')
        // );
    }

    function buildComponentCard(row) {

        return `
            <div class="card border-0 shadow-sm payroll-card mb-3">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <div class="fw-bold fs-5 text-dark">
                                ${row.component_name}
                            </div>

                            <div class="text-muted fs-7">
                                ${row.component_code}
                            </div>

                        </div>

                        <div class="form-check form-switch">

                            <input class="form-check-input"
                                type="checkbox"
                                onchange="updatelevelStatus('${row.sno}', this.checked)"
                                ${row.status == 0 ? 'checked' : ''}>
                        </div>

                    </div>

                    <div class="mt-3 d-flex flex-wrap gap-2">

                        <span class="badge bg-light-primary text-primary">
                            ${row.calculation_type}
                        </span>

                        ${row.taxable == 1
                            ? `<span class="badge bg-light-danger text-danger">Taxable</span>`
                            : ''
                        }

                        ${row.variable_component == 1
                            ? `<span class="badge bg-light-warning text-warning">Variable</span>`
                            : ''
                        }

                        ${row.lop_applicable == 1
                            ? `<span class="badge bg-light-info text-info">LOP</span>`
                            : ''
                        }

                        ${row.include_in_ctc == 1
                            ? `<span class="badge bg-light-success text-success">CTC</span>`
                            : ''
                        }

                        ${row.include_in_payslip == 1
                            ? `<span class="badge bg-light-dark text-dark">Payslip</span>`
                            : ''
                        }

                    </div>

                    <div class="mt-3">

                        ${
                            row.calculation_type === 'percentage'
                            ? `
                                <div class="text-muted fs-7">
                                    Percentage:
                                    <b>${row.percentage_value}%</b>
                                </div>
                            `
                            : ''
                        }

                        ${
                            row.calculation_type === 'formula'
                            ? `
                                <div class="text-muted fs-7 text-truncate">
                                    Formula:
                                    <b>${row.formula_expression ?? '-'}</b>
                                </div>
                            `
                            : ''
                        }

                    </div>

                    <div class="mt-4 d-flex justify-content-end gap-2">

                        <button type="button" class="btn btn-icon btn-sm" data-bs-toggle="modal"  data-bs-target="#kt_modal_update_rule_category"
                         title="Edit"    onclick="openEditModal('${row.sno}')">

                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>

                        </button>

                       
                      

                        <button class="btn btn-icon btn-sm"
                            onclick="confirmDelete('${row.sno}','${row.component_name}')">

                            <i class="mdi mdi-delete-outline fs-3 text-danger"></i>

                        </button>

                    </div>

                </div>

            </div>

            `;
    }

    function noDataCard(message = 'No Data Found') {

        return `
        <div class="card border-0 shadow-sm">

            <div class="card-body text-center py-5">

                <div class="mb-3">
                    <i class="mdi mdi-database-off-outline text-muted"
                        style="font-size: 48px;"></i>
                </div>

                <h6 class="text-muted mb-1">
                    ${message}
                </h6>

                <p class="text-muted fs-7 mb-0">
                    No payroll components available.
                </p>

            </div>

        </div>
        `;
    }

    function loadUI(page = 1) {

        let search = $('#search_filter').val();

        $.ajax({

            url: `/settings/payroll_salary_component?page=${page}`,

            type: 'GET',

            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },

            success: function(res) {

                renderUI(res.data);

            },

            error: function(err) {

                console.log(err);

            }

        });
    }



    loadUI();

    function saveData() {
        $('#createbtn').prop('disabled', true);

        $('.text-danger').html('');

        let component_name = $('#component_name').val().trim();
        let component_code = $('#component_code').val().trim();

        let err = 0;

        if (component_name === '') {
            $('#err_component_name').html('Component name required');
            err++;
        }

        if (component_code === '') {
            $('#err_component_code').html('Component code required');
            err++;
        }

        if (err > 0) {
            $('#createbtn').prop('disabled', false);
            return;
        }

        $.ajax({

            url: '/salary-components/store',

            type: 'POST',

            data: {

                component_name: component_name,

                component_code: component_code,

                category: $('#category').val(),

                calculation_type: $('#calculation_type').val(),

                percentage_value: $('#percentage_value').val(),

                formula_expression: $('#formula_expression').val(),

                rule_id: $('#rule_id').val(),

                display_order: $('#display_order').val(),

                taxable: $('#taxable').is(':checked') ? 1 : 0,

                lop_applicable: $('#lop_applicable').is(':checked') ? 1 : 0,

                variable_component: $('#variable_component').is(':checked') ? 1 : 0,

                include_in_payslip: $('#include_in_payslip').is(':checked') ? 1 : 0,

                _token: '{{ csrf_token() }}'
            },

            success: function(res) {
                $('#createbtn').prop('disabled', false);

                if (res.status == 200) {
                    $('#kt_modal_add_category').modal('hide');

                    loadUI();

                    toastr.success(res.message);
                } else {
                    toastr.error(res.message);
                }
            },

            error: function() {
                $('#createbtn').prop('disabled', false);

                toastr.error('Something went wrong');
            }

        });
    }
</script>
<script>
    function toggleCalculationFields() {
        let type = $('#calculation_type').val();

        $('#percentage_div').addClass('d-none');
        $('#formula_div').addClass('d-none');

        if (type === 'percentage') {
            $('#percentage_div').removeClass('d-none');
        }

        if (type === 'formula') {
            $('#formula_div').removeClass('d-none');
        }
    }




    function toggleEditCalculationFields() {
        let type = $('#calc_edit').val();

        $('.percentage_box_edit').addClass('d-none');
        $('.formula_box_edit').addClass('d-none');
        if (type == 'percentage') {
            $('.percentage_box_edit').removeClass('d-none');
        } else if (type == 'formula') {
            $('.formula_box_edit').removeClass('d-none');
        }
    }
</script>
@endsection