@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Pay Component')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
@vite(['resources/assets/js/form_wizard_icons.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/forms-pickers.js')
@vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection

@section('content')
<style>
    .credential-wrapper {
        min-height: 70vh;
    }

    /* Sidebar */
    .tab-sidebar {
        width: 280px;
        transition: all 0.3s ease;
        background: #fff;
        border-left: 1px solid #ddd;
    }

    .tab-sidebar.collapsed {
        width: 60px;
    }

    .tab-sidebar .nav-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px;
    }

    .tab-sidebar .nav-link i {
        font-size: 22px;
    }

    .nav-align-sideright .nav-link.active>label {
        background-color: #cfcfcf;
        color: #000;
        padding: 5px 8px;
        border-radius: 5px;
    }

    .tab-sidebar ul {
        /* align-items: end; */
    }


    /* Hide text when collapsed */
    .tab-sidebar.collapsed .tab-text {
        display: none;
    }

    .tab-sidebar.collapsed ul {
        align-items: center;
    }

    /* Toggle button */
    .toggle-btn {
        position: absolute;
        top: 15px;
        right: -15px;
        z-index: 10;
        background: #ab2b22;
        color: #fff;
        border: none;
        width: 30px;
        height: 30px;
        border-radius: 50%;
    }

    /* When sidebar collapsed */
    .tab-sidebar.collapsed+.tab-content .toggle-btn {
        right: -15px;
    }

    .tab-sidebar .right_nav {
        cursor: pointer !important;
        width: 100%;
        display: flex;
        justify-content: end;
        align-items: center;
        gap: 4px;
    }

    .tab-sidebar .right_nav:hover {
        color: #ab2b22 !important;
    }
</style>
<style>
    /* =========================
    PAYROLL COMPONENT V2 UI
========================= */

    .payroll-component-card {
        margin-bottom: 24px;
    }

    .payroll-component-card .card {
        border: none;
        border-radius: 24px;
        overflow: hidden;
        background: #fff;
        position: relative;
        transition: all .25s ease;
        box-shadow:
            0 4px 12px rgba(0, 0, 0, .04),
            0 2px 4px rgba(0, 0, 0, .02);
    }

    .payroll-component-card .card:hover {
        transform: translateY(-4px);
        box-shadow:
            0 14px 35px rgba(171, 43, 34, .12),
            0 6px 18px rgba(0, 0, 0, .06);
    }


    /* HEADER */
    .component-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 15px;
    }

    .component-left {
        display: flex;
        align-items: flex-start;
        gap: 16px;
        flex: 1;
    }

    .component-avatar {
        width: 40px;
        height: 40px;
        min-width: 40px;
        border-radius: 22px;
        background: linear-gradient(135deg, #ab2b22, #e74c3c);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        font-weight: 700;
        box-shadow: 0 8px 20px rgba(171, 43, 34, .25);
    }

    .component-title {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
    }



    /* TAGS */
    .component-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .component-chip {
        padding: 6px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .chip-code {
        background: #f3f4f6;
        color: #111827;
    }

    .chip-category {
        background: #eef4ff;
        color: #2563eb;
    }

    .chip-tax {
        background: #e9fff1;
        color: #0f9f4f;
    }

    .chip-nontax {
        background: #fff0f0;
        color: #dc2626;
    }

    .chip-earning {
        background: #dcfce7;
        color: #15803d;
    }

    .chip-deduction {
        background: #fee2e2;
        color: #b91c1c;
    }

    /* RIGHT SIDE */
    .component-right {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    /* STATUS SWITCH BOX */
    .status-box {
        /* background: #fafafa;
        border: 1px solid #f1f1f1;
        border-radius: 16px; */
        padding: 12px 16px;
        /* min-width: 120px; */
    }

    .status-title {
        font-size: 11px;
        color: #9ca3af;
        margin-bottom: 8px;
        font-weight: 600;
    }

    /* RULES */
    .rules-wrapper {
        margin-top: 22px;
    }

    .rules-title {
        font-size: 13px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 14px;
    }

    .rule-grid {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 12px;
    }

    .rule-item {
        background: #fafafa;
        border-radius: 16px;
        padding: 14px 10px;
        text-align: center;
        border: 1px solid #f4f4f4;
        transition: .2s;
    }

    .rule-item:hover {
        background: #fff;
        transform: translateY(-2px);
    }

    .rule-icon {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: auto;
        margin-bottom: 10px;
        font-size: 18px;
    }

    .rule-active {
        background: #e8fff1;
        color: #16a34a;
    }

    .rule-inactive {
        background: #fff0f0;
        color: #dc2626;
    }

    .rule-warning {
        background: #fff8e7;
        color: #f59e0b;
    }

    .rule-name {
        font-size: 12px;
        font-weight: 700;
        color: #374151;
    }

    /* FOOTER */
    .component-footer {
        margin-top: 24px;
        padding-top: 18px;
        border-top: 1px dashed #ececec;

        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
    }

    .component-meta {
        display: flex;
        align-items: center;
        gap: 30px;
        flex-wrap: wrap;
    }

    .meta-item label {
        display: block;
        font-size: 11px;
        color: #9ca3af;
        margin-bottom: 2px;
    }

    .meta-item span {
        font-size: 14px;
        font-weight: 700;
        color: #111827;
    }

    .action-group {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .payroll-action-btn {
        width: 42px;
        height: 42px;
        border: none;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: .2s;
    }

    .payroll-action-btn i {
        font-size: 20px;
    }

    .btn-edit {
        background: #eef4ff;
        color: #2563eb;
    }

    .btn-edit:hover {
        background: #2563eb;
        color: #fff;
    }

    .btn-delete {
        background: #fff1f2;
        color: #e11d48;
    }

    .btn-delete:hover {
        background: #e11d48;
        color: #fff;
    }

    /* EMPTY */
    .empty-data-card {
        background: #fff;
        border-radius: 20px;
        padding: 60px 20px;
        text-align: center;
        box-shadow: 0 4px 15px rgba(0, 0, 0, .04);
    }

    .empty-data-card i {
        font-size: 70px;
        color: #d1d5db;
        margin-bottom: 15px;
    }

    .empty-data-card h5 {
        font-weight: 700;
        color: #111827;
    }

    .empty-data-card p {
        color: #6b7280;
    }

    /* SKELETON */
    .payroll-skeleton {
        height: 270px;
        border-radius: 24px;
        background: linear-gradient(90deg,
                #f3f3f3 25%,
                #ececec 37%,
                #f3f3f3 63%);
        background-size: 400% 100%;
        animation: skeleton-loading 1.4s ease infinite;
    }

    @keyframes skeleton-loading {
        0% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0 50%;
        }
    }

    /* MOBILE */
    @media(max-width:991px) {

        .rule-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .component-header {
            flex-direction: column;
        }

        .component-right {
            width: 100%;
            justify-content: space-between;
        }

    }
</style>
<!-- Users List Table -->
<div class="card">
    <div class="card-header pb-1">
        <ul class="nav nav-tabs flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                            class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>

                <div class="scroll-container" id="scrollContainer">
                    <li class="item nav-item">
                        <a href="{{ url('/settings/general_settings') }}"
                            type="button"
                            class="nav-link scroll-link "
                            role="tab">
                            General Settings
                        </a>
                    </li>
                    <li class="item nav-item">
                        <a
                            href="{{ url('/settings/broadcast_theme') }}"
                            type="button"
                            class="nav-link scroll-link "
                            aria-selected="true">
                            Common
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/credential_book') }}" type="button"
                            class="nav-link scroll-link ">
                            Entity
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                            HRM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/rule_category') }}" type="button"
                            class="nav-link scroll-link active">
                            Payroll
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/applicant_status') }}" type="button"
                            class="nav-link scroll-link ">
                            Recruitment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/interview_mode') }}" type="button"
                            class="nav-link scroll-link ">
                            Interview
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                            class="nav-link scroll-link">
                            Assessment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/business/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Business
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/settings/api_config') }}" type="button"
                            class="nav-link scroll-link ">
                            API Config
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/admin/webhooks') }}" type="button"
                            class="nav-link scroll-link ">
                            Webhook Moniter
                        </a>
                    </li>
                </div>
                <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                        class="mdi mdi-chevron-right fs-2 text-white"></i></button>
            </div>
        </ul>
    </div>
    <div class="card-body px-1 py-1">
        <div class="d-flex credential-wrapper">
            <!-- CONTENT -->
            <div class="tab-content flex-grow-1 position-relative">
                <!-- Toggle Button -->
                <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                    <i class="mdi mdi-chevron-right"></i>
                </button>

                <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                    <div class="d-flex flex-column align-items-start">
                        <h5 class="card-title mb-1 text-black">Pay Component</h5>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb custom-breadcrumb">
                                <!-- Home -->
                                <li class="breadcrumb-item">
                                    <a href="{{ url('/dashboard') }}">
                                        <i class="mdi mdi-cog"></i> Settings
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="javascript:void(0);">Payroll </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <a href="javascript:void(0);" class="active-link">
                                        Pay Component
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                        <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_add_category">
                            <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Pay Component
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="d-flex align-items-center justify-content-between mb-4 ">
                            <div>
                                <span>Show</span>
                                <select id="perpage" class="form-select form-select-sm w-75px"
                                    onchange="loadThemes(1)">
                                    @php $options = [5,10, 25, 100, 500]; @endphp
                                    @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input type="text" id="search_filter" class="searchQueryInput"
                                        placeholder="Search Pay Component..."
                                        value="{{ $search_filter }}" />

                                    <div class="searchAction">
                                        <div class="d-flex align-items-center">
                                            <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                                <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                            </a>
                                            <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                                <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row" id="list-table-body">


                        </div>
                    </div>
                    <div class="text-center my-3" id="pagination-container">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>
            </div>
            <!-- SIDEBAR -->
            <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                <ul class="nav nav-tabs flex-column" role="tablist">
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/rule_category') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text"> Rule Category</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title=" Rule Category"><i class="mdi mdi-clipboard-text-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/rules') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Rule</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Rule"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payroll_setting') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text"> Payroll Settings</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title=" Payroll Settings"><i class="mdi mdi-cog-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payroll_component') }}" class="nav-link active" role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Payroll Component</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payslip_templates') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">payslip Template</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/salary-components-new') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Salary component</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Salary Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/payroll-settings-new') }}" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Payroll Setiing New</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Salary Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
    .component-form-card {
        background: #fff;
        border-radius: 20px;
        padding: 24px;
        border: 1px solid #f1f1f1;
        box-shadow: 0 4px 18px rgba(0, 0, 0, .04);
    }

    .form-section-title {
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 10px;
    }

    .section-icon {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        background: linear-gradient(135deg, #ab2b22, #d94b3f);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 20px;
    }

    .form-section-title h5 {
        font-weight: 700;
        color: #111827;
    }

    .form-section-title small {
        color: #6b7280;
    }

    .custom-label {
        font-weight: 700;
        color: #374151;
        margin-bottom: 8px;
    }





    .custom-select {
        height: 54px;
        border-radius: 14px;
        border: 1px solid #e5e7eb;
        font-weight: 600;
    }

    .custom-select:focus {
        border-color: #ab2b22;
        box-shadow: 0 0 0 4px rgba(171, 43, 34, .08);
    }

    .custom-check-card {
        width: 100%;
        border: 1px solid #ececec;
        border-radius: 18px;
        padding: 16px;
        cursor: pointer;
        transition: .25s ease;
        background: #fff;
        height: 100%;
    }

    .custom-check-card:hover {
        transform: translateY(-2px);
        border-color: #ab2b22;
        box-shadow: 0 10px 24px rgba(0, 0, 0, .05);
    }

    .custom-check-card input {
        display: none;
    }

    .custom-check-card span {
        display: flex;
        align-items: flex-start;
        gap: 14px;
    }

    .rule-icon {
        min-width: 44px;
        width: 44px;
        height: 44px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    .rule-icon.success {
        background: #e8fff1;
        color: #16a34a;
    }

    .rule-icon.warning {
        background: #fff8e7;
        color: #f59e0b;
    }

    .rule-icon.primary {
        background: #eef4ff;
        color: #2563eb;
    }

    .rule-icon.danger {
        background: #fff0f0;
        color: #dc2626;
    }

    .rule-icon.info {
        background: #ecfeff;
        color: #0891b2;
    }

    .rule-icon.dark {
        background: #f3f4f6;
        color: #111827;
    }

    .rule-title {
        font-size: 14px;
        font-weight: 700;
        color: #111827;
    }

    .custom-check-card small {
        color: #6b7280;
    }

    .custom-check-card input:checked+span .rule-title {
        color: #ab2b22;
    }

    .custom-check-card input:checked+span .rule-icon {
        transform: scale(1.06);
    }

    .error-text {
        font-size: 12px;
        margin-top: 6px;
        font-weight: 500;
    }



    .custom-bootstrap-check {
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 14px 16px;
        background: #fff;
        transition: all .2s ease;
        height: 100%;
    }

    .custom-bootstrap-check:hover {
        border-color: #ab2b22;
        box-shadow: 0 4px 12px rgba(171, 43, 34, .08);
    }

    .custom-bootstrap-check .form-check-input {
        width: 20px;
        height: 20px;
        margin-top: 2px;
        cursor: pointer;
    }

    .custom-bootstrap-check .form-check-label {
        width: 100%;
        cursor: pointer;
        margin-left: 10px;
    }

    .rule-icon {
        width: 42px;
        height: 42px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
    }

    .bg-success-subtle {
        background: #e8fff1;
    }

    .bg-warning-subtle {
        background: #fff8e7;
    }

    .bg-primary-subtle {
        background: #eef4ff;
    }

    .bg-danger-subtle {
        background: #fff0f0;
    }

    .bg-info-subtle {
        background: #eefcff;
    }

    .bg-dark-subtle {
        background: #f3f4f6;
    }

    .form-check .form-check-input {
        float: none !important;
        margin-left: 0 !important;
    }
</style>

<div class="modal fade" id="kt_modal_add_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Pay Component</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <form id="addForm">
                    @csrf
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Component Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-lg" id="component_name" name="component_name" placeholder="Basic Salary">
                            <div class="text-danger error-text" id="component_name_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Component Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-lg text-uppercase" id="component_code" name="component_code" placeholder="BASIC" onkeyup="this.value = this.value.toUpperCase()">
                            <div class="text-danger error-text" id="component_code_err"></div>

                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Category<span
                                    class="text-danger">*</span></label>
                            <select name="category" class="form-control select3 " id="category">
                                <option value="">Select Category</option>
                                <option value="earning">Earning</option>
                                <option value="deduction">Deduction</option>
                                <option value="employer_contribution">Employer Contribution</option>
                                <option value="reimbursement">Reimbursement</option>
                                <option value="statutory">Statutory</option>
                            </select>
                            <div class="text-danger error-text" id="category_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Component Type<span
                                    class="text-danger">*</span></label>
                            <select name="component_type" class="form-control select3 " id="component_type">
                                <option value="">Select Type</option>
                                <option value="fixed">Fixed</option>
                                <option value="percentage">Percentage</option>
                                <option value="formula">Formula</option>
                                <option value="dynamic">Dynamic</option>
                            </select>
                            <div class="text-danger error-text" id="component_type_err"></div>
                        </div>

                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Display Order</label>
                            <div>

                                <input type="number" class="form-control custom-input" id="display_order" name="display_order" placeholder="1" min="0">

                            </div>
                        </div>

                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Effective From</label>
                            <div class="">
                                <input type="text" class="form-control custom-input common_datepicker" id="effective_from" name="effective_from" placeholder="DD-MM-YYYY" autocomplete="off">
                            </div>
                            <div class="text-danger error-text" id="effective_from_err"></div>
                        </div>


                        <div class="col-12">
                            <div class="card border rounded-4 shadow-sm">
                                <div class="card-body">

                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div>
                                            <h5 class="mb-0 fw-bold text-dark">
                                                Component Rules
                                            </h5>
                                            <small class="text-muted">
                                                Configure payroll rule applicability
                                            </small>
                                        </div>
                                    </div>

                                    <div class="row g-3">

                                        <!-- TAXABLE -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="taxable"
                                                    id="taxable"
                                                    value="1"
                                                    checked>

                                                <label class="form-check-label" for="taxable">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-success-subtle text-success">
                                                            <i class="mdi mdi-cash-check"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                Taxable
                                                            </div>

                                                            <small class="text-muted">
                                                                Included in tax calculation
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- LOP -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="prorate_on_lop"
                                                    id="prorate_on_lop"
                                                    value="1"
                                                    checked>

                                                <label class="form-check-label" for="prorate_on_lop">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-warning-subtle text-warning">
                                                            <i class="mdi mdi-calendar-remove"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                LOP Prorated
                                                            </div>

                                                            <small class="text-muted">
                                                                Adjust salary for leave
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- PF -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_pf"
                                                    id="affects_pf"
                                                    value="1">

                                                <label class="form-check-label" for="affects_pf">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-primary-subtle text-primary">
                                                            <i class="mdi mdi-shield-check"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                PF Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Provident fund enabled
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- ESI -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_esi"
                                                    id="affects_esi"
                                                    value="1">

                                                <label class="form-check-label" for="affects_esi">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-danger-subtle text-danger">
                                                            <i class="mdi mdi-medical-bag"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                ESI Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Employee state insurance
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- PT -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_pt"
                                                    id="affects_pt"
                                                    value="1">

                                                <label class="form-check-label" for="affects_pt">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-info-subtle text-info">
                                                            <i class="mdi mdi-bank"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                PT Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Professional tax enabled
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- TDS -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_tds"
                                                    id="affects_tds"
                                                    value="1">

                                                <label class="form-check-label" for="affects_tds">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-dark-subtle text-dark">
                                                            <i class="mdi mdi-file-percent"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                TDS Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Tax deduction at source
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>

                        <button type="button" id="createbtn" class="btn btn-primary" onclick="addValidateForm()">
                            <span class="default-text">
                                <i class="mdi mdi-plus-circle-outline me-1"></i>
                                Create Component
                            </span>

                            <span class="loading-text d-none">
                                <span class="spinner-border spinner-border-sm me-2"></span>
                                Creating...
                            </span>
                        </button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Rule Category-->


<!--begin::Modal - Update Rule Category -->
<div class="modal fade" id="kt_modal_update_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Pay Component</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <form id="updateForm">
                    @csrf
                    <div class="row">
                        <!-- Basic -->
                        <input type="hidden" name="edit_id" id="edit_id">
                        <!-- COMPONENT NAME -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">Component Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-lg custom-input" id="component_name_edit" name="component_name" placeholder="Basic Salary">
                            <div class="text-danger error-text " id="component_name_edit_err"></div>
                        </div>
                        <!-- COMPONENT CODE -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">
                                Component Code
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control form-control-lg custom-input text-uppercase" id="component_code_edit" name="component_code" placeholder="BASIC" onkeyup="this.value=this.value.toUpperCase()">
                            <div class="text-danger error-text " id="component_code_edit_err"></div>
                        </div>
                        <!-- CATEGORY -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">Category<span class="text-danger">*</span></label>
                            <select name="category" class="form-select select3" id="category_edit">
                                <option value="">Select Category</option>
                                <option value="earning">Earning</option>
                                <option value="deduction"> Deduction</option>
                                <option value="employer_contribution">Employer Contribution</option>
                                <option value="reimbursement">Reimbursement</option>
                                <option value="statutory">Statutory</option>
                            </select>
                            <div class="text-danger error-text " id="category_edit_err"></div>
                        </div>
                        <!-- COMPONENT TYPE -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">Component Type<span class="text-danger">*</span> </label>
                            <select name="component_type" class="form-select select3" id="component_type_edit">
                                <option value="">Select Type</option>
                                <option value="fixed">Fixed</option>
                                <option value="percentage">Percentage</option>
                                <option value="formula">Formula</option>
                                <option value="dynamic">Dynamic</option>
                            </select>
                            <div class="text-danger error-text" id="component_type_edit_err"></div>
                        </div>
                        <!-- DISPLAY ORDER -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">Display Order</label>
                            <input type="number" class="form-control form-control-lg custom-input" id="display_order_edit" name="display_order" min="0" placeholder="1">
                        </div>
                        <!-- EFFECTIVE FROM -->
                        <div class="col-lg-6">
                            <label class="form-label fw-semibold text-dark">Effective From</label>
                            <input type="text" class="form-control form-control-lg custom-input common_datepicker" id="effective_from_edit" name="effective_from" placeholder="DD-MM-YYYY" autocomplete="off">
                            <div class="text-danger error-text " id="effective_from_edit_err"></div>
                        </div>

                        <div class="col-12">
                            <div class="card border rounded-4 shadow-sm">
                                <div class="card-body">

                                    <div class="d-flex align-items-center justify-content-between mb-4">
                                        <div>
                                            <h5 class="mb-0 fw-bold text-dark">
                                                Component Rules
                                            </h5>
                                            <small class="text-muted">
                                                Configure payroll rule applicability
                                            </small>
                                        </div>
                                    </div>

                                    <div class="row g-3">

                                        <!-- TAXABLE -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="taxable"
                                                    id="taxable_edit"
                                                    value="1"
                                                    checked>

                                                <label class="form-check-label" for="taxable_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-success-subtle text-success">
                                                            <i class="mdi mdi-cash-check"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                Taxable
                                                            </div>

                                                            <small class="text-muted">
                                                                Included in tax calculation
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- LOP -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="prorate_on_lop"
                                                    id="prorate_on_lop_edit"
                                                    value="1"
                                                    checked>

                                                <label class="form-check-label" for="prorate_on_lop_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-warning-subtle text-warning">
                                                            <i class="mdi mdi-calendar-remove"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                LOP Prorated
                                                            </div>

                                                            <small class="text-muted">
                                                                Adjust salary for leave
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- PF -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_pf"
                                                    id="affects_pf_edit"
                                                    value="1">

                                                <label class="form-check-label" for="affects_pf_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-primary-subtle text-primary">
                                                            <i class="mdi mdi-shield-check"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                PF Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Provident fund enabled
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- ESI -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_esi"
                                                    id="affects_esi_edit"
                                                    value="1">

                                                <label class="form-check-label" for="affects_esi_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-danger-subtle text-danger">
                                                            <i class="mdi mdi-medical-bag"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                ESI Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Employee state insurance
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- PT -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_pt"
                                                    id="affects_pt_edit"
                                                    value="1">

                                                <label class="form-check-label" for="affects_pt_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-info-subtle text-info">
                                                            <i class="mdi mdi-bank"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                PT Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Professional tax enabled
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- TDS -->
                                        <div class="col-lg-4 col-md-6">
                                            <div class="form-check custom-bootstrap-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="affects_tds"
                                                    id="affects_tds_edit"
                                                    value="1">

                                                <label class="form-check-label" for="affects_tds_edit">
                                                    <div class="d-flex align-items-center gap-2">
                                                        <div class="rule-icon bg-dark-subtle text-dark">
                                                            <i class="mdi mdi-file-percent"></i>
                                                        </div>

                                                        <div>
                                                            <div class="fw-semibold">
                                                                TDS Applicable
                                                            </div>

                                                            <small class="text-muted">
                                                                Tax deduction at source
                                                            </small>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="updatebtn" class="btn btn-primary" onclick="editValidateForm()">
                            <span class="default-text">
                                <i class="mdi mdi-content-save-outline me-1"></i>
                                Update Component
                            </span>
                            <span class="loading-text d-none">
                                <span class="spinner-border spinner-border-sm me-2"></span>
                                Updating...
                            </span>
                        </button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal -->

<!--begin::Modal - Delete Rule Category-->
<div class="modal fade" id="kt_modal_delete_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Attendance </b>
                    Pay Component ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Rule Category-->




<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    // function buildRow(item, index) {
    //     return `
    //         <tr>

    //             <td><label class="fs-7 fw-medium">${index}</label></td>
    //              <td>
    //                 <div class="d-flex flex-column">

    //                     <span class="fw-bold text-dark">
    //                         ${item.component_name || '-'}
    //                     </span>

    //                     <small class="text-muted">
    //                         ${item.component_type || '-'}
    //                     </small>

    //                 </div>
    //             </td>

    //             <td>
    //                 <span class="badge bg-label-dark">
    //                     ${item.component_code || '-'}
    //                 </span>
    //             </td>

    //             <td>
    //                 <span class="badge bg-label-primary">
    //                     ${item.category || '-'}
    //                 </span>
    //             </td>

    //             <td>
    //                 <span class="
    //                     badge 
    //                     ${item.component_type == 'EARNING'
    //                         ? 'bg-label-success'
    //                         : item.component_type == 'DEDUCTION'
    //                             ? 'bg-label-danger'
    //                             : 'bg-label-secondary'}
    //                 ">
    //                     ${item.component_type || '-'}
    //                 </span>
    //             </td>

    //             <td class="text-center">
    //                 ${item.affects_pf == 1
    //                     ? '<i class="mdi mdi-check-circle text-success fs-5"></i>'
    //                     : '<i class="mdi mdi-close-circle text-danger fs-5"></i>'}
    //             </td>

    //             <td class="text-center">
    //                 ${item.affects_esi == 1
    //                     ? '<i class="mdi mdi-check-circle text-success fs-5"></i>'
    //                     : '<i class="mdi mdi-close-circle text-danger fs-5"></i>'}
    //             </td>

    //             <td class="text-center">
    //                 ${item.affects_pt == 1
    //                     ? '<i class="mdi mdi-check-circle text-success fs-5"></i>'
    //                     : '<i class="mdi mdi-close-circle text-danger fs-5"></i>'}
    //             </td>

    //             <td class="text-center">
    //                 ${item.affects_tds == 1
    //                     ? '<i class="mdi mdi-check-circle text-success fs-5"></i>'
    //                     : '<i class="mdi mdi-close-circle text-danger fs-5"></i>'}
    //             </td>

    //             <td class="text-center">
    //                 ${item.taxable == 1
    //                     ? '<span class="badge bg-success">Yes</span>'
    //                     : '<span class="badge bg-danger">No</span>'}
    //             </td>

    //             <td class="text-center">
    //                 ${item.prorate_on_lop == 1
    //                     ? '<span class="badge bg-label-warning">Yes</span>'
    //                     : '<span class="badge bg-label-secondary">No</span>'}
    //             </td>

    //             <td class="text-center">
    //                 <span class="fw-bold">
    //                     ${item.display_order ?? '-'}
    //                 </span>
    //             </td>

    //             <td>
    //                 <span class="text-muted">
    //                     ${item.effective_from || '-'}
    //                 </span>
    //             </td>
    //             <td>
    //                 <label class="switch switch-square">
    //                     <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
    //                     <span class="switch-toggle-slider">
    //                         <span class="switch-on"></span>
    //                         <span class="switch-off"></span>
    //                     </span>
    //                 </label>
    //             </td>
    //             <td >
    //                 <span class="text-end">
    //                     <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
    //                         data-bs-target="#kt_modal_update_rule_category"
    //                         data-bs-toggle="tooltip" data-bs-placement="bottom"
    //                         title="Edit" onclick="openEditModal('${item.sno}', '${item.component_name}', '${item.component_code || ''}', '${item.component_type || ''}', ${item.is_taxable ? 1 : 0}, ${item.is_statutory ? 1 : 0}, ${item.show_in_payslip ? 1 : 0})">
    //                         <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
    //                     </button>
    //                     <button class="btn btn-icon btn-sm" type="button" 
    //                         data-bs-toggle="modal"
    //                         data-bs-target="#kt_modal_delete_rule_category"
    //                         data-bs-toggle="tooltip" data-bs-placement="bottom"
    //                         title="Delete"  onclick="confirmDelete('${item.sno}', '${item.component_name}')">
    //                         <i class="mdi mdi-delete-outline fs-3 text-black"></i>
    //                     </button>
    //                 </span>
    //             </td>
    //         </tr>
    //     `;
    // }

    function buildRow(item, index) {

        return `

        <div class="col-xl-6 col-lg-12 payroll-component-card">

            <div class="card">

                <div class="card-body p-4">

                    <!-- HEADER -->
                    <div class="component-header">

                        <div class="component-left">

                            <div class="component-avatar">
                                ${index}
                            </div>

                            <div class="flex-grow-1">

                                <div class="d-flex align-items-center gap-2 flex-wrap">

                                    <span class="component-title mb-3">
                                        ${item.component_name || '-'}
                                    </span>

                                    <span class="
                                        component-chip mb-3
                                        ${item.component_type == 'EARNING'
                                            ? 'chip-earning'
                                            : 'chip-deduction'}
                                    ">
                                        <i class="mdi mdi-wallet-outline"></i>
                                        ${item.component_type || '-'}
                                    </span>

                                </div>

                              

                                <div class="component-tags">

                                    <span class="component-chip chip-code">
                                        ${item.component_code || '-'}
                                    </span>

                                    <span class="component-chip chip-category">
                                        ${item.category || '-'}
                                    </span>

                                    ${item.taxable == 1
                                        ? `
                                            <span class="component-chip chip-tax">
                                                <i class="mdi mdi-check-circle"></i>
                                                Taxable
                                            </span>
                                        `
                                        : `
                                            <span class="component-chip chip-nontax">
                                                <i class="mdi mdi-close-circle"></i>
                                                Non Taxable
                                            </span>
                                        `
                                    }

                                </div>

                            </div>

                        </div>

                        <div class="component-right">

                            <div class="status-box">

                               

                                <label class="switch switch-square payroll-status-switch">
                                    <input
                                        type="checkbox"
                                        class="switch-input"
                                        ${item.status == 0 ? 'checked' : ''}
                                        onchange="updatelevelStatus('${item.id}', this.checked)"
                                    />

                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>

                            </div>

                        </div>

                    </div>

                    <!-- RULES -->
                    <div class="rules-wrapper">

                        <div class="rules-title">
                            Salary Rules & Compliance
                        </div>

                        <div class="rule-grid">

                            <div class="rule-item">

                                <div class="
                                    rule-icon
                                    ${item.affects_pf == 1 ? 'rule-active' : 'rule-inactive'}
                                ">
                                    <i class="mdi mdi-shield-check"></i>
                                </div>

                                <div class="rule-name">
                                    PF
                                </div>

                            </div>

                            <div class="rule-item">

                                <div class="
                                    rule-icon
                                    ${item.affects_esi == 1 ? 'rule-active' : 'rule-inactive'}
                                ">
                                    <i class="mdi mdi-hospital-box-outline"></i>
                                </div>

                                <div class="rule-name">
                                    ESI
                                </div>

                            </div>

                            <div class="rule-item">

                                <div class="
                                    rule-icon
                                    ${item.affects_pt == 1 ? 'rule-active' : 'rule-inactive'}
                                ">
                                    <i class="mdi mdi-bank-outline"></i>
                                </div>

                                <div class="rule-name">
                                    PT
                                </div>

                            </div>

                            <div class="rule-item">

                                <div class="
                                    rule-icon
                                    ${item.affects_tds == 1 ? 'rule-active' : 'rule-inactive'}
                                ">
                                    <i class="mdi mdi-cash-minus"></i>
                                </div>

                                <div class="rule-name">
                                    TDS
                                </div>

                            </div>

                            <div class="rule-item">

                                <div class="
                                    rule-icon
                                    ${item.prorate_on_lop == 1 ? 'rule-warning' : 'rule-inactive'}
                                ">
                                    <i class="mdi mdi-calendar-remove"></i>
                                </div>

                                <div class="rule-name">
                                    LOP
                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- FOOTER -->
                    <div class="component-footer">

                        <div class="component-meta">

                            <div class="meta-item">
                                <label>DISPLAY ORDER</label>
                                <span>
                                    ${item.display_order ?? '-'}
                                </span>
                            </div>

                            <div class="meta-item">
                                <label>EFFECTIVE FROM</label>
                                <span>
                                    ${item.effective_from || '-'}
                                </span>
                            </div>

                        </div>

                        <div class="action-group">

                            <button
                                class="payroll-action-btn btn-edit"

                                data-bs-toggle="modal"
                                data-bs-target="#kt_modal_update_rule_category"

                                onclick='openEditModal(${JSON.stringify(item)})'
                            >
                                <i class="mdi mdi-pencil-outline"></i>
                            </button>

                            <button
                                class="payroll-action-btn btn-delete"

                                data-bs-toggle="modal"
                                data-bs-target="#kt_modal_delete_rule_category"

                                onclick="confirmDelete(
                                    '${item.id}',
                                    '${item.component_name}'
                                )"
                            >
                                <i class="mdi mdi-delete-outline"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        `;
    }



    function skeletenRow() {

        let html = '';

        for (let i = 0; i < 4; i++) {

            html += `
                <div class="col-xl-6 col-lg-12 mb-4">
                    <div class="payroll-skeleton"></div>
                </div>
            `;
        }

        return html;
    }



    function NoDataFound() {

        return `
            <div class="col-12">

                <div class="empty-data-card">

                    <i class="mdi mdi-database-remove-outline"></i>

                    <h5>
                        No Payroll Components Found
                    </h5>

                    <p class="mb-0">
                        Try changing search filters or create a new payroll component.
                    </p>

                </div>

            </div>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/payroll/components?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('.payroll-skeleton').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });
                } else {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(9));
                }
                $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('.payroll-skeleton').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('.payroll-skeleton').hide();
                isLoading = false;
            });
    }




    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);
</script>

<!-- status Change -->
<script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/payroll_component_status_change/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    loadThemes(1);
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
    function confirmDelete(id, name) {

        document.querySelector('#kt_modal_delete_rule_category .btn-danger').setAttribute('data-id', id);
        $('#delete_message').html(
            'Are you sure you want to delete <b class="text-danger">' +
            name +
            '</b> Pay Component ?');
    }

    function deleteFunc() {
        var categoryId = document.querySelector('#kt_modal_delete_rule_category .btn-danger').getAttribute('data-id');

        fetch('/payroll_component_delete/' + categoryId, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {

            });
    }
</script>

<!-- add validate -->
<script>
    function addValidateForm() {

        $('#createbtn').prop('disabled', true);

        $('.error-text').html('');

        let err = 0;

        const component_name = $('#component_name').val().trim();
        const component_code = $('#component_code').val().trim();
        const category = $('#category').val();
        const component_type = $('#component_type').val();

        if (component_name == '') {

            $('#component_name_err').html('Component name is required');
            err++;

        }

        if (component_code == '') {

            $('#component_code_err').html('Component code is required');
            err++;

        }

        if (category == '') {

            $('#category_err').html('Category is required');
            err++;

        }

        if (component_type == '') {

            $('#component_type_err').html('Component type is required');
            err++;

        }

        if (err > 0) {

            $('#createbtn').prop('disabled', false);

            return false;
        }

        $('#createbtn .default-text').addClass('d-none');
        $('#createbtn .loading-text').removeClass('d-none');

        let formData = new FormData($('#addForm')[0]);

        $.ajax({

            url: "{{ route('add_payroll_component_new') }}",

            method: "POST",

            data: formData,

            processData: false,

            contentType: false,

            success: function(response) {

                $('#createbtn').prop('disabled', false);

                $('#createbtn .default-text').removeClass('d-none');
                $('#createbtn .loading-text').addClass('d-none');

                if (response.status) {

                    toastr.success(response.message);

                    $('#addForm')[0].reset();

                    $('#kt_modal_add_category').modal('hide');

                    loadThemes(1);

                } else {

                    toastr.error(response.message);

                }

            },

            error: function(xhr) {

                $('#createbtn').prop('disabled', false);

                $('#createbtn .default-text').removeClass('d-none');
                $('#createbtn .loading-text').addClass('d-none');

                if (xhr.status === 422) {

                    let errors = xhr.responseJSON.errors;

                    $.each(errors, function(key, value) {

                        $('#' + key + '_err').html(value[0]);

                    });

                } else {

                    toastr.error('Something went wrong');

                }

            }

        });

    }
</script>
<!-- edit Validate -->
<script>
    function openEditModal(item) {
        $('#edit_id').val(item.id);
        $('#component_name_edit').val(item.component_name || '');

        $('#component_code_edit').val(item.component_code || '');

        $('#category_edit').val(item.category || '').change();

        $('#component_type_edit').val(item.component_type || '').change();

        $('#display_order_edit').val(item.display_order || '');

        $('#effective_from_edit').val(item.effective_from || '');

        $('#taxable_edit').prop(
            'checked',
            item.taxable == 1
        );

        $('#prorate_on_lop_edit').prop(
            'checked',
            item.prorate_on_lop == 1
        );
        $('#affects_pf_edit').prop(
            'checked',
            item.affects_pf == 1
        );
        $('#affects_esi_edit').prop(
            'checked',
            item.affects_esi == 1
        );
        $('#affects_pt_edit').prop(
            'checked',
            item.affects_pt == 1
        );
        $('#affects_tds_edit').prop(
            'checked',
            item.affects_tds == 1
        );
    }

    function editValidateForm() {
        $('#updatebtn').prop('disabled', true);
        $('.error-text').html('');
        let err = 0;

        const component_name = $('#component_name_edit').val().trim();
        const component_code = $('#component_code_edit').val().trim();
        const category = $('#category_edit').val();
        const component_type = $('#component_type_edit').val();

        if (component_name == '') {
            $('#component_name_edit_err').html(
                'Component Name is required'
            );
            err++;
        }

        if (component_code == '') {
            $('#component_code_edit_err').html(
                'Component Code is required'
            );
            err++;
        }

        if (category == '') {
            $('#category_edit_err').html(
                'Category is required'
            );
            err++;
        }
        if (component_type == '') {
            $('#component_type_edit_err').html(
                'Component Type is required'
            );
            err++;
        }

        if (err > 0) {
            $('#updatebtn').prop('disabled', false);
            return false;
        }

        $('.default-text').addClass('d-none');
        $('.loading-text').removeClass('d-none');
        let formData = new FormData($('#updateForm')[0]);

        $.ajax({
            url: "{{ route('payroll_component_update') }}",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $('#updatebtn').prop('disabled', false);
                $('.default-text').removeClass('d-none');
                $('.loading-text').addClass('d-none');
                if (response.status) {
                    toastr.success(response.message);
                    $('#kt_modal_update_rule_category').modal('hide');
                    loadThemes(1);
                } else {
                    toastr.error(response.message);
                }

            },
            error: function(xhr) {
                $('#updatebtn').prop('disabled', false);
                $('.default-text').removeClass('d-none');
                $('.loading-text').addClass('d-none');
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        $('#' + key + '_edit_err').html(value[0]);
                    });
                } else {
                    toastr.error('Something went wrong');
                }
            }

        });

    }
</script>


@endsection