@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Salary Template')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')
<style>
        .credential-wrapper {
             min-height: 70vh;
        }

        /* Sidebar */
        .tab-sidebar {
            width: 280px;
            transition: all 0.3s ease;
            background: #fff;
            border-left: 1px solid #ddd;
        }

        .tab-sidebar.collapsed {
            width: 60px;
        }

        .tab-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
        }

        .tab-sidebar .nav-link i {
            font-size: 22px;
        }

        .nav-align-sideright .nav-link.active > label {
            background-color: #cfcfcf;
            color: #000;
            padding: 5px 8px;
            border-radius: 5px;
        }

        .tab-sidebar ul{
            /* align-items: end; */
        }
        

        /* Hide text when collapsed */
        .tab-sidebar.collapsed .tab-text {
            display: none;
        }
        .tab-sidebar.collapsed ul {
            align-items: center;
        }

        /* Toggle button */
        .toggle-btn {
            position: absolute;
            top: 15px;
            right: -15px;
            z-index: 10;
            background: #ab2b22;
            color: #fff;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
        }

        /* When sidebar collapsed */
        .tab-sidebar.collapsed + .tab-content .toggle-btn {
            right: -15px;
        }

        .tab-sidebar .right_nav{
            cursor:pointer !important;
            width:100%;
            display:flex;
            justify-content:end;
            align-items:center;
            gap:4px;
        }

        .tab-sidebar .right_nav:hover{
            color:#ab2b22 !important;
        }
    </style>
<!-- Users List Table -->
<div class="card">
    <div class="card-header pb-1">
        <ul class="nav nav-tabs flex-nowrap" role="tablist">
            <div class="scroll-container-wrapper">
                <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                            class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                            
                <div class="scroll-container" id="scrollContainer">
                    <li class="item nav-item">
                        <a href="{{ url('/settings/general_settings') }}"
                            type="button"
                            class="nav-link scroll-link "
                            role="tab">
                            General Settings
                        </a>
                    </li>        
                    <li class="item nav-item">
                        <a
                            href="{{ url('/settings/broadcast_theme') }}"
                            type="button"
                            class="nav-link scroll-link "
                            aria-selected="true">
                            Common
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/credential_book') }}" type="button"
                            class="nav-link scroll-link ">
                            Entity
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                            HRM
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/rule_category') }}" type="button"
                            class="nav-link scroll-link active">
                            Payroll
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/applicant_status') }}" type="button"
                            class="nav-link scroll-link ">
                            Recruitment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/interview_mode') }}" type="button"
                            class="nav-link scroll-link ">
                            Interview
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/assessment/guidelines') }}" type="button"
                            class="nav-link scroll-link">
                            Assessment
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/department') }}" type="button"
                            class="nav-link scroll-link ">
                            Management
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="{{ url('/settings/business/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Business
                            </a>
                        </li>

                    <li class="nav-item">
                        <a href="{{ url('/settings/api_config') }}" type="button"
                            class="nav-link scroll-link ">
                            API Config
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/admin/webhooks') }}" type="button"
                            class="nav-link scroll-link ">
                            Webhook Moniter
                        </a>
                    </li>
                </div>
                <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                        class="mdi mdi-chevron-right fs-2 text-white"></i></button>
            </div>
        </ul>
    </div>
    <div class="card-body px-1 py-1">
        <div class="d-flex credential-wrapper">
            <!-- CONTENT -->
            <div class="tab-content flex-grow-1 position-relative">
                <!-- Toggle Button -->
                <button id="toggleSidebarSetting" class="toggle-btn toggle-right">
                    <i class="mdi mdi-chevron-right"></i>
                </button>

                <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                    <div class="d-flex flex-column align-items-start">
                        <h5 class="card-title mb-1 text-black">Pay Component</h5>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb custom-breadcrumb">
                                <!-- Home -->
                                <li class="breadcrumb-item">
                                    <a href="{{ url('/dashboard') }}">
                                        <i class="mdi mdi-cog"></i> Settings
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="javascript:void(0);">Payroll </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <a href="javascript:void(0);" class="active-link">
                                        Pay Component
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                        <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                            data-bs-target="#templateModal">
                            <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Template
                        </a>
                    </div>
                    
                </div>
                    <div class="card-body">

                         <div id="template_list"></div>

                    </div>
            </div>
            <!-- SIDEBAR -->
            <div id="tabSidebarSetting" class="tab-sidebar expanded right nav-align-sideright">
                <ul class="nav nav-tabs flex-column" role="tablist">
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/rule_category') }}" class="nav-link "  role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text"> Rule Category</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title=" Rule Category"><i class="mdi mdi-clipboard-text-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/rules') }}" class="nav-link "  role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Rule</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Rule"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>
                            
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payroll_setting') }}" class="nav-link "  role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text"> Payroll Settings</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title=" Payroll Settings"><i class="mdi mdi-cog-outline fs-3"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payroll_component') }}" class="nav-link active"  role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">Payroll Component</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>
                            
                        </a>
                    </li>
                    <li class="nav-item px-1">
                        <a href="{{ url('/settings/payslip_templates') }}" class="nav-link "  role="tab">
                            <label class="fs-6 right_nav">
                                <span class="tab-text">payslip Template</span>
                                <span class="tab-icon" data-bs-toggle="tooltip" data-bs-placement="right" title="Payroll Component"><i class="mdi mdi-clipboard-check-outline fs-3"></i></span>
                            </label>
                            
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Rule Category -->
<div class="modal fade" id="templateModal" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Template</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
               

                    <input class="form-control mb-3" id="template_name" placeholder="Template Name">

                
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="button" id="createbtn" class="btn btn-primary" onclick="saveTemplate()" >Save</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Rule Category-->


<!--begin::Modal - Update Rule Category -->
<div class="modal fade" id="kt_modal_update_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Pay Component</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
             <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
               
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="mb-3">
                        <label>Component Name</label>
                        <input class="form-control" id="name_edit" placeholder="Enter Component Name">
                        <small class="text-danger" id="err_name_edit"></small>
                    </div>

                    <div class="mb-3">
                        <label>Type</label>
                        <select class="form-select select3" id="type_edit">
                            <option value="earning">Earning</option>
                            <option value="deduction">Deduction</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Calculation Type</label>
                        <select class="form-select select3" id="calc_edit">
                            <option value="fixed">Fixed</option>
                            <option value="percentage">Percentage</option>
                            <option value="formula">Formula</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label>Default Value</label>
                        <input class="form-control" id="value_edit"  placeholder="Enter Default Value">
                    </div>

                    <div class="mb-3">
                        <label>Formula</label>
                        <textarea class="form-control" id="formula_edit" placeholder="Enter Formula"></textarea>
                    </div>
                    

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="payslip_edit" checked>
                        <label class="form-check-label">Show in Payslip</label>
                    </div>

                
                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="button" id="createbtn" class="btn btn-primary" onclick="updateData()" >Update Pay Component</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal -->

<!--begin::Modal - Delete Rule Category-->
<div class="modal fade" id="kt_modal_delete_rule_category" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                <div>
                    <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                </div>
            </div>
            <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Attendance </b>
                    Pay Component ?</span>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Rule Category-->




<!-- Logo File Upload Start -->
<!-- jQuery from CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
    function buildRow(item,index) {
        return `
            <tr>

                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <label class="fs-7 fw-medium">${item.component_name}</label>
                    <a href="#" data-bs-toggle="tooltip"
                        data-bs-placement="right" title="${item.component_type || '-'}">
                        <i class="mdi mdi mdi-help-circle text-dark"></i>
                    </a>
                </td>
                <td><label class="fs-7 fw-medium">${item.component_code || '-'}</label></td>
                <td><label class="fs-7 fw-medium">${item.component_type || '-'}</label></td>
                <td><label class="fs-7 fw-medium">${item.is_taxable ? 'Yes':'No'}</label></td>
                <td><label class="fs-7 fw-medium">${item.is_statutory ? 'Yes':'No'}</label></td>
                <td><label class="fs-7 fw-medium">${item.show_in_payslip ? 'Yes':'No'}</label></td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td >
                    <span class="text-end">
                        <button class="btn btn-icon btn-sm" type="button" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_update_rule_category"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Edit" onclick="openEditModal('${item.sno}', '${item.component_name}', '${item.component_code || ''}', '${item.component_type || ''}', ${item.is_taxable ? 1 : 0}, ${item.is_statutory ? 1 : 0}, ${item.show_in_payslip ? 1 : 0})">
                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                        </button>
                        <button class="btn btn-icon btn-sm" type="button" 
                            data-bs-toggle="modal"
                            data-bs-target="#kt_modal_delete_rule_category"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Delete"  onclick="confirmDelete('${item.sno}', '${item.component_name}')">
                            <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                        </button>
                    </span>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/settings/payroll_component?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
            if(res.data.length > 0){
                res.data.forEach((item, index) => {
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                });
            }else{
                document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound(9));
            }
                 $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }
    
    function NoDataFound(col){
        return `
            <tr><td colspan="${col}" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

  

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

    <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/salary_component_status_change/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    // loadThemes(1);
                     location.reload();
                }
            })
            .catch(error => {});
    }
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id, name) {
  
          document.querySelector('#kt_modal_delete_rule_category .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete <b class="text-danger">' +
              name +
              '</b> Salary Component ?');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_rule_category .btn-danger').getAttribute('data-id');

          fetch('/salary_component_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {

              });
      }
</script>

<!-- add validate -->
 <script>
  function addValidateForm(){
    $("#createbtn").prop('disabled', true);
    var err =0;

         var component_name = document.getElementById("component_name").value.trim();
        if (component_name === "") {
            document.getElementById('component_name_err').innerHTML = 'Component Name is required...!';
            err++;
        } else {
            document.getElementById('component_name_err').innerHTML = '';
        }
        
        var component_code = document.getElementById("component_code").value.trim();
        if (component_code === "") {
            document.getElementById('component_code_err').innerHTML = 'Component Code is required...!';
            err++;
        } else {
            document.getElementById('component_code_err').innerHTML = '';
        }

        var component_type = document.getElementById("component_type").value.trim();
        if (component_type === "") {
            document.getElementById('component_type_err').innerHTML = 'Component Type is required...!';
            err++;
        } else {
            document.getElementById('component_type_err').innerHTML = '';
        }
      

    if(err>0){
        $("#createbtn").prop('disabled', false);
        return false;
       }else{
          $("#createbtn").prop('disabled', true);
          $('#addForm').submit();
       }
  }
 </script>
  <!-- edit Validate -->
  <script>
  function openEditModal(id,name,code,type,is_taxable,is_statutory,show_in_payslip){ 
   
    $('#edit_id').val(id);
    $('#component_name_edit').val(name);
    $('#component_code_edit').val(code || '');
    $('#component_type_edit').val(type || '').change();
    $('#is_taxable_edit').prop('checked', is_taxable == 1 ? true : false);
    $('#is_statutory_edit').prop('checked', is_statutory == 1 ? true : false);
    $('#is_prorated_edit').prop('checked', is_prorated == 1 ? true : false);
    $('#show_in_payslip_edit').prop('checked', show_in_payslip == 1 ? true : false);

  }
  function editValidateForm(){
    var err =0;
        
        var component_name_edit = document.getElementById("component_name_edit").value.trim();
        if (component_name_edit === "") {
            document.getElementById('component_name_edit_err').innerHTML = 'Component Name is required...!';
            err++;
        } else {
            document.getElementById('component_name_edit_err').innerHTML = '';
        }

        var component_code_edit = document.getElementById("component_code_edit").value.trim();
        if (component_code_edit === "") {
            document.getElementById('component_code_edit_err').innerHTML = 'Component Code is required...!';
            err++;
        } else {
            document.getElementById('component_code_edit_err').innerHTML = '';
        }

        var component_type_edit = document.getElementById("component_type_edit").value.trim();
        if (component_type_edit === "") {
            document.getElementById('component_type_edit_err').innerHTML = 'Component Type is required...!';
            err++;
        } else {
            document.getElementById('component_type_edit_err').innerHTML = '';
        }


    if(err>0){
        $("#updatebtn").prop('disabled', false);
        return false;
       }else{
          $("#updatebtn").prop('disabled', true);
          $('#updateForm').submit();
       }
  }
 </script>
<script>
    function loadTemplates(){

    $.get('/salary-template/list', function(res){

        let html = '';

        res.forEach(t => {

            html += `
                <div class="card mb-2 p-2 d-flex justify-content-between">

                    <span>${t.template_name}</span>

                    <button class="btn btn-sm btn-primary"
                        onclick="openTemplate(${t.sno})">
                        Configure
                    </button>

                </div>
            `;

        });

        $('#template_list').html(html);

    });

}

loadTemplates();
function saveTemplate(){

    let name = $('#template_name').val();

    $.post('/salary-template/store',{
        template_name:name,
        _token:'{{ csrf_token() }}'
    },function(){

        $('#templateModal').modal('hide');
        loadTemplates();

    });

}
function openTemplate(id){

    $.get('/salary-components', function(res){

        renderTemplateComponents(res.data, id);

    });

}

function renderTemplateComponents(components, template_id){

    let html = '';

    components.forEach(c => {

        html += `
        <div class="border p-2 mb-2">

            <input type="checkbox" class="temp-check"
                data-id="${c.sno}">

            ${c.component_name}

            <select class="form-select calc-type select3" data-id="${c.sno}">
                <option value="fixed" ${c.type == 'fixed' ? 'selected' : ''}>Fixed</option>
                <option value="percentage" ${c.type == 'percentage' ? 'selected' : ''}>%</option>
            </select>

            <input type="number"
                class="form-control temp-value mt-1"
                data-id="${c.sno}"
                placeholder="Value">

        </div>
        `;

    });

    html += `<button class="btn btn-success" onclick="saveTemplateComponents(${template_id})">Save</button>`;

    $('#template_list').html(html);
    $(".select3").select2();

}


function saveTemplateComponents(template_id){

    let components = [];

    $('.temp-check').each(function(){

        let id = $(this).data('id');

        components.push({
            component_id: id,
            amount: $(`.temp-value[data-id="${id}"]`).val(),
            calc_type: $(`.calc-type[data-id="${id}"]`).val(),
            is_active: $(this).is(':checked') ? 1:0
        });

    });

    $.post('/salary-template/components',{
        template_id:template_id,
        components: JSON.stringify(components),
        _token:'{{ csrf_token() }}'
    },function(){

        toastr.success('Saved');

    });

}


function editData(id){

    $.get('/salary-components/view/'+id,function(d){

        $('#name_edit').val(d.component_name);
        $('#type_edit').val(d.type).change();
        $('#calc_edit').val(d.calculation_type).change();
        $('#value_edit').val(d.default_value);
        $('#formula_edit').val(d.formula || '');
        $('#rule_id_edit').val(d.rule_id).change();
        $('#edit_id').val(id);
        $('#payslip_edit').prop('checked', d.show_in_payslip == 1 ? true : false);


        $('#kt_modal_update_rule_category').modal('show');

    });
}
</script>

@endsection
