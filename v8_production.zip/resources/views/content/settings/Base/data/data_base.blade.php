<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Database Table Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
        .editable-cell {
            cursor: pointer;
            padding: 8px;
            transition: background-color 0.3s;
            position: relative;
        }
        .editable-cell:hover {
            background-color: #f0f0f0;
        }
        .editing-cell {
            background-color: #fff3cd;
        }
        .editable-input {
            width: 100%;
            border: 1px solid #ffc107;
            border-radius: 4px;
            padding: 4px 8px;
        }
        .save-btn, .cancel-btn {
            margin: 0 2px;
            padding: 2px 6px;
            font-size: 12px;
        }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 5px;
        }
        .pagination button {
            padding: 5px 10px;
            margin: 0 2px;
            border: 1px solid #ddd;
            background-color: #fff;
            cursor: pointer;
            border-radius: 4px;
        }
        .pagination button.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .pagination button:disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
        .pagination button:hover:not(:disabled):not(.active) {
            background-color: #e9ecef;
        }
        .loading {
            text-align: center;
            padding: 20px;
        }
        .search-box {
            margin-right: 10px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .table th {
            white-space: nowrap;
        }
        .table td {
            white-space: nowrap;
        }
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideIn 0.3s ease-out;
        }
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        .btn-group-sm > .btn, .btn-sm {
            margin: 0 2px;
        }
        .json-editor {
            font-family: monospace;
            font-size: 12px;
        }
        textarea.json-input {
            font-family: monospace;
            font-size: 12px;
            min-height: 100px;
        }
        .json-badge {
            cursor: pointer;
            display: inline-block;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .edit-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1040;
            background-color: rgba(0,0,0,0.1);
        }
    </style>
    <style>
      .select2-container--default .select2-selection--single {
          height: 38px;
          padding: 5px 10px;
          border: 1px solid #ced4da;
          border-radius: 6px;
      }

      .select2-container--default .select2-selection--single .select2-selection__rendered {
          line-height: 26px;
      }

      .select2-container--default .select2-selection--single .select2-selection__arrow {
          height: 36px;
      }

      .select2-dropdown {
          border-radius: 6px;
          border: 1px solid #ced4da;
      }

      .select2-search__field {
          border-radius: 4px !important;
          padding: 6px !important;
      }
    </style>
</head>
<body>
    <div class="container-fluid mt-4">
        <div class="card">
            <div class="card-header">
                <h4>Database Table Manager</h4>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="d-flex">
                        <select id="tableSelect" class="form-select select2" style="width: 250px;">
                            <option value="">Select Table</option>
                        </select>
                        <button id="refreshBtn" class="btn btn-secondary ms-2" disabled>
                            <i class="bi bi-arrow-repeat"></i> Refresh
                        </button>
                        <button id="addRecordBtn" class="btn btn-success ms-2" disabled>
                            <i class="bi bi-plus-circle"></i> Add Record
                        </button>
                    </div>
                    <div class="d-flex">
                        <input type="text" id="searchInput" class="form-control search-box" placeholder="Search..." disabled>
                        <button id="searchBtn" class="btn btn-primary" disabled>
                            <i class="bi bi-search"></i> Search
                        </button>
                        <button id="clearSearchBtn" class="btn btn-secondary ms-2" disabled style="display: none;">
                            <i class="bi bi-x-circle"></i> Clear
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12" id="dataTableAjax">
                        <div class="text-center text-muted">Please select a table to view data</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Record Modal -->
    <div class="modal fade" id="addRecordModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addRecordForm">
                        <div id="formFields"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="submitAddRecord">Save Record</button>
                </div>
            </div>
        </div>
    </div>

    <!-- JSON Editor Modal -->
    <div class="modal fade" id="jsonEditorModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit JSON/Array Value</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label">Column: <strong id="jsonColumnName"></strong></label>
                    <textarea id="jsonValueInput" class="form-control json-input" rows="10"></textarea>
                    <div class="mt-2 text-muted small">
                        <i class="bi bi-info-circle"></i> Enter valid JSON format. Example: ["value1","value2"] or {"key":"value"}
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveJsonValue">Save</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <script>
    $(document).ready(function() {
        let currentTable = '';
        let currentPage = 1;
        let currentData = [];
        let currentSearch = '';
        let addRecordModal = new bootstrap.Modal(document.getElementById('addRecordModal'));
        let jsonEditorModal = new bootstrap.Modal(document.getElementById('jsonEditorModal'));
        let pendingJsonSave = null;
        let activeEditingCell = null; // Track currently editing cell

        // Set CSRF token for all AJAX requests
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Load table list on page load
        loadTableList();

        $('#tableSelect').select2({
            placeholder: "🔍 Search table...",
            allowClear: true,
            width: 'resolve',
            dropdownAutoWidth: true
        });

        // Handle table selection
        $('#tableSelect').change(function() {
            currentTable = $(this).val();
            currentSearch = '';
            currentPage = 1;
            $('#searchInput').val('');
            $('#clearSearchBtn').hide();

            if (currentTable) {
                $('#refreshBtn, #addRecordBtn, #searchBtn').prop('disabled', false);
                $('#searchInput').prop('disabled', false);
                loadTableData(currentTable, currentPage);
            } else {
                $('#refreshBtn, #addRecordBtn, #searchBtn').prop('disabled', true);
                $('#searchInput').prop('disabled', true);
                $('#dataTableAjax').html('<div class="text-center text-muted">Please select a table to view data</div>');
            }
        });

        // Refresh button click
        $('#refreshBtn').click(function() {
            if (currentTable) {
                loadTableData(currentTable, currentPage);
            }
        });

        // Search functionality
        $('#searchBtn').click(function() {
            currentSearch = $('#searchInput').val();
            if (currentSearch.trim() !== '') {
                currentPage = 1;
                searchTableData();
                $('#clearSearchBtn').show();
            }
        });

        $('#clearSearchBtn').click(function() {
            currentSearch = '';
            $('#searchInput').val('');
            currentPage = 1;
            loadTableData(currentTable, currentPage);
            $('#clearSearchBtn').hide();
        });

        $('#searchInput').keypress(function(e) {
            if (e.which === 13) {
                $('#searchBtn').click();
            }
        });

        // Add record button click
        $('#addRecordBtn').click(function() {
            showAddRecordForm();
        });

        $('#submitAddRecord').click(function() {
            submitAddRecord();
        });

        // Save JSON value
        $('#saveJsonValue').click(function() {
            if (pendingJsonSave) {
                let newValue = $('#jsonValueInput').val();
                try {
                    let parsed = JSON.parse(newValue);
                    let jsonString = JSON.stringify(parsed);
                    pendingJsonSave(jsonString);
                    jsonEditorModal.hide();
                    pendingJsonSave = null;
                } catch(e) {
                    showAlert('Invalid JSON format: ' + e.message, 'danger');
                }
            }
        });

        // Close JSON modal without saving
        $('#jsonEditorModal').on('hidden.bs.modal', function() {
            pendingJsonSave = null;
        });

        // Global click handler to cancel editing when clicking outside
        $(document).on('click', function(e) {
            if (activeEditingCell) {
                // Check if click is outside the editing cell
                if (!activeEditingCell.contains(e.target)) {
                    cancelCellEditing(activeEditingCell);
                }
            }
        });

        // Load all database tables
        function loadTableList() {
            $.ajax({
                url: '{{ route("table.manager.tables") }}',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let select = $('#tableSelect');
                        select.empty();
                        select.append('<option value="">Select Table</option>');
                        $.each(response.tables, function(index, table) {
                            select.append(`<option value="${table}">${table}</option>`);
                        });
                    } else {
                        showAlert('Failed to load tables', 'danger');
                    }
                },
                error: function() {
                    showAlert('Error loading tables', 'danger');
                }
            });
        }

        // Load table data with pagination
        function loadTableData(table, page) {
            $('#dataTableAjax').html('<div class="loading"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div><p>Loading data...</p></div>');

            $.ajax({
                url: '{{ route("table.manager.data") }}',
                type: 'POST',
                data: {
                    table: table,
                    page: page,
                    limit: 10
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        currentData = response.data;
                        renderTable(response);
                    } else {
                        $('#dataTableAjax').html(`<div class="alert alert-danger">${response.message}</div>`);
                    }
                },
                error: function(xhr) {
                    let message = 'Error loading table data';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    $('#dataTableAjax').html(`<div class="alert alert-danger">${message}</div>`);
                }
            });
        }

        // Search table data
        function searchTableData() {
            $('#dataTableAjax').html('<div class="loading"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div><p>Searching...</p></div>');

            $.ajax({
                url: '{{ route("table.manager.search") }}',
                type: 'POST',
                data: {
                    table: currentTable,
                    search: currentSearch,
                    page: currentPage,
                    limit: 10
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        currentData = response.data;
                        renderTable(response);
                    } else {
                        $('#dataTableAjax').html(`<div class="alert alert-danger">${response.message}</div>`);
                    }
                },
                error: function(xhr) {
                    let message = 'Error searching data';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    $('#dataTableAjax').html(`<div class="alert alert-danger">${message}</div>`);
                }
            });
        }

        // Check if value is JSON/Array
        function isJsonValue(value) {
            if (!value || typeof value !== 'string') return false;
            let trimmed = value.trim();
            return (trimmed.startsWith('[') && trimmed.endsWith(']')) ||
                   (trimmed.startsWith('{') && trimmed.endsWith('}'));
        }

        // Format value for display
        function formatDisplayValue(value) {
            if (value === null || value === undefined || value === '') return '';
            if (isJsonValue(value)) {
                try {
                    let parsed = JSON.parse(value);
                    let display = JSON.stringify(parsed);
                    if (display.length > 50) {
                        display = display.substring(0, 50) + '...';
                    }
                    return `<span class="json-badge badge bg-info" style="cursor:pointer;" title="Click to edit JSON">📋 ${escapeHtml(display)}</span>`;
                } catch(e) {
                    return escapeHtml(String(value));
                }
            }
            return escapeHtml(String(value));
        }

        // Render table with data
        function renderTable(response) {
            let html = '<div class="table-responsive">';
            html += '<table class="table table-bordered table-hover">';

            // Table header
            html += '<thead class="table-dark">';
            html += '<tr>';
            $.each(response.columns, function(index, column) {
                if (column !== 'idss') {
                    html += `<th>${column}</th>`;
                }
            });
            html += '<th width="140">Actions</th>';
            html += '</tr>';
            html += '</thead>';

            // Table body
            html += '<tbody>';
            if (response.data.length === 0) {
                html += '<tr><td colspan="' + (response.columns.length + 1) + '" class="text-center">No records found</td></tr>';
            } else {
                $.each(response.data, function(index, row) {
                   let rowId = row.sno || row.id;
                    html += `<tr data-row-id="${rowId}" class="copy-row" style="cursor: pointer;">`;
                    $.each(response.columns, function(colIndex, column) {
                        if (column !== 'idss') {
                            let value = row[column] !== null ? row[column] : '';
                            let rawValue = String(value);
                            let displayValue = formatDisplayValue(value);
                            let isJson = isJsonValue(value);

                            // Fix: Properly escape for HTML attribute using encodeURIComponent
                            let encodedValue = encodeURIComponent(rawValue);

                            html += `<td class="editable-cell" data-column="${column}" data-value-encoded="${encodedValue}" data-is-json="${isJson}">${displayValue}</td>`;
                        }
                    });
                    html += `<td class="action-buttons">
                                <button class="btn btn-sm btn-primary edit-row" data-id="${rowId}" onclick="event.stopPropagation()">
                                    <i class="bi bi-pencil"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger delete-row" data-id="${rowId}" onclick="event.stopPropagation()">
                                    <i class="bi bi-trash"></i> Delete
                                </button>
                                <button class="btn btn-sm btn-secondary copy-row-btn" data-id="${rowId}" onclick="event.stopPropagation()" title="Copy entire row">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </td>`;
                    html += '</tr>';
                });
            }
            html += '</tbody>';
            html += '</table>';
            html += '</div>';

            // Add pagination
            if (response.pagination.total_pages > 1) {
                html += renderPagination(response.pagination);
            }

            $('#dataTableAjax').html(html);
            attachEventHandlers();
        }

        // Render pagination
        function renderPagination(pagination) {
            let html = '<div class="pagination">';
            html += `<button class="page-btn" data-page="${pagination.current_page - 1}" ${pagination.current_page <= 1 ? 'disabled' : ''}>« Previous</button>`;
            let startPage = Math.max(1, pagination.current_page - 2);
            let endPage = Math.min(pagination.total_pages, pagination.current_page + 2);
            if (startPage > 1) {
                html += `<button class="page-btn" data-page="1">1</button>`;
                if (startPage > 2) html += `<button class="page-btn disabled">...</button>`;
            }
            for (let i = startPage; i <= endPage; i++) {
                html += `<button class="page-btn ${pagination.current_page === i ? 'active' : ''}" data-page="${i}">${i}</button>`;
            }
            if (endPage < pagination.total_pages) {
                if (endPage < pagination.total_pages - 1) html += `<button class="page-btn disabled">...</button>`;
                html += `<button class="page-btn" data-page="${pagination.total_pages}">${pagination.total_pages}</button>`;
            }
            html += `<button class="page-btn" data-page="${pagination.current_page + 1}" ${pagination.current_page >= pagination.total_pages ? 'disabled' : ''}>Next »</button>`;
            html += `</div>`;
            html += `<div class="text-center mt-2 text-muted">
                        Showing ${pagination.start} to ${pagination.end} of ${pagination.total_records} records
                    </div>`;
            return html;
        }

        // Cancel cell editing and restore original value
        function cancelCellEditing(cell) {
            if (!cell || !cell.length) return;

            let originalValue = cell.data('original-value');
            let isJson = isJsonValue(originalValue);

            console.log('Cancelling edit, restoring to:', originalValue);

            let displayValue = formatDisplayValue(originalValue);
            cell.html(displayValue);
            cell.removeClass('editing-cell');
            cell.data('is-json', isJson);

            let encodedValue = encodeURIComponent(originalValue);
            cell.data('value-encoded', encodedValue);

            activeEditingCell = null;
        }

        // Make cell editable
        function makeCellEditable(cell) {
            if (activeEditingCell && activeEditingCell[0] !== cell[0]) {
                cancelCellEditing(activeEditingCell);
            }

            let column = cell.data('column');
            let encodedValue = cell.data('value-encoded');
            let currentValue = decodeURIComponent(encodedValue || '');

            console.log('Editing - Raw value:', currentValue);

            cell.data('original-value', currentValue);

            let input = $(`<input type="text" class="editable-input form-control form-control-sm" value="${escapeHtml(currentValue)}">`);
            cell.html(input);
            cell.addClass('editing-cell');

            activeEditingCell = cell;
            input.focus();

            input.on('keypress', function(e) {
                if (e.which === 13) {
                    saveCellValue(cell, column, input.val());
                    e.preventDefault();
                }
            });

            input.on('blur', function() {
                setTimeout(function() {
                    if (activeEditingCell && activeEditingCell[0] === cell[0]) {
                        saveCellValue(cell, column, input.val());
                    }
                }, 200);
            });
        }

        // Save cell value
        function saveCellValue(cell, column, newValue) {
            let row = cell.closest('tr');
            let rowId = row.data('row-id');
            let originalValue = cell.data('original-value');

            if (newValue === originalValue) {
                cancelCellEditing(cell);
                return;
            }

            let trimmed = newValue.trim();
            if ((trimmed.startsWith('[') && trimmed.endsWith(']')) ||
                (trimmed.startsWith('{') && trimmed.endsWith('}'))) {
                try {
                    let parsed = JSON.parse(trimmed);
                    newValue = JSON.stringify(parsed);
                } catch(e) {
                    showAlert('Invalid JSON format: ' + e.message, 'danger');
                    cancelCellEditing(cell);
                    return;
                }
            }

            $.ajax({
                url: '{{ route("table.manager.update.cell") }}',
                type: 'POST',
                data: {
                    table: currentTable,
                    id: rowId,
                    column: column,
                    value: newValue
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let isJson = isJsonValue(newValue);
                        let displayValue = formatDisplayValue(newValue);
                        cell.html(displayValue);
                        cell.data('is-json', isJson);
                        let encodedValue = encodeURIComponent(newValue);
                        cell.data('value-encoded', encodedValue);
                        cell.data('original-value', newValue);
                        cell.removeClass('editing-cell');
                        activeEditingCell = null;
                        showAlert('Record updated successfully', 'success');

                        let rowData = currentData.find(r => r.sno == rowId);
                        if (rowData) {
                            rowData[column] = newValue;
                        }
                    } else {
                        showAlert(response.message || 'Update failed', 'danger');
                        cancelCellEditing(cell);
                    }
                },
                error: function(xhr) {
                    let message = 'Error updating record';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    showAlert(message, 'danger');
                    cancelCellEditing(cell);
                }
            });
        }

        // Attach event handlers
        function attachEventHandlers() {
            $('.page-btn').click(function() {
                if (!$(this).prop('disabled') && !$(this).hasClass('disabled')) {
                    let page = $(this).data('page');
                    if (page && page !== currentPage) {
                        currentPage = page;
                        if (currentSearch) {
                            searchTableData();
                        } else {
                            loadTableData(currentTable, currentPage);
                        }
                    }
                }
            });

            $('.edit-row').click(function() {
                if (activeEditingCell) {
                    cancelCellEditing(activeEditingCell);
                }
                let rowId = $(this).data('idss');
                let row = currentData.find(r => r.sno == rowId);
                if (row) {
                    enableRowEditing($(this).closest('tr'), row);
                }
            });

            $('.delete-row').click(function() {
                let rowId = $(this).data('idss');
                if (confirm('Are you sure you want to delete this record?')) {
                    deleteRecord(rowId);
                }
            });

            $('.editable-cell').off('click').on('click', function(e) {
                e.stopPropagation();
                if (!$(this).closest('tr').hasClass('editing')) {
                    let isJson = $(this).data('is-json') === 'true';

                    if (isJson) {
                        let column = $(this).data('column');
                        let encodedValue = $(this).data('value-encoded');
                        let currentValue = decodeURIComponent(encodedValue || '');
                        let rowId = $(this).closest('tr').data('row-id');
                        let cell = $(this);

                        $('#jsonColumnName').text(column);
                        try {
                            let parsed = JSON.parse(currentValue);
                            $('#jsonValueInput').val(JSON.stringify(parsed, null, 2));
                        } catch(e) {
                            $('#jsonValueInput').val(currentValue);
                        }

                        pendingJsonSave = function(newValue) {
                            saveCellValue(cell, column, newValue, rowId);
                        };

                        jsonEditorModal.show();
                    } else {
                        makeCellEditable($(this));
                    }
                }
            });
        }

        // Enable row editing mode
        function enableRowEditing(row, data) {
            if (row.hasClass('editing')) return;

            // Cancel any active cell editing
            if (activeEditingCell) {
                cancelCellEditing(activeEditingCell);
            }

            row.addClass('editing');
            let cells = row.find('td:not(:last-child)');

            cells.each(function() {
                let column = $(this).data('column');
                let value = $(this).data('value');
                let isJson = $(this).data('is-json') === 'true';

                if (isJson) {
                    // For JSON fields, show a formatted textarea
                    let formattedValue = value;
                    try {
                        let parsed = JSON.parse(value);
                        formattedValue = JSON.stringify(parsed, null, 2);
                    } catch(e) {}
                    $(this).html(`<textarea class="form-control form-control-sm json-editor" data-column="${column}" rows="3">${escapeHtml(formattedValue)}</textarea>`);
                } else {
                    $(this).html(`<input type="text" class="form-control form-control-sm" data-column="${column}" value="${escapeHtml(value)}">`);
                }
                $(this).removeClass('editable-cell');
            });

            let actionCell = row.find('td:last-child');
            actionCell.html(`
                <button class="btn btn-sm btn-success save-row">
                    <i class="bi bi-check-lg"></i> Save
                </button>
                <button class="btn btn-sm btn-secondary cancel-row">
                    <i class="bi bi-x-lg"></i> Cancel
                </button>
            `);

            actionCell.find('.save-row').click(function() {
                saveRowChanges(row);
            });

            actionCell.find('.cancel-row').click(function() {
                cancelRowEditing(row, data);
            });
        }

        // Save row changes
        function saveRowChanges(row) {
            let rowId = row.data('row-id');
            let updatedData = {};
            let hasError = false;

            row.find('input, textarea').each(function() {
                let column = $(this).data('column');
                let value = $(this).val();

                let trimmed = value.trim();
                if ((trimmed.startsWith('[') && trimmed.endsWith(']')) ||
                    (trimmed.startsWith('{') && trimmed.endsWith('}'))) {
                    try {
                        let parsed = JSON.parse(trimmed);
                        value = JSON.stringify(parsed);
                    } catch(e) {
                        showAlert(`Invalid JSON in column ${column}: ${e.message}`, 'danger');
                        hasError = true;
                        return false;
                    }
                }

                updatedData[column] = value;
            });

            if (hasError) return;

            $.ajax({
                url: '{{ route("table.manager.update.row") }}',
                type: 'POST',
                data: {
                    table: currentTable,
                    id: rowId,
                    data: updatedData
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        if (currentSearch) {
                            searchTableData();
                        } else {
                            loadTableData(currentTable, currentPage);
                        }
                        showAlert('Row updated successfully', 'success');
                    } else {
                        showAlert(response.message, 'danger');
                        // Find row by sno or id
                        let originalRow = currentData.find(r => r.sno == rowId || r.id == rowId);
                        cancelRowEditing(row, originalRow);
                    }
                },
                error: function(xhr) {
                    let message = 'Error updating row';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    showAlert(message, 'danger');
                    let originalRow = currentData.find(r => r.sno == rowId || r.id == rowId);
                    cancelRowEditing(row, originalRow);
                }
            });
        }

        // Cancel row editing
        function cancelRowEditing(row, originalData) {
            if (!originalData) {
                if (currentSearch) {
                    searchTableData();
                } else {
                    loadTableData(currentTable, currentPage);
                }
                return;
            }

            let cells = row.find('td:not(:last-child)');
            // Get all keys except id and sno
            let columns = Object.keys(originalData).filter(key => key !== 'idss' && key !== 'sno');

            cells.each(function(index) {
                let column = columns[index];
                if (column) {
                    let value = originalData[column] !== null ? originalData[column] : '';
                    let displayValue = formatDisplayValue(value);
                    let isJson = isJsonValue(value);
                    $(this).html(displayValue);
                    $(this).data('value', value);
                    $(this).data('original-value', value);
                    $(this).data('is-json', isJson);
                    let encodedValue = encodeURIComponent(String(value));
                    $(this).data('value-encoded', encodedValue);
                    $(this).addClass('editable-cell');
                }
            });

            let actionCell = row.find('td:last-child');
            actionCell.html(`
                <button class="btn btn-sm btn-primary edit-row" data-id="${originalData.sno || originalData.id}">
                    <i class="bi bi-pencil"></i> Edit
                </button>
                <button class="btn btn-sm btn-danger delete-row" data-id="${originalData.sno || originalData.id}">
                    <i class="bi bi-trash"></i> Delete
                </button>
                <button class="btn btn-sm btn-secondary copy-row-btn" data-id="${originalData.sno || originalData.id}" onclick="event.stopPropagation()" title="Copy entire row">
                    <i class="bi bi-clipboard"></i> Copy
                </button>
            `);

            row.removeClass('editing');
            attachEventHandlers();
        }

        // Delete record
        function deleteRecord(rowId) {
            $.ajax({
                url: '{{ route("table.manager.delete") }}',
                type: 'DELETE',
                data: {
                    table: currentTable,
                    id: rowId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        if (currentSearch) {
                            searchTableData();
                        } else {
                            loadTableData(currentTable, currentPage);
                        }
                        showAlert('Record deleted successfully', 'success');
                    } else {
                        showAlert(response.message, 'danger');
                    }
                },
                error: function(xhr) {
                    let message = 'Error deleting record';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    showAlert(message, 'danger');
                }
            });
        }

        // Show add record form
        function showAddRecordForm() {
            if (!currentTable) return;

            $.ajax({
                url: '{{ route("table.manager.data") }}',
                type: 'POST',
                data: {
                    table: currentTable,
                    page: 1,
                    limit: 1
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let formHtml = '';
                        $.each(response.columns, function(index, column) {
                            if (column !== 'sno') {
                                formHtml += `
                                    <div class="mb-3">
                                        <label for="field_${column}" class="form-label">${column}</label>
                                        <textarea class="form-control" id="field_${column}" name="${column}" rows="3"></textarea>
                                        <small class="text-muted">For JSON/Array values, enter valid JSON format like: ["value1","value2"]</small>
                                    </div>
                                `;
                            }
                        });
                        $('#formFields').html(formHtml);
                        addRecordModal.show();
                    } else {
                        showAlert('Failed to load form fields', 'danger');
                    }
                },
                error: function() {
                    showAlert('Error loading form fields', 'danger');
                }
            });
        }

        // Submit add record
        function submitAddRecord() {
            let formData = {};
            let isValid = true;

            $('#addRecordForm textarea').each(function() {
                let column = $(this).attr('name');
                let value = $(this).val();

                let trimmed = value.trim();
                if (trimmed !== '' && ((trimmed.startsWith('[') && trimmed.endsWith(']')) ||
                    (trimmed.startsWith('{') && trimmed.endsWith('}')))) {
                    try {
                        let parsed = JSON.parse(trimmed);
                        value = JSON.stringify(parsed);
                    } catch(e) {
                        showAlert(`Invalid JSON format for column ${column}: ${e.message}`, 'danger');
                        isValid = false;
                        return false;
                    }
                }

                formData[column] = value;
            });

            if (!isValid) return;

            $.ajax({
                url: '{{ route("table.manager.add") }}',
                type: 'POST',
                data: {
                    table: currentTable,
                    data: formData
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        addRecordModal.hide();
                        if (currentSearch) {
                            searchTableData();
                        } else {
                            loadTableData(currentTable, currentPage);
                        }
                        showAlert('Record added successfully', 'success');
                        $('#addRecordForm')[0].reset();
                    } else {
                        showAlert(response.message, 'danger');
                    }
                },
                error: function(xhr) {
                    let message = 'Error adding record';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    showAlert(message, 'danger');
                }
            });
        }

        // Helper functions
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function showAlert(message, type) {
            let alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            $('body').append(alertHtml);
            setTimeout(function() {
                $('.alert').fadeOut('slow', function() {
                    $(this).remove();
                });
            }, 3000);
        }

        // Add this function to copy row data
        function copyRowData(rowId) {
            // Try to find row by sno, id, or any primary key
            let row = currentData.find(r => r.sno == rowId || r.id == rowId);

            if (!row) {
                showAlert('Row not found', 'danger');
                return;
            }

            // Create copy text
            let copyText = '';
            for (let [key, value] of Object.entries(row)) {
                if (key !== 'sno' && key !== 'idss') {
                    copyText += `${key}: ${value}\n`;
                }
            }

            // Copy to clipboard
            navigator.clipboard.writeText(copyText).then(function() {
                showAlert('Row copied to clipboard!', 'success');
            }).catch(function(err) {
                // Fallback for older browsers
                let textarea = document.createElement('textarea');
                textarea.value = copyText;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showAlert('Row copied to clipboard!', 'success');
            });
        }

        // Add this function to copy as JSON
        function copyRowAsJSON(rowId) {
            // Try to find row by sno, id, or any primary key
            let row = currentData.find(r => r.sno == rowId || r.id == rowId);

            if (!row) {
                showAlert('Row not found', 'danger');
                return;
            }

            let copyData = {};
            for (let [key, value] of Object.entries(row)) {
                if (key !== 'sno' && key !== 'idss') {
                    copyData[key] = value;
                }
            }

            let jsonString = JSON.stringify(copyData, null, 2);

            navigator.clipboard.writeText(jsonString).then(function() {
                showAlert('Row copied as JSON!', 'success');
            }).catch(function(err) {
                let textarea = document.createElement('textarea');
                textarea.value = jsonString;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showAlert('Row copied as JSON!', 'success');
            });
        }

        // Add this function to copy specific cell
        function copyCellValue(column, value) {
            navigator.clipboard.writeText(value).then(function() {
                showAlert(`Copied: ${column} = ${value}`, 'success');
            }).catch(function(err) {
                let textarea = document.createElement('textarea');
                textarea.value = value;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showAlert(`Copied: ${column} = ${value}`, 'success');
            });
        }

        // Replace the attachEventHandlers function
        function attachEventHandlers() {
            // Pagination click
            $('.page-btn').click(function() {
                if (!$(this).prop('disabled') && !$(this).hasClass('disabled')) {
                    let page = $(this).data('page');
                    if (page && page !== currentPage) {
                        currentPage = page;
                        if (currentSearch) {
                            searchTableData();
                        } else {
                            loadTableData(currentTable, currentPage);
                        }
                    }
                }
            });

            // Edit row
            $('.edit-row').click(function(e) {
                e.stopPropagation();
                if (activeEditingCell) {
                    cancelCellEditing(activeEditingCell);
                }
                let rowId = $(this).data('idss');
                let row = currentData.find(r => r.sno == rowId);
                if (row) {
                    enableRowEditing($(this).closest('tr'), row);
                }
            });

            // Delete row
            $('.delete-row').click(function(e) {
                e.stopPropagation();
                let rowId = $(this).data('idss');
                if (confirm('Are you sure you want to delete this record?')) {
                    deleteRecord(rowId);
                }
            });

            // Copy row button
            $('.copy-row-btn').click(function(e) {
                e.stopPropagation();
                let rowId = $(this).data('idss');
                copyRowData(rowId);
            });

            // Copy entire row when clicking on the row
            $('.copy-row').off('click').on('click', function(e) {
                // Don't copy if clicking on editable cell that's being edited
                if ($(e.target).closest('.editing-cell').length) {
                    return;
                }
                let rowId = $(this).data('row-id');
                copyRowData(rowId);
            });

            // Make cells editable on click with copy option
            $('.editable-cell').off('click').on('click', function(e) {
                e.stopPropagation();

                // Show context menu on right click
                if (e.which === 3) {
                    e.preventDefault();
                    let column = $(this).data('column');
                    let encodedValue = $(this).data('value-encoded');
                    let currentValue = decodeURIComponent(encodedValue || '');
                    showCopyContextMenu(e, column, currentValue);
                    return;
                }

                if (!$(this).closest('tr').hasClass('editing')) {
                    let isJson = $(this).data('is-json') === 'true';

                    if (isJson) {
                        let column = $(this).data('column');
                        let encodedValue = $(this).data('value-encoded');
                        let currentValue = decodeURIComponent(encodedValue || '');
                        let rowId = $(this).closest('tr').data('row-id');
                        let cell = $(this);

                        $('#jsonColumnName').text(column);
                        try {
                            let parsed = JSON.parse(currentValue);
                            $('#jsonValueInput').val(JSON.stringify(parsed, null, 2));
                        } catch(e) {
                            $('#jsonValueInput').val(currentValue);
                        }

                        pendingJsonSave = function(newValue) {
                            saveCellValue(cell, column, newValue, rowId);
                        };

                        jsonEditorModal.show();
                    } else {
                        makeCellEditable($(this));
                    }
                }
            });

            // Add right-click context menu for cells
            $('.editable-cell').on('contextmenu', function(e) {
                e.preventDefault();
                e.stopPropagation();
                let column = $(this).data('column');
                let encodedValue = $(this).data('value-encoded');
                let currentValue = decodeURIComponent(encodedValue || '');
                showCopyContextMenu(e, column, currentValue);
            });
        }

        // Add context menu for copying
        function showCopyContextMenu(event, column, value) {
            // Remove existing context menu
            $('#customContextMenu').remove();

            let menu = $(`
                <div id="customContextMenu" style="position: fixed; background: white; border: 1px solid #ccc; border-radius: 4px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); z-index: 10000; min-width: 150px;">
                    <div style="padding: 8px 12px; border-bottom: 1px solid #eee; font-weight: bold; background: #f8f9fa;">
                        ${column}
                    </div>
                    <div class="context-menu-item" style="padding: 8px 12px; cursor: pointer; transition: background 0.2s;" onclick="window.copyCellValue('${column}', '${escapeHtml(value).replace(/'/g, "\\'")}'); $('#customContextMenu').remove();">
                        <i class="bi bi-clipboard"></i> Copy Value
                    </div>
                    <div class="context-menu-item" style="padding: 8px 12px; cursor: pointer; transition: background 0.2s; border-top: 1px solid #eee;" onclick="$('#customContextMenu').remove();">
                        <i class="bi bi-x-circle"></i> Cancel
                    </div>
                </div>
            `);

            $('body').append(menu);

            menu.css({
                top: event.pageY + 'px',
                left: event.pageX + 'px'
            });

            // Highlight on hover
            $('.context-menu-item').hover(
                function() { $(this).css('background', '#f0f0f0'); },
                function() { $(this).css('background', 'white'); }
            );

            // Close menu when clicking elsewhere
            $(document).one('click', function() {
                $('#customContextMenu').remove();
            });
        }

        // Make copyCellValue globally accessible
        window.copyCellValue = copyCellValue;

        // Optional: Add keyboard shortcut (Ctrl+C) to copy selected row
        $(document).on('keydown', function(e) {
            if (e.ctrlKey && e.keyCode === 67) { // Ctrl+C
                let selectedRow = $('.copy-row:hover');
                if (selectedRow.length) {
                    e.preventDefault();
                    let rowId = selectedRow.data('row-id');
                    copyRowData(rowId);
                }
            }
        });
    });
    </script>
</body>
</html>
