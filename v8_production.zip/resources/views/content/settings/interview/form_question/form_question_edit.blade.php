@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Interview Question Edit')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <!-- Users List Table -->
    <div class="card">
        <div class="card-body px-1 py-1">
            <div class="nav-align-right nav-tabs-shadow">

                <div class="tab-content">
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Interview Form Question Update</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Interview</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Form Question
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <form id="add_customer_type_option_form" action="{{ route('form_question_update') }}" method="POST" >
                        @csrf
                    
                    <div class="row">
                        <div id="questions_container">

                

                        </div>

                        

                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <a href="{{url('/settings/interview_question')}}" class="btn btn-outline-danger text-primary fw-bold waves-effect">Cancel</a>
                            <button type="button" class="btn btn-primary" id="saveQuestions" onclick="AddvalidateForm()">Update Question</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    




<!-- Label Value Function Start -->
<script>
    function payment_mode_option_label_func() {
        var payment_mode_option_label_value = document.getElementById("payment_mode_option_label_value").value;
        var payment_mode_option_check_box = document.getElementById("payment_mode_option_check_box");
        var payment_mode_option_radio_button = document.getElementById("payment_mode_option_radio_button");
        var payment_mode_option_list_box = document.getElementById("payment_mode_option_list_box");

        if (payment_mode_option_label_value == "check_box") {
            payment_mode_option_check_box.style.display = "block";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        } else if (payment_mode_option_label_value == "radio_button") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "block";
            payment_mode_option_list_box.style.display = "none";
        } else if (payment_mode_option_label_value == "list_box") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "block";
        } else {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        }
    }
</script>


<script>
function createQuestionBlock(isDefault = false) {
    // Delete button only for non-default blocks
    var deleteButtonHTML = isDefault ? '' : `
        <div class="col-lg-1">
            <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 del-question">
                <i class="mdi mdi-delete fs-4"></i>
            </a>
        </div>
    `;

    var block = `
    <div class="altmobile-row rounded mb-3">
       <div class="payment_mode_question_block px-2 py-2">
            <div class="row my-2">
              <div class="col-lg-11">
                  <div class="row">
                      <div class="col-lg-12 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Question Name<span class="text-danger">*</span></label>
                          <input type="text" class="form-control label-name" name="label_names[]" placeholder="Enter Question Name" />
                          <input type="hidden" class="edit_id" value="">
                      </div>
                      <div class="col-lg-4 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Input Value<span class="text-danger">*</span></label>
                          <select class="select3 form-select input-value-select" name="label_values[]">
                              <option>Select Input Value</option>
                              <option value="text_field">Text Field</option>
                              <option value="check_box">Check Box</option>
                              <option value="radio_button">Radio Button</option>
                              <option value="list_box">List Box</option>
                          </select>
                         
                      </div>

                      <div class="col-lg-6 mb-3 mt-3 option-blocks"></div>


                  </div>
              </div>
              ${deleteButtonHTML}
          </div>
          <hr class="bg-light m-1">
        </div>
    </div>
    `;
    return block;
}

// Add default block on page load
// $(document).ready(function(){
//     var $firstBlock = $(createQuestionBlock(true));
//     $('#questions_container').append($firstBlock);
//     initializeBlock($firstBlock);
// });

// Add new question block


// Initialize block behavior
function initializeBlock($block){
    $block.find('.select3').select2({width: '100%'});
    handleInputValueChange($block);

    // Delete question block
    $block.find('.del-question').on('click', function() {
        $block.remove();
    });

   
}

// Handle Input Value (Main Section)
function handleInputValueChange($block) {
    $block.find('.input-value-select').on('change', function() {
        var value = $(this).val();
        var $container = $block.find('.option-blocks');
        $container.empty();

        if(value === 'check_box' || value === 'radio_button' || value === 'list_box') {
            var type = value;
            var uniqueId = 'accordion-' + type + '-' + new Date().getTime();
            var typeText = type.replace('_',' ');
            typeText = typeText.charAt(0).toUpperCase() + typeText.slice(1);

            var html = `
            <div class="accordion">
              <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                  <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#${uniqueId}"> ${typeText} </button>
                </h2>
                <div id="${uniqueId}" class="accordion-collapse collapse">
                  <div class="accordion-body px-2">
                    <div class="scroll-y max-h-200px ${type}-container p-3" style="overflow-x: hidden;">
                      <div class="option-item row mb-2">
                        <div class="col-lg-10">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Option 1 <span class="text-danger">*</span></label>
                          <textarea class="form-control" rows="1" placeholder="Enter Option 1"></textarea>
                        </div>
                        <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1"></div>
                      </div>
                    </div>
                    <div class="mb-1 mt-1">
                      <button type="button" class="btn btn-primary mt-2 add-option-btn">Add Option</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
            $container.append(html);

            $container.find('.add-option-btn').on('click', function(e){
                e.preventDefault();
                var $optionsContainer = $container.find(`.${type}-container`);
                var nextNum = $optionsContainer.find('.option-item').length + 1;
                var $newRow = $(`
                    <div class="option-item row mb-2">
                      <div class="col-lg-10">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Option ${nextNum} <span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" placeholder="Enter Option ${nextNum}"></textarea>
                      </div>
                      <div class="col-lg-2 d-flex justify-content-start align-items-end mb-1">
                        <div>
                          <a href="javascript:;" class="btn btn-outline-danger delete-option w-100 h-100 d-flex justify-content-center align-items-center p-1">
                            <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                `);
                $optionsContainer.append($newRow);

                $newRow.find('.delete-option').on('click', function() {
                    $newRow.remove();
                    updateOptionNumbers($optionsContainer);
                    updateDependsSelect($block);
                });

                $newRow.find('textarea').on('input', function() {
                    updateDependsSelect($block);
                });

                updateDependsSelect($block);
            });

            $container.find('textarea').on('input', function() {
                updateDependsSelect($block);
            });
            updateDependsSelect($block);
        }
    });
}

// Update depends select based on main options only
function updateDependsSelect($block) {
    var $dependsSelect = $block.find('.depends-select');
    $dependsSelect.empty().append('<option value="">Select Label</option>');
    $block.find('.option-blocks textarea').each(function(){
        var val = $(this).val().trim();
        if(val) $dependsSelect.append(`<option value="${val}">${val}</option>`);
    });
}

// Update numbering for main options
function updateOptionNumbers($optionsContainer){
    $optionsContainer.find('.option-item').each(function(index){
        $(this).find('label').html(`Option ${index+1} <span class="text-danger">*</span>`);
        $(this).find('textarea').attr('placeholder', `Enter Option ${index+1}`);
    });
}

// Update numbering for depends local options
function updateDepOptionNumbers($container){
    $container.find('.option-item').each(function(index){
        $(this).find('label').html(`Option ${index+1} <span class="text-danger">*</span>`);
        $(this).find('textarea').attr('placeholder', `Enter Option ${index+1}`);
    });
}
</script>
<script>
function AddvalidateForm() {

    const $form = $('#add_customer_type_option_form');

    const $block = $('#questions_container .payment_mode_question_block').first();

    let isValid = true;

    $form.find('.is-invalid').removeClass('is-invalid');
    $form.find('.invalid-feedback-dynamic').remove();

    const $labelName = $block.find('.label-name');
    const $inputValue = $block.find('.input-value-select');

    const labelName = ($labelName.val() || '').trim();
    const inputValue = $inputValue.val();

    if (!labelName) {
        showError($labelName, 'Question Name is required.');
        isValid = false;
    }

    if (!inputValue || inputValue === 'Select Input Value') {
        showError(
            $inputValue.next('.select2'),
            'Please select an Input Value.'
        );

        isValid = false;
    }

    if (
        ['check_box', 'radio_button', 'list_box'].includes(inputValue)
    ) {

        const $options = $block.find('.option-blocks textarea');

        if ($options.length === 0) {

            showError(
                $block.find('.option-blocks'),
                'Option is required.'
            );

            isValid = false;

        } else {

            $options.each(function () {

                if (!$(this).val().trim()) {

                    showError(
                        $(this),
                        'Option is required.'
                    );

                    isValid = false;
                }
            });
        }
    }

    if (!isValid) {

        const $firstInvalid = $('.is-invalid').first();

        if ($firstInvalid.length) {
            $('html, body').animate({
                scrollTop: $firstInvalid.offset().top - 120
            }, 400);
        }

        return false;
    }

    serializeQuestions($form);
}

// Helper: Show inline validation message
function showError($el, message) {
    $el.addClass('is-invalid');
    if ($el.next('.invalid-feedback-dynamic').length === 0) {
        $(`<div class="invalid-feedback invalid-feedback-dynamic">${message}</div>`).insertAfter($el);
    }

    // Remove error dynamically when corrected
    $el.on('input change', function() {
        if ($(this).val()?.trim()) {
            $(this).removeClass('is-invalid');
            $(this).next('.invalid-feedback-dynamic').remove();
        }
    });
}

// Serialize questions into hidden inputs

</script>



<script>
    const questionData = @json($questionData);

    $(document).ready(function () {

        $('#questions_container').empty();

        const $block = $(createQuestionBlock(true));

        $('#questions_container').append($block);

        initializeBlock($block);

        // Existing question ID
        $block.find('.edit_id').val(questionData.sno);

        // Existing question name
        $block.find('.label-name').val(questionData.question_name || '');

        // Existing question type
        const questionType = questionData.question_type || '';

        $block.find('.input-value-select')
            .val(questionType)
            .trigger('change');

        // Existing options
        let options = [];

        if (questionData.question_option) {
            try {
                options = typeof questionData.question_option === 'string'
                    ? JSON.parse(questionData.question_option)
                    : questionData.question_option;
            } catch (error) {
                console.error('Invalid question options JSON:', error);
                options = [];
            }
        }

        if (
            ['check_box', 'radio_button', 'list_box'].includes(questionType) &&
            Array.isArray(options)
        ) {

            const $optionsContainer = $block.find(
                `.${questionType}-container`
            );

            $optionsContainer.empty();

            options.forEach(function (option, index) {

                const label = option.label || '';

                const deleteButton = index === 0
                    ? ''
                    : `
                        <div class="col-lg-2 d-flex justify-content-start align-items-end mb-1">
                            <a href="javascript:;"
                               class="btn btn-outline-danger delete-option p-1">
                                <i class="mdi mdi-delete fs-4"></i>
                            </a>
                        </div>
                    `;

                const $row = $(`
                    <div class="option-item row mb-2">
                        <div class="col-lg-10">
                            <label class="text-dark mb-1 fs-6 fw-semibold">
                                Option ${index + 1}
                                <span class="text-danger">*</span>
                            </label>

                            <textarea
                                class="form-control"
                                rows="1"
                                placeholder="Enter Option ${index + 1}"
                            ></textarea>
                        </div>

                        ${deleteButton}
                    </div>
                `);

                $row.find('textarea').val(label);

                $optionsContainer.append($row);

                $row.find('.delete-option').on('click', function () {
                    $row.remove();

                    updateOptionNumbers($optionsContainer);
                });
            });

            updateOptionNumbers($optionsContainer);
            updateDependsSelect($block);
        }
    });

    function serializeQuestions($form) {

        // Remove previous serialized question input
        $form.find('input[name="questions"]').remove();

        const $block = $('#questions_container .payment_mode_question_block').first();

        const editId = parseInt(
            $block.find('.edit_id').val() || 0,
            10
        );

        const labelName = ($block.find('.label-name').val() || '').trim();

        const labelValue = $block.find('.input-value-select').val() || '';

        const options = [];

        $block.find('.option-blocks textarea').each(function (index) {

            const label = ($(this).val() || '').trim();

            if (label) {
                options.push({
                    value: index,
                    label: label
                });
            }
        });

        const question = {
            edit_id: editId,
            label_name: labelName,
            label_value: labelValue,
            options: options
        };

        $('<input>', {
            type: 'hidden',
            name: 'questions',
            value: JSON.stringify([question])
        }).appendTo($form);

        $form.trigger('submit');
    }
</script>
@endsection
