@extends('layouts/layoutMaster')

@section('title', 'Staff Timechamp')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')

@php
  
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ;
    $auth_id = auth()->user()->id ;
  @endphp
<style>

    /* ================= Dashboard Wrapper ================= */

.dashboard-wrapper {
    min-height: 60vh;
}
.light-style .flatpickr-calendar{
    width:auto !important;
}
/* Staff Scroll */
.staff-scroll {
    max-height: calc(110vh - 300px);
    overflow-y: auto;
}
.datepicker tbody tr.active-week > td {
    background-color: #007bff;
    color: white;
}
/* Staff Item */
.staff-item {
    transition: 0.2s;
    cursor: pointer;
}

.staff-item:hover {
    background: #f8f9fa;
}

.staff-selected {
    background: #eef4ff !important;
    border-left: 4px solid #4a6cf7;
}

/* Tabs Modern Look */
.custom-tabs .nav-link {
    border-radius: 8px;
    font-weight: 500;
    padding: 6px 12px;
}

.custom-tabs .nav-link.active {
    background: #ab2b22;
    color: #fff;
}

/* Card Hover */
.card {
    transition: 0.2s;
}

.card:hover {
    transform: translateY(-2px);
}

/* Responsive */
@media(max-width: 991px){

    .staff-scroll {
        max-height: 300px;
    }

    .dashboard-wrapper {
        flex-direction: column;
    }
}

    .dataTables_scroll {
        max-height: 200px;
    }

    .floating-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        /* animation: floatBounce 2.5s ease-in-out infinite; */
    }
/*
    @keyframes floatBounce {
        0%   { transform: translateY(0px); }
        50%  { transform: translateY(-8px); }
        100% { transform: translateY(0px); }
    } */

     .scroll-container-filter {
        display: flex;
        
        /* overflow-x: auto;
        scroll-behavior: smooth; */
        /* padding: 10px 40px; */
        gap: 4px;
        /* scrollbar-width: none; */
        list-style:none;
    }

    .scroll-container-filter::-webkit-scrollbar {
        display: none;
    }

    .item {
        flex: 0 0 auto;
        text-align: center;
        font-weight: bold;
        border-radius: 8px;
    }

    .item .active{
         background: #ab2b22;
         color:white;
    }

</style>

<style>
    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<style>
    /* Scroll styling */
    .staff-scroll {
        height: calc(100vh - 190px);
        overflow-y: auto;
    }

    .staff-details-scroll {
        height: calc(100vh - 190px);
        overflow-y: auto;
    }

    /* Hover & Selected Effect */
    .staff-item {
        transition: background 0.2s ease;
        cursor: pointer;
    }

    .staff-item:hover {
        background: #f5f5f5;
    }

    .staff-selected {
        background: #eef4ff !important;
        border-left: 4px solid #4a6cf7;
    }

    /* Rounded Image */
    .staff-avatar {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        object-fit: cover;
    }
</style>
<style>
    .mini-card {
        border-radius: 10px;
        transition: 0.2s ease-in-out;
    }

    .mini-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .icon-box {
        width: 45px;
        height: 45px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0">
        <div class="d-flex flex-column align-items-start">
            <h5 class="card-title mb-1 text-black">Staff Timechamp</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-account-group"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Staff Timechamp
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_filter">
                <span><i class="mdi mdi-filter-outline" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"></i></span>
            </a> -->
            @if($user_id == 0)
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="modal" data-bs-target="#kt_modal_staff_report">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>update report
            </a>
            @endif
        </div>
    </div>
    <div class="card-body pt-3">

        <!-- ===================== FILTER BAR ===================== -->
        <div class="filter-bar mb-3">

            <div class="row g-3 align-items-end">

                <!-- Company -->
                <div class="col-lg-3 col-md-6">
                    <label class="form-label fw-semibold">Company</label>
                    <select id="company_fill" class="form-select select3 ">
                        <option value="egc">Elysium Groups</option>
                        @foreach($company_list ?? [] as $clist)
                            <option value="{{$clist->sno}}">
                                {{$clist->company_name}}
                            </option>
                        @endforeach
                    </select>
                </div>

                <!-- Entity -->
                <div class="col-lg-3 col-md-6">
                    <label class="form-label fw-semibold">Entity</label>
                    <select id="entity_fill" class="form-select select3 ">
                        <option value="">Select Entity</option>
                    </select>
                </div>

                <!-- Date Picker -->
                <div class="col-lg-3 col-md-6">
                    <label class="form-label fw-semibold">Select Date</label>
                   <input type="text"
                        id="global_date_picker"
                        class="form-control ">
                </div>

                <!-- Tabs -->
                <div class="col-lg-3 col-md-6">
                    <label class="form-label fw-semibold">View Type</label>
                    <ul class="nav nav-pills nav-fill custom-tabs " role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active"
                                    data-bs-toggle="tab"
                                    data-bs-target="#day_info">
                                Day
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link"
                                    data-bs-toggle="tab"
                                    data-bs-target="#week_info">
                                Week
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link"
                                    data-bs-toggle="tab"
                                    data-bs-target="#month_info">
                                Month
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link"
                                    data-bs-toggle="tab"
                                    data-bs-target="#year_info">
                                Year
                            </button>
                        </li>
                    </ul>
                </div>

            </div>
        </div>


        <!-- ===================== MAIN LAYOUT ===================== -->
        <div class="row g-3 dashboard-wrapper">

            <!-- LEFT: STAFF LIST -->
            <div class="col-xl-3 col-lg-4 col-md-5">

                <div class="card border-0 shadow-sm h-100">

                    <div class="card-body p-0">

                        <!-- Search -->
                        <div class="p-3 border-bottom">
                            <input type="text"
                                id="staff_search"
                                class="form-control form-control-sm"
                                placeholder="Search staff...">
                        </div>

                        <!-- Scroll List -->
                        <ul id="list-table-body"
                            class="list-group list-group-flush staff-scroll">
                        </ul>

                    </div>
                </div>

            </div>


            <!-- RIGHT: REPORT PANEL -->
            <div class="col-xl-9 col-lg-8 col-md-7">

                <div class="tab-content">

                    <!-- DAY -->
                    <div class="tab-pane fade show active"
                        id="day_info">

                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-header bg-white border-bottom">
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    
                                    <div class="d-flex align-items-center gap-2">
                                        <div>
                                            <h5 class="fw-bold mb-0">
                                                Staff Performance Dashboard
                                            </h5>
                                            <small class="text-muted"
                                                id="report-period-label">
                                                Day Report
                                            </small>
                                        </div>
                                        <div class="align-self-start">
                                            <span class="badge bg-primary-subtle text-primary">
                                                Live Analytics
                                            </span>
                                        </div>
                                    </div>

                                    <div class="align-self-start" id="staff-profile-day">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="card-body" style="min-height:500px;" >

                                <div class="text-center text-muted mt-5" id="staff-details-day">
                                    <i class="mdi mdi-account-circle-outline fs-1"></i>
                                    <p class="mt-3">
                                        Select a staff to view report
                                    </p>
                                </div>
                                <div class="loadingegc" id="loadingScreenegc-day"  style=" width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999;display:none; ">
                                    <div class="loading-content-egc" style="text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                                        <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; margin-bottom: 20px;height:100%">
                                        <div class="d-block">
                                            <div class="dot red"></div>
                                            <div class="dot orange"></div>
                                            <div class="dot yellow"></div>
                                            <div class="dot green"></div>
                                            <div class="dot teal"></div>
                                            <div class="dot blue"></div>
                                            <div class="dot violet"></div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                    <!-- WEEK -->
                    <div class="tab-pane fade"
                        id="week_info">
                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-header bg-white border-bottom">
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    
                                    <div class="d-flex align-items-center gap-2">
                                        <div>
                                            <h5 class="fw-bold mb-0">
                                                Staff Performance Dashboard
                                            </h5>
                                            <small class="text-muted"
                                                id="report-period-label">
                                                Week Report
                                            </small>
                                        </div>
                                        <div class="align-self-start">
                                            <span class="badge bg-primary-subtle text-primary">
                                                Live Analytics
                                            </span>
                                        </div>
                                    </div>

                                    <div class="align-self-start" id="staff-profile-week">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="card-body" style="min-height:500px;">

                                <div class="text-center text-muted mt-5" id="staff-details-week">
                                    <i class="mdi mdi-account-circle-outline fs-1"></i>
                                    <p class="mt-3">
                                        Select a staff to view report
                                    </p>
                                </div>

                            </div>

                        </div>
                    </div>

                    <!-- MONTH -->
                    <div class="tab-pane fade"
                        id="month_info">
                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-header bg-white border-bottom">
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    
                                    <div class="d-flex align-items-center gap-2">
                                        <div>
                                            <h5 class="fw-bold mb-0">
                                                Staff Performance Dashboard
                                            </h5>
                                            <small class="text-muted"
                                                id="report-period-label">
                                                Month Report
                                            </small>
                                        </div>
                                        <div class="align-self-start">
                                            <span class="badge bg-primary-subtle text-primary">
                                                Live Analytics
                                            </span>
                                        </div>
                                    </div>

                                    <div class="align-self-start" id="staff-profile-month">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="card-body" style="min-height:500px;" id="staff-details-month">

                                <div class="text-center text-muted mt-5">
                                    <i class="mdi mdi-account-circle-outline fs-1"></i>
                                    <p class="mt-3">
                                        Select a staff to view report
                                    </p>
                                </div>

                            </div>

                        </div>
                    </div>

                    <!-- YEAR -->
                    <div class="tab-pane fade"
                        id="year_info">
                        <div class="card border-0 shadow-sm h-100">

                            <div class="card-header bg-white border-bottom">
                                <div class="d-flex justify-content-between align-items-center w-100">
                                    
                                    <div class="d-flex align-items-center gap-2">
                                        <div>
                                            <h5 class="fw-bold mb-0">
                                                Staff Performance Dashboard
                                            </h5>
                                            <small class="text-muted"
                                                id="report-period-label">
                                                Year Report
                                            </small>
                                        </div>
                                        <div class="align-self-start">
                                            <span class="badge bg-primary-subtle text-primary">
                                                Live Analytics
                                            </span>
                                        </div>
                                    </div>

                                    <div class="align-self-start" id="staff-profile-year">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="card-body" style="min-height:500px;">

                                <div class="text-center text-muted mt-5" id="staff-details-year">
                                    <i class="mdi mdi-account-circle-outline fs-1"></i>
                                    <p class="mt-3">
                                        Select a staff to view report
                                    </p>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

</div>




    <div class="modal fade" id="aiUsageModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                        <div class="row mb-2">
                            <h3 class="text-black" id="aiUsageModalLabel">AI Usage Details</h3>
                        </div>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white ">
                    <div class="modal-body" id="aiUsageModalBody">
                        <div class="text-center py-5">
                        <div class="spinner-border text-primary"></div>
                        <p class="mt-3 text-muted">Loading AI usage...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <div class="modal fade" id="applicationUsageModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                        <div class="row mb-2">
                            <h3 class="text-black" id="applicationUsageTitle">Usage Details</h3>
                        </div>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 pt-5 bg-white ">
                    <div  id="applicationUsageBody">
                        <div class="text-center py-5">
                        <div class="spinner-border text-primary"></div>
                        <p class="mt-3 text-muted">Loading usage...</p>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

<!--begin::Modal Filter--->
<div class="modal fade" id="kt_modal_staff_report" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Staff Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form  method="POST" action="{{ route('update_staff_timestamp_report') }}" enctype="multipart/form-data" autocomplete="off" id="updateTimestampForm">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="row mb-3">
                    <div class="col-lg-12 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                         <input type="text" id="date_timestamp_edit" name="date" placeholder="Select Date" class="form-control common_datepicker" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Timechamp data :</label>
                        <span lass="text-black mb-1 fs-6 fw-semibold "id="total_timestamp_data">0 </span>Record Found
                      
                    </div>
                </div>
                <!--end::Modal body-->
                <div class="d-flex justify-content-end align-items-center pb-2 mt-4">
                    <button type="button" class="btn btn-primary me-3" id="submitTimestampBtn" onclick="submit_timestamp_form()">Update Staff Timechamp</button>
                </div>
            </div>
            </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Filter-->

 <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

<script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
   
     
<script>
    function open_update_staffId(){
        loadCompanyStaff(0);
    }

// CLICK COMPANY TAB
$(document).on("click", ".company-tab", function () {
    let companyId = $(this).data("company");
    loadCompanyStaff(companyId);
});

// COMMON FUNCTION TO LOAD STAFF
function loadCompanyStaff(companyId) {

    $("#companyStaffList").html(`
        <div class="text-center py-5">
            <div class="spinner-border"></div>
            <p>Loading staff...</p>
        </div>
    `);

    $.ajax({
        url: "/get-company-staff",
        type: "GET",
        data: { company_id: companyId },
        success: function (res) {

            // RENDER STAFF TABLE HTML COMING FROM BACKEND
            $("#companyStaffList").html(res.staff_html);

            // Show Bulk Update button when list loads
            $("#bulkUpdateContainer").show();
        }
    });
}

// BULK UPDATE BUTTON CLICK
$("#bulkUpdateBtn").on("click", function () {

    let updates = [];

    $(".staff-id-input").each(function () {
        let sno = $(this).data("sno");
        let newId = $(this).val();
        updates.push({ sno: sno, staff_id: newId });
    });

    $.ajax({
        url: "/bulk-update-staff-id",
        type: "POST",
        data: {
            _token: $("meta[name='csrf-token']").attr("content"),
            updates: updates
        },
        success: function (res) {
            toastr.success("Bulk Update Successful!");
        }
    });
});

</script>

<script>
/* =========================================================
   STAFF TIMECHAMP PRODUCTION DASHBOARD
========================================================= */
let globalStaffData =null;
let globalType ='day';
let loaderEgc =document.getElementById(`loadingScreenegc-${globalType}`);
const StaffTimechamp = {

    selectedStaff: null,
    activeType: 'day',
    

    init() {
        this.bindEvents();
    },

    bindEvents() {

        // Tab Change
        $('button[data-bs-toggle="tab"]').on('shown.bs.tab', (e) => {
            const target = $(e.target).data("bs-target");
            this.activeType = target.replace('#','').replace('_info','');
            this.updateHeaderLabel();
            this.renderProfile();
            this.loadReport();
            globalType=this.activeType;
        });

        // Date change
        $(document).on('change', '#global_date_picker', () => {
            this.loadReport();
        });
    },

    updateHeaderLabel(){
        $('#report-period-label').text(
            currentViewType.charAt(0).toUpperCase() + currentViewType.slice(1) + " Report"
        );
    },

    selectStaff(item){

        document.querySelectorAll(".staff-item")
            .forEach(el => el.classList.remove("staff-selected"));

        document.getElementById("staff-" + item.sno)
            .classList.add("staff-selected");

        const data = typeof item.data === 'string'
            ? JSON.parse(item.data)
            : item.data;

        this.selectedStaff = {
            sno: item.sno,
            name: item.staff_name,
            gender: item.gender,
            staff_id: data.staff_id,
            timechamp_id: data.timechamp_id,
            image: data.staff_image,
            company_type: data.company_type,
            company_id: data.company_id,
            entity_id: data.entity_id
        };
        globalStaffData = this.selectedStaff;

        this.renderProfile();
        this.loadReport();
    },

    loadReport(){
        
        loaderEgc.style.display='block';
        
        if(!this.selectedStaff || !this.selectedStaff.timechamp_id) return;

        const date = $('#global_date_picker').val();

        this.showLoader();

        $.ajax({
            url: `/timechamp/staff-report`,
            type: "GET",
            data: {
                staff_id: this.selectedStaff.timechamp_id,
                date: date,
                type: this.activeType,
            },
            success: (res) => {

                if(res.status && res.data){
                    console.log(res)
                    loaderEgc.style.display='none';
                    this.renderReport(res.data[0]);
                }else{
                    this.renderEmpty();
                }
            },
            error: () => {
                this.renderEmpty();
            }
        });
    },

    renderProfile(){
        
        console.log("resm")
        let image = '';

        if (this.selectedStaff.image && this.selectedStaff.image.trim() !== '') {

            if (this.selectedStaff.company_type == 1) {
                image = `staff_images/Management/${this.selectedStaff.image}`;
            } else {
                image = `staff_images/Buisness/${this.selectedStaff.company_id}/${this.selectedStaff.entity_id}/${this.selectedStaff.image}`;
            }

        } else {
            image = this.selectedStaff.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }

        image = `{{ asset('${image}') }}`;
        $(`#staff-profile-${this.activeType}`).html(`
           
            <div class="d-flex align-items-center gap-2">
                <div class="text-end">
                    <h4 class="fw-bold mb-1">${this.selectedStaff.name}</h4>
                    <span class="badge bg-primary mb-1">${this.selectedStaff.gender == 1 ? "Male" : "Female"}</span>
                    <div class="text-muted small">${this.selectedStaff.staff_id}</div>
                </div>
                <img src="${image}" class="staff-avatar me-3" style="width:70px;height:70px;">
            </div>
            
        `);
        
        $(`#staff-details-${this.activeType}`).html(`
            <div id="report-content-${this.activeType}"></div>
        `);
    },

    renderReport(d){
        console.log(d)
      
        let startsummaryTime = this.activeType == 'day' ? this.card("Start Time", formatTime(d.startDateTime), "mdi-clock-start", "#4a6cf7") :'';
        let endsummaryTime = this.activeType == 'day' ? this.card("End Time", formatTime(d.finishDateTime), "mdi-clock-end", "#6f42c1") :'';
        $(`#report-content-${this.activeType}`).html(`
            <div class="p-4">
                <div class="row g-3">
            
                    ${startsummaryTime}
                    ${endsummaryTime}
                    ${this.card("Working Time", d.workingTime, "mdi-timer-outline", "#198754")}

                    ${this.card("Productive", d.productiveTime, "mdi-trending-up", "#28a745")}
                    ${this.card("Non Productive", d.nonProductiveTime, "mdi-alert-circle-outline", "#dc3545")}
                    ${this.card("Neutral", d.neutralTime, "mdi-minus-circle-outline", "#ffc107")}

                    ${this.card("Away", d.awayTime, "mdi-account-off", "#fd7e14")}
                    ${this.card("Online", d.onlineTime, "mdi-wifi", "#0dcaf0")}
                    ${this.card("Offline", d.offlineTime, "mdi-wifi-off", "#6c757d")}
                    ${this.card("AI Usage", d.aiUsageTime, "mdi mdi-robot", "#530066")}

                </div>
            </div>
        `);
    },

    renderEmpty(){
        loaderEgc.style.display='none';
        $('#report-content').html(`
            <div class="text-center py-5 text-muted">
                <i class="mdi mdi-database-off fs-1"></i>
                <p class="mt-3">No data available.</p>
            </div>
        `);
    },

    showLoader(){
        $('#report-content').html(`
            <div class="text-center py-5">
                <div class="spinner-border text-primary"></div>
                <p class="mt-3 text-muted">Loading ${this.activeType} report...</p>
            </div>
        `);
    },

    card(title, value, icon, color){
        let filter = '';

        if(title === "Productive") filter = "Productive";
        if(title === "Non Productive") filter = "UnProductive";
        if(title === "Neutral") filter = "Neutral";
        return `
            <div class="col-md-4">
                <div class="card mini-card shadow-sm border-0 cursor-pointer usageModal ${title == "AI Usage" ? "aiModal" : ""}" data-filter="${filter}">
                    <div class="card-body d-flex align-items-center">
                        <div class="icon-box me-3" 
                             style="background:${color}15;color:${color}">
                            <i class="mdi ${icon} fs-4"></i>
                        </div>
                        <div>
                            <div class="text-muted small">${title}</div>
                            <div class="fw-bold fs-5">${value || '00:00:00'}</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

  
};

    // Initialize
    $(document).ready(function(){
        StaffTimechamp.init();
    });

    // Make selectStaff globally accessible
    function selectStaff(item){
        StaffTimechamp.selectStaff(item);
    }

    function formatTime(timeString) {
        if (!timeString) return "00:00";

        // Convert to JS Date
        const date = new Date(timeString);

        if (isNaN(date)) return "00:00";

        let hours = date.getHours();
        let minutes = date.getMinutes().toString().padStart(2, "0");
        let seconds = date.getSeconds().toString().padStart(2, "0");

        let ampm = hours >= 12 ? "PM" : "AM";

        hours = hours % 12;
        hours = hours ? hours : 12; // 0 → 12

        return `${hours.toString().padStart(2, "0")}:${minutes}:${seconds} ${ampm}`;
    }
</script>

   <script>
     function submit_form() {
        const form = document.getElementById("addOldStaffForm");
        const submitBtn = document.getElementById("submitStaffBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
    function submit_timestamp_form() {
        const form = document.getElementById("updateTimestampForm");
        const submitBtn = document.getElementById("submitTimestampBtn");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                }
            });
        }
    }
   </script>

   <script>
    // Example: Add event listeners to staff list items to show their details on the right side.
    // function selectStaff(item) {
    //     // highlight selected
    //     document.querySelectorAll(".staff-item").forEach(el => el.classList.remove("staff-selected"));
    //     document.getElementById("staff-" + item.sno).classList.add("staff-selected");
    //     var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
    //     let date = document.getElementById("date_timestamp").value;
    //     var staff_id =data.timechamp_id;
    //     // if (staff_id) {
    //     //     // Fetch and populate states based on selected country
    //     //     $.ajax({
    //     //         url: "{{ route('get_staff_daily_timestamp') }}",
    //     //         type: "GET",
    //     //         data: {
    //     //             staff_id: staff_id,
    //     //             date:date
    //     //         },
    //     //         success: function(response) {
    //     //             console.log(response)
    //     //         },
    //     //         error: function(error) {
    //     //             console.error('Error fetching report:', error);
    //     //         }
    //     //     });
    //     // }

    //     if (staff_id) {
    //         $.ajax({
    //             url: "{{ route('get_staff_daily_timestamp') }}",
    //             type: "GET",
    //             data: {
    //                 staff_id: staff_id,
    //                 date: date
    //             },
    //             success: function (response) {
    //                 console.log(response);

    //                 if (response.status === true && response.data.length > 0) {
    //                     updateDetails(item, data, response.data[0]);  // send timestamp data
    //                 } else {
    //                     updateDetails(item, data, null); // no logs
    //                 }
    //             },
    //             error: function (error) {
    //                 console.error("Timechamp Error:", error);
    //                 updateDetails(item, data, null);
    //             }
    //         });
    //     }
        
    // }
    // function formatTime(timeString) {
    //     if (!timeString) return "00:00";

    //     // Convert to JS Date
    //     const date = new Date(timeString);

    //     if (isNaN(date)) return "00:00";

    //     let hours = date.getHours();
    //     let minutes = date.getMinutes().toString().padStart(2, "0");
    //     let seconds = date.getSeconds().toString().padStart(2, "0");

    //     let ampm = hours >= 12 ? "PM" : "AM";

    //     hours = hours % 12;
    //     hours = hours ? hours : 12; // 0 → 12

    //     return `${hours.toString().padStart(2, "0")}:${minutes}:${seconds} ${ampm}`;
    // }

    // function updateDetails(item, staff, logs) {

    //     let staff_image = '';

    //     if (staff.staff_image && staff.staff_image.trim() !== '') {
    //         if (staff.company_type == 1) {
    //             staff_image = `staff_images/Management/${staff.staff_image}`;
    //         } else {
    //             staff_image = `staff_images/Buisness/${staff.company_id}/${staff.entity_id}/${staff.staff_image}`;
    //         }
    //     } else {
    //         staff_image = staff.gender == 1
    //             ? 'assets/egc_images/auth/user_2.png'
    //             : 'assets/egc_images/auth/user_7.png';
    //     }

    //     staff_image = `{{ asset('${staff_image}') }}`;

    //     let d = logs || {}; // fallback if no logs

    //     const staffDetails = document.getElementById('staff-details');

    //     staffDetails.innerHTML = `
    //         <div class="p-3">

    //             <!-- Profile -->
    //             <div class="d-flex align-items-center mb-4">
    //                 <img src="${staff_image}" class="staff-avatar me-3" style="width:70px;height:70px;">
    //                 <div>
    //                     <h4 class="fw-bold mb-1">${item.staff_name}</h4>
    //                     <span class="badge bg-primary">${item.gender == 1 ? "Male" : "Female"}</span>
    //                     <div class="text-muted small">Employee ID: ${staff.staff_id}</div>
    //                 </div>
    //             </div>

    //             <!-- Mini Cards -->
    //             <div class="row g-3">

    //                 ${miniCard("Start Time", formatTime(d.startDateTime) || "00:00")}
    //                 ${miniCard("Working Time", d.workingTime || "00:00:00")}
    //                 ${miniCard("Last Seen", formatTime(d.finishDateTime) || "—")}

    //                 ${miniCard("Productive Time", d.productiveTime || "00:00:00")}
    //                 ${miniCard("Non Productive", d.nonProductiveTime || "00:00:00")}
    //                 ${miniCard("Neutral Time", d.neutralTime || "00:00:00")}

    //                 ${miniCard("Away Time", d.awayTime || "00:00:00")}
    //                 ${miniCard("Online Time", d.onlineTime || "00:00:00")}
    //                 ${miniCard("Offline Time", d.offlineTime || "00:00:00")}
    //             </div>

    //         </div>`;
    // }

    // function miniCard(title, value) {
    //     return `
    //         <div class="col-md-4">
    //             <div class="card shadow-sm border-0 mini-card">
    //                 <div class="card-body">
    //                     <div class="fw-semibold text-black fs-6">${title}</div>
    //                     <div class="fw-bold fs-5 mt-2">${value}</div>
    //                 </div>
    //             </div>
    //         </div>
    //     `;
    // }
    // // Update `buildRow` function to call `selectStaff` on click
    function buildRow(item) {
        var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;

        let staff_image = '';

        if (data.staff_image && data.staff_image.trim() !== '') {
            if (data.company_type == 1) {
                staff_image = `staff_images/Management/${data.staff_image}`;
            } else {
                staff_image = `staff_images/Buisness/${data.company_id}/${data.entity_id}/${data.staff_image}`;
            }
        } else {
            staff_image = data.gender == 1
                ? 'assets/egc_images/auth/user_2.png'
                : 'assets/egc_images/auth/user_7.png';
        }

        staff_image = `{{ asset('${staff_image}') }}`;

        return `
            <li id="staff-${item.sno}" 
                class="list-group-item staff-item"
                onclick='selectStaff(${JSON.stringify(item)})'>
                
                <div class="d-flex align-items-center">
                    <img src="${staff_image}" class="staff-avatar me-3">

                    <div>
                        <div class="fw-semibold">${item.staff_name}</div>
                        <small class="text-muted">${data.staff_id}</small>
                    </div>
                </div>
            </li>
        `;
    }

</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id =@json($user_id);

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }
   
 
    function loadThemes(page = 1) {
        // const perpage = document.getElementById('perpage').value;
        const search_staff = document.getElementById('staff_search').value;
        const company_fill = document.getElementById('company_fill').value;
        // const to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt').value;
        // const from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt').value;
        // const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        // const job_role_fill = document.getElementById('job_role_fill').value;
        // const division_fill = document.getElementById('division_fill').value;
        // const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_management/staff_timechamp?page=${page}&search_filter=${search_staff}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=&division_fill=&job_role_fill=&dt_fill_issue_rpt=&from_dt_iss_rpt=&to_dt_iss_rpt=`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                // updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <li class="skeleton-loader" id="skeleton-loader">
                <div style="position:relative;" class="skeleton-cell">
                    <div class="skeleton"></div>
                </div>
             </li>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="7" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;
    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };

    let searchTimer;

    $('#staff_search').on('keyup', function () {
        clearTimeout(searchTimer);

        searchTimer = setTimeout(() => {
            loadThemes(1);
        }, 400);
    });

    // SearchBar
    // document.getElementById('search_filter').addEventListener('input', function() {
    //     const searchValue = document.getElementById('search_filter').value;
    //     if (searchValue) {
    //         document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
    //     } else {
    //         document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
    //     }
    // });

     // Listen for changes in the perpage dropdown and reload data
    // document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    // document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    // document.getElementById('refreshSearch').addEventListener('click', function() {
    //     document.getElementById('search_filter').value = '';  // Clear the search input
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    // document.getElementById('searchSubmit').addEventListener('click', function() {
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    //  document.getElementById('filterSubmit').addEventListener('click', function() {
    //     loadThemes(1);  // Reload the table data without the search filter
    // });

    // Initial load
    loadThemes(1);

</script>

<script>
  function formatDate(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    // Get the day, month (abbreviated), and year
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
    const year = date.getFullYear(); // Get full year

    // Construct and return the formatted date string
    return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
  }
</script>

<script>
   

    function clearFilter() {
        document.getElementById('filter_div').style.display = 'none';
        location.reload();
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
 <script>
$(document).ready(function() {

    // When company changes
    $('#staff_company_name').on('change', function() {
        var companyId = $(this).val();
        var entityDropdown = $('#staff_entity_name');

        // Reset dropdown
        entityDropdown.empty().append('<option value="">Select Entity</option>');

        if (companyId) {
            $.ajax({
                url: "{{ route('entity_list') }}",
                type: "GET",
                data: { company_id: companyId },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            entityDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .attr('data-baseurl', entity.entity_base_url)
                                    .text(entity.entity_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
    });

    // When entity changes
    $('#staff_entity_name').on('change', function() {
         $('#staff_add_btn').prop('disabled', true);
         $('#staff_data_payload').val('');
         $('#total_Staff_data').text('0');
          var entityId = $(this).val();
          const verify_key='egcsecret2030datagetapierp';
         var branchDropdown = $('#staff_branch_name');
         if (entityId) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: { entity_id: entityId},
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(entity) {
                            branchDropdown.append(
                                $('<option></option>')
                                    .attr('value', entity.sno)
                                    .text(entity.branch_name)
                            );
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching entities:', error);
                }
            });
        }
        var baseurl = $(this).find(':selected').data('baseurl'); // ✅ Correct way
        if (baseurl) {
            var url = baseurl + 'api/staff_data_get';
            $.ajax({
                url: url,
                type: "GET",
                data:{auth_key:verify_key},
                success: function(response) {
                    console.log('response:', response);
                    if (response.status === 200 && response.data) {
                        console.log(response.data);
                        var length=response.data.length;
                        var staffData =response.data;
                        $('#total_Staff_data').text(length+' ')
                        // TODO: handle data display or form updates here
                        if(length > 0){
                            $('#staff_add_btn').prop('disabled', false);
                            // $('#staff_data_payload').val(JSON.stringify(staffData));
                        }else{
                             $('#staff_add_btn').prop('disabled', true);
                        }
                    }
                },
                error: function(error) {
                    console.error('Error fetching staff data:', error);
                }
            });
        }
    });

});
</script>

 <!-- status Change -->
 <script>
    function updatelevelStatus(Id, isChecked) {
        const status = isChecked ? 0 : 1;
        fetch(`/staff_status/${Id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                      loadThemes(currentPage);
                }
            })
            .catch(error => {});
    }

    
</script>

<!-- Delete Function -->
<script>
      function confirmDelete(id,staff) {
  
          document.querySelector('#kt_modal_delete_staff .btn-danger').setAttribute('data-id', id);
          $('#delete_message').html(
              'Are you sure you want to delete Staff ?<br><br> <b class="text-black fw-bold fs-4">' +
              staff +
              '</b>');
      }

      function deleteFunc() {
          var categoryId = document.querySelector('#kt_modal_delete_staff .btn-danger').getAttribute('data-id');

          fetch('/staff_delete/' + categoryId, {
                  method: 'DELETE',
                  headers: {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': '{{ csrf_token() }}'
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                  }
              })
              .catch(error => {
                toastr.error(error);
              });
      }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    function getExperienceDuration(joinDate) {
    if (!joinDate) return '-';

    const start = new Date(joinDate);
    const now = new Date();

    if (isNaN(start)) return '-'; // invalid date safeguard

    // Determine direction
    const isFuture = start > now;
    const earlier = isFuture ? now : start;
    const later = isFuture ? start : now;

    // Calculate raw differences
    let years = later.getFullYear() - earlier.getFullYear();
    let months = later.getMonth() - earlier.getMonth();
    let days = later.getDate() - earlier.getDate();

    // Adjust days
    if (days < 0) {
        const prevMonth = new Date(later.getFullYear(), later.getMonth(), 0);
        days += prevMonth.getDate();
        months--;
    }

    // Adjust months
    if (months < 0) {
        months += 12;
        years--;
    }

    // Build result text
    let result = '';
    if (years > 0) result += `${years} yr${years > 1 ? 's' : ''} `;
    if (months > 0) result += `${months} month${months > 1 ? 's' : ''} `;
    if (days > 0) result += `${days} day${days > 1 ? 's' : ''}`;

    if (!result.trim()) result = '0 days';

        result = result.trim();

        // Add "In" or "Ago"
        if (isFuture) {
            result = `In ${result}`;
        } else if (result !== '0 days') {
            // result += ' ago';
            result += '';
        }

        return result;
    }

    function getNextBDayDate(dob) {
        if (!dob) return { short: '-', full: '-' };

        const birthDate = new Date(dob);
        if (isNaN(birthDate)) return { short: '-', full: '-' };

        const today = new Date();

        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (nextBirthday < today) nextBirthday.setFullYear(today.getFullYear() + 1);

        const diffMs = nextBirthday - today;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            return { short: '🎉 Today', full: '🎉 Happy Birthday!' };
        }

        let years = nextBirthday.getFullYear() - today.getFullYear();
        let months = nextBirthday.getMonth() - today.getMonth();
        let days = nextBirthday.getDate() - today.getDate();

        if (days < 0) {
            const prevMonth = new Date(nextBirthday.getFullYear(), nextBirthday.getMonth(), 0);
            days += prevMonth.getDate();
            months--;
        }

        if (months < 0) {
            months += 12;
            years--;
        }

        // Build readable text
        let full = '';
        if (years > 0) full += `${years} year${years > 1 ? 's' : ''} `;
        if (months > 0) full += `${months} month${months > 1 ? 's' : ''} `;
        if (days > 0) full += `${days} day${days > 1 ? 's' : ''}`;
        if (!full.trim()) full = `${diffDays} days`;
        full = `${full.trim()} to go 🎂`;

        // Short text (for compact badge)
        let short = '';
        if (months > 0) short += `${months}M `;
        if (days > 0) short += `${days}D`;
        if (!short.trim()) short = `${diffDays}D`;

        return { short: short.trim(), full };
    }

</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>

<script>
     $(document).ready(function() {
            // Business dropdown
            $('#company_fill').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_fill');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
                if(countryId == 'egc'){
                    loadThemes(currentPage);
                }
            });

            // depart list
            $('#entity_fill').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#department_fill');
                if(entity_id ){
                    loadThemes(currentPage);
                }

                stateDropdown.empty().append('<option value="">Select Department</option>');

                if (entity_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }

                
            });
            // division dropdown
             $('#department_fill').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#division_fill');
                stateDropdown.empty().append('<option value="">Select Division</option>');

                let erp_depert = $(this).find(':selected').data('erpdepartmentid');
                $('#erp_department_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpdivisionid', state.erp_division_id)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
             });

              $('#division_fill').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#job_role_fill');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                let erp_depert = $(this).find(':selected').data('erpdivisionid');
                $('#erp_division_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpjobroleid', state.erp_job_role_id)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
             });

        })
</script>
<script>

let datePicker;
let currentViewType = "day";

document.addEventListener("DOMContentLoaded", function () {

    initDatePicker("day");

    // Detect tab change
    $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {

        let target = $(e.target).data("bs-target");

        currentViewType = target.replace('#','').replace('_info','');

        initDatePicker(currentViewType);

        // Optional: reload report
        if(typeof StaffTimechamp !== "undefined"){
            StaffTimechamp.loadReport();
        }
    });

});



</script>

<script>
   let curr_date = "{{date('d-M-Y')}}";
let curr_month = "{{date('M-Y')}}";
let curr_year = "{{date('Y')}}";
let weekStart = null;
let weekEnd = null;
let flatInstance = null;

function initDatePicker(type) {
    const input = "#global_date_picker";

    // Destroy existing
    if ($(input).data('datepicker')) {
        $(input).datepicker('destroy');
    }

    if (flatInstance) {
        flatInstance.destroy();
        flatInstance = null;
    }


    $(input).val('');
    
    

    /* ================= DAY ================= */
    if (type === "day") {
        $(input).datepicker({
            format: 'dd-M-yyyy',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        }).datepicker('setDate', new Date());

        $(input).val(curr_date);
    }

    /* ================= WEEK ================= */
    // else if (type === "week") {

    //     $(input).datepicker({
    //         format: 'dd-M-yyyy',
    //         todayHighlight: true,
    //         autoclose: false,
    //         endDate: new Date(),
    //         orientation: 'bottom'
    //     }).on('changeDate', function(e) {
    //         let selected = e.date;
    //         if (!selected) return;

    //         // Calculate start (Monday) and end (Sunday) of the week
    //         let day = selected.getDay();
    //         let diff = selected.getDate() - day + (day === 0 ? -6 : 1);
    //         weekStart = new Date(selected);
    //         weekStart.setHours(0,0,0,0);
    //         weekStart.setDate(diff);
    //         weekEnd = new Date(weekStart);
    //         weekEnd.setDate(weekStart.getDate() + 6);

    //         // Set input value as week range
    //         $(this).val(formatDate(weekStart) + " - " + formatDate(weekEnd));

    //         // Close manually
    //         $(this).datepicker('hide');

    //         // Trigger report with full week range
    //         if (typeof StaffTimechamp !== "undefined") {
    //             StaffTimechamp.loadReport(weekStart, weekEnd); // pass start & end
    //         }
    //     });

    //     // Set default week (current week)
    //     let today = new Date();
    //     let day = today.getDay();
    //     let diff = today.getDate() - day + (day === 0 ? -6 : 1);
    //     weekStart = new Date(today);
    //     weekStart.setHours(0,0,0,0);
    //     weekStart.setDate(diff);
    //     weekEnd = new Date(weekStart);
    //     weekEnd.setDate(weekStart.getDate() + 6);

    //     $(input).datepicker('setDate', today);
    //     $(input).val(formatDate(weekStart) + " - " + formatDate(weekEnd));
    // }

   else if (type === "week") {

        flatInstance = flatpickr(input, {
            plugins: [new weekSelect({})],
            dateFormat: "Y-\\WW",
            defaultDate: "today",
            maxDate: "today"
        });
    }

    /* ================= MONTH ================= */
    else if (type === "month") {
        $(input).datepicker({
            format: 'M-yyyy',
            viewMode: 'months',
            minViewMode: 'months',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        }).datepicker('setDate', new Date());

        $(input).val(curr_month);
    }

    /* ================= YEAR ================= */
    else if (type === "year") {
        $(input).datepicker({
            format: 'yyyy',
            viewMode: 'years',
            minViewMode: 'years',
            todayHighlight: true,
            autoclose: true,
            endDate: new Date(),
            orientation: 'bottom'
        }).datepicker('setDate', new Date());

        $(input).val(curr_year);
    }
}


// Helper function for date formatting
function formatDate(date) {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    let day = String(date.getDate()).padStart(2, '0');
    let month = months[date.getMonth()];
    let year = date.getFullYear();
    return `${day}-${month}-${year}`;
}


$(document).on('click', '.aiModal', () => {
    console.log('AI Modal Clicked. Selected Staff:', globalStaffData);
    if(!globalStaffData || !globalStaffData.timechamp_id) return;

    $('#aiUsageModalBody').html(`
        <div class="text-center py-5">
            <div class="spinner-border text-primary"></div>
            <p class="mt-3 text-muted">Loading AI usage...</p>
        </div>
    `);

    const date = $('#global_date_picker').val();

    $.ajax({
        url: `/timechamp/ai-usage-details`,
        type: 'GET',
        data: {
            staff_id: globalStaffData.timechamp_id,
            type: globalType,
            date: date
        },
        success: (res) => {
            if(res.status && res.data.length){
                let html = '<div class="row g-3">';
                res.data.forEach(item => {
                    html += `
                        <div class="col-md-6">
                            <div class="card shadow-sm">
                                <div class="card-body d-flex align-items-center">
                                    <img src="${item.ai_info.logo || 'assets/egc_images/auth/user_2.png'}" class="me-3 rounded-circle" style="width:40px;height:40px;">
                                    <div>
                                        <h6 class="mb-1">${item.ai_info.name || item.applicationName}</h6>
                                        <p class="mb-0 text-muted">${item.ai_info.desc || ''}</p>
                                        <div class="text-small mt-1">Time Spent: ${formatSeconds(item.spentTimeInSeconds)}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
                html += '</div>';
                $('#aiUsageModalBody').html(html);
            } else {
                $('#aiUsageModalBody').html(`
                    <div class="text-center py-5 text-muted">
                        <i class="mdi mdi-database-off fs-1"></i>
                        <p class="mt-3">No AI usage found.</p>
                    </div>
                `);
            }
        },
        error: () => {
            $('#aiUsageModalBody').html(`
                <div class="text-center py-5 text-danger">
                    <p>Failed to load AI usage. Try again.</p>
                </div>
            `);
        }
    });

    new bootstrap.Modal(document.getElementById('aiUsageModal')).show();
});
function formatSeconds(seconds){
    if(!seconds) return "00:00:00";
    const h = Math.floor(seconds / 3600).toString().padStart(2,'0');
    const m = Math.floor((seconds % 3600)/60).toString().padStart(2,'0');
    const s = Math.floor(seconds % 60).toString().padStart(2,'0');
    return `${h}:${m}:${s}`;
}
</script>

<script>
    $(document).on('click', '.usageModal', function(){

    const filterType = $(this).data('filter');
    if(!filterType) return;

    if(!globalStaffData || !globalStaffData.timechamp_id) return;

    $('#applicationUsageTitle').text(`${filterType} Details`);

    $('#applicationUsageBody').html(`
        <div class="text-center py-5">
            <div class="spinner-border text-primary"></div>
        </div>
    `);

    const date = $('#global_date_picker').val();

    $.ajax({
        url: '/timechamp/application-usage-details',
        type: 'GET',
        data: {
            staff_id: globalStaffData.timechamp_id,
            date: date,
            day_type: globalType,
            type_filter: filterType
        },
        success: function(res){

            if(res.status && res.data.length){

                let html = `
                    <div class="mb-4">
                        <h4>Total Time: 
                            <span class="badge bg-primary">
                                ${res.formatted_total}
                            </span>
                        </h4>
                    </div>
                    <div class="table-responsive">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead >
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th>Application</th>
                                <th>Computer</th>
                                <th>Time Spent</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                `;

                res.data.forEach(item => {
                    html += `
                        <tr>
                            <td>
                                <strong>${item.applicationName}</strong>
                            </td>
                            <td>${item.computer}</td>
                            <td>
                                <span class="badge bg-warning text-black fw-bold">
                                    ${formatSeconds(item.spentTimeInSeconds)}
                                </span>
                            </td>
                        </tr>
                    `;
                });

                html += `
                        </tbody>
                    </table>
                    </div>
                `;

                $('#applicationUsageBody').html(html);

            } else {

                $('#applicationUsageBody').html(`
                    <div class="text-center py-5 text-muted">
                        <i class="mdi mdi-database-off fs-1"></i>
                        <p>No ${filterType} applications found.</p>
                    </div>
                `);
            }
        },
        error: function(){
            $('#applicationUsageBody').html(`
                <div class="text-center py-5 text-danger">
                    Failed to load data.
                </div>
            `);
        }
    });

    new bootstrap.Modal(document.getElementById('applicationUsageModal')).show();
});
</script>
@endsection
