@extends('layouts/layoutMaster')

@section('title', 'CUG Management')

@section('vendor-style')

    @vite([
        'resources/assets/vendor/libs/select2/select2.scss',
        'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
    ])

@endsection



@section('vendor-script')

    @vite([
        'resources/assets/vendor/libs/select2/select2.js',
        'resources/assets/vendor/libs/flatpickr/flatpickr.js'
    ])

@endsection



@section('content')

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">

<style>
    /* =========================================================
    CUG MANAGEMENT
    Production UI Foundation
    ========================================================= */

    :root {
        --primary: #8f1d1d;
        --primary-2: #b52b25;
        --accent: #f5a623;

        --bg: #f4f6f9;
        --card: #ffffff;

        --text: #172033;
        --muted: #6b7280;
        --border: #e5e7eb;

        --success: #16a34a;
        --warning: #d97706;
        --danger: #dc2626;

        --cug-primary-soft: rgba(143, 29, 29, 0.08);
        --cug-primary-soft-2: rgba(143, 29, 29, 0.04);

        --cug-success-soft: rgba(22, 163, 74, 0.09);
        --cug-warning-soft: rgba(217, 119, 6, 0.10);
        --cug-danger-soft: rgba(220, 38, 38, 0.09);

        --cug-radius-sm: 7px;
        --cug-radius-md: 10px;
        --cug-radius-lg: 14px;
        --cug-radius-xl: 16px;

        --cug-shadow-sm:
            0 2px 8px rgba(23, 32, 51, 0.04);

        --cug-shadow-md:
            0 8px 24px rgba(23, 32, 51, 0.08);

        --cug-transition:
            all 0.2s ease;
    }


    /* =========================================================
    PAGE
    ========================================================= */

    .cug-page {
        width: 100%;
        min-width: 0;
        color: var(--text);
    }

    .cug-page *,
    .cug-page *::before,
    .cug-page *::after {
        box-sizing: border-box;
    }


    /* =========================================================
    BOOTSTRAP PRIMARY OVERRIDE
    ========================================================= */

    .cug-page .btn-primary {
        --bs-btn-color: #fff;
        --bs-btn-bg: var(--primary);
        --bs-btn-border-color: var(--primary);

        --bs-btn-hover-color: #fff;
        --bs-btn-hover-bg: var(--primary-2);
        --bs-btn-hover-border-color: var(--primary-2);

        --bs-btn-active-color: #fff;
        --bs-btn-active-bg: var(--primary-2);
        --bs-btn-active-border-color: var(--primary-2);

        --bs-btn-disabled-color: #fff;
        --bs-btn-disabled-bg: var(--primary);
        --bs-btn-disabled-border-color: var(--primary);
    }


    /* =========================================================
    GENERAL BUTTONS
    ========================================================= */

    .cug-page .btn {
        font-weight: 600;
        transition: var(--cug-transition);
    }

    .cug-page .btn:focus-visible {
        outline: 0;
        box-shadow:
            0 0 0 3px rgba(143, 29, 29, 0.15);
    }

    .cug-page .btn-label-secondary {
        background: transparent;
        border-color: var(--border);
        color: var(--text);
    }

    .cug-page .btn-label-secondary:hover {
        background: var(--cug-primary-soft);
        border-color: rgba(143, 29, 29, 0.20);
        color: var(--primary);
    }


    /* =========================================================
    FORM CONTROLS
    ========================================================= */

    .cug-page .form-control,
    .cug-page .form-select {
        color: var(--text);
        background-color: var(--card);
        border-color: var(--border);
        transition:
            border-color .2s ease,
            box-shadow .2s ease;
    }

    .cug-page .form-control::placeholder {
        color: #9ca3af;
    }

    .cug-page .form-control:focus,
    .cug-page .form-select:focus {
        color: var(--text);
        border-color: var(--primary);
        box-shadow:
            0 0 0 .15rem rgba(143, 29, 29, .10);
    }

    .cug-page .form-control:disabled,
    .cug-page .form-select:disabled {
        background-color: #f8f9fa;
        cursor: not-allowed;
    }

    .cug-page .form-control.is-invalid,
    .cug-page .form-select.is-invalid {
        border-color: var(--danger);
    }

    .cug-page .form-control.is-invalid:focus,
    .cug-page .form-select.is-invalid:focus {
        box-shadow:
            0 0 0 .15rem rgba(220, 38, 38, .10);
    }


    /* =========================================================
    FORM LABELS
    ========================================================= */

    .cug-page .form-label {
        margin-bottom: 6px;
        color: var(--text);
        font-size: .78rem;
        font-weight: 600;
    }

    .cug-page .form-label .required {
        margin-left: 2px;
        color: var(--danger);
    }


    /* =========================================================
    SELECT2
    ========================================================= */

    .cug-page .select2-container {
        width: 100% !important;
    }

    .cug-page
    .select2-container--default
    .select2-selection--single {
        height: 42px;
        min-height: 42px;
        display: flex;
        align-items: center;

        background-color: var(--card);
        border: 1px solid var(--border);
        border-radius: var(--cug-radius-md);
    }

    .cug-page
    .select2-container--default
    .select2-selection--single
    .select2-selection__rendered {
        padding-left: 12px;
        padding-right: 35px;

        color: var(--text);
        font-size: .82rem;
        line-height: 40px;
    }

    .cug-page
    .select2-container--default
    .select2-selection--single
    .select2-selection__placeholder {
        color: #9ca3af;
    }

    .cug-page
    .select2-container--default
    .select2-selection--single
    .select2-selection__arrow {
        top: 1px;
        right: 8px;
        height: 40px;
    }

    .select2-container--default
    .select2-dropdown {
        z-index: 99999;
        overflow: hidden;

        border-color: var(--border);
        border-radius: 10px;

        box-shadow:
            0 10px 30px rgba(23, 32, 51, .12);
    }

    .select2-container--default
    .select2-search--dropdown
    .select2-search__field {
        border-color: var(--border);
        border-radius: 7px;
    }

    .select2-container--default
    .select2-search--dropdown
    .select2-search__field:focus {
        outline: 0;
        border-color: var(--primary);
    }

    .select2-container--default
    .select2-results__option {
        padding: 8px 10px;
        color: var(--text);
        font-size: .78rem;
    }

    .select2-container--default
    .select2-results__option--highlighted {
        background-color: var(--primary);
        color: #fff;
    }


    /* =========================================================
    DATE PICKER
    ========================================================= */

    .cug-page .flatpickr-input {
        cursor: pointer;
    }

    .flatpickr-calendar {
        z-index: 99999 !important;
        border: 1px solid var(--border);
        border-radius: 12px;

        box-shadow:
            0 10px 30px rgba(23, 32, 51, .12);
    }

    .flatpickr-calendar .flatpickr-day.selected,
    .flatpickr-calendar .flatpickr-day.startRange,
    .flatpickr-calendar .flatpickr-day.endRange {
        background: var(--primary);
        border-color: var(--primary);
    }

    .flatpickr-calendar .flatpickr-day:hover {
        background: var(--cug-primary-soft);
        border-color: transparent;
        color: var(--primary);
    }


    /* =========================================================
    BADGES
    ========================================================= */

    .cug-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;

        min-height: 24px;
        padding: 4px 8px;

        border-radius: 6px;

        font-size: .68rem;
        font-weight: 700;
        line-height: 1;
    }

    .cug-badge-primary {
        background: var(--cug-primary-soft);
        color: var(--primary);
    }

    .cug-badge-success {
        background: var(--cug-success-soft);
        color: var(--success);
    }

    .cug-badge-warning {
        background: var(--cug-warning-soft);
        color: var(--warning);
    }

    .cug-badge-danger {
        background: var(--cug-danger-soft);
        color: var(--danger);
    }


    /* =========================================================
    LOADING OVERLAY
    ========================================================= */

    .cug-loading-overlay {
        position: absolute;
        inset: 0;

        z-index: 50;

        display: flex;
        align-items: center;
        justify-content: center;

        background: rgba(255, 255, 255, .72);

        backdrop-filter: blur(2px);
    }

    .cug-loading-spinner {
        width: 34px;
        height: 34px;

        border: 3px solid rgba(143, 29, 29, .15);
        border-top-color: var(--primary);

        border-radius: 50%;

        animation:
            cugSpin .7s linear infinite;
    }

    @keyframes cugSpin {

        to {
            transform: rotate(360deg);
        }

    }


    /* =========================================================
    BUTTON LOADING
    ========================================================= */

    .cug-btn-loading {
        position: relative;
        pointer-events: none;
    }

    .cug-btn-loading .cug-btn-text {
        visibility: hidden;
    }

    .cug-btn-loading::after {
        content: "";

        position: absolute;

        top: 50%;
        left: 50%;

        width: 16px;
        height: 16px;

        margin-top: -8px;
        margin-left: -8px;

        border: 2px solid rgba(255, 255, 255, .35);
        border-top-color: #fff;

        border-radius: 50%;

        animation:
            cugSpin .65s linear infinite;
    }


    /* =========================================================
    SKELETON
    ========================================================= */

    .cug-skeleton {
        overflow: hidden;

        border-radius: 6px;

        background:
            linear-gradient(
                90deg,
                #f1f2f4 25%,
                #e7e9ec 37%,
                #f1f2f4 63%
            );

        background-size: 400% 100%;

        animation:
            cugSkeleton 1.4s ease infinite;
    }

    @keyframes cugSkeleton {

        0% {
            background-position: 100% 0;
        }

        100% {
            background-position: 0 0;
        }

    }


    /* =========================================================
    AJAX ERROR
    ========================================================= */

    .cug-ajax-error {
        padding: 18px;

        border: 1px solid rgba(220, 38, 38, .15);
        border-radius: 10px;

        background: rgba(220, 38, 38, .04);

        color: var(--danger);

        font-size: .78rem;
    }


    /* =========================================================
    TOOLTIP
    ========================================================= */

    .cug-page .tooltip-inner {
        max-width: 240px;
        padding: 6px 9px;

        border-radius: 6px;

        font-size: .68rem;
    }


    /* =========================================================
    SCROLLBAR
    ========================================================= */

    .cug-page ::-webkit-scrollbar {
        width: 7px;
        height: 7px;
    }

    .cug-page ::-webkit-scrollbar-track {
        background: transparent;
    }

    .cug-page ::-webkit-scrollbar-thumb {
        background: #d1d5db;
        border-radius: 20px;
    }

    .cug-page ::-webkit-scrollbar-thumb:hover {
        background: #9ca3af;
    }


    /* =========================================================
    ACCESSIBILITY
    ========================================================= */

    .cug-page button:focus-visible,
    .cug-page a:focus-visible,
    .cug-page input:focus-visible,
    .cug-page select:focus-visible {
        /* outline: 2px solid var(--primary); */
        /* outline-offset: 2px; */
    }


    /* =========================================================
    MOBILE
    ========================================================= */

    @media (max-width: 767.98px) {

        .cug-page .form-control,
        .cug-page .form-select {
            min-height: 40px;
        }

    }

    /* =========================================================
    HELPER LOADING OVERLAYS
    ========================================================= */

    .cug-page-loading-overlay,
    .cug-table-loading-overlay,
    .cug-modal-loading-overlay {
        position: absolute;
        inset: 0;
        z-index: 100;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, .72);
        backdrop-filter: blur(2px);
    }

    .cug-page-loading-overlay {
        position: fixed;
        z-index: 1090;
    }

    .cug-table-loading-overlay {
        border-radius: 16px;
    }

    .cug-modal-loading-overlay {
        border-radius: inherit;
    }

    /* =========================================================
    DASHBOARD LOADING
    ========================================================= */

    .cug-dashboard-fetching
    .cug-stat-card {
        cursor: wait;
    }

    .cug-dashboard-loading
    .cug-stat-value {
        opacity: .45;
        transition: opacity .2s ease;
    }

    .cug-dashboard-loading
    .cug-stat-mini-icon {
        opacity: .35;
    }

    .cug-dashboard-loading
    .cug-stat-card-footer {
        opacity: .55;
    }

    /* =========================================================
    DATATABLE PROCESSING
    ========================================================= */

    .cug-table-card .dataTables_processing {
        position: absolute !important;
        top: 50% !important;
        left: 50% !important;
        z-index: 20;

        width: auto !important;
        min-width: 180px;

        padding: 12px 16px !important;

        transform: translate(-50%, -50%);

        border: 1px solid var(--border) !important;
        border-radius: 10px !important;

        background: rgba(255, 255, 255, .95) !important;

        color: var(--text) !important;

        box-shadow:
            0 8px 25px rgba(23, 32, 51, .10);

        font-size: .75rem !important;
        font-weight: 600;
    }

    .cug-table-card .dataTables_length select {
        min-width: 65px;
        margin: 0 5px;
        border-color: var(--border);
        border-radius: 7px;
    }

    .cug-table-card .dataTables_length,
    .cug-table-card .dataTables_info {
        color: var(--muted);
        font-size: .72rem;
    }
</style>

<!-- CUG TOPBAR -->
<style>

    /* CUG TOPBAR */

  .cug-topbar {
      position: relative;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 20px 22px;
      box-shadow: 0 2px 8px rgba(23, 32, 51, 0.04);
  }

  .cug-page-icon {
      width: 48px;
      height: 48px;
      min-width: 48px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 12px;
      background: rgba(143, 29, 29, 0.10);
      color: var(--primary);
      font-size: 24px;
  }

  .cug-page-title {
      color: var(--text);
      font-size: 1.35rem;
      line-height: 1.35;
  }

  .cug-page-subtitle {
      margin-top: 3px;
      color: var(--muted);
      font-size: 0.82rem;
  }

  .cug-breadcrumb-icon {
      color: var(--muted);
      font-size: 13px;
  }

  .cug-topbar .btn {
      min-height: 40px;
      border-radius: 9px;
      font-weight: 600;
  }

  .cug-topbar .btn-primary {
      background: var(--primary);
      border-color: var(--primary);
  }

  .cug-topbar .btn-primary:hover,
  .cug-topbar .btn-primary:focus {
      background: var(--primary-2);
      border-color: var(--primary-2);
  }

  .cug-topbar .btn-label-secondary {
      color: var(--text);
  }

  .cug-topbar .btn-label-secondary:hover {
      background: rgba(143, 29, 29, 0.06);
      color: var(--primary);
  }

  .cug-topbar .btn-icon {
      width: 40px;
      height: 40px;
      padding: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
  }
</style>

<!-- CUG TOOLBAR -->
<style>
    /* CUG TOOLBAR  */

  .cug-toolbar {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 2px 8px rgba(23, 32, 51, 0.04);
  }

  .cug-toolbar-main {
      display: grid;
      grid-template-columns:
          minmax(260px, 1.8fr)
          minmax(170px, 1fr)
          minmax(170px, 1fr)
          minmax(150px, .85fr)
          auto
          auto;
      gap: 12px;
      align-items: end;
  }

  .cug-search-wrapper {
      position: relative;
  }

  .cug-search-icon {
      position: absolute;
      left: 13px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--muted);
      z-index: 2;
      pointer-events: none;
  }

  .cug-search-input {
      padding-left: 39px;
      padding-right: 38px;
      min-height: 42px;
  }

  .cug-search-clear {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      width: 26px;
      height: 26px;
      border: 0;
      background: transparent;
      color: var(--muted);
      border-radius: 50%;
      display: inline-flex;
      align-items: center;
      justify-content: center;
  }

  .cug-search-clear:hover {
      background: rgba(143, 29, 29, .08);
      color: var(--primary);
  }

  .cug-filter-field {
      min-width: 0;
  }

  .cug-filter-label {
      display: block;
      margin-bottom: 6px;
      color: var(--text);
      font-size: .76rem;
      font-weight: 600;
  }

  .cug-filter-select,
  .cug-filter-field .form-control {
      min-height: 42px;
      border-color: var(--border);
      border-radius: 8px;
  }

  .cug-filter-select:focus,
  .cug-filter-field .form-control:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 .15rem rgba(143, 29, 29, .10);
  }

  .cug-filter-toggle,
  .cug-toolbar-main > .btn {
      min-height: 42px;
      white-space: nowrap;
      border-radius: 8px;
      font-weight: 600;
  }

  .cug-advanced-filter-panel {
      padding: 18px;
      border: 1px solid var(--border);
      border-radius: 12px;
      background: var(--bg);
  }

  .cug-filter-summary {
      margin-top: 16px;
      padding-top: 14px;
      border-top: 1px solid var(--border);
  }

  .cug-filter-summary-title {
      color: var(--muted);
      font-size: .78rem;
      font-weight: 600;
  }

  .cug-filter-tag {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 9px;
      border-radius: 7px;
      background: rgba(143, 29, 29, .08);
      color: var(--primary);
      font-size: .74rem;
      font-weight: 600;
  }

  .cug-filter-tag button {
      padding: 0;
      border: 0;
      background: transparent;
      color: inherit;
      line-height: 1;
  }

  .cug-toolbar .select2-container {
      width: 100% !important;
  }

  .cug-toolbar .select2-container--default
  .select2-selection--single {
      min-height: 42px;
      height: 42px;
      border-color: var(--border);
      border-radius: 8px;
      display: flex;
      align-items: center;
  }

  .cug-toolbar .select2-container--default
  .select2-selection--single
  .select2-selection__rendered {
      line-height: 40px;
      color: var(--text);
      font-size: .875rem;
  }

  .cug-toolbar .select2-container--default
  .select2-selection--single
  .select2-selection__arrow {
      height: 40px;
  }
</style>

<!-- CUG STAT CARDS  -->
<style>

    /*  CUG STAT CARDS  */

    .cug-stat-card {
        position: relative;
        min-height: 188px;
        overflow: hidden;
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 18px;
        cursor: pointer;
        transition:
            transform .2s ease,
            box-shadow .2s ease,
            border-color .2s ease;
    }

    .cug-stat-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: var(--stat-color);
    }

    .cug-stat-card:hover {
        transform: translateY(-3px);
        border-color: var(--stat-color);
        box-shadow: 0 10px 25px rgba(23, 32, 51, .08);
    }

    .cug-stat-card.cug-stat-active {
        border-color: var(--stat-color);
        box-shadow: 0 0 0 2px color-mix(
            in srgb,
            var(--stat-color) 15%,
            transparent
        );
    }

    .cug-stat-primary {
        --stat-color: var(--primary);
    }

    .cug-stat-success {
        --stat-color: var(--success);
    }

    .cug-stat-warning {
        --stat-color: var(--warning);
    }

    .cug-stat-danger {
        --stat-color: var(--danger);
    }

    .cug-stat-card-top {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .cug-stat-icon {
        width: 42px;
        height: 42px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 11px;
        background: color-mix(
            in srgb,
            var(--stat-color) 10%,
            transparent
        );
        color: var(--stat-color);
        font-size: 21px;
    }

    .cug-stat-label,
    .cug-stat-status {
        color: var(--muted);
        font-size: .75rem;
        font-weight: 600;
    }

    .cug-stat-status {
        padding: 5px 8px;
        border-radius: 6px;
        background: color-mix(
            in srgb,
            var(--stat-color) 8%,
            transparent
        );
        color: var(--stat-color);
    }

    .cug-stat-card-body {
        padding: 20px 0 15px;
    }

    .cug-stat-value {
        margin: 0;
        color: var(--text);
        font-size: 1.8rem;
        font-weight: 700;
        line-height: 1.1;
    }

    .cug-stat-description {
        display: block;
        margin-top: 7px;
        color: var(--muted);
        font-size: .75rem;
    }

    .cug-stat-mini-icon {
        color: color-mix(
            in srgb,
            var(--stat-color) 18%,
            transparent
        );
        font-size: 38px;
    }

    .cug-stat-card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-top: 11px;
        border-top: 1px solid var(--border);
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-stat-card-footer i:last-child {
        color: var(--stat-color);
    }


    /* =========================================================
    SUMMARY CARDS
    ========================================================= */

    .cug-summary-card {
        height: 100%;
        min-height: 176px;
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
    }

    .cug-summary-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 15px;
    }

    .cug-summary-title {
        display: block;
        color: var(--text);
        font-size: .9rem;
        font-weight: 700;
    }

    .cug-summary-subtitle {
        display: block;
        margin-top: 4px;
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-summary-icon {
        width: 38px;
        height: 38px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 9px;
        font-size: 19px;
    }

    .cug-utilization-body {
        margin-top: 23px;
    }

    .cug-utilization-value {
        display: flex;
        align-items: baseline;
        gap: 7px;
    }

    .cug-utilization-value span {
        color: var(--text);
        font-size: 1.65rem;
        font-weight: 700;
    }

    .cug-utilization-value small {
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-progress {
        height: 7px;
        margin-top: 10px;
        overflow: hidden;
        background: #eef0f3;
        border-radius: 20px;
    }

    .cug-progress .progress-bar {
        background: var(--primary);
        border-radius: inherit;
        transition: width .6s ease;
    }


    /* =========================================================
    CALL SUMMARY
    ========================================================= */

    .cug-call-summary {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 25px;
        margin-top: 22px;
    }

    .cug-call-total span {
        display: block;
        color: var(--text);
        font-size: 1.7rem;
        font-weight: 700;
    }

    .cug-call-total small {
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-call-breakdown {
        min-width: 145px;
    }

    .cug-call-breakdown > div {
        display: grid;
        grid-template-columns: 8px 1fr auto;
        gap: 7px;
        align-items: center;
        margin-bottom: 7px;
        color: var(--muted);
        font-size: .7rem;
    }

    .cug-call-breakdown strong {
        color: var(--text);
    }

    .cug-call-dot,
    .cug-pool-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        display: inline-block;
    }

    .cug-call-dot.received {
        background: var(--success);
    }

    .cug-call-dot.dialled {
        background: var(--primary);
    }

    .cug-call-dot.missed {
        background: var(--danger);
    }


    /* =========================================================
    NUMBER POOL
    ========================================================= */

    .cug-pool-stats {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px 22px;
        margin-top: 20px;
    }

    .cug-pool-stat {
        display: flex;
        align-items: center;
        gap: 9px;
    }

    .cug-pool-stat small {
        display: block;
        color: var(--muted);
        font-size: .68rem;
    }

    .cug-pool-stat strong {
        display: block;
        margin-top: 1px;
        color: var(--text);
        font-size: .9rem;
    }

    .cug-pool-dot.available {
        background: var(--success);
    }

    .cug-pool-dot.assigned {
        background: var(--primary);
    }

    .cug-pool-dot.reserved {
        background: var(--warning);
    }

    .cug-pool-dot.inactive {
        background: var(--danger);
    }

    @media (max-width: 767.98px) {

        .cug-stat-card {
            min-height: 170px;
        }

        .cug-stat-value {
            font-size: 1.55rem;
        }

        .cug-summary-card {
            min-height: auto;
        }

        .cug-call-summary {
            align-items: flex-start;
        }

    }

    @media (max-width: 575.98px) {

        .cug-call-summary {
            flex-direction: column;
            align-items: stretch;
        }

        .cug-call-breakdown {
            width: 100%;
        }

    }
</style>

<!-- CUG DATA TABLE -->
<style>
    /* CUG DATA TABLE  */

    .cug-table-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
    }

    .cug-table-header {
        min-height: 76px;
        padding: 18px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        border-bottom: 1px solid var(--border);
    }

    .cug-table-header h5 {
        color: var(--text);
        font-size: .95rem;
    }

    .cug-table-subtitle {
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-selected-count {
        padding: 6px 10px;
        border-radius: 7px;
        background: rgba(143, 29, 29, .08);
        color: var(--primary);
        font-size: .75rem;
        font-weight: 600;
    }

    .cug-data-table {
        margin: 0 !important;
        width: 100% !important;
    }

    .cug-data-table thead th {
        padding: 13px 15px;
        /* background: #fafbfc; */
        border-bottom: 1px solid var(--border);
        /* color: var(--muted); */
        font-size: .69rem;
        font-weight: 700;
        letter-spacing: .02em;
        text-transform: uppercase;
        white-space: nowrap;
    }

    .cug-data-table tbody td {
        padding: 14px 15px;
        vertical-align: middle;
        border-bottom: 1px solid #f0f1f3;
        color: var(--text);
        font-size: .8rem;
    }

    .cug-data-table tbody tr {
        transition: background-color .15s ease;
    }

    .cug-data-table tbody tr:hover {
        background: rgba(143, 29, 29, .025);
    }

    .cug-data-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .cug-checkbox-column {
        width: 42px !important;
        padding-left: 18px !important;
    }

    .cug-action-column {
        width: 70px !important;
        text-align: center;
    }

    .cug-data-table .form-check-input {
        width: 16px;
        height: 16px;
        margin: 0;
        cursor: pointer;
        border-color: #cbd0d7;
    }

    .cug-data-table .form-check-input:checked {
        background-color: var(--primary);
        border-color: var(--primary);
    }

    /* =========================================================
    CUG NUMBER CELL
    ========================================================= */

    .cug-number-cell {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 170px;
    }

    .cug-number-icon {
        width: 34px;
        height: 34px;
        min-width: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(143, 29, 29, .08);
        color: var(--primary);
        font-size: 16px;
    }

    .cug-number-value {
        display: block;
        color: var(--text);
        font-weight: 700;
        letter-spacing: .25px;
    }

    .cug-number-id {
        display: block;
        margin-top: 2px;
        color: var(--muted);
        font-size: .66rem;
    }

    /* =========================================================
    STAFF CELL
    ========================================================= */

    .cug-staff-cell {
        display: flex;
        align-items: center;
        gap: 9px;
        min-width: 170px;
    }

    .cug-staff-avatar {
        width: 34px;
        height: 34px;
        min-width: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: rgba(143, 29, 29, .09);
        color: var(--primary);
        font-size: .72rem;
        font-weight: 700;
    }

    .cug-staff-name {
        display: block;
        color: var(--text);
        font-weight: 600;
    }

    .cug-staff-id {
        display: block;
        margin-top: 2px;
        color: var(--muted);
        font-size: .66rem;
    }

    /* =========================================================
    STATUS
    ========================================================= */

    .cug-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border-radius: 7px;
        font-size: .68rem;
        font-weight: 700;
        white-space: nowrap;
    }

    .cug-status-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
    }

    .cug-status-assigned {
        background: rgba(22, 163, 74, .09);
        color: var(--success);
    }

    .cug-status-assigned .cug-status-dot { 
        background: var(--success);
    }

    .cug-status-available {
        background: rgba(143, 29, 29, .09);
        color: var(--primary);
    }

    .cug-status-available .cug-status-dot {
        background: var(--primary);
    }

    .cug-status-reserved {
        background: rgba(217, 119, 6, .10);
        color: var(--warning);
    }

    .cug-status-reserved .cug-status-dot {
        background: var(--warning);
    }

    .cug-status-inactive {
        background: rgba(220, 38, 38, .09);
        color: var(--danger);
    }

    .cug-status-inactive .cug-status-dot {
        background: var(--danger);
    }

    /* =========================================================
    ASSIGNMENT
    ========================================================= */

    .cug-assignment-date {
        color: var(--text);
        font-size: .75rem;
        font-weight: 600;
    }

    .cug-assignment-duration {
        display: block;
        margin-top: 2px;
        color: var(--muted);
        font-size: .65rem;
    }

    .cug-unassigned {
        color: var(--muted);
        font-size: .74rem;
        font-style: italic;
    }

    /* =========================================================
    CALL COUNT
    ========================================================= */

    .cug-call-count {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        color: var(--primary);
        font-weight: 700;
        cursor: pointer;
    }

    .cug-call-count:hover {
        color: var(--primary-2);
        text-decoration: underline;
    }

    /* =========================================================
    ACTION BUTTON
    ========================================================= */

    .cug-row-action {
        width: 34px;
        height: 34px;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 0;
        border-radius: 8px;
        background: transparent;
        color: var(--muted);
    }

    .cug-row-action:hover {
        background: rgba(143, 29, 29, .08);
        color: var(--primary);
    }

    .cug-data-table .dropdown-menu {
        min-width: 190px;
        padding: 7px;
        border: 1px solid var(--border);
        border-radius: 10px;
        box-shadow: 0 8px 25px rgba(23, 32, 51, .12);
    }

    .cug-data-table .dropdown-item {
        border-radius: 7px;
        padding: 8px 10px;
        font-size: .78rem;
    }

    .cug-data-table .dropdown-item:hover {
        background: rgba(143, 29, 29, .06);
        color: var(--primary);
    }

    .cug-data-table .dropdown-item.text-danger:hover {
        background: rgba(220, 38, 38, .07);
        color: var(--danger);
    }

    /* =========================================================
    EMPTY STATE
    ========================================================= */

    .cug-table-empty {
        padding: 55px 20px;
        text-align: center;
    }

    .cug-empty-icon {
        width: 58px;
        height: 58px;
        margin: 0 auto 15px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 14px;
        background: rgba(143, 29, 29, .07);
        color: var(--primary);
        font-size: 26px;
    }

    .cug-table-empty h6 {
        color: var(--text);
    }

    .cug-table-empty p {
        color: var(--muted);
        font-size: .78rem;
    }

    /* =========================================================
    DATATABLE CONTROLS
    ========================================================= */

    .cug-table-card .dataTables_wrapper {
        padding-bottom: 0;
    }

    .cug-table-card .dataTables_info {
        padding: 16px 20px;
        color: var(--muted);
        font-size: .72rem;
    }

    .cug-table-card .dataTables_paginate {
        padding: 10px 20px 16px;
    }

    .cug-table-card .pagination {
        margin-bottom: 0;
    }

    .cug-table-card .page-link {
        min-width: 32px;
        height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 7px;
        font-size: .72rem;
    }

    .cug-table-card .page-item.active .page-link {
        background: var(--primary);
        border-color: var(--primary);
    }

    /* =========================================================
    RESPONSIVE
    ========================================================= */

    @media (max-width: 767.98px) {

        .cug-table-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .cug-table-header > .d-flex {
            width: 100%;
        }

        .cug-table-header .dropdown,
        .cug-table-header .btn {
            width: 100%;
        }

        .cug-data-table thead th,
        .cug-data-table tbody td {
            padding-left: 11px;
            padding-right: 11px;
        }

    }
</style>

<!-- ACTIVITY TIMELINE -->
<style>
    /* ACTIVITY TIMELINE */

    .cug-activity-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(23, 32, 51, .04);
    }

    .cug-activity-header {
        min-height: 74px;
        padding: 17px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        border-bottom: 1px solid var(--border);
    }

    .cug-activity-header h5 {
        color: var(--text);
        font-size: .95rem;
    }

    .cug-activity-header .btn {
        border-radius: 8px;
        font-size: .72rem;
        font-weight: 600;
    }

    .cug-activity-body {
        position: relative;
        padding: 20px;
    }

    /* =========================================================
    TIMELINE ITEM
    ========================================================= */

    .cug-timeline {
        position: relative;
    }

    .cug-timeline-item {
        position: relative;
        display: flex;
        gap: 14px;
        padding-bottom: 22px;
    }

    .cug-timeline-item:last-child {
        padding-bottom: 0;
    }

    .cug-timeline-item:not(:last-child)::before {
        content: "";
        position: absolute;
        left: 16px;
        top: 34px;
        bottom: 0;
        width: 1px;
        background: var(--border);
    }

    .cug-timeline-icon {
        position: relative;
        z-index: 2;
        width: 33px;
        height: 33px;
        min-width: 33px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        border: 3px solid var(--card);
        background: rgba(143, 29, 29, .09);
        color: var(--primary);
        font-size: 15px;
        box-shadow: 0 0 0 1px var(--border);
    }

    .cug-timeline-icon.assigned {
        background: rgba(22, 163, 74, .10);
        color: var(--success);
    }

    .cug-timeline-icon.transferred {
        background: rgba(143, 29, 29, .10);
        color: var(--primary);
    }

    .cug-timeline-icon.released {
        background: rgba(217, 119, 6, .10);
        color: var(--warning);
    }

    .cug-timeline-icon.activated {
        background: rgba(22, 163, 74, .10);
        color: var(--success);
    }

    .cug-timeline-icon.deactivated {
        background: rgba(220, 38, 38, .10);
        color: var(--danger);
    }

    .cug-timeline-content {
        flex: 1;
        min-width: 0;
    }

    .cug-timeline-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 15px;
    }

    .cug-timeline-title {
        color: var(--text);
        font-size: .78rem;
        font-weight: 700;
    }

    .cug-timeline-time {
        color: var(--muted);
        font-size: .66rem;
        white-space: nowrap;
    }

    .cug-timeline-description {
        margin-top: 4px;
        color: var(--muted);
        font-size: .72rem;
        line-height: 1.5;
    }

    .cug-timeline-description strong {
        color: var(--text);
        font-weight: 600;
    }

    .cug-timeline-meta {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 7px;
    }

    .cug-timeline-tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 7px;
        border-radius: 6px;
        background: var(--bg);
        color: var(--muted);
        font-size: .64rem;
        font-weight: 600;
    }

    .cug-timeline-tag.cug-number {
        color: var(--primary);
        background: rgba(143, 29, 29, .06);
    }

    /* =========================================================
    LOADING
    ========================================================= */


    .cug-activity-item {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 13px 0;
        border-bottom: 1px solid var(--border);
    }

    .cug-activity-item:last-of-type {
        border-bottom: 0;
    }

    .cug-activity-icon {
        width: 34px;
        height: 34px;
        min-width: 34px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 9px;
        background: var(--cug-primary-soft);
        color: var(--primary);
    }

    .cug-activity-icon.assigned {
        background: var(--cug-success-soft);
        color: var(--success);
    }

    .cug-activity-icon.released,
    .cug-activity-icon.deactivated {
        background: var(--cug-warning-soft);
        color: var(--warning);
    }

    .cug-activity-icon.deleted {
        background: var(--cug-danger-soft);
        color: var(--danger);
    }

    .cug-activity-content {
        min-width: 0;
        flex: 1;
    }

    .cug-activity-title {
        color: var(--text);
        font-size: .74rem;
        font-weight: 700;
    }

    .cug-activity-description {
        margin-top: 3px;
        color: var(--muted);
        font-size: .67rem;
    }

    .cug-activity-meta {
        margin-top: 4px;
        color: var(--muted);
        font-size: .60rem;
    }

    .cug-activity-error {
        min-height: 120px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        color: var(--danger);
        font-size: .72rem;
    }

    .cug-activity-loading {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .cug-timeline-skeleton {
        height: 48px;
        border-radius: 8px;
        background: linear-gradient(
            90deg,
            #f1f2f4 25%,
            #e8eaed 37%,
            #f1f2f4 63%
        );
        background-size: 400% 100%;
        animation: cugSkeleton 1.4s ease infinite;
    }

    @keyframes cugSkeleton {

        0% {
            background-position: 100% 0;
        }

        100% {
            background-position: 0 0;
        }

    }

    /* =========================================================
    EMPTY
    ========================================================= */

    .cug-activity-empty {
        min-height: 160px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 9px;
        color: var(--muted);
        font-size: .76rem;
    }

    .cug-activity-empty-icon {
        width: 46px;
        height: 46px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
        background: rgba(143, 29, 29, .07);
        color: var(--primary);
        font-size: 20px;
    }

    /* =========================================================
    RESPONSIVE
    ========================================================= */

    @media (max-width: 575.98px) {

        .cug-activity-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .cug-activity-header .btn {
            width: 100%;
        }

        .cug-activity-body {
            padding: 16px;
        }

        .cug-timeline-top {
            flex-direction: column;
            gap: 3px;
        }

    }
</style>

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
     $module_name = 'CUG Management';
     $submenu_name = 'Manage CUG';
     $last_name = NULL;
     $menu_name = 'Manage Calls';

    $recent_activity = 0;
    $add_cug_check = 0;
    $change_staff_check = 0;
    $assign_staff_check = 0;
    $call_history_check = 0;
    $assign_history_check = 0;
    $delete_check = 0;
    $recent_activity = 0;
    
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Add Cug')){
        $add_cug_check = 1;
    }else{
       $add_cug_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Assign Cug')){
        $assign_staff_check = 1;
    }else{
       $assign_staff_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Change Cug')){
        $change_staff_check = 1;
    }else{
       $change_staff_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Call History')){
        $call_history_check = 1;
    }else{
       $call_history_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Assign History')){
        $assign_history_check = 1;
    }else{
       $assign_history_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Delete')){
        $delete_check = 1;
    }else{
       $delete_check = 0;
    }
    if(auth()->user()->hasPermission($module_name,$submenu_name,$last_name, 'Recent Activity')){
        $recent_activity = 1;
    }else{
       $recent_activity = 0;
    }

@endphp

<div class="cug-page" id="cugManagementPage">

    {{-- Topbar --}}
    <div class="cug-topbar mb-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            {{-- Left --}}
            <div class="d-flex align-items-center gap-3">
                <div class="cug-page-icon">
                    <i class="ti ti-device-mobile"></i>
                </div>
                <div>
                    <div class="d-flex align-items-center gap-2 mb-1">
                        <span class="text-muted small">
                            Communication
                        </span>
                        <i class="ti ti-chevron-right cug-breadcrumb-icon"></i>
                        <span class="text-muted small">
                            CUG
                        </span>
                    </div>
                    <h4 class="mb-0 fw-bold cug-page-title">
                        CUG Management
                    </h4>
                    <div class="cug-page-subtitle">
                        Manage CUG numbers, staff assignments and call history
                    </div>
                </div>
            </div>
            {{-- Right --}}
            <div class="d-flex align-items-center flex-wrap gap-2">
                {{-- Refresh --}}
                <button type="button" class="btn btn-icon btn-label-secondary" id="btnRefreshCug" data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh">
                    <i class="ti ti-refresh"></i>
                </button>
                {{-- Export --}}
                <!-- <button type="button" class="btn btn-label-secondary" id="btnExportCug">
                    <i class="ti ti-file-export me-1"></i>
                    Export
                </button> -->
                {{-- Add CUG --}}
                @if($add_cug_check == 1)
                <button type="button" class="btn btn-primary" id="btnAddCug"  data-bs-toggle="modal" data-bs-target="#cugNumberModal">
                    <i class="ti ti-plus me-1"></i>
                    Add CUG Number
                </button>
                @endif
            </div>
        </div>
    </div>

    {{-- Toolbar --}}
    <div class="cug-toolbar mb-4" id="cugToolbar">
        {{-- Main Filter Row --}}
        <div class="cug-toolbar-main">
            {{-- Search --}}
            <div class="cug-search-wrapper">
                <i class="ti ti-search cug-search-icon"></i>
                <input
                    type="search"
                    class="form-control cug-search-input"
                    id="cugSearch"
                    placeholder="Search CUG number, staff, employee ID..."
                    autocomplete="off">
                <button
                    type="button"
                    class="cug-search-clear d-none"
                    id="btnClearCugSearch"
                    aria-label="Clear search">

                    <i class="ti ti-x"></i>
                </button>
            </div>
            {{-- Company --}}
            <div class="cug-filter-field">
                <label class="cug-filter-label">
                    Company
                </label>
                <select
                    class="form-select cug-filter-select select3"
                    id="filterCugCompany"
                    name="company_id">

                    <option value="">
                        All Companies
                    </option>

                </select>

            </div>

            {{-- Entity --}}
            <div class="cug-filter-field">

                <label class="cug-filter-label">
                    Entity
                </label>

                <select
                    class="form-select cug-filter-select select3"
                    id="filterCugEntity"
                    name="entity_id"
                    disabled>

                    <option value="">
                        All Entities
                    </option>

                </select>

            </div>

            {{-- Status --}}
            <div class="cug-filter-field">

                <label class="cug-filter-label">
                    Status
                </label>

                <select
                    class="form-select cug-filter-select select3"
                    id="filterCugStatus"
                    name="status">

                    <option value="">
                        All Status
                    </option>

                    <option value="0">
                        Available
                    </option>

                    <option value="1">
                        Assigned
                    </option>

                    <option value="2">
                        Reserved
                    </option>

                    <option value="3">
                        Inactive
                    </option>

                </select>

            </div>

            {{-- More Filters --}}
            <button
                type="button"
                class="btn btn-label-secondary cug-filter-toggle"
                id="btnCugAdvancedFilter"
                data-bs-toggle="collapse"
                data-bs-target="#cugAdvancedFilters"
                aria-expanded="false"
                aria-controls="cugAdvancedFilters">

                <i class="ti ti-adjustments-horizontal me-1"></i>

                Filters

                <span
                    class="badge bg-primary ms-1 d-none"
                    id="cugFilterCount">

                    0

                </span>

            </button>

            {{-- Reset --}}
            <button
                type="button"
                class="btn btn-label-secondary"
                id="btnResetCugFilter">

                <i class="ti ti-refresh me-1"></i>

                Reset

            </button>

        </div>
        {{-- Advanced Filters --}}
        <div
            class="collapse"
            id="cugAdvancedFilters">
            <div class="cug-advanced-filter-panel mt-3">
                <div class="row g-3">
                    {{-- Branch --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <label class="cug-filter-label">
                            Branch
                        </label>
                        <select
                            class="form-select cug-filter-select"
                            id="filterCugBranch"
                            name="branch_id"
                            disabled>
                            <option value="">
                                All Branches
                            </option>
                        </select>
                    </div>
                    {{-- Provider --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <label class="cug-filter-label">
                            Provider
                        </label>
                        <select
                            class="form-select cug-filter-select"
                            id="filterCugProvider"
                            name="provider">
                            <option value="">
                                All Providers
                            </option>
                            <option value="Airtel">
                                Airtel
                            </option>
                            <option value="Jio">
                                Jio
                            </option>
                            <option value="Vi">
                                Vi
                            </option>
                            <option value="BSNL">
                                BSNL
                            </option>
                        </select>
                    </div>
                    {{-- Assignment --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <label class="cug-filter-label">
                            Assignment
                        </label>
                        <select
                            class="form-select cug-filter-select"
                            id="filterCugAssignment"
                            name="assignment_status">
                            <option value="">
                                All Assignments
                            </option>
                            <option value="assigned">
                                Assigned to Staff
                            </option>
                            <option value="available">
                                Unassigned
                            </option>
                        </select>
                    </div>


                    {{-- Staff --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">

                        <label class="cug-filter-label">

                            Staff

                        </label>

                        <select
                            class="form-select cug-filter-select"
                            id="filterCugStaff"
                            name="staff_id">

                            <option value="">
                                All Staff
                            </option>

                        </select>

                    </div>


                    {{-- CUG Number From --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">

                        <label class="cug-filter-label">

                            CUG Number From

                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="filterCugNumberFrom"
                            name="number_from"
                            inputmode="numeric"
                            maxlength="20"
                            placeholder="Starting number">

                    </div>


                    {{-- CUG Number To --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">

                        <label class="cug-filter-label">

                            CUG Number To

                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="filterCugNumberTo"
                            name="number_to"
                            inputmode="numeric"
                            maxlength="20"
                            placeholder="Ending number">

                    </div>


                    {{-- Assignment Date From --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">

                        <label class="cug-filter-label">

                            Assigned From

                        </label>

                        <input
                            type="text"
                            class="form-control cug-date-filter"
                            id="filterCugAssignedFrom"
                            name="assigned_from"
                            placeholder="Select date">

                    </div>


                    {{-- Assignment Date To --}}
                    <div class="col-xl-3 col-lg-4 col-md-6">

                        <label class="cug-filter-label">

                            Assigned To

                        </label>

                        <input
                            type="text"
                            class="form-control cug-date-filter"
                            id="filterCugAssignedTo"
                            name="assigned_to"
                            placeholder="Select date">

                    </div>

                </div>

                {{-- Active Filter Summary --}}
                <div
                    class="cug-filter-summary d-none"
                    id="cugFilterSummary">

                    <div class="d-flex align-items-center flex-wrap gap-2">

                        <span class="cug-filter-summary-title">

                            <i class="ti ti-filter me-1"></i>

                            Active Filters:

                        </span>

                        <div
                            class="d-flex align-items-center flex-wrap gap-2"
                            id="cugActiveFilterTags">
                        </div>

                        <button
                            type="button"
                            class="btn btn-sm btn-link text-danger p-0 ms-1"
                            id="btnClearAdvancedCugFilters">

                            Clear all

                        </button>

                    </div>

                </div>

            </div>
        </div>
    </div>


    {{-- Dashboard Cards --}}
    <div class="row g-4 mb-4" id="cugDashboardCards">
        {{-- Total CUG --}}
        <div class="col-xl-3 col-sm-6">
            <div class="cug-stat-card cug-stat-primary" id="cugCardTotal" data-card-filter="all">
                <div class="cug-stat-card-top">
                    <div class="cug-stat-icon">
                        <i class="ti ti-device-mobile"></i>
                    </div>
                    <span class="cug-stat-label">
                        Total CUG
                    </span>
                </div>
                <div class="cug-stat-card-body">
                    <div class="d-flex align-items-end justify-content-between">
                        <div>
                            <h3 class="cug-stat-value" id="cugTotalCount">
                                0
                            </h3>
                            <span class="cug-stat-description">
                                Registered CUG numbers
                            </span>
                        </div>
                        <div class="cug-stat-mini-icon">
                            <i class="ti ti-device-sim"></i>
                        </div>
                    </div>
                </div>
                <div class="cug-stat-card-footer">
                    <span>
                        <i class="ti ti-database me-1"></i>
                        CUG inventory
                    </span>
                    <i class="ti ti-arrow-up-right"></i>
                </div>
            </div>
        </div>
        {{-- Assigned --}}
        <div class="col-xl-3 col-sm-6">
            <div class="cug-stat-card cug-stat-success"
                id="cugCardAssigned"
                data-card-filter="assigned">
                <div class="cug-stat-card-top">
                    <div class="cug-stat-icon">
                        <i class="ti ti-user-check"></i>
                    </div>
                    <span class="cug-stat-status">
                        Active
                    </span>
                </div>
                <div class="cug-stat-card-body">
                    <div class="d-flex align-items-end justify-content-between">
                        <div>
                            <h3 class="cug-stat-value"
                                id="cugAssignedCount">
                                0
                            </h3>
                            <span class="cug-stat-description">
                                Assigned to staff
                            </span>
                        </div>
                        <div class="cug-stat-mini-icon">
                            <i class="ti ti-user"></i>
                        </div>
                    </div>
                </div>
                <div class="cug-stat-card-footer">
                    <span>
                        <i class="ti ti-users me-1"></i>
                        Current assignments
                    </span>
                    <i class="ti ti-arrow-up-right"></i>
                </div>
            </div>
        </div>


        {{-- Available --}}
        <div class="col-xl-3 col-sm-6">
            <div
                class="cug-stat-card cug-stat-warning"
                id="cugCardAvailable"
                data-card-filter="available">
                <div class="cug-stat-card-top">
                    <div class="cug-stat-icon">
                        <i class="ti ti-device-mobile-plus"></i>
                    </div>
                    <span class="cug-stat-status">
                        Ready
                    </span>
                </div>
                <div class="cug-stat-card-body">
                    <div class="d-flex align-items-end justify-content-between">
                        <div>
                            <h3 class="cug-stat-value" id="cugAvailableCount">
                                0
                            </h3>
                            <span class="cug-stat-description">
                                Available for assignment
                            </span>
                        </div>
                        <div class="cug-stat-mini-icon">
                            <i class="ti ti-user-plus"></i>
                        </div>
                    </div>
                </div>
                <div class="cug-stat-card-footer">
                    <span>
                        <i class="ti ti-check me-1"></i>
                        Available pool
                    </span>
                    <i class="ti ti-arrow-up-right"></i>
                </div>
            </div>
        </div>


        {{--  Inactive / Reserved --}}
        <div class="col-xl-3 col-sm-6">
            <div
                class="cug-stat-card cug-stat-danger"
                id="cugCardInactive"
                data-card-filter="inactive">
                <div class="cug-stat-card-top">
                    <div class="cug-stat-icon">
                        <i class="ti ti-device-mobile-off"></i>
                    </div>
                    <span class="cug-stat-status">
                        Attention
                    </span>
                </div>
                <div class="cug-stat-card-body">
                    <div class="d-flex align-items-end justify-content-between">
                        <div>
                            <h3 class="cug-stat-value"
                                id="cugInactiveCount">
                                0
                            </h3>
                            <span class="cug-stat-description">
                                Reserved / inactive
                            </span>
                        </div>
                        <div class="cug-stat-mini-icon">
                            <i class="ti ti-alert-circle"></i>
                        </div>
                    </div>
                </div>
                <div class="cug-stat-card-footer">
                    <span>
                        <i class="ti ti-info-circle me-1"></i>
                        Requires attention
                    </span>
                    <i class="ti ti-arrow-up-right"></i>
                </div>
            </div>
        </div>
    </div>

    {{-- Operational Summary --}}
    <div class="row g-4 mb-4">
        {{-- Assignment Utilization --}}
        <div class="col-xl-4 col-lg-6">

            <div class="cug-summary-card">

                <div class="cug-summary-header">

                    <div>

                        <span class="cug-summary-title">

                            Assignment Utilization

                        </span>

                        <small class="cug-summary-subtitle">

                            Current CUG allocation

                        </small>

                    </div>

                    <div class="cug-summary-icon bg-primary-subtle">

                        <i class="ti ti-chart-donut"></i>

                    </div>

                </div>

                <div class="cug-utilization-body">

                    <div class="cug-utilization-value">

                        <span id="cugUtilization">

                            0%

                        </span>

                        <small>

                            utilized

                        </small>

                    </div>

                    <div class="progress cug-progress">

                        <div
                            class="progress-bar"
                            id="cugUtilizationBar"
                            role="progressbar"
                            style="width:0%"
                            aria-valuenow="0"
                            aria-valuemin="0"
                            aria-valuemax="100">
                        </div>

                    </div>

                    <div class="d-flex justify-content-between mt-2">

                        <small class="text-muted">

                            Assigned

                            <strong id="cugUtilizationAssigned">
                                0
                            </strong>

                        </small>

                        <small class="text-muted">

                            Total

                            <strong id="cugUtilizationTotal">
                                0
                            </strong>

                        </small>

                    </div>

                </div>

            </div>

        </div>


        {{-- Today's Calls --}}

        <div class="col-xl-4 col-lg-6">

            <div class="cug-summary-card">

                <div class="cug-summary-header">

                    <div>

                        <span class="cug-summary-title">

                            Today's CUG Calls

                        </span>

                        <small class="cug-summary-subtitle">

                            Current day activity

                        </small>

                    </div>

                    <div class="cug-summary-icon bg-success-subtle">

                        <i class="ti ti-phone-call"></i>

                    </div>

                </div>

                <div class="cug-call-summary">

                    <div class="cug-call-total">

                        <span id="cugTodayCalls">

                            0

                        </span>

                        <small>

                            total calls

                        </small>

                    </div>

                    <div class="cug-call-breakdown">

                        <div>

                            <span class="cug-call-dot received"></span>

                            <span>

                                Received

                            </span>

                            <strong id="cugReceivedCalls">

                                0

                            </strong>

                        </div>

                        <div>

                            <span class="cug-call-dot dialled"></span>

                            <span>

                                Dialled

                            </span>

                            <strong id="cugDialledCalls">

                                0

                            </strong>

                        </div>

                        <div>

                            <span class="cug-call-dot missed"></span>

                            <span>

                                Missed

                            </span>

                            <strong id="cugMissedCalls">

                                0

                            </strong>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Available Pool --}}

        <div class="col-xl-4 col-lg-12">

            <div class="cug-summary-card cug-summary-pool">

                <div class="cug-summary-header">

                    <div>

                        <span class="cug-summary-title">

                            Number Pool

                        </span>

                        <small class="cug-summary-subtitle">

                            Availability overview

                        </small>

                    </div>

                    <div class="cug-summary-icon bg-warning-subtle">

                        <i class="ti ti-stack-2"></i>

                    </div>

                </div>

                <div class="cug-pool-stats">

                    <div class="cug-pool-stat">

                        <span class="cug-pool-dot available"></span>

                        <div>

                            <small>

                                Available

                            </small>

                            <strong id="cugPoolAvailable">

                                0

                            </strong>

                        </div>

                    </div>

                    <div class="cug-pool-stat">

                        <span class="cug-pool-dot assigned"></span>

                        <div>

                            <small>

                                Assigned

                            </small>

                            <strong id="cugPoolAssigned">

                                0

                            </strong>

                        </div>

                    </div>

                    <div class="cug-pool-stat">

                        <span class="cug-pool-dot reserved"></span>

                        <div>

                            <small>

                                Reserved

                            </small>

                            <strong id="cugPoolReserved">

                                0

                            </strong>

                        </div>

                    </div>

                    <div class="cug-pool-stat">

                        <span class="cug-pool-dot inactive"></span>

                        <div>

                            <small>

                                Inactive

                            </small>

                            <strong id="cugPoolInactive">

                                0

                            </strong>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    {{-- CUG Register --}}
    <div class="cug-table-card mb-4">

        {{-- =====================================================
            Table Header
        ====================================================== --}}

        <div class="cug-table-header">

            <div>

                <h5 class="mb-1 fw-semibold">

                    CUG Number Register

                </h5>

                <span class="cug-table-subtitle">

                    Manage numbers, current assignments and CUG activity

                </span>

            </div>

            <div class="d-flex align-items-center gap-2">

                {{-- Selected Count --}}

                <span
                    class="cug-selected-count d-none"
                    id="cugSelectedCount">

                    <span id="cugSelectedNumber">0</span>
                    selected

                </span>

                {{-- Bulk Actions --}}

                <div
                    class="dropdown d-none"
                    id="cugBulkActions">

                    <button
                        type="button"
                        class="btn btn-label-secondary dropdown-toggle"
                        data-bs-toggle="dropdown"
                        aria-expanded="false">

                        <i class="ti ti-list-check me-1"></i>

                        Bulk Actions

                    </button>

                    <ul class="dropdown-menu dropdown-menu-end">

                        <li>
                            <button type="button" class="dropdown-item" id="btnBulkExportCug">
                                <i class="ti ti-file-export me-2"></i>
                                Export Selected
                            </button>
                        </li>

                        <li>

                            <hr class="dropdown-divider">

                        </li>

                        <li>

                            <button
                                type="button"
                                class="dropdown-item text-danger"
                                id="btnBulkDeactivateCug">

                                <i class="ti ti-device-mobile-off me-2"></i>

                                Deactivate Selected

                            </button>

                        </li>

                    </ul>

                </div>

            </div>

        </div>


        {{-- =====================================================
            Table
        ====================================================== --}}

        <div class="table-responsive">

            <table class="table cug-data-table" id="cugDataTable">
                <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="cug-checkbox-column">
                            <input
                                type="checkbox"
                                class="form-check-input"
                                id="cugSelectAll"
                                aria-label="Select all CUG numbers">
                        </th>

                        <th>
                            CUG Number
                        </th>

                        <th>
                            Provider
                        </th>

                        <th>
                            Company
                        </th>

                        <th>
                            Entity
                        </th>

                        <th>
                            Current Staff
                        </th>

                        <th>
                            Assignment
                        </th>

                        <th>
                            Calls
                        </th>

                        <th>
                            Status
                        </th>

                        <th class="cug-action-column">
                            Actions
                        </th>

                    </tr>

                </thead>

                <tbody>

                    {{-- AJAX CUG rows --}}

                </tbody>

            </table>

        </div>


        {{-- =====================================================
            Empty State
        ====================================================== --}}

        <div
            class="cug-table-empty d-none"
            id="cugTableEmpty">

            <div class="cug-empty-icon">

                <i class="ti ti-device-mobile-off"></i>

            </div>

            <h6 class="mb-1">

                No CUG numbers found

            </h6>

            <p class="mb-3">

                Try changing your filters or add a new CUG number.

            </p>

            <button
                type="button"
                class="btn btn-primary btn-sm"
                id="btnEmptyAddCug"
                data-bs-toggle="modal"
                data-bs-target="#cugNumberModal">

                <i class="ti ti-plus me-1"></i>

                Add CUG Number

            </button>

        </div>

    </div>

    {{-- Recent Activity --}}
    @if($recent_activity == 1)
    <div class="cug-activity-card mb-4">

        {{-- Header --}}
        <div class="cug-activity-header">

            <div>

                <h5 class="mb-1 fw-semibold">

                    Recent CUG Activity 

                </h5>

                <span class="cug-table-subtitle">

                    Latest assignments, transfers and releases

                </span>

            </div>

            <button
                type="button"
                class="btn btn-sm btn-label-secondary"
                id="btnViewAllCugHistory">

                <i class="ti ti-history me-1"></i>

                View History

            </button>

        </div>


        {{-- Activity Body --}}
        <div
            class="cug-activity-body"
            id="cugActivityTimeline">

            {{-- AJAX content --}}

            <div
                class="cug-activity-loading"
                id="cugActivityLoading">

                <div class="cug-timeline-skeleton"></div>
                <div class="cug-timeline-skeleton"></div>
                <div class="cug-timeline-skeleton"></div>

            </div>


            {{-- Empty --}}
            <div
                class="cug-activity-empty d-none"
                id="cugActivityEmpty">

                <div class="cug-activity-empty-icon">

                    <i class="ti ti-history-off"></i>

                </div>

                <span>

                    No recent CUG activity

                </span>

            </div>

        </div>

    </div>
    @endif

</div>


{{--  Modals --}}
@include('content.control_panel.cug_management.cug_modal')


<script>
    window.cugRoutes = {
        dashboard: @json(route('cug.management.dashboard')),
        datatable: @json(route('cug.management.datatable')),

        store: @json(route('cug.management.store')),

        show: @json(route('cug.management.show', ['id' => '__ID__'])),
        update: @json(route('cug.management.update', ['id' => '__ID__'])),

        assign: @json(route('cug.management.assign')),
        changeStaff: @json(route('cug.management.change-staff')),

        release: @json(route('cug.management.release', ['id' => '__ID__'])),
        deactivate: @json(route('cug.management.deactivate', ['id' => '__ID__'])),
        delete: @json(route('cug.management.delete', ['id' => '__ID__'])),

        assignmentHistory: @json(
            route('cug.management.assignment-history', ['id' => '__ID__'])
        ),

        callHistory: @json(
            route('cug.management.call-history', ['id' => '__ID__'])
        ),

        companies: @json(route('cug.management.companies')),
        entities: @json(route('cug.management.entities')),
        branches: @json(route('cug.management.branches')),
        recentActivity: @json(route('cug.management.recent-activity')),

        staffSearch: @json(route('cug.management.staff.search')),
        staffs: @json(route('cug.management.branch-staff.search')),
        staffShow: @json(
            route('cug.management.staff.show', ['id' => '__ID__'])
        )
    };
</script>

<!-- helper js -->
<script>
  (function ($) {

      'use strict';

        /**
         * =========================================================
         * CUG Management — Helper
         * =========================================================
         *
         * Responsibilities:
         *
         * 1. AJAX defaults
         * 2. CSRF handling
         * 3. API request wrapper
         * 4. Error normalization
         * 5. Notifications
         * 6. Button loading
         * 7. Page loading
         * 8. Confirmation dialog
         * 9. Debounce
         * 10. Number/date formatting
         * 11. HTML escaping
         * 12. Route resolver
         * =========================================================
         */

    window.CugHelper = {
        /* =====================================================
            CONFIG
        ===================================================== */

        config: {
        currency: '₹',

        locale: 'en-IN',

        dateFormat: 'DD MMM YYYY',

        animationDuration: 500
        },

        /* =====================================================
            INIT
        ===================================================== */

        init() {
        this.setupAjax();

        this.initTooltips();
        },

        /* =====================================================
            AJAX SETUP
        ===================================================== */

        setupAjax() {
        const token = document

            .querySelector('meta[name="csrf-token"]')

            ?.getAttribute('content');

        if (!token) {
            console.warn('CUG Management: CSRF token not found.');

            return;
        }

        $.ajaxSetup({
            headers: {
            'X-CSRF-TOKEN': token,

            'X-Requested-With': 'XMLHttpRequest'
            }
        });
        },

        /* =====================================================
            AJAX REQUEST
        ===================================================== */

        request(options = {}) {
        const defaults = {
            type: 'GET',

            dataType: 'json',

            timeout: 30000,

            processData: true,

            contentType: 'application/x-www-form-urlencoded; charset=UTF-8'
        };

        const settings = $.extend(true, {}, defaults, options);

        return $.ajax(settings);
        },

        /* =====================================================
            GET
        ===================================================== */

        get(url, data = {}) {
        return this.request({
            url: url,

            type: 'GET',

            data: data
        });
        },

        /* =====================================================
            POST
        ===================================================== */

        post(url, data = {}) {
        return this.request({
            url: url,

            type: 'POST',

            data: data
        });
        },

        /* =====================================================
            FORM DATA POST
        ===================================================== */

        postForm(url, form) {
        const formElement = form instanceof HTMLFormElement ? form : $(form)[0];

        if (!formElement) {
            return $.Deferred()

            .reject({
                message: 'Form could not be found.'
            })

            .promise();
        }

        const formData = new FormData(formElement);

        return $.ajax({
            url: url,

            type: 'POST',

            data: formData,

            processData: false,

            contentType: false,

            dataType: 'json',

            timeout: 30000
        });
        },

        /* =====================================================
            PUT
        ===================================================== */

        put(url, data = {}) {
        return this.request({
            url: url,

            type: 'POST',

            data: $.extend({}, data, {
            _method: 'PUT'
            })
        });
        },

        formatDateTime(value) {
            if (!value) {
                return '—';
            }

            const date = new Date(value);

            if (Number.isNaN(date.getTime())) {
                return '—';
            }

            return date.toLocaleString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            });
        },

        /* =====================================================
            DELETE
        ===================================================== */

        delete(url, data = {}) {
        return this.request({
            url: url,

            type: 'POST',

            data: $.extend({}, data, {
            _method: 'DELETE'
            })
        });
        },

        /* =====================================================
            ERROR HANDLER
        ===================================================== */

        getError(xhr) {
        if (!xhr) {
            return {
            status: 0,

            message: 'Unknown server error.',

            errors: {}
            };
        }

        const response = xhr.responseJSON || {};

        let message = response.message || response.error || 'Something went wrong. Please try again.';

        if (xhr.status === 0) {
            message = 'Unable to connect to the server.';
        }

        if (xhr.status === 401) {
            message = 'Your session has expired. Please login again.';
        }

        if (xhr.status === 403) {
            message = 'You do not have permission to perform this action.';
        }

        if (xhr.status === 404) {
            message = 'The requested resource was not found.';
        }

        if (xhr.status === 419) {
            message = 'Your session has expired. Please refresh the page.';
        }

        if (xhr.status >= 500) {
            message = 'Server error. Please try again later.';
        }

        return {
            status: xhr.status || 0,

            message: message,

            errors: response.errors || {}
        };
        },

        /* =====================================================
            SHOW ERROR
        ===================================================== */

        handleError(xhr, fallback = null) {
        const error = this.getError(xhr);

        this.error(fallback || error.message);

        return error;
        },

        /* =====================================================
            SUCCESS NOTIFICATION
        ===================================================== */

        success(message) {
        if (typeof toastr !== 'undefined') {
            toastr.success(message || 'Operation completed successfully.');

            return;
        }

        console.info(message);
        },

        /* =====================================================
            ERROR NOTIFICATION
        ===================================================== */

        error(message) {
        if (typeof toastr !== 'undefined') {
            toastr.error(message || 'Something went wrong.');

            return;
        }

        console.error(message);
        },

        /* =====================================================
            WARNING
        ===================================================== */

        warning(message) {
        if (typeof toastr !== 'undefined') {
            toastr.warning(message);

            return;
        }

        console.warn(message);
        },

        /* =====================================================
            INFO
        ===================================================== */

        info(message) {
        if (typeof toastr !== 'undefined') {
            toastr.info(message);

            return;
        }

        console.info(message);
        },

        /* =====================================================
            BUTTON LOADING
        ===================================================== */

        buttonLoading(button, loading = true) {
        const element = $(button);

        if (!element.length) {
            return;
        }

        if (loading) {
            if (!element.data('original-html')) {
            element.data('original-html', element.html());
            }

            element

            .addClass('cug-btn-loading')

            .prop('disabled', true);
        } else {
            const original = element.data('original-html');

            if (original !== undefined) {
            element.html(original);
            }

            element

            .removeClass('cug-btn-loading')

            .prop('disabled', false);
        }
        },

        /* =====================================================
            PAGE LOADING
        ===================================================== */

        pageLoading(show = true) {
        const page = $('#cugManagementPage');

        if (!page.length) {
            return;
        }

        let overlay = page.find('.cug-page-loading-overlay');

        if (show) {
            if (!overlay.length) {
            overlay = $(`
                        <div class="cug-page-loading-overlay">
                            <div class="cug-loading-spinner"></div>
                        </div>
                    `);

            page.css('position', 'relative');

            page.append(overlay);
            }

            overlay.removeClass('d-none');
        } else {
            overlay.addClass('d-none');
        }
        },

        /* =====================================================
            TABLE LOADING
        ===================================================== */

        tableLoading(show = true) {
        const tableCard = $('.cug-table-card');

        if (!tableCard.length) {
            return;
        }

        let overlay = tableCard.find('.cug-table-loading-overlay');

        if (show) {
            if (!overlay.length) {
            overlay = $(`
                        <div class="cug-table-loading-overlay">
                            <div class="cug-loading-spinner"></div>
                        </div>
                    `);

            tableCard.css('position', 'relative');

            tableCard.append(overlay);
            }

            overlay.removeClass('d-none');
        } else {
            overlay.addClass('d-none');
        }
        },

        /* =====================================================
            MODAL LOADING
        ===================================================== */

        modalLoading(modal, show = true) {
        const element = $(modal);

        if (!element.length) {
            return;
        }

        let overlay = element.find('.cug-modal-loading-overlay');

        if (show) {
            if (!overlay.length) {
            overlay = $(`
                        <div class="cug-modal-loading-overlay">
                            <div class="cug-loading-spinner"></div>
                        </div>
                    `);

            element

                .find('.modal-content')

                .css('position', 'relative')

                .append(overlay);
            }

            overlay.removeClass('d-none');
        } else {
            overlay.addClass('d-none');
        }
        },

        /* =====================================================
            CONFIRM
        ===================================================== */

        confirm(options = {}) {
        const defaults = {
            title: 'Are you sure?',

            text: 'This action cannot be undone.',

            confirmText: 'Confirm',

            cancelText: 'Cancel',

            type: 'warning'
        };

        const settings = $.extend({}, defaults, options);

        /*
            |--------------------------------------------------------------------------
            | SweetAlert2
            |--------------------------------------------------------------------------
            */

        if (typeof Swal !== 'undefined') {
            return Swal.fire({
            title: settings.title,

            text: settings.text,

            icon: settings.type,

            showCancelButton: true,

            confirmButtonText: settings.confirmText,

            cancelButtonText: settings.cancelText,

            reverseButtons: true,

            customClass: {
                confirmButton: 'btn btn-primary ms-2',

                cancelButton: 'btn btn-label-secondary'
            },

            buttonsStyling: false
            }).then(result => {
            return result.isConfirmed;
            });
        }

        /*
            |--------------------------------------------------------------------------
            | Native Fallback
            |--------------------------------------------------------------------------
            */

        return Promise.resolve(window.confirm(settings.title + '\n\n' + settings.text));
        },

        /* =====================================================
            DEBOUNCE
        ===================================================== */

        debounce(callback, delay = 400) {
        let timer = null;

        return function (...args) {
            clearTimeout(timer);

            timer = setTimeout(() => {
            callback.apply(this, args);
            }, delay);
        };
        },

        /* =====================================================
            THROTTLE
        ===================================================== */

        throttle(callback, delay = 300) {
        let waiting = false;

        return function (...args) {
            if (waiting) {
            return;
            }

            callback.apply(this, args);

            waiting = true;

            setTimeout(() => {
            waiting = false;
            }, delay);
        };
        },

        /* =====================================================
            NUMBER FORMAT
        ===================================================== */

        number(value, decimals = 0) {
        const number = Number(value || 0);

        return number.toLocaleString(
            this.config.locale,

            {
            minimumFractionDigits: decimals,

            maximumFractionDigits: decimals
            }
        );
        },

        /* =====================================================
            CURRENCY
        ===================================================== */

        currency(value, decimals = 2) {
        return this.config.currency + ' ' + this.number(value, decimals);
        },

        /* =====================================================
            PERCENTAGE
        ===================================================== */

        percentage(value, decimals = 1) {
        const number = Number(value || 0);

        return number.toFixed(decimals) + '%';
        },

        /* =====================================================
            ESCAPE HTML
        ===================================================== */

        escapeHtml(value) {
        if (value === null || value === undefined) {
            return '';
        }

        return String(value)
            .replace(/&/g, '&amp;')

            .replace(/</g, '&lt;')

            .replace(/>/g, '&gt;')

            .replace(/"/g, '&quot;')

            .replace(/'/g, '&#039;');
        },

        /* =====================================================
            INITIALS
        ===================================================== */

        initials(name) {
        if (!name) {
            return '?';
        }

        const parts = String(name)
            .trim()

            .split(/\s+/)

            .filter(Boolean);

        if (!parts.length) {
            return '?';
        }

        if (parts.length === 1) {
            return parts[0]

            .substring(0, 2)

            .toUpperCase();
        }

        return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
        },

        /* =====================================================
            EMPTY VALUE
        ===================================================== */

        value(value, fallback = '—') {
        if (value === null || value === undefined || value === '') {
            return fallback;
        }

        return value;
        },

        /* =====================================================
            ROUTE
        ===================================================== */

        route(name, id = null) {
        if (!window.cugRoutes || !window.cugRoutes[name]) {
            console.error(`CUG route "${name}" is not defined.`);

            return null;
        }

        let url = window.cugRoutes[name];

        if (id !== null) {
            const encodedId = encodeURIComponent(id);
            url = url.replace('__ID__', encodedId);
            url = url.replace(':id', encodedId);
        }

        return url;
        },

        /* =====================================================
            DATE
        ===================================================== */

        formatDate(value) {
        if (!value) {
            return '—';
        }

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return value;
        }

        return date.toLocaleDateString(
            this.config.locale,

            {
            day: '2-digit',

            month: 'short',

            year: 'numeric'
            }
        );
        },

        /* =====================================================
            FORM RESET
        ===================================================== */

        resetForm(form) {
        const element = $(form);

        if (!element.length) {
            return;
        }

        const formNode = element[0];

        if (formNode instanceof HTMLFormElement) {
            formNode.reset();
        }

        element

            .find('.is-invalid')

            .removeClass('is-invalid');

        element

            .find('.invalid-feedback')

            .remove();

        element

            .find('select')

            .val(null)

            .trigger('change');
        },

        /* =====================================================
            VALIDATION
        ===================================================== */

        showValidationErrors(form, errors = {}) {
        const element = $(form);

        if (!element.length) {
            return;
        }

        element

            .find('.is-invalid')

            .removeClass('is-invalid');

        element

            .find('.invalid-feedback.cug-validation-error')

            .remove();

        Object.keys(errors)

            .forEach(field => {
            const messages = Array.isArray(errors[field]) ? errors[field] : [errors[field]];

            const input = element.find(`[name="${field}"]`);

            if (!input.length) {
                return;
            }

            input.addClass('is-invalid');

            const feedback = $(`
                        <div class="invalid-feedback cug-validation-error">
                            ${this.escapeHtml(messages[0])}
                        </div>
                    `);

            if (input.next('.select2-container').length) {
                input

                .next('.select2-container')

                .after(feedback);
            } else {
                input.after(feedback);
            }
            });
        },

        /* =====================================================
            CLEAR VALIDATION
        ===================================================== */

        clearValidation(form) {
        const element = $(form);

        element

            .find('.is-invalid')

            .removeClass('is-invalid');

        element

            .find('.cug-validation-error')

            .remove();
        },

        /* =====================================================
            TOOLTIP
        ===================================================== */

        initTooltips() {
        if (typeof bootstrap === 'undefined') {
            return;
        }

        document

            .querySelectorAll('[data-bs-toggle="tooltip"]')

            .forEach(element => {
            bootstrap.Tooltip.getOrCreateInstance(element);
            });
        }
    };

    $(function () {
        CugHelper.init();
    });

    // CugHelper.get()
    // CugHelper.post()
    // CugHelper.postForm()

    // CugHelper.success()
    // CugHelper.error()
    // CugHelper.warning()

    // CugHelper.confirm()

    // CugHelper.buttonLoading()
    // CugHelper.pageLoading()
    // CugHelper.tableLoading()
    // CugHelper.modalLoading()

    // CugHelper.debounce()
    // CugHelper.throttle()

    // CugHelper.number()
    // CugHelper.percentage()

    // CugHelper.escapeHtml()
    // CugHelper.initials()

    // CugHelper.route()

    // CugHelper.showValidationErrors()
    // CugHelper.clearValidation()

  })(jQuery);
</script>

<!-- Tool Bar Js -->
<script>
(function ($) {

    'use strict';

    /**
     * =========================================================
     * CUG Management — Filters
     * =========================================================
     *
     * Responsibilities:
     *
     * - Search handling
     * - Company → Entity → Branch dependency
     * - Staff loading
     * - Advanced filters
     * - Date filters
     * - Filter count
     * - Active filter tags
     * - Reset
     * - Dashboard/DataTable synchronization
     * - Debounced refresh
     *
     * =========================================================
     */

    class CugFilters {
      constructor() {
        this.initialized = false;

        this.refreshTimer = null;

        this.dependencyRequests = {};

        this.silentChange = false;

        this.refreshDelay = 350;
      }

      /* =====================================================
          INIT
        ===================================================== */

      init() {
        if (this.initialized) {
          return;
        }

        this.initialized = true;

        this.initSelects();

        this.initDates();

        this.registerEvents();

        this.updateSearchClear();

        this.updateFilterState();
      }

      /* =====================================================
          SELECT2
        ===================================================== */

      initSelects() {
        if (typeof $.fn.select2 !== 'function') {
          return;
        }

        const selects = [
          '#filterCugCompany',

          '#filterCugEntity',

          '#filterCugBranch',

          '#filterCugProvider',

          '#filterCugAssignment',

          '#filterCugStaff',

          '#filterCugStatus'
        ];

        selects.forEach(selector => {
          const element = $(selector);

          if (!element.length) {
            return;
          }

          if (element.hasClass('select2-hidden-accessible')) {
            return;
          }

          element.select2({
            width: '100%',

            allowClear: false,

            minimumResultsForSearch: 8,

            dropdownParent: element.closest('#cugManagementPage').length
              ? element.closest('#cugManagementPage')
              : $(document.body)
          });
        });
      }

      /* =====================================================
          DATE PICKERS
        ===================================================== */

      initDates() {
        if (typeof flatpickr === 'undefined') {
          return;
        }

        const self = this;

        $('.cug-date-filter').each(function () {
          const element = $(this);

          if (element.data('cug-flatpickr')) {
            return;
          }

          const picker = flatpickr(this, {
            dateFormat: 'Y-m-d',

            altInput: true,

            altFormat: 'd M Y',

            allowInput: false,

            disableMobile: true,

            onChange: function () {
              self.scheduleRefresh();
            }
          });

          element.data('cug-flatpickr', picker);
        });
      }

      /* =====================================================
          EVENTS
        ===================================================== */

      registerEvents() {
        const self = this;

        /* -------------------------------------------------
              Search
            ------------------------------------------------- */

        $(document).on(
          'input',
          '#cugSearch',
          CugHelper.debounce(function () {
            self.updateSearchClear();

            self.scheduleRefresh();
          }, 350)
        );

        /* -------------------------------------------------
              Search Clear
            ------------------------------------------------- */

        $(document).on('click', '#btnClearCugSearch', function () {
          $('#cugSearch').val('');

          self.updateSearchClear();

          self.scheduleRefresh();
        });

        /* -------------------------------------------------
              Company
            ------------------------------------------------- */

        $(document).on('change', '#filterCugCompany', function () {
          const companyId = $(this).val();

          self.loadEntities(companyId);

          self.scheduleRefresh();
        });

        /* -------------------------------------------------
              Entity
            ------------------------------------------------- */

        $(document).on('change', '#filterCugEntity', function () {
          const entityId = $(this).val();

          self.loadBranches(entityId);

          self.scheduleRefresh();
        });

        /* -------------------------------------------------
              Branch
            ------------------------------------------------- */

        $(document).on('change', '#filterCugBranch', function () {
          self.scheduleRefresh();
        });

        /* -------------------------------------------------
              Normal Select Filters
            ------------------------------------------------- */

        $(document).on(
          'change',
          ['#filterCugStatus', '#filterCugProvider', '#filterCugAssignment', '#filterCugStaff'].join(','),
          function () {
            self.scheduleRefresh();
          }
        );

        /* -------------------------------------------------
              Number Range
            ------------------------------------------------- */

        $(document).on(
          'input',
          '#filterCugNumberFrom, #filterCugNumberTo',
          CugHelper.debounce(function () {
            self.scheduleRefresh();
          }, 450)
        );

        /* -------------------------------------------------
              Date Filter
            ------------------------------------------------- */

        $(document).on('change', '#filterCugAssignedFrom, #filterCugAssignedTo', function () {
          self.scheduleRefresh();
        });

        /* -------------------------------------------------
              Reset
            ------------------------------------------------- */

        $(document).on('click', '#btnResetCugFilter', function () {
          self.reset();
        });

        /* -------------------------------------------------
              Clear Advanced
            ------------------------------------------------- */

        $(document).on('click', '#btnClearAdvancedCugFilters', function () {
          self.clearAdvanced();
        });

        /* -------------------------------------------------
              Advanced Collapse
            ------------------------------------------------- */

        $(document).on('shown.bs.collapse hidden.bs.collapse', '#cugAdvancedFilters', function () {
          self.updateFilterState();
        });
      }

      /* =====================================================
          COMPANY → ENTITY
        ===================================================== */

      loadEntities(companyId) {
        const self = this;

        self.clearSelect('#filterCugEntity', 'All Entities');

        self.clearSelect('#filterCugBranch', 'All Branches');

        $('#filterCugEntity').prop('disabled', !companyId).trigger('change.select2');

        $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

        if (!companyId) {
          return;
        }

        const url = CugHelper.route('entities');

        if (!url) {
          return;
        }

        self.abortDependency('entities');

        self.dependencyRequests.entities = CugHelper.get(url, {
          company_id: companyId
        })

          .done(function (response) {
            const records = self.extractRecords(response, 'entities');

            self.populateSelect('#filterCugEntity', records, 'All Entities');
          })

          .fail(function (xhr, status) {
            if (status === 'abort') {
              return;
            }

            CugHelper.handleError(xhr, 'Unable to load entities.');
          });
      }

      /* =====================================================
          ENTITY → BRANCH
        ===================================================== */

      loadBranches(entityId) {
        const self = this;

        self.clearSelect('#filterCugBranch', 'All Branches');

        $('#filterCugBranch').prop('disabled', !entityId).trigger('change.select2');

        if (!entityId) {
          return;
        }

        const url = CugHelper.route('branches');

        if (!url) {
          return;
        }

        self.abortDependency('branches');

        self.dependencyRequests.branches = CugHelper.get(url, {
          entity_id: entityId
        })

          .done(function (response) {
            const records = self.extractRecords(response, 'branches');

            self.populateSelect('#filterCugBranch', records, 'All Branches');
          })

          .fail(function (xhr, status) {
            if (status === 'abort') {
              return;
            }

            CugHelper.handleError(xhr, 'Unable to load branches.');
          });
      }

      /* =====================================================
          STAFF
        ===================================================== */

      loadStaff(params = {}) {
        const self = this;

        const url = CugHelper.route('staff');

        if (!url) {
          return;
        }

        const select = $('#filterCugStaff');

        if (!select.length) {
          return;
        }

        self.abortDependency('staff');

        self.dependencyRequests.staff = CugHelper.get(url, params)

          .done(function (response) {
            const records = self.extractRecords(response, 'staff');

            self.populateSelect('#filterCugStaff', records, 'All Staff');
          })

          .fail(function (xhr, status) {
            if (status === 'abort') {
              return;
            }

            CugHelper.handleError(xhr, 'Unable to load staff.');
          });
      }

      /* =====================================================
          POPULATE SELECT
        ===================================================== */

      populateSelect(selector, records, placeholder) {
        const select = $(selector);

        if (!select.length) {
          return;
        }

        const currentValue = select.val();

        select.empty();

        select.append(new Option(placeholder, '', false, false));

        records.forEach(record => {
          const id = record.id ?? record.sno ?? record.value;

          const text =
            record.name ??
            record.label ??
            record.text ??
            record.company_name ??
            record.entity_name ??
            record.branch_name ??
            record.staff_name;

          if (id === undefined || text === undefined) {
            return;
          }

          select.append(new Option(text, id, false, String(id) === String(currentValue)));
        });

        select.trigger('change.select2');
      }

      /* =====================================================
          CLEAR SELECT
        ===================================================== */

      clearSelect(selector, placeholder) {
        const select = $(selector);

        if (!select.length) {
          return;
        }

        select.empty();

        select.append(new Option(placeholder, '', false, false));

        select.val(null);

        select.trigger('change.select2');
      }

      /* =====================================================
          EXTRACT RECORDS
        ===================================================== */

      extractRecords(response, key = null) {
        if (!response) {
          return [];
        }

        let records = response.data ?? response;

        if (key && records && !Array.isArray(records) && Array.isArray(records[key])) {
          records = records[key];
        }

        if (records && records.data && Array.isArray(records.data)) {
          records = records.data;
        }

        return Array.isArray(records) ? records : [];
      }

      /* =====================================================
          ABORT DEPENDENCY
        ===================================================== */

      abortDependency(name) {
        if (this.dependencyRequests[name]) {
          this.dependencyRequests[name].abort();

          this.dependencyRequests[name] = null;
        }
      }

      /* =====================================================
          FILTER OBJECT
        ===================================================== */

      getFilters() {
        return {
          search: this.getValue('#cugSearch'),

          company_id: this.getValue('#filterCugCompany'),

          entity_id: this.getValue('#filterCugEntity'),

          branch_id: this.getValue('#filterCugBranch'),

          status: this.getValue('#filterCugStatus'),

          provider: this.getValue('#filterCugProvider'),

          assignment_status: this.getValue('#filterCugAssignment'),

          staff_id: this.getValue('#filterCugStaff'),

          number_from: this.getValue('#filterCugNumberFrom'),

          number_to: this.getValue('#filterCugNumberTo'),

          assigned_from: this.getValue('#filterCugAssignedFrom'),

          assigned_to: this.getValue('#filterCugAssignedTo')
        };
      }

      /* =====================================================
          GET VALUE
        ===================================================== */

      getValue(selector) {
        return $(selector).val() || '';
      }

      /* =====================================================
          SCHEDULE REFRESH
        ===================================================== */

      scheduleRefresh() {
        clearTimeout(this.refreshTimer);

        this.updateFilterState();

        this.refreshTimer = setTimeout(() => {
          this.refreshAll();
        }, this.refreshDelay);
      }

      /* =====================================================
          REFRESH ALL
        ===================================================== */

      refreshAll() {
        /*
            |--------------------------------------------------------------------------
            | Dashboard
            |--------------------------------------------------------------------------
            */

        if (window.cugDashboard && typeof window.cugDashboard.load === 'function') {
          window.cugDashboard.load();
        }

        /*
            |--------------------------------------------------------------------------
            | CUG table
            |--------------------------------------------------------------------------
            */

        if (window.cugDataTable && typeof window.cugDataTable.reload === 'function') {
          window.cugDataTable.reload();
        }

        /*
            |--------------------------------------------------------------------------
            | Timeline
            |--------------------------------------------------------------------------
            */

        if (window.cugTimeline && typeof window.cugTimeline.load === 'function') {
          window.cugTimeline.load();
        }
      }

      /* =====================================================
          RESET
        ===================================================== */

      reset() {
        const self = this;

        self.silentChange = true;

        clearTimeout(self.refreshTimer);

        /*
            |--------------------------------------------------------------------------
            | Search
            |--------------------------------------------------------------------------
            */

        $('#cugSearch').val('');

        self.updateSearchClear();

        /*
            |--------------------------------------------------------------------------
            | Main Filters
            |--------------------------------------------------------------------------
            */

        self.resetSelect('#filterCugCompany');

        self.clearSelect('#filterCugEntity', 'All Entities');

        self.clearSelect('#filterCugBranch', 'All Branches');

        $('#filterCugEntity').prop('disabled', true).trigger('change.select2');

        $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

        self.resetSelect('#filterCugStatus');

        self.resetSelect('#filterCugProvider');

        self.resetSelect('#filterCugAssignment');

        self.resetSelect('#filterCugStaff');

        /*
            |--------------------------------------------------------------------------
            | Number Range
            |--------------------------------------------------------------------------
            */

        $('#filterCugNumberFrom').val('');

        $('#filterCugNumberTo').val('');

        /*
            |--------------------------------------------------------------------------
            | Dates
            |--------------------------------------------------------------------------
            */

        self.clearDate('#filterCugAssignedFrom');

        self.clearDate('#filterCugAssignedTo');

        /*
            |--------------------------------------------------------------------------
            | Card State
            |--------------------------------------------------------------------------
            */

        $('.cug-stat-card').removeClass('cug-stat-active');

        /*
            |--------------------------------------------------------------------------
            | Advanced Filter Summary
            |--------------------------------------------------------------------------
            */

        self.silentChange = false;

        self.updateFilterState();

        self.refreshAll();
      }

      /* =====================================================
          RESET SELECT
        ===================================================== */

      resetSelect(selector) {
        const select = $(selector);

        if (!select.length) {
          return;
        }

        select.val('').trigger('change.select2');
      }

      /* =====================================================
          CLEAR DATE
        ===================================================== */

      clearDate(selector) {
        const input = $(selector);

        if (!input.length) {
          return;
        }

        const picker = input.data('cug-flatpickr');

        if (picker && typeof picker.clear === 'function') {
          picker.clear();
        } else {
          input.val('');
        }
      }

      /* =====================================================
          CLEAR ADVANCED
        ===================================================== */

      clearAdvanced() {
        const self = this;

        self.silentChange = true;

        self.resetSelect('#filterCugStatus');

        self.resetSelect('#filterCugProvider');

        self.resetSelect('#filterCugAssignment');

        self.resetSelect('#filterCugStaff');

        $('#filterCugNumberFrom').val('');

        $('#filterCugNumberTo').val('');

        self.clearDate('#filterCugAssignedFrom');

        self.clearDate('#filterCugAssignedTo');

        self.silentChange = false;

        self.updateFilterState();

        self.refreshAll();
      }

      /* =====================================================
          SEARCH CLEAR
        ===================================================== */

      updateSearchClear() {
        const search = $('#cugSearch');

        const clearButton = $('#btnClearCugSearch');

        if (!search.length || !clearButton.length) {
          return;
        }

        clearButton.toggleClass('d-none', !search.val());
      }

      /* =====================================================
          FILTER STATE
        ===================================================== */

      updateFilterState() {
        const filters = this.getFilters();

        const ignored = ['search'];

        let count = 0;

        Object.keys(filters).forEach(key => {
          if (ignored.includes(key)) {
            return;
          }

          if (filters[key] !== '') {
            count++;
          }
        });

        /*
            |--------------------------------------------------------------------------
            | Filter Count
            |--------------------------------------------------------------------------
            */

        const badge = $('#cugFilterCount');

        badge

          .text(count)

          .toggleClass('d-none', count === 0);

        /*
            |--------------------------------------------------------------------------
            | Summary
            |--------------------------------------------------------------------------
            */

        const summary = $('#cugFilterSummary');

        const tags = $('#cugActiveFilterTags');

        if (!summary.length || !tags.length) {
          return;
        }

        tags.empty();

        const labels = {
          company_id: 'Company',

          entity_id: 'Entity',

          branch_id: 'Branch',

          status: 'Status',

          provider: 'Provider',

          assignment_status: 'Assignment',

          staff_id: 'Staff',

          number_from: 'Number From',

          number_to: 'Number To',

          assigned_from: 'Assigned From',

          assigned_to: 'Assigned To'
        };

        Object.keys(filters).forEach(key => {
          if (ignored.includes(key) || filters[key] === '') {
            return;
          }

          const label = labels[key] || key;

          const display = this.getDisplayValue(key, filters[key]);

          const tag = $(`
                        <span
                            class="cug-filter-tag"
                            data-filter-key="${CugHelper.escapeHtml(key)}">

                            ${CugHelper.escapeHtml(label)}:
                            ${CugHelper.escapeHtml(display)}

                            <button
                                type="button"
                                class="cug-remove-filter"
                                data-filter-key="${CugHelper.escapeHtml(key)}"
                                aria-label="Remove ${CugHelper.escapeHtml(label)}">

                                <i class="ti ti-x"></i>

                            </button>

                        </span>
                    `);

          tags.append(tag);
        });

        summary.toggleClass('d-none', count === 0);
      }

      /* =====================================================
          DISPLAY FILTER VALUE
        ===================================================== */

      getDisplayValue(key, value) {
        let selector = null;

        switch (key) {
          case 'company_id':
            selector = '#filterCugCompany';

            break;

          case 'entity_id':
            selector = '#filterCugEntity';

            break;

          case 'branch_id':
            selector = '#filterCugBranch';

            break;

          case 'status':
            selector = '#filterCugStatus';

            break;

          case 'provider':
            selector = '#filterCugProvider';

            break;

          case 'assignment_status':
            selector = '#filterCugAssignment';

            break;

          case 'staff_id':
            selector = '#filterCugStaff';

            break;
        }

        if (selector) {
          const selectedText = $(selector).find('option:selected').text();

          if (selectedText && selectedText.trim()) {
            return selectedText.trim();
          }
        }

        return String(value);
      }

      /* =====================================================
          REMOVE INDIVIDUAL FILTER
        ===================================================== */

      removeFilter(key) {
        switch (key) {
          case 'company_id':
            this.resetSelect('#filterCugCompany');

            this.clearSelect('#filterCugEntity', 'All Entities');

            this.clearSelect('#filterCugBranch', 'All Branches');

            $('#filterCugEntity').prop('disabled', true).trigger('change.select2');

            $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

            break;

          case 'entity_id':
            this.resetSelect('#filterCugEntity');

            this.clearSelect('#filterCugBranch', 'All Branches');

            $('#filterCugBranch').prop('disabled', true).trigger('change.select2');

            break;

          case 'branch_id':
            this.resetSelect('#filterCugBranch');

            break;

          case 'status':
            this.resetSelect('#filterCugStatus');

            break;

          case 'provider':
            this.resetSelect('#filterCugProvider');

            break;

          case 'assignment_status':
            this.resetSelect('#filterCugAssignment');

            break;

          case 'staff_id':
            this.resetSelect('#filterCugStaff');

            break;

          case 'number_from':
            $('#filterCugNumberFrom').val('');

            break;

          case 'number_to':
            $('#filterCugNumberTo').val('');

            break;

          case 'assigned_from':
            this.clearDate('#filterCugAssignedFrom');

            break;

          case 'assigned_to':
            this.clearDate('#filterCugAssignedTo');

            break;
        }

        this.scheduleRefresh();
      }

      /* =====================================================
          FILTER TAG CLICK
        ===================================================== */

      bindRemoveFilter() {
        const self = this;

        $(document).on('click', '.cug-remove-filter', function () {
          const key = $(this).data('filter-key');

          if (!key) {
            return;
          }

          self.removeFilter(key);
        });
      }
    }

    /* =========================================================
      GLOBAL INSTANCE
    ========================================================= */

    $(function () {
      window.cugFilters = new CugFilters();

      cugFilters.init();

      cugFilters.bindRemoveFilter();
    });

})(jQuery);
</script>

<script>
(function ($) {
    'use strict';

    class CugRecentActivity {
        constructor() {
            this.request = null;
            this.initialized = false;
        }

        init() {
            if (this.initialized) return;
            this.initialized = true;

            this.load();

            $(document).on('click', '#btnViewAllCugHistory', () => {
                const firstActivity = document.querySelector('.cug-activity-item[data-cug-id]');
                const cugId = firstActivity?.getAttribute('data-cug-id');

                if (cugId && window.cugModal) {
                    window.cugModal.openHistory(cugId, 'assignments');
                } else {
                    this.load();
                }
            });
        }

        load() {
            const body = $('#cugActivityTimeline');
            const loading = $('#cugActivityLoading');
            const empty = $('#cugActivityEmpty');

            if (!body.length) return;

            if (this.request) {
                this.request.abort();
            }

            loading.removeClass('d-none');
            empty.addClass('d-none');

            this.request = CugHelper.get(CugHelper.route('recentActivity'), {
                limit: 6
            });

            this.request
                .done((response) => {
                    const rows = Array.isArray(response?.data)
                        ? response.data
                        : [];

                    loading.addClass('d-none');
                    body.find('.cug-activity-item, .cug-activity-error').remove();

                    if (!rows.length) {
                        empty.removeClass('d-none');
                        return;
                    }

                    body.append(
                        rows.map(row => this.render(row)).join('')
                    );
                })
                .fail((xhr, status) => {
                    if (status === 'abort') return;

                    loading.addClass('d-none');
                    empty.addClass('d-none');
                    body.find('.cug-activity-item, .cug-activity-error').remove();

                    body.append(`
                        <div class="cug-activity-error">
                            <i class="ti ti-alert-circle"></i>
                            <span>Unable to load recent CUG activity.</span>
                        </div>
                    `);
                })
                .always(() => {
                    this.request = null;
                });
        }

        render(row) {
            const actionMap = {
                ASSIGN: ['ti-user-plus', 'assigned', 'CUG Assigned'],
                CHANGE_STAFF: ['ti-user-shared', 'changed', 'Staff Changed'],
                RELEASE: ['ti-user-minus', 'released', 'CUG Released'],
                DEACTIVATE: ['ti-device-mobile-off', 'deactivated', 'CUG Deactivated'],
                DELETE: ['ti-trash', 'deleted', 'CUG Deleted'],
                CREATE: ['ti-device-mobile-plus', 'created', 'CUG Created'],
                UPDATE: ['ti-edit', 'updated', 'CUG Updated']
            };

            const meta = actionMap[String(row.action || '').toUpperCase()]
                || ['ti-history', 'activity', String(row.action || 'Activity')];

            const staff = row.new_staff_name
                || row.old_staff_name
                || 'Unassigned';

            return `
                <div class="cug-activity-item" data-cug-id="${CugHelper.escapeHtml(row.cug_id || '')}">
                    <div class="cug-activity-icon ${meta[1]}">
                        <i class="ti ${meta[0]}"></i>
                    </div>
                    <div class="cug-activity-content">
                        <div class="cug-activity-title">
                            ${CugHelper.escapeHtml(meta[2])}
                        </div>
                        <div class="cug-activity-description">
                            <strong>${CugHelper.escapeHtml(row.cug_number || 'CUG')}</strong>
                            ${row.action === 'CHANGE_STAFF'
                                ? ` · ${CugHelper.escapeHtml(row.old_staff_name || 'Unassigned')} → ${CugHelper.escapeHtml(staff)}`
                                : row.action === 'ASSIGN'
                                    ? ` · ${CugHelper.escapeHtml(staff)}`
                                    : ''}
                        </div>
                        <div class="cug-activity-meta">
                            ${CugHelper.escapeHtml(CugHelper.formatDateTime(row.event_date))}
                        </div>
                    </div>
                </div>
            `;
        }
    }

    $(function () {
        window.cugRecentActivity = new CugRecentActivity();
        cugRecentActivity.init();
    });
})(jQuery);
</script>

<!-- Dashboard Js -->
<script>
    (function ($) {

        'use strict';

        /**
         * =========================================================
         * CUG Management — Dashboard
         * =========================================================
         *
         * Responsibilities:
         *
         * - Load dashboard KPI data
         * - Apply current filters
         * - Animate counters
         * - Update utilization
         * - Update call statistics
         * - Update number-pool statistics
         * - Handle card filtering
         * - Prevent stale AJAX responses
         * - Refresh without page reload
         *
         * =========================================================
         */

        class CugDashboard {
            constructor() {
                this.request = null;

                this.requestSequence = 0;

                this.initialized = false;
            }

            /* INIT */

            init() {
                if (this.initialized) {
                return;
                }

                this.initialized = true;

                this.registerEvents();

                this.load();
            }

            /* EVENTS */

            registerEvents() {
                const self = this;

                /*
                    |--------------------------------------------------------------------------
                    | Dashboard Card Click
                    |--------------------------------------------------------------------------
                    */

                $(document).on('click', '.cug-stat-card', function () {
                const filter = $(this).data('card-filter');

                if (!filter) {
                    return;
                }

                self.handleCardFilter(filter);
                });
            }

            /*  LOAD  */

            load() {
                const self = this;

                const url = CugHelper.route('dashboard');
                // const url = CugHelper.route('dashboard');

                if (!url) {
                    return;
                }

                /*
                    |--------------------------------------------------------------------------
                    | Abort Previous Request
                    |--------------------------------------------------------------------------
                    */

                if (self.request) {
                self.request.abort();
                }

                const sequence = ++self.requestSequence;

                self.setLoading(true);

                self.request = CugHelper.get(
                url,

                self.getFilters()
                );

                self.request

                .done(function (response) {
                    /*
                            |--------------------------------------------------------------------------
                            | Ignore stale response
                            |--------------------------------------------------------------------------
                            */

                    if (sequence !== self.requestSequence) {
                    return;
                    }

                    const data = self.normalizeResponse(response);

                    self.render(data);
                })

                .fail(function (xhr, status) {
                    /*
                            |--------------------------------------------------------------------------
                            | Ignore intentionally aborted requests
                            |--------------------------------------------------------------------------
                            */

                    if (status === 'abort') {
                    return;
                    }

                    CugHelper.handleError(xhr, 'Unable to load CUG dashboard.');
                })

                .always(function () {
                    if (sequence === self.requestSequence) {
                    self.setLoading(false);
                    }
                });
            }

            /* REFRESH */

            refresh() {
                this.load();
            }

            /*FILTERS */

            getFilters() {
                return {
                search: $('#cugSearch').val() || '',

                company_id: $('#filterCugCompany').val() || '',

                entity_id: $('#filterCugEntity').val() || '',

                branch_id: $('#filterCugBranch').val() || '',

                status: $('#filterCugStatus').val() || '',

                provider: $('#filterCugProvider').val() || '',

                assignment_status: $('#filterCugAssignment').val() || '',

                staff_id: $('#filterCugStaff').val() || '',

                number_from: $('#filterCugNumberFrom').val() || '',

                number_to: $('#filterCugNumberTo').val() || '',

                assigned_from: $('#filterCugAssignedFrom').val() || '',

                assigned_to: $('#filterCugAssignedTo').val() || ''
                };
            }

            /*  RESPONSE NORMALIZATION */

            normalizeResponse(response) {
                let data = response?.data || response || {};

                /*
                    |--------------------------------------------------------------------------
                    | Support nested dashboard response
                    |--------------------------------------------------------------------------
                    */

                if (data && typeof data === 'object') {
                    data = data;
                }

                const total = this.toNumber(data.total_count);

                const assigned = this.toNumber(data.assigned_count);

                const available = this.toNumber(data.available_count);

                const reserved = this.toNumber(data.reserved);

                const inactive = this.toNumber(data.inactive_count);

                let utilization = this.toNumber(data.utilization);

                /*
                    |--------------------------------------------------------------------------
                    | Calculate utilization if backend didn't provide it
                    |--------------------------------------------------------------------------
                    */

                if (!Object.prototype.hasOwnProperty.call(data, 'utilization')) {
                utilization = total > 0 ? (assigned / total) * 100 : 0;
                }

                return {
                total_cug: total,

                assigned: assigned,

                available: available,

                reserved: reserved,

                inactive: inactive,

                utilization: this.clamp(utilization, 0, 100),

                today_calls: this.toNumber(data.today_calls),

                received_calls: this.toNumber(data.received_calls),

                dialled_calls: this.toNumber(data.dialled_calls),

                missed_calls: this.toNumber(data.missed_calls)
                };
            }

            /* RENDER */

            render(data) {
                /*
                    |--------------------------------------------------------------------------
                    | Main KPI Cards
                    |--------------------------------------------------------------------------
                    */

                this.animateCounter('#cugTotalCount', data.total_cug);

                this.animateCounter('#cugAssignedCount', data.assigned);

                this.animateCounter('#cugAvailableCount', data.available);

                this.animateCounter('#cugInactiveCount', data.reserved + data.inactive);

                /*
                    |--------------------------------------------------------------------------
                    | Utilization
                    |--------------------------------------------------------------------------
                    */

                this.animatePercentage('#cugUtilization', data.utilization);

                $('#cugUtilizationBar')
                .css('width', data.utilization + '%')

                .attr('aria-valuenow', data.utilization);

                this.animateCounter('#cugUtilizationAssigned', data.assigned);

                this.animateCounter('#cugUtilizationTotal', data.total_cug);

                /*
                    |--------------------------------------------------------------------------
                    | Calls
                    |--------------------------------------------------------------------------
                    */

                this.animateCounter('#cugTodayCalls', data.today_calls);

                this.animateCounter('#cugReceivedCalls', data.received_calls);

                this.animateCounter('#cugDialledCalls', data.dialled_calls);

                this.animateCounter('#cugMissedCalls', data.missed_calls);

                /*
                    |--------------------------------------------------------------------------
                    | Number Pool
                    |--------------------------------------------------------------------------
                    */

                this.animateCounter('#cugPoolAvailable', data.available);

                this.animateCounter('#cugPoolAssigned', data.assigned);

                this.animateCounter('#cugPoolReserved', data.reserved);

                this.animateCounter('#cugPoolInactive', data.inactive);
            }

            /* COUNTER  */

            animateCounter(selector, target, duration = 550) {
                const element = $(selector);

                if (!element.length) {
                return;
                }

                const finalValue = this.toNumber(target);

                const currentValue = this.toNumber(element.attr('data-cug-value'));

                const startTime = performance.now();

                const startValue = currentValue;

                const difference = finalValue - startValue;

                const easeOut = function (progress) {
                return 1 - Math.pow(1 - progress, 3);
                };

                const update = function (timestamp) {
                const elapsed = timestamp - startTime;

                const progress = Math.min(elapsed / duration, 1);

                const eased = easeOut(progress);

                const value = startValue + difference * eased;

                element.text(CugHelper.number(value, 0));

                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    element

                    .text(CugHelper.number(finalValue, 0))

                    .attr('data-cug-value', finalValue);
                }
                };

                requestAnimationFrame(update);
            }

            /* PERCENTAGE */

            animatePercentage(selector, target, duration = 550) {
                const element = $(selector);

                if (!element.length) {
                return;
                }

                const finalValue = this.clamp(this.toNumber(target), 0, 100);

                const currentValue = this.toNumber(element.attr('data-cug-percentage'));

                const startTime = performance.now();

                const difference = finalValue - currentValue;

                const update = function (timestamp) {
                const elapsed = timestamp - startTime;

                const progress = Math.min(elapsed / duration, 1);

                const eased = 1 - Math.pow(1 - progress, 3);

                const value = currentValue + difference * eased;

                element.text(value.toFixed(1) + '%');

                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    element

                    .text(finalValue.toFixed(1) + '%')

                    .attr('data-cug-percentage', finalValue);
                }
                };

                requestAnimationFrame(update);
            }

            /* LOADING */

            setLoading(show) {
                const cards = $('#cugDashboardCards').find('.cug-stat-card');

                cards.toggleClass('cug-dashboard-loading', show);

                $('#cugDashboardCards').toggleClass('cug-dashboard-fetching', show);
            }

            /*  CARD FILTER */

            handleCardFilter(filter) {
                /*
                    |--------------------------------------------------------------------------
                    | Remove Previous Active State
                    |--------------------------------------------------------------------------
                    */

                $('.cug-stat-card').removeClass('cug-stat-active');

                /*
                    |--------------------------------------------------------------------------
                    | All
                    |--------------------------------------------------------------------------
                    */

                if (filter === 'all') {
                $('#filterCugStatus')
                    .val('')

                    .trigger('change');

                $('#filterCugAssignment')
                    .val('')

                    .trigger('change');

                $('#cugCardTotal').addClass('cug-stat-active');

                return;
                }

                /*
                    |--------------------------------------------------------------------------
                    | Assigned
                    |--------------------------------------------------------------------------
                    */

                if (filter === 'assigned') {
                $('#filterCugStatus')
                    .val('1')

                    .trigger('change');

                $('#filterCugAssignment')
                    .val('assigned')

                    .trigger('change');

                $('#cugCardAssigned').addClass('cug-stat-active');

                return;
                }

                /*
                    |--------------------------------------------------------------------------
                    | Available
                    |--------------------------------------------------------------------------
                    */

                if (filter === 'available') {
                $('#filterCugStatus')
                    .val('0')

                    .trigger('change');

                $('#filterCugAssignment')
                    .val('available')

                    .trigger('change');

                $('#cugCardAvailable').addClass('cug-stat-active');

                return;
                }

                /*
                    |--------------------------------------------------------------------------
                    | Inactive
                    |--------------------------------------------------------------------------
                    */

                if (filter === 'inactive') {
                $('#filterCugStatus')
                    .val('3')

                    .trigger('change');

                $('#filterCugAssignment')
                    .val('')

                    .trigger('change');

                $('#cugCardInactive').addClass('cug-stat-active');
                }
            }

            /* NUMBER */

            toNumber(value) {
                const number = Number(value);

                return Number.isFinite(number) ? number : 0;
            }

            /* CLAMP */

            clamp(value, minimum, maximum) {
                return Math.min(
                Math.max(value, minimum),

                maximum
                );
            }
        }

        /* GLOBAL INSTANCE  */
        $(function () {
            window.cugDashboard = new CugDashboard();

            cugDashboard.init();
        });
    })(jQuery);
</script>

<!-- Main Table Js -->
<script>
    (function ($) {

        'use strict';

        /**
         * =========================================================
         * CUG Management — Server-paginated table
         * =========================================================
         *
         * Responsibilities:
         *
         * - Server-side pagination
         * - CUG inventory listing
         * - Filtering
         * - Sorting
         * - Pagination
         * - Row selection
         * - Bulk selection
         * - Row action menu
         * - Empty state
         * - Reload without recreating the table
         *
         * =========================================================
         */

        class CugDataTable {
            constructor() {
                this.table = $('#cugDataTable');
                this.tbody = this.table.find('tbody');
                this.initialized = false;
                this.selectedRows = new Set();
                this.currentRows = [];
                this.currentPage = 1;
                this.lastPage = 1;
                this.total = 0;
                this.perPage = 25;
                this.currentRequest = null;
                this.ajaxSequence = 0;
            }

            init() {
                if (this.initialized || !this.table.length) return;
                this.initialized = true;
                this.ensureTableControls();
                this.registerEvents();
                this.load(1);
            }

            ensureTableControls() {
                if (!$('#cugPerPage').length) {
                    $('.cug-table-header > .d-flex').prepend(`
                        <div class="d-flex align-items-center gap-2 cug-per-page-wrap">
                            <label for="cugPerPage" class="small text-muted mb-0">Show</label>
                            <select id="cugPerPage" class="form-select form-select-sm" style="width:80px">
                                <option value="5">5</option>
                                <option value="10">10</option>
                                <option value="25" selected>25</option>
                                <option value="100">100</option>
                                <option value="500">500</option>
                            </select>
                        </div>
                    `);
                }
                if (!$('#cugPaginationContainer').length) {
                    this.table.closest('.cug-table-card').append(`
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 px-3 py-3 border-top" id="cugPaginationContainer">
                            <div class="text-muted small" id="cugPaginationInfo"></div>
                            <nav aria-label="CUG pagination">
                                <ul class="pagination pagination-sm mb-0" id="cugPagination"></ul>
                            </nav>
                        </div>
                    `);
                }
            }

            load(page = 1) {
                page = Math.max(1, Number(page) || 1);
                this.currentPage = page;
                this.setLoading(true);
                if (this.currentRequest) this.currentRequest.abort();

                const sequence = ++this.ajaxSequence;
                const filters = window.cugFilters && typeof window.cugFilters.getFilters === 'function'
                    ? window.cugFilters.getFilters()
                    : {};
                const perPage = Number($('#cugPerPage').val() || this.perPage);
                this.perPage = [5, 10, 25, 100, 500].includes(perPage) ? perPage : 25;

                const payload = $.extend({}, filters, {
                    page: page,
                    per_page: this.perPage
                });

                this.currentRequest = CugHelper.get(CugHelper.route('datatable'), payload);
                this.currentRequest
                    .done(response => {
                        if (sequence !== this.ajaxSequence) return;
                        const rows = Array.isArray(response?.data) ? response.data : [];
                        this.currentRows = rows;
                        this.currentPage = Number(response?.current_page || page);
                        this.lastPage = Math.max(1, Number(response?.last_page || 1));
                        this.total = Number(response?.total || 0);
                        this.renderRows(rows);
                        this.updatePagination();
                        this.updateSelectionUI();
                        CugHelper.initTooltips();
                        if (rows.length) {
                            $('#cugTableEmpty').addClass('d-none');
                            this.table.removeClass('d-none');
                        } else {
                            $('#cugTableEmpty').toggleClass('d-none', this.total !== 0);
                            this.table.toggleClass('d-none', this.total === 0);
                        }
                    })
                    .fail((xhr, status) => {
                        if (status === 'abort' || sequence !== this.ajaxSequence) return;
                        this.currentRows = [];
                        this.renderRows([]);
                        this.total = 0;
                        this.lastPage = 1;
                        this.updatePagination();
                        CugHelper.handleError(xhr, 'Unable to load CUG numbers.');
                    })
                    .always(() => {
                        if (sequence === this.ajaxSequence) {
                            this.currentRequest = null;
                            this.setLoading(false);
                        }
                    });
            }

            setLoading(loading) {
                const body = this.tbody;
                body.css('opacity', loading ? '0.55' : '1');
                $('#cugTableLoading').toggleClass('d-none', !loading);
            }

            renderRows(rows) {
                this.tbody.empty();
                if (!rows.length) {
                    this.updateSelectAllState();
                    return;
                }

                const html = rows.map(row => `
                    <tr>
                        <td class="cug-checkbox-column">${this.renderCheckbox(row)}</td>
                        <td>${this.renderNumber(row.cug_number, row)}</td>
                        <td>${this.renderProvider(row.provider)}</td>
                        <td>${CugHelper.escapeHtml(CugHelper.value(row.company_name))}</td>
                        <td>${CugHelper.escapeHtml(CugHelper.value(row.entity_name))}</td>
                        <td>${this.renderStaff(row.staff_name, row)}</td>
                        <td>${this.renderAssignment(row.assignment_date, row)}</td>
                        <td class="text-center">${this.renderCalls(row.call_count, row)}</td>
                        <td>${this.renderStatus(row.status, row)}</td>
                        <td class="cug-action-column">${this.renderActions(row)}</td>
                    </tr>
                `).join('');

                this.tbody.html(html);
                this.updateSelectAllState();
            }

            updatePagination() {
                const total = this.total;
                const current = this.currentPage;
                const last = this.lastPage;
                const perPage = this.perPage;
                const start = total ? ((current - 1) * perPage) + 1 : 0;
                const end = Math.min(current * perPage, total);

                $('#cugPaginationInfo').text(`Showing ${start} to ${end} of ${total} results`);

                const pagination = $('#cugPagination');
                if (!pagination.length) return;
                pagination.empty();
                if (last <= 1) return;

                const addButton = (label, page, disabled = false, active = false) => {
                    const li = $('<li>', { class: `page-item${disabled ? ' disabled' : ''}${active ? ' active' : ''}` });
                    const btn = $('<button>', { type: 'button', class: 'page-link', html: label });
                    if (!disabled) btn.on('click', () => this.load(page));
                    li.append(btn);
                    pagination.append(li);
                };

                addButton('&laquo;', 1, current === 1);
                addButton('&lsaquo;', current - 1, current === 1);

                let startPage = Math.max(1, current - 2);
                let endPage = Math.min(last, current + 2);
                if (current <= 3) endPage = Math.min(last, 5);
                if (current >= last - 2) startPage = Math.max(1, last - 4);

                for (let p = startPage; p <= endPage; p++) addButton(String(p), p, false, p === current);

                addButton('&rsaquo;', current + 1, current === last);
                addButton('&raquo;', last, current === last);
            }

            /* =====================================================
                NUMBER
                ===================================================== */

            renderNumber(number, row) {
                const safeNumber = CugHelper.escapeHtml(CugHelper.value(number));

                const code = CugHelper.escapeHtml(CugHelper.value(row.cug_code));

                return `
                        <div class="cug-number-cell">

                            <div class="cug-number-icon">

                                <i class="ti ti-device-mobile"></i>

                            </div>

                            <div>

                                <span class="cug-number-value">

                                    ${safeNumber}

                                </span>

                                ${
                                code !== '—'
                                    ? `
                                            <span class="cug-number-id">
                                                ${code}
                                            </span>
                                        `
                                    : ''
                                }

                            </div>

                        </div>
                    `;
            }

            /* =====================================================
                PROVIDER
                ===================================================== */

            renderProvider(provider) {
                const value = CugHelper.value(provider);

                if (value === '—') {
                return `
                            <span class="text-muted">
                                —
                            </span>
                        `;
                }

                return `
                        <span class="cug-badge cug-badge-primary">
                            ${CugHelper.escapeHtml(value)}
                        </span>
                    `;
            }

            /* =====================================================
                STAFF
                ===================================================== */

            renderStaff(staffName, row) {
                if (!row.staff_id) {
                return `
                            <div class="cug-unassigned">

                                <i class="ti ti-user-off me-1"></i>

                                Unassigned

                            </div>
                        `;
                }

                const name = CugHelper.value(staffName, 'Unknown Staff');
                const assignStaff = row.staff ?? '';

                const staffId = CugHelper.value(row.staff_code ?? row.staff_id);

                return `
                        <div class="cug-staff-cell">

                            <div class="cug-staff-avatar avatar avatar-offline border border-1 border-success">
                                ${assignStaff.staff_image_url ? 
                                    `<img src="${assignStaff.staff_image_url}" 
                                                            alt="user-avatar"  
                                                            class="rounded-circle "
                                                            style="width:40px; height:40px; object-fit:fill;"/>` : ` ${CugHelper.escapeHtml(CugHelper.initials(name))}`}

                               

                            </div>

                            <div>

                                <span class="cug-staff-name">

                                    ${CugHelper.escapeHtml(name)}

                                </span>

                                <span class="cug-staff-id">

                                    ${CugHelper.escapeHtml(staffId)}

                                </span>

                            </div>

                        </div>
                    `;
            }

            /* =====================================================
                ASSIGNMENT
                ===================================================== */

            renderAssignment(date, row) {
                if (!row.staff_id) {
                return `
                            <span class="cug-unassigned">
                                Not assigned
                            </span>
                        `;
                }

                const formattedDate = date ? CugHelper.formatDate(date) : '—';

                const duration = row.assignment_duration ? CugHelper.escapeHtml(row.assignment_duration) : '';

                return `
                        <div>

                            <span class="cug-assignment-date">

                                ${CugHelper.escapeHtml(formattedDate)}

                            </span>

                            ${
                            duration
                                ? `
                                        <span class="cug-assignment-duration">
                                            ${duration}
                                        </span>
                                    `
                                : ''
                            }

                        </div>
                    `;
            }

            /* =====================================================
                CALLS
                ===================================================== */

            renderCalls(count, row) {
                const total = this.toNumber(count);

                return `
                        <span
                        
                            class="cug-call-count btn-reset-cug-call cursor-pointer badge rounded bg-label-primary"
                            data-cug-id="${this.escapeAttribute(row.sno)}"
                            title="View call history">

                            <i class="ti ti-phone-call"></i>

                            <span>
                                ${CugHelper.number(total)}
                            </span>

                        </span>
                    `;
            }

            /* =====================================================
                STATUS
                ===================================================== */

            renderStatus(status, row) {
                const normalized = String(status ?? row.status ?? '');

                let label = 'Unknown';

                let className = 'cug-status-inactive';

                switch (normalized) {
                case '0':
                    label = 'Available';

                    className = 'cug-status-available';

                    break;

                case '1':
                    label = 'Assigned';

                    className = 'cug-status-assigned';

                    break;

                case '2':
                    label = 'Reserved';

                    className = 'cug-status-reserved';

                    break;

                case '3':
                    label = 'Inactive';

                    className = 'cug-status-inactive';

                    break;

                default:
                    if (row.status_label) {
                    label = row.status_label;
                    }

                    break;
                }

                return `
                        <span class="cug-status-badge ${className}">

                            <span class="cug-status-dot"></span>

                            ${CugHelper.escapeHtml(label)}

                        </span>
                    `;
            }

            /* =====================================================
                CHECKBOX
                ===================================================== */

            renderCheckbox(row) {
                const id = row.sno ?? row.id;

                const checked = this.selectedRows.has(String(id));

                return `
                        <input
                            type="checkbox"
                            class="form-check-input cug-row-checkbox"
                            value="${this.escapeAttribute(id)}"
                            ${checked ? 'checked' : ''}
                            aria-label="Select CUG number">
                    `;
            }

            /* =====================================================
                ACTIONS
                ===================================================== */

            renderActions(row) {
                const id = row.sno ?? row.id;

                const status = String(row.status ?? '');

                const assigned = Boolean(row.staff_id);

                const safeId = this.escapeAttribute(id);

                return `
                        <div class="dropdown">

                            <button
                                type="button"
                                class="cug-row-action "
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                                aria-label="CUG actions">

                                <i class="ti ti-dots-vertical"></i>

                            </button>

                            <ul class="dropdown-menu dropdown-menu-end">

                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-view fs-7"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-eye me-2"></i>

                                        View

                                    </button>

                                </li>

                                ${
                                !assigned && status === '0'
                                    ? `
                                            <li>
                                                <button
                                                    type="button"
                                                    class="dropdown-item cug-action-assign fs-7"
                                                    data-cug-id="${safeId}">

                                                    <i class="ti ti-user-plus me-2"></i>

                                                    Assign Staff

                                                </button>
                                            </li>
                                        `
                                    : ''
                                }

                                ${
                                assigned && status === '1'
                                    ? `
                                            <li>
                                                <button
                                                    type="button"
                                                    class="dropdown-item cug-action-change fs-7"
                                                    data-cug-id="${safeId}">

                                                    <i class="mdi mdi-account-convert me-2 text-dark"></i>
                                                    Change Staff

                                                </button>
                                            </li>

                                            <li>

                                                <button
                                                    type="button"
                                                    class="dropdown-item cug-action-release fs-7"
                                                    data-cug-id="${safeId}">

                                                    <i class="ti ti-user-minus me-2"></i>

                                                    Release CUG

                                                </button>

                                            </li>
                                        `
                                    : ''
                                }

                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-call-history fs-7"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-phone-call me-2"></i>

                                        Call History

                                    </button>

                                </li>

                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-assignment-history fs-7"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-history me-2"></i>

                                        Assignment History

                                    </button>

                                </li>

                                <li>

                                    <hr class="dropdown-divider">

                                </li>

                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item cug-action-edit fs-7"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-edit me-2"></i>

                                        Edit Number

                                    </button>

                                </li>

                                ${
                                status !== '3'
                                    ? `
                                        @if($delete_check == 1)
                                            <li>

                                                <button
                                                    type="button"
                                                    class="dropdown-item text-danger cug-action-deactivate fs-7"
                                                    data-cug-id="${safeId}">

                                                    <i class="ti ti-device-mobile-off me-2"></i>

                                                    Deactivate

                                                </button>

                                            </li>
                                            @endif
                                        `
                                    : ''
                                }
                                @if($delete_check == 1)
                                <li>

                                    <button
                                        type="button"
                                        class="dropdown-item text-danger cug-action-delete fs-7"
                                        data-cug-id="${safeId}">

                                        <i class="ti ti-trash me-2"></i>

                                        Delete

                                    </button>

                                </li>
                                @endif

                            </ul>

                        </div>
                    `;
            }

            /* =====================================================
                EVENTS
                ===================================================== */

            registerEvents() {
                const self = this;

                $(document).on('change', '.cug-row-checkbox', function () {
                    const id = String($(this).val());
                    if ($(this).is(':checked')) self.selectedRows.add(id);
                    else self.selectedRows.delete(id);
                    self.updateSelectionUI();
                });

                $(document).on('change', '#cugSelectAll', function () {
                    self.selectCurrentPage($(this).is(':checked'));
                });

                $(document).on('change', '#cugPerPage', function () {
                    self.load(1);
                });

                [
                    ['.cug-action-view', 'view'],
                    ['.cug-action-assign', 'assign'],
                    ['.cug-action-change', 'change'],
                    ['.cug-action-release', 'release'],
                    ['.cug-action-call-history, .btn-reset-cug-call', 'call-history'],
                    ['.cug-action-assignment-history', 'assignment-history'],
                    ['.cug-action-edit', 'edit'],
                    ['.cug-action-deactivate', 'deactivate'],
                    ['.cug-action-delete', 'delete']
                ].forEach(([selector, action]) => {
                    $(document).on('click', selector, function () {
                        self.emitAction(action, $(this).data('cug-id'));
                    });
                });

                $(document).on('click', '#btnBulkExportCug', function () {
                    self.emitAction('bulk-export', self.getSelectedIds());
                });

                $(document).on('click', '#btnBulkDeactivateCug', function () {
                    self.emitAction('bulk-deactivate', self.getSelectedIds());
                });
            }

            emitAction(action, id) {
                $(document).trigger(`cug:${action}`, [id]);
            }

            selectCurrentPage(checked) {
                this.currentRows.forEach(row => {
                    const id = String(row.sno ?? row.id);
                    if (checked) this.selectedRows.add(id);
                    else this.selectedRows.delete(id);
                });
                this.tbody.find('.cug-row-checkbox').prop('checked', checked);
                this.updateSelectionUI();
            }

            updateSelectionUI() {
                const count = this.selectedRows.size;
                $('#cugSelectedNumber').text(count);
                $('#cugSelectedCount').toggleClass('d-none', count === 0);
                $('#cugBulkActions').toggleClass('d-none', count === 0);
                this.updateSelectAllState();
            }

            updateSelectAllState() {
                const checkbox = $('#cugSelectAll');
                if (!checkbox.length) return;
                const total = this.currentRows.length;
                const selected = this.currentRows.filter(row => this.selectedRows.has(String(row.sno ?? row.id))).length;
                checkbox.prop('checked', total > 0 && selected === total);
                checkbox.prop('indeterminate', selected > 0 && selected < total);
            }

            getSelectedIds() {
                return Array.from(this.selectedRows);
            }

            clearSelection() {
                this.selectedRows.clear();
                this.tbody.find('.cug-row-checkbox').prop('checked', false);
                this.updateSelectionUI();
            }

            reload(resetPaging = false) {
                this.load(resetPaging ? 1 : this.currentPage);
            }

            /* =====================================================
                ESCAPE ATTRIBUTE
                ===================================================== */

            escapeAttribute(value) {
                return CugHelper.escapeHtml(value);
            }

            /* =====================================================
                NUMBER
                ===================================================== */

            toNumber(value) {
                const number = Number(value);

                return Number.isFinite(number) ? number : 0;
            }
        }

        /* =========================================================
        GLOBAL INSTANCE
        ========================================================= */

        $(function () {
        window.cugDataTable = new CugDataTable();

        cugDataTable.init();
        });
    })(jQuery);
</script>
@endsection