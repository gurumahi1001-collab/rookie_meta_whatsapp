{{-- CUG Management Add / Edit CUG Number Modal  --}}
<div class="modal fade"  id="cugNumberModal" tabindex="-1" aria-labelledby="cugNumberModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg ">
       <div class="modal-content cug-modal-content">
            {{-- HEADER --}}
            <div class="modal-header cug-modal-header">
                <div class="cug-modal-heading">
                    <div class="cug-modal-icon">
                        <i class="ti ti-device-mobile" id="cugNumberModalIcon"></i>
                    </div>
                    <div>
                        <h5 class="modal-title" id="cugNumberModalLabel">
                            Add CUG Number
                        </h5>
                        <span class="cug-modal-subtitle"  id="cugNumberModalSubtitle">
                            Add a new CUG number to the managed number pool.
                        </span>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- FORM  --}}
            <form  id="cugNumberForm" autocomplete="off">
                @csrf
                <input type="hidden"  name="sno" id="cugNumberId" value="">
                <input type="hidden" name="_method" id="cugNumberMethod" value="POST">
                <div class="modal-body cug-modal-body">
                    {{--ALERT --}}
                    <div class="alert alert-danger d-none cug-modal-alert" id="cugNumberFormAlert" role="alert">
                        <div class="d-flex align-items-start gap-2">
                            <i class="ti ti-alert-circle mt-1"></i>
                            <div>
                                <strong>
                                    Unable to save CUG number.
                                </strong>
                                <div
                                    class="mt-1"
                                    id="cugNumberFormAlertMessage">
                                </div>
                            </div>
                        </div>
                    </div>
                    {{--  BASIC INFORMATION --}}
                    <div class="cug-form-section">
                        <div class="cug-form-section-header">
                            <div>
                                <h6>
                                    Number Information
                                </h6>
                                <span>
                                    Enter the CUG number and provider details.
                                </span>
                            </div>
                        </div>
                        <div class="row g-3">
                            {{-- CUG Number --}}
                            <div class="col-md-7">
                                <label for="cugNumber" class="form-label">
                                    CUG Number<span class="required">*</span>
                                </label>
                                <div class="cug-input-group">
                                    <span class="cug-input-prefix">
                                        <i class="ti ti-phone"></i>
                                    </span>
                                    <input type="text" class="form-control" id="cugNumber" name="cug_number" placeholder="Enter CUG number"  maxlength="20" inputmode="numeric" autocomplete="off" required>
                                </div>
                                <div class="form-text" id="cugNumberHelp">
                                    Enter the complete CUG mobile number.
                                </div>
                            </div>
                            {{-- Provider --}}
                            <div class="col-md-5">
                                <label for="cugProvider" class="form-label">
                                    Provider<span class="required">*</span>
                                </label>
                                <select class="form-select select3" id="cugProvider" name="provider" required>
                                    <option value="">Select Provider</option>
                                    <option value="Airtel">Airtel</option>
                                    <option value="Jio">Jio</option>
                                    <option value="Vi">Vi</option>
                                    <option value="BSNL"> BSNL</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            {{-- Status --}}
                            <div class="col-md-6">
                                <label  for="cugStatus" class="form-label">
                                    Status <span class="required">*</span>
                                </label>
                                <select class="form-select select3" id="cugStatus"  name="status" required>
                                    <option value="0">Available</option>
                                    <option value="1">Assigned</option>
                                                                        <option value="3">Inactive</option>
                                </select>
                                <div class="form-text">
                                    New numbers normally start as Available.
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- NOTES --}}
                    <div class="cug-form-section mb-0">
                        <div class="cug-form-section-header">
                            <div>
                                <h6>
                                    Notes
                                </h6>
                                <span>
                                    Optional internal information.
                                </span>
                            </div>
                        </div>
                        <div>
                            <label for="cugRemarks" class="form-label">
                                Remarks
                            </label>
                            <textarea class="form-control" id="cugRemarks" name="remarks" rows="3" maxlength="500" placeholder="Add any internal remarks..."></textarea>
                            <div class="d-flex justify-content-end mt-1">
                                <small class="text-muted" id="cugRemarksCounter">
                                    0 / 500
                                </small>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 my-3">
                        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary" id="btnSaveCugNumber">
                            <span class="cug-btn-text">
                                <i class="ti ti-device-mobile-plus me-1" id="cugSaveButtonIcon"></i>
                                <span id="cugSaveButtonText">Add CUG Number</span>
                            </span>
                        </button>
                    </div>
                </div>
                {{-- FOOTER --}}
                
            </form>
        </div>
    </div>
</div>

{{-- Assign CUG Staff Modal --}}
<div class="modal fade"  id="cugAssignModal" tabindex="-1" aria-labelledby="cugAssignModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content cug-modal-content">
            {{--HEADER --}}
            <div class="modal-header cug-modal-header">
                <div class="cug-modal-heading">
                    <div class="cug-modal-icon cug-modal-icon-success">
                        <i class="ti ti-user-plus"></i>
                    </div>
                    <div>
                        <h5 class="modal-title" id="cugAssignModalLabel">
                            Assign CUG Number
                        </h5>
                        <span class="cug-modal-subtitle" id="cugAssignModalSubtitle">
                            Assign an available CUG number to a staff member.
                        </span>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- FORM --}}
            <form id="cugAssignForm" autocomplete="off">
                @csrf
                <input type="hidden" name="cug_id" id="cugAssignNumberId" value="">
                <div class="modal-body cug-modal-body">
                    {{--  ALERT --}}
                    <div class="alert alert-danger d-none cug-modal-alert" id="cugAssignFormAlert" role="alert">
                        <div class="d-flex align-items-start gap-2">
                            <i class="ti ti-alert-circle mt-1"></i>
                            <div>
                                <strong>
                                    Unable to assign CUG number.
                                </strong>
                                <div class="mt-1" id="cugAssignFormAlertMessage"></div>
                            </div>
                        </div>
                    </div>
                    {{-- CUG NUMBER SUMMARY --}}
                    <div class="cug-assignment-summary">
                        <div class="cug-assignment-summary-icon">
                            <i class="ti ti-device-mobile"></i>
                        </div>
                        <div class="cug-assignment-summary-content">
                            <span class="cug-assignment-summary-label">
                                CUG Number
                            </span>
                            <strong id="cugAssignNumber" class="cug-assignment-number">
                                —
                            </strong>
                            <div id="cugAssignProvider" class="cug-assignment-provider">
                                —
                            </div>
                        </div>
                        <div id="cugAssignCurrentStatus" class="cug-status-badge cug-status-available">
                            <span class="cug-status-dot"></span>
                            Available
                        </div>
                    </div>
                    {{-- STAFF --}}
                    <div class="cug-form-section">
                        <div class="cug-form-section-header">
                            <div>
                                <h6>
                                    Staff Assignment
                                </h6>
                                <span>
                                    Select the staff member who will use this CUG number.
                                </span>
                            </div>
                        </div>
                        <div class="row g-3">
                            {{-- Company --}}
                            <div class="col-md-4 cug-org-field" id="cugAssignCompanyWrap">
                                <label for="cugAssignCompany" class="form-label">Company <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugAssignCompany" name="company_id" required>
                                    <option value="">Select Company</option>
                                    <option value="0">Elysium Groups</option>
                                </select>
                            </div>
                            {{-- Entity --}}
                            <div class="col-md-4 cug-org-field" id="cugAssignEntityWrap">
                                <label for="cugAssignEntity" class="form-label">Entity <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugAssignEntity" name="entity_id" disabled required>
                                    <option value="">Select Entity</option>
                                    <option value="0" class="d-none">Not Applicable</option>
                                </select>
                            </div>
                            {{-- Branch --}}
                            <div class="col-md-4 cug-org-field" id="cugAssignBranchWrap">
                                <label for="cugAssignBranch" class="form-label">Branch <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugAssignBranch" name="branch_id" disabled required>
                                    <option value="">Select Branch</option>
                                    <option value="0" class="d-none">Not Applicable</option>
                                </select>
                            </div>
                            {{-- Staff --}}
                            <div class="col-12">
                                <label for="cugAssignStaff" class="form-label">
                                    Staff
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <select class="form-select select3"  id="cugAssignStaff" name="staff_id" required>
                                    <option value="">Search Staff</option>
                                </select>
                                <div class="form-text">
                                    Only eligible active staff should be selectable.
                                </div>
                            </div>
                            {{-- Assignment Date --}}
                            <div class="col-md-6">
                                <label  for="cugAssignDate" class="form-label">
                                    Assignment Date
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <div class="cug-input-group">
                                    <span class="cug-input-prefix">
                                        <i class="ti ti-calendar-event"></i>
                                    </span>
                                    <input  type="text" class="form-control cug-date-input" id="cugAssignDate" name="assignment_date"  placeholder="Select date" required>
                                </div>
                                <div class="form-text">
                                    Defaults to today.
                                </div>
                            </div>
                            {{-- Assignment Type --}}
                            <div class="col-md-6">
                                <label for="cugAssignmentType" class="form-label">
                                    Assignment Type
                                </label>
                                <select class="form-select select3" id="cugAssignmentType" name="assignment_type">
                                    <option value="NEW"> New Assignment</option>
                                    <option value="REASSIGN">Reassignment</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    {{-- STAFF PREVIEW --}}
                    <div class="cug-staff-preview d-none" id="cugAssignStaffPreview">
                        <div class="cug-staff-preview-avatar">
                            <span id="cugAssignStaffInitials">
                                ?
                            </span>
                        </div>
                        <div class="cug-staff-preview-content">
                            <strong id="cugAssignStaffName">
                                —
                            </strong>
                            <span id="cugAssignStaffId">
                                —
                            </span>
                            <div class="cug-staff-preview-meta">
                                <span id="cugAssignStaffDepartment">
                                    —
                                </span>
                                <span class="cug-preview-divider">
                                    •
                                </span>
                                <span id="cugAssignStaffDesignation">
                                    —
                                </span>
                            </div>
                        </div>
                        <span class="cug-badge cug-badge-success">
                            Active
                        </span>
                    </div>
                    {{--  WARNING --}}
                    <div class="cug-assignment-warning d-none" id="cugAssignStaffWarning">
                        <div class="cug-assignment-warning-icon">
                            <i class="ti ti-alert-triangle"></i>
                        </div>
                        <div>
                            <strong>
                                Staff already has a CUG number
                            </strong>
                            <p id="cugAssignStaffWarningText">
                                This staff member is already assigned
                                to another CUG number.
                            </p>
                            <div class="cug-existing-cug">
                                <span>
                                    Existing CUG:
                                </span>
                                <strong id="cugAssignExistingNumber">
                                    —
                                </strong>
                            </div>
                        </div>
                    </div>
                    {{-- REMARKS --}}
                    <div class="cug-form-section mb-0">
                        <div class="cug-form-section-header">
                            <div>
                                <h6>
                                    Assignment Notes
                                </h6>
                                <span>
                                    Optional information for the assignment history.
                                </span>
                            </div>
                        </div>
                        <label for="cugAssignRemarks" class="form-label">
                            Remarks
                        </label>
                        <textarea class="form-control" id="cugAssignRemarks" name="remarks" rows="3"  maxlength="500" placeholder="Example: New employee CUG assignment...">
                        </textarea>
                        <div class="d-flex justify-content-end mt-1">
                            <small class="text-muted"
                                id="cugAssignRemarksCounter">
                                0 / 500
                            </small>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 my-3">
                        <button
                            type="button"
                            class="btn btn-label-secondary"
                            data-bs-dismiss="modal">

                            Cancel

                        </button>
                        <button
                            type="submit"
                            class="btn btn-primary"
                            id="btnAssignCug">
                            <span class="cug-btn-text">
                                <i class="ti ti-user-plus me-1"></i>
                                Assign CUG
                            </span>
                        </button>
                    </div>
                </div>


                {{-- =================================================
                    FOOTER
                ================================================= --}}

                

            </form>
        </div>
    </div>
</div>

{{-- Change / Transfer CUG Staff Modal --}}
<div class="modal fade" id="cugChangeStaffModal" tabindex="-1" aria-labelledby="cugChangeStaffModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content cug-modal-content">
            {{-- HEADER --}}
            <div class="modal-header cug-modal-header">
                <div class="cug-modal-heading">
                    <div class="cug-modal-icon cug-modal-icon-transfer">
                        <i class="ti ti-user-shared"></i>
                    </div>
                    <div>
                        <h5 class="modal-title" id="cugChangeStaffModalLabel">
                            Change CUG Staff
                        </h5>
                        <span class="cug-modal-subtitle">
                            Transfer this CUG number from the current staff member to another staff member.
                        </span>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- FORM --}}
            <form id="cugChangeStaffForm" autocomplete="off">
                @csrf
                <input type="hidden" name="cug_id" id="cugChangeCugId" value="">
                <div class="modal-body cug-modal-body">
                    {{-- ERROR --}}
                    <div class="alert alert-danger d-none cug-modal-alert" id="cugChangeStaffFormAlert" role="alert">
                        <div class="d-flex align-items-start gap-2">
                            <i class="ti ti-alert-circle mt-1"></i>
                            <div>
                                <strong>
                                    Unable to change CUG staff.
                                </strong>
                                <div class="mt-1" id="cugChangeStaffFormAlertMessage"></div>
                            </div>
                        </div>
                    </div>
                    {{-- CUG SUMMARY --}}
                    <div class="cug-assignment-summary">
                        <div class="cug-assignment-summary-icon">
                            <i class="ti ti-device-mobile"></i>
                        </div>
                        <div class="cug-assignment-summary-content">
                            <span class="cug-assignment-summary-label">
                                CUG Number
                            </span>
                            <strong id="cugChangeCugNumber" class="cug-assignment-number">
                                —
                            </strong>
                            <div id="cugChangeCugProvider" class="cug-assignment-provider">
                                —
                            </div>
                        </div>
                        <span class="cug-status-badge cug-status-assigned">
                            <span class="cug-status-dot"></span>
                            Assigned
                        </span>
                    </div>
                    {{-- CURRENT ASSIGNMENT --}}
                    <div class="cug-transfer-section">
                        <div class="cug-transfer-section-header">
                            <div class="cug-transfer-step-number">
                                1
                            </div>
                            <div>
                                <h6>
                                    Current Staff
                                </h6>
                                <span>
                                    Existing assignment that will be closed.
                                </span>
                            </div>
                        </div>
                        <div class="cug-current-staff-card" id="cugCurrentStaffCard">
                            <div class="cug-current-staff-avatar">
                                <span id="cugCurrentStaffInitials">
                                    ?
                                </span>
                            </div>
                            <div class="cug-current-staff-content">
                                <strong id="cugCurrentStaffName">
                                    —
                                </strong>
                                <span id="cugCurrentStaffId">
                                    —
                                </span>
                                <div class="cug-current-staff-meta">
                                    <span id="cugCurrentStaffDepartment">
                                        —
                                    </span>
                                    <span class="cug-preview-divider">
                                        •
                                    </span>
                                    <span id="cugCurrentStaffDesignation">
                                        —
                                    </span>
                                </div>
                            </div>
                            <span class="cug-badge cug-badge-warning">
                                Current Owner
                            </span>
                        </div>
                    </div>

                    {{-- TRANSFER ARROW --}}
                    <div class="cug-transfer-arrow">
                        <div class="cug-transfer-line"></div>
                        <div class="cug-transfer-arrow-icon">
                            <i class="ti ti-arrow-down"></i>
                        </div>
                        <div class="cug-transfer-line"></div>
                    </div>

                    {{-- NEW STAFF --}}
                    <div class="cug-transfer-section">
                        <div class="cug-transfer-section-header">
                            <div class="cug-transfer-step-number cug-step-success">
                                2
                            </div>
                            <div>
                                <h6>
                                    Replacement Staff
                                </h6>
                                <span>
                                    Select the staff member who will receive this CUG number.
                                </span>
                            </div>
                        </div>
                        <div class="row g-3">
                            {{-- Company --}}
                            <div class="col-md-4 cug-org-field" id="cugChangeCompanyWrap">
                                <label for="cugChangeCompany" class="form-label">Company <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugChangeCompany" name="company_id" required>
                                    <option value="">Select Company</option>
                                    <option value="0">Elysium Groups</option>
                                </select>
                            </div>
                            {{-- Entity --}}
                            <div class="col-md-4 cug-org-field" id="cugChangeEntityWrap">
                                <label for="cugChangeEntity" class="form-label">Entity <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugChangeEntity" name="entity_id" disabled required>
                                    <option value="">Select Entity</option>
                                    <option value="0" class="d-none">Not Applicable</option>
                                </select>
                            </div>
                            {{-- Branch --}}
                            <div class="col-md-4 cug-org-field" id="cugChangeBranchWrap">
                                <label for="cugChangeBranch" class="form-label">Branch <span class="required">*</span></label>
                                <select class="form-select select3 cug-org-select" id="cugChangeBranch" name="branch_id" disabled required>
                                    <option value="">Select Branch</option>
                                    <option value="0" class="d-none">Not Applicable</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label for="cugReplacementStaff" class="form-label">
                                    New Staff
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <select class="form-select select3" id="cugReplacementStaff" name="staff_id" required>
                                    <option value="">Search replacement staff</option>
                                </select>
                                <div class="form-text">
                                    The replacement staff member must be active and eligible for CUG assignment.
                                </div>
                            </div>
                        </div>

                        {{-- New Staff Preview --}}
                        <div class="cug-staff-preview d-none" id="cugReplacementStaffPreview">
                            <div class="cug-staff-preview-avatar">
                                <span id="cugReplacementStaffInitials">
                                    ?
                                </span>
                            </div>
                            <div class="cug-staff-preview-content">
                                <strong id="cugReplacementStaffName">
                                    —
                                </strong>
                                <span id="cugReplacementStaffId">
                                    —
                                </span>
                                <div class="cug-staff-preview-meta">
                                    <span id="cugReplacementStaffDepartment">
                                        —
                                    </span>
                                    <span class="cug-preview-divider">
                                        •
                                    </span>
                                    <span  id="cugReplacementStaffDesignation">
                                        —
                                    </span>
                                </div>
                            </div>
                            <span class="cug-badge cug-badge-success">
                                New Owner
                            </span>
                        </div>
                        {{-- Existing CUG warning --}}
                        <div class="cug-assignment-warning d-none" id="cugReplacementStaffWarning">
                            <div class="cug-assignment-warning-icon">
                                <i class="ti ti-alert-triangle"></i>
                            </div>
                            <div>
                                <strong>
                                    Replacement staff already has a CUG
                                </strong>
                                <p id="cugReplacementStaffWarningText">
                                    This staff member already has an assigned CUG number.
                                </p>
                                <div class="cug-existing-cug">
                                    <span>
                                        Existing CUG:
                                    </span>
                                    <strong id="cugReplacementExistingNumber">
                                        —
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- TRANSFER DETAILS --}}
                    <div class="cug-form-section">
                        <div class="cug-form-section-header">
                            <div>
                                <h6>
                                    Transfer Details
                                </h6>
                                <span>
                                    Record why and when the CUG ownership changed.
                                </span>
                            </div>
                        </div>
                        <div class="row g-3">
                            {{-- Effective Date --}}
                            <div class="col-md-6">
                                <label for="cugChangeEffectiveDate" class="form-label">
                                    Effective Date
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <div class="cug-input-group">
                                    <span class="cug-input-prefix">
                                        <i class="ti ti-calendar-event"></i>
                                    </span>
                                    <input type="text"
                                        class="form-control cug-date-input"
                                        id="cugChangeEffectiveDate"
                                        name="effective_date"
                                        placeholder="Select date"
                                        required>
                                </div>
                            </div>

                            {{-- Transfer Reason --}}
                            <div class="col-md-6">
                                <label for="cugTransferReason" class="form-label">
                                    Transfer Reason
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <select class="form-select select3" id="cugTransferReason" name="transfer_reason" required>
                                    <option value="">Select reason</option>
                                    <option value="STAFF_EXIT">Staff Exit</option>
                                    <option value="STAFF_TRANSFER">Staff Transfer</option>
                                    <option value="ROLE_CHANGE">Role Change</option>
                                    <option value="BUSINESS_REQUIREMENT">Business Requirement</option>
                                    <option value="TEMPORARY_REPLACEMENT">Temporary Replacement</option>
                                    <option value="OTHER">Other</option>
                                </select>
                            </div>

                            {{-- Remarks --}}
                            <div class="col-12">
                                <label for="cugChangeRemarks" class="form-label">
                                    Remarks
                                    <span class="required">
                                        *
                                    </span>
                                </label>
                                <textarea class="form-control" id="cugChangeRemarks" name="remarks" rows="3" maxlength="500" placeholder="Explain the reason for the CUG staff change..." >
                                </textarea>
                                <div class="d-flex justify-content-end mt-1">
                                    <small class="text-muted" id="cugChangeRemarksCounter">
                                        0 / 500
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- HISTORY NOTICE --}}
                    <div class="cug-history-notice">
                        <div class="cug-history-notice-icon">
                            <i class="ti ti-history"></i>
                        </div>
                        <div>
                            <strong>
                                Assignment history will be preserved
                            </strong>
                            <p>
                                The current staff assignment will be closed,
                                and the new staff assignment will be recorded.
                                Previous CUG usage will remain available in history.
                            </p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 my-3">
                        <button type="button"
                            class="btn btn-label-secondary"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit"
                            class="btn btn-primary"
                            id="btnChangeCugStaff">
                            <span class="cug-btn-text">
                                <i class="ti ti-user-shared me-1"></i>
                                Transfer CUG
                            </span>
                        </button>
                    </div>
                </div>

                {{-- FOOTER --}}
                
            </form>
        </div>
    </div>
</div>


{{-- CUG History Modal --}}
<div class="modal fade" id="cugHistoryModal" tabindex="-1" aria-labelledby="cugHistoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content cug-history-modal">
            {{-- HEADER --}}
            <div class="modal-header cug-modal-header">
                <div class="cug-modal-heading">
                    <div class="cug-modal-icon">
                        <i class="ti ti-history"></i>
                    </div>
                    <div>
                        <h5 class="modal-title" id="cugHistoryModalLabel">
                            CUG History
                        </h5>
                        <span class="cug-modal-subtitle" id="cugHistoryModalSubtitle">
                            Assignment and call activity for this CUG number.
                        </span>
                    </div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            {{-- BODY --}}
            <div class="modal-body cug-history-modal-body">
                {{-- CUG SUMMARY --}}
                <div class="cug-history-summary">
                    <div class="cug-history-summary-left">
                        <div class="cug-history-number-icon">
                            <i class="ti ti-device-mobile"></i>
                        </div>
                        <div>
                            <span class="cug-history-summary-label">
                                CUG Number
                            </span>
                            <strong id="cugHistoryNumber" class="cug-history-number">
                                —
                            </strong>
                            <div id="cugHistoryProvider" class="cug-history-provider">
                                —
                            </div>
                        </div>
                    </div>
                    <div class="cug-history-summary-stats">
                        <div class="cug-history-summary-stat">
                            <span>
                                Current Staff
                            </span>
                            <strong id="cugHistoryCurrentStaff">
                                —
                            </strong>
                        </div>
                        <div class="cug-history-summary-stat">
                            <span>
                                Total Calls
                            </span>
                            <strong id="cugHistoryTotalCalls">
                                0
                            </strong>
                        </div>
                        <div class="cug-history-summary-stat">
                            <span>
                                Current Status
                            </span>
                            <strong id="cugHistoryStatus">
                                —
                            </strong>
                        </div>
                    </div>
                </div>
                {{--  TABS --}}
                <div class="cug-history-tabs-wrapper">
                    <ul class="nav nav-tabs cug-history-tabs" id="cugHistoryTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button type="button"
                                class="nav-link active"
                                id="cugAssignmentHistoryTab"
                                data-bs-toggle="tab"
                                data-bs-target="#cugAssignmentHistoryPane"
                                role="tab"
                                aria-controls="cugAssignmentHistoryPane"
                                aria-selected="true">
                                <i class="ti ti-users me-1"></i>
                                Assignment History
                                <span class="cug-history-tab-count" id="cugAssignmentHistoryCount">
                                    0
                                </span>
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button type="button"class="nav-link" id="cugCallHistoryTab"
                                data-bs-toggle="tab"
                                data-bs-target="#cugCallHistoryPane"
                                role="tab"
                                aria-controls="cugCallHistoryPane"
                                aria-selected="false">
                                <i class="ti ti-phone-call me-1"></i>
                                Call History
                                <span class="cug-history-tab-count" id="cugCallHistoryCount">
                                    0
                                </span>
                            </button>
                        </li>
                    </ul>
                </div>
                {{-- TAB CONTENT --}}
                <div class="tab-content cug-history-tab-content" id="cugHistoryTabContent">
                    {{-- ASSIGNMENT HISTORY --}}
                    <div class="tab-pane fade show active"
                        id="cugAssignmentHistoryPane"
                        role="tabpanel"
                        aria-labelledby="cugAssignmentHistoryTab">
                        <div class="cug-history-loading d-none" id="cugAssignmentHistoryLoading">
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                        </div>
                        <div class="cug-assignment-timeline" id="cugAssignmentTimeline">
                            {{-- AJAX populated --}}
                        </div>
                        <div class="cug-history-empty d-none" id="cugAssignmentHistoryEmpty">
                            <div class="cug-history-empty-icon">
                                <i class="ti ti-users-off"></i>
                            </div>
                            <strong>
                                No assignment history
                            </strong>
                            <span>
                                No staff assignment records were found for this CUG number.
                            </span>
                        </div>
                    </div>
                    {{--  CALL HISTORY --}}
                    <div class="tab-pane fade"
                        id="cugCallHistoryPane"
                        role="tabpanel"
                        aria-labelledby="cugCallHistoryTab">
                        <div class="cug-call-history-toolbar">
                            <div>
                                <span class="cug-call-history-title">
                                    Call Activity
                                </span>
                                <span class="cug-call-history-subtitle">
                                    Calls associated with this CUG number.
                                </span>
                            </div>
                            <div class="cug-call-history-filters">
                                <div class="cug-history-date-filter">
                                    <i class="ti ti-calendar"></i>
                                    <input type="text"
                                        class="form-control cug-date-input"
                                        id="cugCallHistoryFrom"
                                        placeholder="From">
                                </div>
                                <span class="cug-date-range-separator">
                                    —
                                </span>
                                <div class="cug-history-date-filter">
                                    <i class="ti ti-calendar"></i>
                                    <input
                                        type="text"
                                        class="form-control cug-date-input"
                                        id="cugCallHistoryTo"
                                        placeholder="To">
                                </div>
                                <button
                                    type="button"
                                    class="btn btn-sm btn-label-secondary"
                                    id="btnFilterCugCalls">
                                    <i class="ti ti-filter me-1"></i>
                                    Filter
                                </button>
                            </div>
                        </div>
                        <div class="cug-call-history-loading d-none" id="cugCallHistoryLoading">
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                            <div class="cug-history-loading-row"></div>
                        </div>
                        <div class="table-responsive cug-call-table-wrapper" id="cugCallHistoryTableWrapper">
                            <table class="table cug-call-history-table">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th> Date / Time</th>
                                        <th> Type</th>
                                        <th> Caller / Number</th>
                                        <th> Duration</th>
                                        <th> Staff</th>
                                        <th> Status</th>
                                    </tr>
                                </thead>
                                <tbody id="cugCallHistoryBody">
                                    {{-- AJAX populated --}}
                                </tbody>
                            </table>
                        </div>
                        <div class="cug-history-empty d-none" id="cugCallHistoryEmpty">
                            <div class="cug-history-empty-icon">
                                <i class="ti ti-phone-off"></i>
                            </div>
                            <strong>
                                No call history
                            </strong>
                            <span>
                                No call records were found for the selected period.
                            </span>
                        </div>
                        <div class="cug-call-pagination" id="cugCallHistoryPagination">
                            {{-- AJAX populated --}}
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end gap-3 my-3">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                </div>
            </div>
            {{-- FOOTER --}}
            
        </div>
    </div>
</div>


<style>

    /* CUG HISTORY MODAL */
    .modal .modal-body, .modal .modal-content, .modal .card{
        overflow:auto !important;
    }

    .cug-history-modal {
        overflow: hidden;
        border: 1px solid var(--border);
        border-radius: 16px;
        background: var(--card);
        box-shadow:
            0 20px 60px rgba(23, 32, 51, .16);
    }

    .cug-history-modal-body {
        max-height: calc(100vh - 170px);
        overflow-y: auto;
        padding: 20px;
    }


    /* =========================================================
    HISTORY SUMMARY
    ========================================================= */

    .cug-history-summary {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;

        margin-bottom: 20px;
        padding: 15px;

        border: 1px solid var(--border);
        border-radius: 12px;

        background: #fafbfc;
    }

    .cug-history-summary-left {
        min-width: 220px;

        display: flex;
        align-items: center;
        gap: 12px;
    }

    .cug-history-number-icon {
        width: 44px;
        height: 44px;
        min-width: 44px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 11px;

        background: var(--cug-primary-soft);
        color: var(--primary);

        font-size: 20px;
    }

    .cug-history-summary-label {
        display: block;

        margin-bottom: 2px;

        color: var(--muted);
        font-size: .63rem;
        font-weight: 600;
    }

    .cug-history-number {
        display: block;

        color: var(--text);
        font-size: .95rem;
        font-weight: 700;
        letter-spacing: .2px;
    }

    .cug-history-provider {
        margin-top: 2px;

        color: var(--muted);
        font-size: .66rem;
    }

    .cug-history-summary-stats {
        display: flex;
        align-items: stretch;
        gap: 1px;
    }

    .cug-history-summary-stat {
        min-width: 115px;

        padding: 0 14px;

        border-left: 1px solid var(--border);
    }

    .cug-history-summary-stat span {
        display: block;

        color: var(--muted);
        font-size: .62rem;
    }

    .cug-history-summary-stat strong {
        display: block;

        margin-top: 4px;

        color: var(--text);
        font-size: .76rem;
        font-weight: 700;
    }


    /* =========================================================
    TABS
    ========================================================= */

    .cug-history-tabs-wrapper {
        border-bottom: 1px solid var(--border);
    }

    .cug-history-tabs {
        gap: 4px;
        border-bottom: 0;
    }

    .cug-history-tabs .nav-link {
        display: inline-flex;
        align-items: center;
        gap: 2px;

        margin-bottom: -1px;
        padding: 10px 13px;

        border: 0;
        border-bottom: 2px solid transparent;

        border-radius: 7px 7px 0 0;

        background: transparent;

        color: var(--muted);

        font-size: .72rem;
        font-weight: 600;

        transition: var(--cug-transition);
    }

    .cug-history-tabs .nav-link:hover {
        color: var(--primary);
        background: var(--cug-primary-soft-2);
    }

    .cug-history-tabs .nav-link.active {
        border-bottom-color: var(--primary);

        background: var(--cug-primary-soft-2);

        color: var(--primary);
    }

    .cug-history-tab-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;

        min-width: 19px;
        height: 18px;

        margin-left: 4px;
        padding: 0 5px;

        border-radius: 10px;

        background: var(--border);

        color: var(--muted);

        font-size: .58rem;
        font-weight: 700;
    }

    .cug-history-tabs .nav-link.active
    .cug-history-tab-count {
        background: var(--primary);
        color: #fff;
    }


    /* =========================================================
    TAB CONTENT
    ========================================================= */

    .cug-history-tab-content {
        padding-top: 20px;
    }


    /* =========================================================
    ASSIGNMENT TIMELINE
    ========================================================= */

    .cug-assignment-timeline {
        position: relative;
        padding: 4px 4px 4px 8px;
    }

    .cug-assignment-history-item {
        position: relative;

        display: flex;
        gap: 13px;

        padding-bottom: 22px;
    }

    .cug-assignment-history-item:last-child {
        padding-bottom: 0;
    }

    .cug-assignment-history-item:not(:last-child)::before {
        content: "";

        position: absolute;

        left: 16px;
        top: 34px;
        bottom: 0;

        width: 1px;

        background: var(--border);
    }

    .cug-assignment-history-icon {
        position: relative;
        z-index: 2;

        width: 33px;
        height: 33px;
        min-width: 33px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border: 3px solid var(--card);
        border-radius: 50%;

        background: var(--cug-primary-soft);

        color: var(--primary);

        box-shadow:
            0 0 0 1px var(--border);

        font-size: 14px;
    }

    .cug-assignment-history-icon.assigned {
        background: var(--cug-success-soft);
        color: var(--success);
    }

    .cug-assignment-history-icon.released {
        background: var(--cug-warning-soft);
        color: var(--warning);
    }

    .cug-assignment-history-icon.transferred {
        background: var(--cug-primary-soft);
        color: var(--primary);
    }

    .cug-assignment-history-icon.current {
        background: var(--cug-success-soft);
        color: var(--success);
    }

    .cug-assignment-history-content {
        flex: 1;
        min-width: 0;
    }

    .cug-assignment-history-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 15px;
    }

    .cug-assignment-history-title {
        color: var(--text);
        font-size: .77rem;
        font-weight: 700;
    }

    .cug-assignment-history-date {
        white-space: nowrap;

        color: var(--muted);
        font-size: .64rem;
    }

    .cug-assignment-history-description {
        margin-top: 4px;

        color: var(--muted);
        font-size: .69rem;
        line-height: 1.5;
    }

    .cug-assignment-history-description strong {
        color: var(--text);
        font-weight: 600;
    }

    .cug-assignment-history-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;

        margin-top: 8px;
    }

    .cug-assignment-history-tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;

        padding: 4px 7px;

        border-radius: 6px;

        background: var(--bg);

        color: var(--muted);

        font-size: .61rem;
        font-weight: 600;
    }

    .cug-assignment-history-tag.reason {
        background: var(--cug-warning-soft);
        color: var(--warning);
    }


    /* =========================================================
    CALL HISTORY TOOLBAR
    ========================================================= */

    .cug-call-history-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;

        margin-bottom: 14px;
    }

    .cug-call-history-title {
        display: block;

        color: var(--text);
        font-size: .78rem;
        font-weight: 700;
    }

    .cug-call-history-subtitle {
        display: block;

        margin-top: 3px;

        color: var(--muted);
        font-size: .65rem;
    }

    .cug-call-history-filters {
        display: flex;
        align-items: center;
        gap: 7px;
    }

    .cug-history-date-filter {
        position: relative;
    }

    .cug-history-date-filter > i {
        position: absolute;

        top: 50%;
        left: 9px;

        z-index: 2;

        transform: translateY(-50%);

        color: var(--muted);

        font-size: 14px;

        pointer-events: none;
    }

    .cug-history-date-filter .form-control {
        width: 125px;

        height: 34px;

        padding-left: 29px;

        font-size: .66rem;
    }

    .cug-date-range-separator {
        color: var(--muted);
        font-size: .68rem;
    }


    /* =========================================================
    CALL TABLE
    ========================================================= */

    .cug-call-table-wrapper {
        border: 1px solid var(--border);
        border-radius: 10px;
    }

    .cug-call-history-table {
        min-width: 760px;
        margin-bottom: 0;
    }

    .cug-call-history-table thead th {
        padding: 10px 12px;

        border-bottom: 1px solid var(--border);

        /* background: #fafbfc;

        color: var(--muted); */

        font-size: .64rem;
        font-weight: 700;
        white-space: nowrap;
    }

    .cug-call-history-table tbody td {
        padding: 11px 12px;

        border-bottom: 1px solid var(--border);

        color: var(--text);

        font-size: .68rem;
        vertical-align: middle;
    }

    .cug-call-history-table tbody tr:last-child td {
        border-bottom: 0;
    }

    .cug-call-history-table tbody tr:hover {
        background: var(--cug-primary-soft-2);
    }

    .cug-call-datetime strong {
        display: block;

        color: var(--text);
        font-size: .68rem;
    }

    .cug-call-datetime span {
        display: block;

        margin-top: 2px;

        color: var(--muted);
        font-size: .60rem;
    }

    .cug-call-number {
        color: var(--text);
        font-weight: 600;
    }

    .cug-call-duration {
        color: var(--muted);
    }

    .cug-call-staff {
        color: var(--text);
        font-weight: 600;
    }


    /* =========================================================
    CALL TYPE
    ========================================================= */

    .cug-call-type {
        display: inline-flex;
        align-items: center;
        gap: 4px;

        padding: 4px 7px;

        border-radius: 6px;

        font-size: .61rem;
        font-weight: 700;
    }

    .cug-call-type.incoming {
        background: var(--cug-success-soft);
        color: var(--success);
    }

    .cug-call-type.outgoing {
        background: var(--cug-primary-soft);
        color: var(--primary);
    }

    .cug-call-type.missed {
        background: var(--cug-danger-soft);
        color: var(--danger);
    }


    /* =========================================================
    CALL STATUS
    ========================================================= */

    .cug-call-status {
        display: inline-flex;
        align-items: center;
        gap: 5px;

        font-size: .62rem;
        font-weight: 600;
    }

    .cug-call-status-dot {
        width: 6px;
        height: 6px;

        border-radius: 50%;

        background: currentColor;
    }


    /* =========================================================
    EMPTY
    ========================================================= */

    .cug-history-empty {
        min-height: 210px;

        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;

        gap: 5px;

        text-align: center;
    }

    .cug-history-empty-icon {
        width: 48px;
        height: 48px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        margin-bottom: 5px;

        border-radius: 12px;

        background: var(--cug-primary-soft);

        color: var(--primary);

        font-size: 21px;
    }

    .cug-history-empty strong {
        color: var(--text);
        font-size: .76rem;
    }

    .cug-history-empty span {
        max-width: 320px;

        color: var(--muted);
        font-size: .65rem;
        line-height: 1.45;
    }


    /* =========================================================
    LOADING
    ========================================================= */

    .cug-history-loading,
    .cug-call-history-loading {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .cug-history-loading-row {
        height: 58px;

        border-radius: 8px;

        background:
            linear-gradient(
                90deg,
                #f1f2f4 25%,
                #e7e9ec 37%,
                #f1f2f4 63%
            );

        background-size: 400% 100%;

        animation:
            cugHistorySkeleton 1.4s ease infinite;
    }

    @keyframes cugHistorySkeleton {

        0% {
            background-position: 100% 0;
        }

        100% {
            background-position: 0 0;
        }

    }


    /* =========================================================
    CALL PAGINATION
    ========================================================= */

    .cug-call-pagination {
        display: flex;
        justify-content: flex-end;

        margin-top: 12px;
    }

    .cug-call-pagination .pagination {
        margin-bottom: 0;
    }

    .cug-call-pagination .page-link {
        min-width: 30px;
        height: 30px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        padding: 0 7px;

        border-color: var(--border);

        color: var(--muted);

        font-size: .64rem;
    }

    .cug-call-pagination .page-item.active .page-link {
        border-color: var(--primary);
        background: var(--primary);
        color: #fff;
    }


    /* =========================================================
    MOBILE
    ========================================================= */

    @media (max-width: 767.98px) {

        .cug-history-modal-body {
            padding: 15px;
        }

        .cug-history-summary {
            align-items: flex-start;
            flex-direction: column;
        }

        .cug-history-summary-stats {
            width: 100%;
            overflow-x: auto;
        }

        .cug-history-summary-stat {
            flex: 1;
            min-width: 100px;
        }

        .cug-call-history-toolbar {
            align-items: flex-start;
            flex-direction: column;
        }

        .cug-call-history-filters {
            width: 100%;
            flex-wrap: wrap;
        }

        .cug-history-date-filter {
            flex: 1;
        }

        .cug-history-date-filter .form-control {
            width: 100%;
        }

        .cug-call-history-filters .btn {
            height: 34px;
        }

    }

    @media (max-width: 575.98px) {

        .cug-history-tabs .nav-link {
            padding: 9px 8px;
            font-size: .66rem;
        }

        .cug-history-tabs .nav-link i {
            display: none;
        }

    }
</style>

<style>
    /* CHANGE STAFF / TRANSFER MODAL */

    .cug-modal-icon-transfer {
        background: var(--cug-primary-soft);
        color: var(--primary);
    }


    /* =========================================================
    TRANSFER SECTION
    ========================================================= */

    .cug-transfer-section {
        margin-bottom: 4px;
    }

    .cug-transfer-section-header {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
    }

    .cug-transfer-section-header h6 {
        margin: 0;
        color: var(--text);
        font-size: .80rem;
        font-weight: 700;
    }

    .cug-transfer-section-header span {
        display: block;
        margin-top: 3px;
        color: var(--muted);
        font-size: .67rem;
    }

    .cug-transfer-step-number {
        width: 28px;
        height: 28px;
        min-width: 28px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 50%;

        background: var(--cug-warning-soft);
        color: var(--warning);

        font-size: .70rem;
        font-weight: 800;
    }

    .cug-transfer-step-number.cug-step-success {
        background: var(--cug-success-soft);
        color: var(--success);
    }


    /* =========================================================
    CURRENT STAFF CARD
    ========================================================= */

    .cug-current-staff-card {
        display: flex;
        align-items: center;
        gap: 11px;

        padding: 12px;

        border: 1px solid rgba(217, 119, 6, .18);
        border-radius: 10px;

        background: rgba(217, 119, 6, .045);
    }

    .cug-current-staff-avatar {
        width: 40px;
        height: 40px;
        min-width: 40px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 50%;

        background: var(--cug-warning-soft);
        color: var(--warning);

        font-size: .74rem;
        font-weight: 700;
    }

    .cug-current-staff-content {
        flex: 1;
        min-width: 0;
    }

    .cug-current-staff-content strong {
        display: block;

        overflow: hidden;

        color: var(--text);
        font-size: .77rem;
        font-weight: 700;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .cug-current-staff-content > span {
        display: block;
        margin-top: 2px;

        color: var(--muted);
        font-size: .64rem;
    }

    .cug-current-staff-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;

        margin-top: 4px;

        color: var(--muted);
        font-size: .62rem;
    }


    /* =========================================================
    TRANSFER ARROW
    ========================================================= */

    .cug-transfer-arrow {
        display: flex;
        align-items: center;
        gap: 9px;

        margin: 10px 0;
    }

    .cug-transfer-line {
        flex: 1;
        height: 1px;
        background: var(--border);
    }

    .cug-transfer-arrow-icon {
        width: 28px;
        height: 28px;
        min-width: 28px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border: 1px solid var(--border);
        border-radius: 50%;

        background: var(--card);
        color: var(--primary);

        font-size: 14px;
    }


    /* =========================================================
    HISTORY NOTICE
    ========================================================= */

    .cug-history-notice {
        display: flex;
        align-items: flex-start;
        gap: 11px;

        padding: 13px;

        border: 1px solid rgba(143, 29, 29, .12);
        border-radius: 10px;

        background: var(--cug-primary-soft-2);
    }

    .cug-history-notice-icon {
        width: 32px;
        height: 32px;
        min-width: 32px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 8px;

        background: var(--cug-primary-soft);
        color: var(--primary);

        font-size: 16px;
    }

    .cug-history-notice strong {
        display: block;

        color: var(--text);
        font-size: .73rem;
        font-weight: 700;
    }

    .cug-history-notice p {
        margin: 4px 0 0;

        color: var(--muted);
        font-size: .67rem;
        line-height: 1.5;
    }


    /* =========================================================
    MOBILE
    ========================================================= */

    @media (max-width: 575.98px) {

        .cug-current-staff-card {
            align-items: flex-start;
        }

        .cug-current-staff-card
        .cug-badge {
            display: none;
        }

    }
</style>

<style>

    /* ASSIGNMENT MODAL */

    .cug-modal-icon-success {
        background: var(--cug-success-soft);
        color: var(--success);
    }


    /*  CUG ASSIGNMENT SUMMARY */

    .cug-assignment-summary {
        display: flex;
        align-items: center;
        gap: 13px;

        margin-bottom: 22px;
        padding: 14px;

        border: 1px solid var(--border);
        border-radius: 11px;

        background: #fafbfc;
    }

    .cug-assignment-summary-icon {
        width: 42px;
        height: 42px;
        min-width: 42px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 10px;

        background: var(--cug-primary-soft);
        color: var(--primary);

        font-size: 19px;
    }

    .cug-assignment-summary-content {
        min-width: 0;
        flex: 1;
    }

    .cug-assignment-summary-label {
        display: block;
        margin-bottom: 2px;

        color: var(--muted);
        font-size: .63rem;
        font-weight: 600;
    }

    .cug-assignment-number {
        display: block;

        color: var(--text);
        font-size: .94rem;
        letter-spacing: .2px;
    }

    .cug-assignment-provider {
        margin-top: 2px;

        color: var(--muted);
        font-size: .66rem;
    }


    /* =========================================================
    STAFF PREVIEW
    ========================================================= */

    .cug-staff-preview {
        display: flex;
        align-items: center;
        gap: 11px;

        margin-top: 16px;
        margin-bottom: 22px;
        padding: 12px;

        border: 1px solid var(--border);
        border-radius: 10px;

        background: var(--card);
    }

    .cug-staff-preview-avatar {
        width: 40px;
        height: 40px;
        min-width: 40px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 50%;

        background: var(--cug-primary-soft);
        color: var(--primary);

        font-size: .74rem;
        font-weight: 700;
    }

    .cug-staff-preview-content {
        flex: 1;
        min-width: 0;
    }

    .cug-staff-preview-content strong {
        display: block;

        overflow: hidden;

        color: var(--text);
        font-size: .77rem;
        font-weight: 700;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .cug-staff-preview-content > span {
        display: block;
        margin-top: 2px;

        color: var(--muted);
        font-size: .64rem;
    }

    .cug-staff-preview-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;

        margin-top: 4px;

        color: var(--muted);
        font-size: .62rem;
    }

    .cug-preview-divider {
        color: #d1d5db;
    }


    /* =========================================================
    EXISTING CUG WARNING
    ========================================================= */

    .cug-assignment-warning {
        display: flex;
        align-items: flex-start;
        gap: 11px;

        margin-bottom: 22px;
        padding: 13px;

        border: 1px solid rgba(217, 119, 6, .18);
        border-radius: 10px;

        background: var(--cug-warning-soft);
    }

    .cug-assignment-warning-icon {
        width: 31px;
        height: 31px;
        min-width: 31px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 8px;

        background: rgba(217, 119, 6, .12);
        color: var(--warning);

        font-size: 16px;
    }

    .cug-assignment-warning strong {
        display: block;

        color: #92400e;
        font-size: .73rem;
        font-weight: 700;
    }

    .cug-assignment-warning p {
        margin: 3px 0 7px;

        color: #92400e;
        font-size: .67rem;
        line-height: 1.45;
    }

    .cug-existing-cug {
        display: inline-flex;
        align-items: center;
        gap: 6px;

        padding: 5px 8px;

        border-radius: 6px;

        background: rgba(255, 255, 255, .65);

        color: var(--muted);
        font-size: .64rem;
    }

    .cug-existing-cug strong {
        color: #92400e;
        font-size: .68rem;
    }


    /* =========================================================
    DATE INPUT
    ========================================================= */

    .cug-date-input {
        cursor: pointer;
    }


    /* =========================================================
    ASSIGN SELECT2
    ========================================================= */

    #cugAssignModal
    .select2-container--default
    .select2-selection--single {
        min-height: 42px;
        height: 42px;
    }

    #cugAssignModal
    .select2-container--default
    .select2-selection--single
    .select2-selection__rendered {
        line-height: 40px;
    }


    /* =========================================================
    MOBILE
    ========================================================= */

    @media (max-width: 575.98px) {

        .cug-assignment-summary {
            flex-wrap: wrap;
        }

        .cug-assignment-summary
        .cug-status-badge {
            margin-left: 55px;
        }

        .cug-staff-preview {
            align-items: flex-start;
        }

    }
</style>

<style>
    /* CUG MODAL */
    .cug-modal-content {
        /* overflow: hidden; */
        border: 1px solid var(--border);
        border-radius: 16px;
        background: var(--card);
        box-shadow: 0 20px 60px rgba(23, 32, 51, .16);
    }

    .cug-modal-header {
        padding: 18px 20px;
        border-bottom: 1px solid var(--border);
        background: var(--card);
    }

    .cug-modal-heading {
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .cug-modal-icon {
        width: 42px;
        height: 42px;
        min-width: 42px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border-radius: 11px;

        background: var(--cug-primary-soft);
        color: var(--primary);

        font-size: 20px;
    }

    .cug-modal-header .modal-title {
        margin: 0;
        color: var(--text);
        font-size: .95rem;
        font-weight: 700;
    }

    .cug-modal-subtitle {
        display: block;
        margin-top: 3px;
        color: var(--muted);
        font-size: .70rem;
        line-height: 1.4;
    }

    .cug-modal-body {
        max-height: calc(100vh - 190px);
        overflow-y: auto;
        padding: 20px;
    }

    .cug-modal-footer {
        padding: 14px 20px;
        border-top: 1px solid var(--border);
        background: #fafbfc;
    }


    /* =========================================================
    FORM SECTION
    ========================================================= */

    .cug-form-section {
        margin-bottom: 22px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--border);
    }

    .cug-form-section-header {
        margin-bottom: 15px;
    }

    .cug-form-section-header h6 {
        margin: 0;
        color: var(--text);
        font-size: .80rem;
        font-weight: 700;
    }

    .cug-form-section-header span {
        display: block;
        margin-top: 3px;
        color: var(--muted);
        font-size: .68rem;
    }


    /* =========================================================
    INPUT GROUP
    ========================================================= */

    .cug-input-group {
        position: relative;
        display: flex;
    }

    .cug-input-prefix {
        width: 42px;
        min-width: 42px;

        display: inline-flex;
        align-items: center;
        justify-content: center;

        border: 1px solid var(--border);
        border-right: 0;

        border-radius: 8px 0 0 8px;

        background: #f8f9fa;
        color: var(--muted);

        font-size: 16px;
    }

    .cug-input-group .form-control {
        border-radius: 0 8px 8px 0;
    }


    /* =========================================================
    MODAL SELECT2
    ========================================================= */

    .cug-modal-content
    .select2-container--default
    .select2-selection--single {
        min-height: 42px;
        height: 42px;
    }

    .cug-modal-content
    .select2-container--default
    .select2-selection--single
    .select2-selection__rendered {
        line-height: 40px;
    }



    /* =========================================================
    ORGANISATION / STAFF SELECT3
    ========================================================= */
    .cug-org-hidden {
        display: none !important;
    }

    .cug-select-staff-option {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
    }

    .cug-select-staff-avatar {
        width: 32px;
        height: 32px;
        min-width: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: var(--cug-primary-soft);
        color: var(--primary);
        font-size: .67rem;
        font-weight: 700;
    }

    .cug-select-staff-option > div:last-child {
        min-width: 0;
    }

    .cug-select-staff-option strong {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: var(--text);
        font-size: .74rem;
    }

    .cug-select-staff-option small {
        display: block;
        margin-top: 2px;
        color: var(--muted);
        font-size: .60rem;
    }

    .cug-select-loading {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 2px;
        color: var(--muted);
        font-size: .72rem;
    }

    /* =========================================================
    ALERT
    ========================================================= */

    .cug-modal-alert {
        border: 1px solid rgba(220, 38, 38, .15);
        border-radius: 9px;
        background: rgba(220, 38, 38, .05);
        color: var(--danger);
        font-size: .74rem;
    }


    /* =========================================================
    REQUIRED
    ========================================================= */

    .cug-modal-content .required {
        color: var(--danger);
    }


    /* =========================================================
    FORM TEXT
    ========================================================= */

    .cug-modal-content .form-text {
        margin-top: 5px;
        color: var(--muted);
        font-size: .65rem;
    }


    /* =========================================================
    RESPONSIVE
    ========================================================= */

    @media (max-width: 767.98px) {

        .cug-modal-header {
            padding: 15px;
        }

        .cug-modal-body {
            max-height: calc(100vh - 160px);
            padding: 15px;
        }

        .cug-modal-footer {
            padding: 12px 15px;
        }

        .cug-modal-footer .btn {
            flex: 1;
        }

    }
</style>

<script>
(function ($) {

    'use strict';

    /**
     * =========================================================
     * CUG Management — Modal Controller
     * =========================================================
     *
     * Responsibilities
     *
     * 1. Add CUG
     * 2. Edit CUG
     * 3. Assign CUG to Staff
     * 4. Change / Transfer Staff
     * 5. Release CUG
     * 6. Deactivate CUG
     * 7. Delete CUG
     * 8. Assignment History
     * 9. Call History
     * 10. Company → Entity → Branch
     * 11. Staff AJAX search
     * 12. Modal state management
     *
     * =========================================================
     */

    class CugModalController {
    constructor() {
        this.currentCugId = null;

        this.currentCug = null;

        this.currentModal = null;

        this.request = null;

        this.historyRequest = null;

        this.callHistoryRequest = null;

        this.callHistoryPage = 1;

        this.callHistoryPerPage = 25;

        this.initialized = false;

        this.staffSearchDelay = null;
        this.staffContextVersion = {
            assign: 0,
            change: 0
        };

        this.staffRequests = {
            assign: null,
            change: null
        };

        this.orgRequests = {
            assign: { companies: null, entities: null, branches: null },
            change: { companies: null, entities: null, branches: null }
        };
    }

    /* =====================================================
        INIT
        ===================================================== */

    init() {
        if (this.initialized) {
        return;
        }

        this.initialized = true;

        this.registerEvents();

        this.initializeDatePickers();

        this.initializeSelects();

        this.initializeCounters();
    }

    /* =====================================================
        EVENTS
        ===================================================== */

    registerEvents() {
        const self = this;

        /* -------------------------------------------------
            Add CUG
            ------------------------------------------------- */

        $(document).on('click', '#btnAddCugNumber', function () {
        self.openAddNumber();
        });

        /* -------------------------------------------------
            DataTable → View
            ------------------------------------------------- */

        $(document).on('cug:view', function (event, cugId) {
        self.openView(cugId);
        });

        /* -------------------------------------------------
            DataTable → Edit
            ------------------------------------------------- */

        $(document).on('cug:edit', function (event, cugId) {
        self.openEditNumber(cugId);
        });

        /* -------------------------------------------------
            DataTable → Assign
            ------------------------------------------------- */

        $(document).on('cug:assign', function (event, cugId) {
            self.openAssign(cugId);
        });

        /* -------------------------------------------------
            DataTable → Change Staff
            ------------------------------------------------- */

        $(document).on('cug:change', function (event, cugId) {
        self.openChangeStaff(cugId);
        });

        /* -------------------------------------------------
            DataTable → Release
            ------------------------------------------------- */

        $(document).on('cug:release', function (event, cugId) {
        self.releaseCug(cugId);
        });

        /* -------------------------------------------------
            Call History
            ------------------------------------------------- */

        $(document).on('cug:call-history', function (event, cugId) {
        self.openHistory(cugId, 'calls');
        });

        /* -------------------------------------------------
            Assignment History
            ------------------------------------------------- */

        $(document).on('cug:assignment-history', function (event, cugId) {
        self.openHistory(cugId, 'assignments');
        });

        /* -------------------------------------------------
            Deactivate
            ------------------------------------------------- */

        $(document).on('cug:deactivate', function (event, cugId) {
        self.deactivateCug(cugId);
        });

        /* -------------------------------------------------
            Delete
            ------------------------------------------------- */

        $(document).on('cug:delete', function (event, cugId) {
        self.deleteCug(cugId);
        });

        /* -------------------------------------------------
            Add / Edit Form
            ------------------------------------------------- */

        $(document).on('submit', '#cugNumberForm', function (event) {
            event.preventDefault();
            console.log('form submit')
            self.submitNumberForm(this);
        });

        /* -------------------------------------------------
            Assign Form
            ------------------------------------------------- */

        $(document).on('submit', '#cugAssignForm', function (event) {
        event.preventDefault();

        self.submitAssignForm(this);
        });

        /* -------------------------------------------------
            Change Staff Form
            ------------------------------------------------- */

        $(document).on('submit', '#cugChangeStaffForm', function (event) {
        event.preventDefault();

        self.submitChangeStaffForm(this);
        });

        /* -------------------------------------------------
            Company Change
            ------------------------------------------------- */

        //     self.loadEntities($(this).val());
        // });

        /* -------------------------------------------------
            Entity Change
            ------------------------------------------------- */

        // });

        /* -------------------------------------------------
            Assign / Change organisation dependencies
            ------------------------------------------------- */
        window.jQuery(document).on('change', '#cugAssignCompany', function () {
            self.loadOrgEntities('assign', $(this).val());
        });
        window.jQuery(document).on('change', '#cugAssignEntity', function () {
           self.loadOrgBranches('assign', $(this).val());
        });
        window.jQuery(document).on('change', '#cugAssignBranch', function () {
            self.loadOrgStaffs('assign', $(this).val());
            // self.updateOrgStaffState('assign');
        });
       
        window.jQuery(document).on('change', '#cugChangeCompany', function () {
            self.loadOrgEntities('change', $(this).val());
        });
        window.jQuery(document).on('change', '#cugChangeEntity', function () {
           self.loadOrgBranches('change', $(this).val());
        });
        window.jQuery(document).on('change', '#cugChangeBranch', function () {
            self.loadOrgStaffs('change');
        });


        /* -------------------------------------------------
            Assignment Staff
            ------------------------------------------------- */
        window.jQuery(document).on('change', '#cugAssignStaff', function () {
            self.loadStaffPreview($(this).val(), 'assign');
        });

        /* -------------------------------------------------
            Replacement Staff
            ------------------------------------------------- */


        window.jQuery(document).on('change', '#cugReplacementStaff', function () {
            self.loadStaffPreview($(this).val(), 'replacement');
        });

        /* -------------------------------------------------
            Call Filter
            ------------------------------------------------- */

        $(document).on('click', '#btnFilterCugCalls', function () {
        self.callHistoryPage = 1;

        self.loadCallHistory();
        });

        /* -------------------------------------------------
            Assignment Tab
            ------------------------------------------------- */

        $(document).on('shown.bs.tab', '#cugAssignmentHistoryTab', function () {
        if (self.currentCugId) {
            self.loadAssignmentHistory();
        }
        });

        /* -------------------------------------------------
            Call Tab
            ------------------------------------------------- */

        $(document).on('shown.bs.tab', '#cugCallHistoryTab', function () {
        if (self.currentCugId) {
            self.loadCallHistory();
        }
        });

        /* -------------------------------------------------
            Number input
            ------------------------------------------------- */

        $(document).on('input', '#cugNumber', function () {
        self.cleanNumberInput(this);
        });

        /* -------------------------------------------------
            Remarks counters
            ------------------------------------------------- */

        $(document).on('input', '#cugRemarks', function () {
        self.updateCounter(this, '#cugRemarksCounter', 500);
        });

        $(document).on('input', '#cugAssignRemarks', function () {
        self.updateCounter(this, '#cugAssignRemarksCounter', 500);
        });

        $(document).on('input', '#cugChangeRemarks', function () {
        self.updateCounter(this, '#cugChangeRemarksCounter', 500);
        });

        /* -------------------------------------------------
            Modal hidden
            ------------------------------------------------- */

        $(document).on('hidden.bs.modal', '#cugNumberModal', function () {
        self.resetNumberModal();
        });

        $(document).on('hidden.bs.modal', '#cugAssignModal', function () {
        self.resetAssignModal();
        });

        $(document).on('hidden.bs.modal', '#cugChangeStaffModal', function () {
        self.resetChangeStaffModal();
        });

        $(document).on('hidden.bs.modal', '#cugHistoryModal', function () {
        self.resetHistoryModal();
        });
    }

    /* =====================================================
        DATE PICKERS
        ===================================================== */

    initializeDatePickers() {
        const self = this;

        if (typeof flatpickr === 'function') {
        flatpickr('.cug-date-input', {
            dateFormat: 'Y-m-d',
            allowInput: true
        });

        return;
        }

        /*
            |--------------------------------------------------------------------------
            | Native fallback
            |--------------------------------------------------------------------------
            */

        $('.cug-date-input').attr('type', 'date');
    }

    /* =====================================================
        SELECTS
        ===================================================== */

    initializeSelects() {
        const modalSelectors = [
            '#cugProvider',
            '#cugStatus',
            '#cugAssignCompany',
            '#cugAssignEntity',
            '#cugAssignBranch',
            '#cugAssignStaff',
            '#cugAssignmentType',
            '#cugChangeCompany',
            '#cugChangeEntity',
            '#cugChangeBranch',
            '#cugReplacementStaff',
            '#cugTransferReason'
        ];

        modalSelectors.forEach(selector => {
            if (selector === '#cugAssignStaff' || selector === '#cugReplacementStaff') {
                this.initializeStaffSelect(selector);
            } else {
                this.initializeSimpleSelect3(selector);
            }
        });

        this.setCompanyZeroState('assign');
        this.setCompanyZeroState('change');
    }

    initializeSimpleSelect3(selector) {
        const element = $(selector);

        if (!element.length || typeof $.fn.select2 !== 'function') {
            return;
        }

        if (element.hasClass('select2-hidden-accessible')) {
            return;
        }

        const modal = element.closest('.modal');

        element.select2({
            width: '100%',
            dropdownParent: modal.length ? modal : $(document.body),
            placeholder: element.data('placeholder') || element.find('option:first').text(),
            allowClear: true,
            minimumResultsForSearch: 8,
            language: {
                noResults: () => 'No options found'
            }
        });
    }

    initializeStaffSelect(selector) {
        const element = $(selector);

        if (!element.length || typeof $.fn.select2 !== 'function') return;

        if (element.hasClass('select2-hidden-accessible')) {
            element.select2('destroy');
        }

        const modal = element.closest('.modal');
        const self = this;
        const type = selector === '#cugReplacementStaff' ? 'change' : 'assign';

        element.select2({
            width: '100%',
            dropdownParent: modal.length ? modal : $(document.body),
            placeholder: 'Search Staff',
            allowClear: true,
            minimumInputLength: 0,
            ajax: {
                delay: 300,
                cache: false,

                // Select2 resolves the endpoint for EVERY request. This is
                // important because company can change while the modal stays open.
                url: function () {
                    const companyId = String(
                        modal.find('select[name="company_id"]').val() ?? ''
                    );

                    return companyId === '0'
                        ? self.route('staffs')
                        : self.route('staffSearch');
                },

                data: function (params) {
                    const companyId = String(
                        modal.find('select[name="company_id"]').val() ?? ''
                    );
                    const entityId = String(
                        modal.find('select[name="entity_id"]').val() ?? ''
                    );
                    const branchId = String(
                        modal.find('select[name="branch_id"]').val() ?? ''
                    );

                    const contextVersion =
                        self.staffContextVersion[type] || 0;

                    params.__cugContextVersion = contextVersion;

                    // Elysium Groups is always ERP branch 0.
                    if (companyId === '0') {
                        return {
                            q: String(params.term || '').trim(),
                            page: Number(params.page || 1),
                            branch_id: '0'
                        };
                    }

                    return {
                        q: String(params.term || '').trim(),
                        page: Number(params.page || 1),
                        company_id: companyId,
                        entity_id: entityId,
                        branch_id: branchId
                    };
                },

                processResults: function (response, params) {
                    params.page = params.page || 1;

                    // Discard a response created for an older company/entity/branch.
                    if (
                        params.__cugContextVersion !==
                        (self.staffContextVersion[type] || 0)
                    ) {
                        return {
                            results: [],
                            pagination: { more: false }
                        };
                    }

                    const rows = Array.isArray(response?.data)
                        ? response.data
                        : [];

                    return {
                        results: rows.map(function (staff) {
                            const name = staff.staff_name || 'Unknown Staff';
                            const role = staff.job_role_name || 'Role not assigned';
                            const id = staff.id ?? staff.sno;

                            return {
                                id: id,
                                text: `${name} - ${role}`,
                                staff: staff
                            };
                        }),
                        pagination: {
                            more: Boolean(response?.pagination?.more)
                        }
                    };
                }
            },
            language: {
                searching: () => 'Searching staff...',
                loadingMore: () => 'Loading more staff...',
                noResults: () => 'No eligible staff found'
            },
            templateResult: function (item) {
                if (item.loading) {
                    return $(
                        '<div class="cug-select-loading">' +
                            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>' +
                            '<span>Loading staff...</span>' +
                        '</div>'
                    );
                }

                if (!item.id) return item.text || '';

                const staff = item.staff || {};
                const name = staff.staff_name || 'Unknown Staff';
                const role = staff.job_role_name || 'Role not assigned';
                const code = staff.staff_id ? `ID: ${staff.staff_id}` : '';

                return `
                    <div class="cug-select-staff-option">
                        <div class="cug-select-staff-avatar">
                            ${CugHelper.escapeHtml(CugHelper.initials(name))}
                        </div>
                        <div>
                            <strong>${CugHelper.escapeHtml(`${name} - ${role}`)}</strong>
                            <small>${CugHelper.escapeHtml(code)}</small>
                        </div>
                    </div>
                `;
            },
            templateSelection: function (item) {
                return item && item.id
                    ? CugHelper.escapeHtml(item.text || '')
                    : '';
            },
            escapeMarkup: function (markup) {
                return markup;
            }
        });
    }

    orgIds(type) {
        if (type === 'change') {
            return {
                company: '#cugChangeCompany',
                entity: '#cugChangeEntity',
                branch: '#cugChangeBranch',
                companyWrap: '#cugChangeCompanyWrap',
                entityWrap: '#cugChangeEntityWrap',
                branchWrap: '#cugChangeBranchWrap',
                staff: '#cugReplacementStaff'
            };
        }

        return {
            company: '#cugAssignCompany',
            entity: '#cugAssignEntity',
            branch: '#cugAssignBranch',
            companyWrap: '#cugAssignCompanyWrap',
            entityWrap: '#cugAssignEntityWrap',
            branchWrap: '#cugAssignBranchWrap',
            staff: '#cugAssignStaff'
        };
    }

    setCompanyZeroState(type) {
        const ids = this.orgIds(type);
        const company = $(ids.company);

        if (!company.length) {
            return;
        }

        const companyId = String(company.val() ?? '');
        const isElysium = companyId === '0';

        $(ids.entityWrap).toggleClass('cug-org-hidden', isElysium);
        $(ids.branchWrap).toggleClass('cug-org-hidden', isElysium);

        const entity = $(ids.entity);
        const branch = $(ids.branch);

        if (isElysium) {
            this.setSelectValue(ids.entity, '0', 'Not Applicable');
            this.setSelectValue(ids.branch, '0', 'Not Applicable');

            // Entity/Branch are not applicable for Elysium Groups.
            // Keep their submitted values at 0 but keep the controls disabled
            // because they are hidden and must never participate in selection.
            entity.prop('disabled', true).trigger('change.select2');
            branch.prop('disabled', true).trigger('change.select2');
        } else {
            if (String(entity.val() ?? '') === '0') {
                this.resetSelect2(ids.entity);
            }
            if (String(branch.val() ?? '') === '0') {
                this.resetSelect2(ids.branch);
            }

            entity.prop('disabled', !companyId).trigger('change.select2');
            branch.prop('disabled', true).trigger('change.select2');
        }

        this.loadOrgStaffs(type);
    }

    loadOrgCompanies(
        type,
        selectedId = null,
        selectedName = null,
        selectedEntityId = null,
        selectedEntityName = null,
        selectedBranchId = null,
        selectedBranchName = null
    ) {
        const ids = this.orgIds(type);
        const select = $(ids.company);

        if (!select.length) {
            return;
        }

        this.setSelectLoading(select, 'Loading companies...');

        if (this.orgRequests[type].companies) {
            this.orgRequests[type].companies.abort();
            this.orgRequests[type].companies = null;
        }

        const request = CugHelper.get(this.route('companies'));
        this.orgRequests[type].companies = request;

        request
            .done(response => {
                const rows = this.extractRows(response);

                const merged = [
                    { id: 0, company_id: 0, company_name: 'Elysium Groups' },
                    ...rows.filter(row => String(row.id ?? '') !== '0')
                ];

                this.populateSelect(
                    select,
                    merged,
                    selectedId === null || selectedId === undefined ? null : selectedId,
                    selectedName || (String(selectedId ?? '') === '0' ? 'Elysium Groups' : null),
                    'Select Company'
                );

                select.prop('disabled', false).trigger('change.select2');
                this.setCompanyZeroState(type);

                if (String(select.val() ?? '') === '0') {
                    return;
                }

                if (selectedEntityId !== null && selectedEntityId !== undefined) {
                    this.loadOrgEntities(
                        type,
                        selectedId,
                        selectedEntityId,
                        selectedEntityName,
                        selectedBranchId,
                        selectedBranchName
                    );
                } else {
                    this.loadOrgStaffs(type);
                }
            })
            .fail((xhr, status) => {
                if (status === 'abort') return;
                this.showModalError(
                    type === 'assign' ? '#cugAssignFormAlert' : '#cugChangeStaffFormAlert',
                    type === 'assign' ? '#cugAssignFormAlertMessage' : '#cugChangeStaffFormAlertMessage',
                    xhr,
                    'Unable to load companies.'
                );
            })
            .always(() => {
                if (this.orgRequests[type].companies === request) {
                    this.orgRequests[type].companies = null;
                }
            });
    }

    loadOrgEntities(
        type,
        companyId,
        selectedId = null,
        selectedName = null,
        selectedBranchId = null,
        selectedBranchName = null
    ) {
        const ids = this.orgIds(type);

        if (String(companyId ?? '') === '0') {
            this.setCompanyZeroState(type);
            this.staffContextVersion[type] =
                (this.staffContextVersion[type] || 0) + 1;

            if (this.staffRequests[type]) {
                this.staffRequests[type].abort();
                this.staffRequests[type] = null;
            }

            this.resetSelect2(ids.staff);
            this.loadOrgStaffs(type);
            return;
        }

        this.setCompanyZeroState(type);

        const entity = $(ids.entity);
        const branch = $(ids.branch);

        this.staffContextVersion[type] = (this.staffContextVersion[type] || 0) + 1;
        if (this.staffRequests[type]) {
            this.staffRequests[type].abort();
            this.staffRequests[type] = null;
        }

        entity.prop('disabled', true);
        branch.prop('disabled', true);

        this.clearSelect(entity, 'Select Entity');
        this.clearSelect(branch, 'Select Branch');
        this.resetSelect2(ids.staff);

        if (this.orgRequests[type].entities) {
            this.orgRequests[type].entities.abort();
            this.orgRequests[type].entities = null;
        }

        if (!companyId) {
            this.loadOrgStaffs(type);
            return;
        }

        this.setSelectLoading(entity, 'Loading entities...');

        const request = CugHelper.get(this.route('entities'), {
            company_id: companyId
        });
        this.orgRequests[type].entities = request;

        request
            .done(response => {
                this.populateSelect(
                    entity,
                    this.extractRows(response),
                    selectedId,
                    selectedName,
                    'Select Entity'
                );

                entity.prop('disabled', false).trigger('change.select2');

                if (selectedId !== null && selectedId !== undefined && String(selectedId) !== '0') {
                    this.loadOrgBranches(
                        type,
                        selectedId,
                        selectedBranchId,
                        selectedBranchName
                    );
                } else {
                    this.loadOrgStaffs(type);
                }
            })
            .fail(xhr => {
                this.showModalError(
                    type === 'assign' ? '#cugAssignFormAlert' : '#cugChangeStaffFormAlert',
                    type === 'assign' ? '#cugAssignFormAlertMessage' : '#cugChangeStaffFormAlertMessage',
                    xhr,
                    'Unable to load entities.'
                );
            })
            .always(() => {
                if (this.orgRequests[type].entities === request) {
                    this.orgRequests[type].entities = null;
                }
            });
    }

    loadOrgBranches(type, entityId, selectedId = null, selectedName = null) {
        const ids = this.orgIds(type);
        const companyId = $(ids.company).val();

        if (String(companyId ?? '') === '0') {
            this.setCompanyZeroState(type);
            return;
        }

        const branch = $(ids.branch);

        this.staffContextVersion[type] = (this.staffContextVersion[type] || 0) + 1;
        if (this.staffRequests[type]) {
            this.staffRequests[type].abort();
            this.staffRequests[type] = null;
        }

        branch.prop('disabled', true);
        this.clearSelect(branch, 'Select Branch');
        this.resetSelect2(ids.staff);

        if (this.orgRequests[type].branches) {
            this.orgRequests[type].branches.abort();
            this.orgRequests[type].branches = null;
        }

        if (!entityId) {
            this.loadOrgStaffs(type);
            return;
        }

        this.setSelectLoading(branch, 'Loading branches...');

        const request = CugHelper.get(this.route('branches'), {
            company_id: companyId || '',
            entity_id: entityId
        });
        this.orgRequests[type].branches = request;

        request
            .done(response => {
                this.populateSelect(
                    branch,
                    this.extractRows(response),
                    selectedId,
                    selectedName,
                    'Select Branch'
                );

                branch.prop('disabled', false).trigger('change.select2');

                if (selectedId !== null && selectedId !== undefined) {
                    branch.val(String(selectedId)).trigger('change.select2');
                }

                this.loadOrgStaffs(type);
            })
            .fail(xhr => {
                this.showModalError(
                    type === 'assign' ? '#cugAssignFormAlert' : '#cugChangeStaffFormAlert',
                    type === 'assign' ? '#cugAssignFormAlertMessage' : '#cugChangeStaffFormAlertMessage',
                    xhr,
                    'Unable to load branches.'
                );
            })
            .always(() => {
                if (this.orgRequests[type].branches === request) {
                    this.orgRequests[type].branches = null;
                }
            });
    }

    loadOrgStaffs(type, branchId, selectedId = null, selectedName = null) {
        const ids = this.orgIds(type);
        const companyId = $(ids.company).val();
        
       
        const staff = $(ids.staff);

        this.staffContextVersion[type] = (this.staffContextVersion[type] || 0) + 1;
        if (this.staffRequests[type]) {
            this.staffRequests[type].abort();
            this.staffRequests[type] = null;
        }

        

        staff.prop('disabled', true);
        this.clearSelect(staff, 'Select Staff');
        this.resetSelect2(ids.staff);

        if (this.orgRequests[type].staffs) {
            this.orgRequests[type].staffs.abort();
            this.orgRequests[type].staffs = null;
        }

        // if (!staffId) {
        //     this.updateOrgStaffState(type);
        //     return;
        // }

        this.setSelectLoading(staff, 'Loading staffs...');

        const request = CugHelper.get(this.route('staffs'), {
            company_id: companyId || '',
            branch_id: companyId == '0' ? 0 : branchId
        });
        this.orgRequests[type].staffes = request;

        request
            .done(response => {
                this.populateStaffSelect(
                    staff,
                    this.extractRows(response),
                    selectedId,
                    selectedName,
                    'Select Staff'
                );

                staff.prop('disabled', false).trigger('change.select2');

                if (selectedId !== null && selectedId !== undefined) {
                    staff.val(String(selectedId)).trigger('change.select2');
                }

                // this.updateOrgStaffState(type);
            })
            .fail(xhr => {
                this.showModalError(
                    type === 'assign' ? '#cugAssignFormAlert' : '#cugChangeStaffFormAlert',
                    type === 'assign' ? '#cugAssignFormAlertMessage' : '#cugChangeStaffFormAlertMessage',
                    xhr,
                    'Unable to load staffes.'
                );
            })
            .always(() => {
                if (this.orgRequests[type].staffs === request) {
                    this.orgRequests[type].staffs = null;
                }
            });
    }

    updateOrgStaffState(type) {
        const ids = this.orgIds(type);
        const companyId = String($(ids.company).val() ?? '');
        const entityId = String($(ids.entity).val() ?? '');
        const branchId = String($(ids.branch).val() ?? '');
        const staff = $(ids.staff);

        if (!staff.length) {
            return;
        }

        /*
         * Every organisation change creates a new staff lookup context.
         * Any in-flight AJAX response from the previous context is ignored.
         */
        this.staffContextVersion[type] =
            (this.staffContextVersion[type] || 0) + 1;

        if (this.staffRequests[type]) {
            this.staffRequests[type].abort();
            this.staffRequests[type] = null;
        }

        const ready = companyId === '0'
            ? branchId === '0'
            : Boolean(companyId && entityId && branchId);

        /*
         * Always clear the previous staff selection whenever the
         * organisation context changes or becomes incomplete.
         */
        this.resetSelect2(ids.staff);
        staff.prop('disabled', !ready);

        /*
         * Refresh the Select2 widget without triggering the business-level
         * "change" handlers. The next dropdown open/search will request
         * staff using the latest company/entity/branch values.
         */
        staff.trigger('change.select2');
    }

    validateOrganization(type) {
        const ids = this.orgIds(type);
        const alert = type === 'assign'
            ? '#cugAssignFormAlert'
            : '#cugChangeStaffFormAlert';
        const message = type === 'assign'
            ? '#cugAssignFormAlertMessage'
            : '#cugChangeStaffFormAlertMessage';

        const companyId = String($(ids.company).val() ?? '');

        if (!companyId) {
            this.showModalMessage(alert, message, 'Please select a company.');
            return false;
        }

        if (companyId === '0') {
            return true;
        }

        if (!$(ids.entity).val()) {
            this.showModalMessage(alert, message, 'Please select an entity.');
            return false;
        }

        if (!$(ids.branch).val()) {
            this.showModalMessage(alert, message, 'Please select a branch.');
            return false;
        }

        return true;
    }

    /* =====================================================
        ADD CUG
        ===================================================== */

    openAddNumber() {
        this.currentCugId = null;

        this.currentCug = null;

        this.resetNumberModal();

        $('#cugNumberModalLabel').text('Add CUG Number');

        $('#cugNumberModalSubtitle').text('Add a new CUG number to the managed number pool.');

        $('#cugNumberMethod').val('POST');

        $('#cugNumberId').val('');

        $('#cugSaveButtonText').text('Add CUG Number');

        $('#cugSaveButtonIcon').attr('class', 'ti ti-device-mobile-plus me-1');

        $('#cugStatus').val('0').prop('disabled', true);

        this.showModal('#cugNumberModal');

    }

    /* =====================================================
        EDIT CUG
        ===================================================== */

    openEditNumber(cugId) {
        if (!cugId) {
        return;
        }

        this.currentCugId = cugId;

        this.resetNumberModal();

        $('#cugNumberModalLabel').text('Edit CUG Number');

        $('#cugNumberModalSubtitle').text('Update the CUG number information.');

        $('#cugNumberMethod').val('PUT');

        $('#cugSaveButtonText').text('Update CUG Number');

        $('#cugSaveButtonIcon').attr('class', 'ti ti-device-mobile-check me-1');

        $('#cugStatus').prop('disabled', false);

        this.showModal('#cugNumberModal');

        this.setButtonLoading('#btnSaveCugNumber', true, 'Loading...');

        this.loadCug(cugId)

        .done(response => {
            const data = this.extractData(response);

            this.currentCug = data;

            this.populateNumberForm(data);
        })

        .fail(xhr => {
            this.showModalError('#cugNumberFormAlert', '#cugNumberFormAlertMessage', xhr, 'Unable to load CUG number.');
        })

        .always(() => {
            this.setButtonLoading('#btnSaveCugNumber', false);
        });
    }

    /* =====================================================
        LOAD CUG
        ===================================================== */

    loadCug(cugId) {
        return $.ajax({
        url: this.route('show', cugId),

        type: 'GET',

        dataType: 'json'
        });
    }

    /* =====================================================
        POPULATE NUMBER FORM
        ===================================================== */

    populateNumberForm(data) {
        $('#cugNumberId').val(data.sno ?? data.id ?? '');

        $('#cugNumber').val(data.cug_number ?? '');

        // $('#cugCode').val(data.cug_code ?? '');

        $('#cugProvider').val(data.provider ?? '');

        $('#cugStatus').val(String(data.status ?? 0));

        $('#cugRemarks').val(data.remarks ?? '');

        this.updateCounter(document.getElementById('cugRemarks'), '#cugRemarksCounter', 500);

        /*
            |--------------------------------------------------------------------------
            | Company
            |--------------------------------------------------------------------------
            */

        // this.setSelectValue('#cugCompany', data.company_id, data.company_name);

        /*
            |--------------------------------------------------------------------------
            | Entity
            |--------------------------------------------------------------------------
            */

        this.loadEntities(data.company_id, data.entity_id, data.entity_name);

        /*
            |--------------------------------------------------------------------------
            | Branch
            |--------------------------------------------------------------------------
            */

        if (data.entity_id) {
        this.loadBranches(data.entity_id, data.branch_id, data.branch_name);
        }
    }

    /* =====================================================
        NUMBER FORM SUBMIT
        ===================================================== */

    submitNumberForm(form) {
        const self = this;

        this.clearModalError('#cugNumberFormAlert');

        if (!this.validateNumberForm(form)) {
        return;
        }

        const id = $('#cugNumberId').val();

        const method = $('#cugNumberMethod').val() || 'POST';

        const url = method === 'PUT' ? this.route('update', id) : this.route('store');

        const data = $(form).serialize();

        this.setButtonLoading('#btnSaveCugNumber', true, method === 'PUT' ? 'Updating...' : 'Saving...');

        $.ajax({
        url: url,

        type: 'POST',

        data: data,

        dataType: 'json'
        })

        .done(function (response) {
            self.handleSuccess(
            response,
            method === 'PUT' ? 'CUG number updated successfully.' : 'CUG number added successfully.'
            );

            self.closeModal('#cugNumberModal');

            self.refreshAfterChange();
        })

        .fail(function (xhr) {
            self.showModalError('#cugNumberFormAlert', '#cugNumberFormAlertMessage', xhr, 'Unable to save CUG number.');
        })

        .always(function () {
            self.setButtonLoading('#btnSaveCugNumber', false);
        });
    }

    /* =====================================================
        VALIDATE NUMBER
        ===================================================== */

    validateNumberForm(form) {
        const number = $.trim($('#cugNumber').val());

        const provider = $('#cugProvider').val();

        // const company = $('#cugCompany').val();

        if (!number) {
        this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'CUG number is required.');

        $('#cugNumber').trigger('focus');

        return false;
        }

        if (!/^[0-9+\-\s]{7,20}$/.test(number)) {
        this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Enter a valid CUG number.');

        $('#cugNumber').trigger('focus');

        return false;
        }

        if (!provider) {
        this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Please select a provider.');

        $('#cugProvider').trigger('focus');

        return false;
        }

        // if (!company) {
        //     this.showModalMessage('#cugNumberFormAlert', '#cugNumberFormAlertMessage', 'Please select a company.');

        //     $('#cugCompany').trigger('focus');

        //     return false;
        // }

        return true;
    }

    /* =====================================================
        STAFF PREVIEW
        ===================================================== */

    loadStaffPreview(staffId, type) {
        if (!staffId) {
        if (type === 'assign') {
            $('#cugAssignStaffPreview').addClass('d-none');

            $('#cugAssignStaffWarning').addClass('d-none');
        } else {
            $('#cugReplacementStaffPreview').addClass('d-none');

            $('#cugReplacementStaffWarning').addClass('d-none');
        }

        return;
        }

        $.ajax({
        url: this.route('staffShow', staffId),

        type: 'GET',

        dataType: 'json'
        })

        .done(response => {
            const staff = this.extractData(response);

            this.populateStaffPreview(staff, type);
        })

        .fail(xhr => {
            this.showToastError(xhr, 'Unable to load staff details.');
        });
    }

    /* =====================================================
        STAFF PREVIEW UI
        ===================================================== */

    populateStaffPreview(staff, type) {
        const name = staff.staff_name || staff.name || 'Unknown Staff';

        const staffCode = staff.staff_id || staff.staff_code || staff.id || '—';

        const department = staff.department_name || '—';

        const designation = staff.job_role_name || staff.designation || '—';

        const initials = CugHelper.initials(name);

        if (type === 'assign') {
        $('#cugAssignStaffInitials').text(initials);

        $('#cugAssignStaffName').text(name);

        $('#cugAssignStaffId').text(staffCode);

        $('#cugAssignStaffDepartment').text(department);

        $('#cugAssignStaffDesignation').text(designation);

        $('#cugAssignStaffPreview').removeClass('d-none');

        this.updateExistingCugWarning(staff, 'assign');
        } else {
        $('#cugReplacementStaffInitials').text(initials);

        $('#cugReplacementStaffName').text(name);

        $('#cugReplacementStaffId').text(staffCode);

        $('#cugReplacementStaffDepartment').text(department);

        $('#cugReplacementStaffDesignation').text(designation);

        $('#cugReplacementStaffPreview').removeClass('d-none');

        this.updateExistingCugWarning(staff, 'replacement');
        }
    }

    /* =====================================================
        EXISTING CUG WARNING
        ===================================================== */

    updateExistingCugWarning(staff, type) {
        const existing = staff.existing_cug_number || staff.current_cug_number || staff.cug_number || null;

        if (type === 'assign') {
        const warning = $('#cugAssignStaffWarning');

        if (existing) {
            $('#cugAssignExistingNumber').text(existing);

            $('#cugAssignStaffWarningText').text('This staff member already has an assigned CUG number.');

            warning.removeClass('d-none');
        } else {
            warning.addClass('d-none');
        }
        } else {
        const warning = $('#cugReplacementStaffWarning');

        if (existing) {
            $('#cugReplacementExistingNumber').text(existing);

            $('#cugReplacementStaffWarningText').text('This staff member already has an assigned CUG number.');

            warning.removeClass('d-none');
        } else {
            warning.addClass('d-none');
        }
        }
    }

    /* =====================================================
        OPEN ASSIGN
        ===================================================== */

    openAssign(cugId) {
        if (!cugId) {
        return;
        }

        this.currentCugId = cugId;

        this.resetAssignModal();

        $('#cugAssignNumberId').val(cugId);

        this.showModal('#cugAssignModal');

        this.setButtonLoading('#btnAssignCug', true, 'Loading...');

        this.loadCug(cugId)

        .done(response => {
            const data = this.extractData(response);

            this.currentCug = data;

            this.populateAssignCug(data);
        })

        .fail(xhr => {
            this.showModalError('#cugAssignFormAlert', '#cugAssignFormAlertMessage', xhr, 'Unable to load CUG number.');
        })

        .always(() => {
            this.setButtonLoading('#btnAssignCug', false);
        });
    }

    /* =====================================================
        ASSIGN CUG SUMMARY
        ===================================================== */

    populateAssignCug(data) {
        $('#cugAssignNumber').text(data.cug_number || '—');

        $('#cugAssignProvider').text(data.provider || '—');

        $('#cugAssignCurrentStatus').html(this.renderStatus(data.status, data.status_label));

        this.loadOrgCompanies('assign', data.company_id ?? null, data.company_name ?? null, data.entity_id ?? null, data.entity_name ?? null, data.branch_id ?? null, data.branch_name ?? null);

        /*
            |--------------------------------------------------------------------------
            | Default assignment date
            |--------------------------------------------------------------------------
            */

        if (!$('#cugAssignDate').val()) {
        $('#cugAssignDate').val(this.today());
        }

        /*
            |--------------------------------------------------------------------------
            | Assignment type
            |--------------------------------------------------------------------------
            */

        $('#cugAssignmentType').val('NEW');
    }

    /* =====================================================
        SUBMIT ASSIGN
        ===================================================== */

    submitAssignForm(form) {
        const self = this;

        this.clearModalError('#cugAssignFormAlert');

        if (!this.validateAssignForm(form)) {
        return;
        }

        const data = $(form).serialize();

      

        this.setButtonLoading('#btnAssignCug', true, 'Assigning...');

        $.ajax({
        url: this.route('assign'),

        type: 'POST',

        data: data,

        dataType: 'json'
        })

        .done(function (response) {
            self.handleSuccess(response, 'CUG number assigned successfully.');

            self.closeModal('#cugAssignModal');

            self.refreshAfterChange();
        })

        .fail(function (xhr) {
            self.showModalError('#cugAssignFormAlert', '#cugAssignFormAlertMessage', xhr, 'Unable to assign CUG number.');
        })

        .always(function () {
            self.setButtonLoading('#btnAssignCug', false);
        });
    }

    /* =====================================================
        VALIDATE ASSIGN
        ===================================================== */

    validateAssignForm(form) {
        const cugId = $('#cugAssignNumberId').val();

        const staffId = $('#cugAssignStaff').val();

        const date = $('#cugAssignDate').val();

        if (!cugId) {
        this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'CUG number was not selected.');

        return false;
        }

        if (!this.validateOrganization('assign')) {
            return false;
        }

        if (!staffId) {
        this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'Please select a staff member.');

        $('#cugAssignStaff').trigger('focus');

        return false;
        }

        if (!date) {
        this.showModalMessage('#cugAssignFormAlert', '#cugAssignFormAlertMessage', 'Assignment date is required.');

        return false;
        }

        return true;
    }

    /* =====================================================
        OPEN CHANGE STAFF
        ===================================================== */

    openChangeStaff(cugId) {
        if (!cugId) {
        return;
        }

        this.currentCugId = cugId;

        this.resetChangeStaffModal();

        $('#cugChangeCugId').val(cugId);

        this.showModal('#cugChangeStaffModal');

        this.setButtonLoading('#btnChangeCugStaff', true, 'Loading...');

        this.loadCug(cugId)

        .done(response => {
            const data = this.extractData(response);

            this.currentCug = data;

            this.populateChangeStaff(data);
        })

        .fail(xhr => {
            this.showModalError(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            xhr,
            'Unable to load current CUG assignment.'
            );
        })

        .always(() => {
            this.setButtonLoading('#btnChangeCugStaff', false);
        });
    }

    /* =====================================================
        POPULATE CHANGE STAFF
        ===================================================== */

    populateChangeStaff(data) {
        $('#cugChangeCugNumber').text(data.cug_number || '—');

        $('#cugChangeCugProvider').text(data.provider || '—');

        const staff = data.current_staff || data.staff || {};

        const name = staff.staff_name || data.staff_name || 'Unassigned';

        const staffCode = staff.staff_id || data.staff_code || data.staff_id || '—';

        const department = staff.department_name || data.department_name || '—';

        const designation = staff.job_role_name || staff.designation || data.designation || '—';

        $('#cugCurrentStaffInitials').text(CugHelper.initials(name));

        $('#cugCurrentStaffName').text(name);

        $('#cugCurrentStaffId').text(staffCode);

        $('#cugCurrentStaffDepartment').text(department);

        $('#cugCurrentStaffDesignation').text(designation);

        this.loadOrgCompanies('change', data.company_id ?? null, data.company_name ?? null, data.entity_id ?? null, data.entity_name ?? null, data.branch_id ?? null, data.branch_name ?? null);

        /*
            |--------------------------------------------------------------------------
            | Effective date
            |--------------------------------------------------------------------------
            */

        $('#cugChangeEffectiveDate').val(this.today());
    }

    /* =====================================================
        SUBMIT CHANGE STAFF
        ===================================================== */

    submitChangeStaffForm(form) {
        const self = this;

        this.clearModalError('#cugChangeStaffFormAlert');

        if (!this.validateChangeStaffForm(form)) {
        return;
        }

        const confirmed = window.confirm(
        'Are you sure you want to transfer this CUG number to the selected staff member? The current assignment will be closed and preserved in history.'
        );

        if (!confirmed) {
        return;
        }

        this.setButtonLoading('#btnChangeCugStaff', true, 'Transferring...');

        $.ajax({
        url: this.route('changeStaff'),

        type: 'POST',

        data: $(form).serialize(),

        dataType: 'json'
        })

        .done(function (response) {
            self.handleSuccess(response, 'CUG staff changed successfully.');

            self.closeModal('#cugChangeStaffModal');

            self.refreshAfterChange();
        })

        .fail(function (xhr) {
            self.showModalError(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            xhr,
            'Unable to change CUG staff.'
            );
        })

        .always(function () {
            self.setButtonLoading('#btnChangeCugStaff', false);
        });
    }

    /* =====================================================
        VALIDATE CHANGE STAFF
        ===================================================== */

    validateChangeStaffForm(form) {
        const cugId = $('#cugChangeCugId').val();

        const staffId = $('#cugReplacementStaff').val();

        const date = $('#cugChangeEffectiveDate').val();

        const reason = $('#cugTransferReason').val();

        const remarks = $.trim($('#cugChangeRemarks').val());

        if (!cugId) {
        this.showModalMessage(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            'CUG number was not selected.'
        );

        return false;
        }

        if (!this.validateOrganization('change')) {
            return false;
        }

        if (!staffId) {
        this.showModalMessage(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            'Please select the replacement staff.'
        );

        return false;
        }

        if (!date) {
        this.showModalMessage(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            'Effective date is required.'
        );

        return false;
        }

        if (!reason) {
        this.showModalMessage(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            'Please select a transfer reason.'
        );

        return false;
        }

        if (!remarks) {
        this.showModalMessage(
            '#cugChangeStaffFormAlert',
            '#cugChangeStaffFormAlertMessage',
            'Please enter transfer remarks.'
        );

        return false;
        }

        return true;
    }

    /* =====================================================
        RELEASE CUG
        ===================================================== */

    releaseCug(cugId) {
        if (!cugId) {
        return;
        }

        const confirmed = window.confirm(
        'Release this CUG number from the current staff member? The assignment will be closed and preserved in history.'
        );

        if (!confirmed) {
        return;
        }

        this.performAction('release', cugId, 'CUG number released successfully.', 'Unable to release CUG number.');
    }

    /* =====================================================
        DEACTIVATE CUG
        ===================================================== */

    deactivateCug(cugId) {
        if (!cugId) {
        return;
        }

        const confirmed = window.confirm('Deactivate this CUG number? It will no longer be available for assignment.');

        if (!confirmed) {
        return;
        }

        this.performAction('deactivate', cugId, 'CUG number deactivated successfully.', 'Unable to deactivate CUG number.');
    }

    /* =====================================================
        DELETE CUG
        ===================================================== */

    deleteCug(cugId) {
        if (!cugId) {
        return;
        }

        const confirmed = window.confirm(
        'Delete this CUG number? This action should only be used when the number was entered incorrectly. Historical assignment and call records must not be removed.'
        );

        if (!confirmed) {
        return;
        }

        this.performAction('delete', cugId, 'CUG number deleted successfully.', 'Unable to delete CUG number.');
    }

    /* =====================================================
        ACTION REQUEST
        ===================================================== */

    performAction(action, cugId, successMessage, errorMessage) {
        const self = this;

        $.ajax({
        url: this.route(action, cugId),

        type: 'POST',

        data: {
            _token: this.csrf(),

            cug_id: cugId
        },

        dataType: 'json'
        })

        .done(function (response) {
            self.handleSuccess(response, successMessage);

            self.refreshAfterChange();
        })

        .fail(function (xhr) {
            self.showToastError(xhr, errorMessage);
        });
    }

    /* =====================================================
        HISTORY
        ===================================================== */

    openHistory(cugId, tab = 'assignments') {
        if (!cugId) {
        return;
        }

        this.currentCugId = cugId;

        this.resetHistoryModal();

        this.showModal('#cugHistoryModal');

        this.loadHistorySummary(cugId);

        if (tab === 'calls') {
        const callTab = document.querySelector('#cugCallHistoryTab');

        if (callTab && typeof bootstrap !== 'undefined') {
            bootstrap.Tab.getOrCreateInstance(callTab).show();
        } else {
            $('#cugCallHistoryTab').tab('show');
        }
        } else {
        const assignmentTab = document.querySelector('#cugAssignmentHistoryTab');

        if (assignmentTab && typeof bootstrap !== 'undefined') {
            bootstrap.Tab.getOrCreateInstance(assignmentTab).show();
        } else {
            $('#cugAssignmentHistoryTab').tab('show');
        }
        }
    }

    /* =====================================================
        HISTORY SUMMARY
        ===================================================== */

    loadHistorySummary(cugId) {
        $.ajax({
        url: this.route('show', cugId),

        type: 'GET',

        dataType: 'json'
        })

        .done(response => {
            const data = this.extractData(response);

            $('#cugHistoryNumber').text(data.cug_number || '—');

            $('#cugHistoryProvider').text(data.provider || '—');

            $('#cugHistoryCurrentStaff').text(data.staff_name || data.current_staff?.staff_name || 'Unassigned');

            $('#cugHistoryTotalCalls').text(CugHelper.number(data.call_count || data.total_calls || 0));

            $('#cugHistoryStatus').html(this.renderStatus(data.status, data.status_label));
        });
    }

    /* =====================================================
        ASSIGNMENT HISTORY
        ===================================================== */

    loadAssignmentHistory() {
        const cugId = this.currentCugId;

        if (!cugId) {
        return;
        }

        const loading = $('#cugAssignmentHistoryLoading');

        const timeline = $('#cugAssignmentTimeline');

        const empty = $('#cugAssignmentHistoryEmpty');

        loading.removeClass('d-none');

        timeline.empty();

        empty.addClass('d-none');

        if (this.historyRequest) {
        this.historyRequest.abort();
        }

        this.historyRequest = $.ajax({
        url: this.route('assignmentHistory', cugId),

        type: 'GET',

        dataType: 'json'
        });

        this.historyRequest

        .done(response => {
            const data = this.extractData(response);

            const rows = data.assignments || data.history || [];

            $('#cugAssignmentHistoryCount').text(rows.length);

            if (!rows.length) {
            empty.removeClass('d-none');

            return;
            }

            timeline.html(rows.map(row => this.renderAssignmentHistory(row)).join(''));
        })

        .fail((xhr, status) => {
            if (status === 'abort') {
            return;
            }

            timeline.html(this.renderHistoryError('Unable to load assignment history.'));
        })

        .always(() => {
            loading.addClass('d-none');

            this.historyRequest = null;
        });
    }

    /* =====================================================
        RENDER ASSIGNMENT HISTORY
        ===================================================== */

    renderAssignmentHistory(row) {
        const action = String(row.action || row.type || '').toUpperCase();

        let icon = 'ti-user';

        let className = '';

        let title = 'Assignment';

        switch (action) {
        case 'ASSIGNED':
            icon = 'ti-user-plus';

            className = 'assigned';

            title = 'CUG Assigned';

            break;

        case 'RELEASED':
            icon = 'ti-user-minus';

            className = 'released';

            title = 'CUG Released';

            break;

        case 'TRANSFERRED':
            icon = 'ti-user-shared';

            className = 'transferred';

            title = 'CUG Transferred';

            break;

        case 'CHANGED':
            icon = 'ti-user-shared';

            className = 'transferred';

            title = 'Staff Changed';

            break;

        default:
            icon = 'ti-history';

            break;
        }

        if (row.is_current) {
        icon = 'ti-user-check';

        className = 'current';

        title = 'Current Assignment';
        }

        const staffName = row.staff_name || 'Unassigned';

        const staffCode = row.staff_code || row.staff_id || '—';

        const startDate = row.start_date ? CugHelper.formatDate(row.start_date) : '—';

        const endDate = row.end_date ? CugHelper.formatDate(row.end_date) : null;

        const reason = row.reason || row.transfer_reason || null;

        const remarks = row.remarks || '';

        return `
                <div class="cug-assignment-history-item">

                    <div class="cug-assignment-history-icon ${className}">

                        <i class="ti ${icon}"></i>

                    </div>

                    <div class="cug-assignment-history-content">

                        <div class="cug-assignment-history-top">

                            <div>

                                <span class="cug-assignment-history-title">

                                    ${CugHelper.escapeHtml(title)}

                                </span>

                            </div>

                            <span class="cug-assignment-history-date">

                                ${CugHelper.escapeHtml(startDate)}

                                ${endDate ? ` — ${CugHelper.escapeHtml(endDate)}` : ''}

                            </span>

                        </div>

                        <div class="cug-assignment-history-description">

                            <strong>

                                ${CugHelper.escapeHtml(staffName)}

                            </strong>

                            ${staffCode !== '—' ? ` (${CugHelper.escapeHtml(staffCode)})` : ''}

                            ${row.department_name ? ` · ${CugHelper.escapeHtml(row.department_name)}` : ''}

                        </div>

                        <div class="cug-assignment-history-meta">

                            ${
                            reason
                                ? `
                                        <span class="cug-assignment-history-tag reason">

                                            <i class="ti ti-info-circle"></i>

                                            ${CugHelper.escapeHtml(this.formatReason(reason))}

                                        </span>
                                    `
                                : ''
                            }

                            ${
                            row.created_at
                                ? `
                                        <span class="cug-assignment-history-tag">

                                            <i class="ti ti-clock"></i>

                                            ${CugHelper.escapeHtml(CugHelper.formatDateTime(row.created_at))}

                                        </span>
                                    `
                                : ''
                            }

                            ${
                            remarks
                                ? `
                                        <span
                                            class="cug-assignment-history-tag"
                                            title="${CugHelper.escapeHtml(remarks)}">

                                            <i class="ti ti-message"></i>

                                            Remarks

                                        </span>
                                    `
                                : ''
                            }

                        </div>

                    </div>

                </div>
            `;
    }

    /* =====================================================
        CALL HISTORY
        ===================================================== */

    loadCallHistory() {
        const cugId = this.currentCugId;

        if (!cugId) {
        return;
        }

        const loading = $('#cugCallHistoryLoading');

        const wrapper = $('#cugCallHistoryTableWrapper');

        const empty = $('#cugCallHistoryEmpty');

        loading.removeClass('d-none');

        wrapper.removeClass('d-none');

        empty.addClass('d-none');

        if (this.callHistoryRequest) {
        this.callHistoryRequest.abort();
        }

        this.callHistoryRequest = $.ajax({
        url: this.route('callHistory', cugId),

        type: 'GET',

        data: {
            page: this.callHistoryPage,

            per_page: this.callHistoryPerPage,

            from: $('#cugCallHistoryFrom').val(),

            to: $('#cugCallHistoryTo').val()
        },

        dataType: 'json'
        });

        this.callHistoryRequest

        .done(response => {
            const data = this.extractData(response);

            const rows = data.records || data.data || [];

            $('#cugCallHistoryCount').text(data.total ?? rows.length);

            if (!rows.length) {
            $('#cugCallHistoryBody').empty();

            wrapper.addClass('d-none');

            empty.removeClass('d-none');

            $('#cugCallHistoryPagination').empty();

            return;
            }

            $('#cugCallHistoryBody').html(rows.map(row => this.renderCallRow(row)).join(''));

            this.renderCallPagination(data);
        })

        .fail((xhr, status) => {
            if (status === 'abort') {
            return;
            }

            $('#cugCallHistoryBody').html(this.renderTableError('Unable to load call history.'));
        })

        .always(() => {
            loading.addClass('d-none');

            this.callHistoryRequest = null;
        });
    }

    /* =====================================================
        CALL ROW
        ===================================================== */

    renderCallRow(row) {
        const dateTime = row.call_datetime || row.datetime || row.created_at;

        const date = dateTime ? CugHelper.formatDate(dateTime) : '—';

        const time = dateTime ? CugHelper.formatTime(dateTime) : '—';

        const type = String(row.type || row.call_type || '').toUpperCase();

        let typeClass = 'incoming';

        let typeIcon = 'ti-phone-incoming';

        let typeLabel = 'Incoming';

        if (type === 'OUTGOING') {
        typeClass = 'outgoing';

        typeIcon = 'ti-phone-outgoing';

        typeLabel = 'Outgoing';
        }

        if (type === 'MISSED') {
        typeClass = 'missed';

        typeIcon = 'ti-phone-off';

        typeLabel = 'Missed';
        }

        const status = String(row.status || 'ANSWERED').toUpperCase();

        let statusClass = 'text-success';

        if (status === 'MISSED' || status === 'FAILED') {
        statusClass = 'text-danger';
        }

        return `
                <tr>

                    <td>

                        <div class="cug-call-datetime">

                            <strong>

                                ${CugHelper.escapeHtml(date)}

                            </strong>

                            <span>

                                ${CugHelper.escapeHtml(time)}

                            </span>

                        </div>

                    </td>

                    <td>

                        <span class="cug-call-type ${typeClass}">

                            <i class="ti ${typeIcon}"></i>

                            ${typeLabel}

                        </span>

                    </td>

                    <td>

                        <span class="cug-call-number">

                            ${CugHelper.escapeHtml(row.caller_number || row.phone_number || row.number || '—')}

                        </span>

                    </td>

                    <td>

                        <span class="cug-call-duration">

                            ${CugHelper.escapeHtml(row.duration || '—')}

                        </span>

                    </td>

                    <td>

                        <span class="cug-call-staff">

                            ${CugHelper.escapeHtml(row.staff_name || '—')}

                        </span>

                    </td>

                    <td>

                        <span class="cug-call-status ${statusClass}">

                            <span class="cug-call-status-dot"></span>

                            ${CugHelper.escapeHtml(this.formatReason(status))}

                        </span>

                    </td>

                </tr>
            `;
    }

    /* =====================================================
        CALL PAGINATION
        ===================================================== */

    renderCallPagination(data) {
        const current = Number(data.current_page || data.currentPage || 1);

        const last = Number(data.last_page || data.lastPage || 1);

        if (last <= 1) {
        $('#cugCallHistoryPagination').empty();

        return;
        }

        let html = `
                <nav aria-label="CUG call history pagination">

                    <ul class="pagination pagination-sm">
            `;

        html += `
                <li class="page-item ${current <= 1 ? 'disabled' : ''}">

                    <button
                        type="button"
                        class="page-link"
                        data-cug-call-page="${current - 1}">

                        <i class="ti ti-chevron-left"></i>

                    </button>

                </li>
            `;

        const start = Math.max(1, current - 2);

        const end = Math.min(last, current + 2);

        for (let page = start; page <= end; page++) {
        html += `
                    <li class="page-item ${page === current ? 'active' : ''}">

                        <button
                            type="button"
                            class="page-link"
                            data-cug-call-page="${page}">

                            ${page}

                        </button>

                    </li>
                `;
        }

        html += `
                <li class="page-item ${current >= last ? 'disabled' : ''}">

                    <button
                        type="button"
                        class="page-link"
                        data-cug-call-page="${current + 1}">

                        <i class="ti ti-chevron-right"></i>

                    </button>

                </li>
            `;

        html += `
                    </ul>

                </nav>
            `;

        $('#cugCallHistoryPagination').html(html);
    }

    /* =====================================================
        PAGINATION EVENT
        ===================================================== */

    initializePaginationEvents() {
        const self = this;

        $(document).on('click', '[data-cug-call-page]', function () {
        const button = $(this);

        if (button.closest('.disabled').length) {
            return;
        }

        self.callHistoryPage = Number(button.data('cug-call-page'));

        self.loadCallHistory();
        });
    }

    /* =====================================================
        OPEN VIEW
        ===================================================== */

    openView(cugId) {
        this.openHistory(cugId, 'assignments');
    }

    /* =====================================================
        STATUS HTML
        ===================================================== */

    renderStatus(status, label) {
        const value = String(status ?? '');

        let className = 'cug-status-inactive';

        let text = label || 'Unknown';

        switch (value) {
        case '0':
            className = 'cug-status-available';

            text = label || 'Available';

            break;

        case '1':
            className = 'cug-status-assigned';

            text = label || 'Assigned';

            break;

        case '2':
            className = 'cug-status-reserved';

            text = label || 'Reserved';

            break;

        case '3':
            className = 'cug-status-inactive';

            text = label || 'Inactive';

            break;
        }

        return `
                <span class="cug-status-badge ${className}">

                    <span class="cug-status-dot"></span>

                    ${CugHelper.escapeHtml(text)}

                </span>
            `;
    }

    /* =====================================================
        REFRESH AFTER CHANGE
        ===================================================== */

    refreshAfterChange() {
        if (window.cugRecentActivity) window.cugRecentActivity.load();
        /*
            |--------------------------------------------------------------------------
            | DataTable
            |--------------------------------------------------------------------------
            */

        if (window.cugDataTable && typeof window.cugDataTable.reload === 'function') {
        window.cugDataTable.reload(false);
        }

        /*
            |--------------------------------------------------------------------------
            | Dashboard
            |--------------------------------------------------------------------------
            */

        if (window.cugDashboard && typeof window.cugDashboard.refresh === 'function') {
        window.cugDashboard.refresh();
        }

        /*
            |--------------------------------------------------------------------------
            | Timeline
            |--------------------------------------------------------------------------
            */

        $(document).trigger('cug:data-changed');
    }

    /* =====================================================
        SUCCESS
        ===================================================== */

    handleSuccess(response, fallbackMessage) {
        const message = response?.message || fallbackMessage;

        if (typeof CugHelper.toastSuccess === 'function') {
        CugHelper.toastSuccess(message);

        return;
        }

        // if (typeof Swal !== 'undefined') {
        //     Swal.fire({
        //         icon: 'success',

        //         title: 'Success',

        //         text: message,

        //         timer: 1800,

        //         showConfirmButton: false
        //     });

        //     return;
        // }
        toastr.success(message)

        console.info(message);
    }

    /* =====================================================
        MODAL ERROR
        ===================================================== */

    showModalError(alertSelector, messageSelector, xhr, fallback) {
        let message = fallback;

        const response = xhr?.responseJSON;

        if (response?.message) {
        message = response.message;
        }

        /*
            |--------------------------------------------------------------------------
            | Laravel validation errors
            |--------------------------------------------------------------------------
            */

        if (response?.errors) {
        const errors = [];

        Object.keys(response.errors).forEach(key => {
            const values = response.errors[key];

            if (Array.isArray(values)) {
            values.forEach(value => {
                errors.push(value);
            });
            }
        });

        if (errors.length) {
            message = errors.join('<br>');
        }
        }

        $(messageSelector).html(this.escapeHtmlMessage(message));

        $(alertSelector).removeClass('d-none');
    }

    /* =====================================================
        SIMPLE MODAL MESSAGE
        ===================================================== */

    showModalMessage(alertSelector, messageSelector, message) {
        $(messageSelector).text(message);

        $(alertSelector).removeClass('d-none');
    }

    clearModalError(selector) {
        $(selector).addClass('d-none');
    }

    /* =====================================================
        TOAST ERROR
        ===================================================== */

    showToastError(xhr, fallback) {
        const message = xhr?.responseJSON?.message || fallback;

        if (typeof CugHelper.toastError === 'function') {
        CugHelper.toastError(message);

        return;
        }

        // if (typeof Swal !== 'undefined') {
        //     Swal.fire({
        //         icon: 'error',

        //         title: 'Unable to complete',

        //         text: message
        //     });

        //     return;
        // }
        toastr.error(message)
        console.error(message);
    }

    /* =====================================================
        BUTTON LOADING
        ===================================================== */

    setButtonLoading(selector, loading, text = null) {
        const button = $(selector);

        if (!button.length) {
        return;
        }

        if (loading) {
        if (!button.data('original-html')) {
            button.data('original-html', button.html());
        }

        button.prop('disabled', true).html(`
                        <span
                            class="spinner-border spinner-border-sm me-1"
                            role="status"
                            aria-hidden="true">
                        </span>

                        ${CugHelper.escapeHtml(text || 'Processing...')}
                    `);

        return;
        }

        const original = button.data('original-html');

        if (original) {
        button.html(original);
        }

        button.prop('disabled', false);
    }

    /* =====================================================
        SELECT HELPERS
        ===================================================== */

    setSelectLoading(select, text) {
        select.prop('disabled', true).html(`<option value="">${text}</option>`).trigger('change.select2');
    }

    setSelectError(select, text) {
        select.prop('disabled', true).html(`<option value="">${text}</option>`).trigger('change.select2');
    }

    clearSelect(select, placeholder) {
        select.html(`<option value="">${placeholder}</option>`).trigger('change.select2');
    }

    populateSelect(select, rows, selectedId, selectedName, placeholder) {
        let html = `<option value="">${placeholder}</option>`;

        rows.forEach(row => {
        const id = row.id ?? row.sno ?? row.company_id ?? row.entity_id ?? row.branch_id;

        const name = row.name ?? row.company_name ?? row.entity_name ?? row.branch_name ?? row.label ?? row.staff_name ?? 'Unnamed';

        const selected = selectedId !== null && String(id) === String(selectedId) ? 'selected' : '';

        html += `
                        <option
                            value="${CugHelper.escapeHtml(id)}"
                            ${selected}>

                            ${CugHelper.escapeHtml(name)}

                        </option>
                    `;
        });

        if (selectedId && !rows.some(row => String(row.id ?? row.sno) === String(selectedId)) && selectedName) {
        html += `
                    <option
                        value="${CugHelper.escapeHtml(selectedId)}"
                        selected>

                        ${CugHelper.escapeHtml(selectedName)}

                    </option>
                `;
        }

        select.html(html).trigger('change.select2');
    }

    
    populateStaffSelect(select, rows, selectedId, selectedName, placeholder) {
        let html = `<option value="">${placeholder}</option>`;

        rows.forEach(row => {
        const id = row.id ?? row.sno ?? row.company_id ?? row.entity_id ?? row.branch_id;

        const name =  row.staff_name ?? 'Unnamed';

        const selected = selectedId !== null && String(id) === String(selectedId) ? 'selected' : '';

        html += `
                        <option
                            value="${CugHelper.escapeHtml(id)}"
                            ${selected}>

                            ${CugHelper.escapeHtml(name)}

                        </option>
                    `;
        });

        if (selectedId && !rows.some(row => String(row.id ?? row.sno) === String(selectedId)) && selectedName) {
        html += `
                    <option
                        value="${CugHelper.escapeHtml(selectedId)}"
                        selected>

                        ${CugHelper.escapeHtml(selectedName)}

                    </option>
                `;
        }

        select.html(html).trigger('change.select2');
    }

    setSelectValue(selector, value, text = null) {
        const select = $(selector);

        if (!select.length) {
        return;
        }

        if (value === null || typeof value === 'undefined' || value === '') {
        select.val('').trigger('change.select2');

        return;
        }

        if (!select.find(`option[value="${value}"]`).length) {
        select.append(
            $('<option>', {
            value: value,

            text: text || value
            })
        );
        }

        select.val(value).trigger('change.select2');
    }

    /* =====================================================
        DATA HELPERS
        ===================================================== */

    extractData(response) {
        if (response?.data && typeof response.data === 'object') {
        return response.data;
        }

        return response || {};
    }

    extractRows(response) {
        const data = response?.data;

        if (Array.isArray(data)) {
        return data;
        }

        if (Array.isArray(data?.data)) {
        return data.data;
        }

        if (Array.isArray(response?.rows)) {
        return response.rows;
        }

        return [];
    }

    /* =====================================================
        COUNTERS
        ===================================================== */

    initializeCounters() {
        this.updateCounter(document.getElementById('cugRemarks'), '#cugRemarksCounter', 500);

        this.updateCounter(document.getElementById('cugAssignRemarks'), '#cugAssignRemarksCounter', 500);

        this.updateCounter(document.getElementById('cugChangeRemarks'), '#cugChangeRemarksCounter', 500);
    }

    updateCounter(element, counterSelector, max) {
        if (!element) {
        return;
        }

        const length = $(element).val().length;

        $(counterSelector).text(`${length} / ${max}`);
    }

    /* =====================================================
        NUMBER CLEANING
        ===================================================== */

    cleanNumberInput(element) {
        let value = $(element).val();

        value = value.replace(/[^0-9+\-\s]/g, '');

        $(element).val(value);
    }

    /* =====================================================
        RESET NUMBER MODAL
        ===================================================== */

    resetNumberModal() {
        const form = document.getElementById('cugNumberForm');

        if (form) {
        form.reset();
        }

        $('#cugNumberId').val('');

        $('#cugNumberMethod').val('POST');

        $('#cugStatus').val('0').prop('disabled', false);

        this.clearModalError('#cugNumberFormAlert');

        $('#cugRemarksCounter').text('0 / 500');
    }

    /* =====================================================
        RESET ASSIGN
        ===================================================== */

    resetAssignModal() {
        const form = document.getElementById('cugAssignForm');

        if (form) {
        form.reset();
        }

        $('#cugAssignNumberId').val('');

        $('#cugAssignNumber').text('—');

        $('#cugAssignProvider').text('—');

        $('#cugAssignStaffPreview').addClass('d-none');

        $('#cugAssignStaffWarning').addClass('d-none');

        $('#cugAssignRemarksCounter').text('0 / 500');

        this.clearModalError('#cugAssignFormAlert');

        /*
            |--------------------------------------------------------------------------
            | Reset Select2
            |--------------------------------------------------------------------------
            */

        this.resetSelect2('#cugAssignStaff');
        this.resetSelect2('#cugAssignCompany');
        $('#cugAssignCompany').val('').trigger('change.select2');
        this.resetSelect2('#cugAssignEntity');
        this.resetSelect2('#cugAssignBranch');
        $('#cugAssignEntity, #cugAssignBranch').prop('disabled', true);
        this.loadOrgStaffs('assign');

        /*
            |--------------------------------------------------------------------------
            | Default date
            |--------------------------------------------------------------------------
            */

        $('#cugAssignDate').val(this.today());
    }

    /* =====================================================
        RESET CHANGE STAFF
        ===================================================== */

    resetChangeStaffModal() {
        const form = document.getElementById('cugChangeStaffForm');

        if (form) {
        form.reset();
        }

        $('#cugChangeCugId').val('');

        $('#cugChangeCugNumber').text('—');

        $('#cugChangeCugProvider').text('—');

        $('#cugCurrentStaffInitials').text('?');

        $('#cugCurrentStaffName').text('—');

        $('#cugCurrentStaffId').text('—');

        $('#cugCurrentStaffDepartment').text('—');

        $('#cugCurrentStaffDesignation').text('—');

        $('#cugReplacementStaffPreview').addClass('d-none');

        $('#cugReplacementStaffWarning').addClass('d-none');

        $('#cugChangeEffectiveDate').val(this.today());

        $('#cugChangeRemarksCounter').text('0 / 500');

        this.clearModalError('#cugChangeStaffFormAlert');

        this.resetSelect2('#cugReplacementStaff');
        this.resetSelect2('#cugChangeCompany');
        $('#cugChangeCompany').val('').trigger('change.select2');
        this.resetSelect2('#cugChangeEntity');
        this.resetSelect2('#cugChangeBranch');
        $('#cugChangeEntity, #cugChangeBranch').prop('disabled', true);
        this.loadOrgStaffs('change');
    }

    /* =====================================================
        RESET HISTORY
        ===================================================== */

    resetHistoryModal() {
        this.currentCugId = null;

        this.currentCug = null;

        if (this.historyRequest) {
        this.historyRequest.abort();

        this.historyRequest = null;
        }

        if (this.callHistoryRequest) {
        this.callHistoryRequest.abort();

        this.callHistoryRequest = null;
        }

        $('#cugHistoryNumber').text('—');

        $('#cugHistoryProvider').text('—');

        $('#cugHistoryCurrentStaff').text('—');

        $('#cugHistoryTotalCalls').text('0');

        $('#cugHistoryStatus').text('—');

        $('#cugAssignmentTimeline').empty();

        $('#cugCallHistoryBody').empty();

        $('#cugCallHistoryPagination').empty();

        $('#cugAssignmentHistoryEmpty').addClass('d-none');

        $('#cugCallHistoryEmpty').addClass('d-none');

        $('#cugAssignmentHistoryLoading').addClass('d-none');

        $('#cugCallHistoryLoading').addClass('d-none');
    }

    /* =====================================================
        RESET SELECT2
        ===================================================== */

    resetSelect2(selector) {
        const element = $(selector);

        if (!element.length) {
            return;
        }

        // Clear both the native value and Select2's rendered selection without
        // firing the business-level change handlers.
        element.val(null).trigger('change.select2');
    }

    /* =====================================================
        CLOSE MODAL
        ===================================================== */

    getModalInstance(selector) {
        const element = document.querySelector(selector);

        if (!element) {
            return null;
        }

        if (!window.bootstrap || !window.bootstrap.Modal) {
            console.error('Bootstrap 5 Modal API is not available.');
            return null;
        }

        return window.bootstrap.Modal.getOrCreateInstance(element, {
            backdrop: 'static',
            keyboard: false
        });
    }

    showModal(selector) {
        const instance = this.getModalInstance(selector);
        if (instance) instance.show();
    }

    closeModal(selector) {
        const instance = this.getModalInstance(selector);
        if (instance) instance.hide();
    }

    /* =====================================================
        ROUTES
        ===================================================== */

    route(name, id = null) {
        if (window.cugRoutes && window.cugRoutes[name]) {
        let url = window.cugRoutes[name];

        if (id !== null) {
            url = url.replace('__ID__', encodeURIComponent(id));
        }

        return url;
        }

        if (window.CugHelper && typeof CugHelper.route === 'function') {
        return CugHelper.route(name, id);
        }

        console.error(`CUG route "${name}" is not configured.`);

        return '#';
    }

    /* =====================================================
        CSRF
        ===================================================== */

    csrf() {
        const token = $('meta[name="csrf-token"]').attr('content');

        if (token) {
        return token;
        }

        return (
        $('#cugNumberForm input[name="_token"]').val() ||
        $('#cugAssignForm input[name="_token"]').val() ||
        $('#cugChangeStaffForm input[name="_token"]').val() ||
        ''
        );
    }

    /* =====================================================
        TODAY
        ===================================================== */

    today() {
        const date = new Date();

        const year = date.getFullYear();

        const month = String(date.getMonth() + 1).padStart(2, '0');

        const day = String(date.getDate()).padStart(2, '0');

        return `${year}-${month}-${day}`;
    }

    /* =====================================================
        FORMAT REASON
        ===================================================== */

    formatReason(value) {
        if (!value) {
        return '—';
        }

        return String(value)
        .replace(/_/g, ' ')

        .toLowerCase()

        .replace(/\b\w/g, char => char.toUpperCase());
    }

    /* =====================================================
        HISTORY ERROR
        ===================================================== */

    renderHistoryError(message) {
        return `
                <div class="cug-history-empty">

                    <div class="cug-history-empty-icon">

                        <i class="ti ti-alert-circle"></i>

                    </div>

                    <strong>
                        Unable to load history
                    </strong>

                    <span>
                        ${CugHelper.escapeHtml(message)}
                    </span>

                </div>
            `;
    }

    /* =====================================================
        TABLE ERROR
        ===================================================== */

    renderTableError(message) {
        return `
                <tr>

                    <td
                        colspan="6"
                        class="text-center py-4">

                        <span class="text-danger">

                            <i class="ti ti-alert-circle me-1"></i>

                            ${CugHelper.escapeHtml(message)}

                        </span>

                    </td>

                </tr>
            `;
    }

    /* =====================================================
        ESCAPE HTML MESSAGE
        ===================================================== */

    escapeHtmlMessage(message) {
        if (typeof message !== 'string') {
        return '';
        }

        /*
            |--------------------------------------------------------------------------
            | Validation errors intentionally use <br>
            |--------------------------------------------------------------------------
            */

        return message
        .split('<br>')
        .map(part => CugHelper.escapeHtml(part))
        .join('<br>');
    }
    }

    /* =========================================================
    INITIALIZE
    ========================================================= */

    $(function () {
    window.cugModal = new CugModalController();

    cugModal.init();

    cugModal.initializePaginationEvents();
    });

})(jQuery);
</script>