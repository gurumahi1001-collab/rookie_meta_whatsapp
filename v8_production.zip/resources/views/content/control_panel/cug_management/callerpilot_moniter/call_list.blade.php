@extends('layouts/layoutMaster')

@section('title', 'Manage Calls')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
@php
    $dayCounter = 1;
    $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
    $currentYear = request()->get('year', date('Y')); // Default to current year if not provided

    // Calculate the first day of the month
    $firstDayOfMonth = Carbon\Carbon::createFromDate($currentYear, $currentMonth, 1);
    // Get the number of days in the current month
    $daysInMonth = $firstDayOfMonth->daysInMonth;

    // Calculate previous month and year
    $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
    $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January

    // Calculate next month and year
    $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
    $nextYear = $currentMonth == 12 ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December
    $currentDate = '2025-' . str_pad($currentMonth, 2, '0', STR_PAD_LEFT) . '-' . str_pad($dayCounter, 2, '0', STR_PAD_LEFT);
    
     $module_name = 'Lead Management';
     $menu_name = 'Manage Calls';
@endphp

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }
.wa-audio{

    width:250px;

    height:46px;

    display:flex;

    align-items:center;

    gap:10px;

    padding:6px 10px;

    background:#eef6ff;

    border-radius:24px;

    border:1px solid #d8e8ff;

    transition:.25s;

    cursor:pointer;

}

.wa-audio:hover{

    background:#e5f1ff;

}

.wa-player{

    display:none;

}

.wa-play{

    width:34px;

    height:34px;

    border:none;

    border-radius:50%;

    background:#0d6efd;

    color:#fff;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:18px;

    flex-shrink:0;

}

.wa-wave{

    position:relative;

    flex:1;

    height:4px;

    background:#d7d7d7;

    border-radius:20px;

    overflow:hidden;

}

.wa-progress{

    position:absolute;

    left:0;

    top:0;

    width:0%;

    height:100%;

    background:#0d6efd;

    border-radius:20px;

}

.wa-time{

    font-size:11px;

    font-weight:600;

    color:#555;

    white-space:nowrap;

}

.wa-size{

    font-size:10px;

    color:#888;

    white-space:nowrap;

}

.wa-download{

    color:#666;

    font-size:18px;

}

.wa-download:hover{

    color:#0d6efd;

}

.wa-audio-empty{

    width:170px;

    height:42px;

    border:1px dashed #ddd;

    border-radius:22px;

    display:flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    color:#999;

    font-size:12px;

}
   
</style>
 
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    .tagify__dropdown {
        z-index: 999999 !important;
    }
    .tagify__dropdown__wrapper {
        z-index: 999999 !important;
    }

     #aiBtn.ai-loading {
        opacity: 0.7;
        pointer-events: none;
    }
     #aiBtnEdit.ai-loading {
        opacity: 0.7;
        pointer-events: none;
    }


    .searchBar {
          width: 100%;
          display: flex;
          flex-direction: row;
          align-items: center;
          position: relative;
      }

      


      .searchQueryInput {
          width: 100%;
          height: 2.8rem;
          background: #f5f5f5;
          outline: none;
          border: none;
          border-radius: 0.5rem;
          padding: 0 6rem 0 1.5rem; /* extra space for 2 icons */
          font-size: 1rem;
      }

      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }
      .searchAction {
          position: absolute;
          background: none;
          border: none;
          outline: none;
          right:0;
      }
      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }

      
      .searchSubmit, .refreshBar {
            padding: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 5px;
        }

        .searchSubmit:hover, .refreshBar:hover {
            background-color: #f5f5f5;
            border-radius: 50%;
        }

        .searchSubmit {
            background-color: transparent;
        }

        .refreshBar {
            background-color: transparent;
            display: none; /* Hidden initially */
        }

        .searchQueryInput:focus + .searchAction .searchSubmit {
            background-color: #f5f5f5;
        }

        .searchQueryInput:focus + .searchAction .refreshBar {
            display: block;
        }

        /* Optional: Adding a smooth transition for the search icon and refresh icon */
        .searchSubmit, .refreshBar {
            transition: transform 0.2s ease;
        }

        .searchSubmit:hover, .refreshBar:hover {
            transform: scale(1.2);
            background:none;
        }

      .searchIcon {
          right: 3rem; /* search stays left of refresh */
      }

      .refreshIcon {
          right: 0.8rem; /* refresh at far right */
      }

      .searchQuerySubmit:hover {
          cursor: pointer;
      }

      .role-remove-btn {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: none;
        background-color: #ccc;
        color: #fff;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .role-remove-btn:hover {
        background-color: #ff4d4f; /* red on hover */
        transform: scale(1.4) rotate(90deg);
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
</style>

<style>

    .searchBar {
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: center;
        position: relative;
    }

    


    .searchQueryInput {
        width: 100%;
        height: 2.8rem;
        background: #f5f5f5;
        outline: none;
        border: none;
        border-radius: 0.5rem;
        padding: 0 6rem 0 1.5rem; /* extra space for 2 icons */
        font-size: 1rem;
    }

    .searchQuerySubmit {
        background: none;
        border: none;
        outline: none;
    }
    .searchAction {
        position: absolute;
        background: none;
        border: none;
        outline: none;
        right:0;
    }
    .searchQuerySubmit {
        background: none;
        border: none;
        outline: none;
    }

    
    .searchSubmit, .refreshBar {
            padding: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 5px;
        }

        .searchSubmit:hover, .refreshBar:hover {
            background-color: #f5f5f5;
            border-radius: 50%;
        }

        .searchSubmit {
            background-color: transparent;
        }

        .refreshBar {
            background-color: transparent;
            display: none; /* Hidden initially */
        }

        .searchQueryInput:focus + .searchAction .searchSubmit {
            background-color: #f5f5f5;
        }

        .searchQueryInput:focus + .searchAction .refreshBar {
            display: block;
        }

        /* Optional: Adding a smooth transition for the search icon and refresh icon */
        .searchSubmit, .refreshBar {
            transition: transform 0.2s ease;
        }

        .searchSubmit:hover, .refreshBar:hover {
            transform: scale(1.2);
            background:none;
        }

    .searchIcon {
        right: 3rem; /* search stays left of refresh */
    }

    .refreshIcon {
        right: 0.8rem; /* refresh at far right */
    }

    .searchQuerySubmit:hover {
        cursor: pointer;
    }

    .role-remove-btn {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: none;
        background-color: #ccc;
        color: #fff;
        font-weight: bold;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .role-remove-btn:hover {
        background-color: #ff4d4f; /* red on hover */
        transform: scale(1.4) rotate(90deg);
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .skeleton-loader {
        /*display: flex;*/
        /*flex-direction: row;*/
        /*gap: 10px;*/
    }

    .skeleton-row {
        display: flex;
        flex-direction: row;
        gap: 10px;
    }

    .skeleton {
        width: 100%;
        height: 30px; /* Adjust height as needed */
        background: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
        background-size: 200% 100%;
        border-radius: 4px;
        animation: loading 1.2s infinite;
    }

    .skeleton-cell {
        flex: 1;
        height: 40px; /* Match the row height */
    }

    
        .skeleton-loader-view {
            background-color: #e0e0e0;
            background-image: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
            background-size: 200% 100%;
            animation: loading 1.2s infinite;
            border-radius: 4px;
            height: 20px;
        }
        
        .skeleton-loader-view.max-w-75 {
            width: 75%;
        }
        
        @keyframes loading {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }
</style>     
    
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
        <h5 class="card-title mb-1">Manage Calls</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">CUG Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="mb-0 d-flex align-items-center">
            {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-2 mb-2" data-bs-toggle="modal" data-bs-target="#">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Export"><i class="mdi mdi-calendar-export-outline"></i></span>
            </a> --}}

            <div class="me-2 mb-2 w-60">
            
                <div class="cursor-pointer input-group input-group-merge">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" id="month_filter" value="<?php echo date("M-Y"); ?>" readonly onchange="loadThemes(1)">
                    <!--<span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>-->
                </div>
               
            </div>
            
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-2 mb-2" id="filter">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
            
            

        </div>
    </div>
    
   
   
    <div class="card-body px-4 py-0 pt-2">
        
        <div class="d-flex flex-wrap align-items-center mb-2">
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Incoming Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info dash_month"></span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/egc_images/calls/incoming_call.png')}}" alt="Incoming Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-black fs-6" style="background-color: #50CD89 !important;" id="dash_incomming_call">0</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Outgoing Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info dash_month"></span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/egc_images/calls/outgoing_call.png')}}" alt="Outgoing Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <label class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Outgoing Calls" style="background-color: #FFA500 !important;" id="dash_outgoing_call">0</label>
                    <label class="fw-bold text-black fs-5 ms-1 me-1">/</label>
                    <label class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Outgoing Call Ratio" style="background-color: #FFA500 !important;" id="dash_outgoing_call_ratio">0%</label>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Missed Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info dash_month"></span> )</div>
                <div class="mb-3">
                    <img src="{{asset('assets/egc_images/calls/missed_call.png')}}" alt="Missed Call Icon" class="text-black fw-bold" style="height: 35px !important;Width: 35px !important;">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Missed Calls" style="background-color: #4CD2FC !important;" id="dash_missed_call">0</div>
                    <label class="fw-bold text-black fs-5 ms-1 me-1">/</label>
                    <div class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Missed Call Ratio" style="background-color: #4CD2FC !important;" id="dash_missed_call_ratio">0 %</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                <div class="text-dark fw-semibold fs-6 mb-1">Rejected Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info dash_month"></span> )</div>
                <div class="mb-3">
                    <img src="{{asset('assets/egc_images/calls/rejected_call.png')}}" alt="Rejected Call Icon" class="text-black fw-bold" style="height: 35px !important;Width: 35px !important;">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #9F0A22 !important;" id="dash_rejected_call">0</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                <div class="text-dark fw-semibold fs-6 mb-1">Dialed Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info dash_month"></span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/egc_images/calls/dialed_call.png')}}" alt="Dialed Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #1855FD !important;" id="dash_dialed_call">0</div>
                </div>
            </a>
        </div>
        
        <div class="filter_tbox" style="display: none;">
         
            <div class="row py-1">
       
                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                    <select id="status_fill" name="status_fill" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="0" >Outgoing Call</option>
                        <option value="4" >Dialed Call</option>
                        <option value="1" >Incoming Call</option>
                        <option value="2" >Missed Call</option>
                        <option value="3" >Rejected Call</option>
                    </select>
                </div>

                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Callers</label>
                    <select id="staff_fill" name="staff_fill" class="select3 form-select">
                        <option value="" selected>All</option>
                        @foreach ($staff_list as $stf_list)
                            <option value="{{ $stf_list->staff_id }}" >{{ $stf_list->staff_name }}</option>
                            @endforeach
                    </select>
                </div>
            </div>
            <div class="d-flex justify-content-end mb-2">
              <a href="javascript:;" type="button"
                  class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
              </a>
              <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>

        @php
            if(auth()->user()->hasPermission($module_name, 'Location', $menu_name)){
                $location_check = 1;
            }else{
                 $location_check = 0;
            }
            if(auth()->user()->hasPermission($module_name, 'Audio', $menu_name)){
                $audio_check = 1;
            }else{
                 $audio_check = 0;
            }
        @endphp
        
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Calls..."
                                value=""/>
                            
                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                        <span class="mdi mdi-magnify fs-4 fw-bold text-primary"  ></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                        <span class="mdi mdi-refresh fs-4 fw-bold text-primary" ></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px px-2">Staff</th>
                                <th class="min-w-100px px-2">Communicator</th>
                                <th class="min-w-100px px-1">Call Date</th>
                                <th class="min-w-100px px-1">Start Time</th>
                                <th class="min-w-100px px-1">End Time</th>
                                <th class="min-w-100px px-1">Duration</th>
                                <th class="min-w-100px px-1">Status</th>
                              
                                <th class="min-w-100px px-1">Audio</th>
                              
                                <th class="min-w-50px px-1">Location</th>
                              
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="list-table-body" >
                            <tr class="skeleton-loader" id="skeleton-loader" >
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                         
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                               
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                           
                                
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>


  <!--begin::Modal - Staff Call Location-->
  <div class="modal fade" id="kt_modal_call_location" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black" id="call_location_name">Call Location</h3>
                    </div>
                    <div class="row mb-4">
                        <div id="call-location-data"></div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Staff Call Location-->

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#filter_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#filter_form').submit();
    }
  }
</script>
 <script>
      function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/manage_calls/?month_filter=' + val;
    }

    </script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#lead_week_st_dt_fill').val(firstday);
            $('#lead_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>


<script>
    function call_location_func(latitude, longitude){
        console.log(longitude)
        var location =`<iframe width="100%" height="500" src="https://maps.google.com/maps?q=${latitude},${longitude}&hl=es;z=14&output=embed"></iframe>`
            $('#call-location-data').html(location);
    }

</script>





    <script>
        let currentPageCall = 1;
        let isLoadingCall = false;
        let abortControllerCall = new AbortController();
        let locationCheck =@json($location_check);
        let audioCheck =@json($audio_check);

        function formatDate(dateString) {
            const date = new Date(dateString);

            // Check if the date is valid
            if (isNaN(date.getTime())) {
                return '-'; // Return '-' if the date is invalid
            }

            // Get the day, month (abbreviated), and year
            const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
            const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
            const year = date.getFullYear(); // Get full year

            // Construct and return the formatted date string
            return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
        }

        function safeJsonParse(str) {
            try { return JSON.parse(str); }
            catch(e) { return str; }
        }

        function callStatusBadge(status) {
            switch (parseInt(status)) {

                case 0:
                    return `<span class="badge rounded text-dark fs-7 fw-semibold" style="background:#FFA500">Outgoing Call</span>`;

                case 1:
                    return `<span class="badge rounded text-dark fs-7 fw-semibold" style="background:#50CD89">Incoming Call</span>`;

                case 2:
                    return `<span class="badge rounded text-dark fs-7 fw-semibold" style="background:#4CD2FC">Missed Call</span>`;

                case 3:
                    return `<span class="badge rounded text-white fs-7 fw-semibold" style="background:#9F0A22">Rejected Call</span>`;

                case 4:
                    return `<span class="badge rounded text-white fs-7 fw-semibold" style="background:#1855FD">Dialed Call</span>`;

                default:
                    return "-";
            }

        }

        function formatTime(timeString) {
            if (!timeString) return "-";

            const parts = timeString.split(":");
            if (parts.length < 2) return "-";

            let hours = parseInt(parts[0]);
            let minutes = parts[1];
            let seconds = parts[2] || "00";

            let ampm = hours >= 12 ? "PM" : "AM";

            hours = hours % 12;
            hours = hours ? hours : 12;

            return `${hours.toString().padStart(2,"0")}:${minutes} ${ampm}`;
        }

        function isOlderThan24Hours(callStartDate) {
            if (!callStartDate) return false;

            const callDate = new Date(callStartDate);
            const now = new Date();

            return (now - callDate) >= (24 * 60 * 60 * 1000);
        }
   
    
        function buildRow(item, index) {

            let d = item.data;

            let leadName =
                d.communicator_staff_name ??
                d.internal_user_name ??
                d.customer_name ??
                "Unknown";

            let leadStatus = "-";

            if (d.communicator_staff_name) {
            

                switch (parseInt(d.lead_status)) {

                    case 0:
                        leadStatus = `<span class="badge bg-info text-white rounded fw-bold fs-8 mb-2">Active</span>`;
                        break;

                    case 1:
                        leadStatus = `<span class="badge bg-warning text-white rounded fw-bold fs-8 mb-2">Inactive</span>`;
                        break;

                    case 4:
                        leadStatus = `<span class="badge bg-success text-white rounded fw-bold fs-8 mb-2">Customer</span>`;
                        break;

                    case 10:
                        leadStatus = `<span class="badge bg-success text-white rounded fw-bold fs-8 mb-2">Old Customer</span>`;
                        break;

                    case 8:
                        leadStatus = `<span class="badge bg-warning text-primary rounded fw-bold fs-8 mb-2">Old Lead</span>`;
                        break;

                    case 5:

                        if (d.drop_verified == 0 || d.drop_tl_verified == 0)
                            leadStatus = `<span class="badge bg-danger text-white rounded fw-bold fs-8 mb-2">Dead Lead Awaiting</span>`;
                        else
                            leadStatus = `<span class="badge bg-danger text-white rounded fw-bold fs-8 mb-2">Dead Lead</span>`;

                        break;

                    case 7:

                        if (d.spam_verified == 0 || d.spam_tl_verified == 0)
                            leadStatus = `<span class="badge bg-primary text-white rounded fw-bold fs-8 mb-2">Spam Awaiting</span>`;
                        else
                            leadStatus = `<span class="badge bg-primary text-white rounded fw-bold fs-8 mb-2">Spam</span>`;

                        break;
                }
            }                  
                
            let audioHtml = d.audio_file
                    ? `
                    <div class="wa-audio" onclick="toggleAudio(this)">

                        <audio preload="metadata" class="wa-player">
                            <source src="/call_audios/${d.audio_file}">
                        </audio>

                        <button type="button" class="wa-play">
                            <i class="mdi mdi-play"></i>
                        </button>

                        <div class="wa-wave">
                            <div class="wa-progress"></div>
                        </div>

                        <div class="wa-time">
                            <span class="wa-current">00:00</span>
                            <span>/</span>
                            <span class="wa-duration">${d.call_duration ?? '--'}</span>
                        </div>

                        <div class="wa-size">
                            ${item.audio_size}
                        </div>

                        <a href="/call_audios/${d.audio_file}"
                        download
                        class="wa-download"
                        onclick="event.stopPropagation();">

                            <i class="mdi mdi-download"></i>

                        </a>

                    </div>
                    `
                    :
                    `
                    <div class="wa-audio-empty">
                        <i class="mdi mdi-music-off"></i>
                        No Recording
                    </div>
                    `;
                    
            return `
                <tr style="background:${item.bgColor}">
                    <td class="px-1">
                        <div class="d-flex align-items-center px-1">
                            <div class="symbol symbol-35px border border-gray-400 bg-primary rounded px-1 py-1 me-2">
                                <div class="image-input image-input-circle" data-kt-image-input="true">
                                    <img src="/assets/egc_images/calls/${item.img}" alt="Communicator" class="image-input-wrapper w-20px h-20px" />
                                </div>
                            </div>
                            <div class="mb-0 align-items-center">
                                <label class="fs-7 me-1">${d.staff_name}</label>
                                <div class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">${d.staff_phone_no}</div>
                            </div>
                        </div>
                        ${item.last_login_date ? `
                            <div class="ms-4">

                                <span
                                    data-bs-toggle="tooltip"
                                    title="Last Login">

                                    <span class="text-info fs-8 fw-bold">
                                        ${formatDate(item.last_login_date)}
                                    </span>

                                    <span class="text-info fs-8 fw-bold">
                                        ${formatTime(item.last_login_time)}
                                    </span>

                                </span>

                                <div class="text-danger fs-8 fw-bold">
                                    ${item.duration} ago
                                </div>

                            </div>
                            ` : ''}
                    </td>
                    <td>
                    ${d.communicator_staff_name ?
                        `<div class="d-flex align-items-center px-1">
                            <div class="mb-0 align-items-center">
                                <label class="fs-7 me-1">${d.communicator_staff_name}</label>
                                <div class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">${d.customer_phone_no}</div>
                                <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-info rounded fw-bold fs-8 mb-2 mt-1 px-1 ">${ d.lead_staff || 'Old Staff'}</span></div>
                            </div>
                        </div>
                        `
                    :
                    (d.internal_user_name ?
                        `
                        <div class="d-flex align-items-center px-1">
                            <div class="mb-0 align-items-center">
                                <label class="fs-7 me-1">${d.internal_user_name}</label>
                                <div class="d-block text-primary fs-8 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">${d.customer_phone_no}</div>
                                <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-warning rounded fw-bold fs-8 mb-2 mt-1 px-1 ">Internal</span></div>
                            </div>
                        </div>
                        `
                    :
                    `
                        <div class="d-flex align-items-center px-1">
                            <div class="mb-0 align-items-center">
                                <label class="fs-7 me-1">${ d.communicator_staff_name ? d.communicator_staff_name :(d.customer_name ? d.customer_name :"Unknown")}</label>
                                <label class="d-block text-primary fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">
                                <div class="d-flex align-items-center justify-content-center gap-2">
                                    ${d.customer_phone_no}
                                    ${isOlderThan24Hours(d.call_start_date) ? `
                                        
                                    ` : ''}
                                </div>
                                </label>
                            </div>
                        </div>
                    `
                    )
                            
                    }
                    </td>
              
                    <td>
                        <span class="text-black fs-7 fw-semibold">
                            ${d.call_start_date ? formatDate(d.call_start_date) : "-"}
                        </span>
                    </td>
                    <td>
                        <span class="text-info fs-7 fw-semibold">
                            ${d.call_start_time ? formatTime(d.call_start_time) : "-"}
                        </span>
                    </td>
                    <td>
                        <span class="text-danger fs-7 fw-semibold">
                            ${d.call_end_time ? formatTime(d.call_end_time) : "-"}
                        </span>
                    
                    </td>
                    <td>
                        <span class="badge bg-warning text-black fs-7 fw-bold">
                            ${d.call_duration ?? "-"}
                        </span>
                    </td>
                    <td>
                        ${callStatusBadge(d.call_status)}
                    </td>
                   
                    <td>
                        ${audioHtml}
                    </td>
                    <td>
                        <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_call_location" class="border border-gray-400 rounded px-1 py-2"   onclick="call_location_func(${d.latitude || 0},${d.longitude || 0})">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Location"> <i class="mdi mdi-map-marker-radius text-gray fs-4"></i></span>
                        </a>
                    </td>
                </tr>
            `;
        }

        function loadThemes(page = 1) {
            const perpage = document.getElementById('perpage').value;
            const search = document.getElementById('search_filter').value;
            const staff_fill = document.getElementById('staff_fill').value;
            const status_fill = document.getElementById('status_fill').value;
            const month_filter = document.getElementById('month_filter').value;

            const url = `/manage_calls?page=${page}&sorting_filter=${perpage}&search_filter=${search}&staff_fill=${staff_fill}&status_fill=${status_fill}&month_filter=${month_filter}`;

            // Show skeleton loader and clear old data before fetching new data
            isLoadingCall = true;
            document.getElementById('list-table-body').innerHTML = ''; // Clear old data
            document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
            $('#skeleton-loader').show(); // Show skeleton loader

            if (abortControllerCall.signal) {
                abortControllerCall.abort(); // Abort the previous request
            }
            abortControllerCall = new AbortController();

            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortControllerCall.signal })
                .then(res => res.json())
                .then(res => {

                    $('.dash_month').text(res.month_name);
                    $('#dash_incomming_call').text(res.incoming_call_count);

                    $('#dash_outgoing_call').text(res.outgoingcall_count);

                    $('#dash_missed_call').text(res.missedcall_count);

                    $('#dash_rejected_call').text(res.rejected_call_count);

                    $('#dash_dialed_call').text(res.dialedcall_count);

                    $('#dash_outgoing_call_ratio').text(
                        Number(res.outgoing_call_ratio).toFixed(2) + '%'
                    );

                    $('#dash_missed_call_ratio').text(
                        Number(res.missed_call_ratio).toFixed(2) + '%'
                    );
                    // Insert new data into the table
                    if(res.data.length > 0){
                        res.data.forEach((item, index) => {
                            document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                        });

                    }else{
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                    }
                        $('[data-bs-toggle="tooltip"]').tooltip();

                    // Update pagination and results info
                    updatePagination(res.current_page, res.last_page, res.total, perpage);

                    // Hide skeleton loader after data is fetched
                    isLoadingCall = false;
                    $('#skeleton-loader').hide();
                })
                .catch(error => {
                    if (error.name !== 'AbortError') { // Only handle abort error
                        console.error('Error loading data:', error);
                    }
                    // Hide skeleton loader in case of error
                    $('#skeleton-loader').hide();
                    isLoadingCall = false;
                });
        }

        function skeletenRow(){
            return `
                <tr class="skeleton-loader" id="skeleton-loader">
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                    <td class="skeleton-cell">
                        <div class="skeleton"></div>
                    </td>
                </tr>
                `;
        }

        function NoDataFound(){
            return `
                <tr><td colspan="10" class="text-center">No Data Found</td></tr>
                `;
        }

        function updatePagination(currentPageCall, lastPage, total, perpage) {
            let paginationContainer = document.getElementById('pagination-container');
            paginationContainer.innerHTML = ''; // Clear old pagination

            // Set the pagination container style
            paginationContainer.style.display = "flex";
            paginationContainer.style.justifyContent = "space-between";
            paginationContainer.style.alignItems = "center";

            // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
            let start = (currentPageCall - 1) * perpage + 1;
            let end = Math.min(currentPageCall * perpage, total);
            let showingInfo = `Showing ${start} to ${end} of ${total} results`;
            paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

            // Create Pagination Buttons

            // << First button
            let firstButton = `<li class="page-item ${currentPageCall === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
            
            // < Previous button
            let prevButton = `<li class="page-item ${currentPageCall > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPageCall - 1})" >‹</button> </li>`;
            
            // Next button
            let nextButton = `<li class="page-item ${currentPageCall < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPageCall + 1})" >›</button> </li>`;
            
            // >> Last button
            let lastButton = `<li class="page-item ${currentPageCall === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

            // Page Number Buttons (Dynamically show a range of pages around the current page)
            let pageButtons = '';
            let range = 2; // Show 2 pages before and after the current page
            let startPage = Math.max(1, currentPageCall - range);
            let endPage = Math.min(lastPage, currentPageCall + range);

            // Generate page numbers
            for (let i = startPage; i <= endPage; i++) {
                pageButtons += `<li class="page-item ${i === currentPageCall ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
            }

            // Add the pagination buttons and page numbers
            paginationContainer.insertAdjacentHTML('beforeend', `
                <nav aria-label="Page navigation example">
                    <ul class="pagination">
                        ${firstButton}
                        ${prevButton}
                        ${pageButtons}
                        ${nextButton}
                        ${lastButton}
                    </ul>
                </nav>
            `);

            // Update perpage dropdown if changed
            document.getElementById('perpage').value = perpage;
        }

        function debounceSearch(e) {
            if (e.keyCode === 13) {
                loadThemes(1);  // Trigger the search when the user presses enter
            }
        }

        // Debounce function to handle input changes
        let debounceTimeout;
        function debounce(fn, delay) {
            return function() {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(fn, delay);
            };
        };

  

        // SearchBar
        document.getElementById('search_filter').addEventListener('input', function() {
            const searchValue = document.getElementById('search_filter').value;
            if (searchValue) {
                document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
            } else {
                document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
            }
        });

        // Listen for changes in the perpage dropdown and reload data
        document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

        // Listen for Enter key in the search filter and reload data
        document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

        document.getElementById('refreshSearch').addEventListener('click', function() {
            document.getElementById('search_filter').value = '';  // Clear the search input
            loadThemes(1);  // Reload the table data without the search filter
        });

        document.getElementById('searchSubmit').addEventListener('click', function() {
            loadThemes(1);  // Reload the table data without the search filter
        });

        document.getElementById('filterSubmit').addEventListener('click', function() {
            loadThemes(1);  // Reload the table data without the search filter
        });

        // Initial load
        loadThemes(1);

    </script>
    <script>
        function toggleAudio(box){

                const audio = box.querySelector("audio");
                const icon = box.querySelector(".wa-play i");
                const progress = box.querySelector(".wa-progress");
                const current = box.querySelector(".wa-current");

                if(audio.paused){

                    document.querySelectorAll(".wa-player").forEach(function(a){

                        if(a!==audio){

                            a.pause();

                            const parent=a.closest(".wa-audio");

                            if(parent){

                                parent.querySelector(".wa-play i").className="mdi mdi-play";
                            }

                        }

                    });

                    audio.play();

                    icon.className="mdi mdi-pause";

                }else{

                    audio.pause();

                    icon.className="mdi mdi-play";

                }

                audio.ontimeupdate=function(){

                    if(audio.duration){

                        progress.style.width=(audio.currentTime/audio.duration)*100+"%";

                        current.innerHTML=formatTimeAudio(audio.currentTime);

                    }

                }

                audio.onended=function(){

                    icon.className="mdi mdi-play";

                    progress.style.width="0%";

                    current.innerHTML="00:00";

                }

            }

            function formatTimeAudio(sec){

                sec=Math.floor(sec);

                let m=Math.floor(sec/60);

                let s=sec%60;

                return String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");

            }
    </script>
@endsection