@extends('layouts/layoutMaster')

@section('title', 'Add NewsBroadcast')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection
@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')
     @vite(['resources/assets/js/forms_date_time_pickers.js'])

@endsection
@section('content')
<!-- Users List Table -->
  @php
    $helper = new \App\Helpers\Helpers();
    $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id ?? 1;
    $Header_branch_data = $helper->get_branch_id($selectedBranch);
    $general_setting = $helper->general_setting_data();
  @endphp
  <style>
      #ent_wrapper_preview_setting.ent_wrapper{
          z-index:1;
      }
      .flatpickr-calendar {
          z-index: 99999999999 !important; /* Ensures it appears on top of other elements */
        }

        .select2-results__group {
            color: #beb63c; /* Primary blue color */
            font-weight: bold;
        }

        /* Example: Customizing options */
        .select2-results__option {
            color: #333;
        }
  </style>
<div class="row">
    <div class="col-xl-12">
        
        <div class="card">
            <div class="card-body">
                <div class="tab-content p-0">

                    <!--begin:: Tools tab-->
                    <div class="tab-pane fade show active" id="tab_tools" role="tabpanel">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_tools">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Tools
                            </a> -->
                        </div>
                         <h3 class="mb-4">Create News Broadcast</h3>
                        <div class="row mb-4 px-4">
                        <!--  News Items Wrapper -->
                        <!--<div class="" >-->
                        <!--  <div id="news_items_wrapper">-->
                        <div class="news_item">
                              <div class="row">
                                <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Title<span class="text-danger">*</span></label>
                                  <input type="text" class="form-control news_prefix" id="news_prefix" placeholder="Title">
                                  <div class="text-danger news_prefix_err"></div>
                                </div>
                                <!-- <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                                  <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" class="form-control news_date common_date_cust_class" id="news_date" placeholder="Date">
                                  </div>
                                  <div class="text-danger news_date_err"></div>
                                </div> -->
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="news_date" name="news_date" placeholder="Select Date"
                                            class="form-control common_datepicker news_date" readonly  />
                                            
                                    </div>
                                    <div class="text-danger" id="news_date_err"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Content<span class="text-danger">*</span></label>
                                  <textarea  class="form-control news_heading" id="news_heading" placeholder="Content"></textarea>
                                  <div class="text-danger news_heading_err"></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                  <input type="text" class="form-control news_url" id="news_url" placeholder="URL" value="#">
                                </div>
                                <!--<div class="col-lg-12 text-end">-->
                                <!--  <button type="button" class="btn btn-outline-danger remove_news_item d-none">-->
                                <!--    <i class="mdi mdi-delete fs-4"></i>-->
                                <!--  </button>-->
                                <!--</div>-->
                              </div>
                               <div class="divider divider-primary mb-2 mt-3">
                                <!--<div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>-->
                            </div>
                            </div>
                        <!--  </div>-->
                        <!--</div>-->
                        <div class="row mb-2">
                            <!--<div class="col-lg-4 mb-3">-->
                            <!--  <label class="text-black mb-1 fs-6 fw-semibold">Templete Name<span class="text-danger">*</span></label>-->
                            <!--  <input type="text" class="form-control" placeholder="Templete Name" name="template_name" id="template_name" >-->
                            <!--  <div class="text-danger " id="template_name_err"></div>-->
                            <!--</div>-->
                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                              <select class="select3 form-select" id="company_id" name="company_id[]" multiple data-placeholder="Select Company">
                                  <option value="All">All</option>
                                  <option value="0">Elysium Groups</option>
                                  @if(isset($company_list))
                                    @foreach($company_list as $clist)
                                        <option value="{{$clist->sno}}" >{{$clist->company_name}}</option>
                                    @endforeach
                                  @endif
                                 
                              </select>
                             <div class="text-danger" id="company_id_err"></div>
                          </div>
                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                              <select class="select3 form-select" id="entity_id" name="entity_id[]" multiple data-placeholder="Select Entity">
                                  <option value="All">All</option>
                              </select>
                             <div class="text-danger" id="entity_id_err"></div>
                          </div>

                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                              <select class="select3 form-select" id="branch_id_new" name="branch_id_new[]" multiple data-placeholder="Select Entity">
                                  <option value="All">All</option>
                              </select>
                             <div class="text-danger" id="branch_id_new_err"></div>
                          </div>
                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">User Role<span class="text-danger">*</span></label>
                              <select class="select3 form-select" id="role_id" name="role_id[]" multiple data-placeholder="Select User Role">
                                  <option value="All">All</option>
                              </select>
                             <div class="text-danger" id="role_id_new_err"></div>
                          </div>
                          
                          <!-- <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Entity<span class="text-danger">*</span></label>
                              <select class="select3 form-select" id="branch_id" name="branch_id" multiple data-placeholder="Select Branch">
                                  <option value="All">All Entity</option>
                                  <optgroup label="{{$general_setting->company_short_name}}" class="fw-bold" >
                                    <option value="0">{{$general_setting->title}}</option>
                                  </optgroup>
                                  @foreach ($entity_list as $elist)
                                  <optgroup label="{{$elist->entity_short_name}}" class="fw-bold">
                                      @foreach ($branch_list as $blist)
                                          @if ($elist->sno == $blist->entity_id)
                                              <option value="{{ $blist->sno }}">{{ $blist->branch_name ?? '-' }}</option>
                                          @endif
                                      @endforeach
                                  </optgroup>
                                  @endforeach
                              </select>
                              <div class="text-danger" id="branch_id_err"></div>
                          </div>
                          <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">User Role<span class="text-danger">*</span></label>
                            <select name="role_id_navbar"
                                class="select3 form-select"
                                id="roleSelectsAddIds"
                                multiple
                                data-placeholder="Select Role">

                                <option value="all">All Roles</option>

                                <optgroup label="{{$general_setting->company_short_name}}"
                                          data-entity-id="0"
                                          class="fw-bold">
                                    @foreach ($roleList as $role)
                                        @if ($role->entity_id == 0)
                                            <option value="{{ $role->sno }}">{{ $role->role_name }}</option>
                                        @endif
                                    @endforeach
                                </optgroup>

                                @foreach ($entity_list as $elist)
                                    <optgroup label="{{$elist->entity_name}}"
                                              data-entity-id="{{ $elist->sno }}"
                                              class="fw-bold">
                                        @foreach ($roleList as $role)
                                            @if ($role->entity_id == $elist->sno)
                                                <option value="{{ $role->sno }}">{{ $role->role_name }}</option>
                                            @endif
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            </select>

                              <div class="text-danger" id="roleSelectsAddIds_err"></div>
                          </div> -->
                          
                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Templete Start date<span class="text-danger">*</span></label>
                              <input type="text" class="form-control common_date_time_class " placeholder="Templete Start date " name="start_date" id="start_date" readonly>
                              <div class="text-danger " id="start_date_err"></div>
                          </div>
                          <div class="col-lg-4 mb-3">
                              <label class="text-black mb-1 fs-6 fw-semibold">Templete End date<span class="text-danger">*</span></label>
                              <input type="text" class="form-control common_date_time_class" name="end_date" id="end_date" placeholder="Templete End date " readonly>
                              <div class="text-danger " id="end_date_err"></div>
                          </div>
                          <input type="hidden" name="theme_id" id="theme_id" value="{{$theme_id ?? 0}}" />
                          <!--<div class="col-lg-4 mb-3">-->
                          <!--  <label class="text-black mb-1 fs-6 fw-semibold">Theme<span class="text-danger">*</span></label>-->
                          <!--  <select class="select3 form-select" name="theme_id" id="theme_id">-->
                          <!--      <option value="">Select Theme</option>-->
                          <!--      @foreach ($theme_list as $theme)-->
                          <!--      <option value="{{ $theme->sno }}" >{{$theme->theme_name }}</option>-->
                          <!--      @endforeach-->
                          <!--  </select>-->
                          <!--   <div class="text-danger" id="theme_id_err"></div>-->
                          <!--</div>-->
                        </div>
                          <!-- Add Button -->
                          <div class="text-end mt-3">
                            <!--<button type="button" class="btn btn-primary btn-sm" id="add_news_item">+ Add More</button>-->
                            <!--<button type="button" id="update_ent_preview" name="update_ent_preview" value="save" class="btn btn-primary btn-md" >Preview</button>-->
                          </div>

  
        
        
                      </div>
                      <div id="section_contain_setting" class="mb-4 px-4">
                              <div id="ent_wrapper_preview_setting"></div>
                      </div>
                      <div class="d-flex justify-content-end mt-4 mb-2 px-4">
                        <div class="create_templatebtn"> 
                          <button type="button" id="create_btn" name="create_btn" class="create_btn btn btn-primary btn-md" >Create Template</button>
                        </div>
                      </div>
                  </div>
                    <!--end:: Tools tab-->
                </div>
            </div>
        </div>
    </div>
   
</div>



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>

  fieldset.custom-fieldset {
  border: 1px solid #ccc !important;
  padding: 1rem !important;
  border-radius: 5px;
}

fieldset.custom-fieldset legend {
  width: auto !important;
  padding: 0 10px !important;
  font-size: 1rem !important;
  font-weight: bold;
  color: #333;
}
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>

<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    $(".course_view_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive scroll-y max-h-200px'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>


  @php
   $helper = new \App\Helpers\Helpers();
  $settings = $helper->showTicker();
  @endphp
<script>
  var settings = {};  
var themes = [];
   $(document).ready(function () {

       var isRtl = $("html").attr("dir") === "rtl";

       $(".common_date_time_class").flatpickr({
          enableTime: true,
          dateFormat: "d-M-Y h:i K",  // Use 'h' for 12-hour format and 'K' for AM/PM
          defaultDate: new Date(),
          minDate: "today",
          position: isRtl ? "auto right" : "auto left",
          onOpen: function(selectedDates, dateStr, instance) {
            // Dynamically set z-index when flatpickr calendar opens
            instance.calendarContainer.style.zIndex = 99999999999; // Set z-index dynamically
          }
        });
        
    
        $(".common_date_cust_class").flatpickr({
             dateFormat: "d-M-Y",
            position: isRtl ? "auto right" : "auto left"
        });
        
               $("#ent_wrapper_preview_setting").empty();


      function getSettings(customNews) {
        var news, updateNews, i;
        settings = {
          position: 'fixed' ,
          height: 50,
          theme: 1,
          margin: '0px',
          roundness: 0,
          shadow: {
            enable: false,
            type: 1,
            reverse: false
          },
          animation: {
            effect: 'scroll',
            scroll_speed: parseInt($('#animation-scroll_speed').val()),
            easing: "easeInOutCirc",
            duration:500,
            delay: 2000
          },
          data: null,
          label: {
            onMobile: {
              enable: true
            },
            enable: true,
            padding: '15px',
            fontFamily: "Roboto",
            fontSize: 14,
            fontWeight: "700",
            background: "#DA0037",
            color: "#EEE",
            text: "News",
            logo: ""
          },
          news: {
            background: "#EEE",
            padding: "0 15px",
            prefix: {
              enable: true,
              fontFamily: "Roboto",
              fontSize: 14,
              fontWeight: "700",
              background: "#444",
              color: "#EEE",
              roundness:5,
              padding: "5px 10px"
            },
            date: {
              enable: true,
              fontFamily: "Roboto",
              fontSize: 14,
              fontWeight: "700",
              background: "none",
              color: $('#news-date-color').val(),
              roundness: 0,
              padding: "0px"
            },
            heading: {
              color: "#171717",
              fontFamily: "Roboto",
              fontSize: 16,
              fontWeight: "400"
            },
            separator: {
              size: 10,
              background: "#DA0037"
            }
          },
          navigation: {
            onMobile: {
              enable: true
            },
            enable: true,
            autohide: false,
            padding: "15px",
            background: "#171717",
            color: "#EEE",
            hover: "#EEE"
          }
        };

        var defaultNews = [
          { 
            date: 'September 30, 2025', 
            prefix: 'Event Update', 
            heading: 'Elysium Employee Appreciation Day: Join us on October 22nd for a company-wide virtual event to celebrate our amazing team!',
            url: ''
          },
          { 
            date: 'September 25, 2025', 
            prefix: 'HR Announcement', 
            heading: 'Upcoming Holiday: The office will be closed on December 24th for Christmas Eve and January 1st for New Year\'s Day.',
            url: ''
          }
        ];


      var updateNews = customNews && customNews.length > 0 ? customNews : defaultNews;

        if (!settings.news.prefix.enable) {
          for (i = 0; i < updateNews.length; i++) {
            delete updateNews[i].prefix;
          }
        }
        if (!settings.news.date.enable) {
          for (i = 0; i < updateNews.length; i++) {
            delete updateNews[i].date;
          }
        }
        settings.data = updateNews;
      }
      
      var settings, themes;
        themes = [
          {
            label: {
              background: '#DA0037',
              color: '#EEE'
            },
            news: {
              background: '#EEE',
              heading: {
                color: '#171717'
              },
              separator: {
                background: '#DA0037'
              },
              prefix: {
                background: '#444',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#444'
              }
            },
            navigation: {
              background: '#171717',
              color: '#EEE',
              hover: '#EEE'
            }
          },
          {
            label: {
              background: '#DA0037',
              color: '#EEE'
            },
            news: {
              background: '#171717',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#DA0037'
              },
              prefix: {
                background: '#DA0037',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#EEE'
              }
            },
            navigation: {
              background: '#EEEEEE',
              color: '#171717',
              hover: '#171717'
            }
          },
          {
            label: {
              background: '#1B1A17',
              color: '#F0A500'
            },
            news: {
              background: '#F0A500',
              heading: {
                color: '#1B1A17'
              },
              separator: {
                background: '#1B1A17'
              },
              prefix: {
                background: '#1B1A17',
                color: '#F0A500'
              },
              date: {
                background: 'none',
                color: '#1B1A17'
              }
            },
            navigation: {
              background: '#1B1A17',
              color: '#EEE',
              hover: '#F0A500'
            }
          },
          {
            label: {
              background: '#F0A500',
              color: '#1B1A17'
            },
            news: {
              background: '#1B1A17',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#F0A500'
              },
              prefix: {
                background: '#EEE',
                color: '#1B1A17'
              },
              date: {
                background: 'none',
                color: '#F0A500'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#1B1A17',
              hover: '#F0A500'
            }
          },
          {
            label: {
              background: '#222831',
              color: '#EEE'
            },
            news: {
              background: '#00ADB5',
              heading: {
                color: '#222831'
              },
              separator: {
                background: '#222831'
              },
              prefix: {
                background: '#EEE',
                color: '#00ADB5'
              },
              date: {
                background: 'none',
                color: '#222831'
              }
            },
            navigation: {
              background: '#222831',
              color: '#EEE',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#00ADB5',
              color: '#EEE'
            },
            news: {
              background: '#222831',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#00ADB5'
              },
              prefix: {
                background: '#EEE',
                color: '#00ADB5'
              },
              date: {
                background: 'none',
                color: '#EEE'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#222831',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#FF5722',
              color: '#EEE'
            },
            news: {
              background: '#303841',
              heading: {
                color: '#EEE'
              },
              separator: {
                background: '#FF5722'
              },
              prefix: {
                background: '#00ADB5',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#FF5722'
              }
            },
            navigation: {
              background: '#EEE',
              color: '#303841',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#FF5722',
              color: '#EEE'
            },
            news: {
              background: '#EEEEEE',
              heading: {
                color: '#303841'
              },
              separator: {
                background: '#FF5722'
              },
              prefix: {
                background: '#00ADB5',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#FF5722'
              }
            },
            navigation: {
              background: '#303841',
              color: '#EEE',
              hover: '#00ADB5'
            }
          },
          {
            label: {
              background: '#EEE',
              color: '#FF5722'
            },
            news: {
              background: '#FF5722',
              heading: {
                color: '#222831'
              },
              separator: {
                background: '#222831'
              },
              prefix: {
                background: '#222831',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#222831'
              }
            },
            navigation: {
              background: '#303841',
              color: '#EEE',
              hover: '#FF5722'
            }
          },
          {
            label: {
              background: '#14274E',
              color: '#EEE'
            },
            news: {
              background: '#F1F6F9',
              heading: {
                color: '#14274E'
              },
              separator: {
                background: '#9BA4B4'
              },
              prefix: {
                background: '#9BA4B4',
                color: '#EEE'
              },
              date: {
                background: 'none',
                color: '#9BA4B4'
              }
            },
            navigation: {
              background: '#9BA4B4',
              color: '#14274E',
              hover: '#EEE'
            }
          }
        ];
    
    getSettings()

 function applyThemeAndPreview(customNews) {
        var theme_id = $('#theme_id').val();

        // rebuild settings (base)
        getSettings(customNews);
    
        if (theme_id > 0) {
            // fetch theme from DB
            $.ajax({
                url: "/broadcast_theme_by_id",
                type: "GET",
                data: { theme_id: theme_id },
                success: function (response) {
                    if (response.status === "200" && response.data) {
                        // merge DB theme into settings
                          var themeIndex = parseInt(response.data.theme) - 1;
                        $.extend(true, settings, response.data);
                    }
                    // re-init ticker
                    $('#ent_wrapper_preview_setting').html('').removeClass();
                    $('#ent_wrapper_preview_setting').easyNewsTicker(settings);
                },
                error: function (xhr) {
                    console.error("Theme fetch error:", xhr.responseText);
                    toastr.error("Error fetching theme.");

                    // fallback to base settings
                    $('#ent_wrapper_preview_setting').html('').removeClass();
                    $('#ent_wrapper_preview_setting').easyNewsTicker(settings);
                }
            });
        } else {
            // no theme selected → just base settings
            $('#ent_wrapper_preview_setting').html('').removeClass();
            $('#ent_wrapper_preview_setting').easyNewsTicker(settings);
        }
    }

    // ==============================
    // THEME CHANGE
    // ==============================
    // $('#theme_id').on('change', function () {
     $(document).ready(function () {
        
        var currentNews = [];
        $(".news_item").each(function () {
            var date = $(this).find(".news_date").val();
            var prefix = $(this).find(".news_prefix").val();
            var heading = $(this).find(".news_heading").val();
            var url = $(this).find(".news_url").val();

            if (heading) {
                currentNews.push({
                    date: date,
                    prefix: prefix,
                    heading: heading,
                    url: url || ""
                });
            }
        });

        applyThemeAndPreview(currentNews);
     });

    // ==============================
    // PREVIEW BUTTON
    // ==============================
    
    
    // $('#update_ent_preview').on('click', function () {
    //     var dynamicNews = [];
    //     $(".news_item").each(function () {
    //         var date = $(this).find(".news_date").val() || '';
    //         var prefix = $(this).find(".news_prefix").val() || '';
    //         var heading = $(this).find(".news_heading").val() || '';
    //         var url = $(this).find(".news_url").val() || '';

    //         // if (heading) {
    //             dynamicNews.push({
    //                 date: date,
    //                 prefix: prefix,
    //                 heading: heading,
    //                 url: url || ""
    //             });
    //         // }
    //     });

    //     applyThemeAndPreview(dynamicNews);
    // });
    
    function collectDynamicNews() {
        var dynamicNews = [];
        
        $(".news_item").each(function () {
            var date = $(this).find(".news_date").val() || '';
            var prefix = $(this).find(".news_prefix").val() || '';
            var heading = $(this).find(".news_heading").val() || '';
            var url = $(this).find(".news_url").val() || '';
    
            dynamicNews.push({
                date: date,
                prefix: prefix,
                heading: heading,
                url: url || ""
            });
        });
    
        return dynamicNews;
    }
    
    // Function to handle the preview generation
    function handlePreview() {
        var dynamicNews = collectDynamicNews();
        applyThemeAndPreview(dynamicNews);
    }
    
    // jQuery to bind onkeyup events to all relevant fields
    $(document).ready(function() {
        // Bind onkeyup event to all input and textarea elements related to news
        $('#news_prefix, #news_heading, #news_url').on('keyup', function() {
            handlePreview();  // Trigger the handlePreview function on keyup
        });
        $('#news_date').on('change', function() {
            handlePreview();  // Trigger the handlePreview function on keyup
        });
    });

    // first-time init
    getSettings();
    $('#ent_wrapper_preview_setting').easyNewsTicker(settings);
    });
    

//   $(document).ready(function () {
//   // Add new news item
//   $("#add_news_item").on("click", function () {
//     var newItem = $(".news_item").first().clone();

//     // clear values for all fields
//     newItem.find("input").val("");
//     newItem.find("textarea").val(""); // ✅ clear textarea (content)
//     newItem.find(".news_url").val("#");
//     newItem.find(".text-danger").text(""); // clear errors

//     // show remove button
//     newItem.find(".remove_news_item").removeClass("d-none");

//     // append to wrapper
//     $("#news_items_wrapper").append(newItem);

//     // re-init flatpickr for new date field
//     newItem.find(".common_date_cust_class").flatpickr({
//       dateFormat: "d-M-Y",
//       position: $("html").attr("dir") === "rtl" ? "auto right" : "auto left"
//     });
//   });

//   // Remove news item
//   $(document).on("click", ".remove_news_item", function () {
//     $(this).closest(".news_item").remove();
//   });
// });


$("#create_btn").on("click", function () {
  // collect data same as before...

  var err=0;
     var company_ids = $("#company_id").val();
      if (company_ids && company_ids.includes("All")) company_ids = "all";

     var entity_ids = $("#entity_id").val();
      if (entity_ids && entity_ids.includes("All")) entity_ids = "all";

     var branch_ids = $("#branch_id_new").val();
      if (branch_ids && branch_ids.includes("All")) branch_ids = "all";
    
      var role_ids = $("#role_id").val();
      if (role_ids && role_ids.includes("All")) role_ids = "all";
    
      var start_date = $("#start_date").val();
      var end_date   = $("#end_date").val();
    //   var template_name = $("#template_name").val();
      var template_name =$("#news_prefix").val() ;
      var broadcast_message =$("#news_heading").val() ;
      var theme_id = $("#theme_id").val();
    
      // === BASIC VALIDATION ===
   
    
      if (!company_ids || company_ids.length === 0) {
        $("#company_id_err").text("Company is required...!");
        err++;
      } else {
        $("#company_id_err").text("");
      }
        if (company_ids.length === 1 && company_ids.includes("0")) {
           $("#entity_id_err").text("");
           $("#branch_id_new_err").text("");
        }else{
          if (!entity_ids || entity_ids.length === 0) {
            $("#entity_id_err").text("Entity is required...!");
            err++;
          } else {
            $("#entity_id_err").text("");
          }

          if (!branch_ids || branch_ids.length === 0) {
            $("#branch_id_new_err").text("Branch is required...!");
            err++;
          } else {
            $("#branch_id_new_err").text("");
          }
        }
      
    
      if (!role_ids || role_ids.length === 0) {
        $("#role_id_new_err").text("Role is required...!");
        err++;
      } else {
        $("#role_id_new_err").text("");
      }
    
      if (start_date === "") {
        $("#start_date_err").text("Start Date is required...!");
        err++;
      } else {
        $("#start_date_err").text("");
      }
    
      if (end_date === "") {
        $("#end_date_err").text("End Date is required...!");
        err++;
      } else {
        $("#end_date_err").text("");
      }
      
      if (start_date !== "" && end_date !== "") {
          var start = new Date(start_date);
          var end   = new Date(end_date);
        
          if (start >= end) {
            $("#end_date_err").text("End Date must be greater than Start Date...!");
            err++;
          }
        }
        
        if (theme_id.trim() === "") {
            $("#theme_id_err").text("Theme is required...!");
            err++;
          } else {
            $("#theme_id_err").text("");
          }

         var news_data = [];
        var news_err = 0;
        $(".news_item").each(function () {
          var date    = $(this).find(".news_date").val();
          var prefix  = $(this).find(".news_prefix").val();
          var heading = $(this).find(".news_heading").val();
          var url     = $(this).find(".news_url").val();

          // title validation
          if (prefix.trim() === "") {
            $(this).find(".news_prefix_err").text("Title is required...!");
            news_err++;
          } else {
            $(this).find(".news_prefix_err").text("");
          }

          // content validation
          if (heading.trim() === "") {
            $(this).find(".news_heading_err").text("Content is required...!");
            news_err++;
          } else {
            $(this).find(".news_heading_err").text("");
          }

          if (heading.trim() && prefix.trim()) {
            news_data.push({
              date: date,
              prefix: prefix,
              heading: heading,
              url: url || ""
            });
          }
        });
  

        if (news_err > 0) err++;
  
          if (err === 0) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
        
            $.ajax({
              url: "/check_news_broadcast_dates",
              method: "POST",
              headers: {
                "X-CSRF-TOKEN": csrfToken
              },
              data: {
                start_date: start_date,
                end_date: end_date
              },
              success: function (response) {
                if (response.conflict) {
                  // Example: response.message = "Start & End Date already used between 2025-09-08 12:00:00 and 2025-09-09 15:00:00"
                  toastr.error(response.message);
                } else {
                  // ✅ safe to proceed with save
                  saveTemplate(company_ids,entity_ids,branch_ids, role_ids, start_date, end_date, news_data,template_name,theme_id,broadcast_message);
                }
              },
              error: function (xhr) {
                console.error("Date validation failed:", xhr.responseText);
                toastr.error("Error validating dates. Please try again.");
              }
            });
         }
});


function saveTemplate(company_ids,entity_ids,branch_ids, role_ids, start_date, end_date, news_data,template_name,theme_id,broadcast_message) {
  var payload = {
    company_ids: company_ids,
    entity_ids: entity_ids,
    branch_ids: branch_ids,
    template_name: template_name,
    broadcast_message: broadcast_message,
    theme_id: theme_id,
    role_ids: role_ids,
    start_date: start_date,
    end_date: end_date,
    information: JSON.stringify(news_data),
  };

  const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute("content");

  $.ajax({
    url: "/broadcast_template_create",
    method: "POST",
    headers: {
      "X-CSRF-TOKEN": csrfToken
    },
    data: payload,
    success: function () {
      toastr.success("Template saved successfully!");
       window.location.href = '/communication_tool/news_broadcast'; 
    },
    error: function (xhr) {
      console.error("Save failed:", xhr.responseText);
      toastr.error("Error saving template. Please check console.");
    }
  });
}


</script>


<script>
$(document).ready(function () {

    $('#branch_id').on('change', function () {

        let selectedEntities = $(this).val() || [];
        // Reset role selection
        $('#roleSelectsAddIds').val(null).trigger('change');

        $('#roleSelectsAddIds optgroup').each(function () {

            let groupEntityId = $(this).data('entity-id');

            // Company level roles always visible
            if (groupEntityId === 0) {
                $(this).show();
                return;
            }

            // Show group if entity selected
            if (
                selectedEntities.includes('All') ||
                selectedEntities.includes(String(groupEntityId))
            ) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });

        // Refresh Select2 / Select3
        $('#roleSelectsAddIds').select2();
    });

});
</script>

<!-- <script>
  $(document).ready(function() {
        // Business dropdown
        $('#company_id').on('change', function () {

            let companyIds = $(this).val() || [];

            $('#entity_id').empty().append('<option value="All">All</option>');
            $('#branch_id_new').empty().append('<option value="All">All</option>');
            // $('#trainer').empty().append('<option value="">Select Trainer</option>');

            // ✅ If ONLY EGC selected
            if (companyIds.length === 1 && companyIds.includes("0")) {

                $('#entity_id').closest('.col-lg-4').hide();
                $('#branch_id_new').closest('.col-lg-4').hide();

                updateRole([0]); // Directly call with branch 0
                return;
            }else{
               $('#entity_id').closest('.col-lg-4').show();
                $('#branch_id_new').closest('.col-lg-4').show();
            }

            // Show entity & branch if not only EGC
            $('#entity_id').closest('.col-lg-4').show();
            $('#branch_id_new').closest('.col-lg-4').show();

            if (companyIds.length === 0) return;

            $.ajax({
                url: "{{ route('entity_list_multiple_newsbroadcast') }}",
                type: "GET",
                data: { company_id: companyIds },
                success: function (response) {

                    if (response.status === 200) {

                        response.data.forEach(function (entity) {

                            $('#entity_id').append(
                                `<option value="${entity.sno}">
                                    ${entity.entity_name}
                                </option>`
                            );

                        });

                    }
                }
            });

        });
        // branch list
        $('#entity_id').on('change', function () {

            let entityIds = $(this).val();

            $('#branch_id_new').empty().append('<option value="All">All</option>');
            $('#role_id').empty().append('<option value="All">All</option>');

            if (!entityIds) return;

            $.ajax({

                url: "{{ route('branch_list_multiple_newsbroadcast') }}",
                type: "GET",
                data: { entity_id: entityIds },

                success: function (response) {

                    if (response.status === 200) {

                        response.data.forEach(function (branch) {

                            $('#branch_id_new').append(
                                `<option value="${branch.sno}">
                                    ${branch.branch_name}
                                </option>`
                            );

                        });

                    }

                }

            });
            $.ajax({

                url: "{{ route('user_role_list_multiple') }}",
                type: "GET",
                data: { entity_id: entityIds },

                success: function (response) {

                    if (response.status === 200) {

                        response.data.forEach(function (role) {

                            $('#role_id').append(
                                `<option value="${role.sno}">
                                    ${role.role_name}
                                </option>`
                            );

                        });

                    }

                }

            });

        });

         function updateRole(customEntityIds = null) {
            let entityIds = customEntityIds ?? $('#entity_id').val();
            if (!entityIds) return;
            $.ajax({
                url: "{{ route('user_role_list_multiple') }}",
                type: "GET",
                data: { entity_id: entityIds },

                success: function (response) {

                    $('#role_id').empty()
                        .append('<option value="All">All</option>');

                    response.data.forEach(function (role) {

                        $('#role_id').append(
                            `<option value="${role.sno}">
                                ${role.role_name}
                            </option>`
                        );

                    });

                }
            });
        }
    });

    
</script> -->
<script>
$(document).ready(function () {

    function resetDropdown(id){
        $(id).empty().append('<option value="All">All</option>');
    }

    // COMPANY CHANGE
    $('#company_id').on('change', function () {

        let companyIds = $(this).val() || [];
        let isAll = companyIds.includes("All");

        resetDropdown('#entity_id');
        resetDropdown('#branch_id_new');
        resetDropdown('#role_id');

        $('#entity_id').closest('.col-lg-4').show();
        $('#branch_id_new').closest('.col-lg-4').show();

        if (companyIds.length === 1 && companyIds.includes("0")) {
            // hide entity and branch
            $('#entity_id').closest('.col-lg-4').hide();
            $('#branch_id_new').closest('.col-lg-4').hide();
            // load roles for company 0
            updateRole([0],0);
            return;
        }

         $('#entity_id').closest('.col-lg-4').show();
        $('#branch_id_new').closest('.col-lg-4').show();
        //  if (companyIds.length === 0 || companyIds.includes("All")) return;

        $.ajax({
            url: "{{ route('entity_list_multiple_newsbroadcast') }}",
            type: "GET",
            data: {
                company_id: companyIds,
                all: isAll ? 1 : 0
            },

            success: function (response) {

                if (response.status === 200) {

                    let grouped = {};

                    response.data.forEach(function (row) {

                        let company = row.company_name ?? 'Elysium Groups';

                        if (!grouped[company]) grouped[company] = [];

                        grouped[company].push(row);

                    });

                    for (let company in grouped) {

                        let optgroup = $('<optgroup>', { label: company });

                        grouped[company].forEach(function (entity) {

                            optgroup.append(
                                `<option value="${entity.sno}">
                                    ${entity.entity_name}
                                </option>`
                            );

                        });

                        $('#entity_id').append(optgroup);
                    }

                }
            }
        });

    });

    // ENTITY CHANGE
    $('#entity_id').on('change', function () {

        let entityIds = $(this).val() || [];
        let isAll = entityIds.includes("All");

        resetDropdown('#branch_id_new');
        resetDropdown('#role_id');

        $.ajax({
            url: "{{ route('branch_list_multiple_newsbroadcast') }}",
            type: "GET",
            data: {
                entity_id: entityIds,
                all: isAll ? 1 : 0
            },

            success: function (response) {

                let grouped = {};

                response.data.forEach(function (row) {

                    let entity = row.entity_name ?? 'Unknown';

                    if (!grouped[entity]) grouped[entity] = [];

                    grouped[entity].push(row);

                });

                for (let entity in grouped) {

                    let optgroup = $('<optgroup>', { label: entity });

                    grouped[entity].forEach(function (branch) {

                        optgroup.append(
                            `<option value="${branch.sno}">
                                ${branch.branch_name}
                            </option>`
                        );

                    });

                    $('#branch_id_new').append(optgroup);
                }

            }
        });

        updateRole(entityIds, isAll);

    });


    function updateRole(entityIds, isAll){

    let companyIds = $('#company_id').val() || [];

    $.ajax({
        url: "{{ route('user_role_list_multiple') }}",
        type: "GET",
        data: {
            entity_id: entityIds,
            company_id: companyIds,
            all: isAll ? 1 : 0
        },

        success: function (response) {

            resetDropdown('#role_id');

            let grouped = {};

            response.data.forEach(function (row) {

                let company = row.company_name ?? 'Elysium Groups';

                if (!grouped[company]) grouped[company] = [];

                grouped[company].push(row);

            });

            for (let company in grouped) {

                let optgroup = $('<optgroup>', { label: company });

                grouped[company].forEach(function (role) {

                    optgroup.append(
                        `<option value="${role.sno}">
                            ${role.role_name}
                        </option>`
                    );

                });

                $('#role_id').append(optgroup);
            }

        }
    });

}

      // function updateRole(entityIds, isAll){

      //     $.ajax({
      //         url: "{{ route('user_role_list_multiple') }}",
      //         type: "GET",
      //         data: {
      //             entity_id: entityIds,
      //             all: isAll ? 1 : 0
      //         },

      //         success: function (response) {

      //             resetDropdown('#role_id');

      //             let grouped = {};

      //             response.data.forEach(function (row) {

      //                 let company = row.company_name ?? 'Elysium Groups';

      //                 if (!grouped[company]) grouped[company] = [];

      //                 grouped[company].push(row);

      //             });

      //             for (let company in grouped) {

      //                 let optgroup = $('<optgroup>', { label: company });

      //                 grouped[company].forEach(function (role) {

      //                     optgroup.append(
      //                         `<option value="${role.sno}">
      //                             ${role.role_name}
      //                         </option>`
      //                     );

      //                 });

      //                 $('#role_id').append(optgroup);
      //             }

      //         }
      //     });

      // }

});
</script>
@endsection