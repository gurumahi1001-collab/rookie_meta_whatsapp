@extends('layouts/layoutMaster')

@section('title', 'Manage Target')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
<style>
    .quarter-card {

        border-radius: 12px;
    }

    .month-card {
        background: #f4f6fb;
        border-radius: 10px;
        padding: 12px;
    }

    .week-box {

        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 8px;
    }





    .label {
        font-size: 11px;
        font-weight: 600;
        color: #6b7280;
    }

    .valid {
        border: 2px solid #28c76f;
    }

    .invalid {
        border: 2px solid #ea5455;
    }
</style>
<style>
    .current-quarter {
        border: 2px solid #ab2b22 !important;
        box-shadow: 0 0 20px rgba(115, 103, 240, .2);
    }

    .current-month-card {
        border: 2px solid #28c76f !important;
        background: linear-gradient(135deg, #e9fff3, #ffffff);
    }

    .current-week {
        border: 2px solid #ff9f43 !important;
        background: #fff8ef;
    }

    .year-sticky-bar {
        position: sticky;
        top: 0;
        z-index: 50;
        background: #fff;
        padding: 12px;
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, .06);
        margin-bottom: 20px;
    }

    .quarter-section {
        margin-bottom: 28px;
    }

    .quarter-title {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 14px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .quarter-scroll {
        display: flex;
        gap: 18px;
        overflow-x: auto;
        padding-bottom: 10px;
        scroll-behavior: smooth;
    }

    .quarter-scroll::-webkit-scrollbar {
        height: 8px;
    }

    .quarter-scroll::-webkit-scrollbar-thumb {
        background: #ccc;
        border-radius: 20px;
    }

    .month-card-modern {
        min-width: 340px;
        /* background: rgba(255, 255, 255, .75); */
        backdrop-filter: blur(10px);
        border-radius: 22px;
        padding: 18px;
        border: 1px solid rgba(255, 255, 255, .4);
        box-shadow: 0 10px 30px rgba(0, 0, 0, .08);
        transition: .3s ease;
        position: relative;
        background:
            linear-gradient(135deg,
                rgba(115, 103, 240, .15),
                rgba(255, 255, 255, .95));
    }

    /* .month-card-modern:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 40px rgba(0, 0, 0, .12);
    } */

    .month-card-modern.current-month {
        border: 3px solid #ab2b22;
        transform: scale(1.03);
        box-shadow: 0 20px 50px rgba(115, 103, 240, .25);

        background:
            linear-gradient(135deg,
                rgba(115, 103, 240, .25),
                rgba(255, 255, 255, 1));
    }

    .month-badge {
        position: absolute;
        top: 14px;
        right: 14px;
        background: #ab2b22;
        color: #fff;
        font-size: 11px;
        padding: 5px 12px;
        border-radius: 30px;
        font-weight: 700;
    }

    .month-title {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 18px;
    }

    .summary-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
        margin-bottom: 18px;
    }

    .summary-box {
        background: #f5f7fb;
        border-radius: 14px;
        padding: 12px;
        text-align: center;
    }

    .summary-label {
        font-size: 11px;
        color: #666;
        margin-bottom: 4px;
    }

    .summary-value {
        font-size: 18px;
        font-weight: 700;
    }

    .week-row {
        background: rgba(255, 255, 255, .9);
        border-radius: 18px;
        padding: 14px;
        margin-bottom: 12px;
        border: 1px solid rgba(255, 255, 255, .5);

        backdrop-filter: blur(8px);

        transition: .3s ease;
    }

    .week-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .week-no {
        font-weight: 700;
        color: #111;
    }

    .week-range {
        font-size: 12px;
        color: #ab2b22;
        font-weight: 600;
    }

    .week-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
    }

    .mini-input label {
        font-size: 11px;
        color: #666;
        margin-bottom: 3px;
    }

    .mini-input input {
        border-radius: 10px;
        font-size: 13px;
    }

    .quarter-q1 {
        color: #ab2b22;
    }

    .quarter-q2 {
        color: #28c76f;
    }

    .quarter-q3 {
        color: #ff9f43;
    }

    .quarter-q4 {
        color: #ea5455;
    }

    .quarter-wrapper {
        margin-bottom: 40px;
    }

    .quarter-tabs {
        display: flex;
        margin-bottom: 20px;
    }

    .quarter-tab {
        border: 0;
        padding: 12px 24px;
        border-radius: 14px;
        background: linear-gradient(135deg, #ab2b22, #ff9d96);
        color: #fff;
        font-weight: 700;
        box-shadow: 0 10px 25px rgba(115, 103, 240, .2);
    }

    .quarter-carousel-wrapper {
        position: relative;
        display: flex;
        align-items: center;
    }

    .carousel-nav {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        border: 0;
        background: #fff;
        box-shadow: 0 10px 30px rgba(0, 0, 0, .1);
        position: absolute;
        z-index: 20;
    }

    .carousel-nav.left {
        left: -20px;
    }

    .carousel-nav.right {
        right: -20px;
    }

    .modern-carousel {
        overflow-x: auto;
        scroll-behavior: smooth;
        padding: 10px 30px;
    }

    .big-card {
        min-width: 420px;
    }
</style>
<style>
    .month-slider {
        position: relative;
    }

    .month-slide {
        display: none;
        animation: fadeIn .25s ease;
    }

    .month-slide.active {
        display: block;
    }

    .month-tabs {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }

    .month-tab {
        padding: 6px 14px;
        border-radius: 30px;
        border: 1px solid #dfe3ea;
        background: #fff;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: 0.2s;
    }

    .month-tab.active {
        background: #ab2b22;
        color: #fff;
        border-color: #ab2b22;
    }

    .month-nav-btn {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        border: none;
        background: #f4f6fb;
        transition: .2s;
    }

    .month-nav-btn:hover {
        background: #ab2b22;
        color: #fff;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(8px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Target</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Entity Hub
                        </a>
                    </li>
                </ol>
            </nav>
        </div>

    </div>
    <div class="card-body">
        <div class="container-fluid">

            <!-- TOP BAR -->
            <div class="year-sticky-bar">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                    <div class="d-flex gap-2">
                        <div>
                            <label for="Year"></label>
                            <input type="text" id="year_picker" class="form-control w-150px" value="{{ date('Y') }}" placeholder="Select Year">
                        </div>

                        <div class="w-250px ">
                            <label for="entity"></label>
                            <select id="entity_id" class="form-select select3" onchange="changeEntity()">
                                @foreach($entity_list as $e)
                                <option value="{{ $e->sno }}">{{ $e->entity_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="w-250px ">
                            <label for="branch_id"></label>
                            <select id="branch_id" class="form-select select3" onchange="loadData()">

                            </select>
                        </div>



                    </div>

                    <div class="d-flex gap-2">
                        <input type="file" id="excel" hidden>

                        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_upload_target" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Upload">
                            <span class="me-2"><i class="mdi mdi-file-upload"></i></span>Upload Targets
                        </a>
                        <button type="button" id="saveBtn" onclick="saveAll()" class="btn btn-success btn-sm">
                            Save
                        </button>
                    </div>

                </div>
            </div>



            <!-- QUARTERS -->
            <div class="row g-3" id="quarters"></div>

            <!-- YEAR SUMMARY -->
            <div class="card p-3 my-3 bg-light border">
                <h5 class="mb-2">Year Summary</h5>
                <div class="row g-2">
                    <div class="col-md-4">
                        <label for="year_target" class="fs-4">Total Target</label>
                        <input type="text" id="year_target" class="form-control fs-4" placeholder="Total Target" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" value="0">
                    </div>
                    <div class="col-md-4">
                        <label for="year_pre" class="fs-4">Pre Sale</label>
                        <input type="text" id="year_pre" class="form-control fs-4" placeholder="Pre Sale" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="0">
                    </div>
                    <div class="col-md-4">
                        <label for="year_post" class="fs-4">Post Sale</label>
                        <input type="text" id="year_post" class="form-control fs-4" placeholder="Post Sale" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="0">
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="kt_modal_upload_target" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Upload Targets</h3>
                </div>
                <div class="text-end">
                        <span>
                            <label>Sample Download For Traget Import</label>
                            <a href="javascript:;" download="Target Data"  class="hover-warning cursor-pointer" title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger" title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                <form id="uploadMaterialForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                    @csrf
                    <div class="row mt-2">


                        <!-- File Upload -->
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Targets File<span class="text-danger">*</span></label>
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                                <p class="mb-2">Drag & Drop your files here or click to select</p>
                                <div class="small text-center mb-2">Allowed excel,.xls,.xlsx,.xlsm,.csv </div>
                                <input type="file" id="fileInput" name="file_upload" class="d-none" accept=".xls,.xlsx,.xlsm,.csv" />
                                <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('fileInput').click()">
                                    Browse Files
                                </button>
                            </div>
                            <div id="fileList" class="text-muted"></div>
                            <div class="text-danger" id="err_mssg"></div>
                        </div>
                    </div>

                    <!-- Footer -->
                    <div class="row">
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <div class="position-relative">
                                <button type="submit" class="btn btn-primary" id="uploadButton">
                                    <div class="d-flex gap-1">
                                        <div id="uploadLoader" class="import-loader d-none">
                                            <div class="spinner-border text-light" role="status"></div>
                                            <span class="ms-2"></span>
                                        </div>Upload
                                    </div>
                                </button>

                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<script>
    let weekSettings = @json($week_settings);
    changeEntity()

    function changeEntity() {
        var entity_id = $('#entity_id').val();
        var branchDropdown = $('#branch_id');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .text(state.branch_name));
                        });
                        loadData();

                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>
<script>
    const today = new Date();

    const currentMonth = today.toLocaleString('default', {
        month: 'long'
    });
    var yearFilter = document.getElementById('year_picker');
    var entity = document.getElementById('entity_id');
    const months = [{
            name: 'April',
            q: 'Q1'
        }, {
            name: 'May',
            q: 'Q1'
        }, {
            name: 'June',
            q: 'Q1'
        },
        {
            name: 'July',
            q: 'Q2'
        }, {
            name: 'August',
            q: 'Q2'
        }, {
            name: 'September',
            q: 'Q2'
        },
        {
            name: 'October',
            q: 'Q3'
        }, {
            name: 'November',
            q: 'Q3'
        }, {
            name: 'December',
            q: 'Q3'
        },
        {
            name: 'January',
            q: 'Q4'
        }, {
            name: 'February',
            q: 'Q4'
        }, {
            name: 'March',
            q: 'Q4'
        }
    ];


    // function getWeekRanges(monthName, year) {

    //     const monthIndex = new Date(`${monthName} 1, ${year}`).getMonth();
    //     const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

    //     return [
    //         `1 - 8`,
    //         `9 - 14`,
    //         `15 - 21`,
    //         `22 - ${daysInMonth}`
    //     ];
    // }
    // function getWeekRanges(monthName, year) {

    //     const monthIndex = new Date(`${monthName} 1, ${year}`).getMonth();

    //     const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

    //     return [{
    //             range: `1 - 10`,
    //             percentage: 40
    //         },
    //         {
    //             range: `11 - 17`,
    //             percentage: 30
    //         },
    //         {
    //             range: `18 - 24`,
    //             percentage: 25
    //         },
    //         {
    //             range: `25 - ${daysInMonth}`,
    //             percentage: 5
    //         }
    //     ];
    // }
    function getWeekRanges(monthName, year) {

        const monthIndex = new Date(`${monthName} 1, ${year}`).getMonth();

        const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

        return weekSettings.map(w => {

            let endDay = w.end_day === 'END' ?
                daysInMonth :
                w.end_day;

            return {
                week_no: w.week_no,
                week_name: w.week_name,
                range: `${w.start_day} - ${endDay}`,
                percentage: parseFloat(w.percentage)
            };
        });
    }
</script>
<script>
    // function renderUI() {

    //     let html = '';

    //     const currentMonth = new Date().toLocaleString('default', {
    //         month: 'long'
    //     });

    //     ['Q1', 'Q2', 'Q3', 'Q4'].forEach(q => {

    //         html += `
    //             <div class="quarter-wrapper">

    //                 <div class="quarter-tabs">
    //                     <button class="quarter-tab active">${q}</button>
    //                 </div>

    //                 <div class="quarter-carousel-wrapper">

    //                     <button class="carousel-nav left">
    //                         <i class="mdi mdi-chevron-left"></i>
    //                     </button>

    //                     <div class="quarter-scroll modern-carousel" id="scroll-${q}">
    //             `;

    //         months.filter(m => m.q == q).forEach(m => {

    //             let year = $('#year_picker').val();

    //             let weeks = getWeekRanges(m.name, year);

    //             let activeClass = currentMonth === m.name ?
    //                 'current-month' :
    //                 '';

    //             html += `
    //             <div class="month-card-modern big-card ${activeClass}" data-month="${m.name}">

    //                 ${currentMonth === m.name ? `
    //                     <div class="month-badge">
    //                         Current Month
    //                     </div>
    //                 ` : ''}

    //                 <div class="month-title">
    //                     ${m.name}
    //                 </div>

    //                 <div class="summary-grid">

    //                     <div class="summary-box">
    //                         <div class="summary-label">
    //                             Target
    //                         </div>

    //                         <input type="text"
    //                             class="form-control month-target"
    //                             value="0">
    //                     </div>

    //                     <div class="summary-box">
    //                         <div class="summary-label">
    //                             Pre Sale
    //                         </div>

    //                         <input type="text"
    //                             class="form-control month-pre"
    //                             value="0">
    //                     </div>

    //                     <div class="summary-box">
    //                         <div class="summary-label">
    //                             Post Sale
    //                         </div>

    //                         <input type="text"
    //                             class="form-control month-post"
    //                             value="0">
    //                     </div>

    //                 </div>
    //             `;

    //             for (let i = 0; i < 4; i++) {

    //                 html += `
    //                 <div class="week-row">

    //                     <div class="week-header">

    //                         <div class="week-no">
    //                             Week ${i+1}
    //                         </div>

    //                         <div class="week-range">
    //                             ${weeks[i]}
    //                         </div>

    //                     </div>

    //                     <div class="week-grid">

    //                         <div class="mini-input">
    //                             <label>%</label>
    //                             <input type="text"
    //                                 class="form-control week-per"
    //                                 value="25">
    //                         </div>

    //                         <div class="mini-input">
    //                             <label>Target</label>
    //                             <input type="text"
    //                                 class="form-control week-target"
    //                                 value="0">
    //                         </div>

    //                         <div class="mini-input">
    //                             <label>Pre</label>
    //                             <input type="text"
    //                                 class="form-control week-pre"
    //                                 value="0">
    //                         </div>

    //                         <div class="mini-input">
    //                             <label>Post</label>
    //                             <input type="text"
    //                                 class="form-control week-post"
    //                                 value="0">
    //                         </div>

    //                     </div>

    //                 </div>
    //                 `;
    //             }

    //             html += `
    //                 <div class="progress mt-3" style="height:8px;">
    //                     <div class="progress-bar bg-success per-bar"></div>
    //                 </div>

    //             </div>
    //             `;
    //         });

    //         html += `
    //                 </div>

    //                 <button class="carousel-nav right">
    //                     <i class="mdi mdi-chevron-right"></i>
    //                 </button>

    //             </div>
    //         </div>
    //         `;
    //     });

    //     document.getElementById('quarters').innerHTML = html;
    // }

    function renderUI() {

        let html = '';

        const now = new Date();

        const currentMonthName = now.toLocaleString('default', {
            month: 'long'
        });

        const currentDate = now.getDate();

        const currentYear = now.getFullYear();

        const selectedYear = parseInt($('#year_picker').val());

        let currentQuarter = '';

        if (['April', 'May', 'June'].includes(currentMonthName)) {
            currentQuarter = 'Q1';
        } else if (['July', 'August', 'September'].includes(currentMonthName)) {
            currentQuarter = 'Q2';
        } else if (['October', 'November', 'December'].includes(currentMonthName)) {
            currentQuarter = 'Q3';
        } else {
            currentQuarter = 'Q4';
        }

        ['Q1', 'Q2', 'Q3', 'Q4'].forEach(q => {

            let quarterMonths = months.filter(m => m.q === q);

            let defaultMonth = quarterMonths[0].name;

            if (selectedYear === currentYear) {

                let found = quarterMonths.find(m => m.name === currentMonthName);

                if (found) {
                    defaultMonth = currentMonthName;
                }
            }

            html += `
            <div class="col-md-6">

                <div class="card quarter-card p-3 mb-3 
                    ${q === currentQuarter && selectedYear === currentYear ? 'current-quarter' : ''}">

                    <div class="d-flex justify-content-between align-items-center mb-3">

                        <div>
                            <h5 class="mb-1">${q}</h5>

                            <small class="text-muted">
                                ${quarterMonths.map(x => x.name).join(', ')}
                            </small>
                        </div>

                        <div class="month-tabs">

                            ${quarterMonths.map(m => `

                                <div class="month-tab 
                                    ${m.name === defaultMonth ? 'active' : ''}"

                                    data-quarter="${q}"
                                    data-month="${m.name}"

                                    onclick="showMonthSlide('${q}','${m.name}',this)">

                                    ${m.name}

                                </div>

                            `).join('')}

                        </div>

                    </div>

                    <div class="month-slider">
            `;

            quarterMonths.forEach(m => {

                let weeks = getWeekRanges(m.name, selectedYear);

                let isCurrentMonth =
                    m.name === currentMonthName &&
                    selectedYear === currentYear;

                html += `
                <div class="month-slide 
                    ${m.name === defaultMonth ? 'active' : ''}"

                    data-quarter="${q}"
                    data-month="${m.name}">

                    <div class="month-card 
                        ${isCurrentMonth ? 'current-month-card' : ''}"

                        data-month-card="${m.name}">

                        <div class="d-flex justify-content-between align-items-center mb-3">

                            <div>
                                <h5>${m.name}</h5>

                                <small class="text-muted">
                                    Monthly Planning
                                </small>
                            </div>

                            ${isCurrentMonth ? `
                                <span class="badge bg-success">
                                    Current Month
                                </span>
                            ` : ''}

                        </div>

                        <div class="row g-3 mb-3">

                            <div class="col-md-4">
                                <label class="label">Target</label>

                                <input type="text"
                                    class="form-control month-target"
                                    value="0">
                            </div>

                            <div class="col-md-4">
                                <label class="label">Pre Sale</label>

                                <input type="text"
                                    class="form-control month-pre"
                                    value="0">
                            </div>

                            <div class="col-md-4">
                                <label class="label">Post Sale</label>

                                <input type="text"
                                    class="form-control month-post"
                                    value="0">
                            </div>

                        </div>

                        <div class="row g-3">
                `;

                weeks.forEach((week, i) => {

                    let isCurrentWeek = false;

                    if (isCurrentMonth) {

                        if (
                            (i === 0 && currentDate <= 10) ||
                            (i === 1 && currentDate >= 11 && currentDate <= 17) ||
                            (i === 2 && currentDate >= 18 && currentDate <= 24) ||
                            (i === 3 && currentDate >= 25)
                        ) {
                            isCurrentWeek = true;
                        }
                    }

                    html += `
                    <div class="col-md-3">

                        <div class="week-box 
                            ${isCurrentWeek ? 'current-week' : ''}">

                            <div class="text-center mb-2">

                                <div class="fw-bold text-primary">
                                    Week ${i + 1}
                                </div>
                                <div class="d-flex gap-1 align-items-center justify-content-center">
                                    <small class="text-muted week-range-badge">
                                        ${week.range}
                                    </small>
                                    <small class="week-percent-badge  text-info fs-9">
                                        (${week.percentage}%)
                                    </small>
                                </div>
                                

                            </div>

                            <!-- HIDDEN SPLIT -->
                            <input type="hidden"
                                class="week-per"
                                value="${week.percentage}">

                            <div class="mb-2">

                                <label class="label">
                                    Target
                                </label>

                                <input type="text"
                                    class="form-control form-control-sm week-target"
                                    value="0"
                                    readonly>

                            </div>

                            <div class="mb-2">

                                <label class="label">
                                    Pre Sale
                                </label>

                                <input type="text"
                                    class="form-control form-control-sm week-pre"
                                    value="0"
                                    readonly>

                            </div>

                            <div>

                                <label class="label">
                                    Post Sale
                                </label>

                                <input type="text"
                                    class="form-control form-control-sm week-post"
                                    value="0"
                                    readonly>

                            </div>

                        </div>

                    </div>
                    `;
                });

                html += `
                        </div>

                        <div class="progress mt-3" style="height:8px;">

                            <div class="progress-bar bg-success per-bar"
                                style="width:100%">
                            </div>

                        </div>

                    </div>

                </div>
                `;
            });

            html += `
                    </div>

                </div>

            </div>
            `;
        });

        $('#quarters').html(html);

        setTimeout(() => {

            document.querySelectorAll('.month-card').forEach(container => {
                calculateWeeklySplit(container);
            });

            calculateYearSummary();

        }, 100);
    }

    renderUI();

    document.addEventListener('click', function(e) {

        if (e.target.closest('.carousel-nav.left')) {

            let scroll = e.target.closest('.quarter-carousel-wrapper')
                .querySelector('.quarter-scroll');

            scroll.scrollBy({
                left: -400,
                behavior: 'smooth'
            });
        }

        if (e.target.closest('.carousel-nav.right')) {

            let scroll = e.target.closest('.quarter-carousel-wrapper')
                .querySelector('.quarter-scroll');

            scroll.scrollBy({
                left: 400,
                behavior: 'smooth'
            });
        }

    });


    setTimeout(() => {
        document.querySelectorAll('.month-card').forEach(container => {
            calculateWeeklySplit(container);
        });
    }, 200);
</script>
<script>
    document.addEventListener('input', function(e) {

        let container = e.target.closest('.month-card');
        if (!container) return;

        //  Trigger on ALL important inputs
        if (
            e.target.classList.contains('week-per') ||
            e.target.classList.contains('month-target') ||
            e.target.classList.contains('month-pre') ||
            e.target.classList.contains('month-post')
        ) {
            calculateWeeklySplit(container);
            calculateYearSummary();
        }



    });

    function splitInteger(total, percentages) {

        let raw = [];
        let values = [];
        let sum = 0;

        // Step 1: raw calculation
        percentages.forEach(p => {
            let val = (total * p) / 100;
            raw.push(val);
            let floored = Math.floor(val);
            values.push(floored);
            sum += floored;
        });

        // Step 2: remaining
        let diff = total - sum;

        // Step 3: distribute to highest decimal parts
        let decimals = raw.map((v, i) => ({
            index: i,
            decimal: v - Math.floor(v)
        }));

        decimals.sort((a, b) => b.decimal - a.decimal);

        for (let i = 0; i < diff; i++) {
            values[decimals[i].index]++;
        }

        return values;
    }
</script>

<script>
    function loadData() {
        let year = $('#year_picker').val();
        let entity = $('#entity_id').val();
        let branch_id = $('#branch_id').val();


        fetch(`/targets/data?year=${year}&entity=${entity}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {

                let data = res.data;

                // ✅ CHANGE BUTTON TEXT
                const btn = document.getElementById('saveBtn');

                if (res.is_existing) {
                    btn.innerText = 'Update';
                    btn.classList.remove('btn-primary');
                    btn.classList.add('btn-warning');
                } else {
                    btn.innerText = 'Save';
                    btn.classList.remove('btn-warning');
                    btn.classList.add('btn-primary');
                }

                // RESET UI
                renderUI();

                setTimeout(() => {

                    data.forEach(d => {

                        // let monthName = d.month?.month;
                        let monthName = getMonthName(d.month?.month);
                        let weekNo = d.week;

                        let monthDiv = document.querySelector(`[data-month-card="${monthName}"]`);
                        if (!monthDiv) return;

                        monthDiv.querySelectorAll('.week-per')[weekNo - 1].value = d.percentage;
                        monthDiv.querySelectorAll('.week-target')[weekNo - 1].value = d.target_amount;
                        monthDiv.querySelectorAll('.week-pre')[weekNo - 1].value = d.pre_sale;
                        monthDiv.querySelectorAll('.week-post')[weekNo - 1].value = d.post_sale;
                    });

                    let monthMap = {};

                    data.forEach(d => {
                        let m = d.month?.month;

                        if (!monthMap[m]) {
                            monthMap[m] = {
                                target: 0,
                                pre: 0,
                                post: 0
                            };
                        }

                        monthMap[m].target += parseFloat(d.target_amount) || 0;
                        monthMap[m].pre += parseInt(d.pre_sale) || 0;
                        monthMap[m].post += parseInt(d.post_sale) || 0;
                    });

                    Object.keys(monthMap).forEach(monthNum => {

                        let monthName = getMonthName(monthNum);
                        let container = document.querySelector(`[data-month-card="${monthName}"]`);

                        if (!container) return;

                        container.querySelector('.month-target').value = monthMap[monthNum].target;
                        container.querySelector('.month-pre').value = monthMap[monthNum].pre;
                        container.querySelector('.month-post').value = monthMap[monthNum].post;

                        // ✅ Recalculate split visuals
                        calculateWeeklySplit(container);
                    });

                    calculateYearSummary();

                }, 200);

            });
    }
</script>

<script>
    function getQuarter(month) {
        if (['April', 'May', 'June'].includes(month)) return 1;
        if (['July', 'August', 'September'].includes(month)) return 2;
        if (['October', 'November', 'December'].includes(month)) return 3;
        return 4;
    }

    function saveAll() {

        let payload = [];
        let entity_id = $('#entity_id').val();
        let branch_id = $('#branch_id').val();

        document.querySelectorAll('.month-card').forEach(m => {

            let month = m.dataset.monthCard;

            m.querySelectorAll('.week-per').forEach((w, i) => {

                payload.push({
                    company: document.getElementById('entity_id').value,
                    year: document.getElementById('year_picker').value,
                    quarter: getQuarter(month),
                    month: month,
                    week: i + 1,
                    percentage: parseFloat(w.value) || 0,
                    target: parseFloat(m.querySelectorAll('.week-target')[i].value) || 0,
                    pre_sale: parseInt(m.querySelectorAll('.week-pre')[i].value) || 0,
                    post_sale: parseInt(m.querySelectorAll('.week-post')[i].value) || 0
                });

            });
        });
        if (branch_id) {
            fetch('/targets/save', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        data: payload,
                        entity_id: entity_id,
                        branch_id: branch_id
                    })
                })
                .then(res => res.json())
                .then(res => {
                    if (res.status) {
                        toastr.success('Target Update Successfully ');
                    } else {
                        toastr.error(res.msg);
                    }
                });

        } else {
            toastr.warning('Branch Is Required');
        }


    }
</script>


<script>
    const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const fileList = document.getElementById("fileList");

    const allowedExtensions = ["xls", "xlsx", "xlsm", "csv"];

    // Highlight on drag
    dropArea.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });

    dropArea.addEventListener("dragleave", () => {
        dropArea.classList.remove("bg-light");
    });

    // Handle drop
    dropArea.addEventListener("drop", (e) => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");

        const droppedFiles = Array.from(e.dataTransfer.files);
        const validFiles = droppedFiles.filter(isValidExcelFile);

        if (validFiles.length !== droppedFiles.length) {
            $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
        } else {
            $('#err_mssg').text("")
        }

        if (validFiles.length > 0) {
            fileInput.files = createFileList(validFiles);
            displayFileNames(validFiles);
            $('#err_mssg').text("")
        }
    });

    // Handle manual file selection
    fileInput.addEventListener("change", (e) => {
        const selectedFiles = Array.from(e.target.files);
        const validFiles = selectedFiles.filter(isValidExcelFile);

        if (validFiles.length !== selectedFiles.length) {
            $('#err_mssg').text("Only Excel files (.xls, .xlsx, .xlsm, .csv) are allowed.")
            fileInput.value = ""; // reset invalid file
            return;
        } else {
            $('#err_mssg').text("")
        }

        displayFileNames(validFiles);
    });

    // Validate file type
    function isValidExcelFile(file) {
        const ext = file.name.split(".").pop().toLowerCase();
        return allowedExtensions.includes(ext);
    }

    // Display file names
    function displayFileNames(files) {
        fileList.innerHTML = files
            .map((file, index) => `<span>${index + 1}. ${file.name}</span>`)
            .join("");
    }

    // Create a new FileList object (needed when filtering dropped files)
    function createFileList(files) {
        const dataTransfer = new DataTransfer();
        files.forEach(file => dataTransfer.items.add(file));
        return dataTransfer.files;
    }
</script>

<script>
    document.getElementById('uploadMaterialForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const errMssg = document.getElementById('err_mssg');
        errMssg.innerHTML = "";



        const fileInput = document.getElementById('fileInput');
        const uploadCourseId = document.getElementById('upload_chap_course_id').value;



        // ✅ For non-lab docs → file required
        if (!fileInput.value || fileInput.files.length === 0) {
            errMssg.textContent = "Please select at least one file to upload.";
            return;
        }


        const formData = new FormData();
        for (let i = 0; i < fileInput.files.length; i++) {
            formData.append('file_upload', fileInput.files[i]);
        }


        const uploadButton = document.getElementById('uploadButton');
        const uploadLoader = document.getElementById('uploadLoader');

        uploadButton.disabled = true;
        uploadLoader.classList.remove('d-none');

        fetch('/targets/import', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                },
                body: formData
            })
            .then(async response => {
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.includes("application/json")) {
                    return response.json();
                } else {
                    const text = await response.text();
                    throw new Error("Server returned non-JSON response:\n" + text);
                }
            })
            .then(data => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                if (data.success) {
                    toastr.success('File uploaded successfully!');


                    // Reset full form
                    document.getElementById('uploadMaterialForm').reset();
                    // Reset file input + file list
                    $('#fileInput').val('');
                    $('#fileList').empty();
                    $('#err_mssg').text('');

                    // Hide modal
                    $('#kt_modal_upload_target').modal('hide');
                    renderUI();
                    setTimeout(() => {
                        loadData();
                    }, 200);
                } else {
                    errMssg.textContent = data.message || "An error occurred while uploading files.";
                }
            })
            .catch(error => {
                uploadLoader.classList.add('d-none');
                uploadButton.disabled = false;
                console.error('Error:', error);
                errMssg.textContent = "An error occurred while uploading files.";
            });
    });
</script>
<script>
    let curr_year = "{{ date('Y') }}";
    $('#year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        // endDate: new Date(),
        orientation: 'bottom'
    }).datepicker('setDate', new Date());
    $('#year_picker').val(curr_year);
</script>
<script>
    function calculateYearSummary() {

        let totalTarget = 0;
        let totalPre = 0;
        let totalPost = 0;

        document.querySelectorAll('.month-card').forEach(m => {

            totalTarget += parseFloat(m.querySelector('.month-target').value) || 0;
            totalPre += parseInt(m.querySelector('.month-pre').value) || 0;
            totalPost += parseInt(m.querySelector('.month-post').value) || 0;

        });

        // ✅ Set values
        document.getElementById('year_target').value = totalTarget.toFixed(0);
        document.getElementById('year_pre').value = totalPre;
        document.getElementById('year_post').value = totalPost;
    }
</script>
<script>
    // function calculateWeeklySplit(container) {

    //     let inputs = container.querySelectorAll('.week-per');

    //     let percentages = [];
    //     let total = 0;

    //     inputs.forEach(i => {
    //         let val = parseFloat(i.value) || 0;
    //         percentages.push(val);
    //         total += val;
    //     });

    //     // ✅ Progress bar
    //     let bar = container.querySelector('.per-bar');
    //     if (bar) {
    //         bar.style.width = total + '%';
    //     }

    //     // ❌ NOT 100 → just mark invalid
    //     if (total !== 100) {
    //         container.classList.add('invalid');
    //         container.classList.remove('valid');
    //         return;
    //     }

    //     // ✅ VALID
    //     container.classList.remove('invalid');
    //     container.classList.add('valid');

    //     let monthTarget = parseFloat(container.querySelector('.month-target').value) || 0;
    //     let monthPre = parseInt(container.querySelector('.month-pre').value) || 0;
    //     let monthPost = parseInt(container.querySelector('.month-post').value) || 0;

    //     // TARGET
    //     percentages.forEach((per, idx) => {
    //         let t = (monthTarget * per) / 100;
    //         container.querySelectorAll('.week-target')[idx].value = t.toFixed(0);
    //     });

    //     // INTEGER SPLIT
    //     let preSplit = splitInteger(monthPre, percentages);
    //     let postSplit = splitInteger(monthPost, percentages);

    //     preSplit.forEach((val, idx) => {
    //         container.querySelectorAll('.week-pre')[idx].value = val;
    //     });

    //     postSplit.forEach((val, idx) => {
    //         container.querySelectorAll('.week-post')[idx].value = val;
    //     });
    // }
    function calculateWeeklySplit(container) {

        let percentages = [];

        container.querySelectorAll('.week-per').forEach(i => {
            console.log(percentages)
            percentages.push(parseFloat(i.value) || 0);
        });

        let total = percentages.reduce((a, b) => a + b, 0);


        // Progress
        let bar = container.querySelector('.per-bar');

        if (bar) {
            bar.style.width = total + '%';
        }

        let monthTarget =
            parseFloat(container.querySelector('.month-target').value) || 0;

        let monthPre =
            parseInt(container.querySelector('.month-pre').value) || 0;

        let monthPost =
            parseInt(container.querySelector('.month-post').value) || 0;

        // TARGET
        percentages.forEach((per, idx) => {

            let t = (monthTarget * per) / 100;

            container.querySelectorAll('.week-target')[idx].value =
                Math.round(t);
        });

        // PRE
        let preSplit = splitInteger(monthPre, percentages);

        preSplit.forEach((val, idx) => {

            container.querySelectorAll('.week-pre')[idx].value = val;
        });

        // POST
        let postSplit = splitInteger(monthPost, percentages);

        postSplit.forEach((val, idx) => {

            container.querySelectorAll('.week-post')[idx].value = val;
        });
    }
</script>
<script>
    function getMonthName(monthNumber) {
        const months = [
            'January', 'February', 'March',
            'April', 'May', 'June',
            'July', 'August', 'September',
            'October', 'November', 'December'
        ];
        return months[monthNumber - 1];
    }
</script>
<script>
    function showMonthSlide(quarter, month, el = null) {

        // Hide all
        document.querySelectorAll(
            `.month-slide[data-quarter="${quarter}"]`
        ).forEach(slide => {
            slide.classList.remove('active');
        });

        // Show selected
        document.querySelector(
            `.month-slide[data-quarter="${quarter}"][data-month="${month}"]`
        )?.classList.add('active');

        // Update tabs
        document.querySelectorAll(
            `.month-tab[data-quarter="${quarter}"]`
        ).forEach(tab => {
            tab.classList.remove('active');
        });

        if (el) {
            el.classList.add('active');
        } else {
            document.querySelector(
                `.month-tab[data-quarter="${quarter}"][data-month="${month}"]`
            )?.classList.add('active');
        }
    }
</script>

<script>
    function sampleToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/target/sample-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link
                   
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
            //  location.reload();
        }

        // Event listener for Excel export button
        $('#sample_excel').on('click', function(e) {
            // e.preventDefault();
            sampleToExcel();
             setTimeout(function() {
                console.log('This message will appear after 2 seconds');
                location.reload();
            }, 2000); // 2000 milliseconds = 2 seconds           
        });
</script>

@endsection